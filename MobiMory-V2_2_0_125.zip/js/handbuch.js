/*
 * Handbuch (seit 2.0.125): die Bedienungsanleitung von MobiMory, als Seiten in der App und als PDF zum Drucken.
 *
 * Die Texte stehen NUR hier, in einer Tabelle: jeder Baustein hat die Sprachen nebeneinander (de, en). Seiten und PDF entstehen daraus.
 * Eine weitere Sprache kommt dazu, indem sie in SPRACHEN eingetragen und in jedem Baustein ergänzt wird (der Test prüft, dass keine fehlt).
 *
 * Aufbau nach Aufgaben („Ich will tanken“), nicht nach Menüpunkten. Beschrieben wird nur, was die App wirklich kann.
 * Bausteine (typ): 'p' Absatz, 'kopf' Zwischenüberschrift, 'schritte' nummerierte Schritte, 'liste' Aufzählung, 'hinweis' hervorgehobener Hinweis, 'bild' Schlüsselbild (id).
 * Schlüsselbilder liegen als handbuch/<id>.jpg (deutsch) in der App; sie entstehen per Skript aus der echten App (siehe docs/HANDBUCH-BILDER.md).
 *
 * Nur reine Funktionen und Texte: kein Speicher, keine Seite. Die Seite steht in ansicht.js (#/handbuch).
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var SPRACHEN = [{ id: 'de', name: 'Deutsch' }, { id: 'en', name: 'English' }];
  var STANDARD_SPRACHE = 'de';
  var BILDER = ['schnellstart', 'cockpit', 'karte', 'wache', 'reisebuch'];

  var UI = {
    de: {
      titel: 'Handbuch', untertitel: 'So benutzt du MobiMory', einleitung: 'Such dir aus, was du tun willst. Jedes Kapitel führt dich Schritt für Schritt.',
      inhalt: 'Inhalt', zurueck: 'Zurück', zumInhalt: 'Zum Inhalt', weiter: 'Weiter', vorher: 'Vorheriges Kapitel', naechstes: 'Nächstes Kapitel',
      sprache: 'Sprache', pdfKnopf: 'Handbuch als PDF speichern', pdfHilfe: 'Das PDF erzeugt MobiMory selbst, auch ohne Internet. Du kannst es ausdrucken.', pdfLaeuft: 'Das PDF wird erzeugt …', pdfFertig: 'Das PDF ist gespeichert: ',
      pdfFehler: 'Das PDF konnte nicht erzeugt werden.', bildFehlt: '(Bild nicht verfügbar)', stand: 'Stand: Version ', kopf: 'Handbuch', fuss: 'MobiMory · Handbuch',
      kapitel: 'Kapitel', dateiName: 'MobiMory_Handbuch_', menueText: 'Bedienungsanleitung nach Aufgaben, auch als PDF zum Drucken', kein: 'Dieses Kapitel gibt es nicht.'
    },
    en: {
      titel: 'Manual', untertitel: 'How to use MobiMory', einleitung: 'Pick what you want to do. Each chapter leads you step by step.',
      inhalt: 'Contents', zurueck: 'Back', zumInhalt: 'To the contents', weiter: 'Next', vorher: 'Previous chapter', naechstes: 'Next chapter',
      sprache: 'Language', pdfKnopf: 'Save manual as PDF', pdfHilfe: 'MobiMory creates the PDF itself, even without internet. You can print it.', pdfLaeuft: 'Creating the PDF …', pdfFertig: 'The PDF is saved: ',
      pdfFehler: 'The PDF could not be created.', bildFehlt: '(Picture not available)', stand: 'Version ', kopf: 'Manual', fuss: 'MobiMory · Manual',
      kapitel: 'Chapter', dateiName: 'MobiMory_Manual_', menueText: 'Instructions by task, also as a PDF to print', kein: 'This chapter does not exist.'
    }
  };

  function p(de, en) { return { typ: 'p', de: de, en: en }; }
  function schritte(de, en) { return { typ: 'schritte', de: de, en: en }; }
  function liste(de, en) { return { typ: 'liste', de: de, en: en }; }
  function kopf(de, en) { return { typ: 'kopf', de: de, en: en }; }
  function hinweis(de, en) { return { typ: 'hinweis', de: de, en: en }; }
  function bild(id, de, en) { return { typ: 'bild', id: id, de: de, en: en }; }

  var KAPITEL = [
    { id: 'schnellstart', titel: { de: 'Schnellstart: mein erstes Fahrzeug und meine erste Reise', en: 'Quick start: my first vehicle and my first trip' }, bloecke: [
      p('In wenigen Minuten bist du unterwegs: eine Person, ein Fahrzeug, deine erste Aktivität. Die Vorarbeit übernimmt MobiMory für dich.',
        'In a few minutes you are on your way: one person, one vehicle, your first activity. MobiMory takes care of the groundwork.'),
      bild('schnellstart', 'Der Schnellstart beim ersten Öffnen.', 'The quick start when you first open the app.'),
      p('Beim ersten Öffnen fragt MobiMory, wie du starten möchtest:', 'When you open MobiMory for the first time, it asks how you want to start:'),
      liste(['„Ich lege eine Person und Fahrzeuge an“: Du legst sofort los, ohne Anmeldung. Alles bleibt auf deinem Gerät.',
        '„Ich melde mich mit einem Konto an“: Du startest mit einer Testwoche (Online-Check, Routenplanung, Dokumente scannen und deine Daten auf mehreren Geräten).',
        '„Erst einmal umschauen“: Du überspringst den Schnellstart. Du findest ihn jederzeit im Hauptmenü.'],
        ['“I create a person and vehicles”: You start right away, without signing in. Everything stays on your device.',
          '“I sign in with an account”: You start with a trial week (online check, route planning, scanning documents and your data on several devices).',
          '“Just look around first”: You skip the quick start. You can find it any time in the main menu.']),
      p('Danach folgen drei Schritte:', 'Then three steps follow:'),
      schritte(['Wer fährt? Gib deinen Namen ein. Du bist bei deiner ersten Aktivität verantwortlich (Skipper oder Fahrer).',
        'Womit bist du unterwegs? Wähle, wo du unterwegs bist (an Land, auf dem Wasser, in der Luft), die Art des Fahrzeugs und gib ihm einen Namen. Maße, Kennzeichen und Papiere trägst du später ein.',
        'Deine erste Aktivität: Wähle, was du machst, und bis wann. Tippe auf „Los geht’s“. Das Logbuch startet und das Cockpit öffnet sich.'],
        ['Who is driving? Enter your name. You are responsible (skipper or driver) for your first activity.',
          'What are you travelling with? Choose where you travel (on land, on the water, in the air), the type of vehicle, and give it a name. You enter dimensions, registration and papers later.',
          'Your first activity: Choose what you are doing, and until when. Tap “Let’s go”. The logbook starts and the cockpit opens.']),
      hinweis('Hast du schon Daten (zum Beispiel aus einer Sicherung), fragt MobiMory beim Start nicht. Den Schnellstart findest du dann im Hauptmenü.',
        'If you already have data (for example from a backup), MobiMory does not ask at the start. You can then find the quick start in the main menu.')
    ] },

    { id: 'einrichten', titel: { de: 'Auf dem Gerät einrichten: Browser, Android, iPad', en: 'Setting up on your device: browser, Android, iPad' }, bloecke: [
      p('MobiMory läuft im Browser (PC, Tablet, Handy) und als Android-App. Die Daten bleiben auf deinem Gerät, solange du kein Konto benutzt.',
        'MobiMory runs in the browser (PC, tablet, phone) and as an Android app. Your data stays on your device as long as you do not use an account.'),
      kopf('Im Browser (PC, Tablet, Handy)', 'In the browser (PC, tablet, phone)'),
      schritte(['Öffne die Adresse von MobiMory im Browser.',
        'Wähle im Browser-Menü „Zum Startbildschirm hinzufügen“ (die Bezeichnung hängt vom Browser ab). Dann startet MobiMory wie eine App und arbeitet auch ohne Internet.'],
        ['Open the MobiMory address in your browser.',
          'In the browser menu choose “Add to home screen” (the wording depends on the browser). MobiMory then starts like an app and also works without internet.']),
      kopf('Auf Android (App)', 'On Android (app)'),
      schritte(['Lade auf mobimory.com/download.html die Datei MobiMory.apk und tippe sie an.',
        'Android fragt einmal, ob Installationen aus dieser Quelle erlaubt sind: erlauben und installieren.',
        'Beim ersten Öffnen fragt Android nach dem Standort (genau, bei Nutzung der App) und nach Benachrichtigungen: beides erlauben.'],
        ['On mobimory.com/download.html download the file MobiMory.apk and tap it.',
          'Android asks once whether installations from this source are allowed: allow it and install.',
          'When you first open the app, Android asks for the location (precise, while using the app) and for notifications: allow both.']),
      liste(['In der Android-App zählen Kilometer und GPS auch im Hintergrund weiter. Solange das Cockpit offen ist, steht oben die Meldung „MobiMory zeichnet auf“.',
        'Beendet dein Gerät die App im Hintergrund, stelle in den Android-Einstellungen der App den Akku auf „Nicht eingeschränkt“.',
        'Die App hat einen eigenen Speicher, getrennt vom Browser. Daten aus dem Browser kommen über eine Sicherung oder dein Konto.',
        'Gibt es eine neue Version, zeigt die App „Neue Version verfügbar“. Tippe auf „Herunterladen“.'],
        ['In the Android app, kilometres and GPS keep counting in the background. As long as the cockpit is open, the message “MobiMory is recording” shows at the top.',
          'If your device stops the app in the background, set the battery for the app to “Unrestricted” in the Android settings.',
          'The app has its own storage, separate from the browser. Data from the browser comes over a backup or your account.',
          'When a new version exists, the app shows “New version available”. Tap “Download”.']),
      kopf('Auf dem iPad und iPhone', 'On the iPad and iPhone'),
      p('Eine Apple-App gibt es noch nicht. Auf dem iPad und iPhone benutzt du MobiMory im Browser Safari.',
        'There is no Apple app yet. On the iPad and iPhone you use MobiMory in the Safari browser.'),
      schritte(['Öffne MobiMory in Safari.',
        'Tippe auf „Teilen“ und wähle „Zum Home-Bildschirm“. Starte MobiMory künftig über das Symbol auf dem Home-Bildschirm.',
        'Für Alarm-Nachrichten: Öffne in MobiMory die Seite „Wache“, tippe auf „Nachrichten auf diesem Gerät erlauben“ und antworte auf die Frage von iOS mit „Erlauben“. Das geht nur, wenn MobiMory vom Home-Bildschirm aus gestartet wurde.'],
        ['Open MobiMory in Safari.',
          'Tap “Share” and choose “Add to Home Screen”. From then on, start MobiMory with the icon on the home screen.',
          'For alarm messages: In MobiMory open the “Watch” page, tap “Allow messages on this device” and answer the iOS question with “Allow”. This only works if MobiMory was started from the home screen.']),
      hinweis('Im Browser läuft die Aufzeichnung nur bei offener App. Im Cockpit hält MobiMory den Bildschirm an, wo der Browser das erlaubt. Wechselst du in eine andere App oder sperrst du den Bildschirm, wird in dieser Zeit nichts aufgezeichnet.',
        'In the browser, recording only runs while the app is open. In the cockpit MobiMory keeps the screen on, where the browser allows it. If you switch to another app or lock the screen, nothing is recorded during that time.')
    ] },

    { id: 'stammdaten', titel: { de: 'Ich lege mein Fahrzeug an und pflege meine Stammdaten', en: 'I add my vehicle and keep my master data' }, bloecke: [
      p('Die Stammdaten sind alles, was du einmal einträgst und immer wieder brauchst. Du findest sie im Hauptmenü unter „Stammdaten“.',
        'Master data is everything you enter once and need again and again. You find it in the main menu under “Master data”.'),
      liste(['Fahrzeuge und Fahrzeugarten', 'Personen (Besatzung und Gäste) und Tiere', 'Nachweisarten (zum Beispiel Führerschein, Ausweis, Heimtierausweis)', 'Orte (Heimat- und Reiseorte, Standorte und Besuche) und Gebiete (Länder und Reviere mit ihren Regeln)',
        'Adressen (Werkstätten, Lieferanten und Händler)', 'Arten von Aktivitäten und Arten von Ereignissen (für Logbuch und Cockpit)', 'Merkmale und Einheiten, Kostenarten und Zahlungsmittel'],
        ['Vehicles and vehicle types', 'People (crew and guests) and animals', 'Types of proof (for example driving licence, ID, pet passport)', 'Places (home and travel places, locations and visits) and areas (countries and waters with their rules)',
          'Addresses (workshops, suppliers and dealers)', 'Types of activities and types of events (for logbook and cockpit)', 'Characteristics and units, cost types and means of payment']),
      kopf('Fahrzeug anlegen', 'Adding a vehicle'),
      schritte(['Öffne Stammdaten › Fahrzeuge und tippe auf „Fahrzeug anlegen“.', 'Wähle die Art und gib dem Fahrzeug einen Namen. Name und Art genügen. Maße, Kennzeichen und Papiere trägst du später ein.',
        'Öffne das Fahrzeug und tippe auf „Angaben ändern“, um Angaben zu ergänzen. Jede Änderung bleibt im Änderungsverlauf.'],
        ['Open Master data › Vehicles and tap “Add vehicle”.', 'Choose the type and give the vehicle a name. Name and type are enough. You enter dimensions, registration and papers later.',
          'Open the vehicle and tap “Change details” to add information. Every change stays in the change history.']),
      kopf('Die 19 Fahrzeugarten', 'The 19 vehicle types'),
      liste(['An Land (8): Auto, Motorrad, Transporter, Lkw, Wohnmobil, Wohnwagen, Anhänger, Bootstrailer',
        'Auf dem Wasser (10): Motorboot, Segelboot Monohull, Segelboot Katamaran, Segelboot Jolle oder Kleinboot, Schlauchboot oder RIB, Jetski, Hausboot, Beiboot oder Dinghy, Paddel- oder Ruderboot, Sonstiges Wasserfahrzeug',
        'In der Luft (1): Flugzeug'],
        ['On land (8): car, motorcycle, van, truck, motorhome, caravan, trailer, boat trailer',
          'On the water (10): motorboat, sailing boat monohull, sailing boat catamaran, sailing boat dinghy or small boat, inflatable or RIB, jet ski, houseboat, tender or dinghy, paddle or rowing boat, other watercraft',
          'In the air (1): aeroplane']),
      p('Eigene Arten und Untergruppen legst du unter Stammdaten › Fahrzeugarten an.', 'You create your own types and subgroups under Master data › Vehicle types.'),
      kopf('Komponenten', 'Components'),
      p('Ein Fahrzeug hat Hauptkomponenten (zum Beispiel Motor, Tank, Ausrüstung). Darunter kannst du beliebig tief Teile eintragen. So weiß MobiMory, was an Bord ist, und kann Fristen, Störungen und den Grundcheck dazu führen.',
        'A vehicle has main components (for example engine, tank, equipment). Below them you can enter parts to any depth. This way MobiMory knows what is on board and can attach deadlines, faults and the basic check to it.'),
      hinweis('Orte brauchen eine Position (Breite und Länge), damit Route, Wetter und Karte sie nutzen können. Die Ortssuche hilft dir dabei.',
        'Places need a position (latitude and longitude) so that route, weather and map can use them. The place search helps you with this.')
    ] },

    { id: 'planen', titel: { de: 'Ich will eine Route planen: Aktivität, Route, Tag', en: 'I want to plan a route: activity, route, day' }, bloecke: [
      p('Du planst von außen nach innen: zuerst die Aktivität (die ganze Reise), dann die Route, dann die einzelnen Tage.',
        'You plan from the outside in: first the activity (the whole trip), then the route, then the single days.'),
      kopf('1. Die Aktivität', '1. The activity'),
      schritte(['Öffne Funktionen › Aktivitäten und tippe auf „Aktivität planen“.', 'Wähle die Art (zum Beispiel Urlaub oder Törn), das Fahrzeug, von und bis wann, und die verantwortliche Person.',
        'Trage Start, Ziel und Zwischenziele ein. Die Zwischenziele sind eine nummerierte Liste. Mit „Hoch“ und „Runter“ änderst du die Reihenfolge. Es sind so viele Zwischenziele möglich, wie die Aktivität Tage hat, höchstens 25. Jedes braucht einen Ort mit Position.'],
        ['Open Functions › Activities and tap “Plan activity”.', 'Choose the type (for example holiday or cruise), the vehicle, from and until when, and the responsible person.',
          'Enter start, destination and stopovers. The stopovers are a numbered list. Use “Up” and “Down” to change the order. As many stopovers are possible as the activity has days, at most 25. Each needs a place with a position.']),
      kopf('2. Die Route', '2. The route'),
      p('Bei der Aktivität öffnest du „Route und Wetter“. Dort liest du eine Routendatei (GPX) ein, zum Beispiel aus deiner Navigations-App. Du siehst den Fahrplan und kannst das Wetter holen.',
        'At the activity you open “Route and weather”. There you load a route file (GPX), for example from your navigation app. You see the schedule and can fetch the weather.'),
      kopf('3. Der Tag', '3. The day'),
      p('Jede Aktivität besteht aus Tagen. Jeder Tag hat einen Start und ein Ziel. Tag 2 startet am Ziel von Tag 1, du kannst es ändern. Trage bei jedem Tag die Uhrzeit des Beginns ein.',
        'Each activity consists of days. Each day has a start and a destination. Day 2 starts at the destination of day 1; you can change it. Enter the start time for every day.'),
      p('Bei Straßenfahrzeugen plant MobiMory einen Tag für sich:', 'For road vehicles MobiMory plans one day at a time:'),
      schritte(['Öffne die Seite des Tages und tippe auf „Tag planen“. Du kannst vorher bis zu 10 Zwischenziele für diesen Tag wählen.',
        'MobiMory plant vom Start zum Ziel des Tages, mit den Maßen und Gewichten deines Fahrzeugs. Du siehst Länge, Fahrzeit und Warnungen.',
        'Die Tagesroute kannst du als GPX-Datei sichern.'],
        ['Open the page of the day and tap “Plan day”. Beforehand you can choose up to 10 stopovers for this day.',
          'MobiMory plans from the start to the destination of the day, using your vehicle’s dimensions and weights. You see length, travel time and warnings.',
          'You can save the day route as a GPX file.']),
      hinweis('Jede geplante Tagesroute zählt als 1 Route in deinem Konto: fünf Tage sind fünf Routen. Die Routenplanung läuft über dein MobiMory-Konto (ab Stufe Mittel). Für Wasserfahrzeuge plant MobiMory keine Route; du kannst das Ziel in einer Navigations-App öffnen.',
        'Each planned day route counts as 1 route in your account: five days are five routes. Route planning runs over your MobiMory account (from the Medium level). For watercraft MobiMory does not plan a route; you can open the destination in a navigation app.'),
      kopf('Voraussichtliche Ankunft (ETA)', 'Estimated arrival (ETA)'),
      p('Die ETA steht beim Tag und nach dem Ablegen. Bei Straßenfahrzeugen rechnet sie mit der Länge der geplanten Tagesroute und der Reisegeschwindigkeit deines Fahrzeugs. Ist der Tag noch nicht geplant, steht dort „unklar“ und der Hinweis, den Tag zu planen. Strömung, Schleusen, Pausen und Tide sind nicht enthalten. Das ist eine Hilfestellung und keine rechtliche Aussage.',
        'The ETA shows at the day and after casting off. For road vehicles it uses the length of the planned day route and your vehicle’s cruising speed. If the day is not planned yet, it shows “unclear” and the hint to plan the day. Current, locks, breaks and tide are not included. This is an aid and not a legal statement.')
    ] },

    { id: 'checks', titel: { de: 'Ich prüfe, ob alles stimmt: Reisecheck und Grundcheck', en: 'I check that everything is in order: trip check and basic check' }, bloecke: [
      p('Reisecheck: Er sagt dir, was für diese Reise nötig ist (Papiere, Ausrüstung, Regeln der Länder und Gebiete) und ob es bei dir erfüllt ist. Du findest ihn unter Funktionen › Reisecheck. Für einen einzelnen Tag gibt es den Check am Tag.',
        'Trip check: It tells you what is needed for this trip (papers, equipment, rules of the countries and areas) and whether you meet it. You find it under Functions › Trip check. For a single day there is the check at the day.'),
      p('Grundcheck: Er prüft ein Fahrzeug an seinem Heimatort. Er fragt: Was braucht dieses Fahrzeug im Heimatland an Papieren und Grundausrüstung? Du brauchst dafür keine Aktivität. Du öffnest ihn am Fahrzeug.',
        'Basic check: It checks a vehicle at its home location. It asks: What papers and basic equipment does this vehicle need in its home country? You do not need an activity for it. You open it at the vehicle.'),
      liste(['Jeder Punkt zeigt Quelle und Stand. Es steht dort: vorhanden, zu wenig, fehlt oder unklar.', 'Fehlt etwas, führt ein Link direkt zur Ausrüstung des Fahrzeugs oder zu den Nachweisen.',
        'Heißt ein Punkt bei dir anders (zum Beispiel „Persönliche Schwimmhilfe“ statt „Rettungsweste“), wählst du bei diesem Punkt „Habe ich unter anderem Namen“. MobiMory setzt nie von selbst etwas gleich.',
        'Der Online-Check läuft über dein Konto und zählt zum Kontingent (Mittel 3, Voll 10 in 12 Monaten, egal ob Reisecheck, Tagcheck oder Grundcheck). Schlägt eine Recherche fehl, wird nicht gezählt.',
        'Nach einem Reisecheck merkt sich MobiMory die Ergebnisse als Regeln bei den Orten und Gebieten, mit Datum. Reist du wieder dorthin, siehst du zuerst diesen Überblick mit dem Hinweis, dass die Daten veraltet sein können.'],
        ['Each item shows its source and date. It says: present, too few, missing or unclear.', 'If something is missing, a link leads directly to the vehicle’s equipment or to the proofs.',
          'If an item has a different name for you (for example “personal flotation aid” instead of “life jacket”), choose “I have it under another name” at that item. MobiMory never treats things as equal by itself.',
          'The online check runs over your account and counts towards the quota (Medium 3, Full 10 in 12 months, whether trip check, day check or basic check). If a search fails, it is not counted.',
          'After a trip check, MobiMory remembers the results as rules at the places and areas, with a date. If you travel there again, you first see this overview with the note that the data may be out of date.']),
      hinweis('Die Checks sind eine Hilfe für die Planung und keine rechtsgültige Aussage. Die letzte Verantwortung hat der Skipper bzw. Fahrer. Zum Check gehen keine Namen und keine Nummern ins Netz.',
        'The checks are an aid for planning and not a legally binding statement. The final responsibility lies with the skipper or driver. No names and no numbers go online for the check.')
    ] },

    { id: 'wetter', titel: { de: 'Ich will das Wetter wissen: Vorhersage, Wellen, Tide', en: 'I want to know the weather: forecast, waves, tide' }, bloecke: [
      p('Das Wetter holt MobiMory für die Punkte zwischen Start und Ziel eines Tages, passend zur Ankunftszeit an jedem Punkt. Die Quelle ist Open-Meteo.',
        'MobiMory fetches the weather for the points between the start and the destination of a day, matching the arrival time at each point. The source is Open-Meteo.'),
      schritte(['Öffne die Seite des Tages. Der Tag braucht Start, Ziel mit Position, die Uhrzeit des Beginns und eine Geschwindigkeit.', 'Tippe auf „Wetter online holen“. Später heißt der Knopf „Wetter neu holen“.',
        'Du siehst je Punkt Himmel, Temperatur, Wind, Böen und Regen. Bei Wasserfahrzeugen kommen Wellen, Wasserstand sowie Hoch- und Niedrigwasser dazu.'],
        ['Open the page of the day. The day needs a start, a destination with position, the start time and a speed.', 'Tap “Fetch weather online”. Later the button reads “Fetch weather again”.',
          'For each point you see sky, temperature, wind, gusts and rain. For watercraft, waves, water level and high and low water are added.']),
      liste(['Eine Prognose gibt es nur für die nächsten 15 Tage. Für einen Tag, der mehr als einen Tag zurückliegt, holt MobiMory kein Wetter.',
        'Der geholte Stand bleibt im Gerät und ist auch ohne Netz zu sehen. Zum Holen braucht das Gerät Netz.', 'Du kannst das Wetter eines Tages auch von Hand eintragen.',
        'Im Cockpit schreibt „Wetter jetzt“ das Wetter an deinem Standort als Eintrag ins Logbuch. Wie oft das Wetter im Cockpit automatisch geholt wird, stellst du unter Einstellungen › Anzeige ein.'],
        ['A forecast is only available for the next 15 days. For a day that is more than one day in the past, MobiMory does not fetch weather.',
          'The fetched state stays on the device and can be seen without network. Fetching needs network.', 'You can also enter the weather of a day by hand.',
          'In the cockpit, “Weather now” writes the weather at your position as an entry in the logbook. How often the weather is fetched automatically in the cockpit, you set under Settings › Display.']),
      hinweis('Das sind Prognosen und Modellwerte, keine Garantie und keine amtlichen Gezeitentafeln.', 'These are forecasts and model values, no guarantee and no official tide tables.')
    ] },

    { id: 'unterwegs', titel: { de: 'Ich will unterwegs etwas festhalten: Cockpit und Logbuch', en: 'I want to record things on the way: cockpit and logbook' }, bloecke: [
      p('Das Cockpit ist dein Schnellzugriff unterwegs. Du öffnest es bei der Aktivität. Jeder Eintrag bekommt Datum, Uhrzeit und, wenn das Gerät eine Position hat, den Ort. Daraus wächst dein Logbuch.',
        'The cockpit is your quick access on the way. You open it at the activity. Every entry gets date, time and, if the device has a position, the place. Your logbook grows from this.'),
      bild('cockpit', 'Das Cockpit, Seite 1: Position, Ankunftszeit und Rest.', 'The cockpit, page 1: position, arrival time and remaining distance.'),
      p('Das Cockpit hat drei Seiten. Du wischst nach links und rechts, die Punkte unten zeigen, wo du bist.', 'The cockpit has three pages. You swipe left and right; the dots below show where you are.'),
      liste(['Seite 1: Info mit Position und Ankunftszeit', 'Seite 2: die Knöpfe', 'Seite 3: Motoren, Zähler und Tagesabschluss'], ['Page 1: info with position and arrival time', 'Page 2: the buttons', 'Page 3: engines, counters and end-of-day closing']),
      p('Die wichtigsten Knöpfe:', 'The most important buttons:'),
      liste(['Abfahrt und Ankunft (bei Wasserfahrzeugen „Ablegen“ und „Anlegen“)', 'Notiz und Foto', 'Wetter jetzt', 'Ver- und Entsorgung (zum Beispiel Tanken)',
        'Wechsel: Skipper und Rudergänger (die Verantwortung wechselt, zum Beispiel beim Törn)', 'Kurswechsel festhalten (nur Wasserfahrzeuge): Grund wählen, Notiz schreiben, MobiMory trägt Zeit und Position ein',
        'Wache und Karte'],
        ['Departure and arrival (for watercraft “Cast off” and “Moor”)', 'Note and photo', 'Weather now', 'Supply and disposal (for example refuelling)',
          'Change: skipper and helmsman (responsibility changes, for example on a cruise)', 'Record course change (watercraft only): choose a reason, write a note, MobiMory enters time and position',
          'Watch and map']),
      liste(['Schaltest du einen Motor oder Verbraucher ein oder aus, schreibt MobiMory dazu einen Eintrag ins Logbuch.',
        'Am Ende des Tages machst du den Tagesabschluss mit dem tatsächlichen Ziel und einer Notiz.',
        'Etwas vergessen? Trage es im Logbuch nach. Es steht dann als „nachgetragen“ da. Änderst du die Position eines Eintrags, schreibst du dazu, warum; der Verlauf hält es fest.',
        'Das Cockpit kann von selbst zwischen den Seiten, der Karte und den letzten Ereignissen wechseln. Das schont den Bildschirm. Du stellst es unten auf Seite 3 unter „Ansichten-Wechsel“ ein.'],
        ['If you switch an engine or consumer on or off, MobiMory writes an entry in the logbook.',
          'At the end of the day you do the end-of-day closing with the actual destination and a note.',
          'Forgot something? Add it later in the logbook. It then shows as “added later”. If you change the position of an entry, you write why; the history records it.',
          'The cockpit can switch by itself between the pages, the map and the latest events. This saves the screen. You set it on page 3 under “View switching”.']),
      hinweis('Kilometer und GPS werden nur gezählt, solange MobiMory offen ist. Nur die Android-App zeichnet auch im Hintergrund auf.',
        'Kilometres and GPS are only counted while MobiMory is open. Only the Android app also records in the background.')
    ] },

    { id: 'karte', titel: { de: 'Ich will die Karte nutzen', en: 'I want to use the map' }, bloecke: [
      p('Die Karte öffnest du im Cockpit mit „Karte“ oder bei der Aktivität. Sie füllt den ganzen Bildschirm.', 'You open the map in the cockpit with “Map” or at the activity. It fills the whole screen.'),
      bild('karte', 'Die Karte: Route, gefahrener Weg und deine Position.', 'The map: route, travelled path and your position.'),
      liste(['Du siehst die Route, die Wetterpunkte, den gefahrenen Weg und deine Position. Auf der Karte siehst du auch, wo du auf der Route liegst und ob du früher oder später bist als geplant.',
        'Bei Wasserfahrzeugen zeigt die blaue Linie den Soll-Kurs, die orange den gefahrenen Weg. Die Wechselpunkte stehen als Nummern darauf.',
        'Mit „Folgen“ bleibt die Karte bei dir. Mit „Alles zeigen“ siehst du die ganze Route.',
        'Einträge mit Position erscheinen mit eigenem Zeichen, zum Beispiel „!“ für eine Störung. Unter „Ereignisse“ wählst du, welche Arten du sehen willst, für alle Aktivitäten und bei jeder Aktivität extra.',
        'Für einen einzelnen Tag gibt es die Karte des Tages mit Tagesroute, Start, Ziel und Warnstellen.',
        'Wasserfahrzeuge können auf Wunsch Seezeichen (Tonnen, Leuchtfeuer, Häfen) von OpenSeaMap zeigen.'],
        ['You see the route, the weather points, the travelled path and your position. On the map you also see where you are on the route and whether you are earlier or later than planned.',
          'For watercraft the blue line shows the planned course, the orange one the travelled path. The waypoints are shown on it as numbers.',
          'With “Follow” the map stays with you. With “Show all” you see the whole route.',
          'Entries with a position appear with their own symbol, for example “!” for a fault. Under “Events” you choose which kinds you want to see, for all activities and separately for each activity.',
          'For a single day there is the day map with day route, start, destination and warning spots.',
          'Watercraft can show seamarks (buoys, lights, harbours) from OpenSeaMap on request.']),
      kopf('Karte ohne Internet', 'Map without internet'),
      p('Tippe vor der Fahrt auf „Offline-Karte holen“. MobiMory lädt dann die Kartenbilder für deine Route aufs Gerät, bei Wasserfahrzeugen mit den Seezeichen. Ohne Internet und ohne geholte Karte zeigt die Karte „Kein Internet“.',
        'Before the trip tap “Fetch offline map”. MobiMory then loads the map images for your route onto the device, for watercraft with the seamarks. Without internet and without a fetched map, the map shows “No internet”.'),
      hinweis('Die Seezeichen sind nur eine Information und keine amtliche Karte. Es gibt keine Wassertiefen. Für die Navigation bleiben deine Navigations-App und die amtliche Seekarte zuständig.',
        'The seamarks are information only and not an official chart. There are no water depths. For navigation your navigation app and the official nautical chart remain responsible.')
    ] },

    { id: 'tanken', titel: { de: 'Ich will tanken', en: 'I want to refuel' }, bloecke: [
      p('Tanken trägst du im Cockpit über den Knopf „Ver- und Entsorgung“ ein.', 'You enter refuelling in the cockpit with the button “Supply and disposal”.'),
      schritte(['Tippe im Cockpit auf „Ver- und Entsorgung“.',
        'Wähle bei „Was?“: Treibstoff tanken, Gasflasche tauschen, Frischwasser auffüllen, Grauwasser, Schwarzwasser oder Chemietoilette entleeren. MobiMory zeigt nur, was dein Fahrzeug als Tank hat.',
        'Trage die Angaben ein, nach denen MobiMory fragt, zum Beispiel die Menge und den Preis.'],
        ['In the cockpit tap “Supply and disposal”.',
          'Under “What?” choose: refuel, change gas bottle, fill fresh water, empty grey water, black water or chemical toilet. MobiMory only shows what your vehicle has as a tank.',
          'Enter the details MobiMory asks for, for example the quantity and the price.']),
      p('Nach dem Tanken rechnet MobiMory alles, was sich rechnen lässt: Liter je Betriebsstunde, je Kilometer, je Seemeile und je Tag. Die Betriebsstunden und Kilometer kommen aus den Zählern. Der Literpreis steht mit drei Stellen hinter dem Komma.',
        'After refuelling, MobiMory calculates everything that can be calculated: litres per operating hour, per kilometre, per nautical mile and per day. The operating hours and kilometres come from the counters. The price per litre is shown with three decimal places.'),
      p('Den Verbrauch siehst du unter Einstellungen › Anzeige in der Einheit, die du wählst.', 'You see the consumption under Settings › Display in the unit you choose.')
    ] },

    { id: 'wache', titel: { de: 'Ich will sicher ankern: Wache und Standortwache', en: 'I want to anchor safely: watch and location watch' }, bloecke: [
      p('Die Wache ist deine Alarmanlage. Du öffnest sie im Cockpit mit dem Knopf „Wache“.', 'The watch is your alarm system. You open it in the cockpit with the button “Watch”.'),
      bild('wache', 'Die Wache: Radius wählen und „Wache starten“ tippen.', 'The watch: choose a radius and tap “Start watch”.'),
      schritte(['Wähle den Radius.', 'Stelle ein, ob Alarmton und Vibration an diesem Gerät kommen sollen und ob MobiMory warnen soll, wenn sich dieses Gerät 15 Minuten lang nicht mehr meldet.', 'Tippe auf „Wache starten“.'],
        ['Choose the radius.', 'Set whether alarm sound and vibration should come on this device, and whether MobiMory should warn if this device does not report for 15 minutes.', 'Tap “Start watch”.']),
      liste(['Ankerwache: Vor Anker merkt sich MobiMory die Position. Treibt das Fahrzeug über den gewählten Radius hinaus, schlägt die App Alarm mit Ton, Abstand, Richtung und einer Zeichnung des Versatzes.',
        'Standortwache: Bei Stillstand oder festgemacht überwacht sie jedes Fahrzeug, auch an Land.', 'Die Wache braucht kein Internet.',
        '„Ton aus“ stellt den Alarmton ab.'],
        ['Anchor watch: At anchor MobiMory remembers the position. If the vehicle drifts beyond the chosen radius, the app sounds the alarm with sound, distance, direction and a drawing of the offset.',
          'Location watch: At standstill or when moored it watches any vehicle, also on land.', 'The watch does not need internet.',
          '“Sound off” turns off the alarm sound.']),
      kopf('Alarm auf deinen anderen Geräten', 'Alarm on your other devices'),
      schritte(['Melde dich auf den Geräten mit demselben Konto an.', 'Öffne auf jedem Gerät die Seite „Wache“ und tippe auf „Nachrichten auf diesem Gerät erlauben“. Beantworte die Frage des Geräts mit „Zulassen“.',
        'Mit „Test-Nachricht an meine anderen Geräte“ prüfst du, ob es klappt.'],
        ['Sign in on the devices with the same account.', 'On each device open the “Watch” page and tap “Allow messages on this device”. Answer the device’s question with “Allow”.',
          'With “Test message to my other devices” you check that it works.']),
      p('Löst die Wache aus, bekommen deine anderen Geräte eine Nachricht, und eine E-Mail geht an dein Konto. Das ist nur eine Zusatzwarnung und braucht Internet.',
        'If the watch triggers, your other devices get a message and an email goes to your account. This is only an additional warning and needs internet.'),
      hinweis('Im Browser muss der Bildschirm an bleiben. Sicherer ist die Android-App. Verlass dich nicht allein auf die App: Sie ist eine Hilfe, keine Garantie.',
        'In the browser the screen must stay on. The Android app is safer. Do not rely on the app alone: it is an aid, not a guarantee.')
    ] },

    { id: 'kasse', titel: { de: 'Ich will meine Reisekasse und Kosten führen', en: 'I want to keep my travel cash and costs' }, bloecke: [
      p('Jede Aktivität kann ihre Reisekasse haben: Bargeld und Fremdwährung der Reise.', 'Every activity can have its own travel cash box: cash and foreign currency of the trip.'),
      liste(['Du öffnest die Reisekasse bei der Aktivität. Dort legst du Kassen an und trägst Ausgaben ein.', 'Mit dem Kassensturz vergleichst du, was in der Kasse sein soll, mit dem, was wirklich drin ist.',
        'Im Kassenbuch (Funktionen › Kassenbuch) siehst du die Kassen aller Aktivitäten. Jede Zeile führt zur Reisekasse.',
        'Kosten (Funktionen › Kosten) zeigen Fixkosten, variable Kosten, Instandhaltung und Wertverlust über alle Fahrzeuge.',
        'An einem Posten kannst du ein Foto und Belege anhängen. Falsch eingegeben? Auf der Seite des Postens: Korrigieren, Ausblenden oder Löschen. Löschen fragt vorher nach.'],
        ['You open the travel cash box at the activity. There you create cash boxes and enter expenses.', 'With the cash check you compare what should be in the box with what is really in it.',
          'In the cash book (Functions › Cash book) you see the cash boxes of all activities. Each line leads to the travel cash box.',
          'Costs (Functions › Costs) show fixed costs, variable costs, maintenance and loss of value across all vehicles.',
          'You can attach a photo and receipts to an item. Entered wrongly? On the item’s page: Correct, Hide or Delete. Delete asks first.']),
      p('Kosten werden einem Tag zugeordnet. Die Summe der Reise ist die Summe aller Tage, dazu kommen Posten ohne Tag.', 'Costs are assigned to a day. The sum of the trip is the sum of all days, plus items without a day.')
    ] },

    { id: 'stoerung', titel: { de: 'Ich melde eine Störung: Werkstatt und Schadensbericht', en: 'I report a fault: workshop and damage report' }, bloecke: [
      p('In der Werkstatt (Funktionen › Werkstatt) meldest du Störungen, planst Arbeiten und hakst sie ab.', 'In the workshop (Functions › Workshop) you report faults, plan work and complete it.'),
      schritte(['Öffne das Fahrzeug oder die betroffene Komponente und tippe auf „Störung melden“.', 'Beschreibe, was nicht geht, und ob das Fahrzeug nutzbar bleibt.',
        'Plane die Arbeit und trage sie als erledigt ein, wenn sie fertig ist.'],
        ['Open the vehicle or the affected component and tap “Report fault”.', 'Describe what does not work and whether the vehicle remains usable.', 'Plan the work and mark it as done when it is finished.']),
      kopf('Schadensbericht für die Versicherung', 'Damage report for the insurance'),
      p('Unter Funktionen › Schadensbericht hältst du einen Schaden fest, mit Fotos und Belegen. Beim Speichern legt MobiMory automatisch eine Störung in der Werkstatt dazu. Den Bericht gibst du als Seite oder als PDF aus, zum Drucken oder Mailen.',
        'Under Functions › Damage report you record damage, with photos and receipts. When you save, MobiMory automatically adds a fault in the workshop. You output the report as a page or as a PDF, to print or email.')
    ] },

    { id: 'reisebuch', titel: { de: 'Ich mache aus der Reise ein Buch: Reisebuch und PDF', en: 'I turn the trip into a book: travel book and PDF' }, bloecke: [
      p('Aus deiner Reise wird ein Buch: Reise, Tag für Tag, Ereignisse, besuchte Orte und deine Fotos. Du liest es in MobiMory, druckst es aus oder speicherst es als PDF. MobiMory ändert dabei nichts an deinen Daten.',
        'Your trip becomes a book: trip, day by day, events, visited places and your photos. You read it in MobiMory, print it or save it as a PDF. MobiMory does not change your data in the process.'),
      bild('reisebuch', 'Das Reisebuch: wähle, was ins Buch kommt.', 'The travel book: choose what goes into the book.'),
      schritte(['Öffne Funktionen › Reisebuch und wähle die Reise.', 'Wähle eine fertige Zusammenstellung oder stelle selbst zusammen, was ins Buch soll. Eigene Auswahlen kannst du mit Namen speichern.', 'Lies das Buch, drucke es oder tippe auf „PDF erzeugen“.'],
        ['Open Functions › Travel book and choose the trip.', 'Choose a ready-made selection or put together yourself what should go into the book. You can save your own selections with a name.', 'Read the book, print it or tap “Create PDF”.']),
      liste(['Reisetagebuch: Bilder und die Texte aus dem Tagesabschluss.', 'Vollständiges Logbuch: jeder Schritt der Reise, jeder Eintrag mit Datum, Uhrzeit, Position und Herkunft, dazu Motorlaufzeiten, Wetter und Störungen.',
        'Nur Zahlen der Reise und Tagesabschlüsse ohne Bilder gibt es auch.', 'Karten (Übersichtskarte und Karte je Tag) werden als Bild bei der Reise gespeichert und sehen später auch ohne Internet gleich aus.'],
        ['Travel diary: pictures and the texts from the end-of-day closing.', 'Complete logbook: every step of the trip, every entry with date, time, position and origin, plus engine running times, weather and faults.',
          'There are also “Trip figures only” and “End-of-day closings without pictures”.', 'Maps (overview map and map per day) are saved as a picture with the trip and later look the same even without internet.']),
      hinweis('Kosten stehen nur im Buch, wenn du es willst. Fotos stehen nur im Buch, wenn sie auf diesem Gerät liegen; im PDF sind sie verkleinert.',
        'Costs are only in the book if you want them. Photos are only in the book if they are on this device; in the PDF they are reduced in size.')
    ] },

    { id: 'geraete', titel: { de: 'Ich nutze mehrere Geräte: Konto, Abgleich, Schlüsselwort', en: 'I use several devices: account, sync, keyword' }, bloecke: [
      p('Mit einem Konto hast du deine Daten auf allen deinen Geräten. Das Konto findest du unter Einstellungen › Deine Daten › Konto.', 'With an account you have your data on all your devices. You find the account under Settings › Your data › Account.'),
      schritte(['Melde dich auf dem ersten Gerät an. Gibt es noch kein Konto, entsteht beim ersten Mal eines, mit einer Testwoche.', 'Melde dich auf dem zweiten Gerät mit demselben Konto an.',
        'Tippe auf dem neuen Gerät einmal auf „Jetzt abgleichen“. Das holt deine Daten.'],
        ['Sign in on the first device. If there is no account yet, one is created the first time, with a trial week.', 'Sign in on the second device with the same account.',
          'On the new device tap “Sync now” once. This fetches your data.']),
      liste(['In der Testwoche und mit den Stufen Mittel und Voll gleicht MobiMory von allein ab, solange die App offen ist: kurz nach einer Änderung, sonst fragt sie jede Minute nach Neuem.',
        'Mit Basic gleichst du nur von Hand ab. Ohne Netz arbeitest du wie bisher.', 'Läuft die Aufzeichnung auf zwei Geräten, werden Weg und Kilometer zusammengeführt statt überschrieben.'],
        ['In the trial week and with the Medium and Full levels MobiMory syncs by itself while the app is open: shortly after a change, otherwise it asks every minute for news.',
          'With Basic you only sync by hand. Without network you work as before.', 'If recording runs on two devices, path and kilometres are merged instead of overwritten.']),
      kopf('Das Schlüsselwort', 'The keyword'),
      p('Alles Private geht nur verschlüsselt zum Dienst, und der Dienst kann es nicht lesen: Notizen, Telefonnummern, E-Mail- und Postadressen, Nummern der Nachweise, Namen im Reisecheck, Scans und die GPS-Spur. Den Schlüssel dafür bildet dein Schlüsselwort. Du gibst es einmal je Gerät ein, es bleibt auf dem Gerät gespeichert. Auf dem zweiten Gerät brauchst du dasselbe Wort.',
        'Everything private goes to the service only encrypted, and the service cannot read it: notes, phone numbers, email and postal addresses, proof numbers, names in the trip check, scans and the GPS track. Your keyword forms the key for this. You enter it once per device, it stays saved on the device. On the second device you need the same word.'),
      hinweis('Vergisst du das Schlüsselwort und hast kein Gerät mehr mit gespeichertem Wort, sind diese Angaben nicht mehr zu öffnen. Schreib es dir auf.',
        'If you forget the keyword and no longer have a device with the word saved, this information can no longer be opened. Write it down.'),
      kopf('Sicherung', 'Backup'),
      p('Unter Einstellungen › Deine Daten › Sicherung erstellst du eine Sicherung deiner Daten, zum Beispiel als Datei. Mach das regelmäßig; MobiMory erinnert dich daran. Eine Sicherung beim Dienst wird mit deinem Schlüsselwort verschlüsselt.',
        'Under Settings › Your data › Backup you create a backup of your data, for example as a file. Do this regularly; MobiMory reminds you. A backup at the service is encrypted with your keyword.')
    ] },

    { id: 'verleih', titel: { de: 'Ich verleihe oder gebe ein Fahrzeug ab', en: 'I lend or hand over a vehicle' }, bloecke: [
      kopf('Verleihen (Funktionen › Verleih)', 'Lending (Functions › Lending)'),
      liste(['Du gibst ein Fahrzeug für eine andere Person frei: nur zum Lesen, für höchstens 12 Monate. Die Person bekommt einen Code, meldet sich mit ihrer E-Mail-Adresse an und trägt den Code ein.',
        'Sie sieht das Fahrzeug, die Fristen und Zähler, die Dokumente und das letzte Prüfergebnis. Kosten, Notizen, Nachweise, Aktivitäten und Ereignisse sieht sie nicht.',
        'Leihst du ein Fahrzeug, machst du die Reise wie jede andere, mit Logbuch und Reisebuch. Endet die Leihe, bleibt alles lesbar, du kannst aber nichts Neues anlegen.',
        'Mit den Kontrollpapieren (Funktionen › Kontrollpapiere) erzeugst du einen Kontroll-Code. Wer ihn hat, kann Papiere und das Prüfergebnis ohne Konto lesen, zum Beispiel bei einer Kontrolle.'],
        ['You share a vehicle with another person: read-only, for at most 12 months. The person gets a code, signs in with their email address and enters the code.',
          'They see the vehicle, the deadlines and counters, the documents and the last check result. They do not see costs, notes, proofs, activities and events.',
          'If you borrow a vehicle, you make the trip like any other, with logbook and travel book. When the loan ends, everything stays readable, but you cannot add anything new.',
          'With the control papers (Functions › Control papers) you create a control code. Whoever has it can read papers and the check result without an account, for example at a control.']),
      kopf('Abgeben (Funktionen › Fahrzeug abgeben)', 'Handing over (Functions › Hand over vehicle)'),
      schritte(['Wähle das Fahrzeug und den Grund: verkauft, verschenkt oder verschrottet, mit Datum.', 'Das Fahrzeug verschwindet aus den Auswahllisten, bleibt bei dir aber lesbar, unter „Abgegebene Fahrzeuge“. Du kannst es jederzeit wieder aktiv setzen.',
        'Für den neuen Besitzer erzeugst du die Übergabedatei und, wenn du willst, ein PDF der Technik-Akte.'],
        ['Choose the vehicle and the reason: sold, given away or scrapped, with date.', 'The vehicle disappears from the selection lists but stays readable for you, under “Handed-over vehicles”. You can reactivate it at any time.',
          'For the new owner you create the handover file and, if you want, a PDF of the technical file.']),
      hinweis('Die Übergabedatei enthält die technische Geschichte (Komponenten, Zähler, Fristen, Störungen, Dokumente). Aktivitäten, Logbuch, Kosten, Reisekasse und Personen gehören nicht dazu.',
        'The handover file contains the technical history (components, counters, deadlines, faults, documents). Activities, logbook, costs, travel cash and people are not part of it.')
    ] }
  ];

  function sprache(s) { return UI[s] ? s : STANDARD_SPRACHE; }
  function ui(s) { return UI[sprache(s)]; }
  function inhaltsliste(s) {
    s = sprache(s);
    return KAPITEL.map(function (k, i) { return { id: k.id, nr: i + 1, titel: k.titel[s] }; });
  }
  /* Ein Kapitel in einer Sprache: { id, nr, titel, bloecke: [{ typ, text | punkte, bild?: id }], vorher, naechstes } oder null. */
  function kapitel(id, s) {
    s = sprache(s);
    var i = -1; KAPITEL.forEach(function (k, n) { if (k.id === id) i = n; });
    if (i < 0) return null;
    var k = KAPITEL[i];
    return { id: k.id, nr: i + 1, titel: k.titel[s],
      bloecke: k.bloecke.map(function (b) {
        var o = { typ: b.typ };
        if (b.typ === 'schritte' || b.typ === 'liste') o.punkte = b[s]; else o.text = b[s];
        if (b.typ === 'bild') o.bild = b.id;
        return o;
      }),
      vorher: i > 0 ? { id: KAPITEL[i - 1].id, titel: KAPITEL[i - 1].titel[s] } : null,
      naechstes: i < KAPITEL.length - 1 ? { id: KAPITEL[i + 1].id, titel: KAPITEL[i + 1].titel[s] } : null };
  }

  function dateiName(s, version) { return ui(s).dateiName + String(version || '').replace(/[^0-9A-Za-z.]+/g, '_') + '.pdf'; }

  /*
   * Das PDF des ganzen Handbuchs (MM.Pdf, ohne Netz). bilder: { <bildId>: Uint8Array mit JPEG } (fehlt eines, steht ein Hinweis).
   * ctx: { version, datum }. Gibt { bytes, name, bilder, ohneBild } zurück.
   */
  function pdf(s, bilder, ctx) {
    s = sprache(s); bilder = bilder || {}; ctx = ctx || {};
    var u = UI[s], eingefuegt = 0, ohne = 0;
    var d = MM.Pdf.neu({ fuss: u.fuss + (ctx.version ? ' · ' + ctx.version : ''), titel: 'MobiMory ' + u.titel, datum: ctx.datum });
    d.titelseite({ kopf: 'MobiMory', titel: u.titel, untertitel: u.untertitel, zeilen: ctx.version ? [[u.stand.replace(/ $/, ''), ctx.version]] : [], fuss: MM.Texte ? MM.Texte.COPYRIGHT : '' });
    d.titel(u.titel, u.untertitel);
    d.absatz(u.einleitung, { grau: true });
    d.abschnitt(u.inhalt);
    inhaltsliste(s).forEach(function (k) { d.absatz(k.nr + '. ' + k.titel); });
    KAPITEL.forEach(function (_, i) {
      var k = kapitel(KAPITEL[i].id, s);
      d.abschnitt(k.nr + '. ' + k.titel);
      k.bloecke.forEach(function (b) {
        if (b.typ === 'p') d.absatz(b.text);
        else if (b.typ === 'kopf') d.absatz(b.text, { fett: true, groesse: 11 });
        else if (b.typ === 'hinweis') d.absatz(b.text, { fett: true });
        else if (b.typ === 'liste') b.punkte.forEach(function (t) { d.absatz('• ' + t); });
        else if (b.typ === 'schritte') b.punkte.forEach(function (t, n) { d.absatz((n + 1) + '. ' + t); });
        else if (b.typ === 'bild') {
          var by = bilder[b.bild];
          if (by && d.bild(by, { maxH: 260, unterschrift: b.text })) eingefuegt++;
          else { ohne++; d.absatz(u.bildFehlt, { grau: true, groesse: 8 }); }
        }
      });
    });
    return { bytes: d.bytes(), name: dateiName(s, ctx.version), bilder: eingefuegt, ohneBild: ohne };
  }

  MM.Handbuch = { SPRACHEN: SPRACHEN, STANDARD_SPRACHE: STANDARD_SPRACHE, BILDER: BILDER, KAPITEL: KAPITEL, UI: UI, sprache: sprache, ui: ui, inhaltsliste: inhaltsliste, kapitel: kapitel, dateiName: dateiName, pdf: pdf };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
