"""Erzeugt die Schlüsselbilder des Handbuchs aus der echten App (Playwright), mit Beispieldaten.
Aufruf: python3 handbuch_bilder.py <App-Ordner> <Ausgabe-Ordner>
Die App wird lokal ausgeliefert, die Karten-Kacheln werden durch eine neutrale Kachel ersetzt (kein Netz nötig)."""
import sys, os, io, subprocess, time, json
from playwright.sync_api import sync_playwright
from PIL import Image

app, aus = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
os.makedirs(aus, exist_ok=True)
PORT = 8766
srv = subprocess.Popen([sys.executable, '-m', 'http.server', str(PORT), '-d', app, '--bind', '127.0.0.1'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.0)
URL = f'http://127.0.0.1:{PORT}/index.html'

kachel = io.BytesIO()
t = Image.new('RGB', (256, 256), (206, 224, 232))
for i in range(0, 256, 64):
    for j in range(256):
        t.putpixel((i, j), (190, 210, 220)); t.putpixel((j, i), (190, 210, 220))
t.save(kachel, 'PNG'); KACHEL = kachel.getvalue()

SEED = """
async () => {
  const sp = await new MM.Speicher.IdbSpeicher().oeffnen();
  const d = new MM.Daten.Daten(sp); await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const mia = (await d.personAnlegen({ bezeichnung: 'Mia', funktionen: ['Fahrer'] })).id;
  const fz = (await d.fahrzeugAnlegen('motorboot', { bezeichnung: 'Seestern', reisegeschwindigkeit: '12', hoechstgeschwindigkeit: '25' })).id;
  const ort = async (n, b, l) => (await d.ortAnlegen({ bezeichnung: n, positionBreite: String(b), positionLaenge: String(l) })).id;
  await ort('Kiel', 54.32, 10.14); await ort('Eckernförde', 54.47, 9.84); await ort('Flensburg', 54.79, 9.44);
  const r = await d.logbuchSofortStarten({ fahrzeugId: fz, verantwortlichId: mia, artId: '' });
  if (!r.ok) throw new Error(JSON.stringify(r));
  const gpx = '<gpx><rte><rtept lat="54.32" lon="10.14"><n>Kiel</n></rtept><rtept lat="54.40" lon="10.00"/><rtept lat="54.47" lon="9.84"><n>Eckernförde</n></rtept><rtept lat="54.62" lon="9.70"/><rtept lat="54.79" lon="9.44"><n>Flensburg</n></rtept></rte></gpx>';
  const imp = await d.routeImportieren(r.id, gpx, 'ostsee.gpx');
  if (imp && imp.id) await d.routeAendern(imp.id, { bezeichnung: 'Kiel – Flensburg', geschwindigkeit: '6', einheit: 'kn' });
  try { await d.ereignisSchnell(r.id, 'Notiz', { text: 'Ablegen in Kiel, Wind 3 Bft aus West' }); } catch (e) {}
  return r.id;
}
"""

def shot(page, name):
    png = page.screenshot(type='png')
    Image.open(io.BytesIO(png)).convert('RGB').save(os.path.join(aus, name + '.jpg'), 'JPEG', quality=82)
    print('Bild', name)

with sync_playwright() as pw:
    br = pw.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
    ctx = br.new_context(viewport={'width': 900, 'height': 680}, locale='de-DE', timezone_id='Europe/Berlin',
                         geolocation={'latitude': 54.40, 'longitude': 10.00}, permissions=['geolocation'], service_workers='block')
    ctx.route('**/*tile.openstreetmap.org/**', lambda r: r.fulfill(status=200, content_type='image/png', body=KACHEL))
    ctx.route('**/*openseamap.org/**', lambda r: r.fulfill(status=200, content_type='image/png', body=KACHEL))
    page = ctx.new_page()
    fehler = []
    page.on('pageerror', lambda e: fehler.append(str(e)))
    # 1. Schnellstart (leere App)
    page.goto(URL + '#/schnellstart'); page.wait_for_timeout(1500)
    shot(page, 'schnellstart')
    # Beispieldaten anlegen
    akt = page.evaluate(SEED)
    page.reload(); page.wait_for_timeout(800)
    for name, h in [('cockpit', f'#/aktivitaet/{akt}'), ('karte', f'#/aktivitaet/{akt}/karte'), ('wache', f'#/aktivitaet/{akt}/wache'), ('reisebuch', f'#/reisebuch/{akt}')]:
        page.goto(URL + h); page.reload(); page.wait_for_timeout(2200)
        shot(page, name)
    print('Seitenfehler:', fehler)
    br.close()
srv.terminate()
