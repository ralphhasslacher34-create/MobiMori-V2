# Handbuch-Bilder neu erzeugen

Die fünf Schlüsselbilder (`handbuch/schnellstart.jpg`, `cockpit.jpg`, `karte.jpg`, `wache.jpg`, `reisebuch.jpg`) entstehen aus der echten App mit Beispieldaten, damit sie bei einer neuen Version neu durchlaufen können.

```
python3 tools/handbuch_bilder.py <App-Ordner> <App-Ordner>/handbuch
```

Voraussetzung: Python mit `playwright` und `Pillow`, Google Chrome. Das Skript startet die App lokal, legt Beispieldaten an (Person Mia, Boot Seestern, Route Kiel – Flensburg), ersetzt die Karten-Kacheln durch eine neutrale Kachel und speichert die Bilder.

Bilder gibt es erst in der Sprache der App (Deutsch). Sobald die App selbst Englisch kann, kommt eine zweite Bildreihe dazu.
