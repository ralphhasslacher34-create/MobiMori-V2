'use strict';
/* 2.0.124: 19 Fahrzeugarten und der geführte Start (Schnellstart). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/rudergaenger.js');
require('../js/status.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/reiseorte.js');
require('../js/schnellstart.js');
require('../js/texte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const F = MM.Fahrzeugarten, S = MM.Schnellstart;
const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

function neueDaten() {
  let t = 0;
  const start = new Date(2026, 10, 22, 9, 0, 0).getTime();
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(start + (t++)).toISOString() });
}

/* ---------- Teil A: 19 Fahrzeugarten ---------- */
test('Arten: 19 wählbare, Land 8, Wasser 10, Luft 1, entfernte Arten gibt es nicht mehr', () => {
  const alle = F.alle();
  assert.equal(alle.length, 19);
  const welt = (w) => alle.filter((a) => a.welt === w).map((a) => a.id);
  assert.deepEqual(welt('land').sort(), ['anhaenger', 'auto', 'bootstrailer', 'lkw', 'motorrad', 'transporter', 'wohnmobil', 'wohnwagen']);
  assert.equal(welt('wasser').length, 10);
  assert.deepEqual(welt('luft'), ['flugzeug']);
  ['oldtimer', 'zeltanhaenger', 'sportboot', 'wasserskiboot', 'wohnboot', 'motorschiff'].forEach((i) => assert.equal(F.art(i), null, i));
  ['boot', 'segelboot'].forEach((i) => assert.ok(F.art(i) && !alle.some((a) => a.id === i), i + ' ist nur Gruppe'));
});

test('Arten: Motorboot 16 m ist „Sehr groß“, Wasserski und Übernachten bleiben als Eignung', () => {
  assert.ok(F.art('motorboot'));
  const quelle = lesen('js/aktivitaeten.js') + lesen('js/logbuch.js');
  assert.ok(/Wasserski[\s\S]{0,200}\['motorboot'\]/.test(quelle));
});

/* ---------- Teil B: reine Funktionen ---------- */
test('Schnellstart: Fortschritt, Schritte und Zurück', () => {
  assert.deepEqual(S.fortschritt('person'), { nr: 1, von: 3, text: 'Schritt 1 von 3', prozent: 33 });
  assert.equal(S.fortschritt('aktivitaet').prozent, 100);
  assert.equal(S.fortschritt('x'), null);
  assert.equal(S.naechsterSchritt(false, false), 'person');
  assert.equal(S.naechsterSchritt(true, false), 'fahrzeug');
  assert.equal(S.naechsterSchritt(true, true), 'aktivitaet');
  assert.ok(S.schrittErlaubt('person', false, false));
  assert.ok(!S.schrittErlaubt('fahrzeug', false, false) && S.schrittErlaubt('fahrzeug', true, false));
  assert.ok(!S.schrittErlaubt('aktivitaet', true, false) && S.schrittErlaubt('aktivitaet', true, true));
  assert.equal(S.vorherigerSchritt('person'), null);
  assert.equal(S.vorherigerSchritt('aktivitaet'), 'fahrzeug');
});

test('Schnellstart: nötig nur ohne Entscheidung und ohne Daten; Prüfungen', () => {
  assert.equal(S.noetig(null, 0, 0), true);
  assert.equal(S.noetig(null, 1, 0), false);
  assert.equal(S.noetig({ stand: 'uebersprungen' }, 0, 0), false);
  assert.equal(S.noetig({ stand: 'fertig' }, 0, 0), false);
  assert.equal(S.pruefePerson({}).ok, false);
  assert.equal(S.pruefePerson({ bezeichnung: 'Ralph' }).ok, true);
  assert.equal(S.pruefeFahrzeug({ artId: 'auto' }).fehler.bezeichnung !== undefined, true);
  assert.equal(S.pruefeFahrzeug({ artId: 'auto', bezeichnung: 'Mia' }).ok, true);
  const wasser = S.artenInWelt(F.alle(), 'wasser');
  assert.equal(wasser.length, 10);
  assert.ok(wasser.every((a) => a.wert && a.label));
});

/* ---------- Teil B: Ablauf mit Daten ---------- */
test('Ablauf Basic: Weg, Person, Fahrzeug, Start im Cockpit, Aktivitätsarten und Verantwortlicher gesetzt', async () => {
  const d = neueDaten();
  assert.equal(await d.schnellstartNoetig(), true);
  assert.equal((await d.schnellstartWeg('basic')).ok, true);
  assert.equal(await d.schnellstartNoetig(), false);
  assert.equal((await d.schnellstartWeg('quatsch')).ok, false);
  assert.equal((await d.schnellstartPerson({})).ok, false);
  const p = await d.schnellstartPerson({ bezeichnung: 'Ralph' });
  assert.equal(p.ok, true);
  assert.equal((await d.schnellstartFahrzeug({ artId: 'motorboot' })).ok, false);
  const f = await d.schnellstartFahrzeug({ artId: 'motorboot', bezeichnung: 'Seestern' });
  assert.equal(f.ok, true);
  assert.equal((await d.schnellstartLesen()).fahrzeugId, f.id);
  const r = await d.schnellstartStarten({});
  assert.equal(r.ok, true);
  const s = await d.schnellstartLesen();
  assert.equal(s.stand, 'fertig');
  assert.equal(s.aktivitaetId, r.id);
  const akt = await d.aktivitaetLaden(r.id);
  assert.equal(akt.status, 'laeuft');
  const ver = (await d.speicher.alle('verantwortung')).filter((v) => v.aktivitaetId === r.id);
  assert.equal(ver.length, 1); assert.equal(ver[0].personId, p.id);
  assert.ok((await d.speicher.alle('aktivitaetsarten')).length > 0);
});

test('Ablauf: vorhandene Person nehmen, Basic-Grenze 1 Fahrzeug, Überspringen', async () => {
  const d = neueDaten();
  const a = await d.personAnlegen({ bezeichnung: 'Tanja' });
  assert.equal((await d.schnellstartPerson({ personId: a.id })).id, a.id);
  assert.equal((await d.schnellstartPerson({ personId: 'gibtsnicht' })).ok, false);
  assert.equal((await d.schnellstartStarten({})).ok, false, 'ohne Fahrzeug kein Start');
  await d.schnellstartUeberspringen();
  assert.equal((await d.schnellstartLesen()).stand, 'uebersprungen');
  assert.equal(await d.schnellstartNoetig(), false);
});

test('Fertig bleibt fertig, auch beim Überspringen', async () => {
  const d = neueDaten();
  await d.schnellstartPerson({ bezeichnung: 'Ralph' });
  await d.schnellstartFahrzeug({ artId: 'auto', bezeichnung: 'Golf' });
  await d.schnellstartStarten({});
  await d.schnellstartUeberspringen();
  assert.equal((await d.schnellstartLesen()).stand, 'fertig');
});

/* ---------- Einbau ---------- */
test('Einbau: Modul in index.html und Service Worker, Router, Menükachel, Konto-Hinweis', () => {
  const html = lesen('index.html');
  assert.ok(html.indexOf('js/konto.js') < html.indexOf('js/schnellstart.js'));
  assert.ok(lesen('sw.js').includes("'js/schnellstart.js'"));
  const a = lesen('js/ansicht.js');
  assert.ok(/teile\[0\] === 'schnellstart'/.test(a));
  assert.ok(/schnellstartNoetig\(\)\.then/.test(a));
  assert.ok(a.includes("'#/schnellstart'"));
  assert.ok(/Weiter mit dem Schnellstart|MM\.Schnellstart\.TEXTE\.konto/.test(a));
  assert.ok(!/peilung/i.test(lesen('js/schnellstart.js')));
  assert.equal(MM.VERSION, '2.0.125');
  assert.equal(MM.Texte.NEUERUNGEN[1].version, '2.0.124');
});
