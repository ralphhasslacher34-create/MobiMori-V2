'use strict';
/* 2.0.118: Wetterpunkt neben Wechselpunkt (Karte), Mindestabstand und Kursänderung der Wechselpunkte, Reisegeschwindigkeit vorbelegt. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status',
  'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'kartenereignisse', 'texte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const R = MM.Routen;
const lesen = p => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

/* Eine Route: gerade nach Norden (10 Punkte, je rund 100 m), scharfer Knick nach Osten (6 Punkte). */
function punkte() {
  const p = [];
  for (let i = 0; i < 10; i++) p.push({ breite: 40 + i * 0.0009, laenge: 10, name: 'P' + i, km: i * 0.1 });
  for (let i = 1; i <= 6; i++) p.push({ breite: 40 + 9 * 0.0009, laenge: 10 + i * 0.0012, name: 'Q' + i, km: 1 + i * 0.1 });
  return p;
}
function gpx() {
  return '<?xml version="1.0"?><gpx version="1.1" creator="Test"><rte><name>Bogen</name>' + punkte().map(q => '<rtept lat="' + q.breite + '" lon="' + q.laenge + '"><name>' + q.name + '</name></rtept>').join('') + '</rte></gpx>';
}
function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 19, 12, 0, 0).getTime() };
  let n = 0;
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (n++)).toISOString() });
}
async function mitBoot(werte) {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen('motorboot', Object.assign({ bezeichnung: 'Boot' }, werte || {}))).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: fz, vonDatum: '2026-11-19', vonZeit: '19:41', bisDatum: '2026-11-19', bisZeit: '23:00', verantwortlichId: anna });
  assert.ok(r.ok);
  await d.heutigerTag(r.id);
  const imp = await d.routeImportieren(r.id, gpx(), 'bogen.gpx');
  assert.ok(imp.ok, JSON.stringify(imp));
  return { d, id: r.id, fz };
}

/* ---------- F: Mindestabstand und Kursänderung ---------- */
test('Wechselpunkte ohne Regel: wie bisher, alle Punkte', () => {
  const w = R.wechselpunkte(punkte(), 'route', {}, []);
  assert.equal(w.liste.length, 16); assert.equal(w.regel, null); assert.equal(w.ausgeduennt, 0);
  assert.equal(R.wechselpunkte(punkte(), 'route', {}, [], { abstandSm: null, knickGrad: null }).liste.length, 16);
});

test('Mindestabstand: weiche Punkte entfallen, Anfang, Ende und Knick bleiben', () => {
  const w = R.wechselpunkte(punkte(), 'route', {}, [], { abstandSm: 0.5, knickGrad: 30 });
  assert.deepEqual(w.liste.map(x => x.name), ['P0', 'P9', 'Q6']);
  assert.equal(w.ausgeduennt, 13); assert.deepEqual(w.regel, { abstandSm: 0.5, knickGrad: 30 });
  assert.deepEqual(w.liste.map(x => x.nr), [1, 2, 3]);
  assert.equal(w.liste[1].kursHin, R.peilung(40, 10, 40.0081, 10)); assert.equal(w.liste[1].kursWeiter, R.peilung(40.0081, 10, 40.0081, 10.0072));
});

test('Mindestabstand: ein sehr kleiner Wert ändert nichts, ohne Knickwert gilt 30 Grad', () => {
  assert.equal(R.wechselpunkte(punkte(), 'route', {}, [], { abstandSm: 0.01, knickGrad: null }).liste.length, 16);
  const w = R.wechselpunkte(punkte(), 'route', {}, [], { abstandSm: 0.5 });
  assert.deepEqual(w.regel, { abstandSm: 0.5, knickGrad: R.WP_KNICK_STANDARD });
  assert.ok(w.liste.some(x => x.name === 'P9'));
});

test('Mindestabstand: Punkt mit eigenem Namen und Handpunkte bleiben, Namen hängen am Index', () => {
  const w = R.wechselpunkte(punkte(), 'route', { '4': 'Kap' }, [{ id: 'h', name: 'Hand', breite: 40.004, laenge: 10.0001 }], { abstandSm: 0.5, knickGrad: 30 });
  const namen = w.liste.map(x => x.name);
  assert.ok(namen.includes('Kap')); assert.ok(namen.includes('Hand'));
  assert.equal(w.liste.find(x => x.name === 'Kap').index, 4);
  assert.equal(w.liste.find(x => x.name === 'Hand').hand, true);
});

test('Mindestabstand: eine sanfte Kurve verliert Punkte, eine scharfe Ecke nicht', () => {
  const kurve = [];
  for (let i = 0; i <= 18; i++) { const a = i * 5 * Math.PI / 180; kurve.push({ breite: 40 + 0.0015 * Math.sin(a) * 3, laenge: 10 + 0.0015 * (1 - Math.cos(a)) * 3, km: i * 0.05, name: 'K' + i }); }
  const w = R.wechselpunkte(kurve, 'route', {}, [], { abstandSm: 0.3, knickGrad: 30 });
  assert.ok(w.liste.length < kurve.length && w.liste.length >= 2);
  assert.equal(w.liste[0].name, 'K0'); assert.equal(w.liste[w.liste.length - 1].name, 'K18');
});

test('Regel prüfen: Zahlen mit Komma, leer = aus, Knick nur mit Abstand, Grenzen', () => {
  assert.deepEqual(R.wpRegelPruefen({ abstandSm: '0,5', knickGrad: '30' }).werte, { abstandSm: 0.5, knickGrad: 30 });
  assert.deepEqual(R.wpRegelPruefen({ abstandSm: '', knickGrad: '' }).werte, { abstandSm: null, knickGrad: null });
  assert.deepEqual(R.wpRegelPruefen({ abstandSm: '1', knickGrad: '' }).werte, { abstandSm: 1, knickGrad: null });
  assert.ok(R.wpRegelPruefen({ abstandSm: '', knickGrad: '30' }).fehler.abstandSm);
  assert.ok(R.wpRegelPruefen({ abstandSm: '0' }).fehler.abstandSm);
  assert.ok(R.wpRegelPruefen({ abstandSm: 'x' }).fehler.abstandSm);
  assert.ok(R.wpRegelPruefen({ abstandSm: '51' }).fehler.abstandSm);
  assert.ok(R.wpRegelPruefen({ abstandSm: '1', knickGrad: '0' }).fehler.knickGrad);
  assert.ok(R.wpRegelPruefen({ abstandSm: '1', knickGrad: '180' }).fehler.knickGrad);
});

test('Regel speichern: wirkt auf die Route, bleibt bei Umbenennen und Handpunkten, Datei unverändert, Ausschalten stellt alles wieder her', async () => {
  const { d, id } = await mitBoot();
  let ra = await d.routeAnsicht(id);
  assert.equal(ra.route.wechselpunkte.liste.length, 16);
  const bad = await d.wechselpunktRegelSetzen(id, { abstandSm: '', knickGrad: '30' });
  assert.equal(bad.ok, false); assert.ok(bad.fehler.abstandSm);
  const ok = await d.wechselpunktRegelSetzen(id, { abstandSm: '0,5', knickGrad: '30' });
  assert.ok(ok.ok);
  ra = await d.routeAnsicht(id);
  assert.deepEqual(ra.route.wechselpunkte.liste.map(x => x.name), ['P0', 'P9', 'Q6']);
  assert.equal(ra.route.punkte.length, 16, 'Die Punkte der Route bleiben');
  assert.equal(ra.route.wechselpunkte.ausgeduennt, 13);
  assert.ok((await d.wechselpunktBenennen(id, 9, 'Ecke')).ok);
  assert.ok((await d.wechselpunktHandNeu(id, { name: 'Hand', breite: '40,004', laenge: '10,0001' })).ok);
  ra = await d.routeAnsicht(id);
  assert.deepEqual(ra.route.wechselpunkte.regel, { abstandSm: 0.5, knickGrad: 30 }, 'Regel bleibt nach Namen und Handpunkt');
  assert.ok(ra.route.wechselpunkte.liste.some(x => x.name === 'Ecke') && ra.route.wechselpunkte.liste.some(x => x.name === 'Hand'));
  assert.ok((await d.wechselpunktRegelSetzen(id, { abstandSm: '', knickGrad: '' })).ok);
  ra = await d.routeAnsicht(id);
  assert.equal(ra.route.wechselpunkte.regel, null);
  assert.equal(ra.route.wechselpunkte.liste.length, 17);
  assert.ok(ra.route.wechselpunkte.liste.some(x => x.name === 'Ecke'), 'Name bleibt');
});

/* ---------- G: Reisegeschwindigkeit vorbelegt ---------- */
test('Tempo: eigener Wert gewinnt, sonst Fahrzeug, unterwegs Ø Tag, dann Ø fahrend', () => {
  const fz = { reisegeschwindigkeit: 18.52, hoechstgeschwindigkeit: 40 };
  assert.deepEqual(R.tempoVorschlag({ geschwindigkeit: 6, einheit: 'kn' }, fz, 'wasser', null), { eigen: true, wert: 6, einheit: 'kn', herkunft: 'eigen', text: 'Von dir eingetragen.' });
  const a = R.tempoVorschlag({ geschwindigkeit: null, einheit: 'kn' }, fz, 'wasser', null);
  assert.equal(a.eigen, false); assert.equal(a.wert, 10); assert.equal(a.einheit, 'kn'); assert.equal(a.herkunft, 'fahrzeug'); assert.match(a.text, /Fahrzeug/);
  const b = R.tempoVorschlag({ geschwindigkeit: null, einheit: 'kmh' }, fz, 'land', null);
  assert.equal(b.wert, 18.5);
  const c = R.tempoVorschlag({ geschwindigkeit: null, einheit: 'kn' }, fz, 'wasser', { unterwegs: true, tagKmh: 12.96, fahrendKmh: 20 });
  assert.equal(c.herkunft, 'tag'); assert.equal(c.wert, 7);
  const dd = R.tempoVorschlag({ geschwindigkeit: null, einheit: 'kn' }, fz, 'wasser', { unterwegs: true, tagKmh: null, fahrendKmh: 20.4 });
  assert.equal(dd.herkunft, 'fahrend'); assert.equal(dd.wert, 11);
  const e = R.tempoVorschlag({ geschwindigkeit: null, einheit: 'kn' }, fz, 'wasser', { unterwegs: false, tagKmh: 12 });
  assert.equal(e.herkunft, 'fahrzeug', 'ohne laufende Fahrt zählt das Fahrzeug');
  const f = R.tempoVorschlag({ geschwindigkeit: null, einheit: 'kn' }, fz, 'wasser', { unterwegs: true, tagKmh: 90, fahrendKmh: 95 });
  assert.equal(f.herkunft, 'fahrzeug', 'über der Höchstgeschwindigkeit wird übersprungen');
  const g = R.tempoVorschlag({ geschwindigkeit: null }, {}, 'wasser', null);
  assert.equal(g.wert, null); assert.equal(g.einheit, 'kn'); assert.match(g.text, /keine Reisegeschwindigkeit/);
});

test('Tempo: die Route rechnet mit dem Wert des Fahrzeugs, ohne ihn zu speichern; ein eigener Wert gewinnt; Ø folgt der Fahrt', async () => {
  const { d, id, fz } = await mitBoot({ reisegeschwindigkeit: '18,52' });
  let ra = await d.routeAnsicht(id);
  assert.equal(ra.route.tempo.herkunft, 'fahrzeug');
  assert.equal(ra.route.werte.geschwindigkeit, 10); assert.equal(ra.route.werte.einheit, 'kn');
  assert.equal(ra.route.fahrplan.ok, true, 'Fahrplan rechnet ohne Eingabe');
  const gespeichert = await d.routeLaden(ra.route.id);
  assert.equal(gespeichert.aktuell.werte.geschwindigkeit, null, 'nichts gespeichert');
  /* Speichern ohne die Vorbelegung zu ändern behält die Route ohne eigenen Wert */
  const w = ra.route.werte;
  assert.ok((await d.routeAendern(ra.route.id, { bezeichnung: w.bezeichnung, geschwindigkeit: '', einheit: w.einheit, abfahrtDatum: w.abfahrtDatum, abfahrtZeit: w.abfahrtZeit, notiz: 'x' })).ok);
  assert.equal((await d.routeLaden(ra.route.id)).aktuell.werte.geschwindigkeit, null);
  /* Fahrt läuft: Ø Tag */
  d.tempoLive = () => ({ unterwegs: true, tagKmh: 12.96, fahrendKmh: 15 });
  ra = await d.routeAnsicht(id);
  assert.equal(ra.route.tempo.herkunft, 'tag'); assert.equal(ra.route.werte.geschwindigkeit, 7);
  d.tempoLive = null;
  /* Eigener Wert */
  assert.ok((await d.routeAendern(ra.route.id, { bezeichnung: w.bezeichnung, geschwindigkeit: '5', einheit: 'kn', abfahrtDatum: w.abfahrtDatum, abfahrtZeit: w.abfahrtZeit })).ok);
  ra = await d.routeAnsicht(id);
  assert.equal(ra.route.tempo.eigen, true); assert.equal(ra.route.werte.geschwindigkeit, 5);
});

test('Tempo: Fahrzeug ohne Wert lässt das Feld leer mit Hinweis', async () => {
  const { d, id } = await mitBoot();
  const ra = await d.routeAnsicht(id);
  assert.equal(ra.route.tempo.wert, null); assert.equal(ra.route.werte.geschwindigkeit, null);
  assert.match(ra.route.tempo.text, /keine Reisegeschwindigkeit/);
  assert.equal(ra.route.fahrplan.ok, false);
});

/* ---------- E: Karte, Oberfläche, Einbau ---------- */
test('Karte: Wetterpunkt wird neben den Wechselpunkt gesetzt, Schalter und neue Zoom-Prüfung vorhanden', () => {
  const k = lesen('js/kartenansicht.js');
  assert.match(k, /function pinVersetzt/); assert.match(k, /nahBeieinander/);
  assert.match(k, /zeigeWetter && kd\.wetter/); assert.match(k, /zeigeWechsel && kd\.route && kd\.route\.wechselpunkte/);
  assert.match(k, /kv-zeige-wetter/); assert.match(k, /kv-zeige-wechsel/); assert.match(k, /'zoomend'/);
  assert.match(k, /Punkte der Route/);
});

test('Oberfläche: Einstellung Mindestabstand auf der Routenseite, Tempo-Hinweis, Live-Werte', () => {
  const a = lesen('js/ansicht.js');
  assert.match(a, /Weniger Wechselpunkte \(Mindestabstand\)/); assert.match(a, /wechselpunktRegelSetzen/);
  assert.match(a, /daten\.tempoLive = function/); assert.match(a, /r\.tempo && r\.tempo\.text/);
  assert.match(a, /function tempoSatzHolen/); assert.match(a, /Die Reisegeschwindigkeit ist vorbelegt/);
  assert.doesNotMatch(a, /placeholder: 'z\. B\. 0,5', value: '0,5'/);
});

test('Einbau: Version 2.0.118, Neuerungen, Changelog', () => {
  assert.equal(MM.VERSION, '2.0.125');
  assert.equal(MM.Texte.NEUERUNGEN[7].version, '2.0.118'); assert.equal(MM.Texte.NEUERUNGEN[8].version, '2.0.117');
  const n = MM.Texte.NEUERUNGEN[7].punkte.join(' ');
  assert.match(n, /Wetterpunkt/); assert.match(n, /Mindestabstand/); assert.match(n, /Reisegeschwindigkeit/);
  assert.ok(lesen('CHANGELOG.md').includes('## 2.0.118'));
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.125';"));
  assert.equal(JSON.parse(lesen('package.json')).version, '2.0.125');
  const l = JSON.parse(lesen('package-lock.json')); assert.equal(l.version, '2.0.125'); assert.equal(l.packages[''].version, '2.0.125');
  assert.ok(lesen('README.md').includes('Version 2.0.125'));
  assert.ok(lesen('server/EINRICHTUNG.md').startsWith('# Konto-Dienst: Einrichtung und Updates (Stand 2.0.125'));
  /* Das Wort „Peilung“ nur in routen.js */
  ['ansicht', 'daten', 'logbuch', 'texte', 'kartenansicht'].forEach(f => assert.doesNotMatch(lesen('js/' + f + '.js'), /Peilung/));
});
