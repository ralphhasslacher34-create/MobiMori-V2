'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/personen.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;

/* feste Uhr: 3. November 2026, mittags */
const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  const wm = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' });
  const boot = await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' });
  return { d, wm: wm.id, boot: boot.id };
}
const oelwechsel = z => ({ bezeichnung: 'Ölwechsel', kategorie: 'wartung', kalenderWert: '12', kalenderEinheit: 'monate',
  zaehlerId: z, zaehlerWert: '10000', wirkung: 'warnen', vorwarnTage: '30', vorwarnZaehler: '500' });

test('Heute kommt aus der Uhr der Daten-Schicht', async () => {
  const { d } = await neu();
  assert.equal(d.heute(), '2026-11-03');
});

test('Zähler anlegen am Fahrzeug und an einer Komponente; Name im Verlauf', async () => {
  const { d, boot } = await neu();
  const m = await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor Backbord' });
  const a = await d.zaehlerAnlegen(boot, null, 'stunden', { bezeichnung: 'Betriebsstunden' });
  const b = await d.zaehlerAnlegen(boot, m.id, 'stunden', { bezeichnung: 'Betriebsstunden Motor' });
  assert.ok(a.ok && b.ok);
  const liste = await d.zaehlerListe(boot);
  assert.deepEqual(liste.map(z => z.label), ['Betriebsstunden (Fahrzeug)', 'Betriebsstunden Motor (Motor Backbord)']);
  assert.equal(liste[0].einheit, 'h');
  assert.equal(liste[0].stand, null);
});

test('Zähler: Pflichtangaben und Zugehörigkeit', async () => {
  const { d, wm, boot } = await neu();
  assert.ok((await d.zaehlerAnlegen(wm, null, 'strecke', { bezeichnung: ' ' })).fehler.bezeichnung);
  assert.ok((await d.zaehlerAnlegen(wm, null, 'ufo', { bezeichnung: 'X' })).fehler.art);
  const m = await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor' });
  assert.equal((await d.zaehlerAnlegen(wm, m.id, 'stunden', { bezeichnung: 'X' })).ok, false);
  assert.equal((await d.zaehlerAnlegen('gibt-es-nicht', null, 'stunden', { bezeichnung: 'X' })).ok, false);
});

test('Zählerstand: Verlauf, steigt nur, Datum nicht in der Zukunft', async () => {
  const { d, wm } = await neu();
  const z = (await d.zaehlerAnlegen(wm, null, 'strecke', { bezeichnung: 'Kilometerstand' })).id;
  assert.ok((await d.zaehlerStandEintragen(z, { wert: '84.200'.replace('.', ''), datum: '2026-10-01' })).ok);
  assert.ok((await d.zaehlerStandEintragen(z, { wert: '85000', datum: '2026-11-01' })).ok);
  const zu = await d.zaehlerStandEintragen(z, { wert: '84000' });
  assert.equal(zu.ok, false); assert.ok(zu.fehler.wert.includes('niedriger'));
  assert.ok((await d.zaehlerStandEintragen(z, { wert: '86000', datum: '2027-01-01' })).fehler.datum);
  assert.ok((await d.zaehlerStandEintragen(z, { wert: '' })).fehler.wert);
  assert.ok((await d.zaehlerStandEintragen(z, { wert: 'abc' })).fehler.wert);
  const c = await d.zaehlerLaden(z);
  assert.equal(c.staende.length, 2);
  assert.equal(c.stand.wert, 85000);
  assert.deepEqual(c.staende.map(s => s.nr), [2, 1]);
  /* gleicher Stand ist erlaubt */
  assert.ok((await d.zaehlerStandEintragen(z, { wert: '85000' })).ok);
});

test('Stand mit Komma und ohne Datum: Datum ist heute', async () => {
  const { d, boot } = await neu();
  const z = (await d.zaehlerAnlegen(boot, null, 'stunden', { bezeichnung: 'Betriebsstunden' })).id;
  await d.zaehlerStandEintragen(z, { wert: '112,5' });
  const c = await d.zaehlerLaden(z);
  assert.equal(c.stand.wert, 112.5); assert.equal(c.stand.datum, '2026-11-03');
});

test('Zähler umbenennen = neuer Eintrag, alter bleibt', async () => {
  const { d, wm } = await neu();
  const z = (await d.zaehlerAnlegen(wm, null, 'strecke', { bezeichnung: 'Kilometer' })).id;
  const r = await d.zaehlerAendern(z, { bezeichnung: 'Kilometerstand' });
  assert.ok(r.ok && r.geaendert);
  const c = await d.zaehlerLaden(z);
  assert.equal(c.bezeichnung, 'Kilometerstand'); assert.equal(c.verlauf.length, 2);
  assert.equal(c.verlauf[1].eintrag.werte.bezeichnung, 'Kilometer');
  assert.equal((await d.zaehlerAendern(z, { bezeichnung: 'Kilometerstand' })).geaendert, false);
});

test('Frist nur mit Kalender anlegen: Ausgangswert ist heute, Status in Ordnung', async () => {
  const { d, wm } = await neu();
  const r = await d.fristAnlegen(wm, null, { bezeichnung: 'Verbandskasten', kategorie: 'pruefung', kalenderWert: '24', kalenderEinheit: 'monate', vorwarnTage: '30' });
  assert.ok(r.ok);
  const f = await d.fristLaden(r.id);
  assert.equal(f.letzte.datum, '2026-11-03');
  assert.equal(f.letzte.art, 'ausgangswert');
  assert.equal(f.status.status, 'ok');
  assert.equal(f.status.kalender.faelligAm, '2028-11-03');
  assert.equal(f.aktuell.werte.wirkung, 'warnen');
});

test('Frist mit "zuletzt erledigt am" in der Vergangenheit wird überfällig', async () => {
  const { d, wm } = await neu();
  const r = await d.fristAnlegen(wm, null, { bezeichnung: 'Feuerlöscher', kategorie: 'pruefung', kalenderWert: '12', vorwarnTage: '30', zuletztAm: '2025-06-01' });
  assert.ok(r.ok);
  const f = await d.fristLaden(r.id);
  assert.equal(f.status.status, 'ueberfaellig');
  assert.equal(f.status.kalender.faelligAm, '2026-06-01');
});

test('Frist mit Zähler: Ausgangsstand fehlt = Fehler, mit Stand = gerechnet', async () => {
  const { d, wm } = await neu();
  const z = (await d.zaehlerAnlegen(wm, null, 'strecke', { bezeichnung: 'Kilometerstand' })).id;
  /* noch kein Stand: ab heute zählen geht nicht */
  const ohne = await d.fristAnlegen(wm, null, oelwechsel(z));
  assert.equal(ohne.ok, false); assert.ok(ohne.fehler.zuletztStand);
  await d.zaehlerStandEintragen(z, { wert: '84200' });
  const mit = await d.fristAnlegen(wm, null, oelwechsel(z));
  assert.ok(mit.ok);
  let f = await d.fristLaden(mit.id);
  assert.equal(f.letzte.zaehlerstand, 84200);
  assert.equal(f.status.status, 'ok');
  assert.equal(f.status.zaehler.faelligBei, 94200);
  await d.zaehlerStandEintragen(z, { wert: '93900' });
  f = await d.fristLaden(mit.id);
  assert.equal(f.status.status, 'bald');
  await d.zaehlerStandEintragen(z, { wert: '94500' });
  f = await d.fristLaden(mit.id);
  assert.equal(f.status.status, 'ueberfaellig'); assert.equal(f.status.zaehler.rest, -300);
});

test('Frist mit Datum in der Vergangenheit braucht den Zählerstand damals', async () => {
  const { d, wm } = await neu();
  const z = (await d.zaehlerAnlegen(wm, null, 'strecke', { bezeichnung: 'Kilometerstand' })).id;
  await d.zaehlerStandEintragen(z, { wert: '90000' });
  const a = await d.fristAnlegen(wm, null, Object.assign(oelwechsel(z), { zuletztAm: '2026-03-01' }));
  assert.equal(a.ok, false); assert.ok(a.fehler.zuletztStand);
  const hoch = await d.fristAnlegen(wm, null, Object.assign(oelwechsel(z), { zuletztAm: '2026-03-01', zuletztStand: '95000' }));
  assert.equal(hoch.ok, false); assert.ok(hoch.fehler.zuletztStand.includes('höher'));
  const gut = await d.fristAnlegen(wm, null, Object.assign(oelwechsel(z), { zuletztAm: '2026-03-01', zuletztStand: '84200' }));
  assert.ok(gut.ok);
});

test('Boot: 100 Betriebsstunden oder 12 Monate, was zuerst eintritt', async () => {
  const { d, boot } = await neu();
  const m = await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor' });
  const z = (await d.zaehlerAnlegen(boot, m.id, 'stunden', { bezeichnung: 'Betriebsstunden Motor' })).id;
  await d.zaehlerStandEintragen(z, { wert: '200' });
  const r = await d.fristAnlegen(boot, m.id, { bezeichnung: 'Ölwechsel', kategorie: 'wartung', kalenderWert: '12', zaehlerId: z, zaehlerWert: '100', vorwarnTage: '30', vorwarnZaehler: '10' });
  assert.ok(r.ok);
  await d.zaehlerStandEintragen(z, { wert: '305' });
  const f = await d.fristLaden(r.id);
  assert.equal(f.status.kalender.status, 'ok');
  assert.equal(f.status.zaehler.status, 'ueberfaellig');
  assert.equal(f.status.status, 'ueberfaellig');
  assert.equal(f.komponente.id, m.id);
});

test('Frist: Pflichtangaben', async () => {
  const { d, wm } = await neu();
  const basis = { bezeichnung: 'X', kategorie: 'wartung' };
  assert.ok((await d.fristAnlegen(wm, null, { kategorie: 'wartung', kalenderWert: '12' })).fehler.bezeichnung);
  assert.ok((await d.fristAnlegen(wm, null, Object.assign({}, basis))).fehler.kalenderWert, 'mindestens eine Grenze');
  assert.ok((await d.fristAnlegen(wm, null, { bezeichnung: 'X', kalenderWert: '12' })).fehler.kategorie);
  assert.ok((await d.fristAnlegen(wm, null, Object.assign({}, basis, { kalenderWert: '0' }))).fehler.kalenderWert);
  assert.ok((await d.fristAnlegen(wm, null, Object.assign({}, basis, { kalenderWert: '1,5' }))).fehler.kalenderWert);
  assert.ok((await d.fristAnlegen(wm, null, Object.assign({}, basis, { kalenderWert: '12', wirkung: 'streng' }))).fehler.wirkung);
  assert.ok((await d.fristAnlegen(wm, null, Object.assign({}, basis, { kalenderWert: '12', zuletztAm: '2027-01-01' }))).fehler.zuletztAm);
  assert.ok((await d.fristAnlegen(wm, null, Object.assign({}, basis, { zaehlerWert: '100' }))).fehler.zaehlerId);
  assert.equal((await d.fristenListe(wm)).length, 0);
});

test('Frist: Zähler eines anderen Fahrzeugs wird abgelehnt', async () => {
  const { d, wm, boot } = await neu();
  const z = (await d.zaehlerAnlegen(boot, null, 'stunden', { bezeichnung: 'Betriebsstunden' })).id;
  await d.zaehlerStandEintragen(z, { wert: '10' });
  const r = await d.fristAnlegen(wm, null, { bezeichnung: 'X', kategorie: 'wartung', zaehlerId: z, zaehlerWert: '100' });
  assert.equal(r.ok, false); assert.ok(r.fehler.zaehlerId);
});

test('Erledigt eintragen setzt die Rechnung neu an; alte Erledigungen bleiben', async () => {
  const { d, wm } = await neu();
  const r = await d.fristAnlegen(wm, null, { bezeichnung: 'Feuerlöscher', kategorie: 'pruefung', kalenderWert: '12', vorwarnTage: '30', zuletztAm: '2025-06-01' });
  assert.equal((await d.fristLaden(r.id)).status.status, 'ueberfaellig');
  const e = await d.durchfuehrungAnlegen(r.id, { datum: '2026-10-20', notiz: 'neu geprüft' });
  assert.ok(e.ok);
  const f = await d.fristLaden(r.id);
  assert.equal(f.status.status, 'ok');
  assert.equal(f.status.kalender.faelligAm, '2027-10-20');
  assert.equal(f.durchfuehrungen.length, 2);
  assert.deepEqual(f.durchfuehrungen.map(x => x.art), ['erledigt', 'ausgangswert']);
  assert.ok((await d.durchfuehrungAnlegen(r.id, { datum: '2027-02-01' })).fehler.datum);
});

test('Erledigt mit Zähler: Stand wird übernommen und im Zähler nachgetragen', async () => {
  const { d, wm } = await neu();
  const z = (await d.zaehlerAnlegen(wm, null, 'strecke', { bezeichnung: 'Kilometerstand' })).id;
  await d.zaehlerStandEintragen(z, { wert: '84200' });
  const fr = await d.fristAnlegen(wm, null, oelwechsel(z));
  /* Ohne Stand und heute: aktueller Zählerstand wird genommen */
  const a = await d.durchfuehrungAnlegen(fr.id, {});
  assert.ok(a.ok);
  assert.equal((await d.fristLaden(fr.id)).letzte.zaehlerstand, 84200);
  /* Mit höherem Stand: auch im Zähler eingetragen */
  const b = await d.durchfuehrungAnlegen(fr.id, { zaehlerstand: '90000' });
  assert.ok(b.ok);
  const zc = await d.zaehlerLaden(z);
  assert.equal(zc.stand.wert, 90000);
  assert.equal(zc.staende.length, 2);
  assert.ok(zc.stand.notiz.includes('Ölwechsel'));
  /* Niedriger als bei der letzten Erledigung: abgelehnt */
  const c = await d.durchfuehrungAnlegen(fr.id, { zaehlerstand: '80000', datum: '2026-11-02' });
  assert.equal(c.ok, false); assert.ok(c.fehler.zaehlerstand.includes('niedriger'));
  /* Altes Datum ohne Stand: abgelehnt */
  assert.ok((await d.durchfuehrungAnlegen(fr.id, { datum: '2026-10-01' })).fehler.zaehlerstand);
});

test('Frist ändern = neuer Eintrag, Zähler im Verlauf mit Namen, Grenzen neu gerechnet', async () => {
  const { d, wm } = await neu();
  const z = (await d.zaehlerAnlegen(wm, null, 'strecke', { bezeichnung: 'Kilometerstand' })).id;
  await d.zaehlerStandEintragen(z, { wert: '1000' });
  const fr = (await d.fristAnlegen(wm, null, { bezeichnung: 'Ölwechsel', kategorie: 'wartung', kalenderWert: '12', vorwarnTage: '30' })).id;
  const r = await d.fristAendern(fr, { bezeichnung: 'Ölwechsel', kategorie: 'wartung', kalenderWert: '12', vorwarnTage: '30', zaehlerId: z, zaehlerWert: '5000', wirkung: 'sperre' });
  assert.ok(r.ok && r.geaendert);
  const f = await d.fristLaden(fr);
  assert.equal(f.verlauf.length, 2);
  assert.equal(f.aktuell.werte.wirkung, 'sperre');
  const u = f.verlauf[0].aenderungen.find(x => x.key === 'zaehlerId');
  assert.equal(u.neu, 'Kilometerstand (Fahrzeug)');
  /* Ausgangsstand fehlt, weil die Frist ursprünglich ohne Zähler angelegt war */
  assert.equal(f.status.zaehler.status, 'unbekannt');
  assert.equal((await d.fristAendern(fr, f.aktuell.werte)).geaendert, false);
  assert.ok((await d.fristAendern(fr, { bezeichnung: '' })).fehler.bezeichnung);
});

test('Fristenliste sortiert überfällig zuerst; Übersicht zählt je Fahrzeug', async () => {
  const { d, wm, boot } = await neu();
  await d.fristAnlegen(wm, null, { bezeichnung: 'B ok', kategorie: 'wartung', kalenderWert: '24', zuletztAm: '2026-10-01' });
  await d.fristAnlegen(wm, null, { bezeichnung: 'A überfällig', kategorie: 'pruefung', kalenderWert: '12', zuletztAm: '2025-01-01' });
  await d.fristAnlegen(wm, null, { bezeichnung: 'C bald', kategorie: 'pruefung', kalenderWert: '12', vorwarnTage: '30', zuletztAm: '2025-11-20' });
  assert.deepEqual((await d.fristenListe(wm)).map(f => f.aktuell.werte.bezeichnung), ['A überfällig', 'C bald', 'B ok']);
  const u = await d.fristenUebersicht();
  assert.deepEqual(u[wm], { ueberfaellig: 1, bald: 1, unbekannt: 0 });
  assert.deepEqual(u[boot], { ueberfaellig: 0, bald: 0, unbekannt: 0 });
});

test('Fristen an Komponenten bleiben beim Fahrzeug gelistet und kennen ihre Komponente', async () => {
  const { d, boot } = await neu();
  const m = await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor' });
  await d.fristAnlegen(boot, m.id, { bezeichnung: 'Impeller', kategorie: 'wartung', kalenderWert: '12' });
  await d.fristAnlegen(boot, null, { bezeichnung: 'Rettungsinsel', kategorie: 'pruefung', kalenderWert: '36' });
  const alle = await d.fristenListe(boot);
  assert.equal(alle.length, 2);
  assert.deepEqual(alle.filter(x => x.frist.komponenteId === m.id).map(x => x.aktuell.werte.bezeichnung), ['Impeller']);
  assert.deepEqual(alle.filter(x => !x.frist.komponenteId).map(x => x.aktuell.werte.bezeichnung), ['Rettungsinsel']);
});

test('Nach dem Löschen aller Daten sind auch Zähler und Fristen weg', async () => {
  const { d, wm } = await neu();
  const z = (await d.zaehlerAnlegen(wm, null, 'strecke', { bezeichnung: 'Kilometerstand' })).id;
  await d.zaehlerStandEintragen(z, { wert: '10' });
  await d.fristAnlegen(wm, null, { bezeichnung: 'X', kategorie: 'wartung', kalenderWert: '12' });
  await d.allesLoeschen();
  for (const t of ['zaehler', 'zaehlerstaende', 'fristen', 'verlaeufe', 'durchfuehrungen']) {
    assert.equal((await d.speicher.alle(t)).length, 0, t);
  }
});
