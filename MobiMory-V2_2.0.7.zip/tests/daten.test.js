'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/personen.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;

async function neu(jetzt) {
  let t = 0;
  const uhr = jetzt || (() => new Date(Date.UTC(2026, 10, 3, 12, 0, t++)).toISOString());
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: uhr });
  await d.starten();
  return d;
}

test('Beim ersten Start entsteht genau ein Datenraum', async () => {
  const d = await neu();
  const a = await d.speicher.alle('datenraeume');
  assert.equal(a.length, 1);
  await d.starten();
  assert.equal((await d.speicher.alle('datenraeume')).length, 1);
});

test('Fahrzeug anlegen: erscheint in der Liste, Eintrag Nr. 1, Herkunft Handeingabe', async () => {
  const d = await neu();
  const r = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Fahrzeug A', kennzeichen: 'LB-MM 123' });
  assert.ok(r.ok);
  const liste = await d.fahrzeugListe();
  assert.equal(liste.length, 1);
  assert.equal(liste[0].aktuell.nr, 1);
  assert.equal(liste[0].aktuell.quelle, 'hand');
  assert.equal(liste[0].aktuell.korrekturZu, null);
  assert.equal(liste[0].aktuell.werte.kennzeichen, 'LB-MM 123');
});

test('Ohne Bezeichnung wird nichts gespeichert', async () => {
  const d = await neu();
  const r = await d.fahrzeugAnlegen('auto', { bezeichnung: '   ' });
  assert.equal(r.ok, false);
  assert.ok(r.fehler.bezeichnung);
  assert.equal((await d.fahrzeugListe()).length, 0);
});

test('Unbekannte Fahrzeugart wird abgelehnt', async () => {
  const d = await neu();
  const r = await d.fahrzeugAnlegen('ufo', { bezeichnung: 'X' });
  assert.equal(r.ok, false);
});

test('Zahlen mit Komma werden richtig gelesen, Unsinn wird abgelehnt', async () => {
  const d = await neu();
  const ok = d.pruefen('boot', { bezeichnung: 'B', tiefgang: '1,25', laenge: ' 9.8 ' });
  assert.equal(ok.werte.tiefgang, 1.25);
  assert.equal(ok.werte.laenge, 9.8);
  const schlecht = d.pruefen('boot', { bezeichnung: 'B', tiefgang: 'viel', laenge: '-3' });
  assert.ok(schlecht.fehler.tiefgang);
  assert.ok(schlecht.fehler.laenge);
});

test('Baujahr und Datum werden geprüft', async () => {
  const d = await neu();
  assert.ok(d.pruefen('auto', { bezeichnung: 'A', baujahr: '1500' }).fehler.baujahr);
  assert.ok(d.pruefen('auto', { bezeichnung: 'A', baujahr: '2099' }).fehler.baujahr);
  assert.equal(d.pruefen('auto', { bezeichnung: 'A', baujahr: '1998' }).werte.baujahr, 1998);
  assert.ok(d.pruefen('auto', { bezeichnung: 'A', erstzulassung: '2026-02-30' }).fehler.erstzulassung);
  assert.equal(d.pruefen('auto', { bezeichnung: 'A', erstzulassung: '2020-02-29' }).ok, true);
});

test('Änderung = neuer Eintrag "Korrektur zu"; der alte bleibt unverändert sichtbar', async () => {
  const d = await neu();
  const { id } = await d.fahrzeugAnlegen('auto', { bezeichnung: 'Fahrzeug A', marke: 'Opel' });
  const vorher = await d.fahrzeugLaden(id);
  const r = await d.fahrzeugAendern(id, { bezeichnung: 'Fahrzeug A', marke: 'Ford' });
  assert.ok(r.ok && r.geaendert);
  const nachher = await d.fahrzeugLaden(id);
  assert.equal(nachher.verlauf.length, 2);
  assert.equal(nachher.aktuell.nr, 2);
  assert.equal(nachher.aktuell.werte.marke, 'Ford');
  assert.equal(nachher.aktuell.korrekturZu, vorher.aktuell.id);
  const alt = nachher.verlauf[1].eintrag;
  assert.deepEqual(alt, vorher.aktuell);
  assert.equal(alt.werte.marke, 'Opel');
  assert.deepEqual(nachher.verlauf[0].aenderungen.map(a => [a.label, a.alt, a.neu]), [['Marke', 'Opel', 'Ford']]);
});

test('Speichern ohne Änderung legt keinen neuen Eintrag an', async () => {
  const d = await neu();
  const { id } = await d.fahrzeugAnlegen('auto', { bezeichnung: 'A', marke: 'Opel' });
  const r = await d.fahrzeugAendern(id, { bezeichnung: 'A', marke: 'Opel' });
  assert.ok(r.ok);
  assert.equal(r.geaendert, false);
  assert.equal((await d.fahrzeugLaden(id)).verlauf.length, 1);
});

test('Fehlerhafte Änderung lässt den Stand unberührt', async () => {
  const d = await neu();
  const { id } = await d.fahrzeugAnlegen('auto', { bezeichnung: 'A', baujahr: '2000' });
  const r = await d.fahrzeugAendern(id, { bezeichnung: 'A', baujahr: 'abc' });
  assert.equal(r.ok, false);
  const f = await d.fahrzeugLaden(id);
  assert.equal(f.verlauf.length, 1);
  assert.equal(f.aktuell.werte.baujahr, 2000);
});

test('Felder hängen an der Fahrzeugart', async () => {
  const A = MM.Fahrzeugarten;
  const keys = id => A.felder(id).map(f => f.key);
  assert.ok(keys('boot').includes('tiefgang'));
  assert.ok(keys('boot').includes('hin'));
  assert.ok(!keys('boot').includes('achsen'));
  assert.ok(!keys('boot').includes('fin'));
  assert.ok(keys('wohnmobil').includes('achsen'));
  assert.ok(keys('wohnmobil').includes('fin'));
  assert.ok(!keys('wohnmobil').includes('tiefgang'));
  assert.equal(A.kennungFeld('boot'), 'registriernummer');
  assert.equal(A.kennungFeld('auto'), 'kennzeichen');
  assert.equal(A.felder('flugzeug').find(f => f.key === 'breite').label, 'Spannweite');
});

test('Jede Art nutzt nur bekannte Felder und hat ihr Kennungsfeld', async () => {
  for (const a of MM.Fahrzeugarten.alle()) {
    const keys = MM.Fahrzeugarten.felder(a.id).map(f => f.key);
    assert.ok(keys.includes(a.kennung), a.id + ' braucht sein Kennungsfeld');
    assert.equal(new Set(keys).size, keys.length, a.id + ' hat doppelte Felder');
    MM.Fahrzeugarten.felder(a.id).forEach(f => assert.ok(f.label && f.typ && f.gruppe, a.id + ':' + f.key));
  }
});

test('Liste ist nach Bezeichnung sortiert (Zahlen natürlich)', async () => {
  const d = await neu();
  for (const n of ['Fahrzeug 10', 'Fahrzeug 2', 'Boot']) await d.fahrzeugAnlegen('auto', { bezeichnung: n });
  const namen = (await d.fahrzeugListe()).map(x => x.aktuell.werte.bezeichnung);
  assert.deepEqual(namen, ['Boot', 'Fahrzeug 2', 'Fahrzeug 10']);
});

test('Anzeige-Helfer: deutsche Schreibweise', async () => {
  const H = MM.Hilfen;
  assert.equal(H.datum('2026-11-03'), '03.11.2026');
  assert.equal(H.wert({ typ: 'zahl', einheit: 'm' }, 2.5), '2,5 m');
  assert.equal(H.wert({ typ: 'text' }, null), null);
  assert.equal(H.wert({ typ: 'ganzzahl' }, 1998), '1998');
});
