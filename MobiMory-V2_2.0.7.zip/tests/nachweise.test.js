'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/personen.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;

const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  const fz = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  return { d, fz };
}
const scan = (name, size) => ({ name: name || 'scan.jpg', type: 'image/jpeg', size: size || 1000 });

/* ---------- Personen ---------- */
test('Person anlegen: Funktionen in fester Reihenfolge, E-Mail und Telefon freiwillig', async () => {
  const { d } = await neu();
  const r = await d.personAnlegen({ bezeichnung: ' Anna Muster ', funktionen: ['Crew', 'Skipper', 'Unsinn'], email: 'anna@beispiel.de', telefon: '+49 171 1234567' });
  assert.ok(r.ok);
  const p = await d.personLaden(r.id);
  assert.equal(p.aktuell.werte.bezeichnung, 'Anna Muster');
  assert.deepEqual(p.aktuell.werte.funktionen, ['Skipper', 'Crew']);
  assert.equal(p.aktuell.quelle, 'hand');
});

test('Person: Name Pflicht, E-Mail und Telefon werden geprüft', async () => {
  const { d } = await neu();
  assert.ok((await d.personAnlegen({ bezeichnung: ' ' })).fehler.bezeichnung.includes('Namen'));
  assert.ok((await d.personAnlegen({ bezeichnung: 'A', email: 'keine-mail' })).fehler.email);
  assert.ok((await d.personAnlegen({ bezeichnung: 'A', telefon: 'abc' })).fehler.telefon);
  assert.equal((await d.personAnlegen({ bezeichnung: 'A', email: '', telefon: '' })).ok, true);
  assert.equal((await d.personenListe()).length, 1);
});

test('Person ändern = neuer Eintrag, Funktionen im Verlauf lesbar; ohne Änderung kein neuer Eintrag', async () => {
  const { d } = await neu();
  const { id } = await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Crew'] });
  const r = await d.personAendern(id, { bezeichnung: 'Anna', funktionen: ['Skipper', 'Crew'] });
  assert.ok(r.ok && r.geaendert);
  const p = await d.personLaden(id);
  assert.equal(p.verlauf.length, 2);
  const u = p.verlauf[0].aenderungen[0];
  assert.equal(MM.Hilfen.wert(u.feld, u.alt), 'Crew');
  assert.equal(MM.Hilfen.wert(u.feld, u.neu), 'Skipper, Crew');
  assert.equal((await d.personAendern(id, { bezeichnung: 'Anna', funktionen: ['Skipper', 'Crew'] })).geaendert, false);
});

test('Personenliste ist nach Namen sortiert', async () => {
  const { d } = await neu();
  for (const n of ['Zoe', 'anna', 'Berta']) await d.personAnlegen({ bezeichnung: n });
  assert.deepEqual((await d.personenListe()).map(x => x.aktuell.werte.bezeichnung), ['anna', 'Berta', 'Zoe']);
});

/* ---------- Tiere ---------- */
test('Tier anlegen: Tierart Pflicht, Chipnummer wird bereinigt und geprüft', async () => {
  const { d } = await neu();
  assert.ok((await d.tierAnlegen({ bezeichnung: 'Bello' })).fehler.tierart);
  assert.ok((await d.tierAnlegen({ bezeichnung: 'Bello', tierart: 'Hund', chipnummer: '12ab' })).fehler.chipnummer);
  assert.ok((await d.tierAnlegen({ bezeichnung: 'Bello', tierart: 'Drache' })).fehler.tierart);
  const r = await d.tierAnlegen({ bezeichnung: 'Bello', tierart: 'Hund', chipnummer: '276 0981 2345 6789' });
  assert.ok(r.ok);
  const t = await d.tierLaden(r.id);
  assert.equal(t.aktuell.werte.chipnummer, '276098123456789');
  assert.equal((await d.tiereListe()).length, 1);
});

test('Tier ändern = neuer Eintrag', async () => {
  const { d } = await neu();
  const { id } = await d.tierAnlegen({ bezeichnung: 'Mia', tierart: 'Katze' });
  assert.ok((await d.tierAendern(id, { bezeichnung: 'Mia', tierart: 'Katze', notiz: 'ängstlich' })).geaendert);
  assert.equal((await d.tierLaden(id)).verlauf.length, 2);
});

/* ---------- Nachweisarten ---------- */
test('Eigene Nachweisart anlegen: offene Liste, eigene Felder mit stabilen Schlüsseln', async () => {
  const { d } = await neu();
  const r = await d.nachweisartAnlegen({ bezeichnung: 'Kanadischer Bootsführerschein', gehoertZu: 'person', hatAblauf: 'ja', land: 'CA',
    felder: [{ label: 'Provinz', typ: 'text', papier: 'Feld 3' }, { label: 'Prüfdatum', typ: 'datum' }, { label: '', papier: '' }] });
  assert.ok(r.ok);
  const x = await d.nachweisartLaden(r.id);
  assert.equal(x.werte.herkunft, 'eigen');
  assert.deepEqual(x.werte.felder.map(f => [f.key, f.label, f.typ, f.papier]), [['z1', 'Provinz', 'text', 'Feld 3'], ['z2', 'Prüfdatum', 'datum', '']]);
  /* beliebig viele Arten */
  for (let i = 0; i < 30; i++) assert.ok((await d.nachweisartAnlegen({ bezeichnung: 'Art ' + i, gehoertZu: 'fahrzeug' })).ok);
  assert.equal((await d.nachweisartenListe()).length, 31);
});

test('Nachweisart: Pflichtangaben', async () => {
  const { d } = await neu();
  assert.ok((await d.nachweisartAnlegen({ gehoertZu: 'person' })).fehler.bezeichnung);
  assert.ok((await d.nachweisartAnlegen({ bezeichnung: 'X' })).fehler.gehoertZu);
  assert.ok((await d.nachweisartAnlegen({ bezeichnung: 'X', gehoertZu: 'ufo' })).fehler.gehoertZu);
  assert.ok((await d.nachweisartAnlegen({ bezeichnung: 'X', gehoertZu: 'tier', felder: [{ label: '', papier: 'A' }] })).fehler.felder);
});

test('Vorschlag übernehmen: Quelle, Prüfdatum und Felder kommen mit; doppelt übernehmen geht nicht', async () => {
  const { d } = await neu();
  const r = await d.nachweisartAusVorschlag('DE_FEV_FUEHRERSCHEIN_EU');
  assert.ok(r.ok);
  const x = await d.nachweisartLaden(r.id);
  assert.equal(x.werte.herkunft, 'vorschlag');
  assert.equal(x.werte.gehoertZu, 'person');
  assert.equal(x.werte.hatAblauf, 'ja');
  assert.equal(x.werte.pruefstatus, 'geprueft');
  assert.equal(x.werte.geprueftAm, '2026-11-03');
  assert.ok(x.werte.quelleUrl.startsWith('https://'));
  assert.equal(x.werte.felder.length, 6);
  assert.equal(x.werte.gemeinsam.nummer.papier, '5');
  const nochmal = await d.nachweisartAusVorschlag('DE_FEV_FUEHRERSCHEIN_EU');
  assert.equal(nochmal.ok, false); assert.equal(nochmal.vorhanden, true);
  assert.equal((await d.nachweisartAusVorschlag('GIBT_ES_NICHT')).ok, false);
});

test('Übernommene Art ist frei änderbar; Änderung bleibt im Verlauf', async () => {
  const { d } = await neu();
  const { id } = await d.nachweisartAusVorschlag('DE_SPFV_SBF');
  const r = await d.nachweisartAendern(id, { bezeichnung: 'SBF Binnen und See', hatAblauf: 'nein', ausgeblendet: 'nein', land: 'DE', felder: [{ key: 'z1', label: 'Antrieb', typ: 'text' }, { label: 'Ausstellungsort', typ: 'text' }] });
  assert.ok(r.ok && r.geaendert);
  const x = await d.nachweisartLaden(id);
  assert.equal(x.verlauf.length, 2);
  assert.equal(x.werte.bezeichnung, 'SBF Binnen und See');
  assert.equal(x.werte.vorschlagId, 'DE_SPFV_SBF', 'Herkunft bleibt');
  assert.deepEqual(x.werte.felder.map(f => f.key), ['z1', 'z2']);
});

test('Alle Vorschläge lassen sich übernehmen und liefern brauchbare Felder', async () => {
  const { d } = await neu();
  for (const v of MM.NachweisVorschlaege.alle()) {
    const r = await d.nachweisartAusVorschlag(v.id);
    assert.ok(r.ok, v.id);
    const art = (await d.nachweisartLaden(r.id)).aktuell.werte;
    const felder = MM.Nachweise.felderFuer(art);
    assert.ok(felder.length >= 2, v.id);
    assert.equal(new Set(felder.map(f => f.key)).size, felder.length, 'doppelte Schlüssel in ' + v.id);
    felder.forEach(f => assert.ok(f.label && ['text', 'datum', 'zahl'].includes(f.typ), v.id + ':' + f.key));
  }
  assert.equal((await d.nachweisartenListe()).length, MM.NachweisVorschlaege.alle().length);
});

test('Vorschlagsliste: Quelle und Prüfstand sind ehrlich angegeben', () => {
  const v = MM.NachweisVorschlaege.alle();
  v.forEach(x => {
    assert.ok(['geprueft', 'teilweise', 'offen'].includes(x.pruefstatus), x.id);
    if (x.pruefstatus === 'offen') { assert.equal(x.geprueftAm, null, x.id); assert.equal(x.quelle, null, x.id); }
    else { assert.equal(x.geprueftAm, '2026-11-03', x.id); assert.ok(x.quelle && /^https:\/\//.test(x.quelle.url), x.id); }
    assert.ok(['person', 'tier', 'fahrzeug'].includes(x.gehoertZu), x.id);
  });
  assert.equal(v.find(x => x.id === 'DE_FZV_ZB_I').felder.find(f => f.papier === 'E').label.includes('FIN'), true);
  assert.equal(v.find(x => x.id === 'DE_FEV_FUEHRERSCHEIN_EU').felder.some(f => f.papier === '3'), true);
});

/* ---------- Nachweise ---------- */
async function mitFS() {
  const c = await neu();
  const p = (await c.d.personAnlegen({ bezeichnung: 'Anna' })).id;
  const art = (await c.d.nachweisartAusVorschlag('DE_FEV_FUEHRERSCHEIN_EU')).id;
  return Object.assign(c, { p, art });
}

test('Nachweis anlegen: Angaben der Art, Herkunft Handeingabe, optionaler Scan getrennt', async () => {
  const { d, p, art } = await mitFS();
  const r = await d.nachweisAnlegen('person', p, art, { nummer: 'B123456789', aussteller: 'Landratsamt', klassen: 'B, BE', gueltigBis: '2036-05-01', z1: 'Muster', datei: scan('fs.jpg', 5000) });
  assert.ok(r.ok);
  const n = await d.nachweisLaden(r.id);
  assert.equal(n.aktuell.werte.nummer, 'B123456789');
  assert.equal(n.aktuell.werte.z1, 'Muster');
  assert.equal(n.aktuell.quelle, 'hand');
  assert.equal(n.datei.name, 'fs.jpg');
  assert.equal(n.besitzer.name, 'Anna');
  assert.equal(n.status.status, 'gueltig');
  assert.equal((await d.nachweisDateiHolen(r.id)).groesse, 5000);
  assert.equal((await d.speicher.alle('dateien')).length, 0, 'Scans liegen nicht bei den Dokumenten');
});

test('Nachweis: Status Gültigkeit mit Vorwarnung, abgelaufen, unbekannt, unbefristet', async () => {
  const { d, p, art } = await mitFS();
  const neuN = async w => d.nachweisLaden((await d.nachweisAnlegen('person', p, art, w)).id);
  assert.equal((await neuN({ gueltigBis: '2026-12-03' })).status.status, 'bald');
  assert.equal((await neuN({ gueltigBis: '2026-12-04' })).status.status, 'gueltig');
  assert.equal((await neuN({ gueltigBis: '2026-11-03' })).status.status, 'bald');
  assert.equal((await neuN({ gueltigBis: '2026-11-02' })).status.status, 'abgelaufen');
  assert.equal((await neuN({})).status.status, 'unbekannt');
  const sbf = (await d.nachweisartAusVorschlag('DE_SPFV_SBF')).id;
  const x = await d.nachweisLaden((await d.nachweisAnlegen('person', p, sbf, { nummer: '1' })).id);
  assert.equal(x.status.status, 'unbefristet');
  assert.equal(x.felder.some(f => f.key === 'gueltigBis'), false, 'ohne Ablauf kein Feld "Gültig bis"');
});

test('Nachweis: Prüfungen und Zuordnung', async () => {
  const { d, p, art, fz } = await mitFS();
  assert.ok((await d.nachweisAnlegen('person', p, art, { gueltigBis: 'kein Datum' })).fehler.gueltigBis);
  assert.ok((await d.nachweisAnlegen('person', p, art, { ausgestelltAm: '2020-01-01', gueltigBis: '2019-01-01' })).fehler.gueltigBis);
  assert.ok((await d.nachweisAnlegen('person', p, art, { datei: { name: 'x', size: 0 } })).fehler.datei);
  assert.ok((await d.nachweisAnlegen('person', p, 'gibt-es-nicht', {})).fehler.artId);
  assert.equal((await d.nachweisAnlegen('fahrzeug', fz, art, {})).ok, false, 'Führerschein gilt nicht für Fahrzeuge');
  assert.equal((await d.nachweisAnlegen('person', 'gibt-es-nicht', art, {})).ok, false);
  assert.equal((await d.nachweiseListe('person', p)).length, 0);
});

test('Nachweis an Tier und an Fahrzeug', async () => {
  const { d, fz } = await neu();
  const t = (await d.tierAnlegen({ bezeichnung: 'Bello', tierart: 'Hund' })).id;
  const ht = (await d.nachweisartAusVorschlag('EU_HEIMTIERAUSWEIS')).id;
  const tw = (await d.nachweisartAusVorschlag('EU_TOLLWUTIMPFUNG')).id;
  const zb = (await d.nachweisartAusVorschlag('DE_FZV_ZB_I')).id;
  assert.ok((await d.nachweisAnlegen('tier', t, ht, { nummer: 'DE 123', z1: '276098123456789', z2: '2024-03-01' })).ok);
  assert.ok((await d.nachweisAnlegen('tier', t, tw, { ausgestelltAm: '2025-01-10', gueltigBis: '2026-11-20', z1: 'Nobivac' })).ok);
  assert.ok((await d.nachweisAnlegen('fahrzeug', fz, zb, { z1: 'LB-MM 123', z6: 'WVWZZZ1KZAW000001', z9: '1250,5' })).ok);
  const liste = await d.nachweiseListe('tier', t);
  assert.deepEqual(liste.map(x => x.art.aktuell.werte.bezeichnung), ['Tollwutimpfung', 'EU-Heimtierausweis'], 'bald ablaufend zuerst');
  assert.equal(liste[0].status.status, 'bald');
  const zbn = (await d.nachweiseListe('fahrzeug', fz))[0];
  assert.equal(zbn.aktuell.werte.z9, 1250.5);
});

test('Nachweis ändern = neuer Eintrag "Korrektur zu", Scan und Herkunft bleiben', async () => {
  const { d, p, art } = await mitFS();
  const { id } = await d.nachweisAnlegen('person', p, art, { nummer: 'B1', gueltigBis: '2026-11-10', datei: scan('a.jpg', 100) });
  const r = await d.nachweisAendern(id, { nummer: 'B1', gueltigBis: '2036-11-10' });
  assert.ok(r.ok && r.geaendert);
  const n = await d.nachweisLaden(id);
  assert.equal(n.verlauf.length, 2);
  assert.equal(n.status.status, 'gueltig');
  assert.equal(n.aktuell.werte.dateiName, 'a.jpg');
  assert.equal(n.verlauf[1].eintrag.werte.gueltigBis, '2026-11-10');
  assert.deepEqual(n.verlauf[0].aenderungen.map(u => u.label), ['Ablaufdatum des Dokuments']);
  assert.equal((await d.nachweisAendern(id, { nummer: 'B1', gueltigBis: '2036-11-10' })).geaendert, false);
});

test('Ändert sich die Art, bleiben die gespeicherten Angaben der Nachweise erhalten', async () => {
  const { d, p, art } = await mitFS();
  const { id } = await d.nachweisAnlegen('person', p, art, { nummer: 'B1', z1: 'Muster' });
  await d.nachweisartAendern(art, { bezeichnung: 'Führerschein', hatAblauf: 'ja', ausgeblendet: 'nein', felder: [] });
  const n = await d.nachweisLaden(id);
  assert.equal(n.felder.some(f => f.key === 'z1'), false);
  assert.equal(n.aktuell.werte.z1, 'Muster', 'nichts geht verloren');
});

test('Ausgeblendete Art kann nicht mehr für neue Nachweise genutzt werden', async () => {
  const { d, p, art } = await mitFS();
  await d.nachweisartAendern(art, { bezeichnung: 'Führerschein', hatAblauf: 'ja', ausgeblendet: 'ja', felder: [] });
  assert.ok((await d.nachweisAnlegen('person', p, art, {})).fehler.artId);
});

test('Übersicht: abgelaufene und bald ablaufende Nachweise je Besitzer', async () => {
  const { d, p, art, fz } = await mitFS();
  await d.nachweisAnlegen('person', p, art, { gueltigBis: '2020-01-01' });
  await d.nachweisAnlegen('person', p, art, { gueltigBis: '2026-11-15' });
  await d.nachweisAnlegen('person', p, art, { gueltigBis: '2040-01-01' });
  const u = await d.nachweisUebersicht();
  assert.deepEqual(u[p], { abgelaufen: 1, bald: 1, unbekannt: 0 });
  assert.equal(u[fz], undefined);
});

test('Gilt der Nachweis bis zum Ende des Zeitraums? (Grundlage für die spätere Prüfung)', async () => {
  const art = { hatAblauf: 'ja' };
  assert.equal(MM.Nachweise.gueltigBisZum(art, { gueltigBis: '2027-01-31' }, '2027-01-31'), true);
  assert.equal(MM.Nachweise.gueltigBisZum(art, { gueltigBis: '2027-01-30' }, '2027-01-31'), false);
  assert.equal(MM.Nachweise.gueltigBisZum(art, {}, '2027-01-31'), null);
  assert.equal(MM.Nachweise.gueltigBisZum({ hatAblauf: 'nein' }, {}, '2027-01-31'), true);
});

test('Löschen aller Daten leert auch Personen, Tiere, Arten und Nachweise', async () => {
  const { d, p, art } = await mitFS();
  await d.nachweisAnlegen('person', p, art, { datei: scan() });
  await d.allesLoeschen();
  for (const t of ['personen', 'tiere', 'nachweisarten', 'nachweise', 'nachweisdateien']) assert.equal((await d.speicher.alle(t)).length, 0, t);
});
