'use strict';
/* Schritt 9b (2.0.34): Wetter jetzt, Weg, Kartendaten, Offline-Karte merken und freigeben, Rhythmus. Das Netz wird nachgebaut. */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren', 'personen', 'orte', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'daten']
  .forEach(m => require('../js/' + m + '.js'));
const MM = globalThis.MM;

const JETZT = new Date(2026, 10, 3, 12, 0, 0);
const GPX = `<gpx><rte><rtept lat="48.0" lon="8.0"><n>Start</n></rtept><rtept lat="48.2" lon="8.0"/><rtept lat="48.4" lon="8.0"><n>Ziel</n></rtept></rte></gpx>`;

function netz(o) {
  o = o || {};
  const t0 = Math.floor(Date.UTC(2026, 10, 3, 0, 0) / 1000), zeiten = [];
  for (let i = 0; i < 48; i++) zeiten.push(t0 + i * 3600);
  const aufrufe = [];
  async function holeJson(url) {
    aufrufe.push(url);
    if (o.aus) throw new Error('kein Netz');
    if (url.includes('marine-api')) {
      if (o.ohneMarine) throw new Error('400');
      return { hourly: { time: zeiten, wave_height: zeiten.map(() => 0.8), wave_direction: zeiten.map(() => 270), wave_period: zeiten.map(() => 5), sea_level_height_msl: zeiten.map((_, i) => Math.round(Math.sin(i / 2) * 100) / 100) } };
    }
    if (o.leer) return { hourly: { time: [] } };
    return { hourly: { time: zeiten, temperature_2m: zeiten.map(() => 9), precipitation: zeiten.map(() => 0), precipitation_probability: zeiten.map(() => 10), wind_speed_10m: zeiten.map(() => 14), wind_gusts_10m: zeiten.map(() => 25), wind_direction_10m: zeiten.map(() => 225), weather_code: zeiten.map(() => 3) } };
  }
  return { holeJson, aufrufe };
}

async function neu(o) {
  let t = 0;
  const n = netz(o);
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(JETZT.getTime() + (t++)).toISOString(), holeJson: n.holeJson });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = x => arten.find(a => a.aktuell.werte.bezeichnung === x).objekt.id;
  return { d, boot, wm, anna, artId, netz: n };
}
const heute = (c, fz, extra) => c.d.aktivitaetAnlegen(Object.assign({ bezeichnung: 'Törn', artId: c.artId('Törn'), fahrzeugId: fz, vonDatum: '2026-11-03', vonZeit: '08:00', bisDatum: '2026-11-04', verantwortlichId: c.anna }, extra || {})).then(r => { assert.equal(r.ok, true, JSON.stringify(r)); return r.id; });
const pos = { breite: 48.1, laenge: 8.2, genauigkeit: 8 };

test('Wetter jetzt (Boot): holt Wetter und Marine, legt den Eintrag „Wetter“ mit Text und Position an, Wind in Knoten', async () => {
  const c = await neu();
  const id = await heute(c, c.boot);
  const r = await c.d.wetterJetzt(id, pos);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.match(r.text, /^Wetter: bedeckt, 9 °C, Wind 14 kn aus SW/);
  assert.match(r.text, /Welle 0,8 m/);
  assert.equal(c.netz.aufrufe.length, 2);
  assert.ok(c.netz.aufrufe[0].includes('wind_speed_unit=kn') && c.netz.aufrufe[0].includes('forecast_days=2'));
  const lb = await c.d.logbuchLaden(id);
  const e = lb.abschnitte[0].ereignisse.filter(x => x.artName === 'Wetter');
  assert.equal(e.length, 1);
  assert.equal(e[0].text, r.text);
  assert.equal(e[0].breite, 48.1); assert.equal(e[0].laenge, 8.2); assert.equal(e[0].positionQuelle, 'gps');
});

test('Wetter jetzt (Wohnmobil): nur Wetter in km/h, die Art „Wetter“ gibt es danach genau einmal und gilt für alle Fahrzeugarten', async () => {
  const c = await neu();
  const id = await heute(c, c.wm);
  const r = await c.d.wetterJetzt(id, pos);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(c.netz.aufrufe.length, 1);
  assert.match(r.text, /Wind 14 km\/h/);
  await c.d.wetterJetzt(id, pos, { automatisch: true });
  const arten = (await c.d.ereignisartenListe()).filter(a => a.aktuell.werte.bezeichnung === 'Wetter');
  assert.equal(arten.length, 1);
  assert.ok(MM.Logbuch.ereignisartGilt(arten[0].aktuell.werte.zuordnung, 'boot') && MM.Logbuch.ereignisartGilt(arten[0].aktuell.werte.zuordnung, 'wohnmobil'));
  const lb = await c.d.logbuchLaden(id);
  const t = lb.abschnitte[0].ereignisse.filter(x => x.artName === 'Wetter').map(x => x.text);
  assert.equal(t.length, 2);
  assert.ok(t.some(x => x.startsWith('Wetter (automatisch): ')));
});

test('Wetter jetzt: ohne Netz, ohne Position, ohne Werte und bei storno wird nichts gespeichert und klar erklärt', async () => {
  const c = await neu({ aus: true });
  const id = await heute(c, c.wm);
  const a = await c.d.wetterJetzt(id, pos);
  assert.equal(a.ok, false); assert.equal(a.offline, true); assert.match(a.fehler.allgemein, /kein Netz.*nichts gespeichert/s);
  const b = await c.d.wetterJetzt(id, null);
  assert.equal(b.ok, false); assert.match(b.fehler.allgemein, /GPS-Position/);
  const c2 = await neu({ leer: true });
  const id2 = await heute(c2, c2.wm);
  const l = await c2.d.wetterJetzt(id2, pos);
  assert.equal(l.ok, false); assert.match(l.fehler.allgemein, /keine Werte/);
  for (const x of [c, c2]) { const lb = await x.d.logbuchLaden(x === c ? id : id2); assert.equal(lb.abschnitte.reduce((s, t) => s + t.ereignisse.length, 0), 0); }
  const c3 = await neu();
  const id3 = await heute(c3, c3.wm);
  await c3.d.aktivitaetStornieren(id3, 'Test');
  const s = await c3.d.wetterJetzt(id3, pos);
  assert.equal(s.ok, false); assert.match(s.fehler.allgemein, /storniert/);
  assert.equal((await c3.d.wetterJetzt('gibtsnicht', pos)).ok, false);
});

test('Wetter jetzt: Marine fällt aus, das Wetter wird trotzdem gespeichert', async () => {
  const c = await neu({ ohneMarine: true });
  const id = await heute(c, c.boot);
  const r = await c.d.wetterJetzt(id, pos);
  assert.equal(r.ok, true);
  assert.doesNotMatch(r.text, /Welle/);
});

test('Weg: speichern und lesen, getrennt von der GPS-Strecke; ohne Eintrag ein leerer Weg', async () => {
  const c = await neu();
  const id = await heute(c, c.boot);
  assert.deepEqual((await c.d.gpsWegLesen(id)).punkte, []);
  let w = MM.Karte.wegPunkt(MM.Karte.wegNeu(), { breite: 48, laenge: 8, zeitMs: 1000000, genauigkeit: 5 }, 'wasser');
  w = MM.Karte.wegPunkt(w, { breite: 48.001, laenge: 8, zeitMs: 1060000, genauigkeit: 5 }, 'wasser');
  await c.d.gpsWegSpeichern(id, w);
  assert.deepEqual((await c.d.gpsWegLesen(id)).punkte, w.punkte);
  assert.equal((await c.d.gpsSpurLesen ? await c.d.gpsSpurLesen(id) : { km: 0 }).km, 0);
});

test('Rhythmus: Vorgabe aus, nur gültige Werte, gilt für das Gerät und lässt andere Geräteangaben stehen', async () => {
  const c = await neu();
  assert.deepEqual(await c.d.geraetWetterRhythmus(), { minuten: 0, gesetzt: false });
  assert.equal((await c.d.geraetWetterRhythmusSetzen('45')).ok, false);
  await c.d.geraetWartezeitSetzen(7);
  assert.equal((await c.d.geraetWetterRhythmusSetzen('120')).ok, true);
  assert.equal((await c.d.geraetWetterRhythmus()).minuten, 120);
  assert.equal((await c.d.geraetWartezeit()).wartezeit, 7);
});

test('Kartendaten: Route, Orte mit Position als Start und Ziel, Wetterpunkte, Einträge mit Position, Weg', async () => {
  const c = await neu();
  const start = (await c.d.ortAnlegen({ bezeichnung: 'Hafen A', positionBreite: '48,0', positionLaenge: '8,0' })).id;
  const ziel = (await c.d.ortAnlegen({ bezeichnung: 'Hafen B', positionBreite: '48,4', positionLaenge: '8,0' })).id;
  const ohne = (await c.d.ortAnlegen({ bezeichnung: 'Irgendwo' })).id;
  const id = await heute(c, c.boot, { startOrtId: start, zielOrtId: ziel, zwischenzielIds: [ohne] });
  let kd = await c.d.kartenDaten(id, 0);
  assert.equal(kd.ok, true, JSON.stringify(kd));
  assert.equal(kd.route, null); assert.equal(kd.wetter, null);
  assert.deepEqual(kd.planOrte.map(o => o.rolle + ':' + o.name), ['start:Hafen A', 'ziel:Hafen B']);
  assert.equal(kd.aktivitaet.welt, 'wasser');
  const imp = await c.d.routeImportieren(id, GPX, 'r.gpx');
  await c.d.routeAendern(imp.id, { bezeichnung: 'R', geschwindigkeit: '6', einheit: 'kn', abfahrtDatum: '2026-11-03', abfahrtZeit: '13:00' });
  assert.equal((await c.d.wetterAbrufen(id)).ok, true);
  await c.d.wetterJetzt(id, pos);
  await c.d.ereignisSchnell(id, 'Notiz', { text: 'ohne Position' });
  kd = await c.d.kartenDaten(id, 0);
  assert.equal(kd.route.punkte.length, 3); assert.ok(kd.route.kmh > 10); assert.equal(typeof kd.route.abfahrtMs, 'number');
  assert.ok(kd.wetter.zeilen.length >= 2 && kd.wetter.aktuell === true);
  assert.equal(kd.ereignisse.length, 1); assert.equal(kd.ereignisse[0].istWetter, true);
  const v = await c.d.kartenDaten(id, 60);
  assert.equal(v.wetter.versatzMin, 60);
  assert.equal((await c.d.kartenDaten('x', 0)).ok, false);
});

test('Offline-Karte: Punkte aus Route, sonst Orte; Planung je Stufe; Merken vereinigt, Freigeben lässt Kacheln anderer Aktivitäten stehen', async () => {
  const c = await neu();
  const id1 = await heute(c, c.boot);
  const id2 = await heute(c, c.wm, { bezeichnung: 'Zweite' });
  assert.equal((await c.d.kartePlanen(id1, 'grob')).ok, false);
  assert.equal((await c.d.kartePunkte(id1)).quelle, null);
  const imp = await c.d.routeImportieren(id1, GPX, 'r.gpx');
  assert.equal(imp.ok, true);
  assert.equal((await c.d.kartePunkte(id1)).quelle, 'route');
  const p = await c.d.kartePlanen(id1, 'mittel');
  assert.equal(p.ok, true); assert.equal(p.quelle, 'route'); assert.ok(p.anzahl > 0);
  assert.equal(await c.d.karteInfo(id1), null);
  await c.d.karteMerken(id1, 'grob', ['5/1/1', '5/1/2'], 1000);
  const m = await c.d.karteMerken(id1, 'mittel', ['5/1/2', '6/2/2'], 500);
  assert.deepEqual([m.anzahl, m.bytes], [3, 1500]);
  await c.d.karteMerken(id2, 'grob', ['5/1/2', '7/9/9'], 10);
  const f = await c.d.karteFreigeben(id1);
  assert.deepEqual(f.keys.sort(), ['5/1/1', '6/2/2']);
  assert.equal(await c.d.karteInfo(id1), null);
  assert.equal((await c.d.karteInfo(id2)).anzahl, 2);
  assert.deepEqual((await c.d.karteFreigeben(id1)).keys, []);
});

test('Die Ereignisart „Wetter“ steht in den Vorschlägen, und ein Cockpit-Eintrag „Wetter“ ist in jedem Status möglich', async () => {
  assert.ok(MM.Logbuch.ZUSATZ_VORSCHLAEGE.some(v => v.bezeichnung === 'Wetter'));
  const c = await neu();
  const id = await heute(c, c.boot);
  await c.d.ereignisSchnell(id, 'Abfahrt', {});
  assert.equal((await c.d.wetterJetzt(id, pos)).ok, true);
  const st = await c.d.fahrzeugStatus(c.boot);
  if (st.ok && st.hatStatus) assert.equal(st.pruefe('Wetter').erlaubt, true);
});
