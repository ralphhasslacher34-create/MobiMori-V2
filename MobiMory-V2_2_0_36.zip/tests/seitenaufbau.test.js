'use strict';
/* 2.0.31: Aufbau der Seiten im Quelltext. Es gibt keinen echten Browser im Test, darum wird geprüft, was im Programm festgelegt ist. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const ansicht = lesen('js/ansicht.js');

function funktion(name) {
  const start = ansicht.indexOf('  function ' + name + '(');
  assert.ok(start >= 0, 'Funktion fehlt: ' + name);
  const ende = ansicht.indexOf('\n  }\n', start);
  return ansicht.slice(start, ende);
}

test('Funktionen: Kachel Kassenbuch führt zu #/kassenbuch', () => {
  assert.match(funktion('seiteFunktionen'), /kachel\('Kassenbuch'[^\n]*'#\/kassenbuch'\)/);
});

test('Es gibt eine Route und eine Seite für das Kassenbuch, jede Zeile führt zur Reisekasse der Aktivität', () => {
  assert.match(ansicht, /teile\[0\] === 'kassenbuch'\) p = seiteKassenbuch\(\)/);
  const f = funktion('seiteKassenbuch');
  assert.match(f, /daten\.aktivitaetenListe\(\)/);
  assert.match(f, /daten\.kassenListe\(/);
  assert.match(f, /\/reisekasse/);
});

test('Stammdaten: alle Arten-Listen haben eine Kachel', () => {
  const f = funktion('seiteStammdaten');
  ['#/aktivitaetsarten', '#/ereignisarten', '#/kosten/listen', '#/fahrzeugarten', '#/nachweisarten', '#/orte', '#/gebiete', '#/adressen', '#/personen', '#/tiere', '#/fahrzeuge'].forEach(h => {
    assert.ok(f.includes("'" + h + "'"), 'Kachel fehlt: ' + h);
  });
});

test('Die Seiten der Listen hängen unter Stammdaten, nicht mehr unter Funktionen', () => {
  ['seiteAktivitaetsarten', 'seiteEreignisarten', 'seiteKostenListen'].forEach(n => {
    const f = funktion(n);
    assert.match(f, /KR_STAMM/, n + ': Brotkrumen');
    assert.match(f, /href: '#\/stammdaten', text: 'Zurück'/, n + ': Zurück');
    assert.doesNotMatch(f, /\['Funktionen', '#\/funktionen'\]/, n + ': noch Funktionen');
  });
});

test('Die Links an den bisherigen Stellen bleiben', () => {
  assert.match(funktion('seiteAktivitaeten'), /#\/aktivitaetsarten/);
  assert.match(funktion('seiteAktivitaeten'), /#\/ereignisarten/);
  assert.match(ansicht, /href: '#\/kosten\/listen'/);
});

test('Kachelseiten bekommen das Raster, das Stilblatt kennt die Klasse', () => {
  assert.match(funktion('seite'), /kachelseite/);
  assert.match(funktion('seite'), /kachelnAnpassen\(main\)/);
  assert.match(lesen('css/styles.css'), /\.inhalt\.kachelseite/);
});

test('Das Logo ist eine einzige Datei und enthält V, T und D', () => {
  const svg = lesen('icons/icon.svg');
  assert.match(svg, /<svg /);
  ['>V<', '>T<', '>D<'].forEach(b => assert.ok(svg.includes(b), 'Buchstabe fehlt: ' + b));
  assert.ok(svg.length < 4000, 'Logo-Datei ist unerwartet groß');
  assert.doesNotMatch(svg, /<script|<image/);
});

test('Kacheln: Text wird nicht abgeschnitten, Titel bleiben ganze Wörter, Beschreibungen brechen an Silben um (2.0.32)', () => {
  const css = lesen('css/styles.css');
  const kachelCss = css.slice(css.indexOf('Kachelseiten (seit 2.0.31'), css.indexOf('umbruch-notfall .kachel-text') + 60);
  assert.match(kachelCss, /grid-auto-rows: minmax\(4\.8rem, auto\)/, 'Zeilenhöhe muss mit dem Text wachsen');
  assert.match(kachelCss, /\.kachel-text \{ hyphens: auto/);
  assert.match(kachelCss, /\.kachel-titel \{ hyphens: manual/);
  assert.doesNotMatch(kachelCss.replace(/umbruch-notfall[^}]*}/g, ''), /overflow-wrap: anywhere/, 'Umbruch an jeder Stelle nur in der Notlösung');
  assert.doesNotMatch(kachelCss.replace(/\/\*[\s\S]*?\*\//g, ''), /\.kachelseite \.kachel \{[^}]*overflow: hidden/, 'Kachel darf nichts abschneiden');
  const f = funktion('kachelnAnpassen');
  assert.match(f, /minmax\(' \+ x\.hoehe \+ 'px, auto\)/);
  assert.match(f, /hoechstSpalten/);
  assert.match(f, /umbruch-notfall/);
  assert.match(ansicht, /KACHEL_SCHRIFTEN = \[1, 0\.9, 0\.8\]/);
  assert.match(lesen('index.html'), /<html lang="de"/);
});
