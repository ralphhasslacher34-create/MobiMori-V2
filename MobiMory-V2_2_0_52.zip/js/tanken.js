/* Tanken: Füllstand, Verbrauch und Reichweite (seit 2.0.51). Nur Regeln, kein Speicher und kein Netz.
 *
 * Festlegungen des Nutzers (09.11.2026):
 *  - Der Füllstand beginnt, indem der Nutzer den Stand EINMAL beim Tank angibt. „Voll getankt“ setzt den Tank danach auf seinen Tankinhalt.
 *  - „Nicht voll getankt“: Füllstand plus Menge, mit Hinweis, dass der Stand dann nur gerechnet ist.
 *  - Verbrauch: aus Füllstand ODER aus Betriebsstunden, je Verbraucher wählbar. Bei mehreren Verbrauchern an einem Tank gibt der
 *    Füllstand nur eine Summe.
 *
 * Was „aus Füllstand“ und „aus Betriebsstunden“ hier heißt:
 *  - aus Füllstand:      verbrauchte Liter seit dem letzten Stand, je Tag (l/Tag)
 *  - aus Betriebsstunden: dieselben Liter, geteilt durch die Betriebsstunden des Verbrauchers in dieser Zeit (l/h)
 * Verbrauchte Liter gibt es nur, wenn der letzte Stand genau war (angegeben oder voll) und jetzt voll getankt wurde:
 *   Liter = letzter Stand − (Tankinhalt − getankte Menge).
 * Nichts wird geraten: Fehlt etwas, steht es als Hinweis im Ergebnis und es wird nichts gerechnet.
 *
 * Gespeichert wird in den Werten des Tanks (Verlauf wie bei jedem anderen Feld):
 *   fuellstand (Liter), fuellstandArt ('angegeben' | 'voll' | 'gerechnet'), fuellstandZeit ('JJJJ-MM-TTTHH:MM'),
 *   fuellstandStunden ({ Kennung des Verbrauchers: Stand des Betriebsstunden-Zählers zu dieser Zeit }),
 *   verbrauch ({ liter, tage, von, bis, lProTag, summe, einzeln: [{ id, name, aus, lProTag, lProStunde, stunden }] }),
 *   reichweite ([{ name, wert, einheit }]). */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var TAG_MS = 86400000;

  function zahl(v) {
    if (typeof v === 'number') return isFinite(v) ? v : null;
    var t = String(v === undefined || v === null ? '' : v).trim().replace(',', '.');
    if (!t || !/^-?\d+(\.\d+)?$/.test(t)) return null;
    return Number(t);
  }
  function runde(x, stellen) { var f = Math.pow(10, stellen === undefined ? 1 : stellen); return Math.round(x * f) / f; }
  function text(x, stellen) { return String(runde(x, stellen === undefined ? 1 : stellen)).replace('.', ','); }
  function ms(iso) { var t = iso ? new Date(iso).getTime() : NaN; return isFinite(t) ? t : null; }
  function gleichText(a, b) { return String(a == null ? '' : a).trim().toLowerCase() === String(b == null ? '' : b).trim().toLowerCase(); }

  /* Tankinhalt in Litern aus den Merkmalen des Tanks, oder null (fehlt, keine Zahl oder andere Einheit als Liter). */
  function kapazitaet(werte) {
    var m = ((werte && werte.merkmale) || []).filter(function (x) { return x && gleichText(x.name, 'Tankinhalt'); })[0];
    if (!m) return null;
    var n = zahl(m.wert);
    if (n === null || !(n > 0)) return null;
    var e = String(m.einheit || '').trim().toLowerCase();
    return e === '' || e === 'l' || e === 'liter' ? n : null;
  }

  /*
   * Ein Tankvorgang. o:
   *   kapazitaet   Tankinhalt in Litern oder null
   *   alt          { fuellstand, art, zeit, stunden }  der Stand vor diesem Tanken (Werte des Tanks)
   *   altVerbrauch zuletzt berechneter Verbrauch (für die Reichweite, wenn dieses Tanken keinen neuen liefert)
   *   menge        getankte Liter
   *   voll         true, wenn voll getankt
   *   zeit         Zeitpunkt des Tankens ('JJJJ-MM-TTTHH:MM')
   *   verbraucher  [{ id, name, aus: 'fuellstand' | 'stunden', stunden: aktueller Stand des Betriebsstunden-Zählers oder null }]
   * Ergebnis: { setzen, fuellstand, art, verbrauch, reichweite, stunden, hinweise }
   *   setzen = der Füllstand des Tanks soll geändert werden (sonst bleibt er, wie er ist).
   */
  function berechnen(o) {
    var hinweise = [];
    var erg = { setzen: false, fuellstand: null, art: null, verbrauch: null, reichweite: null, stunden: {}, hinweise: hinweise };
    var kap = o.kapazitaet === undefined ? null : o.kapazitaet;
    var alt = o.alt || {}, menge = o.menge, voll = !!o.voll;
    var verb = o.verbraucher || [];
    verb.forEach(function (v) { if (typeof v.stunden === 'number') erg.stunden[v.id] = v.stunden; });
    var altStand = typeof alt.fuellstand === 'number' ? alt.fuellstand : null;
    var zt = ms(o.zeit), za = ms(alt.zeit);

    if (altStand !== null && zt !== null && za !== null && zt < za) {
      hinweise.push('Dieses Tanken liegt vor dem letzten Füllstand. Der Füllstand bleibt, wie er ist.');
      return erg;
    }

    var nach = null;
    if (voll) {
      if (kap === null) {
        hinweise.push('Der Tankinhalt fehlt oder ist nicht in Litern angegeben. Ohne ihn setzt „voll getankt“ keinen Füllstand. Trag „Tankinhalt“ beim Tank ein.');
      } else {
        nach = kap; erg.art = 'voll';
        if (menge > kap) hinweise.push('Die Menge ist größer als der Tankinhalt (' + text(kap) + ' l). Bitte Menge und Tankinhalt prüfen. Verbrauch wurde nicht gerechnet.');
        else if (altStand === null) hinweise.push('Verbrauch noch nicht gerechnet: Es gibt noch keinen früheren Füllstand. Ab dem nächsten Volltanken wird gerechnet.');
        else if (alt.art === 'gerechnet') hinweise.push('Verbrauch nicht gerechnet: Der letzte Füllstand war nur gerechnet, nicht angegeben und nicht voll.');
        else {
          var liter = altStand - (kap - menge);
          if (liter < 0) hinweise.push('Verbrauch nicht gerechnet: Die Menge passt nicht zum letzten Füllstand (' + text(altStand) + ' l). Bitte Füllstand und Menge prüfen.');
          else if (za === null || zt === null || !((zt - za) / TAG_MS > 0.0001)) hinweise.push('Verbrauch nicht gerechnet: Zwischen dem letzten Stand und diesem Tanken ist keine Zeit vergangen oder die Zeit fehlt.');
          else erg.verbrauch = verbrauchRechnen(liter, (zt - za) / TAG_MS, alt, o, verb, hinweise);
        }
      }
    } else if (altStand === null) {
      hinweise.push('Der Füllstand ist noch nicht angegeben. Gib den Stand einmal beim Tank an. Bis dahin wird nichts gerechnet.');
    } else {
      nach = altStand + menge; erg.art = 'gerechnet';
      if (kap !== null && nach > kap) { nach = kap; hinweise.push('Letzter Stand plus Menge ist mehr als der Tankinhalt. Der Füllstand ist auf ' + text(kap) + ' l begrenzt.'); }
      hinweise.push('Der Füllstand ist nur gerechnet: letzter Stand plus Menge. Der Verbrauch dazwischen ist nicht abgezogen.');
    }

    if (nach !== null) {
      erg.setzen = true; erg.fuellstand = runde(nach, 2);
      erg.reichweite = reichweiteRechnen(erg.fuellstand, erg.verbrauch || o.altVerbrauch || null);
      if (!erg.reichweite) hinweise.push('Reichweite noch nicht gerechnet: Es gibt noch keinen Verbrauch.');
    }
    return erg;
  }

  function verbrauchRechnen(liter, tage, alt, o, verb, hinweise) {
    var v = { liter: runde(liter, 2), tage: runde(tage, 3), von: alt.zeit, bis: o.zeit, lProTag: runde(liter / tage, 2), summe: verb.length !== 1, einzeln: [] };
    verb.forEach(function (x) {
      var e = { id: x.id, name: x.name, aus: x.aus === 'stunden' ? 'stunden' : 'fuellstand' };
      var delta = alt.stunden && typeof alt.stunden[x.id] === 'number' && typeof x.stunden === 'number' ? x.stunden - alt.stunden[x.id] : null;
      if (e.aus === 'stunden') {
        if (delta !== null && delta > 0) {
          e.stunden = runde(delta, 2);
          if (!v.summe) e.lProStunde = runde(liter / delta, 2);
        } else if (!v.summe) hinweise.push('Für „' + x.name + '“ fehlen Betriebsstunden in dieser Zeit (kein Zähler oder kein neuer Stand). Es gibt nur den Verbrauch je Tag.');
      }
      if (!v.summe) e.lProTag = v.lProTag;
      v.einzeln.push(e);
    });
    if (verb.length > 1) hinweise.push('An diesem Tank hängen mehrere Verbraucher. Der Füllstand gibt nur die Summe, nicht den Verbrauch je Verbraucher.');
    return v;
  }

  function reichweiteRechnen(stand, v) {
    if (!v || !(stand > 0)) return null;
    var liste = [];
    (v.einzeln || []).forEach(function (e) {
      if (e.lProStunde > 0) liste.push({ name: e.name, wert: runde(stand / e.lProStunde, 1), einheit: 'Betriebsstunden' });
    });
    if (v.lProTag > 0) liste.push({ name: v.summe ? 'alle Verbraucher zusammen' : ((v.einzeln[0] && v.einzeln[0].name) || 'Verbraucher'), wert: runde(stand / v.lProTag, 1), einheit: 'Tage' });
    return liste.length ? liste : null;
  }

  /* Die Zeilen für „Das hat die App getan“. */
  function zeilen(erg, tankName) {
    var z = [];
    if (erg.setzen) {
      z.push('Füllstand ' + tankName + ': ' + text(erg.fuellstand) + ' l' + (erg.art === 'voll' ? ' (voll getankt)' : ' (nur gerechnet)') + '.');
    }
    return z;
  }
  function verbrauchZeilen(v) {
    if (!v) return [];
    var z = ['Verbrauch seit dem letzten Stand: ' + text(v.liter) + ' l in ' + text(v.tage, 1) + ' Tagen (' + text(v.lProTag, 2) + ' l je Tag' + (v.summe ? ', Summe aller Verbraucher' : '') + ').'];
    (v.einzeln || []).forEach(function (e) {
      if (e.lProStunde > 0) z.push(e.name + ': ' + text(e.lProStunde, 2) + ' l je Betriebsstunde (' + text(e.stunden, 1) + ' Betriebsstunden).');
      else if (e.stunden > 0) z.push(e.name + ': ' + text(e.stunden, 1) + ' Betriebsstunden in dieser Zeit.');
    });
    return z;
  }
  function reichweiteZeilen(r) {
    return (r || []).map(function (x) { return 'Reichweite ' + x.name + ': etwa ' + text(x.wert, 1) + ' ' + x.einheit + '.'; });
  }

  /* Eine Zeile für die Liste der Tanks (Fahrzeugseite). */
  function tankZeile(t) {
    if (typeof t.fuellstand !== 'number') return 'Füllstand noch nicht angegeben';
    var art = t.fuellstandArt === 'voll' ? 'voll getankt' : (t.fuellstandArt === 'gerechnet' ? 'nur gerechnet' : 'angegeben');
    return 'Füllstand ' + text(t.fuellstand) + ' l (' + art + (t.fuellstandZeit ? ', ' + String(t.fuellstandZeit).replace('T', ' ') + ' Uhr' : '') + ')';
  }

  MM.Tanken = {
    zahl: zahl, runde: runde, reichweite: reichweiteRechnen, kapazitaet: kapazitaet, berechnen: berechnen, zeilen: zeilen, verbrauchZeilen: verbrauchZeilen,
    reichweiteZeilen: reichweiteZeilen, tankZeile: tankZeile, text: text,
    VERBRAUCH_AUS: [
      { wert: 'fuellstand', label: 'Aus dem Füllstand (Liter je Tag)' },
      { wert: 'stunden', label: 'Aus den Betriebsstunden (Liter je Betriebsstunde)' }
    ]
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
