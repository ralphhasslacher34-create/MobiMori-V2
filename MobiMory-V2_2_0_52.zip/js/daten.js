/*
 * Daten: die EINE Tür zu allen Fahrzeugdaten.
 *
 * Regeln aus den V2-Festlegungen, die hier gelten:
 *  - Eine Quelle: alle Teile der App fragen nur hier nach.
 *  - Handeingabe hat Vorrang. Es wird nichts überschrieben: Jede Änderung
 *    ist ein neuer Eintrag "Korrektur zu ...", der alte bleibt sichtbar.
 *  - Nichts wird gelöscht.
 *  - Jeder Eintrag nennt seine Herkunft (hier: "hand").
 *
 * Aufbau der gespeicherten Daten:
 *  datenraum   { id, name, erstelltAm }
 *  fahrzeug    { id, datenraumId, art, erstelltAm }
 *  eintrag     { id, fahrzeugId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  komponente  { id, fahrzeugId, parentId, art, erstelltAm }
 *              parentId = null: Hauptkomponente (dann gilt "art"), sonst gehört
 *              sie zu einer anderen Komponente ("gehört zu").
 *  komponenteneintrag { id, komponenteId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  zaehler     { id, fahrzeugId, komponenteId|null, art, erstelltAm }      (Name im Verlauf)
 *  zaehlerstand { id, zaehlerId, nr, wert, datum, notiz, quelle, erstelltAm }
 *  frist       { id, fahrzeugId, komponenteId|null, erstelltAm }            (Angaben im Verlauf)
 *  verlauf     { id, objektTyp, objektId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  durchfuehrung { id, fristId, datum, zaehlerstand, notiz, art, quelle, erstelltAm }
 *  dokument    { id, fahrzeugId, komponenteId|null, vorgangId|null, erstelltAm }  (Angaben im Verlauf; vorgangId seit 2.0.26: hängt am Werkstatt-Vorgang)
 *  datei       { id, dokumentId, name, mime, groesse, inhalt, erstelltAm }  (inhalt = die Datei selbst)
 *  person      { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  tier        { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  nachweisart { id, datenraumId, erstelltAm }                              (Angaben im Verlauf; offene Liste)
 *  nachweis    { id, datenraumId, artId, besitzerTyp, besitzerId, erstelltAm }  (Angaben im Verlauf)
 *  nachweisdatei { id, nachweisId, name, mime, groesse, inhalt, erstelltAm } (Scan oder Foto, bleibt lokal)
 *  aktivitaet  { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  aktivitaetsart { id, datenraumId, erstelltAm }                           (offene Liste, Angaben im Verlauf)
 *  besatzung   { id, aktivitaetId, personId, erstelltAm }                   (Rolle und "dabei von bis" im Verlauf)
 *  verantwortung { id, aktivitaetId, personId, ab, erstelltAm }             (Wechsel der Verantwortlichen, nur anhängen)
 *  anforderung { id, datenraumId, fahrzeugId, erstelltAm }                  (welche Nachweise Skipper und Fahrer brauchen)
 *  tagesabschnitt { id, datenraumId, aktivitaetId, herkunft, erstelltAm }   (Angaben im Verlauf; herkunft: vorbereitet oder hand)
 *  tagespruefung { id, datenraumId, aktivitaetId, abschnittId, stand, erstelltAm } (festgehaltene Prüfung zum Tagesbeginn, nur anhängen)
 *  ereignis    { id, datenraumId, aktivitaetId, abschnittId, erstelltAm }   (Angaben im Verlauf; Foto in ereignisdatei)
 *  ereignisart { id, datenraumId, erstelltAm }                              (offene Liste, Angaben im Verlauf)
 *  ereignisdatei { id, ereignisId, name, mime, groesse, inhalt, erstelltAm } (Foto, bleibt lokal)
 *  kosten      { id, datenraumId, fahrzeugId, erstelltAm }                  (Angaben im Verlauf: Gruppe, Betrag, Rhythmus, Datum, Verweise auf Komponente, Aktivität, Vorgang; seit 2.0.27)
 *  besuche     { id, datenraumId, aktivitaetId, fahrzeugId, ereignisId, erstelltAm }  (Angaben im Verlauf: Status, Ort, Standort, Datum, Ausstattung, Plan, Notiz; seit 2.0.28)
 *  kostenstamm { id 'ks-<fahrzeugId>', datenraumId, fahrzeugId, erstelltAm } (Wert, Wertverlust, Vergleichspreis im Verlauf; seit 2.0.27)
 *  reisecheck  { id, datenraumId, aktivitaetId, fahrzeugId, erstelltAm, stand, anfrage, namen, ergebnis, dienst }  (Ergebnis des Online-Checks; seit 2.0.38)
 *  einstellung { id, ... }                                                  (zum Beispiel id "sicherung": letzteSicherung, erinnerungTage)
 *
 * "werte" enthält Bezeichnung und alle Felder. Der aktuelle Stand ist der
 * Eintrag mit der höchsten Nummer.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Holt JSON aus dem Netz (Wetter, Tide). Ohne Netz oder bei Fehler wird die Zusage abgelehnt, der Aufrufer behandelt das. */
  function standardHoleJson(url) {
    var f = global.fetch;
    if (typeof f !== 'function') return Promise.reject(new Error('Kein Netz verfügbar.'));
    var ctl = typeof global.AbortController === 'function' ? new global.AbortController() : null;
    var timer = ctl ? global.setTimeout(function () { ctl.abort(); }, 20000) : null;
    return f(url, ctl ? { signal: ctl.signal } : undefined).then(function (r) {
      if (timer) global.clearTimeout(timer);
      if (!r.ok) throw new Error('Antwort ' + r.status);
      return r.json();
    }, function (e) { if (timer) global.clearTimeout(timer); throw e; });
  }

  function neueId(praefix) {
    var c = global.crypto;
    if (c && typeof c.randomUUID === 'function') return praefix + '-' + c.randomUUID();
    return praefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function Daten(speicher, optionen) {
    this.speicher = speicher;
    this.jetzt = (optionen && optionen.jetzt) || function () { return new Date().toISOString(); };
    /* Holt eine Antwort aus dem Netz (nur für Wetter und Tide, seit 2.0.33). Für Tests austauschbar. */
    this.holeJson = (optionen && optionen.holeJson) || standardHoleJson;
    /* Schickt eine Anfrage an den Recherche-Dienst des Reisechecks (seit 2.0.38). Für Tests austauschbar. */
    this.sendeJsonFn = (optionen && optionen.sendeJson) || null;
    this.datenraumId = null;
  }

  /* Beim ersten Start entsteht der eigene Datenraum auf diesem Gerät. */
  Daten.prototype.starten = function () {
    var self = this;
    return this.speicher.alle('datenraeume').then(function (liste) {
      if (liste.length) { self.datenraumId = liste[0].id; return liste[0]; }
      var dr = { id: neueId('dr'), name: 'Mein Datenraum', erstelltAm: self.jetzt() };
      return self.speicher.speichern('datenraeume', dr).then(function () {
        self.datenraumId = dr.id;
        return dr;
      });
    }).then(function (dr) {
      /* Eigene Fahrzeugarten und Änderungen am Baum laden (seit 2.0.16). Ohne Angabe gilt der mitgelieferte Baum. */
      return self.speicher.holen('einstellungen', 'fahrzeugarten').then(function (dok) {
        MM.Fahrzeugarten.konfigurieren(dok);
        return dr;
      });
    });
  };

  /* ---------- Prüfen und in saubere Werte umwandeln ---------- */
  function optWert(o) { return typeof o === 'string' ? o : o.wert; }

  function pruefeWerte(felder, roh, jahr, optionen) {
    var ohneBez = !!(optionen && optionen.ohneBezeichnung);
    var werte = {};
    var fehler = {};
    roh = roh || {};

    if (!ohneBez) {
      var bez = String(roh.bezeichnung == null ? '' : roh.bezeichnung).trim();
      if (!bez) fehler.bezeichnung = (optionen && optionen.bezeichnungFehler) || 'Bitte eine Bezeichnung eingeben, zum Beispiel „Fahrzeug A“.';
      werte.bezeichnung = bez;
    }

    felder.forEach(function (f) {
      if (f.typ === 'mehrfach') {
        var gewaehlt = Array.isArray(roh[f.key]) ? roh[f.key] : [];
        werte[f.key] = f.optionen.filter(function (o) { return gewaehlt.indexOf(optWert(o)) >= 0; }).map(optWert);
        return;
      }
      if (f.typ === 'liste') {
        var zeilen = Array.isArray(roh[f.key]) ? roh[f.key] : [];
        var sauber = [];
        zeilen.forEach(function (z) {
          var n = String(z && z.name != null ? z.name : '').trim();
          var w = String(z && z.wert != null ? z.wert : '').trim();
          /* Seit 2.0.45 kann eine Zeile auch eine Einheit und eine Bezugsgröße haben. Alte Zeilen haben nur Name und Wert und bleiben so. */
          var e = String(z && z.einheit != null ? z.einheit : '').trim();
          var b = String(z && z.bezug != null ? z.bezug : '').trim();
          if (!n && !w && !e && !b) return;
          if (!n || !w) fehler[f.key] = 'Bitte bei jedem Merkmal Name und Wert eingeben.';
          else if (e.length > MM.Komponenten.MAX_EINHEIT) fehler[f.key] = 'Die Einheit darf höchstens ' + MM.Komponenten.MAX_EINHEIT + ' Zeichen haben.';
          else if (b.length > MM.Komponenten.MAX_BEZUG) fehler[f.key] = 'Die Bezugsgröße darf höchstens ' + MM.Komponenten.MAX_BEZUG + ' Zeichen haben.';
          var zeile = { name: n, wert: w };
          if (e) zeile.einheit = e;
          if (b) zeile.bezug = b;
          sauber.push(zeile);
        });
        werte[f.key] = sauber;
        return;
      }

      var v = roh[f.key];
      v = (v === undefined || v === null) ? '' : v;
      if (typeof v === 'string') v = v.trim();

      if (f.typ === 'text') {
        if (f.maxLaenge && String(v).length > f.maxLaenge) fehler[f.key] = 'Bitte höchstens ' + f.maxLaenge + ' Zeichen eingeben.';
        werte[f.key] = v === '' ? null : String(v);
        return;
      }

      if (f.typ === 'auswahl') {
        if (v === '') { werte[f.key] = null; return; }
        if (!f.optionen.some(function (o) { return optWert(o) === v; })) { fehler[f.key] = 'Bitte eine Möglichkeit aus der Liste wählen.'; }
        werte[f.key] = v;
        return;
      }

      if (f.typ === 'zeit') {
        if (v === '') { werte[f.key] = null; return; }
        if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(v)) { fehler[f.key] = 'Bitte eine Uhrzeit eingeben, zum Beispiel 14:30.'; werte[f.key] = null; } else { werte[f.key] = v; }
        return;
      }
      if (f.typ === 'datum') {
        if (v === '') { werte[f.key] = null; return; }
        var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
        var d = m ? new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])) : null;
        if (!d || d.getUTCFullYear() !== +m[1] || d.getUTCMonth() !== +m[2] - 1 || d.getUTCDate() !== +m[3]) {
          fehler[f.key] = 'Bitte ein gültiges Datum eingeben.';
          werte[f.key] = null;
        } else { werte[f.key] = v; }
        return;
      }

      /* zahl und ganzzahl: Komma oder Punkt als Dezimalzeichen erlaubt */
      if (v === '') { werte[f.key] = null; return; }
      var text = String(v).replace(/\s/g, '').replace(',', '.');
      var n = /^-?\d+(\.\d+)?$/.test(text) ? Number(text) : NaN;
      if (isNaN(n)) {
        fehler[f.key] = f.typ === 'ganzzahl' ? 'Bitte eine ganze Zahl eingeben.' : 'Bitte eine Zahl eingeben, zum Beispiel 2,5.';
        werte[f.key] = null;
        return;
      }
      if (f.typ === 'ganzzahl' && Math.floor(n) !== n) { fehler[f.key] = 'Bitte eine ganze Zahl eingeben.'; werte[f.key] = null; return; }
      if (n < 0) { fehler[f.key] = 'Die Zahl darf nicht negativ sein.'; werte[f.key] = null; return; }
      if (f.key === 'baujahr' && (n < f.min || n > jahr + 1)) {
        fehler[f.key] = 'Bitte ein Baujahr zwischen ' + f.min + ' und ' + (jahr + 1) + ' eingeben.';
        werte[f.key] = null; return;
      }
      if (f.min !== undefined && f.key !== 'baujahr' && n < f.min) { fehler[f.key] = 'Der Wert muss mindestens ' + f.min + ' sein.'; werte[f.key] = null; return; }
      if (f.max !== undefined && n > f.max) { fehler[f.key] = 'Der Wert darf höchstens ' + f.max + ' sein.'; werte[f.key] = null; return; }
      werte[f.key] = n;
    });

    return { werte: werte, fehler: fehler, ok: Object.keys(fehler).length === 0 };
  }

  Daten.prototype.pruefen = function (artId, roh) {
    return pruefeWerte(MM.Fahrzeugarten.felder(artId), roh, new Date(this.jetzt()).getFullYear());
  };

  Daten.prototype.pruefenKomponente = function (roh) {
    var p = pruefeWerte(MM.Komponenten.felder(), roh, new Date(this.jetzt()).getFullYear());
    var w = p.werte;
    if (w.eingebautAm && w.ausgebautAm && w.ausgebautAm < w.eingebautAm && !p.fehler.ausgebautAm) {
      p.fehler.ausgebautAm = 'Der Ausbau kann nicht vor dem Einbau liegen.';
      p.ok = false;
    }
    return p;
  };

  /* ---------- Unterschiede zwischen zwei Ständen ---------- */
  function gleich(a, b) {
    if (a === b) return true;
    if (a && b && typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) return JSON.stringify(a) === JSON.stringify(b);
    var la = Array.isArray(a) ? a : (a === null || a === undefined ? [] : null);
    var lb = Array.isArray(b) ? b : (b === null || b === undefined ? [] : null);
    if (la && lb) return JSON.stringify(la) === JSON.stringify(lb);
    return false;
  }

  function unterschiedeFelder(felder, alt, neu) {
    var liste = [{ key: 'bezeichnung', label: 'Bezeichnung' }].concat(felder);
    var res = [];
    liste.forEach(function (f) {
      var a = alt[f.key] === undefined ? null : alt[f.key];
      var n = neu[f.key] === undefined ? null : neu[f.key];
      if (!gleich(a, n)) res.push({ key: f.key, label: f.label, feld: f, alt: a, neu: n });
    });
    return res;
  }

  /* „Gehört zu“ (seit 2.0.45) gilt für jede Fahrzeugart. Es steht als Kennung des anderen Fahrzeugs in den Werten (hauptfahrzeugId). */
  var ZUORDNUNG_FELD = { key: 'hauptfahrzeugId', label: 'Gehört zu', typ: 'text' };

  Daten.prototype.unterschiede = function (artId, alt, neu) {
    return unterschiedeFelder(MM.Fahrzeugarten.felder(artId).concat([ZUORDNUNG_FELD]), alt, neu);
  };

  function neuester(eintraege) {
    return eintraege.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
  }
  function nachNr(a, b) { return a.nr - b.nr; }

  /* ---------- Fahrzeuge ---------- */
  /*
   * Gleiches Fahrzeug nicht doppelt (seit 2.0.46): Kennzeichen, Registriernummer, FIN und HIN gelten als Kennung. Verglichen wird ohne
   * Groß- und Kleinschreibung, Leerzeichen, Striche und Punkte (dieselbe Regel wie MM.Austausch.kennungNorm beim Import, ein Test hält beide gleich).
   * kennungTreffer(werte, ausserId) gibt die schon vorhandenen Fahrzeuge des Datenraums mit gleicher Kennung zurück, auch abgegebene
   * (gekennzeichnet), jeweils { id, name, artName, abgegeben, abgabeDatum }. Ohne Kennung gibt es keinen Treffer.
   */
  var KENNUNG_FELDER = ['kennzeichen', 'registriernummer', 'fin', 'hin'];
  function kennungNorm(s) { return String(s == null ? '' : s).toUpperCase().replace(/[\s\-.]/g, ''); }
  function kennungenVon(werte) {
    var res = [];
    KENNUNG_FELDER.forEach(function (k) {
      var n = werte && werte[k] ? kennungNorm(werte[k]) : '';
      if (n && res.indexOf(n) < 0) res.push(n);
    });
    return res;
  }
  /* Die Kennung, wie sie der Nutzer eingegeben hat (für den Hinweistext). */
  function kennungAnzeige(werte, treffer) {
    var da = {}; treffer.forEach(function (t) { (t.kennungen || []).forEach(function (n) { da[n] = true; }); });
    for (var i = 0; i < KENNUNG_FELDER.length; i++) {
      var v = werte && werte[KENNUNG_FELDER[i]];
      if (v && da[kennungNorm(v)]) return String(v).trim();
    }
    return '';
  }
  Daten.prototype.kennungTreffer = function (werte, ausserId) {
    var ids = kennungenVon(werte);
    if (!ids.length) return Promise.resolve([]);
    return this.fahrzeugListe({ alle: true }).then(function (liste) {
      return liste.filter(function (x) {
        if (ausserId && x.fahrzeug.id === ausserId) return false;
        var da = kennungenVon(x.aktuell.werte);
        return ids.some(function (k) { return da.indexOf(k) >= 0; });
      }).map(function (x) {
        var a = MM.Fahrzeugarten.art(x.fahrzeug.art), da = kennungenVon(x.aktuell.werte);
        return { id: x.fahrzeug.id, name: x.aktuell.werte.bezeichnung, artName: a ? a.name : '', abgegeben: !!x.fahrzeug.abgabe,
          abgabeDatum: x.fahrzeug.abgabe ? x.fahrzeug.abgabe.datum : null, kennungen: da.filter(function (k) { return ids.indexOf(k) >= 0; }) };
      });
    });
  };
  /* Der Satz zur Rückfrage: welches Fahrzeug es schon gibt. */
  function kennungTrefferText(werte, treffer) {
    var kennung = kennungAnzeige(werte, treffer);
    var namen = treffer.map(function (t) { return '„' + t.name + '“' + (t.abgegeben ? ' (abgegeben' + (t.abgabeDatum ? ' am ' + (MM.Hilfen ? MM.Hilfen.datum(t.abgabeDatum) : t.abgabeDatum) : '') + ')' : ''); }).join(', ');
    return 'Es gibt schon ' + (treffer.length === 1 ? 'ein Fahrzeug' : treffer.length + ' Fahrzeuge') + ' mit der Kennung „' + kennung + '“: ' + namen + '.';
  }
  Daten.prototype.kennungTrefferText = function (werte, treffer) { return kennungTrefferText(werte, treffer); };

  /* opt.trotzdem = true: ausdrücklich bestätigt, dass trotz gleicher Kennung ein neues Fahrzeug angelegt wird. */
  Daten.prototype.fahrzeugAnlegen = function (artId, roh, opt) {
    var gewaehlt = MM.Fahrzeugarten.art(artId);
    if (!gewaehlt || gewaehlt.gruppe) {
      return Promise.resolve({ ok: false, fehler: { art: 'Bitte zuerst die Fahrzeugart wählen.' } });
    }
    if (!MM.Fahrzeugarten.sichtbar(artId)) {
      return Promise.resolve({ ok: false, fehler: { art: 'Diese Fahrzeugart ist ausgeblendet. Blende sie unter „Fahrzeugarten verwalten“ wieder ein.' } });
    }
    var p = this.pruefen(artId, roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var self = this;
    var haupt = roh && roh.hauptfahrzeugId ? String(roh.hauptfahrzeugId).trim() : '';
    return this.kennungTreffer(p.werte, null).then(function (treffer) {
      /* Gleiche Kennung: nichts anlegen, erst fragen (seit 2.0.46). */
      if (treffer.length && !(opt && opt.trotzdem)) {
        return { ok: false, doppelt: treffer, fehler: { allgemein: kennungTrefferText(p.werte, treffer) } };
      }
      return self.zuordnungPruefen(null, haupt || null).then(function (zf) {
        if (zf) return { ok: false, fehler: { hauptfahrzeugId: zf } };
        if (haupt) p.werte.hauptfahrzeugId = haupt;
        var jetzt = self.jetzt();
        var fahrzeug = { id: neueId('fz'), datenraumId: self.datenraumId, art: artId, erstelltAm: jetzt };
        var eintrag = { id: neueId('en'), fahrzeugId: fahrzeug.id, nr: 1, werte: p.werte, art: artId,
          quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'fahrzeuge', objekt: fahrzeug },
          { tabelle: 'eintraege', objekt: eintrag }
        ]).then(function () { return { ok: true, id: fahrzeug.id }; });
      });
    });
  };

  /*
   * Zusammengehörige Fahrzeuge (seit 2.0.45): Der Trailer gehört zum Boot, das Dinghy zur Yacht, der Motorradanhänger zum Wohnmobil.
   * Jedes Fahrzeug bleibt eigenständig. „Gehört zu“ verweist auf ein anderes Fahrzeug des Datenraums, ist änderbar (mit Verlauf)
   * und darf eine Kette bilden (Motorrad auf Anhänger am Wohnmobil). Kein Selbstbezug, keine Kreise.
   * Gibt null zurück, wenn die Wahl in Ordnung ist, sonst den Fehlertext. eigeneId = null beim Anlegen.
   */
  Daten.prototype.zuordnungPruefen = function (eigeneId, zielId) {
    if (!zielId) return Promise.resolve(null);
    if (eigeneId && zielId === eigeneId) return Promise.resolve('Ein Fahrzeug kann nicht zu sich selbst gehören.');
    return this.fahrzeugListe({ alle: true }).then(function (liste) {
      var nachId = {}; liste.forEach(function (x) { nachId[x.fahrzeug.id] = x; });
      var ziel = nachId[zielId];
      if (!ziel) return 'Dieses Fahrzeug wurde nicht gefunden.';
      if (ziel.fahrzeug.abgabe) return 'Dieses Fahrzeug ist abgegeben und steht nicht zur Auswahl.';
      var c = ziel, n = 0;
      while (c && eigeneId && n++ < 50) {
        var weiter = c.aktuell.werte.hauptfahrzeugId || null;
        if (!weiter) break;
        if (weiter === eigeneId) return '„' + ziel.aktuell.werte.bezeichnung + '“ gehört schon ' + (c === ziel ? '' : 'über „' + c.aktuell.werte.bezeichnung + '“ ') + 'zu diesem Fahrzeug. So entstünde ein Kreis.';
        c = nachId[weiter];
      }
      return null;
    });
  };

  /*
   * Die Zuordnung eines Fahrzeugs: hauptfahrzeug (wozu es gehört), kette (von dort nach oben), direkt (was direkt zu ihm gehört)
   * und alle (alles darunter, auch über Ketten, mit Tiefe und dem Fahrzeug, zu dem es direkt gehört). Abgegebene Fahrzeuge fehlen.
   */
  Daten.prototype.fahrzeugZuordnung = function (fahrzeugId) {
    return this.fahrzeugListe({ alle: true }).then(function (liste) {
      var nachId = {}; liste.forEach(function (x) { nachId[x.fahrzeug.id] = x; });
      var ich = nachId[fahrzeugId];
      if (!ich) return null;
      function ref(x) { var a = MM.Fahrzeugarten.art(x.fahrzeug.art); return { id: x.fahrzeug.id, name: x.aktuell.werte.bezeichnung, artId: x.fahrzeug.art, artName: a ? a.name : '' }; }
      function gueltig(id) { return id && nachId[id] && !nachId[id].fahrzeug.abgabe ? nachId[id] : null; }
      var haupt = gueltig(ich.aktuell.werte.hauptfahrzeugId || null);
      var kette = [], c = haupt, n = 0;
      while (c && n++ < 50 && kette.every(function (k) { return k.id !== c.fahrzeug.id; }) && c.fahrzeug.id !== fahrzeugId) { kette.push(ref(c)); c = gueltig(c.aktuell.werte.hauptfahrzeugId || null); }
      function direktVon(id) { return liste.filter(function (x) { return !x.fahrzeug.abgabe && x.fahrzeug.id !== id && (x.aktuell.werte.hauptfahrzeugId || null) === id; }); }
      var alle = [], gesehen = {}; gesehen[fahrzeugId] = true;
      var front = [{ id: fahrzeugId, name: ich.aktuell.werte.bezeichnung, tiefe: 0 }];
      while (front.length) {
        var naechste = [];
        front.forEach(function (f) {
          direktVon(f.id).forEach(function (x) {
            if (gesehen[x.fahrzeug.id]) return;
            gesehen[x.fahrzeug.id] = true;
            var r = ref(x); r.tiefe = f.tiefe + 1; r.ueber = f.name; r.ueberId = f.id;
            alle.push(r); naechste.push({ id: r.id, name: r.name, tiefe: r.tiefe });
          });
        });
        front = naechste;
      }
      return { hauptfahrzeug: haupt ? ref(haupt) : null, kette: kette, direkt: direktVon(fahrzeugId).map(ref), alle: alle };
    });
  };

  /* Die Auswahl für „Gehört zu“: alle nicht abgegebenen Fahrzeuge außer diesem selbst und allem, was (über Ketten) zu ihm gehört. */
  Daten.prototype.zuordnungAuswahl = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.fahrzeugListe(), fahrzeugId ? this.fahrzeugZuordnung(fahrzeugId) : Promise.resolve(null)]).then(function (r) {
      var gesperrt = {}; if (fahrzeugId) gesperrt[fahrzeugId] = true;
      if (r[1]) r[1].alle.forEach(function (x) { gesperrt[x.id] = true; });
      return r[0].filter(function (x) { return !gesperrt[x.fahrzeug.id]; }).map(function (x) {
        var a = MM.Fahrzeugarten.art(x.fahrzeug.art);
        return { wert: x.fahrzeug.id, label: x.aktuell.werte.bezeichnung + (a ? ' (' + a.name + ')' : '') };
      });
    });
  };

  /* Wird ein Hauptfahrzeug abgegeben, verlieren die dazugehörigen Fahrzeuge nur die Zuordnung. Sie bleiben bestehen, der Verlauf zeigt es. Gibt ihre Namen zurück. */
  Daten.prototype.zuordnungenLoesen = function (hauptId) {
    var self = this;
    return this.fahrzeugListe().then(function (liste) {
      var betroffen = liste.filter(function (x) { return (x.aktuell.werte.hauptfahrzeugId || null) === hauptId; });
      if (!betroffen.length) return [];
      var jetzt = self.jetzt();
      var schreiben = betroffen.map(function (x) {
        var werte = Object.assign({}, x.aktuell.werte); werte.hauptfahrzeugId = null;
        return { tabelle: 'eintraege', objekt: { id: neueId('en'), fahrzeugId: x.fahrzeug.id, nr: x.aktuell.nr + 1, werte: werte, art: x.fahrzeug.art,
          quelle: 'hand', korrekturZu: x.aktuell.id, erstelltAm: jetzt } };
      });
      return self.speicher.mehrereSpeichern(schreiben).then(function () { return betroffen.map(function (x) { return x.aktuell.werte.bezeichnung; }); });
    });
  };

  /*
   * Änderung = neuer Eintrag. Der alte bleibt unverändert erhalten.
   * Mit neueArtId (seit 2.0.37) wird auch die Fahrzeugart gewechselt: Der neue Eintrag nennt die Art
   * (art) und die vorherige (artVorher), am Fahrzeug steht die Liste der Wechsel (artWechsel).
   * Felder, die es in der neuen Art nicht gibt, bleiben in den Werten erhalten und sind nur ausgeblendet.
   */
  Daten.prototype.fahrzeugAendern = function (fahrzeugId, roh, neueArtId) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (f.fahrzeug.abgabe) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug ist abgegeben. Setze es zuerst wieder auf „aktiv“, wenn du etwas ändern willst.' } };
      var altArt = f.fahrzeug.art;
      var artNeu = neueArtId && neueArtId !== altArt ? neueArtId : null;
      if (artNeu) {
        var gewaehlt = MM.Fahrzeugarten.art(artNeu);
        if (!gewaehlt || gewaehlt.gruppe) return { ok: false, fehler: { art: 'Bitte eine Fahrzeugart wählen.' } };
        if (!MM.Fahrzeugarten.sichtbar(artNeu)) return { ok: false, fehler: { art: 'Diese Fahrzeugart ist ausgeblendet. Blende sie unter „Fahrzeugarten verwalten“ wieder ein.' } };
      }
      var zielArt = artNeu || altArt;
      var p = self.pruefen(zielArt, roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      /* „Gehört zu“ (seit 2.0.45): nur prüfen, wenn es sich ändert. Fehlt die Angabe in roh, bleibt der bisherige Wert. */
      var hatZuordnung = !!roh && Object.prototype.hasOwnProperty.call(roh, 'hauptfahrzeugId');
      var wunsch = hatZuordnung && roh.hauptfahrzeugId ? String(roh.hauptfahrzeugId).trim() : null;
      var bisherZu = f.aktuell.werte.hauptfahrzeugId || null;
      var zuPruefung = hatZuordnung && wunsch !== bisherZu ? self.zuordnungPruefen(fahrzeugId, wunsch) : Promise.resolve(null);
      return zuPruefung.then(function (zf) {
        if (zf) return { ok: false, fehler: { hauptfahrzeugId: zf } };
        /* Werte, die in der neuen Art nicht vorkommen, bleiben gespeichert. */
        var werte = {};
        Object.keys(f.aktuell.werte).forEach(function (k) { if (!Object.prototype.hasOwnProperty.call(p.werte, k)) werte[k] = f.aktuell.werte[k]; });
        Object.keys(p.werte).forEach(function (k) { werte[k] = p.werte[k]; });
        if (hatZuordnung && wunsch !== bisherZu) werte.hauptfahrzeugId = wunsch;
        var diff = self.unterschiede(zielArt, f.aktuell.werte, werte);
        if (!diff.length && !artNeu) return { ok: true, id: fahrzeugId, geaendert: false };
        var jetzt = self.jetzt();
        var eintrag = { id: neueId('en'), fahrzeugId: fahrzeugId, nr: f.aktuell.nr + 1, werte: werte, art: zielArt,
          quelle: 'hand', korrekturZu: f.aktuell.id, erstelltAm: jetzt };
        var liste = [{ tabelle: 'eintraege', objekt: eintrag }];
        if (artNeu) {
          eintrag.artVorher = altArt;
          var fz = Object.assign({}, f.fahrzeug);
          fz.art = artNeu;
          fz.artWechsel = (f.fahrzeug.artWechsel || []).concat([{ von: altArt, nach: artNeu, am: jetzt, eintragNr: eintrag.nr }]);
          liste.push({ tabelle: 'fahrzeuge', objekt: fz });
        }
        return self.speicher.mehrereSpeichern(liste)
          .then(function () { return { ok: true, id: fahrzeugId, geaendert: true, artGeaendert: !!artNeu }; });
      });
    });
  };

  /*
   * Was ändert sich, wenn die Fahrzeugart gewechselt wird? Für die Warnung vor dem Speichern.
   * Nichts wird verändert. Ergebnis: { ok, alt, neu, weltWechsel, entfallen: [{ label, wert }], neuFelder: [label],
   *   ereignisse: Anzahl erfasster Ereignisse, die nicht mehr zur Art gehören, anforderungen: Anzahl }
   */
  Daten.prototype.artWechselVorschau = function (fahrzeugId, neueArtId) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      var a = MM.Fahrzeugarten.art(f.fahrzeug.art), n = MM.Fahrzeugarten.art(neueArtId);
      if (!n || n.gruppe) return { ok: false, fehler: { art: 'Bitte eine Fahrzeugart wählen.' } };
      var feldAlt = MM.Fahrzeugarten.felder(a.id), feldNeu = MM.Fahrzeugarten.felder(n.id);
      var inNeu = {}; feldNeu.forEach(function (x) { inNeu[x.key] = true; });
      var inAlt = {}; feldAlt.forEach(function (x) { inAlt[x.key] = true; });
      var entfallen = [];
      feldAlt.forEach(function (x) {
        if (inNeu[x.key]) return;
        var t = MM.Hilfen.wert(x, f.aktuell.werte[x.key]);
        if (t !== null) entfallen.push({ label: x.label, wert: t });
      });
      var neuFelder = feldNeu.filter(function (x) { return !inAlt[x.key]; }).map(function (x) { return x.label; });
      return Promise.all([self.speicher.wo('anforderungen', 'fahrzeugId', fahrzeugId), self.ereignisseDesFahrzeugs(fahrzeugId)]).then(function (r) {
        var nichtMehr = 0;
        r[1].forEach(function (e) { if (e.zuordnung !== undefined && !MM.Logbuch.ereignisartGilt(e.zuordnung, n.id)) nichtMehr++; });
        return { ok: true, alt: { id: a.id, name: a.name, welt: a.welt }, neu: { id: n.id, name: n.name, welt: n.welt },
          weltWechsel: a.welt !== n.welt, entfallen: entfallen, neuFelder: neuFelder, ereignisse: nichtMehr, anforderungen: r[0].length };
      });
    });
  };

  /* Alle erfassten Ereignisse der Aktivitäten dieses Fahrzeugs, mit der Zuordnung ihrer Ereignisart (nur lesen). */
  Daten.prototype.ereignisseDesFahrzeugs = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.aktivitaetenListe(), this.ereignisartenListe(), this.speicher.alle('ereignisse'), this.speicher.alle('verlaeufe')]).then(function (r) {
      var meine = {};
      r[0].forEach(function (a) { if (a.aktuell.werte.fahrzeugId === fahrzeugId) meine[a.objekt.id] = true; });
      var zuo = {}; r[1].forEach(function (x) { zuo[x.objekt.id] = x.aktuell.werte.zuordnung; });
      var res = [];
      neuesteStaende(r[2].filter(function (e) { return meine[e.aktivitaetId]; }), r[3], 'ereignis').forEach(function (e) {
        var w = e.aktuell.werte;
        if (w.ausgeblendet === 'ja') return;
        res.push({ id: e.objekt.id, artId: w.artId || null, zuordnung: w.artId && Object.prototype.hasOwnProperty.call(zuo, w.artId) ? zuo[w.artId] : undefined });
      });
      return res;
    });
  };

  /*
   * Alle Fahrzeuge des Datenraums, jeweils mit aktuellem Stand (Schale 1).
   * Abgegebene Fahrzeuge (seit 2.0.37) stehen nur mit opt.alle = true in der Liste, sonst fehlen sie in allen Auswahllisten.
   */
  Daten.prototype.fahrzeugListe = function (opt) {
    var self = this, alle = !!(opt && opt.alle);
    return Promise.all([this.speicher.alle('fahrzeuge'), this.speicher.alle('eintraege')]).then(function (r) {
      var nachFahrzeug = {};
      r[1].forEach(function (e) { (nachFahrzeug[e.fahrzeugId] = nachFahrzeug[e.fahrzeugId] || []).push(e); });
      var liste = r[0].filter(function (f) { return f.datenraumId === self.datenraumId && (alle || !f.abgabe); })
        .map(function (f) { return { fahrzeug: f, aktuell: neuester(nachFahrzeug[f.id] || []) }; })
        .filter(function (x) { return x.aktuell; });
      liste.sort(function (a, b) {
        return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return liste;
    });
  };

  /* Die Fahrzeugart, die zu jedem Eintrag gehörte (alte Einträge ohne Angabe: die Art vor dem ersten Wechsel). */
  function artJeEintrag(fahrzeug, eintraege) {
    var ersterWechsel = null;
    eintraege.forEach(function (e) { if (ersterWechsel === null && e.artVorher) ersterWechsel = e.artVorher; });
    return eintraege.map(function (e) { return e.art || ersterWechsel || fahrzeug.art; });
  }

  /* Ein Fahrzeug mit aktuellem Stand und dem ganzen Verlauf (neueste zuerst). */
  Daten.prototype.fahrzeugLaden = function (id) {
    var self = this;
    return Promise.all([this.speicher.holen('fahrzeuge', id), this.speicher.wo('eintraege', 'fahrzeugId', id)])
      .then(function (r) {
        var fahrzeug = r[0];
        if (!fahrzeug || !r[1].length) return null;
        var eintraege = r[1].slice().sort(nachNr);
        var arten = artJeEintrag(fahrzeug, eintraege);
        var verlauf = eintraege.map(function (e, i) {
          var vorher = i > 0 ? eintraege[i - 1] : null;
          var aenderungen = vorher ? self.unterschiede(arten[i], vorher.werte, e.werte) : [];
          if (vorher && arten[i] !== arten[i - 1]) {
            var an = MM.Fahrzeugarten.art(arten[i - 1]), nn = MM.Fahrzeugarten.art(arten[i]);
            aenderungen.unshift({ key: 'art', label: 'Fahrzeugart', feld: { typ: 'text' }, alt: an ? an.name : arten[i - 1], neu: nn ? nn.name : arten[i] });
          }
          return { eintrag: e, vorher: vorher, aenderungen: aenderungen };
        }).reverse();
        return { fahrzeug: fahrzeug, aktuell: eintraege[eintraege.length - 1], verlauf: verlauf };
      }).then(function (res) {
        /* Im Verlauf steht bei „Gehört zu“ der Name des Fahrzeugs, nicht seine Kennung (seit 2.0.45). */
        if (!res || !res.verlauf.some(function (v) { return v.aenderungen.some(function (u) { return u.key === 'hauptfahrzeugId'; }); })) return res;
        return self.fahrzeugListe({ alle: true }).then(function (liste) {
          var namen = {}; liste.forEach(function (x) { namen[x.fahrzeug.id] = x.aktuell.werte.bezeichnung; });
          res.verlauf.forEach(function (v) {
            v.aenderungen.forEach(function (u) {
              if (u.key !== 'hauptfahrzeugId') return;
              u.alt = u.alt ? (namen[u.alt] || 'ein anderes Fahrzeug') : null;
              u.neu = u.neu ? (namen[u.neu] || 'ein anderes Fahrzeug') : null;
            });
          });
          return res;
        });
      });
  };

  /* ---------- Fahrzeug abgeben (seit 2.0.37) ---------- */
  var ABGABE_GRUENDE = [
    { wert: 'verkauft', label: 'Verkauft' }, { wert: 'verschenkt', label: 'Verschenkt' },
    { wert: 'verschrottet', label: 'Verschrottet' }, { wert: 'sonstiges', label: 'Anderer Grund' }
  ];

  Daten.prototype.abgabeGruende = function () { return ABGABE_GRUENDE.slice(); };

  /*
   * Das Fahrzeug steht danach auf „abgegeben“: weg aus allen Auswahllisten, aber lesbar mit seiner ganzen Historie.
   * Nichts wird gelöscht. Die Angabe bleibt als Liste (abgabeVerlauf) erhalten, auch wenn man es wieder aktiv setzt.
   */
  Daten.prototype.fahrzeugAbgeben = function (fahrzeugId, roh) {
    var self = this;
    roh = roh || {};
    return this.speicher.holen('fahrzeuge', fahrzeugId).then(function (fz) {
      if (!fz || fz.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (fz.abgabe) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug ist schon abgegeben.' } };
      var fehler = {};
      var datum = String(roh.datum == null ? '' : roh.datum).trim();
      if (!/^\d{4}-\d{2}-\d{2}$/.test(datum) || isNaN(Date.parse(datum + 'T00:00:00Z')) || new Date(datum + 'T00:00:00Z').toISOString().slice(0, 10) !== datum) fehler.datum = 'Bitte ein Datum eingeben.';
      var heute = self.jetztLokal().slice(0, 10);
      if (!fehler.datum && datum > heute) fehler.datum = 'Das Datum darf nicht in der Zukunft liegen.';
      var grund = String(roh.grund == null ? '' : roh.grund).trim();
      if (!ABGABE_GRUENDE.some(function (g) { return g.wert === grund; })) fehler.grund = 'Bitte einen Grund wählen.';
      var notiz = String(roh.notiz == null ? '' : roh.notiz).trim();
      if (notiz.length > 500) fehler.notiz = 'Die Notiz darf höchstens 500 Zeichen haben.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var neu = Object.assign({}, fz);
      neu.abgabe = { datum: datum, grund: grund, notiz: notiz || null, erfasstAm: self.jetzt() };
      return self.speicher.speichern('fahrzeuge', neu).then(function () { return self.zuordnungenLoesen(fahrzeugId); })
        .then(function (namen) { return { ok: true, id: fahrzeugId, zuordnungGeloest: namen }; });
    });
  };

  /* Wieder aktiv setzen, zum Beispiel nach einem Fehler beim Testen. Die frühere Abgabe bleibt in abgabeVerlauf. */
  Daten.prototype.fahrzeugWiederAktiv = function (fahrzeugId) {
    var self = this;
    return this.speicher.holen('fahrzeuge', fahrzeugId).then(function (fz) {
      if (!fz || fz.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (!fz.abgabe) return { ok: true, id: fahrzeugId, geaendert: false };
      var neu = Object.assign({}, fz);
      neu.abgabeVerlauf = (fz.abgabeVerlauf || []).concat([Object.assign({}, fz.abgabe, { zurueckAm: self.jetzt() })]);
      delete neu.abgabe;
      return self.speicher.speichern('fahrzeuge', neu).then(function () { return { ok: true, id: fahrzeugId, geaendert: true }; });
    });
  };

  /* Alle abgegebenen Fahrzeuge, neueste Abgabe zuerst. */
  Daten.prototype.fahrzeugeAbgegeben = function () {
    return this.fahrzeugListe({ alle: true }).then(function (l) {
      return l.filter(function (x) { return x.fahrzeug.abgabe; }).sort(function (a, b) { return a.fahrzeug.abgabe.datum < b.fahrzeug.abgabe.datum ? 1 : (a.fahrzeug.abgabe.datum > b.fahrzeug.abgabe.datum ? -1 : 0); });
    });
  };

  /* ---------- Komponenten (Schale 3 und tiefer) ---------- */

  /* Alle Komponenten eines Fahrzeugs mit aktuellem Stand, unsortiert. */
  Daten.prototype.komponentenListe = function (fahrzeugId) {
    return Promise.all([this.speicher.wo('komponenten', 'fahrzeugId', fahrzeugId), this.speicher.alle('komponenteneintraege')])
      .then(function (r) {
        var nach = {};
        r[1].forEach(function (e) { (nach[e.komponenteId] = nach[e.komponenteId] || []).push(e); });
        return r[0].map(function (k) {
          var eintraege = (nach[k.id] || []).slice().sort(nachNr);
          return { komponente: k, eintraege: eintraege, aktuell: eintraege[eintraege.length - 1] || null };
        }).filter(function (x) { return x.aktuell; });
      });
  };

  /* Reihenfolge: Hauptkomponenten nach Art, sonst nach Bezeichnung. */
  Daten.prototype.sortiereKomponenten = function (liste) {
    return liste.slice().sort(function (a, b) {
      var ia = MM.Komponenten.artIndex(a.komponente.art), ib = MM.Komponenten.artIndex(b.komponente.art);
      if (!a.komponente.parentId && !b.komponente.parentId && ia !== ib) return ia - ib;
      return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
  };

  /*
   * Neue Komponente. parentId = null: Hauptkomponente (art ist dann Pflicht),
   * sonst gehört sie zu der genannten Komponente (Art entfällt).
   */
  Daten.prototype.komponenteAnlegen = function (fahrzeugId, parentId, artId, roh) {
    var self = this;
    return merkmaleVorbereiten(this, roh, []).then(function (mv) {
      /* Verbraucher, Stoff und Quelle (seit 2.0.48): ein Tank ist eine Hauptkomponente der Art „Tank“. */
      return versorgungVorbereiten(self, fahrzeugId, null, !parentId && artId === 'tank', mv.roh, null).then(function (vv) {
        var p = self.pruefenKomponente(mv.roh);
        var fehler = p.fehler;
        if (mv.fehler) fehler.merkmale = mv.fehler;
        Object.keys(vv.fehler).forEach(function (k) { fehler[k] = vv.fehler[k]; });
        if (!parentId && !MM.Komponenten.art(artId)) fehler.art = 'Bitte zuerst die Art der Hauptkomponente wählen.';
        if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
        Object.assign(p.werte, vv.werte);
        return komponenteAnlegenPruefen(self, fahrzeugId, parentId, artId, p, mv.schreiben.concat(vv.schreiben));
      });
    });
  };

  function komponenteAnlegenPruefen(self, fahrzeugId, parentId, artId, p, schreibenListen) {
    return Promise.all([
      self.speicher.holen('fahrzeuge', fahrzeugId),
      parentId ? self.speicher.holen('komponenten', parentId) : Promise.resolve(null)
    ]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (parentId && (!r[1] || r[1].fahrzeugId !== fahrzeugId)) {
        return { ok: false, fehler: { allgemein: 'Die übergeordnete Komponente wurde nicht gefunden.' } };
      }
      if (!parentId && artId === 'motor') {
        return self.kurznameKollision(fahrzeugId, null, p.werte).then(function (f) {
          if (f) return { ok: false, fehler: f };
          return komponenteSpeichern();
        });
      }
      return komponenteSpeichern();
    });

    function komponenteSpeichern() {
      var jetzt = self.jetzt();
      var k = { id: neueId('ko'), fahrzeugId: fahrzeugId, parentId: parentId || null,
        art: parentId ? null : artId, erstelltAm: jetzt };
      var e = { id: neueId('ke'), komponenteId: k.id, nr: 1, werte: p.werte,
        quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'komponenten', objekt: k },
        { tabelle: 'komponenteneintraege', objekt: e }
      ].concat(schreibenListen || [])).then(function () { return { ok: true, id: k.id }; });
    }
  }

  /*
   * Zwei Motoren eines Fahrzeugs sollen nicht denselben Kurznamen haben, sonst sind ihre Schalter nicht zu
   * unterscheiden. Geprüft wird nur, wenn der Nutzer einen Kurznamen selbst einträgt (ohne Eintrag gilt der Vorschlag).
   * Gibt null oder { kurzname: Text } zurück.
   */
  Daten.prototype.kurznameKollision = function (fahrzeugId, eigeneId, werte) {
    var kurz = werte && werte.kurzname ? String(werte.kurzname).trim().toUpperCase() : '';
    if (!kurz) return Promise.resolve(null);
    return this.komponentenListe(fahrzeugId).then(function (liste) {
      var anderer = liste.filter(function (k) {
        return MM.Komponenten.istMotor(k.komponente) && k.komponente.id !== eigeneId &&
          MM.Komponenten.kurzAnzeige(k.aktuell.werte).toUpperCase() === kurz;
      })[0];
      return anderer ? { kurzname: 'Der Motor „' + anderer.aktuell.werte.bezeichnung + '“ hat schon den Kurznamen ' + kurz + '. Bitte einen anderen wählen.' } : null;
    });
  };

  /* Änderung = neuer Eintrag, wie beim Fahrzeug. */
  Daten.prototype.komponenteAendern = function (komponenteId, roh) {
    var self = this;
    return this.komponenteLaden(komponenteId).then(function (c) {
      if (!c) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      return merkmaleVorbereiten(self, roh, c.aktuell.werte.merkmale || []).then(function (mv) {
        return versorgungVorbereiten(self, c.fahrzeug.id, komponenteId, MM.Versorgung.istTank(c.komponente), mv.roh, c.aktuell.werte).then(function (vv) {
          var p = self.pruefenKomponente(mv.roh);
          if (mv.fehler && !p.fehler.merkmale) { p.fehler.merkmale = mv.fehler; p.ok = false; }
          Object.keys(vv.fehler).forEach(function (k) { p.fehler[k] = vv.fehler[k]; p.ok = false; });
          if (!p.ok) return { ok: false, fehler: p.fehler };
          Object.assign(p.werte, vv.werte);
          var diff = unterschiedeFelder(MM.Komponenten.felder().concat(MM.Versorgung.ANZEIGE_FELDER), c.aktuell.werte, p.werte);
          if (!diff.length) return { ok: true, id: komponenteId, geaendert: false };
          var pruefung = MM.Komponenten.istMotor(c.komponente) ? self.kurznameKollision(c.fahrzeug.id, komponenteId, p.werte) : Promise.resolve(null);
          return pruefung.then(function (f) {
            if (f) return { ok: false, fehler: f };
            var e = { id: neueId('ke'), komponenteId: komponenteId, nr: c.aktuell.nr + 1, werte: p.werte,
              quelle: 'hand', korrekturZu: c.aktuell.id, erstelltAm: self.jetzt() };
            return self.speicher.mehrereSpeichern([{ tabelle: 'komponenteneintraege', objekt: e }].concat(mv.schreiben).concat(vv.schreiben))
              .then(function () { return { ok: true, id: komponenteId, geaendert: true }; });
          });
        });
      });
    });
  };

  /*
   * Eine Komponente mit Stand, Verlauf, dem Weg von der Hauptkomponente bis
   * zu ihr (weg), den Teilen direkt darunter (kinder) und dem Fahrzeug.
   * tiefe: 3 = Hauptkomponente (Schale 3), 4 = Teil darunter, usw.
   */
  Daten.prototype.komponenteLaden = function (id) {
    var self = this;
    return this.speicher.holen('komponenten', id).then(function (k) {
      if (!k) return null;
      return Promise.all([self.komponentenListe(k.fahrzeugId), self.fahrzeugLaden(k.fahrzeugId)]).then(function (r) {
        var alle = r[0], fz = r[1];
        var nachId = {};
        alle.forEach(function (x) { nachId[x.komponente.id] = x; });
        var ich = nachId[id];
        if (!ich || !fz) return null;

        var weg = [];
        var p = ich.komponente.parentId;
        while (p && nachId[p]) { weg.unshift(nachId[p]); p = nachId[p].komponente.parentId; }

        function anzahlKinder(x) {
          return alle.filter(function (y) { return y.komponente.parentId === x.komponente.id; }).length;
        }
        var kinder = self.sortiereKomponenten(alle.filter(function (x) { return x.komponente.parentId === id; }))
          .map(function (x) { return { komponente: x.komponente, aktuell: x.aktuell, anzahlKinder: anzahlKinder(x) }; });

        var felder = MM.Komponenten.felder().concat(MM.Versorgung.ANZEIGE_FELDER);
        /* Im Verlauf stehen bei „Quelle (Tank)“ die Namen, nicht die Kennungen; ein gelöschter Tank heißt „gelöschter Tank“ (seit 2.0.48). */
        function quellenText(ids) {
          var t = (Array.isArray(ids) ? ids : []).map(function (q) { return nachId[q] ? nachId[q].aktuell.werte.bezeichnung : 'gelöschter Tank'; });
          return t.length ? t.join(', ') : null;
        }
        var verlauf = ich.eintraege.map(function (e, i) {
          var vorher = i > 0 ? ich.eintraege[i - 1] : null;
          var aend = vorher ? unterschiedeFelder(felder, vorher.werte, e.werte) : [];
          aend.forEach(function (u) {
            if (u.key === 'quellen') { u.alt = quellenText(u.alt); u.neu = quellenText(u.neu); }
            if (u.key === 'verbraucher') { u.alt = u.alt === 'ja' ? 'Ja' : (u.alt === 'nein' ? 'Nein' : null); u.neu = u.neu === 'ja' ? 'Ja' : (u.neu === 'nein' ? 'Nein' : null); }
          });
          /* Verschieben, Ausblenden und Einblenden (seit 2.0.45) stehen als eigene Einträge im Verlauf, die Angaben bleiben gleich. */
          if (e.verschoben) aend.unshift({ key: 'verschoben', label: 'Verschoben', feld: { typ: 'text' }, alt: e.verschoben.von, neu: e.verschoben.nach });
          if (e.sichtbarkeit) aend.unshift({ key: 'sichtbarkeit', label: 'Sichtbarkeit', feld: { typ: 'text' }, alt: e.sichtbarkeit === 'ausgeblendet' ? 'sichtbar' : 'ausgeblendet', neu: e.sichtbarkeit === 'ausgeblendet' ? 'ausgeblendet' : 'sichtbar' });
          return { eintrag: e, vorher: vorher, aenderungen: aend, art: e.verschoben ? 'verschoben' : (e.sichtbarkeit ? e.sichtbarkeit : 'korrektur') };
        }).reverse();

        return { komponente: ich.komponente, aktuell: ich.aktuell, verlauf: verlauf, weg: weg, kinder: kinder,
          fahrzeug: fz.fahrzeug, fahrzeugAktuell: fz.aktuell, tiefe: weg.length + 3 };
      });
    });
  };

  /* ---------- Merkmale und Einheiten: offene Listen (seit 2.0.45) ---------- */
  /*
   * Zwei Listen mit Vorlage (MM.Komponenten.MERKMAL_VORLAGE und EINHEITEN_VORLAGE), eigenen Einträgen und Ausgeblendeten.
   * Sie liegen als Dokumente „merkmale“ und „einheiten“ in „einstellungen“ (keine Umstellung der Datenbank, die Sicherung nimmt sie mit).
   * Eine Zeile an einer Komponente trägt Name, Wert, Einheit und Bezugsgröße als Text. Ausblenden oder Ändern der Liste ändert keine Komponente.
   * Eine Einheit muss aus der Liste kommen (sonst steht einmal „kn“ und einmal „Knoten“). Neue Einheiten legt der Nutzer direkt im Formular an.
   */
  var MERKMALE_DOK = 'merkmale', EINHEITEN_DOK = 'einheiten';

  function listenDok(dok, id) {
    var d = dok ? JSON.parse(JSON.stringify(dok)) : { id: id };
    if (!Array.isArray(d.eigene)) d.eigene = [];
    if (!Array.isArray(d.ausgeblendet)) d.ausgeblendet = [];
    return d;
  }

  Daten.prototype.einheitenListe = function () {
    return this.speicher.holen('einstellungen', EINHEITEN_DOK).then(function (d) { return MM.Komponenten.einheitenListe(d); });
  };
  Daten.prototype.merkmaleListe = function () {
    return this.speicher.holen('einstellungen', MERKMALE_DOK).then(function (d) { return MM.Komponenten.merkmaleListe(d); });
  };

  Daten.prototype.einheitAnlegen = function (bezeichnung) {
    var self = this, bez = trimmed2(bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte eine Einheit eingeben, zum Beispiel „kn“.' } });
    if (bez.length > MM.Komponenten.MAX_EINHEIT) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte höchstens ' + MM.Komponenten.MAX_EINHEIT + ' Zeichen.' } });
    return this.speicher.holen('einstellungen', EINHEITEN_DOK).then(function (dok) {
      var d = listenDok(dok, EINHEITEN_DOK);
      var gleich = MM.Komponenten.einheitenListe(d).filter(function (x) { return MM.Komponenten.gleichText(x.label, bez); })[0];
      if (gleich) return { ok: false, fehler: { bezeichnung: gleich.ausgeblendet ? 'Diese Einheit gibt es schon, sie ist ausgeblendet. Blende sie wieder ein.' : 'Diese Einheit gibt es schon.' } };
      var id = neueId('ei');
      d.eigene.push({ wert: id, label: bez, erstelltAm: self.jetzt() });
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, id: id, label: bez }; });
    });
  };

  Daten.prototype.einheitAusblenden = function (wert, ausblenden) {
    var self = this;
    return this.speicher.holen('einstellungen', EINHEITEN_DOK).then(function (dok) {
      var d = listenDok(dok, EINHEITEN_DOK);
      if (!MM.Komponenten.einheitenListe(d).some(function (x) { return x.wert === wert; })) return { ok: false, fehler: { allgemein: 'Diese Einheit wurde nicht gefunden.' } };
      d.ausgeblendet = d.ausgeblendet.filter(function (x) { return x !== wert; });
      if (ausblenden) d.ausgeblendet.push(wert);
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  Daten.prototype.merkmalAnlegen = function (name, einheit, bezug) {
    var self = this, n = trimmed2(name), e = trimmed2(einheit), b = trimmed2(bezug);
    var fehler = {};
    if (!n) fehler.name = 'Bitte einen Namen für das Merkmal eingeben, zum Beispiel „Leistung“.';
    else if (n.length > MM.Komponenten.MAX_MERKMAL) fehler.name = 'Bitte höchstens ' + MM.Komponenten.MAX_MERKMAL + ' Zeichen.';
    if (b.length > MM.Komponenten.MAX_BEZUG) fehler.bezug = 'Bitte höchstens ' + MM.Komponenten.MAX_BEZUG + ' Zeichen.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return Promise.all([this.speicher.holen('einstellungen', MERKMALE_DOK), this.einheitenListe()]).then(function (r) {
      var d = listenDok(r[0], MERKMALE_DOK);
      if (MM.Komponenten.merkmaleListe(d).some(function (x) { return MM.Komponenten.gleichText(x.label, n); })) return { ok: false, fehler: { name: 'Dieses Merkmal gibt es schon.' } };
      if (e) {
        var u = r[1].filter(function (x) { return MM.Komponenten.gleichText(x.label, e); })[0];
        if (!u) return { ok: false, fehler: { einheit: 'Diese Einheit gibt es nicht in der Liste. Lege sie zuerst an.' } };
        e = u.label;
      }
      var id = neueId('me');
      d.eigene.push({ wert: id, label: n, einheit: e, bezug: b, erstelltAm: self.jetzt() });
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, id: id, label: n }; });
    });
  };

  Daten.prototype.merkmalAusblenden = function (wert, ausblenden) {
    var self = this;
    return this.speicher.holen('einstellungen', MERKMALE_DOK).then(function (dok) {
      var d = listenDok(dok, MERKMALE_DOK);
      if (!MM.Komponenten.merkmaleListe(d).some(function (x) { return x.wert === wert; })) return { ok: false, fehler: { allgemein: 'Dieses Merkmal wurde nicht gefunden.' } };
      d.ausgeblendet = d.ausgeblendet.filter(function (x) { return x !== wert; });
      if (ausblenden) d.ausgeblendet.push(wert);
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  /*
   * Vor dem Speichern einer Komponente: Die Einheit jeder Zeile muss aus der Liste kommen. Eine neu eingegebene Einheit
   * (Feld „neueEinheit“ der Zeile) kommt dabei in die Liste, ebenso ein neuer Merkmalname. Es wird erst geschrieben, wenn die
   * Komponente selbst gespeichert wird (die Rückgabe „schreiben“ geht mit in dieselbe Speicherung).
   * Zeilen, die schon vorher an der Komponente standen (bisher), füllen die Liste nicht von selbst.
   * Ergebnis: { roh, fehler: Text oder null, schreiben: [{ tabelle, objekt }] }
   */
  function merkmaleVorbereiten(self, roh, bisher) {
    roh = roh || {};
    var zeilen = Array.isArray(roh.merkmale) ? roh.merkmale : [];
    if (!zeilen.length) return Promise.resolve({ roh: roh, fehler: null, schreiben: [] });
    return Promise.all([self.speicher.holen('einstellungen', EINHEITEN_DOK), self.speicher.holen('einstellungen', MERKMALE_DOK)]).then(function (r) {
      var eDok = listenDok(r[0], EINHEITEN_DOK), mDok = listenDok(r[1], MERKMALE_DOK);
      var eListe = MM.Komponenten.einheitenListe(eDok), mListe = MM.Komponenten.merkmaleListe(mDok);
      var jetzt = self.jetzt(), eNeu = false, mNeu = false, fehler = null;
      var vorher = (bisher || []).map(function (z) { return String(z && z.name != null ? z.name : '').trim().toLowerCase(); });
      var neu = zeilen.map(function (z) {
        var c = Object.assign({}, z);
        var n = trimmed2(c.name), e = trimmed2(c.einheit), ne = trimmed2(c.neueEinheit), b = trimmed2(c.bezug);
        delete c.neueEinheit;
        if (ne) e = ne;
        if (e) {
          if (e.length > MM.Komponenten.MAX_EINHEIT) { fehler = fehler || 'Die Einheit darf höchstens ' + MM.Komponenten.MAX_EINHEIT + ' Zeichen haben.'; return c; }
          var g = eListe.filter(function (x) { return MM.Komponenten.gleichText(x.label, e); })[0];
          if (g) e = g.label;
          else if (ne) {
            var eid = neueId('ei');
            eDok.eigene.push({ wert: eid, label: e, erstelltAm: jetzt });
            eListe.push({ wert: eid, label: e, eigen: true, ausgeblendet: false });
            eNeu = true;
          } else fehler = fehler || 'Die Einheit „' + e + '“ gibt es in der Liste nicht. Bitte eine Einheit aus der Liste wählen oder eine neue anlegen.';
          c.einheit = e;
        }
        if (n && n.length <= MM.Komponenten.MAX_MERKMAL && vorher.indexOf(n.toLowerCase()) < 0 &&
            !mListe.some(function (x) { return MM.Komponenten.gleichText(x.label, n); })) {
          var mid = neueId('me');
          mDok.eigene.push({ wert: mid, label: n, einheit: e || '', bezug: b, erstelltAm: jetzt });
          mListe.push({ wert: mid, label: n, einheit: e || '', bezug: b, eigen: true, ausgeblendet: false });
          mNeu = true;
        }
        return c;
      });
      var schreiben = [];
      if (eNeu) schreiben.push({ tabelle: 'einstellungen', objekt: eDok });
      if (mNeu) schreiben.push({ tabelle: 'einstellungen', objekt: mDok });
      return { roh: Object.assign({}, roh, { merkmale: neu }), fehler: fehler, schreiben: schreiben };
    });
  }

  /* ---------- Stoffe, Verbraucher und Quelle (seit 2.0.48) ---------- */
  /*
   * Die Liste der Stoffe (Diesel, Benzin, Gas, Strom …) ist offen: Vorlage, eigene Einträge, Ausgeblendete. Sie liegt als Dokument „stoffe“
   * in „einstellungen“ (keine Umstellung der Datenbank, die Sicherung nimmt sie mit). Ein Stoff muss aus der Liste kommen, damit
   * „Diesel“ und „diesel“ nicht zwei Dinge sind. Einen neuen Stoff legt der Nutzer direkt im Formular der Komponente an.
   */
  var STOFFE_DOK = 'stoffe';

  Daten.prototype.stoffeListe = function () {
    return this.speicher.holen('einstellungen', STOFFE_DOK).then(function (d) { return MM.Versorgung.stoffeListe(d); });
  };

  Daten.prototype.stoffAnlegen = function (bezeichnung) {
    var self = this, bez = trimmed2(bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Stoff eingeben, zum Beispiel „Wasserstoff“.' } });
    if (bez.length > MM.Versorgung.MAX_STOFF) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte höchstens ' + MM.Versorgung.MAX_STOFF + ' Zeichen.' } });
    return this.speicher.holen('einstellungen', STOFFE_DOK).then(function (dok) {
      var d = listenDok(dok, STOFFE_DOK);
      var gleich = MM.Versorgung.stoffeListe(d).filter(function (x) { return MM.Versorgung.gleichText(x.label, bez); })[0];
      if (gleich) return { ok: false, fehler: { bezeichnung: gleich.ausgeblendet ? 'Diesen Stoff gibt es schon, er ist ausgeblendet. Blende ihn wieder ein.' : 'Diesen Stoff gibt es schon.' } };
      var id = neueId('st');
      d.eigene.push({ wert: id, label: bez, erstelltAm: self.jetzt() });
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, id: id, label: bez }; });
    });
  };

  Daten.prototype.stoffAusblenden = function (wert, ausblenden) {
    var self = this;
    return this.speicher.holen('einstellungen', STOFFE_DOK).then(function (dok) {
      var d = listenDok(dok, STOFFE_DOK);
      if (!MM.Versorgung.stoffeListe(d).some(function (x) { return x.wert === wert; })) return { ok: false, fehler: { allgemein: 'Diesen Stoff gibt es nicht.' } };
      d.ausgeblendet = d.ausgeblendet.filter(function (x) { return x !== wert; });
      if (ausblenden) d.ausgeblendet.push(wert);
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  /*
   * Vor dem Speichern einer Komponente: Verbraucher, Stoff und Quelle prüfen und in saubere Werte umwandeln.
   *  - Ein Tank (istTank) hat nur einen Inhalt (Stoff). „Verbraucher“ und Quelle gibt es bei ihm nicht.
   *  - Sonst: verbraucher ist 'ja', 'nein' oder leer (leer = noch nicht beantwortet). Nur bei 'ja' gelten Stoff und Quelle.
   *  - Der Stoff kommt aus der Liste oder ist neu (Feld „neuerStoff“, kommt dann in die Liste, in derselben Speicherung).
   *  - Quellen sind Tanks dieses Fahrzeugs (mehrere erlaubt). Für Strom gibt es noch keine Quelle (spätere Stufe).
   *  - Fehlen alle vier Schlüssel in roh, bleibt der bisherige Stand (bisher) unverändert.
   * Ergebnis: { werte: { verbraucher, stoff, quellen }, fehler, schreiben: [{ tabelle, objekt }] }
   */
  function versorgungVorbereiten(self, fahrzeugId, eigeneId, istTank, roh, bisher) {
    roh = roh || {};
    bisher = bisher || {};
    var V = MM.Versorgung;
    var vorhanden = ['verbraucher', 'stoff', 'neuerStoff', 'quellen', 'verbrauchAus', 'fuellstand'].some(function (k) { return Object.prototype.hasOwnProperty.call(roh, k); });
    if (!vorhanden) {
      return Promise.resolve({ werte: tankFelderUebernehmen({ verbraucher: bisher.verbraucher || null, stoff: bisher.stoff || null, quellen: V.quellenIds(bisher) }, bisher), fehler: {}, schreiben: [] });
    }
    var fehler = {};
    var ver = trimmed2(roh.verbraucher);
    if (!istTank && ver !== '' && ver !== 'ja' && ver !== 'nein') fehler.verbraucher = 'Bitte Ja oder Nein wählen.';
    var verbraucher = istTank ? null : (ver === 'ja' || ver === 'nein' ? ver : null);
    if (!istTank && verbraucher !== 'ja') {
      return Promise.resolve({ werte: { verbraucher: verbraucher, stoff: null, quellen: [] }, fehler: fehler, schreiben: [] });
    }
    /* Füllstand (nur Tank) und „Verbrauch rechnen aus“ (nur Verbraucher), seit 2.0.51 */
    var fuellRoh = istTank && Object.prototype.hasOwnProperty.call(roh, 'fuellstand') ? String(roh.fuellstand === undefined || roh.fuellstand === null ? '' : roh.fuellstand).trim() : '';
    var fuellNeu = null;
    if (fuellRoh !== '') {
      fuellNeu = MM.Tanken.zahl(fuellRoh);
      var kapRoh = MM.Tanken.kapazitaet({ merkmale: roh.merkmale });
      if (fuellNeu === null || fuellNeu < 0) fehler.fuellstand = 'Bitte eine Zahl in Litern eingeben, zum Beispiel 45 oder 0.';
      else if (fuellNeu > 1000000) fehler.fuellstand = 'Der Füllstand ist zu groß.';
      else if (kapRoh !== null && fuellNeu > kapRoh) fehler.fuellstand = 'Der Füllstand ist größer als der Tankinhalt (' + MM.Tanken.text(kapRoh) + ' l).';
    }
    var aus = null;
    if (!istTank) {
      var ausRoh = trimmed2(roh.verbrauchAus);
      if (ausRoh === 'stunden') aus = 'stunden';
      else if (ausRoh === 'fuellstand') aus = bisher.verbrauchAus !== undefined ? 'fuellstand' : null;
      else if (ausRoh === '') aus = bisher.verbrauchAus !== undefined ? bisher.verbrauchAus : null;
      else fehler.verbrauchAus = 'Bitte „Aus dem Füllstand“ oder „Aus den Betriebsstunden“ wählen.';
    }
    return Promise.all([self.speicher.holen('einstellungen', STOFFE_DOK), self.komponentenListe(fahrzeugId)]).then(function (r) {
      var dok = listenDok(r[0], STOFFE_DOK), liste = V.stoffeListe(dok), schreiben = [];
      var stoff = trimmed2(roh.stoff), neu = trimmed2(roh.neuerStoff);
      if (neu) stoff = neu;
      if (stoff) {
        if (stoff.length > V.MAX_STOFF) fehler.stoff = 'Bitte höchstens ' + V.MAX_STOFF + ' Zeichen.';
        else {
          var g = liste.filter(function (x) { return V.gleichText(x.label, stoff); })[0];
          if (g) stoff = g.label;
          else if (neu) {
            var sid = neueId('st');
            dok.eigene.push({ wert: sid, label: stoff, erstelltAm: self.jetzt() });
            schreiben.push({ tabelle: 'einstellungen', objekt: dok });
          } else fehler.stoff = 'Den Stoff „' + stoff + '“ gibt es in der Liste nicht. Bitte einen Stoff aus der Liste wählen oder einen neuen anlegen.';
        }
      }
      if (istTank && stoff && V.istStrom(stoff) && !fehler.stoff) fehler.stoff = 'Ein Tank hält keinen Strom. Batterien und Laden kommen in einer späteren Stufe.';
      var quellen = [];
      if (!istTank) {
        (Array.isArray(roh.quellen) ? roh.quellen : []).forEach(function (q) { q = String(q); if (q && quellen.indexOf(q) < 0) quellen.push(q); });
        if (stoff && V.istStrom(stoff)) {
          if (quellen.length) fehler.quellen = 'Für Strom gibt es noch keine Quelle. Das kommt in einer späteren Stufe.';
          quellen = [];
        } else {
          var nachId = {};
          r[1].forEach(function (x) { nachId[x.komponente.id] = x; });
          if (quellen.some(function (q) { return !nachId[q] || !V.istTank(nachId[q].komponente) || q === eigeneId; })) fehler.quellen = 'Eine gewählte Quelle ist kein Tank dieses Fahrzeugs.';
        }
      }
      var werte = { verbraucher: verbraucher, stoff: stoff || null, quellen: quellen };
      if (aus) werte.verbrauchAus = aus;
      var ergebnis = function (stunden) {
        tankFelderUebernehmen(werte, bisher);
        if (istTank && fuellNeu !== null && !fehler.fuellstand && fuellNeu !== bisher.fuellstand) {
          werte.fuellstand = MM.Tanken.runde(fuellNeu, 2); werte.fuellstandArt = 'angegeben'; werte.fuellstandZeit = self.jetztLokal();
          werte.fuellstandStunden = stunden || {};
          var rw = MM.Tanken.reichweite(werte.fuellstand, bisher.verbrauch || null);
          if (rw) werte.reichweite = rw; else delete werte.reichweite;
        }
        return { werte: werte, fehler: fehler, schreiben: fehler.stoff ? [] : schreiben };
      };
      /* Wer den Füllstand neu angibt, hält auch den Stand der Betriebsstunden seiner Verbraucher fest (Grundlage für den Verbrauch). */
      if (istTank && fuellNeu !== null && !fehler.fuellstand && fuellNeu !== bisher.fuellstand && eigeneId) {
        var vids = V.verbraucherVon(r[1], [eigeneId]).map(function (x) { return x.komponente.id; });
        return self.stundenStaende(fahrzeugId, vids).then(ergebnis);
      }
      return ergebnis(null);
    });
  }

  var TANK_FELDER = ['fuellstand', 'fuellstandArt', 'fuellstandZeit', 'fuellstandStunden', 'verbrauch', 'reichweite'];
  /* Was am Tank von selbst entsteht (Füllstand, Verbrauch, Reichweite) und was beim Verbraucher eingestellt ist, bleibt bei jeder Änderung erhalten. */
  function tankFelderUebernehmen(ziel, bisher) {
    TANK_FELDER.forEach(function (k) { if (bisher[k] !== undefined && ziel[k] === undefined) ziel[k] = bisher[k]; });
    if (bisher.verbrauchAus !== undefined && ziel.verbrauchAus === undefined && ziel.verbraucher === 'ja') ziel.verbrauchAus = bisher.verbrauchAus;
    return ziel;
  }

  /* Stand der Betriebsstunden-Zähler der genannten Komponenten: { Kennung: Stand }. Ohne Zähler oder ohne Stand fehlt der Eintrag. */
  Daten.prototype.stundenStaende = function (fahrzeugId, ids) {
    return this.zaehlerListe(fahrzeugId).then(function (liste) {
      var o = {};
      (ids || []).forEach(function (id) {
        var z = liste.filter(function (x) { return x.komponenteId === id && x.art === 'stunden'; })[0];
        if (z && z.stand && typeof z.stand.wert === 'number') o[id] = z.stand.wert;
      });
      return o;
    });
  };

  /* Die Kette eines Fahrzeugs: Tanks mit ihren Verbrauchern, Verbraucher ohne Quelle, offene Fragen, Tank-Vorschläge. Siehe MM.Versorgung.kette. */
  Daten.prototype.versorgungKette = function (fahrzeugId) {
    return this.komponentenListe(fahrzeugId).then(function (liste) { return MM.Versorgung.kette(liste); });
  };

  /* ---------- Komponenten löschen, ausblenden, verschieben (seit 2.0.45) ---------- */

  /*
   * Wird eine Komponente (oder ein Teil darunter) irgendwo benutzt? Das ist die EINE Stelle für diese Frage.
   * Benutzt heißt: Frist, Zähler, Motorlauf, Kosten (auch im Verlauf eines Postens), Werkstatt-Vorgang, Dokument
   * oder ein von dir bestätigter Name bei der Pflichtausrüstung („Habe ich unter anderem Namen“).
   * Ergebnis: { benutzt, gruende: [Text], anzahlUnter, inUnterteilen: ob die Verwendung an einem Teil darunter hängt }
   */
  Daten.prototype.komponenteVerwendung = function (id) {
    var self = this;
    return this.speicher.holen('komponenten', id).then(function (k) {
      if (!k) return null;
      var fid = k.fahrzeugId;
      return Promise.all([self.komponentenListe(fid), self.speicher.wo('zaehler', 'fahrzeugId', fid), self.speicher.wo('fristen', 'fahrzeugId', fid),
        self.speicher.wo('vorgaenge', 'fahrzeugId', fid), self.speicher.wo('dokumente', 'fahrzeugId', fid), self.speicher.alle('verlaeufe'),
        laufDokument(self), self.zuordnungenDokument()]).then(function (r) {
        var ids = MM.Komponenten.mitUnterkomponenten(r[0], id);
        function drin(x) { return ids.indexOf(x) >= 0; }
        var gruende = [], anUnter = false;
        function zaehle(n, einzahl, mehrzahl, objekte) {
          if (!n) return;
          gruende.push(n === 1 ? '1 ' + einzahl : n + ' ' + mehrzahl);
          if (objekte.some(function (x) { return x !== id; })) anUnter = true;
        }
        var z = r[1].filter(function (x) { return x.komponenteId && drin(x.komponenteId); });
        zaehle(z.length, 'Zähler', 'Zähler', z.map(function (x) { return x.komponenteId; }));
        var fr = r[2].filter(function (x) { return x.komponenteId && drin(x.komponenteId); });
        zaehle(fr.length, 'Frist', 'Fristen', fr.map(function (x) { return x.komponenteId; }));
        var vg = r[3].filter(function (x) { return x.komponenteId && drin(x.komponenteId); });
        zaehle(vg.length, 'Werkstatt-Vorgang', 'Werkstatt-Vorgänge', vg.map(function (x) { return x.komponenteId; }));
        var dk = r[4].filter(function (x) { return x.komponenteId && drin(x.komponenteId); });
        zaehle(dk.length, 'Dokument', 'Dokumente', dk.map(function (x) { return x.komponenteId; }));
        var posten = {}, postenKomp = [];
        r[5].forEach(function (x) {
          if (x.objektTyp === 'kosten' && x.werte && x.werte.komponenteId && drin(x.werte.komponenteId) && !posten[x.objektId]) { posten[x.objektId] = true; postenKomp.push(x.werte.komponenteId); }
        });
        zaehle(postenKomp.length, 'Kostenposten', 'Kostenposten', postenKomp);
        var lauf = (r[6].laeufe || []).filter(function (l) { return l.komponenteId && drin(l.komponenteId); });
        var nurMotorLauf = lauf.every(function (l) { var kk = r[0].filter(function (x) { return x.komponente.id === l.komponenteId; })[0]; return !!kk && MM.Komponenten.istMotor(kk.komponente); });
        zaehle(lauf.length, nurMotorLauf ? 'Motorlauf' : 'Lauf', nurMotorLauf ? 'Motorläufe' : 'Läufe', lauf.map(function (l) { return l.komponenteId; }));
        var namen = {};
        r[0].forEach(function (x) { if (drin(x.komponente.id)) namen[x.komponente.id] = x.aktuell.werte.bezeichnung; });
        var gleichGesetzt = [];
        ((r[7] && r[7].eintraege) || []).forEach(function (e) {
          (e.namen || []).forEach(function (nm) {
            Object.keys(namen).forEach(function (kid) { if (MM.Komponenten.gleichText(namen[kid], nm)) gleichGesetzt.push(kid); });
          });
        });
        if (gleichGesetzt.length) { gruende.push('bei der Pflichtausrüstung gleichgesetzt'); if (gleichGesetzt.some(function (x) { return x !== id; })) anUnter = true; }
        /* Ein Tank, aus dem ein Verbraucher bezieht (seit 2.0.48), wird benutzt. Dann nur ausblenden, sonst hängt die Quelle ins Leere. */
        var kunden = MM.Versorgung.verbraucherVon(r[0], ids).filter(function (x) { return !drin(x.komponente.id); });
        var bezogen = [];
        kunden.forEach(function (x) { MM.Versorgung.quellenIds(x.aktuell.werte).forEach(function (q) { if (drin(q)) bezogen.push(q); }); });
        zaehle(kunden.length, 'Verbraucher, der hier bezieht', 'Verbraucher, die hier beziehen', bezogen);
        return { benutzt: gruende.length > 0, gruende: gruende, anzahlUnter: ids.length - 1, inUnterteilen: anUnter, ids: ids };
      });
    });
  };

  /* Löschen nur, wenn nichts benutzt wird. Gelöscht werden die Komponente, alle Teile darunter und ihre Einträge. */
  Daten.prototype.komponenteLoeschen = function (id) {
    var self = this;
    return this.komponenteVerwendung(id).then(function (v) {
      if (!v) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      if (v.benutzt) return { ok: false, benutzt: true, gruende: v.gruende, fehler: { allgemein: 'Diese Komponente wird benutzt (' + v.gruende.join(', ') + (v.inUnterteilen ? ', zum Teil an einem Teil darunter' : '') + '). Benutzte Komponenten lassen sich nur ausblenden.' } };
      return self.speicher.alle('komponenteneintraege').then(function (alle) {
        var weg = v.ids.map(function (i) { return { tabelle: 'komponenten', id: i }; });
        alle.forEach(function (e) { if (v.ids.indexOf(e.komponenteId) >= 0) weg.push({ tabelle: 'komponenteneintraege', id: e.id }); });
        return self.speicher.mehrereLoeschen(weg).then(function () { return { ok: true, anzahl: v.ids.length, anzahlUnter: v.anzahlUnter }; });
      });
    });
  };

  /* Ausblenden oder wieder einblenden. Das steht als eigener Eintrag im Verlauf. Eine ausgeblendete Hauptkomponente verdeckt alles darunter. */
  Daten.prototype.komponenteAusblenden = function (id, ausblenden) {
    var self = this;
    ausblenden = !!ausblenden;
    return this.komponenteLaden(id).then(function (c) {
      if (!c) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      if (!!c.komponente.ausgeblendet === ausblenden) return { ok: true, id: id, geaendert: false };
      var k = Object.assign({}, c.komponente);
      if (ausblenden) k.ausgeblendet = true; else delete k.ausgeblendet;
      var e = { id: neueId('ke'), komponenteId: id, nr: c.aktuell.nr + 1, werte: JSON.parse(JSON.stringify(c.aktuell.werte)),
        quelle: 'hand', korrekturZu: c.aktuell.id, erstelltAm: self.jetzt(), sichtbarkeit: ausblenden ? 'ausgeblendet' : 'eingeblendet' };
      return self.speicher.mehrereSpeichern([{ tabelle: 'komponenten', objekt: k }, { tabelle: 'komponenteneintraege', objekt: e }])
        .then(function () { return { ok: true, id: id, geaendert: true }; });
    });
  };

  /*
   * Wohin darf eine Komponente verschoben werden? Unter jede andere Komponente desselben Fahrzeugs, nur nicht unter sich selbst
   * und nicht unter ein Teil darunter, oder direkt unters Fahrzeug (dann ist sie Hauptkomponente und braucht eine Art).
   * Ergebnis: [{ id, name, weg }] (weg = Text wie „Motor › Einspritzung“)
   */
  Daten.prototype.komponenteZiele = function (id) {
    var self = this;
    return this.speicher.holen('komponenten', id).then(function (k) {
      if (!k) return null;
      return self.komponentenListe(k.fahrzeugId).then(function (liste) {
        var nachId = {}; liste.forEach(function (x) { nachId[x.komponente.id] = x; });
        var gesperrt = MM.Komponenten.mitUnterkomponenten(liste, id);
        function weg(x) { var t = [x.aktuell.werte.bezeichnung], p = x.komponente.parentId, n = 0; while (p && nachId[p] && n++ < 50) { t.unshift(nachId[p].aktuell.werte.bezeichnung); p = nachId[p].komponente.parentId; } return t.join(' › '); }
        return self.sortiereKomponenten(liste.filter(function (x) { return gesperrt.indexOf(x.komponente.id) < 0; }))
          .map(function (x) { return { id: x.komponente.id, name: x.aktuell.werte.bezeichnung, weg: weg(x) }; });
      });
    });
  };

  /*
   * Verschiebt eine Komponente samt allem darunter. ziel: { parentId: Kennung oder null, art: Art (nur bei null Pflicht) }.
   * Geändert wird nur der Platz (parentId, bei einer Hauptkomponente die Art). Alle Verweise laufen über die Kennung und bleiben gültig.
   * Der Verlauf hält fest, von wo nach wo. In ein anderes Fahrzeug wird nicht verschoben.
   */
  Daten.prototype.komponenteVerschieben = function (id, ziel) {
    var self = this;
    ziel = ziel || {};
    var neuParent = ziel.parentId ? String(ziel.parentId) : null;
    return this.komponenteLaden(id).then(function (c) {
      if (!c) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      return self.komponentenListe(c.fahrzeug.id).then(function (liste) {
        var nachId = {}; liste.forEach(function (x) { nachId[x.komponente.id] = x; });
        if (neuParent) {
          if (!nachId[neuParent]) return { ok: false, fehler: { parentId: 'Diese Komponente gibt es an diesem Fahrzeug nicht. In ein anderes Fahrzeug lässt sich nicht verschieben.' } };
          if (MM.Komponenten.mitUnterkomponenten(liste, id).indexOf(neuParent) >= 0) return { ok: false, fehler: { parentId: 'Das geht nicht: Eine Komponente lässt sich nicht unter sich selbst oder unter ein Teil von sich verschieben.' } };
        } else if (!MM.Komponenten.art(ziel.art)) return { ok: false, fehler: { art: 'Bitte die Art der Hauptkomponente wählen (zum Beispiel „Sonstiges“).' } };
        var altParent = c.komponente.parentId || null, altArt = c.komponente.art || null;
        var neuArt = neuParent ? null : ziel.art;
        if (altParent === neuParent && altArt === neuArt) return { ok: true, id: id, geaendert: false };
        /* Tank und Verbraucher (seit 2.0.48): Ein Tank, aus dem Verbraucher beziehen, bleibt ein Tank. Ein Verbraucher wird kein Tank. */
        var warTank = MM.Versorgung.istTank(c.komponente), wirdTank = !neuParent && neuArt === 'tank';
        if (warTank && !wirdTank) {
          var kunden = MM.Versorgung.verbraucherVon(liste, id);
          if (kunden.length) return { ok: false, fehler: { allgemein: 'Dieser Tank versorgt ' + (kunden.length === 1 ? '1 Verbraucher' : kunden.length + ' Verbraucher') + ' (' + kunden.map(function (x) { return x.aktuell.werte.bezeichnung; }).join(', ') + '). Nimm ihn dort zuerst als Quelle heraus, dann lässt er sich verschieben oder umwandeln.' } };
        }
        if (wirdTank && !warTank && c.aktuell.werte.verbraucher === 'ja') return { ok: false, fehler: { art: 'Diese Komponente ist als Verbraucher eingetragen. Ein Tank ist kein Verbraucher. Ändere zuerst die Angabe „Verbraucher“.' } };
        function ortText(parentId, art) {
          if (!parentId) { var a = MM.Komponenten.art(art); return 'direkt am Fahrzeug' + (a ? ' (Art: ' + a.name + ')' : ''); }
          var t = [], p = parentId, n = 0; while (p && nachId[p] && n++ < 50) { t.unshift(nachId[p].aktuell.werte.bezeichnung); p = nachId[p].komponente.parentId; }
          return 'unter ' + t.join(' › ');
        }
        var pruefung = !neuParent && neuArt === 'motor' ? self.kurznameKollision(c.fahrzeug.id, id, c.aktuell.werte) : Promise.resolve(null);
        return pruefung.then(function (f) {
          if (f) return { ok: false, fehler: f };
          var k = Object.assign({}, c.komponente);
          k.parentId = neuParent; k.art = neuArt;
          var e = { id: neueId('ke'), komponenteId: id, nr: c.aktuell.nr + 1, werte: JSON.parse(JSON.stringify(c.aktuell.werte)),
            quelle: 'hand', korrekturZu: c.aktuell.id, erstelltAm: self.jetzt(),
            verschoben: { von: ortText(altParent, altArt), nach: ortText(neuParent, neuArt), vonParentId: altParent, nachParentId: neuParent, vonArt: altArt, nachArt: neuArt } };
          return self.speicher.mehrereSpeichern([{ tabelle: 'komponenten', objekt: k }, { tabelle: 'komponenteneintraege', objekt: e }])
            .then(function () { return { ok: true, id: id, geaendert: true }; });
        });
      });
    });
  };

  /* ---------- Hilfen für Zähler und Fristen ---------- */
  Daten.prototype.heute = function () {
    var d = new Date(this.jetzt());
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
  };

  function jahrVon(self) { return new Date(self.jetzt()).getFullYear(); }

  /* Prüft, ob Fahrzeug (und Komponente) existieren und zusammengehören. Gibt null oder einen Fehler zurück. */
  Daten.prototype.pruefeObjekt = function (fahrzeugId, komponenteId) {
    return Promise.all([
      this.speicher.holen('fahrzeuge', fahrzeugId),
      komponenteId ? this.speicher.holen('komponenten', komponenteId) : Promise.resolve(null)
    ]).then(function (r) {
      if (!r[0]) return { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' };
      if (komponenteId && (!r[1] || r[1].fahrzeugId !== fahrzeugId)) return { allgemein: 'Diese Komponente wurde nicht gefunden.' };
      return null;
    });
  };

  /* Verlauf der Angaben zu einem Objekt (Zähler, Frist): neueste zuerst, mit Unterschieden. */
  function verlaufAus(eintraege, felder) {
    var auf = eintraege.slice().sort(nachNr);
    return auf.map(function (e, i) {
      var vorher = i > 0 ? auf[i - 1] : null;
      return { eintrag: e, vorher: vorher, aenderungen: vorher ? unterschiedeFelder(felder, vorher.werte, e.werte) : [] };
    }).reverse();
  }
  function neuerVerlaufEintrag(typ, objektId, nr, werte, korrekturZu, jetzt) {
    return { id: neueId('vl'), objektTyp: typ, objektId: objektId, nr: nr, werte: werte,
      quelle: 'hand', korrekturZu: korrekturZu, erstelltAm: jetzt };
  }

  /* ---------- Zähler und Zählerstände ---------- */
  /*
   * Ein Zähler zählt Strecke (km) oder Betriebsstunden (h) und hängt am
   * Fahrzeug oder an einer einzelnen Komponente (zum Beispiel pro Motor).
   * Der Stand ist ein Verlauf von Einträgen. Der aktuelle Stand ist der
   * neueste Eintrag, ein Handeintrag hat Vorrang.
   */
  Daten.prototype.zaehlerAnlegen = function (fahrzeugId, komponenteId, art, roh) {
    var self = this;
    var p = pruefeWerte([], roh, jahrVon(this));
    var fehler = p.fehler;
    if (!MM.Fristen.zaehlerArt(art)) fehler.art = 'Bitte wählen, ob der Zähler Strecke oder Betriebsstunden zählt.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      var jetzt = self.jetzt();
      var z = { id: neueId('za'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, art: art, erstelltAm: jetzt };
      var e = neuerVerlaufEintrag('zaehler', z.id, 1, p.werte, null, jetzt);
      return self.speicher.mehrereSpeichern([{ tabelle: 'zaehler', objekt: z }, { tabelle: 'verlaeufe', objekt: e }])
        .then(function () { return { ok: true, id: z.id }; });
    });
  };

  Daten.prototype.zaehlerAendern = function (zaehlerId, roh) {
    var self = this;
    return this.zaehlerLaden(zaehlerId).then(function (z) {
      if (!z) return { ok: false, fehler: { allgemein: 'Dieser Zähler wurde nicht gefunden.' } };
      var p = pruefeWerte([], roh, jahrVon(self));
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (!unterschiedeFelder([], z.aktuell.werte, p.werte).length) return { ok: true, id: zaehlerId, geaendert: false };
      var e = neuerVerlaufEintrag('zaehler', zaehlerId, z.aktuell.nr + 1, p.werte, z.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: zaehlerId, geaendert: true }; });
    });
  };

  var FELDER_STAND = [
    { key: 'wert', label: 'Zählerstand', typ: 'zahl' },
    { key: 'datum', label: 'Abgelesen am', typ: 'datum' },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  Daten.prototype.zaehlerStandEintragen = function (zaehlerId, roh) {
    var self = this;
    var p = pruefeWerte(FELDER_STAND, roh, jahrVon(this), { ohneBezeichnung: true });
    var fehler = p.fehler, w = p.werte, heute = this.heute();
    if (w.wert === null && !fehler.wert) fehler.wert = 'Bitte den Zählerstand eingeben.';
    if (!w.datum && !fehler.datum) w.datum = heute;
    if (w.datum && w.datum > heute && !fehler.datum) fehler.datum = 'Das Datum liegt in der Zukunft.';
    return this.speicher.holen('zaehler', zaehlerId).then(function (z) {
      if (!z) return { ok: false, fehler: { allgemein: 'Dieser Zähler wurde nicht gefunden.' } };
      return self.speicher.wo('zaehlerstaende', 'zaehlerId', zaehlerId).then(function (staende) {
        var letzter = staende.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
        if (letzter && w.wert !== null && w.wert < letzter.wert && !fehler.wert) {
          var einheit = MM.Fristen.zaehlerArt(z.art).einheit;
          fehler.wert = 'Der Stand ist niedriger als der letzte Eintrag (' + MM.Hilfen.zahl(letzter.wert) + ' ' + einheit +
            ' vom ' + MM.Hilfen.datum(letzter.datum) + '). Zählerstände steigen. Wurde der Zähler getauscht, lege einen neuen Zähler an.';
        }
        if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
        var e = { id: neueId('zs'), zaehlerId: zaehlerId, nr: letzter ? letzter.nr + 1 : 1, wert: w.wert, datum: w.datum,
          notiz: w.notiz, quelle: 'hand', erstelltAm: self.jetzt() };
        return self.speicher.speichern('zaehlerstaende', e).then(function () { return { ok: true, id: e.id }; });
      });
    });
  };

  /* Alle Zähler eines Fahrzeugs mit Name, aktuellem Stand und Besitzer (Fahrzeug oder Komponente). */
  Daten.prototype.zaehlerListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([
      this.speicher.wo('zaehler', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.speicher.alle('zaehlerstaende'),
      this.komponentenListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'zaehler') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var sta = {}; r[2].forEach(function (e) { (sta[e.zaehlerId] = sta[e.zaehlerId] || []).push(e); });
      var kn = {}; r[3].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      return r[0].map(function (z) {
        var namen = (ver[z.id] || []).slice().sort(nachNr);
        var aktuell = namen[namen.length - 1];
        if (!aktuell) return null;
        var liste = (sta[z.id] || []).slice().sort(nachNr);
        var letzter = liste[liste.length - 1] || null;
        var art = MM.Fristen.zaehlerArt(z.art);
        var besitzer = z.komponenteId ? (kn[z.komponenteId] || 'Komponente') : 'Fahrzeug';
        return { zaehler: z, bezeichnung: aktuell.werte.bezeichnung, einheit: art.einheit, art: z.art,
          stand: letzter ? { wert: letzter.wert, datum: letzter.datum, quelle: letzter.quelle || 'hand' } : null,
          komponenteId: z.komponenteId, besitzer: besitzer,
          label: aktuell.werte.bezeichnung + ' (' + besitzer + ')' };
      }).filter(Boolean).sort(function (a, b) { return a.label.localeCompare(b.label, 'de', { numeric: true }); });
    });
  };

  Daten.prototype.zaehlerLaden = function (id) {
    var self = this;
    return this.speicher.holen('zaehler', id).then(function (z) {
      if (!z) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('zaehlerstaende', 'zaehlerId', id),
        self.fahrzeugLaden(z.fahrzeugId),
        self.komponentenListe(z.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[2]) return null;
        var staende = r[1].slice().sort(nachNr).reverse();
        var komp = z.komponenteId ? r[3].filter(function (k) { return k.komponente.id === z.komponenteId; })[0] : null;
        var art = MM.Fristen.zaehlerArt(z.art);
        return { zaehler: z, aktuell: eintraege[eintraege.length - 1], bezeichnung: eintraege[eintraege.length - 1].werte.bezeichnung,
          verlauf: verlaufAus(eintraege, []), staende: staende, stand: staende[0] || null, art: art, einheit: art.einheit,
          fahrzeug: r[2].fahrzeug, fahrzeugAktuell: r[2].aktuell, komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /*
   * Der Kilometer-Zähler eines Fahrzeugs (seit 2.0.20): der Zähler der Art Strecke, der am Fahrzeug selbst hängt.
   * Gibt es mehrere, gilt der mit dem jüngsten Stand (bei gleichem Datum der höhere). Null, wenn es keinen gibt.
   * Die Kilometer trägt der Nutzer von Hand ein; GPS wäre später nur eine weitere Quelle, nie Voraussetzung.
   */
  Daten.prototype.streckenZaehler = function (fahrzeugId) {
    return this.zaehlerListe(fahrzeugId).then(function (liste) {
      var meine = liste.filter(function (x) { return x.art === 'strecke' && !x.komponenteId; });
      if (!meine.length) return null;
      meine.sort(function (a, b) {
        var da = a.stand ? a.stand.datum : '', db = b.stand ? b.stand.datum : '';
        if (da !== db) return da < db ? 1 : -1;
        return (b.stand ? b.stand.wert : -1) - (a.stand ? a.stand.wert : -1);
      });
      var z = meine[0];
      return { id: z.zaehler.id, bezeichnung: z.bezeichnung, einheit: z.einheit, stand: z.stand };
    });
  };

  /* ---------- Läufe: Ein und Aus für jeden Verbraucher (Motor seit 2.0.19, allgemein seit 2.0.52) ---------- */
  /*
   * Ein Lauf hat Start, Stopp, Dauer und füllt den Betriebsstunden-Zähler des Verbrauchers. Das gilt für jeden Verbraucher
   * (Komponente mit „Verbraucher: ja“) und für jeden Motor; der Motor ist nur der erste Verbraucher mit dieser Fähigkeit.
   * Die Läufe liegen als ein Dokument „motorlaeufe“ in „einstellungen“ (keine Umstellung des Speichers, in der Sicherung enthalten;
   * der Name des Dokuments bleibt, damit bestehende Läufe gültig bleiben). Beim Stopp entsteht ein neuer Zählerstand
   * (Quelle „schalter“): letzter Stand plus Laufzeit. Nichts wird überschrieben: Eine Korrektur der Stoppzeit ist ein weiterer
   * Zählerstand (Quelle „korrektur“), der alte bleibt im Verlauf.
   * Allgemeine Namen: verbraucherStart, verbraucherStopp, verbraucherLaufKorrigieren, verbraucherZaehler, verbraucherListe,
   * verbraucherAuswahl. Die Namen motorStart, motorStopp, motorLaufKorrigieren, motorZaehler, motorenListe bleiben als
   * Weiterleitung mit den Texten und dem Verhalten für Motoren.
   */
  var MOTORLAEUFE = 'motorlaeufe';
  function laufDokument(self) {
    return self.speicher.holen('einstellungen', MOTORLAEUFE).then(function (d) { return d || { id: MOTORLAEUFE, laeufe: [] }; });
  }
  function laufFehler(text, feld) { var f = {}; f[feld || 'allgemein'] = text; return { ok: false, fehler: f }; }
  function neuesterStand(staende) { return staende.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null); }
  function zeitMs(iso) { return new Date(iso).getTime(); }

  /* Wörter für Meldungen: beim Motor wie bisher, sonst „Verbraucher“. */
  var WORT_MOTOR = { dieser: 'Dieser Motor', dieses: 'dieses Motors', lauf: 'Motorlauf', gestoppt: 'Motor gestoppt', stoppZiel: 'Stoppzeit von der Ankunft übernommen' };
  var WORT_VERBRAUCHER = { dieser: 'Dieser Verbraucher', dieses: 'dieses Verbrauchers', lauf: 'Lauf', gestoppt: 'Verbraucher gestoppt', stoppZiel: 'Stoppzeit von der Ankunft übernommen' };
  function laufWort(komponente) { return MM.Komponenten.istMotor(komponente) ? WORT_MOTOR : WORT_VERBRAUCHER; }

  /* Der Betriebsstunden-Zähler eines Verbrauchers. Gibt es keinen, entsteht er hier („Betriebsstunden“). */
  Daten.prototype.verbraucherZaehler = function (fahrzeugId, komponenteId) {
    var self = this;
    return this.zaehlerListe(fahrzeugId).then(function (liste) {
      var z = liste.filter(function (x) { return x.komponenteId === komponenteId && x.art === 'stunden'; })[0];
      if (z) return { ok: true, id: z.zaehler.id };
      return self.zaehlerAnlegen(fahrzeugId, komponenteId, 'stunden', { bezeichnung: 'Betriebsstunden' });
    });
  };
  Daten.prototype.motorZaehler = function (fahrzeugId, komponenteId) { return this.verbraucherZaehler(fahrzeugId, komponenteId); };

  /*
   * Die Läufe einer Auswahl von Komponenten eines Fahrzeugs in der Reihenfolge der Komponenten: Name, Kurzname (und was auf dem Knopf steht),
   * läuft oder nicht (seit wann), Zähler mit Stand und die letzten fünf Läufe. Eine ausgebaute oder ausgeblendete Komponente fehlt,
   * außer sie läuft noch. passt: Funktion über { komponente, aktuell }.
   */
  function laufListe(self, fahrzeugId, passt) {
    return Promise.all([self.komponentenListe(fahrzeugId), self.zaehlerListe(fahrzeugId), laufDokument(self)]).then(function (r) {
      var heute = self.heute();
      var verdeckt = MM.Komponenten.verdecktIds(r[0]);
      var motoren = self.sortiereKomponenten(r[0].filter(passt));
      return Promise.all(motoren.map(function (k) {
        var w = k.aktuell.werte, id = k.komponente.id;
        var meine = r[2].laeufe.filter(function (l) { return l.komponenteId === id; }).sort(function (a, b) { return zeitMs(b.start) - zeitMs(a.start); });
        var offen = meine.filter(function (l) { return !l.stopp; })[0] || null;
        if (w.ausgebautAm && w.ausgebautAm <= heute && !offen) return null;
        /* Ein ausgeblendeter Motor hat keinen Schalter, außer er läuft noch (seit 2.0.45). */
        if (verdeckt[id] && !offen) return null;
        var z = r[1].filter(function (x) { return x.komponenteId === id && x.art === 'stunden'; })[0] || null;
        var zu = z ? self.speicher.wo('zaehlerstaende', 'zaehlerId', z.zaehler.id) : Promise.resolve([]);
        return zu.then(function (staende) {
          var neuester = neuesterStand(staende);
          var zu_ = meine.filter(function (l) { return l.stopp; });
          return {
            komponenteId: id, name: w.bezeichnung, kurzname: w.kurzname || null, kurz: MM.Komponenten.kurzAnzeige(w), istMotor: MM.Komponenten.istMotor(k.komponente),
            laeuft: !!offen, seit: offen ? offen.start : null, laufId: offen ? offen.id : null,
            frageEreignisId: offen && offen.frage ? offen.frage.ereignisId : null, frageStufe: offen && offen.frage ? offen.frage.stufe : null,
            zaehler: z ? { id: z.zaehler.id, stand: z.stand, einheit: z.einheit } : null,
            laeufe: zu_.slice(0, 5).map(function (l, i) {
              return { id: l.id, start: l.start, stopp: l.stopp, stunden: l.stunden, standNachher: l.standNachher,
                korrigiert: !!(l.korrekturen && l.korrekturen.length),
                korrigierbar: i === 0 && !offen && !!neuester && neuester.id === l.standId };
            })
          };
        });
      })).then(function (liste) { return liste.filter(Boolean); });
    });
  }

  /* Die Motoren eines Fahrzeugs (Schalter im Cockpit). Unverändert seit 2.0.19. */
  Daten.prototype.motorenListe = function (fahrzeugId) {
    return laufListe(this, fahrzeugId, function (k) { return MM.Komponenten.istMotor(k.komponente); });
  };

  /* Die übrigen Verbraucher eines Fahrzeugs (keine Motoren), die schon einen Lauf haben oder gerade laufen. */
  Daten.prototype.verbraucherListe = function (fahrzeugId) {
    return laufListe(this, fahrzeugId, function (k) { return !MM.Komponenten.istMotor(k.komponente) && MM.Komponenten.kannLaufen(k.komponente, k.aktuell.werte); })
      .then(function (liste) { return liste.filter(function (x) { return x.laeuft || x.laeufe.length; }); });
  };

  /* Alle Verbraucher des Fahrzeugs, die ein- und ausgeschaltet werden können (auch Motoren): für die Frage „Verbraucher“ im Baukasten. */
  Daten.prototype.verbraucherAuswahl = function (fahrzeugId) {
    return laufListe(this, fahrzeugId, function (k) { return MM.Komponenten.kannLaufen(k.komponente, k.aktuell.werte); }).then(function (liste) {
      return liste.map(function (x) { return { id: x.komponenteId, name: x.name, istMotor: x.istMotor, laeuft: x.laeuft, seit: x.seit }; });
    });
  };

  /*
   * Einschalten vorbereiten: prüft und liefert, was zu speichern ist (schreiben), damit der Aufrufer es mit anderem zusammen in einem
   * Schritt speichern kann. nurMotor: der Aufruf kommt vom Motorschalter, dann gelten die Texte und Prüfungen für Motoren.
   * optionen.zeitpunktWennMoeglich (ISO): Startzeit, zum Beispiel die Zeit eines Ereignisses. Sie gilt nur, wenn sie nicht in der Zukunft
   * und nicht vor dem Ende des letzten Laufs liegt, sonst gilt jetzt. optionen.ereignisId: das Ereignis, das den Lauf auslöst.
   */
  function laufStartVorbereiten(self, komponenteId, optionen, nurMotor) {
    optionen = optionen || {};
    return self.komponenteLaden(komponenteId).then(function (c) {
      var ok = !!c && (nurMotor ? MM.Komponenten.istMotor(c.komponente) : MM.Komponenten.kannLaufen(c.komponente, c.aktuell.werte));
      if (!ok) return laufFehler(nurMotor ? 'Dieser Motor wurde nicht gefunden.' : 'Dieser Verbraucher wurde nicht gefunden.');
      var W = laufWort(c.komponente), w = c.aktuell.werte;
      if (w.ausgebautAm && w.ausgebautAm <= self.heute()) return laufFehler(W.dieser + ' ist ausgebaut.');
      if (!MM.Komponenten.istMotor(c.komponente) && c.komponente.ausgeblendet) return laufFehler(W.dieser + ' ist ausgeblendet.');
      return laufDokument(self).then(function (dok) {
        if (dok.laeufe.some(function (l) { return l.komponenteId === komponenteId && !l.stopp; })) return laufFehler(W.dieser + ' läuft schon.');
        return self.verbraucherZaehler(c.fahrzeug.id, komponenteId).then(function (zr) {
          if (!zr.ok) return laufFehler('Der Zähler für die Betriebsstunden konnte nicht angelegt werden.');
          var jetzt = self.jetzt(), start = jetzt, vomEreignis = false;
          if (optionen.zeitpunktWennMoeglich && !isNaN(zeitMs(optionen.zeitpunktWennMoeglich))) {
            var t = zeitMs(optionen.zeitpunktWennMoeglich);
            var letzterStopp = dok.laeufe.filter(function (l) { return l.komponenteId === komponenteId && l.stopp; }).reduce(function (m, l) { return Math.max(m, zeitMs(l.stopp)); }, 0);
            if (t <= zeitMs(jetzt) && t >= letzterStopp) { start = optionen.zeitpunktWennMoeglich; vomEreignis = true; }
          }
          var lauf = { id: neueId('ml'), fahrzeugId: c.fahrzeug.id, komponenteId: komponenteId, zaehlerId: zr.id, start: start,
            stopp: null, standVorher: null, standNachher: null, standId: null, stunden: null };
          if (optionen.ereignisId) lauf.startEreignisId = optionen.ereignisId;
          dok.laeufe.push(lauf);
          return { ok: true, schreiben: [{ tabelle: 'einstellungen', objekt: dok }],
            ergebnis: { ok: true, id: lauf.id, start: lauf.start, name: w.bezeichnung, vomEreignis: vomEreignis } };
        });
      });
    });
  }

  /*
   * Ausschalten vorbereiten (siehe laufStartVorbereiten). Ohne optionen: jetzt. Mit optionen.zeitpunkt (ISO): zu diesem Zeitpunkt, zum Beispiel
   * die Zeit der Ankunft (Motorstopp-Frage, seit 2.0.22); er darf nicht vor dem Start und nicht nach jetzt liegen. Mit optionen.zeitpunktWennMoeglich:
   * wie zeitpunkt, aber bei einer unpassenden Zeit gilt jetzt. optionen.ereignisId: das Ereignis, von dem die Stoppzeit stammt (kommt an den Lauf).
   */
  function laufStoppVorbereiten(self, komponenteId, optionen, nurMotor) {
    optionen = optionen || {};
    return Promise.all([laufDokument(self), self.komponenteLaden(komponenteId)]).then(function (rr) {
      var dok = rr[0], c = rr[1];
      var W = nurMotor ? WORT_MOTOR : (c ? laufWort(c.komponente) : WORT_VERBRAUCHER);
      var lauf = dok.laeufe.filter(function (l) { return l.komponenteId === komponenteId && !l.stopp; })[0];
      if (!lauf) return laufFehler(W.dieser + ' läuft nicht.');
      var jetzt = self.jetzt();
      var stoppZeit = jetzt, vomZiel = false, vomEreignis = false;
      if (optionen.zeitpunkt) {
        if (isNaN(zeitMs(optionen.zeitpunkt))) return laufFehler('Die Stoppzeit ist keine gültige Zeit.', 'zeit');
        if (zeitMs(optionen.zeitpunkt) < zeitMs(lauf.start)) return laufFehler('Der Stopp kann nicht vor dem Start liegen (Start: ' + MM.Hilfen.zeitpunkt(lauf.start) + ').', 'zeit');
        if (zeitMs(optionen.zeitpunkt) > zeitMs(jetzt)) return laufFehler('Die Zeit liegt in der Zukunft.', 'zeit');
        stoppZeit = optionen.zeitpunkt; vomZiel = true;
      } else if (optionen.zeitpunktWennMoeglich && !isNaN(zeitMs(optionen.zeitpunktWennMoeglich))) {
        var t = zeitMs(optionen.zeitpunktWennMoeglich);
        if (t >= zeitMs(lauf.start) && t <= zeitMs(jetzt)) { stoppZeit = optionen.zeitpunktWennMoeglich; vomEreignis = true; }
      }
      var stunden = MM.Motoren.laufStunden(lauf.start, stoppZeit);
      if (stunden === null) return laufFehler('Der Start liegt nach der jetzigen Uhrzeit des Geräts. Bitte die Uhr des Geräts prüfen.');
      return self.speicher.holen('zaehler', lauf.zaehlerId).then(function (z) {
        return z ? { ok: true, id: z.id } : self.verbraucherZaehler(lauf.fahrzeugId, komponenteId);
      }).then(function (zr) {
        if (!zr.ok) return laufFehler('Der Zähler für die Betriebsstunden wurde nicht gefunden.');
        return self.speicher.wo('zaehlerstaende', 'zaehlerId', zr.id).then(function (staende) {
          var letzter = neuesterStand(staende);
          var basis = letzter ? letzter.wert : 0;
          var neu = MM.Motoren.runde(basis + stunden);
          var stand = { id: neueId('zs'), zaehlerId: zr.id, nr: letzter ? letzter.nr + 1 : 1, wert: neu, datum: (vomZiel || vomEreignis) ? MM.Motoren.ortsdatum(stoppZeit) : self.heute(),
            notiz: W.lauf + ' ' + MM.Hilfen.zeitpunkt(lauf.start) + ' bis ' + MM.Hilfen.zeitpunkt(stoppZeit) + ' (' + MM.Motoren.stundenText(stunden) + ')' + (vomZiel ? ', ' + W.stoppZiel : (vomEreignis ? ', Stoppzeit vom Ereignis übernommen' : '')),
            quelle: 'schalter', laufId: lauf.id, erstelltAm: jetzt };
          lauf.stopp = stoppZeit; lauf.zaehlerId = zr.id; lauf.standVorher = basis; lauf.standNachher = neu; lauf.standId = stand.id; lauf.stunden = stunden;
          if (vomZiel) lauf.stoppVonEreignis = optionen.ereignisId || true;
          if (optionen.ereignisId) lauf.stoppEreignisId = optionen.ereignisId;
          return { ok: true, schreiben: [{ tabelle: 'zaehlerstaende', objekt: stand }, { tabelle: 'einstellungen', objekt: dok }],
            ergebnis: { ok: true, id: lauf.id, stunden: stunden, stand: neu, ohneStartstand: !letzter, stopp: stoppZeit, vomZiel: vomZiel, vomEreignis: vomEreignis } };
        });
      });
    });
  }

  function laufSpeichern(self, vorbereitet) {
    if (vorbereitet.ok === false) return Promise.resolve(vorbereitet);
    return self.speicher.mehrereSpeichern(vorbereitet.schreiben).then(function () { return vorbereitet.ergebnis; });
  }

  /* Intern für ereignisAblaufAusfuehren: prüft und liefert, was zu speichern ist, ohne selbst zu speichern. art: 'ein' oder 'aus'. */
  Daten.prototype.verbraucherLaufVorbereiten = function (art, komponenteId, optionen) {
    return art === 'ein' ? laufStartVorbereiten(this, komponenteId, optionen, false) : laufStoppVorbereiten(this, komponenteId, optionen, false);
  };

  Daten.prototype.verbraucherStart = function (komponenteId, optionen) { return laufStartVorbereiten(this, komponenteId, optionen, false).then(laufSpeichern.bind(null, this)); };
  Daten.prototype.verbraucherStopp = function (komponenteId, optionen) { return laufStoppVorbereiten(this, komponenteId, optionen, false).then(laufSpeichern.bind(null, this)); };
  Daten.prototype.motorStart = function (komponenteId) { return laufStartVorbereiten(this, komponenteId, null, true).then(laufSpeichern.bind(null, this)); };
  Daten.prototype.motorStopp = function (komponenteId, optionen) { return laufStoppVorbereiten(this, komponenteId, optionen, true).then(laufSpeichern.bind(null, this)); };

  /*
   * Der Nutzer sagt bei der Motorstopp-Frage „Läuft weiter“. stufe 'jetzt': die Frage nach der Ankunft ist beantwortet,
   * der Vorschlag nach der Wartezeit kommt später noch. stufe 'vorschlag': für dieses Ereignis kommt nichts mehr.
   */
  Daten.prototype.motorStoppFrageVerneinen = function (laufId, ereignisId, stufe) {
    var self = this;
    if (stufe !== 'jetzt' && stufe !== 'vorschlag') return Promise.resolve(laufFehler('Unbekannte Stufe der Frage.'));
    return laufDokument(this).then(function (dok) {
      var lauf = dok.laeufe.filter(function (l) { return l.id === laufId; })[0];
      if (!lauf) return laufFehler('Dieser Lauf wurde nicht gefunden.');
      if (lauf.stopp) return { ok: true, id: laufId, geaendert: false };
      var alt = lauf.frage && lauf.frage.ereignisId === ereignisId ? lauf.frage.stufe : null;
      if (alt === 'vorschlag' || alt === stufe) return { ok: true, id: laufId, geaendert: false };
      lauf.frage = { ereignisId: ereignisId, stufe: stufe };
      return self.speicher.speichern('einstellungen', dok).then(function () { return { ok: true, id: laufId, geaendert: true }; });
    });
  };

  /*
   * Stoppzeit eines beendeten Laufs korrigieren (zum Beispiel, wenn das Stoppen vergessen wurde).
   * roh: { datum, zeit } in Ortszeit. Nur der letzte Lauf eines Verbrauchers, und nur solange der Zählerstand danach nicht
   * weiterverändert wurde (sonst bleibt nur, den richtigen Stand von Hand einzutragen).
   */
  Daten.prototype.verbraucherLaufKorrigieren = function (laufId, roh) {
    var self = this; roh = roh || {};
    return laufDokument(this).then(function (dok) {
      var lauf = dok.laeufe.filter(function (l) { return l.id === laufId; })[0];
      if (!lauf) return laufFehler('Dieser Lauf wurde nicht gefunden.');
      return self.komponenteLaden(lauf.komponenteId).then(function (c) {
        var W = c ? laufWort(c.komponente) : WORT_VERBRAUCHER;
        if (!lauf.stopp) return laufFehler(W.dieser + ' läuft noch. Erst stoppen, dann die Zeit korrigieren.');
        var neuStopp = MM.Motoren.zeitpunktAusOrtszeit(roh.datum, roh.zeit);
        if (!neuStopp) return laufFehler('Bitte Datum und Uhrzeit angeben, zum Beispiel 14:30.', 'zeit');
        if (zeitMs(neuStopp) < zeitMs(lauf.start)) return laufFehler('Der Stopp kann nicht vor dem Start liegen (Start: ' + MM.Hilfen.zeitpunkt(lauf.start) + ').', 'zeit');
        var jetzt = self.jetzt();
        if (zeitMs(neuStopp) > zeitMs(jetzt)) return laufFehler('Die Zeit liegt in der Zukunft.', 'zeit');
        if (dok.laeufe.some(function (l) { return l.komponenteId === lauf.komponenteId && l.id !== lauf.id && zeitMs(l.start) >= zeitMs(lauf.start); })) {
          return laufFehler('Nur der letzte Lauf ' + W.dieses + ' lässt sich korrigieren. Trage den richtigen Zählerstand von Hand ein.');
        }
        return self.speicher.wo('zaehlerstaende', 'zaehlerId', lauf.zaehlerId).then(function (staende) {
          var letzter = neuesterStand(staende);
          if (!letzter || letzter.id !== lauf.standId) {
            return laufFehler('Seit diesem Lauf wurde der Zählerstand geändert. Die Zeit lässt sich nicht mehr korrigieren. Trage den richtigen Zählerstand von Hand ein.');
          }
          if (MM.Motoren.ortsdatum(neuStopp) === MM.Motoren.ortsdatum(lauf.stopp) && MM.Motoren.ortszeit(neuStopp) === MM.Motoren.ortszeit(lauf.stopp)) {
            return { ok: true, id: lauf.id, geaendert: false };
          }
          var stunden = MM.Motoren.laufStunden(lauf.start, neuStopp);
          var neu = MM.Motoren.runde((lauf.standVorher || 0) + stunden);
          var stand = { id: neueId('zs'), zaehlerId: lauf.zaehlerId, nr: letzter.nr + 1, wert: neu, datum: MM.Motoren.ortsdatum(neuStopp),
            notiz: 'Korrektur: ' + W.gestoppt + ' ' + MM.Hilfen.zeitpunkt(neuStopp) + ' statt ' + MM.Hilfen.zeitpunkt(lauf.stopp) + ' (' + MM.Motoren.stundenText(stunden) + ' Laufzeit)',
            quelle: 'korrektur', laufId: lauf.id, erstelltAm: jetzt };
          lauf.korrekturen = (lauf.korrekturen || []).concat([{ stoppAlt: lauf.stopp, standAlt: lauf.standNachher, korrigiertAm: jetzt }]);
          lauf.stopp = neuStopp; lauf.stunden = stunden; lauf.standNachher = neu; lauf.standId = stand.id;
          return self.speicher.mehrereSpeichern([{ tabelle: 'zaehlerstaende', objekt: stand }, { tabelle: 'einstellungen', objekt: dok }])
            .then(function () { return { ok: true, id: lauf.id, geaendert: true, stunden: stunden, stand: neu }; });
        });
      });
    });
  };
  Daten.prototype.motorLaufKorrigieren = function (laufId, roh) { return this.verbraucherLaufKorrigieren(laufId, roh); };

  /* ---------- Fristen ---------- */
  Daten.prototype.pruefenFrist = function (roh, mitAusgang) {
    var p = pruefeWerte(MM.Fristen.felder(mitAusgang), roh, jahrVon(this));
    var w = p.werte, f = p.fehler;
    if (!w.kategorie && !f.kategorie) f.kategorie = 'Bitte die Art der Frist wählen.';
    if (w.kalenderWert) { if (!w.kalenderEinheit) w.kalenderEinheit = 'monate'; } else { w.kalenderEinheit = null; }
    if (!w.wirkung) w.wirkung = 'warnen';
    if (w.vorwarnTage === null || w.vorwarnTage === undefined) w.vorwarnTage = 0;
    var hatZ = !!w.zaehlerId, hatW = w.zaehlerWert !== null && w.zaehlerWert !== undefined;
    if (hatZ && !hatW && !f.zaehlerWert) f.zaehlerWert = 'Bitte angeben, nach wie viel Strecke oder Stunden die Frist fällig wird.';
    if (!hatZ && hatW && !f.zaehlerId) f.zaehlerId = 'Bitte einen Zähler wählen oder die Zählergrenze leer lassen.';
    if (hatW && w.zaehlerWert <= 0 && !f.zaehlerWert) f.zaehlerWert = 'Die Grenze muss größer als null sein.';
    if (!w.kalenderWert && !(hatZ && hatW) && !f.kalenderWert && !f.zaehlerWert && !f.zaehlerId) {
      f.kalenderWert = 'Bitte mindestens eine Grenze angeben: Zeit oder Zähler.';
    }
    if (!hatZ) { w.zaehlerId = null; w.zaehlerWert = null; w.vorwarnZaehler = null; }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Letzte Erledigung: das späteste Datum, bei gleichem Datum die zuletzt eingetragene. */
  function letzteDurchfuehrung(liste) {
    return liste.reduce(function (a, b) {
      if (!a) return b;
      if (b.datum !== a.datum) return b.datum > a.datum ? b : a;
      return b.erstelltAm >= a.erstelltAm ? b : a;
    }, null);
  }

  function statusZu(self, frist, werte, durchfuehrungen, zaehlerInfo) {
    var letzte = letzteDurchfuehrung(durchfuehrungen);
    if (!letzte) return { status: 'unbekannt', kalender: null, zaehler: null, grund: 'Es gibt noch keine Erledigung als Ausgangswert.' };
    var res = MM.Fristen.berechne({ werte: werte, letzte: letzte, stand: zaehlerInfo ? zaehlerInfo.stand : null, heute: self.heute() });
    res.letzte = letzte;
    return res;
  }

  Daten.prototype.fristAnlegen = function (fahrzeugId, komponenteId, roh) {
    var self = this;
    var p = this.pruefenFrist(roh, true);
    var w = p.werte, fehler = p.fehler, heute = this.heute();
    var zuletztAm = w.zuletztAm, zuletztStand = w.zuletztStand;
    delete w.zuletztAm; delete w.zuletztStand;
    if (zuletztAm && zuletztAm > heute && !fehler.zuletztAm) fehler.zuletztAm = 'Das Datum liegt in der Zukunft.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return self.zaehlerListe(fahrzeugId).then(function (liste) {
        var z = w.zaehlerId ? liste.filter(function (x) { return x.zaehler.id === w.zaehlerId; })[0] : null;
        if (w.zaehlerId && !z) return { ok: false, fehler: { zaehlerId: 'Dieser Zähler gehört nicht zu diesem Fahrzeug.' } };
        var basisDatum = zuletztAm || heute;
        var basisStand = zuletztStand;
        if (basisStand === null && !zuletztAm && z && z.stand) basisStand = z.stand.wert;
        var e2 = {};
        if (z && basisStand === null) e2.zuletztStand = 'Bitte den Zählerstand angeben, bei dem die Frist zuletzt erledigt wurde, oder trage zuerst einen aktuellen Zählerstand ein.';
        if (z && basisStand !== null && z.stand && basisStand > z.stand.wert) {
          e2.zuletztStand = 'Dieser Stand ist höher als der aktuelle Zählerstand (' + MM.Hilfen.zahl(z.stand.wert) + ' ' + z.einheit + '). Trage zuerst den aktuellen Zählerstand ein.';
        }
        if (Object.keys(e2).length) return { ok: false, fehler: e2 };

        var jetzt = self.jetzt();
        var fr = { id: neueId('fr'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, erstelltAm: jetzt };
        var ve = neuerVerlaufEintrag('frist', fr.id, 1, w, null, jetzt);
        var du = { id: neueId('du'), fristId: fr.id, datum: basisDatum, zaehlerstand: z ? basisStand : null,
          notiz: 'Ausgangswert bei Anlage der Frist', art: 'ausgangswert', quelle: 'hand', erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'fristen', objekt: fr }, { tabelle: 'verlaeufe', objekt: ve }, { tabelle: 'durchfuehrungen', objekt: du }
        ]).then(function () { return { ok: true, id: fr.id }; });
      });
    });
  };

  Daten.prototype.fristAendern = function (fristId, roh) {
    var self = this;
    return this.fristLaden(fristId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Diese Frist wurde nicht gefunden.' } };
      var p = self.pruefenFrist(roh, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.zaehlerListe(f.frist.fahrzeugId).then(function (liste) {
        if (p.werte.zaehlerId && !liste.some(function (x) { return x.zaehler.id === p.werte.zaehlerId; })) {
          return { ok: false, fehler: { zaehlerId: 'Dieser Zähler gehört nicht zu diesem Fahrzeug.' } };
        }
        if (!unterschiedeFelder(MM.Fristen.felder(false), f.aktuell.werte, p.werte).length) return { ok: true, id: fristId, geaendert: false };
        var e = neuerVerlaufEintrag('frist', fristId, f.aktuell.nr + 1, p.werte, f.aktuell.id, self.jetzt());
        return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: fristId, geaendert: true }; });
      });
    });
  };

  var FELDER_ERLEDIGT = [
    { key: 'datum', label: 'Erledigt am', typ: 'datum' },
    { key: 'zaehlerstand', label: 'Zählerstand dabei', typ: 'zahl', min: 0 },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  /* Eine Erledigung (Prüfung, Kontrolle, Arbeit). Sie setzt die Rechnung der Frist neu an. */
  Daten.prototype.durchfuehrungAnlegen = function (fristId, roh) {
    var self = this;
    var p = pruefeWerte(FELDER_ERLEDIGT, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, fehler = p.fehler, heute = this.heute();
    if (!w.datum && !fehler.datum) w.datum = heute;
    if (w.datum && w.datum > heute && !fehler.datum) fehler.datum = 'Das Datum liegt in der Zukunft.';
    return this.fristLaden(fristId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Diese Frist wurde nicht gefunden.' } };
      var z = f.zaehler;
      var neuerStand = null;
      if (z && !fehler.zaehlerstand) {
        if (w.zaehlerstand === null) {
          if (w.datum === heute && z.stand) w.zaehlerstand = z.stand.wert;
          else fehler.zaehlerstand = 'Bitte den Zählerstand angeben, bei dem die Frist erledigt wurde.';
        } else if (f.letzte && f.letzte.zaehlerstand !== null && f.letzte.zaehlerstand !== undefined && w.zaehlerstand < f.letzte.zaehlerstand) {
          fehler.zaehlerstand = 'Der Stand ist niedriger als bei der letzten Erledigung (' + MM.Hilfen.zahl(f.letzte.zaehlerstand) + ' ' + z.einheit + ').';
        }
        if (!fehler.zaehlerstand && w.zaehlerstand !== null && (!z.stand || w.zaehlerstand > z.stand.wert)) neuerStand = w.zaehlerstand;
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };

      var jetzt = self.jetzt();
      var du = { id: neueId('du'), fristId: fristId, datum: w.datum, zaehlerstand: w.zaehlerstand, notiz: w.notiz,
        art: 'erledigt', quelle: 'hand', erstelltAm: jetzt };
      var liste = [{ tabelle: 'durchfuehrungen', objekt: du }];
      if (neuerStand === null) return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: du.id }; });
      /* Ist der Stand höher als der bisher bekannte, wird er auch im Zähler eingetragen (eine Quelle). */
      return self.speicher.wo('zaehlerstaende', 'zaehlerId', z.zaehler.id).then(function (staende) {
        var nr = staende.reduce(function (m, e) { return Math.max(m, e.nr); }, 0) + 1;
        liste.push({ tabelle: 'zaehlerstaende', objekt: { id: neueId('zs'), zaehlerId: z.zaehler.id, nr: nr, wert: neuerStand,
          datum: w.datum, notiz: 'Bei Erledigung: ' + f.aktuell.werte.bezeichnung, quelle: 'hand', erstelltAm: jetzt } });
        return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: du.id }; });
      });
    });
  };

  /* Alle Fristen eines Fahrzeugs mit gerechnetem Stand. Sortiert: überfällig zuerst. */
  Daten.prototype.fristenListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([
      this.speicher.wo('fristen', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.speicher.alle('durchfuehrungen'),
      this.zaehlerListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'frist') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var du = {}; r[2].forEach(function (e) { (du[e.fristId] = du[e.fristId] || []).push(e); });
      var zl = {}; r[3].forEach(function (z) { zl[z.zaehler.id] = z; });
      var res = r[0].map(function (fr) {
        var eintraege = (ver[fr.id] || []).slice().sort(nachNr);
        var aktuell = eintraege[eintraege.length - 1];
        if (!aktuell) return null;
        var z = aktuell.werte.zaehlerId ? zl[aktuell.werte.zaehlerId] || null : null;
        return { frist: fr, aktuell: aktuell, zaehler: z, status: statusZu(self, fr, aktuell.werte, du[fr.id] || [], z) };
      }).filter(Boolean);
      res.sort(function (a, b) {
        var d = MM.Fristen.rang(b.status.status) - MM.Fristen.rang(a.status.status);
        return d || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true });
      });
      return res;
    });
  };

  Daten.prototype.fristLaden = function (id) {
    var self = this;
    return this.speicher.holen('fristen', id).then(function (fr) {
      if (!fr) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('durchfuehrungen', 'fristId', id),
        self.zaehlerListe(fr.fahrzeugId),
        self.fahrzeugLaden(fr.fahrzeugId),
        self.komponentenListe(fr.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[3]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        var zl = r[2];
        var z = aktuell.werte.zaehlerId ? zl.filter(function (x) { return x.zaehler.id === aktuell.werte.zaehlerId; })[0] || null : null;
        var du = r[1].slice().sort(function (a, b) { return a.datum !== b.datum ? (a.datum < b.datum ? 1 : -1) : (a.erstelltAm < b.erstelltAm ? 1 : -1); });
        var verlauf = verlaufAus(eintraege, MM.Fristen.felder(false));
        /* Zähler im Verlauf mit Namen statt Kennung zeigen */
        var namen = {}; zl.forEach(function (x) { namen[x.zaehler.id] = x.label; });
        verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'zaehlerId') { u.alt = u.alt ? (namen[u.alt] || 'unbekannter Zähler') : null; u.neu = u.neu ? (namen[u.neu] || 'unbekannter Zähler') : null; }
          });
        });
        var komp = fr.komponenteId ? r[4].filter(function (k) { return k.komponente.id === fr.komponenteId; })[0] : null;
        return { frist: fr, aktuell: aktuell, verlauf: verlauf, durchfuehrungen: du, letzte: letzteDurchfuehrung(r[1]),
          zaehler: z, zaehlerListe: zl, status: statusZu(self, fr, aktuell.werte, r[1], z),
          fahrzeug: r[3].fahrzeug, fahrzeugAktuell: r[3].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /* Pro Fahrzeug: wie viele Fristen sind überfällig oder bald fällig? */
  Daten.prototype.fristenUebersicht = function () {
    var self = this;
    return this.fahrzeugListe().then(function (liste) {
      return Promise.all(liste.map(function (x) { return self.fristenListe(x.fahrzeug.id); })).then(function (alle) {
        var res = {};
        liste.forEach(function (x, i) {
          var z = { ueberfaellig: 0, bald: 0, unbekannt: 0 };
          alle[i].forEach(function (f) { if (z[f.status.status] !== undefined) z[f.status.status]++; });
          res[x.fahrzeug.id] = z;
        });
        return res;
      });
    });
  };

  /* ---------- Werkstatt: Vorgänge (Störungen und Arbeiten, seit 2.0.24) ---------- */
  /*
   * Ein Vorgang ist eine Störung oder eine Arbeit am Fahrzeug oder an einer Komponente.
   * Er ist offen oder erledigt, nichts wird gelöscht. Jede Änderung ist ein neuer Eintrag im
   * Verlauf. Aus einer Störung wird eine Arbeit (selbst oder durch eine Werkstatt).
   * Offene Vorgänge mit Einschränkung bremsen das Fahrzeug: Für versprochene Aktivitäten
   * kommt dann eine Warnung, und der Nutzer entscheidet pro Aktivität: trotzdem nutzen
   * oder absagen (Absagen läuft über das vorhandene Stornieren der Aktivität).
   */
  Daten.prototype.pruefenVorgang = function (roh, art) {
    var p = pruefeWerte(MM.Werkstatt.felder(art), roh, jahrVon(this), {
      bezeichnungFehler: 'Bitte kurz sagen, worum es geht, zum Beispiel „Motor springt schlecht an“ oder „Ölwechsel“.' });
    var w = p.werte, f = p.fehler, heute = this.heute();
    if (!w.auswirkung && !f.auswirkung) {
      if (art === 'stoerung') f.auswirkung = 'Bitte wählen, wie weit die Störung das Fahrzeug einschränkt.';
      else w.auswirkung = 'keine';
    }
    if (!w.gemeldetAm && !f.gemeldetAm) w.gemeldetAm = heute;
    if (w.gemeldetAm && w.gemeldetAm > heute && !f.gemeldetAm) f.gemeldetAm = 'Das Datum liegt in der Zukunft.';
    if (art === 'arbeit') {
      if (!w.ausfuehrung && !f.ausfuehrung) f.ausfuehrung = 'Bitte wählen, ob du die Arbeit selbst erledigst oder eine Werkstatt sie macht.';
    } else { w.ausfuehrung = null; w.arbeit = null; }
    /* Verweis auf die Adressliste (seit 2.0.25), nur bei einer Arbeit. Ob es die Adresse gibt, prüft pruefeAdresseDesVorgangs. */
    var aid = roh && typeof roh.adresseId === 'string' ? roh.adresseId.trim() : '';
    w.adresseId = (art === 'arbeit' && aid) ? aid : null;
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Prüft die gewählte Adresse eines Vorgangs. behalte = die Adresse, die schon am Vorgang hängt: sie bleibt erlaubt, auch wenn sie inzwischen ausgeblendet ist. */
  function pruefeAdresseDesVorgangs(self, adresseId, behalte) {
    if (!adresseId) return Promise.resolve(null);
    return self.mitVerlaufLaden('adressen', adresseId, adresseFelder()).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { adresseId: 'Diese Adresse gibt es nicht.' };
      if (x.aktuell.werte.ausgeblendet === 'ja' && adresseId !== behalte) return { adresseId: 'Diese Adresse ist ausgeblendet. Blende sie in der Adressliste wieder ein, wenn du sie brauchst.' };
      return null;
    });
  }

  Daten.prototype.vorgangAnlegen = function (fahrzeugId, komponenteId, art, roh) {
    var self = this;
    if (art !== 'stoerung' && art !== 'arbeit') return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Art von Vorgang gibt es nicht.' } });
    var p = this.pruefenVorgang(roh, art);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return pruefeAdresseDesVorgangs(self, p.werte.adresseId, null).then(function (af) {
        if (af) return { ok: false, fehler: af };
        var w = p.werte;
        w.art = art; w.status = 'offen'; w.erledigtAm = null; w.erledigtNotiz = null;
        var jetzt = self.jetzt();
        var v = { id: neueId('vg'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'vorgaenge', objekt: v }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('vorgang', v.id, 1, w, null, jetzt) }
        ]).then(function () { return { ok: true, id: v.id }; });
      });
    });
  };

  /* Ein Vorgang in einem neuen Stand. Die Änderung bekommt die Werte, gibt neue Werte oder einen Fehler zurück. */
  function vorgangNeuerStand(self, id, aenderung) {
    return self.vorgangLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
      var neu = aenderung(Object.assign({}, x.aktuell.werte), x);
      if (neu.fehler) return { ok: false, fehler: neu.fehler };
      return self.mitVerlaufAendern('vorgang', id, { aktuell: x.aktuell }, neu.werte, MM.Werkstatt.felderAlle());
    });
  }

  Daten.prototype.vorgangAendern = function (id, roh) {
    var self = this;
    var aid = roh && typeof roh.adresseId === 'string' ? roh.adresseId.trim() : '';
    return this.vorgangLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
      var aw = x.aktuell.werte;
      return pruefeAdresseDesVorgangs(self, aw.art === 'arbeit' ? aid : '', aw.adresseId || null);
    }).then(function (af) {
      if (af && af.ok === false) return af;
      if (af) return { ok: false, fehler: af };
      return vorgangNeuerStand(self, id, function (alt) {
        if (alt.status === 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist erledigt. Öffne ihn zuerst wieder, wenn du etwas ändern willst.' } };
        var p = self.pruefenVorgang(roh, alt.art);
        if (!p.ok) return { fehler: p.fehler };
        return { werte: Object.assign(alt, p.werte) };
      });
    });
  };

  /* Aus einer offenen Störung eine Arbeit machen: selbst erledigen oder durch eine Werkstatt. */
  Daten.prototype.vorgangZuArbeit = function (id, roh) {
    var self = this;
    var p = pruefeWerte(MM.Werkstatt.felder('arbeit').filter(function (x) { return x.key === 'ausfuehrung' || x.key === 'arbeit'; }), roh, jahrVon(this), { ohneBezeichnung: true });
    if (!p.werte.ausfuehrung && !p.fehler.ausfuehrung) p.fehler.ausfuehrung = 'Bitte wählen, ob du die Arbeit selbst erledigst oder eine Werkstatt sie macht.';
    if (Object.keys(p.fehler).length) return Promise.resolve({ ok: false, fehler: p.fehler });
    var aid = roh && typeof roh.adresseId === 'string' ? roh.adresseId.trim() : '';
    return pruefeAdresseDesVorgangs(this, aid, null).then(function (af) {
      if (af) return { ok: false, fehler: af };
      return vorgangNeuerStand(self, id, function (alt) {
        if (alt.status === 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist erledigt.' } };
        if (alt.art !== 'stoerung') return { fehler: { allgemein: 'Das ist schon eine Arbeit.' } };
        alt.art = 'arbeit'; alt.ausfuehrung = p.werte.ausfuehrung; alt.arbeit = p.werte.arbeit; alt.adresseId = aid || null;
        return { werte: alt };
      });
    });
  };

  Daten.prototype.vorgangErledigen = function (id, roh) {
    var self = this;
    var p = pruefeWerte([{ key: 'datum', label: 'Erledigt am', typ: 'datum' }, { key: 'notiz', label: 'Notiz', typ: 'text' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var heute = this.heute();
    if (!p.werte.datum && !p.fehler.datum) p.werte.datum = heute;
    if (p.werte.datum && p.werte.datum > heute && !p.fehler.datum) p.fehler.datum = 'Das Datum liegt in der Zukunft.';
    if (Object.keys(p.fehler).length) return Promise.resolve({ ok: false, fehler: p.fehler });
    return vorgangNeuerStand(this, id, function (alt) {
      if (alt.status === 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist schon erledigt.' } };
      if (alt.gemeldetAm && p.werte.datum < alt.gemeldetAm) return { fehler: { datum: 'Das Datum liegt vor dem Tag, an dem der Vorgang eingetragen wurde (' + MM.Hilfen.datum(alt.gemeldetAm) + ').' } };
      alt.status = 'erledigt'; alt.erledigtAm = p.werte.datum; alt.erledigtNotiz = p.werte.notiz;
      return { werte: alt };
    });
  };

  Daten.prototype.vorgangWiederOeffnen = function (id) {
    return vorgangNeuerStand(this, id, function (alt) {
      if (alt.status !== 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist nicht erledigt.' } };
      alt.status = 'offen'; alt.erledigtAm = null; alt.erledigtNotiz = null;
      return { werte: alt };
    });
  };

  function vorgangEintrag(v, eintraege, namen) {
    var l = eintraege.slice().sort(nachNr);
    var a = l[l.length - 1];
    if (!a) return null;
    return { vorgang: v, aktuell: a, komponenteId: v.komponenteId, besitzer: v.komponenteId ? (namen[v.komponenteId] || 'Komponente') : null };
  }
  function vorgangSortieren(res) {
    res.sort(function (a, b) {
      var d = MM.Werkstatt.rang(b.aktuell.werte) - MM.Werkstatt.rang(a.aktuell.werte);
      if (d) return d;
      var wa = a.aktuell.werte, wb = b.aktuell.werte;
      var da = wa.status === 'erledigt' ? (wa.erledigtAm || '') : (wa.gemeldetAm || ''), db = wb.status === 'erledigt' ? (wb.erledigtAm || '') : (wb.gemeldetAm || '');
      if (da !== db) return da < db ? 1 : -1;
      return wa.bezeichnung.localeCompare(wb.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
    return res;
  }

  /* Alle Vorgänge eines Fahrzeugs und seiner Komponenten. Was das Fahrzeug am meisten bremst, steht oben, Erledigtes unten. */
  Daten.prototype.vorgaengeListe = function (fahrzeugId) {
    return Promise.all([this.speicher.wo('vorgaenge', 'fahrzeugId', fahrzeugId), this.speicher.alle('verlaeufe'), this.komponentenListe(fahrzeugId)]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'vorgang') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var kn = {}; r[2].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      return vorgangSortieren(r[0].map(function (v) { return vorgangEintrag(v, ver[v.id] || [], kn); }).filter(Boolean));
    });
  };

  /* Pro Fahrzeug: wie viele Vorgänge sind offen, wie viele bremsen das Fahrzeug? */
  Daten.prototype.vorgaengeUebersicht = function () {
    var self = this;
    return this.fahrzeugListe().then(function (liste) {
      return Promise.all(liste.map(function (x) { return self.vorgaengeListe(x.fahrzeug.id); })).then(function (alle) {
        var res = {};
        liste.forEach(function (x, i) {
          var z = { offen: 0, nicht: 0, bedingt: 0 };
          alle[i].forEach(function (v) {
            var w = v.aktuell.werte;
            if (w.status !== 'offen') return;
            z.offen++;
            if (MM.Werkstatt.bremst(w)) z[w.auswirkung]++;
          });
          res[x.fahrzeug.id] = z;
        });
        return res;
      });
    });
  };

  /* Entscheidungen „trotzdem nutzen“: neueste je Vorgang und Aktivität. */
  function neuesteEntscheidungen(liste) {
    var res = {};
    liste.forEach(function (e) {
      var k = e.vorgangId + '|' + e.aktivitaetId;
      if (!res[k] || e.nr > res[k].nr) res[k] = e;
    });
    return res;
  }

  Daten.prototype.vorgangLaden = function (id) {
    var self = this;
    return this.speicher.holen('vorgaenge', id).then(function (v) {
      if (!v) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.fahrzeugLaden(v.fahrzeugId),
        self.komponentenListe(v.fahrzeugId),
        self.speicher.wo('vorgangsentscheidungen', 'vorgangId', id),
        self.adressenListe()
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[1]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        /* Im Verlauf steht bei der Adresse ihr Name, nicht ihre Kennung. */
        var adressOpt = r[4].map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; });
        var felder = MM.Werkstatt.felderAlle().map(function (f) { return f.key === 'adresseId' ? Object.assign({}, f, { optionen: adressOpt }) : f; });
        var adresse = aktuell.werte.adresseId ? (r[4].filter(function (a) { return a.objekt.id === aktuell.werte.adresseId; })[0] || null) : null;
        var komp = v.komponenteId ? r[2].filter(function (k) { return k.komponente.id === v.komponenteId; })[0] : null;
        var neueste = neuesteEntscheidungen(r[3]), entscheidungen = {};
        Object.keys(neueste).forEach(function (k) { var e = neueste[k]; entscheidungen[e.aktivitaetId] = { entscheidung: e.entscheidung, am: e.erstelltAm }; });
        return { vorgang: v, aktuell: aktuell, verlauf: verlaufAus(eintraege, felder), adresse: adresse,
          fahrzeug: r[1].fahrzeug, fahrzeugAktuell: r[1].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null,
          entscheidungen: entscheidungen };
      });
    });
  };

  /*
   * Warnung für ein Fahrzeug: Bremsen offene Vorgänge das Fahrzeug, und ist es für die nächste Zeit
   * versprochen (Aktivität läuft oder ist geplant, nicht storniert)? Gibt immer ein Ergebnis zurück:
   * stufe 'nicht', 'bedingt' oder 'ok', die bremsenden Vorgänge und die betroffenen Aktivitäten.
   * Eine Aktivität gilt als entschieden („trotzdem nutzen“), wenn das für jeden bremsenden Vorgang bestätigt ist.
   */
  Daten.prototype.vorgangWarnung = function (fahrzeugId) {
    return Promise.all([this.vorgaengeListe(fahrzeugId), this.aktivitaetenListe(), this.speicher.alle('vorgangsentscheidungen')]).then(function (r) {
      var bremsend = r[0].filter(function (x) { return MM.Werkstatt.bremst(x.aktuell.werte); });
      var stufe = MM.Werkstatt.einsatz(r[0].map(function (x) { return x.aktuell.werte; }));
      var neueste = neuesteEntscheidungen(r[2]);
      var aktivitaeten = stufe === 'ok' ? [] : r[1].filter(function (a) {
        return a.aktuell.werte.fahrzeugId === fahrzeugId && (a.status === 'laeuft' || a.status === 'geplant');
      }).map(function (a) {
        var entschieden = bremsend.every(function (b) { var e = neueste[b.vorgang.id + '|' + a.objekt.id]; return e && e.entscheidung === 'trotzdem'; });
        return { aktivitaet: a, trotzdem: entschieden };
      });
      return { stufe: stufe, vorgaenge: bremsend, aktivitaeten: aktivitaeten };
    });
  };

  /* Entscheidung zu einer Aktivität: 'trotzdem' (trotzdem nutzen) oder 'offen' (zurückgenommen). Nichts wird gelöscht. */
  Daten.prototype.vorgangEntscheiden = function (vorgangId, aktivitaetId, entscheidung) {
    var self = this;
    if (entscheidung !== 'trotzdem' && entscheidung !== 'offen') return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Entscheidung gibt es nicht.' } });
    return Promise.all([this.speicher.holen('vorgaenge', vorgangId), this.speicher.holen('aktivitaeten', aktivitaetId), this.speicher.wo('vorgangsentscheidungen', 'vorgangId', vorgangId)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
      if (!r[1]) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var nr = r[2].filter(function (e) { return e.aktivitaetId === aktivitaetId; }).reduce(function (m, e) { return Math.max(m, e.nr); }, 0) + 1;
      var e = { id: neueId('vt'), vorgangId: vorgangId, aktivitaetId: aktivitaetId, nr: nr, entscheidung: entscheidung, erstelltAm: self.jetzt() };
      return self.speicher.speichern('vorgangsentscheidungen', e).then(function () { return { ok: true, id: e.id }; });
    });
  };

  /* ---------- Werkstatt: Adressen (Werkstätten, Lieferanten, Händler, seit 2.0.25) ---------- */
  /*
   * Eine einzige, zentrale Liste im Datenraum des Nutzers, nicht pro Fahrzeug. Jede Änderung ist ein neuer
   * Eintrag im Verlauf. Eine Adresse, auf die ein Vorgang verweist, wird nie gelöscht: Es gibt kein Löschen,
   * nur Ausblenden (wie bei Orten und Gebieten). Der Vorgang verweist mit adresseId auf sie.
   */
  function adresseFelder() { return MM.Werkstatt.adressFelder().concat([{ key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }]); }

  Daten.prototype.pruefenAdresse = function (roh) {
    var p = pruefeWerte(MM.Werkstatt.adressFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen eingeben, zum Beispiel „Autohaus Müller“.' });
    var w = p.werte, f = p.fehler;
    if (!w.art && !f.art) f.art = 'Bitte wählen, ob es eine Werkstatt, ein Lieferant oder ein Händler ist.';
    if (w.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(w.email)) f.email = 'Das ist keine gültige E-Mail-Adresse.';
    if (w.telefon && !/^[0-9+\-\/() ]{5,}$/.test(w.telefon)) f.telefon = 'Bitte nur Ziffern, Leerzeichen und + - / ( ) eingeben.';
    w.ausgeblendet = roh && roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Welche Vorgänge verweisen (im aktuellen Stand) auf welche Adresse? { adresseId: [{ vorgang, aktuell }] } */
  function vorgaengeNachAdresse(vorgaenge, verlaeufe) {
    var neu = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === 'vorgang' && (!neu[e.objektId] || e.nr > neu[e.objektId].nr)) neu[e.objektId] = e; });
    var res = {};
    vorgaenge.forEach(function (v) {
      var a = neu[v.id];
      if (a && a.werte.adresseId) (res[a.werte.adresseId] = res[a.werte.adresseId] || []).push({ vorgang: v, aktuell: a });
    });
    return res;
  }

  /* Alle Adressen, nach Namen sortiert, mit der Zahl der Vorgänge, die darauf verweisen. */
  Daten.prototype.adressenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('adressen'), this.speicher.alle('verlaeufe'), this.speicher.alle('vorgaenge')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'adresse');
      var karte = vorgaengeNachAdresse(r[2], r[1]);
      liste.forEach(function (x) { x.anzahlVorgaenge = (karte[x.objekt.id] || []).length; });
      return liste;
    });
  };

  function gleicheAdresse(liste, name, art, ausser) {
    var n = name.toLowerCase();
    return liste.some(function (x) { return x.objekt.id !== ausser && x.aktuell.werte.art === art && x.aktuell.werte.bezeichnung.toLowerCase() === n; });
  }

  Daten.prototype.adresseAnlegen = function (roh) {
    var self = this;
    var p = this.pruefenAdresse(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    p.werte.ausgeblendet = 'nein';
    return this.adressenListe().then(function (liste) {
      if (gleicheAdresse(liste, p.werte.bezeichnung, p.werte.art)) return { ok: false, fehler: { bezeichnung: 'Diese Adresse gibt es schon.' } };
      return self.mitVerlaufAnlegen('adressen', 'adresse', 'ad', p.werte);
    });
  };

  Daten.prototype.adresseAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('adressen', id, adresseFelder()), this.adressenListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Adresse wurde nicht gefunden.' } };
      var p = self.pruefenAdresse(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicheAdresse(r[1], p.werte.bezeichnung, p.werte.art, id)) return { ok: false, fehler: { bezeichnung: 'Diese Adresse gibt es schon.' } };
      return self.mitVerlaufAendern('adresse', id, x, p.werte, adresseFelder());
    });
  };

  /* Eine Adresse mit Verlauf und den Vorgängen, die darauf verweisen (mit Fahrzeug, offene zuerst). */
  Daten.prototype.adresseLaden = function (id) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('adressen', id, adresseFelder()), this.speicher.alle('vorgaenge'), this.speicher.alle('verlaeufe'), this.fahrzeugListe({ alle: true })]).then(function (r) {
      var x = r[0];
      if (!x || x.objekt.datenraumId !== self.datenraumId) return null;
      var fz = {}; r[3].forEach(function (f) { fz[f.fahrzeug.id] = f.aktuell.werte.bezeichnung; });
      x.vorgaenge = (vorgaengeNachAdresse(r[1], r[2])[id] || []).map(function (m) {
        var w = m.aktuell.werte;
        return { id: m.vorgang.id, bezeichnung: w.bezeichnung, art: w.art, status: w.status, fahrzeugName: fz[m.vorgang.fahrzeugId] || 'Fahrzeug' };
      }).sort(function (a, b) {
        if (a.status !== b.status) return a.status === 'offen' ? -1 : 1;
        return a.bezeichnung.localeCompare(b.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return x;
    });
  };

  /* ---------- Kosten (seit 2.0.27) ---------- */
  /*
   * Eine einzige Kosten-Liste für alle Fahrzeuge (Tabelle „kosten“, Index fahrzeugId). Ein Posten gehört zu einem
   * Fahrzeug und hat die Gruppe Fixkosten, variable Kosten oder Instandhaltung. Die Gruppe lässt sich nachträglich
   * nicht ändern. Verweise (in den Werten, damit sie im Verlauf stehen): komponenteId, aktivitaetId (nur variable
   * Kosten), vorgangId (nur Instandhaltung, nur beim Anlegen). Jede Änderung ist ein neuer Eintrag im Verlauf, nichts
   * wird gelöscht: Ein Posten lässt sich ausblenden und wieder einblenden, ausgeblendete rechnen nicht mit.
   * Die Kostenstammdaten (Tabelle „kostenstamm“, eine Zeile je Fahrzeug, Verlauf) halten Wert, Wertverlust und den
   * Vergleichspreis. Der Wertverlust ist keine Eingabe, sondern wird in der Auswertung gerechnet.
   */
  function trimmed2(v) { return typeof v === 'string' ? v.trim() : ''; }

  /* Geldbeträge: Der Punkt als Tausendertrennzeichen („2.400“, „1.234,50“) gilt als Tausenderpunkt, nicht als Komma:
     „2.400“ sind 2400 Euro und nicht 2,4. Alles andere (Komma oder Punkt als Dezimalzeichen, „12,5“ und „12.5“) bleibt, wie es ist. */
  function geldRoh(v) {
    if (typeof v !== 'string') return v;
    var t = v.replace(/\s/g, '').replace(/€/g, '');
    return /^\d{1,3}(\.\d{3})+(,\d+)?$/.test(t) ? t.replace(/\./g, '') : t;
  }

  /* arten (seit 2.0.29, freiwillig): die Kostenarten, die gelten (eingebaute und eigene). Ohne Angabe gelten nur die eingebauten. */
  Daten.prototype.pruefenKosten = function (roh, gruppe, arten) {
    roh = Object.assign({}, roh || {});
    roh.betrag = geldRoh(roh.betrag);
    var g = MM.Kosten.istGruppe(gruppe) ? gruppe : null;
    if (!g) return { werte: {}, fehler: { gruppe: 'Bitte wählen: Fixkosten, variable Kosten, Instandhaltung oder Reisekasse.' }, ok: false };
    var p = pruefeWerte(MM.Kosten.felder(g, arten), roh, jahrVon(this), {
      bezeichnungFehler: 'Bitte kurz sagen, wofür der Betrag ist, zum Beispiel „Liegeplatz Heimathafen“ oder „Zündkerzen“.' });
    var w = p.werte, f = p.fehler;
    w.gruppe = g;
    /* Währung (seit 2.0.29): nur bei variablen Kosten und in der Reisekasse. Ohne Angabe oder bei EUR steht nichts am Posten (Euro). */
    var wRoh = trimmed2(roh.waehrung), wc = wRoh ? MM.Reisekasse.waehrungNormal(wRoh) : null;
    if (wRoh && !wc) f.waehrung = 'Bitte ein Währungskürzel mit drei Buchstaben eingeben, zum Beispiel NOK.';
    var fremd = !!wc && wc !== 'EUR';
    if (fremd && g !== 'variabel' && g !== 'reisekasse') f.waehrung = 'Eine andere Währung gibt es nur bei variablen Kosten und in der Reisekasse.';
    var extra = pruefeWerte([{ key: 'betragWaehrung', typ: 'zahl' }, { key: 'ortText', typ: 'text', maxLaenge: 120 }],
      Object.assign({}, roh, { betragWaehrung: geldRoh(roh.betragWaehrung) }), jahrVon(this), { ohneBezeichnung: true });
    if (extra.fehler.ortText) f.ortText = extra.fehler.ortText;
    if (fremd && extra.fehler.betragWaehrung) f.betragWaehrung = extra.fehler.betragWaehrung;
    w.waehrung = fremd ? wc : null;
    w.betragWaehrung = null;
    if (fremd && !f.betragWaehrung) {
      var bw = extra.werte.betragWaehrung;
      if (!(bw > 0)) f.betragWaehrung = 'Bitte den Betrag in ' + wc + ' eingeben.';
      else if (bw > 1000000000) f.betragWaehrung = 'Der Betrag ist zu groß.';
      else w.betragWaehrung = MM.Kosten.runde(bw);
    }
    /* Der Euro-Betrag darf bei Fremdwährung fehlen: Dann rechnet ihn die App mit dem Kurs der Kasse. */
    if (w.betrag === null && !f.betrag && !fremd) f.betrag = 'Bitte einen Betrag eingeben.';
    else if (w.betrag !== null && !f.betrag) {
      if (!(w.betrag > 0)) f.betrag = 'Der Betrag muss größer als 0 sein.';
      else if (w.betrag > 10000000) f.betrag = 'Der Betrag ist zu groß.';
      else w.betrag = MM.Kosten.runde(w.betrag);
    }
    if (!w.datum && !f.datum) w.datum = this.heute();
    if (g === 'fix') {
      if (!w.rhythmus && !f.rhythmus) f.rhythmus = 'Bitte wählen, wie oft der Betrag fällig wird.';
      if (w.rhythmus === 'einmalig') w.bis = null;
      if (w.bis && w.datum && w.bis < w.datum && !f.bis) f.bis = 'Das Ende kann nicht vor dem Beginn liegen.';
    } else { w.rhythmus = 'einmalig'; w.bis = null; }
    if (!w.grundlage && !f.grundlage) w.grundlage = 'eingegeben';
    w.komponenteId = trimmed2(roh.komponenteId) || null;
    var mitAkt = g === 'variabel' || g === 'reisekasse';
    var aid = trimmed2(roh.aktivitaetId);
    if (aid && !mitAkt) f.aktivitaetId = 'Eine Aktivität kann nur bei variablen Kosten und in der Reisekasse gewählt werden.';
    if (g === 'reisekasse' && !aid && !f.aktivitaetId) f.aktivitaetId = 'Eine Ausgabe der Reisekasse gehört zu einer Aktivität. Bitte wählen.';
    w.aktivitaetId = mitAkt && aid ? aid : null;
    var oid = trimmed2(roh.ortId);
    if (oid && !mitAkt) f.ortId = 'Ein Ort kann nur bei variablen Kosten und in der Reisekasse gewählt werden.';
    w.ortId = mitAkt && oid ? oid : null;
    var ot = extra.werte.ortText;
    if (ot && !mitAkt) f.ortText = 'Ein Ort als Text kann nur bei variablen Kosten und in der Reisekasse stehen.';
    w.ortText = mitAkt && ot ? ot : null;
    /* Tag der Reise (seit 2.0.43): ein Posten einer Aktivität kann einem Tag (Etappe) zugeordnet werden. */
    var tid = trimmed2(roh.abschnittId);
    if (tid && !(mitAkt && aid)) f.abschnittId = 'Ein Tag kann nur bei Kosten einer Aktivität gewählt werden.';
    w.abschnittId = mitAkt && aid && tid ? tid : null;
    w.besuchId = null;
    w.vorgangId = null;
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Prüft, ob es die verknüpften Dinge gibt und ob sie zum Fahrzeug gehören. Gibt null oder die Fehler zurück. */
  function pruefeKostenVerweise(self, fahrzeugId, w, vorgangId) {
    return Promise.all([
      w.komponenteId ? self.speicher.holen('komponenten', w.komponenteId) : Promise.resolve(null),
      w.aktivitaetId ? self.aktivitaetLaden(w.aktivitaetId) : Promise.resolve(null),
      vorgangId ? self.speicher.holen('vorgaenge', vorgangId) : Promise.resolve(null),
      w.ortId ? self.speicher.holen('orte', w.ortId) : Promise.resolve(null),
      w.abschnittId ? self.speicher.holen('tagesabschnitte', w.abschnittId) : Promise.resolve(null)
    ]).then(function (r) {
      var fehler = {};
      if (w.abschnittId && (!r[4] || r[4].aktivitaetId !== w.aktivitaetId)) fehler.abschnittId = 'Diesen Tag gibt es bei dieser Aktivität nicht.';
      if (w.ortId && (!r[3] || r[3].datenraumId !== self.datenraumId)) fehler.ortId = 'Diesen Ort gibt es nicht.';
      if (w.komponenteId && (!r[0] || r[0].fahrzeugId !== fahrzeugId)) fehler.komponenteId = 'Diese Komponente gibt es an diesem Fahrzeug nicht.';
      if (w.aktivitaetId && (!r[1] || r[1].fahrzeug.id !== fahrzeugId)) fehler.aktivitaetId = 'Diese Aktivität gibt es für dieses Fahrzeug nicht.';
      if (vorgangId && (!r[2] || r[2].fahrzeugId !== fahrzeugId)) fehler.vorgangId = 'Diesen Vorgang gibt es an diesem Fahrzeug nicht.';
      return { fehler: Object.keys(fehler).length ? fehler : null, vorgang: r[2] };
    });
  }

  /* Neuer Posten. roh.gruppe ist Pflicht, roh.vorgangId (freiwillig) hängt den Betrag an einen Vorgang der Werkstatt.
     Seit 2.0.29: eigene Kostenarten, eine neue Art mitten im Formular (neueKostenart), Bezahlt mit (bezahltMit, neuesZahlungsmittel),
     Währung (waehrung, betragWaehrung), Ort als Text (ortText) und die Gruppe „reisekasse“ (gehört immer zu einer Aktivität). */
  Daten.prototype.kostenAnlegen = function (fahrzeugId, roh) {
    var self = this;
    roh = roh || {};
    var vid = trimmed2(roh.vorgangId), bid = trimmed2(roh.besuchId);
    return kostenVollstaendig(self, roh, roh.gruppe, null, null).then(function (p) {
      var fehler = p.ok ? {} : Object.assign({}, p.fehler);
      var gr = MM.Kosten.istGruppe(roh.gruppe) ? roh.gruppe : null;
      if (vid && gr && gr !== 'instandhaltung') fehler.gruppe = 'Ein Betrag an einem Vorgang gehört zur Instandhaltung.';
      if (bid && gr && gr !== 'variabel') fehler.gruppe = 'Ein Betrag an einem Besuch gehört zu den variablen Kosten.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      return self.pruefeObjekt(fahrzeugId, null).then(function (f) {
        if (f) return { ok: false, fehler: f };
        /* Ein Betrag an einem Besuch (seit 2.0.28) übernimmt Ort und Aktivität des Besuchs. */
        return (bid ? self.mitVerlaufLaden('besuche', bid, []) : Promise.resolve(null)).then(function (bx) {
          if (bid && (!bx || bx.objekt.fahrzeugId !== fahrzeugId || bx.aktuell.werte.status !== 'besucht')) return { ok: false, fehler: { besuchId: 'Diesen Besuch gibt es an diesem Fahrzeug nicht.' } };
          if (bx) { p.werte.ortId = bx.aktuell.werte.ortId || null; p.werte.aktivitaetId = bx.objekt.aktivitaetId || null; }
          return pruefeKostenVerweise(self, fahrzeugId, p.werte, vid || null).then(function (v) {
            if (v.fehler) return { ok: false, fehler: v.fehler };
            var w = p.werte;
            w.besuchId = bx ? bid : null;
            w.vorgangId = vid || null;
            if (v.vorgang && !w.komponenteId) w.komponenteId = v.vorgang.komponenteId || null;
            var jetzt = self.jetzt(), ko = { id: neueId('ko'), datenraumId: self.datenraumId, fahrzeugId: fahrzeugId, erstelltAm: jetzt };
            return self.speicher.mehrereSpeichern(p.schreiben.concat([{ tabelle: 'kosten', objekt: ko },
              { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kosten', ko.id, 1, w, null, jetzt) }])).then(function () { return { ok: true, id: ko.id }; });
          });
        });
      });
    });
  };

  Daten.prototype.kostenAendern = function (id, roh) {
    var self = this;
    roh = roh || {};
    return this.mitVerlaufLaden('kosten', id, MM.Kosten.felderAlle()).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieser Posten wurde nicht gefunden.' } };
      var alt = x.aktuell.werte;
      /* Ein Posten der Reisekasse bleibt an seiner Aktivität. */
      if (alt.gruppe === 'reisekasse') roh = Object.assign({}, roh, { aktivitaetId: alt.aktivitaetId });
      return kostenVollstaendig(self, roh, alt.gruppe, alt, null).then(function (p) {
        if (!p.ok) return { ok: false, fehler: p.fehler };
        if (!Object.prototype.hasOwnProperty.call(roh, 'ausgeblendet')) p.werte.ausgeblendet = alt.ausgeblendet || 'nein';
        return pruefeKostenVerweise(self, x.objekt.fahrzeugId, p.werte, null).then(function (v) {
          if (v.fehler) return { ok: false, fehler: v.fehler };
          p.werte.vorgangId = alt.vorgangId || null;
          /* Kommt das Feld „Tag“ nicht mit, bleibt der bisherige Tag erhalten. */
          if (!Object.prototype.hasOwnProperty.call(roh, 'abschnittId') && p.werte.aktivitaetId === (alt.aktivitaetId || null)) p.werte.abschnittId = alt.abschnittId || null;
          /* Ein Betrag aus einem Besuch behält Besuch und Ort (sonst stimmt die Historie des Ortes nicht mehr). */
          p.werte.besuchId = alt.besuchId || null;
          if (alt.besuchId) p.werte.ortId = alt.ortId || null;
          var aenderung = unterschiedeFelder(MM.Kosten.felderAlle(), alt, p.werte).length > 0;
          if (!aenderung && !p.schreiben.length) return { ok: true, id: id, geaendert: false };
          var e = aenderung ? neuerVerlaufEintrag('kosten', id, x.aktuell.nr + 1, p.werte, x.aktuell.id, self.jetzt()) : null;
          return self.speicher.mehrereSpeichern(p.schreiben.concat(e ? [{ tabelle: 'verlaeufe', objekt: e }] : []))
            .then(function () { return { ok: true, id: id, geaendert: aenderung }; });
        });
      });
    });
  };

  /* Ausblenden (der Posten rechnet nicht mehr mit) oder wieder einblenden. Nichts wird gelöscht. */
  Daten.prototype.kostenAusblenden = function (id, ausblenden) {
    var self = this;
    return this.mitVerlaufLaden('kosten', id, MM.Kosten.felderAlle()).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieser Posten wurde nicht gefunden.' } };
      var w = Object.assign({}, x.aktuell.werte, { ausgeblendet: ausblenden ? 'ja' : 'nein' });
      return self.mitVerlaufAendern('kosten', id, x, w, MM.Kosten.felderAlle());
    });
  };

  /*
   * Löschen (seit 2.0.46): Der Posten, sein ganzer Verlauf und seine Fotos und Belege (samt Dateien) werden endgültig entfernt.
   * Wer nur will, dass der Posten nicht mehr mitrechnet, blendet ihn aus. Die Kasse einer Reise rechnet aus den Posten, ein gelöschter
   * Betrag zählt dort nicht mehr. Ergebnis { ok, belege } mit der Zahl der mitgelöschten Fotos und Belege.
   */
  Daten.prototype.kostenLoeschen = function (id) {
    var self = this;
    return this.speicher.holen('kosten', id).then(function (o) {
      if (!o || o.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieser Posten wurde nicht gefunden.' } };
      return Promise.all([self.speicher.wo('verlaeufe', 'objektId', id), self.speicher.wo('dokumente', 'kostenId', id)]).then(function (r) {
        var docs = r[1].filter(function (d) { return d.kostenId === id; });
        return Promise.all(docs.map(function (d) {
          return Promise.all([self.speicher.wo('verlaeufe', 'objektId', d.id), self.speicher.wo('dateien', 'dokumentId', d.id)]);
        })).then(function (rd) {
          var weg = [{ tabelle: 'kosten', id: id }];
          r[0].forEach(function (e) { if (e.objektTyp === 'kosten') weg.push({ tabelle: 'verlaeufe', id: e.id }); });
          docs.forEach(function (d, i) {
            weg.push({ tabelle: 'dokumente', id: d.id });
            rd[i][0].forEach(function (e) { if (e.objektTyp === 'dokument') weg.push({ tabelle: 'verlaeufe', id: e.id }); });
            rd[i][1].forEach(function (f) { weg.push({ tabelle: 'dateien', id: f.id }); });
          });
          return self.speicher.mehrereLoeschen(weg).then(function () { return { ok: true, belege: docs.length }; });
        });
      });
    });
  };

  /* Namen für die Verweise der Posten eines Fahrzeugs: { komponenten, aktivitaeten, vorgaenge } (Kennung -> Name). */
  function kostenNamen(self, fahrzeugId) {
    return Promise.all([self.komponentenListe(fahrzeugId), self.aktivitaetenListe(), self.vorgaengeListe(fahrzeugId), self.orteListe()]).then(function (r) {
      var k = {}, a = {}, v = {}, o = {};
      r[0].forEach(function (x) { k[x.komponente.id] = x.aktuell.werte.bezeichnung; });
      r[1].forEach(function (x) { a[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      r[2].forEach(function (x) { v[x.vorgang.id] = x.aktuell.werte.bezeichnung; });
      r[3].forEach(function (x) { o[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      return { komponenten: k, aktivitaeten: a, vorgaenge: v, orte: o };
    });
  }

  function kostenSortieren(liste) {
    liste.sort(function (a, b) {
      var da = a.aktuell.werte.datum || '', db = b.aktuell.werte.datum || '';
      if (da !== db) return da < db ? 1 : -1;
      return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
    return liste;
  }

  /* Alle Posten eines Fahrzeugs (auch ausgeblendete), neueste zuerst, mit den Namen der Verweise. */
  Daten.prototype.kostenListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.speicher.wo('kosten', 'fahrzeugId', fahrzeugId), this.speicher.alle('verlaeufe'), kostenNamen(this, fahrzeugId), this.kostenartenListe(), this.zahlungsmittelListe()]).then(function (r) {
      var artN = {}, zmN = {};
      r[3].forEach(function (x) { artN[x.wert] = x.label; }); r[4].forEach(function (x) { zmN[x.wert] = x.label; });
      var ver = {};
      r[1].forEach(function (e) { if (e.objektTyp === 'kosten') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var n = r[2];
      var liste = r[0].filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
        var l = (ver[o.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1];
        if (!a) return null;
        var w = a.werte;
        return { objekt: o, aktuell: a, komponenteName: w.komponenteId ? (n.komponenten[w.komponenteId] || 'Komponente') : null,
          aktivitaetName: w.aktivitaetId ? (n.aktivitaeten[w.aktivitaetId] || 'Aktivität') : null,
          vorgangName: w.vorgangId ? (n.vorgaenge[w.vorgangId] || 'Vorgang') : null,
          ortName: w.ortId ? (n.orte[w.ortId] || 'Ort') : null,
          artName: w.kostenart ? (artN[w.kostenart] || 'Art') : null, zahlungName: w.bezahltMit ? (zmN[w.bezahltMit] || 'Zahlungsmittel') : null };
      }).filter(Boolean);
      return kostenSortieren(liste);
    });
  };

  /* Ein Posten mit Verlauf (die Verweise im Verlauf mit Namen) und den verknüpften Dingen. */
  Daten.prototype.kostenLaden = function (id) {
    var self = this;
    return this.speicher.holen('kosten', id).then(function (o) {
      if (!o || o.datenraumId !== self.datenraumId) return null;
      return Promise.all([self.speicher.wo('verlaeufe', 'objektId', id), self.fahrzeugLaden(o.fahrzeugId), kostenNamen(self, o.fahrzeugId), self.kostenartenListe(), self.zahlungsmittelListe(), self.dokumenteFuerKosten(id)]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[1]) return null;
        var artN = {}, zmN = {};
        r[3].forEach(function (x) { artN[x.wert] = x.label; }); r[4].forEach(function (x) { zmN[x.wert] = x.label; });
        var n = r[2], aktuell = eintraege[eintraege.length - 1];
        function opt(karte) { return Object.keys(karte).map(function (k) { return { wert: k, label: karte[k] }; }); }
        var felder = MM.Kosten.felderAlle().map(function (f) {
          if (f.key === 'komponenteId') return Object.assign({}, f, { optionen: opt(n.komponenten) });
          if (f.key === 'aktivitaetId') return Object.assign({}, f, { optionen: opt(n.aktivitaeten) });
          if (f.key === 'vorgangId') return Object.assign({}, f, { optionen: opt(n.vorgaenge) });
          if (f.key === 'ortId') return Object.assign({}, f, { optionen: opt(n.orte) });
          if (f.key === 'kostenart') return Object.assign({}, f, { optionen: r[3].map(function (x) { return { wert: x.wert, label: x.label }; }) });
          if (f.key === 'bezahltMit') return Object.assign({}, f, { optionen: r[4].map(function (x) { return { wert: x.wert, label: x.label }; }) });
          return f;
        });
        var w = aktuell.werte;
        return { objekt: o, aktuell: aktuell, verlauf: verlaufAus(eintraege, felder), fahrzeug: r[1].fahrzeug, fahrzeugAktuell: r[1].aktuell,
          komponenteName: w.komponenteId ? (n.komponenten[w.komponenteId] || 'Komponente') : null,
          aktivitaetName: w.aktivitaetId ? (n.aktivitaeten[w.aktivitaetId] || 'Aktivität') : null,
          vorgangName: w.vorgangId ? (n.vorgaenge[w.vorgangId] || 'Vorgang') : null,
          ortName: w.ortId ? (n.orte[w.ortId] || 'Ort') : null,
          artName: w.kostenart ? (artN[w.kostenart] || 'Art') : null, zahlungName: w.bezahltMit ? (zmN[w.bezahltMit] || 'Zahlungsmittel') : null,
          dokumente: r[5] };
      });
    });
  };

  /* ---------- Offene Listen: Kostenarten und Zahlungsmittel (seit 2.0.29) ---------- */
  /*
   * Kostenarten: die eingebauten (Startliste in MM.Kosten.KOSTENARTEN, Kennung = ihr Name) und eigene (Tabelle „kostenarten“, mit Verlauf).
   * Eine Art gehört zu einer Gruppe. Benutzte Arten werden nur ausgeblendet, nicht gelöscht. Ausgeblendet bleibt eine Art an
   * bestehenden Posten gültig. Die eingebauten lassen sich ebenfalls ausblenden (Einstellung „kostenarten“).
   * Zahlungsmittel: „Bar“ ist fest (Kennung 'bar', gehört zur Kasse), alle weiteren sind eigene Bezeichnungen ohne Nummern.
   */
  var KOSTENART_FELDER = [{ key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: [{ wert: 'ja', label: 'Ja' }, { wert: 'nein', label: 'Nein' }] }];

  Daten.prototype.kostenartenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('kostenarten'), this.speicher.alle('verlaeufe'), this.speicher.holen('einstellungen', 'kostenarten')]).then(function (r) {
      var versteckt = (r[2] && r[2].ausgeblendet) || [];
      var liste = MM.Kosten.KOSTENARTEN.map(function (a) { return { wert: a.wert, label: a.label, gruppe: a.gruppe, eigen: false, ausgeblendet: versteckt.indexOf(a.wert) >= 0 }; });
      sammle(self, r[0], r[1], 'kostenart').forEach(function (x) {
        liste.push({ wert: x.objekt.id, label: x.aktuell.werte.bezeichnung, gruppe: x.aktuell.werte.gruppe, eigen: true, ausgeblendet: x.aktuell.werte.ausgeblendet === 'ja' });
      });
      return liste;
    });
  };

  Daten.prototype.kostenartAnlegen = function (gruppe, bezeichnung) {
    var self = this, bez = trimmed2(bezeichnung);
    if (!MM.Kosten.istGruppe(gruppe)) return Promise.resolve({ ok: false, fehler: { gruppe: 'Bitte die Gruppe wählen.' } });
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben, zum Beispiel „Kurtaxe“.' } });
    if (bez.length > 60) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte höchstens 60 Zeichen.' } });
    return this.kostenartenListe().then(function (liste) {
      if (liste.some(function (a) { return a.gruppe === gruppe && a.label.toLowerCase() === bez.toLowerCase(); })) return { ok: false, fehler: { bezeichnung: 'Diese Art gibt es in dieser Gruppe schon.' } };
      return self.mitVerlaufAnlegen('kostenarten', 'kostenart', 'kart', { bezeichnung: bez, gruppe: gruppe, ausgeblendet: 'nein' });
    });
  };

  /* Eine Art ausblenden oder wieder einblenden (eingebaut oder eigen). */
  Daten.prototype.kostenartAusblenden = function (wert, ausblenden) {
    var self = this;
    var eingebaut = MM.Kosten.KOSTENARTEN.some(function (a) { return a.wert === wert; });
    if (eingebaut) {
      return this.speicher.holen('einstellungen', 'kostenarten').then(function (e) {
        var l = ((e && e.ausgeblendet) || []).filter(function (x) { return x !== wert; });
        if (ausblenden) l.push(wert);
        return self.speicher.speichern('einstellungen', { id: 'kostenarten', ausgeblendet: l }).then(function () { return { ok: true }; });
      });
    }
    return this.mitVerlaufLaden('kostenarten', wert, KOSTENART_FELDER).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      return self.mitVerlaufAendern('kostenart', wert, x, Object.assign({}, x.aktuell.werte, { ausgeblendet: ausblenden ? 'ja' : 'nein' }), KOSTENART_FELDER);
    });
  };

  Daten.prototype.zahlungsmittelListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('zahlungsmittel'), this.speicher.alle('verlaeufe')]).then(function (r) {
      var liste = [{ wert: MM.Reisekasse.BAR, label: 'Bar', eigen: false, ausgeblendet: false }];
      sammle(self, r[0], r[1], 'zahlungsmittel').forEach(function (x) {
        liste.push({ wert: x.objekt.id, label: x.aktuell.werte.bezeichnung, eigen: true, ausgeblendet: x.aktuell.werte.ausgeblendet === 'ja' });
      });
      return liste;
    });
  };

  Daten.prototype.zahlungsmittelAnlegen = function (bezeichnung) {
    var self = this, bez = trimmed2(bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte eine Bezeichnung eingeben, zum Beispiel „Kreditkarte“. Keine Karten- oder Kontonummern.' } });
    if (bez.length > 40) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte höchstens 40 Zeichen.' } });
    return this.zahlungsmittelListe().then(function (liste) {
      if (liste.some(function (z) { return z.label.toLowerCase() === bez.toLowerCase(); })) return { ok: false, fehler: { bezeichnung: 'Dieses Zahlungsmittel gibt es schon.' } };
      return self.mitVerlaufAnlegen('zahlungsmittel', 'zahlungsmittel', 'zm', { bezeichnung: bez, ausgeblendet: 'nein' });
    });
  };

  Daten.prototype.zahlungsmittelAusblenden = function (id, ausblenden) {
    var self = this;
    if (id === MM.Reisekasse.BAR) return Promise.resolve({ ok: false, fehler: { allgemein: '„Bar“ gehört zur Kasse und bleibt immer da.' } });
    return this.mitVerlaufLaden('zahlungsmittel', id, KOSTENART_FELDER).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieses Zahlungsmittel wurde nicht gefunden.' } };
      return self.mitVerlaufAendern('zahlungsmittel', id, x, Object.assign({}, x.aktuell.werte, { ausgeblendet: ausblenden ? 'ja' : 'nein' }), KOSTENART_FELDER);
    });
  };

  /*
   * Prüft einen Posten ganz: Gruppe, Betrag, offene Arten (auch eine neue Art mitten im Formular), Zahlungsmittel (auch ein neues),
   * Währung und Kurs. alt = der bisherige Stand beim Ändern. ctx = gemeinsamer Merker mehrerer Zeilen (neue Arten nur einmal anlegen).
   * Gibt { ok: false, fehler } oder { ok: true, werte, schreiben } (schreiben: nur neue Arten und Zahlungsmittel, für mehrereSpeichern).
   */
  function kostenVollstaendig(self, roh, gruppe, alt, ctx) {
    ctx = ctx || { arten: {}, zm: {} };
    roh = Object.assign({}, roh || {});
    return Promise.all([self.kostenartenListe(), self.zahlungsmittelListe()]).then(function (r) {
      var arten = r[0].map(function (a) { return { wert: a.wert, label: a.label, gruppe: a.gruppe }; }), zms = r[1];
      var g = MM.Kosten.istGruppe(gruppe) ? gruppe : null, jetzt = self.jetzt(), schreiben = [], f0 = {};

      var neueArt = trimmed2(roh.neueKostenart);
      if (neueArt && g) {
        var gl = arten.filter(function (a) { return a.gruppe === g && a.label.toLowerCase() === neueArt.toLowerCase(); })[0];
        if (gl) roh.kostenart = gl.wert;
        else if (neueArt.length > 60) f0.neueKostenart = 'Bitte höchstens 60 Zeichen.';
        else {
          var k1 = g + '|' + neueArt.toLowerCase();
          if (!ctx.arten[k1]) {
            ctx.arten[k1] = neueId('kart');
            schreiben.push({ tabelle: 'kostenarten', objekt: { id: ctx.arten[k1], datenraumId: self.datenraumId, erstelltAm: jetzt } },
              { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kostenart', ctx.arten[k1], 1, { bezeichnung: neueArt, gruppe: g, ausgeblendet: 'nein' }, null, jetzt) });
          }
          roh.kostenart = ctx.arten[k1];
          arten.push({ wert: ctx.arten[k1], label: neueArt, gruppe: g });
        }
      }
      var p = self.pruefenKosten(roh, g, arten);
      var f = Object.assign({}, p.fehler, f0), w = p.werte;
      if (!g) return { ok: false, fehler: f };

      var zid = trimmed2(roh.bezahltMit), neuZm = trimmed2(roh.neuesZahlungsmittel);
      if (neuZm) {
        var gz = zms.filter(function (z) { return z.label.toLowerCase() === neuZm.toLowerCase(); })[0];
        if (gz) zid = gz.wert;
        else if (neuZm.length > 40) f.neuesZahlungsmittel = 'Bitte höchstens 40 Zeichen.';
        else {
          var k2 = neuZm.toLowerCase();
          if (!ctx.zm[k2]) {
            ctx.zm[k2] = neueId('zm');
            schreiben.push({ tabelle: 'zahlungsmittel', objekt: { id: ctx.zm[k2], datenraumId: self.datenraumId, erstelltAm: jetzt } },
              { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('zahlungsmittel', ctx.zm[k2], 1, { bezeichnung: neuZm, ausgeblendet: 'nein' }, null, jetzt) });
          }
          zid = ctx.zm[k2];
          zms.push({ wert: zid, label: neuZm });
        }
      }
      if (zid && !zms.some(function (z) { return z.wert === zid; })) f.bezahltMit = 'Dieses Zahlungsmittel gibt es nicht.';
      w.bezahltMit = zid || null;
      if (Object.keys(f).length) return { ok: false, fehler: f };

      var code = w.waehrung || 'EUR';
      return (w.aktivitaetId ? self.kasseInfo(w.aktivitaetId, code) : Promise.resolve(null)).then(function (ki) {
        if (w.bezahltMit === MM.Reisekasse.BAR && w.aktivitaetId && w.waehrung && !(ki && ki.vorhanden)) {
          return { ok: false, fehler: { bezahltMit: 'Für ' + code + ' gibt es in dieser Aktivität noch keine Kasse. Lege sie zuerst mit dem Anfangsbestand an.' } };
        }
        if (w.waehrung && (w.betrag === null || w.betrag === undefined)) {
          if (alt && alt.waehrung === w.waehrung && Number(alt.betragWaehrung) === w.betragWaehrung && Number(alt.betrag) > 0) {
            w.betrag = alt.betrag; w.grundlage = alt.grundlage || 'gerechnet';
          } else {
            var e = MM.Reisekasse.euroAus(w.betragWaehrung, ki && ki.rechnung ? ki.rechnung.kurs : null);
            if (e === null) return { ok: false, fehler: { betrag: 'Bitte den Betrag in Euro eingeben. Die App kennt noch keinen Kurs für ' + code + ': Er entsteht aus dem Anfangsbestand oder einer Einzahlung der Kasse.' } };
            w.betrag = e; w.grundlage = 'gerechnet';
          }
        }
        return { ok: true, werte: w, schreiben: schreiben };
      });
    });
  }

  /* ---------- Kassen der Reisekasse (seit 2.0.29) ---------- */
  /*
   * Eine Kasse gehört zu einer Aktivität und einer Währung (Tabelle „kassen“, Kennung aus beidem). Ihre Bewegungen stehen in
   * „kassenbuchungen“ (mit Verlauf): Anfangsbestand, Einzahlung (Umbuchung, keine Ausgabe) und Differenz (Kassensturz).
   * Die Ausgaben sind keine eigenen Einträge: Es sind die Posten der Kosten-Liste, die „Bar“ bezahlt wurden. Der Stand wird daraus
   * gerechnet (MM.Reisekasse.rechnen), nie gespeichert. So gibt es nur eine Quelle für jeden Betrag.
   */
  var KASSEN_FELDER = KOSTENART_FELDER;

  function kassenbuchungenSammeln(self, objekte, verlaeufe) {
    var ver = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === 'kassenbuchung') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
    return objekte.filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
      var l = (ver[o.id] || []).slice().sort(nachNr), a = l[l.length - 1];
      return a ? { objekt: o, aktuell: a } : null;
    }).filter(Boolean).sort(function (x, y) {
      var a = (x.aktuell.werte.datum || '') + x.objekt.erstelltAm, b = (y.aktuell.werte.datum || '') + y.objekt.erstelltAm;
      return a < b ? -1 : (a > b ? 1 : 0);
    });
  }

  function kasseRechnung(code, kasseIdent, buchungen, kosten, aktivitaetId) {
    var bu = buchungen.filter(function (b) { return b.objekt.kasseId === kasseIdent; });
    var aus = kosten.filter(function (k) {
      var w = k.aktuell.werte;
      return w.aktivitaetId === aktivitaetId && w.bezahltMit === MM.Reisekasse.BAR && (w.waehrung || 'EUR') === code;
    });
    return { buchungen: bu, ausgaben: aus, rechnung: MM.Reisekasse.rechnen({ waehrung: code,
      buchungen: bu.map(function (b) { return { werte: b.aktuell.werte }; }), ausgaben: aus.map(function (k) { return { werte: k.aktuell.werte }; }) }) };
  }

  function kassenDaten(self, aktivitaetId) {
    return Promise.all([self.speicher.wo('kassen', 'aktivitaetId', aktivitaetId), self.speicher.wo('kassenbuchungen', 'aktivitaetId', aktivitaetId),
      self.speicher.alle('verlaeufe'), kostenAlleSammeln(self)]).then(function (r) {
      return { kassen: r[0].filter(function (k) { return k.datenraumId === self.datenraumId; }), buchungen: kassenbuchungenSammeln(self, r[1], r[2]), kosten: r[3] };
    });
  }

  /* Eine Kasse (Aktivität und Währung): { vorhanden, kasse, waehrung, buchungen, ausgaben, rechnung }. Auch ohne angelegte Kasse (vorhanden false). */
  Daten.prototype.kasseInfo = function (aktivitaetId, waehrung) {
    var self = this, code = waehrung || 'EUR', id = MM.Reisekasse.kasseId(aktivitaetId, code);
    return kassenDaten(this, aktivitaetId).then(function (d) {
      var kasse = d.kassen.filter(function (k) { return k.id === id; })[0] || null;
      var x = kasseRechnung(code, id, d.buchungen, d.kosten, aktivitaetId);
      return { vorhanden: !!kasse, kasse: kasse, waehrung: code, buchungen: x.buchungen, ausgaben: x.ausgaben, rechnung: x.rechnung };
    });
  };

  /* Alle Kassen einer Aktivität, Euro zuerst. */
  Daten.prototype.kassenListe = function (aktivitaetId) {
    return kassenDaten(this, aktivitaetId).then(function (d) {
      return d.kassen.map(function (k) {
        var x = kasseRechnung(k.waehrung, k.id, d.buchungen, d.kosten, aktivitaetId);
        return { kasse: k, waehrung: k.waehrung, buchungen: x.buchungen, ausgaben: x.ausgaben, rechnung: x.rechnung };
      }).sort(function (a, b) { return a.waehrung === 'EUR' ? -1 : (b.waehrung === 'EUR' ? 1 : a.waehrung.localeCompare(b.waehrung)); });
    });
  };

  function kasseKontext(self, aktivitaetId) {
    return self.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (a.aktuell.werte.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      return { aktivitaet: a };
    });
  }

  /* Anfangsbestand oder Einzahlung. roh: art ('anfang' | 'einzahlung'), waehrung (ohne Angabe EUR), betrag, euro (bei Fremdwährung Pflicht), datum, notiz. */
  Daten.prototype.kasseBuchen = function (aktivitaetId, roh) {
    var self = this;
    roh = roh || {};
    var art = trimmed2(roh.art), code = MM.Reisekasse.waehrungNormal(trimmed2(roh.waehrung) || 'EUR'), f = {};
    if (art !== 'anfang' && art !== 'einzahlung') f.art = 'Bitte wählen: Anfangsbestand oder Einzahlung.';
    if (!code) f.waehrung = 'Bitte ein Währungskürzel mit drei Buchstaben eingeben, zum Beispiel NOK.';
    var p = pruefeWerte(MM.Reisekasse.buchungsFelder(art || 'anfang', code || 'EUR'), Object.assign({}, roh, { betrag: geldRoh(roh.betrag), euro: geldRoh(roh.euro) }), jahrVon(this), { ohneBezeichnung: true });
    Object.keys(p.fehler).forEach(function (k) { f[k] = p.fehler[k]; });
    var w = p.werte;
    if (!f.betrag) { if (!(w.betrag > 0)) f.betrag = 'Bitte einen Betrag größer als 0 eingeben.'; else if (w.betrag > 1000000000) f.betrag = 'Der Betrag ist zu groß.'; }
    if (code && code !== 'EUR') {
      if (!f.euro) { if (!(w.euro > 0)) f.euro = 'Bitte eingeben, wie viel Euro du dafür bezahlt hast. Daraus rechnet die App den Kurs.'; }
    }
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return kasseKontext(this, aktivitaetId).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      return self.kasseInfo(aktivitaetId, code).then(function (ki) {
        if (art === 'anfang' && ki.buchungen.some(function (b) { return b.aktuell.werte.art === 'anfang' && b.aktuell.werte.ausgeblendet !== 'ja'; })) {
          return { ok: false, fehler: { art: 'Der Anfangsbestand ist schon eingetragen. Geld, das du dazu holst, trägst du als Einzahlung ein.' } };
        }
        var jetzt = self.jetzt(), id = MM.Reisekasse.kasseId(aktivitaetId, code), liste = [];
        if (!ki.vorhanden) liste.push({ tabelle: 'kassen', objekt: { id: id, datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, fahrzeugId: k.aktivitaet.fahrzeug.id, waehrung: code, erstelltAm: jetzt } });
        var b = { id: neueId('kb'), datenraumId: self.datenraumId, kasseId: id, aktivitaetId: aktivitaetId, erstelltAm: jetzt };
        var werte = { art: art, betrag: MM.Reisekasse.runde(w.betrag), euro: code === 'EUR' ? null : MM.Reisekasse.runde(w.euro), waehrung: code,
          datum: w.datum || self.heute(), notiz: w.notiz || null, ausgeblendet: 'nein' };
        liste.push({ tabelle: 'kassenbuchungen', objekt: b }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kassenbuchung', b.id, 1, werte, null, jetzt) });
        return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: b.id, kasseId: id }; });
      });
    });
  };

  /* Kassensturz: roh.ist = was wirklich im Portemonnaie liegt. Weicht es vom Stand ab, speichert die App die Differenz als eigenen Eintrag. */
  Daten.prototype.kassensturz = function (aktivitaetId, roh) {
    var self = this;
    roh = roh || {};
    var code = MM.Reisekasse.waehrungNormal(trimmed2(roh.waehrung) || 'EUR');
    if (!code) return Promise.resolve({ ok: false, fehler: { waehrung: 'Bitte ein Währungskürzel mit drei Buchstaben eingeben, zum Beispiel NOK.' } });
    var p = pruefeWerte([{ key: 'ist', typ: 'zahl' }, { key: 'datum', typ: 'datum' }, { key: 'notiz', typ: 'text' }], Object.assign({}, roh, { ist: geldRoh(roh.ist) }), jahrVon(this), { ohneBezeichnung: true });
    var f = Object.assign({}, p.fehler);
    if (!f.ist && p.werte.ist === null) f.ist = 'Bitte eingeben, wie viel Geld in der Kasse liegt (auch 0 ist möglich).';
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return kasseKontext(this, aktivitaetId).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      return self.kasseInfo(aktivitaetId, code).then(function (ki) {
        if (!ki.vorhanden) return { ok: false, fehler: { waehrung: 'Für ' + code + ' gibt es noch keine Kasse. Lege sie zuerst mit dem Anfangsbestand an.' } };
        var diff = MM.Reisekasse.kassensturzDifferenz(ki.rechnung, p.werte.ist);
        if (diff === 0) return { ok: true, differenz: 0, geaendert: false, stand: ki.rechnung.stand };
        var jetzt = self.jetzt(), b = { id: neueId('kb'), datenraumId: self.datenraumId, kasseId: ki.kasse.id, aktivitaetId: aktivitaetId, erstelltAm: jetzt };
        var werte = { art: 'differenz', betrag: diff, euro: null, waehrung: code, datum: p.werte.datum || self.heute(), notiz: p.werte.notiz || null, ausgeblendet: 'nein' };
        return self.speicher.mehrereSpeichern([{ tabelle: 'kassenbuchungen', objekt: b },
          { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kassenbuchung', b.id, 1, werte, null, jetzt) }])
          .then(function () { return { ok: true, id: b.id, differenz: diff, geaendert: true, stand: MM.Reisekasse.runde(p.werte.ist) }; });
      });
    });
  };

  /* Eine Buchung ausblenden (zählt nicht mehr) oder wieder einblenden. Nichts wird gelöscht; eine falsche Buchung blendest du aus und trägst sie neu ein. */
  Daten.prototype.kasseBuchungAusblenden = function (buchungId, ausblenden) {
    var self = this;
    return this.mitVerlaufLaden('kassenbuchungen', buchungId, KASSEN_FELDER).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Diese Buchung wurde nicht gefunden.' } };
      return self.mitVerlaufAendern('kassenbuchung', buchungId, x, Object.assign({}, x.aktuell.werte, { ausgeblendet: ausblenden ? 'ja' : 'nein' }), KASSEN_FELDER);
    });
  };

  /* Eine Ausgabe der Reisekasse: wie kostenAnlegen, aber mit der Aktivität statt des Fahrzeugs. */
  Daten.prototype.reiseAusgabeAnlegen = function (aktivitaetId, roh) {
    var self = this;
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      return self.kostenAnlegen(a.fahrzeug.id, Object.assign({}, roh || {}, { gruppe: 'reisekasse', aktivitaetId: aktivitaetId }));
    });
  };

  /* ---------- Kostenstammdaten eines Fahrzeugs: Wert, Wertverlust, Vergleichspreis ---------- */
  function kostenstammId(fahrzeugId) { return 'ks-' + fahrzeugId; }

  Daten.prototype.kostenstammLaden = function (fahrzeugId) {
    return this.mitVerlaufLaden('kostenstamm', kostenstammId(fahrzeugId), MM.Kosten.stammFelder());
  };

  Daten.prototype.pruefenKostenstamm = function (roh) {
    roh = Object.assign({}, roh || {});
    roh.fahrzeugwert = geldRoh(roh.fahrzeugwert); roh.vergleichPreisTag = geldRoh(roh.vergleichPreisTag);
    var p = pruefeWerte(MM.Kosten.stammFelder(), roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler, heute = this.heute();
    if (w.fahrzeugwert !== null && !f.fahrzeugwert) {
      if (!(w.fahrzeugwert > 0)) f.fahrzeugwert = 'Der Wert muss größer als 0 sein.';
      else if (w.fahrzeugwert > 1000000000) f.fahrzeugwert = 'Der Wert ist zu groß.';
      else w.fahrzeugwert = MM.Kosten.runde(w.fahrzeugwert);
    }
    if (w.fahrzeugwert && !w.wertDatum && !f.wertDatum) w.wertDatum = heute;
    if (w.wertDatum && w.wertDatum > heute && !f.wertDatum) f.wertDatum = 'Das Datum liegt in der Zukunft.';
    if (w.wertverlustProzent !== null && !f.wertverlustProzent && !w.fahrzeugwert && !f.fahrzeugwert) f.fahrzeugwert = 'Für einen Wertverlust braucht die App den Wert des Fahrzeugs.';
    if (w.vergleichPreisTag !== null && !f.vergleichPreisTag) {
      if (!(w.vergleichPreisTag > 0)) f.vergleichPreisTag = 'Der Preis muss größer als 0 sein.';
      else if (w.vergleichPreisTag > 1000000) f.vergleichPreisTag = 'Der Preis ist zu groß.';
      else w.vergleichPreisTag = MM.Kosten.runde(w.vergleichPreisTag);
    }
    if (w.vergleichPreisTag === null) { w.vergleichGrundlage = null; }
    else if (!w.vergleichGrundlage && !f.vergleichGrundlage) w.vergleichGrundlage = 'geschaetzt';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.kostenstammSetzen = function (fahrzeugId, roh) {
    var self = this;
    var p = this.pruefenKostenstamm(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.pruefeObjekt(fahrzeugId, null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return self.kostenstammLaden(fahrzeugId).then(function (x) {
        if (x) return self.mitVerlaufAendern('kostenstamm', kostenstammId(fahrzeugId), x, p.werte, MM.Kosten.stammFelder());
        var jetzt = self.jetzt();
        var o = { id: kostenstammId(fahrzeugId), datenraumId: self.datenraumId, fahrzeugId: fahrzeugId, erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'kostenstamm', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kostenstamm', o.id, 1, p.werte, null, jetzt) }
        ]).then(function () { return { ok: true, id: o.id, geaendert: true }; });
      });
    });
  };

  /* „Der Wert stimmt noch“: der Stand des Werts wird auf heute gesetzt, der Wert bleibt. */
  Daten.prototype.kostenstammWertBestaetigen = function (fahrzeugId) {
    var self = this;
    return this.kostenstammLaden(fahrzeugId).then(function (x) {
      if (!x || !(Number(x.aktuell.werte.fahrzeugwert) > 0)) return { ok: false, fehler: { allgemein: 'Es ist noch kein Wert eingetragen.' } };
      var w = Object.assign({}, x.aktuell.werte, { wertDatum: self.heute() });
      return self.mitVerlaufAendern('kostenstamm', kostenstammId(fahrzeugId), x, w, MM.Kosten.stammFelder());
    });
  };

  /* ---------- Kosten: Auswertung ---------- */
  function jahrGueltig(jahr, standard) {
    var j = Number(jahr);
    return isFinite(j) && Math.floor(j) === j && j >= 1900 && j <= 2200 ? j : standard;
  }

  /*
   * Die Auswertung eines Fahrzeugs für ein Jahr (ohne Angabe: dieses Jahr). Rechnung steht in MM.Kosten.auswertung.
   * Dazu die Posten, nach Gruppen geordnet: posten.<gruppe> = die Posten, die im Jahr etwas zählen (mit imJahr),
   * andere = sichtbare Posten ohne Anteil in diesem Jahr, ausgeblendet = ausgeblendete Posten.
   */
  Daten.prototype.kostenAuswertung = function (fahrzeugId, jahr) {
    var self = this;
    var heute = this.heute();
    var j = jahrGueltig(jahr, +heute.slice(0, 4));
    return Promise.all([this.fahrzeugLaden(fahrzeugId), this.kostenListe(fahrzeugId), this.kostenstammLaden(fahrzeugId),
      this.aktivitaetenListe(), this.zaehlerListe(fahrzeugId), this.speicher.alle('zaehlerstaende')]).then(function (r) {
      if (!r[0]) return null;
      var liste = r[1], stamm = r[2];
      var sichtbar = liste.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; });
      var aktivitaeten = r[3].filter(function (a) { return a.aktuell.werte.fahrzeugId === fahrzeugId && a.status !== 'storniert'; })
        .map(function (a) { return { vonDatum: a.aktuell.werte.vonDatum, bisDatum: a.aktuell.werte.bisDatum }; });
      var km = r[4].filter(function (z) { return z.art === 'strecke' && !z.komponenteId; });
      var zaehler = km.length ? km[0] : null;
      var staende = zaehler ? r[5].filter(function (s) { return s.zaehlerId === zaehler.zaehler.id; }).map(function (s) { return { datum: s.datum, wert: s.wert }; }) : [];
      var a = MM.Kosten.auswertung({ jahr: j, heute: heute, eintraege: sichtbar.map(function (x) { return { werte: x.aktuell.werte }; }),
        stamm: stamm ? stamm.aktuell.werte : null, aktivitaeten: aktivitaeten, staende: staende });
      var posten = { fix: [], variabel: [], instandhaltung: [] }, andere = [];
      sichtbar.forEach(function (x) {
        if (x.aktuell.werte.gruppe === 'reisekasse') return; /* die Reisekasse gehört zur Aktivität, nicht zu den Fahrzeugkosten */
        var y = Object.assign({}, x, { imJahr: MM.Kosten.imJahr(x.aktuell.werte, j, heute) });
        if (y.imJahr.summe > 0 && posten[x.aktuell.werte.gruppe]) posten[x.aktuell.werte.gruppe].push(y); else andere.push(y);
      });
      a.ok = true;
      a.fahrzeug = r[0].fahrzeug; a.fahrzeugAktuell = r[0].aktuell;
      a.stamm = stamm; a.posten = posten; a.andere = andere;
      a.ausgeblendet = liste.filter(function (x) { return x.aktuell.werte.ausgeblendet === 'ja' && x.aktuell.werte.gruppe !== 'reisekasse'; });
      a.kmZaehler = zaehler ? zaehler.bezeichnung : null;
      a.heute = heute;
      return a;
    });
  };

  /* Pro Fahrzeug die Auswertung des Jahres, für die Kostenstartseite. */
  Daten.prototype.kostenUebersicht = function (jahr) {
    var self = this;
    return this.fahrzeugListe({ alle: true }).then(function (liste) {
      return Promise.all(liste.map(function (x) { return self.kostenAuswertung(x.fahrzeug.id, jahr); })).then(function (alle) {
        return liste.map(function (x, i) { return { fahrzeug: x.fahrzeug, aktuell: x.aktuell, auswertung: alle[i] }; });
      });
    });
  };

  /* ---------- Besuche und Reiseorte (seit 2.0.28) ---------- */
  /*
   * Ein Besuch ist die Antwort auf die freiwillige Abfrage nach einer Ankunft (oder von Hand nachgetragen). Tabelle „besuche“
   * (Index aktivitaetId, ereignisId), Angaben im Verlauf. Das Objekt hält, was sich nie ändert: Aktivität, Fahrzeug, Ereignis.
   * Ort, Standort, Datum, Ausstattung beim Besuch und Notiz stehen im Verlauf. Status „besucht“ zählt, „uebersprungen“ heißt:
   * Der Nutzer wollte nichts festhalten, die Frage kommt für dieses Ereignis nicht wieder.
   * Die Kosten eines Besuchs stehen nur in der Kosten-Liste (variable Kosten mit ortId, aktivitaetId und besuchId).
   * Die Ausstattung gehört zum Ort (die eine Quelle). Der Besuch hält nur, was beim Besuch gesagt wurde.
   * Hier und in js/reiseorte.js steht, was später teilbar wäre (Ort, Art, Position, Ausstattung): Nichts wird veröffentlicht. */
  function planAus(w) {
    return { startOrtId: (w && w.startOrtId) || null, zielOrtId: (w && w.zielOrtId) || null, zwischenzielIds: (w && w.zwischenzielIds) || [] };
  }

  /* Alle Posten der Kosten-Liste mit aktuellem Stand (alle Fahrzeuge). */
  function kostenAlleSammeln(self) {
    return Promise.all([self.speicher.alle('kosten'), self.speicher.alle('verlaeufe')]).then(function (r) {
      var ver = {};
      r[1].forEach(function (e) { if (e.objektTyp === 'kosten') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      return r[0].filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
        var l = (ver[o.id] || []).slice().sort(nachNr), a = l[l.length - 1];
        return a ? { objekt: o, aktuell: a } : null;
      }).filter(Boolean);
    });
  }

  /* Alle Besuche mit aktuellem Stand, nach Aktivität gefiltert, wenn eine genannt ist. */
  function besucheAlleSammeln(self, aktivitaetId) {
    var quelle = aktivitaetId ? self.speicher.wo('besuche', 'aktivitaetId', aktivitaetId) : self.speicher.alle('besuche');
    return Promise.all([quelle, self.speicher.alle('verlaeufe')]).then(function (r) {
      var ver = {};
      r[1].forEach(function (e) { if (e.objektTyp === 'besuch') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      return r[0].filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
        var l = (ver[o.id] || []).slice().sort(nachNr), a = l[l.length - 1];
        return a ? { objekt: o, aktuell: a } : null;
      }).filter(Boolean);
    });
  }

  function besuchSchluessel(x) { var w = x.aktuell.werte; return (w.datum || '') + 'T' + (w.zeit || '00:00'); }

  /* Ein Ereignis in Kurzform: { id, aktivitaetId, artName, datum, zeit, breite, laenge, ortName, ausgeblendet } oder null. */
  Daten.prototype.ereignisKurz = function (ereignisId) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('ereignisse', ereignisId, []), this.ereignisartenListe()]).then(function (r) {
      var x = r[0];
      if (!x || x.objekt.datenraumId !== self.datenraumId) return null;
      var w = x.aktuell.werte, art = r[1].filter(function (a) { return a.objekt.id === w.artId; })[0];
      return { id: x.objekt.id, aktivitaetId: x.objekt.aktivitaetId, artName: art ? art.aktuell.werte.bezeichnung : 'unbekannt', datum: w.datum || null, zeit: w.zeit || null,
        breite: typeof w.breite === 'number' ? w.breite : null, laenge: typeof w.laenge === 'number' ? w.laenge : null, ortName: w.ortName || null, ausgeblendet: w.ausgeblendet === 'ja' };
    });
  };

  /*
   * Alles, was das Formular und die Prüfung brauchen: die Aktivität, ihr Plan, das Ereignis (mit Position), die Orte und
   * Standorte, ein Vorschlag aus der Position und der zuletzt bezahlte Preis je Ort.
   * Ergebnis: { ok, aktivitaet, plan, ereignis, orte, standorte, vorschlag, preise, besuchVorhanden }
   */
  Daten.prototype.besuchKontext = function (aktivitaetId, ereignisId) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.orteListe(), this.standorteListe(),
      ereignisId ? this.ereignisKurz(ereignisId) : Promise.resolve(null), this.speicher.wo('besuche', 'aktivitaetId', aktivitaetId), kostenAlleSammeln(this)]).then(function (r) {
      var a = r[0], e = r[3];
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (ereignisId && (!e || e.aktivitaetId !== aktivitaetId)) return { ok: false, fehler: { allgemein: 'Dieses Ereignis gehört nicht zu dieser Aktivität.' } };
      var vorhanden = ereignisId ? r[4].filter(function (b) { return b.ereignisId === ereignisId; })[0] : null;
      var preise = {};
      r[5].filter(function (k) { return k.aktuell.werte.ortId && k.aktuell.werte.ausgeblendet !== 'ja' && Number(k.aktuell.werte.betrag) > 0; })
        .sort(function (x, y) { return (x.aktuell.werte.datum || '') < (y.aktuell.werte.datum || '') ? -1 : 1; })
        .forEach(function (k) { preise[k.aktuell.werte.ortId] = { betrag: Number(k.aktuell.werte.betrag), datum: k.aktuell.werte.datum || null, grundlage: k.aktuell.werte.grundlage || 'eingegeben' }; });
      return { ok: true, aktivitaet: a, plan: planAus(a.aktuell.werte), ereignis: e, orte: r[1], standorte: r[2], preise: preise,
        vorschlag: e ? MM.Reiseorte.naechster(MM.Reiseorte.kandidaten(r[1], r[2]), e.breite, e.laenge) : null, besuchVorhanden: vorhanden ? vorhanden.id : null };
    });
  };

  /* Prüft die Angaben zu einem Besuch (ohne Ort und Kosten). Ohne Angabe bleibt ein Feld leer. */
  Daten.prototype.pruefenBesuch = function (roh) {
    roh = roh || {};
    var felder = [
      { key: 'datum', typ: 'datum' }, { key: 'zeit', typ: 'zeit' },
      { key: 'ausstattung', typ: 'mehrfach', optionen: MM.Orte.AUSSTATTUNG },
      { key: 'ausstattungSonst', typ: 'text', maxLaenge: 200 },
      { key: 'notiz', typ: 'text' }
    ];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    if (p.werte.datum && p.werte.datum > this.heute() && !p.fehler.datum) { p.fehler.datum = 'Ein Besuch liegt nicht in der Zukunft.'; p.ok = false; }
    return p;
  };

  /*
   * Einen Besuch festhalten. roh:
   *   ereignisId (freiwillig: das Ereignis der Ankunft), datum, zeit (ohne Angabe die des Ereignisses, sonst heute),
   *   ortId (vorhandener Ort) ODER neuerOrtName (mit neuerOrtArt, positionBreite, positionLaenge, sonst die Position des Ereignisses),
   *   standortId (freiwillig, nur bei vorhandenem Ort), ausstattung (Liste) und ausstattungSonst (werden auch am Ort gemerkt),
   *   notiz, betrag (freiwillig, dann entsteht ein variabler Posten), kostenart, grundlage, kostenBezeichnung.
   * Alles wird in einem Zug gespeichert, ganz oder gar nicht: neuer Ort, Besuch, Ausstattung am Ort, Posten.
   * Kennt der Ort noch keine Position und das Ereignis hat eine, bekommt der Ort sie.
   */
  Daten.prototype.besuchAnlegen = function (aktivitaetId, roh) {
    var self = this;
    roh = roh || {};
    var ereignisId = trimmed2(roh.ereignisId) || null;
    return this.besuchKontext(aktivitaetId, ereignisId).then(function (k) {
      if (!k.ok) return k;
      var a = k.aktivitaet;
      if (a.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      if (k.besuchVorhanden) return { ok: false, fehler: { allgemein: 'Zu dieser Ankunft gibt es schon einen Besuch.' } };
      var e = k.ereignis;
      var eingabe = Object.assign({}, roh);
      if (!trimmed2(eingabe.datum)) eingabe.datum = e && e.datum ? e.datum : self.heute();
      if (!trimmed2(eingabe.zeit) && e && e.zeit) eingabe.zeit = e.zeit;
      var p = self.pruefenBesuch(eingabe), w = p.werte, f = p.fehler;

      /* Ort */
      var ortId = trimmed2(roh.ortId), neuerName = trimmed2(roh.neuerOrtName), ort = null, neuerOrt = null;
      if (ortId) {
        ort = k.orte.filter(function (o) { return o.objekt.id === ortId; })[0] || null;
        if (!ort) f.ortId = 'Diesen Ort gibt es nicht.';
      } else if (neuerName) {
        var po = self.pruefenOrt({ bezeichnung: neuerName, ortart: roh.neuerOrtArt,
          positionBreite: roh.positionBreite !== undefined ? roh.positionBreite : (e ? e.breite : null),
          positionLaenge: roh.positionLaenge !== undefined ? roh.positionLaenge : (e ? e.laenge : null),
          ausstattung: Array.isArray(roh.ausstattung) ? roh.ausstattung : [], ausstattungSonst: roh.ausstattungSonst });
        var abbild = { bezeichnung: 'neuerOrtName', ortart: 'neuerOrtArt' };
        Object.keys(po.fehler).forEach(function (key) { f[abbild[key] || key] = po.fehler[key]; });
        if (gleicherName(k.orte, neuerName)) f.neuerOrtName = 'Diesen Ort gibt es schon. Wähle ihn oben aus der Liste.';
        if (!f.neuerOrtName || !Object.keys(po.fehler).length) neuerOrt = { id: neueId('or'), werte: po.werte };
      } else f.ortId = 'Bitte einen Ort wählen oder einen neuen Namen eingeben.';

      /* Standort */
      var standortId = trimmed2(roh.standortId) || null;
      if (standortId) {
        if (!ort) f.standortId = 'Ein Standort gehört zu einem schon vorhandenen Ort.';
        else if (!k.standorte.some(function (s) { return s.objekt.id === standortId && s.objekt.ortId === ort.objekt.id; })) f.standortId = 'Diesen Standort gibt es an diesem Ort nicht.';
      }

      /* Kosten: mehrere Zeilen je Besuch (seit 2.0.29, roh.zeilen: Art, Betrag) oder wie bisher ein Betrag. Jede Zeile wird ein eigener Posten. */
      var ortName = ort ? ort.aktuell.werte.bezeichnung : neuerName;
      var zz = besuchZeilen(roh, ortName), ctx = { arten: {}, zm: {} }, ergebnisse = [];
      var kette = zz.zeilen.reduce(function (kk, z) {
        return kk.then(function () {
          return kostenVollstaendig(self, Object.assign({}, z.roh, { datum: w.datum, aktivitaetId: aktivitaetId, grundlage: roh.grundlage, bezahltMit: roh.bezahltMit,
            neuesZahlungsmittel: roh.neuesZahlungsmittel, waehrung: roh.waehrung,
            betrag: MM.Reisekasse.waehrungNormal(roh.waehrung) && MM.Reisekasse.waehrungNormal(roh.waehrung) !== 'EUR' ? '' : z.roh.betrag,
            betragWaehrung: z.roh.betrag }), 'variabel', null, ctx).then(function (e) { ergebnisse.push(e); });
        });
      }, Promise.resolve());
      return kette.then(function () {
        ergebnisse.forEach(function (e, i) {
          if (e.ok) return;
          Object.keys(e.fehler).forEach(function (key) {
            if (key === 'bezahltMit' || key === 'waehrung' || key === 'neuesZahlungsmittel') { f[key] = e.fehler[key]; return; }
            if (!zz.neu) { f[key === 'bezeichnung' ? 'kostenBezeichnung' : key] = e.fehler[key]; return; }
            if (!f.zeilen) f.zeilen = 'Zeile ' + zz.zeilen[i].nr + ': ' + e.fehler[key];
          });
        });
        if (Object.keys(f).length) return { ok: false, fehler: f };

        var jetzt = self.jetzt(), fahrzeugId = a.fahrzeug.id;
        var endOrtId = ort ? ort.objekt.id : neuerOrt.id;
        var sendetAusstattung = Array.isArray(roh.ausstattung), sendetSonst = roh.ausstattungSonst !== undefined;
        var ausstattung = sendetAusstattung ? w.ausstattung : (ort ? (ort.aktuell.werte.ausstattung || []) : []);
        var sonst = sendetSonst ? w.ausstattungSonst : (ort ? (ort.aktuell.werte.ausstattungSonst || null) : null);
        var geplant = MM.Reiseorte.planVergleich(k.plan, endOrtId);
        var batch = [];

        if (neuerOrt) {
          batch.push({ tabelle: 'orte', objekt: { id: neuerOrt.id, datenraumId: self.datenraumId, erstelltAm: jetzt } },
            { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ort', neuerOrt.id, 1, neuerOrt.werte, null, jetzt) });
        } else {
          /* Die Angaben des Besuchs gelten auch am Ort (er ist die eine Quelle), und ein Ort ohne Position bekommt die der Ankunft. */
          var alt = ort.aktuell.werte, neu = Object.assign({}, alt, { ausstattung: ausstattung, ausstattungSonst: sonst });
          if (typeof alt.positionBreite !== 'number' && e && typeof e.breite === 'number' && typeof e.laenge === 'number') { neu.positionBreite = e.breite; neu.positionLaenge = e.laenge; }
          if (unterschiedeFelder(ORT_FELDER, alt, neu).length) batch.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ort', ort.objekt.id, ort.aktuell.nr + 1, neu, ort.aktuell.id, jetzt) });
        }

        var besuch = { id: neueId('bs'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, fahrzeugId: fahrzeugId, ereignisId: ereignisId, erstelltAm: jetzt };
        var besuchWerte = { status: 'besucht', ortId: endOrtId, standortId: standortId, datum: w.datum, zeit: w.zeit || null, geplant: geplant,
          ausstattung: ausstattung, ausstattungSonst: sonst, notiz: w.notiz || null, ausgeblendet: 'nein' };
        batch.push({ tabelle: 'besuche', objekt: besuch }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besuch', besuch.id, 1, besuchWerte, null, jetzt) });

        var kostenIds = [];
        ergebnisse.forEach(function (er) {
          er.schreiben.forEach(function (x) { batch.push(x); });
          var kw = er.werte;
          kw.ortId = endOrtId; kw.besuchId = besuch.id; kw.aktivitaetId = aktivitaetId;
          var ko = { id: neueId('ko'), datenraumId: self.datenraumId, fahrzeugId: fahrzeugId, erstelltAm: jetzt };
          kostenIds.push(ko.id);
          batch.push({ tabelle: 'kosten', objekt: ko }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kosten', ko.id, 1, kw, null, jetzt) });
        });
        return self.speicher.mehrereSpeichern(batch).then(function () {
          return { ok: true, id: besuch.id, ortId: endOrtId, kostenId: kostenIds[0] || null, kostenIds: kostenIds, geplant: geplant, neuerOrt: !!neuerOrt };
        });
      });
    });
  };

  /* Die Kostenzeilen eines Besuchs: roh.zeilen (jede mit Betrag, Art oder neuer Art, freiwillig Bezeichnung) oder der eine Betrag von früher. */
  function besuchZeilen(roh, ortName) {
    var out = [];
    if (Array.isArray(roh.zeilen)) {
      roh.zeilen.forEach(function (z, i) {
        z = z || {};
        var b = trimmed2(z.betrag == null ? '' : String(z.betrag)), art = trimmed2(z.kostenart), neu = trimmed2(z.neueKostenart);
        if (!b && !art && !neu) return;
        out.push({ nr: i + 1, roh: { bezeichnung: trimmed2(z.bezeichnung) || ortName, kostenart: art, neueKostenart: neu, betrag: z.betrag } });
      });
      return { zeilen: out, neu: true };
    }
    var b0 = roh.betrag === undefined || roh.betrag === null ? '' : String(roh.betrag).trim();
    if (b0) out.push({ nr: 1, roh: { bezeichnung: trimmed2(roh.kostenBezeichnung) || ortName, kostenart: roh.kostenart || 'unterwegs', betrag: roh.betrag } });
    return { zeilen: out, neu: false };
  }

  /* „Nicht jetzt“: Die Frage zu dieser Ankunft kommt nicht wieder. Es wird nichts festgehalten und nichts gezählt. */
  Daten.prototype.besuchUeberspringen = function (aktivitaetId, ereignisId) {
    var self = this;
    return this.besuchKontext(aktivitaetId, ereignisId).then(function (k) {
      if (!k.ok) return k;
      if (!k.ereignis) return { ok: false, fehler: { allgemein: 'Es fehlt das Ereignis, zu dem die Frage gehört.' } };
      if (k.besuchVorhanden) return { ok: true, id: k.besuchVorhanden, geaendert: false };
      var jetzt = self.jetzt();
      var b = { id: neueId('bs'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, fahrzeugId: k.aktivitaet.fahrzeug.id, ereignisId: ereignisId, erstelltAm: jetzt };
      var w = { status: 'uebersprungen', ortId: null, standortId: null, datum: k.ereignis.datum, zeit: k.ereignis.zeit, geplant: null, ausstattung: [], ausstattungSonst: null, notiz: null, ausgeblendet: 'nein' };
      return self.speicher.mehrereSpeichern([{ tabelle: 'besuche', objekt: b }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besuch', b.id, 1, w, null, jetzt) }])
        .then(function () { return { ok: true, id: b.id, geaendert: true }; });
    });
  };

  /* Ein Besuch mit Verlauf (Orte und Standorte mit Namen), seinem Ort, seiner Aktivität und den Posten, die zu ihm gehören. */
  Daten.prototype.besuchLaden = function (id) {
    var self = this;
    return this.speicher.holen('besuche', id).then(function (o) {
      if (!o || o.datenraumId !== self.datenraumId) return null;
      return Promise.all([self.speicher.wo('verlaeufe', 'objektId', id), self.orteListe(), self.standorteListe(), self.aktivitaetLaden(o.aktivitaetId),
        self.kostenListe(o.fahrzeugId), self.fahrzeugLaden(o.fahrzeugId)]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length) return null;
        var aktuell = eintraege[eintraege.length - 1], w = aktuell.werte;
        var orte = {}; r[1].forEach(function (x) { orte[x.objekt.id] = x; });
        var standorte = {}; r[2].forEach(function (x) { standorte[x.objekt.id] = x; });
        var felder = MM.Reiseorte.besuchFelder().map(function (f) {
          if (f.key === 'ortId') return Object.assign({}, f, { optionen: r[1].map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; }) });
          if (f.key === 'standortId') return Object.assign({}, f, { optionen: r[2].map(function (x) { return { wert: x.objekt.id, label: (orte[x.objekt.ortId] ? orte[x.objekt.ortId].aktuell.werte.bezeichnung + ', ' : '') + x.aktuell.werte.bezeichnung }; }) });
          return f;
        });
        var ort = w.ortId && orte[w.ortId] ? orte[w.ortId] : null, st = w.standortId && standorte[w.standortId] ? standorte[w.standortId] : null;
        return { objekt: o, aktuell: aktuell, verlauf: verlaufAus(eintraege, felder),
          ort: w.ortId ? { id: w.ortId, name: ort ? ort.aktuell.werte.bezeichnung : 'unbekannt', werte: ort ? ort.aktuell.werte : null } : null,
          standort: w.standortId ? { id: w.standortId, name: st ? st.aktuell.werte.bezeichnung : 'unbekannt' } : null,
          aktivitaet: r[3] ? { id: o.aktivitaetId, name: r[3].aktuell.werte.bezeichnung } : { id: o.aktivitaetId, name: 'unbekannt' },
          fahrzeug: r[5] ? { id: r[5].fahrzeug.id, name: r[5].aktuell.werte.bezeichnung } : { id: o.fahrzeugId, name: 'unbekannt' },
          kosten: r[4].filter(function (x) { return x.aktuell.werte.besuchId === id; }),
          geplantText: w.geplant ? MM.Reiseorte.labelVon(MM.Reiseorte.GEPLANT, w.geplant) : null };
      });
    });
  };

  /*
   * Angaben eines Besuchs ändern: Standort, Datum, Uhrzeit, Ausstattung beim Besuch, Notiz. Nur die Angaben, die der Aufruf nennt.
   * Der Ort bleibt (sonst stimmt die Historie des Ortes nicht mehr): Ein falscher Besuch wird ausgeblendet und neu eingetragen.
   * Die Ausstattung beim Besuch ändert nur den Besuch, nicht den Ort. Ausgeblendete Besuche zählen nicht mit, nichts wird gelöscht.
   */
  Daten.prototype.besuchAendern = function (id, roh) {
    var self = this;
    roh = roh || {};
    return Promise.all([this.besuchLaden(id), this.standorteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Besuch wurde nicht gefunden.' } };
      var alt = x.aktuell.werte;
      if (alt.status !== 'besucht') return { ok: false, fehler: { allgemein: 'Zu diesem Besuch wurde nichts festgehalten, es gibt nichts zu ändern.' } };
      var p = self.pruefenBesuch(roh), f = p.fehler;
      function da(k) { return Object.prototype.hasOwnProperty.call(roh, k); }
      if (da('datum') && !trimmed2(roh.datum) && !f.datum) f.datum = 'Bitte das Datum angeben.';
      var standortId = da('standortId') ? (trimmed2(roh.standortId) || null) : alt.standortId;
      if (da('standortId') && standortId && !r[1].some(function (s) { return s.objekt.id === standortId && s.objekt.ortId === alt.ortId; })) f.standortId = 'Diesen Standort gibt es an diesem Ort nicht.';
      if (Object.keys(f).length) return { ok: false, fehler: f };
      var neu = Object.assign({}, alt, { standortId: standortId });
      ['datum', 'zeit', 'ausstattung', 'ausstattungSonst', 'notiz'].forEach(function (k) { if (da(k)) neu[k] = p.werte[k]; });
      if (da('ausgeblendet')) neu.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
      /* Ort, Plan und Status ändert dieser Weg nie. */
      var felder = MM.Reiseorte.besuchFelder();
      if (!unterschiedeFelder(felder, alt, neu).length) return { ok: true, id: id, geaendert: false };
      var e = neuerVerlaufEintrag('besuch', id, x.aktuell.nr + 1, neu, x.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: id, geaendert: true }; });
    });
  };

  Daten.prototype.besuchAusblenden = function (id, ausblenden) { return this.besuchAendern(id, { ausgeblendet: ausblenden ? 'ja' : 'nein' }); };

  /*
   * Besuche mit den Namen von Ort, Standort und Aktivität, neueste zuerst. opt: { ortId, aktivitaetId, mitUebersprungenen }
   * Ohne mitUebersprungenen stehen nur die Besuche mit Status „besucht“ in der Liste (auch ausgeblendete, mit Kennzeichen).
   */
  Daten.prototype.besuchListe = function (opt) {
    opt = opt || {};
    var self = this;
    return Promise.all([besucheAlleSammeln(this, opt.aktivitaetId || null), this.orteListe(), this.standorteListe(), this.aktivitaetenListe()]).then(function (r) {
      var orte = {}, standorte = {}, akt = {};
      r[1].forEach(function (x) { orte[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      r[2].forEach(function (x) { standorte[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      r[3].forEach(function (x) { akt[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      var liste = r[0].filter(function (x) {
        return (opt.mitUebersprungenen || x.aktuell.werte.status === 'besucht') && (!opt.ortId || x.aktuell.werte.ortId === opt.ortId);
      }).map(function (x) {
        var w = x.aktuell.werte;
        return Object.assign({}, x, { ortName: w.ortId ? (orte[w.ortId] || 'unbekannt') : null, standortName: w.standortId ? (standorte[w.standortId] || 'unbekannt') : null,
          aktivitaetName: akt[x.objekt.aktivitaetId] || 'unbekannt' });
      });
      liste.sort(function (a, b) { var ka = besuchSchluessel(a), kb = besuchSchluessel(b); return ka < kb ? 1 : (ka > kb ? -1 : 0); });
      return liste;
    });
  };

  /* Was ein Ort dich gekostet hat und wie oft du dort warst, dazu die Besuche und die Posten. null, wenn es den Ort nicht gibt. */
  Daten.prototype.ortAuswertung = function (ortId) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', ortId, []), this.besuchListe({ ortId: ortId }), kostenAlleSammeln(this)]).then(function (r) {
      if (!r[0] || r[0].objekt.datenraumId !== self.datenraumId) return null;
      var kosten = r[2].filter(function (x) { return x.aktuell.werte.ortId === ortId; })
        .sort(function (a, b) { return (a.aktuell.werte.datum || '') < (b.aktuell.werte.datum || '') ? 1 : -1; });
      var a = MM.Reiseorte.ortAuswertung(r[1].map(function (b) { return { werte: b.aktuell.werte }; }), kosten.map(function (k) { return { werte: k.aktuell.werte }; }));
      a.ok = true; a.besuche = r[1]; a.kosten = kosten;
      return a;
    });
  };

  /* Was hat eine Reise (Aktivität) gekostet, wie gliedert es sich auf, welche Orte waren dabei, was war geplant? null, wenn es die Aktivität nicht gibt. */
  Daten.prototype.reiseAuswertung = function (aktivitaetId, opts) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.orteListe(), besucheAlleSammeln(this, aktivitaetId), kostenAlleSammeln(this)]).then(function (r) {
      var a = r[0];
      if (!a) return null;
      var namen = {}; r[1].forEach(function (o) { namen[o.objekt.id] = o.aktuell.werte.bezeichnung; });
      var alleAkt = r[3].filter(function (x) { return x.aktuell.werte.aktivitaetId === aktivitaetId; });
      var kosten = alleAkt.filter(function (x) { return x.aktuell.werte.gruppe !== 'reisekasse'; }); /* Orte und Fahrzeug-Seite der Reise */
      var res = MM.Reiseorte.reiseAuswertung({ kosten: kosten.map(function (k) { return { werte: k.aktuell.werte }; }),
        besuche: r[2].map(function (b) { return { werte: b.aktuell.werte }; }), plan: planAus(a.aktuell.werte), orteNamen: namen });
      res.ok = true;
      return Promise.all([self.zahlungsmittelListe(), self.kostenartenListe(), self.kassenListe(aktivitaetId)]).then(function (z) {
        var zm = {}; z[0].forEach(function (x) { zm[x.wert] = x.label; });
        var artN = {}; z[1].forEach(function (x) { artN[x.wert] = x.label; });
        var fixPosten = r[3].filter(function (x) { return x.objekt.fahrzeugId === a.fahrzeug.id && x.aktuell.werte.gruppe === 'fix' && x.aktuell.werte.ausgeblendet !== 'ja'; })
          .map(function (x) { return { werte: x.aktuell.werte }; });
        res.gesamt = MM.Reisekasse.reiseGesamt({ kosten: alleAkt.map(function (x) { return { werte: x.aktuell.werte }; }), von: a.aktuell.werte.vonDatum, bis: a.aktuell.werte.bisDatum,
          personen: a.besatzung.length, fixPosten: fixPosten, fixEin: !(opts && opts.fixEin === false), zahlungsmittel: zm, heute: self.heute() });
        res.artNamen = artN; res.zahlungNamen = zm;
        res.kassen = z[2];
        res.reisekassePosten = alleAkt.filter(function (x) { return x.aktuell.werte.gruppe === 'reisekasse'; });
        res.besuche = r[2].filter(function (b) { return b.aktuell.werte.status === 'besucht'; }).map(function (b) { return Object.assign({}, b, { ortName: namen[b.aktuell.werte.ortId] || 'unbekannt' }); })
        .sort(function (x, y) { return besuchSchluessel(x) < besuchSchluessel(y) ? -1 : 1; });
        return res;
      });
    });
  };

  /*
   * Die kleine Abfrage im Cockpit: Gibt es eine Ankunft (Ankunft, Anlegen, Anker werfen), zu der noch nichts festgehalten oder
   * übersprungen wurde? Dann: das Ereignis, der Ort im Umfeld der Position (wenn es einen gibt) und wie es zum Plan der Aktivität
   * steht. ereignisse: die sichtbaren Ereignisse aus dem Logbuch. Gibt null, wenn nichts zu fragen ist.
   */
  Daten.prototype.reiseortFrage = function (aktivitaetId, ereignisse) {
    var self = this;
    return Promise.all([this.speicher.wo('besuche', 'aktivitaetId', aktivitaetId), this.mitVerlaufLaden('aktivitaeten', aktivitaetId, [])]).then(function (r) {
      var e = MM.Reiseorte.besuchFrage(ereignisse, r[0], self.jetztLokal());
      if (!e || !r[1]) return null;
      var plan = planAus(r[1].aktuell.werte);
      return Promise.all([self.orteListe(), self.standorteListe()]).then(function (o) {
        var namen = {}; o[0].forEach(function (x) { namen[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var vorschlag = MM.Reiseorte.naechster(MM.Reiseorte.kandidaten(o[0], o[1]), e.breite, e.laenge);
        var art = vorschlag ? MM.Reiseorte.planVergleich(plan, vorschlag.ortId) : null;
        return { ereignisId: e.id, artName: e.artName, datum: e.datum, zeit: e.zeit, breite: e.breite, laenge: e.laenge, ortName: e.ortName || null,
          vorschlag: vorschlag, plan: { vorhanden: MM.Reiseorte.planVergleich(plan, '-') !== null, art: art, text: MM.Reiseorte.planText(art),
            zielName: plan.zielOrtId ? (namen[plan.zielOrtId] || null) : null } };
      });
    });
  };

  /* ---------- Dokumente ---------- */
  /*
   * Ein Dokument ist eine Datei vom Gerät oder ein Link. Die Datei liegt in
   * einer eigenen Ablage, getrennt vom Eintrag. Das Dokument selbst bleibt
   * unverändert: Wer eine andere Datei will, legt ein neues Dokument an.
   */
  Daten.prototype.pruefenDokument = function (roh, quelle) {
    var p = pruefeWerte(MM.Dokumente.felder(quelle), roh, jahrVon(this));
    var w = p.werte, f = p.fehler;
    if (!w.art && !f.art) f.art = 'Bitte die Art des Dokuments wählen.';
    if (quelle === 'link') {
      if (!String(roh.link == null ? '' : roh.link).trim()) f.link = 'Bitte den Link eingeben.';
      else {
        var l = MM.Dokumente.normalisiereLink(roh.link);
        if (!l) { if (!f.link) f.link = 'Das ist kein gültiger Link. Er soll mit http oder https beginnen, zum Beispiel https://www.beispiel.de/anleitung.pdf'; }
        else w.link = l;
      }
    } else { w.link = null; }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  function istQuotaFehler(err) {
    return !!err && (err.name === 'QuotaExceededError' || /quota/i.test(String(err.message || '')));
  }

  /* vorgangId (seit 2.0.26, freiwillig): Das Dokument hängt an diesem Werkstatt-Vorgang (Bild, Beleg, Reparaturbuch-Seite). Fahrzeug und Komponente
     sind dann die des Vorgangs. */
  Daten.prototype.dokumentAnlegen = function (fahrzeugId, komponenteId, roh, vorgangId, kostenId) {
    var self = this;
    roh = roh || {};
    var quelle = roh.quelle, datei = roh.datei, fehler = {};
    if (quelle !== 'datei' && quelle !== 'link') fehler.quelle = 'Bitte wählen, ob du eine Datei oder einen Link ablegen möchtest.';
    if (quelle === 'datei' && !(datei && typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Bitte eine Datei auswählen.';
    var rohW = Object.assign({}, roh);
    if (quelle === 'datei' && !String(rohW.bezeichnung == null ? '' : rohW.bezeichnung).trim() && datei && datei.name) {
      rohW.bezeichnung = String(datei.name).replace(/\.[^.]+$/, '');
    }
    var p = this.pruefenDokument(rohW, quelle);
    Object.keys(p.fehler).forEach(function (k) { fehler[k] = p.fehler[k]; });
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    var vorgangPruefung = vorgangId ? this.speicher.holen('vorgaenge', vorgangId) : Promise.resolve(null);
    var kostenPruefung = kostenId ? this.speicher.holen('kosten', kostenId) : Promise.resolve(null);
    return Promise.all([vorgangPruefung, kostenPruefung]).then(function (rr) {
      var vg = rr[0], ko = rr[1];
      if (kostenId && (!ko || ko.fahrzeugId !== fahrzeugId || ko.datenraumId !== self.datenraumId)) return { ok: false, fehler: { allgemein: 'Dieser Posten wurde nicht gefunden.' } };
      if (vorgangId) {
        if (!vg || vg.fahrzeugId !== fahrzeugId) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
        komponenteId = vg.komponenteId || null;
      }
      return self.pruefeObjekt(fahrzeugId, komponenteId || null);
    }).then(function (f) {
      if (f && f.ok === false) return f;
      if (f) return { ok: false, fehler: f };
      var jetzt = self.jetzt();
      var w = p.werte;
      w.quelle = quelle;
      w.dateiName = quelle === 'datei' ? String(datei.name || 'Datei') : null;
      w.dateiTyp = quelle === 'datei' ? String(datei.type || '') : null;
      w.dateiGroesse = quelle === 'datei' ? datei.size : null;
      var d = { id: neueId('do'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, vorgangId: vorgangId || null, kostenId: kostenId || null, erstelltAm: jetzt };
      var liste = [
        { tabelle: 'dokumente', objekt: d },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('dokument', d.id, 1, w, null, jetzt) }
      ];
      if (quelle === 'datei') {
        liste.push({ tabelle: 'dateien', objekt: { id: neueId('da'), dokumentId: d.id, name: w.dateiName, mime: w.dateiTyp,
          groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      }
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: d.id }; })
        .catch(function (err) {
          if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei. Gib Platz frei oder wähle eine kleinere Datei.' } };
          throw err;
        });
    });
  };

  Daten.prototype.dokumentAendern = function (dokumentId, roh) {
    var self = this;
    return this.dokumentLaden(dokumentId).then(function (d) {
      if (!d) return { ok: false, fehler: { allgemein: 'Dieses Dokument wurde nicht gefunden.' } };
      var quelle = d.aktuell.werte.quelle;
      var p = self.pruefenDokument(roh, quelle);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, d.aktuell.werte, p.werte);
      if (!unterschiedeFelder(MM.Dokumente.felder(quelle), d.aktuell.werte, neu).length) return { ok: true, id: dokumentId, geaendert: false };
      var e = neuerVerlaufEintrag('dokument', dokumentId, d.aktuell.nr + 1, neu, d.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: dokumentId, geaendert: true }; });
    });
  };

  Daten.prototype.dokumentLaden = function (id) {
    var self = this;
    return this.speicher.holen('dokumente', id).then(function (d) {
      if (!d) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('dateien', 'dokumentId', id),
        self.fahrzeugLaden(d.fahrzeugId),
        self.komponentenListe(d.fahrzeugId),
        d.vorgangId ? self.vorgangLaden(d.vorgangId) : Promise.resolve(null)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[2]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        var komp = d.komponenteId ? r[3].filter(function (k) { return k.komponente.id === d.komponenteId; })[0] : null;
        var datei = r[1][0] ? { id: r[1][0].id, name: r[1][0].name, mime: r[1][0].mime, groesse: r[1][0].groesse } : null;
        return { dokument: d, aktuell: aktuell, verlauf: verlaufAus(eintraege, MM.Dokumente.felder(aktuell.werte.quelle)), datei: datei,
          fahrzeug: r[2].fahrzeug, fahrzeugAktuell: r[2].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null,
          vorgang: r[4] ? r[4].vorgang : null, vorgangAktuell: r[4] ? r[4].aktuell : null };
      });
    });
  };

  /* Die Datei selbst (mit Inhalt), zum Öffnen oder Speichern. */
  Daten.prototype.dateiHolen = function (dokumentId) {
    return this.speicher.wo('dateien', 'dokumentId', dokumentId).then(function (l) { return l[0] || null; });
  };

  /* Alle Dokumente eines Fahrzeugs und seiner Komponenten. Zuerst das Fahrzeug, dann die Komponenten nach Name. */
  Daten.prototype.dokumenteListe = function (fahrzeugId) {
    return Promise.all([
      this.speicher.wo('dokumente', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.komponentenListe(fahrzeugId),
      this.vorgaengeListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'dokument') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var kn = {}; r[2].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      var vn = {}; r[3].forEach(function (v) { vn[v.vorgang.id] = v.aktuell.werte.bezeichnung; });
      var res = r[0].map(function (d) {
        var l = (ver[d.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1];
        if (!a) return null;
        return { dokument: d, aktuell: a, komponenteId: d.komponenteId, besitzer: d.komponenteId ? (kn[d.komponenteId] || 'Komponente') : null,
          vorgangId: d.vorgangId || null, vorgangName: d.vorgangId ? (vn[d.vorgangId] || 'Vorgang') : null, kostenId: d.kostenId || null };
      }).filter(Boolean);
      res.sort(function (a, b) {
        if (!a.besitzer !== !b.besitzer) return a.besitzer ? 1 : -1;
        var o = (a.besitzer || '').localeCompare(b.besitzer || '', 'de', { numeric: true, sensitivity: 'base' });
        if (o) return o;
        var art = MM.Dokumente.artIndex(a.aktuell.werte.art) - MM.Dokumente.artIndex(b.aktuell.werte.art);
        return art || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return res;
    });
  };

  /* Die Dokumente und Bilder, die an einem Werkstatt-Vorgang hängen (seit 2.0.26), in der Reihenfolge der Liste. */
  Daten.prototype.dokumenteFuerVorgang = function (vorgangId) {
    var self = this;
    return this.speicher.holen('vorgaenge', vorgangId).then(function (v) {
      if (!v) return [];
      return self.dokumenteListe(v.fahrzeugId).then(function (l) { return l.filter(function (x) { return x.vorgangId === vorgangId; }); });
    });
  };

  /* Fotos und Belege an einem Posten der Kosten-Liste (seit 2.0.29), in der Reihenfolge der Liste. */
  Daten.prototype.dokumenteFuerKosten = function (kostenId) {
    var self = this;
    return this.speicher.holen('kosten', kostenId).then(function (k) {
      if (!k) return [];
      return self.dokumenteListe(k.fahrzeugId).then(function (l) { return l.filter(function (x) { return x.kostenId === kostenId; }); });
    });
  };

  /* Scans und Fotos von Nachweisen: bleiben immer nur auf diesem Gerät. */
  Daten.prototype.scansBelegung = function () {
    return this.speicher.alle('nachweisdateien').then(function (l) {
      return { anzahl: l.length, bytes: l.reduce(function (s, x) { return s + (x.groesse || 0); }, 0) };
    });
  };

  /* Wie viel Platz belegen die Dateien auf diesem Gerät? */
  Daten.prototype.dateienBelegung = function () {
    return this.speicher.alle('dateien').then(function (l) {
      return { anzahl: l.length, bytes: l.reduce(function (s, x) { return s + (x.groesse || 0); }, 0) };
    });
  };

  /* ---------- Personen und Tiere ---------- */
  function tabelleVon(typ) { return typ === 'person' ? 'personen' : (typ === 'tier' ? 'tiere' : 'fahrzeuge'); }
  function trimmed(v) { return String(v == null ? '' : v).trim(); }

  Daten.prototype.pruefenPerson = function (roh) {
    var p = pruefeWerte(MM.Personen.personFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen eingeben.' });
    var w = p.werte, f = p.fehler;
    if (w.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(w.email)) f.email = 'Das ist keine gültige E-Mail-Adresse.';
    if (w.telefon && !/^[0-9+\-\/() ]{5,}$/.test(w.telefon)) f.telefon = 'Bitte nur Ziffern, Leerzeichen und + - / ( ) eingeben.';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.pruefenTier = function (roh) {
    var p = pruefeWerte(MM.Personen.tierFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen eingeben.' });
    var w = p.werte, f = p.fehler;
    if (!w.tierart && !f.tierart) f.tierart = 'Bitte die Tierart wählen.';
    if (w.chipnummer) {
      var c = w.chipnummer.replace(/[\s-]/g, '');
      if (!/^\d{9,15}$/.test(c)) f.chipnummer = 'Die Chipnummer besteht aus Ziffern, meist 15.'; else w.chipnummer = c;
    }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Gemeinsame Bausteine für Dinge mit Verlauf: Person, Tier. */
  Daten.prototype.mitVerlaufAnlegen = function (tabelle, typ, praefix, werte, extra) {
    var jetzt = this.jetzt();
    var o = { id: neueId(praefix), datenraumId: this.datenraumId, erstelltAm: jetzt };
    if (extra) { for (var k in extra) { o[k] = extra[k]; } }
    return this.speicher.mehrereSpeichern([
      { tabelle: tabelle, objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag(typ, o.id, 1, werte, null, jetzt) }
    ]).then(function () { return { ok: true, id: o.id }; });
  };

  Daten.prototype.mitVerlaufLaden = function (tabelle, id, felder) {
    var self = this;
    return Promise.all([this.speicher.holen(tabelle, id), this.speicher.wo('verlaeufe', 'objektId', id)]).then(function (r) {
      if (!r[0] || !r[1].length) return null;
      var eintraege = r[1].slice().sort(nachNr);
      return { objekt: r[0], aktuell: eintraege[eintraege.length - 1], verlauf: verlaufAus(eintraege, felder || []) };
    });
  };

  Daten.prototype.mitVerlaufAendern = function (typ, id, geladen, neu, felder) {
    if (!unterschiedeFelder(felder, geladen.aktuell.werte, neu).length) return Promise.resolve({ ok: true, id: id, geaendert: false });
    var e = neuerVerlaufEintrag(typ, id, geladen.aktuell.nr + 1, neu, geladen.aktuell.id, this.jetzt());
    return this.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: id, geaendert: true }; });
  };

  Daten.prototype.personAnlegen = function (roh) {
    var p = this.pruefenPerson(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.mitVerlaufAnlegen('personen', 'person', 'pe', p.werte);
  };
  Daten.prototype.personAendern = function (id, roh) {
    var self = this;
    return this.personLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Person wurde nicht gefunden.' } };
      var p = self.pruefenPerson(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('person', id, x, p.werte, MM.Personen.personFelder());
    });
  };
  Daten.prototype.personLaden = function (id) { return this.mitVerlaufLaden('personen', id, MM.Personen.personFelder()); };
  Daten.prototype.personenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('personen'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'person');
    });
  };

  Daten.prototype.tierAnlegen = function (roh) {
    var p = this.pruefenTier(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.mitVerlaufAnlegen('tiere', 'tier', 'ti', p.werte);
  };
  Daten.prototype.tierAendern = function (id, roh) {
    var self = this;
    return this.tierLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Tier wurde nicht gefunden.' } };
      var p = self.pruefenTier(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('tier', id, x, p.werte, MM.Personen.tierFelder());
    });
  };
  Daten.prototype.tierLaden = function (id) { return this.mitVerlaufLaden('tiere', id, MM.Personen.tierFelder()); };
  Daten.prototype.tiereListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('tiere'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'tier');
    });
  };

  /* Objekte mit aktuellem Stand, nach Namen sortiert. */
  function sammle(self, objekte, verlaeufe, typ) {
    var ver = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === typ) (ver[e.objektId] = ver[e.objektId] || []).push(e); });
    var liste = objekte.filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
      var l = (ver[o.id] || []).slice().sort(nachNr);
      return { objekt: o, aktuell: l[l.length - 1] || null };
    }).filter(function (x) { return x.aktuell; });
    liste.sort(function (a, b) { return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' }); });
    return liste;
  }

  /* ---------- Nachweisarten (offene Liste) ---------- */
  var ART_FELDER = [
    { key: 'bezeichnung', label: 'Name der Art' },
    { key: 'hatAblauf', label: 'Mit Ablaufdatum', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN },
    { key: 'land', label: 'Land', typ: 'text' },
    { key: 'beschreibung', label: 'Beschreibung', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN },
    { key: 'felder', label: 'Weitere Angaben', typ: 'zeilen' }
  ];

  Daten.prototype.pruefenNachweisart = function (roh, neu) {
    roh = roh || {};
    var f = {}, w = {};
    var bez = trimmed(roh.bezeichnung);
    if (!bez) f.bezeichnung = 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segelschein“.';
    w.bezeichnung = bez;
    if (neu) {
      if (!MM.Nachweise.BESITZER.some(function (b) { return b.wert === roh.gehoertZu; })) f.gehoertZu = 'Bitte wählen, wofür der Nachweis gilt: Person, Tier oder Fahrzeug.';
      else w.gehoertZu = roh.gehoertZu;
    }
    w.hatAblauf = roh.hatAblauf === 'ja' ? 'ja' : 'nein';
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    w.land = trimmed(roh.land) || null;
    w.beschreibung = trimmed(roh.beschreibung) || null;

    var zeilen = Array.isArray(roh.felder) ? roh.felder : [];
    var belegt = {}, hoechste = 0;
    zeilen.forEach(function (z) { var m = /^z(\d+)$/.exec(z && z.key || ''); if (m) { belegt[z.key] = true; hoechste = Math.max(hoechste, +m[1]); } });
    var sauber = [], benutzt = {};
    zeilen.forEach(function (z) {
      var label = trimmed(z && z.label), papier = trimmed(z && z.papier);
      if (!label && !papier) return;
      if (!label) { f.felder = 'Bitte bei jeder weiteren Angabe eine Beschriftung eingeben.'; return; }
      var typ = MM.Nachweise.FELDTYPEN.some(function (t) { return t.wert === z.typ; }) ? z.typ : 'text';
      var key = z.key && /^z\d+$/.test(z.key) && !benutzt[z.key] ? z.key : null;
      if (!key) { hoechste++; key = 'z' + hoechste; }
      benutzt[key] = true;
      sauber.push({ key: key, label: label, typ: typ, papier: papier });
    });
    w.felder = sauber;
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.nachweisartAnlegen = function (roh) {
    var p = this.pruefenNachweisart(roh, true);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var w = p.werte;
    w.gemeinsam = {}; w.ohne = []; w.herkunft = 'eigen'; w.vorschlagId = null;
    w.quelleTitel = null; w.quelleUrl = null; w.pruefstatus = null; w.geprueftAm = null;
    return this.mitVerlaufAnlegen('nachweisarten', 'nachweisart', 'na', w);
  };

  /* Übernimmt einen Vorschlag als eigene Art. Danach ist sie frei änderbar. */
  Daten.prototype.nachweisartAusVorschlag = function (vorschlagId) {
    var self = this;
    var v = MM.NachweisVorschlaege.finde(vorschlagId);
    if (!v) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diesen Vorschlag gibt es nicht.' } });
    return this.nachweisartenListe().then(function (liste) {
      var vorhanden = liste.filter(function (x) { return x.aktuell.werte.vorschlagId === vorschlagId; })[0];
      if (vorhanden) return { ok: false, vorhanden: true, id: vorhanden.objekt.id, fehler: { allgemein: 'Diese Art ist schon übernommen.' } };
      return self.mitVerlaufAnlegen('nachweisarten', 'nachweisart', 'na', {
        bezeichnung: v.name, gehoertZu: v.gehoertZu, hatAblauf: v.hatAblauf ? 'ja' : 'nein', ausgeblendet: 'nein',
        land: v.land, beschreibung: v.hinweis || null, gemeinsam: v.gemeinsam, ohne: v.ohne, felder: v.felder,
        herkunft: 'vorschlag', vorschlagId: v.id, quelleTitel: v.quelle ? v.quelle.titel : null, quelleUrl: v.quelle ? v.quelle.url : null,
        pruefstatus: v.pruefstatus, geprueftAm: v.geprueftAm
      });
    });
  };

  Daten.prototype.nachweisartAendern = function (id, roh) {
    var self = this;
    return this.nachweisartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var p = self.pruefenNachweisart(roh, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, x.aktuell.werte, p.werte);
      return self.mitVerlaufAendern('nachweisart', id, x, neu, ART_FELDER);
    });
  };

  Daten.prototype.nachweisartLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('nachweisarten', id, ART_FELDER).then(function (x) {
      if (!x) return null;
      return self.speicher.alle('nachweise').then(function (n) {
        x.anzahlNachweise = n.filter(function (k) { return k.artId === id; }).length;
        x.art = x.objekt; x.werte = x.aktuell.werte;
        return x;
      });
    });
  };

  /* Alle Arten, nach Besitzer (Person, Tier, Fahrzeug) und Name geordnet. */
  Daten.prototype.nachweisartenListe = function (gehoertZu) {
    var self = this;
    return Promise.all([this.speicher.alle('nachweisarten'), this.speicher.alle('verlaeufe'), this.speicher.alle('nachweise')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'nachweisart');
      var anzahl = {}; r[2].forEach(function (n) { anzahl[n.artId] = (anzahl[n.artId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlNachweise = anzahl[x.objekt.id] || 0; });
      if (gehoertZu) liste = liste.filter(function (x) { return x.aktuell.werte.gehoertZu === gehoertZu; });
      var reihenfolge = { person: 0, tier: 1, fahrzeug: 2 };
      liste.sort(function (a, b) {
        var o = reihenfolge[a.aktuell.werte.gehoertZu] - reihenfolge[b.aktuell.werte.gehoertZu];
        return o || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return liste;
    });
  };

  /* ---------- Nachweise ---------- */
  Daten.prototype.besitzerLaden = function (typ, id) {
    if (typ === 'fahrzeug') return this.fahrzeugLaden(id).then(function (f) { return f ? { name: f.aktuell.werte.bezeichnung, id: id } : null; });
    return this.mitVerlaufLaden(tabelleVon(typ), id, []).then(function (x) { return x ? { name: x.aktuell.werte.bezeichnung, id: id } : null; });
  };

  function artStatus(art, werte, heute) { return MM.Nachweise.status(art, werte, heute); }

  Daten.prototype.nachweisAnlegen = function (besitzerTyp, besitzerId, artId, roh) {
    var self = this;
    roh = roh || {};
    return Promise.all([this.nachweisartLaden(artId), this.besitzerLaden(besitzerTyp, besitzerId)]).then(function (r) {
      var art = r[0], besitzer = r[1];
      if (!art) return { ok: false, fehler: { artId: 'Bitte zuerst die Art des Nachweises wählen.' } };
      if (!besitzer) return { ok: false, fehler: { allgemein: 'Dazu wurde nichts gefunden.' } };
      var aw = art.aktuell.werte;
      if (aw.gehoertZu !== besitzerTyp) return { ok: false, fehler: { artId: 'Diese Art gilt nicht hierfür.' } };
      if (aw.ausgeblendet === 'ja') return { ok: false, fehler: { artId: 'Diese Art ist ausgeblendet.' } };

      var felder = MM.Nachweise.felderFuer(aw);
      var p = pruefeWerte(felder, roh, jahrVon(self), { ohneBezeichnung: true });
      var fehler = p.fehler, w = p.werte;
      if (w.ausgestelltAm && w.gueltigBis && w.gueltigBis < w.ausgestelltAm && !fehler.gueltigBis) fehler.gueltigBis = 'Das Ablaufdatum liegt vor dem Ausstellungsdatum.';
      var datei = roh.datei;
      if (datei && !(typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Diese Datei ist leer.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };

      var jetzt = self.jetzt();
      var n = { id: neueId('nw'), datenraumId: self.datenraumId, artId: artId, besitzerTyp: besitzerTyp, besitzerId: besitzerId, erstelltAm: jetzt };
      w.dateiName = datei ? String(datei.name || 'Datei') : null;
      w.dateiTyp = datei ? String(datei.type || '') : null;
      w.dateiGroesse = datei ? datei.size : null;
      var liste = [{ tabelle: 'nachweise', objekt: n }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('nachweis', n.id, 1, w, null, jetzt) }];
      if (datei) liste.push({ tabelle: 'nachweisdateien', objekt: { id: neueId('nd'), nachweisId: n.id, name: w.dateiName, mime: w.dateiTyp, groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: n.id }; }).catch(function (err) {
        if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei.' } };
        throw err;
      });
    });
  };

  Daten.prototype.nachweisAendern = function (id, roh) {
    var self = this;
    return this.nachweisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Nachweis wurde nicht gefunden.' } };
      var p = pruefeWerte(x.felder, roh || {}, jahrVon(self), { ohneBezeichnung: true });
      var fehler = p.fehler, w = p.werte;
      if (w.ausgestelltAm && w.gueltigBis && w.gueltigBis < w.ausgestelltAm && !fehler.gueltigBis) fehler.gueltigBis = 'Das Ablaufdatum liegt vor dem Ausstellungsdatum.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var neu = Object.assign({}, x.aktuell.werte, w);
      return self.mitVerlaufAendern('nachweis', id, { aktuell: x.aktuell }, neu, x.felder);
    });
  };

  Daten.prototype.nachweisLaden = function (id) {
    var self = this;
    return this.speicher.holen('nachweise', id).then(function (n) {
      if (!n) return null;
      return Promise.all([self.nachweisartLaden(n.artId), self.mitVerlaufLaden('nachweise', id, []), self.speicher.wo('nachweisdateien', 'nachweisId', id), self.besitzerLaden(n.besitzerTyp, n.besitzerId)]).then(function (r) {
        var art = r[0], x = r[1];
        if (!art || !x) return null;
        var felder = MM.Nachweise.felderFuer(art.aktuell.werte);
        var eintraege = x.verlauf.map(function (v) { return v.eintrag; });
        var verlauf = verlaufAus(eintraege, felder);
        var d = r[2][0] ? { id: r[2][0].id, name: r[2][0].name, mime: r[2][0].mime, groesse: r[2][0].groesse } : null;
        return { nachweis: n, aktuell: x.aktuell, verlauf: verlauf, art: art, felder: felder, datei: d, besitzer: r[3],
          status: artStatus(art.aktuell.werte, x.aktuell.werte, self.heute()) };
      });
    });
  };

  Daten.prototype.nachweisDateiHolen = function (nachweisId) {
    return this.speicher.wo('nachweisdateien', 'nachweisId', nachweisId).then(function (l) { return l[0] || null; });
  };

  /* Nachweise eines Besitzers, mit Status. Abgelaufene zuerst. */
  Daten.prototype.nachweiseListe = function (besitzerTyp, besitzerId) {
    var self = this;
    return Promise.all([this.speicher.wo('nachweise', 'besitzerId', besitzerId), this.speicher.alle('verlaeufe'), this.nachweisartenListe()]).then(function (r) {
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a; });
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'nachweis') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var heute = self.heute();
      var liste = r[0].filter(function (n) { return n.besitzerTyp === besitzerTyp; }).map(function (n) {
        var l = (ver[n.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1], art = arten[n.artId];
        if (!a || !art) return null;
        return { nachweis: n, aktuell: a, art: art, status: artStatus(art.aktuell.werte, a.werte, heute) };
      }).filter(Boolean);
      liste.sort(function (a, b) {
        var d = MM.Nachweise.rang(b.status.status) - MM.Nachweise.rang(a.status.status);
        return d || a.art.aktuell.werte.bezeichnung.localeCompare(b.art.aktuell.werte.bezeichnung, 'de', { numeric: true });
      });
      return liste;
    });
  };

  /* Pro Besitzer: wie viele Nachweise sind abgelaufen oder laufen bald ab? */
  Daten.prototype.nachweisUebersicht = function () {
    var self = this;
    return Promise.all([this.speicher.alle('nachweise'), this.speicher.alle('verlaeufe'), this.nachweisartenListe()]).then(function (r) {
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a; });
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'nachweis') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var heute = self.heute(), res = {};
      r[0].forEach(function (n) {
        var l = (ver[n.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1], art = arten[n.artId];
        if (!a || !art) return;
        var s = artStatus(art.aktuell.werte, a.werte, heute).status;
        var z = res[n.besitzerId] = res[n.besitzerId] || { abgelaufen: 0, bald: 0, unbekannt: 0 };
        if (z[s] !== undefined) z[s]++;
      });
      return res;
    });
  };

  /* ---------- Aktivitäten: gemeinsame Hilfen ---------- */
  Daten.prototype.jetztLokal = function () {
    var d = new Date(this.jetzt());
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()) + 'T' + z(d.getHours()) + ':' + z(d.getMinutes());
  };

  /* ---------- Aktivitätsarten (offene Liste) ---------- */
  var AKTART_FELDER = [
    { key: 'bezeichnung', label: 'Name der Art' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  /* Seit 2.0.17 gilt jede Aktivitätsart für Fahrzeugarten (Baum, wie bei den Ereignisarten).
     Fehlt die Angabe (ältere Arten), gilt sie für alle. */
  var AKTIVITAETSART_FELDER = AKTART_FELDER.concat([{ key: 'zuordnung', label: 'Gilt für Fahrzeugarten', typ: 'text' }]);

  Daten.prototype.aktivitaetsartenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('aktivitaetsarten'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'aktivitaetsart');
    });
  };

  Daten.prototype.aktivitaetsartAnlegen = function (roh) {
    var self = this;
    var bez = trimmed(roh && roh.bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segeln“.' } });
    return this.aktivitaetsartenListe().then(function (liste) {
      if (liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === bez.toLowerCase(); })) {
        return { ok: false, fehler: { bezeichnung: 'Diese Art gibt es schon.' } };
      }
      return self.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: bez, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungNormal(roh.zuordnung) });
    });
  };

  /* Legt die Vorschläge an, die es noch nicht gibt. Gibt die Anzahl der neuen zurück. */
  Daten.prototype.aktivitaetsartenAusVorschlaegen = function () {
    var self = this;
    return this.aktivitaetsartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Aktivitaeten.VORSCHLAEGE_ARTEN.filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
      return neu.reduce(function (kette, n) {
        var gilt = MM.Aktivitaeten.zuordnungVorschlag(n);
        var zuordnung = gilt ? MM.Logbuch.zuordnungFuerKnoten(gilt) : MM.Logbuch.zuordnungNormal();
        return kette.then(function () { return self.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: n, ausgeblendet: 'nein', zuordnung: zuordnung }); });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  /* Setzt die Starthilfe-Zuordnung bei den vorgeschlagenen Arten, die noch keine Zuordnung haben (ältere Arten).
     Was der Nutzer schon eingestellt hat, bleibt unberührt. */
  Daten.prototype.aktivitaetsartenVorauswahlUebernehmen = function () {
    var self = this;
    return this.aktivitaetsartenListe().then(function (liste) {
      var offen = liste.filter(function (x) { return x.aktuell.werte.zuordnung === undefined && MM.Aktivitaeten.zuordnungVorschlag(x.aktuell.werte.bezeichnung); });
      return offen.reduce(function (kette, x) {
        return kette.then(function () {
          return self.aktivitaetsartAendern(x.objekt.id, { bezeichnung: x.aktuell.werte.bezeichnung, ausgeblendet: x.aktuell.werte.ausgeblendet,
            zuordnung: MM.Logbuch.zuordnungFuerKnoten(MM.Aktivitaeten.zuordnungVorschlag(x.aktuell.werte.bezeichnung)) });
        });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: offen.length, namen: offen.map(function (x) { return x.aktuell.werte.bezeichnung; }) }; });
    });
  };

  /* Die Aktivitätsarten, die zu einer Fahrzeugart passen (ohne ausgeblendete). Eine Art, die schon an einer
     Aktivität hängt, bleibt auswählbar (behalteIds). Ohne Fahrzeugart: alle nicht ausgeblendeten. */
  Daten.prototype.aktivitaetsartenFuerFahrzeugart = function (artId, behalteIds) {
    var behalte = behalteIds || [];
    return this.aktivitaetsartenListe().then(function (liste) {
      return liste.filter(function (x) {
        if (behalte.indexOf(x.objekt.id) >= 0) return true;
        if (x.aktuell.werte.ausgeblendet === 'ja') return false;
        return !artId || MM.Logbuch.ereignisartGilt(x.aktuell.werte.zuordnung, artId);
      });
    });
  };

  Daten.prototype.aktivitaetsartLaden = function (id) { return this.mitVerlaufLaden('aktivitaetsarten', id, AKTIVITAETSART_FELDER); };

  Daten.prototype.aktivitaetsartAendern = function (id, roh) {
    var self = this;
    return this.aktivitaetsartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var bez = trimmed(roh && roh.bezeichnung);
      if (!bez) return { ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben.' } };
      var neu = { bezeichnung: bez, ausgeblendet: roh.ausgeblendet === 'ja' ? 'ja' : 'nein' };
      /* Ohne Angabe bleibt die Zuordnung, wie sie ist (bei alten Arten: gilt für alle). */
      if (roh.zuordnung !== undefined) neu.zuordnung = MM.Logbuch.zuordnungNormal(roh.zuordnung);
      else if (x.aktuell.werte.zuordnung !== undefined) neu.zuordnung = x.aktuell.werte.zuordnung;
      return self.mitVerlaufAendern('aktivitaetsart', id, x, neu, AKTIVITAETSART_FELDER);
    });
  };

  /* ---------- Anforderungen an Skipper und Fahrer (je Fahrzeug) ---------- */
  var ANF_FELDER = [
    { key: 'bezeichnung', label: 'Bezeichnung' },
    { key: 'artIds', label: 'Akzeptierte Nachweisarten', typ: 'mehrfach' },
    { key: 'gilt', label: 'Gilt', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  Daten.prototype.pruefenAnforderung = function (roh, personenArten) {
    roh = roh || {};
    var f = {}, w = {};
    w.bezeichnung = trimmed(roh.bezeichnung);
    if (!w.bezeichnung) f.bezeichnung = 'Bitte eine Bezeichnung eingeben, zum Beispiel „Führerschein Klasse B“.';
    var gew = Array.isArray(roh.artIds) ? roh.artIds : [];
    w.artIds = personenArten.filter(function (a) { return gew.indexOf(a) >= 0; });
    if (!w.artIds.length) f.artIds = 'Bitte mindestens eine Art von Nachweis wählen, die genügt.';
    w.gilt = roh.gilt === 'nein' ? 'nein' : 'ja';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  function personenArtIds(self) {
    return self.nachweisartenListe('person').then(function (l) { return l.map(function (x) { return x.objekt.id; }); });
  }

  Daten.prototype.anforderungAnlegen = function (fahrzeugId, roh) {
    var self = this;
    return Promise.all([this.pruefeObjekt(fahrzeugId, null), personenArtIds(this)]).then(function (r) {
      if (r[0]) return { ok: false, fehler: r[0] };
      var p = self.pruefenAnforderung(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAnlegen('anforderungen', 'anforderung', 'an', p.werte, { fahrzeugId: fahrzeugId });
    });
  };

  Daten.prototype.anforderungLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('anforderungen', id, ANF_FELDER).then(function (x) {
      if (!x) return null;
      return self.nachweisartenListe('person').then(function (arten) {
        var namen = {}; arten.forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artIds') {
              u.feld = { typ: 'text' };
              u.alt = (u.alt || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null;
              u.neu = (u.neu || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null;
            }
          });
        });
        x.arten = arten; x.namen = namen;
        return x;
      });
    });
  };

  Daten.prototype.anforderungAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.anforderungLaden(id), personenArtIds(this)]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Anforderung wurde nicht gefunden.' } };
      var p = self.pruefenAnforderung(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('anforderung', id, x, p.werte, ANF_FELDER);
    });
  };

  /* Anforderungen eines Fahrzeugs; nurGueltige blendet abgeschaltete aus. */
  Daten.prototype.anforderungenListe = function (fahrzeugId, nurGueltige) {
    var self = this;
    return Promise.all([this.speicher.wo('anforderungen', 'fahrzeugId', fahrzeugId), this.speicher.alle('verlaeufe'), this.nachweisartenListe('person')]).then(function (r) {
      var namen = {}; r[2].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      var liste = sammle(self, r[0], r[1], 'anforderung').map(function (x) {
        x.artNamen = x.aktuell.werte.artIds.map(function (i) { return namen[i] || 'unbekannte Art'; });
        return x;
      });
      return nurGueltige ? liste.filter(function (x) { return x.aktuell.werte.gilt !== 'nein'; }) : liste;
    });
  };

  /* ---------- Orte, Standorte, Gebiete und Regeln ---------- */
  var AUSGEBLENDET = { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN };
  /* Das Revier-Feld des Formulars (revierName) wird nicht gespeichert, gespeichert wird die Verknüpfung (revierId). */
  var ORT_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.ortFelder().filter(function (f) { return f.key !== 'revierName'; }), [
    { key: 'gebietId', label: 'Gebiet', typ: 'text' }, { key: 'revierId', label: 'Revier', typ: 'text' }, { key: 'ortGeprueft', label: 'Ort geprüft', typ: 'text' }, AUSGEBLENDET]);
  var STANDORT_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.standortFelder(), [AUSGEBLENDET]);
  var GEBIET_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.gebietFelder(), [AUSGEBLENDET,
    { key: 'ebene', label: 'Ebene', typ: 'text' }, { key: 'elternId', label: 'Gehört zu', typ: 'text' }, { key: 'schluessel', label: 'Schlüssel', typ: 'text' },
    { key: 'ortId', label: 'Ort', typ: 'text' }]);
  var REGEL_FELDER = [
    { key: 'bezeichnung', label: 'Bezeichnung' },
    { key: 'art', label: 'Art der Regel', typ: 'auswahl', optionen: MM.Orte.REGELARTEN },
    { key: 'pflichtAusruestung', label: 'Pflichtausrüstung', typ: 'text' },
    { key: 'menge', label: 'Menge', typ: 'ganzzahl' },
    { key: 'bezug', label: 'Bezugsgröße', typ: 'auswahl', optionen: MM.Orte.BEZUGSGROESSEN },
    { key: 'eignung', label: 'Gefordert (Eignung)', typ: 'text' },
    { key: 'fahrzeugArten', label: 'Gilt für Fahrzeugarten', typ: 'mehrfach' },
    { key: 'ausruestung', label: 'Nur mit Ausrüstung', typ: 'text' },
    { key: 'artIds', label: 'Genügt einer dieser Nachweise', typ: 'mehrfach' },
    { key: 'gilt', label: 'Gilt', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  /* Das Gebiet eines Ortes (Ebene „ort“, seit 2.0.42) trägt den Namen des Ortes und zählt beim Namensvergleich der Gebiete nicht mit. */
  function ohneOrtGebiete(liste) { return liste.filter(function (x) { return x.aktuell.werte.ebene !== 'ort'; }); }

  function gleicherName(liste, name, ausser) {
    var n = name.toLowerCase();
    return liste.some(function (x) { return x.objekt.id !== ausser && x.aktuell.werte.bezeichnung.toLowerCase() === n; });
  }

  /* Gemeinsame Prüfung für Ort, Standort und Gebiet: Name, freie Felder, „ausgeblendet“. */
  function pruefeBenannt(self, felder, roh, text) {
    var p = pruefeWerte(felder, roh, jahrVon(self), { bezeichnungFehler: text });
    p.werte.ausgeblendet = roh && roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    p.werte.herkunft = 'eigen';
    return p;
  }

  /* Position eines Ortes oder Standorts (seit 2.0.28): Breite und Länge als Dezimalgrad, beide oder keine. Gespeichert als Zahl. */
  function pruefeKoordinaten(p, roh) {
    roh = roh || {};
    var b = MM.Logbuch.koordinateLesen(roh.positionBreite, 'breite'), l = MM.Logbuch.koordinateLesen(roh.positionLaenge, 'laenge');
    p.werte.positionBreite = null; p.werte.positionLaenge = null;
    if (b.fehler) p.fehler.positionBreite = b.fehler;
    if (l.fehler) p.fehler.positionLaenge = l.fehler;
    if (!b.fehler && !l.fehler) {
      if (b.leer && !l.leer) p.fehler.positionBreite = 'Bitte auch die Breite eingeben. Breite und Länge gehören zusammen.';
      else if (l.leer && !b.leer) p.fehler.positionLaenge = 'Bitte auch die Länge eingeben. Breite und Länge gehören zusammen.';
      else if (!b.leer) { p.werte.positionBreite = b.wert; p.werte.positionLaenge = l.wert; }
    }
    p.ok = Object.keys(p.fehler).length === 0;
    return p;
  }

  Daten.prototype.pruefenOrt = function (roh) {
    var p = pruefeBenannt(this, MM.Orte.ortFelder(), roh, 'Bitte einen Namen für den Ort eingeben, zum Beispiel „Hafen Biograd“.');
    if (p.werte.telefon && !/^[0-9+\-\/() ]{5,}$/.test(p.werte.telefon)) { p.fehler.telefon = 'Bitte nur Ziffern, Leerzeichen und + - / ( ) eingeben.'; p.ok = false; }
    /* Der Name des Reviers ist nur Eingabe: Er wird beim Speichern zur Verknüpfung (revierId). null = Feld war nicht im Formular. */
    p.revierName = roh && typeof roh.revierName === 'string' ? roh.revierName.replace(/\s+/g, ' ').trim() : null;
    delete p.werte.revierName;
    return pruefeKoordinaten(p, roh);
  };
  Daten.prototype.pruefenStandort = function (roh) {
    return pruefeKoordinaten(pruefeBenannt(this, MM.Orte.standortFelder(), roh, 'Bitte einen Namen für den Standort eingeben, zum Beispiel „Liegeplatz 12“.'), roh);
  };
  Daten.prototype.pruefenGebiet = function (roh) {
    return pruefeBenannt(this, MM.Orte.gebietFelder(), roh, 'Bitte einen Namen für das Gebiet eingeben, zum Beispiel „Kroatien, Adria“.');
  };

  /* ----- Orte ----- */
  Daten.prototype.orteListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('orte'), this.speicher.alle('verlaeufe'), this.speicher.alle('standorte')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'ort');
      var anzahl = {}; r[2].forEach(function (s) { anzahl[s.ortId] = (anzahl[s.ortId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlStandorte = anzahl[x.objekt.id] || 0; });
      return liste;
    });
  };

  Daten.prototype.ortAnlegen = function (roh) {
    var self = this;
    var p = this.pruefenOrt(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    if (p.revierName) return Promise.resolve({ ok: false, fehler: { revierName: REVIER_OHNE_LAND } });
    return this.orteListe().then(function (liste) {
      if (gleicherName(liste, p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Diesen Ort gibt es schon.' } };
      /* Ohne Ortssuche bleibt der Ort ungeprüft: kein Gebiet, die Prüfung sagt dann „unklar“. */
      p.werte.gebietId = null; p.werte.revierId = null; p.werte.ortGeprueft = 'nein';
      return self.mitVerlaufAnlegen('orte', 'ort', 'or', p.werte);
    });
  };

  var REVIER_OHNE_LAND = 'Das Revier gehört zu einem Land. Prüfe den Ort zuerst über die Ortssuche, dann kann das Revier eingetragen werden.';

  /* Speichert eine Änderung am Ort zusammen mit neuen Gebieten, ganz oder gar nicht. */
  function ortAenderungSpeichern(self, id, x, neu, zusatz) {
    var gleich = !unterschiedeFelder(ORT_FELDER, x.aktuell.werte, neu).length;
    if (gleich && !zusatz.length) return Promise.resolve({ ok: true, id: id, geaendert: false });
    var liste = zusatz.slice();
    if (!gleich) liste.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ort', id, x.aktuell.nr + 1, neu, x.aktuell.id, self.jetzt()) });
    return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: id, geaendert: true }; });
  }

  Daten.prototype.ortAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', id, ORT_FELDER), this.orteListe(), this.gebieteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var p = self.pruefenOrt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(r[1], p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Diesen Ort gibt es schon.' } };
      /* Gebiet, Revier und „geprüft“ kommen aus der Ortssuche und bleiben beim Ändern der übrigen Angaben erhalten. */
      var alt = x.aktuell.werte, neu = p.werte, zusatz = [];
      neu.gebietId = alt.gebietId || null; neu.revierId = alt.revierId || null; neu.ortGeprueft = alt.ortGeprueft || 'nein';
      if (p.revierName !== null) {
        if (!p.revierName) neu.revierId = null;
        else {
          var weg = neu.gebietId ? MM.Gebiete.pfad(r[2], neu.gebietId) : [];
          if (!weg.length || weg[0].ebene !== 'land') return { ok: false, fehler: { revierName: REVIER_OHNE_LAND } };
          var rv = revierSichern(self, r[2], weg[0].id, p.revierName, self.jetzt());
          neu.revierId = rv.id; zusatz = rv.speichern;
        }
      }
      /* Hat der Ort eigene Regeln, heißt sein Gebiet wie der Ort (seit 2.0.42). */
      var wegL = neu.gebietId ? MM.Gebiete.pfad(r[2], neu.gebietId) : [];
      zusatz = zusatz.concat(ortGebietAbgleichen(self, r[2], id, neu.bezeichnung, wegL[0] && wegL[0].ebene === 'land' ? wegL[0].id : null, self.jetzt(), false).speichern);
      return ortAenderungSpeichern(self, id, x, neu, zusatz);
    });
  };

  /* Ein Ort mit seinen Standorten. */
  Daten.prototype.ortLaden = function (id) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', id, ORT_FELDER), this.standorteListe(id), this.gebieteListe()]).then(function (r) {
      if (!r[0]) return null;
      r[0].standorte = r[1];
      /* Das Gebiet des Ortes (seit 2.0.39): der Weg von oben, und das Revier, wenn es eingetragen ist. */
      var w = r[0].aktuell.werte;
      r[0].gebietPfad = w.gebietId ? MM.Gebiete.pfad(r[2], w.gebietId) : [];
      var rev = w.revierId ? MM.Gebiete.pfad(r[2], w.revierId) : [];
      r[0].revier = rev.length ? rev[rev.length - 1] : null;
      /* Eigene Regeln des Ortes (seit 2.0.42): Der Ort ist die unterste Ebene, aber nur mit eigenen Regeln. */
      var og = MM.Gebiete.ortGebiet(r[2], id);
      r[0].ortGebiet = og ? { id: og.objekt.id } : null;
      return (og ? self.regelnListe(og.objekt.id) : Promise.resolve([])).then(function (reg) { r[0].eigeneRegeln = reg; return r[0]; });
    });
  };

  /* Zu dieser Position: der nächste Ort oder Standort mit Position im Umfeld (300 m), oder null. { ortId, standortId, name, abstand } */
  Daten.prototype.ortZuPosition = function (breite, laenge) {
    if (typeof breite !== 'number' || typeof laenge !== 'number') return Promise.resolve(null);
    return Promise.all([this.orteListe(), this.standorteListe()]).then(function (r) {
      return MM.Reiseorte.naechster(MM.Reiseorte.kandidaten(r[0], r[1]), breite, laenge);
    });
  };

  /* Die Namen, die die App bei Ankünften gelernt hat und zu denen es noch keinen Ort gibt (gleicher Name, Groß- und Kleinschreibung egal). */
  Daten.prototype.gelernteNamenOffen = function () {
    return Promise.all([this.positionsnamenListe(), this.orteListe()]).then(function (r) {
      var vorhanden = {}; r[1].forEach(function (o) { vorhanden[o.aktuell.werte.bezeichnung.toLowerCase()] = true; });
      var gesehen = {}, offen = [];
      r[0].forEach(function (pt) {
        var n = String(pt.name || '').trim().toLowerCase();
        if (!n || vorhanden[n] || gesehen[n]) return;
        gesehen[n] = true; offen.push(pt);
      });
      return offen;
    });
  };

  /* Aus den gelernten Namen werden Orte (mit der gelernten Position). Alles in einem Zug, ganz oder gar nicht. */
  Daten.prototype.gelernteNamenUebernehmen = function () {
    var self = this;
    return this.gelernteNamenOffen().then(function (offen) {
      var liste = [], jetzt = self.jetzt(), angelegt = 0;
      offen.forEach(function (pt) {
        var p = self.pruefenOrt({ bezeichnung: pt.name, positionBreite: pt.breite, positionLaenge: pt.laenge });
        if (!p.ok) return;
        var o = { id: neueId('or'), datenraumId: self.datenraumId, erstelltAm: jetzt };
        liste.push({ tabelle: 'orte', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ort', o.id, 1, p.werte, null, jetzt) });
        angelegt++;
      });
      if (!liste.length) return { ok: true, angelegt: 0 };
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, angelegt: angelegt }; });
    });
  };

  /* ----- Standorte ----- */
  Daten.prototype.standorteListe = function (ortId) {
    var self = this;
    return Promise.all([this.speicher.alle('standorte'), this.speicher.alle('verlaeufe')]).then(function (r) {
      var rec = ortId ? r[0].filter(function (s) { return s.ortId === ortId; }) : r[0];
      return sammle(self, rec, r[1], 'standort');
    });
  };

  Daten.prototype.standortAnlegen = function (ortId, roh) {
    var self = this;
    return Promise.all([this.speicher.holen('orte', ortId), this.standorteListe(ortId)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var p = self.pruefenStandort(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(r[1], p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Diesen Standort gibt es an diesem Ort schon.' } };
      return self.mitVerlaufAnlegen('standorte', 'standort', 'so', p.werte, { ortId: ortId });
    });
  };

  Daten.prototype.standortLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('standorte', id, STANDORT_FELDER).then(function (x) {
      if (!x) return null;
      return self.mitVerlaufLaden('orte', x.objekt.ortId, ORT_FELDER).then(function (o) {
        x.ort = o ? { id: x.objekt.ortId, name: o.aktuell.werte.bezeichnung } : { id: x.objekt.ortId, name: 'unbekannt' };
        return x;
      });
    });
  };

  Daten.prototype.standortAendern = function (id, roh) {
    var self = this;
    return this.standortLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Standort wurde nicht gefunden.' } };
      var p = self.pruefenStandort(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.standorteListe(x.objekt.ortId).then(function (liste) {
        if (gleicherName(liste, p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Diesen Standort gibt es an diesem Ort schon.' } };
        return self.mitVerlaufAendern('standort', id, x, p.werte, STANDORT_FELDER);
      });
    });
  };

  /* ----- Heimatstandort eines Fahrzeugs (mit Verlauf, nichts wird überschrieben) ----- */
  Daten.prototype.fahrzeugStandortSetzen = function (fahrzeugId, standortId) {
    var self = this;
    standortId = standortId || null;
    return Promise.all([this.pruefeObjekt(fahrzeugId, null), standortId ? this.speicher.holen('standorte', standortId) : Promise.resolve(true),
      this.speicher.wo('verlaeufe', 'objektId', fahrzeugId)]).then(function (r) {
      if (r[0]) return { ok: false, fehler: r[0] };
      if (!r[1]) return { ok: false, fehler: { standortId: 'Dieser Standort wurde nicht gefunden.' } };
      var alt = r[2].filter(function (e) { return e.objektTyp === 'fahrzeugstandort'; }).sort(nachNr);
      var letzter = alt[alt.length - 1] || null;
      var bisher = letzter ? letzter.werte.standortId : null;
      if (bisher === standortId) return { ok: true, id: fahrzeugId, geaendert: false };
      var e = neuerVerlaufEintrag('fahrzeugstandort', fahrzeugId, letzter ? letzter.nr + 1 : 1, { standortId: standortId }, letzter ? letzter.id : null, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: fahrzeugId, geaendert: true }; });
    });
  };

  /* Heimatstandort eines Fahrzeugs: { standort: {id, name, ortId, ortName} | null, verlauf: [{ ... }] } */
  Daten.prototype.fahrzeugStandort = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.speicher.wo('verlaeufe', 'objektId', fahrzeugId), this.standorteListe(), this.orteListe()]).then(function (r) {
      var alt = r[0].filter(function (e) { return e.objektTyp === 'fahrzeugstandort'; }).sort(nachNr);
      var namen = {};
      r[1].forEach(function (s) {
        var o = r[2].filter(function (x) { return x.objekt.id === s.objekt.ortId; })[0];
        namen[s.objekt.id] = { id: s.objekt.id, name: s.aktuell.werte.bezeichnung, ortId: s.objekt.ortId, ortName: o ? o.aktuell.werte.bezeichnung : 'unbekannt' };
      });
      function text(id) { return id ? (namen[id] ? namen[id].ortName + ', ' + namen[id].name : 'unbekannt') : 'keiner'; }
      var verlauf = alt.map(function (e, i) { return { eintrag: e, alt: i ? text(alt[i - 1].werte.standortId) : null, neu: text(e.werte.standortId) }; }).reverse();
      var letzter = alt[alt.length - 1];
      return { standort: letzter && letzter.werte.standortId && namen[letzter.werte.standortId] ? namen[letzter.werte.standortId] : null, verlauf: verlauf };
    });
  };

  /* ----- Gebiete ----- */
  Daten.prototype.gebieteListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('gebiete'), this.speicher.alle('verlaeufe'), this.speicher.alle('regeln')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'gebiet');
      var anzahl = {}; r[2].forEach(function (g) { anzahl[g.gebietId] = (anzahl[g.gebietId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlRegeln = anzahl[x.objekt.id] || 0; });
      return liste;
    });
  };

  Daten.prototype.gebietAnlegen = function (roh) {
    var self = this;
    var p = this.pruefenGebiet(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.gebieteListe().then(function (liste) {
      if (gleicherName(ohneOrtGebiete(liste), p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Dieses Gebiet gibt es schon.' } };
      return self.mitVerlaufAnlegen('gebiete', 'gebiet', 'ge', p.werte);
    });
  };

  Daten.prototype.gebietAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('gebiete', id, GEBIET_FELDER), this.gebieteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Gebiet wurde nicht gefunden.' } };
      var p = self.pruefenGebiet(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(ohneOrtGebiete(r[1]), p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Dieses Gebiet gibt es schon.' } };
      /* Ebene, Zugehörigkeit, Schlüssel, Ort und Herkunft kommen aus der Ortssuche und bleiben beim Umbenennen erhalten. */
      ['ebene', 'elternId', 'schluessel', 'ortId'].forEach(function (k) { if (x.aktuell.werte[k] !== undefined) p.werte[k] = x.aktuell.werte[k]; });
      /* Das Gebiet eines Ortes heißt wie der Ort. Umbenannt wird beim Ort. */
      if (x.aktuell.werte.ebene === 'ort') p.werte.bezeichnung = x.aktuell.werte.bezeichnung;
      if (x.aktuell.werte.herkunft) p.werte.herkunft = x.aktuell.werte.herkunft;
      return self.mitVerlaufAendern('gebiet', id, x, p.werte, GEBIET_FELDER);
    });
  };

  /* Ein Gebiet mit seinen Regeln. */
  Daten.prototype.gebietLaden = function (id) {
    return Promise.all([this.mitVerlaufLaden('gebiete', id, GEBIET_FELDER), this.regelnListe(id), this.gebieteListe(), this.orteListe()]).then(function (r) {
      if (!r[0]) return null;
      r[0].regeln = r[1];
      /* Das Gebiet eines Ortes (seit 2.0.42) verweist auf seinen Ort. */
      var ortId = r[0].aktuell.werte.ebene === 'ort' ? r[0].aktuell.werte.ortId : null;
      var ortX = ortId ? r[3].filter(function (o) { return o.objekt.id === ortId; })[0] : null;
      r[0].ort = ortX ? { id: ortId, name: ortX.aktuell.werte.bezeichnung } : null;
      /* Weg von oben und die Gebiete darunter (seit 2.0.39) */
      r[0].pfad = MM.Gebiete.pfad(r[2], id);
      r[0].unter = r[2].filter(function (x) { return x.aktuell.werte.elternId === id; }).map(function (x) { return { id: x.objekt.id, name: x.aktuell.werte.bezeichnung }; });
      return r[0];
    });
  };


  /* ---------- Ortssuche und Gebiete aus Orten (seit 2.0.39) ----------
   * Der Nutzer gibt nur Orte ein. Die Ortssuche liefert Treffer, aus dem gewählten Treffer entsteht die Kette
   * Land > Region > Kreis. Jedes Gebiet wird beim ersten Mal gespeichert und danach wiederverwendet. */
  Daten.prototype.ortSuchen = function (suche) { return MM.Ortssuche.suchen(suche, this.holeJson); };

  /* Baut die Kette. Was es schon gibt (gleicher Schlüssel), wird wiederverwendet. Ein eigenes Gebiet ohne Ebene mit dem
     gleichen Namen übernimmt die Ebene, seine Regeln bleiben. Nur Beschreibung, gespeichert wird später in einem Zug. */
  function gebietKetteBauen(self, liste, kette, jetzt) {
    var nachSchluessel = {}, frei = {};
    liste.forEach(function (x) {
      var w = x.aktuell.werte;
      if (w.schluessel) nachSchluessel[w.schluessel] = x;
      else if (!w.ebene) { var n = String(w.bezeichnung).toLowerCase(); (frei[n] = frei[n] || []).push(x); }
    });
    var speichern = [], ids = [], eltern = null, elternSchl = '', neu = 0, uebernommen = 0;
    kette.forEach(function (g) {
      var key = MM.Gebiete.schluessel(elternSchl, g.ebene, g.name, g.code), x = nachSchluessel[key], id;
      if (x) id = x.objekt.id;
      else {
        var f = (frei[String(g.name).toLowerCase()] || []).filter(function (y) { return !y.vergeben; })[0];
        if (f) {
          f.vergeben = true; id = f.objekt.id;
          var w2 = Object.assign({}, f.aktuell.werte, { ebene: g.ebene, elternId: eltern, schluessel: key });
          speichern.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('gebiet', id, f.aktuell.nr + 1, w2, f.aktuell.id, jetzt) });
          uebernommen++;
        } else {
          var o = { id: neueId('ge'), datenraumId: self.datenraumId, erstelltAm: jetzt };
          id = o.id;
          var w3 = { bezeichnung: g.name, notiz: null, ausgeblendet: 'nein', herkunft: 'ortssuche', ebene: g.ebene, elternId: eltern, schluessel: key };
          speichern.push({ tabelle: 'gebiete', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('gebiet', id, 1, w3, null, jetzt) });
          neu++;
        }
      }
      ids.push(id); eltern = id; elternSchl = key;
    });
    return { speichern: speichern, ids: ids, blatt: ids[ids.length - 1], neu: neu, uebernommen: uebernommen };
  }

  /* Ein Revier (Binnenwasserstraße) unter einem Land: vorhanden oder neu. */
  function revierSichern(self, liste, landId, name, jetzt) {
    var land = liste.filter(function (x) { return x.objekt.id === landId; })[0];
    var key = MM.Gebiete.schluessel(land ? land.aktuell.werte.schluessel : '', 'revier', name);
    var da = liste.filter(function (x) { return x.aktuell.werte.schluessel === key; })[0];
    if (da) return { id: da.objekt.id, speichern: [], neu: false };
    var o = { id: neueId('ge'), datenraumId: self.datenraumId, erstelltAm: jetzt };
    var w = { bezeichnung: name, notiz: null, ausgeblendet: 'nein', herkunft: 'eigen', ebene: 'revier', elternId: landId, schluessel: key };
    return { id: o.id, neu: true, speichern: [{ tabelle: 'gebiete', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('gebiet', o.id, 1, w, null, jetzt) }] };
  }

  /* Das Gebiet eines Ortes (Ebene „ort“, seit 2.0.42): die unterste Ebene der Kette (Land > Region > Kreis > Ort, Land > Revier > Ort).
     Es entsteht erst mit der ersten eigenen Regel des Ortes (anlegen = true). Name und Land ziehen mit dem Ort mit.
     Nur Beschreibung, gespeichert wird später in einem Zug. */
  function ortGebietAbgleichen(self, liste, ortId, name, landId, jetzt, anlegen) {
    var da = MM.Gebiete.ortGebiet(liste, ortId);
    if (da) {
      var w = da.aktuell.werte, neuName = name || w.bezeichnung, neuEltern = landId || w.elternId || null;
      if (w.bezeichnung === neuName && (w.elternId || null) === neuEltern) return { id: da.objekt.id, speichern: [], neu: false };
      var w2 = Object.assign({}, w, { bezeichnung: neuName, elternId: neuEltern });
      return { id: da.objekt.id, neu: false, speichern: [{ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('gebiet', da.objekt.id, da.aktuell.nr + 1, w2, da.aktuell.id, jetzt) }] };
    }
    if (!anlegen) return { id: null, speichern: [], neu: false };
    var o = { id: neueId('ge'), datenraumId: self.datenraumId, erstelltAm: jetzt };
    var w3 = { bezeichnung: name, notiz: null, ausgeblendet: 'nein', herkunft: 'eigen', ebene: 'ort', elternId: landId || null, schluessel: 'ort:' + ortId, ortId: ortId };
    return { id: o.id, neu: true, speichern: [{ tabelle: 'gebiete', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('gebiet', o.id, 1, w3, null, jetzt) }] };
  }

  var ORT_REGEL_OHNE_LAND = 'Eine eigene Regel gibt es erst, wenn der Ort geprüft ist, denn sie hängt unter dem Land des Ortes. Prüfe den Ort zuerst über die Ortssuche („Ort prüfen“).';

  /* Eine eigene Regel für einen Ort (seit 2.0.42). Der Ort wird zur untersten Ebene der Kette. Das Gebiet des Ortes entsteht mit der
     ersten Regel, vorher gibt es keins: Ohne eigene Regel gelten die Regeln der Ebenen darüber. Gebiet und Regel in einem Zug. */
  Daten.prototype.ortRegelAnlegen = function (ortId, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', ortId, ORT_FELDER), this.gebieteListe(), personenArtIds(this)]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var w = x.aktuell.werte, weg = w.gebietId ? MM.Gebiete.pfad(r[1], w.gebietId) : [];
      if (!weg.length || weg[0].ebene !== 'land') return { ok: false, fehler: { allgemein: ORT_REGEL_OHNE_LAND } };
      var p = self.pruefenRegel(roh, r[2]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var jetzt = self.jetzt();
      var g = ortGebietAbgleichen(self, r[1], ortId, w.bezeichnung, weg[0].id, jetzt, true);
      var rg = { id: neueId('rg'), datenraumId: self.datenraumId, erstelltAm: jetzt, gebietId: g.id };
      var liste = g.speichern.concat([{ tabelle: 'regeln', objekt: rg }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('regel', rg.id, 1, p.werte, null, jetzt) }]);
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: rg.id, gebietId: g.id, gebietNeu: g.neu }; });
    });
  };

  /* Die Kette sichern (ohne Ort), zum Beispiel für Tests oder später für den Reisecheck. */
  Daten.prototype.gebietKetteSichern = function (kette) {
    var self = this;
    return this.gebieteListe().then(function (liste) {
      var b = gebietKetteBauen(self, liste, kette, self.jetzt());
      var fertig = { ok: true, ids: b.ids, blatt: b.blatt, neu: b.neu, uebernommen: b.uebernommen };
      return b.speichern.length ? self.speicher.mehrereSpeichern(b.speichern).then(function () { return fertig; }) : fertig;
    });
  };

  /* Aus einem gewählten Treffer der Ortssuche entsteht ein neuer Ort mit seinem Gebiet. Gibt es den Namen schon, hängt die
     App das Gebiet an („Eutingen (Enzkreis)“), damit zwei Orte gleichen Namens nebeneinander bestehen. */
  Daten.prototype.ortAusTreffer = function (k) {
    var self = this;
    if (!k || !k.name || !k.land) return Promise.resolve({ ok: false, fehler: { allgemein: 'Der Treffer ist unvollständig.' } });
    return Promise.all([this.gebieteListe(), this.orteListe()]).then(function (r) {
      var b = gebietKetteBauen(self, r[0], MM.Ortssuche.kette(k), self.jetzt());
      var bestehende = r[1].filter(function (o) { return o.aktuell.werte.gebietId === b.blatt && o.aktuell.werte.bezeichnung.toLowerCase().indexOf(k.name.toLowerCase()) === 0
        && typeof o.aktuell.werte.positionBreite === 'number' && Math.abs(o.aktuell.werte.positionBreite - k.breite) < 0.02 && Math.abs(o.aktuell.werte.positionLaenge - k.laenge) < 0.02; })[0];
      if (bestehende) return { ok: true, id: bestehende.objekt.id, vorhanden: true, name: bestehende.aktuell.werte.bezeichnung };
      var name = k.name;
      if (gleicherName(r[1], name)) name = k.name + ' (' + (k.kreis || k.region || k.land) + ')';
      if (gleicherName(r[1], name)) name = k.name + ' (' + [k.kreis, k.region, k.land].filter(Boolean).join(', ') + ')';
      if (gleicherName(r[1], name)) return { ok: false, fehler: { allgemein: 'Diesen Ort gibt es schon.' } };
      var p = self.pruefenOrt({ bezeichnung: name, land: k.land, positionBreite: k.breite, positionLaenge: k.laenge });
      if (!p.ok) return { ok: false, fehler: p.fehler };
      p.werte.gebietId = b.blatt; p.werte.revierId = null; p.werte.ortGeprueft = 'ja';
      var jetzt = self.jetzt(), o = { id: neueId('or'), datenraumId: self.datenraumId, erstelltAm: jetzt };
      var liste = b.speichern.concat([{ tabelle: 'orte', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ort', o.id, 1, p.werte, null, jetzt) }]);
      return self.speicher.mehrereSpeichern(liste).then(function () {
        return { ok: true, id: o.id, vorhanden: false, name: name, gebiete: { neu: b.neu, uebernommen: b.uebernommen, ids: b.ids } };
      });
    });
  };

  /* Einen schon vorhandenen Ort nachträglich prüfen: der gewählte Treffer gibt ihm das Gebiet. Name, Notizen und Kosten bleiben,
     Land und Position werden nur ergänzt, wenn sie fehlen. */
  Daten.prototype.ortPruefungUebernehmen = function (id, k) {
    var self = this;
    if (!k || !k.name || !k.land) return Promise.resolve({ ok: false, fehler: { allgemein: 'Der Treffer ist unvollständig.' } });
    return Promise.all([this.mitVerlaufLaden('orte', id, ORT_FELDER), this.gebieteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var b = gebietKetteBauen(self, r[1], MM.Ortssuche.kette(k), self.jetzt());
      var neu = Object.assign({}, x.aktuell.werte);
      neu.gebietId = b.blatt; neu.ortGeprueft = 'ja';
      if (!neu.land) neu.land = k.land;
      if (typeof neu.positionBreite !== 'number' || typeof neu.positionLaenge !== 'number') { neu.positionBreite = k.breite; neu.positionLaenge = k.laenge; }
      /* Ein Revier gilt nur unter seinem Land. Wechselt das Land, fällt das Revier weg. */
      if (neu.revierId) {
        var rv = r[1].filter(function (g) { return g.objekt.id === neu.revierId; })[0];
        if (!rv || rv.aktuell.werte.elternId !== b.ids[0]) neu.revierId = null;
      }
      /* Hat der Ort eigene Regeln, hängt sein Gebiet nun unter dem neuen Land (seit 2.0.42). */
      var og = ortGebietAbgleichen(self, r[1], id, neu.bezeichnung, b.ids[0], self.jetzt(), false);
      return ortAenderungSpeichern(self, id, x, neu, b.speichern.concat(og.speichern)).then(function (res) {
        res.gebiete = { neu: b.neu, uebernommen: b.uebernommen, ids: b.ids };
        return res;
      });
    });
  };

  /* Welche Arten von Fahrzeugen gibt es im Konto? ['land', 'wasser', 'luft'] */
  Daten.prototype.kontoWelten = function () {
    return this.fahrzeugListe().then(function (liste) {
      var w = [];
      liste.forEach(function (x) { var a = MM.Fahrzeugarten.art(x.fahrzeug.art); var welt = a ? a.welt : 'land'; if (w.indexOf(welt) < 0) w.push(welt); });
      return w;
    });
  };

  /* Die Reviere unter einem Land (für die Vorschlagsliste beim Ort). */
  Daten.prototype.reviereZuLand = function (landId) {
    return this.gebieteListe().then(function (liste) {
      return liste.filter(function (x) { return x.aktuell.werte.ebene === 'revier' && x.aktuell.werte.elternId === landId && x.aktuell.werte.ausgeblendet !== 'ja'; })
        .map(function (x) { return x.aktuell.werte.bezeichnung; });
    });
  };

  /* ----- Regeln: WENN Gebiet, Fahrzeugart und Ausrüstung passen, DANN genügt einer der Nachweise ----- */
  function fahrzeugArtIds() { return MM.Fahrzeugarten.alle(true).map(function (a) { return a.id; }); }

  Daten.prototype.pruefenRegel = function (roh, personenArten) {
    roh = roh || {};
    var f = {}, w = {};
    w.bezeichnung = trimmed(roh.bezeichnung);
    if (!w.bezeichnung) f.bezeichnung = 'Bitte eine Bezeichnung eingeben, zum Beispiel „Funkzeugnis auf See“.';
    var fa = Array.isArray(roh.fahrzeugArten) ? roh.fahrzeugArten : [];
    w.fahrzeugArten = fahrzeugArtIds().filter(function (a) { return fa.indexOf(a) >= 0; });
    w.art = MM.Orte.regelArt(roh);
    if (w.art === 'ausruestung') {
      /* Pflichtausrüstung: Was muss am Fahrzeug eingetragen sein? Eine Bedingung „Ausrüstung“ und Nachweise gibt es hier nicht. */
      w.pflichtAusruestung = trimmed(roh.pflichtAusruestung) || null;
      if (!w.pflichtAusruestung) f.pflichtAusruestung = 'Bitte eintragen, was am Fahrzeug sein muss, zum Beispiel „Rettungsweste“.';
      w.ausruestung = null;
      w.artIds = [];
      /* Menge (ganze Zahl ab 1, leer = 1), Bezugsgröße und freiwillig die geforderte Eignung */
      var mt = String(roh.menge === undefined || roh.menge === null ? '' : roh.menge).trim();
      if (mt === '') { w.menge = 1; }
      else if (!/^\d+$/.test(mt) || Number(mt) < 1) { w.menge = 1; f.menge = 'Bitte eine ganze Zahl ab 1 eingeben, zum Beispiel 6.'; }
      else { w.menge = Number(mt); }
      w.bezug = MM.Orte.bezugsgroesse(roh);
      w.eignung = trimmed(roh.eignung) || null;
    } else {
      w.pflichtAusruestung = null;
      w.menge = null; w.bezug = null; w.eignung = null;
      w.ausruestung = trimmed(roh.ausruestung) || null;
      var gew = Array.isArray(roh.artIds) ? roh.artIds : [];
      w.artIds = personenArten.filter(function (a) { return gew.indexOf(a) >= 0; });
      if (!w.artIds.length) f.artIds = 'Bitte mindestens eine Art von Nachweis wählen, die genügt.';
    }
    w.gilt = roh.gilt === 'nein' ? 'nein' : 'ja';
    w.herkunft = 'eigen';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.regelAnlegen = function (gebietId, roh) {
    var self = this;
    return Promise.all([this.speicher.holen('gebiete', gebietId), personenArtIds(this)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieses Gebiet wurde nicht gefunden.' } };
      var p = self.pruefenRegel(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAnlegen('regeln', 'regel', 'rg', p.werte, { gebietId: gebietId });
    });
  };

  Daten.prototype.regelAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.regelLaden(id), personenArtIds(this)]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Regel wurde nicht gefunden.' } };
      if (!x.aktuell.werte.art) x.aktuell.werte = Object.assign({ art: 'befaehigung' }, x.aktuell.werte);
      if (x.aktuell.werte.art === 'ausruestung') x.aktuell.werte = Object.assign({ menge: 1, bezug: 'fahrzeug', eignung: null }, x.aktuell.werte);
      else x.aktuell.werte = Object.assign({ menge: null, bezug: null, eignung: null }, x.aktuell.werte);
      var p = self.pruefenRegel(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('regel', id, x, p.werte, REGEL_FELDER);
    });
  };

  Daten.prototype.regelLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('regeln', id, REGEL_FELDER).then(function (x) {
      if (!x) return null;
      return Promise.all([self.nachweisartenListe('person'), self.mitVerlaufLaden('gebiete', x.objekt.gebietId, GEBIET_FELDER)]).then(function (r) {
        var namen = {}; r[0].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        function arten(l) { return (l || []).map(function (a) { var z = MM.Fahrzeugarten.art(a); return z ? z.name : a; }).join(', ') || null; }
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artIds') { u.feld = { typ: 'text' }; u.alt = (u.alt || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null; u.neu = (u.neu || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null; }
            if (u.key === 'fahrzeugArten') { u.feld = { typ: 'text' }; u.alt = arten(u.alt); u.neu = arten(u.neu); }
            if (u.key === 'bezug') { u.feld = { typ: 'text' }; u.alt = u.alt ? (u.alt === 'person' ? 'je Person an Bord' : 'je Fahrzeug') : null; u.neu = u.neu ? (u.neu === 'person' ? 'je Person an Bord' : 'je Fahrzeug') : null; }
            if (u.key === 'art') { u.feld = { typ: 'text' }; u.alt = u.alt ? (u.alt === 'ausruestung' ? 'Pflichtausrüstung' : 'Befähigung') : 'Befähigung'; u.neu = u.neu === 'ausruestung' ? 'Pflichtausrüstung' : 'Befähigung'; }
          });
        });
        x.arten = r[0]; x.namen = namen;
        x.gebiet = { id: x.objekt.gebietId, name: r[1] ? r[1].aktuell.werte.bezeichnung : 'unbekannt', ortId: r[1] && r[1].aktuell.werte.ebene === 'ort' ? r[1].aktuell.werte.ortId || null : null };
        return x;
      });
    });
  };

  /* Regeln eines Gebiets (oder aller), mit Namen der Nachweisarten. */
  Daten.prototype.regelnListe = function (gebietId) {
    var self = this;
    return Promise.all([this.speicher.alle('regeln'), this.speicher.alle('verlaeufe'), this.nachweisartenListe('person')]).then(function (r) {
      var rec = gebietId ? r[0].filter(function (g) { return g.gebietId === gebietId; }) : r[0];
      var namen = {}; r[2].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      return sammle(self, rec, r[1], 'regel').map(function (x) {
        x.artNamen = x.aktuell.werte.artIds.map(function (i) { return namen[i] || 'unbekannte Art'; });
        x.fahrzeugArtNamen = (x.aktuell.werte.fahrzeugArten || []).map(function (a) { var z = MM.Fahrzeugarten.art(a); return z ? z.name : a; });
        return x;
      });
    });
  };

  /* ---------- Aktivitäten ---------- */
  var AKT_FELDER = [
    { key: 'bezeichnung', label: 'Name' },
    { key: 'artId', label: 'Art', typ: 'text' },
    { key: 'fahrzeugId', label: 'Fahrzeug', typ: 'text' },
    { key: 'vonDatum', label: 'Von (Datum)', typ: 'datum' },
    { key: 'vonZeit', label: 'Von (Uhrzeit)', typ: 'zeit' },
    { key: 'bisDatum', label: 'Bis (Datum)', typ: 'datum' },
    { key: 'bisZeit', label: 'Bis (Uhrzeit)', typ: 'zeit' },
    { key: 'gebiet', label: 'Gebiet (Text)', typ: 'text' },
    { key: 'gebietId', label: 'Gebiet', typ: 'text' },
    { key: 'geplanteStrecke', label: 'Geplante Strecke', typ: 'zahl' },
    { key: 'geplanteStunden', label: 'Geplante Betriebsstunden', typ: 'zahl' },
    { key: 'startOrtId', label: 'Start', typ: 'text' },
    { key: 'zielOrtId', label: 'Ziel', typ: 'text' },
    { key: 'zwischenzielIds', label: 'Zwischenziele', typ: 'mehrfach' },
    { key: 'tierIds', label: 'Tiere', typ: 'mehrfach' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'status', label: 'Status', typ: 'text' },
    { key: 'stornoGrund', label: 'Grund der Stornierung', typ: 'text' },
    { key: 'sperreUebergangenAm', label: 'Sperre übergangen am', typ: 'text' }
  ];

  Daten.prototype.aktivitaetKontext = function () {
    return Promise.all([this.aktivitaetsartenListe(), this.fahrzeugListe(), this.tiereListe(), this.personenListe(), this.gebieteListe(), this.orteListe()]).then(function (r) {
      return { arten: r[0], fahrzeuge: r[1], tiere: r[2], personen: r[3], gebiete: r[4], orte: r[5] };
    });
  };

  function planOrtOptionen(ctx, gewaehlt) {
    return (ctx.orte || []).filter(function (o) { return o.aktuell.werte.ausgeblendet !== 'ja' || gewaehlt.indexOf(o.objekt.id) >= 0; })
      .map(function (o) { return { wert: o.objekt.id, label: o.aktuell.werte.bezeichnung }; });
  }

  Daten.prototype.pruefenAktivitaet = function (roh, ctx, neu) {
    roh = roh || {};
    var gewaehlteArt = roh.artId;
    var felder = [
      { key: 'artId', typ: 'auswahl', optionen: ctx.arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || a.objekt.id === gewaehlteArt; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; }) },
      { key: 'fahrzeugId', typ: 'auswahl', optionen: ctx.fahrzeuge.map(function (x) { return { wert: x.fahrzeug.id, label: x.aktuell.werte.bezeichnung }; }) },
      { key: 'vonDatum', typ: 'datum' }, { key: 'vonZeit', typ: 'zeit' }, { key: 'bisDatum', typ: 'datum' }, { key: 'bisZeit', typ: 'zeit' },
      { key: 'gebiet', typ: 'text' },
      { key: 'gebietId', typ: 'auswahl', optionen: (ctx.gebiete || []).filter(function (g) { return g.aktuell.werte.ausgeblendet !== 'ja' || g.objekt.id === roh.gebietId; })
        .map(function (g) { return { wert: g.objekt.id, label: g.aktuell.werte.bezeichnung }; }) },
      { key: 'geplanteStrecke', typ: 'zahl', min: 0 }, { key: 'geplanteStunden', typ: 'zahl', min: 0 },
      /* Reiseplan (seit 2.0.28): Start, Ziel und Zwischenziele sind Orte aus der Orte-Liste. Ausgeblendete Orte bleiben nur, wenn sie schon gewählt waren. */
      { key: 'startOrtId', typ: 'auswahl', optionen: planOrtOptionen(ctx, [roh.startOrtId]) },
      { key: 'zielOrtId', typ: 'auswahl', optionen: planOrtOptionen(ctx, [roh.zielOrtId]) },
      { key: 'zwischenzielIds', typ: 'mehrfach', optionen: planOrtOptionen(ctx, Array.isArray(roh.zwischenzielIds) ? roh.zwischenzielIds : []) },
      { key: 'tierIds', typ: 'mehrfach', optionen: ctx.tiere.map(function (t) { return { wert: t.objekt.id, label: t.aktuell.werte.bezeichnung }; }) },
      { key: 'notiz', typ: 'text' }
    ];
    var p = pruefeWerte(felder, roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen für die Aktivität eingeben, zum Beispiel „Sommertörn Kroatien“.' });
    var w = p.werte, f = p.fehler;
    if (!w.artId && !f.artId) f.artId = ctx.arten.length ? 'Bitte die Art der Aktivität wählen.' : 'Es gibt noch keine Art. Übernimm zuerst die Vorschläge oder lege eine Art an.';
    if (!w.fahrzeugId && !f.fahrzeugId) f.fahrzeugId = ctx.fahrzeuge.length ? 'Bitte das Fahrzeug wählen.' : 'Es gibt noch kein Fahrzeug. Lege zuerst ein Fahrzeug an.';
    if (!w.vonDatum && !f.vonDatum) f.vonDatum = 'Bitte das Datum angeben, an dem es losgeht.';
    if (!w.bisDatum && !f.bisDatum) f.bisDatum = 'Bitte das Datum angeben, an dem es endet.';
    if (w.vonDatum && w.bisDatum && !f.bisDatum) {
      if (w.bisDatum < w.vonDatum) f.bisDatum = 'Das Ende liegt vor dem Beginn.';
      else if (w.bisDatum === w.vonDatum && w.vonZeit && w.bisZeit && w.bisZeit < w.vonZeit && !f.bisZeit) f.bisZeit = 'Die Uhrzeit des Endes liegt vor der des Beginns.';
    }
    if (neu) {
      var pid = roh.verantwortlichId;
      if (!ctx.personen.some(function (x) { return x.objekt.id === pid; })) {
        f.verantwortlichId = ctx.personen.length ? 'Bitte wählen, wer verantwortlich ist.' : 'Es gibt noch keine Person. Lege zuerst die Besatzung an.';
      }
    }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.aktivitaetAnlegen = function (roh) {
    var self = this;
    return this.aktivitaetKontext().then(function (ctx) {
      var p = self.pruefenAktivitaet(roh, ctx, true);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var w = p.werte, jetzt = self.jetzt();
      w.status = 'geplant'; w.stornoGrund = null; w.stornoAm = null; w.sperreUebergangenAm = null;
      var a = { id: neueId('ak'), datenraumId: self.datenraumId, erstelltAm: jetzt };
      var b = { id: neueId('be'), aktivitaetId: a.id, personId: roh.verantwortlichId, erstelltAm: jetzt };
      var v = { id: neueId('ve'), aktivitaetId: a.id, personId: roh.verantwortlichId, ab: MM.Aktivitaeten.von(w), erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'aktivitaeten', objekt: a },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('aktivitaet', a.id, 1, w, null, jetzt) },
        { tabelle: 'besatzung', objekt: b },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besatzung', b.id, 1, { rolle: 'verantwortlich', dabeiVonDatum: null, dabeiVonZeit: null, dabeiBisDatum: null, dabeiBisZeit: null, entfernt: 'nein' }, null, jetzt) },
        { tabelle: 'verantwortung', objekt: v }
      ]).then(function () { return { ok: true, id: a.id }; });
    });
  };

  Daten.prototype.aktivitaetAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(id), this.aktivitaetKontext()]).then(function (r) {
      var x = r[0], ctx = r[1];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (x.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenAktivitaet(roh, ctx, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var alt = x.aktuell.werte;
      var neu = Object.assign({}, alt, p.werte);
      var zeitraumGeaendert = ['fahrzeugId', 'vonDatum', 'vonZeit', 'bisDatum', 'bisZeit', 'geplanteStrecke', 'geplanteStunden'].some(function (k) { return !gleich(alt[k], neu[k]); });
      if (zeitraumGeaendert) neu.sperreUebergangenAm = null;
      return self.mitVerlaufAendern('aktivitaet', id, { aktuell: x.aktuell }, neu, AKT_FELDER);
    });
  };

  function aktivitaetNeuerStand(self, id, aenderung) {
    return self.mitVerlaufLaden('aktivitaeten', id, []).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var neu = aenderung(Object.assign({}, x.aktuell.werte));
      if (neu.fehler) return { ok: false, fehler: neu.fehler };
      return self.mitVerlaufAendern('aktivitaet', id, { aktuell: x.aktuell }, neu.werte, AKT_FELDER);
    });
  }

  /* Stornieren: Nichts wird gelöscht, der Status heißt "storniert". */
  Daten.prototype.aktivitaetStornieren = function (id, grund) {
    var self = this;
    return aktivitaetNeuerStand(this, id, function (w) {
      if (w.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist schon storniert.' } };
      w.status = 'storniert'; w.stornoGrund = trimmed(grund) || null; w.stornoAm = self.jetzt();
      return { werte: w };
    });
  };
  Daten.prototype.aktivitaetWiederherstellen = function (id) {
    return aktivitaetNeuerStand(this, id, function (w) {
      if (w.status !== 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist nicht storniert.' } };
      w.status = 'geplant'; w.stornoGrund = null; w.stornoAm = null;
      return { werte: w };
    });
  };
  /* Eine Sperre durch eine Frist ausdrücklich übergehen. Zeit wird festgehalten. */
  Daten.prototype.aktivitaetSperreUebergehen = function (id) {
    var self = this;
    return aktivitaetNeuerStand(this, id, function (w) { w.sperreUebergangenAm = self.jetzt(); return { werte: w }; });
  };

  /* ---------- Besatzung und Verantwortung ---------- */
  var BES_FELDER = [
    { key: 'rolle', label: 'Rolle', typ: 'text' },
    { key: 'dabeiVonDatum', label: 'Dabei von (Datum)', typ: 'datum' }, { key: 'dabeiVonZeit', label: 'Dabei von (Uhrzeit)', typ: 'zeit' },
    { key: 'dabeiBisDatum', label: 'Dabei bis (Datum)', typ: 'datum' }, { key: 'dabeiBisZeit', label: 'Dabei bis (Uhrzeit)', typ: 'zeit' },
    { key: 'entfernt', label: 'Nicht mehr dabei', typ: 'text' }
  ];

  Daten.prototype.pruefenBesatzung = function (roh) {
    roh = roh || {};
    var felder = [{ key: 'dabeiVonDatum', typ: 'datum' }, { key: 'dabeiVonZeit', typ: 'zeit' }, { key: 'dabeiBisDatum', typ: 'datum' }, { key: 'dabeiBisZeit', typ: 'zeit' }];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    var rolle = roh.rolle;
    if (rolle !== 'stellvertreter' && rolle !== 'crew' && rolle !== 'verantwortlich') f.rolle = 'Bitte wählen: Stellvertreter oder Crew.';
    else w.rolle = rolle;
    if (w.dabeiVonDatum && w.dabeiBisDatum && w.dabeiBisDatum < w.dabeiVonDatum && !f.dabeiBisDatum) f.dabeiBisDatum = 'Das Ende liegt vor dem Beginn.';
    w.entfernt = roh.entfernt === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Wer hängt gerade an der Verantwortung (letzter Eintrag der Verantwortung)? */
  function letzteVerantwortung(eintraege) {
    return eintraege.slice().sort(function (a, b) { return a.ab < b.ab ? -1 : (a.ab > b.ab ? 1 : 0); }).pop() || null;
  }

  Daten.prototype.besatzungHinzufuegen = function (aktivitaetId, personId, roh) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.personLaden(personId)]).then(function (r) {
      var a = r[0], person = r[1];
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (!person) return { ok: false, fehler: { personId: 'Bitte eine Person wählen.' } };
      var p = self.pruefenBesatzung(roh);
      if (p.werte.rolle === 'verantwortlich') p.fehler.rolle = 'Die verantwortliche Person wird über „Verantwortung wechseln“ bestimmt.';
      if (Object.keys(p.fehler).length) return { ok: false, fehler: p.fehler };
      var vorhanden = a.besatzung.concat(a.entfernte).filter(function (b) { return b.besatzung.personId === personId; })[0];
      if (vorhanden && vorhanden.aktuell.werte.entfernt !== 'ja') return { ok: false, fehler: { personId: 'Diese Person ist schon dabei.' } };
      if (vorhanden) {
        /* Wieder aufnehmen: neuer Eintrag, die frühere Zeit bleibt sichtbar */
        return self.mitVerlaufAendern('besatzung', vorhanden.besatzung.id, { aktuell: vorhanden.aktuell }, p.werte, BES_FELDER)
          .then(function (res) { res.id = vorhanden.besatzung.id; return res; });
      }
      var jetzt = self.jetzt();
      var b = { id: neueId('be'), aktivitaetId: aktivitaetId, personId: personId, erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'besatzung', objekt: b }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besatzung', b.id, 1, p.werte, null, jetzt) }
      ]).then(function () { return { ok: true, id: b.id }; });
    });
  };

  Daten.prototype.besatzungAendern = function (besatzungId, roh) {
    var self = this;
    return this.speicher.holen('besatzung', besatzungId).then(function (b) {
      if (!b) return { ok: false, fehler: { allgemein: 'Dieser Eintrag wurde nicht gefunden.' } };
      return Promise.all([self.mitVerlaufLaden('besatzung', besatzungId, BES_FELDER), self.speicher.wo('verantwortung', 'aktivitaetId', b.aktivitaetId)]).then(function (r) {
        var x = r[0], letzte = letzteVerantwortung(r[1]);
        var p = self.pruefenBesatzung(roh);
        var gleichBleibt = x.aktuell.werte.rolle === 'verantwortlich' && roh.rolle === 'verantwortlich';
        if (p.werte.rolle === 'verantwortlich' && !gleichBleibt) p.fehler.rolle = 'Die verantwortliche Person wird über „Verantwortung wechseln“ bestimmt.';
        if (Object.keys(p.fehler).length) return { ok: false, fehler: p.fehler };
        var istLetzter = letzte && letzte.personId === b.personId;
        if (istLetzter && (p.werte.entfernt === 'ja' || p.werte.rolle === 'crew')) {
          return { ok: false, fehler: { allgemein: 'Diese Person ist zuletzt als verantwortlich eingetragen. Wechsle zuerst die Verantwortung auf eine andere Person.' } };
        }
        return self.mitVerlaufAendern('besatzung', besatzungId, x, p.werte, BES_FELDER).then(function (res) { res.id = besatzungId; return res; });
      });
    });
  };

  /* Verantwortung ab einem Zeitpunkt auf eine andere Person übertragen. Nur Skipper/Fahrer und Stellvertreter. */
  Daten.prototype.verantwortungWechseln = function (aktivitaetId, personId, roh) {
    var self = this;
    roh = roh || {};
    var p = pruefeWerte([{ key: 'abDatum', typ: 'datum' }, { key: 'abZeit', typ: 'zeit' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var f = p.fehler, w = p.werte;
    if (!w.abDatum && !f.abDatum) f.abDatum = 'Bitte das Datum des Wechsels angeben.';
    if (!w.abZeit && !f.abZeit) f.abZeit = 'Bitte die Uhrzeit des Wechsels angeben.';
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var dabei = a.besatzung.filter(function (b) { return b.besatzung.personId === personId && (b.aktuell.werte.rolle === 'verantwortlich' || b.aktuell.werte.rolle === 'stellvertreter'); })[0];
      if (!dabei) return { ok: false, fehler: { personId: 'Verantwortlich kann nur sein, wer als ' + MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt) + ' oder Stellvertreter dabei ist.' } };
      var ab = w.abDatum + 'T' + w.abZeit;
      var letzte = letzteVerantwortung(a.verantwortung);
      if (letzte && ab <= letzte.ab) return { ok: false, fehler: { abDatum: 'Der Wechsel muss nach dem letzten Wechsel liegen (' + letzte.ab.replace('T', ', ') + ' Uhr).' } };
      if (letzte && letzte.personId === personId) return { ok: false, fehler: { personId: 'Diese Person ist schon verantwortlich.' } };
      if (a.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      /* Beim Wechsel prüft die App die Befähigung der übernehmenden Person und hält das Ergebnis mit „geprüft am“ fest.
         Sie weist nur hin und sperrt den Wechsel nicht. Liegt der Zeitpunkt mehr als 5 Minuten vor jetzt, ist es ein Nachtrag. */
      return self.aktivitaetPruefung(aktivitaetId).then(function (pr) {
        var pruefung = MM.Logbuch.wechselPruefungFestgehalten(pr, personId);
        var nachgetragen = MM.Logbuch.zeitpunktArt(w.abDatum, w.abZeit, self.jetztLokal()) === 'nachtrag';
        var jetzt = self.jetzt();
        var v = { id: neueId('ve'), aktivitaetId: aktivitaetId, personId: personId, ab: ab, erstelltAm: jetzt };
        if (pruefung) v.pruefung = pruefung;
        if (nachgetragen) v.nachgetragenAm = jetzt;
        return self.speicher.speichern('verantwortung', v).then(function () { return { ok: true, id: aktivitaetId, verantwortungId: v.id, pruefung: pruefung || null, nachgetragen: nachgetragen }; });
      });
    });
  };

  /* ---------- Aktivität laden, listen, prüfen ---------- */
  Daten.prototype.aktivitaetLaden = function (id) {
    var self = this;
    return this.speicher.holen('aktivitaeten', id).then(function (a) {
      if (!a) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id), self.speicher.wo('besatzung', 'aktivitaetId', id), self.speicher.alle('verlaeufe'),
        self.speicher.wo('verantwortung', 'aktivitaetId', id), self.personenListe(), self.tiereListe(), self.aktivitaetsartenListe(), self.fahrzeugListe({ alle: true }), self.gebieteListe(), self.orteListe()
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length) return null;
        var aktuell = eintraege[eintraege.length - 1], w = aktuell.werte;
        var personen = {}; r[4].forEach(function (p) { personen[p.objekt.id] = p.aktuell.werte.bezeichnung; });
        var tiere = {}; r[5].forEach(function (t) { tiere[t.objekt.id] = t.aktuell.werte.bezeichnung; });
        var arten = {}; r[6].forEach(function (x) { arten[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var gebiete = {}; r[8].forEach(function (x) { gebiete[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var orteNamen = {}; r[9].forEach(function (x) { orteNamen[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var fz = r[7].filter(function (x) { return x.fahrzeug.id === w.fahrzeugId; })[0] || null;
        var welt = fz ? MM.Fahrzeugarten.art(fz.fahrzeug.art).welt : 'land';
        /* Gebiete aus den Orten der Aktivität (seit 2.0.39): Start, Ziel und Zwischenziele; welche Ebenen zählen, bestimmt das Fahrzeug. */
        var planIds = [w.startOrtId].concat(w.zwischenzielIds || [], [w.zielOrtId]).filter(Boolean);
        var planOrte = planIds.filter(function (i, n) { return planIds.indexOf(i) === n; }).map(function (i) {
          var o = r[9].filter(function (x) { return x.objekt.id === i; })[0];
          return o ? { id: i, name: o.aktuell.werte.bezeichnung, werte: o.aktuell.werte } : null;
        }).filter(Boolean);
        var ortGebiete = MM.Gebiete.kettenAusOrten({ gebiete: r[8], orte: planOrte, welt: welt });

        var verl = {}; r[2].forEach(function (e) { if (e.objektTyp === 'besatzung') (verl[e.objektId] = verl[e.objektId] || []).push(e); });
        var alleB = r[1].map(function (b) {
          var l = (verl[b.id] || []).slice().sort(nachNr);
          var ak = l[l.length - 1];
          return ak ? { besatzung: b, aktuell: ak, person: { id: b.personId, name: personen[b.personId] || 'unbekannt' }, rolleText: MM.Aktivitaeten.rolleLabel(ak.werte.rolle, welt) } : null;
        }).filter(Boolean);
        var reihenfolge = { verantwortlich: 0, stellvertreter: 1, crew: 2 };
        alleB.sort(function (x, y) { return reihenfolge[x.aktuell.werte.rolle] - reihenfolge[y.aktuell.werte.rolle] || x.person.name.localeCompare(y.person.name, 'de'); });
        var aktiv = alleB.filter(function (b) { return b.aktuell.werte.entfernt !== 'ja'; });
        var entfernt = alleB.filter(function (b) { return b.aktuell.werte.entfernt === 'ja'; });

        /* Korrekturen der Wechsel (Verlauf der Verantwortung): der neueste Stand gilt, der ursprüngliche Zeitpunkt bleibt sichtbar. */
        var vv = {}; r[2].forEach(function (e) { if (e.objektTyp === 'verantwortung') (vv[e.objektId] = vv[e.objektId] || []).push(e); });
        var ver = r[3].map(function (v) {
          var l = (vv[v.id] || []).slice().sort(nachNr), k = l[l.length - 1];
          return { id: v.id, personId: v.personId, name: personen[v.personId] || 'unbekannt',
            ab: k ? k.werte.abDatum + 'T' + k.werte.abZeit : v.ab, abUrspruenglich: v.ab, erstelltAm: v.erstelltAm,
            notiz: k ? (k.werte.notiz || null) : null, ausgeblendet: k ? (k.werte.ausgeblendet || 'nein') : 'nein', geaendert: !!k,
            nachgetragenAm: v.nachgetragenAm || null, pruefung: v.pruefung || null };
        }).sort(function (x, y) { return x.ab < y.ab ? -1 : (x.ab > y.ab ? 1 : 0); });
        var jetzt = self.jetztLokal();
        var gerade = MM.Aktivitaeten.verantwortlicher(ver, jetzt);

        var verlauf = verlaufAus(eintraege, AKT_FELDER);
        verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            function wandeln(m, wert) { return wert ? m[wert] || 'unbekannt' : null; }
            if (u.key === 'artId') { u.feld = { typ: 'text' }; u.alt = wandeln(arten, u.alt); u.neu = wandeln(arten, u.neu); }
            if (u.key === 'fahrzeugId') { u.feld = { typ: 'text' }; u.alt = u.alt ? self.fahrzeugName(r[7], u.alt) : null; u.neu = u.neu ? self.fahrzeugName(r[7], u.neu) : null; }
            if (u.key === 'tierIds') { u.feld = { typ: 'text' }; u.alt = (u.alt || []).map(function (i) { return tiere[i] || 'unbekannt'; }).join(', ') || null; u.neu = (u.neu || []).map(function (i) { return tiere[i] || 'unbekannt'; }).join(', ') || null; }
            if (u.key === 'gebietId') { u.feld = { typ: 'text' }; u.alt = wandeln(gebiete, u.alt); u.neu = wandeln(gebiete, u.neu); }
            if (u.key === 'startOrtId' || u.key === 'zielOrtId') { u.feld = { typ: 'text' }; u.alt = wandeln(orteNamen, u.alt); u.neu = wandeln(orteNamen, u.neu); }
            if (u.key === 'zwischenzielIds') { u.feld = { typ: 'text' }; u.alt = (u.alt || []).map(function (i) { return orteNamen[i] || 'unbekannt'; }).join(', ') || null; u.neu = (u.neu || []).map(function (i) { return orteNamen[i] || 'unbekannt'; }).join(', ') || null; }
            if (u.key === 'sperreUebergangenAm' || u.key === 'status') { u.feld = { typ: 'text' }; }
          });
        });
        return { aktivitaet: a, aktuell: aktuell, verlauf: verlauf, ortGebiete: ortGebiete, gebiet: w.gebietId ? { id: w.gebietId, name: gebiete[w.gebietId] || 'unbekannt' } : null, art: w.artId ? { id: w.artId, name: arten[w.artId] || 'unbekannt' } : null,
          fahrzeug: fz ? { id: fz.fahrzeug.id, name: fz.aktuell.werte.bezeichnung, artId: fz.fahrzeug.art, welt: welt } : { id: w.fahrzeugId, name: 'unbekannt', artId: null, welt: 'land' },
          besatzung: aktiv, entfernte: entfernt, verantwortung: ver, verantwortlichJetzt: gerade,
          tiere: (w.tierIds || []).map(function (i) { return { id: i, name: tiere[i] || 'unbekannt' }; }), status: MM.Aktivitaeten.status(w, jetzt),
          /* Reiseplan (seit 2.0.28): Start, Ziel und Zwischenziele mit Namen, null wenn nicht gewählt */
          startOrt: w.startOrtId ? { id: w.startOrtId, name: orteNamen[w.startOrtId] || 'unbekannt' } : null,
          zielOrt: w.zielOrtId ? { id: w.zielOrtId, name: orteNamen[w.zielOrtId] || 'unbekannt' } : null,
          zwischenziele: (w.zwischenzielIds || []).map(function (i) { return { id: i, name: orteNamen[i] || 'unbekannt' }; }) };
      });
    });
  };

  Daten.prototype.fahrzeugName = function (liste, id) {
    var f = liste.filter(function (x) { return x.fahrzeug.id === id; })[0];
    return f ? f.aktuell.werte.bezeichnung : 'unbekannt';
  };

  /* Alle Aktivitäten, mit Status und Überschneidungen am selben Fahrzeug. */
  Daten.prototype.aktivitaetenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('aktivitaeten'), this.speicher.alle('verlaeufe'), this.aktivitaetsartenListe(), this.fahrzeugListe({ alle: true })]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'aktivitaet');
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      var fz = {}; r[3].forEach(function (f) { fz[f.fahrzeug.id] = f; });
      var jetzt = self.jetztLokal();
      liste.forEach(function (x) {
        var w = x.aktuell.werte;
        x.artName = arten[w.artId] || '';
        x.fahrzeugName = fz[w.fahrzeugId] ? fz[w.fahrzeugId].aktuell.werte.bezeichnung : 'unbekannt';
        x.status = MM.Aktivitaeten.status(w, jetzt);
        x.konflikte = [];
      });
      liste.forEach(function (x) {
        if (x.status === 'storniert') return;
        liste.forEach(function (y) {
          if (y !== x && y.status !== 'storniert' && y.aktuell.werte.fahrzeugId === x.aktuell.werte.fahrzeugId && MM.Aktivitaeten.ueberschneiden(x.aktuell.werte, y.aktuell.werte)) x.konflikte.push(y.objekt.id);
        });
      });
      var rang = { laeuft: 0, geplant: 1, vorbei: 2, storniert: 3 };
      liste.sort(function (a, b) {
        var d = rang[a.status] - rang[b.status];
        if (d) return d;
        var va = MM.Aktivitaeten.von(a.aktuell.werte), vb = MM.Aktivitaeten.von(b.aktuell.werte);
        return a.status === 'vorbei' ? (va < vb ? 1 : -1) : (va < vb ? -1 : (va > vb ? 1 : 0));
      });
      return liste;
    });
  };

  /*
   * Prüfung bei der Planung: Befähigung von Skipper/Fahrer und Stellvertretern,
   * Fristen bis zum Ende des Zeitraums, Überschneidungen am Fahrzeug.
   * Nur mit den Daten, die die App kennt. Keine rechtliche Aussage.
   */
  Daten.prototype.aktivitaetPruefung = function (id) {
    var self = this;
    return this.aktivitaetLaden(id).then(function (a) {
      if (!a) return null;
      var w = a.aktuell.werte;
      var pruefpersonen = a.besatzung.filter(function (b) { return b.aktuell.werte.rolle === 'verantwortlich' || b.aktuell.werte.rolle === 'stellvertreter'; });
      /* Die Regeln kommen vom gewählten Gebiet und von den Gebieten der Orte (Land, Region, Kreis oder Revier, je nach Fahrzeug). */
      var ortG = a.ortGebiete || { ids: [], ketten: [], ohneGebiet: [], ohneRevier: [] };
      var pruefIds = []; (w.gebietId ? [w.gebietId] : []).concat(ortG.ids).forEach(function (i) { if (pruefIds.indexOf(i) < 0) pruefIds.push(i); });
      var gebietNamen = (a.gebiet ? [a.gebiet.name] : []).concat(ortG.ketten.map(function (k) { return MM.Gebiete.pfadText(k); }));
      var gebietName = gebietNamen.join('; ');
      return Promise.all([
        self.anforderungenListe(w.fahrzeugId, true),
        Promise.all(pruefpersonen.map(function (b) { return self.nachweiseListe('person', b.person.id); })),
        self.fristenListe(w.fahrzeugId),
        self.aktivitaetenListe(),
        Promise.all(pruefIds.map(function (i) { return self.regelnListe(i); })).then(function (l) { return [].concat.apply([], l); }),
        self.komponentenListe(w.fahrzeugId),
        self.zuordnungenDokument(),
        self.gebieteListe()
      ]).then(function (r) {
        var anf = r[0].map(function (x) { return { bezeichnung: x.aktuell.werte.bezeichnung, artIds: x.aktuell.werte.artIds }; });
        /* Regeln des gewählten Gebiets: Sie gelten zusätzlich zu den Anforderungen am Fahrzeug. */
        var gebietInfo = null, ausruestungErgebnis = null;
        if (pruefIds.length) {
          /* Ausgebaute und ausgeblendete Komponenten (samt allem unter einer ausgeblendeten) zählen nicht (ausgeblendet seit 2.0.45). */
          var kompAktiv = MM.Komponenten.aktive(r[5]);
          var komp = kompAktiv.filter(function (k) { return !k.aktuell.werte.ausgebautAm; }).map(function (k) { return k.aktuell.werte.bezeichnung; });
          var ausw = MM.Orte.regelnAuswerten({
            regeln: r[4].map(function (x) { return Object.assign({ id: x.objekt.id, gebietId: x.objekt.gebietId }, x.aktuell.werte); }),
            fahrzeugArt: a.fahrzeug.artId, komponentenNamen: komp });
          var befGreifen = ausw.greifen.filter(function (g) { return MM.Orte.regelArt(g) === 'befaehigung'; });
          var ausGreifen = ausw.greifen.filter(function (g) { return MM.Orte.regelArt(g) === 'ausruestung'; });
          befGreifen.forEach(function (g) { anf.push({ bezeichnung: 'Gebiet ' + gebietName + ': ' + g.bezeichnung, artIds: g.artIds }); });
          var befNicht = ausw.nichtGreifen.filter(function (n) { return MM.Orte.regelArt(n.regel) === 'befaehigung'; });
          gebietInfo = { id: pruefIds[0], name: gebietName,
            regelnGesamt: r[4].filter(function (x) { return MM.Orte.regelArt(x.aktuell.werte) === 'befaehigung' && x.aktuell.werte.gilt !== 'nein'; }).length,
            greifen: befGreifen.map(function (g) { return g.bezeichnung; }),
            nichtGreifen: befNicht.map(function (n) { return { bezeichnung: n.regel.bezeichnung, grund: n.grund }; }) };
          /* Pflichtausrüstung: gesucht wird in den Namen der eingebauten Komponenten. Nicht eingetragen heißt „unklar“, nicht „fehlt“. */
          var kompDetail = kompAktiv.filter(function (k) { return !k.aktuell.werte.ausgebautAm; })
            .map(function (k) { return { name: k.aktuell.werte.bezeichnung, anzahl: k.aktuell.werte.anzahl, geprueft: k.aktuell.werte.eignungGeprueft }; });
          var pflicht = ausGreifen.map(function (g) {
            /* Bestätigte Namen des Nutzers (seit 2.0.41): Land der Regel (sonst das oberste Gebiet) und Art des Fahrzeugs. Nur was er gleichgesetzt hat, zählt. */
            var weg = g.gebietId ? MM.Gebiete.pfad(r[7], g.gebietId) : [];
            var landG = weg.filter(function (z) { return z.ebene === 'land'; })[0] || weg[0] || null;
            var gleich = landG ? MM.Orte.zuordnungNamen(MM.Orte.zuordnungenFuer(r[6], landG.name, a.fahrzeug.artId), 'ausruestung', g.pflichtAusruestung) : [];
            var e = MM.Orte.ausruestungPruefen({ regel: g, komponenten: MM.Orte.komponentenMitZuordnung(kompDetail, g.pflichtAusruestung, gleich), personen: a.besatzung.length });
            return { bezeichnung: g.bezeichnung, pflicht: g.pflichtAusruestung, status: e.status, soll: e.soll, ist: e.ist, istGeprueft: e.istGeprueft,
              menge: e.menge, bezug: e.bezug, eignung: e.eignung,
              text: e.text + (gleich.length ? ' Gleichgesetzt mit ' + gleich.map(function (n) { return '„' + n + '“'; }).join(', ') + ' (von dir bestätigt).' : '') };
          });
          ausruestungErgebnis = { liste: pflicht, ergebnis: !pflicht.length ? null : (pflicht.every(function (x) { return x.status === 'eingetragen'; }) ? 'erlaubt' : 'unklar') };
        }
        var personen = pruefpersonen.map(function (b, i) {
          var nachweise = r[1][i].map(function (n) { return { artId: n.nachweis.artId, artName: n.art.aktuell.werte.bezeichnung, hatAblauf: MM.Nachweise.hatAblauf(n.art.aktuell.werte), werte: n.aktuell.werte }; });
          var res = MM.Aktivitaeten.pruefeBefaehigung({ anforderungen: anf, nachweise: nachweise, endDatum: w.bisDatum });
          return { person: b.person, rolle: b.aktuell.werte.rolle, rolleText: b.rolleText, ergebnis: res.ergebnis, gruende: res.gruende };
        });
        var ergebnis = MM.Aktivitaeten.gesamtErgebnis(personen.map(function (x) { return x.ergebnis; }));
        var gebiet = gebietInfo ? gebietInfo.name : (trimmed(w.gebiet) || null);
        var gebietHinweis = null, ortHinweis = null;
        /* Fehlt bei einem Ort das Gebiet oder (beim Wasserfahrzeug) das Revier, ist das „unklar“. Gesperrt wird nichts. */
        if (ortG.ohneGebiet.length) ortHinweis = 'Bei ' + ortG.ohneGebiet.join(', ') + ' ist das Gebiet unklar, weil der Ort noch nicht über die Ortssuche geprüft ist (Stammdaten › Orte).';
        if (a.fahrzeug.welt === 'wasser' && ortG.ohneRevier.length && pruefIds.length) {
          ortHinweis = (ortHinweis ? ortHinweis + ' ' : '') + 'Für das Wasserfahrzeug fehlt bei ' + ortG.ohneRevier.join(', ') + ' das Revier (Binnenwasserstraße). Trage es beim Ort ein.';
        }
        if (gebietInfo) {
          /* Kennt die App für dieses Gebiet und dieses Fahrzeug keine Regel, bleibt sie vorsichtig: höchstens „unklar“. */
          if (!gebietInfo.greifen.length) {
            gebietHinweis = gebietInfo.regelnGesamt
              ? 'Für das Gebiet „' + gebietInfo.name + '“ trifft keine Regel auf dieses Fahrzeug zu. Die Prüfung gilt nur für die Anforderungen am Fahrzeug.'
              : 'Für das Gebiet „' + gebietInfo.name + '“ gibt es noch keine Regel für die Befähigung. Die Prüfung gilt nur für die Anforderungen am Fahrzeug.';
            if (ergebnis === 'erlaubt') ergebnis = 'unklar';
          }
        } else if (gebiet) {
          gebietHinweis = 'Das Gebiet „' + gebiet + '“ ist nur als Text eingetragen und wird nicht geprüft. Wähle ein Gebiet aus der Liste, damit seine Regeln gelten.';
          if (ergebnis === 'erlaubt') ergebnis = 'unklar';
        }
        if (ortHinweis) {
          gebietHinweis = (gebietHinweis ? gebietHinweis + ' ' : '') + ortHinweis;
          if (pruefIds.length && ergebnis === 'erlaubt') ergebnis = 'unklar';
        }
        /* Dieselbe Rechnung für das Fahrzeug der Aktivität und für alle dazugehörigen Fahrzeuge (seit 2.0.45). */
        function fristenFuer(fristListe) {
          var eingabe = fristListe.map(function (x) { return { bezeichnung: x.aktuell.werte.bezeichnung, werte: x.aktuell.werte, letzte: x.status.letzte, zaehler: x.zaehler }; });
          return MM.Aktivitaeten.fristenImZeitraum({ fristen: eingabe, heute: self.heute(), endDatum: w.bisDatum, geplanteStrecke: w.geplanteStrecke, geplanteStunden: w.geplanteStunden });
        }
        var fristen = fristenFuer(r[2]);
        var konflikte = r[3].filter(function (x) { return a.aktivitaet.id !== x.objekt.id && a.aktuell.werte.status !== 'storniert' && x.status !== 'storniert' && x.aktuell.werte.fahrzeugId === w.fahrzeugId && MM.Aktivitaeten.ueberschneiden(w, x.aktuell.werte); })
          .map(function (x) { return { id: x.objekt.id, name: x.aktuell.werte.bezeichnung, vonDatum: x.aktuell.werte.vonDatum, bisDatum: x.aktuell.werte.bisDatum }; });
        /* Dazugehörige Fahrzeuge (Anhänger, Dinghy, auch über Ketten): nur ihre Fristen werden mitgeprüft, als Hinweis, getrennt nach Fahrzeug.
           Befähigung, Pflichtausrüstung und Gebiet bleiben beim Fahrzeug der Aktivität. Abgegebene Fahrzeuge zählen nicht. */
        return self.fahrzeugZuordnung(w.fahrzeugId).then(function (zu) {
          var dazu = zu ? zu.alle : [];
          return Promise.all(dazu.map(function (x) { return self.fristenListe(x.id); })).then(function (listen) {
            var gespann = dazu.map(function (x, i) {
              var liste = fristenFuer(listen[i]);
              return { fahrzeugId: x.id, name: x.name, artName: x.artName, ueber: x.ueber, tiefe: x.tiefe, liste: liste, zusammenfassung: MM.Aktivitaeten.fristenZusammenfassung(liste) };
            });
            return { geprueftAm: self.jetztLokal(), anforderungen: anf.length,
              befaehigung: { ergebnis: ergebnis, personen: personen, gebiet: gebiet, gebietHinweis: gebietHinweis, gebietInfo: gebietInfo },
              ausruestung: ausruestungErgebnis,
              fristen: { liste: fristen, zusammenfassung: MM.Aktivitaeten.fristenZusammenfassung(fristen), gespann: gespann }, belegung: { konflikte: konflikte } };
          });
        });
      });
    });
  };

  /* ---------- Fahrzeugarten verwalten (seit 2.0.16) ----------
   * Eigene Arten und Änderungen liegen als ein Dokument in „einstellungen“ (Kennung „fahrzeugarten“),
   * dadurch keine Umstellung des Speichers. Die Regeln selbst stehen in js/fahrzeugarten.js. */
  function fahrzeugartenSpeichern(self) {
    return self.speicher.speichern('einstellungen', MM.Fahrzeugarten.dokument());
  }
  /* Die Arten, die ein Fahrzeug hat (eine Art je Fahrzeug, auch doppelt). */
  Daten.prototype.fahrzeugartenBenutzt = function () {
    return this.speicher.alle('fahrzeuge').then(function (liste) { return liste.map(function (f) { return f.art; }); });
  };

  /* Die Ansicht: alle Arten mit Zustand und Zahl der Fahrzeuge (mit Untergruppen), dazu was „Ungebrauchtes löschen“ träfe. */
  Daten.prototype.fahrzeugartenVerwaltung = function () {
    return this.fahrzeugartenBenutzt().then(function (benutzt) {
      var F = MM.Fahrzeugarten, zahl = {};
      benutzt.forEach(function (b) { F.vorfahren(b).forEach(function (i) { zahl[i] = (zahl[i] || 0) + 1; }); });
      var arten = F.verwaltung().map(function (k) { k.fahrzeuge = zahl[k.id] || 0; return k; });
      var weg = F.ungebraucht(benutzt);
      return { arten: arten, ungebraucht: weg.map(function (i) { return { id: i, name: F.art(i).name }; }), wiederherstellbar: F.wiederherstellbar().length };
    });
  };

  Daten.prototype.fahrzeugartAnlegen = function (roh) {
    var self = this;
    roh = roh || {};
    var r = MM.Fahrzeugarten.anlegen(neueId('fa'), roh.name, roh.eltern);
    if (!r.ok) return Promise.resolve(r);
    return fahrzeugartenSpeichern(self).then(function () { return r; });
  };

  Daten.prototype.fahrzeugartAendern = function (id, roh) {
    var self = this;
    roh = roh || {};
    var r = MM.Fahrzeugarten.aendern(id, roh.name, roh.ausgeblendet);
    if (!r.ok || !r.geaendert) return Promise.resolve(r);
    return fahrzeugartenSpeichern(self).then(function () { return r; });
  };

  Daten.prototype.fahrzeugartLoeschen = function (id) {
    var self = this;
    return this.fahrzeugartenBenutzt().then(function (benutzt) {
      var r = MM.Fahrzeugarten.loeschen(id, benutzt);
      if (!r.ok) return r;
      return fahrzeugartenSpeichern(self).then(function () { return r; });
    });
  };

  /* Löscht alles Ungebrauchte (keine Gruppen Land, Wasser, Luft). Benutzte Arten bleiben. */
  Daten.prototype.fahrzeugartenBereinigen = function () {
    var self = this;
    return this.fahrzeugartenBenutzt().then(function (benutzt) {
      var r = MM.Fahrzeugarten.bereinigen(benutzt);
      if (!r.anzahl) return r;
      return fahrzeugartenSpeichern(self).then(function () { return r; });
    });
  };

  Daten.prototype.fahrzeugartenWiederherstellen = function () {
    var self = this;
    var r = MM.Fahrzeugarten.wiederherstellen();
    if (!r.anzahl) return Promise.resolve(r);
    return fahrzeugartenSpeichern(self).then(function () { return r; });
  };

  /* ---------- Logbuch-Kern: Ereignisarten (offene Liste) ---------- */
  /* Seit 2.0.15 gilt jede Ereignisart für Fahrzeugarten (Baum). Fehlt die Angabe (ältere Arten), gilt sie für alle. */
  var EREIGNISART_FELDER = AKTART_FELDER.concat([{ key: 'zuordnung', label: 'Gilt für Fahrzeugarten', typ: 'text' },
    { key: 'giltImStatus', label: 'Möglich im Status', typ: 'text' }, { key: 'danachStatus', label: 'Danach Status', typ: 'text' },
    { key: 'aktion', label: 'Aktion beim Antippen', typ: 'text' },
    /* Baukasten-Gerüst (seit 2.0.50): Fragen und Wirkungen nach Wo und Wann. Die Aktion aus 2.0.47 geht darin auf (js/baukasten.js). */
    { key: 'fragen', label: 'Fragen nach dem Antippen', typ: 'mehrfach', optionen: baukastenOptionen('fragen') },
    { key: 'wirkungen', label: 'Wirkungen nach dem Antippen', typ: 'mehrfach', optionen: baukastenOptionen('wirkungen') }]);

  function baukastenOptionen(was) {
    return MM.Baukasten ? MM.Baukasten[was]().map(function (x) { return { wert: x.id, label: x.name }; }) : [];
  }
  /* Fragen und Wirkungen aus der Eingabe: { gesetzt, fragen, wirkungen, fehler }. „gesetzt“ ist falsch, wenn die Eingabe keines der beiden Felder hat.
   * Eine Wirkung ohne ihre Frage wird nicht gespeichert (zum Beispiel Kostenposten ohne Betrag), es kommt eine Meldung am Feld „wirkungen“. */
  function baukastenPruefen(roh) {
    var B = MM.Baukasten;
    if (!B || !roh || (roh.fragen === undefined && roh.wirkungen === undefined)) return { gesetzt: false, fragen: [], wirkungen: [], fehler: {} };
    var z = { fragen: B.fragenNormal(roh.fragen), wirkungen: B.wirkungenNormal(roh.wirkungen) };
    var m = B.fehlendeFragen(z);
    return { gesetzt: true, fragen: z.fragen, wirkungen: z.wirkungen, fehler: m.length ? { wirkungen: m.join(' ') } : {} };
  }

  /* Aktion beim Antippen (seit 2.0.47): bekannte Kennung oder ''. Die Liste der Aktionen steht in js/aktionen.js. */
  function aktionNormal(id) { return MM.Aktionen ? MM.Aktionen.normal(id) : ''; }

  Daten.prototype.ereignisartenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('ereignisarten'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'ereignisart');
    });
  };

  Daten.prototype.ereignisartAnlegen = function (roh) {
    var self = this;
    var bez = trimmed(roh && roh.bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segel gesetzt“.' } });
    return this.ereignisartenListe().then(function (liste) {
      if (liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === bez.toLowerCase(); })) {
        return { ok: false, fehler: { bezeichnung: 'Diese Art gibt es schon.' } };
      }
      /* Status-Regel (seit 2.0.23): beides leer = Starthilfe nach dem Namen. */
      var sr = MM.Status.regelNormal(roh);
      if (!sr.ok) return { ok: false, fehler: sr.fehler };
      var neuWerte = { bezeichnung: bez, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungNormal(roh.zuordnung),
        giltImStatus: sr.werte.giltImStatus, danachStatus: sr.werte.danachStatus };
      /* Aktion beim Antippen (seit 2.0.47): nur gesetzt, wenn eine gewählt ist. Ohne Aktion bleibt der Knopf wie bisher. */
      var akt = aktionNormal(roh.aktion);
      if (akt) neuWerte.aktion = akt;
      /* Fragen und Wirkungen (seit 2.0.50): nur gesetzt, wenn etwas gewählt ist. Ohne beides bleibt der Knopf wie bisher. */
      var bk = baukastenPruefen(roh);
      if (Object.keys(bk.fehler).length) return { ok: false, fehler: bk.fehler };
      if (bk.fragen.length || bk.wirkungen.length) { neuWerte.fragen = bk.fragen; neuWerte.wirkungen = bk.wirkungen; }
      return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', neuWerte);
    });
  };

  /* Legt die Vorschläge an, die es noch nicht gibt. Gibt die Anzahl der neuen zurück. */
  Daten.prototype.ereignisartenAusVorschlaegen = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Logbuch.VORSCHLAEGE_EREIGNISARTEN.filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
      return neu.reduce(function (kette, n) {
        return kette.then(function () { return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: n, ausgeblendet: 'nein' }); });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  /* Die Vorschläge mit Zuordnung zu Fahrzeugarten (Anlegen, Segel setzen, ...). Gibt die Anzahl der neuen zurück. */
  Daten.prototype.ereignisartenVorauswahlUebernehmen = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Logbuch.ZUSATZ_VORSCHLAEGE.filter(function (v) { return vorhanden.indexOf(v.bezeichnung.toLowerCase()) < 0; });
      return neu.reduce(function (kette, v) {
        return kette.then(function () {
          return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: v.bezeichnung, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(v.gilt) });
        });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  /* Die Ereignisarten, die zu einer Fahrzeugart passen (ohne ausgeblendete). Eine Art, die schon an einem
     Eintrag hängt, bleibt auswählbar (behalteIds), auch wenn sie nicht mehr zur Fahrzeugart passt. */
  Daten.prototype.ereignisartenFuerFahrzeugart = function (artId, behalteIds) {
    var behalte = behalteIds || [];
    return this.ereignisartenListe().then(function (liste) {
      return liste.filter(function (x) {
        if (behalte.indexOf(x.objekt.id) >= 0) return true;
        if (x.aktuell.werte.ausgeblendet === 'ja') return false;
        return !artId || MM.Logbuch.ereignisartGilt(x.aktuell.werte.zuordnung, artId);
      });
    });
  };

  Daten.prototype.ereignisartLaden = function (id) { return this.mitVerlaufLaden('ereignisarten', id, EREIGNISART_FELDER); };

  Daten.prototype.ereignisartAendern = function (id, roh) {
    var self = this;
    return this.ereignisartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var bez = trimmed(roh && roh.bezeichnung);
      if (!bez) return { ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben.' } };
      var neu = { bezeichnung: bez, ausgeblendet: roh.ausgeblendet === 'ja' ? 'ja' : 'nein' };
      /* Ohne Angabe bleibt die Zuordnung, wie sie ist (bei alten Arten: gilt für alle). */
      if (roh.zuordnung !== undefined) neu.zuordnung = MM.Logbuch.zuordnungNormal(roh.zuordnung);
      else if (x.aktuell.werte.zuordnung !== undefined) neu.zuordnung = x.aktuell.werte.zuordnung;
      /* Status-Regel (seit 2.0.23): ohne Angabe bleibt sie, wie sie ist. */
      if (roh.giltImStatus !== undefined || roh.danachStatus !== undefined) {
        var sr = MM.Status.regelNormal(roh);
        if (!sr.ok) return { ok: false, fehler: sr.fehler };
        neu.giltImStatus = sr.werte.giltImStatus; neu.danachStatus = sr.werte.danachStatus;
      } else {
        if (x.aktuell.werte.giltImStatus !== undefined) neu.giltImStatus = x.aktuell.werte.giltImStatus;
        if (x.aktuell.werte.danachStatus !== undefined) neu.danachStatus = x.aktuell.werte.danachStatus;
      }
      /* Aktion beim Antippen (seit 2.0.47): ohne Angabe bleibt sie, wie sie ist. Eine leere Wahl nimmt sie weg. */
      if (roh.aktion !== undefined) {
        var akt = aktionNormal(roh.aktion);
        if (akt || x.aktuell.werte.aktion) neu.aktion = akt;
      } else if (x.aktuell.werte.aktion !== undefined) neu.aktion = x.aktuell.werte.aktion;
      /* Fragen und Wirkungen (seit 2.0.50): ohne Angabe bleiben sie. Entspricht die Wahl der bisherigen Zusammenstellung (auch der aus dem
       * alten Feld „aktion“), wird nichts umgeschrieben. Eine leere Wahl nimmt die Zusammenstellung weg, auch die aus „aktion“. */
      var bk = baukastenPruefen(roh);
      if (Object.keys(bk.fehler).length) return { ok: false, fehler: bk.fehler };
      var altBk = x.aktuell.werte;
      var behalten = !bk.gesetzt || (MM.Baukasten && MM.Baukasten.gleich(MM.Baukasten.zusammenstellung(altBk), { fragen: bk.fragen, wirkungen: bk.wirkungen }));
      if (behalten) {
        if (altBk.fragen !== undefined) neu.fragen = altBk.fragen;
        if (altBk.wirkungen !== undefined) neu.wirkungen = altBk.wirkungen;
      } else { neu.fragen = bk.fragen; neu.wirkungen = bk.wirkungen; }
      return self.mitVerlaufAendern('ereignisart', id, x, neu, EREIGNISART_FELDER);
    });
  };

  /* ---------- Logbuch ohne Planung starten (seit 2.0.15) ----------
   * Legt sofort eine Aktivität an: Beginn jetzt, Ende standardmäßig heute, Fahrzeug und verantwortliche Person Pflicht,
   * Stellvertreter und Crew freiwillig. Die Art wählt der Nutzer (seit 2.0.17) aus den Arten, die zum Fahrzeug passen;
   * ohne Angabe gilt „Ausfahrt“.
   * Die Aktivität läuft dann wie jede andere, mit derselben Prüfung. Nichts wird nebenbei gebaut.
   *  roh = { fahrzeugId, artId?, verantwortlichId, stellvertreterIds: [], crewIds: [], bisDatum? }  */
  Daten.prototype.logbuchSofortStarten = function (roh) {
    var self = this;
    roh = roh || {};
    return this.aktivitaetsartenAusVorschlaegen().then(function () { return self.aktivitaetKontext(); }).then(function (ctx) {
      var fz = ctx.fahrzeuge.filter(function (x) { return x.fahrzeug.id === roh.fahrzeugId; })[0];
      var fehler = {};
      if (!fz) fehler.fahrzeugId = ctx.fahrzeuge.length ? 'Bitte das Fahrzeug wählen.' : 'Es gibt noch kein Fahrzeug. Lege zuerst ein Fahrzeug an.';
      var welt = fz ? MM.Fahrzeugarten.art(fz.fahrzeug.art).welt : null;
      var verantwortlich = MM.Aktivitaeten.verantwortlichenName(welt);
      if (!ctx.personen.some(function (x) { return x.objekt.id === roh.verantwortlichId; })) {
        fehler.verantwortlichId = ctx.personen.length ? 'Bitte wählen, wer ' + (welt ? verantwortlich : 'verantwortlich') + ' ist.' : 'Es gibt noch keine Person. Lege zuerst die Besatzung an.';
      }
      var stell = (roh.stellvertreterIds || []).filter(function (i) { return i && i !== roh.verantwortlichId; });
      var crew = (roh.crewIds || []).filter(function (i) { return i && i !== roh.verantwortlichId && stell.indexOf(i) < 0; });
      var bekannt = ctx.personen.map(function (x) { return x.objekt.id; });
      if (stell.concat(crew).some(function (i) { return bekannt.indexOf(i) < 0; })) fehler.crewIds = 'Eine gewählte Person gibt es nicht (mehr).';
      var gewaehlt = roh.artId
        ? ctx.arten.filter(function (a) { return a.objekt.id === roh.artId; })[0]
        : ctx.arten.filter(function (a) { return a.aktuell.werte.bezeichnung.toLowerCase() === 'ausfahrt' && a.aktuell.werte.ausgeblendet !== 'ja'; })[0];
      if (roh.artId && !gewaehlt) fehler.artId = 'Bitte eine Art wählen.';
      else if (gewaehlt && gewaehlt.aktuell.werte.ausgeblendet === 'ja') fehler.artId = 'Die Art „' + gewaehlt.aktuell.werte.bezeichnung + '“ ist ausgeblendet. Wähle eine andere Art.';
      else if (!gewaehlt && !Object.keys(fehler).length) fehler.allgemein = 'Die Art „Ausfahrt“ ist ausgeblendet oder fehlt. Blende sie unter „Arten von Aktivitäten“ wieder ein oder wähle eine andere Art.';
      else if (gewaehlt && fz && !MM.Logbuch.ereignisartGilt(gewaehlt.aktuell.werte.zuordnung, fz.fahrzeug.art)) {
        fehler.artId = 'Die Art „' + gewaehlt.aktuell.werte.bezeichnung + '“ gilt nicht für dieses Fahrzeug. Wähle eine passende Art.';
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var jetzt = self.jetztLokal(), tag = jetzt.slice(0, 10), zeit = jetzt.slice(11, 16);
      var a = {
        bezeichnung: gewaehlt.aktuell.werte.bezeichnung + ' ' + fz.aktuell.werte.bezeichnung + ' ' + tag.slice(8, 10) + '.' + tag.slice(5, 7) + '.' + tag.slice(0, 4),
        artId: gewaehlt.objekt.id, fahrzeugId: roh.fahrzeugId,
        vonDatum: tag, vonZeit: zeit, bisDatum: roh.bisDatum || tag, bisZeit: '',
        verantwortlichId: roh.verantwortlichId, tierIds: [], notiz: 'Ohne Planung gestartet'
      };
      return self.aktivitaetAnlegen(a).then(function (res) {
        if (!res.ok) return res;
        var kette = Promise.resolve();
        stell.forEach(function (pid) { kette = kette.then(function () { return self.besatzungHinzufuegen(res.id, pid, { rolle: 'stellvertreter' }); }); });
        crew.forEach(function (pid) { kette = kette.then(function () { return self.besatzungHinzufuegen(res.id, pid, { rolle: 'crew' }); }); });
        return kette.then(function () { return { ok: true, id: res.id }; });
      });
    });
  };

  /* ---------- Logbuch-Kern: Tagesabschnitte, Ereignisse, Prüfung zum Tagesbeginn ---------- */
  var ABSCHNITT_FELDER = [
    { key: 'datum', label: 'Datum', typ: 'datum' },
    { key: 'beginnZeit', label: 'Beginn (Uhrzeit)', typ: 'zeit' },
    { key: 'endeZeit', label: 'Ende (Uhrzeit)', typ: 'zeit' },
    { key: 'von', label: 'Von', typ: 'text' },
    { key: 'nach', label: 'Nach', typ: 'text' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'zielTatsaechlich', label: 'Tatsächliches Ziel', typ: 'text' },
    { key: 'abschlussNotiz', label: 'Notiz zum Tagesabschluss', typ: 'text' },
    { key: 'startOrtId', label: 'Startort des Tages', typ: 'text' },
    { key: 'zielOrtId', label: 'Zielort des Tages', typ: 'text' },
    { key: 'wetterHand', label: 'Wetter (von Hand)', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];
  var EREIGNIS_FELDER = [
    { key: 'artId', label: 'Art', typ: 'text' },
    { key: 'datum', label: 'Datum', typ: 'datum' },
    { key: 'zeit', label: 'Uhrzeit', typ: 'zeit' },
    { key: 'text', label: 'Text', typ: 'text' },
    { key: 'breite', label: 'Breite', typ: 'text' },
    { key: 'laenge', label: 'Länge', typ: 'text' },
    { key: 'positionQuelle', label: 'Herkunft der Position', typ: 'text' },
    { key: 'ortName', label: 'Ortsname', typ: 'text' },
    { key: 'ortNameQuelle', label: 'Herkunft des Ortsnamens', typ: 'text' },
    /* Antworten des Baukastens (seit 2.0.50) und der Kostenposten, den die Wirkung angelegt hat */
    { key: 'betrag', label: 'Betrag (€)', typ: 'zahl' },
    { key: 'ziel', label: 'Ziel', typ: 'text' },
    { key: 'kostenId', label: 'Kostenposten', typ: 'text' },
    /* Tanken (seit 2.0.51) */
    { key: 'tankName', label: 'Tank', typ: 'text' },
    { key: 'menge', label: 'Menge (l)', typ: 'zahl' },
    { key: 'literpreis', label: 'Literpreis (€)', typ: 'zahl' },
    { key: 'voll', label: 'Voll getankt', typ: 'text' },
    { key: 'fuellstandNach', label: 'Füllstand danach (l)', typ: 'zahl' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];
  var WECHSEL_FELDER = [
    { key: 'abDatum', label: 'Datum des Wechsels', typ: 'datum' },
    { key: 'abZeit', label: 'Uhrzeit des Wechsels', typ: 'zeit' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  /* Neuester Stand je Objekt aus dem Verlauf. Kein Datenraum-Filter, kein Sortieren nach Name. */
  function neuesteStaende(objekte, verlaeufe, typ) {
    var ver = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === typ) (ver[e.objektId] = ver[e.objektId] || []).push(e); });
    return objekte.map(function (o) {
      var l = (ver[o.id] || []).slice().sort(nachNr);
      return { objekt: o, aktuell: l[l.length - 1] || null, eintraege: l };
    }).filter(function (x) { return x.aktuell; });
  }

  /* Nur Aktivitäten, die nicht storniert sind, nehmen neue Einträge an (wie bei „Angaben ändern“). */
  function logbuchAktivitaet(self, aktivitaetId, schreibend) {
    return self.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (schreibend && a.aktuell.werte.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      return { a: a };
    });
  }

  function ausserhalbVon(a, datum) { return datum < a.aktuell.werte.vonDatum || datum > a.aktuell.werte.bisDatum; }

  /*
   * Das Logbuch einer Aktivität: alle Tagesabschnitte mit ihren Ereignissen (handeingetragene und
   * automatische Wechsel des Verantwortlichen), der festgehaltenen Prüfung und dem Verantwortlichen
   * zum Tagesbeginn. Es wird nichts geschrieben.
   */
  Daten.prototype.logbuchLaden = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.speicher.wo('tagesabschnitte', 'aktivitaetId', aktivitaetId),
      this.speicher.wo('ereignisse', 'aktivitaetId', aktivitaetId), this.speicher.alle('verlaeufe'),
      this.speicher.wo('tagespruefungen', 'aktivitaetId', aktivitaetId), this.ereignisartenListe()]).then(function (r) {
      var a = r[0];
      if (!a) return null;
      var arten = {}, zuord = {}; r[5].forEach(function (x) { arten[x.objekt.id] = x.aktuell.werte.bezeichnung; zuord[x.objekt.id] = x.aktuell.werte.zuordnung; });
      var fzArt = a.fahrzeug ? a.fahrzeug.artId : null;
      /* Ereignis, dessen Art nicht (mehr) zur Fahrzeugart gehört, zum Beispiel nach einem Wechsel der Fahrzeugart (seit 2.0.37). Es bleibt erhalten. */
      function fremd(artId) { return !!(fzArt && artId && Object.prototype.hasOwnProperty.call(zuord, artId) && !MM.Logbuch.ereignisartGilt(zuord[artId], fzArt)); }
      var abschnitte = MM.Logbuch.abschnitteSortieren(neuesteStaende(r[1], r[3], 'tagesabschnitt'));
      var sichtbar = abschnitte.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; });
      var ziele = sichtbar.length ? sichtbar : abschnitte;

      var proAbschnitt = {};
      abschnitte.forEach(function (x) { proAbschnitt[x.objekt.id] = []; });
      neuesteStaende(r[2], r[3], 'ereignis').forEach(function (e) {
        var w = e.aktuell.werte;
        if (!proAbschnitt[e.objekt.abschnittId]) return;
        proAbschnitt[e.objekt.abschnittId].push({ art: 'ereignis', id: e.objekt.id, artName: arten[w.artId] || 'unbekannt', datum: w.datum, zeit: w.zeit,
          zeitpunkt: MM.Logbuch.ereignisZeit(w), text: w.text || null, ausgeblendet: w.ausgeblendet === 'ja',
          nachgetragen: w.nachgetragen === 'ja', nachgetragenAm: w.nachgetragenAm || null, erstelltAm: e.objekt.erstelltAm || null, hatFoto: !!w.dateiName, geaendert: e.eintraege.filter(function (v) { return v.quelle !== 'aktion'; }).length > 1, fremdeArt: fremd(w.artId),
          ortName: w.ortName || null, ortNameQuelle: w.ortNameQuelle || null, breite: typeof w.breite === 'number' ? w.breite : null, laenge: typeof w.laenge === 'number' ? w.laenge : null, positionQuelle: w.positionQuelle || null });
      });
      MM.Logbuch.wechselEreignisse(a.verantwortung).forEach(function (wz) {
        var ziel = MM.Logbuch.abschnittFuer(ziele, wz.datum);
        if (!ziel) return;
        proAbschnitt[ziel.objekt.id].push({ art: 'wechsel', id: wz.verantwortungId, artName: MM.Logbuch.WECHSEL_ART, datum: wz.datum, zeit: wz.zeit,
          zeitpunkt: wz.ab, text: wz.text, notiz: wz.notiz, ausgeblendet: wz.ausgeblendet, nachgetragen: !!wz.nachgetragenAm, nachgetragenAm: wz.nachgetragenAm, pruefung: wz.pruefung, hatFoto: false, geaendert: wz.geaendert });
      });

      var pruefungen = {};
      r[4].slice().sort(function (x, y) { return x.erstelltAm < y.erstelltAm ? 1 : (x.erstelltAm > y.erstelltAm ? -1 : 0); })
        .forEach(function (p) { (pruefungen[p.abschnittId] = pruefungen[p.abschnittId] || []).push(p); });

      var liste = abschnitte.map(function (x) {
        var w = x.aktuell.werte;
        var tb = w.datum + 'T' + (w.beginnZeit || '00:00');
        var v = MM.Aktivitaeten.verantwortlicher(a.verantwortung, tb);
        var ereignisse = MM.Logbuch.ereignisseSortieren(proAbschnitt[x.objekt.id]);
        var verlauf = verlaufAus(x.eintraege, ABSCHNITT_FELDER);
        return { objekt: x.objekt, aktuell: x.aktuell, verlauf: verlauf, ausgeblendet: w.ausgeblendet === 'ja', ausserhalb: ausserhalbVon(a, w.datum),
          tagesbeginn: tb, verantwortlicher: v ? { personId: v.personId, name: v.name } : null,
          ereignisse: ereignisse, anzahlEreignisse: ereignisse.filter(function (e) { return !e.ausgeblendet; }).length,
          pruefungen: pruefungen[x.objekt.id] || [], pruefung: (pruefungen[x.objekt.id] || [])[0] || null };
      });
      var fehlend = MM.Logbuch.fehlendeTage(a.aktuell.werte, abschnitte.map(function (x) { return x.aktuell.werte.datum; }));
      return { aktivitaet: a, abschnitte: liste, fehlend: fehlend.neu.length, zuLang: fehlend.zuLang };
    });
  };

  /* Ein Abschnitt mit allem, was dazugehört (aus derselben Quelle wie das Logbuch). */
  Daten.prototype.abschnittLaden = function (id) {
    var self = this;
    return this.speicher.holen('tagesabschnitte', id).then(function (o) {
      if (!o) return null;
      return self.logbuchLaden(o.aktivitaetId).then(function (l) {
        if (!l) return null;
        var x = l.abschnitte.filter(function (y) { return y.objekt.id === id; })[0];
        return x ? { abschnitt: x, aktivitaet: l.aktivitaet } : null;
      });
    });
  };

  /* Prüft die Angaben eines Abschnitts. */
  Daten.prototype.pruefenAbschnitt = function (roh) {
    roh = roh || {};
    var felder = [{ key: 'datum', typ: 'datum' }, { key: 'beginnZeit', typ: 'zeit' }, { key: 'endeZeit', typ: 'zeit' },
      { key: 'von', typ: 'text' }, { key: 'nach', typ: 'text' }, { key: 'notiz', typ: 'text' }];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    if (!w.datum && !f.datum) f.datum = 'Bitte das Datum des Tages angeben.';
    if (w.beginnZeit && w.endeZeit && w.endeZeit < w.beginnZeit && !f.endeZeit) f.endeZeit = 'Die Uhrzeit des Endes liegt vor der des Beginns.';
    /* Etappe (seit 2.0.43): Start- und Zielort aus der Ortsliste und das Wetter von Hand. Nur was mitkommt, wird übernommen. */
    var hat = function (k) { return Object.prototype.hasOwnProperty.call(roh, k); };
    ['startOrtId', 'zielOrtId'].forEach(function (k) { if (hat(k)) w[k] = trimmed2(roh[k]) || null; });
    if (hat('wetterHand')) {
      var wh = trimmed2(roh.wetterHand);
      if (wh.length > 200) f.wetterHand = 'Bitte höchstens 200 Zeichen eingeben.';
      w.wetterHand = wh || null;
    }
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Gibt es die gewählten Orte des Tages im eigenen Datenraum? null oder die Fehler. */
  function etappeOrteFehler(self, w) {
    var felder = [['startOrtId', 'Den Startort gibt es nicht.'], ['zielOrtId', 'Den Zielort gibt es nicht.']].filter(function (x) { return w[x[0]]; });
    if (!felder.length) return Promise.resolve(null);
    return Promise.all(felder.map(function (x) { return self.speicher.holen('orte', w[x[0]]); })).then(function (r) {
      var f = {};
      felder.forEach(function (x, i) { if (!r[i] || r[i].datenraumId !== self.datenraumId) f[x[0]] = x[1]; });
      return Object.keys(f).length ? f : null;
    });
  }

  /* Die App bereitet die Tage aus dem Zeitraum der Aktivität vor. Bestehende Abschnitte bleiben unberührt. */
  Daten.prototype.tagesabschnitteVorbereiten = function (aktivitaetId) {
    var self = this;
    return logbuchAktivitaet(this, aktivitaetId, true).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      return self.speicher.wo('tagesabschnitte', 'aktivitaetId', aktivitaetId).then(function (vorhanden) {
        return self.speicher.alle('verlaeufe').then(function (vl) {
          var daten = neuesteStaende(vorhanden, vl, 'tagesabschnitt').map(function (x) { return x.aktuell.werte.datum; });
          var f = MM.Logbuch.fehlendeTage(k.a.aktuell.werte, daten);
          if (f.zuLang) return { ok: false, fehler: { allgemein: 'Der Zeitraum ist länger als ' + MM.Logbuch.MAX_TAGE + ' Tage. Lege die Tage von Hand an.' } };
          var jetzt = self.jetzt(), liste = [];
          f.neu.forEach(function (w) {
            var o = { id: neueId('tg'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, herkunft: 'vorbereitet', erstelltAm: jetzt };
            liste.push({ tabelle: 'tagesabschnitte', objekt: o });
            liste.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('tagesabschnitt', o.id, 1, w, null, jetzt) });
          });
          if (!liste.length) return { ok: true, anzahl: 0 };
          return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, anzahl: f.neu.length }; });
        });
      });
    });
  };

  /* Einen Tag von Hand ergänzen. */
  Daten.prototype.abschnittAnlegen = function (aktivitaetId, roh) {
    var self = this;
    return logbuchAktivitaet(this, aktivitaetId, true).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      var p = self.pruefenAbschnitt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      p.werte.ausgeblendet = 'nein';
      return etappeOrteFehler(self, p.werte).then(function (fo) {
        if (fo) return { ok: false, fehler: fo };
        return self.mitVerlaufAnlegen('tagesabschnitte', 'tagesabschnitt', 'tg', p.werte, { aktivitaetId: aktivitaetId, herkunft: 'hand' });
      });
    });
  };

  Daten.prototype.abschnittAendern = function (id, roh) {
    var self = this;
    return this.abschnittLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenAbschnitt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      /* Die Angaben des Tagesabschlusses stehen nicht im Formular „Tag ändern“ und bleiben unberührt. */
      var neu = Object.assign({}, x.abschnitt.aktuell.werte, p.werte);
      return etappeOrteFehler(self, neu).then(function (fo) {
        if (fo) return { ok: false, fehler: fo };
        return self.mitVerlaufAendern('tagesabschnitt', id, { aktuell: x.abschnitt.aktuell }, neu, ABSCHNITT_FELDER);
      });
    });
  };

  /* Die Prüfung der Aktivität zum Tagesbeginn festhalten (nur anhängen, nichts wird überschrieben). */
  Daten.prototype.tagesPruefungFesthalten = function (abschnittId) {
    var self = this;
    return this.abschnittLaden(abschnittId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      return self.aktivitaetPruefung(x.aktivitaet.aktivitaet.id).then(function (pr) {
        var stand = MM.Logbuch.pruefungFestgehalten(pr, x.abschnitt.verantwortlicher, x.abschnitt.tagesbeginn);
        var rec = { id: neueId('tp'), datenraumId: self.datenraumId, aktivitaetId: x.aktivitaet.aktivitaet.id, abschnittId: abschnittId, stand: stand, erstelltAm: self.jetzt() };
        return self.speicher.speichern('tagespruefungen', rec).then(function () { return { ok: true, id: rec.id }; });
      });
    });
  };

  /* ---------- Ereignisse ---------- */
  /* nachtragen = true: Der Zeitpunkt ist der echte, vergangene Zeitpunkt; das Ereignis steht dann als „nachgetragen am …“ da. */
  Daten.prototype.pruefenEreignis = function (roh, arten, nachtragen, bisherigeArt) {
    roh = roh || {};
    var felder = [
      { key: 'artId', typ: 'auswahl', optionen: arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || a.objekt.id === bisherigeArt; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; }) },
      { key: 'datum', typ: 'datum' }, { key: 'zeit', typ: 'zeit' }, { key: 'text', typ: 'text' }
    ];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    if (!w.artId && !f.artId) f.artId = arten.length ? 'Bitte die Art des Ereignisses wählen.' : 'Es gibt noch keine Art. Übernimm zuerst die Vorschläge oder lege eine Art an.';
    if (!w.datum && !f.datum) f.datum = 'Bitte das Datum angeben.';
    if (!w.zeit && !f.zeit) f.zeit = 'Bitte die Uhrzeit angeben.';
    if (nachtragen && w.datum && w.zeit && !f.datum && !f.zeit && w.datum + 'T' + w.zeit > this.jetztLokal()) {
      f.zeit = 'Ein Nachtrag liegt in der Vergangenheit. Der Zeitpunkt darf nicht nach jetzt liegen.';
    }
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    /* Position und Ortsname (seit 2.0.21): nur wenn die Eingaben sie überhaupt nennen, sonst bleibt ein bestehender Stand unverändert. */
    if (roh.breite !== undefined || roh.laenge !== undefined || roh.ortName !== undefined) {
      var pos = MM.Logbuch.positionPruefen(roh);
      Object.keys(pos.werte).forEach(function (k) { w[k] = pos.werte[k]; });
      Object.keys(pos.fehler).forEach(function (k) { f[k] = pos.fehler[k]; });
    }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* ---------- Position: Gerät und gelernte Ortsnamen (seit 2.0.21) ---------- */
  var POSITIONSNAMEN_DOK = 'positionsnamen';

  /* Die Kennung dieses Geräts. Sie entsteht beim ersten Bedarf und gehört zum Gerät (nicht in die Sicherung). */
  Daten.prototype.geraetKennung = function () {
    var self = this;
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      if (dok && dok.geraetId) return dok.geraetId;
      var id = neueId('ge');
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, geraetId: id })).then(function () { return id; });
    });
  };

  /* Alle gelernten Ortsnamen, nach Name sortiert: [{ name, breite, laenge, n, zuletzt }] */
  Daten.prototype.positionsnamenListe = function () {
    return this.speicher.holen('einstellungen', POSITIONSNAMEN_DOK).then(function (dok) {
      return ((dok && dok.punkte) || []).slice().sort(function (a, b) { return a.name.localeCompare(b.name, 'de'); });
    });
  };

  /* Zu dieser Position: der Name eines bekannten Ortes im Umfeld, oder null. { name, abstand } */
  Daten.prototype.ortNameVorschlag = function (breite, laenge) {
    if (typeof breite !== 'number' || typeof laenge !== 'number') return Promise.resolve(null);
    /* Seit 2.0.28 zuerst die Orte mit Position (die eine Quelle), dann die gelernten Namen. Der näher liegende gewinnt, bei Gleichstand der Ort. */
    return Promise.all([this.speicher.holen('einstellungen', POSITIONSNAMEN_DOK), this.ortZuPosition(breite, laenge)]).then(function (r) {
      var gelernt = MM.Logbuch.ortSuchen(r[0] && r[0].punkte, breite, laenge), ort = r[1];
      if (ort && (!gelernt || ort.abstand <= gelernt.abstand)) return { name: ort.name, abstand: ort.abstand, ortId: ort.ortId, standortId: ort.standortId };
      return gelernt;
    });
  };

  /* Nach dem Speichern: Hat der Nutzer zur Position einen Namen eingegeben oder bestätigt, merkt sich die App ihn. */
  Daten.prototype.ortLernenNachSpeichern = function (w) {
    var self = this;
    if (!w || typeof w.breite !== 'number' || typeof w.laenge !== 'number' || !w.ortName || w.ortNameQuelle !== 'hand') return Promise.resolve(false);
    return this.speicher.holen('einstellungen', POSITIONSNAMEN_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', MM.Logbuch.ortLernen(dok, w.ortName, w.breite, w.laenge, self.jetzt()));
    }).then(function () { return true; });
  };

  Daten.prototype.ereignisAnlegen = function (abschnittId, roh, optionen) {
    var self = this;
    var nachtragen = !!(optionen && optionen.nachtragen);
    roh = roh || {};
    return Promise.all([this.abschnittLaden(abschnittId), this.ereignisartenListe(), this.geraetKennung()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenEreignis(roh, r[1], nachtragen, null);
      var fehler = p.fehler, w = p.werte;
      /* Störung im Logbuch (seit 2.0.26): Das Ereignis „Störung“ legt den Werkstatt-Vorgang an, es gibt nur eine Störung.
         Ohne Angabe gilt „Fahrzeug bleibt nutzbar“ (vorbelegt, Festlegung des Nutzers vom 04.11.2026); der Nutzer ändert es beim Vorgang.
         Die Störung hängt am Fahrzeug der Aktivität. Auch ein Nachtrag legt den Vorgang an, mit dem Datum des Ereignisses. */
      var gewaehlteArt = r[1].filter(function (a) { return a.objekt.id === w.artId; })[0];
      var stoerung = !!gewaehlteArt && MM.Logbuch.istStoerungArt(gewaehlteArt.aktuell.werte.bezeichnung);
      var vorgangWerte = null;
      if (stoerung && !fehler.artId) {
        var au = roh.auswirkung === undefined || roh.auswirkung === null ? '' : String(roh.auswirkung).trim();
        if (!au) au = 'keine';
        if (!MM.Werkstatt.AUSWIRKUNGEN.some(function (o) { return o.wert === au; })) fehler.auswirkung = 'Bitte wählen, wie weit die Störung das Fahrzeug einschränkt.';
        else if (w.datum && w.zeit) {
          var vw = MM.Werkstatt.ausEreignis(w.text, w.datum, w.zeit, self.heute());
          var vp = self.pruefenVorgang({ bezeichnung: vw.bezeichnung, beschreibung: vw.beschreibung, auswirkung: au, gemeldetAm: vw.gemeldetAm }, 'stoerung');
          if (!vp.ok) fehler.allgemein = 'Die Störung konnte nicht als Vorgang in der Werkstatt angelegt werden: ' + Object.keys(vp.fehler).map(function (k) { return vp.fehler[k]; }).join(' ');
          else vorgangWerte = vp.werte;
        }
      }
      /* Schnelles Eintragen (Cockpit): Kennt die App den Ort im Umfeld, steht ihr Name als Vorschlag dabei. Gelernt wird er erst, wenn der Nutzer ihn bestätigt. */
      var vorschlag = optionen && optionen.ortVorschlag && !fehler.breite && !fehler.laenge && typeof w.breite === 'number' && !w.ortName
        ? self.ortNameVorschlag(w.breite, w.laenge) : Promise.resolve(null);
      return vorschlag.then(function (v) {
      if (v) { w.ortName = v.name; w.ortNameQuelle = 'vorschlag'; }
      /* Weicht die Zeit um mehr als 5 Minuten von jetzt ab (in der Vergangenheit), ist es automatisch ein Nachtrag (wie in V1). */
      if (!nachtragen && !Object.keys(fehler).length && MM.Logbuch.zeitpunktArt(w.datum, w.zeit, self.jetztLokal()) === 'nachtrag') nachtragen = true;
      var datei = roh.datei;
      if (datei && !(typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Diese Datei ist leer.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      /* Status des Fahrzeugs (seit 2.0.23): Ein Ereignis „jetzt“ wird nur gespeichert, wenn es im aktuellen Status möglich ist.
         Das Nachtragen mit früherer Uhrzeit wird nie gesperrt, damit Vergessenes nachgetragen werden kann. */
      var artGewaehlt = nachtragen ? null : r[1].filter(function (a) { return a.objekt.id === w.artId; })[0];
      var statusPruefung = artGewaehlt ? self.fahrzeugStatus(x.aktivitaet.aktuell.werte.fahrzeugId) : Promise.resolve(null);
      return statusPruefung.then(function (st) {
      if (st && st.ok) {
        var pr = st.pruefe(artGewaehlt.aktuell.werte.bezeichnung);
        if (!pr.erlaubt) return { ok: false, gesperrt: true, grund: pr.grund, status: pr.statusName,
          fehler: { allgemein: '„' + artGewaehlt.aktuell.werte.bezeichnung + '“ geht jetzt nicht, das Fahrzeug hat den Status „' + pr.statusName + '“ (' + pr.grund + '). Hast du etwas vergessen? Dann trage es mit der echten Uhrzeit nach.' } };
      }
      var jetzt = self.jetzt();
      w.ausgeblendet = 'nein';
      w.nachgetragen = nachtragen ? 'ja' : 'nein';
      w.nachgetragenAm = nachtragen ? jetzt : null;
      w.dateiName = datei ? String(datei.name || 'Foto') : null;
      w.dateiTyp = datei ? String(datei.type || '') : null;
      w.dateiGroesse = datei ? datei.size : null;
      w.geraetId = r[2];
      var e = { id: neueId('ev'), datenraumId: self.datenraumId, aktivitaetId: x.aktivitaet.aktivitaet.id, abschnittId: abschnittId, erstelltAm: jetzt };
      var liste = [{ tabelle: 'ereignisse', objekt: e }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ereignis', e.id, 1, w, null, jetzt) }];
      var vorgangId = null;
      if (vorgangWerte) {
        /* Ereignis, Vorgang und beider Verlauf werden zusammen gespeichert: ganz oder gar nicht. */
        vorgangWerte.art = 'stoerung'; vorgangWerte.status = 'offen'; vorgangWerte.erledigtAm = null; vorgangWerte.erledigtNotiz = null;
        var vg = { id: neueId('vg'), fahrzeugId: x.aktivitaet.aktuell.werte.fahrzeugId, komponenteId: null, erstelltAm: jetzt, ereignisId: e.id };
        vorgangId = vg.id; e.vorgangId = vg.id;
        liste.push({ tabelle: 'vorgaenge', objekt: vg }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('vorgang', vg.id, 1, vorgangWerte, null, jetzt) });
      }
      if (datei) liste.push({ tabelle: 'ereignisdateien', objekt: { id: neueId('ed'), ereignisId: e.id, name: w.dateiName, mime: w.dateiTyp, groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      return self.speicher.mehrereSpeichern(liste).then(function () { return self.ortLernenNachSpeichern(w); }).then(function () {
        return { ok: true, id: e.id, vorgangId: vorgangId, breite: w.breite === undefined ? null : w.breite, laenge: w.laenge === undefined ? null : w.laenge, ortName: w.ortName || null, ortNameQuelle: w.ortNameQuelle || null };
      }).catch(function (err) {
        if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei.' } };
        throw err;
      });
      });
      });
    });
  };

  /* ---------- Status des Fahrzeugs (seit 2.0.23) ----------
   * Der Status gehört zum Fahrzeug und wird aus allen sichtbaren Ereignissen seiner Aktivitäten nach Uhrzeit gerechnet,
   * nichts wird dafür gemerkt. Die Regeln stehen in js/status.js, die Regel einer Art hängt an der Art (nicht am Namen).
   * Ergebnis: { ok, fahrzeugId, welt, hatStatus, stand (MM.Status.rechnen), regeln: [{ name, artId, regel }], pruefe(artName) } */
  Daten.prototype.fahrzeugStatus = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.fahrzeugListe({ alle: true }), this.aktivitaetenListe(), this.ereignisartenListe()]).then(function (r) {
      var fz = r[0].filter(function (f) { return f.fahrzeug.id === fahrzeugId; })[0];
      if (!fz) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      var welt = MM.Fahrzeugarten.art(fz.fahrzeug.art).welt;
      var arten = {}, regeln = [];
      r[2].forEach(function (a) {
        var w = a.aktuell.werte;
        arten[String(w.bezeichnung || '').trim().toLowerCase()] = w;
        if (w.ausgeblendet === 'ja') return;
        if (!MM.Logbuch.ereignisartGilt(w.zuordnung, fz.fahrzeug.art)) return;
        regeln.push({ name: w.bezeichnung, artId: a.objekt.id, regel: MM.Status.regelFuer(w, welt) });
      });
      var meine = r[1].filter(function (a) { return a.aktuell.werte.fahrzeugId === fahrzeugId && a.aktuell.werte.status !== 'storniert' && a.status !== 'storniert'; });
      return Promise.all(meine.map(function (a) { return self.logbuchLaden(a.objekt.id); })).then(function (lbs) {
        var ereignisse = [];
        lbs.forEach(function (lb) {
          if (!lb) return;
          lb.abschnitte.forEach(function (x) {
            if (x.ausgeblendet) return;
            x.ereignisse.forEach(function (e) { if (e.art === 'ereignis' && !e.ausgeblendet) ereignisse.push({ id: e.id, artName: e.artName, zeitpunkt: e.zeitpunkt, erstelltAm: e.erstelltAm || null }); });
          });
        });
        var stand = MM.Status.rechnen(ereignisse, arten, welt, self.jetztLokal());
        function regelVonName(n) {
          var w = arten[String(n || '').trim().toLowerCase()];
          return MM.Status.regelFuer(w || { bezeichnung: n }, welt);
        }
        return { ok: true, fahrzeugId: fahrzeugId, welt: welt, hatStatus: MM.Status.hatStatus(welt), stand: stand, regeln: regeln,
          pruefe: function (artName) { return MM.Status.pruefen(regelVonName(artName), stand, regeln); } };
      });
    });
  };

  Daten.prototype.ereignisLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('ereignisse', id, EREIGNIS_FELDER).then(function (x) {
      if (!x) return null;
      return Promise.all([self.ereignisartenListe(), self.abschnittLaden(x.objekt.abschnittId), self.speicher.wo('ereignisdateien', 'ereignisId', id)]).then(function (r) {
        var arten = {}; r[0].forEach(function (a) { arten[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artId') { u.feld = { typ: 'text' }; u.alt = u.alt ? arten[u.alt] || 'unbekannt' : null; u.neu = u.neu ? arten[u.neu] || 'unbekannt' : null; }
            if (u.key === 'kostenId') { u.feld = { typ: 'text' }; u.alt = u.alt ? 'angelegt' : null; u.neu = u.neu ? 'angelegt' : null; }
            /* Herkunft in Worten (seit 2.0.21) */
            var herkunft = { gps: 'GPS', hand: u.key === 'ortNameQuelle' ? 'von dir eingegeben oder bestätigt' : 'von Hand', vorschlag: 'Vorschlag der App' };
            if (u.key === 'positionQuelle' || u.key === 'ortNameQuelle') { u.alt = u.alt ? herkunft[u.alt] || u.alt : null; u.neu = u.neu ? herkunft[u.neu] || u.neu : null; }
          });
        });
        var w = x.aktuell.werte, d = r[2][0];
        return { ereignis: x.objekt, aktuell: x.aktuell, verlauf: x.verlauf, art: w.artId ? { id: w.artId, name: arten[w.artId] || 'unbekannt' } : null, arten: r[0],
          abschnitt: r[1] ? r[1].abschnitt : null, aktivitaet: r[1] ? r[1].aktivitaet : null,
          datei: d ? { id: d.id, name: d.name, mime: d.mime, groesse: d.groesse } : null };
      });
    });
  };

  /* Antworten nach dem Antippen eines Knopfes (seit 2.0.47, erweitert 2.0.50): Text, Foto, Betrag, Ziel (und die Kennung des Kostenpostens)
   * kommen zu einem Ereignis dazu, das schon gespeichert ist (Wo und Wann stehen davor fest). Der neue Stand im Verlauf hat die Quelle
   * „aktion“ und zählt im Logbuch nicht als „korrigiert“.
   * roh: { text, datei, betrag, ziel, kostenId }. Ein vorhandener Text bleibt, wenn kein neuer kommt. Zu einem Ereignis gehört höchstens eine Datei.
   * Ein Ziel steht zusätzlich als Zeile „Navigation zu: …“ im Text, wie seit 2.0.47. */
  Daten.prototype.ereignisAktionSpeichern = function (id, roh) {
    var self = this;
    roh = roh || {};
    return this.ereignisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      if (x.aktivitaet && x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var alt = x.aktuell.werte, neu = Object.assign({}, alt), datei = roh.datei || null, fehler = {}, geaendert = false;
      var text = roh.text === undefined || roh.text === null ? '' : String(roh.text).trim();
      if (text) {
        if (text.length > 2000) fehler.text = 'Der Text ist zu lang (höchstens 2000 Zeichen).';
        else { neu.text = text; }
      }
      var ziel = roh.ziel === undefined || roh.ziel === null ? '' : String(roh.ziel).trim();
      if (ziel) {
        if (ziel.length > 200) fehler.ziel = 'Das Ziel ist zu lang (höchstens 200 Zeichen).';
        else {
          neu.ziel = ziel;
          /* Eine frühere Zeile „Navigation zu: …“ wird ersetzt, der übrige Text bleibt. */
          var ohneZiel = String(neu.text || '').split('\n').filter(function (z) { return z.indexOf('Navigation zu: ') !== 0; }).join('\n').trim();
          neu.text = (ohneZiel ? ohneZiel + '\n' : '') + 'Navigation zu: ' + ziel;
          if (neu.text.length > 2000) fehler.text = 'Der Text ist zu lang (höchstens 2000 Zeichen).';
        }
      }
      if (roh.betrag !== undefined && roh.betrag !== null && String(roh.betrag).trim() !== '') {
        var b = Number(String(geldRoh(roh.betrag)).replace(',', '.'));
        if (!isFinite(b) || !(b > 0)) fehler.betrag = 'Bitte einen Betrag über 0 eingeben, zum Beispiel 45,50.';
        else if (b > 10000000) fehler.betrag = 'Der Betrag ist zu groß.';
        else neu.betrag = MM.Kosten ? MM.Kosten.runde(b) : Math.round(b * 100) / 100;
      }
      if (roh.kostenId) neu.kostenId = String(roh.kostenId);
      /* Tanken (seit 2.0.51): Die Antworten kommen unverändert zum Eintrag, geprüft hat sie ereignisAblaufAusfuehren. */
      if (roh.tank) {
        ['tankId', 'tankName', 'menge', 'literpreis', 'voll', 'fuellstandNach', 'tankGebucht'].forEach(function (k) { if (roh.tank[k] !== undefined && roh.tank[k] !== null) neu[k] = roh.tank[k]; });
      }
      /* Ein und Aus (seit 2.0.52): Welcher Verbraucher, ein oder aus, und der Lauf. Geprüft und gebucht hat es ereignisAblaufAusfuehren. */
      if (roh.lauf) {
        ['verbraucherId', 'verbraucherName', 'laufArt', 'laufId', 'laufGebucht'].forEach(function (k) { if (roh.lauf[k] !== undefined && roh.lauf[k] !== null) neu[k] = roh.lauf[k]; });
      }
      if (datei) {
        if (!(typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Diese Datei ist leer.';
        else if (x.datei) fehler.datei = 'Zu diesem Ereignis gehört schon eine Datei.';
        else { neu.dateiName = String(datei.name || 'Foto'); neu.dateiTyp = String(datei.type || ''); neu.dateiGroesse = datei.size; geaendert = true; }
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      ['text', 'ziel', 'betrag', 'kostenId', 'tankId', 'tankName', 'menge', 'literpreis', 'voll', 'fuellstandNach', 'tankGebucht', 'verbraucherId', 'verbraucherName', 'laufArt', 'laufId', 'laufGebucht'].forEach(function (k) { if (!gleich(alt[k] === undefined ? null : alt[k], neu[k] === undefined ? null : neu[k])) geaendert = true; });
      if (!geaendert) return { ok: true, id: id, geaendert: false };
      var jetzt = self.jetzt();
      var eintrag = neuerVerlaufEintrag('ereignis', id, x.aktuell.nr + 1, neu, x.aktuell.id, jetzt);
      eintrag.quelle = 'aktion';
      var liste = [{ tabelle: 'verlaeufe', objekt: eintrag }].concat(Array.isArray(roh.zusatz) ? roh.zusatz : []);
      if (datei) liste.push({ tabelle: 'ereignisdateien', objekt: { id: neueId('ed'), ereignisId: id, name: neu.dateiName, mime: neu.dateiTyp, groesse: neu.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: id, geaendert: true }; }).catch(function (err) {
        if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei.' } };
        throw err;
      });
    });
  };

  /* Baukasten-Gerüst (seit 2.0.50): Nach Wo und Wann kommen die Fragen der Art, danach die Wirkungen (Muster Festhalten, Fragen, Wirkungen).
   * Hier steht, was die App selbst tut. Das Öffnen der Navigations-App macht die Oberfläche (sie braucht das Gerät).
   *  antworten: { text, datei, betrag, ziel, tankId, menge, literpreis, voll, verbraucherId }. Antworten zu Fragen, die die Art nicht stellt, werden nicht beachtet.
   * Pflicht ist nur, was eine Wirkung braucht: der Betrag für den Kostenposten, das Ziel für die Navigation.
   * Ergebnis: { ok, id, zusammenstellung, kostenId, kostenNeu, betrag, ziel, navi } oder { ok: false, fehler }.
   * Ein Kostenposten wird je Ereignis nur einmal angelegt: Wer das Formular noch einmal abschickt, legt keinen zweiten an. */
  Daten.prototype.ereignisAblaufAusfuehren = function (id, antworten) {
    var self = this;
    antworten = antworten || {};
    return this.ereignisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      if (x.aktivitaet && x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var w = x.aktuell.werte, B = MM.Baukasten;
      var artObjekt = x.arten.filter(function (a) { return a.objekt.id === w.artId; })[0];
      var z = B && artObjekt ? B.zusammenstellung(artObjekt.aktuell.werte) : { fragen: [], wirkungen: [] };
      if (!z.fragen.length && !z.wirkungen.length) return { ok: false, fehler: { allgemein: 'Zu dieser Art ist nichts eingestellt.' } };
      var artName = x.art ? x.art.name : 'Ereignis';
      var hat = function (f) { return z.fragen.indexOf(f) >= 0; }, wirkt = function (a) { return z.wirkungen.indexOf(a) >= 0; };
      var leerText = function (v) { return v === undefined || v === null || String(v).trim() === ''; };
      var fehler = {};

      var text = hat('text') ? antworten.text : '', betrag = hat('betrag') ? antworten.betrag : '', ziel = hat('ziel') ? antworten.ziel : '';
      var datei = hat('foto') && !x.datei ? (antworten.datei || null) : null;

      /* Tanken (seit 2.0.51): Tank, Menge, Literpreis, voll getankt. Ist der Tankvorgang schon verbucht, wird er nicht noch einmal verbucht. */
      var tankId = hat('tank') ? String(antworten.tankId === undefined || antworten.tankId === null ? '' : antworten.tankId).trim() : '';
      var mengeRoh = hat('menge') ? antworten.menge : '', preisRoh = hat('literpreis') ? antworten.literpreis : '';
      var vollRoh = hat('voll') ? String(antworten.voll === undefined || antworten.voll === null ? '' : antworten.voll).trim() : '';
      var tankWirkt = wirkt('fuellstand') || wirkt('verbrauch') || wirkt('reichweite');
      var tankBuchen = tankWirkt && !w.tankGebucht;
      var menge = null, literpreis = null;
      if (!w.tankGebucht) {
        if (!leerText(mengeRoh)) {
          menge = MM.Tanken.zahl(geldRoh(mengeRoh));
          if (menge === null || !(menge > 0)) fehler.menge = 'Bitte die Menge in Litern eingeben, zum Beispiel 45,5.';
          else if (menge > 100000) fehler.menge = 'Die Menge ist zu groß.';
        }
        if (!leerText(preisRoh)) {
          literpreis = MM.Tanken.zahl(geldRoh(preisRoh));
          if (literpreis === null || !(literpreis > 0)) fehler.literpreis = 'Bitte den Preis je Liter eingeben, zum Beispiel 1,79.';
          else if (literpreis > 1000) fehler.literpreis = 'Der Literpreis ist zu groß.';
        }
        if (vollRoh !== '' && vollRoh !== 'ja' && vollRoh !== 'nein') fehler.voll = 'Bitte Ja oder Nein wählen.';
        if (tankBuchen) {
          if (!tankId) fehler.tank = 'Bitte den Tank wählen.';
          if (menge === null && !fehler.menge) fehler.menge = 'Bitte die Menge in Litern eingeben.';
          if (vollRoh === '' && !fehler.voll) fehler.voll = 'Bitte wählen: Ja oder Nein.';
        }
        if (literpreis !== null && menge === null && !fehler.menge && leerText(betrag)) fehler.menge = 'Für den Literpreis braucht die App die Menge.';
      }
      /* Betrag: Was der Nutzer einträgt. Fehlt er, rechnet die App Menge mal Literpreis (nur bei der Wirkung „Kostenposten Treibstoff und Energie“). */
      var betragRechnen = wirkt('kostenTreibstoff') && !w.kostenId && leerText(betrag) && menge !== null && literpreis !== null && !fehler.menge && !fehler.literpreis;
      if (betragRechnen) betrag = String(MM.Kosten ? MM.Kosten.runde(menge * literpreis) : Math.round(menge * literpreis * 100) / 100).replace('.', ',');
      var tankAngaben = !w.tankGebucht && (tankId || menge !== null || literpreis !== null || vollRoh);

      /* Ein und Aus (seit 2.0.52): Der Verbraucher kommt aus der Frage „Verbraucher“, die Wirkung schaltet ihn ein oder aus. Ist der Lauf schon
       * gebucht, wird er nicht noch einmal gebucht. */
      var verbrId = hat('verbraucher') ? String(antworten.verbraucherId === undefined || antworten.verbraucherId === null ? '' : antworten.verbraucherId).trim() : '';
      var laufArt = wirkt('verbraucherEin') ? 'ein' : (wirkt('verbraucherAus') ? 'aus' : null);
      var laufBuchen = !!laufArt && !w.laufGebucht;
      if (laufBuchen && !verbrId) fehler.verbraucher = 'Bitte den Verbraucher wählen.';

      /* Etwas muss eingetragen sein, sonst gibt es nichts zu speichern. Bei nur einer Frage nennt die Meldung ihr Feld. */
      var etwas = !leerText(text) || !leerText(betrag) || !leerText(ziel) || !!datei || !!tankAngaben || !!verbrId;
      if (!etwas) {
        var nurEine = z.fragen.length === 1 ? z.fragen[0] : null;
        if (nurEine === 'text') fehler.text = 'Bitte den Text eintragen oder zurück zum Cockpit gehen.';
        else if (nurEine === 'foto') fehler.datei = x.datei ? 'Zu diesem Eintrag gehört schon ein Foto.' : 'Bitte ein Foto aufnehmen oder wählen oder zurück zum Cockpit gehen.';
        else if (nurEine === 'ziel') fehler.ziel = 'Bitte das Ziel eintragen.';
        else if (nurEine === 'betrag') fehler.betrag = 'Bitte den Betrag eintragen oder zurück zum Cockpit gehen.';
        else if (nurEine === 'verbraucher') fehler.verbraucher = 'Bitte den Verbraucher wählen oder zurück zum Cockpit gehen.';
        else fehler.allgemein = 'Bitte etwas eintragen oder zurück zum Cockpit gehen.';
      }
      if (wirkt('navi') && leerText(ziel) && !fehler.ziel) fehler.ziel = 'Bitte das Ziel eintragen.';
      var kostenRoh = null;
      var kostenWirkt = (wirkt('kosten') || wirkt('kostenTreibstoff')) && !w.kostenId;
      if (kostenWirkt) {
        kostenRoh = { gruppe: 'variabel', bezeichnung: artName, betrag: betrag, datum: w.datum || self.heute(), abschnittId: x.ereignis.abschnittId || '',
          ortText: w.ortName ? String(w.ortName).slice(0, 120) : '' };
        if (wirkt('kostenTreibstoff')) kostenRoh.kostenart = 'treibstoff';
        if (leerText(betrag)) { if (!fehler.betrag) fehler.betrag = wirkt('kostenTreibstoff') ? 'Bitte den Betrag eintragen, oder Menge und Literpreis. Daraus wird der Kostenposten.' : 'Bitte den Betrag eintragen. Er wird zum Kostenposten.'; }
        else {
          var pk = self.pruefenKosten(Object.assign({}, kostenRoh, { aktivitaetId: x.ereignis.aktivitaetId }), 'variabel');
          if (!pk.ok) fehler.betrag = pk.fehler.betrag || pk.fehler.bezeichnung || 'Der Kostenposten lässt sich so nicht anlegen. Bitte den Betrag prüfen.';
        }
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };

      /* Tank prüfen und rechnen, bevor etwas gespeichert wird. Gespeichert wird alles in einem Schritt (Ereignis und Füllstand zusammen). */
      var vorab = (tankBuchen || (tankAngaben && tankId)) ? self.aktivitaetLaden(x.ereignis.aktivitaetId).then(function (a) {
        if (!a) return { fehler: { allgemein: 'Die Aktivität zu diesem Ereignis wurde nicht gefunden.' } };
        return self.komponentenListe(a.fahrzeug.id).then(function (liste) {
          var tk = tankId ? liste.filter(function (k) { return k.komponente.id === tankId && MM.Versorgung.istTank(k.komponente); })[0] : null;
          if (!tk) return { fehler: { tank: 'Bitte einen Tank dieses Fahrzeugs wählen.' } };
          if (!tankBuchen) return { tk: tk, liste: liste, fahrzeugId: a.fahrzeug.id };
          var verb = MM.Versorgung.verbraucherVon(liste, [tankId]).filter(function (k) { return k.aktuell.werte.verbraucher === 'ja'; });
          return self.stundenStaende(a.fahrzeug.id, verb.map(function (k) { return k.komponente.id; })).then(function (st) {
            return { tk: tk, liste: liste, fahrzeugId: a.fahrzeug.id, verb: verb.map(function (k) {
              return { id: k.komponente.id, name: k.aktuell.werte.bezeichnung, aus: MM.Versorgung.verbrauchAus(k.aktuell.werte), stunden: typeof st[k.komponente.id] === 'number' ? st[k.komponente.id] : null };
            }) };
          });
        });
      }) : Promise.resolve(null);

      /* Ein oder Aus: prüfen und vorbereiten, gespeichert wird zusammen mit dem Eintrag in einem Schritt. Die Zeit des Eintrags gilt als Zeit
       * des Laufs, wenn sie nicht in der Zukunft und nicht vor dem Start (Aus) oder dem Ende des letzten Laufs (Ein) liegt, sonst jetzt. */
      var laufVorab = (laufBuchen && verbrId) ? self.aktivitaetLaden(x.ereignis.aktivitaetId).then(function (a) {
        if (!a) return { fehler: { allgemein: 'Die Aktivität zu diesem Ereignis wurde nicht gefunden.' } };
        return self.komponenteLaden(verbrId).then(function (c) {
          if (!c || c.fahrzeug.id !== a.fahrzeug.id || !MM.Komponenten.kannLaufen(c.komponente, c.aktuell.werte)) return { fehler: { verbraucher: 'Bitte einen Verbraucher dieses Fahrzeugs wählen.' } };
          var zeitIso = w.datum && w.zeit ? MM.Motoren.zeitpunktAusOrtszeit(w.datum, w.zeit) : null;
          return self.verbraucherLaufVorbereiten(laufArt, verbrId, { zeitpunktWennMoeglich: zeitIso, ereignisId: id }).then(function (p) {
            var name = c.aktuell.werte.bezeichnung;
            if (p.ok === false) { var f = p.fehler || {}; return { fehler: { verbraucher: '„' + name + '“: ' + (f.allgemein || f.zeit || 'Das ging nicht.') } }; }
            return { p: p, name: name };
          });
        });
      }) : Promise.resolve(null);

      return Promise.all([vorab, laufVorab]).then(function (vv) {
        var v = vv[0], lv = vv[1];
        if (v && v.fehler) return { ok: false, fehler: v.fehler };
        if (lv && lv.fehler) return { ok: false, fehler: lv.fehler };
        var tank = null, tankErg = null, zusatz = [], lauf = null, laufErg = null;
        if (lv && lv.p) {
          zusatz = zusatz.concat(lv.p.schreiben);
          lauf = { verbraucherId: verbrId, verbraucherName: lv.name, laufArt: laufArt, laufId: lv.p.ergebnis.id, laufGebucht: true };
          laufErg = Object.assign({ verbraucherId: verbrId, name: lv.name, art: laufArt }, lv.p.ergebnis);
        }
        if (v && v.tk) {
          var altW = v.tk.aktuell.werte, tankName = altW.bezeichnung;
          tank = { tankId: tankId, tankName: tankName, menge: menge, literpreis: literpreis, voll: vollRoh || null };
          if (tankBuchen) {
            var zeit = w.datum && w.zeit ? w.datum + 'T' + w.zeit : self.jetztLokal();
            var erg = MM.Tanken.berechnen({ kapazitaet: MM.Tanken.kapazitaet(altW),
              alt: { fuellstand: altW.fuellstand, art: altW.fuellstandArt, zeit: altW.fuellstandZeit, stunden: altW.fuellstandStunden },
              altVerbrauch: altW.verbrauch || null, menge: menge, voll: vollRoh === 'ja', zeit: zeit, verbraucher: v.verb });
            var zeilen = [];
            if (wirkt('fuellstand') && erg.setzen) {
              var neuW = Object.assign({}, altW, { fuellstand: erg.fuellstand, fuellstandArt: erg.art, fuellstandZeit: zeit, fuellstandStunden: erg.stunden });
              zeilen = zeilen.concat(MM.Tanken.zeilen(erg, tankName));
              if (wirkt('verbrauch') && erg.verbrauch) { neuW.verbrauch = erg.verbrauch; zeilen = zeilen.concat(MM.Tanken.verbrauchZeilen(erg.verbrauch)); }
              if (wirkt('reichweite')) {
                if (erg.reichweite) { neuW.reichweite = erg.reichweite; zeilen = zeilen.concat(MM.Tanken.reichweiteZeilen(erg.reichweite)); } else delete neuW.reichweite;
              }
              zusatz.push({ tabelle: 'komponenteneintraege', objekt: { id: neueId('ke'), komponenteId: tankId, nr: v.tk.aktuell.nr + 1, werte: neuW,
                quelle: 'aktion', korrekturZu: v.tk.aktuell.id, erstelltAm: self.jetzt() } });
              tank.fuellstandNach = erg.fuellstand;
            }
            tank.tankGebucht = true;
            tankErg = { tankId: tankId, name: tankName, setzen: !!(wirkt('fuellstand') && erg.setzen), fuellstand: erg.setzen ? erg.fuellstand : null, art: erg.art,
              zeilen: zeilen, hinweise: erg.hinweise.slice() };
          }
        }

        return self.ereignisAktionSpeichern(id, { text: text, datei: datei, betrag: betrag, ziel: ziel, tank: tank, lauf: lauf, zusatz: zusatz }).then(function (r) {
          if (!r.ok) return r;
          var ergebnis = { ok: true, id: id, zusammenstellung: z, kostenId: w.kostenId || null, kostenNeu: false,
            betrag: leerText(betrag) ? null : Number(String(geldRoh(betrag)).replace(',', '.')), ziel: wirkt('navi') ? String(ziel).trim() : null, navi: wirkt('navi'),
            tank: tankErg, tankSchonGebucht: !!(tankWirkt && w.tankGebucht),
            lauf: laufErg, laufSchonGebucht: !!(laufArt && w.laufGebucht) };
          if (!kostenRoh) return ergebnis;
          return self.aktivitaetLaden(x.ereignis.aktivitaetId).then(function (a) {
            if (!a) return { ok: false, fehler: { allgemein: 'Die Aktivität zu diesem Ereignis wurde nicht gefunden.' } };
            return self.kostenAnlegen(a.fahrzeug.id, Object.assign({}, kostenRoh, { aktivitaetId: x.ereignis.aktivitaetId })).then(function (k) {
              if (!k.ok) {
                var f = k.fehler || {};
                return { ok: false, gespeichert: true, fehler: { allgemein: 'Die Angaben stehen beim Eintrag, aber der Kostenposten wurde nicht angelegt: ' + (f.betrag || f.allgemein || 'Bitte den Betrag prüfen.') } };
              }
              return self.ereignisAktionSpeichern(id, { kostenId: k.id }).then(function () {
                ergebnis.kostenId = k.id; ergebnis.kostenNeu = true;
                return ergebnis;
              });
            });
          });
        });
      });
    });
  };

  Daten.prototype.ereignisDateiHolen = function (ereignisId) {
    return this.speicher.wo('ereignisdateien', 'ereignisId', ereignisId).then(function (l) { return l[0] || null; });
  };

  Daten.prototype.ereignisAendern = function (id, roh) {
    var self = this;
    return this.ereignisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      if (x.aktivitaet && x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var alt = x.aktuell.werte;
      var p = self.pruefenEreignis(roh, x.arten, alt.nachgetragen === 'ja', alt.artId);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      /* Störung (seit 2.0.26): Nur ein neues Ereignis „Störung“ legt den Vorgang in der Werkstatt an. Eine Art nachträglich auf „Störung“ zu stellen, würde die Werkstatt auslassen. */
      if (p.werte.artId !== alt.artId && !(x.ereignis && x.ereignis.vorgangId)) {
        var neueArt = x.arten.filter(function (a) { return a.objekt.id === p.werte.artId; })[0];
        if (neueArt && MM.Logbuch.istStoerungArt(neueArt.aktuell.werte.bezeichnung)) {
          return { ok: false, fehler: { artId: 'Eine Störung meldest du mit „Ereignis eintragen“ oder „Nachtragen“, damit sie auch in der Werkstatt steht. Ändere hier nicht die Art.' } };
        }
      }
      var neu = Object.assign({}, alt, p.werte);
      return self.mitVerlaufAendern('ereignis', id, { aktuell: x.aktuell }, neu, EREIGNIS_FELDER).then(function (r) {
        var anders = alt.ortName !== neu.ortName || alt.ortNameQuelle !== neu.ortNameQuelle || alt.breite !== neu.breite || alt.laenge !== neu.laenge;
        if (r && r.ok && anders) return self.ortLernenNachSpeichern(neu).then(function () { return r; });
        return r;
      });
    });
  };

  /* ---------- 2.0.14: Cockpit (schnelles Eintragen) und Tagesabschluss ---------- */
  /* Der heutige Tag: der sichtbare Tag von heute wird geöffnet, gibt es keinen, legt die App ihn von selbst an
     (ohne vorheriges „Tage vorbereiten“). Nur wenn der heutige Tag im Zeitraum der Aktivität liegt und sie nicht storniert ist. */
  Daten.prototype.heutigerTag = function (aktivitaetId) {
    var self = this;
    return this.logbuchLaden(aktivitaetId).then(function (lb) {
      if (!lb) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var a = lb.aktivitaet, heute = self.heute();
      var c = MM.Logbuch.cockpitMoeglich(a.aktuell.werte, heute);
      if (!c.moeglich) {
        var text = { storniert: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.',
          geplant: 'Die Aktivität beginnt erst am ' + MM.Hilfen.datum(a.aktuell.werte.vonDatum) + '. Das Cockpit trägt nur ein, wenn heute im Zeitraum liegt.',
          vorbei: 'Die Aktivität war bis ' + MM.Hilfen.datum(a.aktuell.werte.bisDatum) + '. Das Cockpit trägt nur ein, wenn heute im Zeitraum liegt. Im Logbuch kannst du Tage ergänzen und nachtragen.' }[c.grund];
        return { ok: false, fehler: { allgemein: text } };
      }
      var vorhanden = MM.Logbuch.heutigerAbschnitt(lb.abschnitte, heute);
      if (vorhanden) return { ok: true, abschnittId: vorhanden.objekt.id, neu: false };
      var werte = MM.Logbuch.fehlendeTage(a.aktuell.werte, []).neu.filter(function (x) { return x.datum === heute; })[0]
        || { datum: heute, beginnZeit: null, endeZeit: null, von: null, nach: null, notiz: null, ausgeblendet: 'nein' };
      return self.mitVerlaufAnlegen('tagesabschnitte', 'tagesabschnitt', 'tg', werte, { aktivitaetId: aktivitaetId, herkunft: 'vorbereitet' })
        .then(function (r) { return { ok: true, abschnittId: r.id, neu: true }; });
    });
  };

  /* Ein Tipp auf Abfahrt, Ankunft oder Notiz: Ereignis mit der Uhrzeit „jetzt“, ohne Formular.
     art: 'Abfahrt', 'Ankunft' oder 'Notiz' (Name der Art). Fehlen die Vorschläge der Arten, werden sie angelegt. */
  Daten.prototype.ereignisSchnell = function (aktivitaetId, artName, roh) {
    var self = this;
    roh = roh || {};
    return this.heutigerTag(aktivitaetId).then(function (t) {
      if (!t.ok) return t;
      return self.ereignisartenAusVorschlaegen().then(function () { return self.ereignisartenListe(); }).then(function (arten) {
        /* Ist die Art schon gewählt (artId), wird nicht nach dem Namen gesucht. */
        var art = roh.artId ? { objekt: { id: roh.artId }, aktuell: { werte: { ausgeblendet: 'nein' } } }
          : arten.filter(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === String(artName).toLowerCase(); })[0];
        if (!art) return { ok: false, fehler: { allgemein: 'Die Art „' + artName + '“ gibt es nicht.' } };
        if (art.aktuell.werte.ausgeblendet === 'ja') return { ok: false, fehler: { allgemein: 'Die Art „' + artName + '“ ist ausgeblendet. Blende sie unter „Arten von Ereignissen“ wieder ein.' } };
        /* Leere Zeit heißt „jetzt“ und wird erst beim Speichern genommen, nicht beim Öffnen der Seite. */
        var jetzt = self.jetztLokal();
        var werte = { artId: roh.artId || art.objekt.id, datum: roh.datum || jetzt.slice(0, 10), zeit: roh.zeit || jetzt.slice(11, 16), text: roh.text || '', datei: roh.datei || null };
        if (!roh.datum && roh.zeit) werte.datum = jetzt.slice(0, 10);
        /* Position (seit 2.0.21): vom GPS des Geräts, nur wenn der Aufrufer eine frische mitgibt und die Uhrzeit „jetzt“ ist (beim Nachtragen gibt es keine GPS-Position). */
        var pos = roh.position;
        var mitPosition = pos && !roh.zeit && typeof pos.breite === 'number' && typeof pos.laenge === 'number';
        if (mitPosition) {
          werte.breite = pos.breite; werte.laenge = pos.laenge;
          werte.gpsBreite = pos.breite; werte.gpsLaenge = pos.laenge; werte.gpsGenauigkeit = pos.genauigkeit;
        }
        if (roh.ortName !== undefined) werte.ortName = roh.ortName;
        if (roh.auswirkung !== undefined) werte.auswirkung = roh.auswirkung;
        /* Ohne Namen vom Nutzer schlägt die App einen bekannten Ort im Umfeld vor. Hat der Nutzer das Feld bewusst geleert (ortName ''), bleibt es leer. */
        var vorschlagen = mitPosition && roh.ortName === undefined;
        return self.ereignisAnlegen(t.abschnittId, werte, { ortVorschlag: vorschlagen }).then(function (r) {
          if (r.ok) { r.zeit = werte.zeit; r.datum = werte.datum; r.abschnittId = t.abschnittId; }
          return r;
        });
      });
    });
  };

  /* ---------- Schnellknöpfe im Cockpit (seit 2.0.18) ----------
   * Die Belegung liegt als ein Dokument „schnellknoepfe“ in „einstellungen“ (keine Umstellung des Speichers, in der
   * Sicherung enthalten). Die Regeln stehen in js/logbuch.js. */
  /*
   * knoepfeAlle: alle Knöpfe, die für die Fahrzeugart belegt sind (bis 15).
   * knoepfe:     die Knöpfe, die dieses Gerät zeigt (die ersten „geraetMax“, seit 2.0.20).
   * sonstige:    alles, was nicht auf einem gezeigten Knopf liegt (auch die Knöpfe, die dieses Gerät nicht mehr zeigt).
   */
  Daten.prototype.schnellknoepfeFuerFahrzeugart = function (artId) {
    var self = this;
    return this.ereignisartenAusVorschlaegen().then(function () { return self.werkzeugArtenEinmalSichern(); }).then(function () {
      return Promise.all([self.ereignisartenListe(), self.speicher.holen('einstellungen', 'schnellknoepfe'), self.geraetEinstellungen()]);
    }).then(function (r) {
      var angebot = MM.Logbuch.schnellAngebot(r[0], artId);
      var belegung = MM.Logbuch.schnellBelegung(r[1], artId);
      var alle = MM.Logbuch.schnellKnoepfe(belegung, angebot);
      var knoepfe = MM.Logbuch.schnellAufGeraet(alle, r[2].knoepfe);
      return { artId: artId, angebot: angebot, knoepfe: knoepfe, knoepfeAlle: alle, sonstige: MM.Logbuch.schnellSonstige(knoepfe, angebot),
        eigene: belegung.eigene, von: belegung.von, standard: belegung.keys === null, max: MM.Logbuch.MAX_SCHNELL,
        geraetMax: r[2].knoepfe, geraetGesetzt: r[2].knoepfeGesetzt, versteckt: alle.length - knoepfe.length };
    });
  };

  /* slots: Liste von Schlüsseln in der Reihenfolge der Knöpfe, leere Felder dürfen vorkommen. Die Fehler heißen s1 bis s15. */
  Daten.prototype.schnellknoepfeSetzen = function (artId, slots) {
    var self = this;
    if (!MM.Fahrzeugarten.knoten(artId)) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Fahrzeugart gibt es nicht.' } });
    slots = (slots || []).slice(0, MM.Logbuch.MAX_SCHNELL);
    return this.schnellknoepfeFuerFahrzeugart(artId).then(function (info) {
      var gueltig = {}, fehler = {}, an = {}, keys = [];
      info.angebot.alle.forEach(function (x) { gueltig[x.key] = x.name; });
      slots.forEach(function (k, i) {
        if (!k) return;
        var feld = 's' + (i + 1);
        if (!gueltig[k]) fehler[feld] = 'Das gibt es für diese Fahrzeugart nicht (mehr). Wähle etwas anderes.';
        else if (an[k]) fehler[feld] = '„' + gueltig[k] + '“ liegt schon auf Knopf ' + an[k] + '.';
        else { an[k] = i + 1; keys.push(k); }
      });
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      return self.speicher.holen('einstellungen', 'schnellknoepfe').then(function (dok) {
        return self.speicher.speichern('einstellungen', MM.Logbuch.schnellDokumentSetzen(dok, artId, keys));
      }).then(function () { return { ok: true, id: artId, anzahl: keys.length }; });
    });
  };

  /* Die Art hat dann keine eigene Liste mehr und übernimmt die der Obergruppe (oder den Standard). */
  Daten.prototype.schnellknoepfeZuruecksetzen = function (artId) {
    var self = this;
    return this.speicher.holen('einstellungen', 'schnellknoepfe').then(function (dok) {
      if (!dok || !dok.belegung || !Array.isArray(dok.belegung[artId])) return { ok: true, id: artId, geaendert: false };
      return self.speicher.speichern('einstellungen', MM.Logbuch.schnellDokumentZuruecksetzen(dok, artId)).then(function () { return { ok: true, id: artId, geaendert: true }; });
    });
  };

  /* ---------- Hat die Fahrzeugart einen Motor? (seit 2.0.20) ----------
   * Die Einstellung des Nutzers liegt als ein Dokument „fahrzeugart-motor“ in „einstellungen“ (keine Umstellung des
   * Speichers, in der Sicherung enthalten). Die Regeln stehen in js/motoren.js. Es ist nur ein Hinweis, keine Sperre. */
  var MOTOR_DOK = 'fahrzeugart-motor';

  Daten.prototype.fahrzeugartMotor = function (artId) {
    return this.speicher.holen('einstellungen', MOTOR_DOK).then(function (dok) {
      var r = MM.Motoren.motorArt(dok, artId);
      r.artId = artId;
      return r;
    });
  };

  /* wert: 'ja' oder 'nein' */
  Daten.prototype.fahrzeugartMotorSetzen = function (artId, wert) {
    var self = this;
    if (wert !== 'ja' && wert !== 'nein') return Promise.resolve({ ok: false, fehler: { allgemein: 'Bitte „Hat einen Motor“ oder „Hat keinen Motor“ wählen.' } });
    if (!MM.Fahrzeugarten.knoten(artId)) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Fahrzeugart gibt es nicht.' } });
    return this.speicher.holen('einstellungen', MOTOR_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', MM.Motoren.motorDokumentSetzen(dok, artId, wert));
    }).then(function () { return { ok: true, id: artId, wert: wert }; });
  };

  /* Die Art hat dann keine eigene Einstellung mehr und übernimmt die der Obergruppe (oder die Voreinstellung). */
  Daten.prototype.fahrzeugartMotorZuruecksetzen = function (artId) {
    var self = this;
    return this.speicher.holen('einstellungen', MOTOR_DOK).then(function (dok) {
      if (!dok || !dok.werte || (dok.werte[artId] !== 'ja' && dok.werte[artId] !== 'nein')) return { ok: true, id: artId, geaendert: false };
      return self.speicher.speichern('einstellungen', MM.Motoren.motorDokumentSetzen(dok, artId, null)).then(function () { return { ok: true, id: artId, geaendert: true }; });
    });
  };

  /* ---------- Einstellungen dieses Geräts (seit 2.0.20) ----------
   * Was nur für das einzelne Gerät gilt (zum Beispiel wie viele Knöpfe das Cockpit zeigt), liegt als ein Dokument
   * „geraet“ in „einstellungen“. Es wird nicht in die Sicherung geschrieben und beim Einspielen einer Sicherung
   * nicht überschrieben: Ein Tablet bleibt ein Tablet, auch wenn die Daten vom Handy stammen. */
  var GERAET_DOK = 'geraet';

  Daten.prototype.geraetEinstellungen = function () {
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      var n = MM.Logbuch.geraetKnoepfeGueltig(dok && dok.knoepfe);
      return { knoepfe: n === null ? MM.Logbuch.SCHNELL_GERAET_STANDARD : n, knoepfeGesetzt: n !== null };
    });
  };

  /* Wartezeit der Motorstopp-Frage in Minuten auf diesem Gerät: { wartezeit, gesetzt } (Vorgabe MM.Motoren.WARTEZEIT_STANDARD). */
  Daten.prototype.geraetWartezeit = function () {
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      var wz = MM.Motoren.wartezeitGueltig(dok && dok.motorFrageMinuten);
      return { wartezeit: wz === null ? MM.Motoren.WARTEZEIT_STANDARD : wz, gesetzt: wz !== null };
    });
  };

  /* Wartezeit der Motorstopp-Frage in Minuten (1 bis 1440), nur für dieses Gerät (seit 2.0.22). */
  Daten.prototype.geraetWartezeitSetzen = function (wert) {
    var self = this;
    var n = MM.Motoren.wartezeitGueltig(wert);
    if (n === null) return Promise.resolve({ ok: false, fehler: { wartezeit: 'Bitte eine ganze Zahl von ' + MM.Motoren.WARTEZEIT_MIN + ' bis ' + MM.Motoren.WARTEZEIT_MAX + ' Minuten eintragen.' } });
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, motorFrageMinuten: n }));
    }).then(function () { return { ok: true, wartezeit: n }; });
  };

  /* Höchstzahl der Knöpfe im Cockpit auf diesem Gerät: ganze Zahl von 0 bis 15. */
  Daten.prototype.geraetKnoepfeSetzen = function (wert) {
    var self = this;
    var n = MM.Logbuch.geraetKnoepfeGueltig(wert);
    if (n === null) return Promise.resolve({ ok: false, fehler: { geraet: 'Bitte eine Zahl von 0 bis ' + MM.Logbuch.MAX_SCHNELL + ' wählen.' } });
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, knoepfe: n }));
    }).then(function () { return { ok: true, knoepfe: n }; });
  };

  /* Tagesabschluss (wie in V1): tatsächliches Ziel und Notiz, als neue Felder am Tagesabschnitt.
     Der Zählerstand am Ende gehört zu Schritt 6 und ist nicht dabei. */
  Daten.prototype.tagesabschlussSpeichern = function (abschnittId, roh) {
    var self = this;
    roh = roh || {};
    return this.abschnittLaden(abschnittId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = pruefeWerte([{ key: 'zielTatsaechlich', typ: 'text' }, { key: 'abschlussNotiz', typ: 'text' }], roh, jahrVon(self), { ohneBezeichnung: true });
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, x.abschnitt.aktuell.werte, { zielTatsaechlich: p.werte.zielTatsaechlich || null, abschlussNotiz: p.werte.abschlussNotiz || null });
      return self.mitVerlaufAendern('tagesabschnitt', abschnittId, { aktuell: x.abschnitt.aktuell }, neu, ABSCHNITT_FELDER);
    });
  };

  /* ---------- Wechsel des Verantwortlichen als Ereignis ---------- */
  /* Der Wechsel selbst bleibt in der Tabelle „verantwortung“. Korrekturen stehen im Verlauf und gelten ab sofort überall. */
  Daten.prototype.wechselLaden = function (verantwortungId) {
    var self = this;
    return this.speicher.holen('verantwortung', verantwortungId).then(function (rec) {
      if (!rec) return null;
      return Promise.all([self.aktivitaetLaden(rec.aktivitaetId), self.speicher.wo('verlaeufe', 'objektId', verantwortungId)]).then(function (r) {
        var a = r[0];
        if (!a) return null;
        var wz = MM.Logbuch.wechselEreignisse(a.verantwortung).filter(function (x) { return x.verantwortungId === verantwortungId; })[0];
        if (!wz) return null;
        var eintraege = r[1].filter(function (e) { return e.objektTyp === 'verantwortung'; }).sort(nachNr);
        var basis = { id: 'basis', objektTyp: 'verantwortung', objektId: verantwortungId, nr: 0, quelle: 'hand', korrekturZu: null, erstelltAm: rec.erstelltAm,
          werte: { abDatum: rec.ab.slice(0, 10), abZeit: rec.ab.slice(11, 16), notiz: null, ausgeblendet: 'nein' } };
        return { wechsel: wz, aktivitaet: a, eintraege: eintraege, verlauf: verlaufAus([basis].concat(eintraege), WECHSEL_FELDER) };
      });
    });
  };

  Daten.prototype.wechselAendern = function (verantwortungId, roh) {
    var self = this;
    roh = roh || {};
    var p = pruefeWerte([{ key: 'abDatum', typ: 'datum' }, { key: 'abZeit', typ: 'zeit' }, { key: 'notiz', typ: 'text' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var f = p.fehler, w = p.werte;
    if (!w.abDatum && !f.abDatum) f.abDatum = 'Bitte das Datum des Wechsels angeben.';
    if (!w.abZeit && !f.abZeit) f.abZeit = 'Bitte die Uhrzeit des Wechsels angeben.';
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return this.wechselLaden(verantwortungId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Wechsel wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var ab = w.abDatum + 'T' + w.abZeit;
      var liste = x.aktivitaet.verantwortung;
      var i = liste.map(function (v) { return v.id; }).indexOf(verantwortungId);
      var davor = liste[i - 1], danach = liste[i + 1];
      if (davor && ab <= davor.ab) return { ok: false, fehler: { abDatum: 'Der Wechsel muss nach dem vorherigen Wechsel liegen (' + davor.ab.replace('T', ', ') + ' Uhr).' } };
      if (danach && ab >= danach.ab) return { ok: false, fehler: { abDatum: 'Der Wechsel muss vor dem nächsten Wechsel liegen (' + danach.ab.replace('T', ', ') + ' Uhr).' } };
      var jetztStand = x.verlauf[0].eintrag.werte;
      if (!unterschiedeFelder(WECHSEL_FELDER, jetztStand, w).length) return { ok: true, id: verantwortungId, geaendert: false };
      var letzte = x.eintraege[x.eintraege.length - 1];
      var e = neuerVerlaufEintrag('verantwortung', verantwortungId, letzte ? letzte.nr + 1 : 1, w, letzte ? letzte.id : null, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: verantwortungId, geaendert: true }; });
    });
  };

  /* ---------- Import und Export (seit 2.0.30) ----------
   * Import: Fahrzeuge aus einer Tabelle (Excel oder CSV). Erst die Vorschau, dann das Übernehmen. Es wird nie etwas überschrieben:
   * Ein Fahrzeug, das es schon gibt (gleiches Kennzeichen, gleiche Registriernummer, FIN oder HIN, sonst gleiche Bezeichnung),
   * wird übersprungen. Die Fahrzeuge entstehen alle in einem Zug, oder keines.
   * Export: Fahrzeuge, Kosten und Orte als Tabellen (Excel oder CSV).
   * Das Lesen und Schreiben der Dateien steht in austausch.js. */
  var IMPORT_MAX = 1000;
  var ART_SYNONYME = { pkw: 'auto', pw: 'auto', kfz: 'auto', automobil: 'auto', wagen: 'auto', krad: 'motorrad', camper: 'wohnmobil', reisemobil: 'wohnmobil', womo: 'wohnmobil',
    caravan: 'wohnwagen', wohnanhaenger: 'wohnwagen', anhaenger: 'wohnwagen', segelyacht: 'segelboot', segler: 'segelboot', katamaran: 'segelboot-katamaran',
    jolle: 'segelboot-jolle', flieger: 'flugzeug', motoryacht: 'boot' };

  function artAusText(text) {
    var A = MM.Austausch, n = A.norm(text);
    if (!n) return null;
    var arten = MM.Fahrzeugarten.alle(false), i;
    for (i = 0; i < arten.length; i++) { if (A.norm(arten[i].name) === n || A.norm(arten[i].id) === n) return arten[i].id; }
    var s = ART_SYNONYME[n];
    return s && MM.Fahrzeugarten.sichtbar(s) ? s : null;
  }

  function zelleLeer(z) { return z === null || z === undefined || String(z).trim() === ''; }
  function feldLabel(f) { return f.label + (f.einheit ? ' (' + f.einheit + ')' : ''); }

  /* Die Felder, die eine Spalte bekommen kann. Mit Art: die Felder dieser Art. Ohne Art (steht in einer Spalte): alle Felder aller Arten
     und dazu die Spalte „Fahrzeugart“. */
  Daten.prototype.importZielfelder = function (artId) {
    var liste = [{ key: 'bezeichnung', label: 'Bezeichnung' }], gesehen = { bezeichnung: true };
    if (!artId) liste.push({ key: '__art', label: 'Fahrzeugart' });
    var arten = artId ? [artId] : MM.Fahrzeugarten.alle(false).map(function (a) { return a.id; });
    arten.forEach(function (id) {
      MM.Fahrzeugarten.felder(id).forEach(function (f) {
        if (gesehen[f.key]) return;
        gesehen[f.key] = true;
        liste.push({ key: f.key, label: feldLabel(f), feld: f });
      });
    });
    return liste;
  };

  /*
   * opt = { zeilen: [[Zelle, …], …] (nur Daten, ohne Kopfzeile), zuordnung: [Schlüssel je Spalte oder ''], artId: Art für alle Zeilen oder '',
   *         ersteNr: Zeilennummer der ersten Datenzeile in der Datei (für die Anzeige) }
   * Ergebnis: { ok, zeilen: [{ nr, status: 'neu' | 'vorhanden' | 'doppelt' | 'fehler', artId, artName, bezeichnung, kennung, werte, fehlerListe }], zaehlung, nichtVerwendet }
   */
  Daten.prototype.importVorschau = function (opt) {
    var self = this, A = MM.Austausch;
    opt = opt || {};
    var zeilen = opt.zeilen || [], zuordnung = opt.zuordnung || [], standardArt = opt.artId || null, ersteNr = opt.ersteNr || 1;
    if (zeilen.length > IMPORT_MAX) return Promise.resolve({ ok: false, fehler: 'Die Tabelle hat mehr als ' + IMPORT_MAX + ' Zeilen. Bitte in kleinere Dateien teilen.' });
    if (!zeilen.length) return Promise.resolve({ ok: false, fehler: 'Unter der Kopfzeile stehen keine Zeilen.' });
    if (standardArt) {
      var wahl = MM.Fahrzeugarten.art(standardArt);
      if (!wahl || wahl.gruppe || !MM.Fahrzeugarten.sichtbar(standardArt)) return Promise.resolve({ ok: false, fehler: 'Bitte die Fahrzeugart wählen.' });
    }
    var artSpalte = -1, hatName = false, sp;
    for (sp = 0; sp < zuordnung.length; sp++) {
      if (zuordnung[sp] === '__art') artSpalte = sp;
      if (zuordnung[sp] === 'bezeichnung' || zuordnung[sp] === 'marke' || zuordnung[sp] === 'modell') hatName = true;
    }
    if (!standardArt && artSpalte < 0) return Promise.resolve({ ok: false, fehler: 'Bitte die Fahrzeugart wählen oder eine Spalte mit der Fahrzeugart zuordnen.' });
    if (!hatName) return Promise.resolve({ ok: false, fehler: 'Bitte mindestens eine Spalte der Bezeichnung zuordnen. Es geht auch mit Marke oder Modell.' });
    var kennungen = ['kennzeichen', 'registriernummer', 'fin', 'hin'];
    var alleFelder = {};
    self.importZielfelder(null).forEach(function (z) { alleFelder[z.key] = z.label; });

    return this.fahrzeugListe().then(function (liste) {
      var da = { kennung: {}, bez: {} }, gesehen = { kennung: {}, bez: {} };
      liste.forEach(function (f) {
        var w = f.aktuell.werte, hat = false;
        kennungen.forEach(function (k) { if (w[k]) { da.kennung[A.kennungNorm(w[k])] = true; hat = true; } });
        da.bez[String(w.bezeichnung || '').trim().toLowerCase()] = true;
      });
      var nichtVerwendet = {}, ergebnis = [], zaehlung = { neu: 0, vorhanden: 0, doppelt: 0, fehler: 0 };
      zeilen.forEach(function (zelle, i) {
        var alleLeer = true, s;
        for (s = 0; s < zuordnung.length; s++) { if (zuordnung[s] && !zelleLeer(zelle[s])) { alleLeer = false; break; } }
        if (alleLeer) return;
        var nr = ersteNr + i, artId = standardArt, artFehler = null;
        if (artSpalte >= 0 && !zelleLeer(zelle[artSpalte])) {
          var a = artAusText(zelle[artSpalte]);
          if (a) artId = a; else artFehler = 'Die Fahrzeugart „' + String(zelle[artSpalte]).trim() + '“ kennt die App nicht.';
        }
        if (!artId && !artFehler) artFehler = 'In dieser Zeile steht keine Fahrzeugart.';
        if (artFehler) {
          zaehlung.fehler++;
          ergebnis.push({ nr: nr, status: 'fehler', artId: null, artName: '', bezeichnung: '', kennung: '', werte: null, fehlerListe: [artFehler] });
          return;
        }
        var felder = MM.Fahrzeugarten.felder(artId), nachKey = {};
        felder.forEach(function (f) { nachKey[f.key] = f; });
        var roh = {};
        for (s = 0; s < zuordnung.length; s++) {
          var key = zuordnung[s];
          if (!key || key === '__art') continue;
          if (key === 'bezeichnung') { roh.bezeichnung = zelleLeer(zelle[s]) ? '' : String(zelle[s]).trim(); continue; }
          var f = nachKey[key];
          if (!f) { if (!zelleLeer(zelle[s])) nichtVerwendet[key] = true; continue; }
          roh[key] = A.wertUmwandeln(f, zelle[s]);
        }
        var bezLeer = !String(roh.bezeichnung || '').trim();
        if (bezLeer) {
          var teile = [roh.marke, roh.modell].filter(function (t) { return t && String(t).trim(); });
          if (teile.length) roh.bezeichnung = teile.join(' ');
        }
        var p = self.pruefen(artId, roh), art = MM.Fahrzeugarten.art(artId), fehlerListe = [];
        if (!p.ok) {
          Object.keys(p.fehler).forEach(function (k) {
            if (k === 'bezeichnung') { fehlerListe.push('Die Zeile hat keine Bezeichnung, Marke oder Modell.'); return; }
            fehlerListe.push((nachKey[k] ? nachKey[k].label : k) + ': ' + p.fehler[k] + (roh[k] ? ' (gelesen: „' + roh[k] + '“)' : ''));
          });
        }
        var w = p.werte, ids = kennungen.filter(function (k) { return w[k]; }).map(function (k) { return A.kennungNorm(w[k]); });
        var eintrag = { nr: nr, status: 'neu', artId: artId, artName: art ? art.name : artId, bezeichnung: w.bezeichnung || '', kennung: w[art && art.kennung] || w.kennzeichen || w.registriernummer || '', werte: w, fehlerListe: fehlerListe };
        if (!p.ok) eintrag.status = 'fehler';
        else {
          var bezKey = String(w.bezeichnung).trim().toLowerCase();
          if (ids.length ? ids.some(function (k) { return da.kennung[k]; }) : da.bez[bezKey]) eintrag.status = 'vorhanden';
          else if (ids.length ? ids.some(function (k) { return gesehen.kennung[k]; }) : gesehen.bez[bezKey]) eintrag.status = 'doppelt';
          else { ids.forEach(function (k) { gesehen.kennung[k] = true; }); gesehen.bez[bezKey] = true; }
        }
        zaehlung[eintrag.status]++;
        ergebnis.push(eintrag);
      });
      if (!ergebnis.length) return { ok: false, fehler: 'In den zugeordneten Spalten steht nichts.' };
      return { ok: true, zeilen: ergebnis, zaehlung: zaehlung, nichtVerwendet: Object.keys(nichtVerwendet).map(function (k) { return alleFelder[k] || k; }) };
    });
  };

  /* Legt alle Fahrzeuge der Vorschau mit Status „neu“ an, in einem Zug. Die Vorschau wird dafür noch einmal gerechnet. */
  Daten.prototype.importFahrzeuge = function (opt) {
    var self = this;
    return this.importVorschau(opt).then(function (v) {
      if (!v.ok) return v;
      var neu = v.zeilen.filter(function (z) { return z.status === 'neu'; });
      if (!neu.length) return { ok: false, fehler: 'Es gibt nichts zu übernehmen.' };
      var jetzt = self.jetzt(), schreiben = [], ids = [];
      neu.forEach(function (z) {
        var fz = { id: neueId('fz'), datenraumId: self.datenraumId, art: z.artId, erstelltAm: jetzt };
        var en = { id: neueId('en'), fahrzeugId: fz.id, nr: 1, werte: z.werte, quelle: 'import', korrekturZu: null, erstelltAm: jetzt };
        schreiben.push({ tabelle: 'fahrzeuge', objekt: fz }, { tabelle: 'eintraege', objekt: en });
        ids.push(fz.id);
      });
      return self.speicher.mehrereSpeichern(schreiben).then(function () {
        return { ok: true, anzahl: neu.length, vorhanden: v.zaehlung.vorhanden, doppelt: v.zaehlung.doppelt, fehler: v.zaehlung.fehler, ids: ids };
      });
    });
  };

  /* ----- Export ----- */
  function exportZelle(feld, v) {
    if (v === null || v === undefined || v === '') return '';
    if (feld.typ === 'datum') return { d: v };
    if (feld.typ === 'zahl' || feld.typ === 'ganzzahl') return typeof v === 'number' ? v : Number(v);
    if (feld.typ === 'auswahl' || feld.typ === 'mehrfach' || feld.typ === 'liste') return MM.Hilfen ? (MM.Hilfen.wert(feld, v) || '') : String(v);
    return String(v);
  }
  function optLabel(felder, key, wert) {
    if (wert === null || wert === undefined || wert === '') return '';
    for (var i = 0; i < felder.length; i++) {
      if (felder[i].key !== key) continue;
      var o = (felder[i].optionen || []).filter(function (x) { return x.wert === wert; })[0];
      return o ? o.label : String(wert);
    }
    return String(wert);
  }

  function tabelleFahrzeuge(self) {
    return self.fahrzeugListe().then(function (liste) {
      var benutzt = {}, spalten = [], gesehen = {};
      liste.forEach(function (f) { benutzt[f.fahrzeug.art] = true; });
      var reihe = MM.Fahrzeugarten.alle(true).map(function (a) { return a.id; });
      Object.keys(benutzt).forEach(function (id) { if (reihe.indexOf(id) < 0) reihe.push(id); });
      reihe.forEach(function (id) {
        if (!benutzt[id] || !MM.Fahrzeugarten.art(id)) return;
        MM.Fahrzeugarten.felder(id).forEach(function (fe) { if (!gesehen[fe.key]) { gesehen[fe.key] = true; spalten.push(fe); } });
      });
      var kopf = ['Bezeichnung', 'Art'].concat(spalten.map(feldLabel));
      var zeilen = liste.map(function (f) {
        var w = f.aktuell.werte, art = MM.Fahrzeugarten.art(f.fahrzeug.art);
        return [w.bezeichnung, art ? art.name : f.fahrzeug.art].concat(spalten.map(function (fe) { return exportZelle(fe, w[fe.key]); }));
      });
      return { name: 'Fahrzeuge', zeilen: [kopf].concat(zeilen) };
    });
  }

  function tabelleKosten(self) {
    var felder = MM.Kosten.felderAlle();
    return self.fahrzeugListe({ alle: true }).then(function (liste) {
      return Promise.all(liste.map(function (f) { return self.kostenListe(f.fahrzeug.id); })).then(function (alle) {
        var kopf = ['Fahrzeug', 'Datum', 'Bezeichnung', 'Gruppe', 'Art der Kosten', 'Betrag (€)', 'Wie oft', 'Bis', 'Grundlage', 'Bezahlt mit', 'Währung', 'Betrag in der Währung', 'Ort', 'Ort (Text)', 'Aktivität', 'Komponente', 'Vorgang', 'Notiz', 'Ausgeblendet'];
        var zeilen = [];
        alle.forEach(function (posten, i) {
          var fz = liste[i].aktuell.werte.bezeichnung;
          posten.forEach(function (k) {
            var w = k.aktuell.werte;
            zeilen.push([fz, w.datum ? { d: w.datum } : '', w.bezeichnung || '', optLabel(felder, 'gruppe', w.gruppe), k.artName || '', typeof w.betrag === 'number' ? w.betrag : '',
              optLabel(felder, 'rhythmus', w.rhythmus), w.bis ? { d: w.bis } : '', optLabel(felder, 'grundlage', w.grundlage), k.zahlungName || '', w.waehrung || '',
              typeof w.betragWaehrung === 'number' ? w.betragWaehrung : '', k.ortName || '', w.ortText || '', k.aktivitaetName || '', k.komponenteName || '', k.vorgangName || '', w.notiz || '',
              w.ausgeblendet === 'ja' ? 'Ja' : '']);
          });
        });
        return { name: 'Kosten', zeilen: [kopf].concat(zeilen) };
      });
    });
  }

  function tabelleOrte(self) {
    return self.orteListe().then(function (liste) {
      var kopf = ['Name', 'Art des Ortes', 'Land', 'Adresse', 'Breite (Dezimalgrad)', 'Länge (Dezimalgrad)', 'Ausstattung', 'Weitere Ausstattung', 'Ansprechpartner', 'Telefon', 'Notiz', 'Ausgeblendet'];
      var zeilen = liste.map(function (o) {
        var w = o.aktuell.werte;
        return [w.bezeichnung || '', w.ortart ? (MM.Orte.ortartLabel(w.ortart) || w.ortart) : '', w.land || '', w.adresse || '',
          typeof w.positionBreite === 'number' ? w.positionBreite : '', typeof w.positionLaenge === 'number' ? w.positionLaenge : '',
          Array.isArray(w.ausstattung) ? w.ausstattung.map(MM.Orte.ausstattungLabel).join(', ') : '', w.ausstattungSonst || '', w.ansprechpartner || '', w.telefon || '', w.notiz || '',
          w.ausgeblendet === 'ja' ? 'Ja' : ''];
      });
      return { name: 'Orte', zeilen: [kopf].concat(zeilen) };
    });
  }

  var EXPORT_TABELLEN = [{ wert: 'fahrzeuge', label: 'Fahrzeuge', bau: tabelleFahrzeuge }, { wert: 'kosten', label: 'Kosten (alle Fahrzeuge, auch die Reisekasse)', bau: tabelleKosten }, { wert: 'orte', label: 'Orte', bau: tabelleOrte }];
  Daten.prototype.exportAuswahl = function () { return EXPORT_TABELLEN.map(function (t) { return { wert: t.wert, label: t.label }; }); };

  /* was = Liste der Tabellen ('fahrzeuge', 'kosten', 'orte'), format = 'xlsx' oder 'csv' (CSV nur mit einer Tabelle). */
  Daten.prototype.exportDatei = function (was, format) {
    var self = this, A = MM.Austausch;
    was = (was || []).filter(function (w) { return EXPORT_TABELLEN.some(function (t) { return t.wert === w; }); });
    if (!was.length) return Promise.resolve({ ok: false, fehler: 'Bitte wählen, was ausgegeben werden soll.' });
    if (format !== 'xlsx' && format !== 'csv') return Promise.resolve({ ok: false, fehler: 'Bitte das Format wählen.' });
    if (format === 'csv' && was.length > 1) return Promise.resolve({ ok: false, fehler: 'Eine CSV-Datei enthält nur eine Tabelle. Wähle eine Tabelle oder das Format Excel.' });
    var bauer = {};
    EXPORT_TABELLEN.forEach(function (t) { bauer[t.wert] = t.bau; });
    return Promise.all(was.map(function (w) { return bauer[w](self); })).then(function (tabellen) {
      var tag = lokalesDatum(self.jetzt()), name = 'MobiMory-' + (tabellen.length === 1 ? tabellen[0].name : 'Daten') + '-' + tag;
      var bytes = format === 'xlsx' ? A.xlsxSchreiben(tabellen) : A.csvSchreiben(tabellen[0].zeilen);
      return { ok: true, bytes: bytes, name: name + '.' + format, groesse: bytes.length,
        mime: format === 'xlsx' ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' : 'text/csv',
        tabellen: tabellen.map(function (t) { return { name: t.name, anzahl: t.zeilen.length - 1 }; }) };
    });
  };

  /* ---------- Routen, Wetter und Tide, GPS-Strecke (seit 2.0.33, Schritt 9) ---------- */
  /*
   * Eine Route gehört zu einer Aktivität (Tabelle „routen“: id, datenraumId, aktivitaetId, fahrzeugId, format, dateiName, punkte, laengeKm,
   * anzahlGelesen, erstelltAm). Die Punkte stammen aus der eingelesenen Datei und ändern sich nicht. Name, Reisegeschwindigkeit, Abfahrt, Notiz
   * und „ausgeblendet“ stehen im Verlauf. Es gilt immer die neueste Route, die nicht ausgeblendet ist. Nichts wird gelöscht.
   * Wetter und Tide aus dem Netz liegen als Dokument „wetter-<routeId>“ in „einstellungen“ (gekürzt auf die Stunden um die Ankunftszeiten),
   * damit die Auswertung auch ohne Netz da ist. Die GPS-Strecke eines Geräts liegt als Dokument „gpsspur-<aktivitaetId>“ in „einstellungen“.
   * Beides ist in der Sicherung enthalten.
   */
  /* Als Funktion, damit das Modul Routen erst beim Gebrauch gebraucht wird. */
  function routeFelder() {
    return [
      { key: 'geschwindigkeit', label: 'Reisegeschwindigkeit', typ: 'zahl' },
      { key: 'einheit', label: 'Einheit der Geschwindigkeit', typ: 'auswahl', optionen: MM.Routen.EINHEITEN },
      { key: 'abfahrtDatum', label: 'Abfahrt (Datum)', typ: 'datum' },
      { key: 'abfahrtZeit', label: 'Abfahrt (Uhrzeit)', typ: 'zeit' },
      { key: 'wetterArt', label: 'Wetterpunkte: Abstand nach', typ: 'auswahl', optionen: MM.Routen.WETTER_ARTEN },
      { key: 'wetterAbstand', label: 'Wetterpunkte: Abstand', typ: 'zahl' },
      { key: 'wetterEinheit', label: 'Wetterpunkte: Einheit', typ: 'auswahl', optionen: [{ wert: 'km', label: 'km' }, { wert: 'sm', label: 'sm' }, { wert: 'h', label: 'Stunden' }] },
      { key: 'notiz', label: 'Notiz', typ: 'text' }
    ];
  }
  function routeVerlaufFelder() {
    return [{ key: 'bezeichnung', label: 'Name', typ: 'text' }].concat(routeFelder(), [{ key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }]);
  }

  /* Alle Routen einer Aktivität, die neueste zuerst. */
  Daten.prototype.routenListe = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.speicher.wo('routen', 'aktivitaetId', aktivitaetId), this.speicher.alle('verlaeufe')]).then(function (r) {
      var ver = {};
      r[1].forEach(function (e) { if (e.objektTyp === 'route') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      return r[0].filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
        var l = (ver[o.id] || []).slice().sort(nachNr);
        return { objekt: o, aktuell: l[l.length - 1] || null };
      }).filter(function (x) { return x.aktuell; }).sort(function (a, b) { return a.objekt.erstelltAm < b.objekt.erstelltAm ? 1 : (a.objekt.erstelltAm > b.objekt.erstelltAm ? -1 : 0); });
    });
  };

  function routeFehler(text, feld) { var f = {}; f[feld || 'allgemein'] = text; return { ok: false, fehler: f }; }

  /*
   * Eine Routendatei übernehmen. text ist der Inhalt der Datei, dateiName ihr Name.
   * Die Route wird die gültige Route der Aktivität, frühere Routen werden ausgeblendet (bleiben aber erhalten).
   * Vorbelegt: Name aus der Datei, Einheit nach Fahrzeug (Knoten auf dem Wasser, sonst km/h), Abfahrt aus dem Beginn der Aktivität.
   */
  Daten.prototype.routeImportieren = function (aktivitaetId, text, dateiName) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.routenListe(aktivitaetId)]).then(function (r) {
      var a = r[0], alte = r[1];
      if (!a) return routeFehler('Diese Aktivität wurde nicht gefunden.');
      if (a.aktuell.werte.status === 'storniert') return routeFehler('Diese Aktivität ist storniert. Stelle sie zuerst wieder her.');
      var gelesen = MM.Routen.lesen(text, dateiName);
      if (!gelesen.ok) return routeFehler(gelesen.fehler, 'datei');
      var name = trimmed(gelesen.name) || trimmed(String(dateiName || '').replace(/\.[A-Za-z0-9]+$/, '')) || 'Route';
      var w = { bezeichnung: name.slice(0, 120), geschwindigkeit: null, einheit: a.fahrzeug.welt === 'wasser' ? 'kn' : 'kmh',
        abfahrtDatum: a.aktuell.werte.vonDatum || null, abfahrtZeit: a.aktuell.werte.vonZeit || null, wetterArt: null, wetterAbstand: null, wetterEinheit: null, notiz: null, ausgeblendet: 'nein' };
      var jetzt = self.jetzt();
      var o = { id: neueId('ro'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, fahrzeugId: a.fahrzeug.id, format: gelesen.format, dateiName: trimmed(dateiName) || null,
        punkte: gelesen.punkte, laengeKm: gelesen.laengeKm, anzahlGelesen: gelesen.anzahlGelesen, erstelltAm: jetzt };
      var batch = [{ tabelle: 'routen', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('route', o.id, 1, w, null, jetzt) }];
      alte.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; }).forEach(function (x) {
        batch.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('route', x.objekt.id, x.aktuell.nr + 1, Object.assign({}, x.aktuell.werte, { ausgeblendet: 'ja' }), x.aktuell.id, jetzt) });
      });
      return self.speicher.mehrereSpeichern(batch).then(function () {
        return { ok: true, id: o.id, name: w.bezeichnung, format: gelesen.format, punkte: gelesen.punkte.length, laengeKm: gelesen.laengeKm, hinweise: gelesen.hinweise };
      });
    });
  };

  Daten.prototype.routeLaden = function (id) { return this.mitVerlaufLaden('routen', id, routeVerlaufFelder()); };

  /* Prüft Name, Geschwindigkeit und Abfahrt einer Route. */
  Daten.prototype.pruefenRoute = function (roh) {
    var p = pruefeWerte(routeFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte der Route einen Namen geben.' });
    var w = p.werte, f = p.fehler;
    if (w.bezeichnung && w.bezeichnung.length > 120) f.bezeichnung = 'Bitte höchstens 120 Zeichen eingeben.';
    if (w.geschwindigkeit !== null && !f.geschwindigkeit) {
      var grenze = w.einheit === 'kn' ? 80 : 300;
      if (!w.einheit) f.einheit = 'Bitte wählen, ob die Geschwindigkeit in Knoten oder km/h gemeint ist.';
      else if (w.geschwindigkeit <= 0) f.geschwindigkeit = 'Die Geschwindigkeit muss größer als 0 sein.';
      else if (w.geschwindigkeit > grenze) f.geschwindigkeit = 'Das ist sehr schnell (über ' + grenze + ' ' + (w.einheit === 'kn' ? 'Knoten' : 'km/h') + '). Bitte prüfen.';
    }
    if (w.abfahrtZeit && !w.abfahrtDatum && !f.abfahrtDatum) f.abfahrtDatum = 'Bitte auch das Datum der Abfahrt eingeben.';
    /* Regel der Wetterpunkte: entweder ganz leer (dann gilt die Voreinstellung) oder Art und Abstand zusammen. */
    if (!f.wetterArt && !f.wetterAbstand && !f.wetterEinheit) {
      if (w.wetterArt || w.wetterAbstand !== null) {
        if (!w.wetterArt) f.wetterArt = 'Bitte wählen, ob der Abstand nach Entfernung oder nach Fahrzeit gilt.';
        else if (w.wetterAbstand === null) f.wetterAbstand = 'Bitte den Abstand eingeben.';
        else if (w.wetterAbstand <= 0) f.wetterAbstand = 'Der Abstand muss größer als 0 sein.';
        else if (w.wetterArt === 'zeit') { w.wetterEinheit = 'h'; if (w.wetterAbstand < 0.1) f.wetterAbstand = 'Der Abstand muss mindestens 0,1 Stunden sein.'; }
        else if (w.wetterEinheit !== 'km' && w.wetterEinheit !== 'sm') f.wetterEinheit = 'Bitte km oder sm wählen.';
        else if (w.wetterAbstand * (w.wetterEinheit === 'sm' ? 1.852 : 1) < 0.1) f.wetterAbstand = 'Der Abstand muss mindestens 100 m sein.';
      } else w.wetterEinheit = null;
    }
    w.ausgeblendet = w.ausgeblendet || 'nein';
    return { ok: Object.keys(f).length === 0, werte: w, fehler: f };
  };

  /* Name, Reisegeschwindigkeit, Abfahrt und Notiz einer Route ändern. */
  Daten.prototype.routeAendern = function (id, roh) {
    var self = this;
    return this.routeLaden(id).then(function (x) {
      if (!x) return routeFehler('Diese Route wurde nicht gefunden.');
      var p = self.pruefenRoute(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, x.aktuell.werte, p.werte, { ausgeblendet: x.aktuell.werte.ausgeblendet });
      return self.mitVerlaufAendern('route', id, x, neu, routeVerlaufFelder());
    });
  };

  /* Diese Route gilt jetzt: Sie wird eingeblendet, alle anderen Routen der Aktivität werden ausgeblendet. */
  Daten.prototype.routeVerwenden = function (aktivitaetId, routeId) {
    var self = this;
    return this.routenListe(aktivitaetId).then(function (liste) {
      var ziel = liste.filter(function (x) { return x.objekt.id === routeId; })[0];
      if (!ziel) return routeFehler('Diese Route wurde nicht gefunden.');
      var jetzt = self.jetzt(), batch = [];
      liste.forEach(function (x) {
        var soll = x.objekt.id === routeId ? 'nein' : 'ja';
        if (x.aktuell.werte.ausgeblendet !== soll) batch.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('route', x.objekt.id, x.aktuell.nr + 1, Object.assign({}, x.aktuell.werte, { ausgeblendet: soll }), x.aktuell.id, jetzt) });
      });
      if (!batch.length) return { ok: true, geaendert: false };
      return self.speicher.mehrereSpeichern(batch).then(function () { return { ok: true, geaendert: true }; });
    });
  };

  /* Die Route ausblenden (nichts wird gelöscht). */
  Daten.prototype.routeAusblenden = function (id) {
    var self = this;
    return this.routeLaden(id).then(function (x) {
      if (!x) return routeFehler('Diese Route wurde nicht gefunden.');
      return self.mitVerlaufAendern('route', id, x, Object.assign({}, x.aktuell.werte, { ausgeblendet: 'ja' }), routeVerlaufFelder());
    });
  };

  /* Die Abfahrt als „JJJJ-MM-TTTHH:MM“, oder null, wenn Datum oder Uhrzeit fehlt. */
  function routeAbfahrt(w) { return w.abfahrtDatum && w.abfahrtZeit ? w.abfahrtDatum + 'T' + w.abfahrtZeit : null; }

  /*
   * Alles für die Seite „Route und Wetter“ einer Aktivität.
   * Ergebnis: { ok, aktivitaet: { id, name, welt, vonDatum, vonZeit, geplanteStrecke, storniert }, route: { id, werte, format, dateiName, laengeKm, punkte, anzahlGelesen, fahrplan, wetterRegel, regelEigene, messpunkte } | null, fruehere: [...] }
   */
  Daten.prototype.routeAnsicht = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.routenListe(aktivitaetId)]).then(function (r) {
      var a = r[0], liste = r[1];
      if (!a) return routeFehler('Diese Aktivität wurde nicht gefunden.');
      var gueltig = liste.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; })[0] || null;
      var res = { ok: true, aktivitaet: { id: aktivitaetId, name: a.aktuell.werte.bezeichnung, welt: a.fahrzeug.welt, vonDatum: a.aktuell.werte.vonDatum || null, vonZeit: a.aktuell.werte.vonZeit || null,
        geplanteStrecke: a.aktuell.werte.geplanteStrecke === undefined ? null : a.aktuell.werte.geplanteStrecke, storniert: a.aktuell.werte.status === 'storniert' }, route: null,
        fruehere: liste.filter(function (x) { return x !== gueltig; }).map(function (x) {
          return { id: x.objekt.id, name: x.aktuell.werte.bezeichnung, format: x.objekt.format, laengeKm: x.objekt.laengeKm, erstelltAm: x.objekt.erstelltAm };
        }) };
      if (!gueltig) return res;
      var w = gueltig.aktuell.werte, o = gueltig.objekt;
      var fp = MM.Routen.fahrplan(o.punkte, { geschwindigkeit: w.geschwindigkeit, einheit: w.einheit, abfahrt: routeAbfahrt(w) });
      var regel = MM.Routen.wetterRegel(w, a.fahrzeug.welt);
      res.route = { id: o.id, werte: w, format: o.format, dateiName: o.dateiName, laengeKm: o.laengeKm, punkte: o.punkte, anzahlGelesen: o.anzahlGelesen, fahrplan: fp,
        wetterRegel: regel, regelEigene: !!(w.wetterArt && w.wetterAbstand),
        messpunkte: fp.ok ? MM.Routen.messpunkte(o.punkte, w.geschwindigkeit, w.einheit, regel) : [] };
      return res;
    });
  };

  /* Die Route als GPX-Datei: { ok, name (Dateiname), text }. */
  Daten.prototype.routeGpx = function (id) {
    return this.routeLaden(id).then(function (x) {
      if (!x) return routeFehler('Diese Route wurde nicht gefunden.');
      var name = x.aktuell.werte.bezeichnung;
      return { ok: true, name: (name.replace(/[^A-Za-z0-9ÄÖÜäöüß _-]+/g, '').trim().replace(/\s+/g, '-') || 'Route') + '.gpx', text: MM.Routen.gpx(name, x.objekt.punkte) };
    });
  };

  /* Die Länge der Route wird die geplante Strecke der Aktivität (damit rechnet die App Zähler-Fristen). Eine Handeingabe bleibt im Verlauf der Aktivität. */
  Daten.prototype.routeAlsGeplanteStrecke = function (aktivitaetId, routeId) {
    var self = this;
    return this.speicher.holen('routen', routeId).then(function (o) {
      if (!o || o.aktivitaetId !== aktivitaetId) return routeFehler('Diese Route wurde nicht gefunden.');
      var km = Math.round(o.laengeKm * 10) / 10;
      return aktivitaetNeuerStand(self, aktivitaetId, function (w) {
        if (w.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist storniert.' } };
        w.geplanteStrecke = km; w.sperreUebergangenAm = null;
        return { werte: w };
      }).then(function (r) { return r.ok ? Object.assign({}, r, { km: km }) : r; });
    });
  };

  /* ---- Wetter und Tide holen und auswerten ---- */
  function wetterDokId(routeId) { return 'wetter-' + routeId; }
  var WETTER_FENSTER_S = 8 * 3600, MEER_FENSTER_S = 16 * 3600;
  var MAX_VORLAUF_TAGE = 15;

  /*
   * Wetter (und bei Wasserfahrzeugen Wellen und Wasserstand) für die Messpunkte der Route zur geplanten Ankunftszeit holen und im Gerät merken.
   * Braucht Route, Geschwindigkeit und Abfahrt (Datum und Uhrzeit). Ohne Netz bleibt der alte Stand erhalten.
   * Ergebnis: { ok, punkte, ohneWetter, ohneMeer, abgerufenAm } oder { ok: false, fehler, offline? }
   */
  Daten.prototype.wetterAbrufen = function (aktivitaetId) {
    var self = this;
    return this.routeAnsicht(aktivitaetId).then(function (a) {
      if (!a.ok) return a;
      var r = a.route;
      if (!r) return routeFehler('Es gibt noch keine Route. Lies zuerst eine Routendatei ein.');
      if (!r.fahrplan.ok) return routeFehler('Bitte zuerst die Reisegeschwindigkeit der Route eintragen.', 'geschwindigkeit');
      var abfahrt = routeAbfahrt(r.werte);
      if (!abfahrt) return routeFehler('Bitte Datum und Uhrzeit der Abfahrt eintragen. Das Wetter gilt für die Ankunftszeit an jedem Punkt.', 'abfahrtDatum');
      var abfahrtMs = MM.Routen.zeitMs(abfahrt), jetztMs = new Date(self.jetzt()).getTime();
      if (abfahrtMs > jetztMs + MAX_VORLAUF_TAGE * 86400000) return routeFehler('Eine Prognose gibt es nur für die nächsten ' + MAX_VORLAUF_TAGE + ' Tage. Versuche es später noch einmal.', 'abfahrtDatum');
      if (abfahrtMs + r.fahrplan.dauerMin * 60000 < jetztMs - 86400000) return routeFehler('Die Fahrt liegt mehr als einen Tag in der Vergangenheit. Dafür holt die App kein Wetter.', 'abfahrtDatum');
      var mitMeer = a.aktivitaet.welt === 'wasser', punkte = r.messpunkte;
      var kmh = MM.Routen.geschwindigkeitKmh(r.werte.geschwindigkeit, r.werte.einheit), einheit = mitMeer ? 'kn' : 'kmh';
      return wetterAntwortenHolen(self, punkte, abfahrtMs, mitMeer, einheit).then(function (antworten) {
        var ohneWetter = antworten.filter(function (x) { return !x.wetter; }).length;
        if (ohneWetter === punkte.length) {
          return { ok: false, offline: true, fehler: { allgemein: 'Das Wetter konnte nicht geholt werden. Vermutlich ist gerade kein Netz da. Ein früher geholter Stand bleibt erhalten.' } };
        }
        var dok = { id: wetterDokId(r.id), routeId: r.id, aktivitaetId: aktivitaetId, abgerufenAm: self.jetzt(), abfahrt: abfahrt, geschwindigkeitKmh: kmh, laengeKm: r.laengeKm,
          mitMeer: mitMeer, windEinheit: einheit, regel: r.wetterRegel, messpunkte: punkte, antworten: antworten };
        return self.einstellungSchreiben(dok).then(function () {
          return { ok: true, punkte: punkte.length, ohneWetter: ohneWetter, ohneMeer: mitMeer ? antworten.filter(function (x) { return !x.meer; }).length : 0, abgerufenAm: dok.abgerufenAm };
        });
      });
    });
  };

  /*
   * Wetter (bei Wasserfahrzeugen auch Wellen und Wasserstand) für alle Punkte holen, immer vier gleichzeitig (das schont das Netz).
   * Ein Punkt ohne Antwort bleibt leer. Gemeinsam für die Route und für die Etappen (seit 2.0.43).
   * Ergebnis: Liste { wetter, meer } in der Reihenfolge der Punkte.
   */
  function wetterAntwortenHolen(self, punkte, abfahrtMs, mitMeer, einheit) {
    function holen(url) { return Promise.resolve().then(function () { return self.holeJson(url); }).catch(function () { return null; }); }
    var antworten = new Array(punkte.length), pos = 0;
    function gruppe() {
      if (pos >= punkte.length) return Promise.resolve();
      var von = pos, bis = Math.min(punkte.length, pos + 4);
      pos = bis;
      var arbeit = [];
      for (var i = von; i < bis; i++) {
        (function (i) {
          var p = punkte[i];
          arbeit.push(Promise.all([holen(MM.Routen.wetterUrl(p.breite, p.laenge, einheit)), mitMeer ? holen(MM.Routen.marineUrl(p.breite, p.laenge)) : Promise.resolve(null)]).then(function (x) {
            var eta = Math.round((abfahrtMs + p.minuten * 60000) / 1000);
            antworten[i] = { wetter: x[0] ? MM.Routen.kuerzen(x[0], eta - WETTER_FENSTER_S, eta + WETTER_FENSTER_S) : null, meer: x[1] ? MM.Routen.kuerzen(x[1], eta - MEER_FENSTER_S, eta + MEER_FENSTER_S) : null };
          }));
        })(i);
      }
      return Promise.all(arbeit).then(gruppe);
    }
    return gruppe().then(function () { return antworten; });
  }

  /* Das zuletzt geholte Wetter ist noch für diese Route, Geschwindigkeit und Abfahrt geholt worden? */
  function wetterAktuell(dok, route) {
    if (!dok || !route) return false;
    var kmh = MM.Routen.geschwindigkeitKmh(route.werte.geschwindigkeit, route.werte.einheit);
    return dok.routeId === route.id && dok.abfahrt === routeAbfahrt(route.werte) && kmh !== null && Math.abs(dok.geschwindigkeitKmh - kmh) < 0.001 && dok.laengeKm === route.laengeKm && sameRegel(dok.regel, route.wetterRegel);
  }
  /* Die Regel der Wetterpunkte beim Holen und jetzt. Ein älteres Dokument ohne Regel wurde mit der festen Regel von 2.0.34 geholt, seine Punkte passen nicht mehr. */
  function sameRegel(a, b) { if (!a) return false; if (!b) return false; return a.art === b.art && a.abstand === b.abstand && a.einheit === b.einheit; }

  var VERGLEICH_VERSATZ = [-120, -60, 0, 60, 120];

  /*
   * Das zuletzt geholte Wetter ausgewertet. versatzMin verschiebt die Abfahrt (früher oder später), die Antworten bleiben dieselben.
   * Ergebnis: { ok: false, keins: true } oder { ok, abgerufenAm, abfahrt, mitMeer, windEinheit, aktuell (passt zu den Angaben der Route), zeilen, schwerste, vergleich: [{ versatzMin, schwerste }] }
   */
  Daten.prototype.wetterStand = function (aktivitaetId, versatzMin) {
    var self = this;
    return this.routeAnsicht(aktivitaetId).then(function (a) {
      if (!a.ok) return a;
      if (!a.route) return { ok: false, keins: true };
      return self.einstellungLesen(wetterDokId(a.route.id)).then(function (dok) {
        if (!dok) return { ok: false, keins: true };
        var abfahrtMs = MM.Routen.zeitMs(dok.abfahrt), v = versatzMin || 0;
        var aus = MM.Routen.auswerten(dok.messpunkte, abfahrtMs, v, dok.antworten, dok.mitMeer);
        return { ok: true, abgerufenAm: dok.abgerufenAm, abfahrt: dok.abfahrt, mitMeer: dok.mitMeer, windEinheit: dok.windEinheit, aktuell: wetterAktuell(dok, a.route), versatzMin: v,
          zeilen: aus.zeilen, schwerste: aus.schwerste,
          vergleich: VERGLEICH_VERSATZ.map(function (m) { return { versatzMin: m, schwerste: MM.Routen.auswerten(dok.messpunkte, abfahrtMs, m, dok.antworten, dok.mitMeer).schwerste }; }) };
      });
    });
  };

  /* ---- Kilometer über GPS ---- */
  function gpsSpurId(aktivitaetId) { return 'gpsspur-' + aktivitaetId; }
  /* Die aufgezeichnete GPS-Strecke dieser Aktivität auf diesem Gerät: { km, letzter, punkte, verworfen }. */
  Daten.prototype.gpsSpurLesen = function (aktivitaetId) {
    return this.einstellungLesen(gpsSpurId(aktivitaetId)).then(function (d) { return d && d.spur ? d.spur : MM.Routen.spurNeu(); });
  };
  Daten.prototype.gpsSpurSpeichern = function (aktivitaetId, spur) {
    return this.einstellungSchreiben({ id: gpsSpurId(aktivitaetId), aktivitaetId: aktivitaetId, spur: spur, geaendertAm: this.jetzt() });
  };
  /*
   * Die GPS-Strecke in den Streckenzähler des Fahrzeugs übernehmen: neuer Stand = letzter Stand + Strecke, Quelle „gps“.
   * Der Nutzer löst das selbst aus, die App schreibt nie von allein. Hat der Zähler noch keinen Stand, trägt der Nutzer ihn zuerst von Hand ein (Handeingabe hat Vorrang).
   */
  Daten.prototype.gpsStreckeUebernehmen = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.gpsSpurLesen(aktivitaetId), this.aktivitaetLaden(aktivitaetId)]).then(function (r) {
      var spur = r[0], a = r[1];
      if (!a) return routeFehler('Diese Aktivität wurde nicht gefunden.');
      if (!(spur.km >= 0.05)) return routeFehler('Es ist noch keine GPS-Strecke aufgezeichnet.');
      return self.streckenZaehler(a.fahrzeug.id).then(function (z) {
        if (!z) return routeFehler('Am Fahrzeug gibt es keinen Zähler für die Strecke. Lege ihn am Fahrzeug unter „Zähler“ an und trage den Tachostand ein.');
        if (!z.stand) return routeFehler('Der Streckenzähler hat noch keinen Stand. Trage zuerst den Tachostand von Hand ein, dann kann die GPS-Strecke dazukommen.');
        return self.speicher.wo('zaehlerstaende', 'zaehlerId', z.id).then(function (staende) {
          var letzter = neuesterStand(staende), km = Math.round(spur.km * 10) / 10, neu = Math.round((letzter.wert + spur.km) * 10) / 10;
          var e = { id: neueId('zs'), zaehlerId: z.id, nr: letzter.nr + 1, wert: neu, datum: self.heute(),
            notiz: 'GPS-Strecke ' + String(km).replace('.', ',') + ' km (Luftlinie von Punkt zu Punkt, ' + spur.punkte + ' Punkte) in „' + a.aktuell.werte.bezeichnung + '“', quelle: 'gps', erstelltAm: self.jetzt() };
          var zurueck = { km: 0, letzter: spur.letzter, punkte: 0, verworfen: 0 };
          return self.speicher.speichern('zaehlerstaende', e).then(function () { return self.gpsSpurSpeichern(aktivitaetId, zurueck); }).then(function () {
            return { ok: true, km: km, stand: neu, einheit: z.einheit, zaehlerName: z.bezeichnung };
          });
        });
      });
    });
  };

  /* ---------- Geschwindigkeit aus dem GPS (seit 2.0.44) ----------
   * Der Zustand der laufenden Zählung liegt je Aktivität auf diesem Gerät als Dokument „gpsfahrt-<aktivitaetId>“ in „einstellungen“
   * (wie die GPS-Strecke, in der Sicherung enthalten). Gespeichert wird im Logbuch als Eintrag „Geschwindigkeit“:
   * beim Tagesabschluss (Ø fahrend, Ø Tag, Strecke, Fahrzeit, Gesamtzeit) und im Rhythmus der automatischen Einträge (derselbe wie beim Wetter). */
  function gpsFahrtId(aktivitaetId) { return 'gpsfahrt-' + aktivitaetId; }
  Daten.prototype.gpsFahrtLesen = function (aktivitaetId) {
    return this.einstellungLesen(gpsFahrtId(aktivitaetId)).then(function (d) { return d && d.fahrt ? d.fahrt : MM.Fahrt.neu(); });
  };
  Daten.prototype.gpsFahrtSpeichern = function (aktivitaetId, fahrt) {
    return this.einstellungSchreiben({ id: gpsFahrtId(aktivitaetId), aktivitaetId: aktivitaetId, fahrt: fahrt, geaendertAm: this.jetzt() });
  };

  /* Die Ereignisart „Geschwindigkeit“: vorhanden oder neu angelegt (gilt für alle Fahrzeugarten, ohne Status-Regel). Ergebnis: ihre Kennung. */
  Daten.prototype.geschwindigkeitsArtSichern = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var da = liste.filter(function (x) { return MM.Logbuch.istGeschwindigkeitsArt(x.aktuell.werte.bezeichnung); })[0];
      if (da) return da.objekt.id;
      return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: MM.Logbuch.GESCHWINDIGKEIT_ART, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(['alle']) })
        .then(function (r) { return r.id; });
    });
  };

  /*
   * Einen Eintrag „Geschwindigkeit“ ins Logbuch schreiben. opt: { fahrt: Zustand (live vom Gerät), art: 'rhythmus' | 'tag', position: frische GPS-Position oder null }.
   * Ohne begonnenen Tag (noch keine Bewegung) wird nichts geschrieben. Ergebnis: { ok, text, zeit } oder { ok: false, fehler }.
   */
  Daten.prototype.fahrtEintragen = function (aktivitaetId, opt) {
    var self = this, o = opt || {};
    var fahrt = o.fahrt || null;
    if (!fahrt || fahrt.startMs === null || fahrt.startMs === undefined) return Promise.resolve({ ok: false, fehler: { allgemein: 'Es gibt noch keine Bewegung, also noch keine Geschwindigkeit zu speichern.' } });
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (a.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var welt = a.fahrzeug.welt;
      var w = MM.Fahrt.werte(fahrt, Date.now());
      var text = MM.Fahrt.eintragText(w, welt, o.art === 'tag' ? 'tag' : 'rhythmus');
      return self.geschwindigkeitsArtSichern().then(function (artId) {
        return self.ereignisSchnell(aktivitaetId, MM.Logbuch.GESCHWINDIGKEIT_ART, { artId: artId, text: text, position: o.position || null });
      }).then(function (r) { if (r.ok) r.text = text; return r; });
    });
  };

  /*
   * Tagesabschluss: Die Werte des Tages werden einmal als Eintrag „Geschwindigkeit“ ins Logbuch geschrieben, danach bleibt der Wert dieses Tages
   * auf dem Gerät stehen und die nächste Bewegung beginnt eine neue Zählung. Ohne laufende oder gerade abgeschlossene Zählung dieses Tages geschieht nichts.
   * Der Zustand wird hier aus dem Gerätespeicher gelesen (die Oberfläche sichert ihn vorher).
   * Ergebnis: { ok: true, geschrieben: Boolean, text? } oder { ok: false, fehler }.
   */
  Daten.prototype.fahrtTagAbschliessen = function (abschnittId, opt) {
    var self = this, o = opt || {};
    return this.abschnittLaden(abschnittId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      var aktId = x.aktivitaet.aktivitaet.id, tagDatum = x.abschnitt.aktuell.werte.datum, welt = x.aktivitaet.fahrzeug.welt;
      return self.gpsFahrtLesen(aktId).then(function (f) {
        if (f.startMs === null || f.startMs === undefined || f.abgeschlossen || f.tagDatum !== tagDatum) return { ok: true, geschrieben: false };
        var jetztMs = Date.now();
        var zu = MM.Fahrt.abschliessen(f, jetztMs);
        var w = MM.Fahrt.werte(zu, jetztMs);
        var text = MM.Fahrt.eintragText(w, welt, 'tag');
        return self.geschwindigkeitsArtSichern().then(function (artId) {
          if (tagDatum === self.heute()) return self.ereignisSchnell(aktId, MM.Logbuch.GESCHWINDIGKEIT_ART, { artId: artId, text: text, position: o.position || null });
          /* Ein früherer Tag: nachgetragen mit dem Datum des Tages */
          return self.ereignisAnlegen(abschnittId, { artId: artId, datum: tagDatum, zeit: '23:59', text: text }, { nachtragen: true });
        }).then(function (r) {
          if (!r.ok) return r;
          return self.gpsFahrtSpeichern(aktId, zu).then(function () { return { ok: true, geschrieben: true, text: text }; });
        });
      });
    });
  };

  /* ---------- Karte, Weg und Wetter jetzt (seit 2.0.34, Schritt 9b) ----------
   * Weg: der tatsächlich gefahrene Weg dieser Aktivität auf diesem Gerät, Dokument „gpsweg-<aktivitaetId>“ in „einstellungen“
   *      (getrennt von der GPS-Strecke in Kilometern, die beim Übernehmen in den Zähler auf 0 geht).
   * Wetter jetzt: Wetter und bei Wasserfahrzeugen Wellen und Wasserstand am aktuellen Standort, gespeichert als Logbuch-Eintrag „Wetter“
   *      mit Datum, Uhrzeit und Position. Ohne Netz wird nichts gespeichert.
   * Offline-Karte: welche Kacheln zu einer Aktivität gehören, steht als Dokument „karte-<aktivitaetId>“ in „einstellungen“;
   *      die Kacheln selbst liegen im Cache des Browsers (js/kartenablage.js). */
  function wegDokId(aktivitaetId) { return 'gpsweg-' + aktivitaetId; }
  function karteDokId(aktivitaetId) { return 'karte-' + aktivitaetId; }

  Daten.prototype.gpsWegLesen = function (aktivitaetId) {
    return this.einstellungLesen(wegDokId(aktivitaetId)).then(function (d) { return d && d.weg ? d.weg : MM.Karte.wegNeu(); });
  };
  Daten.prototype.gpsWegSpeichern = function (aktivitaetId, weg) {
    return this.einstellungSchreiben({ id: wegDokId(aktivitaetId), aktivitaetId: aktivitaetId, weg: weg, geaendertAm: this.jetzt() });
  };

  /* Rhythmus der automatischen Wetterabfrage in Minuten (0 = aus), nur für dieses Gerät. */
  Daten.prototype.geraetWetterRhythmus = function () {
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      var n = MM.Karte.rhythmusGueltig(dok && dok.wetterRhythmus);
      return { minuten: n === null ? 0 : n, gesetzt: n !== null };
    });
  };
  Daten.prototype.geraetWetterRhythmusSetzen = function (wert) {
    var self = this, n = MM.Karte.rhythmusGueltig(wert);
    if (n === null) return Promise.resolve({ ok: false, fehler: { rhythmus: 'Bitte einen Rhythmus aus der Liste wählen.' } });
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, wetterRhythmus: n }));
    }).then(function () { return { ok: true, minuten: n }; });
  };

  /* Die Ereignisarten „Wetter“ und „Karte“ (seit 2.0.35): beim ersten Öffnen des Cockpits einmal angelegt, falls es sie nicht gibt
     (gelten für alle Fahrzeugarten). Danach nie wieder: Wer sie löscht oder ausblendet, behält das so. Ein Dokument „werkzeugarten“ merkt es sich. */
  Daten.prototype.werkzeugArtenEinmalSichern = function () {
    var self = this;
    return this.speicher.holen('einstellungen', 'werkzeugarten').then(function (dok) {
      if (dok && dok.angelegt) return { ok: true, neu: 0 };
      return self.ereignisartenListe().then(function (liste) {
        var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
        var fehlt = [MM.Karte.WETTER_ART, MM.Karte.KARTE_ART].filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
        return fehlt.reduce(function (kette, n) {
          return kette.then(function () {
            return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: n, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(['alle']) });
          });
        }, Promise.resolve()).then(function () {
          return self.speicher.speichern('einstellungen', { id: 'werkzeugarten', angelegt: true });
        }).then(function () { return { ok: true, neu: fehlt.length }; });
      });
    });
  };

  /* Die Ereignisart „Wetter“: vorhanden oder neu angelegt (gilt für alle Fahrzeugarten, ohne Status-Regel). Ergebnis: ihre Kennung. */
  Daten.prototype.wetterArtSichern = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var da = liste.filter(function (x) { return MM.Karte.istWetterArt(x.aktuell.werte.bezeichnung); })[0];
      if (da) return da.objekt.id;
      return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: MM.Karte.WETTER_ART, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(['alle']) })
        .then(function (r) { return r.id; });
    });
  };

  /*
   * Wetter jetzt: holt das Wetter für die Position (Open-Meteo, Modellwert der aktuellen Stunde) und legt den Logbuch-Eintrag „Wetter“ an.
   * position: { breite, laenge, genauigkeit } (frische GPS-Position). opt.automatisch: Text kennzeichnet die automatische Abfrage.
   * Ergebnis: { ok, text, zeit, datum, wetter, meer } oder { ok: false, fehler, offline? }. Bei einem Fehler wird nichts gespeichert.
   */
  Daten.prototype.wetterJetzt = function (aktivitaetId, position, opt) {
    var self = this, o = opt || {};
    if (!position || typeof position.breite !== 'number' || typeof position.laenge !== 'number') {
      return Promise.resolve(routeFehler('Für das Wetter braucht die App deine Position, und es gibt gerade keine GPS-Position. Warte einen Moment und versuche es noch einmal.'));
    }
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return routeFehler('Diese Aktivität wurde nicht gefunden.');
      if (a.aktuell.werte.status === 'storniert') return routeFehler('Diese Aktivität ist storniert. Stelle sie zuerst wieder her.');
      var mitMeer = a.fahrzeug.welt === 'wasser', einheit = mitMeer ? 'kn' : 'kmh';
      var sek = Math.round(new Date(self.jetzt()).getTime() / 1000);
      function holen(url) { return self.holeJson(url).then(function (x) { return x; }, function () { return null; }); }
      return Promise.all([holen(MM.Karte.wetterJetztUrl(position.breite, position.laenge, einheit)), mitMeer ? holen(MM.Karte.meerJetztUrl(position.breite, position.laenge)) : Promise.resolve(null)]).then(function (x) {
        if (!x[0] && !x[1]) return { ok: false, offline: true, fehler: { allgemein: 'Das Wetter konnte nicht geholt werden. Vermutlich ist gerade kein Netz da. Es wurde nichts gespeichert.' } };
        var w = x[0] ? MM.Routen.wetterZurZeit(x[0], sek) : null, m = x[1] ? MM.Routen.meerZurZeit(x[1], sek) : null;
        var text = MM.Karte.wetterJetztText(w, m, einheit, !!o.automatisch);
        if (!text) return { ok: false, fehler: { allgemein: 'Für diese Stelle und diese Stunde liefert das Wettermodell keine Werte. Es wurde nichts gespeichert.' } };
        return self.wetterArtSichern().then(function (artId) {
          return self.ereignisSchnell(aktivitaetId, MM.Karte.WETTER_ART, { artId: artId, text: text, position: position });
        }).then(function (r) {
          if (r.ok) { r.text = text; r.wetter = w; r.meer = m; r.windEinheit = einheit; }
          return r;
        });
      });
    });
  };

  /*
   * Alles für die Karte einer Aktivität: die geplante Route, Start, Ziel und Zwischenziele (Orte mit Position), die Wetterpunkte der Route
   * (der zuletzt geholte Stand, gerechnet mit versatzMin), die Wetter-Einträge und weitere Einträge mit Position aus dem Logbuch, und der gefahrene Weg.
   * Ergebnis: { ok, aktivitaet, route: { punkte, laengeKm, kmh, abfahrtMs, name } | null, planOrte, wetter, ereignisse, weg } oder { ok: false, fehler }.
   */
  Daten.prototype.kartenDaten = function (aktivitaetId, versatzMin) {
    var self = this;
    return Promise.all([this.routeAnsicht(aktivitaetId), this.logbuchLaden(aktivitaetId), this.gpsWegLesen(aktivitaetId), this.orteListe(), this.wetterStand(aktivitaetId, versatzMin || 0)]).then(function (r) {
      var ra = r[0], lb = r[1], ws = r[4];
      if (!ra.ok || !lb) return routeFehler('Diese Aktivität wurde nicht gefunden.');
      var a = lb.aktivitaet, w = a.aktuell.werte;
      var orte = {};
      r[3].forEach(function (x) { orte[x.objekt.id] = x.aktuell.werte; });
      function planOrt(rolle, id) {
        var ow = id ? orte[id] : null;
        if (!ow || typeof ow.positionBreite !== 'number' || typeof ow.positionLaenge !== 'number') return null;
        return { rolle: rolle, name: ow.bezeichnung, breite: ow.positionBreite, laenge: ow.positionLaenge };
      }
      var planOrte = [planOrt('start', w.startOrtId), planOrt('ziel', w.zielOrtId)].concat((w.zwischenzielIds || []).map(function (id) { return planOrt('zwischen', id); })).filter(Boolean);
      var route = null;
      if (ra.route) {
        var rw = ra.route.werte;
        route = { id: ra.route.id, name: rw.bezeichnung || ra.route.dateiName || 'Route', punkte: ra.route.punkte, laengeKm: ra.route.laengeKm,
          kmh: MM.Routen.geschwindigkeitKmh(rw.geschwindigkeit, rw.einheit), abfahrtMs: routeAbfahrt(rw) ? MM.Routen.zeitMs(routeAbfahrt(rw)) : null };
      }
      var ereignisse = [];
      lb.abschnitte.forEach(function (t) {
        if (t.ausgeblendet) return;
        t.ereignisse.forEach(function (e) {
          if (e.art !== 'ereignis' || e.ausgeblendet || typeof e.breite !== 'number' || typeof e.laenge !== 'number') return;
          ereignisse.push({ id: e.id, artName: e.artName, datum: e.datum, zeit: e.zeit, text: e.text, breite: e.breite, laenge: e.laenge, ortName: e.ortName, istWetter: MM.Karte.istWetterArt(e.artName) });
        });
      });
      return { ok: true, aktivitaet: { id: aktivitaetId, name: w.bezeichnung, welt: a.fahrzeug.welt, fahrzeugId: a.fahrzeug.id, fahrzeugName: a.fahrzeug.name, status: a.status, storniert: w.status === 'storniert' },
        route: route, planOrte: planOrte, ereignisse: ereignisse, weg: r[2],
        wetter: ws && ws.ok ? { abgerufenAm: ws.abgerufenAm, aktuell: ws.aktuell, windEinheit: ws.windEinheit, mitMeer: ws.mitMeer, zeilen: ws.zeilen, versatzMin: ws.versatzMin } : null };
    });
  };

  /* Die Punkte, für die eine Offline-Karte geholt wird: die Route, sonst Start, Ziel und Zwischenziele mit Position. */
  Daten.prototype.kartePunkte = function (aktivitaetId) {
    return this.kartenDaten(aktivitaetId, 0).then(function (kd) {
      if (!kd.ok) return { ok: false, fehler: kd.fehler, quelle: null, punkte: [] };
      if (kd.route && kd.route.punkte.length >= 2) return { ok: true, quelle: 'route', punkte: kd.route.punkte };
      if (kd.planOrte.length) return { ok: true, quelle: 'orte', punkte: kd.planOrte };
      return { ok: true, quelle: null, punkte: [] };
    });
  };

  /* Was würde eine Stufe der Offline-Karte holen? Siehe MM.Karte.planung. */
  Daten.prototype.kartePlanen = function (aktivitaetId, stufe) {
    return this.kartePunkte(aktivitaetId).then(function (p) {
      if (!p.ok) return { ok: false, grund: (p.fehler && p.fehler.allgemein) || 'Diese Aktivität wurde nicht gefunden.' };
      var pl = MM.Karte.planung(p.punkte, stufe);
      pl.quelle = p.quelle;
      return pl;
    });
  };

  /* Was ist für diese Aktivität schon im Gerät? { stufe, anzahl, bytes, geladenAm, keys } oder null. */
  Daten.prototype.karteInfo = function (aktivitaetId) {
    return this.einstellungLesen(karteDokId(aktivitaetId)).then(function (d) { return d && d.keys && d.keys.length ? d : null; });
  };

  /* Nach einem Abruf merken, welche Kacheln zu dieser Aktivität gehören (zusammen mit den früher geholten). keys: „z/x/y“, bytes: neu geholte Bytes. */
  Daten.prototype.karteMerken = function (aktivitaetId, stufe, keys, bytes) {
    var self = this;
    return this.karteInfo(aktivitaetId).then(function (alt) {
      var alle = {}, liste = [];
      ((alt && alt.keys) || []).concat(keys || []).forEach(function (k) { if (!alle[k]) { alle[k] = true; liste.push(k); } });
      var dok = { id: karteDokId(aktivitaetId), aktivitaetId: aktivitaetId, stufe: stufe, anzahl: liste.length, bytes: ((alt && alt.bytes) || 0) + (bytes || 0), geladenAm: self.jetzt(), keys: liste };
      return self.einstellungSchreiben(dok).then(function () { return { ok: true, anzahl: dok.anzahl, bytes: dok.bytes }; });
    });
  };

  /*
   * Die Offline-Karte dieser Aktivität freigeben: Das Dokument wird entfernt, zurück kommen die Kacheln, die keine andere Aktivität braucht
   * (die der Aufrufer dann aus dem Gerät löscht). Kacheln, die auch zu anderen Aktivitäten gehören, bleiben.
   */
  Daten.prototype.karteFreigeben = function (aktivitaetId) {
    var self = this;
    return this.speicher.alle('einstellungen').then(function (docs) {
      var meins = null, andere = {};
      docs.forEach(function (d) {
        if (!d.id || d.id.indexOf('karte-') !== 0 || !d.keys) return;
        if (d.id === karteDokId(aktivitaetId)) meins = d;
        else d.keys.forEach(function (k) { andere[k] = true; });
      });
      if (!meins) return { ok: true, keys: [] };
      var frei = meins.keys.filter(function (k) { return !andere[k]; });
      /* Der Speicher hat keine Löschfunktion (es wird nichts gelöscht): Das Dokument wird leer geschrieben. */
      return self.speicher.speichern('einstellungen', { id: meins.id, aktivitaetId: aktivitaetId, keys: [], anzahl: 0, bytes: 0, geladenAm: self.jetzt() }).then(function () { return { ok: true, keys: frei }; });
    });
  };

  /* ---------- Sicherung ---------- */
  var DATEI_TABELLEN = ['dateien', 'nachweisdateien', 'ereignisdateien'];
  var ZAEHL_TABELLEN = [['fahrzeuge', 'Fahrzeuge'], ['komponenten', 'Komponenten'], ['fristen', 'Fristen'], ['zaehler', 'Zähler'], ['personen', 'Personen'],
    ['tiere', 'Tiere'], ['nachweise', 'Nachweise'], ['aktivitaeten', 'Aktivitäten'], ['dokumente', 'Dokumente'],
    ['orte', 'Orte'], ['standorte', 'Standorte'], ['gebiete', 'Gebiete'], ['regeln', 'Regeln'],
    ['tagesabschnitte', 'Tagesabschnitte'], ['ereignisse', 'Ereignisse'], ['vorgaenge', 'Vorgänge'], ['adressen', 'Adressen'], ['kosten', 'Kostenposten'], ['besuche', 'Besuche'], ['kassenbuchungen', 'Kassenbuchungen'], ['routen', 'Routen'], ['reisechecks', 'Reisechecks']];

  function lokalesDatum(iso) {
    var d = new Date(iso);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
  }

  Daten.prototype.einstellungLesen = function (id) { return this.speicher.holen('einstellungen', id); };
  Daten.prototype.einstellungSchreiben = function (obj) { return this.speicher.speichern('einstellungen', obj); };

  /* Wann wurde zuletzt gesichert, und wie oft soll erinnert werden? (0 = nie erinnern) */
  Daten.prototype.sicherungInfo = function () {
    return Promise.all([this.einstellungLesen('sicherung'), this.speicher.alle('fahrzeuge'), this.speicher.alle('personen'), this.speicher.alle('tiere')]).then(function (r) {
      var e = r[0] || {};
      return { letzte: e.letzteSicherung || null, erinnerungTage: e.erinnerungTage === undefined ? 30 : e.erinnerungTage, hatDaten: (r[1].length + r[2].length + r[3].length) > 0 };
    });
  };

  Daten.prototype.sicherungEinstellen = function (aenderung) {
    var self = this;
    return this.einstellungLesen('sicherung').then(function (alt) {
      return self.einstellungSchreiben(Object.assign({ id: 'sicherung', letzteSicherung: null, erinnerungTage: 30 }, alt || {}, aenderung));
    });
  };

  /* Soll die App an die Sicherung erinnern? Nur, wenn es Daten gibt und die Erinnerung nicht aus ist. */
  Daten.prototype.sicherungErinnerung = function () {
    var self = this;
    return this.sicherungInfo().then(function (i) {
      if (!i.hatDaten || !i.erinnerungTage) return { faellig: false };
      if (!i.letzte) return { faellig: true, grund: 'nie' };
      var tage = MM.Fristen.tageZwischen(lokalesDatum(i.letzte), self.heute());
      return tage >= i.erinnerungTage ? { faellig: true, grund: 'alt', tage: tage } : { faellig: false, tage: tage };
    });
  };

  /* Zahlen der Daten auf diesem Gerät, in derselben Form wie in einer Sicherung. */
  Daten.prototype.sicherungZahlen = function () {
    return this.speicher.alleTabellen().then(function (t) {
      var z = {};
      ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
      var dl = []; DATEI_TABELLEN.forEach(function (n) { dl = dl.concat(t[n] || []); });
      z.dateien = dl.length;
      z.dateiBytes = dl.reduce(function (s, d) { return s + (d.groesse || 0); }, 0);
      return z;
    });
  };

  /* Erzeugt die Sicherung. Gibt Bytes, Dateinamen und Zahlen zurück. */
  Daten.prototype.sicherungErzeugen = function (optionen) {
    var self = this;
    optionen = optionen || {};
    var mitDateien = !!optionen.mitDateien;
    return this.speicher.alleTabellen().then(function (alle) {
      var tabellen = {}, dateien = [], leer = 0;
      var kette = Promise.resolve();
      MM.Speicher.TABELLEN.forEach(function (name) {
        var liste = alle[name] || [];
        if (DATEI_TABELLEN.indexOf(name) >= 0) {
          if (!mitDateien) return;
          tabellen[name] = [];
          liste.forEach(function (rec) {
            kette = kette.then(function () {
              var kopie = Object.assign({}, rec);
              if (rec.inhalt && typeof rec.inhalt.arrayBuffer === 'function') {
                return rec.inhalt.arrayBuffer().then(function (buf) { kopie.inhalt = { $datei: dateien.length }; dateien.push(new Uint8Array(buf)); tabellen[name].push(kopie); });
              }
              leer++; kopie.inhalt = null; tabellen[name].push(kopie);
            });
          });
          return;
        }
        /* Die Einstellungen dieses Geräts (2.0.20) gehören nicht in die Sicherung. */
        tabellen[name] = name === 'einstellungen' ? liste.filter(function (e) { return e.id !== GERAET_DOK; }) : liste;
      });
      return kette.then(function () {
        var zaehlung = {}; Object.keys(tabellen).forEach(function (n) { zaehlung[n] = tabellen[n].length; });
        var kopf = { format: MM.Sicherung.FORMAT, app: MM.VERSION, dbVersion: MM.Speicher.DB_VERSION, erstelltAm: self.jetzt(), mitDateien: mitDateien, tabellen: tabellen, zaehlung: zaehlung };
        return MM.Sicherung.bauen(kopf, dateien, optionen.schluessel || '').then(function (bytes) {
          var z = {}; ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (tabellen[x[0]] || []).length; });
          var d = new Date(kopf.erstelltAm);
          function p(n) { return (n < 10 ? '0' : '') + n; }
          var name = 'MobiMory-Sicherung_' + d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '_' + p(d.getHours()) + '-' + p(d.getMinutes()) + '.mmsicherung';
          return { bytes: bytes, name: name, groesse: bytes.length, zahlen: z, dateien: dateien.length, ohneInhalt: leer, mitDateien: mitDateien, verschluesselt: !!optionen.schluessel, erstelltAm: kopf.erstelltAm };
        });
      });
    });
  };

  /* Prüft den Inhalt einer entpackten Sicherung. Wirft Fehler mit code und verständlichem Text. */
  function sicherungPruefen(gelesen) {
    function f(code, text) { var e = new Error(text); e.code = code; return e; }
    var k = gelesen.kopf;
    if (!k || typeof k !== 'object' || !k.tabellen || typeof k.tabellen !== 'object') throw f('beschaedigt', 'Die Datei ist beschädigt.');
    if (k.uebergabe) throw f('uebergabe', 'Das ist keine Sicherung, sondern eine Übergabedatei für ein einzelnes Fahrzeug. Sie ersetzt nichts. Lies sie unter „Fahrzeug übernehmen“ ein.');
    if (k.format !== MM.Sicherung.FORMAT) {
      throw f(k.format > MM.Sicherung.FORMAT ? 'neuer' : 'format', k.format > MM.Sicherung.FORMAT ? 'Diese Sicherung stammt aus einer neueren Version von MobiMory. Bitte zuerst die App aktualisieren.' : 'Das ist keine MobiMory-Sicherung.');
    }
    if (typeof k.dbVersion !== 'number' || k.dbVersion > MM.Speicher.DB_VERSION) throw f('neuer', 'Diese Sicherung stammt aus einer neueren Version von MobiMory (' + (k.app || '?') + '). Bitte zuerst die App aktualisieren.');
    var benutzt = {};
    Object.keys(k.tabellen).forEach(function (n) {
      if (MM.Speicher.TABELLEN.indexOf(n) < 0) throw f('beschaedigt', 'Die Sicherung enthält etwas Unbekanntes (' + n + ').');
      var liste = k.tabellen[n];
      if (!Array.isArray(liste)) throw f('beschaedigt', 'Die Datei ist beschädigt.');
      if (k.zaehlung && k.zaehlung[n] !== undefined && k.zaehlung[n] !== liste.length) throw f('beschaedigt', 'Die Datei ist beschädigt: Die Anzahl der Einträge stimmt nicht.');
      liste.forEach(function (o) {
        if (!o || typeof o !== 'object' || typeof o.id !== 'string' || !o.id) throw f('beschaedigt', 'Die Datei ist beschädigt: Ein Eintrag ist unvollständig.');
        if (DATEI_TABELLEN.indexOf(n) >= 0 && o.inhalt !== null && o.inhalt !== undefined) {
          var i = o.inhalt && o.inhalt.$datei;
          if (typeof i !== 'number' || i < 0 || i >= gelesen.dateien.length || benutzt[i]) throw f('beschaedigt', 'Die Datei ist beschädigt: Eine Datei fehlt.');
          benutzt[i] = true;
        }
      });
    });
    return true;
  }

  /* Entpackt und prüft eine Sicherung. Noch nichts wird verändert. */
  Daten.prototype.sicherungLesen = function (bytes, schluessel) {
    return MM.Sicherung.auspacken(bytes, schluessel || '').then(function (g) { sicherungPruefen(g); return g; });
  };

  /* Was steht in der Sicherung, und was ist jetzt auf dem Gerät? */
  Daten.prototype.sicherungVorschau = function (gelesen) {
    return this.sicherungZahlen().then(function (jetzt) {
      var t = gelesen.kopf.tabellen, z = {};
      ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
      var bytes = gelesen.dateien.reduce(function (s, d) { return s + d.length; }, 0);
      return { erstelltAm: gelesen.kopf.erstelltAm, app: gelesen.kopf.app, mitDateien: !!gelesen.kopf.mitDateien, dateien: gelesen.dateien.length, dateiBytes: bytes, zahlen: z, jetzt: jetzt };
    });
  };

  /*
   * Ersetzt ALLE Daten auf dem Gerät durch die der Sicherung, in einem Schritt.
   * Schlägt etwas fehl, bleibt der bisherige Stand unverändert.
   */
  Daten.prototype.sicherungEinspielen = function (gelesen) {
    var self = this;
    try { sicherungPruefen(gelesen); } catch (e) { return Promise.reject(e); }
    var t = gelesen.kopf.tabellen, karte = {};
    MM.Speicher.TABELLEN.forEach(function (n) {
      var liste = t[n] || [];
      karte[n] = liste.map(function (o) {
        if (DATEI_TABELLEN.indexOf(n) >= 0) {
          var kopie = Object.assign({}, o);
          kopie.inhalt = (o.inhalt && typeof o.inhalt.$datei === 'number') ? new Blob([gelesen.dateien[o.inhalt.$datei]], { type: o.mime || '' }) : null;
          return kopie;
        }
        return o;
      });
    });
    var einst = (karte.einstellungen || []).filter(function (e) { return e.id === 'sicherung'; })[0] || {};
    karte.einstellungen = (karte.einstellungen || []).filter(function (e) { return e.id !== 'sicherung'; })
      .concat([{ id: 'sicherung', letzteSicherung: gelesen.kopf.erstelltAm, erinnerungTage: einst.erinnerungTage === undefined ? 30 : einst.erinnerungTage }]);
    /* Die Einstellungen dieses Geräts bleiben, wie sie sind (nicht die des Geräts, von dem die Sicherung stammt). */
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (geraet) {
      karte.einstellungen = karte.einstellungen.filter(function (e) { return e.id !== GERAET_DOK; }).concat(geraet ? [geraet] : []);
      return self.speicher.ersetzenAlles(karte);
    }).then(function () { return self.starten(); });
  };


  /* ---------- Übergabe und Technik-Akte beim Abgeben (seit 2.0.37) ---------- */

  /*
   * Die Übergabedatei enthält NUR die technische Historie des Fahrzeugs: Fahrzeug mit Verlauf, Komponenten und
   * Ausrüstung, Zähler mit Ständen, Fristen und Erledigungen (auch HU), Werkstatt-Vorgänge und Störungen, Dokumente
   * an Fahrzeug, Komponente und Vorgang (auf Wunsch mit den Dateien) und die Namen der Werkstätten.
   * Nicht dabei: Aktivitäten, Logbuch, Reisekasse, Kosten, Personen, Besatzung, Orte, Nachweise, Standort.
   * Das Format ist das der Sicherungsdatei (Kopf mit uebergabe: true), damit Verschlüsselung und Prüfung dieselben bleiben.
   */
  var UEBERGABE_TABELLEN = ['fahrzeuge', 'eintraege', 'komponenten', 'komponenteneintraege', 'zaehler', 'zaehlerstaende',
    'fristen', 'durchfuehrungen', 'vorgaenge', 'dokumente', 'dateien', 'adressen', 'verlaeufe'];
  var UEBERGABE_ZAEHLUNG = [['komponenten', 'Komponenten'], ['zaehler', 'Zähler'], ['fristen', 'Fristen'], ['vorgaenge', 'Vorgänge'], ['dokumente', 'Dokumente']];
  /* Von der Adresse einer Werkstatt geht nur das Öffentliche mit, keine Ansprechpartner und Notizen. */
  var UEBERGABE_ADRESSFELDER = ['bezeichnung', 'art', 'plz', 'ort', 'land'];

  function idErsetzen(o, karte) {
    if (typeof o === 'string') return Object.prototype.hasOwnProperty.call(karte, o) ? karte[o] : o;
    if (Array.isArray(o)) return o.map(function (x) { return idErsetzen(x, karte); });
    if (o && typeof o === 'object' && !(typeof Blob !== 'undefined' && o instanceof Blob)) {
      var k = {}; Object.keys(o).forEach(function (n) { k[n] = idErsetzen(o[n], karte); }); return k;
    }
    return o;
  }
  function idPraefix(id) { var i = String(id).indexOf('-'); return i > 0 ? String(id).slice(0, i) : 'x'; }
  function dateiNameSauber(t) {
    return String(t || 'Fahrzeug').replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/Ä/g, 'Ae').replace(/Ö/g, 'Oe').replace(/Ü/g, 'Ue').replace(/ß/g, 'ss')
      .replace(/[^A-Za-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'Fahrzeug';
  }

  Daten.prototype.uebergabeErzeugen = function (fahrzeugId, optionen) {
    var self = this;
    optionen = optionen || {};
    var mitDateien = optionen.mitDateien !== false;
    return Promise.all([this.speicher.alleTabellen(), this.fahrzeugLaden(fahrzeugId)]).then(function (r) {
      var t = r[0], f = r[1];
      if (!f || f.fahrzeug.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (!f.fahrzeug.abgabe) return { ok: false, fehler: { allgemein: 'Das Fahrzeug ist noch nicht abgegeben. Gib es zuerst ab.' } };
      function wo(name, fn) { return (t[name] || []).filter(fn); }
      function mengeVon(liste) { var m = {}; liste.forEach(function (x) { m[x.id] = true; }); return m; }
      var fz = Object.assign({}, f.fahrzeug); delete fz.abgabe; delete fz.abgabeVerlauf;
      /* „Gehört zu“ (seit 2.0.45) verweist auf ein anderes Fahrzeug und hat in einem fremden Datenraum keine Bedeutung. */
      var eintr = wo('eintraege', function (x) { return x.fahrzeugId === fahrzeugId; }).map(function (x) {
        if (!x.werte || !Object.prototype.hasOwnProperty.call(x.werte, 'hauptfahrzeugId')) return x;
        var w = Object.assign({}, x.werte); delete w.hauptfahrzeugId;
        return Object.assign({}, x, { werte: w });
      });
      var komp = wo('komponenten', function (x) { return x.fahrzeugId === fahrzeugId; }), kM = mengeVon(komp);
      var kEin = wo('komponenteneintraege', function (x) { return kM[x.komponenteId]; });
      var zae = wo('zaehler', function (x) { return x.fahrzeugId === fahrzeugId; }), zM = mengeVon(zae);
      var zSt = wo('zaehlerstaende', function (x) { return zM[x.zaehlerId]; });
      var fri = wo('fristen', function (x) { return x.fahrzeugId === fahrzeugId; }), fM = mengeVon(fri);
      var dur = wo('durchfuehrungen', function (x) { return fM[x.fristId]; });
      var vor = wo('vorgaenge', function (x) { return x.fahrzeugId === fahrzeugId; }), vM = mengeVon(vor);
      /* Belege zu Kosten gehören zu deinen Kosten und gehen nicht mit. */
      var dok = wo('dokumente', function (x) { return x.fahrzeugId === fahrzeugId && !x.kostenId; }), dM = mengeVon(dok);
      var objM = {}; [fM, zM, vM, dM].forEach(function (m) { Object.keys(m).forEach(function (k) { objM[k] = true; }); });
      var verl = wo('verlaeufe', function (x) { return objM[x.objektId]; });
      var adrM = {};
      verl.forEach(function (x) { if (x.objektTyp === 'vorgang' && x.werte && x.werte.adresseId) adrM[x.werte.adresseId] = true; });
      var adr = wo('adressen', function (x) { return adrM[x.id]; });
      wo('verlaeufe', function (x) { return adrM[x.objektId]; }).forEach(function (x) {
        var w = {}; UEBERGABE_ADRESSFELDER.forEach(function (n) { w[n] = x.werte ? (x.werte[n] === undefined ? null : x.werte[n]) : null; });
        verl.push(Object.assign({}, x, { werte: w }));
      });
      var tabellen = { fahrzeuge: [fz], eintraege: eintr, komponenten: komp, komponenteneintraege: kEin, zaehler: zae, zaehlerstaende: zSt,
        fristen: fri, durchfuehrungen: dur, vorgaenge: vor, dokumente: dok, adressen: adr, verlaeufe: verl, dateien: [] };
      var dateien = [], leer = 0, kette = Promise.resolve();
      if (mitDateien) {
        wo('dateien', function (x) { return dM[x.dokumentId]; }).forEach(function (rec) {
          kette = kette.then(function () {
            var kopie = Object.assign({}, rec);
            if (rec.inhalt && typeof rec.inhalt.arrayBuffer === 'function') {
              return rec.inhalt.arrayBuffer().then(function (buf) { kopie.inhalt = { $datei: dateien.length }; dateien.push(new Uint8Array(buf)); tabellen.dateien.push(kopie); });
            }
            leer++; kopie.inhalt = null; tabellen.dateien.push(kopie);
          });
        });
      }
      return kette.then(function () {
        var zaehlung = {}; Object.keys(tabellen).forEach(function (n) { zaehlung[n] = tabellen[n].length; });
        var a = MM.Fahrzeugarten.art(f.fahrzeug.art);
        var kopf = { format: MM.Sicherung.FORMAT, uebergabe: true, app: MM.VERSION, dbVersion: MM.Speicher.DB_VERSION, erstelltAm: self.jetzt(), mitDateien: mitDateien,
          fahrzeug: { bezeichnung: f.aktuell.werte.bezeichnung, art: f.fahrzeug.art, artName: a ? a.name : f.fahrzeug.art,
            artPfad: MM.Fahrzeugarten.vorfahren(f.fahrzeug.art), abgabeDatum: f.fahrzeug.abgabe.datum, grund: f.fahrzeug.abgabe.grund,
            uebergabeId: fahrzeugId + '|' + f.fahrzeug.abgabe.datum + '|' + f.fahrzeug.abgabe.erfasstAm },
          tabellen: tabellen, zaehlung: zaehlung };
        return MM.Sicherung.bauen(kopf, dateien, optionen.schluessel || '').then(function (bytes) {
          var z = {}; UEBERGABE_ZAEHLUNG.forEach(function (x) { z[x[0]] = tabellen[x[0]].length; });
          var name = 'MobiMory-Uebergabe_' + dateiNameSauber(kopf.fahrzeug.bezeichnung) + '_' + f.fahrzeug.abgabe.datum + '.mmuebergabe';
          return { ok: true, bytes: bytes, name: name, groesse: bytes.length, zahlen: z, dateien: dateien.length, ohneInhalt: leer, mitDateien: mitDateien, verschluesselt: !!optionen.schluessel };
        });
      });
    });
  };

  function uebergabePruefen(gelesen) {
    function f(code, text) { var e = new Error(text); e.code = code; return e; }
    var k = gelesen.kopf;
    if (!k || typeof k !== 'object' || !k.tabellen || typeof k.tabellen !== 'object') throw f('beschaedigt', 'Die Datei ist beschädigt.');
    if (!k.uebergabe) throw f('keine-uebergabe', 'Das ist keine Übergabedatei. Eine Sicherung gehört unter Einstellungen zu „Wiederherstellen“.');
    if (k.format !== MM.Sicherung.FORMAT) throw f(k.format > MM.Sicherung.FORMAT ? 'neuer' : 'format', k.format > MM.Sicherung.FORMAT ? 'Diese Übergabedatei stammt aus einer neueren Version von MobiMory. Bitte zuerst die App aktualisieren.' : 'Das ist keine MobiMory-Übergabedatei.');
    if (typeof k.dbVersion !== 'number' || k.dbVersion > MM.Speicher.DB_VERSION) throw f('neuer', 'Diese Übergabedatei stammt aus einer neueren Version von MobiMory (' + (k.app || '?') + '). Bitte zuerst die App aktualisieren.');
    if (!k.fahrzeug || typeof k.fahrzeug !== 'object' || typeof k.fahrzeug.art !== 'string' || typeof k.fahrzeug.uebergabeId !== 'string') throw f('beschaedigt', 'Die Datei ist beschädigt.');
    var benutzt = {};
    Object.keys(k.tabellen).forEach(function (n) {
      if (UEBERGABE_TABELLEN.indexOf(n) < 0) throw f('beschaedigt', 'Die Übergabedatei enthält etwas Unbekanntes (' + n + ').');
      var liste = k.tabellen[n];
      if (!Array.isArray(liste)) throw f('beschaedigt', 'Die Datei ist beschädigt.');
      if (k.zaehlung && k.zaehlung[n] !== undefined && k.zaehlung[n] !== liste.length) throw f('beschaedigt', 'Die Datei ist beschädigt: Die Anzahl der Einträge stimmt nicht.');
      liste.forEach(function (o) {
        if (!o || typeof o !== 'object' || typeof o.id !== 'string' || !o.id) throw f('beschaedigt', 'Die Datei ist beschädigt: Ein Eintrag ist unvollständig.');
        if (n === 'dateien' && o.inhalt !== null && o.inhalt !== undefined) {
          var i = o.inhalt && o.inhalt.$datei;
          if (typeof i !== 'number' || i < 0 || i >= gelesen.dateien.length || benutzt[i]) throw f('beschaedigt', 'Die Datei ist beschädigt: Eine Datei fehlt.');
          benutzt[i] = true;
        }
      });
    });
    if (!k.tabellen.fahrzeuge || k.tabellen.fahrzeuge.length !== 1) throw f('beschaedigt', 'Die Datei ist beschädigt: Es muss genau ein Fahrzeug enthalten sein.');
    return true;
  }

  Daten.prototype.uebergabeLesen = function (bytes, schluessel) {
    return MM.Sicherung.auspacken(bytes, schluessel || '').then(function (g) { uebergabePruefen(g); return g; });
  };

  /* Die Art für die Übernahme: die eigene, sonst die nächste vorhandene darüber. Sonst null. */
  function artFuerUebernahme(kopfFahrzeug) {
    var ids = [kopfFahrzeug.art].concat(Array.isArray(kopfFahrzeug.artPfad) ? kopfFahrzeug.artPfad : []);
    for (var i = 0; i < ids.length; i++) {
      var a = MM.Fahrzeugarten.art(ids[i]);
      if (a && !a.gruppe && MM.Fahrzeugarten.sichtbar(a.id)) return { id: a.id, name: a.name, angepasst: i > 0 };
    }
    return null;
  }

  /* Die Angaben (neuester Eintrag) des Fahrzeugs in der Übergabedatei, für den Vergleich der Kennung (seit 2.0.46). */
  function uebergabeWerte(k) {
    var t = k.tabellen, fid = t.fahrzeuge && t.fahrzeuge[0] ? t.fahrzeuge[0].id : null;
    var e = (t.eintraege || []).filter(function (x) { return x.fahrzeugId === fid; }).sort(nachNr).pop();
    return e && e.werte ? e.werte : {};
  }

  Daten.prototype.uebergabeVorschau = function (gelesen) {
    var self = this, k = gelesen.kopf, t = k.tabellen;
    return Promise.all([this.fahrzeugListe({ alle: true }), this.kennungTreffer(uebergabeWerte(k), null)]).then(function (rr) {
      var liste = rr[0], treffer = rr[1];
      var schon = liste.filter(function (x) { return x.fahrzeug.uebernommen && x.fahrzeug.uebernommen.uebergabeId === k.fahrzeug.uebergabeId; })[0];
      var z = {}; UEBERGABE_ZAEHLUNG.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
      var art = artFuerUebernahme(k.fahrzeug);
      return { bezeichnung: k.fahrzeug.bezeichnung, artName: k.fahrzeug.artName, abgabeDatum: k.fahrzeug.abgabeDatum, grund: k.fahrzeug.grund, erstelltAm: k.erstelltAm, app: k.app,
        mitDateien: !!k.mitDateien, dateien: gelesen.dateien.length, dateiBytes: gelesen.dateien.reduce(function (s, d) { return s + d.length; }, 0), zahlen: z,
        schonUebernommen: schon ? { am: schon.fahrzeug.uebernommen.am, bezeichnung: schon.aktuell.werte.bezeichnung, id: schon.fahrzeug.id } : null,
        kennungTreffer: treffer, kennungText: treffer.length ? kennungTrefferText(uebergabeWerte(k), treffer) : null,
        art: art, artFehlt: !art };
    });
  };

  /*
   * Legt das Fahrzeug aus der Übergabedatei als NEUES Fahrzeug an. Alle Kennungen werden neu vergeben, so kollidiert nichts mit
   * Vorhandenem, auch nicht beim Einlesen auf demselben Gerät. Werkstätten, die es schon gibt (gleicher Name und Ort), werden wiederverwendet.
   * Alles passiert in einem Schritt: Schlägt etwas fehl, wird nichts angelegt.
   */
  Daten.prototype.uebergabeEinspielen = function (gelesen, opt) {
    var self = this;
    opt = opt || {};
    try { uebergabePruefen(gelesen); } catch (e) { return Promise.reject(e); }
    var k = gelesen.kopf, t = k.tabellen;
    return Promise.all([this.fahrzeugListe({ alle: true }), this.adressenListe(), this.kennungTreffer(uebergabeWerte(k), null)]).then(function (r) {
      var schon = r[0].filter(function (x) { return x.fahrzeug.uebernommen && x.fahrzeug.uebernommen.uebergabeId === k.fahrzeug.uebergabeId; })[0];
      if (schon && !opt.nochmal) return { ok: false, schonDa: true, fehler: { allgemein: 'Diese Übergabe ist schon übernommen (am ' + MM.Hilfen.zeitpunkt(schon.fahrzeug.uebernommen.am) + ').' } };
      /* Gleiche Kennung wie ein vorhandenes Fahrzeug: erst fragen (seit 2.0.46). „nochmal“ (schon übernommen) und „trotzdem“ sind die ausdrückliche Zustimmung. */
      if (r[2].length && !opt.trotzdem && !opt.nochmal) return { ok: false, doppelt: r[2], fehler: { allgemein: kennungTrefferText(uebergabeWerte(k), r[2]) } };
      var art = artFuerUebernahme(k.fahrzeug);
      if (!art) return { ok: false, fehler: { allgemein: 'Die Fahrzeugart „' + (k.fahrzeug.artName || k.fahrzeug.art) + '“ gibt es hier nicht. Lege sie unter „Fahrzeugarten verwalten“ an und lies die Datei danach noch einmal ein.' } };

      var karte = {};
      UEBERGABE_TABELLEN.forEach(function (n) { (t[n] || []).forEach(function (o) { karte[o.id] = neueId(idPraefix(o.id)); }); });
      /* vorhandene Werkstätten wiederverwenden */
      var vorhanden = {};
      r[1].forEach(function (x) { vorhanden[((x.aktuell.werte.bezeichnung || '') + '|' + (x.aktuell.werte.ort || '')).toLowerCase()] = x.objekt.id; });
      var uebersprungen = {};
      (t.adressen || []).forEach(function (a) {
        var st = (t.verlaeufe || []).filter(function (v) { return v.objektId === a.id; }).sort(nachNr).pop();
        if (!st) return;
        var key = ((st.werte.bezeichnung || '') + '|' + (st.werte.ort || '')).toLowerCase();
        if (vorhanden[key]) { karte[a.id] = vorhanden[key]; uebersprungen[a.id] = true; }
      });
      var jetzt = self.jetzt(), liste = [], neueFahrzeugId = karte[t.fahrzeuge[0].id];
      UEBERGABE_TABELLEN.forEach(function (n) {
        (t[n] || []).forEach(function (o) {
          if (n === 'adressen' && uebersprungen[o.id]) return;
          if (n === 'verlaeufe' && uebersprungen[o.objektId]) return;
          var neu = idErsetzen(o, karte);
          neu.id = karte[o.id];
          if (n === 'dateien') neu.inhalt = (o.inhalt && typeof o.inhalt.$datei === 'number') ? new Blob([gelesen.dateien[o.inhalt.$datei]], { type: o.mime || '' }) : null;
          if (Object.prototype.hasOwnProperty.call(neu, 'datenraumId')) neu.datenraumId = self.datenraumId;
          if (n === 'fahrzeuge') {
            neu.datenraumId = self.datenraumId;
            delete neu.abgabe; delete neu.abgabeVerlauf;
            neu.uebernommen = { am: jetzt, uebergabeId: k.fahrzeug.uebergabeId, abgabeDatum: k.fahrzeug.abgabeDatum, grund: k.fahrzeug.grund, app: k.app || null };
          }
          liste.push({ tabelle: n, objekt: neu });
        });
      });
      /* Gab es die Fahrzeugart hier nicht, gilt die nächste vorhandene darüber, auch in den Einträgen. */
      if (art.angepasst) {
        var orig = k.fahrzeug.art;
        liste.forEach(function (x) {
          var o = x.objekt;
          if (x.tabelle === 'fahrzeuge') {
            o.art = art.id;
            if (Array.isArray(o.artWechsel)) o.artWechsel = o.artWechsel.map(function (w) { return { von: w.von === orig ? art.id : w.von, nach: w.nach === orig ? art.id : w.nach, am: w.am, eintragNr: w.eintragNr }; });
          }
          if (x.tabelle === 'eintraege') { if (o.art === orig) o.art = art.id; if (o.artVorher === orig) o.artVorher = art.id; }
        });
      }
      return self.speicher.mehrereSpeichern(liste).then(function () {
        var z = {}; UEBERGABE_ZAEHLUNG.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
        return { ok: true, id: neueFahrzeugId, zahlen: z, artAngepasst: art.angepasst ? art.name : null };
      });
    });
  };

  /* ---------- Technik-Akte als PDF ---------- */

  /* Ein Datum (JJJJ-MM-TT) um n Monate zurück, der Tag wird bei Bedarf auf das Monatsende gekürzt. */
  function monateZurueck(iso, n) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
    var y = Number(m[1]), mo = Number(m[2]) - 1 - n, d = Number(m[3]);
    while (mo < 0) { mo += 12; y--; }
    var ende = new Date(Date.UTC(y, mo + 1, 0)).getUTCDate();
    function z(x) { return (x < 10 ? '0' : '') + x; }
    return y + '-' + z(mo + 1) + '-' + z(Math.min(d, ende));
  }

  /*
   * Zeitraum der Technik-Akte: von der letzten HU bis zur Abgabe, höchstens 24 Monate.
   *  - Letzte HU höchstens 24 Monate vor der Abgabe: Beginn = Tag der HU.
   *  - Letzte HU länger her: Beginn = 24 Monate vor der Abgabe (die HU ist dann überfällig).
   *  - Keine HU erfasst: Beginn = Tag, an dem das Fahrzeug angelegt wurde, aber nicht früher als 24 Monate vor der Abgabe.
   * Ergebnis: { von, bis, art: 'hu' | 'hu-alt' | 'angelegt' | 'ohne-hu-grenze', huDatum }
   */
  function akteZeitraum(abgabeDatum, huDatum, angelegtDatum) {
    var grenze = monateZurueck(abgabeDatum, 24);
    if (huDatum) {
      if (huDatum >= grenze) return { von: huDatum, bis: abgabeDatum, art: 'hu', huDatum: huDatum };
      return { von: grenze, bis: abgabeDatum, art: 'hu-alt', huDatum: huDatum };
    }
    if (angelegtDatum && angelegtDatum >= grenze) return { von: angelegtDatum, bis: abgabeDatum, art: 'angelegt', huDatum: null };
    return { von: grenze, bis: abgabeDatum, art: 'ohne-hu-grenze', huDatum: null };
  }

  var HU_NAME = /(^|[^A-Za-zÄÖÜäöüß])(HU|Hauptuntersuchung|T[ÜU]V)([^A-Za-zÄÖÜäöüß]|$)/i;

  /* Die Daten der Akte, ohne PDF. Nur lesen. */
  Daten.prototype.akteDaten = function (fahrzeugId) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f || f.fahrzeug.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (!f.fahrzeug.abgabe) return { ok: false, fehler: { allgemein: 'Das Fahrzeug ist noch nicht abgegeben. Gib es zuerst ab.' } };
      return Promise.all([self.komponentenListe(fahrzeugId), self.fristenListe(fahrzeugId), self.zaehlerListe(fahrzeugId), self.vorgaengeListe(fahrzeugId),
        self.speicher.alle('durchfuehrungen'), self.speicher.alle('zaehlerstaende')]).then(function (r) {
        var abgabe = f.fahrzeug.abgabe.datum, komp = r[0], fristen = r[1], zaehler = r[2], vorgaenge = r[3];
        var fristIds = {}; fristen.forEach(function (x) { fristIds[x.frist.id] = x; });
        var dur = r[4].filter(function (d) { return fristIds[d.fristId]; });
        var namen = {}; komp.forEach(function (k) { namen[k.komponente.id] = k.aktuell.werte.bezeichnung; });
        function besitzer(id) { return id ? (namen[id] || 'Komponente') : 'Fahrzeug'; }

        /* letzte HU: Frist am Fahrzeug, deren Name nach HU oder TÜV klingt, letzte Erledigung bis zur Abgabe */
        var huFristen = fristen.filter(function (x) { return !x.frist.komponenteId && HU_NAME.test(x.aktuell.werte.bezeichnung || ''); });
        var huDatum = null, huFrist = null;
        huFristen.forEach(function (x) {
          dur.filter(function (d) { return d.fristId === x.frist.id && d.datum && d.datum <= abgabe; }).forEach(function (d) {
            if (!huDatum || d.datum > huDatum) { huDatum = d.datum; huFrist = x; }
          });
        });
        var angelegt = f.verlauf[f.verlauf.length - 1].eintrag.erstelltAm;
        var angelegtDatum = angelegt ? new Date(angelegt).toISOString().slice(0, 10) : null;
        var zeit = akteZeitraum(abgabe, huDatum, f.fahrzeug.erstelltAm ? new Date(f.fahrzeug.erstelltAm).toISOString().slice(0, 10) : angelegtDatum);
        var huUeberfaellig = huFristen.some(function (x) { return x.status.status === 'ueberfaellig'; }) || zeit.art === 'hu-alt';

        var staende = zaehler.map(function (z) {
          var l = r[5].filter(function (s) { return s.zaehlerId === z.zaehler.id && s.datum && s.datum <= abgabe; }).sort(function (a, b) { return a.datum !== b.datum ? (a.datum < b.datum ? -1 : 1) : a.nr - b.nr; });
          var s = l[l.length - 1] || null;
          return { name: z.bezeichnung, besitzer: z.besitzer, einheit: z.einheit, wert: s ? s.wert : null, datum: s ? s.datum : null };
        });

        var erledigt = dur.filter(function (d) { return d.datum && d.datum >= zeit.von && d.datum <= zeit.bis; })
          .sort(function (a, b) { return a.datum < b.datum ? -1 : (a.datum > b.datum ? 1 : 0); })
          .map(function (d) { var x = fristIds[d.fristId]; return { datum: d.datum, name: x.aktuell.werte.bezeichnung, besitzer: besitzer(x.frist.komponenteId), zaehlerstand: d.zaehlerstand === undefined ? null : d.zaehlerstand, notiz: d.notiz || null, einheit: x.zaehler ? x.zaehler.einheit : null }; });
        var offene = fristen.map(function (x) {
          var st = x.status, letzte = st.letzte ? st.letzte.datum : null;
          var faellig = st.kalender && st.kalender.faelligAm ? st.kalender.faelligAm : null;
          return { name: x.aktuell.werte.bezeichnung, besitzer: besitzer(x.frist.komponenteId), status: st.status, letzte: letzte, faelligAm: faellig, wirkung: x.aktuell.werte.wirkung || null };
        });
        var werk = vorgaenge.filter(function (v) {
          var w = v.aktuell.werte;
          if (w.status === 'offen') return !w.gemeldetAm || w.gemeldetAm <= zeit.bis;
          return (w.gemeldetAm && w.gemeldetAm >= zeit.von && w.gemeldetAm <= zeit.bis) || (w.erledigtAm && w.erledigtAm >= zeit.von && w.erledigtAm <= zeit.bis);
        }).sort(function (a, b) { var x = a.aktuell.werte.gemeldetAm || '', y = b.aktuell.werte.gemeldetAm || ''; return x < y ? -1 : (x > y ? 1 : 0); })
          .map(function (v) { var w = v.aktuell.werte; return { gemeldetAm: w.gemeldetAm || null, art: w.art, bezeichnung: w.bezeichnung, besitzer: v.besitzer || 'Fahrzeug', status: w.status, erledigtAm: w.erledigtAm || null, auswirkung: w.auswirkung || null, notiz: w.erledigtNotiz || null }; });
        var haupt = self.sortiereKomponenten(komp.filter(function (x) { return !x.komponente.parentId && !x.aktuell.werte.ausgebautAm; }));
        return { ok: true, fahrzeug: f, abgabe: f.fahrzeug.abgabe, zeitraum: zeit, huFrist: huFrist ? huFrist.aktuell.werte.bezeichnung : null, huUeberfaellig: huUeberfaellig,
          staende: staende, erledigt: erledigt, fristen: offene, vorgaenge: werk, komponenten: haupt };
      });
    });
  };

  var GRUND_TEXT = { verkauft: 'verkauft', verschenkt: 'verschenkt', verschrottet: 'verschrottet', sonstiges: 'abgegeben' };
  var VORGANG_ART = { stoerung: 'Störung', arbeit: 'Arbeit' };
  var FRIST_STATUS = { ueberfaellig: 'Überfällig', bald: 'Bald fällig', ok: 'In Ordnung', unbekannt: 'Angaben fehlen' };

  /* Die Technik-Akte als PDF-Datei. */
  Daten.prototype.akteErzeugen = function (fahrzeugId) {
    var self = this;
    return this.akteDaten(fahrzeugId).then(function (a) {
      if (!a.ok) return a;
      var D = MM.Hilfen.datum, w = a.fahrzeug.aktuell.werte, art = MM.Fahrzeugarten.art(a.fahrzeug.fahrzeug.art), z = a.zeitraum;
      var d = MM.Pdf.neu({ fuss: 'MobiMory ' + MM.VERSION + ' · Technik-Akte ' + w.bezeichnung, titel: 'Technik-Akte ' + w.bezeichnung, datum: self.jetzt() });
      d.titel('Technik-Akte', w.bezeichnung + ' · ' + (GRUND_TEXT[a.abgabe.grund] || 'abgegeben') + ' am ' + D(a.abgabe.datum));
      d.absatz('Diese Akte enthält die technische Historie des Fahrzeugs. Aktivitäten, Fahrten, Kosten und Personen sind nicht enthalten.', { grau: true });

      d.abschnitt('Fahrzeug');
      d.zeile('Bezeichnung', w.bezeichnung);
      d.zeile('Fahrzeugart', art ? art.name : a.fahrzeug.fahrzeug.art);
      MM.Fahrzeugarten.gruppen(a.fahrzeug.fahrzeug.art).forEach(function (g) {
        g.felder.forEach(function (fe) { var t = MM.Hilfen.wert(fe, w[fe.key]); if (t !== null) d.zeile(fe.label, t); });
      });

      d.abschnitt('Zeitraum dieser Akte');
      d.zeile('Von', D(z.von));
      d.zeile('Bis (Abgabe)', D(z.bis));
      if (z.art === 'hu') d.zeile('Letzte HU', D(z.huDatum) + (a.huFrist ? ' (' + a.huFrist + ')' : ''));
      else if (z.art === 'hu-alt') d.zeile('Letzte HU', D(z.huDatum) + ' – mehr als 24 Monate vor der Abgabe');
      else d.zeile('Letzte HU', 'nicht erfasst');
      if (z.art === 'hu-alt') d.absatz('Die letzte HU liegt mehr als 24 Monate vor der Abgabe. Die Akte zeigt deshalb die letzten 24 Monate. Die HU war bei der Abgabe überfällig.', { fett: true });
      else if (z.art === 'angelegt') d.absatz('Es ist keine HU erfasst. Die Akte beginnt, als das Fahrzeug in MobiMory angelegt wurde.', { grau: true });
      else if (z.art === 'ohne-hu-grenze') d.absatz('Es ist keine HU erfasst. Die Akte zeigt die letzten 24 Monate vor der Abgabe.', { grau: true });
      else if (a.huUeberfaellig) d.absatz('Die HU ist überfällig.', { fett: true });

      d.abschnitt('Zählerstände bei der Abgabe');
      if (a.staende.length) d.tabelle([{ titel: 'Zähler', breite: 0 }, { titel: 'Gehört zu', breite: 110 }, { titel: 'Stand', breite: 90 }, { titel: 'Datum', breite: 70 }],
        a.staende.map(function (s) { return [s.name, s.besitzer, s.wert === null ? 'kein Stand' : MM.Hilfen.zahl(s.wert) + (s.einheit ? ' ' + s.einheit : ''), s.datum ? D(s.datum) : '']; }));
      else d.absatz('Es sind keine Zähler eingetragen.', { grau: true });

      d.abschnitt('Erledigte Wartungen und Prüfungen im Zeitraum');
      if (a.erledigt.length) d.tabelle([{ titel: 'Datum', breite: 62 }, { titel: 'Was', breite: 0 }, { titel: 'Gehört zu', breite: 100 }, { titel: 'Zählerstand', breite: 70 }],
        a.erledigt.map(function (e) { return [D(e.datum), e.name + (e.notiz ? ' – ' + e.notiz : ''), e.besitzer, e.zaehlerstand === null ? '' : MM.Hilfen.zahl(e.zaehlerstand) + (e.einheit ? ' ' + e.einheit : '')]; }));
      else d.absatz('Im Zeitraum ist nichts als erledigt eingetragen.', { grau: true });

      d.abschnitt('Offene und laufende Fristen');
      if (a.fristen.length) d.tabelle([{ titel: 'Frist', breite: 0 }, { titel: 'Gehört zu', breite: 100 }, { titel: 'Zuletzt erledigt', breite: 78 }, { titel: 'Stand', breite: 105 }],
        a.fristen.map(function (x) { return [x.name, x.besitzer, x.letzte ? D(x.letzte) : '', (FRIST_STATUS[x.status] || x.status) + (x.faelligAm ? ', fällig ' + D(x.faelligAm) : '')]; }));
      else d.absatz('Es sind keine Fristen eingetragen.', { grau: true });
      d.absatz('Der Stand der Fristen gilt am Tag, an dem die Akte erstellt wurde (' + D(self.heute()) + ').', { grau: true, groesse: 8 });

      d.abschnitt('Werkstatt: Störungen und Arbeiten im Zeitraum, dazu alle noch offenen');
      if (a.vorgaenge.length) d.tabelle([{ titel: 'Gemeldet', breite: 62 }, { titel: 'Art', breite: 48 }, { titel: 'Worum es geht', breite: 0 }, { titel: 'Betrifft', breite: 85 }, { titel: 'Stand', breite: 82 }],
        a.vorgaenge.map(function (v) { return [v.gemeldetAm ? D(v.gemeldetAm) : '', VORGANG_ART[v.art] || '', v.bezeichnung + (v.notiz ? ' – ' + v.notiz : ''), v.besitzer, v.status === 'offen' ? 'Offen' : 'Erledigt' + (v.erledigtAm ? ' ' + D(v.erledigtAm) : '')]; }));
      else d.absatz('Im Zeitraum gibt es keine Störungen oder Arbeiten und keine offenen Vorgänge.', { grau: true });

      d.abschnitt('Hauptkomponenten');
      if (a.komponenten.length) d.tabelle([{ titel: 'Komponente', breite: 0 }, { titel: 'Hersteller, Modell', breite: 170 }, { titel: 'Eingebaut', breite: 70 }],
        a.komponenten.map(function (k) { var v = k.aktuell.werte; return [v.bezeichnung, [v.hersteller, v.modell].filter(Boolean).join(' '), v.eingebautAm ? D(v.eingebautAm) : '']; }));
      else d.absatz('Es sind keine Hauptkomponenten eingetragen.', { grau: true });

      d.abstand(8);
      d.absatz('Alle Angaben stammen aus den Aufzeichnungen des bisherigen Besitzers in MobiMory. MobiMory trifft keine rechtliche Aussage.', { grau: true, groesse: 8 });
      var bytes = d.bytes();
      return { ok: true, bytes: bytes, seiten: d.seitenAnzahl(), groesse: bytes.length, mime: 'application/pdf',
        name: 'Technik-Akte_' + dateiNameSauber(w.bezeichnung) + '_' + a.abgabe.datum + '.pdf', zeitraum: z };
    });
  };

  /* Nur für Tests auf dem eigenen Gerät. */
  /* ---------- Reisecheck (Schritt 11, seit 2.0.38) ----------
   * Tabelle „reisechecks“: { id, datenraumId, aktivitaetId, fahrzeugId, erstelltAm, stand (Fingerabdruck der Anfrage),
   *   anfrage (genau das, was hinausging, ohne Namen), namen (P1 → Name, nur auf dem Gerät), ergebnis, dienst, von, bis }.
   * Adresse und Passwort des Dienstes und die Zustimmungen liegen im Geräte-Dokument. Sie sind pro Gerät und nicht in der Sicherung. */

  function rcFehler(text, art) { return { ok: false, fehler: { allgemein: text }, art: art || 'allgemein' }; }

  /* Der Reisecheck dauert oft eine bis zwei Minuten, weil der Dienst im Internet sucht. */
  function standardSendeJson(url, token, body) {
    var f = global.fetch;
    if (typeof f !== 'function') return Promise.reject(new Error('Kein Netz verfügbar.'));
    var ctl = typeof global.AbortController === 'function' ? new global.AbortController() : null;
    var timer = ctl ? global.setTimeout(function () { ctl.abort(); }, 240000) : null;
    function ende() { if (timer) global.clearTimeout(timer); }
    return f(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Mobimory-Token': token }, body: JSON.stringify(body), signal: ctl ? ctl.signal : undefined })
      .then(function (r) {
        return r.json().catch(function () { return null; }).then(function (j) {
          ende();
          if (!r.ok) { var e = new Error((j && j.error) || ('Antwort ' + r.status)); e.status = r.status; throw e; }
          return j;
        });
      }, function (e) { ende(); throw e; });
  }

  function rcFehlerText(err) {
    var s = err && err.status, m = err && err.message ? String(err.message) : '';
    if (s === 401) return 'Das Passwort passt nicht zum Dienst. Prüfe es unter „Dienst einrichten“.';
    if (s === 403) return 'Der Dienst lehnt diese App-Adresse ab. Im Dienst muss die Adresse dieser App als erlaubt eingetragen sein.';
    if (s === 503) return 'Der Dienst ist noch nicht fertig eingerichtet' + (m ? ': ' + m : '.');
    if (s) return 'Der Dienst konnte die Recherche nicht abschließen' + (m ? ': ' + m : '.');
    if (err && err.name === 'AbortError') return 'Der Dienst hat zu lange gebraucht. Versuche es später noch einmal.';
    return 'Keine Verbindung zum Dienst. Prüfe das Netz und die Adresse. Ohne Netz geht der Reisecheck nicht.';
  }

  Daten.prototype.sendeJson = function (url, token, body) {
    return (this.sendeJsonFn || standardSendeJson)(url, token, body);
  };

  Daten.prototype.rcGeraet = function () {
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (d) { return d || { id: GERAET_DOK }; });
  };
  Daten.prototype.rcSchreiben = function (aenderung) {
    var self = this;
    return this.rcGeraet().then(function (d) { return self.speicher.speichern('einstellungen', Object.assign({}, d, { id: GERAET_DOK }, aenderung)); });
  };

  /* Für die Anzeige: nie das Passwort selbst. */
  Daten.prototype.reisecheckEinstellung = function () {
    return this.rcGeraet().then(function (d) {
      var liste = Array.isArray(d.reisecheckZustimmungen) ? d.reisecheckZustimmungen : [];
      var letzte = liste.length ? liste[liste.length - 1] : null;
      var gilt = !!(letzte && letzte.aktion === 'zugestimmt' && letzte.version === MM.Reisecheck.ZUSTIMMUNG_VERSION);
      return { dienstUrl: d.reisecheckDienstUrl || '', hatPasswort: !!d.reisecheckToken, eingerichtet: !!(d.reisecheckDienstUrl && d.reisecheckToken),
        zugestimmt: gilt, zugestimmtAm: gilt ? letzte.am : null, zustimmungAlt: !!(letzte && letzte.aktion === 'zugestimmt' && !gilt),
        widerrufenAm: letzte && letzte.aktion === 'widerrufen' ? letzte.am : null, protokoll: liste.slice() };
    });
  };

  /* Adresse und Passwort speichern. Bleibt das Passwort leer, bleibt das alte. Eine andere Adresse macht die Zustimmung ungültig. */
  Daten.prototype.reisecheckEinrichten = function (roh) {
    var self = this;
    roh = roh || {};
    return this.rcGeraet().then(function (d) {
      var fehler = {}, u = MM.Reisecheck.dienstAdresse(roh.dienstUrl), token = d.reisecheckToken || '';
      if (!u.ok) fehler.dienstUrl = u.fehler;
      var neuesPasswort = String(roh.passwort === null || roh.passwort === undefined ? '' : roh.passwort).trim();
      if (neuesPasswort || !token) {
        var t = MM.Reisecheck.tokenPruefen(neuesPasswort);
        if (!t.ok) fehler.passwort = t.fehler; else token = t.token;
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var aenderung = { reisecheckDienstUrl: u.url, reisecheckToken: token };
      var liste = Array.isArray(d.reisecheckZustimmungen) ? d.reisecheckZustimmungen.slice() : [];
      var letzte = liste.length ? liste[liste.length - 1] : null;
      var adresseNeu = !!d.reisecheckDienstUrl && d.reisecheckDienstUrl !== u.url;
      if (adresseNeu && letzte && letzte.aktion === 'zugestimmt') {
        liste.push({ am: self.jetzt(), aktion: 'widerrufen', version: MM.Reisecheck.ZUSTIMMUNG_VERSION, grund: 'Adresse des Dienstes geändert' });
        aenderung.reisecheckZustimmungen = liste;
      }
      return self.rcSchreiben(aenderung).then(function () { return { ok: true, zustimmungZurueck: !!aenderung.reisecheckZustimmungen }; });
    });
  };

  /* Ruft die Gesundheitsabfrage des Dienstes auf. Ein Passwort braucht sie nicht, das wird erst beim Check geprüft. */
  Daten.prototype.reisecheckVerbindung = function () {
    var self = this;
    return this.rcGeraet().then(function (d) {
      if (!d.reisecheckDienstUrl) return { ok: false, fehler: 'Bitte zuerst die Adresse des Dienstes speichern.' };
      return Promise.resolve().then(function () { return self.holeJson(d.reisecheckDienstUrl + '/health'); }).then(function (x) {
        if (!x || x.ok !== true) return { ok: false, fehler: 'Unter dieser Adresse läuft kein Recherche-Dienst von MobiMory.' };
        if (x.configured === false) return { ok: false, fehler: 'Der Dienst läuft, hat aber noch keinen KI-Schlüssel eingetragen.' };
        return { ok: true, modell: x.model ? String(x.model) : '' };
      }, function () { return { ok: false, fehler: 'Der Dienst antwortet nicht. Prüfe die Adresse und das Netz.' }; });
    });
  };

  Daten.prototype.reisecheckZustimmen = function () {
    var self = this;
    return this.rcGeraet().then(function (d) {
      if (!d.reisecheckDienstUrl || !d.reisecheckToken) return rcFehler('Richte zuerst den Dienst ein. Danach kannst du zustimmen.', 'einrichtung');
      var liste = Array.isArray(d.reisecheckZustimmungen) ? d.reisecheckZustimmungen.slice() : [];
      liste.push({ am: self.jetzt(), aktion: 'zugestimmt', version: MM.Reisecheck.ZUSTIMMUNG_VERSION, text: MM.Reisecheck.ZUSTIMMUNG_TEXT, dienst: d.reisecheckDienstUrl });
      return self.rcSchreiben({ reisecheckZustimmungen: liste.slice(-50) }).then(function () { return { ok: true }; });
    });
  };

  Daten.prototype.reisecheckWiderrufen = function () {
    var self = this;
    return this.rcGeraet().then(function (d) {
      var liste = Array.isArray(d.reisecheckZustimmungen) ? d.reisecheckZustimmungen.slice() : [];
      liste.push({ am: self.jetzt(), aktion: 'widerrufen', version: MM.Reisecheck.ZUSTIMMUNG_VERSION });
      return self.rcSchreiben({ reisecheckZustimmungen: liste.slice(-50) }).then(function () { return { ok: true }; });
    });
  };

  /* Alle Angaben, die der Check aus den Daten braucht (noch mit Namen, sie verlassen das Gerät nicht). */
  Daten.prototype.reisecheckEingabe = function (aktivitaetId, abschnittId) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), abschnittId ? this.abschnittLaden(abschnittId) : Promise.resolve(null), abschnittId ? this.gebieteListe() : Promise.resolve([])]).then(function (rr) {
      var a = rr[0], tag = rr[1];
      if (!a) return null;
      if (abschnittId && (!tag || tag.aktivitaet.aktivitaet.id !== aktivitaetId)) return null;
      var w = a.aktuell.werte;
      function zeilen(liste) {
        return liste.map(function (n) {
          var v = n.aktuell.werte, aw = n.art.aktuell.werte;
          return { art: aw.bezeichnung, gescannt: !!v.dateiName, ausgestelltAm: v.ausgestelltAm || null, gueltigBis: MM.Nachweise.hatAblauf(aw) ? (v.gueltigBis || null) : null, klassen: v.klassen || null };
        });
      }
      return Promise.all([
        self.fahrzeugLaden(w.fahrzeugId), self.komponentenListe(w.fahrzeugId), self.nachweiseListe('fahrzeug', w.fahrzeugId),
        Promise.all(a.besatzung.map(function (b) { return self.nachweiseListe('person', b.person.id); })),
        Promise.all(a.tiere.map(function (t) { return self.nachweiseListe('tier', t.id); })),
        self.personenListe(), self.tiereListe(), self.orteListe()
      ]).then(function (r) {
        var fz = r[0], vwerte = fz ? fz.aktuell.werte : {};
        var funktionen = {}; r[5].forEach(function (p) { funktionen[p.objekt.id] = p.aktuell.werte.funktionen || []; });
        var tierWerte = {}; r[6].forEach(function (t) { tierWerte[t.objekt.id] = t.aktuell.werte; });
        var orte = {}; r[7].forEach(function (o) { orte[o.objekt.id] = o.aktuell.werte; });
        function wegpunkt(art, id) {
          var o = id ? orte[id] : null;
          return o ? { art: art, name: o.bezeichnung, land: o.land || '', breite: o.positionBreite, laenge: o.positionLaenge } : null;
        }
        var wege = [wegpunkt('start', w.startOrtId)].concat((w.zwischenzielIds || []).map(function (i) { return wegpunkt('zwischenziel', i); }), [wegpunkt('ziel', w.zielOrtId)]).filter(Boolean);
        var tw = tag ? tag.abschnitt.aktuell.werte : null, ortGeb = a.ortGebiete;
        if (tw) {
          /* Reisecheck für einen Tag (Etappe, seit 2.0.43): nur die zwei Orte des Tages, nur dieser Tag, nur die Gebiete dieser Orte. */
          wege = [wegpunkt('start', tw.startOrtId), wegpunkt('ziel', tw.zielOrtId)].filter(Boolean);
          var tagOrte = [tw.startOrtId, tw.zielOrtId].filter(function (i, n, l) { return i && l.indexOf(i) === n; }).map(function (i) { return orte[i] ? { id: i, name: orte[i].bezeichnung, werte: orte[i] } : null; }).filter(Boolean);
          ortGeb = MM.Gebiete.kettenAusOrten({ gebiete: rr[2], orte: tagOrte, welt: a.fahrzeug.welt });
        }
        var art = MM.Fahrzeugarten.art(a.fahrzeug.artId);
        return {
          aktivitaet: { id: a.aktivitaet.id, name: w.bezeichnung, fahrzeugId: w.fahrzeugId, fahrzeugName: a.fahrzeug.name, vonDatum: w.vonDatum, bisDatum: w.bisDatum, status: a.status, storniert: w.status === 'storniert',
            abschnittId: tag ? abschnittId : null, tagDatum: tw ? tw.datum : null },
          eingabe: {
            vonDatum: tw ? tw.datum : w.vonDatum, vonZeit: tw ? (tw.beginnZeit || '') : (w.vonZeit || ''), bisDatum: tw ? tw.datum : w.bisDatum, bisZeit: tw ? (tw.endeZeit || '') : (w.bisZeit || ''),
            fahrzeug: { name: a.fahrzeug.name, artName: art ? art.name : '', welt: a.fahrzeug.welt, werte: vwerte,
              komponenten: MM.Komponenten.aktive(r[1]).filter(function (k) { return !k.aktuell.werte.ausgebautAm; }).map(function (k) { return { name: k.aktuell.werte.bezeichnung, anzahl: k.aktuell.werte.anzahl }; }),
              nachweise: zeilen(r[2]) },
            gebiete: (a.gebiet ? [{ name: a.gebiet.name }] : []).concat((ortGeb ? ortGeb.ketten : []).map(function (k) { return { name: MM.Gebiete.pfadText(k, ', ') }; })), gebietText: w.gebiet || '',
            wegpunkte: wege,
            personen: a.besatzung.map(function (b, i) { return { name: b.person.name, rolle: b.rolleText, funktionen: funktionen[b.person.id] || [], nachweise: zeilen(r[3][i]) }; }),
            tiere: a.tiere.map(function (t, i) { var tw = tierWerte[t.id] || {}; return { name: t.name, tierart: tw.tierart || '', hatChip: !!tw.chipnummer, nachweise: zeilen(r[4][i]) }; })
          }
        };
      });
    });
  };

  /* Die anonymisierte Anfrage samt Vorschau (was geht hinaus) und Fingerabdruck. */
  Daten.prototype.reisecheckAnfrage = function (aktivitaetId, abschnittId) {
    return this.reisecheckEingabe(aktivitaetId, abschnittId).then(function (x) {
      if (!x) return null;
      var b = MM.Reisecheck.anfrageBauen(x.eingabe);
      /* Bei einem Tag müssen beide Orte da sein, sonst wäre es ein Check ohne Orte. */
      if (abschnittId && !(x.eingabe.wegpunkte && x.eingabe.wegpunkte.length >= 2)) return { ok: false, fehler: ['Der Tag braucht einen Start- und einen Zielort aus der Ortsliste (Tag ändern).'], aktivitaet: x.aktivitaet };
      if (!b.ok) return { ok: false, fehler: b.fehler, aktivitaet: x.aktivitaet };
      return { ok: true, fehler: [], aktivitaet: x.aktivitaet, anfrage: b.anfrage, namen: b.namen, vorschau: MM.Reisecheck.vorschau(b.anfrage), stand: MM.Reisecheck.fingerabdruck(b.anfrage) };
    });
  };

  Daten.prototype.reisecheckStarten = function (aktivitaetId, abschnittId) {
    var self = this;
    return Promise.all([this.rcGeraet(), this.reisecheckEinstellung(), this.reisecheckAnfrage(aktivitaetId, abschnittId)]).then(function (r) {
      var d = r[0], cfg = r[1], q = r[2];
      if (!q) return rcFehler('Diese Aktivität wurde nicht gefunden.');
      if (q.aktivitaet.storniert) return rcFehler('Diese Aktivität ist storniert. Stelle sie zuerst wieder her.');
      if (!cfg.eingerichtet) return rcFehler('Der Reisecheck ist noch nicht eingerichtet. Trage zuerst die Adresse und das Passwort des Dienstes ein.', 'einrichtung');
      if (!cfg.zugestimmt) return rcFehler('Bitte stimme zuerst zu, dass die Angaben zur Reise an den Dienst gehen dürfen.', 'zustimmung');
      if (!q.ok) return rcFehler(q.fehler.join(' '), 'daten');
      var gesendetAm = self.jetzt();
      return Promise.resolve().then(function () { return self.sendeJson(d.reisecheckDienstUrl + '/research', d.reisecheckToken, q.anfrage); }).then(function (antwort) {
        var p = MM.Reisecheck.antwortPruefen(antwort);
        if (!p.ok) return rcFehler(p.fehler, 'dienst');
        var rec = { id: neueId('rc'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, fahrzeugId: q.aktivitaet.fahrzeugId, erstelltAm: gesendetAm, stand: q.stand,
          anfrage: q.anfrage, namen: q.namen, ergebnis: p.ergebnis, dienst: p.dienst };
        /* Ein Check für einen Tag (seit 2.0.43) zählt nicht als Gesamtcheck und nicht im Kontingent (die Entscheidung kommt mit dem Kostenmodell). */
        if (abschnittId) { rec.art = 'etappe'; rec.abschnittId = abschnittId; }
        return self.speicher.speichern('reisechecks', rec).then(function () { return { ok: true, id: rec.id }; });
      }, function (err) { return rcFehler(rcFehlerText(err), 'netz'); });
    });
  };

  function rcZeile(rec, aktuellerStand) {
    var a = MM.Reisecheck.auswerten(rec.ergebnis);
    return { id: rec.id, erstelltAm: rec.erstelltAm, gesamt: a.gesamt, zaehl: a.zaehl, wichtigFehlt: a.wichtigFehlt, wichtigPruefen: a.wichtigPruefen,
      veraltet: aktuellerStand === undefined ? null : rec.stand !== aktuellerStand, recherche: rec.ergebnis.recherche };
  }

  /* Die Checks einer Aktivität: ohne abschnittId die Gesamtchecks, mit abschnittId die Checks dieses Tages. */
  Daten.prototype.reisecheckListe = function (aktivitaetId, abschnittId) {
    return this.speicher.wo('reisechecks', 'aktivitaetId', aktivitaetId).then(function (l) {
      return l.filter(function (rec) { return abschnittId ? rec.abschnittId === abschnittId : !rec.abschnittId; }).slice().sort(function (x, y) { return x.erstelltAm < y.erstelltAm ? 1 : (x.erstelltAm > y.erstelltAm ? -1 : 0); });
    });
  };

  Daten.prototype.reisecheckLaden = function (id) {
    return this.speicher.holen('reisechecks', id).then(function (rec) {
      if (!rec) return null;
      var a = MM.Reisecheck.auswerten(rec.ergebnis);
      return { check: rec, auswertung: a, anforderungen: MM.Reisecheck.sortiert(rec.ergebnis) };
    });
  };

  /* Die Seite zu einer Aktivität: Einstellung, was hinausginge, frühere Checks (mit „veraltet“). */
  Daten.prototype.reisecheckAnsicht = function (aktivitaetId, abschnittId) {
    var self = this;
    return Promise.all([this.reisecheckAnfrage(aktivitaetId, abschnittId), this.reisecheckEinstellung(), this.reisecheckListe(aktivitaetId, abschnittId)]).then(function (r) {
      var q = r[0];
      if (!q) return null;
      return { aktivitaet: q.aktivitaet, einstellung: r[1], anfrage: q.ok ? { vorschau: q.vorschau, stand: q.stand } : null, fehler: q.ok ? [] : q.fehler,
        checks: r[2].map(function (rec) { return rcZeile(rec, q.ok ? q.stand : undefined); }) };
    });
  };

  /* Für die Funktionenseite: pro Aktivität der letzte Check. */
  Daten.prototype.reisecheckUebersicht = function () {
    var self = this;
    return Promise.all([this.aktivitaetenListe(), this.speicher.alle('reisechecks')]).then(function (r) {
      var nach = {};
      r[1].forEach(function (rec) { if (rec.art === 'grund' || rec.abschnittId) return; if (!nach[rec.aktivitaetId] || nach[rec.aktivitaetId].erstelltAm < rec.erstelltAm) nach[rec.aktivitaetId] = rec; });
      return r[0].filter(function (x) { return x.status !== 'storniert'; }).map(function (x) {
        return { id: x.objekt.id, name: x.aktuell.werte.bezeichnung, fahrzeugName: x.fahrzeugName, vonDatum: x.aktuell.werte.vonDatum, bisDatum: x.aktuell.werte.bisDatum,
          status: x.status, letzter: nach[x.objekt.id] ? rcZeile(nach[x.objekt.id]) : null };
      });
    });
  };

  /* ---------- Etappen (Mehrtagesreisen, seit 2.0.43) ----------
   * Die Etappe ist der vorhandene Tagesabschnitt des Logbuchs, es gibt keine zweite Struktur. Der Tag hat Startort und Zielort (Felder
   * startOrtId und zielOrtId im Verlauf), das Wetter ergibt sich aus diesen zwei Orten, ein Wetter von Hand (wetterHand) ersetzt es.
   * Das online geholte Wetter liegt je Tag als Dokument „wetter-etappe-<tagId>“ in „einstellungen“ (wie bei der Route, in der Sicherung enthalten).
   * Kosten hängen mit dem Feld abschnittId am Tag. Alles zusammen liefert reiseZusammenfassung (eine Quelle für Aktivität, Logbuch und Tag). */
  function etappeWetterDokId(abschnittId) { return 'wetter-etappe-' + abschnittId; }

  function ortKurz(o) {
    var w = o.aktuell.werte;
    function pos(v) { return v === null || v === undefined || v === '' ? null : (isFinite(Number(v)) ? Number(v) : null); }
    return { id: o.objekt.id, name: w.bezeichnung, breite: pos(w.positionBreite), laenge: pos(w.positionLaenge), ausgeblendet: w.ausgeblendet === 'ja', land: w.land || '' };
  }

  /* Alles, was Wetter und Zusammenfassung brauchen: das Logbuch der Aktivität, die Orte und die gültige Route (oder null). */
  function etappenBasis(self, aktivitaetId) {
    return Promise.all([self.logbuchLaden(aktivitaetId), self.orteListe(), self.routeAnsicht(aktivitaetId)]).then(function (r) {
      if (!r[0]) return null;
      var orte = {}; r[1].forEach(function (o) { orte[o.objekt.id] = ortKurz(o); });
      return { lb: r[0], orte: orte, orteListe: Object.keys(orte).map(function (id) { return orte[id]; }), route: r[2] && r[2].ok ? r[2].route : null };
    });
  }
  function tagPlan(b, x) {
    var w = x.aktuell.werte, rt = b.route;
    return MM.Etappen.tagesPlan({ datum: w.datum, beginnZeit: w.beginnZeit || '', endeZeit: w.endeZeit || '',
      start: w.startOrtId ? b.orte[w.startOrtId] || null : null, ziel: w.zielOrtId ? b.orte[w.zielOrtId] || null : null,
      routePunkte: rt ? rt.punkte : null, routeKmh: rt ? MM.Routen.geschwindigkeitKmh(rt.werte.geschwindigkeit, rt.werte.einheit) : null });
  }
  function tagRegel(b) { return b.route ? b.route.wetterRegel : MM.Routen.wetterRegel(null, b.lb.aktivitaet.fahrzeug.welt); }

  /*
   * Das Wetter eines Tages holen: Open-Meteo für die Punkte zwischen Start- und Zielort (Abstandsregel der Route, sonst die Voreinstellung)
   * zur Ankunftszeit. Ergebnis: { ok, punkte, ohneWetter, abgerufenAm } oder { ok: false, fehler, offline? }. Bei einem Fehler bleibt ein früherer Stand erhalten.
   */
  Daten.prototype.etappeWetterAbrufen = function (abschnittId) {
    var self = this;
    return this.abschnittLaden(abschnittId).then(function (t) {
      if (!t) return routeFehler('Dieser Tag wurde nicht gefunden.');
      var aid = t.aktivitaet.aktivitaet.id;
      return etappenBasis(self, aid).then(function (b) {
        var x = b.lb.abschnitte.filter(function (y) { return y.objekt.id === abschnittId; })[0];
        if (!x) return routeFehler('Dieser Tag wurde nicht gefunden.');
        var pl = tagPlan(b, x);
        if (pl.grund) return routeFehler(pl.grund);
        var abfahrtMs = MM.Routen.zeitMs(pl.abfahrt), jetztMs = new Date(self.jetzt()).getTime();
        if (abfahrtMs > jetztMs + MAX_VORLAUF_TAGE * 86400000) return routeFehler('Eine Prognose gibt es nur für die nächsten ' + MAX_VORLAUF_TAGE + ' Tage. Versuche es später noch einmal.');
        if (abfahrtMs < jetztMs - 86400000) return routeFehler('Dieser Tag liegt mehr als einen Tag in der Vergangenheit. Dafür holt die App kein Wetter.');
        var w = x.aktuell.werte, mitMeer = b.lb.aktivitaet.fahrzeug.welt === 'wasser', einheit = mitMeer ? 'kn' : 'kmh', regel = tagRegel(b);
        var punkte = MM.Etappen.wetterMesspunkte(b.orte[w.startOrtId], b.orte[w.zielOrtId], pl.kmh, 'kmh', regel);
        if (!punkte.length) return routeFehler('Für diesen Tag lassen sich keine Wetterpunkte rechnen.');
        return wetterAntwortenHolen(self, punkte, abfahrtMs, mitMeer, einheit).then(function (antworten) {
          var ohneWetter = antworten.filter(function (a) { return !a.wetter; }).length;
          if (ohneWetter === punkte.length) return { ok: false, offline: true, fehler: { allgemein: 'Das Wetter konnte nicht geholt werden. Vermutlich ist gerade kein Netz da. Ein früher geholter Stand bleibt erhalten.' } };
          var dok = { id: etappeWetterDokId(abschnittId), abschnittId: abschnittId, aktivitaetId: aid, abgerufenAm: self.jetzt(), abfahrt: pl.abfahrt, geschwindigkeitKmh: pl.kmh,
            startOrtId: w.startOrtId, zielOrtId: w.zielOrtId, regel: regel, mitMeer: mitMeer, windEinheit: einheit, messpunkte: punkte, antworten: antworten };
          return self.einstellungSchreiben(dok).then(function () { return { ok: true, punkte: punkte.length, ohneWetter: ohneWetter, abgerufenAm: dok.abgerufenAm }; });
        });
      });
    });
  };

  /* Das Wetter eines Tages für die Anzeige: von Hand, online geholt (mit „aktuell“: passt noch zu Orten, Uhrzeit und Geschwindigkeit) oder unklar. */
  function tagWetter(x, dok, pl, regel) {
    var w = x.aktuell.werte;
    if (w.wetterHand) return { quelle: 'hand', text: w.wetterHand, aktuell: true, abgerufenAm: null, grund: null, zeilen: [] };
    if (dok) {
      var aus = MM.Routen.auswerten(dok.messpunkte, MM.Routen.zeitMs(dok.abfahrt), 0, dok.antworten, dok.mitMeer);
      var aktuell = !pl.grund && dok.abfahrt === pl.abfahrt && dok.startOrtId === w.startOrtId && dok.zielOrtId === w.zielOrtId && Math.abs(dok.geschwindigkeitKmh - pl.kmh) < 0.001
        && !!dok.regel && !!regel && dok.regel.art === regel.art && dok.regel.abstand === regel.abstand && dok.regel.einheit === regel.einheit;
      var text = MM.Etappen.wetterKurz(aus.schwerste, dok.windEinheit);
      return { quelle: 'online', text: text || 'Das Wettermodell liefert für diesen Tag keine Werte.', aktuell: aktuell, abgerufenAm: dok.abgerufenAm, grund: null, zeilen: aus.zeilen };
    }
    return { quelle: 'unklar', text: null, aktuell: false, abgerufenAm: null, grund: pl.grund, zeilen: [] };
  }

  /*
   * Die Zusammenfassung der ganzen Reise: eine Zeile je sichtbarem Tag (Start, Ziel, Strecke, Kosten, Ereignisse, Wetter), die Summen und die Gesamtsumme.
   * opts.fixEin: Fixkosten-Anteil in der Gesamtsumme (wie in der Reiseauswertung). Ergebnis: null oder { ok, aktivitaet, tage, streckeSumme, streckeUnklar, kostenSumme, ohneTag, gesamt, ... }.
   */
  Daten.prototype.reiseZusammenfassung = function (aktivitaetId, opts) {
    var self = this;
    return Promise.all([etappenBasis(this, aktivitaetId), kostenAlleSammeln(this), this.reiseAuswertung(aktivitaetId, opts)]).then(function (r) {
      var b = r[0], auswertung = r[2];
      if (!b || !auswertung) return null;
      var tage = b.lb.abschnitte.filter(function (x) { return !x.ausgeblendet; });
      var kosten = r[1].filter(function (k) { return k.aktuell.werte.aktivitaetId === aktivitaetId; }).map(function (k) { return { id: k.objekt.id, werte: k.aktuell.werte }; });
      var ka = MM.Etappen.kostenAnTage(kosten, tage.map(function (x) { return { id: x.objekt.id, datum: x.aktuell.werte.datum }; }));
      return Promise.all(tage.map(function (x) { return self.einstellungLesen(etappeWetterDokId(x.objekt.id)); })).then(function (doks) {
        var regel = tagRegel(b);
        var zeilen = tage.map(function (x, i) {
          var w = x.aktuell.werte, pl = tagPlan(b, x);
          return { id: x.objekt.id, datum: w.datum, beginnZeit: w.beginnZeit || null, endeZeit: w.endeZeit || null, ausserhalb: x.ausserhalb,
            start: w.startOrtId ? b.orte[w.startOrtId] || null : null, ziel: w.zielOrtId ? b.orte[w.zielOrtId] || null : null, vonText: w.von || null, nachText: w.nach || null,
            strecke: pl.strecke, ereignisse: MM.Etappen.ereignisKurz(x.ereignisse), wetter: tagWetter(x, doks[i], pl, regel), wetterGrund: pl.grund, planKmh: pl.kmh };
        });
        var z = MM.Etappen.zusammenfassung({ tage: zeilen, kosten: ka });
        return { ok: true, aktivitaet: { id: aktivitaetId, name: b.lb.aktivitaet.aktuell.werte.bezeichnung, welt: b.lb.aktivitaet.fahrzeug.welt },
          tage: z.zeilen, streckeSumme: z.streckeSumme, streckeUnklar: z.streckeUnklar, kostenSumme: z.kostenSumme, ohneTag: z.ohneTag, gesamt: auswertung.gesamt,
          planOrte: [b.lb.aktivitaet.aktuell.werte.startOrtId].concat(b.lb.aktivitaet.aktuell.werte.zwischenzielIds || [], [b.lb.aktivitaet.aktuell.werte.zielOrtId]).filter(Boolean),
          orteListe: b.orteListe };
      });
    });
  };

  /* Orte, aus denen ein Tag Start und Ziel wählt: die Gesamtplanung der Reise, ohne Planung alle Orte (zusätzlich der schon gewählte). */
  Daten.prototype.etappeOrtOptionen = function (aktivitaetId, gewaehlt) {
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.orteListe()]).then(function (r) {
      var a = r[0]; if (!a) return [];
      var w = a.aktuell.werte, plan = [w.startOrtId].concat(w.zwischenzielIds || [], [w.zielOrtId]).filter(Boolean);
      var orte = r[1].map(function (o) { var k = ortKurz(o); return { id: k.id, name: k.name, ausgeblendet: k.ausgeblendet }; });
      var opt = MM.Etappen.ortOptionen(plan, orte, null);
      (gewaehlt || []).forEach(function (g) { if (g && !opt.some(function (o) { return o.wert === g; })) { var o = orte.filter(function (x) { return x.id === g; })[0]; if (o) opt.push({ wert: o.id, label: o.name }); } });
      return { optionen: opt, nurPlan: plan.length > 0 };
    });
  };

  /* ---------- Grundcheck (Schritt 11b, seit 2.0.40) ----------
   * Was braucht das Fahrzeug an seinem Heimatort (Heimatland) legal? Kein Datum, keine Besatzung.
   * Gespeichert wird in der Tabelle „reisechecks“ mit art „grund“ und aktivitaetId null (Datenbank-Version bleibt 16).
   * Der Vergleich mit dem Fahrzeug wird bei jedem Öffnen neu gerechnet, damit eine Eintragung sofort wirkt und
   * der Check nicht jedes Mal online wiederholt werden muss. Gezählt wird nichts (Entscheidung mit dem Kostenmodell). */

  /* Heimatland: der Heimatstandort des Fahrzeugs, dessen Ort und das Land darüber. { land, ortName, standortName, herkunft } */
  Daten.prototype.heimatland = function (fahrzeugId) {
    var self = this;
    return this.fahrzeugStandort(fahrzeugId).then(function (info) {
      if (!info.standort) return { land: null, ortName: null, standortName: null, herkunft: null, grund: 'Es ist noch kein Heimatstandort gewählt.' };
      return self.ortLaden(info.standort.ortId).then(function (o) {
        if (!o) return { land: null, ortName: info.standort.ortName, standortName: info.standort.name, herkunft: null, grund: 'Der Ort des Heimatstandorts wurde nicht gefunden.' };
        var land = o.gebietPfad.filter(function (g) { return g.ebene === 'land'; })[0];
        if (land) return { land: land.name, ortName: info.standort.ortName, standortName: info.standort.name, herkunft: 'gebiet', grund: null };
        var text = trimmed(o.aktuell.werte.land);
        if (text) return { land: text, ortName: info.standort.ortName, standortName: info.standort.name, herkunft: 'ort', grund: null };
        return { land: null, ortName: info.standort.ortName, standortName: info.standort.name, herkunft: null, grund: 'Beim Ort „' + info.standort.ortName + '“ ist das Land nicht bekannt. Prüfe den Ort über die Ortssuche (Stammdaten › Orte).' };
      });
    });
  };

  /* Alles, was der Check am Fahrzeug braucht (noch mit Namen, nichts davon geht hinaus außer der anonymisierten Anfrage). */
  Daten.prototype.grundcheckEingabe = function (fahrzeugId) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (fz) {
      if (!fz) return null;
      return Promise.all([self.komponentenListe(fahrzeugId), self.nachweiseListe('fahrzeug', fahrzeugId), self.heimatland(fahrzeugId)]).then(function (r) {
        var art = MM.Fahrzeugarten.art(fz.fahrzeug.art);
        var werte = fz.aktuell.werte;
        var komponenten = MM.Komponenten.aktive(r[0]).filter(function (k) { return !k.aktuell.werte.ausgebautAm; });
        return {
          fahrzeug: { id: fz.fahrzeug.id, name: werte.bezeichnung, abgegeben: !!(fz.fahrzeug.abgabe), artId: fz.fahrzeug.art, artName: art ? art.name : '', welt: art ? art.welt : 'land', werte: werte,
            komponenten: komponenten.map(function (k) { return { name: k.aktuell.werte.bezeichnung, anzahl: k.aktuell.werte.anzahl }; }),
            nachweise: r[1].map(function (n) { return { art: n.art.aktuell.werte.bezeichnung, gescannt: !!n.aktuell.werte.dateiName, ausgestelltAm: n.aktuell.werte.ausgestelltAm || null,
              gueltigBis: MM.Nachweise.hatAblauf(n.art.aktuell.werte) ? (n.aktuell.werte.gueltigBis || null) : null, klassen: n.aktuell.werte.klassen || null }; }) },
          vergleich: {
            komponenten: komponenten.map(function (k) { return { name: k.aktuell.werte.bezeichnung, anzahl: k.aktuell.werte.anzahl, geprueft: k.aktuell.werte.eignungGeprueft }; }),
            nachweise: r[1].map(function (n) { return { artName: n.art.aktuell.werte.bezeichnung, gescannt: !!n.aktuell.werte.dateiName }; }),
            plaetze: werte.plaetze || null
          },
          heimat: r[2]
        };
      });
    });
  };

  /* Die anonymisierte Anfrage samt Vorschau und Fingerabdruck. */
  Daten.prototype.grundcheckAnfrage = function (fahrzeugId) {
    var self = this;
    return this.grundcheckEingabe(fahrzeugId).then(function (x) {
      if (!x) return null;
      var b = MM.Grundcheck.anfrageBauen({ heute: self.heute(), land: x.heimat.land, fahrzeug: x.fahrzeug });
      if (!b.ok) return { ok: false, fehler: b.fehler, eingabe: x };
      /* Der Fingerabdruck gilt ohne Datum, damit derselbe Stand an einem anderen Tag nicht als „geändert“ zählt. */
      var ohneDatum = JSON.parse(JSON.stringify(b.anfrage)); ohneDatum.trip.start = ''; ohneDatum.trip.end = '';
      return { ok: true, fehler: [], eingabe: x, anfrage: b.anfrage, vorschau: MM.Grundcheck.vorschau(b.anfrage), stand: MM.Reisecheck.fingerabdruck(ohneDatum) };
    });
  };

  Daten.prototype.grundcheckStarten = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.rcGeraet(), this.reisecheckEinstellung(), this.grundcheckAnfrage(fahrzeugId)]).then(function (r) {
      var d = r[0], cfg = r[1], q = r[2];
      if (!q) return rcFehler('Dieses Fahrzeug wurde nicht gefunden.');
      if (q.eingabe.fahrzeug.abgegeben) return rcFehler('Dieses Fahrzeug ist abgegeben.');
      if (!cfg.eingerichtet) return rcFehler('Der Reisecheck ist noch nicht eingerichtet. Trage zuerst die Adresse und das Passwort des Dienstes ein.', 'einrichtung');
      if (!cfg.zugestimmt) return rcFehler('Bitte stimme zuerst zu, dass die Angaben zum Fahrzeug an den Dienst gehen dürfen.', 'zustimmung');
      if (!q.ok) return rcFehler(q.fehler.join(' '), 'daten');
      var gesendetAm = self.jetzt();
      return Promise.resolve().then(function () { return self.sendeJson(d.reisecheckDienstUrl + '/research', d.reisecheckToken, q.anfrage); }).then(function (antwort) {
        var p = MM.Reisecheck.antwortPruefen(antwort);
        if (!p.ok) return rcFehler(p.fehler, 'dienst');
        var rec = { id: neueId('rc'), datenraumId: self.datenraumId, art: 'grund', aktivitaetId: null, fahrzeugId: fahrzeugId, erstelltAm: gesendetAm, stand: q.stand,
          land: q.anfrage.trip.areas[0].name, anfrage: q.anfrage, namen: {}, ergebnis: p.ergebnis, dienst: p.dienst };
        return self.speicher.speichern('reisechecks', rec).then(function () { return { ok: true, id: rec.id }; });
      }, function (err) { return rcFehler(rcFehlerText(err), 'netz'); });
    });
  };

  /* Die Tabelle hat nur einen Index auf die Aktivität, darum wird hier gefiltert (es sind wenige Einträge). */
  Daten.prototype.grundcheckListe = function (fahrzeugId) {
    return this.speicher.alle('reisechecks').then(function (l) {
      return l.filter(function (x) { return x.art === 'grund' && x.fahrzeugId === fahrzeugId; })
        .sort(function (x, y) { return x.erstelltAm < y.erstelltAm ? 1 : (x.erstelltAm > y.erstelltAm ? -1 : 0); });
    });
  };

  /* Die Seite zum Fahrzeug: Einstellung, was hinausginge, der letzte Check mit dem Vergleich gegen den heutigen Stand. */
  Daten.prototype.grundcheckAnsicht = function (fahrzeugId, checkId) {
    var self = this;
    return Promise.all([this.grundcheckAnfrage(fahrzeugId), this.reisecheckEinstellung(), this.grundcheckListe(fahrzeugId), this.zuordnungenDokument()]).then(function (r) {
      var q = r[0];
      if (!q) return null;
      var liste = r[2];
      var gewaehlt = checkId ? liste.filter(function (x) { return x.id === checkId; })[0] || null : (liste[0] || null);
      var x = q.eingabe, gelesen = null, zeilen = [], zusammen = null;
      if (gewaehlt) {
        gelesen = MM.Grundcheck.punkteLesen(gewaehlt.ergebnis, gewaehlt.dienst);
        /* Bestätigte Namen („Habe ich unter anderem Namen“) gelten für das Land dieses Checks und die Art dieses Fahrzeugs. */
        zeilen = MM.Grundcheck.vergleichen({ punkte: gelesen.punkte, komponenten: x.vergleich.komponenten, nachweise: x.vergleich.nachweise, plaetze: x.vergleich.plaetze, fahrzeugId: fahrzeugId,
          zuordnungen: MM.Orte.zuordnungenFuer(r[3], gewaehlt.land, x.fahrzeug.artId) });
        zusammen = MM.Grundcheck.zusammenfassung(zeilen);
      }
      return { fahrzeug: { id: x.fahrzeug.id, name: x.fahrzeug.name, artName: x.fahrzeug.artName, abgegeben: x.fahrzeug.abgegeben }, heimat: x.heimat, einstellung: r[1],
        anfrage: q.ok ? { vorschau: q.vorschau, stand: q.stand } : null, fehler: q.ok ? [] : q.fehler,
        checks: liste.map(function (rec) { return { id: rec.id, erstelltAm: rec.erstelltAm, land: rec.land, veraltet: q.ok ? rec.stand !== q.stand : null, recherche: rec.ergebnis.recherche }; }),
        gewaehlt: gewaehlt ? { id: gewaehlt.id, erstelltAm: gewaehlt.erstelltAm, land: gewaehlt.land, recherche: gewaehlt.ergebnis.recherche, zusammenfassung: gewaehlt.ergebnis.zusammenfassung,
          warnungen: gewaehlt.ergebnis.warnungen || [], dienst: gewaehlt.dienst, veraltet: q.ok ? gewaehlt.stand !== q.stand : null,
          landWechsel: !!(x.heimat.land && gewaehlt.land && x.heimat.land !== gewaehlt.land) } : null,
        zeilen: zeilen, zaehl: zusammen, nichtLesbar: gelesen ? gelesen.nichtLesbar : [],
        kandidaten: { ausruestung: namenListe(x.vergleich.komponenten.map(function (k) { return k.name; })), papier: namenListe(x.vergleich.nachweise.map(function (n) { return n.artName; })) } };
    });
  };

  /* ---------- Zuordnung „Habe ich unter anderem Namen“ (seit 2.0.41) ----------
   * Gespeichert als ein Dokument „zuordnungen“ in der Tabelle „einstellungen“ (Datenbank-Version bleibt 16). Es gehört dem Nutzer,
   * nicht einem Fahrzeug: je Land und Fahrzeugart. Gilt im Grundcheck und bei der Pflichtausrüstung der Gebietsregeln im Reisecheck.
   * Die App setzt nichts von selbst gleich. Nur was der Nutzer ausdrücklich wählt, wird gespeichert. */
  function namenListe(l) {
    var res = [];
    (l || []).forEach(function (n) { var t = trimmed(n); if (t && res.indexOf(t) < 0) res.push(t); });
    return res.sort(function (a, b) { return a.localeCompare(b, 'de', { numeric: true }); });
  }

  Daten.prototype.zuordnungenDokument = function () {
    return this.speicher.holen('einstellungen', 'zuordnungen').then(function (d) { return d && d.eintraege ? d : MM.Orte.zuordnungenLeer(); });
  };

  /* Alle Zuordnungen für die Übersicht, nach Land und Fahrzeugart sortiert. */
  Daten.prototype.zuordnungenListe = function () {
    return this.zuordnungenDokument().then(function (d) {
      return d.eintraege.slice().sort(function (a, b) { return (a.land + a.punkt).localeCompare(b.land + b.punkt, 'de'); }).map(function (e) {
        var art = MM.Fahrzeugarten.art(e.artId);
        return { schluessel: e.schluessel, land: e.land, artId: e.artId, artName: art ? art.name : e.artId, art: e.art, punkt: e.punkt, namen: e.namen.slice() };
      });
    });
  };

  /* p: { art: 'ausruestung' | 'papier', punkt, land, ziel }. Das Ziel muss am Fahrzeug wirklich eingetragen sein (Komponente oder Nachweis). */
  Daten.prototype.grundcheckZuordnen = function (fahrzeugId, p) {
    var self = this;
    p = p || {};
    return Promise.all([this.grundcheckEingabe(fahrzeugId), this.zuordnungenDokument()]).then(function (r) {
      var x = r[0];
      if (!x) return rcFehler('Dieses Fahrzeug wurde nicht gefunden.');
      var art = p.art === 'papier' ? 'papier' : 'ausruestung', land = trimmed(p.land), punkt = MM.Orte.suchbegriff(p.punkt), ziel = trimmed(p.ziel);
      if (!land) return rcFehler('Das Land des Checks ist nicht bekannt.');
      if (!punkt) return rcFehler('Der Punkt hat keinen Namen.');
      if (!ziel) return rcFehler('Bitte wähle aus, wie dieser Punkt bei dir heißt.');
      var da = art === 'papier' ? x.vergleich.nachweise.map(function (n) { return n.artName; }) : x.vergleich.komponenten.map(function (k) { return k.name; });
      if (da.indexOf(ziel) < 0) return rcFehler('„' + ziel + '“ ist am Fahrzeug nicht eingetragen. Wähle einen Eintrag aus der Liste.');
      if (ziel.toLowerCase() === punkt.toLowerCase()) return rcFehler('Das ist schon derselbe Name. Eine Zuordnung ist nicht nötig.');
      var doc = MM.Orte.zuordnungSetzen(r[1], { land: land, artId: x.fahrzeug.artId, art: art, punkt: punkt, ziel: ziel, jetzt: self.jetzt() });
      return self.speicher.speichern('einstellungen', doc).then(function () { return { ok: true }; });
    });
  };

  /* Hebt die Zuordnung auf. Ohne ziel fallen alle Namen dieses Punktes weg. */
  Daten.prototype.grundcheckZuordnungAufheben = function (fahrzeugId, p) {
    var self = this;
    p = p || {};
    return Promise.all([this.grundcheckEingabe(fahrzeugId), this.zuordnungenDokument()]).then(function (r) {
      var x = r[0];
      if (!x) return rcFehler('Dieses Fahrzeug wurde nicht gefunden.');
      var doc = MM.Orte.zuordnungEntfernen(r[1], { land: trimmed(p.land), artId: x.fahrzeug.artId, art: p.art === 'papier' ? 'papier' : 'ausruestung', punkt: MM.Orte.suchbegriff(p.punkt), ziel: trimmed(p.ziel) });
      return self.speicher.speichern('einstellungen', doc).then(function () { return { ok: true }; });
    });
  };

  Daten.prototype.allesLoeschen = function () {
    var self = this;
    return this.speicher.allesLoeschen().then(function () { return self.starten(); });
  };

  MM.Daten = { Daten: Daten, akteZeitraum: akteZeitraum, monateZurueck: monateZurueck };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
