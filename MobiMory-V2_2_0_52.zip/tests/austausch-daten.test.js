'use strict';
/* 2.0.30, Schritt 8b: Import von Fahrzeugen (Vorschau, Übernehmen) und Export von Fahrzeugen, Kosten und Orten. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/austausch.js');
require('../js/daten.js');
const MM = globalThis.MM;
const A = MM.Austausch;

const JETZT = new Date(2026, 10, 4, 12, 0, 0).toISOString();
async function neuesGeraet() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  return d;
}

const KOPF = ['Name', 'Hersteller', 'Modell', 'Amtl. Kennzeichen', 'Erstzulassung', 'zul. Gesamtgewicht (kg)', 'Länge (m)', 'Kraftstoff'];
const ZEILEN = [
  ['Familienauto', 'VW', 'Touran', 'HN-AB 123', '15.06.2012', '2.150 kg', '4,53', 'Diesel'],
  ['', 'Hymer', 'B-Klasse', 'LB-XY 99', '03.11.2019', '3.500', '7,4', 'super'],
  ['Kaputt', 'Opel', 'Astra', 'S-AA 1', '31.02.2020', 'viel', '4,2', 'Dampf'],
  ['Familienauto', 'VW', 'Touran', 'hn-ab123', '', '', '', ''],
  ['', '', '', '', '', '', '', '']
];

function zuordnung(kopf, artId) { return A.spaltenRaten(kopf, MM.Daten.Daten.prototype.importZielfelder.call(null, artId)); }

test('Zielfelder: mit Art deren Felder, ohne Art alle Felder und die Spalte „Fahrzeugart“', async () => {
  const d = await neuesGeraet();
  const mitArt = d.importZielfelder('auto').map(f => f.key);
  assert.equal(mitArt[0], 'bezeichnung');
  assert.ok(mitArt.includes('kennzeichen') && !mitArt.includes('tiefgang') && !mitArt.includes('__art'));
  const ohne = d.importZielfelder(null).map(f => f.key);
  assert.ok(ohne.includes('__art') && ohne.includes('tiefgang') && ohne.includes('kennzeichen'));
  assert.equal(ohne.filter(k => k === 'laenge').length, 1, 'jedes Feld nur einmal');
});

test('Vorschau: deutsche Zahlen und Daten, Bezeichnung aus Marke und Modell, Fehler, doppelte Zeile, leere Zeile', async () => {
  const d = await neuesGeraet();
  const z = A.spaltenRaten(KOPF, d.importZielfelder('wohnmobil'));
  assert.deepEqual(z, ['bezeichnung', 'marke', 'modell', 'kennzeichen', 'erstzulassung', 'gesamtgewicht', 'laenge', 'kraftstoff']);
  const v = await d.importVorschau({ zeilen: ZEILEN, zuordnung: z, artId: 'wohnmobil', ersteNr: 2 });
  assert.equal(v.ok, true);
  assert.deepEqual(v.zaehlung, { neu: 2, vorhanden: 0, doppelt: 1, fehler: 1 });
  assert.deepEqual(v.zeilen.map(x => x.nr), [2, 3, 4, 5], 'die leere Zeile fehlt, die Nummern bleiben die der Datei');
  const a = v.zeilen[0];
  assert.equal(a.status, 'neu');
  assert.equal(a.werte.gesamtgewicht, 2150);
  assert.equal(a.werte.laenge, 4.53);
  assert.equal(a.werte.erstzulassung, '2012-06-15');
  assert.equal(a.werte.kraftstoff, 'Diesel');
  const b = v.zeilen[1];
  assert.equal(b.bezeichnung, 'Hymer B-Klasse');
  assert.equal(b.werte.gesamtgewicht, 3500);
  assert.equal(b.werte.kraftstoff, 'Benzin');
  const c = v.zeilen[2];
  assert.equal(c.status, 'fehler');
  assert.ok(c.fehlerListe.some(t => /Erstzulassung/.test(t)) && c.fehlerListe.some(t => /Gesamtgewicht/.test(t)) && c.fehlerListe.some(t => /Kraftstoff/.test(t)));
  assert.equal(v.zeilen[3].status, 'doppelt', 'gleiches Kennzeichen wie Zeile 2, anders geschrieben');
});

test('Vorschau: Fahrzeuge, die es schon gibt, werden erkannt und nicht angefasst', async () => {
  const d = await neuesGeraet();
  const alt = (await d.fahrzeugAnlegen('auto', { bezeichnung: 'Mein Touran', kennzeichen: 'HN AB-123' })).id;
  const ohneKennung = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Seestern' })).id;
  const z = ['bezeichnung', 'kennzeichen'];
  const v = await d.importVorschau({ zeilen: [['Anderer Name', 'HN-AB 123'], ['seestern', ''], ['Neu', 'X 1']], zuordnung: z, artId: 'auto' });
  assert.deepEqual(v.zeilen.map(x => x.status), ['vorhanden', 'vorhanden', 'neu']);
  const f = await d.fahrzeugLaden(alt);
  assert.equal(f.aktuell.werte.bezeichnung, 'Mein Touran');
  assert.equal(f.verlauf.length, 1);
  assert.ok(ohneKennung);
});

test('Vorschau: Fahrzeugart aus einer Spalte, unbekannte Art ist ein Fehler dieser Zeile', async () => {
  const d = await neuesGeraet();
  const kopf = ['Name', 'Art', 'Kennzeichen', 'Tiefgang'];
  const z = A.spaltenRaten(kopf, d.importZielfelder(null));
  assert.deepEqual(z, ['bezeichnung', '__art', 'kennzeichen', 'tiefgang']);
  const v = await d.importVorschau({ zeilen: [['A', 'PKW', 'X 1', '1,2'], ['B', 'Boot', '', '1,2'], ['C', 'Raumschiff', '', '']], zuordnung: z, artId: '' });
  assert.deepEqual(v.zeilen.map(x => [x.status, x.artId]), [['neu', 'auto'], ['neu', 'boot'], ['fehler', null]]);
  assert.equal(v.zeilen[1].werte.tiefgang, 1.2);
  assert.equal(v.zeilen[0].werte.tiefgang, undefined, 'beim Auto gibt es keinen Tiefgang');
  assert.deepEqual(v.nichtVerwendet, ['Tiefgang (m)']);
});

test('Vorschau: ohne Art, ohne Namensspalte, zu viele Zeilen, leere Tabelle', async () => {
  const d = await neuesGeraet();
  assert.match((await d.importVorschau({ zeilen: [['A']], zuordnung: ['bezeichnung'], artId: '' })).fehler, /Fahrzeugart/);
  assert.match((await d.importVorschau({ zeilen: [['1']], zuordnung: ['kennzeichen'], artId: 'auto' })).fehler, /Bezeichnung/);
  assert.match((await d.importVorschau({ zeilen: Array.from({ length: 1001 }, () => ['A']), zuordnung: ['bezeichnung'], artId: 'auto' })).fehler, /1000/);
  assert.match((await d.importVorschau({ zeilen: [], zuordnung: ['bezeichnung'], artId: 'auto' })).fehler, /keine Zeilen/);
  assert.match((await d.importVorschau({ zeilen: [['A']], zuordnung: ['bezeichnung'], artId: 'gibtsnicht' })).fehler, /Fahrzeugart/);
  assert.match((await d.importVorschau({ zeilen: [['', '']], zuordnung: ['bezeichnung', 'marke'], artId: 'auto' })).fehler, /nichts/);
});

test('Übernehmen: nur die neuen, alles in einem Zug, Quelle „import“, ein zweiter Lauf findet alles schon vor', async () => {
  const d = await neuesGeraet();
  const opt = { zeilen: ZEILEN, zuordnung: A.spaltenRaten(KOPF, d.importZielfelder('wohnmobil')), artId: 'wohnmobil', ersteNr: 2 };
  const r = await d.importFahrzeuge(opt);
  assert.equal(r.ok, true);
  assert.equal(r.anzahl, 2);
  assert.equal(r.doppelt, 1);
  assert.equal(r.fehler, 1);
  const liste = await d.fahrzeugListe();
  assert.deepEqual(liste.map(x => x.aktuell.werte.bezeichnung), ['Familienauto', 'Hymer B-Klasse']);
  assert.ok(liste.every(x => x.fahrzeug.art === 'wohnmobil' && x.aktuell.quelle === 'import' && x.aktuell.nr === 1));
  const f = await d.fahrzeugLaden(r.ids[0]);
  assert.equal(f.verlauf.length, 1);
  const zwei = await d.importFahrzeuge(opt);
  assert.equal(zwei.ok, false);
  assert.match(zwei.fehler, /nichts zu übernehmen/);
  assert.equal((await d.fahrzeugListe()).length, 2);
  /* ein importiertes Fahrzeug lässt sich wie jedes andere ändern */
  const g = await d.fahrzeugAendern(r.ids[0], Object.assign({}, f.aktuell.werte, { bezeichnung: 'Touran' }));
  assert.equal(g.ok, true);
});

test('Übernehmen: ein Fehler in der Vorschau verhindert nichts bei den fehlerfreien, bricht aber ohne neue Zeilen ab', async () => {
  const d = await neuesGeraet();
  const r = await d.importFahrzeuge({ zeilen: [['Kaputt', 'abc']], zuordnung: ['bezeichnung', 'baujahr'], artId: 'auto' });
  assert.equal(r.ok, false);
  assert.equal((await d.fahrzeugListe()).length, 0);
});

async function gefuellt() {
  const d = await neuesGeraet();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Seestern', registriernummer: 'D-1234', marke: 'Bavaria', laenge: '9,5', erstzulassung: '2015-05-01', kraftstoff: 'Diesel' })).id;
  await d.fahrzeugAnlegen('auto', { bezeichnung: 'Touran, "groß"', kennzeichen: 'HN-AB 123', baujahr: '2012', gesamtgewicht: '2150' });
  await d.kostenAnlegen(boot, { gruppe: 'fix', bezeichnung: 'Liegeplatz Heimathafen', kostenart: 'stellplatz', betrag: '2400', rhythmus: 'jaehrlich', datum: '2026-01-01' });
  await d.kostenAnlegen(boot, { gruppe: 'variabel', bezeichnung: 'Diesel', kostenart: 'treibstoff', betrag: '180,50', datum: '2026-07-05', notiz: 'Zeile 1\nZeile 2' });
  await d.ortAnlegen({ bezeichnung: 'Hafen Biograd', land: 'Kroatien', ortart: 'hafen', ausstattung: ['strom', 'wasser'] });
  return { d, boot };
}

test('Export Excel: alle drei Tabellen als Blätter, mit echten Zahlen und Daten', async () => {
  const { d } = await gefuellt();
  const r = await d.exportDatei(['fahrzeuge', 'kosten', 'orte'], 'xlsx');
  assert.equal(r.ok, true);
  assert.match(r.name, /^MobiMory-Daten-2026-11-04\.xlsx$/);
  assert.deepEqual(r.tabellen, [{ name: 'Fahrzeuge', anzahl: 2 }, { name: 'Kosten', anzahl: 2 }, { name: 'Orte', anzahl: 1 }]);
  const gelesen = await A.dateiLesen(r.bytes);
  assert.deepEqual(gelesen.blaetter.map(b => b.name), ['Fahrzeuge', 'Kosten', 'Orte']);
  const fz = gelesen.blaetter[0].zeilen;
  assert.deepEqual(fz[0].slice(0, 2), ['Bezeichnung', 'Art']);
  const spalte = n => fz[0].indexOf(n);
  const boot = fz.find(z => z[0] === 'Seestern'), auto = fz.find(z => String(z[0]).startsWith('Touran'));
  assert.equal(boot[1], 'Boot');
  assert.equal(boot[spalte('Länge (m)')], 9.5);
  assert.equal(boot[spalte('Erstzulassung')], '2015-05-01');
  assert.equal(auto[0], 'Touran, "groß"');
  assert.equal(auto[spalte('Zulässiges Gesamtgewicht (kg)')], 2150);
  const ko = gelesen.blaetter[1].zeilen;
  assert.deepEqual(ko[0].slice(0, 6), ['Fahrzeug', 'Datum', 'Bezeichnung', 'Gruppe', 'Art der Kosten', 'Betrag (€)']);
  const diesel = ko.find(z => z[2] === 'Diesel');
  assert.deepEqual(diesel.slice(0, 6), ['Seestern', '2026-07-05', 'Diesel', 'Variable Kosten', 'Treibstoff und Energie', 180.5]);
  assert.equal(diesel[ko[0].indexOf('Notiz')], 'Zeile 1\nZeile 2');
  const liege = ko.find(z => z[2] === 'Liegeplatz Heimathafen');
  assert.equal(liege[0 + 5], 2400);
  assert.ok(liege[ko[0].indexOf('Wie oft')]);
  const orte = gelesen.blaetter[2].zeilen;
  assert.deepEqual(orte[1].slice(0, 3), ['Hafen Biograd', 'Hafen oder Marina', 'Kroatien']);
  assert.match(orte[1][orte[0].indexOf('Ausstattung')], /Strom/);
});

test('Export CSV: eine Tabelle, Semikolon, deutsche Zahlen und Daten; mehrere Tabellen gehen nur mit Excel', async () => {
  const { d } = await gefuellt();
  const r = await d.exportDatei(['kosten'], 'csv');
  assert.equal(r.ok, true);
  assert.equal(r.name, 'MobiMory-Kosten-2026-11-04.csv');
  const t = new TextDecoder().decode(r.bytes.subarray(3));
  assert.match(t, /^Fahrzeug;Datum;Bezeichnung;/);
  assert.match(t, /Seestern;05\.07\.2026;Diesel;Variable Kosten;Treibstoff und Energie;180,5;/);
  const zwei = await d.exportDatei(['kosten', 'orte'], 'csv');
  assert.equal(zwei.ok, false);
  assert.match(zwei.fehler, /nur eine Tabelle/);
  assert.equal((await d.exportDatei([], 'xlsx')).ok, false);
  assert.equal((await d.exportDatei(['kosten'], 'pdf')).ok, false);
  assert.equal((await d.exportDatei(['quatsch'], 'xlsx')).ok, false);
});

test('Export ohne Daten: nur die Kopfzeile', async () => {
  const d = await neuesGeraet();
  const r = await d.exportDatei(['fahrzeuge', 'kosten', 'orte'], 'xlsx');
  assert.equal(r.ok, true);
  assert.deepEqual(r.tabellen.map(t => t.anzahl), [0, 0, 0]);
  const g = await A.dateiLesen(r.bytes);
  assert.equal(g.blaetter.length, 3);
});

test('Rundlauf: Fahrzeuge exportieren, auf einem leeren Gerät wieder importieren, alles stimmt', async () => {
  const { d } = await gefuellt();
  const r = await d.exportDatei(['fahrzeuge'], 'xlsx');
  const blatt = (await A.dateiLesen(r.bytes)).blaetter[0].zeilen;
  const neu = await neuesGeraet();
  const z = A.spaltenRaten(blatt[0], neu.importZielfelder(null));
  assert.ok(z.includes('__art') && z.includes('bezeichnung') && z.includes('gesamtgewicht'));
  const opt = { zeilen: blatt.slice(1), zuordnung: z, artId: '', ersteNr: 2 };
  const v = await neu.importVorschau(opt);
  assert.deepEqual(v.zaehlung, { neu: 2, vorhanden: 0, doppelt: 0, fehler: 0 });
  assert.equal((await neu.importFahrzeuge(opt)).ok, true);
  const vorher = await d.fahrzeugListe(), nachher = await neu.fahrzeugListe();
  assert.deepEqual(nachher.map(x => x.fahrzeug.art), vorher.map(x => x.fahrzeug.art));
  vorher.forEach((x, i) => {
    Object.keys(x.aktuell.werte).forEach(k => {
      const a = x.aktuell.werte[k], b = nachher[i].aktuell.werte[k];
      if (a !== null && a !== '' && !(Array.isArray(a) && !a.length)) assert.deepEqual(b, a, k);
    });
  });
  /* und ein zweiter Import ins selbe Gerät findet alles schon vor */
  assert.deepEqual((await neu.importVorschau(opt)).zaehlung, { neu: 0, vorhanden: 2, doppelt: 0, fehler: 0 });
  assert.deepEqual((await d.importVorschau(opt)).zaehlung, { neu: 0, vorhanden: 2, doppelt: 0, fehler: 0 });
});

test('Rundlauf über CSV mit Windows-Zeichensatz aus deutschem Excel', async () => {
  const d = await neuesGeraet();
  /* „Name;Marke;Länge (m)\r\nBoot Ä;Müller;7,5“ in Windows-1252 */
  const text = 'Name;Hersteller;Länge (m);Baujahr\r\nBoot Ä;Müller;7,5;2001\r\n';
  const bytes = new Uint8Array([...text].map(c => c.charCodeAt(0) & 255));
  const r = await A.dateiLesen(bytes);
  const [kopf, ...rest] = r.blaetter[0].zeilen;
  const opt = { zeilen: rest, zuordnung: A.spaltenRaten(kopf, d.importZielfelder('boot')), artId: 'boot' };
  assert.equal((await d.importFahrzeuge(opt)).ok, true);
  const f = (await d.fahrzeugListe())[0].aktuell.werte;
  assert.equal(f.bezeichnung, 'Boot Ä');
  assert.equal(f.marke, 'Müller');
  assert.equal(f.laenge, 7.5);
  assert.equal(f.baujahr, 2001);
});
