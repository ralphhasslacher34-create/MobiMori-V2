'use strict';
/* Schritt 9 (2.0.33): Routen einlesen, Fahrplan, Wetter und Tide holen und auswerten, GPS-Strecke in den Zähler. Das Netz wird nachgebaut. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/routen.js');
require('../js/daten.js');
const MM = globalThis.MM;

/* feste Uhr: 3. November 2026, 12:00 Ortszeit */
const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
const GPX = `<gpx><metadata><name>Rhein Törn</name></metadata><rte>
<rtept lat="48.0" lon="8.0"><name>Start</name></rtept><rtept lat="48.2" lon="8.0"/><rtept lat="48.4" lon="8.0"><name>Ziel</name></rtept></rte></gpx>`;

/* Ein nachgebautes Netz: liefert für jede Anfrage Stundenwerte für 16 Tage ab 3.11.2026 0:00 UTC. */
function netz(optionen) {
  const o = optionen || {};
  const t0 = Math.floor(Date.UTC(2026, 10, 3, 0, 0) / 1000);
  const zeiten = []; for (let i = 0; i < 16 * 24; i++) zeiten.push(t0 + i * 3600);
  const aufrufe = [];
  async function holeJson(url) {
    aufrufe.push(url);
    if (o.aus) throw new Error('kein Netz');
    if (url.includes('marine-api')) {
      if (o.ohneMarine) throw new Error('Antwort 400');
      return { hourly: { time: zeiten, wave_height: zeiten.map(() => 0.8), wave_direction: zeiten.map(() => 270), wave_period: zeiten.map(() => 5),
        sea_level_height_msl: zeiten.map((_, i) => Math.round(1.5 * Math.sin(2 * Math.PI * i / 12.42) * 100) / 100) } };
    }
    return { hourly: { time: zeiten, temperature_2m: zeiten.map(() => 9), precipitation: zeiten.map(() => 0), precipitation_probability: zeiten.map(() => 10),
      wind_speed_10m: zeiten.map((_, i) => 10 + (i % 24)), wind_gusts_10m: zeiten.map((_, i) => 15 + (i % 24) * 2), wind_direction_10m: zeiten.map(() => 225), weather_code: zeiten.map(() => 3) } };
  }
  return { holeJson, aufrufe };
}

async function neu(netzOpt) {
  let t = 0;
  const n = netz(netzOpt);
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(), holeJson: n.holeJson });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = x => arten.find(a => a.aktuell.werte.bezeichnung === x).objekt.id;
  return { d, boot, wm, anna, artId, netz: n };
}
const toern = (c, extra) => Object.assign({ bezeichnung: 'Törn', artId: c.artId('Törn'), fahrzeugId: c.boot, vonDatum: '2026-11-05', vonZeit: '08:00', bisDatum: '2026-11-06', verantwortlichId: c.anna }, extra || {});
async function mitAktivitaet(c, extra) { const r = await c.d.aktivitaetAnlegen(toern(c, extra)); assert.equal(r.ok, true, JSON.stringify(r)); return r.id; }

test('Speicher: Tabelle routen, Version 15, die Sicherung enthält die Routen und stellt sie wieder her, alte Sicherung ohne die Tabelle geht', async () => {
  assert.equal(MM.Speicher.DB_VERSION, 16);
  assert.ok(MM.Speicher.TABELLEN.includes('routen'));
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const r = await c.d.routeImportieren(aktId, GPX, 'rhein.gpx');
  assert.equal(r.ok, true, JSON.stringify(r));
  await c.d.routeAendern(r.id, { bezeichnung: 'Rhein Törn', geschwindigkeit: '6', einheit: 'kn', abfahrtDatum: '2026-11-05', abfahrtZeit: '08:00' });
  await c.d.wetterAbrufen(aktId);
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  assert.equal(s.zahlen.routen, 1);
  const b = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => JETZT });
  await b.starten();
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  const a = await b.routeAnsicht(aktId);
  assert.equal(a.route.werte.geschwindigkeit, 6);
  assert.equal(a.route.punkte.length, 3);
  assert.equal((await b.wetterStand(aktId)).ok, true, 'der gemerkte Wetterstand kommt mit');
  const alt = await c.d.sicherungLesen(s.bytes, '');
  delete alt.kopf.tabellen.routen; delete alt.kopf.zaehlung.routen;
  const b2 = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => JETZT });
  await b2.starten();
  await b2.sicherungEinspielen(alt);
  assert.equal(await b2.speicher.alle('routen').then(l => l.length), 0);
});

test('Import: Name aus der Datei, Einheit nach Fahrzeug, Abfahrt aus der Aktivität, Hinweise, Länge', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const r = await c.d.routeImportieren(aktId, GPX, 'rhein.gpx');
  assert.equal(r.ok, true);
  assert.equal(r.name, 'Rhein Törn'); assert.equal(r.format, 'gpx'); assert.equal(r.punkte, 3);
  assert.ok(r.laengeKm > 44 && r.laengeKm < 45.2, 'Länge ' + r.laengeKm);
  const a = await c.d.routeAnsicht(aktId);
  assert.equal(a.route.werte.einheit, 'kn');
  assert.equal(a.route.werte.abfahrtDatum, '2026-11-05'); assert.equal(a.route.werte.abfahrtZeit, '08:00');
  assert.equal(a.route.fahrplan.ok, false, 'ohne Geschwindigkeit kein Fahrplan');
  assert.equal(a.aktivitaet.welt, 'wasser');
  const land = await mitAktivitaet(c, { bezeichnung: 'Ausfahrt', artId: c.artId('Ausfahrt'), fahrzeugId: c.wm });
  await c.d.routeImportieren(land, GPX, 'x.gpx');
  assert.equal((await c.d.routeAnsicht(land)).route.werte.einheit, 'kmh');
});

test('Import: schlechte Datei, unbekannte und stornierte Aktivität werden abgelehnt', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  assert.match((await c.d.routeImportieren(aktId, 'Hallo', 'x.txt')).fehler.datei, /GPX, KML oder GeoJSON/);
  assert.ok((await c.d.routeImportieren('gibt-es-nicht', GPX, 'x.gpx')).fehler.allgemein);
  await c.d.aktivitaetStornieren(aktId, 'x');
  assert.match((await c.d.routeImportieren(aktId, GPX, 'x.gpx')).fehler.allgemein, /storniert/);
  assert.equal((await c.d.routeAnsicht(aktId)).route, null);
});

test('Neue Route ersetzt die gültige, die frühere bleibt erhalten und lässt sich wieder verwenden', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const eins = (await c.d.routeImportieren(aktId, GPX, 'eins.gpx')).id;
  const zwei = (await c.d.routeImportieren(aktId, GPX.replace('Rhein Törn', 'Zweite'), 'zwei.gpx')).id;
  let a = await c.d.routeAnsicht(aktId);
  assert.equal(a.route.id, zwei); assert.equal(a.fruehere.length, 1); assert.equal(a.fruehere[0].id, eins);
  assert.equal((await c.d.routeVerwenden(aktId, eins)).ok, true);
  a = await c.d.routeAnsicht(aktId);
  assert.equal(a.route.id, eins); assert.equal(a.fruehere[0].id, zwei);
  assert.equal((await c.d.routeVerwenden(aktId, eins)).geaendert, false);
  await c.d.routeAusblenden(eins);
  assert.equal((await c.d.routeAnsicht(aktId)).route, null);
  assert.equal((await c.d.routenListe(aktId)).length, 2, 'nichts wird gelöscht');
});

test('Route ändern: Prüfungen, Fahrplan mit Fahrzeit und Ankunft, keine Änderung ohne Unterschied', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const id = (await c.d.routeImportieren(aktId, GPX, 'a.gpx')).id;
  assert.ok((await c.d.routeAendern(id, { bezeichnung: '' })).fehler.bezeichnung);
  assert.ok((await c.d.routeAendern(id, { bezeichnung: 'X', geschwindigkeit: 'schnell' })).fehler.geschwindigkeit);
  assert.ok((await c.d.routeAendern(id, { bezeichnung: 'X', geschwindigkeit: '6', einheit: '' })).fehler.einheit);
  assert.ok((await c.d.routeAendern(id, { bezeichnung: 'X', geschwindigkeit: '120', einheit: 'kn' })).fehler.geschwindigkeit);
  assert.ok((await c.d.routeAendern(id, { bezeichnung: 'X', geschwindigkeit: '0', einheit: 'kn' })).fehler.geschwindigkeit);
  assert.ok((await c.d.routeAendern(id, { bezeichnung: 'X', abfahrtZeit: '08:00', abfahrtDatum: '' })).fehler.abfahrtDatum);
  const ok = await c.d.routeAendern(id, { bezeichnung: 'Rhein', geschwindigkeit: '6,5', einheit: 'kn', abfahrtDatum: '2026-11-05', abfahrtZeit: '08:00', notiz: 'ruhig' });
  assert.equal(ok.ok, true, JSON.stringify(ok)); assert.equal(ok.geaendert, true);
  const f = (await c.d.routeAnsicht(aktId)).route.fahrplan;
  assert.equal(f.ok, true);
  assert.equal(f.dauerMin, Math.round(f.laengeKm / (6.5 * 1.852) * 60));
  assert.equal(f.zeilen[0].eta, '2026-11-05T08:00');
  assert.equal(f.ankunft, MM.Routen.zeitIso(MM.Routen.zeitMs('2026-11-05T08:00') + f.dauerMin * 60000));
  assert.equal((await c.d.routeAendern(id, { bezeichnung: 'Rhein', geschwindigkeit: '6,5', einheit: 'kn', abfahrtDatum: '2026-11-05', abfahrtZeit: '08:00', notiz: 'ruhig' })).geaendert, false);
});

test('Länge der Route als geplante Strecke der Aktivität übernehmen', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const id = (await c.d.routeImportieren(aktId, GPX, 'a.gpx')).id;
  assert.equal((await c.d.routeAnsicht(aktId)).aktivitaet.geplanteStrecke, null);
  const r = await c.d.routeAlsGeplanteStrecke(aktId, id);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.ok(r.km > 44 && r.km < 45.2);
  assert.equal((await c.d.aktivitaetLaden(aktId)).aktuell.werte.geplanteStrecke, r.km);
  assert.equal((await c.d.routeAlsGeplanteStrecke(aktId, 'nix')).ok, false);
});

test('GPX-Ausgabe: Dateiname aus dem Namen, Inhalt lässt sich wieder einlesen', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const id = (await c.d.routeImportieren(aktId, GPX, 'a.gpx')).id;
  const g = await c.d.routeGpx(id);
  assert.equal(g.ok, true); assert.equal(g.name, 'Rhein-Törn.gpx');
  const neuGelesen = MM.Routen.lesen(g.text, g.name);
  assert.equal(neuGelesen.ok, true); assert.equal(neuGelesen.punkte.length, 3); assert.equal(neuGelesen.punkte[2].name, 'Ziel');
});

const FERTIG = { bezeichnung: 'Rhein', geschwindigkeit: '8', einheit: 'kn', abfahrtDatum: '2026-11-05', abfahrtZeit: '08:00' };

test('Wetter holen: braucht Route, Geschwindigkeit und Abfahrt; Boot holt Wetter und Marine mit Knoten, Wohnmobil nur Wetter mit km/h', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  assert.match((await c.d.wetterAbrufen(aktId)).fehler.allgemein, /noch keine Route/);
  const id = (await c.d.routeImportieren(aktId, GPX, 'a.gpx')).id;
  assert.ok((await c.d.wetterAbrufen(aktId)).fehler.geschwindigkeit);
  await c.d.routeAendern(id, Object.assign({}, FERTIG, { abfahrtDatum: '', abfahrtZeit: '' }));
  assert.ok((await c.d.wetterAbrufen(aktId)).fehler.abfahrtDatum);
  await c.d.routeAendern(id, FERTIG);
  const r = await c.d.wetterAbrufen(aktId);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.ok(r.punkte >= 3 && r.punkte <= 12);
  assert.equal(r.ohneWetter, 0); assert.equal(r.ohneMeer, 0);
  const wetter = c.netz.aufrufe.filter(u => u.startsWith('https://api.open-meteo.com'));
  const meer = c.netz.aufrufe.filter(u => u.includes('marine-api'));
  assert.equal(wetter.length, r.punkte); assert.equal(meer.length, r.punkte);
  assert.ok(wetter.every(u => u.includes('wind_speed_unit=kn')));

  const land = await mitAktivitaet(c, { bezeichnung: 'Ausfahrt', artId: c.artId('Ausfahrt'), fahrzeugId: c.wm });
  const lid = (await c.d.routeImportieren(land, GPX, 'a.gpx')).id;
  await c.d.routeAendern(lid, { bezeichnung: 'Land', geschwindigkeit: '60', einheit: 'kmh', abfahrtDatum: '2026-11-05', abfahrtZeit: '08:00' });
  c.netz.aufrufe.length = 0;
  assert.equal((await c.d.wetterAbrufen(land)).ok, true);
  assert.ok(c.netz.aufrufe.every(u => u.includes('wind_speed_unit=kmh') && !u.includes('marine-api')));
});

test('Wetterstand: Zeilen mit Wetter, Wellen, Wasserstand, Gezeiten und Vergleich früher oder später', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const id = (await c.d.routeImportieren(aktId, GPX, 'a.gpx')).id;
  await c.d.routeAendern(id, FERTIG);
  assert.equal((await c.d.wetterStand(aktId)).keins, true);
  await c.d.wetterAbrufen(aktId);
  const s = await c.d.wetterStand(aktId);
  assert.equal(s.ok, true); assert.equal(s.aktuell, true); assert.equal(s.mitMeer, true); assert.equal(s.windEinheit, 'kn');
  assert.equal(s.zeilen[0].nr, 1);
  assert.equal(s.zeilen[0].wetter.himmel, 'bedeckt');
  assert.equal(s.zeilen[0].meer.welle, 0.8);
  assert.ok(s.zeilen[0].tide && s.zeilen[0].tide.hoch && s.zeilen[0].tide.niedrig, 'Hoch- und Niedrigwasser');
  assert.deepEqual(s.vergleich.map(v => v.versatzMin), [-120, -60, 0, 60, 120]);
  /* Das nachgebaute Netz hat nach der Uhrzeit steigenden Wind: Eine Stunde später ist stärker. */
  const nullV = s.vergleich.find(v => v.versatzMin === 0).schwerste.boeen.wert;
  const spaet = s.vergleich.find(v => v.versatzMin === 60).schwerste.boeen.wert;
  assert.ok(spaet > nullV, spaet + ' > ' + nullV);
  const s2 = await c.d.wetterStand(aktId, 60);
  assert.equal(s2.schwerste.boeen.wert, spaet);
  assert.equal(s2.versatzMin, 60);
});

test('Wetterstand ist „nicht aktuell“, wenn Geschwindigkeit oder Abfahrt danach geändert wurden', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const id = (await c.d.routeImportieren(aktId, GPX, 'a.gpx')).id;
  await c.d.routeAendern(id, FERTIG);
  await c.d.wetterAbrufen(aktId);
  await c.d.routeAendern(id, Object.assign({}, FERTIG, { geschwindigkeit: '9' }));
  assert.equal((await c.d.wetterStand(aktId)).aktuell, false);
  await c.d.wetterAbrufen(aktId);
  assert.equal((await c.d.wetterStand(aktId)).aktuell, true);
  await c.d.routeAendern(id, Object.assign({}, FERTIG, { geschwindigkeit: '9', abfahrtZeit: '09:00' }));
  assert.equal((await c.d.wetterStand(aktId)).aktuell, false);
});

test('Ohne Netz: klare Meldung, der frühere Stand bleibt. Ohne Marine: Wetter bleibt, Wellen fehlen', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const id = (await c.d.routeImportieren(aktId, GPX, 'a.gpx')).id;
  await c.d.routeAendern(id, FERTIG);
  await c.d.wetterAbrufen(aktId);
  const vorher = (await c.d.wetterStand(aktId)).abgerufenAm;
  c.d.holeJson = async () => { throw new Error('kein Netz'); };
  const r = await c.d.wetterAbrufen(aktId);
  assert.equal(r.ok, false); assert.equal(r.offline, true); assert.match(r.fehler.allgemein, /kein Netz/);
  assert.equal((await c.d.wetterStand(aktId)).abgerufenAm, vorher, 'alter Stand bleibt');

  const c2 = await neu({ ohneMarine: true });
  const a2 = await mitAktivitaet(c2);
  const id2 = (await c2.d.routeImportieren(a2, GPX, 'a.gpx')).id;
  await c2.d.routeAendern(id2, FERTIG);
  const r2 = await c2.d.wetterAbrufen(a2);
  assert.equal(r2.ok, true); assert.equal(r2.ohneMeer, r2.punkte); assert.equal(r2.ohneWetter, 0);
  const s2 = await c2.d.wetterStand(a2);
  assert.equal(s2.zeilen[0].meer, null); assert.equal(s2.zeilen[0].tide, null); assert.ok(s2.zeilen[0].wetter.wind > 0);
});

test('Wetter: Abfahrt mehr als 15 Tage voraus oder mehr als einen Tag vorbei wird erklärt statt abgefragt', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const id = (await c.d.routeImportieren(aktId, GPX, 'a.gpx')).id;
  await c.d.routeAendern(id, Object.assign({}, FERTIG, { abfahrtDatum: '2026-12-01' }));
  assert.match((await c.d.wetterAbrufen(aktId)).fehler.abfahrtDatum, /nächsten 15 Tage/);
  await c.d.routeAendern(id, Object.assign({}, FERTIG, { abfahrtDatum: '2026-10-20' }));
  assert.match((await c.d.wetterAbrufen(aktId)).fehler.abfahrtDatum, /Vergangenheit/);
  assert.equal(c.netz.aufrufe.length, 0, 'es wurde nichts abgefragt');
});

test('GPS-Strecke in den Streckenzähler: nur auf Wunsch, nur mit Stand von Hand, Quelle „gps“, Strecke danach wieder bei 0', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c, { bezeichnung: 'Ausfahrt', artId: c.artId('Ausfahrt'), fahrzeugId: c.wm });
  assert.match((await c.d.gpsStreckeUebernehmen(aktId)).fehler.allgemein, /noch keine GPS-Strecke/);
  assert.equal((await c.d.gpsSpurLesen(aktId)).km, 0);
  let spur = MM.Routen.spurNeu();
  const t0 = Date.now();
  for (let i = 0; i <= 20; i++) spur = MM.Routen.spurPunkt(spur, { breite: 48, laenge: 8 + i * 0.0009, genauigkeit: 6, zeitMs: t0 + i * 10000 }, 'land');
  assert.ok(spur.km > 1.2);
  await c.d.gpsSpurSpeichern(aktId, spur);
  assert.match((await c.d.gpsStreckeUebernehmen(aktId)).fehler.allgemein, /keinen Zähler für die Strecke/);
  const z = (await c.d.zaehlerAnlegen(c.wm, null, 'strecke', { bezeichnung: 'Tacho' })).id;
  assert.match((await c.d.gpsStreckeUebernehmen(aktId)).fehler.allgemein, /Tachostand von Hand/);
  await c.d.zaehlerStandEintragen(z, { wert: '45120', datum: '2026-11-01' });
  const r = await c.d.gpsStreckeUebernehmen(aktId);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(r.stand, Math.round((45120 + spur.km) * 10) / 10);
  const staende = (await c.d.speicher.wo('zaehlerstaende', 'zaehlerId', z)).sort((a, b) => a.nr - b.nr);
  assert.equal(staende.length, 2); assert.equal(staende[1].quelle, 'gps'); assert.equal(staende[0].quelle, 'hand');
  assert.match(staende[1].notiz, /GPS-Strecke/);
  const danach = await c.d.gpsSpurLesen(aktId);
  assert.equal(danach.km, 0); assert.ok(danach.letzter, 'der letzte Punkt bleibt, damit es ohne Sprung weitergeht');
  assert.match((await c.d.gpsStreckeUebernehmen(aktId)).fehler.allgemein, /noch keine GPS-Strecke/);
  /* Eine Handeingabe danach hat das letzte Wort: Sie wird der neueste Stand. */
  await c.d.zaehlerStandEintragen(z, { wert: '45200', datum: '2026-11-02' });
  assert.equal((await c.d.streckenZaehler(c.wm)).stand.wert, 45200);
});
