'use strict';
/* 2.0.16: Fahrzeugarten selbst anlegen, umbenennen, ausblenden, löschen und bereinigen. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/reiseorte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const F = MM.Fahrzeugarten, L = MM.Logbuch;

function neueDaten(speicher) {
  let t = 0;
  const start = new Date(2026, 10, 4, 14, 30, 0).getTime();
  return new MM.Daten.Daten(speicher || new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(start + (t++)).toISOString() });
}
async function frisch() { const d = neueDaten(); await d.starten(); return d; }
const ids = () => F.alle().map(a => a.id);

test('Ohne eigene Angaben gilt der mitgelieferte Baum unverändert', async () => {
  await frisch();
  assert.equal(ids().length, 15);
  assert.deepEqual(F.wiederherstellbar(), []);
});

test('Eigene Untergruppe anlegen: erscheint im Baum, erbt Felder, Welt und Ereignisse der Obergruppe', async () => {
  const d = await frisch();
  const r = await d.fahrzeugartAnlegen({ name: 'Trimaran', eltern: 'segelboot' });
  assert.ok(r.ok, JSON.stringify(r));
  const a = F.art(r.id);
  assert.equal(a.name, 'Trimaran'); assert.equal(a.welt, 'wasser'); assert.equal(a.eigen, true);
  assert.deepEqual(F.felder(r.id).map(f => f.key), F.felder('boot').map(f => f.key));
  assert.equal(F.kennungFeld(r.id), 'registriernummer');
  assert.deepEqual(F.vorfahren(r.id), [r.id, 'segelboot', 'boot', 'wasser', 'alle']);
  assert.ok(ids().includes(r.id));
  const z = L.zuordnungFuerKnoten(['segelboot']);
  assert.equal(L.ereignisartGilt(z, r.id), true, 'erbt von „Segelboot“');
  assert.equal(L.ereignisartGilt(z, 'sportboot'), false);
  assert.ok((await d.fahrzeugAnlegen(r.id, { bezeichnung: 'Meine Tri' })).ok);
});

test('Eigene Art direkt unter einer Welt bekommt die Standardfelder der Welt (Aufsitzrasenmäher unter Land)', async () => {
  const d = await frisch();
  const r = await d.fahrzeugartAnlegen({ name: 'Aufsitzrasenmäher', eltern: 'land' });
  assert.ok(r.ok);
  assert.equal(F.art(r.id).welt, 'land');
  assert.deepEqual(F.felder(r.id).map(f => f.key), F.felder('auto').map(f => f.key));
  for (let i = 1; i <= 25; i++) assert.ok((await d.fahrzeugAnlegen(r.id, { bezeichnung: 'Mäher ' + i })).ok);
  assert.equal((await d.fahrzeugListe()).length, 25);
});

test('Eigene Art anlegen: Name Pflicht, Gruppe muss es geben, gleicher Name unter derselben Gruppe nicht', async () => {
  const d = await frisch();
  assert.ok((await d.fahrzeugartAnlegen({ name: '  ', eltern: 'boot' })).fehler.name);
  assert.ok((await d.fahrzeugartAnlegen({ name: 'X', eltern: 'gibt-es-nicht' })).fehler.eltern);
  assert.ok((await d.fahrzeugartAnlegen({ name: 'X' })).fehler.eltern);
  assert.ok((await d.fahrzeugartAnlegen({ name: 'segelboot', eltern: 'boot' })).fehler.name, 'gleicher Name, Groß- und Kleinschreibung egal');
  assert.ok((await d.fahrzeugartAnlegen({ name: 'Segelboot', eltern: 'sportboot' })).ok, 'unter einer anderen Gruppe ist derselbe Name erlaubt');
  assert.equal((await d.fahrzeugartAnlegen({ name: 'Wurzelart', eltern: 'alle' })).ok, false, 'unter der Wurzel nicht');
});

test('Eigene Arten bleiben nach dem Neustart erhalten', async () => {
  const speicher = new MM.Speicher.MemorySpeicher();
  const a = neueDaten(speicher); await a.starten();
  const r = await a.fahrzeugartAnlegen({ name: 'Trimaran', eltern: 'segelboot' });
  await a.fahrzeugartAendern('sportboot', { name: 'Sportboot', ausgeblendet: 'ja' });
  F.konfigurieren(null);
  assert.equal(F.art(r.id), null, 'ohne Laden ist nichts da');
  const b = neueDaten(speicher); await b.starten();
  assert.equal(F.art(r.id).name, 'Trimaran');
  assert.equal(F.sichtbar('sportboot'), false);
});

test('Umbenennen: auch mitgelieferte Arten, Name unter derselben Gruppe bleibt eindeutig, Welten sind fest', async () => {
  const d = await frisch();
  assert.ok((await d.fahrzeugartAendern('segelboot-jolle', { name: 'Jolle', ausgeblendet: 'nein' })).geaendert);
  assert.equal(F.art('segelboot-jolle').name, 'Jolle');
  assert.equal((await d.fahrzeugartAendern('segelboot-jolle', { name: 'Jolle', ausgeblendet: 'nein' })).geaendert, false);
  assert.ok((await d.fahrzeugartAendern('segelboot-jolle', { name: 'segelboot monohull', ausgeblendet: 'nein' })).fehler.name);
  assert.ok((await d.fahrzeugartAendern('segelboot-jolle', { name: '', ausgeblendet: 'nein' })).fehler.name);
  assert.equal((await d.fahrzeugartAendern('wasser', { name: 'Wasser', ausgeblendet: 'ja' })).ok, false);
  assert.equal((await d.fahrzeugartLoeschen('wasser')).ok, false);
});

test('Ausblenden: Art und alles darunter sind für neue Fahrzeuge weg, bestehende Fahrzeuge bleiben unverändert', async () => {
  const d = await frisch();
  const alt = await d.fahrzeugAnlegen('segelboot-katamaran', { bezeichnung: 'Kat' });
  assert.ok((await d.fahrzeugartAendern('segelboot', { name: 'Segelboot', ausgeblendet: 'ja' })).geaendert);
  assert.ok(!ids().includes('segelboot') && !ids().includes('segelboot-katamaran'));
  assert.ok(F.alle(true).map(a => a.id).includes('segelboot-katamaran'));
  assert.equal(F.sichtbar('segelboot-katamaran'), false);
  assert.ok((await d.fahrzeugAnlegen('segelboot-jolle', { bezeichnung: 'x' })).fehler.art);
  const f = await d.fahrzeugListe();
  assert.equal(f.length, 1);
  assert.equal(F.art(f[0].fahrzeug.art).name, 'Segelboot Katamaran', 'das bestehende Fahrzeug kennt seine Art weiter');
  assert.ok(alt.ok);
  await d.fahrzeugartAendern('segelboot', { name: 'Segelboot', ausgeblendet: 'nein' });
  assert.ok(ids().includes('segelboot-katamaran'), 'wieder eingeblendet');
});

test('Ereignisse gelten für eine ausgeblendete Art weiter wie eingestellt, und ihre Angabe geht beim Speichern nicht verloren', async () => {
  const d = await frisch();
  const z = { alle: 'nein', segelboot: 'ja', 'segelboot-katamaran': 'nein' };
  await d.fahrzeugartAendern('segelboot-katamaran', { name: 'Segelboot Katamaran', ausgeblendet: 'ja' });
  assert.equal(L.ereignisartGilt(z, 'segelboot-katamaran'), false, 'die bewusste Abwahl bleibt wirksam');
  assert.equal(L.ereignisartGilt(z, 'segelboot-monohull'), true);
  const ids2 = L.auswahlAusZuordnung(z);
  const neu = L.zuordnungAusAuswahl(ids2, z);
  assert.deepEqual(neu, z, 'die Abwahl am ausgeblendeten Katamaran bleibt in der Angabe');
});

test('Löschen: nur wenn weder die Art noch eine Untergruppe von einem Fahrzeug benutzt wird', async () => {
  const d = await frisch();
  await d.fahrzeugAnlegen('segelboot-katamaran', { bezeichnung: 'Kat' });
  const benutzt = await d.fahrzeugartLoeschen('segelboot');
  assert.equal(benutzt.ok, false); assert.match(benutzt.fehler.allgemein, /benutzt/);
  assert.equal((await d.fahrzeugartLoeschen('segelboot-katamaran')).ok, false);
  assert.equal((await d.fahrzeugartLoeschen('boot')).ok, false, 'auch die Gruppe darüber nicht');
  const frei = await d.fahrzeugartLoeschen('sportboot');
  assert.ok(frei.ok); assert.deepEqual(frei.namen, ['Sportboot']);
  assert.equal(F.art('sportboot'), null);
  assert.ok(!ids().includes('sportboot'));
  assert.ok((await d.fahrzeugAnlegen('sportboot', { bezeichnung: 'x' })).fehler.art, 'gelöscht ist nicht mehr wählbar');
});

test('Löschen: eine Gruppe nimmt alles darunter mit, auch eigene Arten', async () => {
  const d = await frisch();
  const a = await d.fahrzeugartAnlegen({ name: 'Mäher', eltern: 'land' });
  const b = await d.fahrzeugartAnlegen({ name: 'Aufsitzmäher', eltern: a.id });
  const weg = await d.fahrzeugartLoeschen(a.id);
  assert.ok(weg.ok); assert.deepEqual(weg.namen, ['Mäher', 'Aufsitzmäher']);
  assert.equal(F.art(b.id), null);
  assert.equal((await d.fahrzeugartAnlegen({ name: 'Mäher', eltern: 'land' })).ok, true, 'der Name ist wieder frei');
});

test('Gelöschte Vorschläge lassen sich zurückholen, eigene gelöschte Arten nicht', async () => {
  const d = await frisch();
  const eigene = await d.fahrzeugartAnlegen({ name: 'Trimaran', eltern: 'segelboot' });
  await d.fahrzeugartLoeschen('segelboot');
  assert.equal(F.art('segelboot-monohull'), null);
  const v = await d.fahrzeugartenVerwaltung();
  assert.equal(v.wiederherstellbar, 4, 'Segelboot, Monohull, Katamaran, Jolle sind Vorschläge');
  const r = await d.fahrzeugartenWiederherstellen();
  assert.equal(r.anzahl, 4);
  assert.ok(ids().includes('segelboot-katamaran'));
  assert.equal(F.art(eigene.id), null, 'was der Nutzer selbst angelegt und gelöscht hat, bleibt weg');
  assert.equal((await d.fahrzeugartenWiederherstellen()).anzahl, 0);
});

test('Bereinigen: löscht alles Ungebrauchte, behält benutzte Arten samt Weg dorthin und die Gruppen Land, Wasser, Luft', async () => {
  const d = await frisch();
  await d.fahrzeugAnlegen('oldtimer', { bezeichnung: 'Opa' });
  const v = await d.fahrzeugartenVerwaltung();
  assert.ok(v.ungebraucht.length >= 12);
  const r = await d.fahrzeugartenBereinigen();
  assert.equal(r.anzahl, v.ungebraucht.length);
  assert.deepEqual(ids(), ['oldtimer']);
  assert.deepEqual(F.baum().map(k => k.id), ['alle', 'land', 'oldtimer', 'wasser', 'luft']);
  assert.equal((await d.fahrzeugartenBereinigen()).anzahl, 0, 'beim zweiten Mal gibt es nichts mehr');
  assert.equal((await d.fahrzeugartenVerwaltung()).ungebraucht.length, 0);
});

test('Bereinigen: ein benutztes Segelboot Katamaran hält die Gruppen Segelboot und Boot am Leben, die Geschwister gehen', async () => {
  const d = await frisch();
  await d.fahrzeugAnlegen('segelboot-katamaran', { bezeichnung: 'Kat' });
  await d.fahrzeugartenBereinigen();
  assert.deepEqual(ids().sort(), ['boot', 'segelboot', 'segelboot-katamaran']);
  assert.equal(F.art('sportboot'), null);
});

test('Die Übersicht zählt Fahrzeuge je Art mit Untergruppen', async () => {
  const d = await frisch();
  await d.fahrzeugAnlegen('segelboot-katamaran', { bezeichnung: 'A' });
  await d.fahrzeugAnlegen('segelboot-jolle', { bezeichnung: 'B' });
  await d.fahrzeugAnlegen('segelboot-jolle', { bezeichnung: 'C' });
  const z = {}; (await d.fahrzeugartenVerwaltung()).arten.forEach(k => { z[k.id] = k.fahrzeuge; });
  assert.equal(z['segelboot-jolle'], 2); assert.equal(z['segelboot'], 3); assert.equal(z['boot'], 3); assert.equal(z['wasser'], 3); assert.equal(z['auto'], 0);
  const wasser = (await d.fahrzeugartenVerwaltung()).arten.find(k => k.id === 'wasser');
  assert.equal(wasser.fest, true);
});

test('Sicherung: eigene Arten und Änderungen kommen mit zurück', async () => {
  const a = await frisch();
  const r = await a.fahrzeugartAnlegen({ name: 'Trimaran', eltern: 'segelboot' });
  await a.fahrzeugAnlegen(r.id, { bezeichnung: 'Tri' });
  await a.fahrzeugartAendern('sportboot', { name: 'Sportboot', ausgeblendet: 'ja' });
  const s = await a.sicherungErzeugen({ mitDateien: false });
  const b = neueDaten(); await b.starten();
  assert.equal(F.art(r.id), null);
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  assert.equal(F.art(r.id).name, 'Trimaran');
  assert.equal(F.sichtbar('sportboot'), false);
  assert.equal((await b.fahrzeugListe()).length, 1);
});

test('Regeln: eine Regel für eine ausgeblendete Art verliert ihre Angabe beim Speichern nicht, und eigene Untergruppen erben Regeln', async () => {
  const d = await frisch();
  const tri = (await d.fahrzeugartAnlegen({ name: 'Trimaran', eltern: 'segelboot' })).id;
  await d.fahrzeugartAendern('sportboot', { name: 'Sportboot', ausgeblendet: 'ja' });
  const p = d.pruefenRegel({ bezeichnung: 'Regel', fahrzeugArten: ['sportboot', 'segelboot'], art: 'befaehigung', artIds: [], gilt: 'ja' }, []);
  assert.deepEqual(p.werte.fahrzeugArten.sort(), ['segelboot', 'sportboot']);
  const e = MM.Orte.regelnAuswerten({ regeln: [{ id: 'r1', bezeichnung: 'x', fahrzeugArten: ['segelboot'] }], fahrzeugArt: tri, komponentenNamen: [] });
  assert.equal(e.greifen.length, 1);
});
