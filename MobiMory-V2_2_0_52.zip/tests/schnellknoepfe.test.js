'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/reiseorte.js');
require('../js/karte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const L = MM.Logbuch;

const JETZT = new Date(2026, 10, 4, 12, 0, 0).toISOString();
function neueDaten() {
  let t = 0;
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
}
async function start() {
  const d = neueDaten();
  await d.starten();
  await d.ereignisartenAusVorschlaegen();
  await d.ereignisartenVorauswahlUebernehmen();
  return d;
}
const namen = l => l.map(x => x.name);
async function eart(d, n) { return (await d.ereignisartenListe()).find(x => x.aktuell.werte.bezeichnung === n); }

test('Ohne eigene Einstellung gilt der Standard: Abfahrt, Ankunft, Notiz, Foto, Verantwortung wechseln, Wetter, Karte', async () => {
  const d = await start();
  const i = await d.schnellknoepfeFuerFahrzeugart('wohnmobil');
  assert.deepEqual(namen(i.knoepfe), ['Abfahrt', 'Ankunft', 'Notiz', 'Foto', 'Verantwortung wechseln', 'Wetter', 'Karte'], 'seit 2.0.35 sind Wetter und Karte im Standard');
  assert.equal(i.standard, true); assert.equal(i.eigene, false); assert.equal(i.von, null);
  assert.equal(i.max, 15, 'bis zu 15 Knöpfe belegbar (seit 2.0.20)');
  assert.equal(i.geraetMax, 8, 'ohne Einstellung zeigt das Gerät 8 Knöpfe, wie bisher');
});

test('Das Angebot hat nur Ereignisse, die zur Fahrzeugart passen, ohne Wechsel und ohne die Art „Notiz“, dazu die drei Funktionen', async () => {
  const d = await start();
  const wm = await d.schnellknoepfeFuerFahrzeugart('wohnmobil');
  const kat = await d.schnellknoepfeFuerFahrzeugart('segelboot-katamaran');
  assert.ok(namen(wm.angebot.ereignisse).includes('Tanken'));
  assert.ok(!namen(wm.angebot.ereignisse).includes('Segel setzen'), 'Segel setzen gibt es nur für Segelboote');
  assert.ok(namen(kat.angebot.ereignisse).includes('Segel setzen'));
  [wm, kat].forEach(i => {
    assert.ok(!namen(i.angebot.ereignisse).includes('Notiz'));
    assert.ok(!namen(i.angebot.ereignisse).includes(L.WECHSEL_ART));
    assert.deepEqual(namen(i.angebot.funktionen), ['Notiz', 'Foto', 'Verantwortung wechseln']);
  });
});

test('Wer allein fährt, nimmt „Verantwortung wechseln“ vom Knopf: es steht dann unter Sonstige', async () => {
  const d = await start();
  const abf = (await eart(d, 'Abfahrt')).objekt.id, ank = (await eart(d, 'Ankunft')).objekt.id, tanken = (await eart(d, 'Tanken')).objekt.id;
  const r = await d.schnellknoepfeSetzen('wohnmobil', ['e:' + abf, 'e:' + ank, 'e:' + tanken, 'f:notiz', '', '', '', '']);
  assert.ok(r.ok, JSON.stringify(r)); assert.equal(r.anzahl, 4);
  const i = await d.schnellknoepfeFuerFahrzeugart('wohnmobil');
  assert.deepEqual(namen(i.knoepfe), ['Abfahrt', 'Ankunft', 'Tanken', 'Notiz']);
  assert.equal(i.eigene, true); assert.equal(i.standard, false);
  assert.deepEqual(namen(i.sonstige.funktionen), ['Foto', 'Verantwortung wechseln']);
  assert.ok(!namen(i.sonstige.ereignisse).includes('Tanken'), 'was auf einem Knopf liegt, steht nicht noch einmal unter Sonstige');
  assert.ok(namen(i.sonstige.ereignisse).includes('Anlegen') === false, 'Anlegen gilt nicht für das Wohnmobil');
});

test('Die Reihenfolge der Knöpfe ist die, die der Nutzer einstellt', async () => {
  const d = await start();
  const abf = (await eart(d, 'Abfahrt')).objekt.id, ank = (await eart(d, 'Ankunft')).objekt.id;
  await d.schnellknoepfeSetzen('auto', ['f:foto', 'e:' + ank, '', 'e:' + abf]);
  assert.deepEqual(namen((await d.schnellknoepfeFuerFahrzeugart('auto')).knoepfe), ['Foto', 'Ankunft', 'Abfahrt']);
});

test('Wasserskiboot und Katamaran können verschiedene Knöpfe haben, eine Untergruppe übernimmt die Liste der Obergruppe', async () => {
  const d = await start();
  const ski = (await eart(d, 'Wasserski-Lauf')).objekt.id, segel = (await eart(d, 'Segel setzen')).objekt.id, anker = (await eart(d, 'Anker werfen')).objekt.id;
  await d.schnellknoepfeSetzen('wasserskiboot', ['e:' + ski, 'e:' + anker]);
  await d.schnellknoepfeSetzen('segelboot', ['e:' + segel, 'e:' + anker]);
  assert.deepEqual(namen((await d.schnellknoepfeFuerFahrzeugart('wasserskiboot')).knoepfe), ['Wasserski-Lauf', 'Anker werfen']);
  const kat = await d.schnellknoepfeFuerFahrzeugart('segelboot-katamaran');
  assert.deepEqual(namen(kat.knoepfe), ['Segel setzen', 'Anker werfen'], 'der Katamaran übernimmt von „Segelboot“');
  assert.equal(kat.von, 'segelboot'); assert.equal(kat.eigene, false);
  /* eine eigene Liste an der Untergruppe gewinnt */
  await d.schnellknoepfeSetzen('segelboot-katamaran', ['f:foto']);
  assert.deepEqual(namen((await d.schnellknoepfeFuerFahrzeugart('segelboot-katamaran')).knoepfe), ['Foto']);
  assert.deepEqual(namen((await d.schnellknoepfeFuerFahrzeugart('segelboot-jolle')).knoepfe), ['Segel setzen', 'Anker werfen']);
  /* Zurücksetzen: wieder die Liste der Obergruppe */
  const z = await d.schnellknoepfeZuruecksetzen('segelboot-katamaran');
  assert.equal(z.geaendert, true);
  assert.deepEqual(namen((await d.schnellknoepfeFuerFahrzeugart('segelboot-katamaran')).knoepfe), ['Segel setzen', 'Anker werfen']);
  assert.equal((await d.schnellknoepfeZuruecksetzen('segelboot-katamaran')).geaendert, false);
});

test('Prüfung beim Speichern: doppelt, unbekannt, nicht für die Fahrzeugart; nichts wird halb gespeichert', async () => {
  const d = await start();
  const abf = (await eart(d, 'Abfahrt')).objekt.id, segel = (await eart(d, 'Segel setzen')).objekt.id;
  const r = await d.schnellknoepfeSetzen('wohnmobil', ['e:' + abf, 'e:' + abf, 'e:gibt-es-nicht', 'e:' + segel]);
  assert.equal(r.ok, false);
  assert.match(r.fehler.s2, /liegt schon auf Knopf 1/);
  assert.ok(r.fehler.s3); assert.ok(r.fehler.s4, 'Segel setzen gibt es für das Wohnmobil nicht');
  assert.equal((await d.schnellknoepfeFuerFahrzeugart('wohnmobil')).standard, true, 'es blieb beim Standard');
  assert.equal((await d.schnellknoepfeSetzen('gibt-es-nicht', [])).ok, false);
});

test('Mehr als 8 Knöpfe gibt es nicht, alles abwählen ist erlaubt (dann nur Sonstige)', async () => {
  const d = await start();
  const r = await d.schnellknoepfeSetzen('auto', ['f:notiz', 'f:foto', 'f:wechsel']);
  assert.equal(r.anzahl, 3);
  const ids = (await d.schnellknoepfeFuerFahrzeugart('auto')).angebot.ereignisse.map(x => x.key);
  const viele = ['f:notiz', 'f:foto', 'f:wechsel'].concat(ids).slice(0, 12);
  const r2 = await d.schnellknoepfeSetzen('auto', viele);
  assert.ok(r2.ok);
  assert.ok((await d.schnellknoepfeFuerFahrzeugart('auto')).knoepfe.length <= 8);
  const r3 = await d.schnellknoepfeSetzen('auto', []);
  assert.ok(r3.ok);
  const i = await d.schnellknoepfeFuerFahrzeugart('auto');
  assert.equal(i.knoepfe.length, 0);
  assert.equal(i.standard, false, 'eine leere Liste ist eine eigene Einstellung, kein Standard');
  assert.equal(i.sonstige.funktionen.length, 3);
});

test('Ausgeblendete Ereignisarten verschwinden vom Knopf und aus dem Angebot, die Einstellung bleibt gespeichert', async () => {
  const d = await start();
  const abf = await eart(d, 'Abfahrt'), ank = await eart(d, 'Ankunft');
  await d.schnellknoepfeSetzen('auto', ['e:' + abf.objekt.id, 'e:' + ank.objekt.id]);
  await d.ereignisartAendern(abf.objekt.id, { bezeichnung: 'Abfahrt', ausgeblendet: 'ja' });
  assert.deepEqual(namen((await d.schnellknoepfeFuerFahrzeugart('auto')).knoepfe), ['Ankunft']);
  await d.ereignisartAendern(abf.objekt.id, { bezeichnung: 'Abfahrt', ausgeblendet: 'nein' });
  assert.deepEqual(namen((await d.schnellknoepfeFuerFahrzeugart('auto')).knoepfe), ['Abfahrt', 'Ankunft']);
});

test('Ein Tipp auf einen Schnellknopf speichert das Ereignis mit der Uhrzeit von jetzt (auch eigene Ereignisse)', async () => {
  const d = await start();
  const boot = (await d.fahrzeugAnlegen('segelboot-katamaran', { bezeichnung: 'Kat' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  await d.aktivitaetsartenAusVorschlaegen();
  const r = await d.logbuchSofortStarten({ fahrzeugId: boot, verantwortlichId: anna });
  assert.ok(r.ok);
  const segel = (await eart(d, 'Segel setzen')).objekt.id;
  const s = await d.ereignisSchnell(r.id, 'Segel setzen', { artId: segel });
  assert.ok(s.ok, JSON.stringify(s));
  const lb = await d.logbuchLaden(r.id);
  const ereignisse = lb.abschnitte.flatMap(a => a.ereignisse);
  assert.ok(ereignisse.some(e => e.artName === 'Segel setzen'));
});

test('Die Belegung ist in der Sicherung enthalten und kommt beim Einspielen zurück', async () => {
  const d = await start();
  await d.schnellknoepfeSetzen('auto', ['f:foto']);
  const s = await d.sicherungErzeugen({ schluessel: '' });
  const b = neueDaten();
  await b.starten();
  assert.equal((await b.schnellknoepfeFuerFahrzeugart('auto')).standard, true);
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  assert.deepEqual((await b.schnellknoepfeFuerFahrzeugart('auto')).knoepfe.map(x => x.name), ['Foto']);
});
