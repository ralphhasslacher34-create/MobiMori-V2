'use strict';
/* 2.0.26: Schritt 7c (Dokumente und Bilder am Vorgang, Reparaturbuch) und Schritt 7d (Störung im Logbuch = Störung in der Werkstatt). */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/reiseorte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const W = MM.Werkstatt;

/* feste Uhr: 3. November 2026, 12:00 Ortszeit, von Hand stellbar */
function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 3, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (jahr, monat, tag, std, min) => { uhr.ms = new Date(jahr, monat - 1, tag, std, min, 0).getTime(); };
  return d;
}
const datei = (inhalt, name, typ) => { const b = new Blob([inhalt], { type: typ || 'image/jpeg' }); Object.defineProperty(b, 'name', { value: name || 'foto.jpg' }); return b; };

async function neu() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const motor = (await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  return { d, boot, wm, motor, anna, toern };
}
async function mitAktivitaet() {
  const c = await neu();
  const r = await c.d.aktivitaetAnlegen({ bezeichnung: 'Sommertörn', artId: c.toern, fahrzeugId: c.boot, vonDatum: '2026-11-03', vonZeit: '09:00', bisDatum: '2026-11-05', bisZeit: '17:30', verantwortlichId: c.anna });
  assert.ok(r.ok);
  c.id = r.id;
  return c;
}
const eventsVon = async (c) => (await c.d.logbuchLaden(c.id)).abschnitte.flatMap(t => t.ereignisse);
const artId = async (d, name) => { await d.ereignisartenAusVorschlaegen(); return (await d.ereignisartenListe()).find(x => x.aktuell.werte.bezeichnung === name).objekt.id; };

/* ================= 7c: Dokumente und Bilder am Vorgang ================= */
test('Reparaturbuch ist eine Art von Dokument, die Reihenfolge bleibt sinnvoll', () => {
  const werte = MM.Dokumente.ARTEN.map(a => a.wert);
  assert.ok(werte.includes('reparaturbuch'));
  assert.equal(MM.Dokumente.artLabel('reparaturbuch'), 'Reparaturbuch');
  assert.ok(MM.Dokumente.artIndex('reparaturbuch') > MM.Dokumente.artIndex('wartung'));
  assert.ok(werte.includes('foto') && werte.includes('beleg'), 'Bilder und Belege gibt es schon');
});

test('Dokument am Vorgang: Foto und Beleg hängen am Vorgang, nicht am Fahrzeug oder an der Komponente allein', async () => {
  const { d, boot, motor } = await neu();
  const v = (await d.vorgangAnlegen(boot, motor, 'stoerung', { bezeichnung: 'Motor springt schlecht an', auswirkung: 'bedingt' })).id;
  const r1 = await d.dokumentAnlegen(boot, null, { quelle: 'datei', datei: datei('BILD', 'schaden.jpg'), art: 'foto', bezeichnung: 'Schaden' }, v);
  assert.ok(r1.ok);
  const r2 = await d.dokumentAnlegen(boot, null, { quelle: 'link', link: 'https://www.beispiel.de/rechnung.pdf', art: 'beleg', bezeichnung: 'Rechnung Werkstatt' }, v);
  assert.ok(r2.ok);
  const frei = await d.dokumentAnlegen(boot, motor, { quelle: 'link', link: 'https://www.beispiel.de/anleitung.pdf', art: 'bedienung', bezeichnung: 'Anleitung Motor' });
  assert.ok(frei.ok);

  const amVorgang = await d.dokumenteFuerVorgang(v);
  assert.deepEqual(amVorgang.map(x => x.aktuell.werte.bezeichnung).sort(), ['Rechnung Werkstatt', 'Schaden']);
  assert.ok(amVorgang.every(x => x.vorgangId === v && x.vorgangName === 'Motor springt schlecht an'));
  assert.ok(amVorgang.every(x => x.komponenteId === motor), 'die Komponente des Vorgangs gilt auch für das Dokument');
  assert.equal((await d.speicher.holen('dokumente', r1.id)).vorgangId, v);
  assert.equal((await d.speicher.holen('dokumente', frei.id)).vorgangId, null, 'ohne Vorgang bleibt alles wie vorher');

  const alle = await d.dokumenteListe(boot);
  assert.equal(alle.length, 3, 'die Gesamtliste zeigt alle');
  assert.equal(alle.filter(x => x.vorgangId).length, 2);
  assert.equal(alle.find(x => !x.vorgangId).vorgangName, null);
  assert.deepEqual(await d.dokumenteFuerVorgang('gibt-es-nicht'), []);
});

test('Dokument am Vorgang: die Datei liegt auf dem Gerät, dokumentLaden nennt den Vorgang', async () => {
  const { d, boot } = await neu();
  const v = (await d.vorgangAnlegen(boot, null, 'arbeit', { bezeichnung: 'Ölwechsel', ausfuehrung: 'selbst' })).id;
  const r = await d.dokumentAnlegen(boot, null, { quelle: 'datei', datei: datei('BILD-INHALT', 'oel.jpg'), art: 'foto', bezeichnung: '' }, v);
  assert.ok(r.ok);
  const x = await d.dokumentLaden(r.id);
  assert.equal(x.vorgang.id, v);
  assert.equal(x.vorgangAktuell.werte.bezeichnung, 'Ölwechsel');
  assert.equal(x.aktuell.werte.bezeichnung, 'oel', 'ohne Bezeichnung gilt der Dateiname');
  assert.equal(x.datei.name, 'oel.jpg');
  assert.ok((await d.dateiHolen(r.id)).inhalt);
  const frei = await d.dokumentAnlegen(boot, null, { quelle: 'link', link: 'https://www.beispiel.de/a', art: 'sonstiges', bezeichnung: 'X' });
  assert.equal((await d.dokumentLaden(frei.id)).vorgang, null);
});

test('Dokument am Vorgang: ein fremder oder unbekannter Vorgang wird abgelehnt, nichts wird gespeichert', async () => {
  const { d, boot, wm } = await neu();
  const v = (await d.vorgangAnlegen(boot, null, 'stoerung', { bezeichnung: 'Bilgenpumpe tropft', auswirkung: 'keine' })).id;
  const fremd = await d.dokumentAnlegen(wm, null, { quelle: 'link', link: 'https://www.beispiel.de/a', art: 'sonstiges', bezeichnung: 'X' }, v);
  assert.equal(fremd.ok, false); assert.match(fremd.fehler.allgemein, /Vorgang/);
  const unbekannt = await d.dokumentAnlegen(boot, null, { quelle: 'link', link: 'https://www.beispiel.de/a', art: 'sonstiges', bezeichnung: 'X' }, 'vg-gibt-es-nicht');
  assert.equal(unbekannt.ok, false);
  const leer = await d.dokumentAnlegen(boot, null, { quelle: 'datei', art: 'foto', bezeichnung: 'X' }, v);
  assert.equal(leer.ok, false); assert.ok(leer.fehler.datei, 'die Prüfungen der Dokumente gelten auch hier');
  assert.equal((await d.dokumenteListe(boot)).length, 0);
});

test('Dokument am Vorgang: auch bei einem erledigten Vorgang, und beim Wiederöffnen bleibt es', async () => {
  const { d, boot } = await neu();
  const v = (await d.vorgangAnlegen(boot, null, 'arbeit', { bezeichnung: 'Zündkerzen', ausfuehrung: 'werkstatt' })).id;
  assert.ok((await d.vorgangErledigen(v, { datum: '2026-11-03', notiz: 'fertig' })).ok);
  assert.ok((await d.dokumentAnlegen(boot, null, { quelle: 'link', link: 'https://www.beispiel.de/rechnung', art: 'beleg', bezeichnung: 'Rechnung' }, v)).ok, 'der Beleg kommt oft erst nach dem Erledigen');
  assert.ok((await d.vorgangWiederOeffnen(v)).ok);
  assert.equal((await d.dokumenteFuerVorgang(v)).length, 1);
});

test('Dokument am Vorgang: Angaben ändern geht wie bei jedem Dokument, die Zuordnung bleibt', async () => {
  const { d, boot } = await neu();
  const v = (await d.vorgangAnlegen(boot, null, 'stoerung', { bezeichnung: 'Lärm', auswirkung: 'keine' })).id;
  const r = await d.dokumentAnlegen(boot, null, { quelle: 'link', link: 'https://www.beispiel.de/a', art: 'foto', bezeichnung: 'Erste' }, v);
  assert.ok((await d.dokumentAendern(r.id, { quelle: 'link', link: 'https://www.beispiel.de/a', art: 'reparaturbuch', bezeichnung: 'Seite 12' })).geaendert);
  const x = await d.dokumentLaden(r.id);
  assert.equal(x.aktuell.werte.art, 'reparaturbuch');
  assert.equal(x.vorgang.id, v);
  assert.equal(x.verlauf.length, 2, 'der frühere Stand bleibt im Verlauf');
});

test('Sicherung: Dokumente am Vorgang und der Verweis kommen mit und sind nach dem Einspielen wieder da', async () => {
  const a = await neu();
  const v = (await a.d.vorgangAnlegen(a.boot, null, 'stoerung', { bezeichnung: 'Lärm', auswirkung: 'keine' })).id;
  const r = await a.d.dokumentAnlegen(a.boot, null, { quelle: 'datei', datei: datei('BILD', 'a.jpg'), art: 'foto', bezeichnung: 'Bild' }, v);
  const s = await a.d.sicherungErzeugen({ mitDateien: true });
  const b = neueDaten();
  await b.starten();
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  const x = await b.dokumentLaden(r.id);
  assert.equal(x.vorgang.id, v);
  assert.ok((await b.dateiHolen(r.id)).inhalt);
  assert.equal((await b.dokumenteFuerVorgang(v)).length, 1);
});

/* ================= 7d: Störung im Logbuch = Störung in der Werkstatt ================= */
test('Name der Störungs-Art: Groß- und Kleinschreibung und Leerzeichen sind egal', () => {
  assert.equal(MM.Logbuch.STOERUNG_ART, 'Störung');
  assert.ok(MM.Logbuch.istStoerungArt('Störung') && MM.Logbuch.istStoerungArt(' störung '));
  assert.equal(MM.Logbuch.istStoerungArt('Notiz'), false);
  assert.equal(MM.Logbuch.istStoerungArt(null), false);
});

test('Angaben des Vorgangs aus dem Ereignis: kurzer Text wird die Bezeichnung, langer Text die Beschreibung, ohne Text gibt es einen Ersatz', () => {
  assert.deepEqual(W.ausEreignis('Motor ruckelt', '2026-11-03', '14:30', '2026-11-03'), { bezeichnung: 'Motor ruckelt', beschreibung: '', gemeldetAm: '2026-11-03' });
  const lang = 'Der Motor ruckelt seit der Schleuse und geht bei niedriger Drehzahl immer wieder aus, auch der Drehzahlmesser spinnt manchmal';
  const a = W.ausEreignis(lang, '2026-11-03', '14:30', '2026-11-03');
  assert.ok(a.bezeichnung.length <= 80 && a.bezeichnung.endsWith('…'));
  assert.equal(a.beschreibung, lang);
  const leer = W.ausEreignis('  ', '2026-11-03', '14:30', '2026-11-03');
  assert.equal(leer.bezeichnung, 'Störung unterwegs (03.11.2026, 14:30 Uhr)');
  assert.equal(W.ausEreignis('x', '2026-12-01', '10:00', '2026-11-03').gemeldetAm, '2026-11-03', 'nie ein Datum in der Zukunft');
});

test('Störung im Logbuch: ohne Angabe gilt „bleibt nutzbar“, eine unbekannte Einschränkung wird abgelehnt', async () => {
  const c = await mitAktivitaet();
  const art = await artId(c.d, 'Störung');
  const bad = await c.d.ereignisSchnell(c.id, 'Störung', { artId: art, text: 'x', auswirkung: 'egal' });
  assert.equal(bad.ok, false); assert.match(bad.fehler.auswirkung, /Bitte wählen, wie weit/);
  assert.equal((await eventsVon(c)).length, 0); assert.equal((await c.d.vorgaengeListe(c.boot)).length, 0);
  const r = await c.d.ereignisSchnell(c.id, 'Störung', { artId: art, text: 'Motor ruckelt' });
  assert.ok(r.ok);
  assert.equal((await c.d.vorgangLaden(r.vorgangId)).aktuell.werte.auswirkung, 'keine');
});

test('Störung im Logbuch: ein Tipp legt das Ereignis und den Vorgang an, eine Störung für beide', async () => {
  const c = await mitAktivitaet();
  const r = await c.d.ereignisSchnell(c.id, 'Störung', { text: 'Motor ruckelt', auswirkung: 'nicht', position: { breite: 48.5, laenge: 9.1, genauigkeit: 10 } });
  assert.ok(r.ok); assert.ok(r.vorgangId);

  const ev = await eventsVon(c);
  assert.equal(ev.length, 1); assert.equal(ev[0].artName, 'Störung');
  const ereignis = await c.d.speicher.holen('ereignisse', r.id);
  assert.equal(ereignis.vorgangId, r.vorgangId, 'das Logbuch verweist auf den Vorgang');
  const l = await c.d.ereignisLaden(r.id);
  assert.equal(l.aktuell.werte.breite, 48.5, 'das Logbuch behält Zeit und Position');
  assert.equal(l.aktuell.werte.auswirkung, undefined, 'die Einschränkung gehört dem Vorgang, nicht dem Ereignis');

  const v = await c.d.vorgangLaden(r.vorgangId);
  assert.equal(v.vorgang.fahrzeugId, c.boot);
  assert.equal(v.vorgang.komponenteId, null, 'im Cockpit hängt die Störung am Fahrzeug');
  assert.equal(v.vorgang.ereignisId, r.id, 'und der Vorgang weiß, woher er kommt');
  const w = v.aktuell.werte;
  assert.equal(w.art, 'stoerung'); assert.equal(w.status, 'offen'); assert.equal(w.auswirkung, 'nicht');
  assert.equal(w.bezeichnung, 'Motor ruckelt'); assert.equal(w.gemeldetAm, '2026-11-03');
  assert.equal((await c.d.vorgaengeListe(c.boot)).length, 1, 'es gibt nur eine Störung');
});

test('Störung im Logbuch: die Warnung der Werkstatt greift auch unterwegs, „bleibt nutzbar“ bremst nicht', async () => {
  const c = await mitAktivitaet();
  const r = await c.d.ereignisSchnell(c.id, 'Störung', { text: 'Pumpe tropft', auswirkung: 'keine' });
  assert.ok(r.ok);
  assert.equal((await c.d.vorgangWarnung(c.boot)).stufe, 'ok');
  const r2 = await c.d.ereignisSchnell(c.id, 'Störung', { text: 'Motor aus', auswirkung: 'nicht' });
  assert.ok(r2.ok);
  const warn = await c.d.vorgangWarnung(c.boot);
  assert.equal(warn.stufe, 'nicht');
  assert.equal(warn.vorgaenge.length, 1);
  assert.ok(warn.aktivitaeten.some(x => x.aktivitaet.objekt.id === c.id), 'die laufende Aktivität steht in der Warnung');
  assert.ok((await c.d.vorgangEntscheiden(r2.vorgangId, c.id, 'trotzdem')).ok, 'trotzdem nutzen geht wie bei jedem Vorgang');
});

test('Störung im Logbuch: ohne Text steht ein Ersatztext da, ein langer Text wird zur Beschreibung', async () => {
  const c = await mitAktivitaet();
  const a = await c.d.ereignisSchnell(c.id, 'Störung', { auswirkung: 'bedingt' });
  assert.match((await c.d.vorgangLaden(a.vorgangId)).aktuell.werte.bezeichnung, /^Störung unterwegs \(03\.11\.2026, \d\d:\d\d Uhr\)$/);
  const lang = 'Der Motor ruckelt seit der Schleuse und geht bei niedriger Drehzahl immer wieder aus, auch der Drehzahlmesser spinnt';
  const b = await c.d.ereignisSchnell(c.id, 'Störung', { text: lang, auswirkung: 'bedingt' });
  const w = (await c.d.vorgangLaden(b.vorgangId)).aktuell.werte;
  assert.ok(w.bezeichnung.length <= 80); assert.equal(w.beschreibung, lang);
});

test('Störung nachtragen: der Vorgang bekommt das Datum des Ereignisses, nicht das von heute', async () => {
  const c = await mitAktivitaet();
  const t = await c.d.heutigerTag(c.id);
  c.d.stelle(2026, 11, 4, 9, 0);
  const art = await artId(c.d, 'Störung');
  const r = await c.d.ereignisAnlegen(t.abschnittId, { artId: art, datum: '2026-11-03', zeit: '10:15', text: 'gestern Abend ausgefallen', auswirkung: 'bedingt' }, { nachtragen: true });
  assert.ok(r.ok); assert.ok(r.vorgangId);
  assert.equal((await c.d.vorgangLaden(r.vorgangId)).aktuell.werte.gemeldetAm, '2026-11-03');
  const ohne = await c.d.ereignisAnlegen(t.abschnittId, { artId: art, datum: '2026-11-03', zeit: '10:20', text: 'x' }, { nachtragen: true });
  assert.ok(ohne.ok); assert.equal((await c.d.vorgangLaden(ohne.vorgangId)).aktuell.werte.auswirkung, 'keine');
});

test('Andere Ereignisarten legen keinen Vorgang an, eine mitgegebene Einschränkung wird ignoriert', async () => {
  const c = await mitAktivitaet();
  const r = await c.d.ereignisSchnell(c.id, 'Notiz', { text: 'Wetter gut', auswirkung: 'nicht' });
  assert.ok(r.ok); assert.equal(r.vorgangId, null);
  assert.equal((await c.d.speicher.holen('ereignisse', r.id)).vorgangId, undefined);
  assert.equal((await c.d.vorgaengeListe(c.boot)).length, 0);
});

test('Eine ausgeblendete Störungs-Art meldet nichts, eine andere Art namens „Defekt“ legt keinen Vorgang an', async () => {
  const c = await mitAktivitaet();
  const art = await artId(c.d, 'Störung');
  await c.d.ereignisartAendern(art, { bezeichnung: 'Störung', ausgeblendet: 'ja' });
  const r = await c.d.ereignisSchnell(c.id, 'Störung', { auswirkung: 'nicht' });
  assert.equal(r.ok, false); assert.match(r.fehler.allgemein, /ausgeblendet/);
  const defekt = (await c.d.ereignisartAnlegen({ bezeichnung: 'Defekt' })).id;
  const d = await c.d.ereignisSchnell(c.id, 'Defekt', { artId: defekt });
  assert.ok(d.ok); assert.equal(d.vorgangId, null);
  assert.equal((await c.d.vorgaengeListe(c.boot)).length, 0);
});

test('Ereignis ändern: Text einer Störung ändern geht, eine andere Art nachträglich auf „Störung“ stellen nicht', async () => {
  const c = await mitAktivitaet();
  const st = await c.d.ereignisSchnell(c.id, 'Störung', { text: 'Motor ruckelt', auswirkung: 'bedingt' });
  const notiz = await c.d.ereignisSchnell(c.id, 'Notiz', { text: 'Ölstand geprüft' });
  const art = await artId(c.d, 'Störung');
  const notizArt = await artId(c.d, 'Notiz');

  const bleibt = await c.d.ereignisAendern(st.id, { artId: art, datum: '2026-11-03', zeit: '12:00', text: 'Motor ruckelt stark' });
  assert.ok(bleibt.ok);
  assert.equal((await c.d.speicher.holen('ereignisse', st.id)).vorgangId, st.vorgangId, 'der Verweis bleibt');

  const nein = await c.d.ereignisAendern(notiz.id, { artId: art, datum: '2026-11-03', zeit: '12:00', text: 'Ölstand geprüft' });
  assert.equal(nein.ok, false); assert.match(nein.fehler.artId, /Ereignis eintragen/);
  assert.equal((await c.d.vorgaengeListe(c.boot)).length, 1, 'es entsteht kein zweiter Vorgang');

  const ok = await c.d.ereignisAendern(notiz.id, { artId: notizArt, datum: '2026-11-03', zeit: '12:00', text: 'Ölstand erneut geprüft' });
  assert.ok(ok.ok, 'andere Änderungen gehen weiter');
});

test('Störung im Logbuch: Sicherung enthält Ereignis, Vorgang und beide Verweise', async () => {
  const a = await mitAktivitaet();
  const r = await a.d.ereignisSchnell(a.id, 'Störung', { text: 'Lärm', auswirkung: 'nicht' });
  const s = await a.d.sicherungErzeugen({ mitDateien: false });
  const b = neueDaten();
  await b.starten();
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  assert.equal((await b.speicher.holen('ereignisse', r.id)).vorgangId, r.vorgangId);
  const v = await b.vorgangLaden(r.vorgangId);
  assert.equal(v.vorgang.ereignisId, r.id);
  assert.equal(v.aktuell.werte.auswirkung, 'nicht');
});
