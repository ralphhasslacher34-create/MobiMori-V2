'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/reiseorte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const L = MM.Logbuch;

const JETZT = new Date(2026, 10, 4, 12, 0, 0).toISOString();
function neueDaten() {
  let t = 0;
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
}

async function kontext() {
  const d = neueDaten();
  await d.starten();
  const wohnmobil = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const skiboot = (await d.fahrzeugAnlegen('wasserskiboot', { bezeichnung: 'Skiboot' })).id;
  const kat = (await d.fahrzeugAnlegen('segelboot-katamaran', { bezeichnung: 'Kat' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  return { d, wohnmobil, skiboot, kat, anna };
}
async function art(d, name) {
  return (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === name);
}
const gilt = (x, fzArt) => L.ereignisartGilt(x.aktuell.werte.zuordnung, fzArt);

test('Die Vorschläge für Aktivitätsarten werden mit Zuordnung angelegt', async () => {
  const { d } = await kontext();
  await d.aktivitaetsartenAusVorschlaegen();
  const ski = await art(d, 'Wasserski'), toern = await art(d, 'Törn'), segeln = await art(d, 'Segeln');
  const urlaub = await art(d, 'Urlaub'), ausfahrt = await art(d, 'Ausfahrt'), rallye = await art(d, 'Rallye');
  assert.equal(gilt(ski, 'wasserskiboot'), true);
  assert.equal(gilt(ski, 'wohnmobil'), false, 'mit dem Wohnmobil gibt es kein Wasserski');
  assert.equal(gilt(ski, 'sportboot'), false);
  assert.equal(gilt(toern, 'segelboot-katamaran'), true);
  assert.equal(gilt(toern, 'wohnmobil'), false);
  assert.equal(gilt(segeln, 'segelboot-jolle'), true);
  assert.equal(gilt(segeln, 'wasserskiboot'), false);
  assert.equal(gilt(rallye, 'oldtimer'), true);
  assert.equal(gilt(rallye, 'boot'), false);
  ['wohnmobil', 'boot', 'flugzeug', 'segelboot-katamaran'].forEach(a => { assert.equal(gilt(urlaub, a), true, a); assert.equal(gilt(ausfahrt, a), true, a); });
});

test('Ohne Zuordnung gilt eine ältere Aktivitätsart für alle Fahrzeugarten, nichts verschwindet', async () => {
  const { d } = await kontext();
  await d.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: 'Wasserski', ausgeblendet: 'nein' });
  const ski = await art(d, 'Wasserski');
  assert.equal(ski.aktuell.werte.zuordnung, undefined);
  F_ALLE.forEach(a => assert.equal(gilt(ski, a), true, a));
  assert.equal(L.zuordnungText(ski.aktuell.werte.zuordnung), 'Alle Fahrzeuge');
});
const F_ALLE = ['wohnmobil', 'auto', 'boot', 'wasserskiboot', 'segelboot-katamaran', 'flugzeug'];

test('„Vorschläge für Fahrzeugarten übernehmen“ setzt nur dort etwas, wo noch keine Zuordnung steht', async () => {
  const { d } = await kontext();
  await d.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: 'Wasserski', ausgeblendet: 'nein' });
  await d.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: 'Segeln', ausgeblendet: 'nein' });
  await d.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: 'Angeln', ausgeblendet: 'nein' });
  /* Segeln hat der Nutzer selbst eingestellt: gilt für alle Boote */
  const segeln0 = await art(d, 'Segeln');
  await d.aktivitaetsartAendern(segeln0.objekt.id, { bezeichnung: 'Segeln', ausgeblendet: 'nein', zuordnung: L.zuordnungFuerKnoten(['wasser']) });
  const r = await d.aktivitaetsartenVorauswahlUebernehmen();
  assert.deepEqual(r.namen, ['Wasserski']);
  assert.equal(r.anzahl, 1);
  assert.equal(gilt(await art(d, 'Wasserski'), 'wohnmobil'), false);
  assert.equal(gilt(await art(d, 'Wasserski'), 'wasserskiboot'), true);
  assert.equal(gilt(await art(d, 'Segeln'), 'wasserskiboot'), true, 'die eigene Einstellung bleibt');
  assert.equal((await art(d, 'Angeln')).aktuell.werte.zuordnung, undefined, 'eine Art ohne Vorschlag bleibt unberührt');
  const r2 = await d.aktivitaetsartenVorauswahlUebernehmen();
  assert.equal(r2.anzahl, 0, 'ein zweites Mal ändert sich nichts');
});

test('Aktivitätsarten für ein Fahrzeug: nur passende, ohne ausgeblendete, eine schon benutzte bleibt wählbar', async () => {
  const { d } = await kontext();
  await d.aktivitaetsartenAusVorschlaegen();
  const namen = l => l.map(x => x.aktuell.werte.bezeichnung).sort();
  assert.deepEqual(namen(await d.aktivitaetsartenFuerFahrzeugart('wohnmobil')), ['Ausfahrt', 'Rallye', 'Urlaub']);
  assert.deepEqual(namen(await d.aktivitaetsartenFuerFahrzeugart('wasserskiboot')), ['Ausfahrt', 'Törn', 'Urlaub', 'Wasserski']);
  assert.deepEqual(namen(await d.aktivitaetsartenFuerFahrzeugart('segelboot-katamaran')), ['Ausfahrt', 'Segeln', 'Törn', 'Urlaub']);
  assert.equal((await d.aktivitaetsartenFuerFahrzeugart(null)).length, 6, 'ohne Fahrzeug alle');
  const ski = await art(d, 'Wasserski');
  const urlaub = await art(d, 'Urlaub');
  await d.aktivitaetsartAendern(urlaub.objekt.id, { bezeichnung: 'Urlaub', ausgeblendet: 'ja' });
  assert.ok(!namen(await d.aktivitaetsartenFuerFahrzeugart('wohnmobil')).includes('Urlaub'));
  assert.ok(namen(await d.aktivitaetsartenFuerFahrzeugart('wohnmobil', [ski.objekt.id, urlaub.objekt.id])).includes('Wasserski'), 'schon benutzte Art bleibt wählbar');
});

test('Eigene Aktivitätsart: Zuordnung beim Anlegen, beim Ändern bleibt sie, wenn nichts angegeben wird', async () => {
  const { d } = await kontext();
  const r = await d.aktivitaetsartAnlegen({ bezeichnung: 'Oldtimer-Treffen', zuordnung: L.zuordnungFuerKnoten(['oldtimer']) });
  assert.ok(r.ok);
  let x = await d.aktivitaetsartLaden(r.id);
  assert.equal(gilt(x, 'oldtimer'), true);
  assert.equal(gilt(x, 'wohnmobil'), false);
  assert.equal(L.zuordnungText(x.aktuell.werte.zuordnung), 'Oldtimer');
  await d.aktivitaetsartAendern(r.id, { bezeichnung: 'Oldtimer-Treffen', ausgeblendet: 'ja' });
  x = await d.aktivitaetsartLaden(r.id);
  assert.equal(x.aktuell.werte.ausgeblendet, 'ja');
  assert.equal(gilt(x, 'oldtimer'), true, 'die Zuordnung ist geblieben');
  await d.aktivitaetsartAendern(r.id, { bezeichnung: 'Oldtimer-Treffen', ausgeblendet: 'nein', zuordnung: L.zuordnungFuerKnoten(['land']) });
  x = await d.aktivitaetsartLaden(r.id);
  assert.equal(gilt(x, 'wohnmobil'), true);
  assert.ok(x.aktuell.nr >= 3, 'der Verlauf bleibt erhalten: jede Änderung ist ein eigener Eintrag');
  const ohne = await d.aktivitaetsartAnlegen({ bezeichnung: 'Ausflug' });
  assert.equal(L.zuordnungText((await d.aktivitaetsartLaden(ohne.id)).aktuell.werte.zuordnung), 'Alle Fahrzeuge', 'ohne Angabe gilt sie für alle');
});

test('Logbuch jetzt starten: die Art wird gewählt, der Name folgt der Art', async () => {
  const { d, skiboot, kat, anna } = await kontext();
  await d.aktivitaetsartenAusVorschlaegen();
  const ski = await art(d, 'Wasserski'), toern = await art(d, 'Törn');
  const r1 = await d.logbuchSofortStarten({ fahrzeugId: skiboot, verantwortlichId: anna, artId: ski.objekt.id });
  assert.ok(r1.ok, JSON.stringify(r1));
  const a1 = await d.aktivitaetLaden(r1.id);
  assert.equal(a1.aktuell.werte.artId, ski.objekt.id);
  assert.match(a1.aktuell.werte.bezeichnung, /^Wasserski Skiboot 04\.11\.2026$/);
  const r2 = await d.logbuchSofortStarten({ fahrzeugId: kat, verantwortlichId: anna, artId: toern.objekt.id });
  assert.ok(r2.ok);
  assert.match((await d.aktivitaetLaden(r2.id)).aktuell.werte.bezeichnung, /^Törn Kat 04\.11\.2026$/);
});

test('Logbuch jetzt starten: mit dem Wohnmobil gibt es kein Wasserski, es wird nichts angelegt', async () => {
  const { d, wohnmobil, anna } = await kontext();
  await d.aktivitaetsartenAusVorschlaegen();
  const ski = await art(d, 'Wasserski');
  const r = await d.logbuchSofortStarten({ fahrzeugId: wohnmobil, verantwortlichId: anna, artId: ski.objekt.id });
  assert.equal(r.ok, false);
  assert.match(r.fehler.artId, /gilt nicht für dieses Fahrzeug/);
  assert.equal((await d.aktivitaetenListe()).length, 0);
  const ok = await d.logbuchSofortStarten({ fahrzeugId: wohnmobil, verantwortlichId: anna, artId: (await art(d, 'Urlaub')).objekt.id });
  assert.ok(ok.ok);
});

test('Logbuch jetzt starten: ohne Angabe gilt weiter „Ausfahrt“, sofern sie zum Fahrzeug passt', async () => {
  const { d, wohnmobil, anna } = await kontext();
  await d.aktivitaetsartenAusVorschlaegen();
  const r = await d.logbuchSofortStarten({ fahrzeugId: wohnmobil, verantwortlichId: anna });
  assert.ok(r.ok);
  assert.match((await d.aktivitaetLaden(r.id)).aktuell.werte.bezeichnung, /^Ausfahrt Wohnmobil /);
  /* Ausfahrt für das Wohnmobil abwählen: ohne Angabe geht es nicht mehr, mit einer passenden Art schon */
  const aus = await art(d, 'Ausfahrt');
  await d.aktivitaetsartAendern(aus.objekt.id, { bezeichnung: 'Ausfahrt', ausgeblendet: 'nein', zuordnung: L.zuordnungFuerKnoten(['wasser']) });
  const r2 = await d.logbuchSofortStarten({ fahrzeugId: wohnmobil, verantwortlichId: anna });
  assert.equal(r2.ok, false);
  assert.ok(r2.fehler.artId);
  const r3 = await d.logbuchSofortStarten({ fahrzeugId: wohnmobil, verantwortlichId: anna, artId: (await art(d, 'Rallye')).objekt.id });
  assert.ok(r3.ok);
});

test('Logbuch jetzt starten: ausgeblendete oder unbekannte Art wird abgelehnt', async () => {
  const { d, kat, anna } = await kontext();
  await d.aktivitaetsartenAusVorschlaegen();
  const toern = await art(d, 'Törn');
  await d.aktivitaetsartAendern(toern.objekt.id, { bezeichnung: 'Törn', ausgeblendet: 'ja' });
  const r = await d.logbuchSofortStarten({ fahrzeugId: kat, verantwortlichId: anna, artId: toern.objekt.id });
  assert.equal(r.ok, false); assert.match(r.fehler.artId, /ausgeblendet/);
  const r2 = await d.logbuchSofortStarten({ fahrzeugId: kat, verantwortlichId: anna, artId: 'gibt-es-nicht' });
  assert.equal(r2.ok, false); assert.ok(r2.fehler.artId);
  assert.equal((await d.aktivitaetenListe()).length, 0);
});
