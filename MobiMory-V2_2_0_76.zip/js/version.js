/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.76';
  MM.STUFE = 'Störung: Info-Mail an den Besitzer, Hilfe zur Behebung, Reparaturgedächtnis';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
