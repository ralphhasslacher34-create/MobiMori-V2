/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.44';
  MM.STUFE = 'Cockpit: Wetter-Hinweis verschwindet, Geschwindigkeit im Wechselfeld, Tag der Reise im Kalender wählen';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
