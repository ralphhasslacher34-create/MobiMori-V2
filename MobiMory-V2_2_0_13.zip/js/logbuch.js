/*
 * Logbuch-Kern: Regeln und Rechnung (Tagesabschnitte, Ereignisse, Prüfung zum Tagesbeginn).
 *
 * Aus den V2-Festlegungen und der Übergabe für 2.0.13:
 *  - Tagesabschnitte sind ein Zusatzbaustein an der Aktivität, kein eigener Bereich.
 *  - Die App bereitet die Tage aus dem Zeitraum der Aktivität vor. Jeder Abschnitt ist von Hand
 *    änderbar, ergänzbar und ausblendbar.
 *  - Die Prüfung zum Tagesbeginn ist die vorhandene Rechnung der Aktivität (aktivitaetPruefung).
 *    Sie wird hier nur je Tag festgehalten, mit „geprüft am“ und dem Verantwortlichen dieses Tages.
 *  - Ereignisarten sind eine offene Liste mit Vorschlägen.
 *  - Ein Wechsel des Verantwortlichen erscheint automatisch als Ereignis. Er bleibt die eine Quelle
 *    in der Tabelle „verantwortung“; eine Korrektur der Uhrzeit bleibt im Verlauf.
 *  - Nachtragen: ein Ereignis mit dem echten Zeitpunkt, markiert als „nachgetragen am …“.
 *  - Nichts wird gelöscht. Änderung = neuer Stand im Verlauf, Ausblenden statt Löschen.
 *
 * Hier steht nur Rechnung und Beschreibung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var VORSCHLAEGE_EREIGNISARTEN = ['Abfahrt', 'Ankunft', 'Wechsel des Verantwortlichen', 'Störung', 'Notiz'];
  var WECHSEL_ART = 'Wechsel des Verantwortlichen';
  var MAX_TAGE = 366;
  var WOCHENTAGE = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];

  /* "2026-12-01" -> Zahl der Tage seit 1970 (ohne Zeitzonen-Probleme). */
  function tagNummer(datum) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(datum || '');
    if (!m) return NaN;
    return Math.round(Date.UTC(+m[1], +m[2] - 1, +m[3]) / 86400000);
  }
  function tagText(nr) {
    var d = new Date(nr * 86400000);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getUTCFullYear() + '-' + z(d.getUTCMonth() + 1) + '-' + z(d.getUTCDate());
  }

  /* Alle Tage von bis (einschließlich). zuLang = mehr als MAX_TAGE Tage; dann kommt keine Liste. */
  function tageImZeitraum(vonDatum, bisDatum) {
    var a = tagNummer(vonDatum), b = tagNummer(bisDatum);
    if (isNaN(a) || isNaN(b) || b < a) return { tage: [], zuLang: false };
    if (b - a + 1 > MAX_TAGE) return { tage: [], zuLang: true };
    var res = [];
    for (var i = a; i <= b; i++) res.push(tagText(i));
    return { tage: res, zuLang: false };
  }

  function wochentag(datum) {
    var n = tagNummer(datum);
    return isNaN(n) ? '' : WOCHENTAGE[new Date(n * 86400000).getUTCDay()];
  }

  /*
   * Welche Tagesabschnitte fehlen noch? Gibt für jeden fehlenden Tag die Werte eines neuen
   * Abschnitts zurück. Am ersten Tag steht die Uhrzeit des Beginns, am letzten die des Endes
   * (nur wenn sie bei der Aktivität eingetragen sind). Tage, für die es schon einen Abschnitt
   * gibt (auch einen ausgeblendeten), werden nicht noch einmal vorbereitet.
   */
  function fehlendeTage(aktivitaet, vorhandeneDaten) {
    var z = tageImZeitraum(aktivitaet.vonDatum, aktivitaet.bisDatum);
    if (z.zuLang) return { zuLang: true, neu: [] };
    var da = {};
    (vorhandeneDaten || []).forEach(function (d) { da[d] = true; });
    var neu = [];
    z.tage.forEach(function (d, i) {
      if (da[d]) return;
      neu.push({
        datum: d,
        beginnZeit: i === 0 ? (aktivitaet.vonZeit || null) : null,
        endeZeit: i === z.tage.length - 1 ? (aktivitaet.bisZeit || null) : null,
        von: null, nach: null, notiz: null, ausgeblendet: 'nein'
      });
    });
    return { zuLang: false, neu: neu };
  }

  function zeitSchluessel(datum, zeit) { return (datum || '') + 'T' + (zeit || '00:00'); }

  /* Abschnitte nach Datum, dann nach Beginn. x.aktuell.werte hat datum und beginnZeit. */
  function abschnitteSortieren(liste) {
    return liste.slice().sort(function (a, b) {
      var ka = zeitSchluessel(a.aktuell.werte.datum, a.aktuell.werte.beginnZeit);
      var kb = zeitSchluessel(b.aktuell.werte.datum, b.aktuell.werte.beginnZeit);
      return ka < kb ? -1 : (ka > kb ? 1 : 0);
    });
  }

  /*
   * In welchen Abschnitt gehört ein Zeitpunkt (nur für automatische Ereignisse)?
   * Der Abschnitt mit demselben Datum, sonst der letzte davor, sonst der erste. Ohne Abschnitte: null.
   */
  function abschnittFuer(abschnitte, datum) {
    var sortiert = abschnitteSortieren(abschnitte);
    if (!sortiert.length) return null;
    var gleich = sortiert.filter(function (x) { return x.aktuell.werte.datum === datum; })[0];
    if (gleich) return gleich;
    var davor = sortiert.filter(function (x) { return x.aktuell.werte.datum < datum; });
    return davor.length ? davor[davor.length - 1] : sortiert[0];
  }

  /*
   * Aus den Einträgen der Verantwortung die Wechsel machen. Der erste Eintrag ist der Beginn
   * und kein Wechsel. Jeder weitere ist ein Wechsel mit Zeitpunkt („ab“, "JJJJ-MM-TTTHH:MM").
   * eintraege: [{ id, personId, name, ab, notiz, ausgeblendet, geaendert }] nach Zeit sortiert.
   */
  function wechselEreignisse(eintraege) {
    var liste = eintraege.slice().sort(function (a, b) { return a.ab < b.ab ? -1 : (a.ab > b.ab ? 1 : 0); });
    return liste.slice(1).map(function (v, i) {
      return {
        art: 'wechsel', verantwortungId: v.id, personId: v.personId, name: v.name,
        vorher: liste[i].name, ab: v.ab, datum: v.ab.slice(0, 10), zeit: v.ab.slice(11, 16),
        notiz: v.notiz || null, ausgeblendet: v.ausgeblendet === 'ja', geaendert: !!v.geaendert,
        text: v.name + ' ist ab jetzt verantwortlich' + (liste[i].name ? ' (vorher ' + liste[i].name + ')' : '') + '.'
      };
    });
  }

  /* Zeitpunkt eines Ereignisses zum Sortieren. */
  function ereignisZeit(werte) { return zeitSchluessel(werte.datum, werte.zeit); }

  /* Handeingetragene und automatische Ereignisse in eine Reihenfolge bringen. */
  function ereignisseSortieren(liste) {
    return liste.slice().sort(function (a, b) { return a.zeitpunkt < b.zeitpunkt ? -1 : (a.zeitpunkt > b.zeitpunkt ? 1 : 0); });
  }

  /*
   * Die Prüfung der Aktivität (Ergebnis von aktivitaetPruefung) in eine feste Form bringen,
   * die gespeichert wird. Namen und Texte werden mitgespeichert, weil spätere Änderungen an
   * Personen oder Fahrzeugen den damaligen Stand nicht verändern sollen.
   *  pr            Ergebnis von aktivitaetPruefung
   *  verantwortlich { personId, name } der Verantwortliche zum Tagesbeginn
   *  tagesbeginn   "JJJJ-MM-TTTHH:MM"
   */
  function pruefungFestgehalten(pr, verantwortlich, tagesbeginn) {
    var b = pr.befaehigung;
    var meine = verantwortlich ? b.personen.filter(function (p) { return p.person.id === verantwortlich.personId; })[0] : null;
    var fr = pr.fristen;
    return {
      geprueftAm: pr.geprueftAm,
      tagesbeginn: tagesbeginn,
      verantwortlich: verantwortlich ? { personId: verantwortlich.personId, name: verantwortlich.name, ergebnis: meine ? meine.ergebnis : null } : null,
      befaehigung: {
        ergebnis: b.ergebnis, gebiet: b.gebiet || null, gebietHinweis: b.gebietHinweis || null,
        personen: b.personen.map(function (p) {
          return { name: p.person.name, rolleText: p.rolleText, ergebnis: p.ergebnis,
            gruende: p.gruende.map(function (g) { return { ergebnis: g.ergebnis, text: g.text }; }) };
        })
      },
      ausruestung: pr.ausruestung && pr.ausruestung.liste.length ? {
        ergebnis: pr.ausruestung.ergebnis,
        liste: pr.ausruestung.liste.map(function (x) { return { bezeichnung: x.bezeichnung, status: x.status, text: x.text }; })
      } : null,
      fristen: {
        betroffen: fr.zusammenfassung.betroffen, sperre: fr.zusammenfassung.sperre, eingeschraenkt: fr.zusammenfassung.eingeschraenkt,
        liste: fr.liste.filter(function (f) { return f.status !== 'ok'; }).map(function (f) {
          return { bezeichnung: f.bezeichnung, status: f.status, wirkung: f.wirkung || null, text: f.text };
        }),
        gesamt: fr.liste.length
      }
    };
  }

  /* Ein Satz zur festgehaltenen Prüfung, zum Beispiel für die Tagesliste. */
  function pruefungKurz(p) {
    if (!p) return null;
    var e = MM.Aktivitaeten.ERGEBNIS;
    var teile = ['Befähigung: ' + e[p.befaehigung.ergebnis]];
    if (p.ausruestung) teile.push('Ausrüstung: ' + e[p.ausruestung.ergebnis]);
    teile.push(p.fristen.betroffen ? 'Fristen: ' + p.fristen.betroffen + ' betroffen' : 'Fristen: keine betroffen');
    return teile.join(', ');
  }

  MM.Logbuch = {
    VORSCHLAEGE_EREIGNISARTEN: VORSCHLAEGE_EREIGNISARTEN, WECHSEL_ART: WECHSEL_ART, MAX_TAGE: MAX_TAGE,
    tageImZeitraum: tageImZeitraum, wochentag: wochentag, fehlendeTage: fehlendeTage,
    abschnitteSortieren: abschnitteSortieren, abschnittFuer: abschnittFuer,
    wechselEreignisse: wechselEreignisse, ereignisZeit: ereignisZeit, ereignisseSortieren: ereignisseSortieren,
    pruefungFestgehalten: pruefungFestgehalten, pruefungKurz: pruefungKurz
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
