/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.13';
  MM.STUFE = 'Logbuch-Kern: Tage, Ereignisse, Nachtragen';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
