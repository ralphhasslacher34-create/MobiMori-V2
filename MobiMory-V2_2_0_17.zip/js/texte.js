/*
 * Texte, die das Programm von sich selbst zeigt: Kernsatz, Infotext,
 * Copyright und die Liste "Neu im Programm". Nur hier ändern.
 * Das Logo ist die Datei icons/icon.svg (zugleich das App-Symbol).
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  MM.Texte = {
    KERNSATZ: 'Dein Fahrzeug. Dein Weg. Deine Daten.',
    INFOTEXT: 'Fahrzeuge verwalten, Reisen planen und Erinnerungen festhalten. Auf Land, zu Wasser und in der Luft.',
    COPYRIGHT: '© 2026 Ralph Hasslacher',

    /* Neueste Version zuerst. Die oberste muss zu MM.VERSION passen (wird getestet). */
    NEUERUNGEN: [
      { version: '2.0.17', datum: '2026-11-04', punkte: [
        'Die Art der Aktivität richtet sich nach dem Fahrzeug: Bei jeder Art von Aktivität legst du fest, für welche Fahrzeugarten sie gilt (Baum mit Häkchen, wie bei den Ereignissen). Mit dem Wohnmobil gibt es dann zum Beispiel kein Wasserski.',
        'Logbuch jetzt starten: Neues Feld „Aktivität“. Es zeigt nur Arten, die zum gewählten Fahrzeug passen, „Ausfahrt“ ist vorausgewählt, wenn sie passt. Der Name des Logbuchs folgt der gewählten Art, zum Beispiel „Törn Kat 04.11.2026“.',
        'Auch beim Planen und Ändern einer Aktivität stehen nur die Arten zur Wahl, die zum Fahrzeug passen. Eine Art, die schon an der Aktivität hängt, bleibt wählbar.',
        'Unter „Arten von Aktivitäten“ zeigt jede Art „Gilt für: …“. Der Knopf „Vorschläge für Fahrzeugarten übernehmen“ setzt eine Starthilfe (Wasserski nur für Wasserskiboote, Segeln nur für Segelboote, Törn für Wasserfahrzeuge, Rallye für Landfahrzeuge, Urlaub und Ausfahrt für alle), aber nur dort, wo du noch nichts eingestellt hast. Alles ist jederzeit änderbar.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Ältere Arten ohne Zuordnung gelten wie bisher für alle.'
      ] },
      { version: '2.0.16', datum: '2026-11-04', punkte: [
        'Fahrzeugarten selbst verwalten: Unter Stammdaten › Fahrzeugarten siehst du den ganzen Baum. Du kannst Untergruppen anlegen (zum Beispiel Trimaran unter Segelboot oder Aufsitzrasenmäher unter Landfahrzeug), Arten umbenennen und ausblenden.',
        'Eine neue Art übernimmt die Felder und die Ereignisse der Gruppe, unter der sie steht. Bei den Arten von Ereignissen kannst du das wie gewohnt ändern.',
        'Ausblenden geht immer. Eine ausgeblendete Art (und alles darunter) bieten neue Fahrzeuge nicht mehr an, bestehende Fahrzeuge bleiben unverändert.',
        'Löschen geht nur bei Arten, die kein Fahrzeug benutzt (auch keine Untergruppe davon). Was benutzt wird, lässt sich nur ausblenden.',
        'Ungebrauchtes löschen: ein Knopf räumt den Baum auf. Er löscht alles, was kein Fahrzeug benutzt, und zeigt vorher, was weggeht. Wer nur Oldtimer braucht, behält nur die Oldtimer. Gelöschte Vorschläge lassen sich zurückholen.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Eigene Arten sind in der Sicherung enthalten.'
      ] },
      { version: '2.0.15', datum: '2026-11-04', punkte: [
        'Logbuch ohne Planung: Auf der Seite „Aktivitäten“ und beim Fahrzeug gibt es den Knopf „Logbuch jetzt starten“. Du wählst Fahrzeug und wer verantwortlich ist (Stellvertreter und Crew sind freiwillig), der Beginn ist jetzt, und das Cockpit läuft sofort. Es entsteht eine ganz normale Aktivität der Art „Ausfahrt“, mit derselben Prüfung.',
        'Ereignisse gelten für Fahrzeugarten: Bei jeder Art von Ereignis legst du fest, für welche Fahrzeugarten sie gilt. Cockpit und Logbuch zeigen dann nur die Ereignisse, die zum Fahrzeug passen. Ein Häkchen an einer Gruppe gilt für alles darunter, einzelne Arten kannst du abwählen oder wieder ankreuzen.',
        'Fahrzeugarten als Baum: Wasserfahrzeug enthält jetzt Boot mit Sportboot, Wasserskiboot, Motorboot zum Übernachten, Motorschiff und Segelboot (Monohull, Katamaran, Jolle oder Kleinboot). Bestehende Fahrzeuge der Art „Boot“ bleiben gültig. Regeln für „Boot“ gelten auch für diese Untergruppen.',
        'Neue Vorschläge für Ereignisse mit Zuordnung (Tanken, Anlegen, Ablegen, Anker werfen, Anker lichten, Schleuse, Segel setzen, Segel bergen, Wasserski-Lauf) unter „Arten von Ereignissen“. Ältere Ereignisarten gelten wie bisher für alle.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt.'
      ] },
      { version: '2.0.14', datum: '2026-11-03', punkte: [
        'Bei der Aktivität gibt es jetzt zwei Reiter: „Cockpit“ zum schnellen Eintragen unterwegs und „Logbuch“ zum Nachlesen, Korrigieren und Nachtragen. Beide zeigen dieselben Einträge. Läuft die Aktivität gerade, öffnet sich das Cockpit zuerst, sonst das Logbuch.',
        'Cockpit mit großen Knöpfen: Ein Tipp auf Abfahrt oder Ankunft speichert sofort mit der Uhrzeit von jetzt, ohne Formular. Dazu Ereignis, Notiz und Foto. Das Cockpit zeigt den heutigen Tag, die letzten Einträge und wer gerade verantwortlich ist, seit wann. Der heutige Tag wird beim ersten Eintrag von selbst angelegt.',
        'Verantwortung wechseln im Cockpit: ein Tipp auf den Namen, Zeit jetzt. Die App prüft dabei die Befähigung der übernehmenden Person und hält das Ergebnis mit „geprüft am“ beim Wechsel fest. Sie weist nur hin und sperrt nichts. Ein vergessener Wechsel lässt sich mit der echten Uhrzeit nachtragen.',
        'Nachtrag wird erkannt: Weicht die Uhrzeit um mehr als 5 Minuten von jetzt ab, steht das Ereignis automatisch als „nachgetragen am …“ da. Der Knopf „Nachtragen“ bleibt.',
        'Klassisches Logbuch: alle Tage und Ereignisse der Reihe nach wie auf Papier, mit der festgehaltenen Prüfung zum Tagesbeginn beim Tag. Hier wird geändert, nachgetragen und ausgeblendet. Der Verlauf bleibt erhalten, nichts wird gelöscht.',
        'Tagesabschluss: tatsächliches Ziel und eine Notiz zum Tag. Der Zählerstand am Ende kommt später mit dem Schritt „Zähler automatisch“.',
        'Größere Knöpfe und klarere Gestaltung für Tablet und Smartphone.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt.'
      ] },
      { version: '2.0.13', datum: '2026-11-03', punkte: [
        'Logbuch-Kern an der Aktivität: Ein Tagesabschnitt je Tag mit Datum, Beginn und Ende (Uhrzeit freiwillig), von wo nach wo (als Text) und Notiz.',
        'Die App bereitet die Tage aus dem Zeitraum der Aktivität auf Knopfdruck vor. Jeder Tag lässt sich ändern, von Hand ergänzen und ausblenden. Nichts wird gelöscht.',
        'Prüfung zum Tagesbeginn: Die Prüfung der Aktivität wird für den Tag festgehalten, mit „geprüft am“ und dem Verantwortlichen dieses Tages. Spätere Änderungen verändern das Festgehaltene nicht.',
        'Ereignisse in einem Tag: Zeitpunkt, Art, Text und ein Foto, alles außer Zeitpunkt und Art freiwillig. Die Arten sind eine offene Liste mit Vorschlägen (Abfahrt, Ankunft, Wechsel des Verantwortlichen, Störung, Notiz).',
        'Ein Wechsel des Verantwortlichen erscheint von selbst als Ereignis. Du kannst Zeitpunkt und Notiz korrigieren, der frühere Stand bleibt im Verlauf. Die Verantwortung der Aktivität folgt der Korrektur.',
        'Nachtragen: Ein Ereignis mit dem echten Zeitpunkt später eintragen. Es steht dann als „nachgetragen am …“ da.',
        'Bestehende Daten und Sicherungen bleiben gültig. Die Sicherung enthält Tage, Ereignisse, Prüfungen und Fotos.',
        'Noch nicht dabei: Wetter und Wegpunkte, Motor Start und Stopp, Störung als Werkstattvorgang, Orte als Start und Ziel, Kosten.'
      ] },
      { version: '2.0.12', datum: '2026-11-03', punkte: [
        'Komponenten haben eine Anzahl (zum Beispiel 6 Rettungswesten) und den Haken „Eignung geprüft“.',
        'Regeln für Pflichtausrüstung nennen jetzt eine Menge, die Bezugsgröße (je Fahrzeug oder je Person an Bord) und freiwillig die geforderte Eignung, zum Beispiel „Automatik, 150 N“.',
        'Die Prüfung bei der Aktivität vergleicht Soll und Ist und nennt die Zahlen, zum Beispiel „Eingetragen sind 5, Soll ist 6“. Bei „je Person“ zählt die Besatzung der Aktivität.',
        'Fehlt bei geforderter Eignung der Haken, sagt die Prüfung „unklar“. Die App prüft die Eignung nicht selbst.',
        'Bestehende Regeln und Komponenten bleiben gültig und ändern ihr Ergebnis nicht.'
      ] },
      { version: '2.0.11', datum: '2026-11-03', punkte: [
        'Orte: zusätzlich Adresse, Ansprechpartner und Telefon.',
        'Standorte: zusätzlich Länge, Breite, Tiefe und Höhe des Platzes.',
        'Regeln für Pflichtausrüstung: Zu einem Gebiet legst du fest, was am Fahrzeug sein muss, zum Beispiel Rettungsweste oder Feuerlöscher, wahlweise nur für bestimmte Fahrzeugarten.',
        'Die Prüfung bei der Aktivität zeigt die Pflichtausrüstung des Gebiets. Sie sucht in den eingetragenen Komponenten des Fahrzeugs. Ist etwas nicht eingetragen, sagt sie „unklar“ und nicht „fehlt“, weil sie nicht weiß, was wirklich an Bord liegt.',
        'Befähigung und Pflichtausrüstung sind zwei Arten von Regeln im selben Gebiet. Die Regeln sind weiter von dir eingetragen.'
      ] },
      { version: '2.0.10', datum: '2026-11-03', punkte: [
        'Orte und Standorte: Ein Ort (zum Beispiel ein Hafen) hat Standorte (zum Beispiel Liegeplatz 12). Alles gehört deinem eigenen Datenraum.',
        'Heimatstandort am Fahrzeug: Du wählst ihn aus deinen Standorten. Änderungen bleiben im Verlauf sichtbar.',
        'Gebiete mit Regeln: Eine Regel sagt „Wenn Gebiet, Fahrzeugart und Ausrüstung passen, genügt einer dieser Nachweise“. Die Regeln sind von dir eingetragen.',
        'Bei der Aktivität wählst du das Gebiet aus der Liste. Die Prüfung nutzt die Regeln des Gebiets zusätzlich zu den Anforderungen am Fahrzeug.',
        'Kennt die App für ein Gebiet und dein Fahrzeug keine Regel, sagt sie höchstens „unklar“ und nie „erlaubt“.',
        'Noch nicht dabei: Quelle und Prüfdatum je Regel, Reisecheck, weitere Länder.'
      ] },
      { version: '2.0.9', datum: '2026-11-03', punkte: [
        'Sicherungsdatei: ein Tipp erstellt eine Datei mit allen deinen Daten. Sie lässt sich speichern oder teilen, zum Beispiel in die Cloud.',
        'Wahlweise mit Schlüsselwort verschlüsselt. Darin stehen auch Ausweisdaten und Scans.',
        'Dokumente und Scans kannst du mitsichern oder weglassen. Vorher siehst du, wie groß es wird.',
        'Wiederherstellen: Die App zeigt zuerst, was in der Sicherung steht und was ersetzt wird. Erst nach deiner Bestätigung wird etwas verändert, und zwar ganz oder gar nicht.',
        'Die App erinnert an die Sicherung, nach 14, 30 oder 90 Tagen oder gar nicht.'
      ] },
      { version: '2.0.8', datum: '2026-11-03', punkte: [
        'Aktivitäten (Urlaub, Törn, Ausfahrt, Wasserski, Segeln, Rallye): Name, Art, Fahrzeug, Zeitraum mit freiwilliger Uhrzeit, Gebiet, geplante Strecke oder Betriebsstunden, Tiere und Notiz.',
        'Besatzung aus den Personen: Skipper oder Fahrer, Stellvertreter und Crew. Jede Person steht einmal da, bei Bedarf mit „dabei von bis“.',
        'Zu jedem Zeitpunkt ist genau eine Person verantwortlich. Jeder Wechsel wird mit Zeitpunkt festgehalten.',
        'Prüfung bei der Planung: Befähigung von Skipper oder Fahrer und Stellvertretern (erlaubt, nicht erlaubt, unklar, mit „geprüft am“), Fristen bis zum Ende des Zeitraums und Überschneidungen am Fahrzeug.',
        'Am Fahrzeug legst du fest, welche Nachweise ein Skipper oder Fahrer braucht.',
        'Aktivitäten lassen sich jederzeit stornieren und wiederherstellen. Nichts wird gelöscht.'
      ] },
      { version: '2.0.7', datum: '2026-11-03', punkte: [
        'Personen mit Funktionen (Skipper, Fahrer, Crew, Beifahrer, Gast) und Tiere mit Tierart und Chipnummer.',
        'Nachweise an Personen, Tieren und Fahrzeugen, mit „gültig bis“, Status und optionalem Scan oder Foto, das nur auf dem Gerät bleibt.',
        'Die Liste der Nachweisarten ist offen: Du legst eigene Arten an oder übernimmst Vorschläge für Deutschland und die EU. Jeder Vorschlag nennt seine Quelle und wie weit er geprüft ist.',
        'Vorschläge: Führerschein, Personalausweis, Reisepass, Sportbootführerschein, Funkzeugnisse, Heimtierausweis, Tollwutimpfung, Zulassungsbescheinigung Teil I und II, Hauptuntersuchung, Internationaler Bootsschein und mehr.',
        'Die Fahrzeugliste zeigt auch abgelaufene und bald ablaufende Nachweise.'
      ] },
      { version: '2.0.6', datum: '2026-11-03', punkte: [
        'Dokumente an Fahrzeug und Komponente: Bedienungsanleitung, Ersatzteilliste, Wartungsanleitung, Kaufbeleg, Garantie, Foto oder Sonstiges.',
        'Als Datei vom Gerät (auch ohne Internet da) oder als Link ins Internet.',
        'Am Fahrzeug gibt es eine Gesamtliste aller Dokumente, nach Komponente geordnet und mit Suche.',
        'In den Einstellungen siehst du, wie viel Speicher die Dokumente belegen und wie viel Platz der Browser erlaubt.'
      ] },
      { version: '2.0.5', datum: '2026-11-03', punkte: [
        'Fristen am Fahrzeug und an jeder Komponente: nach Zeit (Monate oder Jahre), nach Zähler (Strecke oder Betriebsstunden) oder nach beidem. Was zuerst eintritt, löst die Fälligkeit aus.',
        'Zähler am Fahrzeug oder pro Komponente, zum Beispiel pro Motor, mit Verlauf der Zählerstände.',
        'Jede Frist zeigt, ob sie in Ordnung, bald fällig oder überfällig ist. In der Fahrzeugliste siehst du es auf einen Blick.',
        'Wirkung bei Überfälligkeit (nur warnen, eingeschränkt, Sperre) und Vorwarnung sind einstellbar.',
        '„Erledigt eintragen“ setzt die Rechnung einer Frist neu an, frühere Erledigungen bleiben sichtbar.'
      ] },
      { version: '2.0.4', datum: '2026-11-03', punkte: [
        'Hauptkomponenten (Schale 3): Motor, Getriebe, Heizung, Klima, Stromversorgung, Wasserversorgung und Sonstiges.',
        'Darunter lässt sich beliebig tief aufschlüsseln, zum Beispiel Motor, Einspritzung, Pumpe.',
        'Zu jedem Teil: Hersteller, Modell, Seriennummer, Baujahr, Einbau, Ausbau und technische Merkmale.',
        'Änderungen bleiben wie beim Fahrzeug im Verlauf sichtbar.',
        'Wenn eine neue Version bereitsteht, erscheint ein Hinweis zum Neuladen.'
      ] },
      { version: '2.0.3', datum: '2026-11-03', punkte: [
        'Startseite neu gestaltet: Die Buchstaben V, T und D des Logos stehen vor den drei Teilen des Kernsatzes.',
        'Infotext: „Reisen planen“.',
        'Das Logo ist an einer einzigen Stelle abgelegt und gilt auf der Startseite, in der Kopfzeile und als App-Symbol.'
      ] },
      { version: '2.0.2', datum: '2026-11-03', punkte: [
        'Startseite mit Logo, Kernsatz und den Knöpfen „Programm starten“ und „Neu im Programm“.',
        'Hauptmenü mit Stammdaten, Funktionen und Einstellungen.',
        'Stammdaten mit den Fahrzeugen. Personen und Tiere folgen.',
        'Einstellungen mit Hinweisen zu deinen Daten.'
      ] },
      { version: '2.0.1', datum: '2026-11-03', punkte: [
        'Fahrzeugliste und äußere Hülle für sieben Fahrzeugarten.',
        'Eingaben von Hand, jede Änderung bleibt im Verlauf sichtbar.',
        'Funktioniert ohne Internet, die Daten liegen auf dem Gerät.'
      ] }
    ]
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
