/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.17';
  MM.STUFE = 'Art der Aktivität richtet sich nach dem Fahrzeug';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
