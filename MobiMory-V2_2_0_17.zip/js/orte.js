/*
 * Orte, Standorte, Gebiete und Regeln (Stufe 1).
 *
 * Aus den V2-Festlegungen:
 *  - Orte und Standorte gehören dem eigenen Datenraum des Nutzers.
 *    Hierarchie: Ort -> Standort (zum Beispiel Hafen -> Liegeplatz 12).
 *  - Gebiete sind allgemeine Regeln-Träger: Ein Gebiet (zum Beispiel
 *    „Kroatien, Adria“) trägt Wenn-dann-Regeln.
 *  - Eine Regel: WENN Gebiet (Revier), Fahrzeugart und Ausrüstung passen,
 *    DANN genügt eine der gewählten Nachweisarten.
 *  - Stufe 1: nur eigene Regeln, „von dir eingetragen“. Quelle und Prüfdatum
 *    je Regel sowie weitere Länder kommen in Stufe 2 und 3.
 *  - Pflichtausrüstung hat Menge, Bezugsgröße (je Fahrzeug oder je Person an Bord)
 *    und freiwillig eine Eignung. Verglichen wird Soll gegen Ist (Anzahl der
 *    eingebauten Komponenten). Die Eignung zeigt die App nur an: Ein fehlender
 *    Haken „Eignung geprüft“ macht das Ergebnis „unklar“.
 *  - Die App trifft keine rechtliche Aussage.
 *
 * Hier steht nur Beschreibung und Rechnung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var JA_NEIN = [{ wert: 'ja', label: 'Ja' }, { wert: 'nein', label: 'Nein' }];

  /* Alle Angaben außer dem Namen sind freiwillig. */
  function ortFelder() {
    return [
      { key: 'land', label: 'Land', typ: 'text', hilfe: 'Zum Beispiel „Kroatien“' },
      { key: 'adresse', label: 'Adresse', typ: 'text', hilfe: 'Straße, Postleitzahl und Ort, oder eine Beschreibung der Lage' },
      { key: 'ansprechpartner', label: 'Ansprechpartner', typ: 'text', hilfe: 'Zum Beispiel Hafenmeister oder Platzwart' },
      { key: 'telefon', label: 'Telefon', typ: 'text' },
      { key: 'notiz', label: 'Notiz', typ: 'text' }
    ];
  }

  function standortFelder() {
    return [
      { key: 'standortart', label: 'Art', typ: 'text', hilfe: 'Zum Beispiel „Liegeplatz“, „Stellplatz“ oder „Garage“' },
      { key: 'laenge', label: 'Länge des Platzes', typ: 'zahl', einheit: 'm' },
      { key: 'breite', label: 'Breite des Platzes', typ: 'zahl', einheit: 'm' },
      { key: 'tiefgang', label: 'Tiefe am Platz', typ: 'zahl', einheit: 'm', hilfe: 'Für Liegeplätze: wie viel Wasser unter dem Boot sein darf' },
      { key: 'hoehe', label: 'Höhe (Durchfahrt oder Halle)', typ: 'zahl', einheit: 'm' },
      { key: 'notiz', label: 'Notiz', typ: 'text' }
    ];
  }

  /* Eine Regel verlangt entweder einen Nachweis der Person (Befähigung) oder Pflichtausrüstung am Fahrzeug. */
  var REGELARTEN = [{ wert: 'befaehigung', label: 'Befähigung: ein Nachweis der Person' }, { wert: 'ausruestung', label: 'Pflichtausrüstung: etwas muss am Fahrzeug sein' }];
  function regelArt(w) { return w && w.art === 'ausruestung' ? 'ausruestung' : 'befaehigung'; }

  function gebietFelder() {
    return [
      { key: 'notiz', label: 'Notiz', typ: 'text' }
    ];
  }

  /* Text zur Herkunft. Stufe 1 kennt nur eigene Einträge. */
  function herkunftText() {
    return 'von dir eingetragen';
  }

  /* Ist die Ausrüstung am Fahrzeug eingetragen? Gesucht wird in den Namen der Komponenten,
     die nicht ausgebaut sind. Groß- und Kleinschreibung zählt nicht, ein Teil des Namens genügt. */
  function ausruestungVorhanden(suchtext, komponentenNamen) {
    var s = String(suchtext || '').trim().toLowerCase();
    if (!s) return true;
    return komponentenNamen.some(function (n) { return String(n || '').toLowerCase().indexOf(s) >= 0; });
  }


  /* Bezugsgröße der Menge. Tiere zählen vorerst nicht: Dafür ist keine Pflicht bekannt. */
  var BEZUGSGROESSEN = [{ wert: 'fahrzeug', label: 'je Fahrzeug' }, { wert: 'person', label: 'je Person an Bord' }];
  function bezugsgroesse(w) { return w && w.bezug === 'person' ? 'person' : 'fahrzeug'; }
  function menge(w) { var m = w && Number(w.menge); return m >= 1 && Math.floor(m) === m ? m : 1; }

  /*
   * Soll gegen Ist bei einer Regel „Pflichtausrüstung“.
   *  p.regel        { pflichtAusruestung, menge, bezug, eignung }
   *  p.komponenten  [{ name, anzahl, geprueft }]  nur eingebaute; anzahl leer = 1; geprueft = 'ja' bei gesetztem Haken
   *  p.personen     Zahl der Personen in der Besatzung (nur bei „je Person“ nötig)
   * Ergebnis: { status, soll, ist, istGeprueft, menge, bezug, eignung, text }
   *  status: 'eingetragen' | 'nicht_eingetragen' | 'zu_wenig' | 'eignung_offen' | 'keine_besatzung'
   * Nur „eingetragen“ ist gut. Alles andere heißt „unklar“, nie „fehlt“, weil die App nicht weiß, was wirklich an Bord liegt.
   */
  function ausruestungPruefen(p) {
    var r = p.regel || {};
    var such = String(r.pflichtAusruestung || '').trim().toLowerCase();
    var treffer = (p.komponenten || []).filter(function (k) { return such && String(k.name || '').toLowerCase().indexOf(such) >= 0; });
    var ist = 0, geprueft = 0;
    treffer.forEach(function (k) {
      var n = Number(k.anzahl) >= 1 ? Math.floor(Number(k.anzahl)) : 1;
      ist += n;
      if (k.geprueft === 'ja') geprueft += n;
    });
    var m = menge(r), bezug = bezugsgroesse(r), eignung = String(r.eignung || '').trim() || null;
    var personen = Number(p.personen) >= 0 ? Number(p.personen) : 0;
    var soll = bezug === 'person' ? m * personen : m;
    var name = '„' + (r.pflichtAusruestung || '') + '“';
    var sollText = bezug === 'person' ? soll + ' (' + m + ' je Person, ' + personen + (personen === 1 ? ' Person' : ' Personen') + ')' : String(soll);
    var status, text;
    if (bezug === 'person' && personen === 0) {
      status = 'keine_besatzung';
      text = name + ': Die Menge hängt von der Zahl der Personen an Bord ab, aber bei der Aktivität ist noch niemand als Besatzung eingetragen.';
    } else if (!treffer.length) {
      status = 'nicht_eingetragen';
      text = name + ' ist am Fahrzeug nicht eingetragen. Soll: ' + sollText + '. Trage es als Komponente ein oder prüfe, ob es an Bord ist.';
    } else if (ist < soll) {
      status = 'zu_wenig';
      text = name + ': Eingetragen sind ' + ist + ', Soll ist ' + sollText + '. Es fehlen ' + (soll - ist) + ' in den Komponenten. Prüfe die Anzahl oder ob es an Bord ist.';
    } else if (eignung && geprueft < soll) {
      status = 'eignung_offen';
      text = name + ': ' + ist + ' von ' + sollText + ' eingetragen, die Anzahl passt. Gefordert ist „' + eignung + '“. Als geprüft eingetragen sind erst ' + geprueft + ' von ' + soll + '. Setze bei der Komponente den Haken „Eignung geprüft“, wenn sie passt.';
    } else {
      status = 'eingetragen';
      text = name + ': ' + ist + ' von ' + sollText + ' eingetragen.' + (eignung ? ' Eignung „' + eignung + '“ ist als geprüft eingetragen.' : '');
    }
    return { status: status, soll: soll, ist: ist, istGeprueft: geprueft, menge: m, bezug: bezug, eignung: eignung, text: text };
  }

  /*
   * Welche Regeln eines Gebiets gelten für dieses Fahrzeug?
   *  p.regeln       [{ id, bezeichnung, fahrzeugArten:[id], ausruestung, artIds:[id], gilt }]  nur die des gewählten Gebiets
   *  p.fahrzeugArt  Art des Fahrzeugs (zum Beispiel 'boot')
   *  p.komponentenNamen  Namen der eingebauten Komponenten des Fahrzeugs
   * Ergebnis: { greifen: [...], nichtGreifen: [{ regel, grund }] }
   * Abgeschaltete Regeln (gilt = 'nein') werden gar nicht erst genannt.
   */
  function regelnAuswerten(p) {
    var greifen = [], nicht = [];
    p.regeln.filter(function (r) { return r.gilt !== 'nein'; }).forEach(function (r) {
      var arten = r.fahrzeugArten || [];
      /* Eine Regel für „Boot“ gilt auch für Untergruppen wie „Segelboot Katamaran“ (seit 2.0.15). */
      var meineArten = MM.Fahrzeugarten.vorfahren(p.fahrzeugArt);
      if (arten.length && !arten.some(function (a) { return meineArten.indexOf(a) >= 0; })) {
        nicht.push({ regel: r, grund: 'gilt nur für ' + arten.map(function (a) { var x = MM.Fahrzeugarten.art(a); return x ? x.name : a; }).join(', ') });
        return;
      }
      if (r.ausruestung && !ausruestungVorhanden(r.ausruestung, p.komponentenNamen)) {
        nicht.push({ regel: r, grund: 'gilt nur mit „' + r.ausruestung + '“, am Fahrzeug ist aber keine Komponente mit diesem Namen eingetragen' });
        return;
      }
      greifen.push(r);
    });
    return { greifen: greifen, nichtGreifen: nicht };
  }

  MM.Orte = {
    JA_NEIN: JA_NEIN,
    ortFelder: ortFelder, standortFelder: standortFelder, gebietFelder: gebietFelder,
    REGELARTEN: REGELARTEN, regelArt: regelArt, herkunftText: herkunftText, ausruestungVorhanden: ausruestungVorhanden, regelnAuswerten: regelnAuswerten,
    BEZUGSGROESSEN: BEZUGSGROESSEN, bezugsgroesse: bezugsgroesse, menge: menge, ausruestungPruefen: ausruestungPruefen
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
