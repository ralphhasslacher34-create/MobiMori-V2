/*
 * Komponenten: Hauptkomponenten (Schale 3) und alles darunter (Schale 4 und tiefer).
 *
 * Es gibt nur EINE Liste für alle Komponenten. Jede Komponente "gehört zu"
 * einem Fahrzeug oder zu einer anderen Komponente. So lässt sich beliebig
 * tief aufschlüsseln: Motor, Einspritzung, Pumpe, ...
 *
 * Die Felder sind, wie bei den Fahrzeugarten, als Daten beschrieben.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Nur Hauptkomponenten haben eine Art. Die Reihenfolge ist die Anzeigereihenfolge. */
  var ARTEN = [
    { id: 'motor', name: 'Motor' },
    { id: 'getriebe', name: 'Getriebe' },
    { id: 'heizung', name: 'Heizung' },
    { id: 'klima', name: 'Klima' },
    { id: 'strom', name: 'Stromversorgung' },
    { id: 'wasser', name: 'Wasserversorgung' },
    { id: 'sonstiges', name: 'Sonstiges' }
  ];

  var GRUPPEN = [
    { id: 'teil', titel: 'Teil' },
    { id: 'einbau', titel: 'Einbau' },
    { id: 'merkmale', titel: 'Technische Merkmale' }
  ];

  var FELDER = [
    { key: 'hersteller', label: 'Hersteller', typ: 'text', gruppe: 'teil' },
    { key: 'modell', label: 'Modell', typ: 'text', gruppe: 'teil' },
    { key: 'seriennummer', label: 'Seriennummer', typ: 'text', gruppe: 'teil' },
    { key: 'baujahr', label: 'Baujahr', typ: 'ganzzahl', gruppe: 'teil', min: 1800 },
    { key: 'anzahl', label: 'Anzahl', typ: 'ganzzahl', gruppe: 'teil', min: 1,
      hilfe: 'Wie viele Stück dieser Art eingebaut sind, zum Beispiel 6 Rettungswesten. Leer zählt als 1.' },
    { key: 'eignungGeprueft', label: 'Eignung geprüft', typ: 'auswahl', gruppe: 'teil', leerText: 'Nein, noch nicht geprüft',
      optionen: [{ wert: 'ja', label: 'Ja, geprüft' }],
      hilfe: 'Nur wichtig, wenn eine Regel eine bestimmte Eignung verlangt, zum Beispiel „Automatik, 150 N“.' },
    { key: 'eingebautAm', label: 'Eingebaut am', typ: 'datum', gruppe: 'einbau' },
    { key: 'einbauort', label: 'Einbauort', typ: 'text', gruppe: 'einbau', hilfe: 'Zum Beispiel Motorraum oder Heck' },
    { key: 'ausgebautAm', label: 'Ausgebaut am', typ: 'datum', gruppe: 'einbau',
      hilfe: 'Nur eintragen, wenn das Teil nicht mehr im Fahrzeug ist' },
    { key: 'merkmale', label: 'Technische Merkmale', typ: 'liste', gruppe: 'merkmale',
      hilfe: 'Zum Beispiel „Leistung“ und „110 kW“' }
  ];

  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }

  function art(id) {
    for (var i = 0; i < ARTEN.length; i++) { if (ARTEN[i].id === id) return ARTEN[i]; }
    return null;
  }

  function felder() { return FELDER.map(kopie); }

  function gruppen() {
    return GRUPPEN.map(function (g) {
      return { id: g.id, titel: g.titel, felder: FELDER.filter(function (f) { return f.gruppe === g.id; }).map(kopie) };
    });
  }

  function artIndex(id) {
    for (var i = 0; i < ARTEN.length; i++) { if (ARTEN[i].id === id) return i; }
    return ARTEN.length;
  }

  MM.Komponenten = {
    arten: function () { return ARTEN.slice(); },
    art: art,
    artIndex: artIndex,
    felder: felder,
    gruppen: gruppen
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
