'use strict';
/* 2.0.15: Fahrzeugarten als Baum, Ereignisarten gelten für Fahrzeugarten, Logbuch ohne Planung starten. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;
const F = MM.Fahrzeugarten, L = MM.Logbuch;

function neueDaten() {
  let t = 0;
  const start = new Date(2026, 10, 4, 14, 30, 0).getTime();
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(start + (t++)).toISOString() });
}

/* ---------- Der Baum ---------- */
test('Baum: Wurzel, Welten, Boote mit Untergruppen, alte Art „boot“ bleibt gültig', () => {
  const ids = F.alle().map(a => a.id);
  ['auto', 'motorrad', 'wohnmobil', 'wohnwagen', 'oldtimer', 'boot', 'flugzeug'].forEach(i => assert.ok(ids.includes(i), i));
  ['sportboot', 'wasserskiboot', 'wohnboot', 'motorschiff', 'segelboot', 'segelboot-monohull', 'segelboot-katamaran', 'segelboot-jolle'].forEach(i => assert.ok(ids.includes(i), i));
  assert.ok(!ids.includes('wasser') && !ids.includes('alle'), 'Gruppen sind keine Fahrzeugart');
  assert.deepEqual(F.vorfahren('segelboot-katamaran'), ['segelboot-katamaran', 'segelboot', 'boot', 'wasser', 'alle']);
  assert.deepEqual(F.vorfahren('auto'), ['auto', 'land', 'alle']);
  assert.equal(F.baum()[0].id, 'alle');
  assert.ok(F.gehoertZu('segelboot-jolle', 'wasser') && !F.gehoertZu('auto', 'wasser'));
});

test('Baum: neue Bootsarten haben die Felder des Boots, jede Art hat eine Welt und ein Elternteil im Baum', () => {
  const boot = F.felder('boot').map(f => f.key);
  ['sportboot', 'segelboot-katamaran'].forEach(i => assert.deepEqual(F.felder(i).map(f => f.key), boot));
  F.alle().forEach(a => { assert.ok(a.welt, a.id); assert.ok(F.vorfahren(a.id).includes('alle'), a.id); });
  assert.equal(F.kennungFeld('segelboot-monohull'), 'registriernummer');
});

test('Regeln für „Boot“ gelten auch für Untergruppen, Regeln für „Wohnmobil“ nicht für Boote', () => {
  const regeln = [{ id: 'r1', bezeichnung: 'Bootsregel', fahrzeugArten: ['boot'] }, { id: 'r2', bezeichnung: 'Wohnmobilregel', fahrzeugArten: ['wohnmobil'] }, { id: 'r3', bezeichnung: 'Für alle', fahrzeugArten: [] }];
  const e = MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'segelboot-katamaran', komponentenNamen: [] });
  assert.deepEqual(e.greifen.map(r => r.id), ['r1', 'r3']);
  assert.deepEqual(e.nichtGreifen.map(x => x.regel.id), ['r2']);
});

/* ---------- Zuordnung ---------- */
test('Ohne Angabe gilt eine Ereignisart für alle Fahrzeugarten (so waren alle Arten vor 2.0.15)', () => {
  F.alle().forEach(a => assert.equal(L.ereignisartGilt(undefined, a.id), true, a.id));
  assert.deepEqual(L.zuordnungNormal(undefined), { alle: 'ja' });
  assert.equal(L.zuordnungText(undefined), 'Alle Fahrzeuge');
});

test('Zuordnung: Gruppe gilt für alles darunter, die Art selbst oder die nächste Angabe darüber entscheidet', () => {
  const z = L.zuordnungFuerKnoten(['segelboot']);
  assert.equal(L.ereignisartGilt(z, 'segelboot'), true);
  assert.equal(L.ereignisartGilt(z, 'segelboot-jolle'), true);
  assert.equal(L.ereignisartGilt(z, 'sportboot'), false);
  assert.equal(L.ereignisartGilt(z, 'auto'), false);
  const ohneKat = Object.assign({}, z, { 'segelboot-katamaran': 'nein' });
  assert.equal(L.ereignisartGilt(ohneKat, 'segelboot-katamaran'), false, 'abgewählt, obwohl die Gruppe gilt');
  assert.equal(L.ereignisartGilt(ohneKat, 'segelboot-monohull'), true);
  assert.equal(L.zuordnungText(ohneKat), 'Segelboot außer Segelboot Katamaran');
  assert.equal(L.zuordnungText(L.zuordnungFuerKnoten(['wasser'])), 'Wasserfahrzeug');
  assert.equal(L.zuordnungText({ alle: 'nein' }), 'Keine Fahrzeugart');
});

test('Zuordnung: Häkchen setzen und entfernen zieht nach, bewusste Abweichungen darunter bleiben', () => {
  let ids = L.auswahlAusZuordnung(L.zuordnungFuerKnoten(['segelboot']));
  assert.deepEqual(ids, ['segelboot', 'segelboot-monohull', 'segelboot-katamaran', 'segelboot-jolle']);
  ids = L.auswahlUmschalten(ids, 'segelboot-katamaran', false);
  assert.deepEqual(L.zuordnungAusAuswahl(ids), { alle: 'nein', segelboot: 'ja', 'segelboot-katamaran': 'nein' });
  ids = L.auswahlUmschalten(ids, 'segelboot', false);
  assert.deepEqual(ids, [], 'Monohull und Jolle ziehen mit, Katamaran war schon aus');
  ids = L.auswahlUmschalten(ids, 'boot', true);
  assert.ok(['boot', 'sportboot', 'segelboot', 'segelboot-katamaran'].every(i => ids.includes(i)));
  assert.ok(!ids.includes('auto') && !ids.includes('wasser'));
  assert.deepEqual(L.zuordnungAusAuswahl(ids), { alle: 'nein', boot: 'ja' });
});

test('Zuordnung: Hin und zurück ist verlustfrei und stimmt mit ereignisartGilt überein', () => {
  const z = { alle: 'nein', wasser: 'ja', 'segelboot-jolle': 'nein', oldtimer: 'ja' };
  const ids = L.auswahlAusZuordnung(z);
  assert.deepEqual(L.zuordnungAusAuswahl(ids), L.zuordnungNormal(z));
  F.alle().forEach(a => assert.equal(ids.includes(a.id), L.ereignisartGilt(z, a.id), a.id));
});

test('Zuordnung: ein Häkchen an der Wurzel bleibt gespeichert, auch wenn alles abgewählt ist', () => {
  const z = L.zuordnungAusAuswahl([]);
  assert.deepEqual(z, { alle: 'nein' });
  assert.equal(L.ereignisartGilt(z, 'auto'), false, 'ein leeres Ergebnis darf nicht „für alle“ heißen');
  assert.equal(L.ereignisartGilt(L.zuordnungNormal(z), 'boot'), false);
});

/* ---------- Mit Speicher ---------- */
test('Ereignisarten: neue Art bekommt die Zuordnung, Ändern schreibt Verlauf, alte Art ohne Angabe bleibt „für alle“', async () => {
  const d = neueDaten(); await d.starten();
  await d.ereignisartenAusVorschlaegen();
  const alt = (await d.ereignisartenListe())[0];
  assert.equal(alt.aktuell.werte.zuordnung, undefined, 'die Vorschläge aus 2.0.13 bleiben unangetastet');
  const r = await d.ereignisartAnlegen({ bezeichnung: 'Reff eingebunden', zuordnung: L.zuordnungFuerKnoten(['segelboot']) });
  assert.ok(r.ok);
  const x = await d.ereignisartLaden(r.id);
  assert.deepEqual(x.aktuell.werte.zuordnung, { alle: 'nein', segelboot: 'ja' });
  const g = await d.ereignisartAendern(r.id, { bezeichnung: 'Reff eingebunden', ausgeblendet: 'nein', zuordnung: { alle: 'nein', segelboot: 'ja', 'segelboot-jolle': 'nein' } });
  assert.equal(g.geaendert, true);
  const gleich = await d.ereignisartAendern(r.id, { bezeichnung: 'Reff eingebunden', ausgeblendet: 'nein', zuordnung: { alle: 'nein', segelboot: 'ja', 'segelboot-jolle': 'nein' } });
  assert.equal(gleich.geaendert, false);
  const ohneAngabe = await d.ereignisartAendern(alt.objekt.id, { bezeichnung: alt.aktuell.werte.bezeichnung, ausgeblendet: 'nein' });
  assert.equal(ohneAngabe.geaendert, false, 'ohne Angabe bleibt die alte Art, wie sie ist');
  const v = await d.ereignisartLaden(r.id);
  assert.equal(v.aktuell.nr, 2);
});

test('Ereignisarten: Vorschläge mit Zuordnung kommen nur einmal, und die Auswahl nach Fahrzeugart stimmt', async () => {
  const d = neueDaten(); await d.starten();
  await d.ereignisartenAusVorschlaegen();
  const r = await d.ereignisartenVorauswahlUebernehmen();
  assert.equal(r.anzahl, L.ZUSATZ_VORSCHLAEGE.length);
  assert.equal((await d.ereignisartenVorauswahlUebernehmen()).anzahl, 0);
  const namen = async art => (await d.ereignisartenFuerFahrzeugart(art)).map(x => x.aktuell.werte.bezeichnung);
  const kat = await namen('segelboot-katamaran');
  assert.ok(kat.includes('Segel setzen') && kat.includes('Anlegen') && kat.includes('Abfahrt') && kat.includes('Tanken'));
  assert.ok(!kat.includes('Wasserski-Lauf'));
  const ski = await namen('wasserskiboot');
  assert.ok(ski.includes('Wasserski-Lauf') && !ski.includes('Segel setzen'));
  const auto = await namen('auto');
  assert.ok(auto.includes('Abfahrt') && auto.includes('Tanken') && !auto.includes('Anlegen') && !auto.includes('Segel setzen'));
  const alle = await d.ereignisartenListe();
  const segel = alle.find(x => x.aktuell.werte.bezeichnung === 'Segel setzen').objekt.id;
  assert.ok((await d.ereignisartenFuerFahrzeugart('auto', [segel])).some(x => x.objekt.id === segel), 'eine Art, die schon am Eintrag hängt, bleibt wählbar');
});

test('Ereignisarten: ausgeblendete Arten erscheinen nicht in der Auswahl', async () => {
  const d = neueDaten(); await d.starten();
  const r = await d.ereignisartAnlegen({ bezeichnung: 'Nur Test' });
  await d.ereignisartAendern(r.id, { bezeichnung: 'Nur Test', ausgeblendet: 'ja' });
  assert.ok(!(await d.ereignisartenFuerFahrzeugart('boot')).some(x => x.objekt.id === r.id));
});

test('Fahrzeug mit neuer Bootsart anlegen und alte Fahrzeuge mit „boot“ bleiben benutzbar', async () => {
  const d = neueDaten(); await d.starten();
  const a = await d.fahrzeugAnlegen('segelboot-katamaran', { bezeichnung: 'Kat' });
  const b = await d.fahrzeugAnlegen('boot', { bezeichnung: 'Altes Boot' });
  assert.ok(a.ok && b.ok);
  assert.equal((await d.fahrzeugAnlegen('wasser', { bezeichnung: 'x' })).ok, false, 'eine Gruppe ist keine Fahrzeugart');
});

/* ---------- Logbuch ohne Planung ---------- */
async function startKontext() {
  const d = neueDaten(); await d.starten();
  await d.ereignisartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('segelboot-monohull', { bezeichnung: 'Seestern' })).id;
  const wohnmobil = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Womo' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const ben = (await d.personAnlegen({ bezeichnung: 'Ben' })).id;
  const cara = (await d.personAnlegen({ bezeichnung: 'Cara' })).id;
  return { d, boot, wohnmobil, anna, ben, cara };
}

test('Logbuch jetzt starten: legt eine laufende Aktivität „Ausfahrt“ an, mit Verantwortlichen, Stellvertreter und Crew', async () => {
  const c = await startKontext();
  const r = await c.d.logbuchSofortStarten({ fahrzeugId: c.boot, verantwortlichId: c.anna, stellvertreterIds: [c.ben], crewIds: [c.cara] });
  assert.ok(r.ok, JSON.stringify(r));
  const a = await c.d.aktivitaetLaden(r.id);
  const w = a.aktuell.werte;
  assert.equal(w.vonDatum, '2026-11-04');
  assert.equal(w.vonZeit, '14:30');
  assert.equal(w.bisDatum, '2026-11-04');
  assert.equal(w.fahrzeugId, c.boot);
  assert.match(w.bezeichnung, /^Ausfahrt Seestern 04\.11\.2026$/);
  assert.equal(w.notiz, 'Ohne Planung gestartet');
  const arten = await c.d.aktivitaetsartenListe();
  assert.equal(arten.find(x => x.objekt.id === w.artId).aktuell.werte.bezeichnung, 'Ausfahrt');
  const rollen = a.besatzung.map(b => b.aktuell.werte.rolle).sort();
  assert.deepEqual(rollen, ['crew', 'stellvertreter', 'verantwortlich']);
  const liste = await c.d.aktivitaetenListe();
  assert.equal(liste.find(x => x.objekt.id === r.id).status, 'laeuft', 'das Cockpit öffnet sich zuerst');
});

test('Logbuch jetzt starten: Fahrzeug und verantwortliche Person sind Pflicht, nichts wird halb angelegt', async () => {
  const c = await startKontext();
  const ohneFz = await c.d.logbuchSofortStarten({ verantwortlichId: c.anna });
  assert.equal(ohneFz.ok, false); assert.ok(ohneFz.fehler.fahrzeugId);
  const ohnePerson = await c.d.logbuchSofortStarten({ fahrzeugId: c.boot });
  assert.equal(ohnePerson.ok, false); assert.ok(ohnePerson.fehler.verantwortlichId);
  const fremd = await c.d.logbuchSofortStarten({ fahrzeugId: c.boot, verantwortlichId: c.anna, crewIds: ['gibt-es-nicht'] });
  assert.equal(fremd.ok, false); assert.ok(fremd.fehler.crewIds);
  assert.equal((await c.d.aktivitaetenListe()).length, 0);
});

test('Logbuch jetzt starten: die verantwortliche Person zählt nicht doppelt, die Art „Ausfahrt“ entsteht nur einmal', async () => {
  const c = await startKontext();
  const r1 = await c.d.logbuchSofortStarten({ fahrzeugId: c.wohnmobil, verantwortlichId: c.anna, stellvertreterIds: [c.anna, c.ben], crewIds: [c.anna, c.ben, c.cara] });
  assert.ok(r1.ok);
  const a = await c.d.aktivitaetLaden(r1.id);
  assert.equal(a.besatzung.length, 3);
  const r2 = await c.d.logbuchSofortStarten({ fahrzeugId: c.wohnmobil, verantwortlichId: c.ben });
  assert.ok(r2.ok);
  const arten = (await c.d.aktivitaetsartenListe()).filter(x => x.aktuell.werte.bezeichnung === 'Ausfahrt');
  assert.equal(arten.length, 1);
});

test('Logbuch jetzt starten: ein eigenes Enddatum wird übernommen, ein Ende vor dem Beginn abgelehnt', async () => {
  const c = await startKontext();
  const lang = await c.d.logbuchSofortStarten({ fahrzeugId: c.boot, verantwortlichId: c.anna, bisDatum: '2026-11-10' });
  assert.ok(lang.ok);
  assert.equal((await c.d.aktivitaetLaden(lang.id)).aktuell.werte.bisDatum, '2026-11-10');
  const falsch = await c.d.logbuchSofortStarten({ fahrzeugId: c.boot, verantwortlichId: c.anna, bisDatum: '2026-11-01' });
  assert.equal(falsch.ok, false);
});

test('Logbuch jetzt starten: das Cockpit trägt sofort ein, mit den Ereignisarten der Fahrzeugart', async () => {
  const c = await startKontext();
  await c.d.ereignisartenVorauswahlUebernehmen();
  const r = await c.d.logbuchSofortStarten({ fahrzeugId: c.boot, verantwortlichId: c.anna });
  const e = await c.d.ereignisSchnell(r.id, 'Abfahrt', {});
  assert.ok(e.ok, JSON.stringify(e));
  const a = await c.d.aktivitaetLaden(r.id);
  assert.equal(a.fahrzeug.artId, 'segelboot-monohull');
  const namen = (await c.d.ereignisartenFuerFahrzeugart(a.fahrzeug.artId)).map(x => x.aktuell.werte.bezeichnung);
  assert.ok(namen.includes('Segel setzen') && !namen.includes('Wasserski-Lauf'));
});
