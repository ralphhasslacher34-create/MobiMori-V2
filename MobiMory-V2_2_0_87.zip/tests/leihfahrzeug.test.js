'use strict';
/* 2.0.80 (Bau 3b): Geliehene Fahrzeuge in der Fahrzeugliste. Eigenes Fahrzeug der Person, zählt nicht zur Grenze, inaktiv nach der Leihe,
   Online-Checks über die Freigabe, Besitzer und seine Historie bleiben unberührt, Einbau in die Seiten. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'reisecheck', 'grundcheck', 'konto', 'freigaben',
  'austausch', 'texte', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
MM.Daten.standardFahrzeuggrenze = 1;

const HEUTE = '2026-11-15';
const FREIGABE = (o) => Object.assign({ id: 'fr-1', fahrzeugId: 'bes-fz-1', name: 'Seeschwalbe', von: 'bes@example.org', ab: '2026-11-20', planAb: '2026-11-15', bis: '2027-01-31', status: 'planung', rechte: 'mitnutzen' }, o || {});
const SICHT = (o) => Object.assign({ ok: true, bis: '2027-01-31', rechte: 'mitnutzen', phase: 'planung', nutzungAb: '2026-11-20', planAb: '2026-11-15',
  sicht: { fahrzeug: { id: 'bes-fz-1', bezeichnung: 'Seeschwalbe', kennung: 'D-1234', art: 'Segelyacht', artId: 'boot', check: { artName: 'Segelyacht', welt: 'wasser', werte: { bezeichnung: 'Seeschwalbe', marke: 'Bavaria', laenge: 9.5 } } } } }, o || {});

/* Ein Gerät der Person; Zustand der Freigaben und des Netzes steuert der Test. */
async function geraet(zustand) {
  const z = Object.assign({ erhalten: [FREIGABE()], netz: true, sicht: SICHT(), stufe: 'basic' }, zustand || {});
  const gesendet = [];
  let n = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), {
    jetzt: () => new Date(new Date(2026, 10, 15, 12, 0, 0).getTime() + (n++) * 1000).toISOString(),
    kontoAnfrage: async (url) => {
      if (url.endsWith('/konto/stufe')) return { ok: true, stufe: { id: 'basic', name: 'Basic', bis: null }, grenzen: { geraete: 2, checks: 0, fahrzeuge: 1, online: false }, nutzung: { geraete: 1, checks: 0, checksFrei: 0, zeitraumTage: 365 } };
      throw new Error('unerwartet ' + url);
    }
  });
  await d.starten();
  d.heute = () => HEUTE;
  await d.rcSchreiben({ kontoToken: 'tok', kontoEmail: 'gast@example.org', kontoDatenraumId: 'dr-gast', reisecheckZustimmungen: [{ aktion: 'zugestimmt', version: MM.Reisecheck.ZUSTIMMUNG_VERSION, am: '2026-11-14T09:00:00.000Z' }] });
  d.freigabeListe = async () => z.netz ? { ok: true, gegeben: [], erhalten: z.erhalten, kontrollen: [], verleih: null } : { ok: false, offline: true, fehler: { allgemein: 'Kein Netz' } };
  d.geteiltLaden = async () => z.netz ? z.sicht : { ok: false, offline: true, fehler: { allgemein: 'Kein Netz' } };
  d.kontoSenden = async (m, weg, body) => { gesendet.push([m, weg, body]); return { ok: false, status: 500, fehler: 'Testende' }; };
  return { d, z, gesendet };
}
const eigenes = (d, name) => d.fahrzeugAnlegen('boot', { bezeichnung: name });

test('Abgleich legt das geliehene Fahrzeug an, nur einmal, mit Angaben des Besitzers, ohne etwas an den Dienst zu schicken', async () => {
  const { d, gesendet } = await geraet();
  const r = await d.leihSynchronisieren({ erzwingen: true });
  assert.equal(r.ok, true); assert.equal(r.neu, 1);
  let l = await d.leihFahrzeuge();
  assert.equal(l.length, 1);
  const fz = l[0];
  assert.equal(fz.aktuell.werte.bezeichnung, 'Seeschwalbe'); assert.equal(fz.aktuell.werte.marke, 'Bavaria'); assert.equal(fz.fahrzeug.art, 'boot');
  assert.equal(fz.fahrzeug.geliehen.freigabeId, 'fr-1'); assert.equal(fz.fahrzeug.geliehen.von, 'bes@example.org'); assert.equal(fz.fahrzeug.geliehen.rechte, 'mitnutzen');
  assert.equal(fz.fahrzeug.geliehen.beendetAm, null); assert.ok(!fz.fahrzeug.abgabe);
  assert.equal(fz.fahrzeug.datenraumId, d.datenraumId, 'liegt im Datenraum der Person');
  assert.equal(gesendet.length, 0, 'es geht nichts an den Dienst');
  /* nochmal: kein zweites Fahrzeug */
  await d.leihSynchronisieren({ erzwingen: true });
  assert.equal((await d.leihFahrzeuge()).length, 1);
  assert.equal((await d.fahrzeugListe()).length, 1, 'steht in der normalen Fahrzeugliste');
  const info = d.leihInfo(fz.fahrzeug);
  assert.equal(info.beendet, false); assert.equal(info.bis, '2027-01-31');
});

test('Zwei Aufrufe gleichzeitig legen kein doppeltes Fahrzeug an; ohne Abstand wird nicht ständig abgefragt', async () => {
  const { d } = await geraet();
  await Promise.all([d.leihSynchronisieren({ erzwingen: true }), d.leihSynchronisieren({ erzwingen: true })]);
  assert.equal((await d.leihFahrzeuge()).length, 1);
  let aufrufe = 0; const alt = d.freigabeListe; d.freigabeListe = async () => { aufrufe++; return alt(); };
  const r = await d.leihSynchronisieren();
  assert.equal(r.uebersprungen, true); assert.equal(aufrufe, 0);
});

test('Geliehene Fahrzeuge zählen nicht zur Fahrzeuggrenze; die eigenen schon', async () => {
  const { d } = await geraet();
  await d.leihSynchronisieren({ erzwingen: true });
  assert.equal((await d.fahrzeugGrenzePruefen(1)).ok, true, 'Basic erlaubt 1, geliehen zählt nicht');
  assert.equal((await eigenes(d, 'Mein Boot')).ok, true);
  const r = await eigenes(d, 'Noch ein Boot');
  assert.equal(r.ok, false); assert.equal(r.grenze.anzahl, 1, 'gezählt wird nur das eigene');
  assert.equal((await d.fahrzeugListe()).length, 2);
});

test('Noch nicht in der Planung (wartet) oder nicht angenommen: kein Fahrzeug; ohne Konto oder ohne Netz geschieht nichts', async () => {
  let t = await geraet({ erhalten: [FREIGABE({ status: 'wartet' }), FREIGABE({ id: 'fr-2', status: 'eingeladen' })] });
  assert.equal((await t.d.leihSynchronisieren({ erzwingen: true })).neu, 0);
  assert.equal((await t.d.leihFahrzeuge()).length, 0);
  t = await geraet({ netz: false });
  const r = await t.d.leihSynchronisieren({ erzwingen: true });
  assert.equal(r.ok, false); assert.equal((await t.d.leihFahrzeuge()).length, 0);
  t = await geraet();
  await t.d.rcSchreiben({ kontoToken: '', kontoEmail: '' });
  assert.equal((await t.d.leihSynchronisieren({ erzwingen: true })).ok, false);
  assert.equal((await t.d.leihFahrzeuge()).length, 0);
});

test('Ende der Freigabe: das Fahrzeug wird inaktiv und bleibt lesbar; ohne Netz wird nichts beendet', async () => {
  const t = await geraet();
  await t.d.leihSynchronisieren({ erzwingen: true });
  const id = (await t.d.leihFahrzeuge())[0].fahrzeug.id;
  /* eigener Eintrag bei dem geliehenen Fahrzeug */
  assert.ok((await t.d.zaehlerListe(id)) !== undefined);
  t.z.netz = false;
  await t.d.leihSynchronisieren({ erzwingen: true });
  assert.ok(!(await t.d.speicher.holen('fahrzeuge', id)).abgabe, 'ohne Netz bleibt es aktiv');
  t.z.netz = true; t.z.erhalten = [FREIGABE({ status: 'abgelaufen', bis: '2026-12-31' })];
  const r = await t.d.leihSynchronisieren({ erzwingen: true });
  assert.equal(r.beendet, 1);
  const fz = await t.d.speicher.holen('fahrzeuge', id);
  assert.equal(fz.abgabe.grund, 'leihende'); assert.equal(fz.abgabe.datum, '2026-11-15', 'Datum ist höchstens heute'); assert.equal(fz.geliehen.beendetAm, '2026-11-15');
  assert.equal((await t.d.fahrzeugListe()).length, 0, 'inaktive stehen nicht mehr zur Auswahl');
  assert.equal((await t.d.fahrzeugListe({ alle: true })).length, 1, 'bleiben aber erhalten');
  assert.equal((await t.d.fahrzeugLaden(id)).aktuell.werte.bezeichnung, 'Seeschwalbe', 'Lesen geht');
  assert.equal(t.d.leihInfo(fz).beendet, true);
  /* eine widerrufene Freigabe fehlt in der Liste: ebenfalls beendet (hier: noch ein zweites Fahrzeug) */
  const t2 = await geraet();
  await t2.d.leihSynchronisieren({ erzwingen: true });
  t2.z.erhalten = [];
  assert.equal((await t2.d.leihSynchronisieren({ erzwingen: true })).beendet, 1);
});

test('Wird dasselbe Fahrzeug erneut geliehen, wird derselbe Platz wieder aktiv; die Angaben werden nachgezogen, nichts geht verloren', async () => {
  const t = await geraet();
  await t.d.leihSynchronisieren({ erzwingen: true });
  const id = (await t.d.leihFahrzeuge())[0].fahrzeug.id;
  t.z.erhalten = [];
  await t.d.leihSynchronisieren({ erzwingen: true });
  assert.ok((await t.d.speicher.holen('fahrzeuge', id)).abgabe);
  t.z.erhalten = [FREIGABE({ id: 'fr-9', status: 'aktiv', ab: '2026-12-01', bis: '2027-03-01' })];
  t.z.sicht = SICHT({ bis: '2027-03-01', phase: 'nutzung', sicht: { fahrzeug: Object.assign({}, SICHT().sicht.fahrzeug, { bezeichnung: 'Seeschwalbe II', check: { artName: 'Segelyacht', welt: 'wasser', werte: { bezeichnung: 'Seeschwalbe II', marke: 'Bavaria' } } }) } });
  const r = await t.d.leihSynchronisieren({ erzwingen: true });
  assert.equal(r.neu, 0);
  const l = await t.d.leihFahrzeuge();
  assert.equal(l.length, 1, 'kein zweites Fahrzeug'); assert.equal(l[0].fahrzeug.id, id);
  assert.ok(!l[0].fahrzeug.abgabe); assert.equal(l[0].fahrzeug.geliehen.freigabeId, 'fr-9'); assert.equal(l[0].fahrzeug.abgabeVerlauf.length, 1); assert.equal(l[0].fahrzeug.abgabeVerlauf[0].grund, 'leihende');
  assert.equal(l[0].aktuell.werte.bezeichnung, 'Seeschwalbe II'); assert.equal(l[0].aktuell.nr, 2, 'neuer Stand, der alte bleibt im Verlauf');
  assert.equal((await t.d.fahrzeugLaden(id)).verlauf.length, 2);
});

test('Geliehene Fahrzeuge lassen sich nicht abgeben, nicht ändern, nicht verleihen und nicht von Hand wieder aktiv setzen', async () => {
  const t = await geraet();
  await t.d.leihSynchronisieren({ erzwingen: true });
  const id = (await t.d.leihFahrzeuge())[0].fahrzeug.id;
  assert.match((await t.d.fahrzeugAbgeben(id, { datum: HEUTE, grund: 'verkauft' })).fehler.allgemein, /geliehen/);
  assert.match((await t.d.fahrzeugAendern(id, { bezeichnung: 'Meins' })).fehler.allgemein, /geliehen/);
  assert.deepEqual(await t.d.freigabeFahrzeuge(), [], 'steht nicht zur Auswahl für Verleih und Kontroll-Code');
  t.z.erhalten = []; await t.d.leihSynchronisieren({ erzwingen: true });
  assert.match((await t.d.fahrzeugWiederAktiv(id)).fehler.allgemein, /neuen Freigabe/);
  assert.equal((await t.d.fahrzeugLaden(id)).aktuell.werte.bezeichnung, 'Seeschwalbe', 'nichts hat sich geändert');
});

test('Online-Check: eigenes Fahrzeug über das eigene Konto, geliehenes über die Freigabe (Kontingent des Besitzers), nach dem Ende gar nicht', async () => {
  const t = await geraet();
  await t.d.leihSynchronisieren({ erzwingen: true });
  const eig = (await eigenes(t.d, 'Mein Boot')).id, geli = (await t.d.leihFahrzeuge())[0].fahrzeug.id;
  assert.deepEqual(await t.d.leihCheckWeg(eig), { freigabeId: null });
  assert.deepEqual(await t.d.leihCheckWeg(geli), { freigabeId: 'fr-1' });
  assert.deepEqual(await t.d.leihCheckWeg('gibt-es-nicht'), { freigabeId: null });
  t.z.erhalten = []; await t.d.leihSynchronisieren({ erzwingen: true });
  assert.match((await t.d.leihCheckWeg(geli)).fehler, /zu Ende/);
  /* Der Grundcheck sendet nichts mehr */
  const n = t.gesendet.length;
  const r = await t.d.grundcheckStarten(geli);
  assert.equal(r.ok, false);
  assert.equal(t.gesendet.length, n, 'nach dem Ende geht kein Check an den Dienst');
});

test('Grundcheck am geliehenen Fahrzeug geht mit der Freigabe an den Dienst', async () => {
  const t = await geraet();
  await t.d.leihSynchronisieren({ erzwingen: true });
  const geli = (await t.d.leihFahrzeuge())[0].fahrzeug.id, eig = (await eigenes(t.d, 'Mein Boot')).id;
  t.d.grundcheckAnfrage = async () => ({ ok: true, fehler: [], eingabe: { fahrzeug: { abgegeben: false } }, anfrage: { trip: { areas: [{ name: 'Dänemark' }] } }, vorschau: {}, stand: 's1' });
  await t.d.grundcheckStarten(eig);
  await t.d.grundcheckStarten(geli);
  const checks = t.gesendet.filter((x) => x[1] === '/check/senden');
  assert.equal(checks.length, 2);
  assert.equal(checks[0][2].freigabe, undefined, 'eigenes Fahrzeug: über das eigene Konto');
  assert.equal(checks[1][2].freigabe, 'fr-1', 'geliehenes Fahrzeug: über die Freigabe, zählt beim Besitzer');
});

test('Besitzer und Historie bleiben unberührt: nichts Eigenes der Person geht an den Dienst, die Sicherung enthält das geliehene Fahrzeug nur bei der Person', async () => {
  const t = await geraet();
  await t.d.leihSynchronisieren({ erzwingen: true });
  const id = (await t.d.leihFahrzeuge())[0].fahrzeug.id;
  assert.equal(t.gesendet.length, 0, 'das geliehene Fahrzeug geht nie an den Dienst');
  const alle = await t.d.speicher.alleTabellen();
  assert.ok(alle.fahrzeuge.some((f) => f.id === id && f.geliehen), 'liegt in der Sicherung der Person');
  /* Kein Weg schreibt ins Fahrzeug des Besitzers außer geteiltErfassen (mitnutzen, 2.0.75) */
  const daten = lesen('js/daten.js');
  const block = daten.slice(daten.indexOf('Geliehene Fahrzeuge in der Fahrzeugliste (2.0.80'), daten.indexOf('Reisebuch (2.0.81, Bau 4)'));
  assert.ok(!/kontoSenden\('POST'/.test(block), 'der Abgleich der geliehenen Fahrzeuge schreibt nie zum Dienst');
  assert.ok(!block.includes('geteiltErfassen'), 'und trägt nie beim Besitzer ein');
});

test('Einbau: Block „Geliehen“, Hinweis auf der Fahrzeugseite, Schutz der Abgeben-Seiten, Texte, Version 2.0.80', () => {
  const a = lesen('js/ansicht.js'), c = lesen('CHANGELOG.md');
  ['function leihBanner', 'function leihZeile', "h2', { text: 'Geliehen' }", 'daten.leihSynchronisieren(', 'mitZeitgrenze(', 'Beim Besitzer eintragen', 'Leihe beendet', "f.fahrzeug.geliehen) { global.location.hash",
    'Art unbekannt', 'In meiner Fahrzeugliste'].forEach((s) => assert.ok(a.includes(s), s));
  assert.ok(c.includes('## 2.0.80\n- **Bau 3b'));
  assert.ok(MM.Texte.NEUERUNGEN[7].version === '2.0.80' && /Geliehen/.test(MM.Texte.NEUERUNGEN[7].punkte.join(' ')));
  assert.equal(MM.VERSION, '2.0.87');
  assert.ok(lesen('js/freigaben.js').includes('artId: fzRec.art || null'));
  assert.ok(lesen('docs/SCHRITTE.md').includes('13f-5'));
});

/* ---- Die echten Funktionen der Seiten (aus ansicht.js herausgeschnitten) mit einem kleinen Ersatz für den Browser ---- */
function neuesElement(tag) {
  const e = { tag, kinder: [], attrs: {} };
  e.appendChild = (k) => { e.kinder.push(k); return k; };
  return e;
}
function hBauen() {
  return function h(tag, attrs) {
    const e = neuesElement(tag);
    if (attrs) Object.keys(attrs).forEach((k) => { const v = attrs[k]; if (v === null || v === undefined || v === false) return; if (k === 'text') e.kinder.push(String(v)); else e.attrs[k] = v; });
    const rein = (k) => { if (k === null || k === undefined) return; if (Array.isArray(k)) k.forEach(rein); else e.kinder.push(k); };
    for (let i = 2; i < arguments.length; i++) rein(arguments[i]);
    return e;
  };
}
const text = (e) => (typeof e === 'string' ? e : (e && e.kinder ? e.kinder.map(text).join(' ') : ''));
const finde = (e, fn, aus) => { aus = aus || []; if (!e || typeof e === 'string' || !e.kinder) return aus; if (fn(e)) aus.push(e); e.kinder.forEach((k) => finde(k, fn, aus)); return aus; };

function schnitt(von, bis) {
  const q = lesen('js/ansicht.js'), a = q.indexOf(von), b = q.indexOf(bis, a);
  assert.ok(a > 0 && b > a, von);
  return q.slice(a, b);
}

test('Fahrzeugliste: Block „Geliehen“ unter den eigenen, inaktive gekennzeichnet, nichts Abgegebenes vermischt, Art unbekannt stürzt nicht ab', async () => {
  const t = await geraet();
  await t.d.leihSynchronisieren({ erzwingen: true });
  await eigenes(t.d, 'Mein Boot');
  /* eine abgegebene eigene Yacht und ein zweites, beendetes geliehenes Fahrzeug */
  t.z.erhalten = [FREIGABE(), FREIGABE({ id: 'fr-2', fahrzeugId: 'bes-fz-2', status: 'aktiv', ab: '2026-11-01', bis: '2026-12-31', von: 'oma@example.org' })];
  t.z.sicht = SICHT({ sicht: { fahrzeug: Object.assign({}, SICHT().sicht.fahrzeug, { bezeichnung: 'Omas Wohnmobil', artId: 'gibt-es-nicht' }) } });
  await t.d.leihSynchronisieren({ erzwingen: true });
  t.z.erhalten = [FREIGABE({ status: 'aktiv', ab: '2026-11-01' })];
  await t.d.leihSynchronisieren({ erzwingen: true });
  const quelle = schnitt('  function mitZeitgrenze(p, ms) {', '  /* ---------- Fristen und Zähler: gemeinsame Bausteine ---------- */');
  const h = hBauen(), seiten = [];
  const f = new Function('MM', 'h', 'daten', 'krumen', 'WEG_FAHRZEUGE', 'fristHinweis', 'nachweisHinweis', 'schild', 'kennungVon', 'GRUND_WORT', 'seite',
    quelle + '\n  return seiteListe;');
  const seiteListe = f(MM, h, t.d, () => h('nav'), [['a'], ['b'], ['c']], () => null, () => null, () => h('span'), () => '', { leihende: 'Leihe beendet', verkauft: 'Verkauft' }, (titel, inhalt) => { seiten.push({ titel, inhalt }); });
  await seiteListe();
  const inhalt = seiten[0].inhalt, alles = inhalt.map(text).join('\n');
  const bloecke = finde({ kinder: inhalt, tag: 'x', attrs: {} }, (e) => e.attrs && e.attrs['aria-label'] === 'Geliehen');
  assert.equal(bloecke.length, 1, 'ein Block „Geliehen“');
  const bt = text(bloecke[0]);
  assert.match(bt, /Geliehen/); assert.match(bt, /zählen nicht zu deiner Fahrzeuggrenze/); assert.match(bt, /Seeschwalbe/);
  assert.match(bt, /geliehen von bes@example\.org bis 31\.01\.2027/);
  assert.ok(!/Omas Wohnmobil/.test(bt), 'beendete Leihen stehen nicht im Block (seit 2.0.87)');
  assert.match(alles, /Beendete Leihen \(1\)/); assert.match(alles, /Omas Wohnmobil.*inaktiv, Leihe beendet am/s);
  assert.ok(!/Mein Boot/.test(bt), 'eigene Fahrzeuge stehen nicht im Block');
  assert.match(alles, /Mein Boot/);
  assert.ok(!/Abgegebene Fahrzeuge/.test(alles), 'beendete Leihen sind keine „Abgegebenen“');
  assert.ok(!/Hier ist noch kein Fahrzeug/.test(alles));
  const zeilen = finde({ kinder: inhalt, tag: 'x', attrs: {} }, (e) => e.tag === 'li');
  assert.equal(zeilen.filter((z) => z.attrs.class === 'inaktiv').length, 1);
});

test('Fahrzeugliste mit nur geliehenen Fahrzeugen: kein Leer-Hinweis, kein leerer Listenrahmen', async () => {
  const t = await geraet();
  await t.d.leihSynchronisieren({ erzwingen: true });
  const quelle = schnitt('  function mitZeitgrenze(p, ms) {', '  /* ---------- Fristen und Zähler: gemeinsame Bausteine ---------- */');
  const h = hBauen(), seiten = [];
  const f = new Function('MM', 'h', 'daten', 'krumen', 'WEG_FAHRZEUGE', 'fristHinweis', 'nachweisHinweis', 'schild', 'kennungVon', 'GRUND_WORT', 'seite', quelle + '\n  return seiteListe;');
  await f(MM, h, t.d, () => h('nav'), [['a'], ['b'], ['c']], () => null, () => null, () => h('span'), () => '', {}, (titel, inhalt) => { seiten.push(inhalt); })();
  const alles = seiten[0].map(text).join('\n');
  assert.ok(!/noch kein Fahrzeug/.test(alles)); assert.match(alles, /Seeschwalbe/);
  const listen = finde({ kinder: seiten[0], tag: 'x', attrs: {} }, (e) => e.tag === 'ul' && e.attrs.class === 'liste');
  assert.ok(listen.every((l) => l.kinder.length > 0), 'keine leere Liste');
});

test('Fahrzeugseite: Hinweis „Geliehen“ mit den richtigen Wegen, nach der Leihe „inaktiv“ ohne Eintragen', async () => {
  const t = await geraet();
  await t.d.leihSynchronisieren({ erzwingen: true });
  const quelle = schnitt('  /* Geliehenes Fahrzeug (seit 2.0.80, Bau 3b)', '  /* Hinweis oben auf der Fahrzeugseite: abgegeben');
  const h = hBauen();
  const baue = new Function('MM', 'h', 'daten', quelle + '\n  return leihBanner;');
  const banner = baue(MM, h, t.d);
  let f = (await t.d.leihFahrzeuge())[0];
  let tx = text(banner(f));
  assert.match(tx, /Geliehen von bes@example\.org/); assert.match(tx, /Planung läuft. Der Verleih beginnt am 20\.11\.2026/);
  assert.match(tx, /Im Fahrzeug des Besitzers trägst du erst ab dem Verleih etwas ein/); assert.match(tx, /Fahrzeug des Besitzers ansehen/); assert.doesNotMatch(tx, /Meine Reise/);
  assert.match(tx, /bleiben bei dir, der Besitzer sieht sie nie/); assert.match(tx, /Kontingent des Besitzers/);
  const links = finde(banner(f), (e) => e.tag === 'a').map((e) => e.attrs.href);
  assert.deepEqual(links, ['#/geteilt/fr-1']);
  /* im Verleih mit Mitnutzung */
  t.d.heute = () => '2026-11-21';
  tx = text(banner(f));
  assert.match(tx, /Verleih seit 20\.11\.2026 bis 31\.01\.2027/); assert.match(tx, /Beim Besitzer eintragen/); assert.match(tx, /bleiben in seiner Fahrzeug-Historie/);
  /* nach dem Ende */
  t.z.erhalten = []; await t.d.leihSynchronisieren({ erzwingen: true });
  f = (await t.d.leihFahrzeuge())[0];
  const b = banner(f);
  tx = text(b);
  assert.match(tx, /Leihe beendet am 21\.11\.2026/); assert.match(tx, /inaktiv/); assert.match(tx, /keine Online-Checks/); assert.match(tx, /Es bleibt bei dir/);
  assert.deepEqual(finde(b, (e) => e.tag === 'a').map((e) => e.attrs.href), []);
});
