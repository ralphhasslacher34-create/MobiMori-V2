/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.81';
  MM.STUFE = 'Geliehene Fahrzeuge in der Fahrzeugliste: Planung, Logbuch, Reisen und Kosten wie bei eigenen, inaktiv nach der Leihe';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
