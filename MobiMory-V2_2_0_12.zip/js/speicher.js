/*
 * Speicher: der Ort, an dem die Daten auf dem Gerät liegen.
 *
 * Es gibt zwei Ausführungen mit denselben Aufrufen:
 *  - IdbSpeicher: der echte Speicher im Gerät (IndexedDB), funktioniert offline
 *  - MemorySpeicher: nur für die automatischen Tests
 *
 * Alle anderen Teile der App sprechen nur mit Daten (daten.js) und nie
 * direkt mit dem Speicher. Das ist die "eine Tür". Kommt später der Server
 * dazu, wird hier ein weiterer Speicher mit denselben Aufrufen ergänzt.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var DB_VERSION = 8;

  var TABELLEN = ['datenraeume', 'fahrzeuge', 'eintraege', 'komponenten', 'komponenteneintraege',
    'zaehler', 'zaehlerstaende', 'fristen', 'verlaeufe', 'durchfuehrungen', 'dokumente', 'dateien',
    'personen', 'tiere', 'nachweisarten', 'nachweise', 'nachweisdateien',
    'aktivitaeten', 'aktivitaetsarten', 'besatzung', 'verantwortung', 'anforderungen', 'einstellungen',
    'orte', 'standorte', 'gebiete', 'regeln'];

  /* Kopie eines Eintrags. Dateien (Blob) und Binärdaten bleiben unverändert dieselben Objekte. */
  function klon(o) {
    if (o === null || typeof o !== 'object') return o;
    if (Array.isArray(o)) return o.map(klon);
    if ((typeof Blob !== 'undefined' && o instanceof Blob) || o instanceof ArrayBuffer || ArrayBuffer.isView(o)) return o;
    var k = {};
    Object.keys(o).forEach(function (n) { k[n] = klon(o[n]); });
    return k;
  }

  /* ---- Speicher nur im Arbeitsspeicher (Tests) ---- */
  function MemorySpeicher() {
    this.t = {};
    TABELLEN.forEach(function (n) { this.t[n] = {}; }, this);
  }
  MemorySpeicher.prototype.alle = function (tabelle) {
    var t = this.t[tabelle];
    return Promise.resolve(Object.keys(t).map(function (k) { return klon(t[k]); }));
  };
  MemorySpeicher.prototype.holen = function (tabelle, id) {
    var o = this.t[tabelle][id];
    return Promise.resolve(o ? klon(o) : null);
  };
  MemorySpeicher.prototype.speichern = function (tabelle, objekt) {
    this.t[tabelle][objekt.id] = klon(objekt);
    return Promise.resolve();
  };
  MemorySpeicher.prototype.mehrereSpeichern = function (liste) {
    liste.forEach(function (e) { this.t[e.tabelle][e.objekt.id] = klon(e.objekt); }, this);
    return Promise.resolve();
  };
  MemorySpeicher.prototype.wo = function (tabelle, feld, wert) {
    return this.alle(tabelle).then(function (l) {
      return l.filter(function (o) { return o[feld] === wert; });
    });
  };
  MemorySpeicher.prototype.alleTabellen = function () {
    var res = {};
    TABELLEN.forEach(function (n) { res[n] = Object.keys(this.t[n]).map(function (k) { return klon(this.t[n][k]); }, this); }, this);
    return Promise.resolve(res);
  };
  /* Ersetzt alles auf einmal. Fehler vorher: nichts wird verändert. */
  MemorySpeicher.prototype.ersetzenAlles = function (tabellen) {
    var neu = {};
    TABELLEN.forEach(function (n) { neu[n] = {}; });
    var unbekannt = Object.keys(tabellen).filter(function (n) { return TABELLEN.indexOf(n) < 0; });
    if (unbekannt.length) return Promise.reject(new Error('Unbekannte Tabelle: ' + unbekannt[0]));
    Object.keys(tabellen).forEach(function (n) { tabellen[n].forEach(function (o) { neu[n][o.id] = klon(o); }); });
    this.t = neu;
    return Promise.resolve();
  };
  MemorySpeicher.prototype.allesLoeschen = function () {
    TABELLEN.forEach(function (n) { this.t[n] = {}; }, this);
    return Promise.resolve();
  };

  /* ---- Speicher im Gerät (IndexedDB) ---- */
  function IdbSpeicher(name) {
    this.name = name || 'mobimory-v2';
    this.db = null;
  }
  IdbSpeicher.prototype.oeffnen = function () {
    var self = this;
    return new Promise(function (ok, fehler) {
      if (typeof indexedDB === 'undefined') {
        fehler(new Error('Dieses Gerät oder dieser Browser kann keine Daten speichern.'));
        return;
      }
      /* Datenbank-Version 8. Jede Version hat ihren eigenen Umstellungsschritt.
         Bestehende Daten bleiben dabei erhalten. */
      var anfrage = indexedDB.open(self.name, DB_VERSION);
      anfrage.onupgradeneeded = function (ev) {
        var db = anfrage.result;
        var von = ev.oldVersion;
        if (von < 1) {
          db.createObjectStore('datenraeume', { keyPath: 'id' });
          db.createObjectStore('fahrzeuge', { keyPath: 'id' });
          var e = db.createObjectStore('eintraege', { keyPath: 'id' });
          e.createIndex('fahrzeugId', 'fahrzeugId');
        }
        if (von < 2) {
          var k = db.createObjectStore('komponenten', { keyPath: 'id' });
          k.createIndex('fahrzeugId', 'fahrzeugId');
          var ke = db.createObjectStore('komponenteneintraege', { keyPath: 'id' });
          ke.createIndex('komponenteId', 'komponenteId');
        }
        if (von < 3) {
          db.createObjectStore('zaehler', { keyPath: 'id' }).createIndex('fahrzeugId', 'fahrzeugId');
          db.createObjectStore('zaehlerstaende', { keyPath: 'id' }).createIndex('zaehlerId', 'zaehlerId');
          db.createObjectStore('fristen', { keyPath: 'id' }).createIndex('fahrzeugId', 'fahrzeugId');
          db.createObjectStore('verlaeufe', { keyPath: 'id' }).createIndex('objektId', 'objektId');
          db.createObjectStore('durchfuehrungen', { keyPath: 'id' }).createIndex('fristId', 'fristId');
        }
        if (von < 4) {
          db.createObjectStore('dokumente', { keyPath: 'id' }).createIndex('fahrzeugId', 'fahrzeugId');
          db.createObjectStore('dateien', { keyPath: 'id' }).createIndex('dokumentId', 'dokumentId');
        }
        if (von < 5) {
          db.createObjectStore('personen', { keyPath: 'id' });
          db.createObjectStore('tiere', { keyPath: 'id' });
          db.createObjectStore('nachweisarten', { keyPath: 'id' });
          db.createObjectStore('nachweise', { keyPath: 'id' }).createIndex('besitzerId', 'besitzerId');
          db.createObjectStore('nachweisdateien', { keyPath: 'id' }).createIndex('nachweisId', 'nachweisId');
        }
        if (von < 6) {
          db.createObjectStore('aktivitaeten', { keyPath: 'id' });
          db.createObjectStore('aktivitaetsarten', { keyPath: 'id' });
          db.createObjectStore('besatzung', { keyPath: 'id' }).createIndex('aktivitaetId', 'aktivitaetId');
          db.createObjectStore('verantwortung', { keyPath: 'id' }).createIndex('aktivitaetId', 'aktivitaetId');
          db.createObjectStore('anforderungen', { keyPath: 'id' }).createIndex('fahrzeugId', 'fahrzeugId');
        }
        if (von < 7) {
          db.createObjectStore('einstellungen', { keyPath: 'id' });
        }
        if (von < 8) {
          db.createObjectStore('orte', { keyPath: 'id' });
          db.createObjectStore('standorte', { keyPath: 'id' }).createIndex('ortId', 'ortId');
          db.createObjectStore('gebiete', { keyPath: 'id' });
          db.createObjectStore('regeln', { keyPath: 'id' }).createIndex('gebietId', 'gebietId');
        }
      };
      anfrage.onsuccess = function () { self.db = anfrage.result; ok(self); };
      anfrage.onerror = function () { fehler(anfrage.error || new Error('Speicher konnte nicht geöffnet werden.')); };
      anfrage.onblocked = function () { fehler(new Error('Der Speicher ist durch ein anderes Fenster blockiert. Bitte andere MobiMory-Fenster schließen.')); };
    });
  };
  function warten(anfrage) {
    return new Promise(function (ok, fehler) {
      anfrage.onsuccess = function () { ok(anfrage.result); };
      anfrage.onerror = function () { fehler(anfrage.error); };
    });
  }
  IdbSpeicher.prototype.alle = function (tabelle) {
    return warten(this.db.transaction(tabelle).objectStore(tabelle).getAll());
  };
  IdbSpeicher.prototype.holen = function (tabelle, id) {
    return warten(this.db.transaction(tabelle).objectStore(tabelle).get(id)).then(function (o) { return o || null; });
  };
  IdbSpeicher.prototype.speichern = function (tabelle, objekt) {
    return this.mehrereSpeichern([{ tabelle: tabelle, objekt: objekt }]);
  };
  IdbSpeicher.prototype.mehrereSpeichern = function (liste) {
    var db = this.db;
    return new Promise(function (ok, fehler) {
      var namen = liste.map(function (e) { return e.tabelle; })
        .filter(function (n, i, a) { return a.indexOf(n) === i; });
      var tx = db.transaction(namen, 'readwrite');
      liste.forEach(function (e) { tx.objectStore(e.tabelle).put(e.objekt); });
      tx.oncomplete = function () { ok(); };
      tx.onerror = function () { fehler(tx.error); };
      tx.onabort = function () { fehler(tx.error || new Error('Speichern abgebrochen.')); };
    });
  };
  IdbSpeicher.prototype.wo = function (tabelle, feld, wert) {
    var store = this.db.transaction(tabelle).objectStore(tabelle);
    if (store.indexNames.contains(feld)) { return warten(store.index(feld).getAll(wert)); }
    return this.alle(tabelle).then(function (l) { return l.filter(function (o) { return o[feld] === wert; }); });
  };
  /* Alle Tabellen in einem Rutsch, ein gleichzeitiger Stand. */
  IdbSpeicher.prototype.alleTabellen = function () {
    var db = this.db;
    return new Promise(function (ok, fehler) {
      var tx = db.transaction(TABELLEN, 'readonly');
      var res = {};
      TABELLEN.forEach(function (n) {
        var a = tx.objectStore(n).getAll();
        a.onsuccess = function () { res[n] = a.result; };
      });
      tx.oncomplete = function () { ok(res); };
      tx.onerror = function () { fehler(tx.error); };
      tx.onabort = function () { fehler(tx.error || new Error('Lesen abgebrochen.')); };
    });
  };
  /* Ersetzt alles in EINER Transaktion: gelingt nicht alles, bleibt der alte Stand erhalten. */
  IdbSpeicher.prototype.ersetzenAlles = function (tabellen) {
    var db = this.db;
    return new Promise(function (ok, fehler) {
      var unbekannt = Object.keys(tabellen).filter(function (n) { return TABELLEN.indexOf(n) < 0; });
      if (unbekannt.length) { fehler(new Error('Unbekannte Tabelle: ' + unbekannt[0])); return; }
      var tx = db.transaction(TABELLEN, 'readwrite');
      TABELLEN.forEach(function (n) {
        var st = tx.objectStore(n);
        st.clear();
        (tabellen[n] || []).forEach(function (o) { st.put(o); });
      });
      tx.oncomplete = function () { ok(); };
      tx.onerror = function () { fehler(tx.error); };
      tx.onabort = function () { fehler(tx.error || new Error('Wiederherstellen abgebrochen. Es wurde nichts verändert.')); };
    });
  };
  IdbSpeicher.prototype.allesLoeschen = function () {
    var db = this.db;
    return new Promise(function (ok, fehler) {
      var tx = db.transaction(TABELLEN, 'readwrite');
      TABELLEN.forEach(function (n) { tx.objectStore(n).clear(); });
      tx.oncomplete = function () { ok(); };
      tx.onerror = function () { fehler(tx.error); };
    });
  };

  MM.Speicher = { MemorySpeicher: MemorySpeicher, IdbSpeicher: IdbSpeicher, DB_VERSION: DB_VERSION, TABELLEN: TABELLEN.slice() };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
