/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.12';
  MM.STUFE = 'Ausrüstung: Anzahl, Soll und Ist';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
