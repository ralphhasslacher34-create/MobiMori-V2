'use strict';
/* 2.0.116: Kurswechsel (Knopf, Grund, Kurs über Grund, Kartenzeichen KW) und Wechselpunkte aus der GPX (Zusammenfassen, Soll-Kurs, Namen, Meldung). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status',
  'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'kartenereignisse', 'texte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = p => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

/* Die NavShip-Datei von Ralph (19.11.2026): Point-2 bis Point-5 liegen auf derselben Stelle. */
const NAVSHIP = `<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<gpx version="1.1" creator="NavShip - CproSoft GmbH">
    <rte>
        <name>Main Route</name>
        <rtept lat="43.8625602722168" lon="8.054025650024414">
            <ele>0</ele>
            <name>Point-1</name>
        </rtept>
        <rtept lat="44.33528137207031" lon="8.956028938293457">
            <ele>0</ele>
            <name>Point-2</name>
        </rtept>
        <rtept lat="44.33528137207031" lon="8.956028938293457">
            <ele>0</ele>
            <name>Point-3</name>
        </rtept>
        <rtept lat="44.33528137207031" lon="8.956028938293457">
            <ele>0</ele>
            <name>Point-4</name>
        </rtept>
        <rtept lat="44.33528137207031" lon="8.956028938293457">
            <ele>0</ele>
            <name>Point-5</name>
        </rtept>
        <rtept lat="42.7376708984375" lon="9.211250305175781">
            <ele>0</ele>
            <name>Point-6</name>
        </rtept>
    </rte>
</gpx>
`;
/* Eine aufgezeichnete Spur im Aufbau des Navionics-Archiv-Exports: keine geplante Route. */
const SPUR = `<?xml version="1.0" encoding="UTF-8" ?><gpx xmlns="http://www.topografix.com/GPX/1/1" version="1.1" creator="Navionics Boating App"><trk><name>Spur</name><trkseg><trkpt lat="44.16" lon="15.59"><time>2023-07-18T03:14:26.373Z</time></trkpt><trkpt lat="44.17" lon="15.60"><time>2023-07-18T03:14:27.373Z</time></trkpt><trkpt lat="44.18" lon="15.61"><time>2023-07-18T03:14:28.373Z</time></trkpt></trkseg></trk></gpx>`;

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 3, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (std, min) => { uhr.ms = new Date(2026, 10, 3, std, min, 0).getTime(); };
  return d;
}
async function mitFahrzeug(art) {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen(art || 'motorboot', { bezeichnung: 'Fahrzeug' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Sommertörn', artId: toern, fahrzeugId: fz, vonDatum: '2026-11-03', vonZeit: '09:00', bisDatum: '2026-11-05', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok);
  await d.heutigerTag(r.id);
  return { d, id: r.id };
}
const GPS = { breite: 43.80123, laenge: 15.95432, genauigkeit: 6.4 };

/* ---------- Kurs über Grund ---------- */
test('Kurs über Grund: nur bei Fahrt (ab 0,5 m/s) und mit frischem Punkt, sonst keiner', () => {
  const L = MM.Logbuch, jetzt = 1760000000000;
  assert.equal(L.kursGrad({ kurs: 214.6, geschwindigkeit: 3, zeitMs: jetzt - 5000 }, jetzt), 215);
  assert.equal(L.kursGrad({ kurs: 359.6, geschwindigkeit: 3, zeitMs: jetzt }, jetzt), 0, '360 wird 0');
  assert.equal(L.kursGrad({ kurs: 90, geschwindigkeit: 0.4, zeitMs: jetzt }, jetzt), null, 'Stillstand');
  assert.equal(L.kursGrad({ kurs: 90, geschwindigkeit: null, zeitMs: jetzt }, jetzt), null, 'ohne Geschwindigkeit');
  assert.equal(L.kursGrad({ kurs: null, geschwindigkeit: 3, zeitMs: jetzt }, jetzt), null, 'ohne Kurs');
  assert.equal(L.kursGrad({ kurs: NaN, geschwindigkeit: 3, zeitMs: jetzt }, jetzt), null);
  assert.equal(L.kursGrad({ kurs: 90, geschwindigkeit: 3, zeitMs: jetzt - 31000 }, jetzt), null, 'zu alt');
  assert.equal(L.kursGrad(null, jetzt), null);
  assert.equal(L.kursText(5), '005°');
});

test('Die App liest den Kurs nur vom GPS: Browser heading, Hülle bearing', () => {
  const a = lesen('js/ansicht.js'), h = lesen('js/huelle.js');
  assert.match(a, /p\.coords\.heading/); assert.match(h, /l\.bearing/);
  assert.ok(!/compass|deviceorientation|alpha/i.test(a + h), 'kein Kompass');
});

/* ---------- Kurswechsel ---------- */
test('Kurswechsel: Eintrag mit Grund, Kurs über Grund und Position, Art entsteht von selbst', async () => {
  const c = await mitFahrzeug();
  const r = await c.d.kurswechsel(c.id, { grund: 'Wetter', notiz: 'Front zieht auf', position: GPS, kurs: 214.6, geschwindigkeit: 3.1 });
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal(r.kurs, 215); assert.equal(r.position, true);
  assert.equal(r.text, 'Kurswechsel: Wetter. Kurs über Grund jetzt 215° (GPS, 6,0 kn). Front zieht auf');
  const lb = await c.d.logbuchLaden(c.id);
  const e = lb.abschnitte[0].ereignisse.filter(x => x.artName === 'Kurswechsel');
  assert.equal(e.length, 1);
  assert.deepEqual([e[0].breite, e[0].laenge, e[0].positionQuelle], [43.80123, 15.95432, 'gps']);
  assert.equal(e[0].text, r.text);
  /* die Art gibt es nur einmal, auch nach dem zweiten Kurswechsel */
  assert.ok((await c.d.kurswechsel(c.id, { grund: 'geplant', position: GPS })).ok);
  const arten = (await c.d.ereignisartenListe()).filter(x => MM.Logbuch.istKurswechselArt(x.aktuell.werte.bezeichnung));
  assert.equal(arten.length, 1);
});

test('Kurswechsel ohne Fahrt: Eintrag sagt „Kurs über Grund: keiner“; ohne GPS ohne Position', async () => {
  const c = await mitFahrzeug();
  const r = await c.d.kurswechsel(c.id, { grund: 'Hindernis', kurs: null, position: null });
  assert.ok(r.ok); assert.equal(r.kurs, null); assert.equal(r.position, false);
  assert.match(r.text, /Kurs über Grund: keiner/);
  const e = (await c.d.logbuchLaden(c.id)).abschnitte[0].ereignisse.filter(x => x.artName === 'Kurswechsel')[0];
  assert.equal(e.breite === undefined || e.breite === null, true);
});

test('Kurswechsel: Grund ist Pflicht, nur aus der Liste; nur Wasserfahrzeuge; nicht bei stornierter Aktivität', async () => {
  const c = await mitFahrzeug();
  assert.equal((await c.d.kurswechsel(c.id, { grund: '' })).fehler.grund, 'Bitte einen Grund wählen.');
  assert.ok((await c.d.kurswechsel(c.id, { grund: 'weil ich will' })).fehler.grund);
  assert.deepEqual(MM.Logbuch.KURSWECHSEL_GRUENDE, ['geplant', 'Plan geändert', 'Hindernis', 'Wetter', 'Strömung/Wind', 'falscher Kurs', 'sonstiges']);
  assert.ok((await c.d.kurswechsel(c.id, { grund: 'sonstiges', notiz: 'x'.repeat(501) })).fehler.notiz);
  const land = await mitFahrzeug('wohnmobil');
  assert.match((await land.d.kurswechsel(land.id, { grund: 'Wetter' })).fehler.allgemein, /nur bei Wasserfahrzeugen/);
  assert.equal((await land.d.logbuchLaden(land.id)).abschnitte[0].ereignisse.length, 0, 'an Land wird nichts gespeichert');
});

test('Kurswechsel steht auf der Karte mit dem Zeichen KW und folgt der Auswahl der Ereignisarten', async () => {
  const c = await mitFahrzeug();
  assert.ok((await c.d.kurswechsel(c.id, { grund: 'Wetter', position: GPS, kurs: 90, geschwindigkeit: 3 })).ok);
  const kd = await c.d.kartenDaten(c.id, 0);
  const k = kd.ereignisse.filter(e => e.artName === 'Kurswechsel');
  assert.equal(k.length, 1);
  assert.equal(MM.KartenEreignisse.aussehen('Kurswechsel').symbol, 'KW');
  assert.equal(MM.KartenEreignisse.sichtbar('Kurswechsel', kd.wahl.wirksam), true, 'zum Start ist alles an');
  const aus = MM.KartenEreignisse.umschalten(kd.wahl.wirksam, 'Kurswechsel', false);
  assert.equal(MM.KartenEreignisse.filtern(kd.ereignisse, aus).filter(e => e.artName === 'Kurswechsel').length, 0);
});

test('Cockpit-Knopf: Kurswechsel nur bei Wasserfahrzeugen, nicht unter den Ereignisarten, im Standard hinter dem Wechsel', async () => {
  const d = neueDaten(); await d.starten();
  const wasser = await d.schnellknoepfeFuerFahrzeugart('segelboot-katamaran');
  const land = await d.schnellknoepfeFuerFahrzeugart('wohnmobil');
  assert.ok(wasser.angebot.funktionen.some(f => f.key === 'f:kurswechsel'));
  assert.ok(!land.angebot.funktionen.some(f => f.key === 'f:kurswechsel'));
  assert.ok(!wasser.angebot.ereignisse.some(e => /kurswechsel/i.test(e.name)));
  const keys = wasser.knoepfeAlle.map(k => k.key);
  assert.equal(keys[keys.indexOf('f:wechsel') + 1], 'f:kurswechsel');
  assert.ok(!land.knoepfeAlle.some(k => k.key === 'f:kurswechsel'));
  const a = lesen('js/ansicht.js');
  assert.match(a, /teile\[3\] === 'kurswechsel'\) p = cockpitKurswechselSeite\(/);
});

/* ---------- Wechselpunkte ---------- */
test('Die NavShip-Datei: eine Route, Point-2 bis Point-5 sind ein Wechselpunkt, Soll-Kurse aus den Punkten', () => {
  const g = MM.Routen.lesen(NAVSHIP, 'navship_export.gpx');
  assert.ok(g.ok); assert.equal(g.wegart, 'route'); assert.equal(g.punkte.length, 6);
  const w = MM.Routen.wechselpunkte(g.punkte, g.wegart, {});
  assert.ok(w.moeglich);
  assert.deepEqual(w.liste.map(x => [x.nr, x.name, x.anzahl]), [[1, 'Point-1', 1], [2, 'Point-2', 4], [3, 'Point-6', 1]]);
  assert.deepEqual(w.liste.map(x => x.kursHin), [null, 54, 173]);
  assert.deepEqual(w.liste.map(x => x.kursWeiter), [54, 173, null]);
  assert.equal(w.liste[1].distanzHinSm, 48.1); assert.equal(w.liste[2].distanzHinSm, 96.6);
});

test('Peilung: Nord, Ost, Süd, West und eine bekannte Strecke', () => {
  const p = MM.Routen.peilung;
  assert.equal(p(0, 0, 1, 0), 0); assert.equal(p(0, 0, 0, 1), 90); assert.equal(p(1, 0, 0, 0), 180); assert.equal(p(0, 1, 0, 0), 270);
  assert.equal(MM.Routen.gradText(5), '005°'); assert.equal(MM.Routen.gradText(359.6), '000°');
});

test('Aufgezeichnete Spur: keine Wechselpunkte, mit Erklärung; Route ohne gespeicherte Art: bitte neu einlesen', () => {
  const s = MM.Routen.lesen(SPUR, 'spur.gpx');
  assert.equal(s.wegart, 'spur');
  const w = MM.Routen.wechselpunkte(s.punkte, s.wegart);
  assert.equal(w.moeglich, false); assert.match(w.grund, /aufgezeichnete Spur/); assert.match(w.grund, /geplante Route/);
  const alt = MM.Routen.wechselpunkte(s.punkte, null);
  assert.equal(alt.moeglich, false); assert.match(alt.grund, /noch einmal ein/);
  assert.equal(MM.Routen.lesen('<gpx><wpt lat="1" lon="1"><name>A</name></wpt><wpt lat="1.1" lon="1"><name>B</name></wpt></gpx>', 'x.gpx').wegart, 'wegpunkte');
});

test('Zusammenfassen: nur nacheinander folgende Punkte; der erste Name bleibt; ohne Namen „Punkt n“', () => {
  const P = (b, l, name) => ({ breite: b, laenge: l, name, km: 0 });
  const w = MM.Routen.wechselpunkte([P(1, 1), P(1, 1.0001), P(2, 1, 'Mitte'), P(1, 1, 'Zurück')], 'route');
  assert.deepEqual(w.liste.map(x => [x.name, x.anzahl]), [['Punkt 1', 2], ['Mitte', 1], ['Zurück', 1]], 'zurück an die erste Stelle zählt als eigener Wechselpunkt');
  assert.equal(MM.Routen.wechselpunkte([P(1, 1, 'A'), P(1, 1, 'B')], 'route').moeglich, false, 'nur ein Punkt bleibt übrig');
});

test('Eigene Namen: ändern, zurücksetzen, zu lang', () => {
  const g = MM.Routen.lesen(NAVSHIP, 'x.gpx');
  const n1 = MM.Routen.wpNamenSetzen({}, g.punkte[1] && 1, 'Kap Mele');
  assert.deepEqual(n1.namen, { '1': 'Kap Mele' });
  const w = MM.Routen.wechselpunkte(g.punkte, 'route', n1.namen);
  assert.equal(w.liste[1].name, 'Kap Mele'); assert.equal(w.liste[1].eigenerName, true); assert.equal(w.liste[1].dateiName, 'Point-2');
  assert.deepEqual(MM.Routen.wpNamenSetzen(n1.namen, 1, '  ').namen, {}, 'leer stellt den Namen aus der Datei wieder her');
  assert.ok(MM.Routen.wpNamenSetzen({}, 1, 'x'.repeat(41)).fehler);
});

test('Meldung im Cockpit: nächster Wechselpunkt, Hervorhebung ab 2 sm, erreicht, passiert, Ende', () => {
  const g = MM.Routen.lesen(NAVSHIP, 'x.gpx'), L = MM.Routen.wechselpunkte(g.punkte, 'route', {}).liste;
  const R = MM.Routen;
  /* Start: Point-1 gilt als passiert, nächster ist Point-2 */
  let n = R.wpNaechster(L, 0, L[0].breite, L[0].laenge);
  assert.equal(n.wp.name, 'Point-2'); assert.equal(n.abstandSm, 48.1); assert.equal(n.naehert, false);
  assert.equal(R.wpMeldung(n, null, null), 'Nächster Wechselpunkt Point-2 in 48,1 sm, Soll-Kurs 054°.');
  assert.equal(R.wpMeldung(n, 60, null), 'Nächster Wechselpunkt Point-2 in 48,1 sm, Soll-Kurs 054°, Kurs jetzt 060°.');
  /* 1 sm davor: „Gleich“ */
  n = R.wpNaechster(L, 0, L[1].breite - 1 / 60, L[1].laenge);
  assert.equal(n.naehert, true); assert.match(R.wpMeldung(n, null, null), /^Gleich Wechselpunkt Point-2 in 1,0 sm/);
  /* Ankunft am Wechselpunkt (0,05 sm): passiert, danach Point-6 */
  const p = R.wpPassiert(L, 0, L[1].breite + 0.05 / 60, L[1].laenge);
  assert.equal(p.passiert, 1); assert.equal(p.erreicht.name, 'Point-2');
  assert.equal(R.wpMeldung(R.wpNaechster(L, 1, L[1].breite, L[1].laenge), null, p.erreicht), 'Wechselpunkt Point-2 erreicht, neuer Soll-Kurs 173°. Nächster Wechselpunkt Point-6 in 96.6 sm, Soll-Kurs 173°.'.replace('96.6', '96,6'));
  /* 1 sm entfernt: nicht erreicht */
  assert.equal(R.wpPassiert(L, 0, L[1].breite + 1 / 60, L[1].laenge).passiert, 0);
  /* nach dem letzten: keine Meldung */
  assert.equal(R.wpNaechster(L, 2, L[2].breite, L[2].laenge), null);
  assert.equal(R.wpMeldung(null, null, null), '');
  /* erste Position mitten auf der Route: Start-Index aus km */
  assert.equal(R.wpStartIndex(L, 100), 1, '100 km: Point-2 (89 km) liegt schon hinter dem Fahrzeug'); assert.equal(R.wpStartIndex(L, 0), 0); assert.equal(R.wpStartIndex(L, 9999), 2);
});

test('Route einlesen: Art wird gespeichert, Wechselpunkte und Namen kommen über Route und Karte', async () => {
  const c = await mitFahrzeug();
  const e = await c.d.routeImportieren(c.id, NAVSHIP, 'navship_export.gpx');
  assert.ok(e.ok, JSON.stringify(e)); assert.equal(e.wegart, 'route');
  let ra = await c.d.routeAnsicht(c.id);
  assert.equal(ra.route.wegart, 'route'); assert.equal(ra.route.wechselpunkte.moeglich, true);
  assert.deepEqual(ra.route.wechselpunkte.liste.map(x => x.name), ['Point-1', 'Point-2', 'Point-6']);
  /* umbenennen */
  const w2 = ra.route.wechselpunkte.liste[1];
  assert.ok((await c.d.wechselpunktBenennen(c.id, w2.index, 'Kap Mele')).ok);
  ra = await c.d.routeAnsicht(c.id);
  assert.deepEqual(ra.route.wechselpunkte.liste.map(x => x.name), ['Point-1', 'Kap Mele', 'Point-6']);
  const kd = await c.d.kartenDaten(c.id, 0);
  assert.deepEqual(kd.route.wechselpunkte.map(x => x.name), ['Point-1', 'Kap Mele', 'Point-6']);
  assert.ok((await c.d.wechselpunktBenennen(c.id, w2.index, '')).ok);
  assert.equal((await c.d.routeAnsicht(c.id)).route.wechselpunkte.liste[1].name, 'Point-2');
  assert.ok((await c.d.wechselpunktBenennen(c.id, 99, 'x')).fehler.allgemein, 'unbekannter Wechselpunkt');
  assert.ok((await c.d.wechselpunktBenennen(c.id, w2.index, 'x'.repeat(41))).fehler.name);
});

test('Route einlesen: eine Spur hat keine Wechselpunkte, Landfahrzeuge zeigen keine', async () => {
  const c = await mitFahrzeug();
  assert.ok((await c.d.routeImportieren(c.id, SPUR, 'archiv.gpx')).ok);
  const ra = await c.d.routeAnsicht(c.id);
  assert.equal(ra.route.wegart, 'spur'); assert.equal(ra.route.wechselpunkte.moeglich, false);
  assert.deepEqual((await c.d.kartenDaten(c.id, 0)).route.wechselpunkte, []);
  const land = await mitFahrzeug('wohnmobil');
  assert.ok((await land.d.routeImportieren(land.id, NAVSHIP, 'navship.gpx')).ok);
  assert.equal((await land.d.routeAnsicht(land.id)).route.wechselpunkte, undefined, 'Wechselpunkte nur bei Wasserfahrzeugen');
});

test('Einbau: Seiten, Cockpit-Zeile, Karte und Neuerungen', () => {
  const a = lesen('js/ansicht.js'), k = lesen('js/kartenansicht.js');
  assert.match(a, /function cockpitKurswechselSeite\(/); assert.match(a, /function wechselpunkteBereich\(/);
  assert.match(a, /wechselpunktZeile\(id, a\.fahrzeug\.welt\)/); assert.match(a, /wpZeichnen\(\);\s*if \(gpsHorcher\)/);
  assert.match(a, /wechselpunkteBereich\(r, function/);
  assert.match(k, /kd\.route\.wechselpunkte\.forEach/); assert.match(k, /Soll-Kurs \(geplant\)/);
  assert.match(lesen('css/styles.css'), /\.kv-art-kurs/); assert.match(lesen('css/styles.css'), /\.cv-wechselpunkt\.nah/);
  assert.equal(MM.Texte.NEUERUNGEN[13].version, '2.0.116');
  assert.match(MM.Texte.NEUERUNGEN[13].punkte.join(' '), /Kurswechsel/); assert.match(MM.Texte.NEUERUNGEN[13].punkte.join(' '), /Wechselpunkt/);
  assert.ok(!/peilung/i.test(a + k + lesen('js/daten.js')), 'Peilung auf eine Tonne bleibt entfernt');
});

test('Hülle: bearing des Dauerdienstes wird zum Kurs des Punkts', () => {
  require('../js/huelle.js');
  const p = MM.Huelle.erzeugen({}).punkt;
  assert.equal(p({ latitude: 1, longitude: 2, speed: 3, bearing: 215.4 }).kurs, 215.4);
  assert.equal(p({ latitude: 1, longitude: 2, speed: 3, bearing: null }).kurs, null);
  assert.equal(p({ latitude: 1, longitude: 2, speed: 3, bearing: -1 }).kurs, null, 'negativer Wert gilt als unbekannt');
  assert.equal(p({ latitude: 1, longitude: 2 }).kurs, null);
});
