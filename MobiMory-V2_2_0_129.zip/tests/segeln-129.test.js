'use strict';
/* Bau 2.0.129: Segel und Segelmanöver. Jedes mitgelieferte Manöver wird einmal durchgespielt. */
const test = require('node:test');
const assert = require('node:assert/strict');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status', 'baukasten', 'segeln',
  'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'kartenereignisse', 'texte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const S = MM.Segeln, B = MM.Baukasten;
function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 3, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (std, min) => { uhr.ms = new Date(2026, 10, 3, std, min, 0).getTime(); };
  return d;
}
async function mitFahrzeug(art) {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen(art || 'motorboot', { bezeichnung: 'Fahrzeug' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Sommertörn', artId: toern, fahrzeugId: fz, vonDatum: '2026-11-03', vonZeit: '09:00', bisDatum: '2026-11-05', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok);
  await d.heutigerTag(r.id);
  return { d, id: r.id };
}
const GPS = { breite: 43.80123, laenge: 15.95432, genauigkeit: 6 };
const T0 = 1000000;

/* Punkte im Sekundentakt. verlauf(sekunde) gibt [Kurs, Fahrt m/s] */
function fahre(z, sekunden, verlauf, regel) {
  for (let s = 0; s <= sekunden; s++) {
    const [k, v] = verlauf(s);
    const r = S.laufPunkt(z, { zeitMs: T0 + s * 1000, kurs: k, geschwindigkeit: v }, regel);
    if (r) return Object.assign({ bei: s }, r);
  }
  return null;
}
const dreh = (von, grad, dauer, v) => s => [((von + grad * Math.min(1, s / dauer)) % 360 + 360) % 360, v || 3];

test('Ende: Wende, Halse, Anluven, Abfallen und Q-Wende werden erkannt, Drehwinkel mit Richtung', () => {
  for (const [name, von, grad] of [['Wende', 40, -90], ['Halse', 150, 70], ['Anluven', 90, -20], ['Abfallen', 90, 25], ['Q-Wende', 310, 270]]) {
    const r = fahre(S.laufNeu('kurs', T0, von, 3), 120, dreh(von, grad, 30));
    assert.ok(r, name);
    assert.equal(r.status, 'erkannt', name);
    assert.ok(Math.abs(r.kursNach - ((von + grad) % 360 + 360) % 360) <= 4, name + ' Kurs ' + r.kursNach);
    assert.ok(Math.abs(r.drehwinkel - grad) <= 5, name + ' Drehung ' + r.drehwinkel);
    assert.ok(r.dauerS >= 15 && r.dauerS <= 35, name + ' Dauer ' + r.dauerS);
  }
});
test('Ende: Q-Wende über 360 Grad zählt die ganze Drehung', () => {
  const r = fahre(S.laufNeu('kurs', T0, 0, 3), 120, dreh(0, 380, 40));
  assert.ok(Math.abs(r.drehwinkel - 380) <= 6, String(r.drehwinkel));
});
test('Ende: ohne deutliche Kursänderung kein Ende, nach 5 Minuten „nicht erkannt“; Stillstand und Lücken zählen nicht', () => {
  const z = S.laufNeu('kurs', T0, 90, 3);
  assert.equal(fahre(z, 200, s => [90 + (s % 4), 3]), null);
  assert.equal(S.laufZuLange(z, T0 + 4 * 60000), null);
  assert.equal(S.laufZuLange(z, T0 + 5 * 60000 + 1000).status, 'nicht erkannt');
  const y = S.laufNeu('kurs', T0, 90, 3);
  assert.equal(fahre(y, 100, () => [200, 0.1]), null, 'steht');
  const x = S.laufNeu('kurs', T0, 90, 3);
  S.laufPunkt(x, { zeitMs: T0 + 1000, kurs: 180, geschwindigkeit: 3 });
  assert.equal(S.laufPunkt(x, { zeitMs: T0 + 60000, kurs: 180, geschwindigkeit: 3 }), null, 'Lücke');
});
test('Ende: Aufschießer bei Fahrt fast null, Beidrehen bei geringer Fahrt, von Hand nie', () => {
  const bremsen = s => [10, s < 15 ? 3 - s * 0.2 : 0.2];
  const a = fahre(S.laufNeu('stopp', T0, 10, 3), 80, bremsen);
  assert.equal(a.status, 'erkannt'); assert.ok(a.geschwNach < 0.5);
  const b = fahre(S.laufNeu('treiben', T0, 10, 3), 80, s => [10, s < 10 ? 3 : 0.6]);
  assert.equal(b.status, 'erkannt'); assert.equal(b.geschwNach, 0.6);
  assert.equal(fahre(S.laufNeu('hand', T0, 10, 3), 80, bremsen), null);
  assert.equal(S.laufZuLange(S.laufNeu('hand', T0, 10, 3), T0 + 3600000), null);
});

test('Mitgelieferte Manöver: alle aus der Übergabe außer Kreuzen, nur bekannte Fragen und Wirkungen', () => {
  const namen = S.MANOEVER.map(m => m.name);
  ['Segel setzen', 'Segel bergen', 'Reffen', 'Ausreffen', 'Gennaker/Spinnaker setzen', 'Gennaker/Spinnaker bergen', 'Gennaker halsen', 'Anluven', 'Abfallen', 'Wende', 'Halse', 'Q-Wende', 'Patenthalse',
    'Beidrehen', 'Beidrehen aufheben', 'Aufschießer', 'Boje über Bord (Übung)', 'Kentern', 'Aufrichten', 'An die Boje', 'Von der Boje'].forEach(n => assert.ok(namen.includes(n), n));
  assert.ok(!namen.some(n => /kreuz/i.test(n)));
  S.MANOEVER.concat([S.MOB]).forEach(m => {
    const z = B.zusammenstellung(m);
    assert.equal(z.fragen.length, m.fragen.length, m.name); assert.equal(z.wirkungen.length, m.wirkungen.length, m.name);
    assert.deepEqual(B.fehlendeFragen(m), [], m.name);
  });
});

async function boot() {
  const c = await mitFahrzeug('segelboot-monohull');
  c.fz = (await c.d.aktivitaetLaden(c.id)).fahrzeug.id;
  c.gross = (await c.d.komponenteAnlegen(c.fz, null, 'segel', { bezeichnung: 'Großsegel', merkmale: [{ name: 'Reffstufen', wert: '2', einheit: '' }] })).id;
  c.d.holeJson = (url) => {
    const jetzt = Math.round(new Date(c.d.jetzt()).getTime() / 1000);
    if (/marine/.test(url)) return Promise.resolve({ hourly: { time: [jetzt], wave_height: [0.8] } });
    assert.match(url, /pressure_msl/);
    return Promise.resolve({ hourly: { time: [jetzt], wind_speed_10m: [12], wind_gusts_10m: [18], wind_direction_10m: [225], weather_code: [1], pressure_msl: [1016.4] } });
  };
  await c.d.schnellknoepfeFuerFahrzeugart('segelboot-monohull');
  c.arten = (await c.d.ereignisartenListe()).map(x => ({ id: x.objekt.id, name: x.aktuell.werte.bezeichnung, w: x.aktuell.werte }));
  return c;
}
async function druecke(c, name) {
  const art = c.arten.find(a => a.name === name);
  assert.ok(art, 'Art ' + name);
  const r = await c.d.ereignisSchnell(c.id, name, { artId: art.id, position: GPS });
  assert.ok(r.ok, name + ' ' + JSON.stringify(r));
  const m = await c.d.manoeverStarten(r.id, { kurs: 214, geschwindigkeit: 3 });
  assert.ok(m.ok && m.manoever, name);
  return { r, m };
}
const werte = async (c, id) => (await c.d.ereignisLaden(id)).aktuell.werte;

test('Jedes Manöver einmal durchgespielt: Druck, Fragen, Messung, Wetter, Logbuchtext', async () => {
  const c = await boot();
  let min = 0;
  for (const mv of S.MANOEVER) {
    c.d.stelle(12, ++min);
    const { r, m } = await druecke(c, mv.name);
    assert.equal(m.seite, mv.fragen.length > 0, mv.name + ' Seite');
    if (mv.fragen.length) {
      const a = await c.d.ereignisAblaufAusfuehren(r.id, { segelIds: [c.gross], reffstufe: '1. Reff', windStaerke: '4', windEinheit: 'bft', windRichtung: 'SW', windArt: 'scheinbar', antrieb: 'motor' });
      assert.ok(a.ok, mv.name + ' ' + JSON.stringify(a));
    }
    if (m.laeuft && !mv.wirkungen.includes('mob')) assert.ok((await c.d.manoeverBeenden(r.id, { status: 'erkannt', kursNach: 124, geschwNach: 2.5, drehwinkel: -90, dauerS: 25 })).ok, mv.name);
    assert.ok((await c.d.manoeverBedingungen(r.id, GPS)).ok, mv.name);
    const w = await werte(c, r.id);
    assert.equal(w.skipperName, 'Anna', mv.name); assert.equal(w.ruderName, 'Anna', mv.name);
    assert.equal(w.breite, GPS.breite);
    const e = (await c.d.logbuchLaden(c.id)).abschnitte[0].ereignisse.find(x => x.id === r.id);
    assert.match(e.text, /Wetterdienst: Wind \(wahr\) 12 kn aus SW, Böen 18 kn.*Welle 0,8 m, Luftdruck 1016 hPa/, mv.name);
    assert.match(e.text, /Skipper: Anna/);
    if (m.endeArt) assert.match(e.text, /Kurs 214°/, mv.name);
    if (mv.wirkungen.includes('kursKurs')) assert.match(e.text, /Kurs 214° → 124° · Fahrt 5,8 kn → 4,9 kn · Drehung 90° nach links · Dauer 25 s/, mv.name);
    if (mv.fragen.includes('wind')) assert.match(e.text, /Wind \(von Hand\) 4 Bft aus SW scheinbar/, mv.name);
    if (mv.fragen.includes('segel')) assert.match(e.text, /Segel: Großsegel/, mv.name);
    if (mv.fragen.includes('antrieb')) assert.match(e.text, /Antrieb: Motor/, mv.name);
    if (mv.wirkungen.includes('zwischenfall')) assert.match(e.text, /Zwischenfall/, mv.name);
    if (mv.wirkungen.includes('mob')) { assert.match(e.text, /Übung/); assert.equal(w.mob, true); assert.ok(e.manoeverLauf.mob); await c.d.manoeverBeenden(r.id, { status: 'erkannt', dauerS: 300 }); }
  }
});

test('Segelzustand und Stunden: setzen, reffen, ausreffen, bergen', async () => {
  const c = await boot();
  const tun = async (std, name, antworten) => { c.d.stelle(std, 0); const x = await druecke(c, name); assert.ok((await c.d.ereignisAblaufAusfuehren(x.r.id, Object.assign({ segelIds: [c.gross] }, antworten))).ok); };
  const stand = async () => (await c.d.segelStand(c.fz))[c.gross];
  await tun(10, 'Segel setzen'); assert.equal(S.zustandText(await stand()), 'gesetzt');
  await tun(11, 'Reffen', { reffstufe: '2. Reff' }); assert.equal(S.zustandText(await stand()), 'gerefft (2. Reff)');
  await tun(12, 'Ausreffen', { reffstufe: '1. Reff' }); assert.equal(S.zustandText(await stand()), 'gerefft (1. Reff)');
  await tun(13, 'Ausreffen', { reffstufe: 'ganz offen' }); assert.equal(S.zustandText(await stand()), 'gesetzt');
  await tun(14, 'Segel bergen');
  const s = await stand();
  assert.equal(s.zustand, 'geborgen'); assert.equal(s.stunden, 4);
});

test('Person über Bord: ein Aufruf, auch am Motorboot, Position gemerkt, Richtung zurück', async () => {
  const c = await mitFahrzeug('motorboot');
  const r = await c.d.personUeberBord(c.id, { position: GPS, kurs: 90, geschwindigkeit: 4 });
  assert.ok(r.ok, JSON.stringify(r));
  const w = await werte(c, r.id);
  assert.equal(w.mob, true); assert.equal(w.endeStatus, 'laeuft'); assert.equal(w.breite, GPS.breite); assert.equal(w.kursVor, 90); assert.equal(w.skipperName, 'Anna');
  assert.ok((await c.d.personUeberBord(c.id, {})).ok, 'ohne Position wird trotzdem gespeichert');
  assert.equal((await c.d.ereignisartenListe()).filter(x => x.aktuell.werte.bezeichnung === 'Person über Bord').length, 1);
  assert.equal(S.richtungGrad(43, 15, 44, 15), 0); assert.equal(S.richtungGrad(0, 15, 0, 16), 90); assert.equal(S.richtungGrad(44, 15, 43, 15), 180);
});

test('Manöverarten: einmal angelegt, Änderungen und Ausblenden bleiben; Motorboot bekommt keine', async () => {
  const m = await mitFahrzeug('motorboot');
  await m.d.schnellknoepfeFuerFahrzeugart('motorboot');
  assert.ok(!(await m.d.ereignisartenListe()).some(x => x.aktuell.werte.bezeichnung === 'Wende'));
  const c = await boot();
  const wende = c.arten.find(a => a.name === 'Wende');
  assert.ok((await c.d.ereignisartAendern(wende.id, { bezeichnung: 'Wende', fragen: ['checkliste'], wirkungen: ['kursKurs'], checkliste: 'Crew gewarnt; Schot klar' })).ok);
  await c.d.segelArtenSichern();
  const nach = await c.d.ereignisartenListe();
  assert.equal(nach.filter(x => x.aktuell.werte.bezeichnung === 'Wende').length, 1);
  const w = nach.find(x => x.objekt.id === wende.id).aktuell.werte;
  assert.equal(w.checkliste, 'Crew gewarnt; Schot klar'); assert.deepEqual(w.wirkungen, ['kursKurs']);
  c.arten = nach.map(x => ({ id: x.objekt.id, name: x.aktuell.werte.bezeichnung }));
  const x = await druecke(c, 'Wende');
  assert.ok((await c.d.ereignisAblaufAusfuehren(x.r.id, { checklisteErledigt: ['Crew gewarnt'] })).ok);
  assert.match(S.zusammenfassung(await werte(c, x.r.id)), /Abgehakt: Crew gewarnt/);
});

test('Nachgetragen: keine Messwerte. Ohne Netz bleibt das Wetter leer. Normale Ereignisse bleiben unberührt', async () => {
  const c = await boot();
  const art = c.arten.find(a => a.name === 'Wende');
  const r = await c.d.ereignisSchnell(c.id, 'Wende', { artId: art.id, zeit: '09:30' });
  const m = await c.d.manoeverStarten(r.id, { kurs: 10, geschwindigkeit: 3 });
  assert.equal(m.laeuft, false); assert.equal(m.bedingungen, false); assert.equal((await werte(c, r.id)).kursVor, undefined);
  c.d.holeJson = () => Promise.reject(new Error('offline'));
  assert.equal((await c.d.manoeverBedingungen(r.id, GPS)).ok, false);
  const n = await c.d.ereignisSchnell(c.id, 'Notiz', { text: 'Hallo' });
  assert.equal((await c.d.manoeverStarten(n.id, {})).manoever, false);
  assert.equal((await werte(c, n.id)).manoever, undefined);
});

test('Einstellungen, Reffstufen und Stil', async () => {
  const d = neueDaten(); await d.starten();
  assert.deepEqual(await d.segelEinstellungen(), S.STANDARD);
  await d.segelEinstellungenSetzen({ windEinheit: 'kn', ruhigSek: '30', ruhigGrad: '999', treibKn: '2,5' });
  assert.deepEqual(await d.segelEinstellungen(), { windEinheit: 'kn', ruhigSek: 30, ruhigGrad: 10, treibKn: 2.5 });
  assert.deepEqual(S.reffstufen([{ name: 'Reffart', wert: 'Rollreff' }]), ['¾', '½', '¼']);
  assert.deepEqual(S.reffstufen([{ name: 'Reffstufen', wert: '2' }]), ['1. Reff', '2. Reff']);
  assert.equal(/peilung/i.test(require('fs').readFileSync(require('path').join(__dirname, '../js/segeln.js'), 'utf8')), false);
});
