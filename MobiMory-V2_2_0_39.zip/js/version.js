/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.39';
  MM.STUFE = 'Ort und Revier: Gebiete aus Orten';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
