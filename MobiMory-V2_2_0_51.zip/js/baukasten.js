/* Gerüst des Ereignis-Baukastens (seit 2.0.50). Nur Regeln, kein Speicher und kein Netz.
 * Gesamtbild Ereignis-Baukasten: Jeder Knopf folgt demselben Muster.
 *   1. Festhalten  Ort und Zeit, immer (macht der Knopf selbst, hier nichts einzustellen)
 *   2. Fragen      nur, was die App nicht wissen kann (Text, Foto, Betrag, Ziel; seit 2.0.51 auch Tank, Menge, Literpreis, Voll getankt)
 *   3. Wirkungen   was die App danach selbst tut (Kostenposten anlegen, Navigations-App öffnen; seit 2.0.51 auch Füllstand, Verbrauch, Reichweite)
 * Welche Fragen und Wirkungen es gibt, steht nur in den Listen FRAGEN und WIRKUNGEN unten. Eine neue kommt als eine weitere Zeile
 * dazu (oder mit MM.Baukasten.frageRegistrieren / wirkungRegistrieren), der Aufbau ändert sich nicht. Tanken (seit 2.0.51), Störung und
 * Aufenthalte (spätere Stufen) sind nur Zusammenstellungen aus diesen Bausteinen (Vorlage: VORLAGEN).
 *
 * Die Zusammenstellung einer Ereignisart liegt in den Feldern „fragen“ und „wirkungen“ (Listen von Kennungen).
 * Die Aktionen aus 2.0.47 (js/aktionen.js: Text, Foto, Navigation) gehen darin auf: Eine Art, die nur das alte Feld „aktion“ hat,
 * bekommt ihre Zusammenstellung daraus (Text = Frage Text, Foto = Frage Foto, Navigation = Frage Ziel + Wirkung Navigation).
 * Nichts wird umgeschrieben, solange der Nutzer die Art nicht ändert.
 *
 * Eintrag Frage:   { id, name, hilfe, typ }   typ: 'auswahl' (aus einer Liste), 'zahl', 'janein'; ohne typ: Text, Foto, Betrag, Ziel wie bisher
 * Eintrag Wirkung: { id, name, hilfe, braucht: [Fragen, ohne die sie nichts tut], brauchtEine: [eine davon genügt], brauchtWirkung: [Wirkungen, auf denen sie aufbaut] } */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var FRAGEN = [
    { id: 'text', name: 'Text', hilfe: 'Ein Textfeld. Der Text kommt zum Eintrag.' },
    { id: 'foto', name: 'Foto', hilfe: 'Foto aufnehmen oder ein vorhandenes Bild wählen. Das Foto kommt zum Eintrag.' },
    { id: 'tank', name: 'Tank', typ: 'auswahl', hilfe: 'Auswahl aus einer Liste: die Tanks des Fahrzeugs. Der gewählte Tank kommt zum Eintrag.' },
    { id: 'menge', name: 'Menge', typ: 'zahl', hilfe: 'Eine Zahl: die getankte Menge in Litern. Sie kommt zum Eintrag.' },
    { id: 'betrag', name: 'Betrag', hilfe: 'Ein Betrag in Euro. Er kommt zum Eintrag.' },
    { id: 'literpreis', name: 'Literpreis', typ: 'zahl', hilfe: 'Eine Zahl: der Preis je Liter in Euro. Mit der Menge rechnet die App den Betrag, wenn du keinen Betrag einträgst.' },
    { id: 'voll', name: 'Voll getankt?', typ: 'janein', hilfe: 'Ja oder Nein. Bei Ja ist der Tank danach voll.' },
    { id: 'ziel', name: 'Ziel', hilfe: 'Ein Ziel (Ort, Adresse oder Koordinaten), mit dem Ziel des Tages vorbelegt, wenn es eines gibt.' }
  ];

  var WIRKUNGEN = [
    { id: 'kosten', name: 'Kostenposten anlegen', braucht: ['betrag'],
      hilfe: 'Aus dem Betrag legt die App einen Posten bei den variablen Kosten an, am Fahrzeug und an der Reise, mit dem Namen der Art und dem Datum des Eintrags.' },
    { id: 'navi', name: 'Navigations-App öffnen', braucht: ['ziel'],
      hilfe: 'Die App übergibt nur das Ziel. Das Gerät entscheidet, welche Navigations-App öffnet.' },
    { id: 'kostenTreibstoff', name: 'Kostenposten Treibstoff und Energie', braucht: [], brauchtEine: ['betrag', 'literpreis'],
      hilfe: 'Legt einen Posten bei den variablen Kosten an, Kostenart „Treibstoff und Energie“, am Fahrzeug und an der Reise. Betrag oder Literpreis (mit der Menge) genügt.' },
    { id: 'fuellstand', name: 'Füllstand setzen', braucht: ['tank', 'menge', 'voll'],
      hilfe: 'Voll getankt: der Tank ist voll (Tankinhalt nötig). Nicht voll: letzter Stand plus Menge, mit Hinweis, dass der Stand nur gerechnet ist. Den Stand gibst du einmal beim Tank an.' },
    { id: 'verbrauch', name: 'Verbrauch rechnen', braucht: ['tank', 'menge', 'voll'], brauchtWirkung: ['fuellstand'],
      hilfe: 'Rechnet beim Volltanken die verbrauchten Liter seit dem letzten genauen Stand, je Verbraucher aus Füllstand oder Betriebsstunden (so, wie beim Verbraucher eingestellt). Bei mehreren Verbrauchern am Tank gibt es nur die Summe.' },
    { id: 'reichweite', name: 'Reichweite rechnen', braucht: ['tank', 'menge', 'voll'], brauchtWirkung: ['fuellstand', 'verbrauch'],
      hilfe: 'Füllstand geteilt durch den Verbrauch, in Betriebsstunden oder Tagen.' }
  ];

  /* Fertige Zusammenstellungen. Nur ein Anfang (Vorlage): Der Nutzer stellt sie bei der Art ein und kann sie ändern. Nichts wird erzwungen. */
  var VORLAGEN = [
    { id: 'tanken', name: 'Tanken', fragen: ['tank', 'menge', 'betrag', 'literpreis', 'voll'], wirkungen: ['kostenTreibstoff', 'fuellstand', 'verbrauch', 'reichweite'] }
  ];

  function kopie(o) {
    var k = Object.assign({}, o);
    ['braucht', 'brauchtEine', 'brauchtWirkung'].forEach(function (f) { if (o[f]) k[f] = o[f].slice(); });
    return k;
  }
  function liste(reg) { return reg.map(kopie); }
  function finde(reg, id) {
    var s = String(id === undefined || id === null ? '' : id);
    var x = reg.filter(function (a) { return a.id === s; })[0];
    return x ? kopie(x) : null;
  }
  function registrieren(reg, a) {
    if (!a || !a.id || !a.name || finde(reg, a.id)) return false;
    var neu = { id: String(a.id), name: String(a.name), hilfe: a.hilfe || '' };
    if (a.typ) neu.typ = String(a.typ);
    ['braucht', 'brauchtEine', 'brauchtWirkung'].forEach(function (f) { if (a[f]) neu[f] = a[f].map(String); });
    reg.push(neu);
    return true;
  }

  function fragen() { return liste(FRAGEN); }
  function wirkungen() { return liste(WIRKUNGEN); }
  function frage(id) { return finde(FRAGEN, id); }
  function wirkung(id) { return finde(WIRKUNGEN, id); }
  function frageRegistrieren(a) { return registrieren(FRAGEN, a); }
  function wirkungRegistrieren(a) { return registrieren(WIRKUNGEN, a); }
  function vorlagen() { return VORLAGEN.map(function (v) { return { id: v.id, name: v.name, fragen: v.fragen.slice(), wirkungen: v.wirkungen.slice() }; }); }
  function vorlage(id) { return vorlagen().filter(function (v) { return v.id === String(id); })[0] || null; }

  /* Nur bekannte Kennungen, ohne Doppelte, in der Reihenfolge der Liste (nicht der Eingabe). */
  function normalListe(reg, roh) {
    var gewaehlt = Array.isArray(roh) ? roh.map(String) : [];
    return reg.filter(function (a) { return gewaehlt.indexOf(a.id) >= 0; }).map(function (a) { return a.id; });
  }
  function fragenNormal(roh) { return normalListe(FRAGEN, roh); }
  function wirkungenNormal(roh) { return normalListe(WIRKUNGEN, roh); }

  /* Die Zusammenstellung einer Ereignisart: { fragen: [...], wirkungen: [...] }.
   * Hat die Art eines der Felder „fragen“ oder „wirkungen“, gilt das. Sonst kommt sie aus dem alten Feld „aktion“ (2.0.47). */
  function zusammenstellung(werte) {
    var w = werte || {};
    if (w.fragen !== undefined || w.wirkungen !== undefined) return { fragen: fragenNormal(w.fragen), wirkungen: wirkungenNormal(w.wirkungen) };
    var a = MM.Aktionen ? MM.Aktionen.art(w.aktion) : null;
    return a ? { fragen: fragenNormal(a.fragen), wirkungen: wirkungenNormal(a.wirkungen) } : { fragen: [], wirkungen: [] };
  }
  function leer(z) { return !z || (!z.fragen.length && !z.wirkungen.length); }
  /* Löst der Knopf nach Wo und Wann noch etwas aus? Nur dann kommt die Seite nach dem Antippen. */
  function hatAblauf(werte) { return !leer(zusammenstellung(werte)); }
  function gleich(a, b) { return JSON.stringify(a.fragen) === JSON.stringify(b.fragen) && JSON.stringify(a.wirkungen) === JSON.stringify(b.wirkungen); }

  /* Eine Wirkung braucht ihre Fragen. Gibt für jede fehlende Frage eine Meldung zurück (leere Liste = in Ordnung). */
  function fehlendeFragen(z) {
    var meldungen = [];
    if (!z) return meldungen;
    z.wirkungen.forEach(function (wid) {
      var w = wirkung(wid);
      (w && w.braucht || []).forEach(function (fid) {
        if (z.fragen.indexOf(fid) < 0) {
          var f = frage(fid);
          meldungen.push('„' + w.name + '“ braucht die Frage „' + (f ? f.name : fid) + '“. Bitte ankreuzen.');
        }
      });
      /* Eine von mehreren Fragen genügt (zum Beispiel Betrag oder Literpreis). */
      if (w && w.brauchtEine && w.brauchtEine.length && !w.brauchtEine.some(function (fid) { return z.fragen.indexOf(fid) >= 0; })) {
        meldungen.push('„' + w.name + '“ braucht eine dieser Fragen: ' + w.brauchtEine.map(function (fid) { var f = frage(fid); return '„' + (f ? f.name : fid) + '“'; }).join(' oder ') + '. Bitte ankreuzen.');
      }
      (w && w.brauchtWirkung || []).forEach(function (wid) {
        if (z.wirkungen.indexOf(wid) < 0) {
          var x = wirkung(wid);
          meldungen.push('„' + w.name + '“ braucht die Wirkung „' + (x ? x.name : wid) + '“. Bitte ankreuzen.');
        }
      });
    });
    return meldungen;
  }

  /* Das Muster in Worten, für Listen und Seiten. Ohne Fragen und Wirkungen: ''. */
  function ablaufText(z) {
    if (leer(z)) return '';
    var teile = ['Festhalten: Ort und Zeit'];
    if (z.fragen.length) teile.push('Fragen: ' + z.fragen.map(function (i) { var f = frage(i); return f ? f.name : i; }).join(', '));
    if (z.wirkungen.length) teile.push('Wirkungen: ' + z.wirkungen.map(function (i) { var w = wirkung(i); return w ? w.name : i; }).join(', '));
    return teile.join(' → ');
  }

  MM.Baukasten = {
    fragen: fragen, wirkungen: wirkungen, frage: frage, wirkung: wirkung,
    frageRegistrieren: frageRegistrieren, wirkungRegistrieren: wirkungRegistrieren, vorlagen: vorlagen, vorlage: vorlage,
    fragenNormal: fragenNormal, wirkungenNormal: wirkungenNormal,
    zusammenstellung: zusammenstellung, hatAblauf: hatAblauf, leer: leer, gleich: gleich,
    fehlendeFragen: fehlendeFragen, ablaufText: ablaufText
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
