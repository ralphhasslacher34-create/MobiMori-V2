'use strict';
/* 2.0.49: Korrektur zu 2.0.48. (1) Weiteren Tank anlegen, ohne das Formular zu verlieren. (2) Foto: zwei klare Knöpfe.
   Es gibt keinen echten Browser im Test, darum wird geprüft, was im Programm festgelegt ist. Das Durchklicken der Seiten
   (jsdom in einem Hilfsordner) ersetzt keinen Test am Gerät. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const ansicht = lesen('js/ansicht.js');
const css = lesen('css/styles.css');

function funktion(name) {
  const start = ansicht.indexOf('  function ' + name + '(');
  assert.ok(start >= 0, 'Funktion fehlt: ' + name);
  const ende = ansicht.indexOf('\n  }\n', start);
  return ansicht.slice(start, ende);
}

test('Tank: der Knopf steht immer unter der Liste, nicht nur ohne Tank', () => {
  const f = funktion('seiteKomponentenFormular');
  assert.ok(f.includes("id: 'weiterer-tank'"));
  assert.ok(f.includes("'Weiteren Tank anlegen'"));
  assert.ok(!/vd\.fahrzeugId && !wahl\.length/.test(f), 'die alte Bedingung „nur ohne Tank“ ist weg');
  assert.ok(/vd\.fahrzeugId \? h\('p', null, h\('button'/.test(f));
});

test('Tank: Entwurf bleibt im Speicher der Seite, Rückkehr per weiter= und entwurf=ja, nichts wird gespeichert', () => {
  const f = funktion('seiteKomponentenFormular');
  assert.ok(ansicht.includes('var komponentenEntwurf = null;'));
  assert.ok(f.includes("'/komponente/neu?art=tank&weiter=' + encodeURIComponent("));
  assert.ok(f.includes('komponentenEntwurf = { schluessel:'));
  assert.ok(f.includes("hashParam('entwurf') === 'ja'"));
  /* beim Wegklicken wird nur gemerkt, es gibt keinen Aufruf der Datenschicht */
  const klick = f.slice(f.indexOf("id: 'weiterer-tank'"), f.indexOf("id: 'weiterer-tank'") + 700);
  assert.ok(!/daten\./.test(klick));
});

test('Tank: Abbrechen und Speichern des Tank-Formulars führen zum ursprünglichen Formular zurück', () => {
  const f = funktion('seiteKomponentenFormular');
  assert.ok(f.includes("var weiter = modus === 'neu-haupt' ? weiterAdresse() : '';"));
  assert.ok(f.includes('if (weiter) zurueck = hashMitEntwurf(weiter);'));
  assert.ok(/href: zurueck, text: 'Abbrechen'/.test(f));
  assert.ok(/global\.location\.hash = zurueck;/.test(f));
});

test('Tank: Rückkehradresse nur innerhalb der App, ein alter Entwurf kommt nie von selbst zurück', () => {
  assert.ok(ansicht.includes("/^#\\/(fahrzeug|komponente)\\//.test(w)"));
  const f = funktion('seiteKomponentenFormular');
  /* ohne „entwurf=ja“ wird ein normales Öffnen immer frisch begonnen */
  assert.ok(/else if \(!weiter\) \{\s*komponentenEntwurf = null;/.test(f));
});

test('Tank: auch beim Ändern (nicht nur beim Anlegen) ist die Abfrage mit dem Knopf da', () => {
  const f = funktion('seiteKomponentenFormular');
  /* die Abfrage hängt an istHaupt/Verbraucher, nicht am Modus */
  assert.ok(f.includes("modus !== 'aendern' || t.id !== c.komponente.id"));
  assert.ok(!/modus === 'neu-haupt'[^\n]*weiterer-tank/.test(f));
});

test('Foto: zwei klare Knöpfe, versteckte Felder, Dateiname sofort sichtbar', () => {
  assert.ok(ansicht.includes("text: 'Foto jetzt aufnehmen'"));
  assert.ok(ansicht.includes("text: 'Vorhandenes Bild wählen'"));
  assert.ok(ansicht.includes("capture: 'environment'"), 'die Kamera öffnet über das Feld mit capture');
  assert.equal((ansicht.match(/class: 'datei-versteckt'/g) || []).length, 2);
  assert.ok(ansicht.includes("'Noch kein Bild gewählt.'"));
  assert.ok(ansicht.includes("status.textContent = 'Gewählt: '"));
  assert.ok(!ansicht.includes('Oder ein vorhandenes Bild wählen'), 'die alte, verwirrende Beschriftung ist weg');
  assert.ok(css.includes('.datei-versteckt'));
  assert.ok(css.includes('.datei-knopf'));
});

test('Foto: überall, wo das Feld „kamera“ benutzt wird, bleibt es dasselbe Feld', () => {
  const n = (ansicht.match(/kamera: true/g) || []).length;
  assert.ok(n >= 3, 'Foto im Cockpit, Ereignis eintragen, Aktion Foto: ' + n);
  /* Wahl über Kamera oder Galerie füllt dasselbe Feld „datei“ */
  const f = funktion('feldElement');
  assert.ok(/name: f\.key, type: 'file', accept: 'image\/\*', capture: 'environment'/.test(f));
  assert.ok(/name: f\.key, type: 'file', accept: f\.accept \|\| 'image\/\*'/.test(f));
});

test('Version 2.0.51 überall gleich', () => {
  require('../js/version.js');
  assert.equal(globalThis.MM.VERSION, '2.0.51');
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.51';"));
  assert.equal(JSON.parse(lesen('package.json')).version, '2.0.51');
  assert.ok(lesen('README.md').includes('Version 2.0.51'));
  assert.ok(lesen('CHANGELOG.md').startsWith('# Änderungen\n\n## 2.0.51'));
});
