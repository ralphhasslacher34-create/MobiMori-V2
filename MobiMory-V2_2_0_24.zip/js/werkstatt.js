/*
 * Werkstatt, Stufe 7a: Vorgänge (Störungen und Arbeiten). Regeln und Beschreibung.
 *
 * Aus den V2-Festlegungen (03./04.11.2026):
 *  - Ausgangspunkt ist die Störungsmeldung. Ist das Fahrzeug nicht oder nur
 *    bedingt einsatzfähig, weist die App sofort darauf hin, dass es für die
 *    nächste Zeit versprochen ist, und fragt, ob es trotzdem genutzt werden
 *    kann oder abgesagt werden muss.
 *  - Aus einer Störung wird eine Arbeit: selbst erledigt oder durch eine Werkstatt.
 *  - Ein Vorgang ist offen oder erledigt. Nichts wird gelöscht.
 *  - Ein Vorgang gehört zum Fahrzeug oder zu einer Komponente.
 *
 * Hier steht nur Beschreibung und Rechnung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var ARTEN = [
    { wert: 'stoerung', label: 'Störung' },
    { wert: 'arbeit', label: 'Arbeit' }
  ];
  var AUSWIRKUNGEN = [
    { wert: 'keine', label: 'Fahrzeug bleibt nutzbar' },
    { wert: 'bedingt', label: 'Nur bedingt einsatzfähig' },
    { wert: 'nicht', label: 'Nicht einsatzfähig' }
  ];
  var AUSFUEHRUNGEN = [
    { wert: 'selbst', label: 'Selbst erledigen' },
    { wert: 'werkstatt', label: 'Durch eine Werkstatt' }
  ];
  var STATUS = [
    { wert: 'offen', label: 'Offen' },
    { wert: 'erledigt', label: 'Erledigt' }
  ];

  function finde(liste, wert) {
    for (var i = 0; i < liste.length; i++) { if (liste[i].wert === wert) return liste[i]; }
    return null;
  }
  function labelVon(liste, wert) { var x = finde(liste, wert); return x ? x.label : null; }
  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }

  /* Felder, die der Nutzer eingibt oder ändert. Art und Status ändern sich nur über die Schritte
     „Arbeit daraus machen“, „Erledigt“ und „Wieder öffnen“. */
  function felder(art) {
    var f = [
      { key: 'beschreibung', label: art === 'arbeit' ? 'Beschreibung' : 'Was ist los?', typ: 'text', gruppe: 'vorgang',
        hilfe: art === 'arbeit' ? 'Zum Beispiel was gemacht werden soll oder warum' : 'Zum Beispiel wann es auftritt oder was du bemerkt hast' },
      { key: 'auswirkung', label: 'Wie weit ist das Fahrzeug eingeschränkt?', typ: 'auswahl', optionen: AUSWIRKUNGEN, gruppe: 'vorgang' },
      { key: 'gemeldetAm', label: art === 'arbeit' ? 'Eingetragen am' : 'Gemeldet am', typ: 'datum', gruppe: 'vorgang' }
    ];
    if (art === 'arbeit') {
      f.push({ key: 'ausfuehrung', label: 'Wer macht die Arbeit?', typ: 'auswahl', optionen: AUSFUEHRUNGEN, gruppe: 'arbeit' });
      f.push({ key: 'arbeit', label: 'Was soll gemacht werden?', typ: 'text', gruppe: 'arbeit', hilfe: 'Zum Beispiel Zündkerzen wechseln oder Kühler prüfen lassen' });
    }
    return f.map(kopie);
  }

  /* Alle gespeicherten Felder eines Vorgangs, für den Verlauf und den Vergleich. */
  function felderAlle() {
    return [
      { key: 'art', label: 'Art des Vorgangs', typ: 'auswahl', optionen: ARTEN },
      { key: 'beschreibung', label: 'Beschreibung', typ: 'text' },
      { key: 'auswirkung', label: 'Einschränkung', typ: 'auswahl', optionen: AUSWIRKUNGEN },
      { key: 'gemeldetAm', label: 'Gemeldet am', typ: 'datum' },
      { key: 'ausfuehrung', label: 'Wer macht die Arbeit', typ: 'auswahl', optionen: AUSFUEHRUNGEN },
      { key: 'arbeit', label: 'Was soll gemacht werden', typ: 'text' },
      { key: 'status', label: 'Stand', typ: 'auswahl', optionen: STATUS },
      { key: 'erledigtAm', label: 'Erledigt am', typ: 'datum' },
      { key: 'erledigtNotiz', label: 'Notiz zur Erledigung', typ: 'text' }
    ].map(kopie);
  }

  /* Bremst dieser Vorgang das Fahrzeug? Nur ein offener Vorgang mit Einschränkung. */
  function bremst(werte) {
    return !!werte && werte.status === 'offen' && (werte.auswirkung === 'nicht' || werte.auswirkung === 'bedingt');
  }

  /* Einsatzfähigkeit eines Fahrzeugs aus den Werten seiner Vorgänge: 'nicht', 'bedingt' oder 'ok'. */
  function einsatz(wertListe) {
    var stufe = 'ok';
    (wertListe || []).forEach(function (w) {
      if (!bremst(w)) return;
      if (w.auswirkung === 'nicht') stufe = 'nicht';
      else if (stufe === 'ok') stufe = 'bedingt';
    });
    return stufe;
  }

  /* Rang für die Sortierung: Was das Fahrzeug am meisten bremst, steht oben. */
  function rang(werte) {
    if (werte.status !== 'offen') return 0;
    return werte.auswirkung === 'nicht' ? 4 : (werte.auswirkung === 'bedingt' ? 3 : 2);
  }

  MM.Werkstatt = {
    ARTEN: ARTEN, AUSWIRKUNGEN: AUSWIRKUNGEN, AUSFUEHRUNGEN: AUSFUEHRUNGEN, STATUS: STATUS,
    felder: felder, felderAlle: felderAlle, labelVon: labelVon, bremst: bremst, einsatz: einsatz, rang: rang
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
