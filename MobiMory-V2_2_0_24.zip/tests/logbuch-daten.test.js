'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;

/* feste Uhr: 3. November 2026, 12:00 Ortszeit, jede Abfrage eine Sekunde später */
const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
function neueDaten() {
  let t = 0;
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
}
const foto = (inhalt, name) => { const b = new Blob([inhalt], { type: 'image/jpeg' }); Object.defineProperty(b, 'name', { value: name || 'foto.jpg' }); return b; };
const text = async blob => new TextDecoder().decode(await blob.arrayBuffer());

async function neu() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  await d.ereignisartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const ben = (await d.personAnlegen({ bezeichnung: 'Ben', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const toern = arten.find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const ea = await d.ereignisartenListe();
  const eart = n => ea.find(x => x.aktuell.werte.bezeichnung === n).objekt.id;
  return { d, boot, anna, ben, toern, eart };
}
async function mitAktivitaet(extra) {
  const c = await neu();
  const r = await c.d.aktivitaetAnlegen(Object.assign({ bezeichnung: 'Sommertörn', artId: c.toern, fahrzeugId: c.boot, vonDatum: '2026-12-01', vonZeit: '09:00', bisDatum: '2026-12-03', bisZeit: '17:30', verantwortlichId: c.anna }, extra || {}));
  assert.ok(r.ok);
  c.id = r.id;
  return c;
}
const ereignisWerte = (c, extra) => Object.assign({ artId: c.eart('Abfahrt'), datum: '2026-12-01', zeit: '09:15', text: 'Leinen los' }, extra || {});

test('Speicher: Datenbank-Version 9 mit den neuen Tabellen', () => {
  assert.equal(MM.Speicher.DB_VERSION, 10);
  ['tagesabschnitte', 'tagespruefungen', 'ereignisse', 'ereignisarten', 'ereignisdateien'].forEach(n => assert.ok(MM.Speicher.TABELLEN.includes(n), n));
});

test('Ereignisarten: Vorschläge übernehmen, nur die fehlenden, eigene Art, doppelt nicht, ausblenden mit Verlauf', async () => {
  const d = neueDaten(); await d.starten();
  assert.equal((await d.ereignisartenAusVorschlaegen()).anzahl, 5);
  assert.equal((await d.ereignisartenAusVorschlaegen()).anzahl, 0);
  const liste = await d.ereignisartenListe();
  assert.deepEqual(liste.map(x => x.aktuell.werte.bezeichnung), ['Abfahrt', 'Ankunft', 'Notiz', 'Störung', 'Wechsel des Verantwortlichen']);
  const neuArt = await d.ereignisartAnlegen({ bezeichnung: 'Segel gesetzt' });
  assert.ok(neuArt.ok);
  assert.ok((await d.ereignisartAnlegen({ bezeichnung: 'segel GESETZT' })).fehler.bezeichnung);
  assert.ok((await d.ereignisartAnlegen({ bezeichnung: '  ' })).fehler.bezeichnung);
  const r = await d.ereignisartAendern(neuArt.id, { bezeichnung: 'Segel gesetzt', ausgeblendet: 'ja' });
  assert.equal(r.geaendert, true);
  const x = await d.ereignisartLaden(neuArt.id);
  assert.equal(x.aktuell.werte.ausgeblendet, 'ja');
  assert.equal(x.verlauf.length, 2, 'der frühere Stand bleibt im Verlauf');
  assert.equal((await d.ereignisartAendern('gibt-es-nicht', { bezeichnung: 'X' })).ok, false);
});

test('Tage vorbereiten: ein Abschnitt je Tag, Uhrzeit nur am ersten und letzten, ein zweites Mal nichts Neues', async () => {
  const c = await mitAktivitaet();
  const r = await c.d.tagesabschnitteVorbereiten(c.id);
  assert.deepEqual([r.ok, r.anzahl], [true, 3]);
  const l = await c.d.logbuchLaden(c.id);
  assert.deepEqual(l.abschnitte.map(x => x.aktuell.werte.datum), ['2026-12-01', '2026-12-02', '2026-12-03']);
  assert.equal(l.abschnitte[0].aktuell.werte.beginnZeit, '09:00');
  assert.equal(l.abschnitte[2].aktuell.werte.endeZeit, '17:30');
  assert.equal(l.abschnitte[0].objekt.herkunft, 'vorbereitet');
  assert.equal(l.fehlend, 0);
  assert.equal((await c.d.tagesabschnitteVorbereiten(c.id)).anzahl, 0);
  assert.equal((await c.d.logbuchLaden(c.id)).abschnitte.length, 3);
});

test('Tage vorbereiten: ändert sich der Zeitraum, kommen nur die neuen Tage dazu; ausgeblendete Tage kommen nicht zurück; nichts wird gelöscht', async () => {
  const c = await mitAktivitaet();
  await c.d.tagesabschnitteVorbereiten(c.id);
  const l = await c.d.logbuchLaden(c.id);
  const mitte = l.abschnitte[1];
  const w = Object.assign({}, mitte.aktuell.werte);
  assert.ok((await c.d.abschnittAendern(mitte.objekt.id, Object.assign({}, w, { ausgeblendet: 'ja' }))).ok);
  const akt = await c.d.aktivitaetLaden(c.id);
  assert.ok((await c.d.aktivitaetAendern(c.id, Object.assign({}, akt.aktuell.werte, { bisDatum: '2026-12-05', bisZeit: '' , verantwortlichId: c.anna }))).ok);
  const vorher = await c.d.logbuchLaden(c.id);
  assert.equal(vorher.fehlend, 2);
  assert.equal((await c.d.tagesabschnitteVorbereiten(c.id)).anzahl, 2);
  const nachher = await c.d.logbuchLaden(c.id);
  assert.deepEqual(nachher.abschnitte.map(x => x.aktuell.werte.datum), ['2026-12-01', '2026-12-02', '2026-12-03', '2026-12-04', '2026-12-05']);
  assert.equal(nachher.abschnitte[1].ausgeblendet, true, 'der ausgeblendete Tag bleibt ausgeblendet und kommt nicht doppelt');
  /* Zeitraum wird kürzer: überzählige Tage bleiben, werden nur als „außerhalb“ markiert */
  const akt2 = await c.d.aktivitaetLaden(c.id);
  await c.d.aktivitaetAendern(c.id, Object.assign({}, akt2.aktuell.werte, { bisDatum: '2026-12-02' }));
  const kurz = await c.d.logbuchLaden(c.id);
  assert.equal(kurz.abschnitte.length, 5);
  assert.deepEqual(kurz.abschnitte.map(x => x.ausserhalb), [false, false, true, true, true]);
});

test('Tage vorbereiten: zu langer Zeitraum wird abgelehnt, unbekannte Aktivität auch', async () => {
  const c = await mitAktivitaet({ vonDatum: '2028-01-01', bisDatum: '2029-06-01' });
  const r = await c.d.tagesabschnitteVorbereiten(c.id);
  assert.equal(r.ok, false); assert.match(r.fehler.allgemein, /länger als 366 Tage/);
  assert.equal((await c.d.logbuchLaden(c.id)).zuLang, true);
  assert.equal((await c.d.tagesabschnitteVorbereiten('gibt-es-nicht')).ok, false);
  assert.equal(await c.d.logbuchLaden('gibt-es-nicht'), null);
});

test('Tag von Hand ergänzen und ändern: Pflichtangaben, Verlauf, ausblenden, Korrektur bleibt sichtbar', async () => {
  const c = await mitAktivitaet();
  assert.ok((await c.d.abschnittAnlegen(c.id, { datum: '' })).fehler.datum);
  assert.ok((await c.d.abschnittAnlegen(c.id, { datum: '2026-13-45' })).fehler.datum);
  assert.ok((await c.d.abschnittAnlegen(c.id, { datum: '2026-12-01', beginnZeit: '18:00', endeZeit: '08:00' })).fehler.endeZeit);
  assert.ok((await c.d.abschnittAnlegen(c.id, { datum: '2026-12-01', beginnZeit: '25:00' })).fehler.beginnZeit);
  const r = await c.d.abschnittAnlegen(c.id, { datum: '2026-12-02', beginnZeit: '07:00', endeZeit: '19:00', von: 'Biograd', nach: 'Zadar', notiz: 'Bora erwartet' });
  assert.ok(r.ok);
  const x = (await c.d.abschnittLaden(r.id)).abschnitt;
  assert.equal(x.objekt.herkunft, 'hand');
  assert.equal(x.aktuell.werte.von, 'Biograd'); assert.equal(x.aktuell.werte.nach, 'Zadar');
  assert.equal(x.aktuell.quelle, 'hand');
  const ae = await c.d.abschnittAendern(r.id, { datum: '2026-12-02', beginnZeit: '07:00', endeZeit: '19:00', von: 'Biograd', nach: 'Kornati', notiz: 'Bora erwartet', ausgeblendet: 'nein' });
  assert.equal(ae.geaendert, true);
  assert.equal((await c.d.abschnittAendern(r.id, { datum: '2026-12-02', beginnZeit: '07:00', endeZeit: '19:00', von: 'Biograd', nach: 'Kornati', notiz: 'Bora erwartet', ausgeblendet: 'nein' })).geaendert, false);
  const y = (await c.d.abschnittLaden(r.id)).abschnitt;
  assert.equal(y.verlauf.length, 2);
  assert.deepEqual(y.verlauf[0].aenderungen.map(u => [u.key, u.alt, u.neu]), [['nach', 'Zadar', 'Kornati']]);
  await c.d.abschnittAendern(r.id, Object.assign({}, y.aktuell.werte, { ausgeblendet: 'ja' }));
  assert.equal((await c.d.abschnittLaden(r.id)).abschnitt.ausgeblendet, true);
  assert.equal((await c.d.abschnittLaden('gibt-es-nicht')), null);
  assert.equal((await c.d.abschnittAendern('gibt-es-nicht', { datum: '2026-12-02' })).ok, false);
});

test('Ereignis eintragen: Pflichtangaben, Art aus der Liste, Verlauf, ändern, ausblenden', async () => {
  const c = await mitAktivitaet();
  const tag = (await c.d.abschnittAnlegen(c.id, { datum: '2026-12-01' })).id;
  assert.ok((await c.d.ereignisAnlegen(tag, ereignisWerte(c, { artId: '' }))).fehler.artId);
  assert.ok((await c.d.ereignisAnlegen(tag, ereignisWerte(c, { artId: 'gibt-es-nicht' }))).fehler.artId);
  assert.ok((await c.d.ereignisAnlegen(tag, ereignisWerte(c, { datum: '' }))).fehler.datum);
  assert.ok((await c.d.ereignisAnlegen(tag, ereignisWerte(c, { zeit: '' }))).fehler.zeit);
  assert.equal((await c.d.ereignisAnlegen('gibt-es-nicht', ereignisWerte(c))).ok, false);
  const r = await c.d.ereignisAnlegen(tag, ereignisWerte(c));
  assert.ok(r.ok);
  const x = await c.d.ereignisLaden(r.id);
  assert.equal(x.art.name, 'Abfahrt'); assert.equal(x.aktuell.werte.text, 'Leinen los');
  assert.equal(x.aktuell.werte.nachgetragen, 'nein'); assert.equal(x.datei, null);
  assert.equal(x.abschnitt.objekt.id, tag);

  const ae = await c.d.ereignisAendern(r.id, ereignisWerte(c, { zeit: '09:40', artId: c.eart('Notiz') }));
  assert.equal(ae.geaendert, true);
  const y = await c.d.ereignisLaden(r.id);
  assert.equal(y.verlauf.length, 2);
  assert.deepEqual(y.verlauf[0].aenderungen.map(u => u.key).sort(), ['artId', 'zeit']);
  assert.deepEqual(y.verlauf[0].aenderungen.find(u => u.key === 'artId').alt, 'Abfahrt', 'im Verlauf steht der Name der Art');
  assert.equal((await c.d.ereignisAendern(r.id, ereignisWerte(c, { zeit: '09:40', artId: c.eart('Notiz') }))).geaendert, false);

  await c.d.ereignisAendern(r.id, ereignisWerte(c, { zeit: '09:40', artId: c.eart('Notiz'), ausgeblendet: 'ja' }));
  const l = await c.d.logbuchLaden(c.id);
  const tg = l.abschnitte.find(a => a.objekt.id === tag);
  assert.equal(tg.ereignisse.length, 1, 'ausgeblendet ist nicht gelöscht');
  assert.equal(tg.ereignisse[0].ausgeblendet, true);
  assert.equal(tg.anzahlEreignisse, 0);
  assert.equal((await c.d.ereignisAendern('gibt-es-nicht', ereignisWerte(c))).ok, false);
});

test('Ereignis: eine ausgeblendete Art ist nicht mehr wählbar, an einem bestehenden Ereignis bleibt sie', async () => {
  const c = await mitAktivitaet();
  const tag = (await c.d.abschnittAnlegen(c.id, { datum: '2026-12-01' })).id;
  const r = await c.d.ereignisAnlegen(tag, ereignisWerte(c));
  await c.d.ereignisartAendern(c.eart('Abfahrt'), { bezeichnung: 'Abfahrt', ausgeblendet: 'ja' });
  assert.ok((await c.d.ereignisAnlegen(tag, ereignisWerte(c))).fehler.artId);
  assert.ok((await c.d.ereignisAendern(r.id, ereignisWerte(c, { text: 'anderer Text' }))).ok, 'die schon gewählte Art bleibt gültig');
});

test('Ohne Ereignisarten gibt es eine verständliche Meldung', async () => {
  const d = neueDaten(); await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const p = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const art = (await d.aktivitaetsartenListe())[0].objekt.id;
  const a = (await d.aktivitaetAnlegen({ bezeichnung: 'T', artId: art, fahrzeugId: fz, vonDatum: '2026-12-01', bisDatum: '2026-12-02', verantwortlichId: p })).id;
  const tag = (await d.abschnittAnlegen(a, { datum: '2026-12-01' })).id;
  const r = await d.ereignisAnlegen(tag, { artId: '', datum: '2026-12-01', zeit: '10:00' });
  assert.match(r.fehler.artId, /noch keine Art/);
});

test('Nachtragen: der echte Zeitpunkt in der Vergangenheit, markiert mit „nachgetragen am“; in der Zukunft nicht', async () => {
  const c = await mitAktivitaet({ vonDatum: '2026-10-30', bisDatum: '2026-11-05' });
  const tag = (await c.d.abschnittAnlegen(c.id, { datum: '2026-11-02' })).id;
  const zukunft = await c.d.ereignisAnlegen(tag, ereignisWerte(c, { datum: '2026-11-03', zeit: '12:30' }), { nachtragen: true });
  assert.equal(zukunft.ok, false);
  assert.match(zukunft.fehler.zeit, /Vergangenheit/);
  assert.ok((await c.d.ereignisAnlegen(tag, ereignisWerte(c, { datum: '2026-11-03', zeit: '12:30' }))).ok, 'ohne Nachtragen ist die Uhrzeit frei');
  const r = await c.d.ereignisAnlegen(tag, ereignisWerte(c, { datum: '2026-11-02', zeit: '18:45', text: 'Ankunft Hafen, vergessen einzutragen' }), { nachtragen: true });
  assert.ok(r.ok);
  const x = await c.d.ereignisLaden(r.id);
  assert.equal(x.aktuell.werte.nachgetragen, 'ja');
  assert.ok(x.aktuell.werte.nachgetragenAm);
  assert.equal(x.aktuell.werte.zeit, '18:45', 'der echte Zeitpunkt steht im Ereignis');
  const e = (await c.d.logbuchLaden(c.id)).abschnitte.find(a => a.objekt.id === tag).ereignisse.find(y => y.id === r.id);
  assert.equal(e.nachgetragen, true); assert.ok(e.nachgetragenAm);
  /* Die Markierung bleibt auch bei einer späteren Korrektur */
  await c.d.ereignisAendern(r.id, ereignisWerte(c, { datum: '2026-11-02', zeit: '18:50' }));
  assert.equal((await c.d.ereignisLaden(r.id)).aktuell.werte.nachgetragen, 'ja');
  assert.ok((await c.d.ereignisAendern(r.id, ereignisWerte(c, { datum: '2026-11-04', zeit: '10:00' }))).fehler.zeit, 'auch korrigiert bleibt ein Nachtrag in der Vergangenheit');
});

test('Foto zum Ereignis: freiwillig, bleibt erhalten, leere Datei wird abgelehnt', async () => {
  const c = await mitAktivitaet();
  const tag = (await c.d.abschnittAnlegen(c.id, { datum: '2026-12-01' })).id;
  const leer = await c.d.ereignisAnlegen(tag, ereignisWerte(c, { datei: foto('') }));
  assert.ok(leer.fehler.datei);
  const r = await c.d.ereignisAnlegen(tag, ereignisWerte(c, { datei: foto('FOTO-BYTES', 'hafen.jpg') }));
  assert.ok(r.ok);
  const x = await c.d.ereignisLaden(r.id);
  assert.equal(x.datei.name, 'hafen.jpg'); assert.equal(x.aktuell.werte.dateiName, 'hafen.jpg');
  assert.equal(await text((await c.d.ereignisDateiHolen(r.id)).inhalt), 'FOTO-BYTES');
  assert.equal((await c.d.logbuchLaden(c.id)).abschnitte[0].ereignisse[0].hatFoto, true);
  /* Eine Änderung lässt das Foto unberührt */
  await c.d.ereignisAendern(r.id, ereignisWerte(c, { text: 'neu' }));
  assert.equal(await text((await c.d.ereignisDateiHolen(r.id)).inhalt), 'FOTO-BYTES');
  assert.equal((await c.d.ereignisLaden(r.id)).aktuell.werte.dateiName, 'hafen.jpg');
  assert.equal(await c.d.ereignisDateiHolen('gibt-es-nicht'), null);
});

test('Wechsel des Verantwortlichen erscheint automatisch als Ereignis im passenden Tag, der Beginn nicht', async () => {
  const c = await mitAktivitaet();
  await c.d.tagesabschnitteVorbereiten(c.id);
  assert.ok((await c.d.besatzungHinzufuegen(c.id, c.ben, { rolle: 'stellvertreter' })).ok);
  let l = await c.d.logbuchLaden(c.id);
  assert.ok(l.abschnitte.every(a => a.ereignisse.length === 0), 'der Beginn ist kein Wechsel');
  assert.ok((await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-12-02', abZeit: '10:30' })).ok);
  l = await c.d.logbuchLaden(c.id);
  assert.deepEqual(l.abschnitte.map(a => a.ereignisse.length), [0, 1, 0]);
  const e = l.abschnitte[1].ereignisse[0];
  assert.equal(e.art, 'wechsel'); assert.equal(e.artName, 'Wechsel des Verantwortlichen');
  assert.equal(e.zeit, '10:30'); assert.equal(e.zeitpunkt, '2026-12-02T10:30');
  assert.equal(e.text, 'Ben ist ab jetzt verantwortlich (vorher Anna).');
  assert.equal(e.geaendert, false);
  /* Ohne Abschnitte entsteht nichts von selbst */
  const c2 = await mitAktivitaet();
  await c2.d.besatzungHinzufuegen(c2.id, c2.ben, { rolle: 'stellvertreter' });
  await c2.d.verantwortungWechseln(c2.id, c2.ben, { abDatum: '2026-12-02', abZeit: '10:30' });
  assert.equal((await c2.d.logbuchLaden(c2.id)).abschnitte.length, 0);
});

test('Wechsel korrigieren: Uhrzeit und Tag ändern, der Verlauf bleibt, die Verantwortung folgt, Reihenfolge wird geschützt', async () => {
  const c = await mitAktivitaet();
  await c.d.tagesabschnitteVorbereiten(c.id);
  await c.d.besatzungHinzufuegen(c.id, c.ben, { rolle: 'stellvertreter' });
  await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-12-02', abZeit: '10:30' });
  await c.d.verantwortungWechseln(c.id, c.anna, { abDatum: '2026-12-03', abZeit: '08:00' });
  const a0 = await c.d.aktivitaetLaden(c.id);
  const [v1, v2, v3] = a0.verantwortung;
  assert.equal(await c.d.wechselLaden(v1.id), null, 'der Beginn ist kein Wechsel');
  assert.equal(await c.d.wechselLaden('gibt-es-nicht'), null);

  const frueh = await c.d.wechselAendern(v2.id, { abDatum: '2026-12-01', abZeit: '08:00' });
  assert.match(frueh.fehler.abDatum, /nach dem vorherigen Wechsel/);
  const spaet = await c.d.wechselAendern(v2.id, { abDatum: '2026-12-03', abZeit: '08:00' });
  assert.match(spaet.fehler.abDatum, /vor dem nächsten Wechsel/);
  assert.ok((await c.d.wechselAendern(v2.id, { abDatum: '', abZeit: '' })).fehler.abDatum);
  assert.ok((await c.d.wechselAendern(v2.id, { abDatum: '2026-12-02', abZeit: '' })).fehler.abZeit);

  const r = await c.d.wechselAendern(v2.id, { abDatum: '2026-12-01', abZeit: '20:15', notiz: 'Wachwechsel am Abend' });
  assert.deepEqual([r.ok, r.geaendert], [true, true]);
  const a1 = await c.d.aktivitaetLaden(c.id);
  assert.equal(a1.verantwortung[1].ab, '2026-12-01T20:15', 'die Verantwortung folgt der Korrektur');
  assert.equal(a1.verantwortung[1].abUrspruenglich, '2026-12-02T10:30', 'der ursprüngliche Zeitpunkt bleibt sichtbar');
  assert.equal(a1.verantwortung[1].geaendert, true);
  const l = await c.d.logbuchLaden(c.id);
  assert.deepEqual(l.abschnitte.map(a => a.ereignisse.length), [1, 0, 1], 'das Ereignis wandert in den Tag der Korrektur');
  assert.equal(l.abschnitte[0].ereignisse[0].geaendert, true);
  assert.equal(l.abschnitte[0].ereignisse[0].notiz, 'Wachwechsel am Abend');
  assert.equal(l.abschnitte[1].verantwortlicher.name, 'Ben', 'am Beginn des 2. Tages ist nach der Korrektur schon Ben verantwortlich');

  const w = await c.d.wechselLaden(v2.id);
  assert.equal(w.verlauf.length, 2, 'der Ausgangsstand und die Korrektur');
  assert.deepEqual(w.verlauf[0].aenderungen.map(u => u.key).sort(), ['abDatum', 'abZeit', 'notiz']);
  assert.equal(w.verlauf[1].eintrag.werte.abDatum, '2026-12-02');
  assert.equal((await c.d.wechselAendern(v2.id, { abDatum: '2026-12-01', abZeit: '20:15', notiz: 'Wachwechsel am Abend' })).geaendert, false);

  await c.d.wechselAendern(v2.id, { abDatum: '2026-12-01', abZeit: '20:15', notiz: 'Wachwechsel am Abend', ausgeblendet: 'ja' });
  const ausg = (await c.d.logbuchLaden(c.id)).abschnitte[0].ereignisse[0];
  assert.equal(ausg.ausgeblendet, true);
  assert.equal((await c.d.aktivitaetLaden(c.id)).verantwortung.length, 3, 'ausblenden löscht den Wechsel nicht');
  assert.equal((await c.d.wechselLaden(v2.id)).verlauf.length, 3);
});

test('Wechsel: die Prüfung „wer ist jetzt verantwortlich“ nutzt den korrigierten Zeitpunkt', async () => {
  const c = await mitAktivitaet({ vonDatum: '2026-10-30', bisDatum: '2026-11-10' });
  await c.d.besatzungHinzufuegen(c.id, c.ben, { rolle: 'stellvertreter' });
  await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-11-05', abZeit: '10:00' });
  assert.equal((await c.d.aktivitaetLaden(c.id)).verantwortlichJetzt.name, 'Anna');
  const v = (await c.d.aktivitaetLaden(c.id)).verantwortung[1];
  await c.d.wechselAendern(v.id, { abDatum: '2026-11-02', abZeit: '08:00' });
  assert.equal((await c.d.aktivitaetLaden(c.id)).verantwortlichJetzt.name, 'Ben', 'jetzt ist der 3.11., der Wechsel liegt nach der Korrektur davor');
  /* ein neuer Wechsel muss nach dem korrigierten kommen */
  const neu = await c.d.verantwortungWechseln(c.id, c.anna, { abDatum: '2026-11-02', abZeit: '07:00' });
  assert.equal(neu.ok, false);
});

test('Prüfung zum Tagesbeginn festhalten: mit „geprüft am“ und dem Verantwortlichen dieses Tages, nur anhängen', async () => {
  const c = await mitAktivitaet();
  await c.d.tagesabschnitteVorbereiten(c.id);
  await c.d.besatzungHinzufuegen(c.id, c.ben, { rolle: 'stellvertreter' });
  await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-12-02', abZeit: '10:30' });
  const l = await c.d.logbuchLaden(c.id);
  assert.equal(l.abschnitte[0].pruefung, null);
  assert.equal(l.abschnitte[0].verantwortlicher.name, 'Anna');
  assert.equal(l.abschnitte[1].verantwortlicher.name, 'Anna', 'um 00:00 am 2. Dezember ist noch Anna verantwortlich');
  assert.equal(l.abschnitte[2].verantwortlicher.name, 'Ben');

  const r = await c.d.tagesPruefungFesthalten(l.abschnitte[2].objekt.id);
  assert.ok(r.ok);
  const x = (await c.d.abschnittLaden(l.abschnitte[2].objekt.id)).abschnitt;
  const p = x.pruefung.stand;
  assert.match(p.geprueftAm, /^2026-11-03T\d\d:\d\d$/);
  assert.equal(p.tagesbeginn, '2026-12-03T00:00');
  assert.equal(p.verantwortlich.name, 'Ben');
  assert.ok(['erlaubt', 'nicht_erlaubt', 'unklar'].includes(p.befaehigung.ergebnis));
  assert.deepEqual(p.befaehigung.personen.map(q => q.name).sort(), ['Anna', 'Ben']);
  assert.ok(p.fristen && Array.isArray(p.fristen.liste));
  /* Die Prüfung gehört nur zu diesem Tag */
  assert.equal((await c.d.abschnittLaden(l.abschnitte[0].objekt.id)).abschnitt.pruefung, null);

  /* Eine zweite Prüfung überschreibt nichts: die neue steht oben, die alte bleibt */
  await c.d.tagesPruefungFesthalten(l.abschnitte[2].objekt.id);
  const y = (await c.d.abschnittLaden(l.abschnitte[2].objekt.id)).abschnitt;
  assert.equal(y.pruefungen.length, 2);
  assert.ok(y.pruefungen[0].erstelltAm > y.pruefungen[1].erstelltAm);
  assert.equal((await c.d.tagesPruefungFesthalten('gibt-es-nicht')).ok, false);
});

test('Prüfung festhalten: der festgehaltene Stand ändert sich nicht, wenn sich später Namen oder Nachweise ändern', async () => {
  const c = await mitAktivitaet();
  const tag = (await c.d.abschnittAnlegen(c.id, { datum: '2026-12-01', beginnZeit: '09:00' })).id;
  await c.d.tagesPruefungFesthalten(tag);
  const vorher = JSON.stringify((await c.d.abschnittLaden(tag)).abschnitt.pruefung.stand);
  const p = await c.d.personLaden(c.anna);
  await c.d.personAendern(c.anna, Object.assign({}, p.aktuell.werte, { bezeichnung: 'Anna Neu' }));
  assert.equal(JSON.stringify((await c.d.abschnittLaden(tag)).abschnitt.pruefung.stand), vorher);
  assert.match(vorher, /Anna/);
  assert.ok(!vorher.includes('Anna Neu'));
});

test('Stornierte Aktivität: im Logbuch kommt nichts Neues dazu, alles bleibt lesbar; nach dem Wiederherstellen geht es weiter', async () => {
  const c = await mitAktivitaet();
  await c.d.tagesabschnitteVorbereiten(c.id);
  const l = await c.d.logbuchLaden(c.id);
  const tag = l.abschnitte[0].objekt.id;
  const e = await c.d.ereignisAnlegen(tag, ereignisWerte(c));
  await c.d.besatzungHinzufuegen(c.id, c.ben, { rolle: 'stellvertreter' });
  await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-12-02', abZeit: '10:30' });
  await c.d.aktivitaetStornieren(c.id, 'Sturm');
  const gesperrt = 'storniert';
  assert.match((await c.d.tagesabschnitteVorbereiten(c.id)).fehler.allgemein, new RegExp(gesperrt));
  assert.match((await c.d.abschnittAnlegen(c.id, { datum: '2026-12-09' })).fehler.allgemein, new RegExp(gesperrt));
  assert.match((await c.d.abschnittAendern(tag, { datum: '2026-12-01' })).fehler.allgemein, new RegExp(gesperrt));
  assert.match((await c.d.ereignisAnlegen(tag, ereignisWerte(c))).fehler.allgemein, new RegExp(gesperrt));
  assert.match((await c.d.ereignisAendern(e.id, ereignisWerte(c, { text: 'x' }))).fehler.allgemein, new RegExp(gesperrt));
  assert.match((await c.d.tagesPruefungFesthalten(tag)).fehler.allgemein, new RegExp(gesperrt));
  const v = (await c.d.aktivitaetLaden(c.id)).verantwortung[1];
  assert.match((await c.d.wechselAendern(v.id, { abDatum: '2026-12-02', abZeit: '11:00' })).fehler.allgemein, new RegExp(gesperrt));
  const lesen = await c.d.logbuchLaden(c.id);
  assert.equal(lesen.abschnitte.length, 3);
  assert.equal(lesen.abschnitte[0].ereignisse.length, 1);
  await c.d.aktivitaetWiederherstellen(c.id);
  assert.ok((await c.d.ereignisAnlegen(tag, ereignisWerte(c))).ok);
});

test('Logbuch gehört zur Aktivität: Tage und Ereignisse einer anderen Aktivität erscheinen nicht', async () => {
  const c = await mitAktivitaet();
  const zweite = (await c.d.aktivitaetAnlegen({ bezeichnung: 'Herbst', artId: c.toern, fahrzeugId: c.boot, vonDatum: '2027-05-01', bisDatum: '2027-05-02', verantwortlichId: c.anna })).id;
  await c.d.tagesabschnitteVorbereiten(c.id);
  await c.d.tagesabschnitteVorbereiten(zweite);
  const l1 = await c.d.logbuchLaden(c.id), l2 = await c.d.logbuchLaden(zweite);
  assert.equal(l1.abschnitte.length, 3); assert.equal(l2.abschnitte.length, 2);
  await c.d.ereignisAnlegen(l2.abschnitte[0].objekt.id, ereignisWerte(c, { datum: '2027-05-01' }));
  assert.equal((await c.d.logbuchLaden(c.id)).abschnitte.reduce((s, a) => s + a.ereignisse.length, 0), 0);
  assert.equal((await c.d.logbuchLaden(zweite)).abschnitte[0].ereignisse.length, 1);
});

test('Sicherung: Tage, Ereignisse, Prüfungen, Wechsel-Korrekturen und Foto kommen mit und sind nach dem Einspielen wieder da', async () => {
  const c = await mitAktivitaet();
  await c.d.tagesabschnitteVorbereiten(c.id);
  await c.d.besatzungHinzufuegen(c.id, c.ben, { rolle: 'stellvertreter' });
  await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-12-02', abZeit: '10:30' });
  const v = (await c.d.aktivitaetLaden(c.id)).verantwortung[1];
  await c.d.wechselAendern(v.id, { abDatum: '2026-12-02', abZeit: '11:00', notiz: 'später' });
  const tag = (await c.d.logbuchLaden(c.id)).abschnitte[0].objekt.id;
  const e = await c.d.ereignisAnlegen(tag, ereignisWerte(c, { datei: foto('FOTO-IN-SICHERUNG', 'x.jpg') }));
  await c.d.tagesPruefungFesthalten(tag);

  const z = await c.d.sicherungZahlen();
  assert.equal(z.tagesabschnitte, 3); assert.equal(z.ereignisse, 1);
  assert.equal(z.dateien, 1);
  const s = await c.d.sicherungErzeugen({ mitDateien: true });
  assert.equal(s.zahlen.tagesabschnitte, 3); assert.equal(s.zahlen.ereignisse, 1); assert.equal(s.dateien, 1);

  const b = neueDaten(); await b.starten();
  const g = await b.sicherungLesen(s.bytes, '');
  const vor = await b.sicherungVorschau(g);
  assert.equal(vor.zahlen.tagesabschnitte, 3); assert.equal(vor.zahlen.ereignisse, 1);
  await b.sicherungEinspielen(g);
  const l = await b.logbuchLaden(c.id);
  assert.equal(l.abschnitte.length, 3);
  assert.equal(l.abschnitte[0].ereignisse.length, 1);
  assert.equal(l.abschnitte[0].pruefungen.length, 1);
  assert.equal(l.abschnitte[1].ereignisse[0].zeit, '11:00', 'die Korrektur des Wechsels ist mitgesichert');
  assert.equal(l.abschnitte[1].ereignisse[0].notiz, 'später');
  assert.equal(await text((await b.ereignisDateiHolen(e.id)).inhalt), 'FOTO-IN-SICHERUNG');

  /* ohne Dateien: das Ereignis ist da, das Foto nicht */
  const s2 = await c.d.sicherungErzeugen({ mitDateien: false });
  const b2 = neueDaten(); await b2.starten();
  await b2.sicherungEinspielen(await b2.sicherungLesen(s2.bytes, ''));
  assert.equal((await b2.logbuchLaden(c.id)).abschnitte[0].ereignisse.length, 1);
  assert.equal(await b2.ereignisDateiHolen(e.id), null);
});

test('Alte Sicherungen (Datenbank-Version 8, ohne Logbuch) lassen sich weiter einspielen', async () => {
  const c = await mitAktivitaet();
  await c.d.tagesabschnitteVorbereiten(c.id);
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  const gelesen = await c.d.sicherungLesen(s.bytes, '');
  const alt = JSON.parse(JSON.stringify({ kopf: gelesen.kopf, dateien: [] }));
  alt.kopf.dbVersion = 8; alt.kopf.app = '2.0.12';
  ['tagesabschnitte', 'tagespruefungen', 'ereignisse', 'ereignisarten', 'ereignisdateien'].forEach(n => { delete alt.kopf.tabellen[n]; if (alt.kopf.zaehlung) delete alt.kopf.zaehlung[n]; });
  const verantw = alt.kopf.tabellen.verantwortung.length;
  const d = neueDaten(); await d.starten();
  await d.sicherungEinspielen(alt);
  assert.equal((await d.aktivitaetenListe()).length, 1, 'die Aktivität aus der alten Sicherung ist da');
  const l = await d.logbuchLaden(c.id);
  assert.equal(l.abschnitte.length, 0, 'ohne Logbuch-Tabellen ist das Logbuch leer');
  assert.equal(l.fehlend, 3);
  assert.equal((await d.aktivitaetLaden(c.id)).verantwortung.length, verantw);
  assert.equal((await d.tagesabschnitteVorbereiten(c.id)).anzahl, 3, 'nach dem Einspielen lässt sich das Logbuch ganz normal beginnen');
  assert.equal((await d.ereignisartenAusVorschlaegen()).anzahl, 5);
});

test('Wechsel ohne Korrektur verhalten sich wie vor 2.0.13: Verantwortung und Zeitpunkte unverändert', async () => {
  const c = await mitAktivitaet();
  await c.d.besatzungHinzufuegen(c.id, c.ben, { rolle: 'stellvertreter' });
  await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-12-02', abZeit: '10:30' });
  const a = await c.d.aktivitaetLaden(c.id);
  assert.deepEqual(a.verantwortung.map(v => [v.name, v.ab]), [['Anna', '2026-12-01T09:00'], ['Ben', '2026-12-02T10:30']]);
  assert.ok(a.verantwortung.every(v => v.geaendert === false && v.ab === v.abUrspruenglich));
});
