'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/daten.js');
const MM = globalThis.MM;

const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = n => arten.find(x => x.aktuell.werte.bezeichnung === n).objekt.id;
  const fuehrerschein = (await d.nachweisartAnlegen({ bezeichnung: 'Sportbootführerschein', gehoertZu: 'person', hatAblauf: 'nein' }));
  return { d, boot, wm, anna, artId, fuehrerschein };
}
const akt = (c, extra) => Object.assign({ bezeichnung: 'Törn', artId: c.artId('Törn'), fahrzeugId: c.boot, vonDatum: '2026-12-01', bisDatum: '2026-12-10', verantwortlichId: c.anna }, extra || {});

test('Orte und Standorte: anlegen, Hierarchie, Namen eindeutig, ändern mit Verlauf, ausblenden', async () => {
  const { d } = await neu();
  assert.ok((await d.ortAnlegen({ bezeichnung: ' ' })).fehler.bezeichnung);
  const o = await d.ortAnlegen({ bezeichnung: 'Hafen Biograd', land: 'Kroatien' });
  assert.ok(o.ok);
  assert.ok((await d.ortAnlegen({ bezeichnung: 'hafen biograd' })).fehler.bezeichnung);
  const s = await d.standortAnlegen(o.id, { bezeichnung: 'Liegeplatz 12', standortart: 'Liegeplatz' });
  assert.ok(s.ok);
  assert.ok((await d.standortAnlegen(o.id, { bezeichnung: 'Liegeplatz 12' })).fehler.bezeichnung);
  const o2 = await d.ortAnlegen({ bezeichnung: 'Zuhause' });
  assert.ok((await d.standortAnlegen(o2.id, { bezeichnung: 'Liegeplatz 12' })).ok, 'gleicher Name an anderem Ort ist erlaubt');
  assert.equal((await d.standortAnlegen('gibt-es-nicht', { bezeichnung: 'X' })).ok, false);

  const x = await d.ortLaden(o.id);
  assert.equal(x.aktuell.werte.land, 'Kroatien');
  assert.equal(x.aktuell.werte.herkunft, 'eigen');
  assert.deepEqual(x.standorte.map(y => y.aktuell.werte.bezeichnung), ['Liegeplatz 12']);
  assert.equal((await d.ortAendern(o.id, { bezeichnung: 'Hafen Biograd', land: 'Kroatien' })).geaendert, false);
  const ae = await d.ortAendern(o.id, { bezeichnung: 'Hafen Biograd na Moru', land: 'Kroatien', ausgeblendet: 'ja' });
  assert.equal(ae.geaendert, true);
  const y = await d.ortLaden(o.id);
  assert.equal(y.verlauf.length, 2);
  assert.equal(y.aktuell.werte.ausgeblendet, 'ja');
  assert.equal((await d.orteListe()).length, 2, 'ausgeblendete Orte bleiben in der Liste');
  assert.equal((await d.orteListe()).find(z => z.objekt.id === o.id).anzahlStandorte, 1);
});

test('Heimatstandort: wählen, ändern, entfernen, Verlauf, ungültiger Standort', async () => {
  const c = await neu(); const d = c.d;
  const o = (await d.ortAnlegen({ bezeichnung: 'Hafen' })).id;
  const s1 = (await d.standortAnlegen(o, { bezeichnung: 'Liegeplatz 1' })).id;
  const s2 = (await d.standortAnlegen(o, { bezeichnung: 'Liegeplatz 2' })).id;
  assert.equal((await d.fahrzeugStandort(c.boot)).standort, null);
  assert.equal((await d.fahrzeugStandortSetzen(c.boot, s1)).geaendert, true);
  assert.equal((await d.fahrzeugStandortSetzen(c.boot, s1)).geaendert, false);
  assert.equal((await d.fahrzeugStandortSetzen(c.boot, s2)).geaendert, true);
  const info = await d.fahrzeugStandort(c.boot);
  assert.equal(info.standort.name, 'Liegeplatz 2');
  assert.equal(info.standort.ortName, 'Hafen');
  assert.equal(info.verlauf.length, 2);
  assert.equal(info.verlauf[0].alt, 'Hafen, Liegeplatz 1');
  assert.equal((await d.fahrzeugStandortSetzen(c.boot, '')).geaendert, true);
  assert.equal((await d.fahrzeugStandort(c.boot)).standort, null);
  assert.equal((await d.fahrzeugStandort(c.boot)).verlauf.length, 3);
  assert.equal((await d.fahrzeugStandortSetzen(c.boot, 'nein')).ok, false);
  assert.equal((await d.fahrzeugStandortSetzen('nein', s1)).ok, false);
  assert.equal((await d.fahrzeugStandort(c.wm)).standort, null, 'anderes Fahrzeug bleibt unberührt');
});

test('Gebiete und Regeln: anlegen, prüfen, ändern, abschalten', async () => {
  const c = await neu(); const d = c.d;
  const g = await d.gebietAnlegen({ bezeichnung: 'Kroatien, Adria' });
  assert.ok(g.ok);
  assert.ok((await d.gebietAnlegen({ bezeichnung: 'kroatien, adria' })).fehler.bezeichnung);
  const art = (await d.nachweisartenListe('person'))[0].objekt.id;
  assert.ok((await d.regelAnlegen(g.id, { bezeichnung: '', artIds: [art] })).fehler.bezeichnung);
  assert.ok((await d.regelAnlegen(g.id, { bezeichnung: 'Führerschein', artIds: [] })).fehler.artIds);
  assert.ok((await d.regelAnlegen(g.id, { bezeichnung: 'Führerschein', artIds: ['unbekannt'] })).fehler.artIds);
  assert.equal((await d.regelAnlegen('nein', { bezeichnung: 'X', artIds: [art] })).ok, false);
  const r = await d.regelAnlegen(g.id, { bezeichnung: 'Führerschein See', fahrzeugArten: ['boot', 'quatsch'], ausruestung: ' Funkanlage ', artIds: [art] });
  assert.ok(r.ok);
  const x = await d.regelLaden(r.id);
  assert.deepEqual(x.aktuell.werte.fahrzeugArten, ['boot']);
  assert.equal(x.aktuell.werte.ausruestung, 'Funkanlage');
  assert.equal(x.gebiet.name, 'Kroatien, Adria');
  assert.equal((await d.regelAendern(r.id, { bezeichnung: 'Führerschein See', fahrzeugArten: ['boot'], ausruestung: 'Funkanlage', artIds: [art] })).geaendert, false);
  assert.equal((await d.regelAendern(r.id, { bezeichnung: 'Führerschein See', fahrzeugArten: [], ausruestung: '', artIds: [art], gilt: 'nein' })).geaendert, true);
  const y = await d.regelLaden(r.id);
  assert.equal(y.verlauf.length, 2);
  assert.equal(y.aktuell.werte.gilt, 'nein');
  const gl = await d.gebietLaden(g.id);
  assert.equal(gl.regeln.length, 1);
  assert.equal((await d.gebieteListe())[0].anzahlRegeln, 1);
});

test('Aktivität: Gebiet aus der Liste wird geprüft, unbekanntes Gebiet abgelehnt', async () => {
  const c = await neu(); const d = c.d;
  const g = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  assert.ok((await d.aktivitaetAnlegen(akt(c, { gebietId: 'gibt-es-nicht' }))).fehler.gebietId);
  const r = await d.aktivitaetAnlegen(akt(c, { gebietId: g }));
  assert.ok(r.ok);
  const a = await d.aktivitaetLaden(r.id);
  assert.equal(a.gebiet.name, 'Kroatien');
  assert.equal(a.aktuell.werte.gebietId, g);
  const r2 = await d.aktivitaetAnlegen(akt(c, {}));
  assert.equal((await d.aktivitaetLaden(r2.id)).gebiet, null);
});

const scan = { name: 'scan.jpg', type: 'image/jpeg', size: 100 };

test('Prüfung: Regel des Gebiets kommt zu den Anforderungen am Fahrzeug dazu', async () => {
  const c = await neu(); const d = c.d;
  const art = c.fuehrerschein.id;
  const g = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  await d.regelAnlegen(g, { bezeichnung: 'SBF See', fahrzeugArten: ['boot'], artIds: [art] });
  const r = await d.aktivitaetAnlegen(akt(c, { gebietId: g }));
  const p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.anforderungen, 1);
  assert.equal(p.befaehigung.gebiet, 'Kroatien');
  assert.equal(p.befaehigung.gebietInfo.greifen.length, 1);
  assert.equal(p.befaehigung.gebietHinweis, null, 'es gibt eine passende Regel, kein Hinweis');
  assert.ok(p.befaehigung.personen[0].gruende.some(x => x.text.startsWith('Gebiet Kroatien: SBF See')));
  assert.equal(p.befaehigung.ergebnis, 'unklar', 'kein Nachweis erfasst');
});

test('Prüfung: Die Regel des Gebiets entscheidet mit – erlaubt, nicht erlaubt, unklar', async () => {
  const c = await neu(); const d = c.d;
  const sbf = c.fuehrerschein.id;
  const funk = (await d.nachweisartAnlegen({ bezeichnung: 'Funkzeugnis', gehoertZu: 'person', hatAblauf: 'ja' })).id;
  const g = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  await d.regelAnlegen(g, { bezeichnung: 'SBF See', fahrzeugArten: ['boot'], artIds: [sbf] });
  await d.regelAnlegen(g, { bezeichnung: 'Funk', fahrzeugArten: ['boot'], artIds: [funk] });
  await d.nachweisAnlegen('person', c.anna, sbf, { nummer: '1', datei: scan });
  const r = await d.aktivitaetAnlegen(akt(c, { gebietId: g }));

  /* Funkzeugnis fehlt: unklar */
  let p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.befaehigung.ergebnis, 'unklar');
  assert.ok(p.befaehigung.personen[0].gruende.some(x => x.ergebnis === 'erlaubt' && x.text.includes('SBF See')));
  assert.ok(p.befaehigung.personen[0].gruende.some(x => x.ergebnis === 'unklar' && x.text.includes('Funk')));

  /* Funkzeugnis mit Scan, aber vor dem Ende des Zeitraums abgelaufen: nicht erlaubt */
  const fn = await d.nachweisAnlegen('person', c.anna, funk, { gueltigBis: '2026-12-05', datei: scan });
  assert.ok(fn.ok);
  p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.befaehigung.ergebnis, 'nicht_erlaubt');

  /* gültig über das Ende hinaus: erlaubt */
  await d.nachweisAendern(fn.id, { gueltigBis: '2027-12-31' });
  p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.befaehigung.ergebnis, 'erlaubt');
  assert.equal(p.befaehigung.gebietHinweis, null);
});

test('Prüfung: Gebiet ohne passende Regel macht „erlaubt“ höchstens zu „unklar“ und nennt den Grund', async () => {
  const c = await neu(); const d = c.d;
  const art = c.fuehrerschein.id;
  const g = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  /* gar keine Regel */
  let r = await d.aktivitaetAnlegen(akt(c, { gebietId: g }));
  let p = await d.aktivitaetPruefung(r.id);
  assert.match(p.befaehigung.gebietHinweis, /noch keine Regel/);
  /* Regel nur für Wohnmobile: für das Boot greift nichts */
  await d.regelAnlegen(g, { bezeichnung: 'Nur Wohnmobil', fahrzeugArten: ['wohnmobil'], artIds: [art] });
  p = await d.aktivitaetPruefung(r.id);
  assert.match(p.befaehigung.gebietHinweis, /keine Regel auf dieses Fahrzeug/);
  assert.equal(p.befaehigung.gebietInfo.nichtGreifen.length, 1);
  assert.match(p.befaehigung.gebietInfo.nichtGreifen[0].grund, /Wohnmobil/);
  assert.notEqual(p.befaehigung.ergebnis, 'erlaubt');
});

test('Prüfung: Regel mit Ausrüstung greift erst, wenn am Fahrzeug eine passende Komponente eingebaut ist', async () => {
  const c = await neu(); const d = c.d;
  const art = c.fuehrerschein.id;
  const g = (await d.gebietAnlegen({ bezeichnung: 'See' })).id;
  await d.regelAnlegen(g, { bezeichnung: 'Funkzeugnis', ausruestung: 'Funkanlage', artIds: [art] });
  const r = await d.aktivitaetAnlegen(akt(c, { gebietId: g }));
  let p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.befaehigung.gebietInfo.greifen.length, 0);
  assert.match(p.befaehigung.gebietInfo.nichtGreifen[0].grund, /Funkanlage/);
  await d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'UKW-Funkanlage' });
  p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.befaehigung.gebietInfo.greifen.length, 1);
});

test('Prüfung: abgeschaltete Regel greift nicht; Gebiet nur als Text bleibt „nicht geprüft“', async () => {
  const c = await neu(); const d = c.d;
  const art = c.fuehrerschein.id;
  const g = (await d.gebietAnlegen({ bezeichnung: 'See' })).id;
  const rg = await d.regelAnlegen(g, { bezeichnung: 'Abgeschaltet', artIds: [art] });
  await d.regelAendern(rg.id, { bezeichnung: 'Abgeschaltet', artIds: [art], gilt: 'nein' });
  const r = await d.aktivitaetAnlegen(akt(c, { gebietId: g }));
  const p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.befaehigung.gebietInfo.greifen.length, 0);
  assert.equal(p.anforderungen, 0);
  const t = await d.aktivitaetAnlegen(akt(c, { gebiet: 'Kroatien, Adria' }));
  const pt = await d.aktivitaetPruefung(t.id);
  assert.equal(pt.befaehigung.gebietInfo, null);
  assert.match(pt.befaehigung.gebietHinweis, /nur als Text/);
  assert.equal(pt.befaehigung.gebiet, 'Kroatien, Adria');
});

test('Sicherung: neue Tabellen sind dabei und werden wiederhergestellt; Sicherung aus 2.0.9 ohne sie lässt sich einspielen', async () => {
  const c = await neu(); const d = c.d;
  const o = (await d.ortAnlegen({ bezeichnung: 'Hafen' })).id;
  const s = (await d.standortAnlegen(o, { bezeichnung: 'Platz 1' })).id;
  await d.fahrzeugStandortSetzen(c.boot, s);
  const g = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  const art = c.fuehrerschein.id;
  await d.regelAnlegen(g, { bezeichnung: 'R', artIds: [art] });
  const sich = await d.sicherungErzeugen({});
  assert.equal(sich.zahlen.orte, 1);
  assert.equal(sich.zahlen.standorte, 1);
  assert.equal(sich.zahlen.gebiete, 1);
  assert.equal(sich.zahlen.regeln, 1);
  const gelesen = await d.sicherungLesen(sich.bytes, '');
  await d.allesLoeschen();
  assert.equal((await d.orteListe()).length, 0);
  await d.sicherungEinspielen(gelesen);
  assert.equal((await d.orteListe()).length, 1);
  assert.equal((await d.gebieteListe())[0].anzahlRegeln, 1);
  assert.equal((await d.fahrzeugStandort(c.boot)).standort.name, 'Platz 1');

  /* alte Sicherung: dbVersion 7, ohne die neuen Tabellen */
  const alt = JSON.parse(JSON.stringify({ kopf: gelesen.kopf, dateien: [] }));
  alt.kopf.dbVersion = 7;
  ['orte', 'standorte', 'gebiete', 'regeln'].forEach(n => { delete alt.kopf.tabellen[n]; if (alt.kopf.zaehlung) delete alt.kopf.zaehlung[n]; });
  await d.sicherungEinspielen(alt);
  assert.equal((await d.orteListe()).length, 0);
  assert.equal((await d.fahrzeugListe()).length, 2, 'Fahrzeuge aus der alten Sicherung sind da');
});

test('Ort und Standort: zusätzliche Angaben, Telefon wird geprüft, Zahlen mit Komma', async () => {
  const { d } = await neu();
  assert.ok((await d.ortAnlegen({ bezeichnung: 'Hafen', telefon: 'abc' })).fehler.telefon);
  const o = await d.ortAnlegen({ bezeichnung: 'Hafen', adresse: 'Hafenstr. 1, 23456 Biograd', ansprechpartner: 'Herr Horvat', telefon: '+385 23 123456' });
  assert.ok(o.ok);
  const x = await d.ortLaden(o.id);
  assert.equal(x.aktuell.werte.ansprechpartner, 'Herr Horvat');
  assert.equal(x.aktuell.werte.telefon, '+385 23 123456');
  const s = await d.standortAnlegen(o.id, { bezeichnung: 'Platz 12', laenge: '12,5', breite: '4', tiefgang: '2,2', hoehe: '' });
  assert.ok(s.ok);
  const y = await d.standortLaden(s.id);
  assert.equal(y.aktuell.werte.laenge, 12.5);
  assert.equal(y.aktuell.werte.tiefgang, 2.2);
  assert.equal(y.aktuell.werte.hoehe, null);
  assert.ok((await d.standortAnlegen(o.id, { bezeichnung: 'Platz 13', laenge: 'lang' })).fehler.laenge);
});

test('Regel Pflichtausrüstung: Pflichtfeld, Art bleibt, alte Regeln gelten als Befähigung', async () => {
  const c = await neu(); const d = c.d;
  const g = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  assert.ok((await d.regelAnlegen(g, { bezeichnung: 'Westen', art: 'ausruestung', pflichtAusruestung: ' ' })).fehler.pflichtAusruestung);
  const r = await d.regelAnlegen(g, { bezeichnung: 'Westen', art: 'ausruestung', pflichtAusruestung: ' Rettungsweste ', fahrzeugArten: ['boot'], ausruestung: 'egal', artIds: ['x'] });
  assert.ok(r.ok);
  const x = await d.regelLaden(r.id);
  assert.equal(x.aktuell.werte.art, 'ausruestung');
  assert.equal(x.aktuell.werte.pflichtAusruestung, 'Rettungsweste');
  assert.equal(x.aktuell.werte.ausruestung, null);
  assert.deepEqual(x.aktuell.werte.artIds, []);
  const art = c.fuehrerschein.id;
  const b = await d.regelAnlegen(g, { bezeichnung: 'SBF', artIds: [art] });
  assert.equal((await d.regelLaden(b.id)).aktuell.werte.art, 'befaehigung');
  assert.equal((await d.regelAendern(b.id, { bezeichnung: 'SBF', art: 'befaehigung', artIds: [art] })).geaendert, false);
  /* Ausrüstungsregel ohne Fahrzeugart-Bedingung für Befähigung ist nicht mit im Nachweis-Test */
});

test('Prüfung: Pflichtausrüstung – eingetragen ist „erlaubt“, sonst nur „unklar“, Befähigung bleibt getrennt', async () => {
  const c = await neu(); const d = c.d;
  const g = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  await d.regelAnlegen(g, { bezeichnung: 'Westen', art: 'ausruestung', pflichtAusruestung: 'Rettungsweste', fahrzeugArten: ['boot'] });
  await d.regelAnlegen(g, { bezeichnung: 'Feuerlöscher', art: 'ausruestung', pflichtAusruestung: 'Feuerlöscher', fahrzeugArten: ['wohnmobil'] });
  const r = await d.aktivitaetAnlegen(akt(c, { gebietId: g }));
  let p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.ausruestung.liste.length, 1, 'die Regel für Wohnmobile greift beim Boot nicht');
  assert.equal(p.ausruestung.liste[0].status, 'nicht_eingetragen');
  assert.equal(p.ausruestung.ergebnis, 'unklar');
  assert.match(p.befaehigung.gebietHinweis, /noch keine Regel für die Befähigung/);
  assert.notEqual(p.befaehigung.ergebnis, 'erlaubt');
  await d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Rettungsweste Set (4 Stück)' });
  p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.ausruestung.liste[0].status, 'eingetragen');
  assert.equal(p.ausruestung.ergebnis, 'erlaubt');
  /* ohne Gebiet gibt es keinen Ausrüstungsblock */
  const r2 = await d.aktivitaetAnlegen(akt(c, {}));
  assert.equal((await d.aktivitaetPruefung(r2.id)).ausruestung, null);
});

/* ---------- Pflichtausrüstung: Menge, Bezugsgröße, Eignung (2.0.12) ---------- */
test('Regel Pflichtausrüstung: Menge, Bezugsgröße und Eignung werden geprüft und gespeichert; alte Regeln bleiben gleich', async () => {
  const c = await neu(); const d = c.d;
  const g = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  assert.ok((await d.regelAnlegen(g, { bezeichnung: 'W', art: 'ausruestung', pflichtAusruestung: 'Weste', menge: '0' })).fehler.menge);
  assert.ok((await d.regelAnlegen(g, { bezeichnung: 'W', art: 'ausruestung', pflichtAusruestung: 'Weste', menge: '2,5' })).fehler.menge);
  assert.ok((await d.regelAnlegen(g, { bezeichnung: 'W', art: 'ausruestung', pflichtAusruestung: 'Weste', menge: 'viele' })).fehler.menge);
  const leer = await d.regelAnlegen(g, { bezeichnung: 'Leer', art: 'ausruestung', pflichtAusruestung: 'Weste' });
  const wl = (await d.regelLaden(leer.id)).aktuell.werte;
  assert.equal(wl.menge, 1);
  assert.equal(wl.bezug, 'fahrzeug');
  assert.equal(wl.eignung, null);
  const r = await d.regelAnlegen(g, { bezeichnung: 'Westen', art: 'ausruestung', pflichtAusruestung: 'Weste', menge: ' 6 ', bezug: 'person', eignung: ' Automatik, 150 N ' });
  assert.ok(r.ok);
  const w = (await d.regelLaden(r.id)).aktuell.werte;
  assert.equal(w.menge, 6);
  assert.equal(w.bezug, 'person');
  assert.equal(w.eignung, 'Automatik, 150 N');
  assert.equal((await d.regelAendern(r.id, { bezeichnung: 'Westen', art: 'ausruestung', pflichtAusruestung: 'Weste', menge: '6', bezug: 'person', eignung: 'Automatik, 150 N' })).geaendert, false);
  const ae = await d.regelAendern(r.id, { bezeichnung: 'Westen', art: 'ausruestung', pflichtAusruestung: 'Weste', menge: '6', bezug: 'fahrzeug', eignung: '' });
  assert.equal(ae.geaendert, true);
  const x = await d.regelLaden(r.id);
  assert.equal(x.aktuell.werte.bezug, 'fahrzeug');
  const u = x.verlauf[0].aenderungen.find(v => v.key === 'bezug');
  assert.equal(u.alt, 'je Person an Bord');
  assert.equal(u.neu, 'je Fahrzeug');
  /* Befähigung: keine Menge, Bezugsgröße und Eignung */
  const b = await d.regelAnlegen(g, { bezeichnung: 'SBF', artIds: [c.fuehrerschein.id], menge: '7', bezug: 'person', eignung: 'x' });
  const bw = (await d.regelLaden(b.id)).aktuell.werte;
  assert.equal(bw.menge, null); assert.equal(bw.bezug, null); assert.equal(bw.eignung, null);
});

test('Komponente: Anzahl ab 1 und Haken „Eignung geprüft“', async () => {
  const c = await neu(); const d = c.d;
  assert.ok((await d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Weste', anzahl: '0' })).fehler.anzahl);
  assert.ok((await d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Weste', anzahl: '2,5' })).fehler.anzahl);
  assert.ok((await d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Weste', eignungGeprueft: 'vielleicht' })).fehler.eignungGeprueft);
  const k = await d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Weste', anzahl: '6', eignungGeprueft: 'ja' });
  assert.ok(k.ok);
  const w = (await d.komponenteLaden(k.id)).aktuell.werte;
  assert.equal(w.anzahl, 6);
  assert.equal(w.eignungGeprueft, 'ja');
  const l = await d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Feuerlöscher' });
  const lw = (await d.komponenteLaden(l.id)).aktuell.werte;
  assert.equal(lw.anzahl, null);
  assert.equal(lw.eignungGeprueft, null);
});

test('Prüfung: Soll gegen Ist bei je Person, mit Besatzung, Anzahl und Eignungshaken', async () => {
  const c = await neu(); const d = c.d;
  const ben = (await d.personAnlegen({ bezeichnung: 'Ben', funktionen: ['Crew'] })).id;
  const g = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  await d.regelAnlegen(g, { bezeichnung: 'Westen', art: 'ausruestung', pflichtAusruestung: 'Rettungsweste', menge: '1', bezug: 'person', eignung: 'Automatik, 150 N', fahrzeugArten: ['boot'] });
  const r = await d.aktivitaetAnlegen(akt(c, { gebietId: g }));
  let p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.ausruestung.liste[0].status, 'nicht_eingetragen');
  assert.equal(p.ausruestung.liste[0].soll, 1, 'Anna ist die einzige Person');
  assert.equal(p.ausruestung.ergebnis, 'unklar');
  /* eine Komponente mit 1 Stück reicht für 1 Person, aber ohne Haken bleibt die Eignung offen */
  const k = await d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Rettungsweste Set', anzahl: '1' });
  p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.ausruestung.liste[0].status, 'eignung_offen');
  assert.equal(p.ausruestung.ergebnis, 'unklar');
  assert.match(p.ausruestung.liste[0].text, /Automatik, 150 N/);
  /* zweite Person: jetzt fehlt eine Weste */
  assert.ok((await d.besatzungHinzufuegen(r.id, ben, { rolle: 'crew' })).ok);
  await d.komponenteAendern(k.id, { bezeichnung: 'Rettungsweste Set', anzahl: '1', eignungGeprueft: 'ja' });
  p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.ausruestung.liste[0].soll, 2);
  assert.equal(p.ausruestung.liste[0].status, 'zu_wenig');
  assert.match(p.ausruestung.liste[0].text, /Eingetragen sind 1, Soll ist 2/);
  /* Anzahl auf 2 und Haken gesetzt: erlaubt */
  await d.komponenteAendern(k.id, { bezeichnung: 'Rettungsweste Set', anzahl: '2', eignungGeprueft: 'ja' });
  p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.ausruestung.liste[0].status, 'eingetragen');
  assert.equal(p.ausruestung.ergebnis, 'erlaubt');
  /* ausgebaute Komponenten zählen nicht */
  await d.komponenteAendern(k.id, { bezeichnung: 'Rettungsweste Set', anzahl: '2', eignungGeprueft: 'ja', ausgebautAm: '2026-11-01' });
  p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.ausruestung.liste[0].status, 'nicht_eingetragen');
});

test('Prüfung: Regel aus 2.0.11 ohne Menge gilt als 1 je Fahrzeug', async () => {
  const c = await neu(); const d = c.d;
  const g = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  const reg = await d.regelAnlegen(g, { bezeichnung: 'Westen', art: 'ausruestung', pflichtAusruestung: 'Rettungsweste' });
  /* Stand von 2.0.11 nachstellen: ohne die neuen Schlüssel */
  const e = (await d.speicher.alle('verlaeufe')).filter(v => v.objektId === reg.id)[0];
  delete e.werte.menge; delete e.werte.bezug; delete e.werte.eignung;
  await d.speicher.speichern('verlaeufe', e);
  const r = await d.aktivitaetAnlegen(akt(c, { gebietId: g }));
  await d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Rettungsweste Set (4 Stück)' });
  const p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.ausruestung.liste[0].status, 'eingetragen');
  assert.equal(p.ausruestung.ergebnis, 'erlaubt');
  assert.equal((await d.regelAendern(reg.id, { bezeichnung: 'Westen', art: 'ausruestung', pflichtAusruestung: 'Rettungsweste' })).geaendert, false, 'Speichern ohne Änderung erzeugt keinen neuen Stand');
});
