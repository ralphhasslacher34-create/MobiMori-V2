'use strict';
/* 2.0.22: Motorstopp-Frage nach Ankunft, Anlegen oder Anker werfen (Schritt 6a). */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;
const M = MM.Motoren;

/* Uhr von Hand stellbar: 4. November 2026, 08:00 Ortszeit; jeder Aufruf eine Millisekunde später. */
function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 4, 8, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (jahr, monat, tag, std, min) => { uhr.ms = new Date(jahr, monat - 1, tag, std, min, 0).getTime(); t = 0; };
  return d;
}

/* Ein Boot mit zwei Motoren und einer laufenden Aktivität. */
async function neuesBoot() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const bb = (await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor Backbord' })).id;
  const stb = (await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor Steuerbord' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: boot, vonDatum: '2026-11-04', vonZeit: '06:00', bisDatum: '2026-11-05', bisZeit: '20:00', verantwortlichId: anna });
  assert.ok(r.ok, JSON.stringify(r));
  return { d, boot, bb, stb, id: r.id };
}
async function ereignisse(c) {
  return (await c.d.logbuchLaden(c.id)).abschnitte.flatMap(t => t.ereignisse).filter(e => e.art === 'ereignis');
}
async function eintragen(c, name, roh) {
  const r = await c.d.ereignisSchnell(c.id, name, roh || {});
  assert.ok(r.ok, name + ': ' + JSON.stringify(r));
  return r;
}
async function fragen(c, wartezeit) {
  return M.stoppFragen(await c.d.motorenListe(c.boot), await ereignisse(c), wartezeit, c.d.jetztLokal());
}

/* ---------- Rechenteile ---------- */

const e = (id, artName, zeitpunkt, extra) => Object.assign({ id, artName, zeitpunkt, ausgeblendet: false }, extra || {});
const motor = (extra) => Object.assign({ komponenteId: 'k1', laufId: 'l1', name: 'Motor Backbord', kurz: 'MOBB', laeuft: true, seit: new Date(2026, 10, 4, 9, 30, 12).toISOString(), frageEreignisId: null, frageStufe: null }, extra || {});
const lokal = (std, min) => '2026-11-04T' + (std < 10 ? '0' : '') + std + ':' + (min < 10 ? '0' : '') + min;

test('Ziel-Ereignisse: Ankunft, Anlegen, Anker werfen, Schreibweise egal; alles andere nicht', () => {
  ['Ankunft', 'anlegen', ' ANKER WERFEN '].forEach(n => assert.equal(M.istZielEreignis(n), true, n));
  ['Abfahrt', 'Ablegen', 'Anker lichten', 'Notiz', 'Tanken', '', undefined].forEach(n => assert.equal(M.istZielEreignis(n), false, String(n)));
});

test('Wartezeit: ganze Minuten von 1 bis 1440, alles andere ist ungültig', () => {
  assert.equal(M.wartezeitGueltig(5), 5);
  assert.equal(M.wartezeitGueltig('30'), 30);
  assert.equal(M.wartezeitGueltig(' 1440 '), 1440);
  [0, -3, 1441, 2.5, 'abc', '', null, undefined, NaN].forEach(w => assert.equal(M.wartezeitGueltig(w), null, String(w)));
  assert.equal(M.WARTEZEIT_STANDARD, 15);
});

test('Frage: kurz nach der Ankunft kommt „Fahrzeug am Ziel, Motor stoppen?“ für den laufenden Motor', () => {
  const f = M.stoppFragen([motor()], [e('e1', 'Ankunft', lokal(12, 0))], 15, lokal(12, 3));
  assert.equal(f.length, 1);
  assert.equal(f[0].stufe, 'jetzt');
  assert.equal(f[0].komponenteId, 'k1'); assert.equal(f[0].laufId, 'l1');
  assert.equal(f[0].ereignisId, 'e1'); assert.equal(f[0].datum, '2026-11-04'); assert.equal(f[0].zeit, '12:00'); assert.equal(f[0].minuten, 3);
  assert.equal(M.FRAGE_TEXT, 'Fahrzeug am Ziel, Motor stoppen?');
});

test('Vorschlag: nach der Wartezeit schlägt die App die Zeit der Ankunft als Stoppzeit vor', () => {
  const m = [motor()], ev = [e('e1', 'Anlegen', lokal(12, 0))];
  assert.equal(M.stoppFragen(m, ev, 30, lokal(12, 29))[0].stufe, 'jetzt');
  const v = M.stoppFragen(m, ev, 30, lokal(12, 30));
  assert.equal(v[0].stufe, 'vorschlag'); assert.equal(v[0].zeit, '12:00'); assert.equal(v[0].minuten, 30);
  assert.equal(M.stoppFragen(m, ev, 5, lokal(12, 5))[0].stufe, 'vorschlag', 'jeder Nutzer stellt die Wartezeit selbst ein');
  assert.equal(M.stoppFragen(m, ev, undefined, lokal(12, 14))[0].stufe, 'jetzt', 'ohne Einstellung gilt die Vorgabe von 15 Minuten');
  assert.equal(M.stoppFragen(m, ev, undefined, lokal(12, 15))[0].stufe, 'vorschlag');
});

test('Auslöser ist nie die Laufzeit: 30 Stunden Motorlauf ohne Ereignis am Ziel fragen nichts', () => {
  const m = [motor({ seit: new Date(2026, 10, 3, 6, 0, 0).toISOString() })];
  assert.deepEqual(M.stoppFragen(m, [], 15, lokal(12, 0)), []);
  assert.deepEqual(M.stoppFragen(m, [e('e1', 'Abfahrt', '2026-11-03T06:05')], 15, lokal(12, 0)), []);
  assert.deepEqual(M.stoppFragen(m, [e('e1', 'Notiz', lokal(11, 0)), e('e2', 'Tanken', lokal(11, 30))], 15, lokal(12, 0)), []);
  assert.equal(M.naechsteFrageInMs(m, [e('e1', 'Abfahrt', '2026-11-03T06:05')], 15, lokal(12, 0)), null);
});

test('Keine Frage: Motor aus, Motor erst nach dem Ziel gestartet, oder es geht schon weiter', () => {
  const ev = [e('e1', 'Ankunft', lokal(12, 0))];
  assert.deepEqual(M.stoppFragen([motor({ laeuft: false, seit: null })], ev, 15, lokal(12, 3)), []);
  assert.deepEqual(M.stoppFragen([motor({ seit: new Date(2026, 10, 4, 12, 10, 0).toISOString() })], ev, 15, lokal(12, 20)), [], 'für die nächste Fahrt gestartet');
  assert.deepEqual(M.stoppFragen([motor({ seit: new Date(2026, 10, 4, 12, 0, 30).toISOString() })], ev, 15, lokal(12, 3)), [], 'gleiche Minute: nichts zu stoppen');
  assert.deepEqual(M.stoppFragen([motor()], ev.concat([e('e2', 'Abfahrt', lokal(12, 10))]), 15, lokal(12, 40)), [], 'danach wieder Abfahrt: der Motor soll laufen');
  assert.deepEqual(M.stoppFragen([motor()], ev.concat([e('e2', 'Anker lichten', lokal(12, 10))]), 15, lokal(12, 40)), []);
  assert.equal(M.stoppFragen([motor()], ev.concat([e('e2', 'Abfahrt', lokal(11, 0))]), 15, lokal(12, 3)).length, 1, 'eine frühere Abfahrt ändert nichts');
});

test('Ausgeblendete Ereignisse und Ereignisse in der Zukunft zählen nicht, Anker werfen und Anlegen schon', () => {
  const m = [motor()];
  assert.deepEqual(M.stoppFragen(m, [e('e1', 'Ankunft', lokal(12, 0), { ausgeblendet: true })], 15, lokal(12, 3)), []);
  assert.deepEqual(M.stoppFragen(m, [e('e1', 'Ankunft', lokal(13, 0))], 15, lokal(12, 3)), []);
  assert.equal(M.stoppFragen(m, [e('e1', 'Anker werfen', lokal(12, 0))], 15, lokal(12, 3)).length, 1);
  assert.equal(M.stoppFragen(m, [e('e1', 'anlegen', lokal(12, 0))], 15, lokal(12, 3)).length, 1);
  /* Das letzte Ereignis gilt: erst Abfahrt, dann Ankunft */
  assert.equal(M.stoppFragen(m, [e('e1', 'Ankunft', lokal(12, 0)), e('e2', 'Abfahrt', lokal(10, 0))], 15, lokal(12, 3)).length, 1);
});

test('Zwei Motoren: jeder laufende Motor wird gefragt, ein gestoppter nicht', () => {
  const m = [motor(), motor({ komponenteId: 'k2', laufId: 'l2', name: 'Motor Steuerbord', kurz: 'MOSTB' }), motor({ komponenteId: 'k3', laufId: null, laeuft: false, seit: null })];
  const f = M.stoppFragen(m, [e('e1', 'Ankunft', lokal(12, 0))], 15, lokal(12, 2));
  assert.deepEqual(f.map(x => x.kurz), ['MOBB', 'MOSTB']);
});

test('„Läuft weiter“: die Stufe „jetzt“ ist beantwortet, der Vorschlag kommt später noch; nach „vorschlag“ kommt für dieses Ereignis nichts mehr', () => {
  const ev = [e('e1', 'Ankunft', lokal(12, 0))];
  const jetztBeantwortet = [motor({ frageEreignisId: 'e1', frageStufe: 'jetzt' })];
  assert.deepEqual(M.stoppFragen(jetztBeantwortet, ev, 15, lokal(12, 5)), []);
  assert.equal(M.stoppFragen(jetztBeantwortet, ev, 15, lokal(12, 15))[0].stufe, 'vorschlag');
  const allesBeantwortet = [motor({ frageEreignisId: 'e1', frageStufe: 'vorschlag' })];
  assert.deepEqual(M.stoppFragen(allesBeantwortet, ev, 15, lokal(12, 5)), []);
  assert.deepEqual(M.stoppFragen(allesBeantwortet, ev, 15, lokal(14, 0)), []);
  /* Eine neue Ankunft ist ein neues Ereignis und fragt wieder */
  const neueAnkunft = ev.concat([e('e9', 'Anlegen', lokal(18, 0))]);
  assert.equal(M.stoppFragen(allesBeantwortet, neueAnkunft, 15, lokal(18, 2)).length, 1, 'e1 ist beantwortet, e9 ist ein neues Ereignis: gefragt wird');
});

test('Wann kommt der Vorschlag? Das Cockpit zeichnet sich zu diesem Zeitpunkt neu', () => {
  const m = [motor()], ev = [e('e1', 'Ankunft', lokal(12, 0))];
  assert.equal(M.naechsteFrageInMs(m, ev, 15, lokal(12, 5)), 10 * 60000);
  assert.equal(M.naechsteFrageInMs(m, ev, 15, lokal(12, 15)), null, 'der Vorschlag ist schon da');
  assert.equal(M.naechsteFrageInMs([motor({ laeuft: false, seit: null })], ev, 15, lokal(12, 5)), null);
  assert.equal(M.naechsteFrageInMs([motor({ frageEreignisId: 'e1', frageStufe: 'vorschlag' })], ev, 15, lokal(12, 5)), null);
  assert.equal(M.naechsteFrageInMs([motor({ frageEreignisId: 'e1', frageStufe: 'jetzt' })], ev, 15, lokal(12, 5)), 10 * 60000, 'der Vorschlag kommt trotzdem');
});

/* ---------- Mit Speicher ---------- */

test('Mit Speicher: Boot kommt an, beide Motoren laufen, die Frage kommt für beide, nach dem Stoppen nicht mehr', async () => {
  const c = await neuesBoot();
  c.d.stelle(2026, 11, 4, 9, 30);
  assert.ok((await c.d.motorStart(c.bb)).ok); assert.ok((await c.d.motorStart(c.stb)).ok);
  c.d.stelle(2026, 11, 4, 9, 35);
  await eintragen(c, 'Abfahrt');
  assert.deepEqual(await fragen(c), [], 'nach der Abfahrt keine Frage');
  c.d.stelle(2026, 11, 4, 12, 0);
  await eintragen(c, 'Ankunft');
  c.d.stelle(2026, 11, 4, 12, 3);
  const f = await fragen(c);
  assert.deepEqual(f.map(x => [x.kurz, x.stufe, x.zeit]), [['MOBB', 'jetzt', '12:00'], ['MOSTB', 'jetzt', '12:00']]);
  assert.ok((await c.d.motorStopp(c.bb)).ok);
  assert.deepEqual((await fragen(c)).map(x => x.kurz), ['MOSTB']);
  assert.ok((await c.d.motorStopp(c.stb)).ok);
  assert.deepEqual(await fragen(c), []);
});

test('Mit Speicher: Anlegen und Anker werfen beim Boot lösen die Frage aus', async () => {
  const c = await neuesBoot();
  assert.ok((await c.d.ereignisartenVorauswahlUebernehmen()).ok);
  c.d.stelle(2026, 11, 4, 9, 30);
  await c.d.motorStart(c.bb);
  c.d.stelle(2026, 11, 4, 10, 0);
  await eintragen(c, 'Ablegen');
  c.d.stelle(2026, 11, 4, 11, 0);
  await eintragen(c, 'Anker werfen');
  c.d.stelle(2026, 11, 4, 11, 2);
  let f = await fragen(c);
  assert.equal(f.length, 1); assert.equal(f[0].ereignisName, 'Anker werfen'); assert.equal(f[0].zeit, '11:00');
  c.d.stelle(2026, 11, 4, 11, 30);
  await eintragen(c, 'Anker lichten');
  assert.deepEqual(await fragen(c), [], 'Anker lichten heißt: es geht weiter');
  c.d.stelle(2026, 11, 4, 12, 0);
  await eintragen(c, 'Anlegen');
  c.d.stelle(2026, 11, 4, 12, 1);
  f = await fragen(c);
  assert.equal(f.length, 1); assert.equal(f[0].ereignisName, 'Anlegen'); assert.equal(f[0].zeit, '12:00');
});

test('Stopp zur Zeit der Ankunft: Der Motor lief bis 12:00, gestoppt wird um 12:40 mit der Stoppzeit 12:00', async () => {
  const c = await neuesBoot();
  c.d.stelle(2026, 11, 4, 9, 30);
  await c.d.motorStart(c.bb);
  c.d.stelle(2026, 11, 4, 12, 0);
  const ank = await eintragen(c, 'Ankunft');
  c.d.stelle(2026, 11, 4, 12, 40);
  const f = (await fragen(c, 30))[0];
  assert.equal(f.stufe, 'vorschlag');
  const r = await c.d.motorStopp(c.bb, { zeitpunkt: M.zeitpunktAusOrtszeit(f.datum, f.zeit), ereignisId: f.ereignisId });
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal(r.vomZiel, true);
  assert.equal(r.stunden, 2.5, 'von 9:30 bis 12:00, nicht bis 12:40');
  assert.equal(r.stand, 2.5);
  assert.equal(M.ortszeit(r.stopp), '12:00');
  const m = (await c.d.motorenListe(c.boot)).find(x => x.komponenteId === c.bb);
  assert.equal(m.laeuft, false);
  assert.equal(m.laeufe[0].stunden, 2.5); assert.equal(MM.Motoren.ortszeit(m.laeufe[0].stopp), '12:00');
  assert.equal(m.zaehler.stand.wert, 2.5);
  assert.equal(m.zaehler.stand.quelle, 'schalter');
  assert.equal(m.zaehler.stand.datum, '2026-11-04');
  const staende = await c.d.speicher.wo('zaehlerstaende', 'zaehlerId', m.zaehler.id);
  assert.ok(staende.some(x => x.notiz.includes('Stoppzeit von der Ankunft')), JSON.stringify(staende.map(x => x.notiz)));
  assert.equal(ank.ok, true);
  assert.deepEqual(await fragen(c, 30), [], 'nach dem Stopp keine Frage mehr');
  assert.equal(m.laeufe[0].korrigierbar, true, 'die Zeit lässt sich wie bisher noch korrigieren');
});

test('Stopp zu einer Zeit: abgelehnt vor dem Start, in der Zukunft und bei Unsinn; der Motor läuft danach unverändert weiter', async () => {
  const c = await neuesBoot();
  c.d.stelle(2026, 11, 4, 9, 30);
  await c.d.motorStart(c.bb);
  c.d.stelle(2026, 11, 4, 12, 0);
  const vorStart = await c.d.motorStopp(c.bb, { zeitpunkt: M.zeitpunktAusOrtszeit('2026-11-04', '09:00') });
  assert.equal(vorStart.ok, false); assert.ok(vorStart.fehler.zeit.includes('vor dem Start'));
  const zukunft = await c.d.motorStopp(c.bb, { zeitpunkt: M.zeitpunktAusOrtszeit('2026-11-04', '12:30') });
  assert.equal(zukunft.ok, false); assert.ok(zukunft.fehler.zeit.includes('Zukunft'));
  const unsinn = await c.d.motorStopp(c.bb, { zeitpunkt: 'gestern' });
  assert.equal(unsinn.ok, false);
  assert.equal((await c.d.motorenListe(c.boot)).find(x => x.komponenteId === c.bb).laeuft, true);
  assert.equal((await c.d.motorStopp(c.stb, { zeitpunkt: M.zeitpunktAusOrtszeit('2026-11-04', '10:00') })).ok, false, 'ein Motor, der nicht läuft');
});

test('Stopp ohne Zeit funktioniert wie bisher (jetzt)', async () => {
  const c = await neuesBoot();
  c.d.stelle(2026, 11, 4, 9, 30);
  await c.d.motorStart(c.bb);
  c.d.stelle(2026, 11, 4, 10, 30);
  const r = await c.d.motorStopp(c.bb);
  assert.ok(r.ok); assert.equal(r.vomZiel, false); assert.equal(r.stunden, 1); assert.equal(r.stand, 1);
  const m = (await c.d.motorenListe(c.boot)).find(x => x.komponenteId === c.bb);
  const staende = await c.d.speicher.wo('zaehlerstaende', 'zaehlerId', m.zaehler.id);
  assert.equal(staende.some(x => x.notiz.includes('Ankunft')), false);
});

test('„Läuft weiter“ wird gespeichert, hält nur für dieses Ereignis und gilt nur für den offenen Lauf', async () => {
  const c = await neuesBoot();
  c.d.stelle(2026, 11, 4, 9, 30);
  await c.d.motorStart(c.bb);
  c.d.stelle(2026, 11, 4, 12, 0);
  await eintragen(c, 'Ankunft');
  c.d.stelle(2026, 11, 4, 12, 2);
  let f = (await fragen(c))[0];
  assert.equal(f.stufe, 'jetzt');
  const v1 = await c.d.motorStoppFrageVerneinen(f.laufId, f.ereignisId, 'jetzt');
  assert.ok(v1.ok); assert.equal(v1.geaendert, true);
  assert.deepEqual(await fragen(c), [], 'die erste Frage kommt nicht wieder');
  const m1 = (await c.d.motorenListe(c.boot)).find(x => x.komponenteId === c.bb);
  assert.equal(m1.frageStufe, 'jetzt'); assert.equal(m1.frageEreignisId, f.ereignisId);
  assert.equal((await c.d.motorStoppFrageVerneinen(f.laufId, f.ereignisId, 'jetzt')).geaendert, false, 'zweimal dasselbe ändert nichts');
  c.d.stelle(2026, 11, 4, 12, 20);
  f = (await fragen(c))[0];
  assert.equal(f.stufe, 'vorschlag', 'nach der Wartezeit kommt der Vorschlag trotzdem');
  assert.ok((await c.d.motorStoppFrageVerneinen(f.laufId, f.ereignisId, 'vorschlag')).ok);
  c.d.stelle(2026, 11, 4, 16, 0);
  assert.deepEqual(await fragen(c), [], 'für diese Ankunft ist alles beantwortet');
  /* Eine neue Ankunft fragt wieder */
  await eintragen(c, 'Ankunft');
  c.d.stelle(2026, 11, 4, 16, 2);
  assert.equal((await fragen(c)).length, 1);
  /* Falsche Eingaben */
  assert.equal((await c.d.motorStoppFrageVerneinen(f.laufId, f.ereignisId, 'egal')).ok, false);
  assert.equal((await c.d.motorStoppFrageVerneinen('gibt-es-nicht', f.ereignisId, 'jetzt')).ok, false);
});

test('Die Antwort „Läuft weiter“ bleibt nicht am nächsten Lauf hängen', async () => {
  const c = await neuesBoot();
  c.d.stelle(2026, 11, 4, 9, 30);
  await c.d.motorStart(c.bb);
  c.d.stelle(2026, 11, 4, 12, 0);
  await eintragen(c, 'Ankunft');
  c.d.stelle(2026, 11, 4, 12, 2);
  const f = (await fragen(c))[0];
  await c.d.motorStoppFrageVerneinen(f.laufId, f.ereignisId, 'vorschlag');
  assert.ok((await c.d.motorStopp(c.bb)).ok);
  assert.equal((await c.d.motorStoppFrageVerneinen(f.laufId, f.ereignisId, 'jetzt')).geaendert, false, 'ein gestoppter Lauf wird nicht mehr verändert');
  c.d.stelle(2026, 11, 4, 12, 30);
  assert.ok((await c.d.motorStart(c.bb)).ok);
  assert.equal((await c.d.motorenListe(c.boot)).find(x => x.komponenteId === c.bb).frageStufe, null);
});

test('Nachgetragene Ankunft: war sie vor langer Zeit, kommt gleich der Vorschlag mit der Zeit der Ankunft', async () => {
  const c = await neuesBoot();
  c.d.stelle(2026, 11, 4, 9, 30);
  await c.d.motorStart(c.bb);
  c.d.stelle(2026, 11, 4, 15, 0);
  const nachtrag = await c.d.ereignisSchnell(c.id, 'Ankunft', { datum: '2026-11-04', zeit: '11:45' });
  assert.ok(nachtrag.ok, JSON.stringify(nachtrag));
  const f = await fragen(c, 15);
  assert.equal(f.length, 1); assert.equal(f[0].stufe, 'vorschlag'); assert.equal(f[0].zeit, '11:45');
  const r = await c.d.motorStopp(c.bb, { zeitpunkt: M.zeitpunktAusOrtszeit(f[0].datum, f[0].zeit), ereignisId: f[0].ereignisId });
  assert.ok(r.ok); assert.equal(r.stunden, 2.25);
});

test('Ein ausgeblendetes Ereignis nimmt die Frage zurück', async () => {
  const c = await neuesBoot();
  c.d.stelle(2026, 11, 4, 9, 30);
  await c.d.motorStart(c.bb);
  c.d.stelle(2026, 11, 4, 12, 0);
  const ank = await eintragen(c, 'Ankunft');
  c.d.stelle(2026, 11, 4, 12, 2);
  assert.equal((await fragen(c)).length, 1);
  const x = await c.d.ereignisLaden(ank.id);
  const w = x.aktuell.werte;
  const aus = await c.d.ereignisAendern(ank.id, { artId: w.artId, datum: w.datum, zeit: w.zeit, ausgeblendet: 'ja' });
  assert.ok(aus.ok, JSON.stringify(aus));
  assert.equal((await ereignisse(c)).find(e => e.id === ank.id).ausgeblendet, true);
  assert.equal((await fragen(c)).length, 0);
});

/* ---------- Wartezeit auf dem Gerät ---------- */

test('Wartezeit: Vorgabe 15, einstellbar, ungültiges wird abgelehnt, bleibt bestehen', async () => {
  const d = neueDaten(); await d.starten();
  assert.deepEqual(await d.geraetWartezeit(), { wartezeit: 15, gesetzt: false });
  assert.deepEqual(await d.geraetWartezeit(), { wartezeit: M.WARTEZEIT_STANDARD, gesetzt: false });
  const r = await d.geraetWartezeitSetzen('30');
  assert.ok(r.ok); assert.equal(r.wartezeit, 30);
  assert.deepEqual(await d.geraetWartezeit(), { wartezeit: 30, gesetzt: true });
  assert.ok((await d.geraetWartezeitSetzen(5)).ok);
  assert.equal((await d.geraetWartezeit()).wartezeit, 5);
  for (const schlecht of [0, -1, 1441, 2.5, 'abc', '', null]) {
    const x = await d.geraetWartezeitSetzen(schlecht);
    assert.equal(x.ok, false, String(schlecht)); assert.ok(x.fehler.wartezeit);
  }
  assert.equal((await d.geraetWartezeit()).wartezeit, 5, 'nach einem Fehler bleibt der alte Wert');
});

test('Wartezeit und Knopfzahl des Geräts stören sich nicht, die Gerätekennung bleibt', async () => {
  const d = neueDaten(); await d.starten();
  const id = await d.geraetKennung();
  assert.ok((await d.geraetKnoepfeSetzen(12)).ok);
  assert.ok((await d.geraetWartezeitSetzen(45)).ok);
  assert.equal((await d.geraetEinstellungen()).knoepfe, 12);
  assert.equal((await d.geraetWartezeit()).wartezeit, 45);
  assert.ok((await d.geraetKnoepfeSetzen(6)).ok);
  assert.equal((await d.geraetWartezeit()).wartezeit, 45, 'die Knopfzahl überschreibt die Wartezeit nicht');
  assert.ok((await d.geraetWartezeitSetzen(20)).ok);
  assert.equal((await d.geraetEinstellungen()).knoepfe, 6, 'die Wartezeit überschreibt die Knopfzahl nicht');
  assert.equal(await d.geraetKennung(), id);
});

test('Die Wartezeit gehört dem Gerät: sie steht nicht in der Sicherung und wird beim Einspielen nicht überschrieben', async () => {
  const a = neueDaten(), b = neueDaten(); await a.starten(); await b.starten();
  assert.ok((await a.geraetWartezeitSetzen(45)).ok);
  assert.ok((await b.geraetWartezeitSetzen(10)).ok);
  const s = await a.sicherungErzeugen({ mitDateien: false });
  const gelesen = await b.sicherungLesen(s.bytes, '');
  assert.ok(!gelesen.kopf.tabellen.einstellungen.some(x => x.id === 'geraet' || x.motorFrageMinuten !== undefined));
  await b.sicherungEinspielen(gelesen);
  assert.equal((await b.geraetWartezeit()).wartezeit, 10, 'das Gerät B behält seine Wartezeit');
});

test('Läufe mit der Antwort „Läuft weiter“ kommen mit der Sicherung zurück (ein noch laufender Motor)', async () => {
  const c = await neuesBoot();
  c.d.stelle(2026, 11, 4, 9, 30);
  await c.d.motorStart(c.bb);
  const lauf = (await c.d.motorenListe(c.boot)).find(x => x.komponenteId === c.bb);
  await c.d.motorStoppFrageVerneinen(lauf.laufId, 'e-test', 'jetzt');
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  const gelesen = await c.d.sicherungLesen(s.bytes, '');
  await c.d.sicherungEinspielen(gelesen);
  const nach = (await c.d.motorenListe(c.boot)).find(x => x.komponenteId === c.bb);
  assert.equal(nach.laeuft, true); assert.equal(nach.frageStufe, 'jetzt'); assert.equal(nach.frageEreignisId, 'e-test');
});
