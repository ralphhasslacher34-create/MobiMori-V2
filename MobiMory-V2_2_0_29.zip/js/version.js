/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.29';
  MM.STUFE = 'Kostenzeilen und Reisekasse: mehrere Zeilen je Besuch, offene Kostenarten, Zahlungsmittel, Bargeldkasse je Währung, Reiseauswertung';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
