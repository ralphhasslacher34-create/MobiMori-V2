/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.23';
  MM.STUFE = 'Status des Fahrzeugs und Regeln der Ereignisse';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
