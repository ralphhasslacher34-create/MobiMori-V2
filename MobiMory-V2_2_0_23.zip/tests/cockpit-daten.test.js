'use strict';
/* 2.0.14: Cockpit, Wechsel mit Prüfung, Nachtrag-Erkennung und Tagesabschluss (mit Speicher). */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;

/* Uhr von Hand stellbar: 3. November 2026, 12:00 Ortszeit; jeder Aufruf eine Millisekunde später, damit die Reihenfolge stimmt. */
function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 3, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.uhr = uhr;
  d.stelle = (jahr, monat, tag, std, min) => { uhr.ms = new Date(jahr, monat - 1, tag, std, min, 0).getTime(); };
  return d;
}
const foto = (inhalt, name) => { const b = new Blob([inhalt], { type: 'image/jpeg' }); Object.defineProperty(b, 'name', { value: name || 'foto.jpg' }); return b; };
const scan = { name: 'scan.jpg', type: 'image/jpeg', size: 100 };

async function neu() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const ben = (await d.personAnlegen({ bezeichnung: 'Ben', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  return { d, boot, wm, anna, ben, toern };
}
async function mitAktivitaet(extra) {
  const c = await neu();
  const r = await c.d.aktivitaetAnlegen(Object.assign({ bezeichnung: 'Sommertörn', artId: c.toern, fahrzeugId: c.boot, vonDatum: '2026-11-03', vonZeit: '09:00', bisDatum: '2026-11-05', bisZeit: '17:30', verantwortlichId: c.anna }, extra || {}));
  assert.ok(r.ok);
  c.id = r.id;
  assert.ok((await c.d.besatzungHinzufuegen(c.id, c.ben, { rolle: 'stellvertreter' })).ok);
  return c;
}
const eventsVon = async (c) => (await c.d.logbuchLaden(c.id)).abschnitte.flatMap(t => t.ereignisse);

test('Heutiger Tag: wird von selbst angelegt, mit der Uhrzeit des Beginns, und danach nur noch geöffnet', async () => {
  const c = await mitAktivitaet();
  assert.equal((await c.d.logbuchLaden(c.id)).abschnitte.length, 0, 'kein „Tage vorbereiten“ nötig');
  const t1 = await c.d.heutigerTag(c.id);
  assert.ok(t1.ok); assert.equal(t1.neu, true);
  const t2 = await c.d.heutigerTag(c.id);
  assert.equal(t2.neu, false); assert.equal(t2.abschnittId, t1.abschnittId);
  const lb = await c.d.logbuchLaden(c.id);
  assert.equal(lb.abschnitte.length, 1);
  const w = lb.abschnitte[0].aktuell.werte;
  assert.equal(w.datum, '2026-11-03'); assert.equal(w.beginnZeit, '09:00'); assert.equal(w.endeZeit, null);
  assert.equal((await c.d.speicher.holen('tagesabschnitte', t1.abschnittId)).herkunft, 'vorbereitet');
});

test('Heutiger Tag: am nächsten Tag ein neuer, am letzten Tag mit dem Ende der Aktivität', async () => {
  const c = await mitAktivitaet();
  await c.d.heutigerTag(c.id);
  c.d.stelle(2026, 11, 4, 8, 0);
  assert.equal((await c.d.heutigerTag(c.id)).neu, true);
  c.d.stelle(2026, 11, 5, 8, 0);
  await c.d.heutigerTag(c.id);
  const lb = await c.d.logbuchLaden(c.id);
  assert.deepEqual(lb.abschnitte.map(t => t.aktuell.werte.datum), ['2026-11-03', '2026-11-04', '2026-11-05']);
  assert.equal(lb.abschnitte[1].aktuell.werte.beginnZeit, null);
  assert.equal(lb.abschnitte[2].aktuell.werte.endeZeit, '17:30');
  assert.equal(lb.fehlend, 0, 'es fehlt nichts mehr zum Vorbereiten');
});

test('Heutiger Tag: außerhalb des Zeitraums und bei stornierter Aktivität kommt nichts', async () => {
  const c = await mitAktivitaet();
  c.d.stelle(2026, 11, 6, 8, 0);
  let r = await c.d.heutigerTag(c.id);
  assert.equal(r.ok, false); assert.match(r.fehler.allgemein, /war bis 05\.11\.2026/);
  c.d.stelle(2026, 11, 2, 8, 0);
  r = await c.d.heutigerTag(c.id);
  assert.equal(r.ok, false); assert.match(r.fehler.allgemein, /beginnt erst am 03\.11\.2026/);
  c.d.stelle(2026, 11, 4, 8, 0);
  await c.d.aktivitaetStornieren(c.id, 'Sturm');
  r = await c.d.heutigerTag(c.id);
  assert.equal(r.ok, false); assert.match(r.fehler.allgemein, /storniert/);
  assert.equal((await c.d.logbuchLaden(c.id)).abschnitte.length, 0, 'nichts angelegt');
  assert.equal((await c.d.heutigerTag('gibt-es-nicht')).ok, false);
});

test('Heutiger Tag: ist heute nur ein ausgeblendeter Tag da, legt die App einen neuen an und blendet nichts wieder ein', async () => {
  const c = await mitAktivitaet();
  const t = await c.d.heutigerTag(c.id);
  const x = (await c.d.abschnittLaden(t.abschnittId)).abschnitt;
  await c.d.abschnittAendern(t.abschnittId, Object.assign({}, x.aktuell.werte, { ausgeblendet: 'ja' }));
  const r = await c.d.heutigerTag(c.id);
  assert.equal(r.neu, true); assert.notEqual(r.abschnittId, t.abschnittId);
  const lb = await c.d.logbuchLaden(c.id);
  assert.equal(lb.abschnitte.filter(a => a.ausgeblendet).length, 1);
});

test('Schnell eintragen: Abfahrt mit der Uhrzeit jetzt, ohne Formular, Arten und Tag entstehen von selbst', async () => {
  const c = await mitAktivitaet();
  assert.equal((await c.d.ereignisartenListe()).length, 0);
  c.d.stelle(2026, 11, 3, 10, 32);
  const r = await c.d.ereignisSchnell(c.id, 'Abfahrt');
  assert.ok(r.ok); assert.equal(r.zeit, '10:32'); assert.equal(r.datum, '2026-11-03');
  assert.equal((await c.d.ereignisartenListe()).length, 5, 'die Vorschläge stehen bereit');
  const e = (await eventsVon(c))[0];
  assert.equal(e.artName, 'Abfahrt'); assert.equal(e.zeit, '10:32'); assert.equal(e.nachgetragen, false);
  c.d.stelle(2026, 11, 3, 12, 5);
  assert.ok((await c.d.ereignisSchnell(c.id, 'Ankunft')).ok);
  const lb = await c.d.logbuchLaden(c.id);
  assert.equal(lb.abschnitte.length, 1, 'beides im selben Tag');
  assert.deepEqual(lb.abschnitte[0].ereignisse.map(x => x.artName), ['Abfahrt', 'Ankunft']);
});

test('Schnell eintragen: Notiz mit Text, Foto bleibt auf dem Gerät, eine leere Datei wird abgelehnt', async () => {
  const c = await mitAktivitaet();
  const r = await c.d.ereignisSchnell(c.id, 'Notiz', { text: 'Ölstand geprüft', datei: foto('BILD-BYTES') });
  assert.ok(r.ok);
  const e = (await eventsVon(c))[0];
  assert.equal(e.text, 'Ölstand geprüft'); assert.equal(e.hatFoto, true);
  assert.equal(new TextDecoder().decode(await (await c.d.ereignisDateiHolen(r.id)).inhalt.arrayBuffer()), 'BILD-BYTES');
  const leer = await c.d.ereignisSchnell(c.id, 'Notiz', { datei: { name: 'leer.jpg', size: 0 } });
  assert.equal(leer.ok, false); assert.ok(leer.fehler.datei);
  assert.equal((await eventsVon(c)).length, 1);
});

test('Schnell eintragen: eine gewählte Art (artId) gilt, eine ausgeblendete Art wird nicht benutzt, stornierte Aktivität nimmt nichts an', async () => {
  const c = await mitAktivitaet();
  await c.d.ereignisartenAusVorschlaegen();
  const arten = await c.d.ereignisartenListe();
  const stoerung = arten.find(x => x.aktuell.werte.bezeichnung === 'Störung').objekt.id;
  assert.ok((await c.d.ereignisSchnell(c.id, 'Notiz', { artId: stoerung, text: 'Motor stottert' })).ok);
  assert.equal((await eventsVon(c))[0].artName, 'Störung');
  const abf = arten.find(x => x.aktuell.werte.bezeichnung === 'Abfahrt');
  await c.d.ereignisartAendern(abf.objekt.id, { bezeichnung: 'Abfahrt', ausgeblendet: 'ja' });
  const r = await c.d.ereignisSchnell(c.id, 'Abfahrt');
  assert.equal(r.ok, false); assert.match(r.fehler.allgemein, /ausgeblendet/);
  assert.equal((await c.d.ereignisSchnell(c.id, 'Gibt es nicht')).ok, false);
  await c.d.aktivitaetStornieren(c.id, 'Sturm');
  const s = await c.d.ereignisSchnell(c.id, 'Notiz', { text: 'x' });
  assert.equal(s.ok, false); assert.match(s.fehler.allgemein, /storniert/);
  assert.equal((await eventsVon(c)).length, 1);
});

test('Nachtrag wird erkannt: mehr als 5 Minuten vor jetzt = nachgetragen, bis 5 Minuten oder später nicht', async () => {
  const c = await mitAktivitaet();
  const t = (await c.d.heutigerTag(c.id)).abschnittId;
  await c.d.ereignisartenAusVorschlaegen();
  const art = (await c.d.ereignisartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Notiz').objekt.id;
  const eintragen = zeit => c.d.ereignisAnlegen(t, { artId: art, datum: '2026-11-03', zeit, text: zeit });
  assert.ok((await eintragen('12:00')).ok);
  assert.ok((await eintragen('11:56')).ok);
  assert.ok((await eintragen('11:30')).ok);
  assert.ok((await eintragen('12:30')).ok);
  const nach = Object.fromEntries((await eventsVon(c)).map(e => [e.text, e.nachgetragen]));
  assert.deepEqual(nach, { '12:00': false, '11:56': false, '11:30': true, '12:30': false });
  const e = (await eventsVon(c)).find(x => x.text === '11:30');
  assert.ok(e.nachgetragenAm, 'mit „nachgetragen am“');
  const gestern = await c.d.ereignisAnlegen(t, { artId: art, datum: '2026-11-02', zeit: '23:00', text: 'gestern' });
  assert.ok(gestern.ok);
  assert.equal((await eventsVon(c)).find(x => x.text === 'gestern').nachgetragen, true);
});

test('Nachtrag: der Knopf „Nachtragen“ bleibt, ein Nachtrag in der Zukunft wird weiter abgelehnt', async () => {
  const c = await mitAktivitaet();
  const t = (await c.d.heutigerTag(c.id)).abschnittId;
  await c.d.ereignisartenAusVorschlaegen();
  const art = (await c.d.ereignisartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Notiz').objekt.id;
  assert.ok((await c.d.ereignisAnlegen(t, { artId: art, datum: '2026-11-03', zeit: '11:58', text: 'knapp' }, { nachtragen: true })).ok);
  assert.equal((await eventsVon(c))[0].nachgetragen, true, 'ausdrücklich nachgetragen, auch bei wenigen Minuten');
  const z = await c.d.ereignisAnlegen(t, { artId: art, datum: '2026-11-03', zeit: '12:30', text: 'später' }, { nachtragen: true });
  assert.equal(z.ok, false); assert.ok(z.fehler.zeit);
});

test('Wechsel mit Prüfung: die Befähigung der übernehmenden Person wird mit „geprüft am“ festgehalten, der Wechsel nicht gesperrt', async () => {
  const c = await mitAktivitaet();
  c.d.stelle(2026, 11, 3, 13, 4);
  const r = await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-11-03', abZeit: '13:04' });
  assert.ok(r.ok); assert.equal(r.nachgetragen, false);
  assert.equal(r.pruefung.name, 'Ben'); assert.equal(r.pruefung.geprueftAm, '2026-11-03T13:04');
  assert.equal(r.pruefung.ergebnis, 'unklar', 'ohne Anforderungen am Fahrzeug weiß die App es nicht');
  assert.ok(r.pruefung.gruende.length >= 1);
  const a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.verantwortung[0].pruefung, null, 'der Beginn ist kein Wechsel');
  assert.equal(a.verantwortung[1].pruefung.name, 'Ben');
  assert.equal(a.verantwortlichJetzt.name, 'Ben');
  const wz = (await eventsVon(c)).filter(e => e.art === 'wechsel');
  assert.equal(wz.length, 0, 'ohne Tag steht der Wechsel noch nirgends');
  await c.d.heutigerTag(c.id);
  const wz2 = (await eventsVon(c)).find(e => e.art === 'wechsel');
  assert.equal(wz2.pruefung.geprueftAm, '2026-11-03T13:04');
  assert.equal((await c.d.wechselLaden(wz2.id)).wechsel.pruefung.name, 'Ben');
});

test('Wechsel mit Prüfung: „nicht erlaubt“ nur, wo die App es sicher weiß, und auch dann wird der Wechsel nicht gesperrt', async () => {
  const c = await neu();
  const fs = (await c.d.nachweisartAusVorschlag('DE_FEV_FUEHRERSCHEIN_EU')).id;
  await c.d.anforderungAnlegen(c.wm, { bezeichnung: 'Führerschein', artIds: [fs] });
  await c.d.nachweisAnlegen('person', c.anna, fs, { gueltigBis: '2030-01-01', datei: scan });
  await c.d.nachweisAnlegen('person', c.ben, fs, { gueltigBis: '2026-11-04', datei: scan });
  const id = (await c.d.aktivitaetAnlegen({ bezeichnung: 'Urlaub', artId: c.toern, fahrzeugId: c.wm, vonDatum: '2026-11-03', bisDatum: '2026-11-05', verantwortlichId: c.anna })).id;
  await c.d.besatzungHinzufuegen(id, c.ben, { rolle: 'stellvertreter' });
  const r = await c.d.verantwortungWechseln(id, c.ben, { abDatum: '2026-11-03', abZeit: '12:00' });
  assert.ok(r.ok, 'nicht gesperrt');
  assert.equal(r.pruefung.ergebnis, 'nicht_erlaubt');
  assert.match(r.pruefung.gruende[0].text, /2026-11-04/);
  const zurueck = await c.d.verantwortungWechseln(id, c.anna, { abDatum: '2026-11-03', abZeit: '12:30' });
  assert.equal(zurueck.pruefung.ergebnis, 'erlaubt');
});

test('Wechsel nachtragen: mehr als 5 Minuten vor jetzt steht er als nachgetragen da, die Reihenfolge der Wechsel bleibt geschützt', async () => {
  const c = await mitAktivitaet();
  await c.d.heutigerTag(c.id);
  const r = await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-11-03', abZeit: '11:30' });
  assert.ok(r.ok); assert.equal(r.nachgetragen, true);
  const wz = (await eventsVon(c)).find(e => e.art === 'wechsel');
  assert.equal(wz.nachgetragen, true); assert.ok(wz.nachgetragenAm); assert.equal(wz.zeit, '11:30');
  const davor = await c.d.verantwortungWechseln(c.id, c.anna, { abDatum: '2026-11-03', abZeit: '11:00' });
  assert.equal(davor.ok, false); assert.ok(davor.fehler.abDatum, 'nicht vor dem letzten Wechsel');
  const knapp = await c.d.verantwortungWechseln(c.id, c.anna, { abDatum: '2026-11-03', abZeit: '11:58' });
  assert.ok(knapp.ok); assert.equal(knapp.nachgetragen, false);
});

test('Wechsel: eine stornierte Aktivität nimmt keinen Wechsel an', async () => {
  const c = await mitAktivitaet();
  await c.d.aktivitaetStornieren(c.id, 'Sturm');
  const r = await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-11-03', abZeit: '12:00' });
  assert.equal(r.ok, false); assert.match(r.fehler.allgemein, /storniert/);
  assert.equal((await c.d.aktivitaetLaden(c.id)).verantwortung.length, 1);
});

test('Tagesabschluss: tatsächliches Ziel und Notiz mit Verlauf, ohne Änderung kein neuer Stand', async () => {
  const c = await mitAktivitaet();
  const t = (await c.d.heutigerTag(c.id)).abschnittId;
  assert.equal((await c.d.tagesabschlussSpeichern(t, { zielTatsaechlich: 'Zadar', abschlussNotiz: 'ruhige Fahrt' })).geaendert, true);
  let x = (await c.d.abschnittLaden(t)).abschnitt;
  assert.equal(x.aktuell.werte.zielTatsaechlich, 'Zadar'); assert.equal(x.aktuell.werte.abschlussNotiz, 'ruhige Fahrt');
  assert.equal(x.verlauf.length, 2);
  assert.equal((await c.d.tagesabschlussSpeichern(t, { zielTatsaechlich: 'Zadar', abschlussNotiz: 'ruhige Fahrt' })).geaendert, false);
  assert.equal((await c.d.tagesabschlussSpeichern(t, { zielTatsaechlich: 'Sibenik', abschlussNotiz: 'ruhige Fahrt' })).geaendert, true);
  x = (await c.d.abschnittLaden(t)).abschnitt;
  assert.equal(x.verlauf.length, 3, 'der frühere Stand bleibt im Verlauf');
  assert.ok(x.verlauf[0].aenderungen.some(u => u.key === 'zielTatsaechlich' && u.alt === 'Zadar' && u.neu === 'Sibenik'));
  assert.equal(MM.Logbuch.hatAbschluss(x.aktuell.werte), true);
  assert.equal((await c.d.tagesabschlussSpeichern('gibt-es-nicht', {})).ok, false);
});

test('Tagesabschluss: „Tag ändern“ lässt ihn unberührt, eine stornierte Aktivität nimmt keinen an', async () => {
  const c = await mitAktivitaet();
  const t = (await c.d.heutigerTag(c.id)).abschnittId;
  await c.d.tagesabschlussSpeichern(t, { zielTatsaechlich: 'Zadar', abschlussNotiz: 'ruhig' });
  const w = (await c.d.abschnittLaden(t)).abschnitt.aktuell.werte;
  assert.ok((await c.d.abschnittAendern(t, { datum: w.datum, beginnZeit: w.beginnZeit, von: 'Biograd', ausgeblendet: 'nein' })).ok);
  const neu = (await c.d.abschnittLaden(t)).abschnitt.aktuell.werte;
  assert.equal(neu.von, 'Biograd'); assert.equal(neu.zielTatsaechlich, 'Zadar'); assert.equal(neu.abschlussNotiz, 'ruhig');
  await c.d.aktivitaetStornieren(c.id, 'Sturm');
  const r = await c.d.tagesabschlussSpeichern(t, { zielTatsaechlich: 'Split' });
  assert.equal(r.ok, false); assert.match(r.fehler.allgemein, /storniert/);
});

test('Alte Tage ohne Tagesabschluss und alte Wechsel ohne Prüfung bleiben lesbar', async () => {
  const c = await mitAktivitaet();
  const vorbereitet = await c.d.tagesabschnitteVorbereiten(c.id);
  assert.equal(vorbereitet.anzahl, 3);
  const lb = await c.d.logbuchLaden(c.id);
  lb.abschnitte.forEach(t => assert.equal(MM.Logbuch.hatAbschluss(t.aktuell.werte), false));
  /* ein Wechsel, wie ihn 2.0.13 gespeichert hat: ohne Feld „pruefung“ */
  await c.d.speicher.speichern('verantwortung', { id: 've-alt', aktivitaetId: c.id, personId: c.ben, ab: '2026-11-04T08:00', erstelltAm: new Date().toISOString() });
  const wz = (await eventsVon(c)).find(e => e.art === 'wechsel');
  assert.equal(wz.pruefung, null); assert.equal(wz.nachgetragen, false);
  assert.equal((await c.d.wechselLaden('ve-alt')).wechsel.pruefung, null);
});

test('Sicherung: Prüfung beim Wechsel, Nachtrag und Tagesabschluss kommen beim Einspielen wieder', async () => {
  const c = await mitAktivitaet();
  const t = (await c.d.heutigerTag(c.id)).abschnittId;
  await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-11-03', abZeit: '11:30' });
  await c.d.tagesabschlussSpeichern(t, { zielTatsaechlich: 'Zadar', abschlussNotiz: 'ruhig' });
  const s = await c.d.sicherungErzeugen({ mitDateien: true });
  const b = neueDaten();
  await b.starten();
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  const a = await b.aktivitaetLaden(c.id);
  assert.equal(a.verantwortung[1].pruefung.name, 'Ben');
  assert.ok(a.verantwortung[1].nachgetragenAm);
  const lb = await b.logbuchLaden(c.id);
  assert.equal(lb.abschnitte[0].aktuell.werte.zielTatsaechlich, 'Zadar');
  assert.equal(MM.Speicher.DB_VERSION, 9, 'keine Umstellung des Speichers');
});
