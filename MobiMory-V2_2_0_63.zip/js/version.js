/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.63';
  MM.STUFE = 'Ver- und Entsorgung, Tankvorgang ändern, Gas in kg, Kennungsprüfung, Fixkosten sichtbar';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
