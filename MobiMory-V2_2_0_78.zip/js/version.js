/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.78';
  MM.STUFE = 'Planung vor dem Verleih: Reise planen, Reisecheck und Reisetagebuch beim geliehenen Fahrzeug';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
