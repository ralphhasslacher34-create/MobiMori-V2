/*
 * Freigaben (Schritt 13c, seit 2.0.67): reine Rechnung und Texte, kein Netz, kein Speicher. Das Senden steht in daten.js.
 *
 * Festlegungen (Nutzer, 03.11.2026): Freigaben gelten je Fahrzeug und Zeitraum, die Einladung höchstens 12 Monate, die Kontroll-Freigabe geht per Code,
 * die Rechte werden auf dem Server geprüft (server/konto-dienst.mjs). Ein Gast darf nur lesen.
 * Der Gast sieht: Fahrzeug, Fristen, Zähler, Dokumente samt Datei und das letzte Prüfergebnis. Der Kontrolleur sieht nur Fahrzeug, Dokumente und Prüfergebnis.
 * Nie: Kosten, Notizen, Nachweise, Reisechecks, Routen, Besuche, Aktivitäten, Ereignisse, Personen, Orte, GPS.
 * Die Ansicht entsteht aus den Datensätzen des Dienstes (Form des Abgleichs) und wird nirgends gespeichert.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var MAX_MONATE = 12;
  var EINLADUNG_CODE = 10;
  var KONTROLLE_CODE = 8;
  var CODE_ZEICHEN = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';
  var KONTROLLE_STUNDEN = [
    { wert: 1, label: '1 Stunde' }, { wert: 4, label: '4 Stunden' }, { wert: 24, label: '1 Tag (Standard)' },
    { wert: 72, label: '3 Tage' }, { wert: 168, label: '7 Tage (Höchstwert)' }
  ];
  var STATUS_TEXT = { eingeladen: 'wartet auf Annahme', aktiv: 'gilt', wartet: 'beginnt später', planung: 'Planung läuft, der Verleih beginnt später', abgelaufen: 'abgelaufen', widerrufen: 'widerrufen' };
  var ERGEBNIS_TEXT = { erlaubt: 'Erlaubt', nicht_erlaubt: 'Nicht erlaubt', unklar: 'Unklar' };

  function text(x) { return x === null || x === undefined ? '' : String(x).trim(); }

  /* ---------- Datum (nur Tage) ---------- */
  function teile(t) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text(t));
    if (!m) return null;
    var y = +m[1], mo = +m[2], d = +m[3], x = new Date(Date.UTC(y, mo - 1, d));
    return x.getUTCFullYear() === y && x.getUTCMonth() === mo - 1 && x.getUTCDate() === d ? { y: y, mo: mo, d: d } : null;
  }
  function plusMonate(t, n) {
    var p = teile(t);
    if (!p) return null;
    var gesamt = p.y * 12 + (p.mo - 1) + n, y = Math.floor(gesamt / 12), mo = (gesamt % 12) + 1;
    var tage = new Date(Date.UTC(y, mo, 0)).getUTCDate(), d = Math.min(p.d, tage);
    function z(k) { return (k < 10 ? '0' : '') + k; }
    return y + '-' + z(mo) + '-' + z(d);
  }

  /* Eingaben der Einladung. Der Dienst prüft alles noch einmal, hier kommt nur die Meldung früher und in einfachen Worten. */
  function einladung(roh, heute) {
    roh = roh || {};
    var fehler = {}, w = {};
    var fz = text(roh.fahrzeugId);
    if (!fz) fehler.fahrzeugId = 'Bitte ein Fahrzeug wählen.'; else w.fahrzeugId = fz;
    var e = MM.Konto.email(roh.email);
    if (!e.ok) fehler.email = e.fehler; else w.email = e.email;
    var ab = text(roh.ab) || heute;
    if (!teile(ab)) fehler.ab = 'Bitte das Datum „von“ als Tag eingeben.';
    else if (ab < heute) fehler.ab = 'Das Datum „von“ liegt in der Vergangenheit.';
    else w.ab = ab;
    /* Planung vor dem Verleih (2.0.78, Bau 3): freiwillig. Ab diesem Tag sieht die Person das Fahrzeug, plant und macht Reisechecks. Eintragen darf sie erst ab „von“. */
    var pa = text(roh.planAb);
    if (pa) {
      if (!teile(pa)) fehler.planAb = 'Bitte das Datum „Planung ab“ als Tag eingeben.';
      else if (pa < heute) fehler.planAb = 'Das Datum „Planung ab“ liegt in der Vergangenheit.';
      else if (w.ab && pa > w.ab) fehler.planAb = 'Die Planung muss vor oder am Tag des Verleihs beginnen.';
      else if (w.ab && w.ab > plusMonate(pa, MAX_MONATE)) fehler.planAb = 'Die Planung darf höchstens ' + MAX_MONATE + ' Monate vor dem Verleih beginnen.';
      else if (w.ab && pa < w.ab) w.planAb = pa;
    }
    var bis = text(roh.bis);
    if (!bis) fehler.bis = 'Bitte angeben, bis wann die Freigabe gilt.';
    else if (!teile(bis)) fehler.bis = 'Bitte das Datum „bis“ als Tag eingeben.';
    else if (w.ab && bis < w.ab) fehler.bis = 'Das Datum „bis“ liegt vor dem Datum „von“.';
    else if (w.ab && bis > plusMonate(w.ab, MAX_MONATE)) fehler.bis = 'Eine Freigabe gilt höchstens ' + MAX_MONATE + ' Monate. Spätestens bis ' + plusMonate(w.ab, MAX_MONATE) + '.';
    else w.bis = bis;
    /* Halterpflicht (Bau B, 2.0.74): Der Halter bestätigt, dass er den Nachweis der Person gesehen hat. Gespeichert wird nur die Art und „gültig bis“, kein Scan. */
    var art = text(roh.nachweisArt);
    if (!art) fehler.nachweisArt = 'Bitte angeben, welchen Nachweis du gesehen hast (zum Beispiel Führerschein).';
    else if (art.length > 60) fehler.nachweisArt = 'Die Bezeichnung ist zu lang (höchstens 60 Zeichen).';
    else w.nachweisArt = art;
    var nb = text(roh.nachweisBis);
    if (nb) {
      if (!teile(nb)) fehler.nachweisBis = 'Bitte das Datum „Nachweis gültig bis“ als Tag eingeben.';
      else if (w.bis && nb < w.bis) fehler.nachweisBis = 'Der Nachweis läuft am ' + nb + ' ab, die Freigabe endet am ' + w.bis + '. Kürze die Freigabe oder lass den Nachweis erneuern.';
      else w.nachweisBis = nb;
    }
    /* Rechte (2.0.75, Bau 1): „lesen“ (wie bisher) oder „mitnutzen“. Mit Mitnutzung steht der Name des Gastes an seinen Einträgen. Dokumente lassen sich ausnehmen. */
    var rechte = text(roh.rechte) || 'lesen';
    if (rechte !== 'lesen' && rechte !== 'mitnutzen') fehler.rechte = 'Bitte wählen: nur lesen oder mitnutzen.';
    else if (roh.rechte !== undefined && roh.rechte !== '') w.rechte = rechte;
    var gn = text(roh.gastName);
    if (gn.length > 40) fehler.gastName = 'Der Name ist zu lang (höchstens 40 Zeichen).';
    else if (rechte === 'mitnutzen' && !gn) fehler.gastName = 'Bitte einen Namen angeben. Er steht an den Einträgen der Person (zum Beispiel „Anna“).';
    else if (gn) w.gastName = gn;
    var aus = Array.isArray(roh.ausnahmen) ? roh.ausnahmen.filter(function (x, i, l) { return typeof x === 'string' && x && l.indexOf(x) === i; }) : [];
    if (aus.length > 50) fehler.ausnahmen = 'Es lassen sich höchstens 50 Dokumente ausnehmen.';
    else if (aus.length) w.ausnahmen = aus;
    if (roh.bestaetigt !== true) fehler.bestaetigt = 'Bitte bestätige, dass du den Nachweis der Person gesehen hast. Ohne diese Bestätigung gibt es keinen Verleih.';
    else w.bestaetigt = true;
    return { ok: Object.keys(fehler).length === 0, werte: w, fehler: fehler };
  }

  function tagText(t) { return MM.Hilfen && MM.Hilfen.datum ? MM.Hilfen.datum(t) : text(t); }
  /* Überschneiden sich zwei Zeiträume (nur Tage, beide Enden zählen mit)? */
  function tageUeberschneiden(a1, b1, a2, b2) { return a1 <= b2 && a2 <= b1; }

  /* Prüfung vor dem Verleih (Bau B, 2.0.74). Sie warnt nur, sie sperrt nicht: Der Halter entscheidet dann „Trotzdem verleihen“ oder „Absage“.
     p.ab, p.bis                       Zeitraum des Verleihs
     p.aktivitaeten  [{ name, vonDatum, bisDatum, status }]   eigene Planung für dieses Fahrzeug (storniert und vorbei zählen nicht)
     p.freigaben     [{ email, ab, bis, status }]              andere Freigaben für dieses Fahrzeug (widerrufen und abgelaufen zählen nicht)
     p.fristen       [{ bezeichnung, status, text, wirkung }]  Ergebnis von MM.Aktivitaeten.fristenImZeitraum bis zum Ende des Verleihs
     p.email                                                   die Person, an die verliehen wird (ihre bisherige Freigabe wird ersetzt und zählt nicht)
     Die eigene Planung hat Vorrang, deshalb steht sie zuerst. */
  function verleihHinweise(p) {
    var liste = [];
    (p.aktivitaeten || []).forEach(function (a) {
      if (!a || a.status === 'storniert' || a.status === 'vorbei') return;
      var von = text(a.vonDatum), bis = text(a.bisDatum) || von;
      if (von && tageUeberschneiden(p.ab, p.bis, von, bis)) {
        liste.push({ art: 'planung', text: 'Eigene Planung: „' + (text(a.name) || 'Aktivität') + '“ vom ' + tagText(von) + (bis !== von ? ' bis ' + tagText(bis) : '') + ' liegt in diesem Zeitraum. Deine Planung hat Vorrang.' });
      }
    });
    (p.freigaben || []).forEach(function (f) {
      if (!f || (f.status !== 'eingeladen' && f.status !== 'aktiv' && f.status !== 'wartet')) return;
      if (text(f.email).toLowerCase() === text(p.email).toLowerCase()) return;
      if (tageUeberschneiden(p.ab, p.bis, text(f.ab), text(f.bis))) {
        liste.push({ art: 'verliehen', text: 'Das Fahrzeug ist vom ' + tagText(f.ab) + ' bis ' + tagText(f.bis) + ' schon an ' + text(f.email) + ' verliehen.' });
      }
    });
    (p.fristen || []).forEach(function (f) {
      if (!f || (f.status !== 'faellig' && f.status !== 'ueberfaellig')) return;
      var wirkung = f.wirkung === 'sperre' ? ' Diese Frist sperrt das Fahrzeug.' : (f.wirkung === 'eingeschraenkt' ? ' Diese Frist schränkt das Fahrzeug ein.' : '');
      liste.push({ art: 'frist', text: (f.status === 'ueberfaellig' ? 'Frist überfällig: ' : 'Frist wird fällig: ') + text(f.bezeichnung) + (f.text ? ' (' + f.text + ')' : '') + '.' + wirkung });
    });
    return { liste: liste, ok: liste.length === 0 };
  }

  /* Eintrag des Gastes bei der Mitnutzung (2.0.75). Dieselben Regeln prüft der Dienst noch einmal. Fixkosten legt nur der Besitzer an, Reisekosten bleiben beim Gast. */
  var GAST_GRUPPEN = [{ wert: 'variabel', label: 'Variable Kosten (Diesel, Maut, Stellplatz unterwegs)' }, { wert: 'instandhaltung', label: 'Reparatur und Wartung' }];
  function zahl(roh) {
    var t = text(roh);
    if (/^\d{1,3}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, '');
    t = t.replace(',', '.');
    if (t === '' || !/^-?\d+(\.\d+)?$/.test(t)) return null;
    return Number(t);
  }
  function erfassung(art, roh, heute) {
    roh = roh || {};
    var fehler = {}, w = { art: art };
    function datumPruefen() {
      var d = text(roh.datum) || heute;
      if (!teile(d)) fehler.datum = 'Bitte das Datum als Tag eingeben.';
      else if (d > plusTage(heute, 1)) fehler.datum = 'Das Datum liegt in der Zukunft.';
      else w.datum = d;
    }
    if (art === 'kilometer') {
      var z = text(roh.zaehlerId);
      if (!z) fehler.zaehlerId = 'Bitte den Kilometerzähler wählen.'; else w.zaehlerId = z;
      var n = zahl(roh.wert);
      if (n === null || n < 0 || n > 10000000) fehler.wert = 'Bitte den Kilometerstand als Zahl eingeben.'; else w.wert = n;
      datumPruefen();
    } else if (art === 'kosten') {
      var g = text(roh.gruppe);
      if (g === 'fix') fehler.gruppe = 'Fixkosten legt nur der Besitzer an.';
      else if (g === 'reisekasse') fehler.gruppe = 'Reisekosten (Campingplatz, Essen, Souvenirs) bleiben bei dir und gehen nicht ins Fahrzeug.';
      else if (g !== 'variabel' && g !== 'instandhaltung') fehler.gruppe = 'Bitte wählen: variable Kosten oder Reparatur und Wartung.';
      else w.gruppe = g;
      var ka = text(roh.kostenart);
      if (ka) w.kostenart = ka;
      var bez = text(roh.bezeichnung);
      if (!bez) fehler.bezeichnung = 'Bitte kurz sagen, wofür der Betrag ist, zum Beispiel „Diesel“ oder „Maut“.';
      else if (bez.length > 80) fehler.bezeichnung = 'Der Text ist zu lang (höchstens 80 Zeichen).'; else w.bezeichnung = bez;
      var b = zahl(roh.betrag);
      if (b === null || !(b > 0) || b > 10000000) fehler.betrag = 'Bitte einen Betrag über 0 eingeben.'; else w.betrag = b;
      datumPruefen();
      var ort = text(roh.ortText);
      if (ort.length > 120) fehler.ortText = 'Der Ort ist zu lang (höchstens 120 Zeichen).'; else if (ort) w.ortText = ort;
    } else if (art === 'stoerung') {
      var sb = text(roh.bezeichnung);
      if (!sb) fehler.bezeichnung = 'Bitte kurz sagen, worum es geht, zum Beispiel „Motor springt schlecht an“.';
      else if (sb.length > 80) fehler.bezeichnung = 'Der Text ist zu lang (höchstens 80 Zeichen).'; else w.bezeichnung = sb;
      var be = text(roh.beschreibung);
      if (be.length > 500) fehler.beschreibung = 'Die Beschreibung ist zu lang (höchstens 500 Zeichen).'; else if (be) w.beschreibung = be;
      var au = text(roh.auswirkung);
      if (au !== 'keine' && au !== 'bedingt' && au !== 'nicht') fehler.auswirkung = 'Bitte wählen, wie weit die Störung das Fahrzeug einschränkt.'; else w.auswirkung = au;
    } else fehler.art = 'Diese Art von Eintrag gibt es nicht.';
    return { ok: Object.keys(fehler).length === 0, werte: w, fehler: fehler };
  }
  function plusTage(t, n) {
    var p = teile(t);
    if (!p) return t;
    var x = new Date(Date.UTC(p.y, p.mo - 1, p.d + n));
    function z(k) { return (k < 10 ? '0' : '') + k; }
    return x.getUTCFullYear() + '-' + z(x.getUTCMonth() + 1) + '-' + z(x.getUTCDate());
  }
  var AUSWIRKUNG_TEXT = { keine: 'Fahrzeug bleibt nutzbar', bedingt: 'Nur bedingt einsatzfähig', nicht: 'Nicht einsatzfähig' };
  /* Eine Zeile für die Liste „Meine Einträge“ des Gastes. */
  function eintragText(e) {
    if (!e) return '';
    if (e.art === 'kilometer') return 'Kilometerstand ' + (MM.Hilfen && MM.Hilfen.zahl ? MM.Hilfen.zahl(e.wert) : e.wert) + ' km';
    if (e.art === 'kosten') return e.titel + ': ' + String(Number(e.betrag).toFixed(2)).replace('.', ',') + ' €' + (e.ausgeblendet ? ' (vom Besitzer ausgeblendet)' : '');
    if (e.art === 'stoerung') return 'Störung: ' + e.titel + (e.status === 'erledigt' ? ' (erledigt)' : ' (offen, ' + (AUSWIRKUNG_TEXT[e.auswirkung] || '').toLowerCase() + ')');
    return e.titel || '';
  }

  /* Die Plätze für Gäste in einem Satz (aus der Antwort des Dienstes). */
  function gaesteText(v) {
    if (!v) return '';
    if (v.erlaubt === false) return 'Gäste gibt es ab der Stufe Mittel. Mit Basic kannst du niemanden einladen.';
    var g = v.gaeste || {};
    if (g.grenze === null || g.grenze === undefined) return 'Für Gäste gibt es keine Grenze. Zurzeit ' + (g.belegt || 0) + ' Gast' + (g.belegt === 1 ? '' : 'e') + '.';
    return 'Gäste: ' + (g.belegt || 0) + ' von ' + g.grenze + ' Plätzen belegt (Geräte der Stufe minus deine eigenen Geräte).';
  }

  function codeSauber(roh, laenge) {
    var t = text(roh).toUpperCase().replace(/[\s-]+/g, '');
    if (t.length !== laenge) return null;
    for (var i = 0; i < t.length; i++) { if (CODE_ZEICHEN.indexOf(t.charAt(i)) < 0) return null; }
    return t;
  }
  function codeEinladung(roh) {
    var c = codeSauber(roh, EINLADUNG_CODE);
    return c ? { ok: true, code: c } : { ok: false, fehler: 'Der Code aus der E-Mail hat ' + EINLADUNG_CODE + ' Zeichen (Buchstaben und Ziffern).' };
  }
  function codeKontrolle(roh) {
    var c = codeSauber(roh, KONTROLLE_CODE);
    return c ? { ok: true, code: c } : { ok: false, fehler: 'Der Kontroll-Code hat ' + KONTROLLE_CODE + ' Zeichen (Buchstaben und Ziffern).' };
  }
  /* Zur Anzeige in zwei Hälften: ABCD-EFGH */
  function codeAnzeige(code) { var t = text(code); return t.length > 4 ? t.slice(0, t.length / 2) + '-' + t.slice(t.length / 2) : t; }

  function stunden(roh) {
    var n = Number(roh);
    return Number.isInteger(n) && n >= 1 && n <= 168 ? { ok: true, stunden: n } : { ok: false, fehler: 'Die Gültigkeit liegt zwischen 1 Stunde und 7 Tagen.' };
  }

  /* Der Link für den Kontrolleur: Adresse der App, Code und Adresse des Dienstes. Die Adresse des Dienstes steht mit im Link, damit
     das Gerät des Kontrolleurs nichts einrichten muss. */
  function kontrollLink(appAdresse, dienstUrl, code) {
    var basis = text(appAdresse).replace(/#.*$/, '');
    return basis + '#/kontrolle/' + encodeURIComponent(text(code)) + '/' + encodeURIComponent(text(dienstUrl));
  }
  function entschluesseln(t) { try { return decodeURIComponent(t); } catch (e) { return ''; } }
  function kontrollLinkLesen(code, dienst) {
    var c = codeKontrolle(code ? entschluesseln(code) : '');
    var u = dienst ? MM.Konto.dienstAdresse(entschluesseln(dienst)) : { ok: false };
    return { code: c.ok ? c.code : '', dienstUrl: u.ok ? u.url : '' };
  }

  /* ---------- Ansicht aus den Datensätzen des Dienstes ---------- */
  function lesen(d) {
    try { var o = JSON.parse(d.nutzlast); return o && typeof o === 'object' && !Array.isArray(o) && o.id === d.id ? o : null; } catch (e) { return null; }
  }
  function neuer(a, b) { return !a || (b.nr || 0) > (a.nr || 0); }

  function sicht(datensaetze, heute) {
    var nach = {};
    (datensaetze || []).forEach(function (d) {
      if (!d || typeof d.tabelle !== 'string') return;
      var o = lesen(d);
      if (o) (nach[d.tabelle] = nach[d.tabelle] || []).push(o);
    });
    function liste(t) { return nach[t] || []; }
    var fzRec = liste('fahrzeuge')[0];
    if (!fzRec) return null;

    var verlauf = {};
    liste('verlaeufe').forEach(function (v) { var k = v.objektTyp + '/' + v.objektId; if (neuer(verlauf[k], v)) verlauf[k] = v; });
    function werte(typ, id) { var v = verlauf[typ + '/' + id]; return v && v.werte && typeof v.werte === 'object' ? v.werte : {}; }

    var eintrag = null;
    liste('eintraege').forEach(function (e) { if (neuer(eintrag, e)) eintrag = e; });
    var fw = eintrag && eintrag.werte ? eintrag.werte : {};
    var kennungFeld = null, artName = '';
    try { kennungFeld = fzRec.art ? MM.Fahrzeugarten.kennungFeld(fzRec.art) : null; var a = fzRec.art ? MM.Fahrzeugarten.art(fzRec.art) : null; artName = a ? a.name : ''; } catch (e) { kennungFeld = null; }
    var fahrzeug = { id: fzRec.id, bezeichnung: text(fw.bezeichnung) || 'Fahrzeug', kennung: kennungFeld ? text(fw[kennungFeld]) : '', art: artName };
    /* Nur für den Reisecheck des Gastes (2.0.78): Fahrzeugart, Welt und technische Angaben, die der Dienst ohnehin an den Gast liefert. Sie werden nie angezeigt, und es geht nie eine Nummer hinaus. */
    var welt = 'land';
    try { var aa = fzRec.art ? MM.Fahrzeugarten.art(fzRec.art) : null; if (aa && aa.welt) welt = aa.welt; } catch (e) { welt = 'land'; }
    fahrzeug.check = { artName: artName, welt: welt, werte: fw };

    /* Zähler mit dem letzten Stand */
    var stand = {};
    liste('zaehlerstaende').forEach(function (s) {
      var b = stand[s.zaehlerId];
      if (!b || String(s.datum || '') > String(b.datum || '') || (s.datum === b.datum && (s.nr || 0) > (b.nr || 0))) stand[s.zaehlerId] = s;
    });
    var zaehler = liste('zaehler').map(function (z) {
      var art = MM.Fristen.zaehlerArt(z.art), s = stand[z.id] || null;
      return { id: z.id, name: text(werte('zaehler', z.id).bezeichnung) || (art ? art.standard : 'Zähler'), einheit: art ? art.einheit : '',
        stand: s && typeof s.wert === 'number' ? s.wert : null, datum: s ? s.datum || null : null };
    });

    /* Fristen */
    var letzte = {};
    liste('durchfuehrungen').forEach(function (d) {
      var b = letzte[d.fristId];
      if (!b || String(d.datum || '') > String(b.datum || '') || (d.datum === b.datum && String(d.erstelltAm || '') > String(b.erstelltAm || ''))) letzte[d.fristId] = d;
    });
    var fristen = liste('fristen').map(function (f) {
      var w = werte('frist', f.id), l = letzte[f.id] || null, s = w.zaehlerId ? stand[w.zaehlerId] : null, res;
      if (l && l.datum) {
        res = MM.Fristen.berechne({ werte: w, letzte: { datum: l.datum, zaehlerstand: l.zaehlerstand === undefined ? null : l.zaehlerstand },
          stand: s && typeof s.wert === 'number' ? { wert: s.wert } : null, heute: heute });
      } else res = { status: 'unbekannt', kalender: null, zaehler: null };
      var zeilen = [], zArt = null;
      zaehler.forEach(function (z) { if (z.id === w.zaehlerId) zArt = z; });
      if (res.kalender) {
        var tage = res.kalender.tage;
        zeilen.push((tage < 0 ? 'überfällig seit ' : 'fällig am ') + MM.Hilfen.datum(res.kalender.faelligAm) + (tage < 0 ? ' (' + (-tage) + (tage === -1 ? ' Tag' : ' Tagen') + ')' : tage === 0 ? ' (heute)' : ' (in ' + tage + (tage === 1 ? ' Tag' : ' Tagen') + ')'));
      }
      if (res.zaehler && res.zaehler.faelligBei !== undefined) {
        zeilen.push('fällig bei ' + MM.Hilfen.zahl(res.zaehler.faelligBei) + (zArt && zArt.einheit ? ' ' + zArt.einheit : ''));
      }
      if (l && l.datum) zeilen.push('zuletzt erledigt am ' + MM.Hilfen.datum(l.datum));
      return { id: f.id, name: text(w.bezeichnung) || 'Frist', kategorie: w.kategorie || null, status: res.status, text: zeilen.join(', ') || 'noch kein Stand bekannt' };
    }).sort(function (a, b) { return MM.Fristen.rang(b.status) - MM.Fristen.rang(a.status) || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0); });

    /* Dokumente mit ihren Dateien */
    var dateien = {};
    liste('dateien').forEach(function (d) { (dateien[d.dokumentId] = dateien[d.dokumentId] || []).push({ id: d.id, name: text(d.name) || 'Datei', mime: text(d.mime), groesse: typeof d.groesse === 'number' ? d.groesse : null }); });
    var dokumente = liste('dokumente').map(function (d) {
      var w = werte('dokument', d.id);
      return { id: d.id, bezeichnung: text(w.bezeichnung) || 'Dokument', art: text(w.art), link: /^https?:\/\//i.test(text(w.link)) ? text(w.link) : null,
        dateien: (dateien[d.id] || []).sort(function (a, b) { return a.name < b.name ? -1 : a.name > b.name ? 1 : 0; }) };
    }).sort(function (a, b) { return a.bezeichnung < b.bezeichnung ? -1 : a.bezeichnung > b.bezeichnung ? 1 : 0; });

    /* Frühere Störungen und Arbeiten (seit 2.0.76, nur mit dem Recht „mitnutzen“ vom Dienst geliefert): nur Texte, nie Beträge. */
    var vorgaenge = liste('vorgaenge').map(function (v) {
      var w = werte('vorgang', v.id);
      return { id: v.id, komponenteId: v.komponenteId || null, art: text(w.art), status: text(w.status), bezeichnung: text(w.bezeichnung), beschreibung: text(w.beschreibung), arbeit: text(w.arbeit),
        gemeldetAm: text(w.gemeldetAm) || null, erledigtAm: text(w.erledigtAm) || null, erledigtNotiz: text(w.erledigtNotiz) };
    }).filter(function (v) { return v.bezeichnung; });

    /* Letztes Prüfergebnis (zum Tagesbeginn festgehalten) */
    var p = null;
    liste('tagespruefungen').forEach(function (t) { if (!p || String(t.erstelltAm || '') > String(p.erstelltAm || '')) p = t; });
    var pruefung = null;
    if (p && p.stand && typeof p.stand === 'object') {
      var f = p.stand.fristen || {};
      pruefung = { geprueftAm: p.stand.geprueftAm || null, tagesbeginn: p.stand.tagesbeginn || null, ergebnis: p.stand.ergebnis || null,
        ergebnisText: ERGEBNIS_TEXT[p.stand.ergebnis] || 'Kein Ergebnis', fristen: { betroffen: f.betroffen || 0, sperre: f.sperre || 0, eingeschraenkt: f.eingeschraenkt || 0 } };
    }
    return { fahrzeug: fahrzeug, fristen: fristen, zaehler: zaehler, dokumente: dokumente, vorgaenge: vorgaenge, pruefung: pruefung };
  }

  MM.Freigaben = {
    MAX_MONATE: MAX_MONATE, EINLADUNG_CODE: EINLADUNG_CODE, KONTROLLE_CODE: KONTROLLE_CODE, KONTROLLE_STUNDEN: KONTROLLE_STUNDEN, STATUS_TEXT: STATUS_TEXT,
    einladung: einladung, erfassung: erfassung, eintragText: eintragText, GAST_GRUPPEN: GAST_GRUPPEN, AUSWIRKUNG_TEXT: AUSWIRKUNG_TEXT, verleihHinweise: verleihHinweise, gaesteText: gaesteText, codeEinladung: codeEinladung, codeKontrolle: codeKontrolle, codeAnzeige: codeAnzeige, stunden: stunden, plusMonate: plusMonate,
    kontrollLink: kontrollLink, kontrollLinkLesen: kontrollLinkLesen, sicht: sicht,
    TEXT_BEFAEHIGUNG: 'Als Halter bist du dafür verantwortlich, dass nur Personen fahren, die das dürfen. Schau dir deshalb den Nachweis der Person an (Führerschein, Bootsführerschein oder was für dein Fahrzeug nötig ist) und bestätige das hier. MobiMory speichert nur die Art und „gültig bis“, keinen Scan und keine Nummer.',
    TEXT_FREIGABE: 'Du verleihst ein Fahrzeug an eine andere Person und gibst es für sie frei, nur zum Lesen, für einen Zeitraum von höchstens 12 Monaten. Die Person bekommt per E-Mail einen Code, meldet sich mit derselben E-Mail-Adresse bei MobiMory an und trägt den Code ein. Sie sieht das Fahrzeug, seine Fristen und Zähler, die Dokumente samt Dateien und das letzte Prüfergebnis. Sie sieht nie deine Kosten, Notizen, Nachweise, Reisechecks, Aktivitäten, Ereignisse oder Standorte. Nachweis-Scans kann sie nicht öffnen, weil sie mit deinem Schlüsselwort verschlüsselt sind. Du kannst die Freigabe jederzeit stornieren, der Zugriff endet dann sofort.',
    TEXT_FREIGABE_VORAUS: 'Das Fahrzeug muss beim Dienst liegen. Tippe vorher unter Einstellungen › Deine Daten › Konto auf „Jetzt abgleichen“.',
    TEXT_KONTROLLE: 'Für eine Kontrolle (zum Beispiel Polizei oder Hafenbehörde) erzeugst du einen kurzen Code. Wer ihn kennt, sieht nur das Fahrzeug, die Dokumente samt Dateien und das letzte Prüfergebnis, ohne eigenes Konto. Der Code gilt nur kurz (höchstens 7 Tage), und du kannst ihn jederzeit widerrufen. Der Code wird nur jetzt angezeigt. Notiere ihn oder schicke den Link gleich weiter.',
    TEXT_MITNUTZUNG: 'Mitnutzen heißt: Die Person trägt Kilometer, Fahrzeugkosten (nicht die Fixkosten) und Störungen im Fahrzeug ein, mit ihrem Namen daran, und kann Kontroll-Codes erzeugen. Meldet sie eine Störung, bekommst du eine Info-Mail. Sie sieht deine früheren Störungen und Arbeiten (nur die Texte, keine Beträge und keine Notizen, die bleiben auf deinem Gerät), damit MobiMory ähnliche frühere Fälle zeigen kann. Sie kann nichts ändern, was du eingetragen hast, das Fahrzeug nicht verkaufen und nicht übergeben. Ihre Reisekosten (Campingplatz, Essen, Souvenirs) bleiben bei ihr.',
    TEXT_GAST_MITNUTZUNG: 'Du darfst dieses Fahrzeug mitnutzen: Trage Kilometer, Fahrzeugkosten und Störungen ein. Sie erscheinen mit deinem Namen im Fahrzeug des Besitzers. Ändern oder löschen kann nur der Besitzer. Reisekosten (Campingplatz, Essen, Souvenirs) gehören nicht hierher, sie bleiben bei dir.',
    TEXT_GAST: 'Du siehst hier nur, was die Person für dich freigegeben hat. Du kannst nichts ändern. Die Daten werden nur angezeigt und nicht auf deinem Gerät gespeichert. Wenn die Freigabe endet oder widerrufen wird, ist sie beim nächsten Laden weg.',
    TEXT_KONTROLLE_SEITE: 'Du siehst nur das Fahrzeug, die Dokumente und das letzte Prüfergebnis. Nichts davon wird auf diesem Gerät gespeichert. Der Code gilt nur für kurze Zeit.'
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
