'use strict';
/* 2.0.78 (Bau 3): Meine Reise zu einem geliehenen Fahrzeug. Reine Regeln (MM.Leihreise), Einladung mit „Planung ab“, Daten-Schicht (Plan, Tagebuch, Reisecheck des Gastes), Einbau. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'personen', 'orte', 'gebiete',
  'ortssuche', 'sicherung', 'speicher', 'hilfen', 'texte', 'logbuch', 'status', 'reiseorte', 'werkstatt', 'kosten', 'reisekasse', 'routen', 'reisecheck', 'konto', 'abgleich', 'freigaben', 'leihreise', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const L = MM.Leihreise;
const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

const HEUTE = '2026-11-14';
const GRENZE = { von: '2026-11-20', bis: '2027-01-31' };
const PLAN = { name: 'Ostsee', vonDatum: '2026-11-21', bisDatum: '2026-11-28', gebiet: 'Dänemark', start: '', ziel: '', besatzung: 'Anna, Fahrer, Führerschein Klasse B\nBen, Mitfahrer', notiz: 'Gas prüfen' };
const ANF = (x) => Object.assign({ id: 'r1', area: 'Papiere', category: 'Pflicht', subjectKey: 'P1', subjectType: 'Person', trafficMode: 'Land', requirement: 'Führerschein für P1', proofKey: 'FS',
  status: 'Erfüllt', evidence: 'P1 hat Führerschein', explanation: 'passt', confidence: 'hoch', conflict: false, sources: [{ title: 'Amt', url: 'https://amt.example/x', publisher: 'Amt', official: true, updated: '' }] }, x || {});
const ANTWORT = { ok: true, model: 'm1', requestId: 'q1', researchedAt: '2026-11-14T11:00:00Z', result: { summary: 'Fertig', researchStatus: 'vollständig', warnings: [], route: { routingStatus: 'plausibel', summary: '', assumptions: [], routeWarnings: [] }, requirements: [ANF()] } };

test('Besatzung: eine Person je Zeile, Rolle und Nachweis freiwillig, Rollen werden erkannt', () => {
  assert.deepEqual(L.besatzungLesen('Anna, Fahrer, Führerschein B\nBen, Mitfahrer\nCleo, Führerschein Klasse B\nDora, Skipper\n\n'), [
    { name: 'Anna', rolle: 'Fahrer', nachweis: 'Führerschein B' }, { name: 'Ben', rolle: 'Mitfahrer', nachweis: '' },
    { name: 'Cleo', rolle: 'Fahrer', nachweis: 'Führerschein Klasse B' }, { name: 'Dora', rolle: 'Skipper', nachweis: '' }]);
  assert.deepEqual(L.besatzungLesen(''), []);
  assert.equal(L.besatzungText(L.besatzungLesen('Anna, Fahrer, Führerschein B')), 'Anna, Fahrer, Führerschein B');
});

test('Plan: Reisetage müssen im Verleih liegen, Besatzung ist Pflicht, Start und Ziel nur zusammen', () => {
  const ok = L.planPruefen(PLAN, GRENZE);
  assert.ok(ok.ok, JSON.stringify(ok.fehler)); assert.equal(ok.werte.besatzung.length, 2); assert.equal(ok.werte.gebiet, 'Dänemark');
  assert.match(L.planPruefen(Object.assign({}, PLAN, { vonDatum: '2026-11-15' }), GRENZE).fehler.vonDatum, /vor dem Verleih/);
  assert.match(L.planPruefen(Object.assign({}, PLAN, { bisDatum: '2027-02-01' }), GRENZE).fehler.bisDatum, /nach dem Verleih/);
  assert.ok(L.planPruefen(Object.assign({}, PLAN, { bisDatum: '2026-11-20' }), GRENZE).fehler.bisDatum);
  assert.ok(L.planPruefen(Object.assign({}, PLAN, { name: '' }), GRENZE).fehler.name);
  assert.ok(L.planPruefen(Object.assign({}, PLAN, { besatzung: '' }), GRENZE).fehler.besatzung);
  assert.ok(L.planPruefen(Object.assign({}, PLAN, { besatzung: Array(9).fill('X').join('\n') }), GRENZE).fehler.besatzung);
  assert.ok(L.planPruefen(Object.assign({}, PLAN, { start: 'Kiel' }), GRENZE).fehler.ziel);
  assert.ok(L.planPruefen(Object.assign({}, PLAN, { start: 'Kiel', ziel: 'Malmö' }), GRENZE).ok);
  assert.ok(L.planPruefen(PLAN, {}).ok, 'ohne bekannte Grenzen (kein Netz) wird nur auf sich selbst geprüft');
});

test('Tagebuch: Datum Vorgabe heute, Text Pflicht und begrenzt', () => {
  const ok = L.tagebuchPruefen({ datum: '', text: ' Schöner Tag ' }, HEUTE);
  assert.ok(ok.ok); assert.equal(ok.werte.datum, HEUTE); assert.equal(ok.werte.text, 'Schöner Tag');
  assert.ok(L.tagebuchPruefen({ datum: HEUTE, text: '  ' }, HEUTE).fehler.text);
  assert.ok(L.tagebuchPruefen({ datum: 'gestern', text: 'x' }, HEUTE).fehler.datum);
  assert.ok(L.tagebuchPruefen({ datum: HEUTE, text: 'x'.repeat(4001) }, HEUTE).fehler.text);
});

test('Einladung: „Planung ab“ ist freiwillig, liegt nicht in der Vergangenheit, nicht nach dem Verleih und höchstens 12 Monate davor', () => {
  const basis = { fahrzeugId: 'fz-1', email: 'kind@example.org', ab: '2026-11-20', bis: '2027-01-31', nachweisArt: 'Führerschein', nachweisBis: '', bestaetigt: true };
  const alt = MM.Freigaben.einladung(basis, HEUTE);
  assert.ok(alt.ok); assert.equal(alt.werte.planAb, undefined);
  const ok = MM.Freigaben.einladung(Object.assign({}, basis, { planAb: '2026-11-15' }), HEUTE);
  assert.ok(ok.ok); assert.equal(ok.werte.planAb, '2026-11-15');
  assert.equal(MM.Freigaben.einladung(Object.assign({}, basis, { planAb: '2026-11-20' }), HEUTE).werte.planAb, undefined, 'gleich dem Verleih heißt keine Planung davor');
  assert.match(MM.Freigaben.einladung(Object.assign({}, basis, { planAb: '2026-11-01' }), HEUTE).fehler.planAb, /Vergangenheit/);
  assert.match(MM.Freigaben.einladung(Object.assign({}, basis, { planAb: '2026-11-25' }), HEUTE).fehler.planAb, /vor oder am Tag/);
  assert.ok(MM.Freigaben.einladung(Object.assign({}, basis, { planAb: 'bald' }), HEUTE).fehler.planAb);
  assert.ok(MM.Freigaben.STATUS_TEXT.planung);
});

test('Sicht des Gastes: Fahrzeugart, Welt und Angaben für den Reisecheck stehen bereit (nie angezeigt)', () => {
  const nutz = (o) => JSON.stringify(o);
  const s = MM.Freigaben.sicht([
    { tabelle: 'fahrzeuge', id: 'fz-1', nutzlast: nutz({ id: 'fz-1', art: 'boot' }) },
    { tabelle: 'eintraege', id: 'en-1', nutzlast: nutz({ id: 'en-1', fahrzeugId: 'fz-1', nr: 1, werte: { bezeichnung: 'Seeschwalbe', marke: 'Bavaria', laenge: 9.5 } }) }
  ], HEUTE);
  assert.equal(s.fahrzeug.bezeichnung, 'Seeschwalbe'); assert.equal(s.fahrzeug.check.welt, 'wasser'); assert.equal(s.fahrzeug.check.werte.marke, 'Bavaria');
  const eingabe = L.checkEingabe(s.fahrzeug.check, s.fahrzeug.bezeichnung, L.planPruefen(PLAN, GRENZE).werte);
  const b = MM.Reisecheck.anfrageBauen(eingabe);
  assert.ok(b.ok, JSON.stringify(b.fehler));
  assert.equal(b.anfrage.vehicle.type, 'Wasserfahrzeug'); assert.equal(b.anfrage.vehicle.manufacturer, 'Bavaria');
  assert.equal(b.anfrage.persons.length, 2); assert.equal(b.anfrage.persons[0].qualifications[0].type, 'Führerschein Klasse B');
  const text = JSON.stringify(b.anfrage);
  assert.ok(!text.includes('Anna') && !text.includes('Ben') && !text.includes('Gas prüfen') && !text.includes('Seeschwalbe'), 'keine Namen und keine Notiz in der Anfrage');
  assert.equal(L.checkEingabe(null, 'x', {}), null);
});

async function neu(optionen) {
  const o = optionen || {};
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => '2026-11-14T10:00:00.000Z' });
  await d.starten();
  const gesendet = [];
  d.rcGeraet = () => Promise.resolve({ kontoToken: o.ohneKonto ? '' : 'tok', kontoEmail: 'gast@example.org', kontoDienstUrl: 'https://konto.example.org',
    reisecheckZustimmungen: o.ohneZustimmung ? [] : [{ aktion: 'zugestimmt', version: MM.Reisecheck.ZUSTIMMUNG_VERSION, am: '2026-11-14T09:00:00.000Z' }] });
  d.kontoSenden = (m, weg, body) => {
    gesendet.push([m, weg, body]);
    if (o.fehler) return Promise.resolve({ ok: false, status: 402, fehler: 'Das Kontingent des Besitzers für Online-Checks ist aufgebraucht.' });
    return Promise.resolve({ ok: true, json: { antwort: ANTWORT, gespeichert: false, kontingent: null } });
  };
  return { d, gesendet };
}
const FZ = { bezeichnung: 'Mein Wohnmobil', check: { artName: 'Wohnmobil', welt: 'land', werte: { marke: 'Fiat', kennzeichen: 'LB-AB 123' } } };

test('Daten-Schicht: Plan wird nur innerhalb des Verleihs gespeichert, Tagebuch bleibt erhalten, nichts geht ins Fahrzeug', async () => {
  const { d, gesendet } = await neu();
  await d.leihreiseMerken('fr-1', { fahrzeug: 'Mein Wohnmobil', planAb: '2026-11-14', nutzungAb: '2026-11-20', bis: '2027-01-31' });
  assert.deepEqual(await d.leihreiseListe(), [], 'ohne Inhalt keine Zeile in der Liste');
  const falsch = await d.leihreisePlanSpeichern('fr-1', Object.assign({}, PLAN, { vonDatum: '2026-11-15' }));
  assert.equal(falsch.ok, false); assert.match(falsch.fehler.vonDatum, /vor dem Verleih/);
  assert.equal((await d.leihreiseLaden('fr-1')).plan, null);
  assert.ok((await d.leihreisePlanSpeichern('fr-1', PLAN)).ok);
  const a = await d.leihreiseTagebuchEintragen('fr-1', { datum: '2026-11-21', text: 'Angekommen' });
  const b = await d.leihreiseTagebuchEintragen('fr-1', { datum: '2026-11-22', text: 'Strand' });
  assert.ok(a.ok && b.ok);
  assert.equal((await d.leihreiseTagebuchEintragen('fr-1', { datum: '2026-11-22', text: '' })).ok, false);
  let rec = await d.leihreiseLaden('fr-1');
  assert.equal(rec.tagebuch.length, 2); assert.equal(rec.plan.name, 'Ostsee'); assert.equal(rec.fahrzeug, 'Mein Wohnmobil');
  await d.leihreiseTagebuchLoeschen('fr-1', a.id);
  rec = await d.leihreiseLaden('fr-1');
  assert.deepEqual(rec.tagebuch.map((x) => x.text), ['Strand']);
  const liste = await d.leihreiseListe();
  assert.equal(liste.length, 1); assert.equal(liste[0].planName, 'Ostsee'); assert.equal(liste[0].tagebuch, 1);
  assert.equal(gesendet.length, 0, 'Plan und Tagebuch gehen nie an den Dienst');
  /* eine zweite Freigabe ist getrennt */
  assert.equal((await d.leihreiseLaden('fr-2')).tagebuch.length, 0);
});

test('Daten-Schicht: Das Tagebuch kommt in die Sicherung, nicht in den Abgleich; es bleibt nach dem Ende der Freigabe', async () => {
  const { d } = await neu();
  await d.leihreiseMerken('fr-1', { fahrzeug: 'Mein Wohnmobil', nutzungAb: '2026-11-20', bis: '2027-01-31' });
  await d.leihreiseTagebuchEintragen('fr-1', { datum: '2026-11-21', text: 'Geheimes Tagebuch' });
  const dok = await d.speicher.holen('einstellungen', 'leihreisen');
  assert.ok(dok && dok.reisen['fr-1'].tagebuch.length === 1);
  const alle = await d.speicher.alleTabellen();
  assert.ok(JSON.stringify(alle.einstellungen).includes('Geheimes Tagebuch'), 'liegt in „einstellungen“');
  /* Die Sicherung nimmt „einstellungen“ mit und lässt nur das Dokument des Geräts weg */
  assert.ok(lesen('js/daten.js').includes("name === 'einstellungen' ? liste.filter(function (e) { return e.id !== GERAET_DOK; }) : liste"));
  assert.ok(!lesen('js/abgleich.js').includes("'einstellungen'"), 'einstellungen gehen nie in den Abgleich');
});

test('Reisecheck des Gastes: geht mit der Freigabe an den Dienst, speichert Ergebnis und Anfrage auf dem Gerät, hält höchstens zehn', async () => {
  const { d, gesendet } = await neu();
  await d.leihreiseMerken('fr-1', { fahrzeug: 'Mein Wohnmobil', nutzungAb: '2026-11-20', bis: '2027-01-31' });
  assert.match((await d.leihreiseCheck('fr-1', FZ)).fehler.allgemein, /Plane zuerst/);
  await d.leihreisePlanSpeichern('fr-1', PLAN);
  const r = await d.leihreiseCheck('fr-1', FZ);
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal(gesendet.length, 1); assert.equal(gesendet[0][1], '/check/senden');
  assert.equal(gesendet[0][2].freigabe, 'fr-1'); assert.equal(gesendet[0][2].art, 'reise'); assert.equal(gesendet[0][2].quelle, 'frisch');
  const roh = JSON.stringify(gesendet[0][2]);
  assert.ok(!roh.includes('Anna') && !roh.includes('LB-AB 123') && !roh.includes('Gas prüfen'), 'weder Namen noch Kennzeichen noch Notiz gehen hinaus');
  const l = await d.leihreiseCheckLaden('fr-1', r.id);
  assert.equal(l.auswertung.gesamt, 'ok'); assert.equal(l.check.namen.P1, 'Anna'); assert.equal(l.anforderungen.length, 1);
  assert.equal((await d.leihreiseCheckLaden('fr-1', 'gibt-es-nicht')), null);
  const rec = await d.leihreiseLaden('fr-1');
  assert.equal(await d.leihreiseStand(rec, FZ), rec.checks[0].stand, 'gleicher Plan, gleicher Stand');
  await d.leihreisePlanSpeichern('fr-1', Object.assign({}, PLAN, { gebiet: 'Norwegen' }));
  assert.notEqual(await d.leihreiseStand(await d.leihreiseLaden('fr-1'), FZ), rec.checks[0].stand, 'nach einer Änderung ist der Check veraltet');
  for (let i = 0; i < 12; i++) assert.ok((await d.leihreiseCheck('fr-1', FZ, { quelle: i === 0 ? 'gespeichert' : 'frisch' })).ok);
  assert.equal((await d.leihreiseLaden('fr-1')).checks.length, MM.Leihreise.MAX_CHECKS);
  assert.equal(gesendet[1][2].quelle, 'gespeichert');
});

test('Reisecheck des Gastes: ohne Konto, ohne Zustimmung oder bei aufgebrauchtem Kontingent des Besitzers gibt es eine einfache Meldung und nichts wird gespeichert', async () => {
  const k = await neu({ ohneKonto: true });
  await k.d.leihreisePlanSpeichern('fr-1', PLAN);
  const r1 = await k.d.leihreiseCheck('fr-1', FZ);
  assert.equal(r1.ok, false); assert.equal(r1.art, 'einrichtung'); assert.equal(k.gesendet.length, 0);
  const z = await neu({ ohneZustimmung: true });
  await z.d.leihreisePlanSpeichern('fr-1', PLAN);
  const r2 = await z.d.leihreiseCheck('fr-1', FZ);
  assert.equal(r2.ok, false); assert.equal(r2.art, 'zustimmung'); assert.equal(z.gesendet.length, 0);
  const f = await neu({ fehler: true });
  await f.d.leihreisePlanSpeichern('fr-1', PLAN);
  const r3 = await f.d.leihreiseCheck('fr-1', FZ);
  assert.equal(r3.ok, false); assert.equal(r3.art, 'kontingent'); assert.match(r3.fehler.allgemein, /Besitzers/);
  assert.equal((await f.d.leihreiseLaden('fr-1')).checks.length, 0);
});

test('Daten-Schicht: geteiltLaden meldet die Phase, die Einladung schickt „Planung ab“ mit', async () => {
  const { d, gesendet } = await neu();
  const sendeAntwort = (r) => { d.kontoSenden = (m, weg, body) => { gesendet.push([m, weg, body]); return Promise.resolve(r); }; };
  const satz = (tabelle, o) => ({ tabelle, id: o.id, nutzlast: JSON.stringify(o) });
  sendeAntwort({ ok: true, json: { phase: 'planung', nutzungAb: '2026-11-20', planAb: '2026-11-14', bis: '2027-01-31', rechte: 'mitnutzen', datensaetze: [satz('fahrzeuge', { id: 'fz-1', art: 'wohnmobil' })] } });
  const r = await d.geteiltLaden('fr-1');
  assert.ok(r.ok); assert.equal(r.phase, 'planung'); assert.equal(r.nutzungAb, '2026-11-20'); assert.equal(r.planAb, '2026-11-14'); assert.equal(r.rechte, 'mitnutzen');
  sendeAntwort({ ok: true, json: { bis: '2027-01-31', rechte: 'lesen', datensaetze: [satz('fahrzeuge', { id: 'fz-1', art: 'wohnmobil' })] } });
  assert.equal((await d.geteiltLaden('fr-1')).phase, 'nutzung', 'ein älterer Dienst kennt nur den Verleih');
  sendeAntwort({ ok: true, json: { id: 'fr-9', ab: '2026-11-20', bis: '2027-01-31', codeGesendet: true } });
  const e = await d.freigabeEinladen({ fahrzeugId: 'fz-1', email: 'kind@example.org', planAb: '2026-11-14', ab: '2026-11-20', bis: '2027-01-31', nachweisArt: 'Führerschein', bestaetigt: true });
  assert.ok(e.ok); assert.equal(gesendet[gesendet.length - 1][2].planAb, '2026-11-14');
});

test('Einbau: Modul in index.html und Service Worker, Route, Seiten und Version 2.0.78', () => {
  const index = lesen('index.html'), sw = lesen('sw.js'), ansicht = lesen('js/ansicht.js');
  assert.ok(index.includes('js/leihreise.js') && index.indexOf('js/freigaben.js') < index.indexOf('js/leihreise.js') && index.indexOf('js/leihreise.js') < index.indexOf('js/daten.js'));
  assert.ok(sw.includes("'js/leihreise.js'"));
  assert.equal(MM.VERSION, '2.0.78');
  ['seiteLeihreise', "teile[0] === 'leihreise'", 'Meine Reise: planen, prüfen, Tagebuch', 'Planung ab (freiwillig)', 'Meine Reisen mit geliehenen Fahrzeugen', 'Reisetagebuch', 'daten.leihreiseCheck(',
    "r.phase === 'planung'"].forEach((s) => assert.ok(ansicht.includes(s), s));
  assert.ok(!/geteiltErfassen\([^)]*leihreise/.test(ansicht), 'Meine Reise trägt nie im Fahrzeug ein');
  assert.ok(!lesen('js/leihreise.js').includes('kontoSenden'), 'die Regeln haben kein Netz');
  assert.match(MM.Texte.NEUERUNGEN[0].punkte.join(' '), /Planung vor dem Verleih/);
  assert.match(lesen('CHANGELOG.md'), /^# Änderungen\n\n## 2\.0\.78\n- \*\*Bau 3/);
});

/* ---- Die Seite „Meine Reise“ mit einem kleinen Ersatz für den Browser: nur so viel, wie sie braucht ---- */
function neuesElement(tag) {
  const e = { tag, kinder: [], attrs: {}, ereignisse: {}, value: '', disabled: false };
  e.appendChild = (k) => { e.kinder.push(k); return k; };
  e.setAttribute = (k, v) => { e.attrs[k] = v; };
  e.addEventListener = (n, f) => { e.ereignisse[n] = f; };
  Object.defineProperty(e, 'textContent', { get() { return e._t !== undefined ? e._t : e.kinder.map((k) => (typeof k === 'string' ? k : k.textContent)).join(''); }, set(v) { e._t = v; e.kinder = []; } });
  return e;
}
function hBauen() {
  return function h(tag, attrs) {
    const e = neuesElement(tag);
    if (attrs) Object.keys(attrs).forEach((k) => {
      const v = attrs[k];
      if (v === null || v === undefined || v === false) return;
      if (k === 'text') e.kinder.push(String(v)); else if (k.slice(0, 2) === 'on') e.ereignisse[k.slice(2)] = v; else if (k === 'value') e.value = v; else e.attrs[k] = v;
    });
    const rein = (k) => { if (k === null || k === undefined) return; if (Array.isArray(k)) k.forEach(rein); else e.kinder.push(k); };
    for (let i = 2; i < arguments.length; i++) rein(arguments[i]);
    return e;
  };
}
const text = (e) => (typeof e === 'string' ? e : (e && e.kinder ? (e._t !== undefined ? e._t : e.kinder.map(text).join('')) : ''));
const finde = (e, fn, aus) => { aus = aus || []; if (!e || typeof e === 'string' || !e.kinder) return aus; if (fn(e)) aus.push(e); e.kinder.forEach((k) => finde(k, fn, aus)); return aus; };
const warte = async () => { for (let i = 0; i < 10; i++) await new Promise((r) => setTimeout(r, 20)); };

function seiteBauen(d, optionen) {
  const quelle = lesen('js/ansicht.js');
  const start = quelle.indexOf('  function seiteLeihreise(id, checkId) {');
  const ende = quelle.indexOf('\n  }\n', start);
  assert.ok(start > 0 && ende > start);
  const h = hBauen();
  const eingabe = (id) => { const e = neuesElement('input'); e.id = id; return e; };
  const kontoFeld = (id, b, typ, wert) => { const e = eingabe(id); e.value = wert || ''; return { eingabe: e, tel: neuesElement('p'), feld: h('div', null, e) }; };
  const aus = { seiten: [], hash: '', ergebnisAufrufe: [] };
  const global = { location: { get hash() { return aus.hash; }, set hash(v) { aus.hash = v; } } };
  const quellText = quelle.slice(start, ende) + '\n  }\n  return seiteLeihreise;';
  // eslint-disable-next-line no-new-func
  const f = new Function('MM', 'h', 'krumen', 'kontoFeld', 'daten', 'global', 'fehlerSeite', 'rcErgebnis', 'rcChip', 'rcZeit', 'enc', 'seite', 'var meldungGeteilt = "";\n' + quellText);
  aus.seite = f(MM, h, () => h('nav'), kontoFeld, d, global, (e) => { throw e; }, (l, z) => { aus.ergebnisAufrufe.push(z); return [h('section', null, 'ERGEBNIS ' + l.check.id)]; },
    (g) => h('span', null, 'Chip ' + g), (iso) => String(iso), encodeURIComponent, (titel, teile) => { aus.seiten.push({ titel, teile }); });
  aus.letzte = () => aus.seiten[aus.seiten.length - 1];
  return aus;
}
const SICHT = (phase) => ({ ok: true, phase, nutzungAb: '2026-11-20', planAb: '2026-11-14', bis: '2027-01-31', rechte: 'mitnutzen', eigene: [], sicht: { fahrzeug: Object.assign({ bezeichnung: 'Mein Wohnmobil' }, { check: FZ.check }) } });

test('Seite Meine Reise: Plan speichern, Reisecheck starten und Ergebnis zeigen, Tagebuch führen, Löschen braucht zwei Tipper', async () => {
  const { d, gesendet } = await neu();
  d.geteiltLaden = () => Promise.resolve(SICHT('planung'));
  const s = seiteBauen(d);
  await s.seite('fr-1', null); await warte();
  let seite = s.letzte();
  let t = seite.teile.map(text).join('\n');
  assert.equal(seite.titel, 'Meine Reise: Mein Wohnmobil');
  assert.match(t, /Planung: Der Verleih beginnt am 20\.11\.2026/); assert.match(t, /Reise planen/); assert.match(t, /Reisecheck/); assert.match(t, /Reisetagebuch/);
  assert.match(t, /zählt zum Kontingent des Besitzers/); assert.match(t, /Plane zuerst deine Reise/);
  const knopf = (teile, beschriftung) => finde({ kinder: teile, tag: 'x', attrs: {} }, (e) => e.tag === 'button' && text(e) === beschriftung)[0];
  assert.ok(knopf(seite.teile, 'Jetzt online prüfen').disabled, 'ohne Plan ist der Check gesperrt');
  /* Plan mit einem Fehler: Meldung statt Speichern */
  const feld = (teile, id) => finde({ kinder: teile, tag: 'x', attrs: {} }, (e) => e.id === id || e.attrs.id === id)[0];
  feld(seite.teile, 'lr-name').value = 'Ostsee'; feld(seite.teile, 'lr-von').value = '2026-11-15'; feld(seite.teile, 'lr-bis').value = '2026-11-28';
  feld(seite.teile, 'lr-gebiet').value = 'Dänemark'; feld(seite.teile, 'lr-besatzung').value = 'Anna, Fahrer, Führerschein B';
  knopf(seite.teile, 'Reise speichern').ereignisse.click(); await warte();
  assert.equal((await d.leihreiseLaden('fr-1')).plan, null);
  /* richtig ausgefüllt */
  feld(seite.teile, 'lr-von').value = '2026-11-21';
  knopf(seite.teile, 'Reise speichern').ereignisse.click(); await warte();
  assert.equal((await d.leihreiseLaden('fr-1')).plan.name, 'Ostsee');
  seite = s.letzte(); t = seite.teile.map(text).join('\n');
  assert.match(t, /Deine Reise ist gespeichert/); assert.match(t, /Plan speichern/);
  /* Reisecheck */
  const los = knopf(seite.teile, 'Jetzt online prüfen');
  assert.ok(!los.disabled); los.ereignisse.click(); await warte();
  assert.equal(gesendet.filter((x) => x[1] === '/check/senden').length, 1);
  const rec = await d.leihreiseLaden('fr-1');
  assert.equal(s.hash, '#/leihreise/fr-1/check/' + encodeURIComponent(rec.checks[0].id));
  /* die Seite mit dem Check zeigt das Ergebnis, nicht veraltet */
  await s.seite('fr-1', rec.checks[0].id); await warte();
  seite = s.letzte(); t = seite.teile.map(text).join('\n');
  assert.match(t, new RegExp('ERGEBNIS ' + rec.checks[0].id)); assert.deepEqual(s.ergebnisAufrufe[s.ergebnisAufrufe.length - 1], { veraltet: false });
  assert.match(t, /Noch einmal online prüfen/);
  /* Tagebuch */
  feld(seite.teile, 'lt-datum').value = '2026-11-22'; feld(seite.teile, 'lt-text').value = 'Schöner Strand';
  knopf(seite.teile, 'Eintrag speichern').ereignisse.click(); await warte();
  seite = s.letzte(); t = seite.teile.map(text).join('\n');
  assert.match(t, /Schöner Strand/); assert.match(t, /Der Eintrag ist im Reisetagebuch/);
  const weg = knopf(seite.teile, 'Löschen');
  weg.ereignisse.click(); await warte();
  assert.equal((await d.leihreiseLaden('fr-1')).tagebuch.length, 1, 'ein Tipper löscht noch nichts');
  assert.equal(text(weg), 'Wirklich löschen?');
  weg.ereignisse.click(); await warte();
  assert.equal((await d.leihreiseLaden('fr-1')).tagebuch.length, 0);
});

test('Seite Meine Reise: Ist die Freigabe zu Ende oder kein Netz da, bleiben Plan, Checks und Tagebuch, Check und Planänderung gehen aber nicht', async () => {
  const { d, gesendet } = await neu();
  d.geteiltLaden = () => Promise.resolve(SICHT('nutzung'));
  let s = seiteBauen(d);
  await s.seite('fr-1', null); await warte();
  const knopfIn = (teile, b) => finde({ kinder: teile, tag: 'x', attrs: {} }, (e) => e.tag === 'button' && text(e) === b)[0];
  const feld = (teile, id) => finde({ kinder: teile, tag: 'x', attrs: {} }, (e) => e.id === id || e.attrs.id === id)[0];
  feld(s.letzte().teile, 'lr-name').value = 'Ostsee'; feld(s.letzte().teile, 'lr-von').value = '2026-11-21'; feld(s.letzte().teile, 'lr-bis').value = '2026-11-25';
  feld(s.letzte().teile, 'lr-gebiet').value = 'Dänemark'; feld(s.letzte().teile, 'lr-besatzung').value = 'Anna';
  knopfIn(s.letzte().teile, 'Reise speichern').ereignisse.click(); await warte();
  assert.match(text({ kinder: s.letzte().teile }), /Verleih: Seit 20\.11\.2026 gelten deine Rechte/);
  d.geteiltLaden = () => Promise.resolve({ ok: false, beendet: true, fehler: { allgemein: 'Diese Freigabe gilt nicht (mehr).' } });
  s = seiteBauen(d);
  await s.seite('fr-1', null); await warte();
  const t = s.letzte().teile.map(text).join('\n');
  assert.match(t, /Die Freigabe gilt nicht mehr/); assert.match(t, /Ostsee/.test(t) ? /Ostsee/ : /Meine Reise/);
  assert.equal(s.letzte().titel, 'Meine Reise: Mein Wohnmobil', 'der Fahrzeugname ist gemerkt');
  assert.ok(knopfIn(s.letzte().teile, 'Jetzt online prüfen').disabled);
  assert.match(t, /Reisechecks gehen nur mit gültiger Freigabe/);
  assert.ok(knopfIn(s.letzte().teile, 'Eintrag speichern'), 'das Tagebuch geht weiter');
  assert.equal(gesendet.length, 0);
});
