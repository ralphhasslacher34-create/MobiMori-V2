'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 3, 12, 0, t++)).toISOString() });
  await d.starten();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  return { d, boot, wm };
}
const pdf = (name, size) => ({ name: name || 'anleitung.pdf', type: 'application/pdf', size: size || 2048, bytes: new Uint8Array([1, 2, 3]) });

test('Links: nur http und https, ohne Angabe wird https ergänzt', () => {
  const n = MM.Dokumente.normalisiereLink;
  assert.equal(n('www.hersteller.de/anleitung.pdf'), 'https://www.hersteller.de/anleitung.pdf');
  assert.equal(n(' https://hersteller.de/a '), 'https://hersteller.de/a');
  assert.equal(n('http://hersteller.de'), 'http://hersteller.de/');
  assert.equal(n('javascript:alert(1)'), null);
  assert.equal(n('ftp://hersteller.de/a'), null);
  assert.equal(n('data:text/html,<b>x</b>'), null);
  assert.equal(n('anleitung'), null);
  assert.equal(n(''), null);
});

test('Datei als Dokument ablegen: Eintrag, Datei getrennt, Name aus dem Dateinamen', async () => {
  const { d, boot } = await neu();
  const r = await d.dokumentAnlegen(boot, null, { quelle: 'datei', datei: pdf('Heizung Bedienung.pdf', 5000), art: 'bedienung' });
  assert.ok(r.ok);
  const x = await d.dokumentLaden(r.id);
  assert.equal(x.aktuell.werte.bezeichnung, 'Heizung Bedienung');
  assert.equal(x.aktuell.werte.quelle, 'datei');
  assert.equal(x.aktuell.werte.dateiGroesse, 5000);
  assert.equal(x.aktuell.werte.link, null);
  assert.equal(x.datei.name, 'Heizung Bedienung.pdf');
  assert.equal(x.datei.groesse, 5000);
  assert.equal(x.datei.inhalt, undefined, 'Inhalt bleibt aus der Anzeige heraus');
  const voll = await d.dateiHolen(r.id);
  assert.deepEqual(Array.from(voll.inhalt.bytes), [1, 2, 3]);
});

test('Link als Dokument ablegen: keine Datei, Adresse wird bereinigt', async () => {
  const { d, boot } = await neu();
  const r = await d.dokumentAnlegen(boot, null, { quelle: 'link', link: 'www.volvopenta.de/d3.pdf', bezeichnung: 'D3 Ersatzteile', art: 'ersatzteile' });
  assert.ok(r.ok);
  const x = await d.dokumentLaden(r.id);
  assert.equal(x.aktuell.werte.link, 'https://www.volvopenta.de/d3.pdf');
  assert.equal(x.datei, null);
  assert.equal(await d.dateiHolen(r.id), null);
});

test('Pflichtangaben: Quelle, Datei, Link, Art, Bezeichnung', async () => {
  const { d, boot } = await neu();
  assert.ok((await d.dokumentAnlegen(boot, null, { art: 'bedienung', bezeichnung: 'X' })).fehler.quelle);
  assert.ok((await d.dokumentAnlegen(boot, null, { quelle: 'datei', art: 'bedienung' })).fehler.datei);
  assert.ok((await d.dokumentAnlegen(boot, null, { quelle: 'datei', datei: { name: 'leer.pdf', size: 0 }, art: 'bedienung' })).fehler.datei);
  assert.ok((await d.dokumentAnlegen(boot, null, { quelle: 'datei', datei: pdf() })).fehler.art);
  assert.ok((await d.dokumentAnlegen(boot, null, { quelle: 'link', bezeichnung: 'X', art: 'bedienung' })).fehler.link);
  assert.ok((await d.dokumentAnlegen(boot, null, { quelle: 'link', link: 'javascript:alert(1)', bezeichnung: 'X', art: 'bedienung' })).fehler.link);
  assert.ok((await d.dokumentAnlegen(boot, null, { quelle: 'link', link: 'https://a.de', art: 'bedienung' })).fehler.bezeichnung);
  assert.ok((await d.dokumentAnlegen(boot, null, { quelle: 'link', link: 'https://a.de', bezeichnung: 'X', art: 'unsinn' })).fehler.art);
  assert.equal((await d.dokumenteListe(boot)).length, 0);
});

test('Dokument gehört zum richtigen Fahrzeug und zur Komponente', async () => {
  const { d, boot, wm } = await neu();
  const m = await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor' });
  const ok = await d.dokumentAnlegen(boot, m.id, { quelle: 'link', link: 'https://a.de/x', bezeichnung: 'Motor-Anleitung', art: 'bedienung' });
  assert.ok(ok.ok);
  const falsch = await d.dokumentAnlegen(wm, m.id, { quelle: 'link', link: 'https://a.de/x', bezeichnung: 'X', art: 'bedienung' });
  assert.equal(falsch.ok, false);
  assert.equal((await d.dokumentAnlegen('gibt-es-nicht', null, { quelle: 'link', link: 'https://a.de', bezeichnung: 'X', art: 'bedienung' })).ok, false);
  assert.equal((await d.dokumentLaden(ok.id)).komponente.id, m.id);
});

test('Gesamtliste: Fahrzeug zuerst, dann Komponenten nach Name, dann nach Art', async () => {
  const { d, boot } = await neu();
  const mot = (await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor' })).id;
  const hei = (await d.komponenteAnlegen(boot, null, 'heizung', { bezeichnung: 'Heizung' })).id;
  const l = (k, titel, art) => d.dokumentAnlegen(boot, k, { quelle: 'link', link: 'https://a.de/' + titel, bezeichnung: titel, art });
  await l(mot, 'Motor Ersatzteile', 'ersatzteile'); await l(mot, 'Motor Bedienung', 'bedienung');
  await l(hei, 'Heizung Anleitung', 'bedienung'); await l(null, 'Kaufvertrag', 'beleg');
  const liste = await d.dokumenteListe(boot);
  assert.deepEqual(liste.map(x => x.aktuell.werte.bezeichnung), ['Kaufvertrag', 'Heizung Anleitung', 'Motor Bedienung', 'Motor Ersatzteile']);
  assert.deepEqual(liste.map(x => x.besitzer), [null, 'Heizung', 'Motor', 'Motor']);
});

test('Ändern = neuer Eintrag, Datei und Herkunft bleiben, Link wird geprüft', async () => {
  const { d, boot } = await neu();
  const r = await d.dokumentAnlegen(boot, null, { quelle: 'datei', datei: pdf('a.pdf', 100), art: 'bedienung', bezeichnung: 'Anleitung' });
  const c = await d.dokumentAendern(r.id, { bezeichnung: 'Anleitung Heizung', art: 'wartung', notiz: 'Seite 12' });
  assert.ok(c.ok && c.geaendert);
  const x = await d.dokumentLaden(r.id);
  assert.equal(x.verlauf.length, 2);
  assert.equal(x.aktuell.werte.bezeichnung, 'Anleitung Heizung');
  assert.equal(x.aktuell.werte.dateiName, 'a.pdf', 'Dateiangaben bleiben');
  assert.equal(x.aktuell.werte.quelle, 'datei');
  assert.equal(x.verlauf[1].eintrag.werte.art, 'bedienung', 'alter Stand bleibt');
  assert.deepEqual(x.verlauf[0].aenderungen.map(u => u.label).sort(), ['Art des Dokuments', 'Bezeichnung', 'Notiz'].sort());
  assert.equal((await d.dokumentAendern(r.id, { bezeichnung: 'Anleitung Heizung', art: 'wartung', notiz: 'Seite 12' })).geaendert, false);
  assert.equal((await d.dateiHolen(r.id)).name, 'a.pdf', 'Datei selbst wird nicht berührt');

  const l = await d.dokumentAnlegen(boot, null, { quelle: 'link', link: 'https://a.de/x', bezeichnung: 'Link', art: 'bedienung' });
  assert.ok((await d.dokumentAendern(l.id, { bezeichnung: 'Link', art: 'bedienung', link: 'ftp://a.de' })).fehler.link);
  assert.ok((await d.dokumentAendern(l.id, { bezeichnung: 'Link', art: 'bedienung', link: 'b.de/y' })).ok);
  assert.equal((await d.dokumentLaden(l.id)).aktuell.werte.link, 'https://b.de/y');
});

test('Belegung: Anzahl und Größe der Dateien auf dem Gerät', async () => {
  const { d, boot } = await neu();
  await d.dokumentAnlegen(boot, null, { quelle: 'datei', datei: pdf('a.pdf', 1000), art: 'bedienung' });
  await d.dokumentAnlegen(boot, null, { quelle: 'datei', datei: pdf('b.pdf', 2500), art: 'foto' });
  await d.dokumentAnlegen(boot, null, { quelle: 'link', link: 'https://a.de', bezeichnung: 'Link', art: 'bedienung' });
  assert.deepEqual(await d.dateienBelegung(), { anzahl: 2, bytes: 3500 });
});

test('Speicher voll: freundliche Meldung statt Absturz', async () => {
  const { d, boot } = await neu();
  d.speicher.mehrereSpeichern = () => Promise.reject(Object.assign(new Error('x'), { name: 'QuotaExceededError' }));
  const r = await d.dokumentAnlegen(boot, null, { quelle: 'datei', datei: pdf(), art: 'bedienung' });
  assert.equal(r.ok, false); assert.ok(r.fehler.datei.includes('Speicherplatz'));
});

test('Löschen aller Daten leert auch Dokumente und Dateien', async () => {
  const { d, boot } = await neu();
  await d.dokumentAnlegen(boot, null, { quelle: 'datei', datei: pdf(), art: 'bedienung' });
  await d.allesLoeschen();
  assert.equal((await d.speicher.alle('dokumente')).length, 0);
  assert.equal((await d.speicher.alle('dateien')).length, 0);
});

test('Anzeige der Dateigröße', () => {
  const g = MM.Hilfen.groesse;
  assert.equal(g(500), '500 Byte'); assert.equal(g(1536), '1,5 KB'); assert.equal(g(5 * 1024 * 1024), '5 MB');
  assert.equal(g(null) === '0 Byte' || g(null) === '', true);
});
