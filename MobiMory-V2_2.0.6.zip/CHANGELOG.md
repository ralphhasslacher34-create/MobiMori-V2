# Änderungen

## 2.0.6
- Dokumente an Fahrzeug und Komponente: Bedienungsanleitung, Ersatzteilliste, Wartungsanleitung, Kaufbeleg oder Rechnung, Garantie, Foto, Sonstiges.
- Ein Dokument ist eine Datei vom Gerät oder ein Link (nur http und https). Dateien liegen auf dem Gerät und sind auch ohne Internet da. Die Datei liegt in einer eigenen Ablage, getrennt vom Eintrag, damit später ein Server dazukommen kann.
- Am Fahrzeug eine Gesamtliste aller Dokumente, nach Komponente geordnet, mit Suche. Dateien lassen sich öffnen oder auf dem Gerät speichern, Fotos werden gezeigt.
- Angaben zu einem Dokument lassen sich ändern (neuer Eintrag „Korrektur zu …“). Die Datei selbst bleibt unverändert, für eine andere Datei wird ein neues Dokument angelegt.
- Ist der Speicher des Geräts voll, meldet die App das verständlich.
- Einstellungen zeigen, wie viel Speicher die Dokumente belegen und wie viel Platz der Browser erlaubt.
- Der Speicher auf dem Gerät wurde auf Datenbank-Version 4 umgestellt. Vorhandene Daten bleiben erhalten.
- Noch nicht dabei: Abgleich zwischen mehreren Geräten und „Offline verfügbar“ vom Server (kommt mit den Konten), Smart Capture.

## 2.0.5
- Fristen am Fahrzeug und an jeder Komponente. Eine Frist gilt nach Zeit (Monate oder Jahre), nach Zähler (Strecke oder Betriebsstunden) oder nach beidem. Was zuerst eintritt, löst die Fälligkeit aus.
- Zähler am Fahrzeug oder an einer einzelnen Komponente (zum Beispiel pro Motor). Der Zählerstand ist ein Verlauf von Handeinträgen, der neueste gilt. Stände steigen nur.
- Jede Frist zeigt „In Ordnung“, „Bald fällig“, „Überfällig“ oder „Angaben fehlen“. Die Fahrzeugliste zeigt überfällige und bald fällige Fristen.
- Wirkung bei Überfälligkeit (nur warnen, eingeschränkt, Sperre) und Vorwarnung (Tage, bei Zählern Strecke oder Stunden) sind einstellbar. Die Wirkung selbst greift erst bei Verleih und Aktivitäten, das folgt später.
- „Erledigt eintragen“ legt eine Erledigung an und setzt die Rechnung neu an. Ein höherer Zählerstand wird dabei auch im Zähler eingetragen. Frühere Erledigungen bleiben sichtbar.
- Änderungen an Fristen und Zählernamen sind wie bisher neue Einträge „Korrektur zu …“.
- Der Speicher auf dem Gerät wurde auf Datenbank-Version 3 umgestellt. Vorhandene Daten bleiben erhalten.
- Noch nicht dabei: Zähler per Start/Stopp-Schalter, Zählerstände aus Aktivitäten, Kosten der Erledigungen, Prüfung von Fristen bei Anfragen und im Reisecheck.

## 2.0.4
- Hauptkomponenten (Schale 3): Motor, Getriebe, Heizung, Klima, Stromversorgung, Wasserversorgung und Sonstiges.
- Beliebig tiefe Aufschlüsselung darunter. Es gibt nur eine Liste für alle Komponenten, jede „gehört zu“ einem Fahrzeug oder einer anderen Komponente.
- Zu jeder Komponente: Hersteller, Modell, Seriennummer, Baujahr, Eingebaut am, Einbauort, Ausgebaut am und technische Merkmale (Name und Wert).
- Änderungen sind wie beim Fahrzeug neue Einträge „Korrektur zu …“, nichts wird überschrieben oder gelöscht. Ausgebaute Teile stehen eingeklappt unter „Ausgebaut“.
- Der Speicher auf dem Gerät wurde auf Datenbank-Version 2 umgestellt. Vorhandene Fahrzeuge bleiben erhalten.
- Neuer Hinweis „Neue Version bereit“ mit Knopf zum Neuladen, damit eine hochgeladene neue Version nicht übersehen wird.
- Noch nicht dabei: Fristen, Kosten und Nachweise an den Komponenten, ein fester Merkmal-Katalog.

## 2.0.3
- Startseite neu gestaltet. Vor den drei Teilen des Kernsatzes stehen die Logo-Buchstaben V, T und D.
- Infotext nennt „Reisen planen“ statt „Reisen prüfen“.
- Das Logo ist eine einzige Datei (`icons/icon.svg`) und wird auf der Startseite, in der Kopfzeile und als App-Symbol verwendet. Das jetzige Zeichen ist ein Platzhalter.

## 2.0.2
- Startseite mit Logo, Kernsatz „Dein Fahrzeug. Dein Weg. Deine Daten.“, Copyright und den Knöpfen „Programm starten“ und „Neu im Programm“.
- Hauptmenü mit den Kacheln Stammdaten, Funktionen (kommt) und Einstellungen.
- Stammdaten mit Fahrzeugen. Personen und Tiere sind als „kommt“ vorgesehen.
- Seite „Neu im Programm“ mit der Liste der Änderungen (steht in `js/texte.js`).
- Einstellungen mit Datenhinweis, Versionsangabe und dem Testknopf zum Löschen.
- Die Fahrzeugliste ist jetzt unter Stammdaten erreichbar, der Rest aus 2.0.1 ist unverändert.
- Neue Prüfungen: Versionsnummer, Änderungsliste und Dateiliste für den Offline-Betrieb müssen zusammenpassen.

## 2.0.1 – Schritt 1
- Neu aufgebaut, nicht aus V1 geflickt.
- Fahrzeugliste mit Kennung (Schale 1) und äußere Hülle (Schale 2).
- Sieben feste Fahrzeugarten: Auto, Motorrad, Wohnmobil, Wohnwagen, Oldtimer, Boot, Flugzeug. Felder je nach Art, zum Beispiel Tiefgang nur beim Boot, Achsen nur an Land.
- Handeingabe mit Prüfung. Änderungen werden als neuer Eintrag „Korrektur zu …“ gespeichert, der alte Stand bleibt im Verlauf.
- Offline-fähig, Daten liegen lokal auf dem Gerät.
- Automatische Tests für die Daten-Schicht.
