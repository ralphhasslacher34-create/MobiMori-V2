/*
 * Dokumente: Bedienungsanleitungen, Ersatzteillisten und mehr.
 *
 * Ein Dokument gehört zu einem Fahrzeug oder zu einer Komponente, wie eine
 * Frist. Es ist entweder eine Datei vom Gerät oder ein Link ins Internet.
 *
 * Die Datei selbst liegt in einer eigenen Ablage ("dateien"), getrennt vom
 * Eintrag. So kann später ein Server dazukommen: Das Original liegt dann dort,
 * das Gerät behält nur eine Kopie von dem, was gebraucht wird.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var ARTEN = [
    { wert: 'bedienung', label: 'Bedienungsanleitung' },
    { wert: 'ersatzteile', label: 'Ersatzteilliste' },
    { wert: 'wartung', label: 'Wartungsanleitung' },
    { wert: 'beleg', label: 'Kaufbeleg oder Rechnung' },
    { wert: 'garantie', label: 'Garantie' },
    { wert: 'foto', label: 'Foto' },
    { wert: 'sonstiges', label: 'Sonstiges' }
  ];
  var QUELLEN = [
    { wert: 'datei', label: 'Datei vom Gerät' },
    { wert: 'link', label: 'Link im Internet' }
  ];

  /* Felder, die sich nachträglich ändern lassen. Die Datei selbst bleibt unverändert. */
  function felder(quelle) {
    var f = [{ key: 'art', label: 'Art des Dokuments', typ: 'auswahl', optionen: ARTEN, gruppe: 'dok' }];
    if (quelle === 'link') f.push({ key: 'link', label: 'Link', typ: 'text', gruppe: 'dok', hilfe: 'Zum Beispiel die Adresse der Anleitung beim Hersteller' });
    f.push({ key: 'notiz', label: 'Notiz', typ: 'text', gruppe: 'dok', hilfe: 'Zum Beispiel für welches Modell oder welche Seite wichtig ist' });
    return f.map(function (x) { var k = {}; for (var p in x) k[p] = x[p]; return k; });
  }

  function find(liste, wert) {
    for (var i = 0; i < liste.length; i++) { if (liste[i].wert === wert) return liste[i]; }
    return null;
  }
  function artLabel(wert) { var a = find(ARTEN, wert); return a ? a.label : ''; }
  function artIndex(wert) { for (var i = 0; i < ARTEN.length; i++) { if (ARTEN[i].wert === wert) return i; } return ARTEN.length; }

  /* Link prüfen: nur http und https, ohne Angabe wird https davorgesetzt. Gibt null zurück, wenn er nicht taugt. */
  function normalisiereLink(text) {
    var t = String(text == null ? '' : text).trim();
    if (!t) return null;
    if (!/^[a-z][a-z0-9+.-]*:/i.test(t)) t = 'https://' + t;
    var u;
    try { u = new URL(t); } catch (e) { return null; }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    if (u.hostname.indexOf('.') < 0 && u.hostname !== 'localhost') return null;
    return u.href;
  }

  MM.Dokumente = { ARTEN: ARTEN, QUELLEN: QUELLEN, felder: felder, artLabel: artLabel, artIndex: artIndex, normalisiereLink: normalisiereLink };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
