/*
 * Ansicht: was der Nutzer sieht.
 *
 * Seiten (Adresse hinter dem #):
 *   #/                         Startseite
 *   #/auswahl                  Hauptmenü (Stammdaten, Funktionen, Einstellungen)
 *   #/stammdaten               Stammdaten (Fahrzeuge, Personen, Tiere)
 *   #/fahrzeuge                Meine Fahrzeuge (Schale 1)
 *   #/neu-im-programm          Neu im Programm
 *   #/einstellungen            Einstellungen
 *   #/fahrzeug/<id>/komponente/neu   Hauptkomponente anlegen
 *   #/komponente/<id>          Komponente (Schale 3 und tiefer)
 *   #/komponente/<id>/neu      Teil darunter anlegen
 *   #/komponente/<id>/aendern  Komponente ändern
 *   #/frist/<id>               Frist (auch /erledigt und /aendern)
 *   #/zaehler/<id>             Zähler (auch /stand und /aendern)
 *   #/fahrzeug/<id>/frist/neu, /zaehler/neu und #/komponente/<id>/frist/neu, /zaehler/neu
 *   #/dokument/<id>            Dokument (auch /aendern)
 *   #/fahrzeug/<id>/dokumente  alle Dokumente eines Fahrzeugs
 *   #/fahrzeug/<id>/dokument/neu und #/komponente/<id>/dokument/neu
 *   #/neu                      Fahrzeug anlegen
 *   #/fahrzeug/<id>            Fahrzeug mit äußerer Hülle (Schale 2)
 *   #/fahrzeug/<id>/aendern    Angaben ändern
 *
 * Alle Texte kommen mit textContent in die Seite, nie als HTML.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  var doc = global.document;

  var daten = null;
  var wurzel = null;
  var meldung = null; /* wird einmal auf der nächsten Seite gezeigt */

  /* ---------- kleine Bauhelfer ---------- */
  function anhaengen(el, kind) {
    if (kind === null || kind === undefined || kind === false) return;
    if (Array.isArray(kind)) { kind.forEach(function (k) { anhaengen(el, k); }); return; }
    if (typeof kind === 'string' || typeof kind === 'number') { el.appendChild(doc.createTextNode(String(kind))); return; }
    el.appendChild(kind);
  }
  function h(tag, attrs) {
    var el = doc.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) return;
        if (k === 'text') el.textContent = v;
        else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
        else if (k === 'value') el.value = v;
        else el.setAttribute(k, v === true ? '' : v);
      });
    }
    for (var i = 2; i < arguments.length; i++) anhaengen(el, arguments[i]);
    return el;
  }

  function kopf() {
    return h('header', { class: 'kopf' },
      h('a', { href: '#/auswahl' }, h('img', { class: 'marke', src: 'icons/icon.svg', alt: '', width: '32', height: '32' }), 'MobiMory'),
      h('span', { class: 'version', text: 'Version ' + MM.VERSION }));
  }

  function fuss() {
    return h('footer', { class: 'fuss' }, h('p', { text: MM.Texte.COPYRIGHT }));
  }

  /* Wo-bin-ich-Zeile: Liste aus [Text, Adresse]; der letzte Eintrag hat keine Adresse. */
  function krumen(liste) {
    var nav = h('nav', { class: 'krumen', 'aria-label': 'Wo du bist' });
    liste.forEach(function (k, i) {
      if (i) nav.appendChild(doc.createTextNode(' › '));
      nav.appendChild(k[1] ? h('a', { href: k[1], text: k[0] }) : doc.createTextNode(k[0]));
    });
    return nav;
  }
  var WEG_FAHRZEUGE = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Fahrzeuge', '#/fahrzeuge']];

  function seite(titel, inhalt, leiste) {
    doc.title = titel + ' – MobiMory';
    wurzel.textContent = '';
    var main = h('main', { class: 'inhalt', id: 'inhalt' });
    if (meldung) { main.appendChild(h('p', { class: 'meldung', role: 'status', text: meldung })); meldung = null; }
    anhaengen(main, inhalt);
    wurzel.appendChild(kopf());
    wurzel.appendChild(main);
    wurzel.appendChild(fuss());
    if (leiste) wurzel.appendChild(leiste);
    var h1 = main.querySelector('h1');
    if (h1) { h1.setAttribute('tabindex', '-1'); h1.focus({ preventScroll: true }); }
    global.scrollTo(0, 0);
  }

  function schild(artId, kennung) {
    var a = MM.Fahrzeugarten.art(artId);
    if (!kennung) return h('span', { class: 'schild leer', text: 'ohne Kennung' });
    return h('span', { class: 'schild welt-' + a.welt, text: kennung });
  }
  function kennungVon(artId, werte) { return werte[MM.Fahrzeugarten.kennungFeld(artId)] || ''; }

  /* ---------- Seite: Meine Fahrzeuge ---------- */
  function seiteListe() {
    return Promise.all([daten.fahrzeugListe(), daten.fristenUebersicht()]).then(function (res) {
      var liste = res[0], uebersicht = res[1];
      var inhalt = [krumen(WEG_FAHRZEUGE.slice(0, 2).concat([['Fahrzeuge']])), h('h1', { text: 'Meine Fahrzeuge' })];
      if (!liste.length) {
        inhalt.push(h('div', { class: 'leer-hinweis' },
          h('p', { text: 'Hier ist noch kein Fahrzeug.' }),
          h('p', { text: 'Lege dein erstes Fahrzeug an. Es genügt zuerst die Bezeichnung und die Fahrzeugart. Alles andere kannst du jederzeit nachtragen.' })));
      } else {
        inhalt.push(h('ul', { class: 'liste' }, liste.map(function (x) {
          var a = MM.Fahrzeugarten.art(x.fahrzeug.art);
          return h('li', null, h('a', { class: 'zeile welt-' + a.welt, href: '#/fahrzeug/' + encodeURIComponent(x.fahrzeug.id) },
            h('span', { class: 'zeile-text' },
              h('strong', { class: 'zeile-name', text: x.aktuell.werte.bezeichnung }),
              h('span', { class: 'zeile-art', text: a.name }),
              fristHinweis(uebersicht[x.fahrzeug.id])),
            schild(a.id, kennungVon(a.id, x.aktuell.werte))));
        })));
      }
      seite('Meine Fahrzeuge', inhalt,
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
          h('a', { class: 'knopf', href: '#/neu', text: 'Fahrzeug anlegen' })));
    });
  }

  /* ---------- Fristen und Zähler: gemeinsame Bausteine ---------- */
  var STATUS_TEXT = { ueberfaellig: 'Überfällig', bald: 'Bald fällig', ok: 'In Ordnung', unbekannt: 'Angaben fehlen' };

  function zahlMit(n, einheit) { return MM.Hilfen.zahl(n) + (einheit ? ' ' + einheit : ''); }
  function tageText(n) { return n + (n === 1 ? ' Tag' : ' Tage'); }
  function tageDativ(n) { return n + (n === 1 ? ' Tag' : ' Tagen'); }

  function fristHinweis(u) {
    if (!u) return null;
    if (u.ueberfaellig) return h('span', { class: 'hinweis-frist status-ueberfaellig', text: u.ueberfaellig === 1 ? '1 Frist überfällig' : u.ueberfaellig + ' Fristen überfällig' });
    if (u.bald) return h('span', { class: 'hinweis-frist status-bald', text: u.bald === 1 ? '1 Frist bald fällig' : u.bald + ' Fristen bald fällig' });
    return null;
  }

  /* Die Zeilen "Zeit: ..." und "Zähler: ..." einer gerechneten Frist. */
  function fristZeilen(st, einheit) {
    var z = [];
    if (st.kalender) {
      var k = st.kalender, d = MM.Hilfen.datum(k.faelligAm);
      if (k.tage < 0) z.push({ status: k.status, text: 'Zeit: seit ' + tageDativ(-k.tage) + ' überfällig (war am ' + d + ')' });
      else if (k.tage === 0) z.push({ status: k.status, text: 'Zeit: heute fällig' });
      else z.push({ status: k.status, text: 'Zeit: fällig am ' + d + ' (in ' + tageDativ(k.tage) + ')' });
    }
    if (st.zaehler) {
      var q = st.zaehler;
      if (q.status === 'unbekannt') z.push({ status: 'unbekannt', text: 'Zähler: ' + q.grund });
      else if (q.rest < 0) z.push({ status: q.status, text: 'Zähler: um ' + zahlMit(-q.rest, einheit) + ' überschritten (fällig war bei ' + zahlMit(q.faelligBei, einheit) + ')' });
      else z.push({ status: q.status, text: 'Zähler: fällig bei ' + zahlMit(q.faelligBei, einheit) + ', noch ' + zahlMit(q.rest, einheit) });
    }
    if (!z.length && st.grund) z.push({ status: 'unbekannt', text: st.grund });
    return z;
  }

  function fristZeile(x, besitzer) {
    var st = x.status, einheit = x.zaehler ? x.zaehler.einheit : '';
    var zeilen = fristZeilen(st, einheit).sort(function (a, b) { return MM.Fristen.rang(b.status) - MM.Fristen.rang(a.status); });
    return h('li', null, h('a', { class: 'frist status-' + st.status, href: '#/frist/' + encodeURIComponent(x.frist.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: x.aktuell.werte.bezeichnung }),
        zeilen.length ? h('span', { class: 'frist-info', text: zeilen[0].text }) : null,
        besitzer ? h('span', { class: 'frist-info', text: 'an: ' + besitzer }) : null),
      h('span', { class: 'chip-status status-' + st.status, text: STATUS_TEXT[st.status] })));
  }

  /* Fristen eines Fahrzeugs oder einer Komponente. neuHash zum Beispiel '#/fahrzeug/<id>'. */
  function fristenBereich(fristen, neuHash, besitzerVon) {
    return h('section', { class: 'bereich', 'aria-label': 'Fristen' },
      h('h2', { text: 'Fristen' }),
      fristen.length ? h('ul', { class: 'fristen' }, fristen.map(function (x) { return fristZeile(x, besitzerVon ? besitzerVon(x) : null); }))
        : h('p', { class: 'leer-text', text: 'Noch keine Frist. Zum Beispiel Ölwechsel, Feuerlöscher oder Hauptuntersuchung.' }),
      h('a', { class: 'knopf leise', href: neuHash + '/frist/neu', text: 'Frist hinzufügen' }));
  }

  function zaehlerBereich(zaehler, neuHash, mitBesitzer) {
    return h('section', { class: 'bereich', 'aria-label': 'Zähler' },
      h('h2', { text: 'Zähler' }),
      zaehler.length ? h('ul', { class: 'fristen' }, zaehler.map(function (z) {
        return h('li', null, h('a', { class: 'frist zaehler-zeile', href: '#/zaehler/' + encodeURIComponent(z.zaehler.id) },
          h('span', { class: 'frist-text' },
            h('strong', { class: 'frist-name', text: z.bezeichnung }),
            mitBesitzer && z.komponenteId ? h('span', { class: 'frist-info', text: 'an: ' + z.besitzer }) : null),
          h('span', { class: 'zaehler-stand', text: z.stand ? zahlMit(z.stand.wert, z.einheit) : 'noch kein Stand' })));
      })) : h('p', { class: 'leer-text', text: 'Noch kein Zähler. Ein Zähler zählt Strecke (km) oder Betriebsstunden (h), zum Beispiel pro Motor.' }),
      h('a', { class: 'knopf leise', href: neuHash + '/zaehler/neu', text: 'Zähler hinzufügen' }));
  }


  /* ---------- Verlauf (gleich für Fahrzeuge und Komponenten) ---------- */
  function verlaufBlock(verlauf) {
    return h('details', { class: 'verlauf' },
      h('summary', { text: 'Verlauf der Eintragungen (' + verlauf.length + ')' }),
      h('ol', null, verlauf.map(function (v, i) {
        var e = v.eintrag;
        var kopfzeile = h('div', null,
          h('span', { class: 'wann', text: MM.Hilfen.zeitpunkt(e.erstelltAm) }),
          i === 0 ? h('span', { class: 'marke-aktuell', text: 'aktuell' }) : null);
        var text;
        if (!v.vorher) text = h('div', { text: 'Angelegt, per Handeingabe' });
        else text = h('div', null,
          h('span', { class: 'korrektur', text: 'Korrektur zu Eintrag vom ' + MM.Hilfen.zeitpunkt(v.vorher.erstelltAm) }),
          h('ul', null, v.aenderungen.map(function (u) {
            var alt = MM.Hilfen.wert(u.feld, u.alt), neu = MM.Hilfen.wert(u.feld, u.neu);
            return h('li', null, u.label + ': ',
              h('span', { class: 'alt', text: alt === null ? 'nicht angegeben' : alt }), ' → ',
              neu === null ? 'nicht angegeben' : neu);
          })));
        return h('li', { class: i === 0 ? 'aktuell' : null }, kopfzeile, text);
      })));
  }

  /* ---------- Liste von Komponenten (Hauptkomponenten oder Teile) ---------- */
  function komponentenKarte(x, anzahlKinder) {
    var w = x.aktuell.werte;
    var art = x.komponente.parentId ? null : MM.Komponenten.art(x.komponente.art);
    var zeile2 = [art ? art.name : null, [w.hersteller, w.modell].filter(Boolean).join(' ')].filter(Boolean).join(', ');
    return h('li', null, h('a', { class: 'teil', href: '#/komponente/' + encodeURIComponent(x.komponente.id) },
      h('span', { class: 'teil-text' },
        h('strong', { class: 'teil-name', text: w.bezeichnung }),
        zeile2 ? h('span', { class: 'teil-info', text: zeile2 }) : null),
      anzahlKinder ? h('span', { class: 'teil-zahl', text: anzahlKinder === 1 ? '1 Teil darunter' : anzahlKinder + ' Teile darunter' }) : null));
  }

  /* Eingebaute zuerst, ausgebaute eingeklappt darunter. */
  function komponentenListeBlock(eintraege, anzahlVon) {
    var drin = eintraege.filter(function (x) { return !x.aktuell.werte.ausgebautAm; });
    var raus = eintraege.filter(function (x) { return x.aktuell.werte.ausgebautAm; });
    return [
      drin.length ? h('ul', { class: 'teile' }, drin.map(function (x) { return komponentenKarte(x, anzahlVon(x)); })) : null,
      raus.length ? h('details', { class: 'ausgebaut' },
        h('summary', { text: 'Ausgebaut (' + raus.length + ')' }),
        h('ul', { class: 'teile' }, raus.map(function (x) { return komponentenKarte(x, anzahlVon(x)); }))) : null
    ];
  }

  /* ---------- Seite: Fahrzeug mit Schalen ---------- */
  function komponentenName(komp, id) {
    var k = komp.filter(function (x) { return x.komponente.id === id; })[0];
    return k ? k.aktuell.werte.bezeichnung : 'Komponente';
  }

  function seiteFahrzeug(id) {
    return Promise.all([daten.fahrzeugLaden(id), daten.komponentenListe(id), daten.fristenListe(id), daten.zaehlerListe(id), daten.dokumenteListe(id)]).then(function (r) {
      var f = r[0], komp = r[1], fristen = r[2], zaehler = r[3], dokumente = r[4];
      if (!f) { return seite('Nicht gefunden', [h('h1', { text: 'Fahrzeug nicht gefunden' }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]); }
      var a = MM.Fahrzeugarten.art(f.fahrzeug.art);
      var w = f.aktuell.werte;

      var gruppen = MM.Fahrzeugarten.gruppen(a.id).map(function (g) {
        var gefuellt = [], offen = [];
        g.felder.forEach(function (fe) {
          var t = MM.Hilfen.wert(fe, w[fe.key]);
          if (t === null) offen.push(fe.label); else gefuellt.push([h('dt', { text: fe.label }), h('dd', { text: t })]);
        });
        return h('section', { class: 'gruppe' },
          h('h3', { text: g.titel }),
          gefuellt.length ? h('dl', { class: 'daten' }, gefuellt) : null,
          offen.length ? h('p', { class: 'offen', text: 'Noch nicht angegeben: ' + offen.join(', ') }) : null);
      });

      var haupt = daten.sortiereKomponenten(komp.filter(function (x) { return !x.komponente.parentId; }));
      function kinderVon(x) { return komp.filter(function (y) { return y.komponente.parentId === x.komponente.id; }).length; }
      var s3 = h('section', { class: 'schale s3 live', 'aria-label': 'Hauptkomponenten' },
        h('div', { class: 'schale-name', text: 'Dritte Schale' }),
        h('h2', { text: 'Hauptkomponenten' }),
        haupt.length ? komponentenListeBlock(haupt, kinderVon)
          : h('p', { class: 'leer-text', text: 'Noch keine Hauptkomponente. Lege zum Beispiel Motor, Getriebe oder Heizung an. Darunter lässt sich beliebig tief aufschlüsseln.' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(id) + '/komponente/neu', text: 'Hauptkomponente hinzufügen' }));

      var s2 = h('section', { class: 'schale s2', 'aria-label': 'Äußere Hülle' },
        h('div', { class: 'schale-kopf' },
          h('div', { class: 'schale-name', text: 'Zweite Schale' }),
          h('h2', { text: 'Äußere Hülle' })),
        gruppen,
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(f.aktuell.erstelltAm) + ', per Handeingabe' }),
        s3);

      var s1 = h('div', { class: 'schale s1' },
        h('div', { class: 'schale-kopf' },
          h('div', { class: 'schale-name', text: 'Erste Schale: ' + a.name }),
          h('div', { class: 'fahrzeug-kopf' },
            h('h1', { text: w.bezeichnung }),
            schild(a.id, kennungVon(a.id, w)))),
        s2);

      var verlauf = verlaufBlock(f.verlauf);

      /* Überfällige oder bald fällige Fristen stehen ganz oben, damit man sie nicht übersieht. */
      var dringend = fristen.some(function (x) { return MM.Fristen.rang(x.status.status) >= MM.Fristen.rang('bald'); });
      var fristBlock = fristenBereich(fristen, '#/fahrzeug/' + encodeURIComponent(id), function (x) { return x.frist.komponenteId ? komponentenName(komp, x.frist.komponenteId) : null; });
      fristBlock.className += ' oben';

      seite(w.bezeichnung, [
        krumen(WEG_FAHRZEUGE.concat([[w.bezeichnung]])),
        dringend ? fristBlock : null,
        s1,
        dringend ? null : fristBlock,
        zaehlerBereich(zaehler, '#/fahrzeug/' + encodeURIComponent(id), true),
        dokumenteBereich(dokumente.filter(function (x) { return !x.komponenteId; }), '#/fahrzeug/' + encodeURIComponent(id),
          { anzahl: dokumente.length, href: '#/fahrzeug/' + encodeURIComponent(id) + '/dokumente' }),
        verlauf
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/fahrzeuge', text: 'Zur Liste' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
    });
  }

  /* ---------- Seite: anlegen / ändern ---------- */
  function optWert(o) { return typeof o === 'string' ? o : o.wert; }
  function optLabel(o) { return typeof o === 'string' ? o : o.label; }

  function feldElement(f, wert, fehler, aenderung) {
    var id = 'f-' + f.key;
    var eingabe;
    if (f.typ === 'auswahl' && f.darstellung === 'wahl') {
      return h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
        h('legend', { class: 'fest-art', text: f.label }),
        f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
        fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null,
        h('div', { class: 'artwahl' }, f.optionen.map(function (o) {
          var r = h('input', { type: 'radio', name: f.key, value: optWert(o), onchange: aenderung });
          if (wert === optWert(o)) r.checked = true;
          return h('label', null, r, h('span', { text: optLabel(o) }));
        })));
    }
    if (f.typ === 'datei') {
      return h('div', { class: 'feld' + (fehler ? ' hat-fehler' : '') },
        h('label', { for: id, text: f.label }),
        f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
        h('div', { class: 'eingabe' }, h('input', { id: id, name: f.key, type: 'file', accept: f.accept || null, onchange: aenderung })),
        wert && wert.name ? h('p', { class: 'gewaehlt', text: 'Gewählt: ' + wert.name + (wert.size ? ' (' + MM.Hilfen.groesse(wert.size) + ')' : '') }) : null,
        fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null);
    }
    if (f.typ === 'auswahl') {
      eingabe = h('select', { id: id, name: f.key, onchange: aenderung },
        h('option', { value: '', text: f.leerText || '– bitte wählen –' }),
        f.optionen.map(function (o) { return h('option', { value: optWert(o), text: optLabel(o) }); }));
      eingabe.value = wert || '';
    } else if (f.typ === 'datum') {
      eingabe = h('input', { id: id, name: f.key, type: 'date', value: wert || '', oninput: aenderung });
    } else {
      eingabe = h('input', { id: id, name: f.key, type: 'text', autocomplete: 'off', autocapitalize: f.typ === 'text' ? 'sentences' : 'off',
        inputmode: f.typ === 'zahl' ? 'decimal' : (f.typ === 'ganzzahl' ? 'numeric' : null),
        value: wert === null || wert === undefined ? '' : String(wert).replace('.', f.typ === 'zahl' ? ',' : '.'),
        'aria-describedby': f.hilfe ? id + '-h' : null, 'aria-invalid': fehler ? 'true' : null, oninput: aenderung });
    }
    return h('div', { class: 'feld' + (fehler ? ' hat-fehler' : '') },
      h('label', { for: id, text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', id: id + '-h', text: f.hilfe }) : null,
      h('div', { class: 'eingabe' }, eingabe, f.einheit ? h('span', { class: 'einheit', text: f.einheit }) : null),
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null);
  }

  function seiteFormular(modus, fahrzeugId) {
    var laden = modus === 'aendern' ? daten.fahrzeugLaden(fahrzeugId) : Promise.resolve(null);
    return laden.then(function (vorhanden) {
      if (modus === 'aendern' && !vorhanden) return seiteFahrzeug(fahrzeugId);
      var zustand = {
        art: vorhanden ? vorhanden.fahrzeug.art : null,
        werte: vorhanden ? Object.assign({}, vorhanden.aktuell.werte) : {},
        fehler: {}
      };
      var titel = modus === 'aendern' ? 'Angaben ändern' : 'Fahrzeug anlegen';
      var behaelter = h('div');

      function lesen() {
        /* Eingaben aus dem Formular in den Zustand übernehmen */
        var felder = behaelter.querySelectorAll('input[name], select[name]');
        Array.prototype.forEach.call(felder, function (el) {
          if (el.type === 'radio') return;
          zustand.werte[el.name] = el.value;
        });
      }

      function speichern(ev) {
        ev.preventDefault();
        lesen();
        var p = modus === 'aendern'
          ? daten.fahrzeugAendern(fahrzeugId, zustand.werte)
          : daten.fahrzeugAnlegen(zustand.art, zustand.werte);
        p.then(function (r) {
          if (!r.ok) {
            zustand.fehler = r.fehler;
            zeichne();
            var ersterFehler = behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten');
            if (ersterFehler) { ersterFehler.focus ? ersterFehler.focus() : null; }
            return;
          }
          meldung = modus === 'aendern'
            ? (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.')
            : 'Fahrzeug angelegt.';
          global.location.hash = '#/fahrzeug/' + encodeURIComponent(r.id);
        }).catch(fehlerSeite);
      }

      function zeichne() {
        behaelter.textContent = '';
        var teile = [];
        if (modus === 'neu' && !zustand.art) {
          teile.push(h('p', { text: 'Wähle zuerst die Fahrzeugart. Dann erscheinen die passenden Felder. Nur die Bezeichnung ist Pflicht.' }));
        }
        var fk = Object.keys(zustand.fehler);
        if (fk.length) {
          teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
            text: fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.' }));
        }

        /* Fahrzeugart: beim Anlegen wählbar, danach fest */
        if (modus === 'neu') {
          teile.push(h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
            h('legend', { class: 'fest-art', text: 'Fahrzeugart' }),
            zustand.fehler.art ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.art }) : null,
            h('div', { class: 'artwahl' }, MM.Fahrzeugarten.alle().map(function (a) {
              var r = h('input', { type: 'radio', name: 'art', value: a.id, onchange: function () {
                lesen(); zustand.art = a.id; zustand.fehler = {}; zeichne();
                var b = behaelter.querySelector('#f-bezeichnung'); if (b) b.focus({ preventScroll: true });
              } });
              if (zustand.art === a.id) r.checked = true;
              return h('label', { class: 'welt-' + a.welt }, r, h('span', { text: a.name }));
            }))));
        } else {
          teile.push(h('p', null, 'Fahrzeugart: ', h('span', { class: 'fest-art', text: MM.Fahrzeugarten.art(zustand.art).name }),
            h('span', { class: 'hilfe', text: ' (lässt sich nicht ändern)' })));
        }

        if (zustand.art) {
          teile.push(feldElement({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Wie du das Fahrzeug nennst, zum Beispiel „Fahrzeug A“' },
            zustand.werte.bezeichnung, zustand.fehler.bezeichnung));
          MM.Fahrzeugarten.gruppen(zustand.art).forEach(function (g) {
            teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
              h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }),
              g.felder.map(function (f) { return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key]); })));
          });
        }
        anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
      }

      zeichne();
      seite(titel, [
        krumen(WEG_FAHRZEUGE.concat([[titel]])),
        h('h1', { text: titel }),
        behaelter
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: modus === 'aendern' ? '#/fahrzeug/' + encodeURIComponent(fahrzeugId) : '#/fahrzeuge', text: 'Abbrechen' }),
        h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
    });
  }

  /* ---------- Seite: Komponente (Schale 3 und tiefer) ---------- */
  function komponentenKrumen(c, mitSelbst) {
    var liste = WEG_FAHRZEUGE.slice(0, 3);
    liste.push([c.fahrzeugAktuell.werte.bezeichnung, '#/fahrzeug/' + encodeURIComponent(c.fahrzeug.id)]);
    c.weg.forEach(function (x) { liste.push([x.aktuell.werte.bezeichnung, '#/komponente/' + encodeURIComponent(x.komponente.id)]); });
    if (mitSelbst) liste.push([c.aktuell.werte.bezeichnung]);
    return liste;
  }
  function adresseUeber(c) {
    var eltern = c.weg.length ? c.weg[c.weg.length - 1] : null;
    return eltern ? '#/komponente/' + encodeURIComponent(eltern.komponente.id) : '#/fahrzeug/' + encodeURIComponent(c.fahrzeug.id);
  }

  function seiteKomponente(id) {
    return daten.komponenteLaden(id).then(function (c) {
      if (!c) {
        return seite('Nicht gefunden', [h('h1', { text: 'Komponente nicht gefunden' }),
          h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
      }
      return Promise.all([daten.fristenListe(c.fahrzeug.id), daten.zaehlerListe(c.fahrzeug.id), daten.dokumenteListe(c.fahrzeug.id)]).then(function (r) {
        return zeigeKomponente(id, c, r[0], r[1], r[2]);
      });
    });
  }

  function zeigeKomponente(id, c, alleFristen, alleZaehler, alleDokumente) {
      var w = c.aktuell.werte;
      var meineFristen = alleFristen.filter(function (x) { return x.frist.komponenteId === id; });
      var meineZaehler = alleZaehler.filter(function (z) { return z.komponenteId === id; });
      var meineDokumente = alleDokumente.filter(function (x) { return x.komponenteId === id; });
      var art = c.komponente.parentId ? null : MM.Komponenten.art(c.komponente.art);
      var eltern = c.weg.length ? c.weg[c.weg.length - 1].aktuell.werte.bezeichnung : c.fahrzeugAktuell.werte.bezeichnung;

      var gruppen = MM.Komponenten.gruppen().map(function (g) {
        var gefuellt = [], offen = [];
        g.felder.forEach(function (fe) {
          var t = MM.Hilfen.wert(fe, w[fe.key]);
          if (t === null) { offen.push(fe.label); return; }
          if (fe.typ === 'liste') {
            w[fe.key].forEach(function (z) { gefuellt.push([h('dt', { text: z.name }), h('dd', { text: z.wert })]); });
          } else gefuellt.push([h('dt', { text: fe.label }), h('dd', { text: t })]);
        });
        return h('section', { class: 'gruppe' },
          h('h3', { text: g.titel }),
          gefuellt.length ? h('dl', { class: 'daten' }, gefuellt) : null,
          offen.length ? h('p', { class: 'offen', text: 'Noch nicht angegeben: ' + offen.join(', ') }) : null);
      });

      var teile = h('section', { class: 'teile-block' },
        h('h2', { text: 'Teile darunter' }),
        c.kinder.length ? komponentenListeBlock(c.kinder, function (x) { return x.anzahlKinder; })
          : h('p', { class: 'leer-text', text: 'Noch kein Teil darunter. Du kannst beliebig tief weiter aufschlüsseln.' }),
        h('a', { class: 'knopf', href: '#/komponente/' + encodeURIComponent(id) + '/neu', text: 'Teil hinzufügen' }));

      var spaeter = h('section', { class: 'schale s3', 'aria-label': 'Folgt' },
        h('p', { text: 'Kosten und Nachweise zu diesem Teil folgen in späteren Schritten.' }));

      var karte = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Schale ' + c.tiefe + (art ? ': ' + art.name : ': Teil') }),
        h('h1', { text: w.bezeichnung }),
        h('p', { class: 'gehoert', text: 'gehört zu: ' + eltern }),
        w.ausgebautAm ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Ausgebaut am ' + MM.Hilfen.datum(w.ausgebautAm) + '. Dieses Teil ist nicht mehr im Fahrzeug.' }) : null,
        gruppen,
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(c.aktuell.erstelltAm) + ', per Handeingabe' }),
        teile,
        fristenBereich(meineFristen, '#/komponente/' + encodeURIComponent(id), null),
        zaehlerBereich(meineZaehler, '#/komponente/' + encodeURIComponent(id), false),
        dokumenteBereich(meineDokumente, '#/komponente/' + encodeURIComponent(id), null),
        spaeter);

      seite(w.bezeichnung, [krumen(komponentenKrumen(c, true)), karte, verlaufBlock(c.verlauf)],
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: adresseUeber(c), text: 'Zurück' }),
          h('a', { class: 'knopf', href: '#/komponente/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
  }

  /* ---------- Seite: Komponente anlegen / ändern ---------- */
  function merkmaleElement(f, zeilen, fehler, hinzu, weg) {
    return h('fieldset', { class: 'feld liste' + (fehler ? ' hat-fehler' : '') },
      h('legend', { class: 'feld-label', text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
      h('div', { class: 'merkmale' }, zeilen.map(function (z, i) {
        return h('div', { class: 'merkmal-zeile' },
          h('input', { class: 'merkmal-name', type: 'text', autocomplete: 'off', placeholder: 'Merkmal', 'aria-label': 'Merkmal ' + (i + 1), value: z.name }),
          h('input', { class: 'merkmal-wert', type: 'text', autocomplete: 'off', placeholder: 'Wert', 'aria-label': 'Wert ' + (i + 1), value: z.wert }),
          h('button', { type: 'button', class: 'knopf leise klein', text: 'Entfernen', onclick: function () { weg(i); } }));
      })),
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null,
      h('button', { type: 'button', class: 'knopf leise', text: 'Merkmal hinzufügen', onclick: hinzu }));
  }

  /* modus: 'neu-haupt' (id = Fahrzeug), 'neu-teil' (id = übergeordnete Komponente), 'aendern' (id = Komponente) */
  function seiteKomponentenFormular(modus, id) {
    var laden;
    if (modus === 'neu-haupt') laden = daten.fahrzeugLaden(id).then(function (f) { return f ? { fz: f, c: null } : null; });
    else laden = daten.komponenteLaden(id).then(function (c) { return c ? { fz: null, c: c } : null; });

    return laden.then(function (k) {
      if (!k) return seite('Nicht gefunden', [h('h1', { text: 'Nicht gefunden' }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
      var c = k.c;
      var fahrzeugId = k.fz ? k.fz.fahrzeug.id : c.fahrzeug.id;
      var titel = modus === 'neu-haupt' ? 'Hauptkomponente hinzufügen' : (modus === 'neu-teil' ? 'Teil hinzufügen' : 'Angaben ändern');

      var zurueck, weg;
      if (modus === 'neu-haupt') {
        zurueck = '#/fahrzeug/' + encodeURIComponent(fahrzeugId);
        weg = WEG_FAHRZEUGE.slice(0, 3).concat([[k.fz.aktuell.werte.bezeichnung, zurueck], [titel]]);
      } else if (modus === 'neu-teil') {
        zurueck = '#/komponente/' + encodeURIComponent(id);
        weg = komponentenKrumen(c, false).concat([[c.aktuell.werte.bezeichnung, zurueck], [titel]]);
      } else {
        zurueck = '#/komponente/' + encodeURIComponent(id);
        weg = komponentenKrumen(c, false).concat([[c.aktuell.werte.bezeichnung, zurueck], [titel]]);
      }

      var zustand = {
        art: modus === 'aendern' ? c.komponente.art : null,
        werte: modus === 'aendern' ? JSON.parse(JSON.stringify(c.aktuell.werte)) : { merkmale: [] },
        fehler: {}
      };
      if (!Array.isArray(zustand.werte.merkmale)) zustand.werte.merkmale = [];
      var istHaupt = modus === 'neu-haupt' || (modus === 'aendern' && !c.komponente.parentId);
      var behaelter = h('div');

      function lesen() {
        Array.prototype.forEach.call(behaelter.querySelectorAll('input[name], select[name]'), function (el) {
          if (el.type !== 'radio') zustand.werte[el.name] = el.value;
        });
        if (behaelter.querySelector('.merkmale')) {
          zustand.werte.merkmale = Array.prototype.map.call(behaelter.querySelectorAll('.merkmal-zeile'), function (z) {
            return { name: z.querySelector('.merkmal-name').value, wert: z.querySelector('.merkmal-wert').value };
          });
        }
      }

      function speichern(ev) {
        ev.preventDefault();
        lesen();
        var p;
        if (modus === 'neu-haupt') p = daten.komponenteAnlegen(fahrzeugId, null, zustand.art, zustand.werte);
        else if (modus === 'neu-teil') p = daten.komponenteAnlegen(fahrzeugId, id, null, zustand.werte);
        else p = daten.komponenteAendern(id, zustand.werte);
        p.then(function (r) {
          if (!r.ok) {
            zustand.fehler = r.fehler;
            zeichne();
            var erster = behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten');
            if (erster && erster.focus) erster.focus();
            return;
          }
          if (modus === 'aendern') meldung = r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.';
          else meldung = modus === 'neu-haupt' ? 'Hauptkomponente angelegt.' : 'Teil angelegt.';
          global.location.hash = zurueck;
        }).catch(fehlerSeite);
      }

      function zeichne() {
        behaelter.textContent = '';
        var teile = [];
        if (modus === 'neu-haupt' && !zustand.art) {
          teile.push(h('p', { text: 'Wähle zuerst die Art. Dann erscheinen die Felder. Nur die Bezeichnung ist Pflicht.' }));
        }
        var fk = Object.keys(zustand.fehler);
        if (fk.length) {
          teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
            text: zustand.fehler.allgemein ? zustand.fehler.allgemein : (fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.') }));
        }

        if (modus === 'neu-haupt') {
          teile.push(h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
            h('legend', { class: 'fest-art', text: 'Art der Hauptkomponente' }),
            zustand.fehler.art ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.art }) : null,
            h('div', { class: 'artwahl' }, MM.Komponenten.arten().map(function (a) {
              var r = h('input', { type: 'radio', name: 'art', value: a.id, onchange: function () {
                lesen(); zustand.art = a.id; zustand.fehler = {};
                if (!String(zustand.werte.bezeichnung || '').trim() && a.id !== 'sonstiges') zustand.werte.bezeichnung = a.name;
                zeichne();
                var b = behaelter.querySelector('#f-bezeichnung'); if (b) b.focus({ preventScroll: true });
              } });
              if (zustand.art === a.id) r.checked = true;
              return h('label', null, r, h('span', { text: a.name }));
            }))));
        } else if (modus === 'aendern' && istHaupt) {
          teile.push(h('p', null, 'Art: ', h('span', { class: 'fest-art', text: MM.Komponenten.art(zustand.art).name }),
            h('span', { class: 'hilfe', text: ' (lässt sich nicht ändern)' })));
        } else if (modus === 'neu-teil') {
          teile.push(h('p', { class: 'gehoert', text: 'gehört zu: ' + c.aktuell.werte.bezeichnung }));
        }

        if (modus !== 'neu-haupt' || zustand.art) {
          teile.push(feldElement({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text',
            hilfe: istHaupt ? 'Zum Beispiel „Motor Backbord“. Bei zwei gleichen Teilen hilft ein Zusatz.' : 'Zum Beispiel „Einspritzpumpe“' },
            zustand.werte.bezeichnung, zustand.fehler.bezeichnung));
          MM.Komponenten.gruppen().forEach(function (g) {
            teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
              h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }),
              g.felder.map(function (f) {
                if (f.typ === 'liste') {
                  return merkmaleElement(f, zustand.werte.merkmale || [], zustand.fehler[f.key],
                    function () {
                      lesen(); zustand.werte.merkmale.push({ name: '', wert: '' }); zeichne();
                      var alle = behaelter.querySelectorAll('.merkmal-name'); if (alle.length) alle[alle.length - 1].focus();
                    },
                    function (i) { lesen(); zustand.werte.merkmale.splice(i, 1); zeichne(); });
                }
                return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key]);
              })));
          });
        }
        anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
      }

      zeichne();
      seite(titel, [krumen(weg), h('h1', { text: titel }), behaelter],
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: zurueck, text: 'Abbrechen' }),
          h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
    });
  }

  /* ---------- Einfaches Formular (für Fristen und Zähler) ---------- */
  /*
   * opts: titel, krumen, zurueck, werte, gruppen(zustand) -> [{titel, hinweis, felder}],
   *       neuzeichnenBei [Feldnamen], nachAenderung(key, zustand), intro,
   *       speichern(werte) -> Promise({ok, fehler, ...}), meldung(r), danach(r) -> Adresse
   */
  function einfachFormular(opts) {
    var zustand = { werte: JSON.parse(JSON.stringify(opts.werte || {})), fehler: {} };
    var behaelter = h('div');

    function lesen() {
      Array.prototype.forEach.call(behaelter.querySelectorAll('input[name], select[name]'), function (el) {
        if (el.type === 'radio') { if (el.checked) zustand.werte[el.name] = el.value; }
        else if (el.type === 'file') { if (el.files && el.files[0]) zustand.werte[el.name] = el.files[0]; }
        else zustand.werte[el.name] = el.value;
      });
    }
    function beiAenderung(key) {
      return function () {
        lesen();
        if (opts.nachAenderung) opts.nachAenderung(key, zustand);
        zustand.fehler = {};
        zeichne();
        var el = behaelter.querySelector('[name="' + key + '"]:checked') || behaelter.querySelector('[name="' + key + '"]');
        if (el && el.focus) el.focus({ preventScroll: true });
      };
    }
    function speichern(ev) {
      ev.preventDefault();
      lesen();
      opts.speichern(zustand.werte).then(function (r) {
        if (!r.ok) {
          zustand.fehler = r.fehler || {};
          zeichne();
          var erster = behaerter_erster();
          if (erster && erster.focus) erster.focus();
          return;
        }
        meldung = opts.meldung(r);
        var ziel = opts.danach(r);
        if (global.location.hash === ziel) zeige(); else global.location.hash = ziel;
      }).catch(fehlerSeite);
    }
    function behaerter_erster() { return behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten'); }

    function zeichne() {
      behaelter.textContent = '';
      var teile = [];
      var fk = Object.keys(zustand.fehler);
      if (fk.length) {
        teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
          text: zustand.fehler.allgemein ? zustand.fehler.allgemein : (fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.') }));
      }
      opts.gruppen(zustand).forEach(function (g) {
        var felder = g.felder.map(function (f) {
          var hook = opts.neuzeichnenBei && opts.neuzeichnenBei.indexOf(f.key) >= 0 ? beiAenderung(f.key) : undefined;
          return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key], hook);
        });
        teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
          g.titel ? h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }) : null,
          g.hinweis ? h('p', { class: 'hilfe', text: g.hinweis }) : null,
          felder));
      });
      anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
    }

    zeichne();
    seite(opts.titel, [opts.krumen, h('h1', { text: opts.titel }), opts.intro || null, behaelter],
      h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: opts.zurueck, text: 'Abbrechen' }),
        h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
  }

  function nichtGefunden(text) {
    return seite('Nicht gefunden', [h('h1', { text: text }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
  }

  function ortKrumen(fz, fzId, komp) {
    var liste = WEG_FAHRZEUGE.slice(0, 3);
    liste.push([fz.werte.bezeichnung, '#/fahrzeug/' + encodeURIComponent(fzId)]);
    if (komp) liste.push([komp.aktuell.werte.bezeichnung, '#/komponente/' + encodeURIComponent(komp.komponente.id)]);
    return liste;
  }

  /* ---------- Seite: Frist ---------- */
  function seiteFrist(id) {
    return daten.fristLaden(id).then(function (f) {
      if (!f) return nichtGefunden('Frist nicht gefunden');
      var w = f.aktuell.werte, st = f.status, einheit = f.zaehler ? f.zaehler.einheit : '';
      var besitzer = f.komponente ? f.komponenteAktuell.werte.bezeichnung : f.fahrzeugAktuell.werte.bezeichnung;
      var zurueck = f.komponente ? '#/komponente/' + encodeURIComponent(f.komponente.id) : '#/fahrzeug/' + encodeURIComponent(f.fahrzeug.id);

      var regeln = [];
      if (w.kalenderWert) regeln.push('alle ' + w.kalenderWert + ' ' + (w.kalenderEinheit === 'jahre' ? (w.kalenderWert === 1 ? 'Jahr' : 'Jahre') : (w.kalenderWert === 1 ? 'Monat' : 'Monate')));
      if (w.zaehlerId && w.zaehlerWert) regeln.push('alle ' + zahlMit(w.zaehlerWert, einheit) + (f.zaehler ? ' (Zähler: ' + f.zaehler.bezeichnung + ')' : ''));
      var regelText = regeln.join(' oder ') + (regeln.length > 1 ? ', was zuerst eintritt' : '');

      var zeilen = fristZeilen(st, einheit);
      var letzte = f.letzte;
      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: MM.Fristen.labelVon(MM.Fristen.KATEGORIEN, w.kategorie) + ' an: ' + besitzer }),
        h('h1', { text: w.bezeichnung }),
        h('p', null, h('span', { class: 'chip-status gross status-' + st.status, text: STATUS_TEXT[st.status] })),
        h('ul', { class: 'status-zeilen' }, zeilen.map(function (z) { return h('li', { class: 'status-' + z.status, text: z.text }); })),
        h('section', { class: 'gruppe' }, h('h3', { text: 'Regel' }),
          h('dl', { class: 'daten' },
            h('dt', { text: 'Fällig' }), h('dd', { text: regelText }),
            h('dt', { text: 'Wirkung' }), h('dd', { text: MM.Fristen.labelVon(MM.Fristen.WIRKUNGEN, w.wirkung) }),
            h('dt', { text: 'Vorwarnung' }), h('dd', { text: [w.kalenderWert ? tageText(w.vorwarnTage || 0) : null,
              (w.zaehlerId && w.vorwarnZaehler !== null && w.vorwarnZaehler !== undefined) ? zahlMit(w.vorwarnZaehler, einheit) : null].filter(Boolean).join(' und ') || 'keine' })),
          w.wirkung !== 'warnen' ? h('p', { class: 'hinweis', text: 'Eine Sperre oder Einschränkung wirkt später bei Verleih und Aktivitäten. Das folgt in späteren Schritten.' }) : null),
        h('section', { class: 'gruppe' }, h('h3', { text: 'Zuletzt erledigt' }),
          letzte ? h('p', { text: MM.Hilfen.datum(letzte.datum) + (letzte.zaehlerstand !== null && letzte.zaehlerstand !== undefined && f.zaehler ? ', bei ' + zahlMit(letzte.zaehlerstand, einheit) : '') +
            (letzte.art === 'ausgangswert' ? ' (Ausgangswert bei Anlage der Frist)' : '') }) : h('p', { class: 'leer-text', text: 'Noch nichts eingetragen.' })),
        h('p', null, h('a', { class: 'knopf leise', href: '#/frist/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));

      var erledigungen = h('details', { class: 'verlauf' },
        h('summary', { text: 'Erledigungen (' + f.durchfuehrungen.length + ')' }),
        h('ol', null, f.durchfuehrungen.map(function (d, i) {
          return h('li', { class: i === 0 ? 'aktuell' : null },
            h('div', null, h('span', { class: 'wann', text: MM.Hilfen.datum(d.datum) }),
              d.zaehlerstand !== null && d.zaehlerstand !== undefined ? ', bei ' + zahlMit(d.zaehlerstand, einheit) : ''),
            d.notiz ? h('div', { text: d.notiz }) : null);
        })));

      seite(w.bezeichnung, [
        krumen(ortKrumen(f.fahrzeugAktuell, f.fahrzeug.id, f.komponente ? { komponente: f.komponente, aktuell: f.komponenteAktuell } : null).concat([[w.bezeichnung]])),
        kopf, erledigungen, verlaufBlock(f.verlauf)
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/frist/' + encodeURIComponent(id) + '/erledigt', text: 'Erledigt eintragen' })));
    });
  }

  /* ---------- Formular: Frist anlegen / ändern ---------- */
  /* modus: 'neu-fz' (id = Fahrzeug), 'neu-komp' (id = Komponente), 'aendern' (id = Frist) */
  function fristFormular(modus, id) {
    var laden;
    if (modus === 'neu-fz') {
      laden = Promise.all([daten.fahrzeugLaden(id), daten.zaehlerListe(id)]).then(function (r) {
        return r[0] ? { fahrzeugId: id, komponenteId: null, fz: r[0].aktuell, komp: null, zl: r[1], zurueck: '#/fahrzeug/' + encodeURIComponent(id), werte: null } : null;
      });
    } else if (modus === 'neu-komp') {
      laden = daten.komponenteLaden(id).then(function (c) {
        if (!c) return null;
        return daten.zaehlerListe(c.fahrzeug.id).then(function (zl) {
          return { fahrzeugId: c.fahrzeug.id, komponenteId: id, fz: c.fahrzeugAktuell, komp: { komponente: c.komponente, aktuell: c.aktuell },
            zl: zl, zurueck: '#/komponente/' + encodeURIComponent(id), werte: null };
        });
      });
    } else {
      laden = daten.fristLaden(id).then(function (f) {
        if (!f) return null;
        return { fahrzeugId: f.fahrzeug.id, komponenteId: f.komponente ? f.komponente.id : null, fz: f.fahrzeugAktuell,
          komp: f.komponente ? { komponente: f.komponente, aktuell: f.komponenteAktuell } : null, zl: f.zaehlerListe,
          zurueck: '#/frist/' + encodeURIComponent(id), werte: JSON.parse(JSON.stringify(f.aktuell.werte)), name: f.aktuell.werte.bezeichnung };
      });
    }
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var neu = modus !== 'aendern';
      var titel = neu ? 'Frist hinzufügen' : 'Frist ändern';
      var start = k.werte || { kategorie: 'wartung', kalenderEinheit: 'monate', wirkung: 'warnen', vorwarnTage: '30' };
      var weg = ortKrumen(k.fz, k.fahrzeugId, k.komp);
      if (!neu) weg.push([k.name, k.zurueck]);
      weg.push([titel]);

      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: k.zurueck, werte: start, neuzeichnenBei: ['zaehlerId'],
        intro: neu ? h('p', { text: 'Eine Frist kann nach Zeit, nach Zähler oder nach beidem fällig werden. Gilt beides, entscheidet, was zuerst eintritt.' }) : null,
        gruppen: function (z) {
          var gewaehlt = k.zl.filter(function (x) { return x.zaehler.id === z.werte.zaehlerId; })[0] || null;
          var einheit = gewaehlt ? gewaehlt.einheit : '';
          function f(key, extra) {
            var def = MM.Fristen.felder(true).filter(function (x) { return x.key === key; })[0];
            return Object.assign({}, def, extra || {});
          }
          var gruppen = [
            { titel: 'Frist', felder: [
              { key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Zum Beispiel „Ölwechsel“ oder „Feuerlöscher prüfen“' },
              f('kategorie', { leerText: '– bitte wählen –' }) ] },
            { titel: 'Kalender', felder: [f('kalenderWert'), f('kalenderEinheit', { leerText: 'Monate' })] }
          ];
          var zfelder = [];
          if (k.zl.length) {
            zfelder.push(f('zaehlerId', { typ: 'auswahl', leerText: 'Kein Zähler', hilfe: 'Wähle, wenn die Frist nach Strecke oder Betriebsstunden gelten soll.',
              optionen: k.zl.map(function (x) { return { wert: x.zaehler.id, label: x.label }; }) }));
            if (gewaehlt) zfelder.push(f('zaehlerWert', { einheit: einheit }));
          }
          gruppen.push({ titel: 'Zähler', hinweis: k.zl.length ? null : 'Es gibt noch keinen Zähler. Lege zuerst einen Zähler am Fahrzeug oder an der Komponente an, wenn die Frist nach Strecke oder Betriebsstunden gelten soll.', felder: zfelder });
          var wf = [f('wirkung', { leerText: 'Nur warnen' }), f('vorwarnTage')];
          if (gewaehlt) wf.push(f('vorwarnZaehler', { einheit: einheit }));
          gruppen.push({ titel: 'Wirkung und Vorwarnung', felder: wf });
          if (neu) {
            var af = [f('zuletztAm')];
            if (gewaehlt) af.push(f('zuletztStand', { einheit: einheit }));
            gruppen.push({ titel: 'Ausgangswert', hinweis: 'Ab wann soll gerechnet werden? Ohne Angabe zählt die Frist ab heute.', felder: af });
          }
          return gruppen;
        },
        speichern: function (w) { return neu ? daten.fristAnlegen(k.fahrzeugId, k.komponenteId, w) : daten.fristAendern(id, w); },
        meldung: function (r) { return neu ? 'Frist angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/frist/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Formular: Frist erledigt eintragen ---------- */
  function erledigtFormular(id) {
    return daten.fristLaden(id).then(function (f) {
      if (!f) return nichtGefunden('Frist nicht gefunden');
      var z = f.zaehler, w = f.aktuell.werte;
      var start = { datum: daten.heute(), zaehlerstand: z && z.stand ? String(z.stand.wert) : '', notiz: '' };
      var weg = ortKrumen(f.fahrzeugAktuell, f.fahrzeug.id, f.komponente ? { komponente: f.komponente, aktuell: f.komponenteAktuell } : null);
      weg.push([w.bezeichnung, '#/frist/' + encodeURIComponent(id)]); weg.push(['Erledigt eintragen']);
      var felder = [{ key: 'datum', label: 'Erledigt am', typ: 'datum' }];
      if (z) felder.push({ key: 'zaehlerstand', label: 'Zählerstand dabei', typ: 'zahl', einheit: z.einheit,
        hilfe: z.stand ? 'Aktueller Stand: ' + zahlMit(z.stand.wert, z.einheit) + '. Ein höherer Stand wird auch im Zähler eingetragen.' : 'Der Stand, als die Frist erledigt wurde.' });
      felder.push({ key: 'notiz', label: 'Notiz', typ: 'text', hilfe: 'Zum Beispiel die Werkstatt oder was gemacht wurde' });
      einfachFormular({
        titel: 'Erledigt eintragen', krumen: krumen(weg), zurueck: '#/frist/' + encodeURIComponent(id), werte: start,
        intro: h('p', { text: w.bezeichnung + ': Danach beginnt die Rechnung der Frist von vorn. Die frühere Erledigung bleibt sichtbar.' }),
        gruppen: function () { return [{ titel: null, felder: felder }]; },
        speichern: function (v) { return daten.durchfuehrungAnlegen(id, v); },
        meldung: function () { return 'Erledigt eingetragen.'; },
        danach: function () { return '#/frist/' + encodeURIComponent(id); }
      });
    });
  }

  /* ---------- Seite: Zähler ---------- */
  function seiteZaehler(id) {
    return daten.zaehlerLaden(id).then(function (z) {
      if (!z) return nichtGefunden('Zähler nicht gefunden');
      var besitzer = z.komponente ? z.komponenteAktuell.werte.bezeichnung : z.fahrzeugAktuell.werte.bezeichnung;
      var zurueck = z.komponente ? '#/komponente/' + encodeURIComponent(z.komponente.id) : '#/fahrzeug/' + encodeURIComponent(z.fahrzeug.id);
      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: z.art.label + ' an: ' + besitzer }),
        h('h1', { text: z.bezeichnung }),
        h('p', { class: 'grosse-zahl', text: z.stand ? zahlMit(z.stand.wert, z.einheit) : 'Noch kein Stand' }),
        z.stand ? h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.datum(z.stand.datum) + ', per Handeingabe' }) : h('p', { class: 'leer-text', text: 'Trage den ersten Zählerstand ein. Dann rechnen die Fristen damit.' }),
        h('p', null, h('a', { class: 'knopf leise', href: '#/zaehler/' + encodeURIComponent(id) + '/aendern', text: 'Name ändern' })));
      var staende = h('details', { class: 'verlauf', open: z.staende.length ? 'open' : null },
        h('summary', { text: 'Zählerstände (' + z.staende.length + ')' }),
        h('ol', null, z.staende.map(function (s, i) {
          return h('li', { class: i === 0 ? 'aktuell' : null },
            h('div', null, h('span', { class: 'wann', text: zahlMit(s.wert, z.einheit) }), ', ' + MM.Hilfen.datum(s.datum), i === 0 ? h('span', { class: 'marke-aktuell', text: 'aktuell' }) : null),
            s.notiz ? h('div', { text: s.notiz }) : null);
        })));
      seite(z.bezeichnung, [
        krumen(ortKrumen(z.fahrzeugAktuell, z.fahrzeug.id, z.komponente ? { komponente: z.komponente, aktuell: z.komponenteAktuell } : null).concat([[z.bezeichnung]])),
        kopf, staende, z.verlauf.length > 1 ? verlaufBlock(z.verlauf) : null
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/zaehler/' + encodeURIComponent(id) + '/stand', text: 'Neuen Stand eintragen' })));
    });
  }

  /* ---------- Formular: Zähler anlegen / Name ändern ---------- */
  /* modus: 'neu-fz' (id = Fahrzeug), 'neu-komp' (id = Komponente), 'aendern' (id = Zähler) */
  function zaehlerFormular(modus, id) {
    var laden;
    if (modus === 'neu-fz') laden = daten.fahrzeugLaden(id).then(function (f) { return f ? { fahrzeugId: id, komponenteId: null, fz: f.aktuell, komp: null, zurueck: '#/fahrzeug/' + encodeURIComponent(id) } : null; });
    else if (modus === 'neu-komp') laden = daten.komponenteLaden(id).then(function (c) { return c ? { fahrzeugId: c.fahrzeug.id, komponenteId: id, fz: c.fahrzeugAktuell, komp: { komponente: c.komponente, aktuell: c.aktuell }, zurueck: '#/komponente/' + encodeURIComponent(id) } : null; });
    else laden = daten.zaehlerLaden(id).then(function (z) { return z ? { fahrzeugId: z.fahrzeug.id, komponenteId: z.komponente ? z.komponente.id : null, fz: z.fahrzeugAktuell, komp: z.komponente ? { komponente: z.komponente, aktuell: z.komponenteAktuell } : null, zurueck: '#/zaehler/' + encodeURIComponent(id), z: z } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var neu = modus !== 'aendern';
      var titel = neu ? 'Zähler hinzufügen' : 'Zähler umbenennen';
      var weg = ortKrumen(k.fz, k.fahrzeugId, k.komp);
      if (!neu) weg.push([k.z.bezeichnung, k.zurueck]);
      weg.push([titel]);
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: k.zurueck,
        werte: neu ? { art: null, bezeichnung: '', startStand: '' } : { bezeichnung: k.z.bezeichnung },
        neuzeichnenBei: ['art'],
        nachAenderung: function (key, z) {
          if (key !== 'art') return;
          var a = MM.Fristen.zaehlerArt(z.werte.art);
          var istStandard = MM.Fristen.ZAEHLERARTEN.some(function (x) { return x.standard === z.werte.bezeichnung; });
          if (a && (!String(z.werte.bezeichnung || '').trim() || istStandard)) z.werte.bezeichnung = a.standard;
        },
        intro: neu ? h('p', { text: 'Ein Zähler zählt Strecke oder Betriebsstunden. Er kann am Fahrzeug oder an einer einzelnen Komponente hängen, zum Beispiel pro Motor.' }) : null,
        gruppen: function (z) {
          var g = [];
          var felder = [];
          if (neu) felder.push({ key: 'art', label: 'Was wird gezählt?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Fristen.ZAEHLERARTEN });
          var a = MM.Fristen.zaehlerArt(z.werte.art);
          if (!neu || a) {
            felder.push({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Zum Beispiel „Kilometerstand“ oder „Betriebsstunden Motor Backbord“' });
            if (neu) felder.push({ key: 'startStand', label: 'Aktueller Stand (kann leer bleiben)', typ: 'zahl', einheit: a.einheit });
          }
          g.push({ titel: null, felder: felder });
          return g;
        },
        speichern: function (w) {
          if (!neu) return daten.zaehlerAendern(id, w);
          return daten.zaehlerAnlegen(k.fahrzeugId, k.komponenteId, w.art, w).then(function (r) {
            if (!r.ok) return r;
            if (String(w.startStand || '').trim() === '') return r;
            return daten.zaehlerStandEintragen(r.id, { wert: w.startStand }).then(function (s) {
              r.standFehler = s.ok ? null : s.fehler.wert || s.fehler.datum || 'Der Stand konnte nicht eingetragen werden.';
              return r;
            });
          });
        },
        meldung: function (r) { return neu ? (r.standFehler ? 'Zähler angelegt. Der Stand fehlt noch: ' + r.standFehler : 'Zähler angelegt.') : (r.geaendert ? 'Gespeichert. Der frühere Name bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/zaehler/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Formular: neuer Zählerstand ---------- */
  function standFormular(id) {
    return daten.zaehlerLaden(id).then(function (z) {
      if (!z) return nichtGefunden('Zähler nicht gefunden');
      var weg = ortKrumen(z.fahrzeugAktuell, z.fahrzeug.id, z.komponente ? { komponente: z.komponente, aktuell: z.komponenteAktuell } : null);
      weg.push([z.bezeichnung, '#/zaehler/' + encodeURIComponent(id)]); weg.push(['Neuen Stand eintragen']);
      einfachFormular({
        titel: 'Neuen Stand eintragen', krumen: krumen(weg), zurueck: '#/zaehler/' + encodeURIComponent(id),
        werte: { wert: '', datum: daten.heute(), notiz: '' },
        intro: z.stand ? h('p', { text: 'Letzter Stand: ' + zahlMit(z.stand.wert, z.einheit) + ' am ' + MM.Hilfen.datum(z.stand.datum) + '.' }) : null,
        gruppen: function () {
          return [{ titel: null, felder: [
            { key: 'wert', label: 'Zählerstand', typ: 'zahl', einheit: z.einheit },
            { key: 'datum', label: 'Abgelesen am', typ: 'datum' },
            { key: 'notiz', label: 'Notiz', typ: 'text', hilfe: 'Zum Beispiel „nach dem Tanken“' }] }];
        },
        speichern: function (w) { return daten.zaehlerStandEintragen(id, w).then(function (r) { r.id = id; return r; }); },
        meldung: function () { return 'Zählerstand eingetragen.'; },
        danach: function () { return '#/zaehler/' + encodeURIComponent(id); }
      });
    });
  }

  /* ---------- Dokumente: gemeinsame Bausteine ---------- */
  function dokInfo(w) {
    return w.quelle === 'link' ? 'Link' : 'Datei, ' + MM.Hilfen.groesse(w.dateiGroesse);
  }

  function dokZeile(x, mitBesitzer) {
    var w = x.aktuell.werte;
    return h('li', null, h('a', { class: 'frist dok', href: '#/dokument/' + encodeURIComponent(x.dokument.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: w.bezeichnung }),
        h('span', { class: 'frist-info', text: dokInfo(w) }),
        mitBesitzer && x.besitzer ? h('span', { class: 'frist-info', text: 'an: ' + x.besitzer }) : null),
      h('span', { class: 'chip-status', text: MM.Dokumente.artLabel(w.art) })));
  }

  /* Dokumente eines Fahrzeugs oder einer Komponente. gesamt: Link zur Gesamtliste (nur beim Fahrzeug). */
  function dokumenteBereich(liste, neuHash, gesamt) {
    return h('section', { class: 'bereich', 'aria-label': 'Dokumente' },
      h('h2', { text: 'Dokumente' }),
      liste.length ? h('ul', { class: 'fristen' }, liste.map(function (x) { return dokZeile(x, false); }))
        : h('p', { class: 'leer-text', text: 'Noch kein Dokument. Lege zum Beispiel eine Bedienungsanleitung oder Ersatzteilliste ab, als Datei oder als Link.' }),
      gesamt && gesamt.anzahl > liste.length ? h('p', null, h('a', { href: gesamt.href, text: 'Alle Dokumente ansehen (' + gesamt.anzahl + '), auch die der Komponenten' })) : null,
      h('a', { class: 'knopf leise', href: neuHash + '/dokument/neu', text: 'Dokument hinzufügen' }));
  }

  /* Datei öffnen oder auf dem Gerät speichern. statusEl zeigt bei Bedarf einen Ersatz-Link. */
  function dateiOeffnen(dokumentId, speichern, statusEl) {
    return daten.dateiHolen(dokumentId).then(function (d) {
      if (!d) { statusEl.textContent = 'Die Datei wurde nicht gefunden.'; return; }
      var url = global.URL.createObjectURL(d.inhalt);
      statusEl.textContent = '';
      if (speichern) {
        var a = doc.createElement('a');
        a.href = url; a.download = d.name;
        doc.body.appendChild(a); a.click(); a.remove();
      } else {
        var w = global.open(url, '_blank');
        if (!w) statusEl.appendChild(h('a', { href: url, target: '_blank', rel: 'noopener', text: 'Tippe hier, um die Datei zu öffnen' }));
      }
      global.setTimeout(function () { global.URL.revokeObjectURL(url); }, 10 * 60 * 1000);
    }).catch(function (err) { statusEl.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler'); });
  }

  /* ---------- Seite: Dokument ---------- */
  function seiteDokument(id) {
    return daten.dokumentLaden(id).then(function (d) {
      if (!d) return nichtGefunden('Dokument nicht gefunden');
      var w = d.aktuell.werte;
      var besitzer = d.komponente ? d.komponenteAktuell.werte.bezeichnung : d.fahrzeugAktuell.werte.bezeichnung;
      var zurueck = d.komponente ? '#/komponente/' + encodeURIComponent(d.komponente.id) : '#/fahrzeug/' + encodeURIComponent(d.fahrzeug.id);
      var status = h('p', { class: 'oeffnen-status', role: 'status' });
      var vorschau = h('div', { class: 'vorschau' });
      var istBild = d.datei && /^image\//.test(d.datei.mime || '');
      if (istBild) {
        daten.dateiHolen(id).then(function (x) {
          if (!x) return;
          var url = global.URL.createObjectURL(x.inhalt);
          vorschau.appendChild(h('img', { src: url, alt: w.bezeichnung, class: 'vorschau-bild' }));
        });
      }
      var knoepfe = w.quelle === 'link'
        ? h('p', null, h('a', { class: 'knopf', href: w.link, target: '_blank', rel: 'noopener noreferrer', text: 'Link öffnen' }))
        : h('p', { class: 'knopfzeile' },
          h('button', { class: 'knopf', type: 'button', text: 'Öffnen', onclick: function () { dateiOeffnen(id, false, status); } }),
          h('button', { class: 'knopf leise', type: 'button', text: 'Auf dem Gerät speichern', onclick: function () { dateiOeffnen(id, true, status); } }));

      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: MM.Dokumente.artLabel(w.art) + ' an: ' + besitzer }),
        h('h1', { text: w.bezeichnung }),
        h('dl', { class: 'daten' },
          w.quelle === 'link' ? [h('dt', { text: 'Link' }), h('dd', { text: w.link })] : [
            h('dt', { text: 'Datei' }), h('dd', { text: (w.dateiName || '') + ' (' + MM.Hilfen.groesse(w.dateiGroesse) + ')' }),
            h('dt', { text: 'Gespeichert' }), h('dd', { text: 'auf diesem Gerät, auch ohne Internet' })],
          w.notiz ? [h('dt', { text: 'Notiz' }), h('dd', { text: w.notiz })] : null),
        vorschau, knoepfe, status,
        h('p', { class: 'stand', text: 'Abgelegt am ' + MM.Hilfen.zeitpunkt(d.dokument.erstelltAm) }),
        h('p', null, h('a', { class: 'knopf leise', href: '#/dokument/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));

      seite(w.bezeichnung, [
        krumen(ortKrumen(d.fahrzeugAktuell, d.fahrzeug.id, d.komponente ? { komponente: d.komponente, aktuell: d.komponenteAktuell } : null).concat([[w.bezeichnung]])),
        kopf, d.verlauf.length > 1 ? verlaufBlock(d.verlauf) : null
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' })));
    });
  }

  /* ---------- Seite: alle Dokumente eines Fahrzeugs ---------- */
  function seiteDokumente(fahrzeugId) {
    return Promise.all([daten.fahrzeugLaden(fahrzeugId), daten.dokumenteListe(fahrzeugId)]).then(function (r) {
      var f = r[0], liste = r[1];
      if (!f) return nichtGefunden('Fahrzeug nicht gefunden');
      var fzName = f.aktuell.werte.bezeichnung;
      var behaelter = h('div', { class: 'dok-gruppen' });
      var suche = h('input', { type: 'search', class: 'suche', placeholder: 'Suchen, zum Beispiel „Heizung“ oder „Ersatzteil“', 'aria-label': 'Dokumente suchen', autocomplete: 'off' });

      function zeichne() {
        var q = suche.value.trim().toLowerCase();
        behaelter.textContent = '';
        var treffer = liste.filter(function (x) {
          if (!q) return true;
          var w = x.aktuell.werte;
          return [w.bezeichnung, MM.Dokumente.artLabel(w.art), x.besitzer || fzName, w.notiz || ''].join(' ').toLowerCase().indexOf(q) >= 0;
        });
        if (!treffer.length) {
          behaelter.appendChild(h('p', { class: 'leer-text', text: liste.length ? 'Nichts gefunden.' : 'Noch kein Dokument. Du kannst es am Fahrzeug oder an jeder Komponente ablegen.' }));
          return;
        }
        var gruppen = [], zuletzt;
        treffer.forEach(function (x) {
          var key = x.komponenteId || '';
          if (key !== zuletzt) { gruppen.push({ key: key, name: x.besitzer || fzName, eintraege: [] }); zuletzt = key; }
          gruppen[gruppen.length - 1].eintraege.push(x);
        });
        gruppen.forEach(function (g) {
          var ziel = g.key ? '#/komponente/' + encodeURIComponent(g.key) : '#/fahrzeug/' + encodeURIComponent(fahrzeugId);
          behaelter.appendChild(h('section', { class: 'bereich' },
            h('h2', null, h('a', { href: ziel, text: g.name })),
            h('ul', { class: 'fristen' }, g.eintraege.map(function (x) { return dokZeile(x, false); }))));
        });
      }
      suche.addEventListener('input', zeichne);
      zeichne();

      seite('Dokumente', [
        krumen(WEG_FAHRZEUGE.concat([[fzName, '#/fahrzeug/' + encodeURIComponent(fahrzeugId)], ['Dokumente']])),
        h('h1', { text: 'Dokumente' }),
        h('p', { class: 'gehoert', text: 'Alle Dokumente von ' + fzName + ' und seinen Komponenten (' + liste.length + ')' }),
        liste.length > 3 ? suche : null,
        behaelter
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/fahrzeug/' + encodeURIComponent(fahrzeugId), text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(fahrzeugId) + '/dokument/neu', text: 'Dokument hinzufügen' })));
    });
  }

  /* ---------- Formular: Dokument ablegen / ändern ---------- */
  /* modus: 'neu-fz' (id = Fahrzeug), 'neu-komp' (id = Komponente), 'aendern' (id = Dokument) */
  function dokumentFormular(modus, id) {
    var laden;
    if (modus === 'neu-fz') laden = daten.fahrzeugLaden(id).then(function (f) { return f ? { fahrzeugId: id, komponenteId: null, fz: f.aktuell, komp: null, zurueck: '#/fahrzeug/' + encodeURIComponent(id) } : null; });
    else if (modus === 'neu-komp') laden = daten.komponenteLaden(id).then(function (c) { return c ? { fahrzeugId: c.fahrzeug.id, komponenteId: id, fz: c.fahrzeugAktuell, komp: { komponente: c.komponente, aktuell: c.aktuell }, zurueck: '#/komponente/' + encodeURIComponent(id) } : null; });
    else laden = daten.dokumentLaden(id).then(function (d) { return d ? { fahrzeugId: d.fahrzeug.id, komponenteId: d.komponente ? d.komponente.id : null, fz: d.fahrzeugAktuell, komp: d.komponente ? { komponente: d.komponente, aktuell: d.komponenteAktuell } : null, zurueck: '#/dokument/' + encodeURIComponent(id), d: d } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var neu = modus !== 'aendern';
      var titel = neu ? 'Dokument hinzufügen' : 'Dokument ändern';
      var weg = ortKrumen(k.fz, k.fahrzeugId, k.komp);
      if (!neu) weg.push([k.d.aktuell.werte.bezeichnung, k.zurueck]);
      weg.push([titel]);
      var start = neu ? { quelle: 'datei', art: 'bedienung', bezeichnung: '', notiz: '' } : JSON.parse(JSON.stringify(k.d.aktuell.werte));
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: k.zurueck, werte: start, neuzeichnenBei: ['quelle', 'datei'],
        nachAenderung: function (key, z) {
          if (key === 'datei' && z.werte.datei && !String(z.werte.bezeichnung || '').trim()) z.werte.bezeichnung = String(z.werte.datei.name).replace(/\.[^.]+$/, '');
        },
        intro: neu ? h('p', { text: 'Lege eine Datei von diesem Gerät ab, zum Beispiel ein PDF oder Foto. Sie bleibt auf dem Gerät und ist auch ohne Internet da. Oder speichere den Link zu einer Anleitung im Internet.' })
          : h('p', { text: k.d.aktuell.werte.quelle === 'datei' ? 'Die Datei selbst bleibt unverändert. Für eine andere Datei lege ein neues Dokument an.' : 'Hier kannst du Angaben und Link ändern.' }),
        gruppen: function (z) {
          var felder = [];
          if (neu) {
            felder.push({ key: 'quelle', label: 'Was möchtest du ablegen?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Dokumente.QUELLEN });
            if (z.werte.quelle === 'datei') felder.push({ key: 'datei', label: 'Datei', typ: 'datei', hilfe: 'Tippe auf „Datei auswählen“ und suche sie auf dem Gerät.' });
          }
          var quelle = neu ? z.werte.quelle : k.d.aktuell.werte.quelle;
          felder.push({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text',
            hilfe: quelle === 'datei' && neu ? 'Zum Beispiel „Heizung Bedienungsanleitung“. Bleibt das Feld leer, nimmt die App den Dateinamen.' : 'Zum Beispiel „Heizung Bedienungsanleitung“' });
          MM.Dokumente.felder(quelle).forEach(function (f) { felder.push(f); });
          return [{ titel: null, felder: felder }];
        },
        speichern: function (w) { return neu ? daten.dokumentAnlegen(k.fahrzeugId, k.komponenteId, w) : daten.dokumentAendern(id, w); },
        meldung: function (r) { return neu ? 'Dokument abgelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/dokument/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Startseite ---------- */
  function seiteStart() {
    doc.title = 'MobiMory';
    wurzel.textContent = '';
    var saetze = MM.Texte.KERNSATZ.split('. ').map(function (t, i, a) { return i < a.length - 1 ? t + '.' : t; });
    wurzel.appendChild(h('main', { class: 'start', id: 'inhalt' },
      h('div', { class: 'start-logo' },
        h('img', { src: 'icons/icon.svg', alt: '', width: '112', height: '112' }),
        h('p', { class: 'start-name', text: 'MobiMory' }),
        h('p', { class: 'start-vtd', text: 'Vehicle, Traffic and Data' })),
      h('h1', { class: 'kernsatz' }, saetze.map(function (z, i) {
        return h('span', { class: 'satz' },
          h('span', { class: 'chip', 'aria-hidden': 'true', text: 'VTD'.charAt(i) }),
          h('span', { text: z + ' ' }));
      })),
      h('p', { class: 'infotext', text: MM.Texte.INFOTEXT }),
      h('div', { class: 'start-knoepfe' },
        h('a', { class: 'knopf gross', href: '#/auswahl', text: 'Programm starten' }),
        h('a', { class: 'knopf leise gross', href: '#/neu-im-programm', text: 'Neu im Programm' })),
      h('footer', { class: 'start-fuss' },
        h('p', { text: MM.Texte.COPYRIGHT }),
        h('p', { text: 'Version ' + MM.VERSION }))));
    global.scrollTo(0, 0);
    return Promise.resolve();
  }

  /* ---------- Kacheln ---------- */
  function kachel(titel, text, href) {
    var inhalt = [h('span', { class: 'kachel-titel', text: titel }), h('span', { class: 'kachel-text', text: text })];
    if (href) return h('a', { class: 'kachel', href: href }, inhalt);
    return h('div', { class: 'kachel bald' }, inhalt, h('span', { class: 'kachel-bald', text: 'kommt' }));
  }

  /* ---------- Hauptmenü (äußerste Schale nach der Startseite) ---------- */
  function seiteHauptmenue() {
    seite('Hauptmenü', [
      h('h1', { text: 'Hauptmenü' }),
      h('div', { class: 'kacheln' },
        kachel('Stammdaten', 'Fahrzeuge, Personen und Tiere', '#/stammdaten'),
        kachel('Funktionen', 'Aktivitäten, Reisecheck, Werkstatt und mehr'),
        kachel('Einstellungen', 'Deine Daten und Hinweise zum Programm', '#/einstellungen')),
      h('p', { class: 'zur-start' }, h('a', { href: '#/', text: 'Zur Startseite' }))
    ]);
    return Promise.resolve();
  }

  /* ---------- Stammdaten ---------- */
  function seiteStammdaten() {
    return daten.fahrzeugListe().then(function (liste) {
      var n = liste.length;
      var text = n === 0 ? 'Noch kein Fahrzeug angelegt' : (n === 1 ? '1 Fahrzeug' : n + ' Fahrzeuge');
      seite('Stammdaten', [
        krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten']]),
        h('h1', { text: 'Stammdaten' }),
        h('div', { class: 'kacheln' },
          kachel('Fahrzeuge', text, '#/fahrzeuge'),
          kachel('Personen', 'Besatzung und Nachweise'),
          kachel('Tiere', 'Tiere an Bord'))
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/auswahl', text: 'Zurück' })));
    });
  }

  /* ---------- Neu im Programm ---------- */
  function seiteNeuerungen() {
    seite('Neu im Programm', [
      h('h1', { text: 'Neu im Programm' }),
      h('div', { class: 'neuerungen' }, MM.Texte.NEUERUNGEN.map(function (v) {
        return h('section', { class: 'neuerung' },
          h('h2', { text: 'Version ' + v.version }),
          h('p', { class: 'datum', text: MM.Hilfen.datum(v.datum) }),
          h('ul', null, v.punkte.map(function (t) { return h('li', { text: t }); })));
      }))
    ], h('div', { class: 'leiste' },
      h('a', { class: 'knopf leise', href: '#/', text: 'Zur Startseite' }),
      h('a', { class: 'knopf', href: '#/auswahl', text: 'Programm starten' })));
    return Promise.resolve();
  }

  /* ---------- Einstellungen ---------- */
  function schaetzung() {
    var n = global.navigator;
    if (!n.storage || !n.storage.estimate) return Promise.resolve(null);
    return Promise.all([
      n.storage.estimate().catch(function () { return null; }),
      n.storage.persisted ? n.storage.persisted().catch(function () { return null; }) : Promise.resolve(null)
    ]).then(function (r) { return r[0] ? { usage: r[0].usage, quota: r[0].quota, dauerhaft: r[1] } : null; });
  }

  function seiteEinstellungen() {
    return Promise.all([daten.dateienBelegung(), schaetzung()]).then(function (r) {
      var dat = r[0], sp = r[1];
      var speicherZeilen = [
        h('p', { text: 'Dokumente auf diesem Gerät: ' + (dat.anzahl === 1 ? '1 Datei' : dat.anzahl + ' Dateien') + (dat.anzahl ? ', zusammen ' + MM.Hilfen.groesse(dat.bytes) : '') + '.' })
      ];
      if (sp && sp.quota) {
        speicherZeilen.push(h('p', { text: 'Der Browser erlaubt MobiMory auf diesem Gerät insgesamt etwa ' + MM.Hilfen.groesse(sp.quota) + '. Davon sind etwa ' + MM.Hilfen.groesse(sp.usage) + ' belegt.' }));
        if (sp.dauerhaft !== null) speicherZeilen.push(h('p', { class: 'hinweis', text: sp.dauerhaft ? 'Der Browser löscht diese Daten nicht von selbst.' : 'Der Browser darf diese Daten bei Platzmangel löschen. Mit „Zum Startbildschirm hinzufügen“ ist das unwahrscheinlicher.' }));
      } else {
        speicherZeilen.push(h('p', { class: 'hinweis', text: 'Dieser Browser nennt keine Angabe zum freien Platz.' }));
      }
      seite('Einstellungen', [
        krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen']]),
        h('h1', { text: 'Einstellungen' }),
        h('section', { class: 'block' },
          h('h2', { text: 'Deine Daten' }),
          h('p', { text: 'Deine Daten liegen nur auf diesem Gerät. Eine automatische Sicherung gibt es in dieser Stufe noch nicht: Geht das Gerät kaputt, sind die Daten weg.' })),
        h('section', { class: 'block' }, h('h2', { text: 'Speicher auf diesem Gerät' }), speicherZeilen),
        h('section', { class: 'block' },
          h('h2', { text: 'Über MobiMory' }),
          h('p', { text: 'Version ' + MM.VERSION + ' (' + MM.STUFE + ')' }),
          h('p', { text: MM.Texte.COPYRIGHT }),
          h('p', { class: 'hinweis', text: 'MobiMory ist eine Hilfestellung und trifft keine rechtliche Aussage. Die letzte Verantwortung hat der verantwortliche Skipper bzw. Fahrer.' })),
        h('details', { class: 'block test' },
          h('summary', { text: 'Nur für Tests' }),
          h('p', { text: 'Löscht alle Fahrzeuge und Dokumente auf diesem Gerät. Das lässt sich nicht rückgängig machen.' }),
          h('button', { class: 'knopf gefahr', type: 'button', text: 'Alle Daten auf diesem Gerät löschen',
            onclick: function () {
              if (global.confirm('Wirklich alle Daten auf diesem Gerät löschen?')) {
                daten.allesLoeschen().then(function () { meldung = 'Alle Daten auf diesem Gerät wurden gelöscht.'; return zeige(); }).catch(fehlerSeite);
              }
            } }))
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/auswahl', text: 'Zurück' })));
    });
  }

  function fehlerSeite(err) {
    wurzel.textContent = '';
    wurzel.appendChild(kopf());
    wurzel.appendChild(h('main', { class: 'fehlerseite' },
      h('h1', { text: 'Das hat nicht geklappt' }),
      h('p', { text: (err && err.message) ? err.message : 'Es ist ein unbekannter Fehler aufgetreten.' }),
      h('p', null, h('a', { class: 'knopf', href: '#/auswahl', text: 'Zum Hauptmenü' }))));
  }

  /* ---------- Weiterleitung nach der Adresse ---------- */
  function zeige() {
    var hash = (global.location.hash || '#/').replace(/^#/, '');
    var teile = hash.split('/').filter(Boolean);
    var p;
    if (teile.length === 0) p = seiteStart();
    else if (teile[0] === 'auswahl') p = seiteHauptmenue();
    else if (teile[0] === 'stammdaten') p = seiteStammdaten();
    else if (teile[0] === 'fahrzeuge') p = seiteListe();
    else if (teile[0] === 'neu-im-programm') p = seiteNeuerungen();
    else if (teile[0] === 'einstellungen') p = seiteEinstellungen();
    else if (teile[0] === 'neu') p = seiteFormular('neu');
    else if (teile[0] === 'dokument' && teile[1] && teile[2] === 'aendern') p = dokumentFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'dokument' && teile[1]) p = seiteDokument(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'dokumente') p = seiteDokumente(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'dokument' && teile[3] === 'neu') p = dokumentFormular('neu-fz', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'dokument' && teile[3] === 'neu') p = dokumentFormular('neu-komp', decodeURIComponent(teile[1]));
    else if (teile[0] === 'frist' && teile[1] && teile[2] === 'aendern') p = fristFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'frist' && teile[1] && teile[2] === 'erledigt') p = erledigtFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'frist' && teile[1]) p = seiteFrist(decodeURIComponent(teile[1]));
    else if (teile[0] === 'zaehler' && teile[1] && teile[2] === 'stand') p = standFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'zaehler' && teile[1] && teile[2] === 'aendern') p = zaehlerFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'zaehler' && teile[1]) p = seiteZaehler(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'frist' && teile[3] === 'neu') p = fristFormular('neu-fz', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'zaehler' && teile[3] === 'neu') p = zaehlerFormular('neu-fz', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'frist' && teile[3] === 'neu') p = fristFormular('neu-komp', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'zaehler' && teile[3] === 'neu') p = zaehlerFormular('neu-komp', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'neu') p = seiteKomponentenFormular('neu-teil', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'aendern') p = seiteKomponentenFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1]) p = seiteKomponente(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'komponente' && teile[3] === 'neu') p = seiteKomponentenFormular('neu-haupt', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'aendern') p = seiteFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1]) p = seiteFahrzeug(decodeURIComponent(teile[1]));
    else p = seiteStart();
    return p.catch(fehlerSeite);
  }

  function starten(d, el) {
    daten = d; wurzel = el;
    global.addEventListener('hashchange', zeige);
    return zeige();
  }

  MM.Ansicht = { starten: starten, fehler: function (el, err) { wurzel = el; fehlerSeite(err); } };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
