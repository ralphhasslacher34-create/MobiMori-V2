/*
 * Daten: die EINE Tür zu allen Fahrzeugdaten.
 *
 * Regeln aus den V2-Festlegungen, die hier gelten:
 *  - Eine Quelle: alle Teile der App fragen nur hier nach.
 *  - Handeingabe hat Vorrang. Es wird nichts überschrieben: Jede Änderung
 *    ist ein neuer Eintrag "Korrektur zu ...", der alte bleibt sichtbar.
 *  - Nichts wird gelöscht.
 *  - Jeder Eintrag nennt seine Herkunft (hier: "hand").
 *
 * Aufbau der gespeicherten Daten:
 *  datenraum   { id, name, erstelltAm }
 *  fahrzeug    { id, datenraumId, art, erstelltAm }
 *  eintrag     { id, fahrzeugId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  komponente  { id, fahrzeugId, parentId, art, erstelltAm }
 *              parentId = null: Hauptkomponente (dann gilt "art"), sonst gehört
 *              sie zu einer anderen Komponente ("gehört zu").
 *  komponenteneintrag { id, komponenteId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  zaehler     { id, fahrzeugId, komponenteId|null, art, erstelltAm }      (Name im Verlauf)
 *  zaehlerstand { id, zaehlerId, nr, wert, datum, notiz, quelle, erstelltAm }
 *  frist       { id, fahrzeugId, komponenteId|null, erstelltAm }            (Angaben im Verlauf)
 *  verlauf     { id, objektTyp, objektId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  durchfuehrung { id, fristId, datum, zaehlerstand, notiz, art, quelle, erstelltAm }
 *  dokument    { id, fahrzeugId, komponenteId|null, erstelltAm }            (Angaben im Verlauf)
 *  datei       { id, dokumentId, name, mime, groesse, inhalt, erstelltAm }  (inhalt = die Datei selbst)
 *
 * "werte" enthält Bezeichnung und alle Felder. Der aktuelle Stand ist der
 * Eintrag mit der höchsten Nummer.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  function neueId(praefix) {
    var c = global.crypto;
    if (c && typeof c.randomUUID === 'function') return praefix + '-' + c.randomUUID();
    return praefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function Daten(speicher, optionen) {
    this.speicher = speicher;
    this.jetzt = (optionen && optionen.jetzt) || function () { return new Date().toISOString(); };
    this.datenraumId = null;
  }

  /* Beim ersten Start entsteht der eigene Datenraum auf diesem Gerät. */
  Daten.prototype.starten = function () {
    var self = this;
    return this.speicher.alle('datenraeume').then(function (liste) {
      if (liste.length) { self.datenraumId = liste[0].id; return liste[0]; }
      var dr = { id: neueId('dr'), name: 'Mein Datenraum', erstelltAm: self.jetzt() };
      return self.speicher.speichern('datenraeume', dr).then(function () {
        self.datenraumId = dr.id;
        return dr;
      });
    });
  };

  /* ---------- Prüfen und in saubere Werte umwandeln ---------- */
  function optWert(o) { return typeof o === 'string' ? o : o.wert; }

  function pruefeWerte(felder, roh, jahr, optionen) {
    var ohneBez = !!(optionen && optionen.ohneBezeichnung);
    var werte = {};
    var fehler = {};
    roh = roh || {};

    if (!ohneBez) {
      var bez = String(roh.bezeichnung == null ? '' : roh.bezeichnung).trim();
      if (!bez) fehler.bezeichnung = 'Bitte eine Bezeichnung eingeben, zum Beispiel „Fahrzeug A“.';
      werte.bezeichnung = bez;
    }

    felder.forEach(function (f) {
      if (f.typ === 'liste') {
        var zeilen = Array.isArray(roh[f.key]) ? roh[f.key] : [];
        var sauber = [];
        zeilen.forEach(function (z) {
          var n = String(z && z.name != null ? z.name : '').trim();
          var w = String(z && z.wert != null ? z.wert : '').trim();
          if (!n && !w) return;
          if (!n || !w) fehler[f.key] = 'Bitte bei jedem Merkmal Name und Wert eingeben.';
          sauber.push({ name: n, wert: w });
        });
        werte[f.key] = sauber;
        return;
      }

      var v = roh[f.key];
      v = (v === undefined || v === null) ? '' : v;
      if (typeof v === 'string') v = v.trim();

      if (f.typ === 'text') { werte[f.key] = v === '' ? null : String(v); return; }

      if (f.typ === 'auswahl') {
        if (v === '') { werte[f.key] = null; return; }
        if (!f.optionen.some(function (o) { return optWert(o) === v; })) { fehler[f.key] = 'Bitte eine Möglichkeit aus der Liste wählen.'; }
        werte[f.key] = v;
        return;
      }

      if (f.typ === 'datum') {
        if (v === '') { werte[f.key] = null; return; }
        var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
        var d = m ? new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])) : null;
        if (!d || d.getUTCFullYear() !== +m[1] || d.getUTCMonth() !== +m[2] - 1 || d.getUTCDate() !== +m[3]) {
          fehler[f.key] = 'Bitte ein gültiges Datum eingeben.';
          werte[f.key] = null;
        } else { werte[f.key] = v; }
        return;
      }

      /* zahl und ganzzahl: Komma oder Punkt als Dezimalzeichen erlaubt */
      if (v === '') { werte[f.key] = null; return; }
      var text = String(v).replace(/\s/g, '').replace(',', '.');
      var n = /^-?\d+(\.\d+)?$/.test(text) ? Number(text) : NaN;
      if (isNaN(n)) {
        fehler[f.key] = f.typ === 'ganzzahl' ? 'Bitte eine ganze Zahl eingeben.' : 'Bitte eine Zahl eingeben, zum Beispiel 2,5.';
        werte[f.key] = null;
        return;
      }
      if (f.typ === 'ganzzahl' && Math.floor(n) !== n) { fehler[f.key] = 'Bitte eine ganze Zahl eingeben.'; werte[f.key] = null; return; }
      if (n < 0) { fehler[f.key] = 'Die Zahl darf nicht negativ sein.'; werte[f.key] = null; return; }
      if (f.key === 'baujahr' && (n < f.min || n > jahr + 1)) {
        fehler[f.key] = 'Bitte ein Baujahr zwischen ' + f.min + ' und ' + (jahr + 1) + ' eingeben.';
        werte[f.key] = null; return;
      }
      if (f.min !== undefined && f.key !== 'baujahr' && n < f.min) { fehler[f.key] = 'Der Wert muss mindestens ' + f.min + ' sein.'; werte[f.key] = null; return; }
      if (f.max !== undefined && n > f.max) { fehler[f.key] = 'Der Wert darf höchstens ' + f.max + ' sein.'; werte[f.key] = null; return; }
      werte[f.key] = n;
    });

    return { werte: werte, fehler: fehler, ok: Object.keys(fehler).length === 0 };
  }

  Daten.prototype.pruefen = function (artId, roh) {
    return pruefeWerte(MM.Fahrzeugarten.felder(artId), roh, new Date(this.jetzt()).getFullYear());
  };

  Daten.prototype.pruefenKomponente = function (roh) {
    var p = pruefeWerte(MM.Komponenten.felder(), roh, new Date(this.jetzt()).getFullYear());
    var w = p.werte;
    if (w.eingebautAm && w.ausgebautAm && w.ausgebautAm < w.eingebautAm && !p.fehler.ausgebautAm) {
      p.fehler.ausgebautAm = 'Der Ausbau kann nicht vor dem Einbau liegen.';
      p.ok = false;
    }
    return p;
  };

  /* ---------- Unterschiede zwischen zwei Ständen ---------- */
  function gleich(a, b) {
    if (a === b) return true;
    var la = Array.isArray(a) ? a : (a === null || a === undefined ? [] : null);
    var lb = Array.isArray(b) ? b : (b === null || b === undefined ? [] : null);
    if (la && lb) return JSON.stringify(la) === JSON.stringify(lb);
    return false;
  }

  function unterschiedeFelder(felder, alt, neu) {
    var liste = [{ key: 'bezeichnung', label: 'Bezeichnung' }].concat(felder);
    var res = [];
    liste.forEach(function (f) {
      var a = alt[f.key] === undefined ? null : alt[f.key];
      var n = neu[f.key] === undefined ? null : neu[f.key];
      if (!gleich(a, n)) res.push({ key: f.key, label: f.label, feld: f, alt: a, neu: n });
    });
    return res;
  }

  Daten.prototype.unterschiede = function (artId, alt, neu) {
    return unterschiedeFelder(MM.Fahrzeugarten.felder(artId), alt, neu);
  };

  function neuester(eintraege) {
    return eintraege.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
  }
  function nachNr(a, b) { return a.nr - b.nr; }

  /* ---------- Fahrzeuge ---------- */
  Daten.prototype.fahrzeugAnlegen = function (artId, roh) {
    if (!MM.Fahrzeugarten.art(artId)) {
      return Promise.resolve({ ok: false, fehler: { art: 'Bitte zuerst die Fahrzeugart wählen.' } });
    }
    var p = this.pruefen(artId, roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var jetzt = this.jetzt();
    var fahrzeug = { id: neueId('fz'), datenraumId: this.datenraumId, art: artId, erstelltAm: jetzt };
    var eintrag = { id: neueId('en'), fahrzeugId: fahrzeug.id, nr: 1, werte: p.werte,
      quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
    return this.speicher.mehrereSpeichern([
      { tabelle: 'fahrzeuge', objekt: fahrzeug },
      { tabelle: 'eintraege', objekt: eintrag }
    ]).then(function () { return { ok: true, id: fahrzeug.id }; });
  };

  /* Änderung = neuer Eintrag. Der alte bleibt unverändert erhalten. */
  Daten.prototype.fahrzeugAendern = function (fahrzeugId, roh) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      var p = self.pruefen(f.fahrzeug.art, roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var diff = self.unterschiede(f.fahrzeug.art, f.aktuell.werte, p.werte);
      if (!diff.length) return { ok: true, id: fahrzeugId, geaendert: false };
      var eintrag = { id: neueId('en'), fahrzeugId: fahrzeugId, nr: f.aktuell.nr + 1, werte: p.werte,
        quelle: 'hand', korrekturZu: f.aktuell.id, erstelltAm: self.jetzt() };
      return self.speicher.speichern('eintraege', eintrag)
        .then(function () { return { ok: true, id: fahrzeugId, geaendert: true }; });
    });
  };

  /* Alle Fahrzeuge des Datenraums, jeweils mit aktuellem Stand (Schale 1). */
  Daten.prototype.fahrzeugListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('fahrzeuge'), this.speicher.alle('eintraege')]).then(function (r) {
      var nachFahrzeug = {};
      r[1].forEach(function (e) { (nachFahrzeug[e.fahrzeugId] = nachFahrzeug[e.fahrzeugId] || []).push(e); });
      var liste = r[0].filter(function (f) { return f.datenraumId === self.datenraumId; })
        .map(function (f) { return { fahrzeug: f, aktuell: neuester(nachFahrzeug[f.id] || []) }; })
        .filter(function (x) { return x.aktuell; });
      liste.sort(function (a, b) {
        return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return liste;
    });
  };

  /* Ein Fahrzeug mit aktuellem Stand und dem ganzen Verlauf (neueste zuerst). */
  Daten.prototype.fahrzeugLaden = function (id) {
    var self = this;
    return Promise.all([this.speicher.holen('fahrzeuge', id), this.speicher.wo('eintraege', 'fahrzeugId', id)])
      .then(function (r) {
        var fahrzeug = r[0];
        if (!fahrzeug || !r[1].length) return null;
        var eintraege = r[1].slice().sort(nachNr);
        var verlauf = eintraege.map(function (e, i) {
          var vorher = i > 0 ? eintraege[i - 1] : null;
          return { eintrag: e, vorher: vorher,
            aenderungen: vorher ? self.unterschiede(fahrzeug.art, vorher.werte, e.werte) : [] };
        }).reverse();
        return { fahrzeug: fahrzeug, aktuell: eintraege[eintraege.length - 1], verlauf: verlauf };
      });
  };

  /* ---------- Komponenten (Schale 3 und tiefer) ---------- */

  /* Alle Komponenten eines Fahrzeugs mit aktuellem Stand, unsortiert. */
  Daten.prototype.komponentenListe = function (fahrzeugId) {
    return Promise.all([this.speicher.wo('komponenten', 'fahrzeugId', fahrzeugId), this.speicher.alle('komponenteneintraege')])
      .then(function (r) {
        var nach = {};
        r[1].forEach(function (e) { (nach[e.komponenteId] = nach[e.komponenteId] || []).push(e); });
        return r[0].map(function (k) {
          var eintraege = (nach[k.id] || []).slice().sort(nachNr);
          return { komponente: k, eintraege: eintraege, aktuell: eintraege[eintraege.length - 1] || null };
        }).filter(function (x) { return x.aktuell; });
      });
  };

  /* Reihenfolge: Hauptkomponenten nach Art, sonst nach Bezeichnung. */
  Daten.prototype.sortiereKomponenten = function (liste) {
    return liste.slice().sort(function (a, b) {
      var ia = MM.Komponenten.artIndex(a.komponente.art), ib = MM.Komponenten.artIndex(b.komponente.art);
      if (!a.komponente.parentId && !b.komponente.parentId && ia !== ib) return ia - ib;
      return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
  };

  /*
   * Neue Komponente. parentId = null: Hauptkomponente (art ist dann Pflicht),
   * sonst gehört sie zu der genannten Komponente (Art entfällt).
   */
  Daten.prototype.komponenteAnlegen = function (fahrzeugId, parentId, artId, roh) {
    var self = this;
    var p = this.pruefenKomponente(roh);
    var fehler = p.fehler;
    if (!parentId && !MM.Komponenten.art(artId)) fehler.art = 'Bitte zuerst die Art der Hauptkomponente wählen.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    return Promise.all([
      this.speicher.holen('fahrzeuge', fahrzeugId),
      parentId ? this.speicher.holen('komponenten', parentId) : Promise.resolve(null)
    ]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (parentId && (!r[1] || r[1].fahrzeugId !== fahrzeugId)) {
        return { ok: false, fehler: { allgemein: 'Die übergeordnete Komponente wurde nicht gefunden.' } };
      }
      var jetzt = self.jetzt();
      var k = { id: neueId('ko'), fahrzeugId: fahrzeugId, parentId: parentId || null,
        art: parentId ? null : artId, erstelltAm: jetzt };
      var e = { id: neueId('ke'), komponenteId: k.id, nr: 1, werte: p.werte,
        quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'komponenten', objekt: k },
        { tabelle: 'komponenteneintraege', objekt: e }
      ]).then(function () { return { ok: true, id: k.id }; });
    });
  };

  /* Änderung = neuer Eintrag, wie beim Fahrzeug. */
  Daten.prototype.komponenteAendern = function (komponenteId, roh) {
    var self = this;
    return this.komponenteLaden(komponenteId).then(function (c) {
      if (!c) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      var p = self.pruefenKomponente(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var diff = unterschiedeFelder(MM.Komponenten.felder(), c.aktuell.werte, p.werte);
      if (!diff.length) return { ok: true, id: komponenteId, geaendert: false };
      var e = { id: neueId('ke'), komponenteId: komponenteId, nr: c.aktuell.nr + 1, werte: p.werte,
        quelle: 'hand', korrekturZu: c.aktuell.id, erstelltAm: self.jetzt() };
      return self.speicher.speichern('komponenteneintraege', e)
        .then(function () { return { ok: true, id: komponenteId, geaendert: true }; });
    });
  };

  /*
   * Eine Komponente mit Stand, Verlauf, dem Weg von der Hauptkomponente bis
   * zu ihr (weg), den Teilen direkt darunter (kinder) und dem Fahrzeug.
   * tiefe: 3 = Hauptkomponente (Schale 3), 4 = Teil darunter, usw.
   */
  Daten.prototype.komponenteLaden = function (id) {
    var self = this;
    return this.speicher.holen('komponenten', id).then(function (k) {
      if (!k) return null;
      return Promise.all([self.komponentenListe(k.fahrzeugId), self.fahrzeugLaden(k.fahrzeugId)]).then(function (r) {
        var alle = r[0], fz = r[1];
        var nachId = {};
        alle.forEach(function (x) { nachId[x.komponente.id] = x; });
        var ich = nachId[id];
        if (!ich || !fz) return null;

        var weg = [];
        var p = ich.komponente.parentId;
        while (p && nachId[p]) { weg.unshift(nachId[p]); p = nachId[p].komponente.parentId; }

        function anzahlKinder(x) {
          return alle.filter(function (y) { return y.komponente.parentId === x.komponente.id; }).length;
        }
        var kinder = self.sortiereKomponenten(alle.filter(function (x) { return x.komponente.parentId === id; }))
          .map(function (x) { return { komponente: x.komponente, aktuell: x.aktuell, anzahlKinder: anzahlKinder(x) }; });

        var felder = MM.Komponenten.felder();
        var verlauf = ich.eintraege.map(function (e, i) {
          var vorher = i > 0 ? ich.eintraege[i - 1] : null;
          return { eintrag: e, vorher: vorher, aenderungen: vorher ? unterschiedeFelder(felder, vorher.werte, e.werte) : [] };
        }).reverse();

        return { komponente: ich.komponente, aktuell: ich.aktuell, verlauf: verlauf, weg: weg, kinder: kinder,
          fahrzeug: fz.fahrzeug, fahrzeugAktuell: fz.aktuell, tiefe: weg.length + 3 };
      });
    });
  };

  /* ---------- Hilfen für Zähler und Fristen ---------- */
  Daten.prototype.heute = function () {
    var d = new Date(this.jetzt());
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
  };

  function jahrVon(self) { return new Date(self.jetzt()).getFullYear(); }

  /* Prüft, ob Fahrzeug (und Komponente) existieren und zusammengehören. Gibt null oder einen Fehler zurück. */
  Daten.prototype.pruefeObjekt = function (fahrzeugId, komponenteId) {
    return Promise.all([
      this.speicher.holen('fahrzeuge', fahrzeugId),
      komponenteId ? this.speicher.holen('komponenten', komponenteId) : Promise.resolve(null)
    ]).then(function (r) {
      if (!r[0]) return { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' };
      if (komponenteId && (!r[1] || r[1].fahrzeugId !== fahrzeugId)) return { allgemein: 'Diese Komponente wurde nicht gefunden.' };
      return null;
    });
  };

  /* Verlauf der Angaben zu einem Objekt (Zähler, Frist): neueste zuerst, mit Unterschieden. */
  function verlaufAus(eintraege, felder) {
    var auf = eintraege.slice().sort(nachNr);
    return auf.map(function (e, i) {
      var vorher = i > 0 ? auf[i - 1] : null;
      return { eintrag: e, vorher: vorher, aenderungen: vorher ? unterschiedeFelder(felder, vorher.werte, e.werte) : [] };
    }).reverse();
  }
  function neuerVerlaufEintrag(typ, objektId, nr, werte, korrekturZu, jetzt) {
    return { id: neueId('vl'), objektTyp: typ, objektId: objektId, nr: nr, werte: werte,
      quelle: 'hand', korrekturZu: korrekturZu, erstelltAm: jetzt };
  }

  /* ---------- Zähler und Zählerstände ---------- */
  /*
   * Ein Zähler zählt Strecke (km) oder Betriebsstunden (h) und hängt am
   * Fahrzeug oder an einer einzelnen Komponente (zum Beispiel pro Motor).
   * Der Stand ist ein Verlauf von Einträgen. Der aktuelle Stand ist der
   * neueste Eintrag, ein Handeintrag hat Vorrang.
   */
  Daten.prototype.zaehlerAnlegen = function (fahrzeugId, komponenteId, art, roh) {
    var self = this;
    var p = pruefeWerte([], roh, jahrVon(this));
    var fehler = p.fehler;
    if (!MM.Fristen.zaehlerArt(art)) fehler.art = 'Bitte wählen, ob der Zähler Strecke oder Betriebsstunden zählt.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      var jetzt = self.jetzt();
      var z = { id: neueId('za'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, art: art, erstelltAm: jetzt };
      var e = neuerVerlaufEintrag('zaehler', z.id, 1, p.werte, null, jetzt);
      return self.speicher.mehrereSpeichern([{ tabelle: 'zaehler', objekt: z }, { tabelle: 'verlaeufe', objekt: e }])
        .then(function () { return { ok: true, id: z.id }; });
    });
  };

  Daten.prototype.zaehlerAendern = function (zaehlerId, roh) {
    var self = this;
    return this.zaehlerLaden(zaehlerId).then(function (z) {
      if (!z) return { ok: false, fehler: { allgemein: 'Dieser Zähler wurde nicht gefunden.' } };
      var p = pruefeWerte([], roh, jahrVon(self));
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (!unterschiedeFelder([], z.aktuell.werte, p.werte).length) return { ok: true, id: zaehlerId, geaendert: false };
      var e = neuerVerlaufEintrag('zaehler', zaehlerId, z.aktuell.nr + 1, p.werte, z.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: zaehlerId, geaendert: true }; });
    });
  };

  var FELDER_STAND = [
    { key: 'wert', label: 'Zählerstand', typ: 'zahl' },
    { key: 'datum', label: 'Abgelesen am', typ: 'datum' },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  Daten.prototype.zaehlerStandEintragen = function (zaehlerId, roh) {
    var self = this;
    var p = pruefeWerte(FELDER_STAND, roh, jahrVon(this), { ohneBezeichnung: true });
    var fehler = p.fehler, w = p.werte, heute = this.heute();
    if (w.wert === null && !fehler.wert) fehler.wert = 'Bitte den Zählerstand eingeben.';
    if (!w.datum && !fehler.datum) w.datum = heute;
    if (w.datum && w.datum > heute && !fehler.datum) fehler.datum = 'Das Datum liegt in der Zukunft.';
    return this.speicher.holen('zaehler', zaehlerId).then(function (z) {
      if (!z) return { ok: false, fehler: { allgemein: 'Dieser Zähler wurde nicht gefunden.' } };
      return self.speicher.wo('zaehlerstaende', 'zaehlerId', zaehlerId).then(function (staende) {
        var letzter = staende.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
        if (letzter && w.wert !== null && w.wert < letzter.wert && !fehler.wert) {
          var einheit = MM.Fristen.zaehlerArt(z.art).einheit;
          fehler.wert = 'Der Stand ist niedriger als der letzte Eintrag (' + MM.Hilfen.zahl(letzter.wert) + ' ' + einheit +
            ' vom ' + MM.Hilfen.datum(letzter.datum) + '). Zählerstände steigen. Wurde der Zähler getauscht, lege einen neuen Zähler an.';
        }
        if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
        var e = { id: neueId('zs'), zaehlerId: zaehlerId, nr: letzter ? letzter.nr + 1 : 1, wert: w.wert, datum: w.datum,
          notiz: w.notiz, quelle: 'hand', erstelltAm: self.jetzt() };
        return self.speicher.speichern('zaehlerstaende', e).then(function () { return { ok: true, id: e.id }; });
      });
    });
  };

  /* Alle Zähler eines Fahrzeugs mit Name, aktuellem Stand und Besitzer (Fahrzeug oder Komponente). */
  Daten.prototype.zaehlerListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([
      this.speicher.wo('zaehler', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.speicher.alle('zaehlerstaende'),
      this.komponentenListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'zaehler') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var sta = {}; r[2].forEach(function (e) { (sta[e.zaehlerId] = sta[e.zaehlerId] || []).push(e); });
      var kn = {}; r[3].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      return r[0].map(function (z) {
        var namen = (ver[z.id] || []).slice().sort(nachNr);
        var aktuell = namen[namen.length - 1];
        if (!aktuell) return null;
        var liste = (sta[z.id] || []).slice().sort(nachNr);
        var letzter = liste[liste.length - 1] || null;
        var art = MM.Fristen.zaehlerArt(z.art);
        var besitzer = z.komponenteId ? (kn[z.komponenteId] || 'Komponente') : 'Fahrzeug';
        return { zaehler: z, bezeichnung: aktuell.werte.bezeichnung, einheit: art.einheit, art: z.art,
          stand: letzter ? { wert: letzter.wert, datum: letzter.datum } : null,
          komponenteId: z.komponenteId, besitzer: besitzer,
          label: aktuell.werte.bezeichnung + ' (' + besitzer + ')' };
      }).filter(Boolean).sort(function (a, b) { return a.label.localeCompare(b.label, 'de', { numeric: true }); });
    });
  };

  Daten.prototype.zaehlerLaden = function (id) {
    var self = this;
    return this.speicher.holen('zaehler', id).then(function (z) {
      if (!z) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('zaehlerstaende', 'zaehlerId', id),
        self.fahrzeugLaden(z.fahrzeugId),
        self.komponentenListe(z.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[2]) return null;
        var staende = r[1].slice().sort(nachNr).reverse();
        var komp = z.komponenteId ? r[3].filter(function (k) { return k.komponente.id === z.komponenteId; })[0] : null;
        var art = MM.Fristen.zaehlerArt(z.art);
        return { zaehler: z, aktuell: eintraege[eintraege.length - 1], bezeichnung: eintraege[eintraege.length - 1].werte.bezeichnung,
          verlauf: verlaufAus(eintraege, []), staende: staende, stand: staende[0] || null, art: art, einheit: art.einheit,
          fahrzeug: r[2].fahrzeug, fahrzeugAktuell: r[2].aktuell, komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /* ---------- Fristen ---------- */
  Daten.prototype.pruefenFrist = function (roh, mitAusgang) {
    var p = pruefeWerte(MM.Fristen.felder(mitAusgang), roh, jahrVon(this));
    var w = p.werte, f = p.fehler;
    if (!w.kategorie && !f.kategorie) f.kategorie = 'Bitte die Art der Frist wählen.';
    if (w.kalenderWert) { if (!w.kalenderEinheit) w.kalenderEinheit = 'monate'; } else { w.kalenderEinheit = null; }
    if (!w.wirkung) w.wirkung = 'warnen';
    if (w.vorwarnTage === null || w.vorwarnTage === undefined) w.vorwarnTage = 0;
    var hatZ = !!w.zaehlerId, hatW = w.zaehlerWert !== null && w.zaehlerWert !== undefined;
    if (hatZ && !hatW && !f.zaehlerWert) f.zaehlerWert = 'Bitte angeben, nach wie viel Strecke oder Stunden die Frist fällig wird.';
    if (!hatZ && hatW && !f.zaehlerId) f.zaehlerId = 'Bitte einen Zähler wählen oder die Zählergrenze leer lassen.';
    if (hatW && w.zaehlerWert <= 0 && !f.zaehlerWert) f.zaehlerWert = 'Die Grenze muss größer als null sein.';
    if (!w.kalenderWert && !(hatZ && hatW) && !f.kalenderWert && !f.zaehlerWert && !f.zaehlerId) {
      f.kalenderWert = 'Bitte mindestens eine Grenze angeben: Zeit oder Zähler.';
    }
    if (!hatZ) { w.zaehlerId = null; w.zaehlerWert = null; w.vorwarnZaehler = null; }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Letzte Erledigung: das späteste Datum, bei gleichem Datum die zuletzt eingetragene. */
  function letzteDurchfuehrung(liste) {
    return liste.reduce(function (a, b) {
      if (!a) return b;
      if (b.datum !== a.datum) return b.datum > a.datum ? b : a;
      return b.erstelltAm >= a.erstelltAm ? b : a;
    }, null);
  }

  function statusZu(self, frist, werte, durchfuehrungen, zaehlerInfo) {
    var letzte = letzteDurchfuehrung(durchfuehrungen);
    if (!letzte) return { status: 'unbekannt', kalender: null, zaehler: null, grund: 'Es gibt noch keine Erledigung als Ausgangswert.' };
    var res = MM.Fristen.berechne({ werte: werte, letzte: letzte, stand: zaehlerInfo ? zaehlerInfo.stand : null, heute: self.heute() });
    res.letzte = letzte;
    return res;
  }

  Daten.prototype.fristAnlegen = function (fahrzeugId, komponenteId, roh) {
    var self = this;
    var p = this.pruefenFrist(roh, true);
    var w = p.werte, fehler = p.fehler, heute = this.heute();
    var zuletztAm = w.zuletztAm, zuletztStand = w.zuletztStand;
    delete w.zuletztAm; delete w.zuletztStand;
    if (zuletztAm && zuletztAm > heute && !fehler.zuletztAm) fehler.zuletztAm = 'Das Datum liegt in der Zukunft.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return self.zaehlerListe(fahrzeugId).then(function (liste) {
        var z = w.zaehlerId ? liste.filter(function (x) { return x.zaehler.id === w.zaehlerId; })[0] : null;
        if (w.zaehlerId && !z) return { ok: false, fehler: { zaehlerId: 'Dieser Zähler gehört nicht zu diesem Fahrzeug.' } };
        var basisDatum = zuletztAm || heute;
        var basisStand = zuletztStand;
        if (basisStand === null && !zuletztAm && z && z.stand) basisStand = z.stand.wert;
        var e2 = {};
        if (z && basisStand === null) e2.zuletztStand = 'Bitte den Zählerstand angeben, bei dem die Frist zuletzt erledigt wurde, oder trage zuerst einen aktuellen Zählerstand ein.';
        if (z && basisStand !== null && z.stand && basisStand > z.stand.wert) {
          e2.zuletztStand = 'Dieser Stand ist höher als der aktuelle Zählerstand (' + MM.Hilfen.zahl(z.stand.wert) + ' ' + z.einheit + '). Trage zuerst den aktuellen Zählerstand ein.';
        }
        if (Object.keys(e2).length) return { ok: false, fehler: e2 };

        var jetzt = self.jetzt();
        var fr = { id: neueId('fr'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, erstelltAm: jetzt };
        var ve = neuerVerlaufEintrag('frist', fr.id, 1, w, null, jetzt);
        var du = { id: neueId('du'), fristId: fr.id, datum: basisDatum, zaehlerstand: z ? basisStand : null,
          notiz: 'Ausgangswert bei Anlage der Frist', art: 'ausgangswert', quelle: 'hand', erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'fristen', objekt: fr }, { tabelle: 'verlaeufe', objekt: ve }, { tabelle: 'durchfuehrungen', objekt: du }
        ]).then(function () { return { ok: true, id: fr.id }; });
      });
    });
  };

  Daten.prototype.fristAendern = function (fristId, roh) {
    var self = this;
    return this.fristLaden(fristId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Diese Frist wurde nicht gefunden.' } };
      var p = self.pruefenFrist(roh, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.zaehlerListe(f.frist.fahrzeugId).then(function (liste) {
        if (p.werte.zaehlerId && !liste.some(function (x) { return x.zaehler.id === p.werte.zaehlerId; })) {
          return { ok: false, fehler: { zaehlerId: 'Dieser Zähler gehört nicht zu diesem Fahrzeug.' } };
        }
        if (!unterschiedeFelder(MM.Fristen.felder(false), f.aktuell.werte, p.werte).length) return { ok: true, id: fristId, geaendert: false };
        var e = neuerVerlaufEintrag('frist', fristId, f.aktuell.nr + 1, p.werte, f.aktuell.id, self.jetzt());
        return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: fristId, geaendert: true }; });
      });
    });
  };

  var FELDER_ERLEDIGT = [
    { key: 'datum', label: 'Erledigt am', typ: 'datum' },
    { key: 'zaehlerstand', label: 'Zählerstand dabei', typ: 'zahl', min: 0 },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  /* Eine Erledigung (Prüfung, Kontrolle, Arbeit). Sie setzt die Rechnung der Frist neu an. */
  Daten.prototype.durchfuehrungAnlegen = function (fristId, roh) {
    var self = this;
    var p = pruefeWerte(FELDER_ERLEDIGT, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, fehler = p.fehler, heute = this.heute();
    if (!w.datum && !fehler.datum) w.datum = heute;
    if (w.datum && w.datum > heute && !fehler.datum) fehler.datum = 'Das Datum liegt in der Zukunft.';
    return this.fristLaden(fristId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Diese Frist wurde nicht gefunden.' } };
      var z = f.zaehler;
      var neuerStand = null;
      if (z && !fehler.zaehlerstand) {
        if (w.zaehlerstand === null) {
          if (w.datum === heute && z.stand) w.zaehlerstand = z.stand.wert;
          else fehler.zaehlerstand = 'Bitte den Zählerstand angeben, bei dem die Frist erledigt wurde.';
        } else if (f.letzte && f.letzte.zaehlerstand !== null && f.letzte.zaehlerstand !== undefined && w.zaehlerstand < f.letzte.zaehlerstand) {
          fehler.zaehlerstand = 'Der Stand ist niedriger als bei der letzten Erledigung (' + MM.Hilfen.zahl(f.letzte.zaehlerstand) + ' ' + z.einheit + ').';
        }
        if (!fehler.zaehlerstand && w.zaehlerstand !== null && (!z.stand || w.zaehlerstand > z.stand.wert)) neuerStand = w.zaehlerstand;
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };

      var jetzt = self.jetzt();
      var du = { id: neueId('du'), fristId: fristId, datum: w.datum, zaehlerstand: w.zaehlerstand, notiz: w.notiz,
        art: 'erledigt', quelle: 'hand', erstelltAm: jetzt };
      var liste = [{ tabelle: 'durchfuehrungen', objekt: du }];
      if (neuerStand === null) return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: du.id }; });
      /* Ist der Stand höher als der bisher bekannte, wird er auch im Zähler eingetragen (eine Quelle). */
      return self.speicher.wo('zaehlerstaende', 'zaehlerId', z.zaehler.id).then(function (staende) {
        var nr = staende.reduce(function (m, e) { return Math.max(m, e.nr); }, 0) + 1;
        liste.push({ tabelle: 'zaehlerstaende', objekt: { id: neueId('zs'), zaehlerId: z.zaehler.id, nr: nr, wert: neuerStand,
          datum: w.datum, notiz: 'Bei Erledigung: ' + f.aktuell.werte.bezeichnung, quelle: 'hand', erstelltAm: jetzt } });
        return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: du.id }; });
      });
    });
  };

  /* Alle Fristen eines Fahrzeugs mit gerechnetem Stand. Sortiert: überfällig zuerst. */
  Daten.prototype.fristenListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([
      this.speicher.wo('fristen', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.speicher.alle('durchfuehrungen'),
      this.zaehlerListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'frist') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var du = {}; r[2].forEach(function (e) { (du[e.fristId] = du[e.fristId] || []).push(e); });
      var zl = {}; r[3].forEach(function (z) { zl[z.zaehler.id] = z; });
      var res = r[0].map(function (fr) {
        var eintraege = (ver[fr.id] || []).slice().sort(nachNr);
        var aktuell = eintraege[eintraege.length - 1];
        if (!aktuell) return null;
        var z = aktuell.werte.zaehlerId ? zl[aktuell.werte.zaehlerId] || null : null;
        return { frist: fr, aktuell: aktuell, zaehler: z, status: statusZu(self, fr, aktuell.werte, du[fr.id] || [], z) };
      }).filter(Boolean);
      res.sort(function (a, b) {
        var d = MM.Fristen.rang(b.status.status) - MM.Fristen.rang(a.status.status);
        return d || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true });
      });
      return res;
    });
  };

  Daten.prototype.fristLaden = function (id) {
    var self = this;
    return this.speicher.holen('fristen', id).then(function (fr) {
      if (!fr) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('durchfuehrungen', 'fristId', id),
        self.zaehlerListe(fr.fahrzeugId),
        self.fahrzeugLaden(fr.fahrzeugId),
        self.komponentenListe(fr.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[3]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        var zl = r[2];
        var z = aktuell.werte.zaehlerId ? zl.filter(function (x) { return x.zaehler.id === aktuell.werte.zaehlerId; })[0] || null : null;
        var du = r[1].slice().sort(function (a, b) { return a.datum !== b.datum ? (a.datum < b.datum ? 1 : -1) : (a.erstelltAm < b.erstelltAm ? 1 : -1); });
        var verlauf = verlaufAus(eintraege, MM.Fristen.felder(false));
        /* Zähler im Verlauf mit Namen statt Kennung zeigen */
        var namen = {}; zl.forEach(function (x) { namen[x.zaehler.id] = x.label; });
        verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'zaehlerId') { u.alt = u.alt ? (namen[u.alt] || 'unbekannter Zähler') : null; u.neu = u.neu ? (namen[u.neu] || 'unbekannter Zähler') : null; }
          });
        });
        var komp = fr.komponenteId ? r[4].filter(function (k) { return k.komponente.id === fr.komponenteId; })[0] : null;
        return { frist: fr, aktuell: aktuell, verlauf: verlauf, durchfuehrungen: du, letzte: letzteDurchfuehrung(r[1]),
          zaehler: z, zaehlerListe: zl, status: statusZu(self, fr, aktuell.werte, r[1], z),
          fahrzeug: r[3].fahrzeug, fahrzeugAktuell: r[3].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /* Pro Fahrzeug: wie viele Fristen sind überfällig oder bald fällig? */
  Daten.prototype.fristenUebersicht = function () {
    var self = this;
    return this.fahrzeugListe().then(function (liste) {
      return Promise.all(liste.map(function (x) { return self.fristenListe(x.fahrzeug.id); })).then(function (alle) {
        var res = {};
        liste.forEach(function (x, i) {
          var z = { ueberfaellig: 0, bald: 0, unbekannt: 0 };
          alle[i].forEach(function (f) { if (z[f.status.status] !== undefined) z[f.status.status]++; });
          res[x.fahrzeug.id] = z;
        });
        return res;
      });
    });
  };

  /* ---------- Dokumente ---------- */
  /*
   * Ein Dokument ist eine Datei vom Gerät oder ein Link. Die Datei liegt in
   * einer eigenen Ablage, getrennt vom Eintrag. Das Dokument selbst bleibt
   * unverändert: Wer eine andere Datei will, legt ein neues Dokument an.
   */
  Daten.prototype.pruefenDokument = function (roh, quelle) {
    var p = pruefeWerte(MM.Dokumente.felder(quelle), roh, jahrVon(this));
    var w = p.werte, f = p.fehler;
    if (!w.art && !f.art) f.art = 'Bitte die Art des Dokuments wählen.';
    if (quelle === 'link') {
      if (!String(roh.link == null ? '' : roh.link).trim()) f.link = 'Bitte den Link eingeben.';
      else {
        var l = MM.Dokumente.normalisiereLink(roh.link);
        if (!l) { if (!f.link) f.link = 'Das ist kein gültiger Link. Er soll mit http oder https beginnen, zum Beispiel https://www.beispiel.de/anleitung.pdf'; }
        else w.link = l;
      }
    } else { w.link = null; }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  function istQuotaFehler(err) {
    return !!err && (err.name === 'QuotaExceededError' || /quota/i.test(String(err.message || '')));
  }

  Daten.prototype.dokumentAnlegen = function (fahrzeugId, komponenteId, roh) {
    var self = this;
    roh = roh || {};
    var quelle = roh.quelle, datei = roh.datei, fehler = {};
    if (quelle !== 'datei' && quelle !== 'link') fehler.quelle = 'Bitte wählen, ob du eine Datei oder einen Link ablegen möchtest.';
    if (quelle === 'datei' && !(datei && typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Bitte eine Datei auswählen.';
    var rohW = Object.assign({}, roh);
    if (quelle === 'datei' && !String(rohW.bezeichnung == null ? '' : rohW.bezeichnung).trim() && datei && datei.name) {
      rohW.bezeichnung = String(datei.name).replace(/\.[^.]+$/, '');
    }
    var p = this.pruefenDokument(rohW, quelle);
    Object.keys(p.fehler).forEach(function (k) { fehler[k] = p.fehler[k]; });
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      var jetzt = self.jetzt();
      var w = p.werte;
      w.quelle = quelle;
      w.dateiName = quelle === 'datei' ? String(datei.name || 'Datei') : null;
      w.dateiTyp = quelle === 'datei' ? String(datei.type || '') : null;
      w.dateiGroesse = quelle === 'datei' ? datei.size : null;
      var d = { id: neueId('do'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, erstelltAm: jetzt };
      var liste = [
        { tabelle: 'dokumente', objekt: d },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('dokument', d.id, 1, w, null, jetzt) }
      ];
      if (quelle === 'datei') {
        liste.push({ tabelle: 'dateien', objekt: { id: neueId('da'), dokumentId: d.id, name: w.dateiName, mime: w.dateiTyp,
          groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      }
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: d.id }; })
        .catch(function (err) {
          if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei. Gib Platz frei oder wähle eine kleinere Datei.' } };
          throw err;
        });
    });
  };

  Daten.prototype.dokumentAendern = function (dokumentId, roh) {
    var self = this;
    return this.dokumentLaden(dokumentId).then(function (d) {
      if (!d) return { ok: false, fehler: { allgemein: 'Dieses Dokument wurde nicht gefunden.' } };
      var quelle = d.aktuell.werte.quelle;
      var p = self.pruefenDokument(roh, quelle);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, d.aktuell.werte, p.werte);
      if (!unterschiedeFelder(MM.Dokumente.felder(quelle), d.aktuell.werte, neu).length) return { ok: true, id: dokumentId, geaendert: false };
      var e = neuerVerlaufEintrag('dokument', dokumentId, d.aktuell.nr + 1, neu, d.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: dokumentId, geaendert: true }; });
    });
  };

  Daten.prototype.dokumentLaden = function (id) {
    var self = this;
    return this.speicher.holen('dokumente', id).then(function (d) {
      if (!d) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('dateien', 'dokumentId', id),
        self.fahrzeugLaden(d.fahrzeugId),
        self.komponentenListe(d.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[2]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        var komp = d.komponenteId ? r[3].filter(function (k) { return k.komponente.id === d.komponenteId; })[0] : null;
        var datei = r[1][0] ? { id: r[1][0].id, name: r[1][0].name, mime: r[1][0].mime, groesse: r[1][0].groesse } : null;
        return { dokument: d, aktuell: aktuell, verlauf: verlaufAus(eintraege, MM.Dokumente.felder(aktuell.werte.quelle)), datei: datei,
          fahrzeug: r[2].fahrzeug, fahrzeugAktuell: r[2].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /* Die Datei selbst (mit Inhalt), zum Öffnen oder Speichern. */
  Daten.prototype.dateiHolen = function (dokumentId) {
    return this.speicher.wo('dateien', 'dokumentId', dokumentId).then(function (l) { return l[0] || null; });
  };

  /* Alle Dokumente eines Fahrzeugs und seiner Komponenten. Zuerst das Fahrzeug, dann die Komponenten nach Name. */
  Daten.prototype.dokumenteListe = function (fahrzeugId) {
    return Promise.all([
      this.speicher.wo('dokumente', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.komponentenListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'dokument') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var kn = {}; r[2].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      var res = r[0].map(function (d) {
        var l = (ver[d.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1];
        if (!a) return null;
        return { dokument: d, aktuell: a, komponenteId: d.komponenteId, besitzer: d.komponenteId ? (kn[d.komponenteId] || 'Komponente') : null };
      }).filter(Boolean);
      res.sort(function (a, b) {
        if (!a.besitzer !== !b.besitzer) return a.besitzer ? 1 : -1;
        var o = (a.besitzer || '').localeCompare(b.besitzer || '', 'de', { numeric: true, sensitivity: 'base' });
        if (o) return o;
        var art = MM.Dokumente.artIndex(a.aktuell.werte.art) - MM.Dokumente.artIndex(b.aktuell.werte.art);
        return art || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return res;
    });
  };

  /* Wie viel Platz belegen die Dateien auf diesem Gerät? */
  Daten.prototype.dateienBelegung = function () {
    return this.speicher.alle('dateien').then(function (l) {
      return { anzahl: l.length, bytes: l.reduce(function (s, x) { return s + (x.groesse || 0); }, 0) };
    });
  };

  /* Nur für Tests auf dem eigenen Gerät. */
  Daten.prototype.allesLoeschen = function () {
    var self = this;
    return this.speicher.allesLoeschen().then(function () { return self.starten(); });
  };

  MM.Daten = { Daten: Daten };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
