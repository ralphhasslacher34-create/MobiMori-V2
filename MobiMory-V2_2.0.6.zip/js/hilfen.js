/* Kleine Helfer zum Anzeigen von Werten (deutsche Schreibweise). */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  function zahl(n) {
    return Number(n).toLocaleString('de-DE', { maximumFractionDigits: 2 });
  }

  /* "2026-11-03" -> "03.11.2026" */
  function datum(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
    return m ? m[3] + '.' + m[2] + '.' + m[1] : '';
  }

  /* "2026-11-03T12:30:00.000Z" -> "03.11.2026, 13:30" (Ortszeit des Geräts) */
  function zeitpunkt(iso) {
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return z(d.getDate()) + '.' + z(d.getMonth() + 1) + '.' + d.getFullYear() +
      ', ' + z(d.getHours()) + ':' + z(d.getMinutes());
  }

  /* Wert eines Feldes zum Anzeigen; null, wenn nichts eingetragen ist. */
  function wert(feld, w) {
    if (w === null || w === undefined || w === '') return null;
    if (feld.typ === 'liste') {
      if (!Array.isArray(w) || !w.length) return null;
      return w.map(function (z) { return z.name + ': ' + z.wert; }).join('; ');
    }
    if (feld.typ === 'auswahl' && feld.optionen) {
      for (var i = 0; i < feld.optionen.length; i++) {
        var o = feld.optionen[i];
        if (typeof o === 'object' && o.wert === w) return o.label;
      }
    }
    if (feld.typ === 'datum') return datum(w);
    if (feld.typ === 'zahl') return zahl(w) + (feld.einheit ? ' ' + feld.einheit : '');
    if (feld.typ === 'ganzzahl') return String(w);
    return String(w);
  }

  /* 1536 -> "1,5 KB", 5242880 -> "5 MB" */
  function groesse(bytes) {
    var n = Number(bytes);
    if (!isFinite(n) || n < 0) return '';
    if (n < 1024) return n + ' Byte';
    if (n < 1024 * 1024) return zahl(n / 1024) + ' KB';
    if (n < 1024 * 1024 * 1024) return zahl(n / 1024 / 1024) + ' MB';
    return zahl(n / 1024 / 1024 / 1024) + ' GB';
  }

  MM.Hilfen = { groesse: groesse, zahl: zahl, datum: datum, zeitpunkt: zeitpunkt, wert: wert };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
