/*
 * Orte, Standorte, Gebiete und Regeln (Stufe 1).
 *
 * Aus den V2-Festlegungen:
 *  - Orte und Standorte gehören dem eigenen Datenraum des Nutzers.
 *    Hierarchie: Ort -> Standort (zum Beispiel Hafen -> Liegeplatz 12).
 *  - Gebiete sind allgemeine Regeln-Träger: Ein Gebiet (zum Beispiel
 *    „Kroatien, Adria“) trägt Wenn-dann-Regeln.
 *  - Eine Regel: WENN Gebiet (Revier), Fahrzeugart und Ausrüstung passen,
 *    DANN genügt eine der gewählten Nachweisarten.
 *  - Stufe 1: nur eigene Regeln, „von dir eingetragen“. Quelle und Prüfdatum
 *    je Regel sowie weitere Länder kommen in Stufe 2 und 3.
 *  - Die App trifft keine rechtliche Aussage.
 *
 * Hier steht nur Beschreibung und Rechnung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var JA_NEIN = [{ wert: 'ja', label: 'Ja' }, { wert: 'nein', label: 'Nein' }];

  function ortFelder() {
    return [
      { key: 'land', label: 'Land', typ: 'text', hilfe: 'Freiwillig, zum Beispiel „Kroatien“' },
      { key: 'notiz', label: 'Notiz', typ: 'text' }
    ];
  }

  function standortFelder() {
    return [
      { key: 'standortart', label: 'Art', typ: 'text', hilfe: 'Freiwillig, zum Beispiel „Liegeplatz“, „Stellplatz“ oder „Garage“' },
      { key: 'notiz', label: 'Notiz', typ: 'text' }
    ];
  }

  function gebietFelder() {
    return [
      { key: 'notiz', label: 'Notiz', typ: 'text' }
    ];
  }

  /* Text zur Herkunft. Stufe 1 kennt nur eigene Einträge. */
  function herkunftText() {
    return 'von dir eingetragen';
  }

  /* Ist die Ausrüstung am Fahrzeug eingetragen? Gesucht wird in den Namen der Komponenten,
     die nicht ausgebaut sind. Groß- und Kleinschreibung zählt nicht, ein Teil des Namens genügt. */
  function ausruestungVorhanden(suchtext, komponentenNamen) {
    var s = String(suchtext || '').trim().toLowerCase();
    if (!s) return true;
    return komponentenNamen.some(function (n) { return String(n || '').toLowerCase().indexOf(s) >= 0; });
  }

  /*
   * Welche Regeln eines Gebiets gelten für dieses Fahrzeug?
   *  p.regeln       [{ id, bezeichnung, fahrzeugArten:[id], ausruestung, artIds:[id], gilt }]  nur die des gewählten Gebiets
   *  p.fahrzeugArt  Art des Fahrzeugs (zum Beispiel 'boot')
   *  p.komponentenNamen  Namen der eingebauten Komponenten des Fahrzeugs
   * Ergebnis: { greifen: [...], nichtGreifen: [{ regel, grund }] }
   * Abgeschaltete Regeln (gilt = 'nein') werden gar nicht erst genannt.
   */
  function regelnAuswerten(p) {
    var greifen = [], nicht = [];
    p.regeln.filter(function (r) { return r.gilt !== 'nein'; }).forEach(function (r) {
      var arten = r.fahrzeugArten || [];
      if (arten.length && arten.indexOf(p.fahrzeugArt) < 0) {
        nicht.push({ regel: r, grund: 'gilt nur für ' + arten.map(function (a) { var x = MM.Fahrzeugarten.art(a); return x ? x.name : a; }).join(', ') });
        return;
      }
      if (r.ausruestung && !ausruestungVorhanden(r.ausruestung, p.komponentenNamen)) {
        nicht.push({ regel: r, grund: 'gilt nur mit „' + r.ausruestung + '“, am Fahrzeug ist aber keine Komponente mit diesem Namen eingetragen' });
        return;
      }
      greifen.push(r);
    });
    return { greifen: greifen, nichtGreifen: nicht };
  }

  MM.Orte = {
    JA_NEIN: JA_NEIN,
    ortFelder: ortFelder, standortFelder: standortFelder, gebietFelder: gebietFelder,
    herkunftText: herkunftText, ausruestungVorhanden: ausruestungVorhanden, regelnAuswerten: regelnAuswerten
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
