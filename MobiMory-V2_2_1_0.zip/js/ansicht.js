/*
 * Ansicht: was der Nutzer sieht.
 *
 * Seiten (Adresse hinter dem #):
 *   #/                         Startseite
 *   #/auswahl                  Hauptmenü (Stammdaten, Funktionen, Einstellungen)
 *   #/stammdaten               Stammdaten (Fahrzeuge, Personen, Tiere, Nachweisarten, Orte, Gebiete)
 *   #/fahrzeuge                Meine Fahrzeuge (Schale 1)
 *   #/neu-im-programm          Neu im Programm
 *   #/einstellungen            Einstellungen
 *   #/fahrzeug/<id>/komponente/neu   Hauptkomponente anlegen
 *   #/komponente/<id>          Komponente (Schale 3 und tiefer)
 *   #/komponente/<id>/neu      Teil darunter anlegen
 *   #/komponente/<id>/aendern  Komponente ändern
 *   #/frist/<id>               Frist (auch /erledigt und /aendern)
 *   #/zaehler/<id>             Zähler (auch /stand und /aendern)
 *   #/fahrzeug/<id>/frist/neu, /zaehler/neu und #/komponente/<id>/frist/neu, /zaehler/neu
 *   #/dokument/<id>            Dokument (auch /aendern)
 *   #/fahrzeug/<id>/dokumente  alle Dokumente eines Fahrzeugs
 *   #/fahrzeug/<id>/dokument/neu und #/komponente/<id>/dokument/neu
 *   #/personen, #/tiere (auch /neu), #/person/<id>, #/tier/<id> (auch /aendern, /nachweis/neu)
 *   #/nachweis/<id>           Nachweis (auch /aendern); #/fahrzeug/<id>/nachweis/neu
 *   #/nachweisarten           offene Liste der Nachweisarten; /vorschlaege; #/nachweisart/<id>, /neu, /aendern
 *   #/funktionen, #/aktivitaeten, #/aktivitaet/<id> (auch /aendern, /stornieren, /besatzung/neu, /verantwortung)
 *   #/besatzung/<id>/aendern, #/aktivitaetsarten, #/aktivitaetsart/<id>/aendern
 *   #/fahrzeug/<id>/anforderung/neu, #/anforderung/<id>/aendern
 *   #/orte (auch /neu), #/ort/<id> (auch /aendern, /standort/neu), #/standort/<id>/aendern
 *   #/gebiete (auch /neu), #/gebiet/<id> (auch /aendern, /regel/neu), #/regel/<id>/aendern
 *   #/fahrzeug/<id>/heimatstandort
 *   #/einstellungen/sichern, #/einstellungen/wiederherstellen
 *   #/neu                      Fahrzeug anlegen
 *   #/fahrzeug/<id>            Fahrzeug mit äußerer Hülle (Schale 2)
 *   #/fahrzeug/<id>/aendern    Angaben ändern
 *
 * Alle Texte kommen mit textContent in die Seite, nie als HTML.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  var doc = global.document;

  var daten = null;
  var wurzel = null;
  var meldung = null; /* wird einmal auf der nächsten Seite gezeigt */

  /* ---------- kleine Bauhelfer ---------- */
  function anhaengen(el, kind) {
    if (kind === null || kind === undefined || kind === false) return;
    if (Array.isArray(kind)) { kind.forEach(function (k) { anhaengen(el, k); }); return; }
    if (typeof kind === 'string' || typeof kind === 'number') { el.appendChild(doc.createTextNode(String(kind))); return; }
    el.appendChild(kind);
  }
  function h(tag, attrs) {
    var el = doc.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) return;
        if (k === 'text') el.textContent = v;
        else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
        else if (k === 'value') el.value = v;
        else el.setAttribute(k, v === true ? '' : v);
      });
    }
    for (var i = 2; i < arguments.length; i++) anhaengen(el, arguments[i]);
    return el;
  }

  function kopf() {
    return h('header', { class: 'kopf' },
      h('a', { href: '#/auswahl' }, h('img', { class: 'marke', src: 'icons/icon.svg', alt: '', width: '32', height: '32' }), 'MobiMory'),
      h('span', { class: 'version', text: 'Version ' + MM.VERSION }));
  }

  function fuss() {
    return h('footer', { class: 'fuss' }, h('p', { text: MM.Texte.COPYRIGHT }));
  }

  /* Wo-bin-ich-Zeile: Liste aus [Text, Adresse]; der letzte Eintrag hat keine Adresse. */
  function krumen(liste) {
    var nav = h('nav', { class: 'krumen', 'aria-label': 'Wo du bist' });
    liste.forEach(function (k, i) {
      if (i) nav.appendChild(doc.createTextNode(' › '));
      nav.appendChild(k[1] ? h('a', { href: k[1], text: k[0] }) : doc.createTextNode(k[0]));
    });
    return nav;
  }
  var WEG_FAHRZEUGE = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Fahrzeuge', '#/fahrzeuge']];

  function seite(titel, inhalt, leiste) {
    doc.title = titel + ' – MobiMory';
    wurzel.textContent = '';
    var main = h('main', { class: 'inhalt', id: 'inhalt' });
    if (meldung) { main.appendChild(h('p', { class: 'meldung', role: 'status', text: meldung })); meldung = null; }
    anhaengen(main, inhalt);
    wurzel.appendChild(kopf());
    wurzel.appendChild(main);
    wurzel.appendChild(fuss());
    if (leiste) wurzel.appendChild(leiste);
    var h1 = main.querySelector('h1');
    if (h1) { h1.setAttribute('tabindex', '-1'); h1.focus({ preventScroll: true }); }
    global.scrollTo(0, 0);
  }

  function schild(artId, kennung) {
    var a = MM.Fahrzeugarten.art(artId);
    if (!kennung) return h('span', { class: 'schild leer', text: 'ohne Kennung' });
    return h('span', { class: 'schild welt-' + a.welt, text: kennung });
  }
  function kennungVon(artId, werte) { return werte[MM.Fahrzeugarten.kennungFeld(artId)] || ''; }

  /* ---------- Seite: Meine Fahrzeuge ---------- */
  function seiteListe() {
    return Promise.all([daten.fahrzeugListe(), daten.fristenUebersicht(), daten.nachweisUebersicht()]).then(function (res) {
      var liste = res[0], uebersicht = res[1], nwUebersicht = res[2];
      var inhalt = [krumen(WEG_FAHRZEUGE.slice(0, 2).concat([['Fahrzeuge']])), h('h1', { text: 'Meine Fahrzeuge' })];
      if (!liste.length) {
        inhalt.push(h('div', { class: 'leer-hinweis' },
          h('p', { text: 'Hier ist noch kein Fahrzeug.' }),
          h('p', { text: 'Lege dein erstes Fahrzeug an. Es genügt zuerst die Bezeichnung und die Fahrzeugart. Alles andere kannst du jederzeit nachtragen.' })));
      } else {
        inhalt.push(h('ul', { class: 'liste' }, liste.map(function (x) {
          var a = MM.Fahrzeugarten.art(x.fahrzeug.art);
          return h('li', null, h('a', { class: 'zeile welt-' + a.welt, href: '#/fahrzeug/' + encodeURIComponent(x.fahrzeug.id) },
            h('span', { class: 'zeile-text' },
              h('strong', { class: 'zeile-name', text: x.aktuell.werte.bezeichnung }),
              h('span', { class: 'zeile-art', text: a.name }),
              fristHinweis(uebersicht[x.fahrzeug.id]),
              nachweisHinweis(nwUebersicht[x.fahrzeug.id])),
            schild(a.id, kennungVon(a.id, x.aktuell.werte))));
        })));
      }
      seite('Meine Fahrzeuge', inhalt,
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
          h('a', { class: 'knopf', href: '#/neu', text: 'Fahrzeug anlegen' })));
    });
  }

  /* ---------- Fristen und Zähler: gemeinsame Bausteine ---------- */
  var STATUS_TEXT = { ueberfaellig: 'Überfällig', bald: 'Bald fällig', ok: 'In Ordnung', unbekannt: 'Angaben fehlen' };

  function zahlMit(n, einheit) { return MM.Hilfen.zahl(n) + (einheit ? ' ' + einheit : ''); }
  function tageText(n) { return n + (n === 1 ? ' Tag' : ' Tage'); }
  function tageDativ(n) { return n + (n === 1 ? ' Tag' : ' Tagen'); }

  function fristHinweis(u) {
    if (!u) return null;
    if (u.ueberfaellig) return h('span', { class: 'hinweis-frist status-ueberfaellig', text: u.ueberfaellig === 1 ? '1 Frist überfällig' : u.ueberfaellig + ' Fristen überfällig' });
    if (u.bald) return h('span', { class: 'hinweis-frist status-bald', text: u.bald === 1 ? '1 Frist bald fällig' : u.bald + ' Fristen bald fällig' });
    return null;
  }

  /* Die Zeilen "Zeit: ..." und "Zähler: ..." einer gerechneten Frist. */
  function fristZeilen(st, einheit) {
    var z = [];
    if (st.kalender) {
      var k = st.kalender, d = MM.Hilfen.datum(k.faelligAm);
      if (k.tage < 0) z.push({ status: k.status, text: 'Zeit: seit ' + tageDativ(-k.tage) + ' überfällig (war am ' + d + ')' });
      else if (k.tage === 0) z.push({ status: k.status, text: 'Zeit: heute fällig' });
      else z.push({ status: k.status, text: 'Zeit: fällig am ' + d + ' (in ' + tageDativ(k.tage) + ')' });
    }
    if (st.zaehler) {
      var q = st.zaehler;
      if (q.status === 'unbekannt') z.push({ status: 'unbekannt', text: 'Zähler: ' + q.grund });
      else if (q.rest < 0) z.push({ status: q.status, text: 'Zähler: um ' + zahlMit(-q.rest, einheit) + ' überschritten (fällig war bei ' + zahlMit(q.faelligBei, einheit) + ')' });
      else z.push({ status: q.status, text: 'Zähler: fällig bei ' + zahlMit(q.faelligBei, einheit) + ', noch ' + zahlMit(q.rest, einheit) });
    }
    if (!z.length && st.grund) z.push({ status: 'unbekannt', text: st.grund });
    return z;
  }

  function fristZeile(x, besitzer) {
    var st = x.status, einheit = x.zaehler ? x.zaehler.einheit : '';
    var zeilen = fristZeilen(st, einheit).sort(function (a, b) { return MM.Fristen.rang(b.status) - MM.Fristen.rang(a.status); });
    return h('li', null, h('a', { class: 'frist status-' + st.status, href: '#/frist/' + encodeURIComponent(x.frist.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: x.aktuell.werte.bezeichnung }),
        zeilen.length ? h('span', { class: 'frist-info', text: zeilen[0].text }) : null,
        besitzer ? h('span', { class: 'frist-info', text: 'an: ' + besitzer }) : null),
      h('span', { class: 'chip-status status-' + st.status, text: STATUS_TEXT[st.status] })));
  }

  /* Fristen eines Fahrzeugs oder einer Komponente. neuHash zum Beispiel '#/fahrzeug/<id>'. */
  function fristenBereich(fristen, neuHash, besitzerVon) {
    return h('section', { class: 'bereich', 'aria-label': 'Fristen' },
      h('h2', { text: 'Fristen' }),
      fristen.length ? h('ul', { class: 'fristen' }, fristen.map(function (x) { return fristZeile(x, besitzerVon ? besitzerVon(x) : null); }))
        : h('p', { class: 'leer-text', text: 'Noch keine Frist. Zum Beispiel Ölwechsel, Feuerlöscher oder Hauptuntersuchung.' }),
      h('a', { class: 'knopf leise', href: neuHash + '/frist/neu', text: 'Frist hinzufügen' }));
  }

  function zaehlerBereich(zaehler, neuHash, mitBesitzer) {
    return h('section', { class: 'bereich', 'aria-label': 'Zähler' },
      h('h2', { text: 'Zähler' }),
      zaehler.length ? h('ul', { class: 'fristen' }, zaehler.map(function (z) {
        return h('li', null, h('a', { class: 'frist zaehler-zeile', href: '#/zaehler/' + encodeURIComponent(z.zaehler.id) },
          h('span', { class: 'frist-text' },
            h('strong', { class: 'frist-name', text: z.bezeichnung }),
            mitBesitzer && z.komponenteId ? h('span', { class: 'frist-info', text: 'an: ' + z.besitzer }) : null),
          h('span', { class: 'zaehler-stand', text: z.stand ? zahlMit(z.stand.wert, z.einheit) : 'noch kein Stand' })));
      })) : h('p', { class: 'leer-text', text: 'Noch kein Zähler. Ein Zähler zählt Strecke (km) oder Betriebsstunden (h), zum Beispiel pro Motor.' }),
      h('a', { class: 'knopf leise', href: neuHash + '/zaehler/neu', text: 'Zähler hinzufügen' }));
  }


  /* ---------- Verlauf (gleich für Fahrzeuge und Komponenten) ---------- */
  function verlaufBlock(verlauf) {
    return h('details', { class: 'verlauf' },
      h('summary', { text: 'Verlauf der Eintragungen (' + verlauf.length + ')' }),
      h('ol', null, verlauf.map(function (v, i) {
        var e = v.eintrag;
        var kopfzeile = h('div', null,
          h('span', { class: 'wann', text: MM.Hilfen.zeitpunkt(e.erstelltAm) }),
          i === 0 ? h('span', { class: 'marke-aktuell', text: 'aktuell' }) : null);
        var text;
        if (!v.vorher) text = h('div', { text: 'Angelegt, per Handeingabe' });
        else text = h('div', null,
          h('span', { class: 'korrektur', text: 'Korrektur zu Eintrag vom ' + MM.Hilfen.zeitpunkt(v.vorher.erstelltAm) }),
          h('ul', null, v.aenderungen.map(function (u) {
            var alt = MM.Hilfen.wert(u.feld, u.alt), neu = MM.Hilfen.wert(u.feld, u.neu);
            return h('li', null, u.label + ': ',
              h('span', { class: 'alt', text: alt === null ? 'nicht angegeben' : alt }), ' → ',
              neu === null ? 'nicht angegeben' : neu);
          })));
        return h('li', { class: i === 0 ? 'aktuell' : null }, kopfzeile, text);
      })));
  }

  /* ---------- Liste von Komponenten (Hauptkomponenten oder Teile) ---------- */
  function komponentenKarte(x, anzahlKinder) {
    var w = x.aktuell.werte;
    var art = x.komponente.parentId ? null : MM.Komponenten.art(x.komponente.art);
    var zeile2 = [art ? art.name : null, [w.hersteller, w.modell].filter(Boolean).join(' ')].filter(Boolean).join(', ');
    return h('li', null, h('a', { class: 'teil', href: '#/komponente/' + encodeURIComponent(x.komponente.id) },
      h('span', { class: 'teil-text' },
        h('strong', { class: 'teil-name', text: w.bezeichnung }),
        zeile2 ? h('span', { class: 'teil-info', text: zeile2 }) : null),
      anzahlKinder ? h('span', { class: 'teil-zahl', text: anzahlKinder === 1 ? '1 Teil darunter' : anzahlKinder + ' Teile darunter' }) : null));
  }

  /* Eingebaute zuerst, ausgebaute eingeklappt darunter. */
  function komponentenListeBlock(eintraege, anzahlVon) {
    var drin = eintraege.filter(function (x) { return !x.aktuell.werte.ausgebautAm; });
    var raus = eintraege.filter(function (x) { return x.aktuell.werte.ausgebautAm; });
    return [
      drin.length ? h('ul', { class: 'teile' }, drin.map(function (x) { return komponentenKarte(x, anzahlVon(x)); })) : null,
      raus.length ? h('details', { class: 'ausgebaut' },
        h('summary', { text: 'Ausgebaut (' + raus.length + ')' }),
        h('ul', { class: 'teile' }, raus.map(function (x) { return komponentenKarte(x, anzahlVon(x)); }))) : null
    ];
  }

  /* ---------- Seite: Fahrzeug mit Schalen ---------- */
  function komponentenName(komp, id) {
    var k = komp.filter(function (x) { return x.komponente.id === id; })[0];
    return k ? k.aktuell.werte.bezeichnung : 'Komponente';
  }

  function seiteFahrzeug(id) {
    return Promise.all([daten.fahrzeugLaden(id), daten.komponentenListe(id), daten.fristenListe(id), daten.zaehlerListe(id), daten.dokumenteListe(id), daten.nachweiseListe('fahrzeug', id), daten.anforderungenListe(id), daten.fahrzeugStandort(id)]).then(function (r) {
      var f = r[0], komp = r[1], fristen = r[2], zaehler = r[3], dokumente = r[4], nachweise = r[5], anforderungen = r[6], heimat = r[7];
      if (!f) { return seite('Nicht gefunden', [h('h1', { text: 'Fahrzeug nicht gefunden' }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]); }
      var a = MM.Fahrzeugarten.art(f.fahrzeug.art);
      var w = f.aktuell.werte;

      var gruppen = MM.Fahrzeugarten.gruppen(a.id).map(function (g) {
        var gefuellt = [], offen = [];
        g.felder.forEach(function (fe) {
          var t = MM.Hilfen.wert(fe, w[fe.key]);
          if (t === null) offen.push(fe.label); else gefuellt.push([h('dt', { text: fe.label }), h('dd', { text: t })]);
        });
        return h('section', { class: 'gruppe' },
          h('h3', { text: g.titel }),
          gefuellt.length ? h('dl', { class: 'daten' }, gefuellt) : null,
          offen.length ? h('p', { class: 'offen', text: 'Noch nicht angegeben: ' + offen.join(', ') }) : null);
      });

      var haupt = daten.sortiereKomponenten(komp.filter(function (x) { return !x.komponente.parentId; }));
      function kinderVon(x) { return komp.filter(function (y) { return y.komponente.parentId === x.komponente.id; }).length; }
      var s3 = h('section', { class: 'schale s3 live', 'aria-label': 'Hauptkomponenten' },
        h('div', { class: 'schale-name', text: 'Dritte Schale' }),
        h('h2', { text: 'Hauptkomponenten' }),
        haupt.length ? komponentenListeBlock(haupt, kinderVon)
          : h('p', { class: 'leer-text', text: 'Noch keine Hauptkomponente. Lege zum Beispiel Motor, Getriebe oder Heizung an. Darunter lässt sich beliebig tief aufschlüsseln.' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(id) + '/komponente/neu', text: 'Hauptkomponente hinzufügen' }));

      var s2 = h('section', { class: 'schale s2', 'aria-label': 'Äußere Hülle' },
        h('div', { class: 'schale-kopf' },
          h('div', { class: 'schale-name', text: 'Zweite Schale' }),
          h('h2', { text: 'Äußere Hülle' })),
        gruppen,
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(f.aktuell.erstelltAm) + ', per Handeingabe' }),
        s3);

      var s1 = h('div', { class: 'schale s1' },
        h('div', { class: 'schale-kopf' },
          h('div', { class: 'schale-name', text: 'Erste Schale: ' + a.name }),
          h('div', { class: 'fahrzeug-kopf' },
            h('h1', { text: w.bezeichnung }),
            schild(a.id, kennungVon(a.id, w)))),
        s2);

      var verlauf = verlaufBlock(f.verlauf);

      /* Überfällige oder bald fällige Fristen stehen ganz oben, damit man sie nicht übersieht. */
      var dringend = fristen.some(function (x) { return MM.Fristen.rang(x.status.status) >= MM.Fristen.rang('bald'); });
      var fristBlock = fristenBereich(fristen, '#/fahrzeug/' + encodeURIComponent(id), function (x) { return x.frist.komponenteId ? komponentenName(komp, x.frist.komponenteId) : null; });
      fristBlock.className += ' oben';

      seite(w.bezeichnung, [
        krumen(WEG_FAHRZEUGE.concat([[w.bezeichnung]])),
        dringend ? fristBlock : null,
        s1,
        heimatstandortBereich(heimat, id),
        dringend ? null : fristBlock,
        zaehlerBereich(zaehler, '#/fahrzeug/' + encodeURIComponent(id), true),
        nachweiseBereich(nachweise, '#/fahrzeug/' + encodeURIComponent(id)),
        anforderungenBereich(anforderungen, id, MM.Fahrzeugarten.art(f.fahrzeug.art).welt),
        dokumenteBereich(dokumente.filter(function (x) { return !x.komponenteId; }), '#/fahrzeug/' + encodeURIComponent(id),
          { anzahl: dokumente.length, href: '#/fahrzeug/' + encodeURIComponent(id) + '/dokumente' }),
        verlauf
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/fahrzeuge', text: 'Zur Liste' }),
        h('a', { class: 'knopf leise', href: '#/aktivitaet/neu?fahrzeug=' + encodeURIComponent(id), text: 'Aktivität planen' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
    });
  }

  /* ---------- Seite: anlegen / ändern ---------- */
  function optWert(o) { return typeof o === 'string' ? o : o.wert; }
  function optLabel(o) { return typeof o === 'string' ? o : o.label; }

  function feldElement(f, wert, fehler, aenderung) {
    var id = 'f-' + f.key;
    var eingabe;
    if (f.typ === 'auswahl' && f.darstellung === 'wahl') {
      return h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
        h('legend', { class: 'fest-art', text: f.label }),
        f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
        fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null,
        h('div', { class: 'artwahl' }, f.optionen.map(function (o) {
          var r = h('input', { type: 'radio', name: f.key, value: optWert(o), onchange: aenderung });
          if (wert === optWert(o)) r.checked = true;
          return h('label', null, r, h('span', { text: optLabel(o) }));
        })));
    }
    if (f.typ === 'mehrfach') {
      var gew = Array.isArray(wert) ? wert : [];
      return h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
        h('legend', { class: 'fest-art', text: f.label }),
        f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
        h('div', { class: 'artwahl' }, f.optionen.map(function (o) {
          var c = h('input', { type: 'checkbox', name: f.key, value: optWert(o) });
          if (gew.indexOf(optWert(o)) >= 0) c.checked = true;
          return h('label', null, c, h('span', { text: optLabel(o) }));
        })),
        fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null);
    }
    if (f.typ === 'datei') {
      return h('div', { class: 'feld' + (fehler ? ' hat-fehler' : '') },
        h('label', { for: id, text: f.label }),
        f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
        h('div', { class: 'eingabe' }, h('input', { id: id, name: f.key, type: 'file', accept: f.accept || null, onchange: aenderung })),
        wert && wert.name ? h('p', { class: 'gewaehlt', text: 'Gewählt: ' + wert.name + (wert.size ? ' (' + MM.Hilfen.groesse(wert.size) + ')' : '') }) : null,
        fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null);
    }
    if (f.typ === 'auswahl') {
      eingabe = h('select', { id: id, name: f.key, onchange: aenderung },
        h('option', { value: '', text: f.leerText || '– bitte wählen –' }),
        f.optionen.map(function (o) { return h('option', { value: optWert(o), text: optLabel(o) }); }));
      eingabe.value = wert || '';
    } else if (f.typ === 'datum') {
      eingabe = h('input', { id: id, name: f.key, type: 'date', value: wert || '', oninput: aenderung });
    } else if (f.typ === 'zeit') {
      eingabe = h('input', { id: id, name: f.key, type: 'time', value: wert || '', oninput: aenderung });
    } else {
      eingabe = h('input', { id: id, name: f.key, type: 'text', autocomplete: 'off', autocapitalize: f.typ === 'text' ? 'sentences' : 'off',
        inputmode: f.typ === 'zahl' ? 'decimal' : (f.typ === 'ganzzahl' ? 'numeric' : null),
        value: wert === null || wert === undefined ? '' : String(wert).replace('.', f.typ === 'zahl' ? ',' : '.'),
        'aria-describedby': f.hilfe ? id + '-h' : null, 'aria-invalid': fehler ? 'true' : null, oninput: aenderung });
    }
    return h('div', { class: 'feld' + (fehler ? ' hat-fehler' : '') },
      h('label', { for: id, text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', id: id + '-h', text: f.hilfe }) : null,
      h('div', { class: 'eingabe' }, eingabe, f.einheit ? h('span', { class: 'einheit', text: f.einheit }) : null),
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null);
  }

  function seiteFormular(modus, fahrzeugId) {
    var laden = modus === 'aendern' ? daten.fahrzeugLaden(fahrzeugId) : Promise.resolve(null);
    return laden.then(function (vorhanden) {
      if (modus === 'aendern' && !vorhanden) return seiteFahrzeug(fahrzeugId);
      var zustand = {
        art: vorhanden ? vorhanden.fahrzeug.art : null,
        werte: vorhanden ? Object.assign({}, vorhanden.aktuell.werte) : {},
        fehler: {}
      };
      var titel = modus === 'aendern' ? 'Angaben ändern' : 'Fahrzeug anlegen';
      var behaelter = h('div');

      function lesen() {
        /* Eingaben aus dem Formular in den Zustand übernehmen */
        var felder = behaelter.querySelectorAll('input[name], select[name]');
        Array.prototype.forEach.call(felder, function (el) {
          if (el.type === 'radio') return;
          zustand.werte[el.name] = el.value;
        });
      }

      function speichern(ev) {
        ev.preventDefault();
        lesen();
        var p = modus === 'aendern'
          ? daten.fahrzeugAendern(fahrzeugId, zustand.werte)
          : daten.fahrzeugAnlegen(zustand.art, zustand.werte);
        p.then(function (r) {
          if (!r.ok) {
            zustand.fehler = r.fehler;
            zeichne();
            var ersterFehler = behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten');
            if (ersterFehler) { ersterFehler.focus ? ersterFehler.focus() : null; }
            return;
          }
          meldung = modus === 'aendern'
            ? (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.')
            : 'Fahrzeug angelegt.';
          global.location.hash = '#/fahrzeug/' + encodeURIComponent(r.id);
        }).catch(fehlerSeite);
      }

      function zeichne() {
        behaelter.textContent = '';
        var teile = [];
        if (modus === 'neu' && !zustand.art) {
          teile.push(h('p', { text: 'Wähle zuerst die Fahrzeugart. Dann erscheinen die passenden Felder. Nur die Bezeichnung ist Pflicht.' }));
        }
        var fk = Object.keys(zustand.fehler);
        if (fk.length) {
          teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
            text: fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.' }));
        }

        /* Fahrzeugart: beim Anlegen wählbar, danach fest */
        if (modus === 'neu') {
          teile.push(h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
            h('legend', { class: 'fest-art', text: 'Fahrzeugart' }),
            zustand.fehler.art ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.art }) : null,
            h('div', { class: 'artwahl' }, MM.Fahrzeugarten.alle().map(function (a) {
              var r = h('input', { type: 'radio', name: 'art', value: a.id, onchange: function () {
                lesen(); zustand.art = a.id; zustand.fehler = {}; zeichne();
                var b = behaelter.querySelector('#f-bezeichnung'); if (b) b.focus({ preventScroll: true });
              } });
              if (zustand.art === a.id) r.checked = true;
              return h('label', { class: 'welt-' + a.welt }, r, h('span', { text: a.name }));
            }))));
        } else {
          teile.push(h('p', null, 'Fahrzeugart: ', h('span', { class: 'fest-art', text: MM.Fahrzeugarten.art(zustand.art).name }),
            h('span', { class: 'hilfe', text: ' (lässt sich nicht ändern)' })));
        }

        if (zustand.art) {
          teile.push(feldElement({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Wie du das Fahrzeug nennst, zum Beispiel „Fahrzeug A“' },
            zustand.werte.bezeichnung, zustand.fehler.bezeichnung));
          MM.Fahrzeugarten.gruppen(zustand.art).forEach(function (g) {
            teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
              h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }),
              g.felder.map(function (f) { return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key]); })));
          });
        }
        anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
      }

      zeichne();
      seite(titel, [
        krumen(WEG_FAHRZEUGE.concat([[titel]])),
        h('h1', { text: titel }),
        behaelter
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: modus === 'aendern' ? '#/fahrzeug/' + encodeURIComponent(fahrzeugId) : '#/fahrzeuge', text: 'Abbrechen' }),
        h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
    });
  }

  /* ---------- Seite: Komponente (Schale 3 und tiefer) ---------- */
  function komponentenKrumen(c, mitSelbst) {
    var liste = WEG_FAHRZEUGE.slice(0, 3);
    liste.push([c.fahrzeugAktuell.werte.bezeichnung, '#/fahrzeug/' + encodeURIComponent(c.fahrzeug.id)]);
    c.weg.forEach(function (x) { liste.push([x.aktuell.werte.bezeichnung, '#/komponente/' + encodeURIComponent(x.komponente.id)]); });
    if (mitSelbst) liste.push([c.aktuell.werte.bezeichnung]);
    return liste;
  }
  function adresseUeber(c) {
    var eltern = c.weg.length ? c.weg[c.weg.length - 1] : null;
    return eltern ? '#/komponente/' + encodeURIComponent(eltern.komponente.id) : '#/fahrzeug/' + encodeURIComponent(c.fahrzeug.id);
  }

  function seiteKomponente(id) {
    return daten.komponenteLaden(id).then(function (c) {
      if (!c) {
        return seite('Nicht gefunden', [h('h1', { text: 'Komponente nicht gefunden' }),
          h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
      }
      return Promise.all([daten.fristenListe(c.fahrzeug.id), daten.zaehlerListe(c.fahrzeug.id), daten.dokumenteListe(c.fahrzeug.id)]).then(function (r) {
        return zeigeKomponente(id, c, r[0], r[1], r[2]);
      });
    });
  }

  function zeigeKomponente(id, c, alleFristen, alleZaehler, alleDokumente) {
      var w = c.aktuell.werte;
      var meineFristen = alleFristen.filter(function (x) { return x.frist.komponenteId === id; });
      var meineZaehler = alleZaehler.filter(function (z) { return z.komponenteId === id; });
      var meineDokumente = alleDokumente.filter(function (x) { return x.komponenteId === id; });
      var art = c.komponente.parentId ? null : MM.Komponenten.art(c.komponente.art);
      var eltern = c.weg.length ? c.weg[c.weg.length - 1].aktuell.werte.bezeichnung : c.fahrzeugAktuell.werte.bezeichnung;

      var gruppen = MM.Komponenten.gruppen().map(function (g) {
        var gefuellt = [], offen = [];
        g.felder.forEach(function (fe) {
          var t = MM.Hilfen.wert(fe, w[fe.key]);
          if (t === null) { offen.push(fe.label); return; }
          if (fe.typ === 'liste') {
            w[fe.key].forEach(function (z) { gefuellt.push([h('dt', { text: z.name }), h('dd', { text: z.wert })]); });
          } else gefuellt.push([h('dt', { text: fe.label }), h('dd', { text: t })]);
        });
        return h('section', { class: 'gruppe' },
          h('h3', { text: g.titel }),
          gefuellt.length ? h('dl', { class: 'daten' }, gefuellt) : null,
          offen.length ? h('p', { class: 'offen', text: 'Noch nicht angegeben: ' + offen.join(', ') }) : null);
      });

      var teile = h('section', { class: 'teile-block' },
        h('h2', { text: 'Teile darunter' }),
        c.kinder.length ? komponentenListeBlock(c.kinder, function (x) { return x.anzahlKinder; })
          : h('p', { class: 'leer-text', text: 'Noch kein Teil darunter. Du kannst beliebig tief weiter aufschlüsseln.' }),
        h('a', { class: 'knopf', href: '#/komponente/' + encodeURIComponent(id) + '/neu', text: 'Teil hinzufügen' }));

      var spaeter = h('section', { class: 'schale s3', 'aria-label': 'Folgt' },
        h('p', { text: 'Kosten und Nachweise zu diesem Teil folgen in späteren Schritten.' }));

      var karte = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Schale ' + c.tiefe + (art ? ': ' + art.name : ': Teil') }),
        h('h1', { text: w.bezeichnung }),
        h('p', { class: 'gehoert', text: 'gehört zu: ' + eltern }),
        w.ausgebautAm ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Ausgebaut am ' + MM.Hilfen.datum(w.ausgebautAm) + '. Dieses Teil ist nicht mehr im Fahrzeug.' }) : null,
        gruppen,
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(c.aktuell.erstelltAm) + ', per Handeingabe' }),
        teile,
        fristenBereich(meineFristen, '#/komponente/' + encodeURIComponent(id), null),
        zaehlerBereich(meineZaehler, '#/komponente/' + encodeURIComponent(id), false),
        dokumenteBereich(meineDokumente, '#/komponente/' + encodeURIComponent(id), null),
        spaeter);

      seite(w.bezeichnung, [krumen(komponentenKrumen(c, true)), karte, verlaufBlock(c.verlauf)],
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: adresseUeber(c), text: 'Zurück' }),
          h('a', { class: 'knopf', href: '#/komponente/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
  }

  /* ---------- Seite: Komponente anlegen / ändern ---------- */
  function merkmaleElement(f, zeilen, fehler, hinzu, weg) {
    return h('fieldset', { class: 'feld liste' + (fehler ? ' hat-fehler' : '') },
      h('legend', { class: 'feld-label', text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
      h('div', { class: 'merkmale' }, zeilen.map(function (z, i) {
        return h('div', { class: 'merkmal-zeile' },
          h('input', { class: 'merkmal-name', type: 'text', autocomplete: 'off', placeholder: 'Merkmal', 'aria-label': 'Merkmal ' + (i + 1), value: z.name }),
          h('input', { class: 'merkmal-wert', type: 'text', autocomplete: 'off', placeholder: 'Wert', 'aria-label': 'Wert ' + (i + 1), value: z.wert }),
          h('button', { type: 'button', class: 'knopf leise klein', text: 'Entfernen', onclick: function () { weg(i); } }));
      })),
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null,
      h('button', { type: 'button', class: 'knopf leise', text: 'Merkmal hinzufügen', onclick: hinzu }));
  }

  /* modus: 'neu-haupt' (id = Fahrzeug), 'neu-teil' (id = übergeordnete Komponente), 'aendern' (id = Komponente) */
  function seiteKomponentenFormular(modus, id) {
    var laden;
    if (modus === 'neu-haupt') laden = daten.fahrzeugLaden(id).then(function (f) { return f ? { fz: f, c: null } : null; });
    else laden = daten.komponenteLaden(id).then(function (c) { return c ? { fz: null, c: c } : null; });

    return laden.then(function (k) {
      if (!k) return seite('Nicht gefunden', [h('h1', { text: 'Nicht gefunden' }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
      var c = k.c;
      var fahrzeugId = k.fz ? k.fz.fahrzeug.id : c.fahrzeug.id;
      var titel = modus === 'neu-haupt' ? 'Hauptkomponente hinzufügen' : (modus === 'neu-teil' ? 'Teil hinzufügen' : 'Angaben ändern');

      var zurueck, weg;
      if (modus === 'neu-haupt') {
        zurueck = '#/fahrzeug/' + encodeURIComponent(fahrzeugId);
        weg = WEG_FAHRZEUGE.slice(0, 3).concat([[k.fz.aktuell.werte.bezeichnung, zurueck], [titel]]);
      } else if (modus === 'neu-teil') {
        zurueck = '#/komponente/' + encodeURIComponent(id);
        weg = komponentenKrumen(c, false).concat([[c.aktuell.werte.bezeichnung, zurueck], [titel]]);
      } else {
        zurueck = '#/komponente/' + encodeURIComponent(id);
        weg = komponentenKrumen(c, false).concat([[c.aktuell.werte.bezeichnung, zurueck], [titel]]);
      }

      var zustand = {
        art: modus === 'aendern' ? c.komponente.art : null,
        werte: modus === 'aendern' ? JSON.parse(JSON.stringify(c.aktuell.werte)) : { merkmale: [] },
        fehler: {}
      };
      if (!Array.isArray(zustand.werte.merkmale)) zustand.werte.merkmale = [];
      var istHaupt = modus === 'neu-haupt' || (modus === 'aendern' && !c.komponente.parentId);
      var behaelter = h('div');

      function lesen() {
        Array.prototype.forEach.call(behaelter.querySelectorAll('input[name], select[name]'), function (el) {
          if (el.type !== 'radio') zustand.werte[el.name] = el.value;
        });
        if (behaelter.querySelector('.merkmale')) {
          zustand.werte.merkmale = Array.prototype.map.call(behaelter.querySelectorAll('.merkmal-zeile'), function (z) {
            return { name: z.querySelector('.merkmal-name').value, wert: z.querySelector('.merkmal-wert').value };
          });
        }
      }

      function speichern(ev) {
        ev.preventDefault();
        lesen();
        var p;
        if (modus === 'neu-haupt') p = daten.komponenteAnlegen(fahrzeugId, null, zustand.art, zustand.werte);
        else if (modus === 'neu-teil') p = daten.komponenteAnlegen(fahrzeugId, id, null, zustand.werte);
        else p = daten.komponenteAendern(id, zustand.werte);
        p.then(function (r) {
          if (!r.ok) {
            zustand.fehler = r.fehler;
            zeichne();
            var erster = behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten');
            if (erster && erster.focus) erster.focus();
            return;
          }
          if (modus === 'aendern') meldung = r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.';
          else meldung = modus === 'neu-haupt' ? 'Hauptkomponente angelegt.' : 'Teil angelegt.';
          global.location.hash = zurueck;
        }).catch(fehlerSeite);
      }

      function zeichne() {
        behaelter.textContent = '';
        var teile = [];
        if (modus === 'neu-haupt' && !zustand.art) {
          teile.push(h('p', { text: 'Wähle zuerst die Art. Dann erscheinen die Felder. Nur die Bezeichnung ist Pflicht.' }));
        }
        var fk = Object.keys(zustand.fehler);
        if (fk.length) {
          teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
            text: zustand.fehler.allgemein ? zustand.fehler.allgemein : (fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.') }));
        }

        if (modus === 'neu-haupt') {
          teile.push(h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
            h('legend', { class: 'fest-art', text: 'Art der Hauptkomponente' }),
            zustand.fehler.art ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.art }) : null,
            h('div', { class: 'artwahl' }, MM.Komponenten.arten().map(function (a) {
              var r = h('input', { type: 'radio', name: 'art', value: a.id, onchange: function () {
                lesen(); zustand.art = a.id; zustand.fehler = {};
                if (!String(zustand.werte.bezeichnung || '').trim() && a.id !== 'sonstiges') zustand.werte.bezeichnung = a.name;
                zeichne();
                var b = behaelter.querySelector('#f-bezeichnung'); if (b) b.focus({ preventScroll: true });
              } });
              if (zustand.art === a.id) r.checked = true;
              return h('label', null, r, h('span', { text: a.name }));
            }))));
        } else if (modus === 'aendern' && istHaupt) {
          teile.push(h('p', null, 'Art: ', h('span', { class: 'fest-art', text: MM.Komponenten.art(zustand.art).name }),
            h('span', { class: 'hilfe', text: ' (lässt sich nicht ändern)' })));
        } else if (modus === 'neu-teil') {
          teile.push(h('p', { class: 'gehoert', text: 'gehört zu: ' + c.aktuell.werte.bezeichnung }));
        }

        if (modus !== 'neu-haupt' || zustand.art) {
          teile.push(feldElement({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text',
            hilfe: istHaupt ? 'Zum Beispiel „Motor Backbord“. Bei zwei gleichen Teilen hilft ein Zusatz.' : 'Zum Beispiel „Einspritzpumpe“' },
            zustand.werte.bezeichnung, zustand.fehler.bezeichnung));
          MM.Komponenten.gruppen().forEach(function (g) {
            teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
              h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }),
              g.felder.map(function (f) {
                if (f.typ === 'liste') {
                  return merkmaleElement(f, zustand.werte.merkmale || [], zustand.fehler[f.key],
                    function () {
                      lesen(); zustand.werte.merkmale.push({ name: '', wert: '' }); zeichne();
                      var alle = behaelter.querySelectorAll('.merkmal-name'); if (alle.length) alle[alle.length - 1].focus();
                    },
                    function (i) { lesen(); zustand.werte.merkmale.splice(i, 1); zeichne(); });
                }
                return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key]);
              })));
          });
        }
        anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
      }

      zeichne();
      seite(titel, [krumen(weg), h('h1', { text: titel }), behaelter],
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: zurueck, text: 'Abbrechen' }),
          h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
    });
  }

  /* Zeilen-Editor für eigene Angaben einer Nachweisart: Beschriftung, Typ, Stelle auf dem Papier. */
  function zeilenElement(f, zeilen, fehler, hinzu, weg) {
    return h('fieldset', { class: 'feld liste' + (fehler ? ' hat-fehler' : '') },
      h('legend', { class: 'feld-label', text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
      h('div', { class: 'zeilen-editor', 'data-feld': f.key }, zeilen.map(function (z, i) {
        return h('div', { class: 'zeile-edit', 'data-key': z.key || '' },
          h('input', { class: 'ze-label', type: 'text', autocomplete: 'off', placeholder: 'Beschriftung, z. B. Geburtsdatum', 'aria-label': 'Beschriftung ' + (i + 1), value: z.label }),
          (function () {
            var sel = h('select', { class: 'ze-typ', 'aria-label': 'Art der Angabe ' + (i + 1) }, MM.Nachweise.FELDTYPEN.map(function (t) { return h('option', { value: t.wert, text: t.label }); }));
            sel.value = z.typ || 'text'; return sel;
          })(),
          h('input', { class: 'ze-papier', type: 'text', autocomplete: 'off', placeholder: 'Stelle auf dem Papier (freiwillig)', 'aria-label': 'Stelle auf dem Papier ' + (i + 1), value: z.papier || '' }),
          h('button', { type: 'button', class: 'knopf leise klein', text: 'Entfernen', onclick: function () { weg(i); } }));
      })),
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null,
      h('button', { type: 'button', class: 'knopf leise', text: 'Angabe hinzufügen', onclick: hinzu }));
  }

  /* ---------- Einfaches Formular (für Fristen und Zähler) ---------- */
  /*
   * opts: titel, krumen, zurueck, werte, gruppen(zustand) -> [{titel, hinweis, felder}],
   *       neuzeichnenBei [Feldnamen], nachAenderung(key, zustand), intro,
   *       speichern(werte) -> Promise({ok, fehler, ...}), meldung(r), danach(r) -> Adresse
   */
  function einfachFormular(opts) {
    var zustand = { werte: JSON.parse(JSON.stringify(opts.werte || {})), fehler: {} };
    var behaelter = h('div');

    function lesen() {
      /* Mehrfachauswahl: alle angekreuzten Werte pro Feld */
      var boxen = {};
      Array.prototype.forEach.call(behaelter.querySelectorAll('input[type="checkbox"][name]'), function (el) {
        (boxen[el.name] = boxen[el.name] || []); if (el.checked) boxen[el.name].push(el.value);
      });
      Object.keys(boxen).forEach(function (k) { zustand.werte[k] = boxen[k]; });
      /* Zeilen (eigene Angaben einer Nachweisart) */
      Array.prototype.forEach.call(behaelter.querySelectorAll('.zeilen-editor[data-feld]'), function (ed) {
        zustand.werte[ed.getAttribute('data-feld')] = Array.prototype.map.call(ed.querySelectorAll('.zeile-edit'), function (z) {
          return { key: z.getAttribute('data-key') || '', label: z.querySelector('.ze-label').value, typ: z.querySelector('.ze-typ').value, papier: z.querySelector('.ze-papier').value };
        });
      });
      Array.prototype.forEach.call(behaelter.querySelectorAll('input[name], select[name]'), function (el) {
        if (el.type === 'checkbox') return;
        if (el.type === 'radio') { if (el.checked) zustand.werte[el.name] = el.value; }
        else if (el.type === 'file') { if (el.files && el.files[0]) zustand.werte[el.name] = el.files[0]; }
        else zustand.werte[el.name] = el.value;
      });
    }
    function beiAenderung(key) {
      return function () {
        lesen();
        if (opts.nachAenderung) opts.nachAenderung(key, zustand);
        zustand.fehler = {};
        zeichne();
        var el = behaelter.querySelector('[name="' + key + '"]:checked') || behaelter.querySelector('[name="' + key + '"]');
        if (el && el.focus) el.focus({ preventScroll: true });
      };
    }
    function speichern(ev) {
      ev.preventDefault();
      lesen();
      opts.speichern(zustand.werte).then(function (r) {
        if (!r.ok) {
          zustand.fehler = r.fehler || {};
          zeichne();
          var erster = behaerter_erster();
          if (erster && erster.focus) erster.focus();
          return;
        }
        meldung = opts.meldung(r);
        var ziel = opts.danach(r);
        if (global.location.hash === ziel) zeige(); else global.location.hash = ziel;
      }).catch(fehlerSeite);
    }
    function behaerter_erster() { return behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten'); }

    function zeichne() {
      behaelter.textContent = '';
      var teile = [];
      var fk = Object.keys(zustand.fehler);
      if (fk.length) {
        teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
          text: zustand.fehler.allgemein ? zustand.fehler.allgemein : (fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.') }));
      }
      opts.gruppen(zustand).forEach(function (g) {
        var felder = g.felder.map(function (f) {
          if (f.typ === 'zeilen') {
            return zeilenElement(f, zustand.werte[f.key] || [], zustand.fehler[f.key],
              function () { lesen(); (zustand.werte[f.key] = zustand.werte[f.key] || []).push({ key: '', label: '', typ: 'text', papier: '' }); zeichne();
                var alle = behaelter.querySelectorAll('.ze-label'); if (alle.length) alle[alle.length - 1].focus(); },
              function (i) { lesen(); zustand.werte[f.key].splice(i, 1); zeichne(); });
          }
          var hook = opts.neuzeichnenBei && opts.neuzeichnenBei.indexOf(f.key) >= 0 ? beiAenderung(f.key) : undefined;
          return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key], hook);
        });
        teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
          g.titel ? h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }) : null,
          g.hinweis ? h('p', { class: 'hilfe', text: g.hinweis }) : null,
          felder));
      });
      anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
    }

    zeichne();
    seite(opts.titel, [opts.krumen, h('h1', { text: opts.titel }), opts.intro || null, behaelter],
      h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: opts.zurueck, text: 'Abbrechen' }),
        h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
  }

  function nichtGefunden(text) {
    return seite('Nicht gefunden', [h('h1', { text: text }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
  }

  function ortKrumen(fz, fzId, komp) {
    var liste = WEG_FAHRZEUGE.slice(0, 3);
    liste.push([fz.werte.bezeichnung, '#/fahrzeug/' + encodeURIComponent(fzId)]);
    if (komp) liste.push([komp.aktuell.werte.bezeichnung, '#/komponente/' + encodeURIComponent(komp.komponente.id)]);
    return liste;
  }

  /* ---------- Seite: Frist ---------- */
  function seiteFrist(id) {
    return daten.fristLaden(id).then(function (f) {
      if (!f) return nichtGefunden('Frist nicht gefunden');
      var w = f.aktuell.werte, st = f.status, einheit = f.zaehler ? f.zaehler.einheit : '';
      var besitzer = f.komponente ? f.komponenteAktuell.werte.bezeichnung : f.fahrzeugAktuell.werte.bezeichnung;
      var zurueck = f.komponente ? '#/komponente/' + encodeURIComponent(f.komponente.id) : '#/fahrzeug/' + encodeURIComponent(f.fahrzeug.id);

      var regeln = [];
      if (w.kalenderWert) regeln.push('alle ' + w.kalenderWert + ' ' + (w.kalenderEinheit === 'jahre' ? (w.kalenderWert === 1 ? 'Jahr' : 'Jahre') : (w.kalenderWert === 1 ? 'Monat' : 'Monate')));
      if (w.zaehlerId && w.zaehlerWert) regeln.push('alle ' + zahlMit(w.zaehlerWert, einheit) + (f.zaehler ? ' (Zähler: ' + f.zaehler.bezeichnung + ')' : ''));
      var regelText = regeln.join(' oder ') + (regeln.length > 1 ? ', was zuerst eintritt' : '');

      var zeilen = fristZeilen(st, einheit);
      var letzte = f.letzte;
      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: MM.Fristen.labelVon(MM.Fristen.KATEGORIEN, w.kategorie) + ' an: ' + besitzer }),
        h('h1', { text: w.bezeichnung }),
        h('p', null, h('span', { class: 'chip-status gross status-' + st.status, text: STATUS_TEXT[st.status] })),
        h('ul', { class: 'status-zeilen' }, zeilen.map(function (z) { return h('li', { class: 'status-' + z.status, text: z.text }); })),
        h('section', { class: 'gruppe' }, h('h3', { text: 'Regel' }),
          h('dl', { class: 'daten' },
            h('dt', { text: 'Fällig' }), h('dd', { text: regelText }),
            h('dt', { text: 'Wirkung' }), h('dd', { text: MM.Fristen.labelVon(MM.Fristen.WIRKUNGEN, w.wirkung) }),
            h('dt', { text: 'Vorwarnung' }), h('dd', { text: [w.kalenderWert ? tageText(w.vorwarnTage || 0) : null,
              (w.zaehlerId && w.vorwarnZaehler !== null && w.vorwarnZaehler !== undefined) ? zahlMit(w.vorwarnZaehler, einheit) : null].filter(Boolean).join(' und ') || 'keine' })),
          w.wirkung !== 'warnen' ? h('p', { class: 'hinweis', text: 'Eine Sperre oder Einschränkung wirkt später bei Verleih und Aktivitäten. Das folgt in späteren Schritten.' }) : null),
        h('section', { class: 'gruppe' }, h('h3', { text: 'Zuletzt erledigt' }),
          letzte ? h('p', { text: MM.Hilfen.datum(letzte.datum) + (letzte.zaehlerstand !== null && letzte.zaehlerstand !== undefined && f.zaehler ? ', bei ' + zahlMit(letzte.zaehlerstand, einheit) : '') +
            (letzte.art === 'ausgangswert' ? ' (Ausgangswert bei Anlage der Frist)' : '') }) : h('p', { class: 'leer-text', text: 'Noch nichts eingetragen.' })),
        h('p', null, h('a', { class: 'knopf leise', href: '#/frist/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));

      var erledigungen = h('details', { class: 'verlauf' },
        h('summary', { text: 'Erledigungen (' + f.durchfuehrungen.length + ')' }),
        h('ol', null, f.durchfuehrungen.map(function (d, i) {
          return h('li', { class: i === 0 ? 'aktuell' : null },
            h('div', null, h('span', { class: 'wann', text: MM.Hilfen.datum(d.datum) }),
              d.zaehlerstand !== null && d.zaehlerstand !== undefined ? ', bei ' + zahlMit(d.zaehlerstand, einheit) : ''),
            d.notiz ? h('div', { text: d.notiz }) : null);
        })));

      seite(w.bezeichnung, [
        krumen(ortKrumen(f.fahrzeugAktuell, f.fahrzeug.id, f.komponente ? { komponente: f.komponente, aktuell: f.komponenteAktuell } : null).concat([[w.bezeichnung]])),
        kopf, erledigungen, verlaufBlock(f.verlauf)
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/frist/' + encodeURIComponent(id) + '/erledigt', text: 'Erledigt eintragen' })));
    });
  }

  /* ---------- Formular: Frist anlegen / ändern ---------- */
  /* modus: 'neu-fz' (id = Fahrzeug), 'neu-komp' (id = Komponente), 'aendern' (id = Frist) */
  function fristFormular(modus, id) {
    var laden;
    if (modus === 'neu-fz') {
      laden = Promise.all([daten.fahrzeugLaden(id), daten.zaehlerListe(id)]).then(function (r) {
        return r[0] ? { fahrzeugId: id, komponenteId: null, fz: r[0].aktuell, komp: null, zl: r[1], zurueck: '#/fahrzeug/' + encodeURIComponent(id), werte: null } : null;
      });
    } else if (modus === 'neu-komp') {
      laden = daten.komponenteLaden(id).then(function (c) {
        if (!c) return null;
        return daten.zaehlerListe(c.fahrzeug.id).then(function (zl) {
          return { fahrzeugId: c.fahrzeug.id, komponenteId: id, fz: c.fahrzeugAktuell, komp: { komponente: c.komponente, aktuell: c.aktuell },
            zl: zl, zurueck: '#/komponente/' + encodeURIComponent(id), werte: null };
        });
      });
    } else {
      laden = daten.fristLaden(id).then(function (f) {
        if (!f) return null;
        return { fahrzeugId: f.fahrzeug.id, komponenteId: f.komponente ? f.komponente.id : null, fz: f.fahrzeugAktuell,
          komp: f.komponente ? { komponente: f.komponente, aktuell: f.komponenteAktuell } : null, zl: f.zaehlerListe,
          zurueck: '#/frist/' + encodeURIComponent(id), werte: JSON.parse(JSON.stringify(f.aktuell.werte)), name: f.aktuell.werte.bezeichnung };
      });
    }
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var neu = modus !== 'aendern';
      var titel = neu ? 'Frist hinzufügen' : 'Frist ändern';
      var start = k.werte || { kategorie: 'wartung', kalenderEinheit: 'monate', wirkung: 'warnen', vorwarnTage: '30' };
      var weg = ortKrumen(k.fz, k.fahrzeugId, k.komp);
      if (!neu) weg.push([k.name, k.zurueck]);
      weg.push([titel]);

      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: k.zurueck, werte: start, neuzeichnenBei: ['zaehlerId'],
        intro: neu ? h('p', { text: 'Eine Frist kann nach Zeit, nach Zähler oder nach beidem fällig werden. Gilt beides, entscheidet, was zuerst eintritt.' }) : null,
        gruppen: function (z) {
          var gewaehlt = k.zl.filter(function (x) { return x.zaehler.id === z.werte.zaehlerId; })[0] || null;
          var einheit = gewaehlt ? gewaehlt.einheit : '';
          function f(key, extra) {
            var def = MM.Fristen.felder(true).filter(function (x) { return x.key === key; })[0];
            return Object.assign({}, def, extra || {});
          }
          var gruppen = [
            { titel: 'Frist', felder: [
              { key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Zum Beispiel „Ölwechsel“ oder „Feuerlöscher prüfen“' },
              f('kategorie', { leerText: '– bitte wählen –' }) ] },
            { titel: 'Kalender', felder: [f('kalenderWert'), f('kalenderEinheit', { leerText: 'Monate' })] }
          ];
          var zfelder = [];
          if (k.zl.length) {
            zfelder.push(f('zaehlerId', { typ: 'auswahl', leerText: 'Kein Zähler', hilfe: 'Wähle, wenn die Frist nach Strecke oder Betriebsstunden gelten soll.',
              optionen: k.zl.map(function (x) { return { wert: x.zaehler.id, label: x.label }; }) }));
            if (gewaehlt) zfelder.push(f('zaehlerWert', { einheit: einheit }));
          }
          gruppen.push({ titel: 'Zähler', hinweis: k.zl.length ? null : 'Es gibt noch keinen Zähler. Lege zuerst einen Zähler am Fahrzeug oder an der Komponente an, wenn die Frist nach Strecke oder Betriebsstunden gelten soll.', felder: zfelder });
          var wf = [f('wirkung', { leerText: 'Nur warnen' }), f('vorwarnTage')];
          if (gewaehlt) wf.push(f('vorwarnZaehler', { einheit: einheit }));
          gruppen.push({ titel: 'Wirkung und Vorwarnung', felder: wf });
          if (neu) {
            var af = [f('zuletztAm')];
            if (gewaehlt) af.push(f('zuletztStand', { einheit: einheit }));
            gruppen.push({ titel: 'Ausgangswert', hinweis: 'Ab wann soll gerechnet werden? Ohne Angabe zählt die Frist ab heute.', felder: af });
          }
          return gruppen;
        },
        speichern: function (w) { return neu ? daten.fristAnlegen(k.fahrzeugId, k.komponenteId, w) : daten.fristAendern(id, w); },
        meldung: function (r) { return neu ? 'Frist angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/frist/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Formular: Frist erledigt eintragen ---------- */
  function erledigtFormular(id) {
    return daten.fristLaden(id).then(function (f) {
      if (!f) return nichtGefunden('Frist nicht gefunden');
      var z = f.zaehler, w = f.aktuell.werte;
      var start = { datum: daten.heute(), zaehlerstand: z && z.stand ? String(z.stand.wert) : '', notiz: '' };
      var weg = ortKrumen(f.fahrzeugAktuell, f.fahrzeug.id, f.komponente ? { komponente: f.komponente, aktuell: f.komponenteAktuell } : null);
      weg.push([w.bezeichnung, '#/frist/' + encodeURIComponent(id)]); weg.push(['Erledigt eintragen']);
      var felder = [{ key: 'datum', label: 'Erledigt am', typ: 'datum' }];
      if (z) felder.push({ key: 'zaehlerstand', label: 'Zählerstand dabei', typ: 'zahl', einheit: z.einheit,
        hilfe: z.stand ? 'Aktueller Stand: ' + zahlMit(z.stand.wert, z.einheit) + '. Ein höherer Stand wird auch im Zähler eingetragen.' : 'Der Stand, als die Frist erledigt wurde.' });
      felder.push({ key: 'notiz', label: 'Notiz', typ: 'text', hilfe: 'Zum Beispiel die Werkstatt oder was gemacht wurde' });
      einfachFormular({
        titel: 'Erledigt eintragen', krumen: krumen(weg), zurueck: '#/frist/' + encodeURIComponent(id), werte: start,
        intro: h('p', { text: w.bezeichnung + ': Danach beginnt die Rechnung der Frist von vorn. Die frühere Erledigung bleibt sichtbar.' }),
        gruppen: function () { return [{ titel: null, felder: felder }]; },
        speichern: function (v) { return daten.durchfuehrungAnlegen(id, v); },
        meldung: function () { return 'Erledigt eingetragen.'; },
        danach: function () { return '#/frist/' + encodeURIComponent(id); }
      });
    });
  }

  /* ---------- Seite: Zähler ---------- */
  function seiteZaehler(id) {
    return daten.zaehlerLaden(id).then(function (z) {
      if (!z) return nichtGefunden('Zähler nicht gefunden');
      var besitzer = z.komponente ? z.komponenteAktuell.werte.bezeichnung : z.fahrzeugAktuell.werte.bezeichnung;
      var zurueck = z.komponente ? '#/komponente/' + encodeURIComponent(z.komponente.id) : '#/fahrzeug/' + encodeURIComponent(z.fahrzeug.id);
      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: z.art.label + ' an: ' + besitzer }),
        h('h1', { text: z.bezeichnung }),
        h('p', { class: 'grosse-zahl', text: z.stand ? zahlMit(z.stand.wert, z.einheit) : 'Noch kein Stand' }),
        z.stand ? h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.datum(z.stand.datum) + ', per Handeingabe' }) : h('p', { class: 'leer-text', text: 'Trage den ersten Zählerstand ein. Dann rechnen die Fristen damit.' }),
        h('p', null, h('a', { class: 'knopf leise', href: '#/zaehler/' + encodeURIComponent(id) + '/aendern', text: 'Name ändern' })));
      var staende = h('details', { class: 'verlauf', open: z.staende.length ? 'open' : null },
        h('summary', { text: 'Zählerstände (' + z.staende.length + ')' }),
        h('ol', null, z.staende.map(function (s, i) {
          return h('li', { class: i === 0 ? 'aktuell' : null },
            h('div', null, h('span', { class: 'wann', text: zahlMit(s.wert, z.einheit) }), ', ' + MM.Hilfen.datum(s.datum), i === 0 ? h('span', { class: 'marke-aktuell', text: 'aktuell' }) : null),
            s.notiz ? h('div', { text: s.notiz }) : null);
        })));
      seite(z.bezeichnung, [
        krumen(ortKrumen(z.fahrzeugAktuell, z.fahrzeug.id, z.komponente ? { komponente: z.komponente, aktuell: z.komponenteAktuell } : null).concat([[z.bezeichnung]])),
        kopf, staende, z.verlauf.length > 1 ? verlaufBlock(z.verlauf) : null
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/zaehler/' + encodeURIComponent(id) + '/stand', text: 'Neuen Stand eintragen' })));
    });
  }

  /* ---------- Formular: Zähler anlegen / Name ändern ---------- */
  /* modus: 'neu-fz' (id = Fahrzeug), 'neu-komp' (id = Komponente), 'aendern' (id = Zähler) */
  function zaehlerFormular(modus, id) {
    var laden;
    if (modus === 'neu-fz') laden = daten.fahrzeugLaden(id).then(function (f) { return f ? { fahrzeugId: id, komponenteId: null, fz: f.aktuell, komp: null, zurueck: '#/fahrzeug/' + encodeURIComponent(id) } : null; });
    else if (modus === 'neu-komp') laden = daten.komponenteLaden(id).then(function (c) { return c ? { fahrzeugId: c.fahrzeug.id, komponenteId: id, fz: c.fahrzeugAktuell, komp: { komponente: c.komponente, aktuell: c.aktuell }, zurueck: '#/komponente/' + encodeURIComponent(id) } : null; });
    else laden = daten.zaehlerLaden(id).then(function (z) { return z ? { fahrzeugId: z.fahrzeug.id, komponenteId: z.komponente ? z.komponente.id : null, fz: z.fahrzeugAktuell, komp: z.komponente ? { komponente: z.komponente, aktuell: z.komponenteAktuell } : null, zurueck: '#/zaehler/' + encodeURIComponent(id), z: z } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var neu = modus !== 'aendern';
      var titel = neu ? 'Zähler hinzufügen' : 'Zähler umbenennen';
      var weg = ortKrumen(k.fz, k.fahrzeugId, k.komp);
      if (!neu) weg.push([k.z.bezeichnung, k.zurueck]);
      weg.push([titel]);
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: k.zurueck,
        werte: neu ? { art: null, bezeichnung: '', startStand: '' } : { bezeichnung: k.z.bezeichnung },
        neuzeichnenBei: ['art'],
        nachAenderung: function (key, z) {
          if (key !== 'art') return;
          var a = MM.Fristen.zaehlerArt(z.werte.art);
          var istStandard = MM.Fristen.ZAEHLERARTEN.some(function (x) { return x.standard === z.werte.bezeichnung; });
          if (a && (!String(z.werte.bezeichnung || '').trim() || istStandard)) z.werte.bezeichnung = a.standard;
        },
        intro: neu ? h('p', { text: 'Ein Zähler zählt Strecke oder Betriebsstunden. Er kann am Fahrzeug oder an einer einzelnen Komponente hängen, zum Beispiel pro Motor.' }) : null,
        gruppen: function (z) {
          var g = [];
          var felder = [];
          if (neu) felder.push({ key: 'art', label: 'Was wird gezählt?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Fristen.ZAEHLERARTEN });
          var a = MM.Fristen.zaehlerArt(z.werte.art);
          if (!neu || a) {
            felder.push({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Zum Beispiel „Kilometerstand“ oder „Betriebsstunden Motor Backbord“' });
            if (neu) felder.push({ key: 'startStand', label: 'Aktueller Stand (kann leer bleiben)', typ: 'zahl', einheit: a.einheit });
          }
          g.push({ titel: null, felder: felder });
          return g;
        },
        speichern: function (w) {
          if (!neu) return daten.zaehlerAendern(id, w);
          return daten.zaehlerAnlegen(k.fahrzeugId, k.komponenteId, w.art, w).then(function (r) {
            if (!r.ok) return r;
            if (String(w.startStand || '').trim() === '') return r;
            return daten.zaehlerStandEintragen(r.id, { wert: w.startStand }).then(function (s) {
              r.standFehler = s.ok ? null : s.fehler.wert || s.fehler.datum || 'Der Stand konnte nicht eingetragen werden.';
              return r;
            });
          });
        },
        meldung: function (r) { return neu ? (r.standFehler ? 'Zähler angelegt. Der Stand fehlt noch: ' + r.standFehler : 'Zähler angelegt.') : (r.geaendert ? 'Gespeichert. Der frühere Name bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/zaehler/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Formular: neuer Zählerstand ---------- */
  function standFormular(id) {
    return daten.zaehlerLaden(id).then(function (z) {
      if (!z) return nichtGefunden('Zähler nicht gefunden');
      var weg = ortKrumen(z.fahrzeugAktuell, z.fahrzeug.id, z.komponente ? { komponente: z.komponente, aktuell: z.komponenteAktuell } : null);
      weg.push([z.bezeichnung, '#/zaehler/' + encodeURIComponent(id)]); weg.push(['Neuen Stand eintragen']);
      einfachFormular({
        titel: 'Neuen Stand eintragen', krumen: krumen(weg), zurueck: '#/zaehler/' + encodeURIComponent(id),
        werte: { wert: '', datum: daten.heute(), notiz: '' },
        intro: z.stand ? h('p', { text: 'Letzter Stand: ' + zahlMit(z.stand.wert, z.einheit) + ' am ' + MM.Hilfen.datum(z.stand.datum) + '.' }) : null,
        gruppen: function () {
          return [{ titel: null, felder: [
            { key: 'wert', label: 'Zählerstand', typ: 'zahl', einheit: z.einheit },
            { key: 'datum', label: 'Abgelesen am', typ: 'datum' },
            { key: 'notiz', label: 'Notiz', typ: 'text', hilfe: 'Zum Beispiel „nach dem Tanken“' }] }];
        },
        speichern: function (w) { return daten.zaehlerStandEintragen(id, w).then(function (r) { r.id = id; return r; }); },
        meldung: function () { return 'Zählerstand eingetragen.'; },
        danach: function () { return '#/zaehler/' + encodeURIComponent(id); }
      });
    });
  }

  /* ---------- Dokumente: gemeinsame Bausteine ---------- */
  function dokInfo(w) {
    return w.quelle === 'link' ? 'Link' : 'Datei, ' + MM.Hilfen.groesse(w.dateiGroesse);
  }

  function dokZeile(x, mitBesitzer) {
    var w = x.aktuell.werte;
    return h('li', null, h('a', { class: 'frist dok', href: '#/dokument/' + encodeURIComponent(x.dokument.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: w.bezeichnung }),
        h('span', { class: 'frist-info', text: dokInfo(w) }),
        mitBesitzer && x.besitzer ? h('span', { class: 'frist-info', text: 'an: ' + x.besitzer }) : null),
      h('span', { class: 'chip-status', text: MM.Dokumente.artLabel(w.art) })));
  }

  /* Dokumente eines Fahrzeugs oder einer Komponente. gesamt: Link zur Gesamtliste (nur beim Fahrzeug). */
  function dokumenteBereich(liste, neuHash, gesamt) {
    return h('section', { class: 'bereich', 'aria-label': 'Dokumente' },
      h('h2', { text: 'Dokumente' }),
      liste.length ? h('ul', { class: 'fristen' }, liste.map(function (x) { return dokZeile(x, false); }))
        : h('p', { class: 'leer-text', text: 'Noch kein Dokument. Lege zum Beispiel eine Bedienungsanleitung oder Ersatzteilliste ab, als Datei oder als Link.' }),
      gesamt && gesamt.anzahl > liste.length ? h('p', null, h('a', { href: gesamt.href, text: 'Alle Dokumente ansehen (' + gesamt.anzahl + '), auch die der Komponenten' })) : null,
      h('a', { class: 'knopf leise', href: neuHash + '/dokument/neu', text: 'Dokument hinzufügen' }));
  }

  /* Datei öffnen oder auf dem Gerät speichern. statusEl zeigt bei Bedarf einen Ersatz-Link. */
  function dateiOeffnen(lade, speichern, statusEl) {
    return lade().then(function (d) {
      if (!d) { statusEl.textContent = 'Die Datei wurde nicht gefunden.'; return; }
      var url = global.URL.createObjectURL(d.inhalt);
      statusEl.textContent = '';
      if (speichern) {
        var a = doc.createElement('a');
        a.href = url; a.download = d.name;
        doc.body.appendChild(a); a.click(); a.remove();
      } else {
        var w = global.open(url, '_blank');
        if (!w) statusEl.appendChild(h('a', { href: url, target: '_blank', rel: 'noopener', text: 'Tippe hier, um die Datei zu öffnen' }));
      }
      global.setTimeout(function () { global.URL.revokeObjectURL(url); }, 10 * 60 * 1000);
    }).catch(function (err) { statusEl.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler'); });
  }

  /* ---------- Seite: Dokument ---------- */
  function seiteDokument(id) {
    return daten.dokumentLaden(id).then(function (d) {
      if (!d) return nichtGefunden('Dokument nicht gefunden');
      var w = d.aktuell.werte;
      var besitzer = d.komponente ? d.komponenteAktuell.werte.bezeichnung : d.fahrzeugAktuell.werte.bezeichnung;
      var zurueck = d.komponente ? '#/komponente/' + encodeURIComponent(d.komponente.id) : '#/fahrzeug/' + encodeURIComponent(d.fahrzeug.id);
      var status = h('p', { class: 'oeffnen-status', role: 'status' });
      var vorschau = h('div', { class: 'vorschau' });
      var istBild = d.datei && /^image\//.test(d.datei.mime || '');
      if (istBild) {
        daten.dateiHolen(id).then(function (x) {
          if (!x) return;
          var url = global.URL.createObjectURL(x.inhalt);
          vorschau.appendChild(h('img', { src: url, alt: w.bezeichnung, class: 'vorschau-bild' }));
        });
      }
      var knoepfe = w.quelle === 'link'
        ? h('p', null, h('a', { class: 'knopf', href: w.link, target: '_blank', rel: 'noopener noreferrer', text: 'Link öffnen' }))
        : h('p', { class: 'knopfzeile' },
          h('button', { class: 'knopf', type: 'button', text: 'Öffnen', onclick: function () { dateiOeffnen(function () { return daten.dateiHolen(id); }, false, status); } }),
          h('button', { class: 'knopf leise', type: 'button', text: 'Auf dem Gerät speichern', onclick: function () { dateiOeffnen(function () { return daten.dateiHolen(id); }, true, status); } }));

      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: MM.Dokumente.artLabel(w.art) + ' an: ' + besitzer }),
        h('h1', { text: w.bezeichnung }),
        h('dl', { class: 'daten' },
          w.quelle === 'link' ? [h('dt', { text: 'Link' }), h('dd', { text: w.link })] : [
            h('dt', { text: 'Datei' }), h('dd', { text: (w.dateiName || '') + ' (' + MM.Hilfen.groesse(w.dateiGroesse) + ')' }),
            h('dt', { text: 'Gespeichert' }), h('dd', { text: 'auf diesem Gerät, auch ohne Internet' })],
          w.notiz ? [h('dt', { text: 'Notiz' }), h('dd', { text: w.notiz })] : null),
        vorschau, knoepfe, status,
        h('p', { class: 'stand', text: 'Abgelegt am ' + MM.Hilfen.zeitpunkt(d.dokument.erstelltAm) }),
        h('p', null, h('a', { class: 'knopf leise', href: '#/dokument/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));

      seite(w.bezeichnung, [
        krumen(ortKrumen(d.fahrzeugAktuell, d.fahrzeug.id, d.komponente ? { komponente: d.komponente, aktuell: d.komponenteAktuell } : null).concat([[w.bezeichnung]])),
        kopf, d.verlauf.length > 1 ? verlaufBlock(d.verlauf) : null
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' })));
    });
  }

  /* ---------- Seite: alle Dokumente eines Fahrzeugs ---------- */
  function seiteDokumente(fahrzeugId) {
    return Promise.all([daten.fahrzeugLaden(fahrzeugId), daten.dokumenteListe(fahrzeugId)]).then(function (r) {
      var f = r[0], liste = r[1];
      if (!f) return nichtGefunden('Fahrzeug nicht gefunden');
      var fzName = f.aktuell.werte.bezeichnung;
      var behaelter = h('div', { class: 'dok-gruppen' });
      var suche = h('input', { type: 'search', class: 'suche', placeholder: 'Suchen, zum Beispiel „Heizung“ oder „Ersatzteil“', 'aria-label': 'Dokumente suchen', autocomplete: 'off' });

      function zeichne() {
        var q = suche.value.trim().toLowerCase();
        behaelter.textContent = '';
        var treffer = liste.filter(function (x) {
          if (!q) return true;
          var w = x.aktuell.werte;
          return [w.bezeichnung, MM.Dokumente.artLabel(w.art), x.besitzer || fzName, w.notiz || ''].join(' ').toLowerCase().indexOf(q) >= 0;
        });
        if (!treffer.length) {
          behaelter.appendChild(h('p', { class: 'leer-text', text: liste.length ? 'Nichts gefunden.' : 'Noch kein Dokument. Du kannst es am Fahrzeug oder an jeder Komponente ablegen.' }));
          return;
        }
        var gruppen = [], zuletzt;
        treffer.forEach(function (x) {
          var key = x.komponenteId || '';
          if (key !== zuletzt) { gruppen.push({ key: key, name: x.besitzer || fzName, eintraege: [] }); zuletzt = key; }
          gruppen[gruppen.length - 1].eintraege.push(x);
        });
        gruppen.forEach(function (g) {
          var ziel = g.key ? '#/komponente/' + encodeURIComponent(g.key) : '#/fahrzeug/' + encodeURIComponent(fahrzeugId);
          behaelter.appendChild(h('section', { class: 'bereich' },
            h('h2', null, h('a', { href: ziel, text: g.name })),
            h('ul', { class: 'fristen' }, g.eintraege.map(function (x) { return dokZeile(x, false); }))));
        });
      }
      suche.addEventListener('input', zeichne);
      zeichne();

      seite('Dokumente', [
        krumen(WEG_FAHRZEUGE.concat([[fzName, '#/fahrzeug/' + encodeURIComponent(fahrzeugId)], ['Dokumente']])),
        h('h1', { text: 'Dokumente' }),
        h('p', { class: 'gehoert', text: 'Alle Dokumente von ' + fzName + ' und seinen Komponenten (' + liste.length + ')' }),
        liste.length > 3 ? suche : null,
        behaelter
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/fahrzeug/' + encodeURIComponent(fahrzeugId), text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(fahrzeugId) + '/dokument/neu', text: 'Dokument hinzufügen' })));
    });
  }

  /* ---------- Formular: Dokument ablegen / ändern ---------- */
  /* modus: 'neu-fz' (id = Fahrzeug), 'neu-komp' (id = Komponente), 'aendern' (id = Dokument) */
  function dokumentFormular(modus, id) {
    var laden;
    if (modus === 'neu-fz') laden = daten.fahrzeugLaden(id).then(function (f) { return f ? { fahrzeugId: id, komponenteId: null, fz: f.aktuell, komp: null, zurueck: '#/fahrzeug/' + encodeURIComponent(id) } : null; });
    else if (modus === 'neu-komp') laden = daten.komponenteLaden(id).then(function (c) { return c ? { fahrzeugId: c.fahrzeug.id, komponenteId: id, fz: c.fahrzeugAktuell, komp: { komponente: c.komponente, aktuell: c.aktuell }, zurueck: '#/komponente/' + encodeURIComponent(id) } : null; });
    else laden = daten.dokumentLaden(id).then(function (d) { return d ? { fahrzeugId: d.fahrzeug.id, komponenteId: d.komponente ? d.komponente.id : null, fz: d.fahrzeugAktuell, komp: d.komponente ? { komponente: d.komponente, aktuell: d.komponenteAktuell } : null, zurueck: '#/dokument/' + encodeURIComponent(id), d: d } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var neu = modus !== 'aendern';
      var titel = neu ? 'Dokument hinzufügen' : 'Dokument ändern';
      var weg = ortKrumen(k.fz, k.fahrzeugId, k.komp);
      if (!neu) weg.push([k.d.aktuell.werte.bezeichnung, k.zurueck]);
      weg.push([titel]);
      var start = neu ? { quelle: 'datei', art: 'bedienung', bezeichnung: '', notiz: '' } : JSON.parse(JSON.stringify(k.d.aktuell.werte));
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: k.zurueck, werte: start, neuzeichnenBei: ['quelle', 'datei'],
        nachAenderung: function (key, z) {
          if (key === 'datei' && z.werte.datei && !String(z.werte.bezeichnung || '').trim()) z.werte.bezeichnung = String(z.werte.datei.name).replace(/\.[^.]+$/, '');
        },
        intro: neu ? h('p', { text: 'Lege eine Datei von diesem Gerät ab, zum Beispiel ein PDF oder Foto. Sie bleibt auf dem Gerät und ist auch ohne Internet da. Oder speichere den Link zu einer Anleitung im Internet.' })
          : h('p', { text: k.d.aktuell.werte.quelle === 'datei' ? 'Die Datei selbst bleibt unverändert. Für eine andere Datei lege ein neues Dokument an.' : 'Hier kannst du Angaben und Link ändern.' }),
        gruppen: function (z) {
          var felder = [];
          if (neu) {
            felder.push({ key: 'quelle', label: 'Was möchtest du ablegen?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Dokumente.QUELLEN });
            if (z.werte.quelle === 'datei') felder.push({ key: 'datei', label: 'Datei', typ: 'datei', hilfe: 'Tippe auf „Datei auswählen“ und suche sie auf dem Gerät.' });
          }
          var quelle = neu ? z.werte.quelle : k.d.aktuell.werte.quelle;
          felder.push({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text',
            hilfe: quelle === 'datei' && neu ? 'Zum Beispiel „Heizung Bedienungsanleitung“. Bleibt das Feld leer, nimmt die App den Dateinamen.' : 'Zum Beispiel „Heizung Bedienungsanleitung“' });
          MM.Dokumente.felder(quelle).forEach(function (f) { felder.push(f); });
          return [{ titel: null, felder: felder }];
        },
        speichern: function (w) { return neu ? daten.dokumentAnlegen(k.fahrzeugId, k.komponenteId, w) : daten.dokumentAendern(id, w); },
        meldung: function (r) { return neu ? 'Dokument abgelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/dokument/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Nachweise: gemeinsame Bausteine ---------- */
  var NW_STATUS = { abgelaufen: 'Abgelaufen', bald: 'Läuft bald ab', gueltig: 'Gültig', unbefristet: 'Ohne Ablauf', unbekannt: 'Datum fehlt' };
  var NW_KLASSE = { abgelaufen: 'status-ueberfaellig', bald: 'status-bald', gueltig: 'status-ok', unbekannt: 'status-unbekannt', unbefristet: '' };

  function nachweisHinweis(u) {
    if (!u) return null;
    if (u.abgelaufen) return h('span', { class: 'hinweis-frist status-ueberfaellig', text: u.abgelaufen === 1 ? '1 Nachweis abgelaufen' : u.abgelaufen + ' Nachweise abgelaufen' });
    if (u.bald) return h('span', { class: 'hinweis-frist status-bald', text: u.bald === 1 ? '1 Nachweis läuft bald ab' : u.bald + ' Nachweise laufen bald ab' });
    return null;
  }

  function nachweisZeile(x) {
    var w = x.aktuell.werte, a = x.art.aktuell.werte, st = x.status;
    var teile = [];
    if (w.nummer) teile.push('Nr. ' + w.nummer);
    if (st.status !== 'unbefristet' && w.gueltigBis) teile.push('gültig bis ' + MM.Hilfen.datum(w.gueltigBis));
    if (w.klassen) teile.push(w.klassen);
    return h('li', null, h('a', { class: 'frist nw ' + NW_KLASSE[st.status], href: '#/nachweis/' + encodeURIComponent(x.nachweis.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: a.bezeichnung }),
        teile.length ? h('span', { class: 'frist-info', text: teile.join(', ') }) : null),
      h('span', { class: 'chip-status ' + NW_KLASSE[st.status], text: NW_STATUS[st.status] })));
  }

  function nachweiseBereich(liste, neuHash) {
    return h('section', { class: 'bereich', 'aria-label': 'Nachweise' },
      h('h2', { text: 'Nachweise' }),
      liste.length ? h('ul', { class: 'fristen' }, liste.map(nachweisZeile))
        : h('p', { class: 'leer-text', text: 'Noch kein Nachweis. Zum Beispiel Führerschein, Ausweis, Heimtierausweis oder Zulassungsbescheinigung.' }),
      h('a', { class: 'knopf leise', href: neuHash + '/nachweis/neu', text: 'Nachweis hinzufügen' }));
  }

  /* ---------- Personen und Tiere ---------- */
  var BESITZER = {
    person: {
      liste: '#/personen', einzel: '#/person/', krumen: 'Personen', schale: 'Person', titelNeu: 'Person hinzufügen', titelAendern: 'Person ändern',
      felder: function () { return MM.Personen.personFelder(); }, laden: function (id) { return daten.personLaden(id); },
      alle: function () { return daten.personenListe(); }, anlegen: function (w) { return daten.personAnlegen(w); }, aendern: function (id, w) { return daten.personAendern(id, w); },
      leer: 'Noch keine Person. Lege die Besatzung an, die du mitnimmst. Für Skipper und Fahrer zählen später die Nachweise.',
      info: function (w) { return w.funktionen && w.funktionen.length ? w.funktionen.join(', ') : 'noch keine Funktion'; },
      intro: 'Name und Funktionen genügen. Geburtsdatum und Wohnort gehören zu den Nachweisen, nicht zur Person, und bleiben auf dem Gerät.'
    },
    tier: {
      liste: '#/tiere', einzel: '#/tier/', krumen: 'Tiere', schale: 'Tier', titelNeu: 'Tier hinzufügen', titelAendern: 'Tier ändern',
      felder: function () { return MM.Personen.tierFelder(); }, laden: function (id) { return daten.tierLaden(id); },
      alle: function () { return daten.tiereListe(); }, anlegen: function (w) { return daten.tierAnlegen(w); }, aendern: function (id, w) { return daten.tierAendern(id, w); },
      leer: 'Noch kein Tier. Lege die Tiere an, die mitreisen. Heimtierausweis und Impfungen kommen als Nachweise dazu.',
      info: function (w) { return [w.tierart, w.chipnummer ? 'Chip ' + w.chipnummer : null].filter(Boolean).join(', '); },
      intro: 'Name und Tierart genügen. Heimtierausweis und Impfungen legst du danach als Nachweise an.'
    }
  };

  function seiteBesitzerListe(typ) {
    var c = BESITZER[typ];
    return Promise.all([c.alle(), daten.nachweisUebersicht()]).then(function (r) {
      var liste = r[0], u = r[1];
      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], [c.krumen]]), h('h1', { text: c.krumen })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: c.leer })));
      else inhalt.push(h('ul', { class: 'liste' }, liste.map(function (x) {
        return h('li', null, h('a', { class: 'zeile welt-' + (typ === 'person' ? 'wasser' : 'land'), href: c.einzel + encodeURIComponent(x.objekt.id) },
          h('span', { class: 'zeile-text' },
            h('strong', { class: 'zeile-name', text: x.aktuell.werte.bezeichnung }),
            h('span', { class: 'zeile-art', text: c.info(x.aktuell.werte) }),
            nachweisHinweis(u[x.objekt.id]))));
      })));
      seite(c.krumen, inhalt, h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
        h('a', { class: 'knopf', href: c.liste + '/neu', text: c.titelNeu })));
    });
  }

  function seiteBesitzer(typ, id) {
    var c = BESITZER[typ];
    return Promise.all([c.laden(id), daten.nachweiseListe(typ, id)]).then(function (r) {
      var x = r[0], nachweise = r[1];
      if (!x) return nichtGefunden(c.schale + ' nicht gefunden');
      var w = x.aktuell.werte;
      var dl = [];
      c.felder().forEach(function (f) {
        var t = MM.Hilfen.wert(f, w[f.key]);
        if (t !== null) dl.push([h('dt', { text: f.label }), h('dd', { text: t })]);
      });
      var karte = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: c.schale }),
        h('h1', { text: w.bezeichnung }),
        dl.length ? h('dl', { class: 'daten' }, dl) : h('p', { class: 'leer-text', text: 'Noch keine weiteren Angaben.' }),
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(x.aktuell.erstelltAm) + ', per Handeingabe' }),
        h('p', null, h('a', { class: 'knopf leise', href: c.einzel + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
      seite(w.bezeichnung, [
        krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], [c.krumen, c.liste], [w.bezeichnung]]),
        karte, nachweiseBereich(nachweise, c.einzel + encodeURIComponent(id)), x.verlauf.length > 1 ? verlaufBlock(x.verlauf) : null
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: c.liste, text: 'Zur Liste' }),
        h('a', { class: 'knopf', href: c.einzel + encodeURIComponent(id) + '/nachweis/neu', text: 'Nachweis hinzufügen' })));
    });
  }

  function besitzerFormular(typ, modus, id) {
    var c = BESITZER[typ];
    var laden = modus === 'aendern' ? c.laden(id) : Promise.resolve({ aktuell: { werte: { bezeichnung: '', funktionen: [] } } });
    return laden.then(function (x) {
      if (!x) return nichtGefunden(c.schale + ' nicht gefunden');
      var neu = modus === 'neu';
      var titel = neu ? c.titelNeu : c.titelAendern;
      var weg = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], [c.krumen, c.liste]];
      if (!neu) weg.push([x.aktuell.werte.bezeichnung, c.einzel + encodeURIComponent(id)]);
      weg.push([titel]);
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: neu ? c.liste : c.einzel + encodeURIComponent(id),
        werte: JSON.parse(JSON.stringify(x.aktuell.werte)),
        intro: neu ? h('p', { text: c.intro }) : null,
        gruppen: function () { return [{ titel: null, felder: [{ key: 'bezeichnung', label: 'Name', typ: 'text' }].concat(c.felder()) }]; },
        speichern: function (w) { return neu ? c.anlegen(w) : c.aendern(id, w); },
        meldung: function (r) { return neu ? c.schale + ' angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return c.einzel + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Seite: Nachweis ---------- */
  var BESITZER_HASH = { person: '#/person/', tier: '#/tier/', fahrzeug: '#/fahrzeug/' };
  function besitzerKrumen(typ, id, name) {
    if (typ === 'fahrzeug') return WEG_FAHRZEUGE.concat([[name, '#/fahrzeug/' + encodeURIComponent(id)]]);
    var c = BESITZER[typ];
    return [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], [c.krumen, c.liste], [name, c.einzel + encodeURIComponent(id)]];
  }

  function seiteNachweis(id) {
    return daten.nachweisLaden(id).then(function (n) {
      if (!n) return nichtGefunden('Nachweis nicht gefunden');
      var aw = n.art.aktuell.werte, w = n.aktuell.werte, st = n.status;
      var zurueck = BESITZER_HASH[n.nachweis.besitzerTyp] + encodeURIComponent(n.nachweis.besitzerId);
      var gefuellt = [], offen = [];
      n.felder.forEach(function (f) {
        var t = MM.Hilfen.wert(f, w[f.key]);
        if (t === null) { offen.push(f.label); return; }
        gefuellt.push([h('dt', null, f.label, f.papier ? h('span', { class: 'papier', text: ' (' + f.papier + ')' }) : null), h('dd', { text: t })]);
      });
      var status = h('p', { class: 'oeffnen-status', role: 'status' });
      var vorschau = h('div', { class: 'vorschau' });
      if (n.datei && /^image\//.test(n.datei.mime || '')) {
        daten.nachweisDateiHolen(id).then(function (x) {
          if (x) vorschau.appendChild(h('img', { src: global.URL.createObjectURL(x.inhalt), alt: 'Scan: ' + aw.bezeichnung, class: 'vorschau-bild' }));
        });
      }
      var dateiTeil = n.datei ? [
        h('section', { class: 'gruppe' }, h('h3', { text: 'Scan oder Foto' }),
          h('p', { text: n.datei.name + ' (' + MM.Hilfen.groesse(n.datei.groesse) + '). Bleibt nur auf diesem Gerät.' }),
          vorschau,
          h('p', { class: 'knopfzeile' },
            h('button', { class: 'knopf leise', type: 'button', text: 'Öffnen', onclick: function () { dateiOeffnen(function () { return daten.nachweisDateiHolen(id); }, false, status); } }),
            h('button', { class: 'knopf leise', type: 'button', text: 'Auf dem Gerät speichern', onclick: function () { dateiOeffnen(function () { return daten.nachweisDateiHolen(id); }, true, status); } })),
          status)] : null;

      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: MM.Nachweise.besitzerLabel(n.nachweis.besitzerTyp) + ': ' + n.besitzer.name }),
        h('h1', { text: aw.bezeichnung }),
        h('p', null, h('span', { class: 'chip-status gross ' + NW_KLASSE[st.status], text: NW_STATUS[st.status] }),
          st.status === 'bald' || st.status === 'gueltig' ? h('span', { class: 'frist-info', text: '  noch ' + st.tage + (st.tage === 1 ? ' Tag' : ' Tage') }) : null,
          st.status === 'abgelaufen' ? h('span', { class: 'frist-info', text: '  seit ' + (-st.tage) + (st.tage === -1 ? ' Tag' : ' Tagen') }) : null),
        gefuellt.length ? h('dl', { class: 'daten stapel' }, gefuellt) : h('p', { class: 'leer-text', text: 'Noch keine Angaben eingetragen.' }),
        offen.length ? h('p', { class: 'offen', text: 'Noch nicht angegeben: ' + offen.join(', ') }) : null,
        dateiTeil,
        h('p', { class: 'stand', text: 'Herkunft: per Handeingabe. Stand vom ' + MM.Hilfen.zeitpunkt(n.aktuell.erstelltAm) }),
        h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: '#/nachweis/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' }),
          h('a', { class: 'knopf leise', href: '#/nachweisart/' + encodeURIComponent(n.nachweis.artId), text: 'Zur Art' })));
      seite(aw.bezeichnung, [
        krumen(besitzerKrumen(n.nachweis.besitzerTyp, n.nachweis.besitzerId, n.besitzer.name).concat([[aw.bezeichnung]])),
        kopf, n.verlauf.length > 1 ? verlaufBlock(n.verlauf) : null
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/nachweis/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
    });
  }

  /* ---------- Formular: Nachweis anlegen / ändern ---------- */
  /* modus 'neu': typ = Besitzer (person, tier, fahrzeug), id = Besitzer. modus 'aendern': id = Nachweis. */
  function nachweisFormular(modus, typ, id) {
    var neu = modus === 'neu';
    var laden = neu
      ? Promise.all([daten.besitzerLaden(typ, id), daten.nachweisartenListe(typ)]).then(function (r) { return r[0] ? { besitzer: r[0], arten: r[1].filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja'; }), typ: typ, bid: id } : null; })
      : daten.nachweisLaden(id).then(function (n) { return n ? { n: n, besitzer: n.besitzer, typ: n.nachweis.besitzerTyp, bid: n.nachweis.besitzerId } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var titel = neu ? 'Nachweis hinzufügen' : 'Nachweis ändern';
      var zurueck = neu ? BESITZER_HASH[k.typ] + encodeURIComponent(k.bid) : '#/nachweis/' + encodeURIComponent(id);
      var weg = besitzerKrumen(k.typ, k.bid, k.besitzer.name);
      if (!neu) weg.push([k.n.art.aktuell.werte.bezeichnung, zurueck]);
      weg.push([titel]);

      function feldDef(f) {
        var d = { key: f.key, label: f.label, typ: f.typ };
        if (f.papier) d.hilfe = 'Steht auf dem Papier unter „' + f.papier + '“';
        return d;
      }
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: zurueck, neuzeichnenBei: neu ? ['artId'] : [],
        werte: neu ? { artId: '' } : JSON.parse(JSON.stringify(k.n.aktuell.werte)),
        intro: neu ? (k.arten.length ? h('p', { text: 'Wähle die Art des Nachweises. Dann erscheinen die passenden Angaben. Alle Angaben sind freiwillig.' })
          : h('div', { class: 'leer-hinweis' }, h('p', { text: 'Es gibt noch keine Art von Nachweis für ' + MM.Nachweise.besitzerLabel(k.typ) + '. Übernimm Vorschläge oder lege eine eigene Art an.' }),
            h('p', null, h('a', { class: 'knopf', href: '#/nachweisarten/vorschlaege', text: 'Vorschläge ansehen' })))) : null,
        gruppen: function (z) {
          var felder = [];
          var art;
          if (neu) {
            if (!k.arten.length) return [];
            felder.push({ key: 'artId', label: 'Art des Nachweises', typ: 'auswahl', leerText: '– bitte wählen –',
              optionen: k.arten.map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; }) });
            var gewaehlt = k.arten.filter(function (a) { return a.objekt.id === z.werte.artId; })[0];
            art = gewaehlt ? gewaehlt.aktuell.werte : null;
          } else {
            art = k.n.art.aktuell.werte;
          }
          if (art) {
            MM.Nachweise.felderFuer(art).forEach(function (f) { felder.push(feldDef(f)); });
            if (neu) felder.push({ key: 'datei', label: 'Scan oder Foto (freiwillig)', typ: 'datei', accept: 'image/*,application/pdf',
              hilfe: 'Zum Beispiel ein Foto des Dokuments. Es bleibt nur auf diesem Gerät.' });
          }
          return [{ titel: null, felder: felder }];
        },
        speichern: function (w) { return neu ? daten.nachweisAnlegen(k.typ, k.bid, w.artId, w) : daten.nachweisAendern(id, w); },
        meldung: function (r) { return neu ? 'Nachweis angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/nachweis/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Nachweisarten ---------- */
  var ARTEN_GRUPPEN = [['person', 'Für Personen'], ['tier', 'Für Tiere'], ['fahrzeug', 'Für Fahrzeuge']];
  var PRUEF_KLASSE = { geprueft: 'status-ok', teilweise: 'status-bald', offen: '' };

  function herkunftText(w) {
    if (w.herkunft === 'vorschlag') return 'Vorschlag, ' + (MM.NachweisVorschlaege.PRUEFSTATUS[w.pruefstatus] || '').toLowerCase();
    return 'von dir eingetragen';
  }

  function seiteNachweisarten() {
    return daten.nachweisartenListe().then(function (liste) {
      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Nachweisarten']]), h('h1', { text: 'Nachweisarten' }),
        h('p', { text: 'Die Liste ist offen. Du legst eigene Arten an oder übernimmst Vorschläge. Alles bleibt änderbar.' })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Noch keine Art. Übernimm Vorschläge für Deutschland und die EU oder lege eine eigene Art an.' })));
      ARTEN_GRUPPEN.forEach(function (g) {
        var teil = liste.filter(function (x) { return x.aktuell.werte.gehoertZu === g[0]; });
        if (!teil.length) return;
        inhalt.push(h('section', { class: 'bereich' }, h('h2', { text: g[1] }),
          h('ul', { class: 'fristen' }, teil.map(function (x) {
            var w = x.aktuell.werte;
            return h('li', null, h('a', { class: 'frist', href: '#/nachweisart/' + encodeURIComponent(x.objekt.id) },
              h('span', { class: 'frist-text' },
                h('strong', { class: 'frist-name', text: w.bezeichnung }),
                h('span', { class: 'frist-info', text: herkunftText(w) + ', ' + (x.anzahlNachweise === 1 ? '1 Nachweis' : x.anzahlNachweise + ' Nachweise') })),
              w.ausgeblendet === 'ja' ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : null));
          }))));
      });
      seite('Nachweisarten', inhalt, h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/nachweisarten/vorschlaege', text: 'Vorschläge' }),
        h('a', { class: 'knopf', href: '#/nachweisart/neu', text: 'Eigene Art anlegen' })));
    });
  }

  function seiteVorschlaege() {
    return daten.nachweisartenListe().then(function (liste) {
      var uebernommen = {};
      liste.forEach(function (x) { if (x.aktuell.werte.vorschlagId) uebernommen[x.aktuell.werte.vorschlagId] = x.objekt.id; });
      var alle = MM.NachweisVorschlaege.alle();

      function uebernehmen(ids) {
        return ids.reduce(function (kette, vid) {
          return kette.then(function () { return daten.nachweisartAusVorschlag(vid); });
        }, Promise.resolve()).then(function () {
          meldung = ids.length === 1 ? 'Art übernommen.' : ids.length + ' Arten übernommen.';
          return zeige();
        }).catch(fehlerSeite);
      }

      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Nachweisarten', '#/nachweisarten'], ['Vorschläge']]),
        h('h1', { text: 'Vorschläge' }),
        h('p', { text: 'Vorschläge für Deutschland und die EU. Du übernimmst, was du brauchst. Danach gehört die Art dir und lässt sich ändern. Jeder Vorschlag nennt seine Quelle und wie weit er geprüft ist.' })];
      ARTEN_GRUPPEN.forEach(function (g) {
        var teil = alle.filter(function (v) { return v.gehoertZu === g[0]; });
        var offen = teil.filter(function (v) { return !uebernommen[v.id]; });
        inhalt.push(h('section', { class: 'bereich' },
          h('h2', { text: g[1] }),
          offen.length > 1 ? h('p', null, h('button', { class: 'knopf leise', type: 'button', text: 'Alle ' + offen.length + ' übernehmen', onclick: function () { uebernehmen(offen.map(function (v) { return v.id; })); } })) : null,
          h('ul', { class: 'fristen' }, teil.map(function (v) {
            var da = uebernommen[v.id];
            return h('li', { class: 'vorschlag' },
              h('div', { class: 'vorschlag-kopf' },
                h('strong', { class: 'frist-name', text: v.name }),
                h('span', { class: 'chip-status ' + PRUEF_KLASSE[v.pruefstatus], text: MM.NachweisVorschlaege.PRUEFSTATUS[v.pruefstatus] })),
              h('p', { class: 'frist-info', text: v.land + (v.geprueftAm ? ', geprüft am ' + MM.Hilfen.datum(v.geprueftAm) : '') + (v.hatAblauf ? ', mit Ablaufdatum' : ', ohne Ablaufdatum') + ', ' + (v.felder.length ? v.felder.length + ' weitere Angaben' : 'nur die allgemeinen Angaben') }),
              h('details', { class: 'vorschlag-mehr' },
                h('summary', { text: 'Hinweis und Quelle' }),
                v.hinweis ? h('p', { text: v.hinweis }) : null,
                v.quelle ? h('p', null, 'Quelle: ', h('a', { href: v.quelle.url, target: '_blank', rel: 'noopener noreferrer', text: v.quelle.titel })) : h('p', { text: 'Quelle: noch keine geprüfte Quelle.' }),
                v.felder.length ? h('p', { class: 'frist-info', text: 'Angaben: ' + v.felder.map(function (f) { return f.label + (f.papier ? ' (' + f.papier + ')' : ''); }).join('; ') }) : null),
              da ? h('p', null, 'Schon übernommen. ', h('a', { href: '#/nachweisart/' + encodeURIComponent(da), text: 'Zur Art' }))
                : h('p', null, h('button', { class: 'knopf', type: 'button', text: 'Übernehmen', onclick: function () { uebernehmen([v.id]); } })));
          }))));
      });
      seite('Vorschläge', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/nachweisarten', text: 'Zurück' })));
    });
  }

  function seiteNachweisart(id) {
    return daten.nachweisartLaden(id).then(function (x) {
      if (!x) return nichtGefunden('Art nicht gefunden');
      var w = x.werte;
      var felderListe = MM.Nachweise.felderFuer(w);
      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Art von Nachweis, ' + MM.Nachweise.besitzerLabel(w.gehoertZu) }),
        h('h1', { text: w.bezeichnung }),
        w.ausgeblendet === 'ja' ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Ausgeblendet: Für neue Nachweise nicht mehr auswählbar. Vorhandene Nachweise bleiben.' }) : null,
        h('dl', { class: 'daten' },
          h('dt', { text: 'Herkunft' }), h('dd', { text: herkunftText(w) }),
          h('dt', { text: 'Ablaufdatum' }), h('dd', { text: MM.Nachweise.hatAblauf(w) ? 'ja' : 'nein' }),
          w.land ? [h('dt', { text: 'Land' }), h('dd', { text: w.land })] : null,
          h('dt', { text: 'Nachweise' }), h('dd', { text: String(x.anzahlNachweise) })),
        w.beschreibung ? h('p', { class: 'hinweis', text: w.beschreibung }) : null,
        h('section', { class: 'gruppe' }, h('h3', { text: 'Angaben je Nachweis' }),
          h('ul', { class: 'angaben' }, felderListe.map(function (f) { return h('li', { text: f.label + (f.papier ? ' (Papier: ' + f.papier + ')' : '') }); }))),
        w.herkunft === 'vorschlag' ? h('section', { class: 'gruppe' }, h('h3', { text: 'Quelle' }),
          w.quelleUrl ? h('p', null, h('a', { href: w.quelleUrl, target: '_blank', rel: 'noopener noreferrer', text: w.quelleTitel || w.quelleUrl })) : h('p', { text: 'Noch keine geprüfte Quelle.' }),
          h('p', { class: 'hinweis', text: (MM.NachweisVorschlaege.PRUEFSTATUS[w.pruefstatus] || '') + (w.geprueftAm ? ', geprüft am ' + MM.Hilfen.datum(w.geprueftAm) : '') })) : null,
        h('p', null, h('a', { class: 'knopf leise', href: '#/nachweisart/' + encodeURIComponent(id) + '/aendern', text: 'Art ändern' })));
      seite(w.bezeichnung, [
        krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Nachweisarten', '#/nachweisarten'], [w.bezeichnung]]),
        kopf, x.verlauf.length > 1 ? verlaufBlock(x.verlauf) : null
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/nachweisarten', text: 'Zur Liste' }),
        h('a', { class: 'knopf', href: '#/nachweisart/' + encodeURIComponent(id) + '/aendern', text: 'Art ändern' })));
    });
  }

  function nachweisartFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = neu ? Promise.resolve({ werte: { gehoertZu: 'person', hatAblauf: 'nein', felder: [] } }) : daten.nachweisartLaden(id);
    return laden.then(function (x) {
      if (!x) return nichtGefunden('Art nicht gefunden');
      var titel = neu ? 'Eigene Art anlegen' : 'Art ändern';
      var weg = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Nachweisarten', '#/nachweisarten']];
      if (!neu) weg.push([x.werte.bezeichnung, '#/nachweisart/' + encodeURIComponent(id)]);
      weg.push([titel]);
      var start = neu ? x.werte : { bezeichnung: x.werte.bezeichnung, hatAblauf: MM.Nachweise.hatAblauf(x.werte) ? 'ja' : 'nein', land: x.werte.land || '', beschreibung: x.werte.beschreibung || '',
        ausgeblendet: x.werte.ausgeblendet || 'nein', felder: JSON.parse(JSON.stringify(x.werte.felder || [])) };
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: neu ? '#/nachweisarten' : '#/nachweisart/' + encodeURIComponent(id), werte: start,
        intro: neu ? h('p', { text: 'Lege eine Art von Nachweis an, die es noch nicht gibt, zum Beispiel einen ausländischen Bootsführerschein. Jeder Nachweis hat immer Nummer, Aussteller, Ausstellungsdatum und Notiz. Hier legst du weitere Angaben fest.' })
          : h('p', { text: 'Du kannst die Art jederzeit ändern. Bereits eingetragene Angaben gehen dabei nicht verloren.' }),
        gruppen: function () {
          var felder = [{ key: 'bezeichnung', label: 'Name der Art', typ: 'text', hilfe: 'Zum Beispiel „Segelschein“ oder „Impfpass Pferd“' }];
          if (neu) felder.push({ key: 'gehoertZu', label: 'Wofür gilt der Nachweis?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Nachweise.BESITZER });
          felder.push({ key: 'hatAblauf', label: 'Hat der Nachweis ein Ablaufdatum?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Nachweise.JA_NEIN });
          felder.push({ key: 'land', label: 'Land', typ: 'text', hilfe: 'Freiwillig, zum Beispiel DE oder EU' });
          felder.push({ key: 'beschreibung', label: 'Beschreibung', typ: 'text', hilfe: 'Freiwillig' });
          if (!neu) felder.push({ key: 'ausgeblendet', label: 'Ausblenden?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Nein, auswählbar' }, { wert: 'ja', label: 'Ja, ausblenden' }],
            hilfe: 'Ausgeblendete Arten sind für neue Nachweise nicht mehr auswählbar. Vorhandene Nachweise bleiben.' });
          felder.push({ key: 'felder', label: 'Weitere Angaben', typ: 'zeilen', hilfe: 'Zum Beispiel „Geburtsdatum“ als Datum. Die Stelle auf dem Papier hilft später beim automatischen Einlesen.' });
          return [{ titel: null, felder: felder }];
        },
        speichern: function (w) { return neu ? daten.nachweisartAnlegen(w) : daten.nachweisartAendern(id, w); },
        meldung: function (r) { return neu ? 'Art angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/nachweisart/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Aktivitäten: gemeinsame Bausteine ---------- */
  var AK_STATUS = { laeuft: 'Läuft', geplant: 'Geplant', vorbei: 'Vorbei', storniert: 'Storniert' };
  var AK_KLASSE = { laeuft: 'status-ok', geplant: '', vorbei: '', storniert: 'status-ueberfaellig' };
  var ERG_KLASSE = { erlaubt: 'status-ok', nicht_erlaubt: 'status-ueberfaellig', unklar: 'status-bald' };
  var FRIST_ERG = { ueberfaellig: ['Überfällig', 'status-ueberfaellig'], faellig: ['Wird fällig', 'status-bald'], unbekannt: ['Angaben fehlen', 'status-unbekannt'], ok: ['In Ordnung', 'status-ok'] };

  function zeitText(datum, zeit) { return MM.Hilfen.datum(datum) + (zeit ? ', ' + zeit + ' Uhr' : ''); }
  function zeitraumText(w) { return zeitText(w.vonDatum, w.vonZeit) + ' bis ' + zeitText(w.bisDatum, w.bisZeit); }
  function jetztText(iso) { return MM.Hilfen.datum(iso.slice(0, 10)) + ', ' + iso.slice(11, 16) + ' Uhr'; }

  function seiteFunktionen() {
    seite('Funktionen', [
      krumen([['Hauptmenü', '#/auswahl'], ['Funktionen']]),
      h('h1', { text: 'Funktionen' }),
      h('div', { class: 'kacheln' },
        kachel('Aktivitäten', 'Urlaub, Törn, Ausfahrt und mehr planen', '#/aktivitaeten'),
        kachel('Reisecheck', 'Reise prüfen und Hinweise bekommen'),
        kachel('Logbuch', 'Unterwegs festhalten, Zähler führen'),
        kachel('Werkstatt', 'Störungen und Arbeiten'))
    ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/auswahl', text: 'Zurück' })));
    return Promise.resolve();
  }

  function aktivitaetZeile(x) {
    var w = x.aktuell.werte;
    return h('li', null, h('a', { class: 'frist ak ' + AK_KLASSE[x.status], href: '#/aktivitaet/' + encodeURIComponent(x.objekt.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: w.bezeichnung }),
        h('span', { class: 'frist-info', text: [x.artName, x.fahrzeugName].filter(Boolean).join(', ') }),
        h('span', { class: 'frist-info', text: zeitraumText(w) }),
        x.konflikte.length ? h('span', { class: 'hinweis-frist status-bald', text: x.konflikte.length === 1 ? 'Überschneidet sich mit 1 anderen' : 'Überschneidet sich mit ' + x.konflikte.length + ' anderen' }) : null),
      h('span', { class: 'chip-status ' + AK_KLASSE[x.status], text: AK_STATUS[x.status] })));
  }

  function seiteAktivitaeten() {
    return daten.aktivitaetenListe().then(function (liste) {
      function teil(status) { return liste.filter(function (x) { return status.indexOf(x.status) >= 0; }); }
      var jetzt = teil(['laeuft', 'geplant']), vorbei = teil(['vorbei']), storno = teil(['storniert']);
      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten']]), h('h1', { text: 'Aktivitäten' })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Noch keine Aktivität. Plane zum Beispiel einen Törn oder einen Urlaub. Du brauchst dafür ein Fahrzeug und eine Person.' })));
      if (jetzt.length) inhalt.push(h('ul', { class: 'fristen' }, jetzt.map(aktivitaetZeile)));
      if (vorbei.length) inhalt.push(h('details', { class: 'ausgebaut' }, h('summary', { text: 'Vorbei (' + vorbei.length + ')' }), h('ul', { class: 'fristen' }, vorbei.map(aktivitaetZeile))));
      if (storno.length) inhalt.push(h('details', { class: 'ausgebaut' }, h('summary', { text: 'Storniert (' + storno.length + ')' }), h('ul', { class: 'fristen' }, storno.map(aktivitaetZeile))));
      inhalt.push(h('p', null, h('a', { href: '#/aktivitaetsarten', text: 'Arten von Aktivitäten verwalten' })));
      seite('Aktivitäten', inhalt, h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/funktionen', text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/aktivitaet/neu', text: 'Aktivität planen' })));
    });
  }

  /* ---------- Seite: Aktivität ---------- */
  function seiteAktivitaet(id) {
    return Promise.all([daten.aktivitaetLaden(id), daten.aktivitaetPruefung(id)]).then(function (r) {
      var a = r[0], pr = r[1];
      if (!a) return nichtGefunden('Aktivität nicht gefunden');
      var w = a.aktuell.werte;
      var verantwortlich = MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt);
      var storniert = w.status === 'storniert';

      /* Kopf */
      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Aktivität' + (a.art ? ': ' + a.art.name : '') }),
        h('h1', { text: w.bezeichnung }),
        h('p', null, h('span', { class: 'chip-status gross ' + AK_KLASSE[a.status], text: AK_STATUS[a.status] })),
        storniert ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Storniert am ' + jetztText(w.stornoAm.replace(/:\d\d(\.\d+)?Z?$/, '').slice(0, 16)) + (w.stornoGrund ? '. Grund: ' + w.stornoGrund : '.') }) : null,
        h('dl', { class: 'daten stapel' },
          h('dt', { text: 'Fahrzeug' }), h('dd', null, h('a', { href: '#/fahrzeug/' + encodeURIComponent(a.fahrzeug.id), text: a.fahrzeug.name })),
          h('dt', { text: 'Zeitraum' }), h('dd', { text: zeitraumText(w) }),
          a.gebiet ? [h('dt', { text: 'Gebiet' }), h('dd', null, h('a', { href: '#/gebiet/' + encodeURIComponent(a.gebiet.id), text: a.gebiet.name }))]
            : (w.gebiet ? [h('dt', { text: 'Gebiet (Text)' }), h('dd', { text: w.gebiet })] : null),
          w.geplanteStrecke ? [h('dt', { text: 'Geplante Strecke' }), h('dd', { text: MM.Hilfen.zahl(w.geplanteStrecke) + ' km' })] : null,
          w.geplanteStunden ? [h('dt', { text: 'Geplante Betriebsstunden' }), h('dd', { text: MM.Hilfen.zahl(w.geplanteStunden) + ' h' })] : null,
          a.tiere.length ? [h('dt', { text: 'Tiere' }), h('dd', { text: a.tiere.map(function (t) { return t.name; }).join(', ') })] : null,
          w.notiz ? [h('dt', { text: 'Notiz' }), h('dd', { text: w.notiz })] : null),
        h('p', { class: 'knopfzeile' },
          storniert ? h('button', { class: 'knopf', type: 'button', text: 'Wiederherstellen', onclick: function () { daten.aktivitaetWiederherstellen(id).then(function () { meldung = 'Die Aktivität ist wieder geplant.'; return zeige(); }).catch(fehlerSeite); } })
            : [h('a', { class: 'knopf leise', href: '#/aktivitaet/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' }),
              h('a', { class: 'knopf gefahr', href: '#/aktivitaet/' + encodeURIComponent(id) + '/stornieren', text: 'Stornieren' })]));

      /* Besatzung */
      var jetzt = a.verantwortlichJetzt;
      var besatzung = h('section', { class: 'bereich', 'aria-label': 'Besatzung' },
        h('h2', { text: 'Besatzung' }),
        h('ul', { class: 'fristen' }, a.besatzung.map(function (b) {
          var dabei = b.aktuell.werte.dabeiVonDatum || b.aktuell.werte.dabeiBisDatum
            ? 'dabei ' + (b.aktuell.werte.dabeiVonDatum ? 'von ' + zeitText(b.aktuell.werte.dabeiVonDatum, b.aktuell.werte.dabeiVonZeit) : '') + (b.aktuell.werte.dabeiBisDatum ? ' bis ' + zeitText(b.aktuell.werte.dabeiBisDatum, b.aktuell.werte.dabeiBisZeit) : '') : null;
          var gerade = jetzt && jetzt.personId === b.person.id;
          return h('li', null, h('a', { class: 'frist ' + (gerade ? 'status-ok' : ''), href: '#/besatzung/' + encodeURIComponent(b.besatzung.id) + '/aendern' },
            h('span', { class: 'frist-text' },
              h('strong', { class: 'frist-name', text: b.person.name }),
              h('span', { class: 'frist-info', text: b.rolleText + (dabei ? ', ' + dabei : '') })),
            gerade ? h('span', { class: 'chip-status status-ok', text: 'verantwortlich' }) : null));
        })),
        a.entfernte.length ? h('details', { class: 'ausgebaut' }, h('summary', { text: 'Nicht mehr dabei (' + a.entfernte.length + ')' }),
          h('ul', { class: 'fristen' }, a.entfernte.map(function (b) {
            return h('li', null, h('a', { class: 'frist', href: '#/besatzung/' + encodeURIComponent(b.besatzung.id) + '/aendern' },
              h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: b.person.name }), h('span', { class: 'frist-info', text: b.rolleText }))));
          }))) : null,
        storniert ? null : h('p', { class: 'knopfzeile' },
          h('a', { class: 'knopf leise', href: '#/aktivitaet/' + encodeURIComponent(id) + '/besatzung/neu', text: 'Person hinzufügen' }),
          h('a', { class: 'knopf leise', href: '#/aktivitaet/' + encodeURIComponent(id) + '/verantwortung', text: 'Verantwortung wechseln' })),
        h('details', { class: 'ausgebaut' }, h('summary', { text: 'Wer war wann verantwortlich (' + a.verantwortung.length + ')' }),
          h('ol', { class: 'wechsel' }, a.verantwortung.map(function (v) {
            return h('li', null, 'ab ' + jetztText(v.ab) + ': ', h('strong', { text: v.name }));
          }))));

      /* Prüfung */
      var b = pr.befaehigung;
      var fr = pr.fristen;
      var betroffene = fr.liste.filter(function (f) { return f.status === 'faellig' || f.status === 'ueberfaellig'; });
      var sperreStatus = null;
      if (fr.zusammenfassung.sperre) {
        sperreStatus = w.sperreUebergangenAm
          ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Die Sperre wurde ausdrücklich übergangen am ' + jetztText(w.sperreUebergangenAm.replace(/:\d\d(\.\d+)?Z?$/, '').slice(0, 16)) + '.' })
          : h('div', null,
            h('p', { class: 'fehlerkasten', text: 'Mindestens eine Frist mit Sperre wird bis zum Ende des Zeitraums fällig.' }),
            storniert ? null : h('p', null, h('button', { class: 'knopf gefahr', type: 'button', text: 'Sperre ausdrücklich übergehen',
              onclick: function () { if (global.confirm('Die Sperre wirklich übergehen? Die Zeit wird festgehalten.')) daten.aktivitaetSperreUebergehen(id).then(function () { meldung = 'Die Sperre wurde übergangen und mit der Zeit festgehalten.'; return zeige(); }).catch(fehlerSeite); } })));
      }
      var pruefung = h('section', { class: 'bereich', 'aria-label': 'Prüfung' },
        h('h2', { text: 'Prüfung' }),
        h('p', { class: 'hinweis', text: 'Geprüft am ' + jetztText(pr.geprueftAm) + ', nur mit den Daten, die die App kennt. Das ist eine Hilfestellung und keine rechtliche Aussage. Die letzte Verantwortung hat der ' + verantwortlich + '.' }),
        h('section', { class: 'gruppe' },
          h('h3', { text: 'Befähigung von ' + verantwortlich + ' und Stellvertretern' }),
          h('p', null, h('span', { class: 'chip-status gross ' + ERG_KLASSE[b.ergebnis], text: MM.Aktivitaeten.ERGEBNIS[b.ergebnis] }),
            h('span', { class: 'frist-info', text: '  gilt bis zum Ende des Zeitraums (' + MM.Hilfen.datum(w.bisDatum) + ')' })),
          b.personen.map(function (p) {
            return h('div', { class: 'pruef-person' },
              h('p', null, h('strong', { text: p.person.name }), ' (' + p.rolleText + '): ', h('span', { class: 'chip-status ' + ERG_KLASSE[p.ergebnis], text: MM.Aktivitaeten.ERGEBNIS[p.ergebnis] })),
              h('ul', { class: 'gruende' }, p.gruende.map(function (g) { return h('li', { class: ERG_KLASSE[g.ergebnis], text: g.text }); })));
          }),
          pr.anforderungen === 0 ? h('p', { class: 'hinweis' }, 'Lege am Fahrzeug fest, welche Nachweise nötig sind. ', h('a', { href: '#/fahrzeug/' + encodeURIComponent(a.fahrzeug.id) + '/anforderung/neu', text: 'Anforderung anlegen' })) : null,
          b.gebietInfo ? h('div', { class: 'pruef-person' },
            h('p', null, h('strong', { text: 'Regeln des Gebiets ' + b.gebietInfo.name })),
            h('ul', { class: 'gruende' }, b.gebietInfo.greifen.map(function (t) { return h('li', { text: 'Gilt: ' + t }); })
              .concat(b.gebietInfo.nichtGreifen.map(function (n) { return h('li', { text: 'Gilt nicht: ' + n.bezeichnung + ' (' + n.grund + ')' }); })))) : null,
          b.gebietHinweis ? h('p', { class: 'hinweis' }, b.gebietHinweis + ' ', b.gebietInfo ? h('a', { href: '#/gebiet/' + encodeURIComponent(b.gebietInfo.id), text: 'Regeln ansehen' }) : null) : null),
        h('section', { class: 'gruppe' },
          h('h3', { text: 'Fristen des Fahrzeugs bis zum Ende' }),
          !fr.liste.length ? h('p', { class: 'leer-text', text: 'Am Fahrzeug gibt es keine Fristen.' })
            : (betroffene.length ? h('ul', { class: 'gruende' }, betroffene.map(function (f) {
              var e = FRIST_ERG[f.status];
              return h('li', { class: e[1] }, h('strong', { text: f.bezeichnung }), ': ' + e[0] + ' (Wirkung: ' + MM.Fristen.labelVon(MM.Fristen.WIRKUNGEN, f.wirkung) + '). ' + f.text);
            })) : h('p', { class: 'leer-text', text: 'Bis zum Ende des Zeitraums wird keine Frist fällig.' })),
          fr.liste.filter(function (f) { return f.status === 'unbekannt'; }).length ? h('p', { class: 'hinweis', text: 'Bei manchen Fristen fehlen Angaben: ' + fr.liste.filter(function (f) { return f.status === 'unbekannt'; }).map(function (f) { return f.bezeichnung; }).join(', ') + '.' }) : null,
          sperreStatus),
        h('section', { class: 'gruppe' },
          h('h3', { text: 'Belegung des Fahrzeugs' }),
          pr.belegung.konflikte.length ? h('ul', { class: 'gruende' }, pr.belegung.konflikte.map(function (k) {
            return h('li', { class: 'status-bald' }, 'Überschneidet sich mit ', h('a', { href: '#/aktivitaet/' + encodeURIComponent(k.id), text: k.name }), ' (' + MM.Hilfen.datum(k.vonDatum) + ' bis ' + MM.Hilfen.datum(k.bisDatum) + '). Das ist nur eine Warnung.');
          })) : h('p', { class: 'leer-text', text: 'Keine Überschneidung mit anderen Aktivitäten dieses Fahrzeugs.' })));

      seite(w.bezeichnung, [
        krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [w.bezeichnung]]),
        kopf, pruefung, besatzung, a.verlauf.length > 1 ? verlaufBlock(a.verlauf) : null
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/aktivitaeten', text: 'Zur Liste' }),
        storniert ? null : h('a', { class: 'knopf', href: '#/aktivitaet/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
    });
  }

  /* ---------- Formular: Aktivität planen / ändern ---------- */
  /* modus 'neu' (id leer oder Fahrzeug) oder 'aendern' (id = Aktivität) */
  function aktivitaetFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = Promise.all([daten.aktivitaetKontext(), neu ? Promise.resolve(null) : daten.aktivitaetLaden(id)]);
    return laden.then(function (r) {
      var ctx = r[0], a = r[1];
      if (!neu && !a) return nichtGefunden('Aktivität nicht gefunden');
      var titel = neu ? 'Aktivität planen' : 'Aktivität ändern';
      var weg = [['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten']];
      if (!neu) weg.push([a.aktuell.werte.bezeichnung, '#/aktivitaet/' + encodeURIComponent(id)]);
      weg.push([titel]);
      var start = neu ? { bezeichnung: '', artId: '', fahrzeugId: id || '', verantwortlichId: '', tierIds: [] } : JSON.parse(JSON.stringify(a.aktuell.werte));
      var artOptionen = ctx.arten.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja' || (!neu && x.objekt.id === a.aktuell.werte.artId); })
        .map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });
      var fzOptionen = ctx.fahrzeuge.map(function (x) { return { wert: x.fahrzeug.id, label: x.aktuell.werte.bezeichnung }; });
      var personOptionen = ctx.personen.map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });
      var gebietOptionen = ctx.gebiete.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja' || (!neu && x.objekt.id === a.aktuell.werte.gebietId); })
        .map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });
      var tierOptionen = ctx.tiere.map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });

      var voraussetzungen = [];
      if (!artOptionen.length) voraussetzungen.push(h('p', null, 'Es gibt noch keine Art von Aktivität. ',
        h('button', { class: 'knopf', type: 'button', text: 'Vorschläge übernehmen (Urlaub, Törn, Ausfahrt, Wasserski, Segeln, Rallye)',
          onclick: function () { daten.aktivitaetsartenAusVorschlaegen().then(function () { return zeige(); }).catch(fehlerSeite); } })));
      if (!fzOptionen.length) voraussetzungen.push(h('p', null, 'Es gibt noch kein Fahrzeug. ', h('a', { class: 'knopf leise', href: '#/neu', text: 'Fahrzeug anlegen' })));
      if (neu && !personOptionen.length) voraussetzungen.push(h('p', null, 'Es gibt noch keine Person. ', h('a', { class: 'knopf leise', href: '#/personen/neu', text: 'Person anlegen' })));

      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: neu ? '#/aktivitaeten' : '#/aktivitaet/' + encodeURIComponent(id), werte: start, neuzeichnenBei: ['fahrzeugId'],
        intro: voraussetzungen.length ? h('div', { class: 'leer-hinweis' }, voraussetzungen)
          : (neu ? h('p', { text: 'Nenne Name, Art, Fahrzeug, Zeitraum und wer verantwortlich ist. Alles Weitere kannst du später ergänzen. Die Besatzung fügst du danach hinzu.' }) : null),
        gruppen: function (z) {
          var fz = ctx.fahrzeuge.filter(function (x) { return x.fahrzeug.id === z.werte.fahrzeugId; })[0];
          var welt = fz ? MM.Fahrzeugarten.art(fz.fahrzeug.art).welt : 'land';
          var verantwortlich = MM.Aktivitaeten.verantwortlichenName(fz ? welt : null);
          var g = [{ titel: null, felder: [
            { key: 'bezeichnung', label: 'Name', typ: 'text', hilfe: 'Zum Beispiel „Sommertörn Kroatien“' },
            { key: 'artId', label: 'Art', typ: 'auswahl', optionen: artOptionen, leerText: '– bitte wählen –' },
            { key: 'fahrzeugId', label: 'Fahrzeug', typ: 'auswahl', optionen: fzOptionen, leerText: '– bitte wählen –' }
          ] }, { titel: 'Zeitraum', felder: [
            { key: 'vonDatum', label: 'Von (Datum)', typ: 'datum' }, { key: 'vonZeit', label: 'Von (Uhrzeit)', typ: 'zeit', hilfe: 'Freiwillig. Ohne Uhrzeit gilt der Tagesbeginn.' },
            { key: 'bisDatum', label: 'Bis (Datum)', typ: 'datum' }, { key: 'bisZeit', label: 'Bis (Uhrzeit)', typ: 'zeit', hilfe: 'Freiwillig. Ohne Uhrzeit gilt das Tagesende.' }
          ] }];
          if (neu) g.push({ titel: 'Verantwortlich', felder: [{ key: 'verantwortlichId', label: verantwortlich, typ: 'auswahl', optionen: personOptionen, leerText: '– bitte wählen –',
            hilfe: 'Zu jedem Zeitpunkt ist genau eine Person verantwortlich. Stellvertreter fügst du danach hinzu.' }] });
          g.push({ titel: 'Weiteres', felder: [
            { key: 'gebietId', label: 'Gebiet', typ: 'auswahl', optionen: gebietOptionen, leerText: '– keines –',
              hilfe: gebietOptionen.length ? 'Freiwillig. Die Regeln des Gebiets gelten bei der Prüfung. Gebiete und Regeln legst du unter Stammdaten › Gebiete an.' : 'Freiwillig. Es gibt noch kein Gebiet. Lege unter Stammdaten › Gebiete eines an, damit die App seine Regeln prüfen kann.' }
          ].concat(!neu && start.gebiet ? [{ key: 'gebiet', label: 'Gebiet als Text (aus einer früheren Version)', typ: 'text', hilfe: 'Der Text wird nicht geprüft. Wähle oben ein Gebiet aus der Liste und leere dieses Feld.' }] : []).concat([
            { key: 'geplanteStrecke', label: 'Geplante Strecke', typ: 'zahl', einheit: 'km', hilfe: 'Freiwillig. Damit rechnet die App Zähler-Fristen bis zum Ende.' },
            { key: 'geplanteStunden', label: 'Geplante Betriebsstunden', typ: 'zahl', einheit: 'h', hilfe: 'Freiwillig, für Fristen nach Betriebsstunden.' }
          ]).concat(tierOptionen.length ? [{ key: 'tierIds', label: 'Mitreisende Tiere', typ: 'mehrfach', optionen: tierOptionen }] : [])
            .concat([{ key: 'notiz', label: 'Notiz', typ: 'text' }]) });
          return g;
        },
        speichern: function (w) { return neu ? daten.aktivitaetAnlegen(w) : daten.aktivitaetAendern(id, w); },
        meldung: function (r) { return neu ? 'Aktivität angelegt. Die Prüfung steht unten.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/aktivitaet/' + encodeURIComponent(r.id); }
      });
    });
  }

  function stornoFormular(id) {
    return daten.aktivitaetLaden(id).then(function (a) {
      if (!a) return nichtGefunden('Aktivität nicht gefunden');
      var w = a.aktuell.werte;
      einfachFormular({
        titel: 'Aktivität stornieren', zurueck: '#/aktivitaet/' + encodeURIComponent(id), werte: { grund: '' },
        krumen: krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [w.bezeichnung, '#/aktivitaet/' + encodeURIComponent(id)], ['Stornieren']]),
        intro: h('p', { text: 'Die Aktivität wird nicht gelöscht. Sie bekommt den Status „storniert“ und bleibt mit allem Drumherum erhalten. Du kannst sie später wiederherstellen.' }),
        gruppen: function () { return [{ titel: null, felder: [{ key: 'grund', label: 'Grund', typ: 'text', hilfe: 'Freiwillig, zum Beispiel „Wetter“ oder „Fahrzeug defekt“' }] }]; },
        speichern: function (v) { return daten.aktivitaetStornieren(id, v.grund).then(function (r) { r.id = id; return r; }); },
        meldung: function () { return 'Die Aktivität ist storniert.'; },
        danach: function () { return '#/aktivitaet/' + encodeURIComponent(id); }
      });
    });
  }

  /* ---------- Besatzung und Verantwortung ---------- */
  var ROLLEN_WAHL = [{ wert: 'stellvertreter', label: 'Stellvertreter' }, { wert: 'crew', label: 'Crew' }];

  function besatzungFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = neu ? daten.aktivitaetLaden(id) : daten.speicher.holen('besatzung', id).then(function (b) { return b ? daten.aktivitaetLaden(b.aktivitaetId).then(function (a) { return a ? { a: a, b: b } : null; }) : null; });
    return Promise.all([laden, daten.personenListe()]).then(function (r) {
      var a = neu ? r[0] : (r[0] && r[0].a), personen = r[1];
      if (!a) return nichtGefunden('Nicht gefunden');
      var aId = a.aktivitaet.id, w = a.aktuell.werte;
      var eintrag = neu ? null : a.besatzung.concat(a.entfernte).filter(function (x) { return x.besatzung.id === id; })[0];
      if (!neu && !eintrag) return nichtGefunden('Nicht gefunden');
      var titel = neu ? 'Person hinzufügen' : 'Besatzung ändern';
      var weg = [['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [w.bezeichnung, '#/aktivitaet/' + encodeURIComponent(aId)], [titel]];
      var verantwortlicheRolle = !neu && eintrag.aktuell.werte.rolle === 'verantwortlich';
      var belegt = a.besatzung.map(function (b) { return b.person.id; });
      var frei = personen.filter(function (p) { return belegt.indexOf(p.objekt.id) < 0; }).map(function (p) { return { wert: p.objekt.id, label: p.aktuell.werte.bezeichnung }; });
      var start = neu ? { personId: '', rolle: 'crew' } : JSON.parse(JSON.stringify(eintrag.aktuell.werte));
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: '#/aktivitaet/' + encodeURIComponent(aId), werte: start,
        intro: neu ? (frei.length ? h('p', { text: 'Jede Person steht nur einmal in der Besatzung. Die Crew ist beliebig austauschbar. Stellvertreter können später verantwortlich werden.' })
          : h('div', { class: 'leer-hinweis' }, h('p', { text: 'Alle Personen sind schon dabei, oder es gibt noch keine weitere Person.' }), h('p', null, h('a', { class: 'knopf', href: '#/personen/neu', text: 'Person anlegen' }))))
          : h('p', null, h('strong', { text: eintrag.person.name }), verantwortlicheRolle ? ' ist ' + MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt) + '. Die Rolle ändert sich über „Verantwortung wechseln“.' : ''),
        gruppen: function () {
          var felder = [];
          if (neu) felder.push({ key: 'personId', label: 'Person', typ: 'auswahl', optionen: frei, leerText: '– bitte wählen –' });
          if (!verantwortlicheRolle) felder.push({ key: 'rolle', label: 'Rolle', typ: 'auswahl', darstellung: 'wahl', optionen: ROLLEN_WAHL });
          felder.push({ key: 'dabeiVonDatum', label: 'Dabei von (Datum)', typ: 'datum', hilfe: 'Freiwillig, wenn die Person nicht die ganze Zeit dabei ist' });
          felder.push({ key: 'dabeiVonZeit', label: 'Dabei von (Uhrzeit)', typ: 'zeit' });
          felder.push({ key: 'dabeiBisDatum', label: 'Dabei bis (Datum)', typ: 'datum' });
          felder.push({ key: 'dabeiBisZeit', label: 'Dabei bis (Uhrzeit)', typ: 'zeit' });
          if (!neu) felder.push({ key: 'entfernt', label: 'Ist die Person dabei?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Ja, dabei' }, { wert: 'ja', label: 'Nicht mehr dabei' }] });
          return [{ titel: null, felder: felder }];
        },
        speichern: function (v) {
          if (verantwortlicheRolle) v.rolle = 'verantwortlich';
          return neu ? daten.besatzungHinzufuegen(aId, v.personId, v).then(function (r) { r.id = aId; return r; }) : daten.besatzungAendern(id, v).then(function (r) { r.id = aId; return r; });
        },
        meldung: function (r) { return neu ? 'Person hinzugefügt.' : (r.geaendert ? 'Gespeichert.' : 'Es gab keine Änderung.'); },
        danach: function () { return '#/aktivitaet/' + encodeURIComponent(aId); }
      });
    });
  }

  function verantwortungFormular(id) {
    return daten.aktivitaetLaden(id).then(function (a) {
      if (!a) return nichtGefunden('Aktivität nicht gefunden');
      var w = a.aktuell.werte;
      var verantwortlich = MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt);
      var letzte = a.verantwortung[a.verantwortung.length - 1];
      var kandidaten = a.besatzung.filter(function (b) { return (b.aktuell.werte.rolle === 'verantwortlich' || b.aktuell.werte.rolle === 'stellvertreter') && (!letzte || b.person.id !== letzte.personId); })
        .map(function (b) { return { wert: b.person.id, label: b.person.name + ' (' + b.rolleText + ')' }; });
      var jetzt = daten.jetztLokal();
      einfachFormular({
        titel: 'Verantwortung wechseln', zurueck: '#/aktivitaet/' + encodeURIComponent(id),
        werte: { personId: '', abDatum: jetzt.slice(0, 10), abZeit: jetzt.slice(11, 16) },
        krumen: krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [w.bezeichnung, '#/aktivitaet/' + encodeURIComponent(id)], ['Verantwortung wechseln']]),
        intro: kandidaten.length ? h('p', { text: 'Zu jedem Zeitpunkt ist genau eine Person verantwortlich. Der Wechsel wird mit dem Zeitpunkt festgehalten. Wechseln können nur ' + verantwortlich + ' und Stellvertreter.' })
          : h('div', { class: 'leer-hinweis' }, h('p', { text: 'Es gibt keine andere Person, die verantwortlich werden könnte. Füge zuerst einen Stellvertreter hinzu.' }),
            h('p', null, h('a', { class: 'knopf', href: '#/aktivitaet/' + encodeURIComponent(id) + '/besatzung/neu', text: 'Person hinzufügen' }))),
        gruppen: function () {
          if (!kandidaten.length) return [];
          return [{ titel: null, felder: [
            { key: 'personId', label: 'Wer ist ab dann verantwortlich?', typ: 'auswahl', optionen: kandidaten, leerText: '– bitte wählen –' },
            { key: 'abDatum', label: 'Ab (Datum)', typ: 'datum' }, { key: 'abZeit', label: 'Ab (Uhrzeit)', typ: 'zeit' }] }];
        },
        speichern: function (v) { return daten.verantwortungWechseln(id, v.personId, v); },
        meldung: function () { return 'Der Wechsel ist festgehalten.'; },
        danach: function () { return '#/aktivitaet/' + encodeURIComponent(id); }
      });
    });
  }

  /* ---------- Aktivitätsarten ---------- */
  function seiteAktivitaetsarten() {
    return daten.aktivitaetsartenListe().then(function (liste) {
      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], ['Arten']]), h('h1', { text: 'Arten von Aktivitäten' }),
        h('p', { text: 'Die Liste ist offen. Übernimm die Vorschläge (Urlaub, Törn, Ausfahrt, Wasserski, Segeln, Rallye) oder lege eigene Arten an.' })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Noch keine Art.' })));
      else inhalt.push(h('ul', { class: 'fristen' }, liste.map(function (x) {
        return h('li', null, h('a', { class: 'frist', href: '#/aktivitaetsart/' + encodeURIComponent(x.objekt.id) + '/aendern' },
          h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: x.aktuell.werte.bezeichnung })),
          x.aktuell.werte.ausgeblendet === 'ja' ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : null));
      })));
      var fehlend = MM.Aktivitaeten.VORSCHLAEGE_ARTEN.filter(function (n) { return !liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === n.toLowerCase(); }); });
      if (fehlend.length) inhalt.push(h('p', null, h('button', { class: 'knopf leise', type: 'button', text: 'Vorschläge übernehmen (' + fehlend.length + ')',
        onclick: function () { daten.aktivitaetsartenAusVorschlaegen().then(function (r) { meldung = r.anzahl + ' Arten übernommen.'; return zeige(); }).catch(fehlerSeite); } })));
      seite('Arten von Aktivitäten', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/aktivitaeten', text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/aktivitaetsart/neu', text: 'Eigene Art anlegen' })));
    });
  }

  function aktivitaetsartFormular(modus, id) {
    var neu = modus === 'neu';
    return (neu ? Promise.resolve({ aktuell: { werte: { bezeichnung: '', ausgeblendet: 'nein' } } }) : daten.aktivitaetsartLaden(id)).then(function (x) {
      if (!x) return nichtGefunden('Art nicht gefunden');
      var titel = neu ? 'Eigene Art anlegen' : 'Art ändern';
      einfachFormular({
        titel: titel, zurueck: '#/aktivitaetsarten', werte: JSON.parse(JSON.stringify(x.aktuell.werte)),
        krumen: krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], ['Arten', '#/aktivitaetsarten'], [titel]]),
        gruppen: function () {
          var f = [{ key: 'bezeichnung', label: 'Name der Art', typ: 'text', hilfe: 'Zum Beispiel „Angeln“ oder „Regatta“' }];
          if (!neu) f.push({ key: 'ausgeblendet', label: 'Ausblenden?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Nein, auswählbar' }, { wert: 'ja', label: 'Ja, ausblenden' }],
            hilfe: 'Ausgeblendete Arten sind für neue Aktivitäten nicht mehr auswählbar. Vorhandene Aktivitäten bleiben.' });
          return [{ titel: null, felder: f }];
        },
        speichern: function (v) { return neu ? daten.aktivitaetsartAnlegen(v) : daten.aktivitaetsartAendern(id, v).then(function (r) { r.id = id; return r; }); },
        meldung: function (r) { return neu ? 'Art angelegt.' : (r.geaendert ? 'Gespeichert.' : 'Es gab keine Änderung.'); },
        danach: function () { return '#/aktivitaetsarten'; }
      });
    });
  }

  /* ---------- Anforderungen am Fahrzeug ---------- */
  function anforderungenBereich(liste, fahrzeugId, welt) {
    var name = MM.Aktivitaeten.verantwortlichenName(welt);
    return h('section', { class: 'bereich', 'aria-label': 'Anforderungen' },
      h('h2', { text: 'Anforderungen an ' + name + ' und Stellvertreter' }),
      liste.length ? h('ul', { class: 'fristen' }, liste.map(function (x) {
        var w = x.aktuell.werte;
        return h('li', null, h('a', { class: 'frist', href: '#/anforderung/' + encodeURIComponent(x.objekt.id) + '/aendern' },
          h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: w.bezeichnung }), h('span', { class: 'frist-info', text: 'Genügt: ' + x.artNamen.join(' oder ') })),
          w.gilt === 'nein' ? h('span', { class: 'chip-status', text: 'abgeschaltet' }) : null));
      })) : h('p', { class: 'leer-text', text: 'Noch keine Anforderung. Lege fest, welche Nachweise nötig sind, damit die App bei der Planung prüfen kann.' }),
      h('a', { class: 'knopf leise', href: '#/fahrzeug/' + encodeURIComponent(fahrzeugId) + '/anforderung/neu', text: 'Anforderung hinzufügen' }));
  }

  /* modus 'neu' (id = Fahrzeug) oder 'aendern' (id = Anforderung) */
  function anforderungFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = neu ? daten.fahrzeugLaden(id).then(function (f) { return f ? { fz: f, start: { bezeichnung: '', artIds: [], gilt: 'ja' } } : null; })
      : daten.anforderungLaden(id).then(function (x) { return x ? daten.speicher.holen('anforderungen', id).then(function (rec) { return daten.fahrzeugLaden(rec.fahrzeugId).then(function (f) { return f ? { fz: f, x: x, start: JSON.parse(JSON.stringify(x.aktuell.werte)) } : null; }); }) : null; });
    return Promise.all([laden, daten.nachweisartenListe('person')]).then(function (r) {
      var k = r[0], arten = r[1];
      if (!k) return nichtGefunden('Nicht gefunden');
      var fz = k.fz.fahrzeug, name = k.fz.aktuell.werte.bezeichnung;
      var welt = MM.Fahrzeugarten.art(fz.art).welt;
      var verantwortlich = MM.Aktivitaeten.verantwortlichenName(welt);
      var titel = neu ? 'Anforderung hinzufügen' : 'Anforderung ändern';
      var zurueck = '#/fahrzeug/' + encodeURIComponent(fz.id);
      var weg = WEG_FAHRZEUGE.concat([[name, zurueck], [titel]]);
      var optionen = arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || (k.start.artIds || []).indexOf(a.objekt.id) >= 0; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; });
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: zurueck, werte: k.start,
        intro: optionen.length ? h('p', { text: 'Welche Nachweise braucht ein ' + verantwortlich + ' für dieses Fahrzeug? Es genügt jeweils eine der Arten, die du wählst. Legst du mehrere Anforderungen an, müssen alle erfüllt sein. Für die Verantwortlichen zählt nur ein Nachweis mit Scan oder Foto.' })
          : h('div', { class: 'leer-hinweis' }, h('p', { text: 'Es gibt noch keine Art von Nachweis für Personen. Übernimm Vorschläge oder lege eine eigene Art an.' }), h('p', null, h('a', { class: 'knopf', href: '#/nachweisarten/vorschlaege', text: 'Vorschläge ansehen' }))),
        gruppen: function () {
          if (!optionen.length) return [];
          var f = [{ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Zum Beispiel „Führerschein Klasse B“ oder „Funkzeugnis“' },
            { key: 'artIds', label: 'Genügt einer dieser Nachweise', typ: 'mehrfach', optionen: optionen }];
          if (!neu) f.push({ key: 'gilt', label: 'Gilt die Anforderung?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'ja', label: 'Ja, sie gilt' }, { wert: 'nein', label: 'Nein, abgeschaltet' }] });
          return [{ titel: null, felder: f }];
        },
        speichern: function (v) { return neu ? daten.anforderungAnlegen(id, v) : daten.anforderungAendern(id, v); },
        meldung: function (r) { return neu ? 'Anforderung angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function () { return zurueck; }
      });
    });
  }

  /* ---------- Orte, Standorte, Gebiete und Regeln ---------- */
  var KR_ORTE = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten']];
  var BENANNT = {
    ort: {
      liste: '#/orte', einzel: '#/ort/', krumen: 'Orte', schale: 'Ort', titelNeu: 'Ort anlegen', titelAendern: 'Ort ändern',
      felder: function () { return MM.Orte.ortFelder(); }, laden: function (id) { return daten.ortLaden(id); },
      anlegen: function (w) { return daten.ortAnlegen(w); }, aendern: function (id, w) { return daten.ortAendern(id, w); },
      namenHilfe: 'Zum Beispiel „Hafen Biograd“ oder „Zuhause“',
      intro: 'Ein Ort ist ein Platz, an dem du dein Fahrzeug hast oder hinbringst, zum Beispiel ein Hafen oder ein Campingplatz. Die einzelnen Plätze darin legst du danach als Standorte an.'
    },
    gebiet: {
      liste: '#/gebiete', einzel: '#/gebiet/', krumen: 'Gebiete', schale: 'Gebiet', titelNeu: 'Gebiet anlegen', titelAendern: 'Gebiet ändern',
      felder: function () { return MM.Orte.gebietFelder(); }, laden: function (id) { return daten.gebietLaden(id); },
      anlegen: function (w) { return daten.gebietAnlegen(w); }, aendern: function (id, w) { return daten.gebietAendern(id, w); },
      namenHilfe: 'Zum Beispiel „Kroatien, Adria“ oder „Deutschland, Binnen“',
      intro: 'Ein Gebiet ist ein Land oder Revier, für das besondere Regeln gelten. Die Regeln trägst du danach selbst ein. MobiMory prüft damit bei der Planung, macht aber keine rechtsgültige Aussage.'
    }
  };

  function seiteBenanntListe(typ) {
    var c = BENANNT[typ];
    return (typ === 'ort' ? daten.orteListe() : daten.gebieteListe()).then(function (liste) {
      var inhalt = [krumen(KR_ORTE.concat([[c.krumen]])), h('h1', { text: c.krumen })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: typ === 'ort' ? 'Noch kein Ort. Lege zum Beispiel deinen Heimathafen oder den Stellplatz zu Hause an.' : 'Noch kein Gebiet. Lege zum Beispiel „Kroatien, Adria“ an und trage danach die Regeln ein.' })));
      else inhalt.push(h('ul', { class: 'liste' }, liste.map(function (x) {
        var w = x.aktuell.werte;
        var zahl = typ === 'ort' ? (x.anzahlStandorte === 1 ? '1 Standort' : x.anzahlStandorte + ' Standorte') : (x.anzahlRegeln === 1 ? '1 Regel' : x.anzahlRegeln + ' Regeln');
        return h('li', null, h('a', { class: 'zeile welt-land', href: c.einzel + encodeURIComponent(x.objekt.id) },
          h('span', { class: 'zeile-text' },
            h('strong', { class: 'zeile-name', text: w.bezeichnung }),
            h('span', { class: 'zeile-art', text: [typ === 'ort' ? w.land : null, zahl].filter(Boolean).join(', ') })),
          w.ausgeblendet === 'ja' ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : null));
      })));
      seite(c.krumen, inhalt, h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
        h('a', { class: 'knopf', href: c.liste + '/neu', text: c.titelNeu })));
    });
  }

  function seiteBenannt(typ, id) {
    var c = BENANNT[typ];
    return c.laden(id).then(function (x) {
      if (!x) return nichtGefunden(c.schale + ' nicht gefunden');
      var w = x.aktuell.werte;
      var dl = [];
      c.felder().forEach(function (f) {
        var t = MM.Hilfen.wert(f, w[f.key]);
        if (t !== null) dl.push([h('dt', { text: f.label }), h('dd', { text: t })]);
      });
      var karte = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: c.schale }),
        h('h1', { text: w.bezeichnung }),
        w.ausgeblendet === 'ja' ? h('p', null, h('span', { class: 'chip-status', text: 'ausgeblendet' })) : null,
        dl.length ? h('dl', { class: 'daten' }, dl) : h('p', { class: 'leer-text', text: 'Noch keine weiteren Angaben.' }),
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(x.aktuell.erstelltAm) + ', ' + MM.Orte.herkunftText() }),
        h('p', null, h('a', { class: 'knopf leise', href: c.einzel + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
      var kinder, neuHref, neuText;
      if (typ === 'ort') {
        neuHref = '#/ort/' + encodeURIComponent(id) + '/standort/neu'; neuText = 'Standort hinzufügen';
        kinder = h('section', { class: 'bereich', 'aria-label': 'Standorte' },
          h('h2', { text: 'Standorte' }),
          x.standorte.length ? h('ul', { class: 'fristen' }, x.standorte.map(function (s) {
            var sw = s.aktuell.werte;
            return h('li', null, h('a', { class: 'frist', href: '#/standort/' + encodeURIComponent(s.objekt.id) + '/aendern' },
              h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: sw.bezeichnung }), sw.standortart ? h('span', { class: 'frist-info', text: sw.standortart }) : null),
              sw.ausgeblendet === 'ja' ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : null));
          })) : h('p', { class: 'leer-text', text: 'Noch kein Standort. Lege zum Beispiel einen Liegeplatz oder Stellplatz an.' }),
          h('a', { class: 'knopf leise', href: neuHref, text: neuText }));
      } else {
        neuHref = '#/gebiet/' + encodeURIComponent(id) + '/regel/neu'; neuText = 'Regel hinzufügen';
        kinder = h('section', { class: 'bereich', 'aria-label': 'Regeln' },
          h('h2', { text: 'Regeln dieses Gebiets' }),
          h('p', { class: 'hilfe', text: 'Eine Regel sagt: Wenn Fahrzeugart und Ausrüstung passen, genügt einer der gewählten Nachweise. Alle passenden Regeln müssen erfüllt sein.' }),
          x.regeln.length ? h('ul', { class: 'fristen' }, x.regeln.map(function (g) {
            var rw = g.aktuell.werte;
            var wenn = [g.fahrzeugArtNamen.length ? g.fahrzeugArtNamen.join(', ') : 'jede Fahrzeugart', rw.ausruestung ? 'mit „' + rw.ausruestung + '“' : null].filter(Boolean).join(', ');
            return h('li', null, h('a', { class: 'frist', href: '#/regel/' + encodeURIComponent(g.objekt.id) + '/aendern' },
              h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: rw.bezeichnung }),
                h('span', { class: 'frist-info', text: 'Wenn: ' + wenn + '. Dann genügt: ' + g.artNamen.join(' oder ') + '.' })),
              rw.gilt === 'nein' ? h('span', { class: 'chip-status', text: 'abgeschaltet' }) : null));
          })) : h('p', { class: 'leer-text', text: 'Noch keine Regel. Ohne Regel kann die App für dieses Gebiet nichts prüfen und sagt höchstens „unklar“.' }),
          h('a', { class: 'knopf leise', href: neuHref, text: neuText }));
      }
      seite(w.bezeichnung, [
        krumen(KR_ORTE.concat([[c.krumen, c.liste], [w.bezeichnung]])), karte, kinder, x.verlauf.length > 1 ? verlaufBlock(x.verlauf) : null
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: c.liste, text: 'Zur Liste' }),
        h('a', { class: 'knopf', href: neuHref, text: neuText })));
    });
  }

  function benanntFormular(typ, modus, id) {
    var c = BENANNT[typ];
    var laden = modus === 'aendern' ? c.laden(id) : Promise.resolve({ aktuell: { werte: { bezeichnung: '' } } });
    return laden.then(function (x) {
      if (!x) return nichtGefunden(c.schale + ' nicht gefunden');
      var neu = modus === 'neu';
      var titel = neu ? c.titelNeu : c.titelAendern;
      var weg = KR_ORTE.concat([[c.krumen, c.liste]]);
      if (!neu) weg.push([x.aktuell.werte.bezeichnung, c.einzel + encodeURIComponent(id)]);
      weg.push([titel]);
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: neu ? c.liste : c.einzel + encodeURIComponent(id),
        werte: JSON.parse(JSON.stringify(x.aktuell.werte)),
        intro: neu ? h('p', { text: c.intro }) : null,
        gruppen: function () {
          var f = [{ key: 'bezeichnung', label: 'Name', typ: 'text', hilfe: c.namenHilfe }].concat(c.felder());
          if (!neu) f.push({ key: 'ausgeblendet', label: 'Anzeigen?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Ja, anzeigen' }, { wert: 'ja', label: 'Nein, ausblenden' }] });
          return [{ titel: null, felder: f }];
        },
        speichern: function (w) { return neu ? c.anlegen(w) : c.aendern(id, w); },
        meldung: function (r) { return neu ? c.schale + ' angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return c.einzel + encodeURIComponent(r.id); }
      });
    });
  }

  /* Standort: modus 'neu' (id = Ort) oder 'aendern' (id = Standort) */
  function standortFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = neu ? daten.ortLaden(id).then(function (o) { return o ? { ort: { id: id, name: o.aktuell.werte.bezeichnung }, start: { bezeichnung: '' } } : null; })
      : daten.standortLaden(id).then(function (s) { return s ? { ort: s.ort, start: JSON.parse(JSON.stringify(s.aktuell.werte)) } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var titel = neu ? 'Standort hinzufügen' : 'Standort ändern';
      var zurueck = '#/ort/' + encodeURIComponent(k.ort.id);
      einfachFormular({
        titel: titel, krumen: krumen(KR_ORTE.concat([['Orte', '#/orte'], [k.ort.name, zurueck], [titel]])), zurueck: zurueck, werte: k.start,
        intro: neu ? h('p', { text: 'Ein Standort ist ein einzelner Platz an diesem Ort, zum Beispiel „Liegeplatz 12“ oder „Stellplatz Nord“.' }) : null,
        gruppen: function () {
          var f = [{ key: 'bezeichnung', label: 'Name', typ: 'text', hilfe: 'Zum Beispiel „Liegeplatz 12“' }].concat(MM.Orte.standortFelder());
          if (!neu) f.push({ key: 'ausgeblendet', label: 'Anzeigen?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Ja, anzeigen' }, { wert: 'ja', label: 'Nein, ausblenden' }] });
          return [{ titel: null, felder: f }];
        },
        speichern: function (w) { return neu ? daten.standortAnlegen(id, w) : daten.standortAendern(id, w); },
        meldung: function (r) { return neu ? 'Standort angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function () { return zurueck; }
      });
    });
  }

  /* Regel: modus 'neu' (id = Gebiet) oder 'aendern' (id = Regel) */
  function regelFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = neu ? daten.gebietLaden(id).then(function (g) { return g ? { gebiet: { id: id, name: g.aktuell.werte.bezeichnung }, start: { bezeichnung: '', fahrzeugArten: [], ausruestung: '', artIds: [], gilt: 'ja' } } : null; })
      : daten.regelLaden(id).then(function (x) { return x ? { gebiet: x.gebiet, start: JSON.parse(JSON.stringify(x.aktuell.werte)) } : null; });
    return Promise.all([laden, daten.nachweisartenListe('person')]).then(function (r) {
      var k = r[0], arten = r[1];
      if (!k) return nichtGefunden('Nicht gefunden');
      var titel = neu ? 'Regel hinzufügen' : 'Regel ändern';
      var zurueck = '#/gebiet/' + encodeURIComponent(k.gebiet.id);
      var optionen = arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || (k.start.artIds || []).indexOf(a.objekt.id) >= 0; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; });
      einfachFormular({
        titel: titel, krumen: krumen(KR_ORTE.concat([['Gebiete', '#/gebiete'], [k.gebiet.name, zurueck], [titel]])), zurueck: zurueck, werte: k.start,
        intro: optionen.length ? h('p', { text: 'Wenn du im Gebiet „' + k.gebiet.name + '“ unterwegs bist und Fahrzeugart und Ausrüstung passen, genügt einer der Nachweise, die du wählst. Ohne Auswahl bei den Fahrzeugarten gilt die Regel für jedes Fahrzeug. Die Regel ist von dir eingetragen, die App prüft sie nicht auf Richtigkeit.' })
          : h('div', { class: 'leer-hinweis' }, h('p', { text: 'Es gibt noch keine Art von Nachweis für Personen. Übernimm Vorschläge oder lege eine eigene Art an.' }), h('p', null, h('a', { class: 'knopf', href: '#/nachweisarten/vorschlaege', text: 'Vorschläge ansehen' }))),
        gruppen: function () {
          if (!optionen.length) return [];
          var f = [{ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Zum Beispiel „Funkzeugnis auf See“' },
            { key: 'fahrzeugArten', label: 'Gilt für diese Fahrzeugarten', typ: 'mehrfach', hilfe: 'Nichts angekreuzt: gilt für jede Fahrzeugart.',
              optionen: MM.Fahrzeugarten.alle().map(function (a) { return { wert: a.id, label: a.name }; }) },
            { key: 'ausruestung', label: 'Nur mit Ausrüstung', typ: 'text', hilfe: 'Freiwillig, zum Beispiel „Funkanlage“. Die Regel gilt, wenn am Fahrzeug eine eingebaute Komponente mit diesem Wort im Namen steht.' },
            { key: 'artIds', label: 'Genügt einer dieser Nachweise', typ: 'mehrfach', optionen: optionen }];
          if (!neu) f.push({ key: 'gilt', label: 'Gilt die Regel?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'ja', label: 'Ja, sie gilt' }, { wert: 'nein', label: 'Nein, abgeschaltet' }] });
          return [{ titel: null, felder: f }];
        },
        speichern: function (v) { return neu ? daten.regelAnlegen(id, v) : daten.regelAendern(id, v); },
        meldung: function (r) { return neu ? 'Regel angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function () { return zurueck; }
      });
    });
  }

  /* Heimatstandort am Fahrzeug */
  function heimatstandortBereich(info, fahrzeugId) {
    var href = '#/fahrzeug/' + encodeURIComponent(fahrzeugId) + '/heimatstandort';
    return h('section', { class: 'bereich', 'aria-label': 'Heimatstandort' },
      h('h2', { text: 'Heimatstandort' }),
      info.standort ? h('p', null, h('a', { href: '#/ort/' + encodeURIComponent(info.standort.ortId), text: info.standort.ortName }), ', ' + info.standort.name)
        : h('p', { class: 'leer-text', text: 'Noch kein Heimatstandort gewählt.' }),
      h('a', { class: 'knopf leise', href: href, text: info.standort ? 'Heimatstandort ändern' : 'Heimatstandort wählen' }),
      info.verlauf.length > 1 ? h('details', { class: 'verlauf' },
        h('summary', { text: 'Verlauf des Heimatstandorts (' + info.verlauf.length + ')' }),
        h('ol', null, info.verlauf.map(function (v, i) {
          return h('li', { class: i === 0 ? 'aktuell' : null }, h('div', null, h('span', { class: 'wann', text: MM.Hilfen.zeitpunkt(v.eintrag.erstelltAm) }), i === 0 ? h('span', { class: 'marke-aktuell', text: 'aktuell' }) : null),
            h('div', { text: v.alt === null ? 'Gewählt: ' + v.neu : v.alt + ' → ' + v.neu }));
        }))) : null);
  }

  function heimatstandortFormular(fahrzeugId) {
    return Promise.all([daten.fahrzeugLaden(fahrzeugId), daten.fahrzeugStandort(fahrzeugId), daten.standorteListe(), daten.orteListe()]).then(function (r) {
      var f = r[0], info = r[1];
      if (!f) return nichtGefunden('Fahrzeug nicht gefunden');
      var orte = {}; r[3].forEach(function (o) { orte[o.objekt.id] = o.aktuell.werte.bezeichnung; });
      var aktuellId = info.standort ? info.standort.id : '';
      var optionen = r[2].filter(function (s) { return s.aktuell.werte.ausgeblendet !== 'ja' || s.objekt.id === aktuellId; })
        .map(function (s) { return { wert: s.objekt.id, label: (orte[s.objekt.ortId] || 'Ort') + ', ' + s.aktuell.werte.bezeichnung }; })
        .sort(function (a, b) { return a.label.localeCompare(b.label, 'de', { numeric: true, sensitivity: 'base' }); });
      var name = f.aktuell.werte.bezeichnung, zurueck = '#/fahrzeug/' + encodeURIComponent(fahrzeugId);
      einfachFormular({
        titel: 'Heimatstandort wählen', krumen: krumen(WEG_FAHRZEUGE.concat([[name, zurueck], ['Heimatstandort']])), zurueck: zurueck, werte: { standortId: aktuellId },
        intro: optionen.length ? h('p', { text: 'Wo steht das Fahrzeug normalerweise, zum Beispiel am Liegeplatz oder in der Garage? Die Wahl lässt sich jederzeit ändern, der frühere Stand bleibt im Verlauf.' })
          : h('div', { class: 'leer-hinweis' }, h('p', { text: 'Es gibt noch keinen Standort. Lege zuerst einen Ort mit einem Standort an.' }), h('p', null, h('a', { class: 'knopf', href: '#/orte', text: 'Zu den Orten' }))),
        gruppen: function () { return optionen.length ? [{ titel: null, felder: [{ key: 'standortId', label: 'Heimatstandort', typ: 'auswahl', optionen: optionen, leerText: '– keiner –' }] }] : []; },
        speichern: function (v) { return daten.fahrzeugStandortSetzen(fahrzeugId, v.standortId); },
        meldung: function (r) { return r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'; },
        danach: function () { return zurueck; }
      });
    });
  }

  /* ---------- Startseite ---------- */
  function seiteStart() {
    doc.title = 'MobiMory';
    wurzel.textContent = '';
    var saetze = MM.Texte.KERNSATZ.split('. ').map(function (t, i, a) { return i < a.length - 1 ? t + '.' : t; });
    wurzel.appendChild(h('main', { class: 'start', id: 'inhalt' },
      h('div', { class: 'start-logo' },
        h('img', { src: 'icons/icon.svg', alt: '', width: '112', height: '112' }),
        h('p', { class: 'start-name', text: 'MobiMory' }),
        h('p', { class: 'start-vtd', text: 'Vehicle, Traffic and Data' })),
      h('h1', { class: 'kernsatz' }, saetze.map(function (z, i) {
        return h('span', { class: 'satz' },
          h('span', { class: 'chip', 'aria-hidden': 'true', text: 'VTD'.charAt(i) }),
          h('span', { text: z + ' ' }));
      })),
      h('p', { class: 'infotext', text: MM.Texte.INFOTEXT }),
      h('div', { class: 'start-knoepfe' },
        h('a', { class: 'knopf gross', href: '#/auswahl', text: 'Programm starten' }),
        h('a', { class: 'knopf leise gross', href: '#/neu-im-programm', text: 'Neu im Programm' })),
      h('footer', { class: 'start-fuss' },
        h('p', { text: MM.Texte.COPYRIGHT }),
        h('p', { text: 'Version ' + MM.VERSION }))));
    global.scrollTo(0, 0);
    return Promise.resolve();
  }

  /* ---------- Kacheln ---------- */
  function kachel(titel, text, href) {
    var inhalt = [h('span', { class: 'kachel-titel', text: titel }), h('span', { class: 'kachel-text', text: text })];
    if (href) return h('a', { class: 'kachel', href: href }, inhalt);
    return h('div', { class: 'kachel bald' }, inhalt, h('span', { class: 'kachel-bald', text: 'kommt' }));
  }

  /* ---------- Hauptmenü (äußerste Schale nach der Startseite) ---------- */
  function seiteHauptmenue() {
    return daten.sicherungErinnerung().then(function (e) {
      var hinweis = null;
      if (e.faellig) {
        hinweis = h('div', { class: 'erinnerung', role: 'status' },
          h('p', { text: e.grund === 'nie' ? 'Du hast noch nie eine Sicherung erstellt. Geht das Gerät kaputt, sind deine Daten weg.' : 'Die letzte Sicherung ist ' + e.tage + ' Tage her.' }),
          h('a', { class: 'knopf', href: '#/einstellungen/sichern', text: 'Jetzt sichern' }));
      }
      seite('Hauptmenü', [
        h('h1', { text: 'Hauptmenü' }),
        hinweis,
        h('div', { class: 'kacheln' },
          kachel('Stammdaten', 'Fahrzeuge, Personen, Tiere, Orte und Gebiete', '#/stammdaten'),
          kachel('Funktionen', 'Aktivitäten, Reisecheck, Werkstatt und mehr', '#/funktionen'),
          kachel('Einstellungen', 'Deine Daten, Sicherung und Hinweise zum Programm', '#/einstellungen')),
        h('p', { class: 'zur-start' }, h('a', { href: '#/', text: 'Zur Startseite' }))
      ]);
    });
  }

  function seiteStammdaten() {
    return Promise.all([daten.fahrzeugListe(), daten.personenListe(), daten.tiereListe(), daten.nachweisartenListe(), daten.orteListe(), daten.gebieteListe()]).then(function (r) {
      function zahl(n, eins, viele, keins) { return n === 0 ? keins : (n === 1 ? '1 ' + eins : n + ' ' + viele); }
      seite('Stammdaten', [
        krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten']]),
        h('h1', { text: 'Stammdaten' }),
        h('div', { class: 'kacheln' },
          kachel('Fahrzeuge', zahl(r[0].length, 'Fahrzeug', 'Fahrzeuge', 'Noch kein Fahrzeug angelegt'), '#/fahrzeuge'),
          kachel('Personen', zahl(r[1].length, 'Person', 'Personen', 'Besatzung und Gäste'), '#/personen'),
          kachel('Tiere', zahl(r[2].length, 'Tier', 'Tiere', 'Tiere an Bord'), '#/tiere'),
          kachel('Nachweisarten', zahl(r[3].length, 'Art', 'Arten', 'Führerschein, Ausweis, Heimtierausweis und mehr'), '#/nachweisarten'),
          kachel('Orte', zahl(r[4].length, 'Ort', 'Orte', 'Häfen, Stellplätze und ihre Standorte'), '#/orte'),
          kachel('Gebiete', zahl(r[5].length, 'Gebiet', 'Gebiete', 'Länder und Reviere mit ihren Regeln'), '#/gebiete'))
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/auswahl', text: 'Zurück' })));
    });
  }

  /* ---------- Neu im Programm ---------- */
  function seiteNeuerungen() {
    seite('Neu im Programm', [
      h('h1', { text: 'Neu im Programm' }),
      h('div', { class: 'neuerungen' }, MM.Texte.NEUERUNGEN.map(function (v) {
        return h('section', { class: 'neuerung' },
          h('h2', { text: 'Version ' + v.version }),
          h('p', { class: 'datum', text: MM.Hilfen.datum(v.datum) }),
          h('ul', null, v.punkte.map(function (t) { return h('li', { text: t }); })));
      }))
    ], h('div', { class: 'leiste' },
      h('a', { class: 'knopf leise', href: '#/', text: 'Zur Startseite' }),
      h('a', { class: 'knopf', href: '#/auswahl', text: 'Programm starten' })));
    return Promise.resolve();
  }

  /* ---------- Einstellungen ---------- */
  /* ---------- Sicherung ---------- */
  var ERINNERUNG_WAHL = [{ wert: '0', label: 'Nie erinnern' }, { wert: '14', label: 'Nach 14 Tagen' }, { wert: '30', label: 'Nach 30 Tagen' }, { wert: '90', label: 'Nach 90 Tagen' }];

  function sicherungBlock(info) {
    var meld = h('p', { class: 'hinweis', role: 'status' });
    var sel = h('select', { id: 'erinnerung', 'aria-label': 'Erinnerung an die Sicherung', onchange: function () {
      daten.sicherungEinstellen({ erinnerungTage: parseInt(sel.value, 10) }).then(function () { meld.textContent = 'Gespeichert.'; }).catch(fehlerSeite);
    } }, ERINNERUNG_WAHL.map(function (o) { return h('option', { value: o.wert, text: o.label }); }));
    sel.value = String(info.erinnerungTage);
    return h('section', { class: 'block' },
      h('h2', { text: 'Sicherung' }),
      info.letzte ? h('p', { text: 'Letzte Sicherung: ' + MM.Hilfen.zeitpunkt(info.letzte) + ' Uhr.' })
        : h('p', { class: info.hatDaten ? 'fehler' : null, text: info.hatDaten ? 'Du hast noch nie gesichert. Geht das Gerät kaputt, sind die Daten weg.' : 'Noch nie gesichert. Es gibt auch noch nichts zu sichern.' }),
      h('p', { class: 'knopfzeile' },
        h('a', { class: 'knopf', href: '#/einstellungen/sichern', text: 'Sicherung erstellen' }),
        h('a', { class: 'knopf leise', href: '#/einstellungen/wiederherstellen', text: 'Wiederherstellen' })),
      h('div', { class: 'feld' }, h('label', { for: 'erinnerung', text: 'Erinnerung' }), h('div', { class: 'eingabe' }, sel), meld));
  }

  function zahlenListe(z) {
    var teile = [['fahrzeuge', 'Fahrzeuge'], ['komponenten', 'Komponenten'], ['fristen', 'Fristen'], ['zaehler', 'Zähler'], ['personen', 'Personen'], ['tiere', 'Tiere'], ['nachweise', 'Nachweise'], ['aktivitaeten', 'Aktivitäten'], ['dokumente', 'Dokumente']];
    return teile.filter(function (t) { return z[t[0]]; }).map(function (t) { return z[t[0]] + ' ' + t[1]; }).join(', ') || 'noch nichts';
  }

  function dateiSpeichern(bytes, name) {
    var url = global.URL.createObjectURL(new global.Blob([bytes], { type: 'application/octet-stream' }));
    var a = doc.createElement('a');
    a.href = url; a.download = name;
    doc.body.appendChild(a); a.click(); a.remove();
    global.setTimeout(function () { global.URL.revokeObjectURL(url); }, 60000);
  }

  function seiteSichern() {
    return daten.sicherungZahlen().then(function (z) {
      var fel = h('p', { class: 'fehler', role: 'alert' });
      var status = h('p', { class: 'hinweis', role: 'status' });
      var cb = h('input', { type: 'checkbox', id: 'sx-dateien', checked: z.dateien ? 'checked' : null });
      var pw1 = h('input', { type: 'password', id: 'sx-pw1', autocomplete: 'new-password', 'aria-describedby': 'sx-pw-hilfe' });
      var pw2 = h('input', { type: 'password', id: 'sx-pw2', autocomplete: 'new-password' });
      var knopf = h('button', { class: 'knopf', type: 'button', text: 'Sicherung erstellen' });
      var behaelter = h('div');

      function ergebnis(s) {
        behaelter.textContent = '';
        var jetztIso = daten.jetzt();
        function markieren() { daten.sicherungEinstellen({ letzteSicherung: jetztIso }); }
        var teilen = null;
        try {
          var f = new global.File([s.bytes], s.name, { type: 'application/octet-stream' });
          if (global.navigator.canShare && global.navigator.canShare({ files: [f] })) {
            teilen = h('button', { class: 'knopf leise', type: 'button', text: 'Teilen oder in die Cloud legen', onclick: function () {
              global.navigator.share({ files: [f], title: 'MobiMory-Sicherung' }).then(markieren).catch(function () {});
            } });
          }
        } catch (e) { teilen = null; }
        behaelter.appendChild(h('section', { class: 'block' },
          h('h2', { text: 'Die Sicherung ist fertig' }),
          h('dl', { class: 'daten stapel' },
            h('dt', { text: 'Datei' }), h('dd', { text: s.name }),
            h('dt', { text: 'Größe' }), h('dd', { text: MM.Hilfen.groesse(s.groesse) }),
            h('dt', { text: 'Enthält' }), h('dd', { text: zahlenListe(s.zahlen) + (s.mitDateien ? '; dazu ' + s.dateien + (s.dateien === 1 ? ' Datei' : ' Dateien') + ' (Dokumente und Scans)' : '; ohne Dokumente und Scans') }),
            h('dt', { text: 'Schutz' }), h('dd', { text: s.verschluesselt ? 'Mit Schlüsselwort verschlüsselt' : 'Ohne Schlüsselwort, jeder kann sie lesen' })),
          h('p', { class: 'knopfzeile' },
            h('button', { class: 'knopf', type: 'button', text: 'Auf dem Gerät speichern', onclick: function () { dateiSpeichern(s.bytes, s.name); markieren(); } }),
            teilen),
          h('p', { class: 'hinweis', text: 'Lege die Datei an einen sicheren Ort, am besten nicht nur auf diesem Gerät, zum Beispiel in deiner Cloud oder per E-Mail an dich selbst. Ob die Datei gut angekommen ist, siehst du dort. Danach merkt sich die App das Datum.' }),
          s.verschluesselt ? h('p', { class: 'hinweis', text: 'Merke dir das Schlüsselwort gut. Ohne es lässt sich die Sicherung nicht mehr öffnen.' }) : null,
          h('p', null, h('a', { class: 'knopf leise', href: '#/einstellungen', text: 'Fertig' }))));
      }

      knopf.addEventListener('click', function () {
        fel.textContent = '';
        var w1 = pw1.value, w2 = pw2.value;
        if (w1 || w2) {
          if (w1.length < 8) { fel.textContent = 'Das Schlüsselwort braucht mindestens 8 Zeichen.'; pw1.focus(); return; }
          if (w1 !== w2) { fel.textContent = 'Die beiden Schlüsselwörter sind nicht gleich.'; pw2.focus(); return; }
        } else if (!global.confirm('Ohne Schlüsselwort kann jeder die Datei lesen, der sie bekommt. Darin stehen auch Ausweisdaten. Trotzdem ohne Schlüsselwort sichern?')) {
          return;
        }
        knopf.disabled = true;
        status.textContent = 'Die Sicherung wird erstellt. Das kann bei vielen Dateien etwas dauern …';
        daten.sicherungErzeugen({ mitDateien: cb.checked, schluessel: w1 }).then(function (s) { status.textContent = ''; ergebnis(s); })
          .catch(function (err) { knopf.disabled = false; status.textContent = ''; fel.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler') + '. Es wurde nichts verändert.'; });
      });

      behaelter.appendChild(h('div', { class: 'formular' },
        h('p', { text: 'Die Sicherungsdatei enthält alle deine Daten. Mit ihr bekommst du alles zurück, wenn das Gerät kaputt geht, und kannst auf ein neues Gerät umziehen.' }),
        z.dateien ? h('div', { class: 'feld' },
          h('label', { class: 'checkzeile' }, cb, h('span', { text: 'Dokumente und Scans mitsichern (' + z.dateien + (z.dateien === 1 ? ' Datei, ' : ' Dateien, ') + MM.Hilfen.groesse(z.dateiBytes) + ')' })),
          h('p', { class: 'hilfe', text: 'Ohne Dateien wird die Sicherung klein. Die Dokumente und Scans müssen dann nach einer Wiederherstellung neu abgelegt werden.' })) : null,
        h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
          h('legend', { class: 'fest-art', text: 'Schlüsselwort (empfohlen)' }),
          h('p', { class: 'hilfe', id: 'sx-pw-hilfe', text: 'Die Datei enthält Ausweisdaten und Scans. Mit einem Schlüsselwort ist sie verschlüsselt. Vergisst du es, kann niemand die Sicherung öffnen, auch ich nicht. Ohne Schlüsselwort kann sie jeder lesen.' }),
          h('label', { for: 'sx-pw1', text: 'Schlüsselwort' }), h('div', { class: 'eingabe' }, pw1),
          h('label', { for: 'sx-pw2', text: 'Schlüsselwort wiederholen' }), h('div', { class: 'eingabe' }, pw2)),
        fel, status, h('p', null, knopf)));

      seite('Sicherung erstellen', [
        krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen', '#/einstellungen'], ['Sicherung erstellen']]),
        h('h1', { text: 'Sicherung erstellen' }), behaelter
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/einstellungen', text: 'Zurück' })));
    });
  }

  function seiteWiederherstellen() {
    var behaelter = h('div');
    var zustand = { bytes: null };

    function zeigeWahl(fehlertext) {
      behaelter.textContent = '';
      var eingabe = h('input', { type: 'file', id: 'wd-datei', onchange: function () {
        var f = eingabe.files && eingabe.files[0];
        if (!f) return;
        f.arrayBuffer().then(function (buf) { zustand.bytes = new Uint8Array(buf); return versuchen(''); }).catch(function (e) { zeigeWahl('Die Datei konnte nicht gelesen werden: ' + (e && e.message ? e.message : '')); });
      } });
      behaelter.appendChild(h('div', { class: 'formular' },
        h('div', { class: 'fehlerkasten' }, 'Beim Wiederherstellen werden ALLE Daten auf diesem Gerät durch die der Sicherung ersetzt. Zusammenführen gibt es nicht.'),
        h('div', { class: 'feld' }, h('label', { for: 'wd-datei', text: 'Sicherungsdatei auswählen' }), h('div', { class: 'eingabe' }, eingabe)),
        fehlertext ? h('p', { class: 'fehler', role: 'alert', text: fehlertext }) : null,
        h('p', { class: 'hinweis', text: 'Es wird noch nichts verändert. Zuerst siehst du, was in der Sicherung steht.' })));
    }

    function zeigeSchluessel(fehlertext) {
      behaelter.textContent = '';
      var pw = h('input', { type: 'password', id: 'wd-pw', autocomplete: 'current-password' });
      behaelter.appendChild(h('div', { class: 'formular' },
        h('p', { text: 'Diese Sicherung ist verschlüsselt. Gib das Schlüsselwort ein.' }),
        h('div', { class: 'feld' }, h('label', { for: 'wd-pw', text: 'Schlüsselwort' }), h('div', { class: 'eingabe' }, pw)),
        fehlertext ? h('p', { class: 'fehler', role: 'alert', text: fehlertext }) : null,
        h('p', { class: 'knopfzeile' },
          h('button', { class: 'knopf', type: 'button', text: 'Öffnen', onclick: function () { versuchen(pw.value); } }),
          h('button', { class: 'knopf leise', type: 'button', text: 'Andere Datei', onclick: function () { zeigeWahl(); } }))));
    }

    function versuchen(wort) {
      return daten.sicherungLesen(zustand.bytes, wort).then(function (g) { return zeigeVorschau(g); }).catch(function (err) {
        if (err && err.code === 'schluessel_noetig') return zeigeSchluessel();
        if (err && err.code === 'schluessel') return zeigeSchluessel(err.message);
        zeigeWahl(err && err.message ? err.message : 'Die Datei lässt sich nicht lesen.');
      });
    }

    function zeigeVorschau(g) {
      return daten.sicherungVorschau(g).then(function (v) {
        behaelter.textContent = '';
        var teile = [['fahrzeuge', 'Fahrzeuge'], ['komponenten', 'Komponenten'], ['fristen', 'Fristen'], ['zaehler', 'Zähler'], ['personen', 'Personen'], ['tiere', 'Tiere'], ['nachweise', 'Nachweise'], ['aktivitaeten', 'Aktivitäten'], ['dokumente', 'Dokumente']];
        var ok = h('input', { type: 'checkbox', id: 'wd-ok' });
        var los = h('button', { class: 'knopf gefahr', type: 'button', text: 'Jetzt wiederherstellen', disabled: 'disabled' });
        var fel = h('p', { class: 'fehler', role: 'alert' });
        ok.addEventListener('change', function () { if (ok.checked) los.removeAttribute('disabled'); else los.setAttribute('disabled', 'disabled'); });
        los.addEventListener('click', function () {
          los.setAttribute('disabled', 'disabled'); fel.textContent = '';
          daten.sicherungEinspielen(g).then(function () {
            meldung = 'Wiederhergestellt: Die Sicherung vom ' + MM.Hilfen.zeitpunkt(v.erstelltAm) + ' Uhr ist jetzt auf diesem Gerät.';
            if (global.location.hash === '#/auswahl') return zeige();
            global.location.hash = '#/auswahl';
          }).catch(function (err) { los.removeAttribute('disabled'); fel.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : '') + ' Es wurde nichts verändert.'; });
        });
        behaelter.appendChild(h('div', { class: 'formular' },
          h('p', null, 'Sicherung vom ', h('strong', { text: MM.Hilfen.zeitpunkt(v.erstelltAm) + ' Uhr' }), ', erstellt mit MobiMory ' + (v.app || '?') + '.'),
          h('table', { class: 'vergleich' },
            h('thead', null, h('tr', null, h('th', { text: '' }), h('th', { text: 'In der Sicherung' }), h('th', { text: 'Jetzt hier' }))),
            h('tbody', null, teile.filter(function (t) { return v.zahlen[t[0]] || v.jetzt[t[0]]; }).map(function (t) {
              return h('tr', null, h('td', { text: t[1] }), h('td', { text: String(v.zahlen[t[0]] || 0) }), h('td', { text: String(v.jetzt[t[0]] || 0) }));
            }))),
          v.mitDateien ? h('p', { text: 'Dokumente und Scans: enthalten (' + v.dateien + (v.dateien === 1 ? ' Datei, ' : ' Dateien, ') + MM.Hilfen.groesse(v.dateiBytes) + ').' })
            : h('p', { class: 'hinweis', text: 'Dokumente und Scans: nicht in der Sicherung. Sie müssen nach der Wiederherstellung neu abgelegt werden.' }),
          h('div', { class: 'fehlerkasten', text: 'Alles, was jetzt auf diesem Gerät steht, wird ersetzt. Was nach dieser Sicherung dazugekommen ist, geht verloren.' }),
          h('p', null, h('a', { href: '#/einstellungen/sichern', text: 'Zuerst den jetzigen Stand sichern' })),
          h('div', { class: 'feld' }, h('label', { class: 'checkzeile' }, ok, h('span', { text: 'Ich weiß es: Alle Daten auf diesem Gerät werden ersetzt.' }))),
          fel, h('p', null, los),
          h('p', null, h('button', { class: 'knopf leise', type: 'button', text: 'Andere Datei', onclick: function () { zeigeWahl(); } }))));
      });
    }

    zeigeWahl();
    seite('Wiederherstellen', [
      krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen', '#/einstellungen'], ['Wiederherstellen']]),
      h('h1', { text: 'Aus Sicherung wiederherstellen' }), behaelter
    ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/einstellungen', text: 'Zurück' })));
    return Promise.resolve();
  }

  function schaetzung() {
    var n = global.navigator;
    if (!n.storage || !n.storage.estimate) return Promise.resolve(null);
    return Promise.all([
      n.storage.estimate().catch(function () { return null; }),
      n.storage.persisted ? n.storage.persisted().catch(function () { return null; }) : Promise.resolve(null)
    ]).then(function (r) { return r[0] ? { usage: r[0].usage, quota: r[0].quota, dauerhaft: r[1] } : null; });
  }

  function seiteEinstellungen() {
    return Promise.all([daten.dateienBelegung(), schaetzung(), daten.scansBelegung(), daten.sicherungInfo()]).then(function (r) {
      var dat = r[0], sp = r[1], scans = r[2], sicherung = r[3];
      var speicherZeilen = [
        h('p', { text: 'Dokumente auf diesem Gerät: ' + (dat.anzahl === 1 ? '1 Datei' : dat.anzahl + ' Dateien') + (dat.anzahl ? ', zusammen ' + MM.Hilfen.groesse(dat.bytes) : '') + '.' })
      ];
      speicherZeilen.push(h('p', { text: 'Scans und Fotos von Nachweisen: ' + (scans.anzahl === 1 ? '1 Datei' : scans.anzahl + ' Dateien') + (scans.anzahl ? ', zusammen ' + MM.Hilfen.groesse(scans.bytes) : '') + '. Sie bleiben immer nur auf diesem Gerät.' }));
      if (sp && sp.quota) {
        speicherZeilen.push(h('p', { text: 'Der Browser erlaubt MobiMory auf diesem Gerät insgesamt etwa ' + MM.Hilfen.groesse(sp.quota) + '. Davon sind etwa ' + MM.Hilfen.groesse(sp.usage) + ' belegt.' }));
        if (sp.dauerhaft !== null) speicherZeilen.push(h('p', { class: 'hinweis', text: sp.dauerhaft ? 'Der Browser löscht diese Daten nicht von selbst.' : 'Der Browser darf diese Daten bei Platzmangel löschen. Mit „Zum Startbildschirm hinzufügen“ ist das unwahrscheinlicher.' }));
      } else {
        speicherZeilen.push(h('p', { class: 'hinweis', text: 'Dieser Browser nennt keine Angabe zum freien Platz.' }));
      }
      seite('Einstellungen', [
        krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen']]),
        h('h1', { text: 'Einstellungen' }),
        h('section', { class: 'block' },
          h('h2', { text: 'Deine Daten' }),
          h('p', { text: 'Deine Daten liegen nur auf diesem Gerät. Eine automatische Sicherung gibt es noch nicht. Mit der Sicherungsdatei schützt du dich davor, dass bei einem Geräteschaden alles weg ist.' })),
        sicherungBlock(sicherung),
        h('section', { class: 'block' }, h('h2', { text: 'Speicher auf diesem Gerät' }), speicherZeilen),
        h('section', { class: 'block' },
          h('h2', { text: 'Über MobiMory' }),
          h('p', { text: 'Version ' + MM.VERSION + ' (' + MM.STUFE + ')' }),
          h('p', { text: MM.Texte.COPYRIGHT }),
          h('p', { class: 'hinweis', text: 'MobiMory ist eine Hilfestellung und trifft keine rechtliche Aussage. Die letzte Verantwortung hat der verantwortliche Skipper bzw. Fahrer.' })),
        h('details', { class: 'block test' },
          h('summary', { text: 'Nur für Tests' }),
          h('p', { text: 'Löscht alle Fahrzeuge und Dokumente auf diesem Gerät. Das lässt sich nicht rückgängig machen.' }),
          h('button', { class: 'knopf gefahr', type: 'button', text: 'Alle Daten auf diesem Gerät löschen',
            onclick: function () {
              if (global.confirm('Wirklich alle Daten auf diesem Gerät löschen?')) {
                daten.allesLoeschen().then(function () { meldung = 'Alle Daten auf diesem Gerät wurden gelöscht.'; return zeige(); }).catch(fehlerSeite);
              }
            } }))
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/auswahl', text: 'Zurück' })));
    });
  }

  function fehlerSeite(err) {
    wurzel.textContent = '';
    wurzel.appendChild(kopf());
    wurzel.appendChild(h('main', { class: 'fehlerseite' },
      h('h1', { text: 'Das hat nicht geklappt' }),
      h('p', { text: (err && err.message) ? err.message : 'Es ist ein unbekannter Fehler aufgetreten.' }),
      h('p', null, h('a', { class: 'knopf', href: '#/auswahl', text: 'Zum Hauptmenü' }))));
  }

  /* ---------- Weiterleitung nach der Adresse ---------- */
  /*
   * Seiten werden immer der Reihe nach aufgebaut und lesen dabei die aktuelle Adresse.
   * So kann eine langsamere ältere Seite nie eine neuere überschreiben, wenn schnell
   * hintereinander getippt wird.
   */
  var aufbauKette = Promise.resolve();
  function zeige() {
    var aufgabe = aufbauKette.then(function () { return zeigeJetzt(); });
    aufbauKette = aufgabe.catch(function () {});
    return aufgabe;
  }

  function zeigeJetzt() {
    var hash = (global.location.hash || '#/').replace(/^#/, '').split('?')[0];
    var teile = hash.split('/').filter(Boolean);
    var p;
    if (teile.length === 0) p = seiteStart();
    else if (teile[0] === 'auswahl') p = seiteHauptmenue();
    else if (teile[0] === 'stammdaten') p = seiteStammdaten();
    else if (teile[0] === 'fahrzeuge') p = seiteListe();
    else if (teile[0] === 'neu-im-programm') p = seiteNeuerungen();
    else if (teile[0] === 'einstellungen' && teile[1] === 'sichern') p = seiteSichern();
    else if (teile[0] === 'einstellungen' && teile[1] === 'wiederherstellen') p = seiteWiederherstellen();
    else if (teile[0] === 'einstellungen') p = seiteEinstellungen();
    else if (teile[0] === 'neu') p = seiteFormular('neu');
    else if (teile[0] === 'funktionen') p = seiteFunktionen();
    else if (teile[0] === 'aktivitaeten') p = seiteAktivitaeten();
    else if (teile[0] === 'aktivitaet' && teile[1] === 'neu') p = aktivitaetFormular('neu', (/fahrzeug=([^&]+)/.exec(global.location.hash) || [])[1] ? decodeURIComponent(/fahrzeug=([^&]+)/.exec(global.location.hash)[1]) : '');
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'aendern') p = aktivitaetFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'stornieren') p = stornoFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'besatzung' && teile[3] === 'neu') p = besatzungFormular('neu', decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'verantwortung') p = verantwortungFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1]) p = seiteAktivitaet(decodeURIComponent(teile[1]));
    else if (teile[0] === 'besatzung' && teile[1] && teile[2] === 'aendern') p = besatzungFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaetsarten') p = seiteAktivitaetsarten();
    else if (teile[0] === 'aktivitaetsart' && teile[1] === 'neu') p = aktivitaetsartFormular('neu');
    else if (teile[0] === 'aktivitaetsart' && teile[1] && teile[2] === 'aendern') p = aktivitaetsartFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'orte' && teile[1] === 'neu') p = benanntFormular('ort', 'neu');
    else if (teile[0] === 'orte') p = seiteBenanntListe('ort');
    else if (teile[0] === 'ort' && teile[1] && teile[2] === 'aendern') p = benanntFormular('ort', 'aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'ort' && teile[1] && teile[2] === 'standort' && teile[3] === 'neu') p = standortFormular('neu', decodeURIComponent(teile[1]));
    else if (teile[0] === 'ort' && teile[1]) p = seiteBenannt('ort', decodeURIComponent(teile[1]));
    else if (teile[0] === 'standort' && teile[1] && teile[2] === 'aendern') p = standortFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'gebiete' && teile[1] === 'neu') p = benanntFormular('gebiet', 'neu');
    else if (teile[0] === 'gebiete') p = seiteBenanntListe('gebiet');
    else if (teile[0] === 'gebiet' && teile[1] && teile[2] === 'aendern') p = benanntFormular('gebiet', 'aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'gebiet' && teile[1] && teile[2] === 'regel' && teile[3] === 'neu') p = regelFormular('neu', decodeURIComponent(teile[1]));
    else if (teile[0] === 'gebiet' && teile[1]) p = seiteBenannt('gebiet', decodeURIComponent(teile[1]));
    else if (teile[0] === 'regel' && teile[1] && teile[2] === 'aendern') p = regelFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'heimatstandort') p = heimatstandortFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'anforderung' && teile[1] && teile[2] === 'aendern') p = anforderungFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'anforderung' && teile[3] === 'neu') p = anforderungFormular('neu', decodeURIComponent(teile[1]));
    else if (teile[0] === 'personen' && teile[1] === 'neu') p = besitzerFormular('person', 'neu');
    else if (teile[0] === 'personen') p = seiteBesitzerListe('person');
    else if (teile[0] === 'person' && teile[1] && teile[2] === 'aendern') p = besitzerFormular('person', 'aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'person' && teile[1] && teile[2] === 'nachweis' && teile[3] === 'neu') p = nachweisFormular('neu', 'person', decodeURIComponent(teile[1]));
    else if (teile[0] === 'person' && teile[1]) p = seiteBesitzer('person', decodeURIComponent(teile[1]));
    else if (teile[0] === 'tiere' && teile[1] === 'neu') p = besitzerFormular('tier', 'neu');
    else if (teile[0] === 'tiere') p = seiteBesitzerListe('tier');
    else if (teile[0] === 'tier' && teile[1] && teile[2] === 'aendern') p = besitzerFormular('tier', 'aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'tier' && teile[1] && teile[2] === 'nachweis' && teile[3] === 'neu') p = nachweisFormular('neu', 'tier', decodeURIComponent(teile[1]));
    else if (teile[0] === 'tier' && teile[1]) p = seiteBesitzer('tier', decodeURIComponent(teile[1]));
    else if (teile[0] === 'nachweis' && teile[1] && teile[2] === 'aendern') p = nachweisFormular('aendern', null, decodeURIComponent(teile[1]));
    else if (teile[0] === 'nachweis' && teile[1]) p = seiteNachweis(decodeURIComponent(teile[1]));
    else if (teile[0] === 'nachweisarten' && teile[1] === 'vorschlaege') p = seiteVorschlaege();
    else if (teile[0] === 'nachweisarten') p = seiteNachweisarten();
    else if (teile[0] === 'nachweisart' && teile[1] === 'neu') p = nachweisartFormular('neu');
    else if (teile[0] === 'nachweisart' && teile[1] && teile[2] === 'aendern') p = nachweisartFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'nachweisart' && teile[1]) p = seiteNachweisart(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'nachweis' && teile[3] === 'neu') p = nachweisFormular('neu', 'fahrzeug', decodeURIComponent(teile[1]));
    else if (teile[0] === 'dokument' && teile[1] && teile[2] === 'aendern') p = dokumentFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'dokument' && teile[1]) p = seiteDokument(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'dokumente') p = seiteDokumente(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'dokument' && teile[3] === 'neu') p = dokumentFormular('neu-fz', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'dokument' && teile[3] === 'neu') p = dokumentFormular('neu-komp', decodeURIComponent(teile[1]));
    else if (teile[0] === 'frist' && teile[1] && teile[2] === 'aendern') p = fristFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'frist' && teile[1] && teile[2] === 'erledigt') p = erledigtFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'frist' && teile[1]) p = seiteFrist(decodeURIComponent(teile[1]));
    else if (teile[0] === 'zaehler' && teile[1] && teile[2] === 'stand') p = standFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'zaehler' && teile[1] && teile[2] === 'aendern') p = zaehlerFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'zaehler' && teile[1]) p = seiteZaehler(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'frist' && teile[3] === 'neu') p = fristFormular('neu-fz', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'zaehler' && teile[3] === 'neu') p = zaehlerFormular('neu-fz', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'frist' && teile[3] === 'neu') p = fristFormular('neu-komp', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'zaehler' && teile[3] === 'neu') p = zaehlerFormular('neu-komp', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'neu') p = seiteKomponentenFormular('neu-teil', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'aendern') p = seiteKomponentenFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1]) p = seiteKomponente(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'komponente' && teile[3] === 'neu') p = seiteKomponentenFormular('neu-haupt', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'aendern') p = seiteFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1]) p = seiteFahrzeug(decodeURIComponent(teile[1]));
    else p = seiteStart();
    return p.catch(fehlerSeite);
  }

  function starten(d, el) {
    daten = d; wurzel = el;
    global.addEventListener('hashchange', zeige);
    return zeige();
  }

  MM.Ansicht = { starten: starten, fehler: function (el, err) { wurzel = el; fehlerSeite(err); } };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
