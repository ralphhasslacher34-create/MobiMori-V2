'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/orte.js');
const MM = globalThis.MM;

const regel = (extra) => Object.assign({ id: 'r1', bezeichnung: 'Funkzeugnis', fahrzeugArten: [], ausruestung: null, artIds: ['a1'], gilt: 'ja' }, extra || {});

test('Ausrüstung: leer passt immer, sonst muss ein Komponentenname den Text enthalten (Groß/Klein egal)', () => {
  assert.equal(MM.Orte.ausruestungVorhanden('', []), true);
  assert.equal(MM.Orte.ausruestungVorhanden(null, []), true);
  assert.equal(MM.Orte.ausruestungVorhanden('Funkanlage', ['Motor', 'UKW-Funkanlage Icom']), true);
  assert.equal(MM.Orte.ausruestungVorhanden('funkanlage', ['FUNKANLAGE']), true);
  assert.equal(MM.Orte.ausruestungVorhanden('Funkanlage', ['Motor', 'Heizung']), false);
  assert.equal(MM.Orte.ausruestungVorhanden('Funkanlage', []), false);
});

test('Regeln auswerten: ohne Bedingung greift die Regel für jedes Fahrzeug', () => {
  const r = MM.Orte.regelnAuswerten({ regeln: [regel()], fahrzeugArt: 'wohnmobil', komponentenNamen: [] });
  assert.equal(r.greifen.length, 1);
  assert.equal(r.nichtGreifen.length, 0);
});

test('Regeln auswerten: Fahrzeugart als Bedingung, mit Grund wenn sie nicht greift', () => {
  const regeln = [regel({ fahrzeugArten: ['boot'] })];
  assert.equal(MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'boot', komponentenNamen: [] }).greifen.length, 1);
  const r = MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'auto', komponentenNamen: [] });
  assert.equal(r.greifen.length, 0);
  assert.equal(r.nichtGreifen.length, 1);
  assert.match(r.nichtGreifen[0].grund, /Boot/);
});

test('Regeln auswerten: Ausrüstung als Bedingung, abgeschaltete Regeln fehlen ganz', () => {
  const regeln = [regel({ ausruestung: 'Funkanlage' }), regel({ id: 'r2', gilt: 'nein' })];
  const mit = MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'boot', komponentenNamen: ['Funkanlage Icom'] });
  assert.deepEqual(mit.greifen.map(x => x.id), ['r1']);
  assert.equal(mit.nichtGreifen.length, 0);
  const ohne = MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'boot', komponentenNamen: ['Motor'] });
  assert.equal(ohne.greifen.length, 0);
  assert.equal(ohne.nichtGreifen.length, 1);
  assert.match(ohne.nichtGreifen[0].grund, /Funkanlage/);
});

test('Regeln auswerten: Fahrzeugart und Ausrüstung müssen beide passen', () => {
  const regeln = [regel({ fahrzeugArten: ['boot'], ausruestung: 'Funk' })];
  assert.equal(MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'boot', komponentenNamen: ['Funk'] }).greifen.length, 1);
  assert.equal(MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'auto', komponentenNamen: ['Funk'] }).greifen.length, 0);
  assert.equal(MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'boot', komponentenNamen: [] }).greifen.length, 0);
});
