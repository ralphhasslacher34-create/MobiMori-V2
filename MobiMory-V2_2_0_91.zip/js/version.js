/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.91';
  MM.STUFE = 'Schadensbericht am Fahrzeug; Planung je Tag mit Karte des Tages; Planung der ganzen Aktivität unverändert';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
