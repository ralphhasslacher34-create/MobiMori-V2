'use strict';
/* 2.0.81 (Bau 4): Reisebuch. PDF mit JPEG-Bild, Buch aus den Angaben einer Reise, Lesen ohne Änderung der Daten, Einbau. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'etappen', 'reisecheck', 'pdf', 'reisebuch', 'daten']
  .forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

/* kleinstes lesbares JPEG: SOI, SOF0 (2 x 3 Punkt, 3 Komponenten), EOI */
const JPEG = Uint8Array.from([0xFF, 0xD8, 0xFF, 0xC0, 0x00, 0x11, 0x08, 0x00, 0x03, 0x00, 0x02, 0x03, 1, 0x11, 0, 2, 0x11, 0, 3, 0x11, 0, 0xFF, 0xD9]);
const alsText = (b) => Buffer.from(b).toString('latin1');

test('PDF: ein JPEG wird eingebettet, Unlesbares wird abgelehnt, die Tabelle der Objekte stimmt', () => {
  assert.deepEqual(MM.Pdf.jpegInfo(JPEG), { breite: 2, hoehe: 3, komponenten: 3 });
  assert.equal(MM.Pdf.jpegInfo(Uint8Array.from([1, 2, 3])), null);
  const d = MM.Pdf.neu({ fuss: 'x' });
  d.titel('Test');
  assert.equal(d.bild(Uint8Array.from([1, 2, 3, 4])), false);
  assert.equal(d.bild(JPEG, { unterschrift: 'Abfahrt, 09:30' }), true);
  assert.equal(d.bilderAnzahl(), 1);
  const t = alsText(d.bytes());
  assert.ok(t.startsWith('%PDF-1.4'));
  assert.match(t, /\/Subtype \/Image \/Width 2 \/Height 3 \/ColorSpace \/DeviceRGB/);
  assert.match(t, /\/DCTDecode/);
  assert.match(t, /\/XObject << \/Im1 8 0 R >>/);
  /* Die Lage jedes Objekts aus der Tabelle stimmt */
  const xref = Number(/startxref\n(\d+)/.exec(t)[1]);
  assert.ok(t.slice(xref).startsWith('xref'));
  const zeilen = t.slice(xref).split('\n').slice(3).filter((z) => /^\d{10} 00000 n/.test(z));
  zeilen.forEach((z, i) => assert.ok(t.slice(Number(z.slice(0, 10))).startsWith((i + 1) + ' 0 obj'), 'Objekt ' + (i + 1)));
});

const roh = () => ({
  titel: 'Sommer am See', vonDatum: '2026-07-01', bisDatum: '2026-07-03', welt: 'land', einheit: 'km', fahrzeug: { name: 'Wohnmobil', artName: 'Wohnmobil' },
  art: 'Urlaub', start: 'Stuttgart', ziel: 'München', zwischenziele: ['Ulm'], gebiet: '', notiz: 'Schöne Reise',
  besatzung: [{ name: 'Anna', rolle: 'Fahrer' }], tiere: [], streckeSumme: 230,
  tage: [
    { id: 't1', datum: '2026-07-01', beginn: '08:00', ende: '17:00', start: 'Stuttgart', ziel: 'Ulm', strecke: 95, verantwortlicher: 'Anna', notiz: 'Sonnig',
      ereignisse: [{ id: 'e1', zeit: '09:30', art: 'Abfahrt', text: 'Los gehts', ort: '', hatFoto: true, ausgeblendet: false },
        { id: 'e2', zeit: '10:00', art: 'Pause', text: 'GEHEIM', ort: '', hatFoto: true, ausgeblendet: true }] },
    { id: 't2', datum: '2026-07-02', beginn: '', ende: '', start: '', ziel: '', strecke: null, verantwortlicher: '', notiz: '', ereignisse: [] }
  ],
  besuche: [{ ort: 'Ulm', datum: '2026-07-01', notiz: 'Münster' }],
  kosten: { gesamt: 300, fahrzeug: 200, reisekasse: 100, proPerson: 300, proTag: 100 }
});

test('Buch: nichts Ausgeblendetes, Kosten und Fotos nur nach Wahl, Notizen abschaltbar', () => {
  const b = MM.Reisebuch.bauen(roh());
  assert.equal(b.titel, 'Sommer am See');
  assert.equal(b.tage.length, 2);
  assert.equal(b.tage[0].ereignisse.length, 1);
  assert.ok(!JSON.stringify(b).includes('GEHEIM'));
  assert.deepEqual(b.bildIds, ['e1']);
  assert.equal(b.kosten, null, 'Kosten stehen nur auf Wunsch im Buch');
  assert.equal(b.tage[0].ereignisse[0].text, 'Los gehts');
  assert.ok(b.zahlen.some((z) => z[0] === 'Fotos' && z[1] === '1'));
  assert.ok(b.zahlen.some((z) => z[0] === 'Reisetage' && z[1] === '3'));
  const k = MM.Reisebuch.bauen(roh(), { kosten: true, bilder: false, notizen: false });
  assert.ok(k.kosten && k.kosten.zeilen[0][0] === 'Gesamt');
  assert.deepEqual(k.bildIds, []);
  assert.equal(k.tage[0].ereignisse[0].text, '');
  assert.equal(k.tage[0].notiz, '');
  assert.ok(!k.steckbrief.some((z) => z[0] === 'Notiz'));
  assert.equal(MM.Reisebuch.dateiName(b), 'Reisebuch_Sommer_am_See.pdf');
});

test('Buch: PDF mit und ohne Foto, fehlendes Foto wird gezählt', () => {
  const b = MM.Reisebuch.bauen(roh());
  const mit = MM.Reisebuch.pdf(b, { e1: JPEG }, { datum: '2026-11-15T10:00:00Z' });
  assert.equal(mit.bilder, 1); assert.equal(mit.ohneBild, 0);
  assert.match(alsText(mit.bytes), /DCTDecode/);
  const ohne = MM.Reisebuch.pdf(b, {}, {});
  assert.equal(ohne.bilder, 0); assert.equal(ohne.ohneBild, 1);
  assert.ok(!/DCTDecode/.test(alsText(ohne.bytes)));
  assert.ok(alsText(ohne.bytes).includes('Sommer am See'));
});

async function reiseMitFoto() {
  let t = 0; const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(), holeJson: async () => { throw new Error('kein Netz'); } });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen(); await d.ereignisartenAusVorschlaegen();
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'] })).id;
  const artId = (await d.aktivitaetsartenListe()).find((a) => a.aktuell.werte.bezeichnung === 'Urlaub').objekt.id;
  const a = (await d.ortAnlegen({ bezeichnung: 'Stuttgart', positionBreite: '48,78', positionLaenge: '9,18' })).id;
  const c = (await d.ortAnlegen({ bezeichnung: 'München', positionBreite: '48,14', positionLaenge: '11,58' })).id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Reise', artId, fahrzeugId: wm, vonDatum: '2026-11-05', vonZeit: '08:00', bisDatum: '2026-11-06', verantwortlichId: anna, startOrtId: a, zielOrtId: c });
  await d.tagesabschnitteVorbereiten(r.id);
  const lb = await d.logbuchLaden(r.id);
  const ea = await d.ereignisartenListe();
  const foto = new Blob([JPEG], { type: 'image/jpeg' });
  await d.ereignisAnlegen(lb.abschnitte[0].objekt.id, { artId: ea[0].objekt.id, datum: '2026-11-05', zeit: '09:30', text: 'Los gehts', datei: foto });
  await d.ereignisAnlegen(lb.abschnitte[0].objekt.id, { artId: ea[0].objekt.id, datum: '2026-11-05', zeit: '10:30', text: 'Zweites ohne Foto' });
  return { d, id: r.id };
}

test('Daten: Reisebuch lesen und PDF erzeugen, ohne etwas zu verändern', async () => {
  const { d, id } = await reiseMitFoto();
  const vorher = JSON.stringify([await d.speicher.alle('verlaeufe'), await d.speicher.alle('ereignisse'), await d.speicher.alle('aktivitaeten')]);
  const liste = await d.reisebuecherListe();
  assert.equal(liste.length, 1); assert.equal(liste[0].id, id);
  const roh = await d.reisebuchLaden(id);
  assert.equal(roh.titel, 'Reise'); assert.equal(roh.fahrzeug.name, 'Wohnmobil');
  assert.equal(roh.besatzung[0].name, 'Anna');
  const tag = roh.tage[0];
  assert.equal(tag.ereignisse.length, 2);
  assert.equal(tag.ereignisse.filter((e) => e.hatFoto).length, 1);
  const bild = await d.reisebuchBild(tag.ereignisse.find((e) => e.hatFoto).id);
  assert.ok(bild && MM.Pdf.jpegInfo(bild));
  assert.equal(await d.reisebuchBild(tag.ereignisse.find((e) => !e.hatFoto).id), null);
  const p = await d.reisebuchPdf(id, {});
  assert.equal(p.ok, true); assert.equal(p.bilder, 1); assert.equal(p.mime, 'application/pdf'); assert.equal(p.name, 'Reisebuch_Reise.pdf');
  assert.ok(alsText(p.bytes).startsWith('%PDF-1.4'));
  const ohne = await d.reisebuchPdf(id, { bilder: false });
  assert.equal(ohne.bilder, 0);
  assert.equal((await d.reisebuchPdf('gibtsnicht', {})).ok, false);
  const nachher = JSON.stringify([await d.speicher.alle('verlaeufe'), await d.speicher.alle('ereignisse'), await d.speicher.alle('aktivitaeten')]);
  assert.equal(nachher, vorher, 'Das Reisebuch ändert nichts');
});

test('Einbau: Modul in index.html und Service Worker, Route, Kachel, Knopf bei der Reise, Druckansicht, Version 2.0.81', () => {
  assert.ok(lesen('index.html').indexOf('js/pdf.js') < lesen('index.html').indexOf('js/reisebuch.js'));
  assert.ok(lesen('sw.js').includes("'js/reisebuch.js'"));
  const a = lesen('js/ansicht.js');
  assert.ok(a.includes("teile[0] === 'reisebuch'") && a.includes("kachel('Reisebuch'") && a.includes("'#/reisebuch/' + encodeURIComponent(id)"));
  assert.ok(lesen('css/styles.css').includes('@media print'));
  assert.equal(MM.VERSION, '2.0.91');
  assert.equal(MM.Texte.NEUERUNGEN[10].version, '2.0.81');
  assert.match(MM.Texte.NEUERUNGEN[10].punkte.join(' '), /Reisebuch/);
  assert.ok(lesen('CHANGELOG.md').includes('## 2.0.81\n- **Bau 4: Reisebuch'));
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.91';"));
});

/* ---- Die echte Seite (aus ansicht.js herausgeschnitten) mit einem kleinen Ersatz für den Browser ---- */
function hBauen() {
  return function h(tag, attrs) {
    const e = { tag, kinder: [], attrs: {}, appendChild(k) { e.kinder.push(k); return k; } };
    if (attrs) Object.keys(attrs).forEach((k) => { const v = attrs[k]; if (v === null || v === undefined || v === false) return; if (k === 'text') e.kinder.push(String(v)); else e.attrs[k] = v; });
    const rein = (k) => { if (k === null || k === undefined) return; if (Array.isArray(k)) k.forEach(rein); else e.kinder.push(k); };
    for (let i = 2; i < arguments.length; i++) rein(arguments[i]);
    return e;
  };
}
const text = (e) => (typeof e === 'string' ? e : (e && e.kinder ? e.kinder.map(text).join(' ') : ''));
const finde = (e, fn, aus) => { aus = aus || []; if (!e || typeof e === 'string' || !e.kinder) return aus; if (fn(e)) aus.push(e); e.kinder.forEach((k) => finde(k, fn, aus)); return aus; };

test('Seite: Buch wird gezeigt, Auswahl schaltet Kosten zu, „PDF erzeugen“ speichert die Datei, unbekannte Reise gibt „nicht gefunden“', async () => {
  const { d, id } = await reiseMitFoto();
  const q = lesen('js/ansicht.js'), a = q.indexOf('  /* ---------- Reisebuch (seit 2.0.81'), b = q.indexOf('  /* ---------- Konto (seit 2.0.64', a);
  assert.ok(a > 0 && b > a);
  const h = hBauen(), seiten = [], gespeichert = [], urls = [];
  const global = { URL: { createObjectURL: (x) => { urls.push(x); return 'blob:x' + urls.length; }, revokeObjectURL() {} }, Blob, print() {} };
  const f = new Function('MM', 'h', 'daten', 'krumen', 'seite', 'nichtGefunden', 'anhaengen', 'global', 'dateiSpeichern', 'fehlerSeite',
    q.slice(a, b) + '\n  return { seiteReisebuch: seiteReisebuch, seiteReisebuecher: seiteReisebuecher };');
  const s = f(MM, h, d, () => h('nav'), (titel, inhalt) => { seiten.push({ titel, inhalt }); }, (t) => { seiten.push({ nichtGefunden: t }); },
    (el, kinder) => { const rein = (k) => { if (k === null || k === undefined) return; if (Array.isArray(k)) k.forEach(rein); else el.kinder.push(k); }; rein(kinder); },
    global, (bytes, name, typ) => { gespeichert.push({ bytes, name, typ }); }, (e) => { throw e; });

  await s.seiteReisebuecher();
  assert.match(seiten[0].inhalt.map(text).join(' '), /Reise/);
  await s.seiteReisebuch(id);
  await new Promise((r) => setTimeout(r, 50));
  const alle = { kinder: seiten[1].inhalt, tag: 'x', attrs: {} };
  const t = text(alle);
  assert.match(t, /Tag 1, 05\.11\.2026/); assert.match(t, /09:30 Abfahrt/); assert.match(t, /Los gehts/); assert.match(t, /Zweites ohne Foto/);
  assert.ok(!/Kosten\s+Gesamt/.test(t) && !/Gesamt/.test(t), 'Kosten stehen zuerst nicht im Buch');
  assert.equal(finde(alle, (e) => e.tag === 'img').length, 1, 'ein Foto auf der Seite');
  const kosten = finde(alle, (e) => e.tag === 'input' && e.attrs.id === 'rb-kosten')[0];
  assert.ok(kosten && !kosten.attrs.checked);
  const knopf = finde(alle, (e) => e.tag === 'button' && text(e) === 'PDF erzeugen')[0];
  knopf.attrs.onclick();
  await new Promise((r) => setTimeout(r, 100));
  assert.equal(gespeichert.length, 1);
  assert.equal(gespeichert[0].name, 'Reisebuch_Reise.pdf'); assert.equal(gespeichert[0].typ, 'application/pdf');
  assert.ok(alsText(gespeichert[0].bytes).startsWith('%PDF'));
  await s.seiteReisebuch('gibtsnicht');
  assert.ok(seiten[seiten.length - 1].nichtGefunden);
});
