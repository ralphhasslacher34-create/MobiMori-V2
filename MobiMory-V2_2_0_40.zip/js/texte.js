/*
 * Texte, die das Programm von sich selbst zeigt: Kernsatz, Infotext,
 * Copyright und die Liste "Neu im Programm". Nur hier ändern.
 * Das Logo ist die Datei icons/icon.svg (zugleich das App-Symbol).
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  MM.Texte = {
    KERNSATZ: 'Dein Fahrzeug. Dein Weg. Deine Daten.',
    INFOTEXT: 'Fahrzeuge verwalten, Reisen planen und Erinnerungen festhalten. Auf Land, zu Wasser und in der Luft.',
    COPYRIGHT: '© 2026 Ralph Hasslacher',

    /* Neueste Version zuerst. Die oberste muss zu MM.VERSION passen (wird getestet). */
    NEUERUNGEN: [
      { version: '2.0.40', datum: '2026-11-05', punkte: [
        'Grundcheck: Am Fahrzeug gibt es jetzt „Grundcheck“. Er sagt, was dein Fahrzeug an seinem Heimatort (Heimatland) an Papieren und Grundausrüstung braucht, zum Beispiel Zulassungsbescheinigung Teil 1 und 2, Warndreieck, Warnweste, Feuerlöscher. Jeder Punkt hat Quelle und Stand. Er braucht kein Datum und keine Besatzung.',
        'Die App vergleicht mit dem, was am Fahrzeug eingetragen ist: vorhanden, zu wenig, fehlt oder unklar. Es wird nichts gesperrt, und es ist keine rechtsgültige Aussage.',
        'Fehlt etwas, führt ein Knopf direkt zum Eintragen. Bei Ausrüstung öffnet sich die Komponentenliste mit Name und Menge schon vorgefüllt, du bestätigst nur. So entsteht nach und nach die Grundausrüstung deines Fahrzeugs. Papiere trägst du als Nachweis am Fahrzeug ein, mit Foto oder Scan.',
        'Neu am Fahrzeug: das Feld „Personen / Plätze“. Damit rechnet der Grundcheck Ausrüstung „je Person“, zum Beispiel Warnwesten. Ohne diese Angabe sagt er „unklar“ und rät nichts.',
        'Das Heimatland kommt vom Heimatstandort des Fahrzeugs (Ort, der über die Ortssuche geprüft ist). Ziehst du um, wählst du den neuen Heimatstandort und wiederholst den Grundcheck. Frühere Checks bleiben erhalten.',
        'Der Grundcheck nutzt den Dienst und die Zustimmung des Reisecheck. Es geht nur das Fahrzeug ohne Namen und ohne Nummern hinaus. Er zählt nicht zum Reisecheck-Kontingent, die Entscheidung kommt mit dem Kostenmodell.'
      ] },
      { version: '2.0.39', datum: '2026-11-05', punkte: [
        'Orte und Gebiete: Du gibst nur noch Orte ein. Die App prüft den Ort mit einer Suche (Netz nötig) und macht daraus das Gebiet: Land, Region, Kreis oder Département, zum Beispiel Deutschland, Baden-Württemberg, Landkreis Böblingen.',
        'Gibt es den Namen mehrfach, bekommst du eine Auswahlliste, zum Beispiel Eutingen bei Herrenberg oder bei Pforzheim. Du wählst, und die App legt den Ort mit Position an.',
        'Jedes Gebiet wird beim ersten Mal gespeichert und danach wiederverwendet. So wächst eine Gebietsbibliothek für den Reisecheck. Ein Gebiet, das du früher selbst angelegt hast und das so heißt, übernimmt die Ebene, seine Regeln bleiben.',
        'Das Gebiet richtet sich nach dem Fahrzeug: Landfahrzeuge zählen mit Land, Region und Kreis (Straße), Wasserfahrzeuge mit Land und Revier (Binnenwasserstraße, zum Beispiel Rhein, beim Ort einzutragen). Hast du nur Landfahrzeuge, siehst du nur das Straßen-Gebiet, nur Wasserfahrzeuge nur das Revier. In der Prüfung zählt das Fahrzeug der Aktivität.',
        'Die Regeln der Gebiete der Orte (Start, Ziel, Zwischenziele) gelten bei der Prüfung und gehen mit den Gebieten in den Reisecheck. Ist ein Ort nicht geprüft oder fehlt das Revier, sagt die App „unklar“. Es wird nichts gesperrt, und du kannst Orte weiter ohne Prüfung anlegen.'
      ] },
      { version: '2.0.38', datum: '2026-11-05', punkte: [
        'Reisecheck: Für jede Aktivität kannst du online prüfen lassen, was für die Reise nötig ist (Papiere, Ausrüstung, Einreise, Hinweise). Das Ergebnis steht nach Pflicht, Wichtig, Empfohlen und Hinweisen, jeweils mit Quellen und Stand.',
        'Vorher siehst du unter „Was geht an den Dienst?“, was hinausgeht. Es gehen keine Namen und keine Nummern mit. Die Besatzung heißt dort nur „Person 1“ und „Tier 1“, ihre Nachweise mit Ablaufdatum werden verglichen.',
        'Du richtest den Dienst einmal ein (Adresse und Passwort, nur auf diesem Gerät, nicht in der Sicherung) und stimmst ausdrücklich zu. Die Zustimmung kannst du jederzeit widerrufen. Sie wird mit Datum festgehalten.',
        'Ändert sich nach einem Check etwas an Besatzung, Nachweisen, Fahrzeug oder Zeitraum, zeigt die App „Daten seitdem geändert“. Alle Checks einer Aktivität bleiben erhalten.',
        'Der Reisecheck ist eine Planungshilfe und keine rechtsgültige Auskunft. Die Verantwortung bleibt beim Skipper oder Fahrer.',
        'Noch nicht dabei: Highlight-Vorschläge, Ampel der Behörden je Land, Kontingent und Bezahlstufe (kommen mit Konten und Server).'
      ] },
      { version: '2.0.37', datum: '2026-11-04', punkte: [
        'Fahrzeugart ändern: Unter „Angaben ändern“ kannst du jetzt auch die Fahrzeugart wechseln, zum Beispiel wenn du beim Anlegen die falsche Gruppe gewählt hast. Vor dem Speichern zeigt die App, was sich ändert, und du bestätigst es.',
        'Nichts geht dabei verloren: Angaben, die es bei der neuen Art nicht gibt, bleiben gespeichert und sind nur ausgeblendet. Wechselst du zurück, sind sie wieder da. Der frühere Stand steht im Verlauf des Fahrzeugs. Bereits erfasste Ereignisse im Logbuch, die nicht mehr zur Art passen, bleiben erhalten und sind mit „Gehört nicht mehr zur Fahrzeugart“ markiert.',
        'Fahrzeug abgeben: Auf der Fahrzeugseite gibt es „Fahrzeug abgeben“ (verkauft, verschenkt, verschrottet, mit Datum). Das Fahrzeug verschwindet aus allen Auswahllisten, bleibt bei dir aber lesbar. Du findest es in der Fahrzeugliste unter „Abgegebene Fahrzeuge“ und kannst es jederzeit wieder aktiv setzen. Aktivitäten, Logbuch, Kosten und Reisekasse bleiben bei dir.',
        'Technik-Akte als PDF: Zum Ausdrucken für den Kaufvertrag. Sie zeigt die technische Historie von der letzten HU bis zur Abgabe, höchstens 24 Monate: letzte HU, Zählerstände, erledigte und offene Fristen, Störungen und Arbeiten, Hauptkomponenten. Ist keine HU erfasst, beginnt sie mit dem Anlegen des Fahrzeugs (aber nicht früher als 24 Monate vor der Abgabe). Eine überfällige HU steht deutlich im PDF.',
        'Übergabedatei für den neuen Besitzer: Sie enthält die ganze technische Historie (Komponenten und Ausrüstung, Zähler, Fristen und Prüfungen, Störungen und Arbeiten, Dokumente, auf Wunsch mit den Dateien, auf Wunsch mit Schlüsselwort). Nicht enthalten sind Aktivitäten, Logbuch, Kosten, Reisekasse, Personen und Besatzung.',
        'Fahrzeug übernehmen: Der neue Besitzer liest die Übergabedatei unter Einstellungen oder in der Fahrzeugliste ein. Das Fahrzeug wird als neues Fahrzeug angelegt, mit der ganzen technischen Historie. Vorhandenes wird nicht verändert.',
        'Der Speicher wurde nicht umgestellt. Alle Daten und Sicherungen bleiben gültig. Eine Übergabedatei lässt sich nicht aus Versehen als Sicherung einspielen.'
      ] },
      { version: '2.0.36', datum: '2026-11-04', punkte: [
        'Neu: Den Abstand der Wetterpunkte an der Route stellst du selbst ein, wie in der ersten Version: nach Entfernung (alle x km oder x sm) oder nach Fahrzeit (alle x Stunden). Du findest das bei den Angaben zur Route unter „Abstand der Wetterpunkte“.',
        'Ohne eigene Eingabe gilt die Voreinstellung: auf dem Wasser alle 10 sm, sonst jede Stunde. Start, Ziel und benannte Wegpunkte bekommen immer Wetter. Ändert sich der Abstand, rechnet die App die Punkte neu, die Route bleibt dieselbe. Das Wetter musst du danach neu holen.',
        'Mit eigenem Abstand nimmt die App höchstens 24 Wetterpunkte je Route.'
      ] },
      { version: '2.0.35', datum: '2026-11-04', punkte: [
        'Geändert: „Wetter“ und „Karte“ sind keine festen Knöpfe mehr, sondern ganz normale Ereignisse. Du legst sie wie alle anderen als Knopf auf den Cockpit-Bildschirm oder lässt sie unter „Sonstige Ereignisse“ liegen. Sie gelten für alle Fahrzeugarten und sind im Standard schon auf Knöpfen.',
        '„Wetter“ holt das Wetter an deinem Standort und speichert es im Logbuch. „Karte“ öffnet nur die Karte und schreibt nichts ins Logbuch. Die feste Zeile im Cockpit ist weg, das Cockpit hat wieder den ganzen Platz für deine Knöpfe.',
        'Wer sie nicht will, blendet die Art aus oder löscht sie unter „Arten von Ereignissen“. Die App legt sie danach nicht noch einmal an.'
      ] },
      { version: '2.0.34', datum: '2026-11-04', punkte: [
        'Neu im Cockpit: „Wetter jetzt“ holt das Wetter an deinem Standort (Quelle Open-Meteo, Modellwert der aktuellen Stunde) und schreibt es als Eintrag „Wetter“ ins Logbuch, mit Datum, Uhrzeit und Position. Bei Wasserfahrzeugen kommen Wellen und Wasserstand dazu. Ohne Netz oder ohne GPS-Position wird nichts gespeichert.',
        'Wetter im Rhythmus: Unter Einstellungen stellst du ein, dass die App das Wetter zusätzlich selbst holt (alle 30 Minuten bis alle 6 Stunden). Das läuft nur, solange das Cockpit oder die Karte offen ist, das Fahrzeug in Fahrt ist und das Gerät GPS und Netz hat. Die Einstellung gilt nur für dieses Gerät.',
        'Neu: Karte im Vollbild, im Cockpit über „Karte“. Sie zeigt die geplante Route, Start, Ziel und Zwischenziele, die Wetterpunkte (grau, wenn du sie schon passiert hast), deine „Wetter jetzt“-Einträge, deinen tatsächlich gefahrenen Weg und deine Position. Der Weg wird aufgezeichnet, solange das Cockpit oder die Karte offen ist und das Fahrzeug in Fahrt ist.',
        'Auf der Karte siehst du, wo du auf der Route liegst, wie weit daneben, und ob du früher oder später bist als geplant. Bist du später, rechnet die App die Wetterpunkte vor dir für die neue Ankunftszeit neu.',
        'Offline-Karte: Unter „Karte“, „Offline-Karte“ holst du für eine Aktivität nur den Streifen entlang der Route (Stufen grob, mittel, fein, die Größe wird vorher angezeigt) und kannst ihn wieder löschen. Die Kacheln liegen nur auf diesem Gerät und nicht in der Sicherungsdatei.',
        'Die Kartenquelle (OpenStreetMap, Standard-Kacheln) ist für Tests im kleinen Rahmen gedacht. Die App begrenzt den Abruf deshalb hart. Vor der Veröffentlichung in einem App-Store wird die Quelle gewechselt, das ist an einer einzigen Stelle möglich.',
        'Die Karte selbst zeichnet Leaflet 1.9.4 (liegt in der App, kein Abruf von außen). Alle Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt.'
      ] },
      { version: '2.0.33', datum: '2026-11-04', punkte: [
        'Neu: Route und Wetter. An jeder Aktivität liest du eine Routendatei ein (GPX, KML oder GeoJSON). MobiMory plant keine Route und navigiert nicht, es rechnet nur mit der Route, die du mitbringst. Eine frühere Route bleibt erhalten.',
        'Mit Reisegeschwindigkeit (Knoten oder km/h) und Abfahrt rechnet die App Fahrzeit und Ankunftszeit an den Punkten der Route. Den Abstand der Wetterpunkte stellst du selbst ein (nach km, sm oder Fahrzeit). Die Länge der Route kannst du als geplante Strecke der Aktivität übernehmen, die Route lässt sich als GPX-Datei wieder ausgeben.',
        'Wetter am Punkt zur Ankunftszeit (Quelle Open-Meteo): Himmel, Temperatur, Wind, Böen, Regen. Bei Wasserfahrzeugen dazu Wellen, Wasserstand sowie Hoch- und Niedrigwasser. Das sind Prognosen und Modellwerte, keine Garantie und keine amtlichen Gezeitentafeln. Der geholte Stand bleibt im Gerät und ist auch ohne Netz sichtbar. Zum Abrufen braucht das Gerät Netz.',
        'Abfahrt früher oder später: ein Vergleich von zwei Stunden früher bis zwei Stunden später zeigt, wann die Böen, Wellen und der Regen am geringsten sind.',
        'Kilometer über GPS: Im Cockpit zählt die App die Strecke, solange das Fahrzeug „in Fahrt“ ist und das Cockpit offen und der Bildschirm an ist. Mit „GPS-Strecke übernehmen“ kommt sie auf Wunsch in den Streckenzähler. Dafür muss der Tachostand vorher von Hand eingetragen sein, deine Handeingabe hat immer Vorrang. Ohne GPS bleibt alles wie bisher von Hand.',
        'Auf der Startseite steht jetzt „Vehicle, Travel and Data“.',
        'Der Speicher bekommt eine neue Tabelle (Routen). Alle Daten und Sicherungen bleiben gültig, die Sicherung enthält die Routen.'
      ] },
      { version: '2.0.32', datum: '2026-11-04', punkte: [
        'Kacheln sind lesbar: Der Text wird nie mehr abgeschnitten. Braucht eine Kachel mehr Platz, wird sie höher.',
        'Titel bleiben ganze Wörter. Passt einer nicht in die Kachel, wird die Schrift etwas kleiner, und wenn es immer noch eng ist, gibt es weniger Spalten. Die Kacheln füllen weiter den freien Platz, solange der Text vollständig lesbar bleibt.',
        'Die kleinere Beschreibung unter dem Titel bricht nur noch an Silbengrenzen um, nicht mehr mitten im Wort an irgendeiner Stelle.',
        'Am Speicher hat sich nichts geändert. Alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.31', datum: '2026-11-04', punkte: [
        'Neues Logo: das M ist runder, mit der gestrichelten Linie und den drei Kreisen V, T und D. Es steht auf der Startseite, im Kopf und als App-Symbol. Die Datei ist icons/icon.svg.',
        'Alle Auswahlseiten füllen den Bildschirm: Hauptmenü, Stammdaten und Funktionen zeigen ihre Kacheln wie das Cockpit in einem Raster. Wenige Kacheln werden groß (bis zu einer sinnvollen Höhe), mehr Kacheln werden kleiner und rücken nebeneinander. So muss man kaum noch scrollen, und keine Kachel ist übertrieben breit. Beim Drehen des Geräts passt sich das Raster an.',
        'Neu unter Funktionen: das Kassenbuch. Es zeigt die Kassen aller Aktivitäten mit ihrem Stand. Ein Tipp öffnet die Reisekasse der Aktivität. Die Reisekasse an der Aktivität bleibt wie bisher.',
        'Alle Listen stehen jetzt zentral in den Stammdaten: Arten von Aktivitäten, Arten von Ereignissen (Logbuch und Cockpit) sowie Kostenarten und Zahlungsmittel. An den bisherigen Stellen (Aktivitäten, Logbuch, Kosten) bleibt der Link zur selben Liste. Es gibt keine zweite Liste.',
        'Am Speicher hat sich nichts geändert. Alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.30', datum: '2026-11-04', punkte: [
        'Fahrzeuge aus Excel oder CSV übernehmen: Unter Einstellungen gibt es „Aus Excel oder CSV übernehmen“ (auch in der Fahrzeugliste als Link). Jede Zeile der Tabelle wird ein Fahrzeug. Du wählst die Datei, die App ordnet die Spalten nach ihren Überschriften zu, du prüfst und änderst die Zuordnung und wählst die Fahrzeugart. Stehen verschiedene Arten in der Tabelle, liest die App sie aus einer Spalte.',
        'Erst die Vorschau, dann das Übernehmen: Die Vorschau zeigt je Zeile, ob das Fahrzeug neu ist, es schon gibt (gleiches Kennzeichen, gleiche Registriernummer, FIN oder HIN, sonst gleiche Bezeichnung), in der Tabelle doppelt steht oder einen Fehler hat. Erst „Übernehmen“ legt etwas an, alle neuen in einem Zug. Vorhandene Fahrzeuge werden nie überschrieben.',
        'Deutsche Schreibweise wird verstanden: „1.234,5“, „3.500 kg“, „7,5 m“, „03.11.2019“, beim Kraftstoff auch „Super“ oder „LPG“. CSV aus deutschem Excel (Semikolon, Windows-Zeichensatz) geht genauso wie UTF-8. Eine Datei darf bis zu 1.000 Zeilen haben.',
        'Daten ausgeben: Unter Einstellungen gibt es „Als Excel oder CSV ausgeben“. Du wählst Fahrzeuge, Kosten (alle Fahrzeuge, auch die Reisekasse) und Orte. Excel enthält ein Blatt je Tabelle mit echten Zahlen und Daten. CSV enthält eine Tabelle mit Semikolon und Komma, so öffnet deutsches Excel sie ohne Umwege. Die Fahrzeug-Tabelle lässt sich wieder übernehmen.',
        'Die Tabelle ist keine Sicherung und nicht verschlüsselt. Zum Sichern aller Daten bleibt die Sicherungsdatei unter Einstellungen.',
        'Bestehende Daten und Sicherungen bleiben gültig, am Speicher hat sich nichts geändert. Noch nicht dabei: Übernehmen von Kosten, Orten oder Komponenten aus einer Tabelle, das alte Excel-Format .xls (bitte in Excel als .xlsx oder CSV speichern), Import und Export von Routen (Schritt 9) und eine Umwandlung von Bildformaten (Fotos werden so abgelegt, wie das Gerät sie liefert). Das echte Aussehen am Tablet ist nicht geprüft.'
      ] },
      { version: '2.0.29', datum: '2026-11-04', punkte: [
        'Mehrere Kostenzeilen je Besuch: Beim Festhalten eines Ortes trägst du jetzt so viele Zeilen ein, wie du brauchst, zum Beispiel Liegegebühr, Stromzuschlag, Wasserzuschlag, Müllentsorgung, Kurtaxe. Jede Zeile wird ein eigener Posten in der Kosten-Liste, mit demselben Ort, derselben Aktivität und demselben Datum. Die Summe steht unter den Zeilen.',
        'Offene Kostenarten: Die Arten sind keine feste Liste mehr. Du legst eigene Arten an, auch mitten im Formular („Oder neue Art anlegen“). Kurtaxe, Müllentsorgung, Stromzuschlag, Wasserzuschlag und Duschmarken sind als Vorschläge schon da. Benutzte Arten werden nur ausgeblendet, nicht gelöscht. Unter „Kosten“ gibt es die Seite „Arten und Zahlungsmittel“.',
        'Reisekasse: Neue Gruppe für Ausgaben der Reise, die nicht das Fahrzeug betreffen: Einkauf, Essen gehen, Souvenirs, Eintritte, Unterkunft an Land, Gebühren. Sie gehört zur Aktivität und zählt nie in die Fahrzeugkosten. Jede Ausgabe kann Notiz, Ort (aus der Orte-Liste oder als Text) und ein Foto oder einen Beleg haben, das Foto am Posten.',
        'Bezahlt mit: Freiwillig bei jeder Ausgabe. Eine eigene Liste mit Bezeichnungen wie „Girokarte“ oder „Kreditkarte“, keine Karten- oder Kontonummern. „Bar“ ist fest und gehört zur Kasse.',
        'Bargeldkasse je Währung: Zu Reisebeginn trägst du den Anfangsbestand ein. Bei „Bar“ zieht die App den Betrag von der Kasse ab, du siehst jederzeit den Stand. Geld, das du später holst, ist eine Einzahlung und keine Ausgabe, so zählt es nicht doppelt. Beim Kassensturz trägst du ein, was wirklich da ist, die App speichert die Differenz als eigenen Eintrag. Jede Währung hat ihre eigene Kasse.',
        'Kurs ohne Internet: Beim Anfangsbestand und bei jeder Einzahlung in Fremdwährung trägst du ein, wie viel Euro du dafür bezahlt hast (zum Beispiel 100 € für 1.150 NOK). Daraus rechnet die App den Durchschnittskurs. Beträge, die sie damit umrechnet, sind als „gerechnet“ gekennzeichnet. Bei einer Kartenzahlung in Fremdwährung trägst du den Euro-Betrag von der Abrechnung später nach, dann gilt er als eingegeben.',
        'Auswertung der Reise: Auf der Seite „Reisekasse“ der Aktivität siehst du Fahrzeug und Reisekasse getrennt, die Gesamtsumme, pro Tag, pro Person und pro Tag und Person, die Reisekasse nach Art und alles nach Zahlungsmittel. Der Anteil der Fixkosten des Fahrzeugs für die Reisetage steht als eigene Zeile und lässt sich ein- und ausschalten.',
        'Bestehende Daten und Sicherungen bleiben gültig. Der Speicher bekommt vier neue Tabellen (eigene Kostenarten, Zahlungsmittel, Kassen, Kassenbuchungen), sie sind in der Sicherung enthalten. Noch nicht dabei: Import und Export (Schritt 8b) und das Löschen von Arten (sie werden ausgeblendet).'
      ] },
      { version: '2.0.28', datum: '2026-11-04', punkte: [
        'Reiseorte: Orte haben jetzt eine Art (Stellplatz, Campingplatz, Hafen, Ankerplatz …), eine Position und eine Ausstattung (Strom, Wasser, Entsorgung, WLAN und mehr). Die gelernten Ortsnamen aus dem Logbuch lassen sich mit einem Tipp als Orte mit Position übernehmen.',
        'Frage nach der Ankunft: Nach Ankunft, Anlegen oder Anker werfen fragt das Cockpit, ob du den Ort festhalten willst. Die Frage ist immer freiwillig und sperrt nichts. Kennt die App den Ort an der Position, schlägt sie ihn vor. Mit „Nicht jetzt“ kommt die Frage nicht wieder.',
        'Besuch: Jeder festgehaltene Besuch bleibt gespeichert, mit Datum, Aktivität, Ausstattung und Kosten. Die Ausstattung gilt auch für den Ort, beim nächsten Mal siehst du sie schon. Ein Ort ohne Position bekommt die der Ankunft.',
        'Kosten unterwegs: Gibst du bei einem Besuch einen Betrag an, steht er als variabler Posten in der Kosten-Liste, verknüpft mit Aktivität und Ort. Es gibt keine zweite Buchführung. Am Ort siehst du, wie oft du dort warst und was du insgesamt und zuletzt bezahlt hast.',
        'Reiseplan: Eine Aktivität kann Start, Ziel und Zwischenziele als Orte haben. Bei der Ankunft zeigt die App, ob es dein geplantes Ziel war. Auf der Seite der Aktivität steht Plan gegen Ist und was die Reise gekostet hat, nach Art aufgegliedert.',
        'Später teilbar wären nur Name, Art, Position und Ausstattung eines Ortes. Deine Notizen, Kosten und Besuche bleiben nur bei dir. Veröffentlicht wird nichts, das kommt erst mit Konten und Server.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher bekommt eine neue Tabelle (Besuche), sie ist in der Sicherung enthalten. Noch nicht dabei: Route, Fahrzeit und Ankunftszeit (Schritt 9) und Import und Export (Schritt 8b). Das echte Aussehen am Tablet ist nicht geprüft.'
      ] },
      { version: '2.0.27', datum: '2026-11-04', punkte: [
        'Kosten: Unter „Funktionen“ gibt es jetzt „Kosten“, eine einzige Liste für alle deine Fahrzeuge. Jeder Betrag gehört zu einer von drei Gruppen: Fixkosten (immer gleich, zum Beispiel Liegeplatz oder Garage am Heimatort, Versicherung, HU, Gasprüfung, Feuerlöscher), variable Kosten (entstehen erst bei der Nutzung, zum Beispiel Treibstoff, Parkplätze und Häfen auf Reisen) und Instandhaltung (Wartung und Reparatur).',
        'Dazu kommt der Wertverlust als vierte Gruppe. Den trägst du nicht ein, die App rechnet ihn aus dem Wert des Fahrzeugs und einem Prozentsatz pro Jahr, den du in den Kostenstammdaten angibst. Ohne Angabe rechnet sie ohne Wertveränderung. Ist der Wert älter als ein Jahr, fragt sie, ob er noch stimmt.',
        'Beträge in der Werkstatt: Auf der Seite eines Vorgangs trägst du Teile, Arbeit oder die Rechnung der Werkstatt ein. Der Betrag steht nur in der Kosten-Liste und gehört zur Instandhaltung, es gibt keine zweite Buchführung. Auch an einer Aktivität (variable Kosten) und an einer Komponente kannst du Beträge eintragen.',
        'Wiederkehrende Kosten: Ein Fixbetrag kann einmalig sein oder jeden Monat, alle 3 oder 6 Monate, jedes Jahr oder alle 2 Jahre fällig werden, mit Beginn und freiwilligem Ende. Die App verteilt ihn auf die Monate, in denen er gilt. Auch geschätzte Beträge und Beträge in der Zukunft sind möglich.',
        'Auswertung pro Fahrzeug und Jahr: Gesamtkosten, davon bis heute und noch zu erwarten, pro Monat, pro Nutzungstag (genutzte Tage aus den Aktivitäten) und pro Kilometer (aus dem Kilometerstand). Bei jedem Wert steht, ob er eingegeben, geschätzt oder gerechnet ist. Über die Pfeile wechselst du das Jahr.',
        'Vergleich mit Mieten oder Chartern: Trägst du in den Kostenstammdaten ein, was ein gemietetes oder gechartertes Fahrzeug der gleichen Klasse pro Tag kostet, zeigt die App, wie deine Kosten bis heute dazu stehen und ab wie vielen Nutzungstagen im Jahr das eigene Fahrzeug günstiger ist. Das ist nur eine Rechnung mit deinen Angaben.',
        'Nichts wird gelöscht: Ein Posten lässt sich ändern oder ausblenden, der frühere Stand bleibt im Verlauf sichtbar. Ausgeblendete Posten rechnen nicht mit.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher bekommt zwei neue Tabellen (Kostenposten und Kostenstammdaten). Beides ist in der Sicherung enthalten. Noch nicht dabei: Import und Export (Schritt 8a), Kostenentwicklung über mehrere Jahre. Das echte Aussehen am Tablet ist nicht geprüft.'
      ] },
      { version: '2.0.26', datum: '2026-11-04', punkte: [
        'Dokumente und Bilder am Vorgang: Auf der Seite eines Vorgangs in der Werkstatt legst du Fotos vom Schaden, Rechnungen und Belege ab, als Datei oder als Link. Das geht auch bei einem erledigten Vorgang, denn die Rechnung kommt oft erst später.',
        'Neue Art von Dokument: Reparaturbuch. Bedienungsanleitung und Ersatzteilliste gab es schon an der Komponente. Die Gesamtliste aller Dokumente eines Fahrzeugs zeigt auch die Dokumente der Vorgänge („am Vorgang: …“), die Suche findet sie ebenfalls.',
        'Störung im Logbuch: Das Ereignis „Störung“ ist jetzt dieselbe Störung wie in der Werkstatt. Im Cockpit tippst du einmal auf „Störung“. Die Störung steht mit Uhrzeit und Position im Logbuch und zugleich als Vorgang in der Werkstatt. Die Warnung bei versprochenen Aktivitäten gilt damit auch unterwegs.',
        'Die Einschränkung ist vorbelegt mit „Fahrzeug bleibt nutzbar“, du änderst sie beim Vorgang in der Werkstatt. Die Störung hängt am Fahrzeug. Beim Nachtragen gilt dasselbe, der Vorgang bekommt dann das Datum des Ereignisses. Im Ereignis steht ein Link zum Vorgang, im Vorgang ein Link zum Ereignis.',
        'Eine ältere Störung im Logbuch bleibt, wie sie ist, sie wird nicht nachträglich zum Vorgang. Die Art eines bestehenden Ereignisses lässt sich nicht auf „Störung“ umstellen, weil sonst die Werkstatt ausgelassen würde.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher ist unverändert. Die Dokumente und Verweise sind in der Sicherung enthalten. Noch nicht dabei: Beträge und Kosten (Schritt 8).'
      ] },
      { version: '2.0.25', datum: '2026-11-04', punkte: [
        'Adressen: Unter „Stammdaten“ gibt es jetzt „Adressen“, eine einzige Liste für Werkstätten, Lieferanten und Händler. Sie gilt für alle deine Fahrzeuge. Du legst Name und Art fest, alles andere ist freiwillig: Ansprechpartner, Telefon, E-Mail, Anschrift, Webseite und Notiz.',
        'Die Werkstatt verweist darauf: Bei einer Arbeit („Wer macht die Arbeit?“) und beim Umwandeln einer Störung in eine Arbeit kannst du eine Adresse aus der Liste wählen. Auf der Seite des Vorgangs steht sie mit Link, auf der Seite der Adresse siehst du alle Vorgänge, die darauf verweisen.',
        'Nichts wird gelöscht: Eine Adresse lässt sich ändern oder ausblenden, der frühere Stand bleibt im Verlauf sichtbar. Eine ausgeblendete Adresse lässt sich nicht neu wählen, bleibt aber an den Vorgängen, an denen sie schon hängt.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher bekommt eine neue Tabelle für die Adressen. Die Adressen sind in der Sicherung enthalten. Noch nicht dabei: Dokumente und Bilder am Vorgang sowie die Kosten.'
      ] },
      { version: '2.0.24', datum: '2026-11-04', punkte: [
        'Werkstatt: Unter „Funktionen“ gibt es jetzt die Werkstatt. Dort meldest du Störungen und planst Arbeiten, am ganzen Fahrzeug oder an einer einzelnen Komponente. Auch auf der Seite des Fahrzeugs und der Komponente steht ein Block „Werkstatt“.',
        'Störung melden: Du sagst kurz, was los ist, und wie weit das Fahrzeug eingeschränkt ist: bleibt nutzbar, nur bedingt einsatzfähig oder nicht einsatzfähig.',
        'Aus der Störung eine Arbeit machen: Du legst fest, ob du die Arbeit selbst erledigst oder eine Werkstatt sie macht. Die Störung bleibt im Verlauf sichtbar. Ist alles gemacht, trägst du „Erledigt“ ein. Ein erledigter Vorgang lässt sich wieder öffnen, nichts wird gelöscht.',
        'Warnung bei versprochenen Aktivitäten: Ist das Fahrzeug nicht oder nur bedingt einsatzfähig, aber für die nächste Zeit eingeplant, warnt die App und fragt, ob es trotzdem genutzt werden kann oder abgesagt werden muss. „Trotzdem nutzen“ wird festgehalten und lässt sich zurücknehmen. „Absagen“ führt zum Stornieren der Aktivität. Die Entscheidung triffst immer du.',
        'Bestehende Daten und Sicherungen bleiben gültig. Die Vorgänge sind in der Sicherung enthalten. Noch nicht dabei: Adressen von Werkstätten und Lieferanten, Dokumente und Bilder am Vorgang sowie die Kosten. Sie folgen in den nächsten Stufen.'
      ] },
      { version: '2.0.23', datum: '2026-11-04', punkte: [
        'Status des Fahrzeugs: Jedes Fahrzeug hat jetzt immer einen Status, und was als Nächstes geht, hängt nur davon ab. Landfahrzeug: Stillstand oder In Fahrt (Abfahrt, Ankunft im Wechsel). Wasserfahrzeug: Festgemacht, In Fahrt oder Vor Anker (Ablegen, Anlegen, Anker werfen, Anker lichten). Am Steg geht nur Ablegen, vor Anker nur Anker lichten.',
        'Im Cockpit steht der Status in der Statuszeile, zum Beispiel „Status In Fahrt seit 09:00 Uhr (Abfahrt)“. Ein Knopf, der zum Status nicht passt, ist grau und nennt den Grund, zum Beispiel „erst Ablegen“. Notiz, Foto, Tanken und andere Ereignisse stören den Status nicht.',
        'Der Status gehört zum Fahrzeug, nicht zur Aktivität: Liegt das Boot nach einem Törn vor Anker, geht es im nächsten Törn mit Anker lichten weiter. Beim allerersten Mal ist der Knopf frei, der den Anfang macht (Abfahrt oder Ablegen).',
        'Vergessen? Trage das fehlende Ereignis mit der echten Uhrzeit nach. Das Nachtragen wird nie gesperrt, und der Status wird nach der Uhrzeit neu gerechnet, nicht nach der Reihenfolge des Eintippens.',
        'Die Regel hängt an der Art des Ereignisses, nicht am Namen: Auf der Seite „Arten von Ereignissen“ gibt es bei jeder Art den Abschnitt „Status des Fahrzeugs (freiwillig)“ mit „Möglich im Status“ und „Danach Status“. So gilt die Regel auch für eigene Arten. Für die sechs bekannten Namen gibt es eine Starthilfe, bei „Ändert den Status nicht“ wird die Art nie gesperrt.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Luftfahrzeuge haben keine Status und werden nie gesperrt. Das echte Aussehen der grauen Knöpfe am Tablet ist nicht geprüft.'
      ] },
      { version: '2.0.22', datum: '2026-11-04', punkte: [
        'Motorstopp-Frage: Tippst du Ankunft, Anlegen oder Anker werfen und ein Motor läuft noch, fragt das Cockpit oben „Fahrzeug am Ziel, Motor stoppen?“. Der Eintrag ist da schon gespeichert, die Frage sperrt nichts. Mit „Motor stoppen“ stoppt der Motor sofort (bei zwei Motoren je Motor ein Knopf), mit „Läuft weiter“ bleibt er an.',
        'Läuft der Motor nach der Frage weiter, schlägt die App nach der Wartezeit die Zeit der Ankunft als Stoppzeit vor, zum Beispiel „Stopp um 12:00 Uhr übernehmen“. Übernimmst du sie, rechnet die App die Betriebsstunden bis zu dieser Zeit und nicht bis jetzt. Die Stoppzeit lässt sich danach wie bisher noch korrigieren.',
        'Die Wartezeit stellst du selbst ein, auf der Seite „Motoren“ unter „Motorstopp-Frage“ (1 bis 1440 Minuten, Vorgabe 15). Sie gilt nur für dieses Gerät und ist nicht in der Sicherung.',
        'Ausgelöst wird die Frage immer von einem Ereignis am Ziel, nie von der Laufzeit des Motors: Bootsmotoren laufen auf langen Törns 24 bis 30 Stunden normal. Geht es nach der Ankunft mit Abfahrt, Ablegen oder Anker lichten weiter, fragt die App nichts. Wurde der Motor erst nach der Ankunft gestartet, auch nicht. Die Frage hängt an den Ereignissen im Logbuch: Auch eine nachgetragene oder ausgeblendete Ankunft wird berücksichtigt.',
        'Sagst du bei der Frage „Läuft weiter“, kommt sie für diese Ankunft nicht wieder. Der Vorschlag nach der Wartezeit kommt trotzdem noch einmal. Sagst du auch dort „Läuft weiter“, ist die Sache für diese Ankunft erledigt. Eine neue Ankunft fragt wieder.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Noch nicht dabei: Motor Start und Stopp als Ereignisse im Logbuch, Korrektur der Startzeit, Kilometer über GPS.'
      ] },
      { version: '2.0.21', datum: '2026-11-04', punkte: [
        'Position bei jedem Eintrag: Ein Ereignis im Logbuch kann jetzt eine Position tragen (Breite und Länge), dazu die Herkunft (vom GPS oder von Hand) und freiwillig einen Ortsnamen. Bei Tipps im Cockpit nimmt die App die GPS-Position dieses Geräts, wenn sie frisch ist (höchstens 2 Minuten alt). Sie wartet nie auf das GPS und fragt nie nach: Ohne GPS wird der Eintrag trotzdem sofort gespeichert, nur ohne Position.',
        'Im Cockpit steht in der Statuszeile die aktuelle Position, bei einem bekannten Ort mit dessen Namen. Beim ersten Mal fragt der Browser, ob dieses Gerät den Standort nutzen darf. Sagst du Nein, geht alles weiter, nur ohne Position.',
        'Von Hand: Im Formular „Ereignis eintragen“, „Nachtragen“ und „Angaben ändern“ gibt es den Abschnitt „Ort und Position“ mit Breite, Länge (Dezimalgrad, zum Beispiel 48,8566; Süd und West mit Minuszeichen oder S und W) und Ortsname. Beim Nachtragen gibt es keine GPS-Position, sie wird nur von Hand eingetragen. Änderst du eine GPS-Position, gilt sie danach als von Hand eingetragen. Die Handeingabe hat Vorrang.',
        'Die App lernt Ortsnamen: Gibst du zu einer Position einen Namen ein oder bestätigst ihn, merkt sich die App ihn für diese Gegend (Umkreis etwa 500 Meter, es kommt nicht auf den Meter an). Bei einer späteren Position im Umfeld schlägt sie den Namen vor, zum Beispiel „Schleuse Gamsheim“. Im Cockpit steht ein vorgeschlagener Name als „Vorschlag“ am Eintrag, gelernt wird er erst, wenn du ihn unter „Angaben ändern“ bestätigst.',
        'Am Ereignis steht außerdem, von welchem Gerät es kam (dieses Gerät oder ein anderes). Wer den Eintrag gemacht hat (Nutzer), folgt mit den Konten. Die gelernten Ortsnamen sind in der Sicherung, die Gerätekennung nicht.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Noch nicht dabei: die Frage „Motor stoppen?“ nach Ankunft (nächste Stufe), Kilometer über GPS, Karte, Route und Wetter am Wegpunkt (Schritt 9). Die gelernten Namen sind noch nicht mit den Orten und Standorten aus den Stammdaten verknüpft, weil diese noch keine Koordinaten haben.'
      ] },
      { version: '2.0.20', datum: '2026-11-04', punkte: [
        'Hinweis „Kein Motor läuft“: Jede Fahrzeugart legt fest, ob sie normalerweise einen Motor hat. Du kannst das je Art ändern (Stammdaten › Fahrzeugarten › Art), eine Untergruppe übernimmt es von der Obergruppe, bis du etwas Eigenes einstellst. Tippst du im Cockpit „Abfahrt“ oder „Ablegen“, ohne dass ein Motor läuft, speichert die App den Eintrag trotzdem sofort. Oben steht nur der Hinweis „Kein Motor läuft“. Es gibt keine Rückfrage und keine Sperre.',
        'Betriebsstunden und Kilometer stehen jetzt zusammen in der Statuszeile des Cockpits, jeweils mit der Quelle des Stands (Hand oder Schalter) und dem Datum. Auf der Seite „Motoren“ gibt es dazu eine Karte „Kilometer“. Die Kilometer trägst du von Hand ein. GPS kann später eine weitere Quelle sein und ist nie Voraussetzung. Ein Handeintrag hat wie bei den Betriebsstunden Vorrang.',
        'Knopfzahl je Gerät: Je Fahrzeugart lassen sich bis zu 15 Knöpfe belegen (bisher 8). Wie viele davon dieses Gerät zeigt, stellst du auf der Seite „Schnellknöpfe“ unter „Auf diesem Gerät“ ein. Bis du etwas einstellst, sind es 8, wie bisher. Die übrigen Knöpfe liegen unter „Sonstige Ereignisse“ und gehen nicht verloren. Die Einstellung gilt nur für das einzelne Gerät und ist nicht in der Sicherung.',
        'Die Spalten im Cockpit richten sich nach der Breite des Bildschirms: Handy 2, Tablet 3, großer Bildschirm 4 (ab 1400 Pixel Breite). Die Zeilen teilen sich weiter die Höhe, es wird nicht gescrollt.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Noch nicht dabei: die Frage „Motor stoppen?“ nach Ankunft, Anlegen oder Anker werfen (nächste Stufe), Kilometer über GPS.'
      ] },
      { version: '2.0.19', datum: '2026-11-04', punkte: [
        'Motorschalter im Cockpit: Jeder Motor hat seinen eigenen Schalter und seinen eigenen Zähler für die Betriebsstunden, einen Sammelschalter „alle“ gibt es nicht. Grau heißt Motor aus (Name und „Start“), rot heißt Motor läuft (Name und „Stopp“). Die Schalter stehen in einer Leiste unter den Knöpfen, oben in der Statuszeile steht, welcher Motor seit wann läuft.',
        'Die Motoren kommen aus den Komponenten: Jede Hauptkomponente der Art Motor bekommt einen Schalter, ein ausgebauter Motor nicht. Beim ersten Start legt die App den Zähler „Betriebsstunden“ am Motor an. Beim Stopp rechnet sie den letzten Stand plus die Laufzeit. Trägst du einen Stand von Hand ein, hat er Vorrang, ab ihm wird weitergerechnet. Ohne Startstand zählt der Zähler ab 0 und die App sagt es dir.',
        'Neues Feld „Kurzname“ bei den Komponenten (höchstens 8 Zeichen). Bei einem Motor macht die App aus der Bezeichnung einen Vorschlag, zum Beispiel wird aus „Motor Steuerbord“ MOSTB. Du siehst ihn im Feld und kannst ihn ändern. Einen selbst geänderten Kurznamen überschreibt die App nicht mehr. Zwei Motoren desselben Fahrzeugs dürfen nicht denselben Kurznamen haben.',
        'Ein oder zwei Motoren haben je einen festen Schalter. Ab drei Motoren steht in der Leiste ein einziger Schalter „Motoren“ mit der Anzeige, wie viele laufen. Ein Tipp darauf öffnet eine Liste mit allen Motoren, jeder mit eigenem Schalter, Zähler und den letzten Läufen. Die Ereignisknöpfe bleiben unverändert.',
        'Stoppen vergessen? Auf der Seite „Motoren“ gibt es bei dem letzten Lauf den Knopf „Stoppzeit korrigieren“. Du trägst ein, wann der Motor wirklich gestoppt wurde, der Stand wird neu gerechnet, und der alte Stand bleibt im Verlauf des Zählers sichtbar. Wurde der Zählerstand danach von Hand geändert, geht das nicht mehr, dann trägst du den richtigen Stand von Hand ein.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Die Läufe sind in der Sicherung enthalten. Noch nicht dabei: die Frage „Motor stoppen?“ nach Ankunft, Anlegen oder Anker werfen (kommt als nächste Stufe).'
      ] },
      { version: '2.0.18', datum: '2026-11-04', punkte: [
        'Das Cockpit füllt jetzt den ganzen Bildschirm: kein Menü, kein Scrollen, große Knöpfe in drei Spalten. Oben steht, wer gerade verantwortlich ist und welcher Tag heute ist, unten der letzte Eintrag und ein paar kleine Knöpfe (Tagesabschluss, Knöpfe ändern, Logbuch und Angaben). Läuft die Aktivität, öffnet sich das Cockpit von selbst.',
        'Schnellknöpfe frei belegbar: Im Cockpit stehen bis zu 8 Knöpfe, die du je Fahrzeugart selbst wählst, dazu fest „Sonstige Ereignisse“ (3 mal 3 Knöpfe). Ein Tipp auf ein Ereignis speichert es sofort mit der Uhrzeit von jetzt. Notiz, Foto und Verantwortung wechseln sind ebenfalls frei wählbar.',
        'Alles, was nicht auf einem Knopf liegt, findest du unter „Sonstige Ereignisse“, auch Notiz, Foto und Verantwortung wechseln, wenn du sie vom Knopf genommen hast.',
        'Eingestellt wird es unter Stammdaten › Fahrzeugarten › Art › „Schnellknöpfe im Cockpit“ oder im Cockpit mit „Knöpfe ändern“. Eine Untergruppe übernimmt die Knöpfe der Obergruppe, bis du etwas Eigenes einstellst. Das Wasserskiboot kann so andere Knöpfe haben als der Katamaran.',
        'Bis du etwas einstellst, gelten die bisherigen Knöpfe: Abfahrt, Ankunft, Notiz, Foto, Verantwortung wechseln. Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Die Einstellung ist in der Sicherung enthalten.'
      ] },
      { version: '2.0.17', datum: '2026-11-04', punkte: [
        'Die Art der Aktivität richtet sich nach dem Fahrzeug: Bei jeder Art von Aktivität legst du fest, für welche Fahrzeugarten sie gilt (Baum mit Häkchen, wie bei den Ereignissen). Mit dem Wohnmobil gibt es dann zum Beispiel kein Wasserski.',
        'Logbuch jetzt starten: Neues Feld „Aktivität“. Es zeigt nur Arten, die zum gewählten Fahrzeug passen, „Ausfahrt“ ist vorausgewählt, wenn sie passt. Der Name des Logbuchs folgt der gewählten Art, zum Beispiel „Törn Kat 04.11.2026“.',
        'Auch beim Planen und Ändern einer Aktivität stehen nur die Arten zur Wahl, die zum Fahrzeug passen. Eine Art, die schon an der Aktivität hängt, bleibt wählbar.',
        'Unter „Arten von Aktivitäten“ zeigt jede Art „Gilt für: …“. Der Knopf „Vorschläge für Fahrzeugarten übernehmen“ setzt eine Starthilfe (Wasserski nur für Wasserskiboote, Segeln nur für Segelboote, Törn für Wasserfahrzeuge, Rallye für Landfahrzeuge, Urlaub und Ausfahrt für alle), aber nur dort, wo du noch nichts eingestellt hast. Alles ist jederzeit änderbar.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Ältere Arten ohne Zuordnung gelten wie bisher für alle.'
      ] },
      { version: '2.0.16', datum: '2026-11-04', punkte: [
        'Fahrzeugarten selbst verwalten: Unter Stammdaten › Fahrzeugarten siehst du den ganzen Baum. Du kannst Untergruppen anlegen (zum Beispiel Trimaran unter Segelboot oder Aufsitzrasenmäher unter Landfahrzeug), Arten umbenennen und ausblenden.',
        'Eine neue Art übernimmt die Felder und die Ereignisse der Gruppe, unter der sie steht. Bei den Arten von Ereignissen kannst du das wie gewohnt ändern.',
        'Ausblenden geht immer. Eine ausgeblendete Art (und alles darunter) bieten neue Fahrzeuge nicht mehr an, bestehende Fahrzeuge bleiben unverändert.',
        'Löschen geht nur bei Arten, die kein Fahrzeug benutzt (auch keine Untergruppe davon). Was benutzt wird, lässt sich nur ausblenden.',
        'Ungebrauchtes löschen: ein Knopf räumt den Baum auf. Er löscht alles, was kein Fahrzeug benutzt, und zeigt vorher, was weggeht. Wer nur Oldtimer braucht, behält nur die Oldtimer. Gelöschte Vorschläge lassen sich zurückholen.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Eigene Arten sind in der Sicherung enthalten.'
      ] },
      { version: '2.0.15', datum: '2026-11-04', punkte: [
        'Logbuch ohne Planung: Auf der Seite „Aktivitäten“ und beim Fahrzeug gibt es den Knopf „Logbuch jetzt starten“. Du wählst Fahrzeug und wer verantwortlich ist (Stellvertreter und Crew sind freiwillig), der Beginn ist jetzt, und das Cockpit läuft sofort. Es entsteht eine ganz normale Aktivität der Art „Ausfahrt“, mit derselben Prüfung.',
        'Ereignisse gelten für Fahrzeugarten: Bei jeder Art von Ereignis legst du fest, für welche Fahrzeugarten sie gilt. Cockpit und Logbuch zeigen dann nur die Ereignisse, die zum Fahrzeug passen. Ein Häkchen an einer Gruppe gilt für alles darunter, einzelne Arten kannst du abwählen oder wieder ankreuzen.',
        'Fahrzeugarten als Baum: Wasserfahrzeug enthält jetzt Boot mit Sportboot, Wasserskiboot, Motorboot zum Übernachten, Motorschiff und Segelboot (Monohull, Katamaran, Jolle oder Kleinboot). Bestehende Fahrzeuge der Art „Boot“ bleiben gültig. Regeln für „Boot“ gelten auch für diese Untergruppen.',
        'Neue Vorschläge für Ereignisse mit Zuordnung (Tanken, Anlegen, Ablegen, Anker werfen, Anker lichten, Schleuse, Segel setzen, Segel bergen, Wasserski-Lauf) unter „Arten von Ereignissen“. Ältere Ereignisarten gelten wie bisher für alle.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt.'
      ] },
      { version: '2.0.14', datum: '2026-11-03', punkte: [
        'Bei der Aktivität gibt es jetzt zwei Reiter: „Cockpit“ zum schnellen Eintragen unterwegs und „Logbuch“ zum Nachlesen, Korrigieren und Nachtragen. Beide zeigen dieselben Einträge. Läuft die Aktivität gerade, öffnet sich das Cockpit zuerst, sonst das Logbuch.',
        'Cockpit mit großen Knöpfen: Ein Tipp auf Abfahrt oder Ankunft speichert sofort mit der Uhrzeit von jetzt, ohne Formular. Dazu Ereignis, Notiz und Foto. Das Cockpit zeigt den heutigen Tag, die letzten Einträge und wer gerade verantwortlich ist, seit wann. Der heutige Tag wird beim ersten Eintrag von selbst angelegt.',
        'Verantwortung wechseln im Cockpit: ein Tipp auf den Namen, Zeit jetzt. Die App prüft dabei die Befähigung der übernehmenden Person und hält das Ergebnis mit „geprüft am“ beim Wechsel fest. Sie weist nur hin und sperrt nichts. Ein vergessener Wechsel lässt sich mit der echten Uhrzeit nachtragen.',
        'Nachtrag wird erkannt: Weicht die Uhrzeit um mehr als 5 Minuten von jetzt ab, steht das Ereignis automatisch als „nachgetragen am …“ da. Der Knopf „Nachtragen“ bleibt.',
        'Klassisches Logbuch: alle Tage und Ereignisse der Reihe nach wie auf Papier, mit der festgehaltenen Prüfung zum Tagesbeginn beim Tag. Hier wird geändert, nachgetragen und ausgeblendet. Der Verlauf bleibt erhalten, nichts wird gelöscht.',
        'Tagesabschluss: tatsächliches Ziel und eine Notiz zum Tag. Der Zählerstand am Ende kommt später mit dem Schritt „Zähler automatisch“.',
        'Größere Knöpfe und klarere Gestaltung für Tablet und Smartphone.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt.'
      ] },
      { version: '2.0.13', datum: '2026-11-03', punkte: [
        'Logbuch-Kern an der Aktivität: Ein Tagesabschnitt je Tag mit Datum, Beginn und Ende (Uhrzeit freiwillig), von wo nach wo (als Text) und Notiz.',
        'Die App bereitet die Tage aus dem Zeitraum der Aktivität auf Knopfdruck vor. Jeder Tag lässt sich ändern, von Hand ergänzen und ausblenden. Nichts wird gelöscht.',
        'Prüfung zum Tagesbeginn: Die Prüfung der Aktivität wird für den Tag festgehalten, mit „geprüft am“ und dem Verantwortlichen dieses Tages. Spätere Änderungen verändern das Festgehaltene nicht.',
        'Ereignisse in einem Tag: Zeitpunkt, Art, Text und ein Foto, alles außer Zeitpunkt und Art freiwillig. Die Arten sind eine offene Liste mit Vorschlägen (Abfahrt, Ankunft, Wechsel des Verantwortlichen, Störung, Notiz).',
        'Ein Wechsel des Verantwortlichen erscheint von selbst als Ereignis. Du kannst Zeitpunkt und Notiz korrigieren, der frühere Stand bleibt im Verlauf. Die Verantwortung der Aktivität folgt der Korrektur.',
        'Nachtragen: Ein Ereignis mit dem echten Zeitpunkt später eintragen. Es steht dann als „nachgetragen am …“ da.',
        'Bestehende Daten und Sicherungen bleiben gültig. Die Sicherung enthält Tage, Ereignisse, Prüfungen und Fotos.',
        'Noch nicht dabei: Wetter und Wegpunkte, Motor Start und Stopp, Störung als Werkstattvorgang, Orte als Start und Ziel, Kosten.'
      ] },
      { version: '2.0.12', datum: '2026-11-03', punkte: [
        'Komponenten haben eine Anzahl (zum Beispiel 6 Rettungswesten) und den Haken „Eignung geprüft“.',
        'Regeln für Pflichtausrüstung nennen jetzt eine Menge, die Bezugsgröße (je Fahrzeug oder je Person an Bord) und freiwillig die geforderte Eignung, zum Beispiel „Automatik, 150 N“.',
        'Die Prüfung bei der Aktivität vergleicht Soll und Ist und nennt die Zahlen, zum Beispiel „Eingetragen sind 5, Soll ist 6“. Bei „je Person“ zählt die Besatzung der Aktivität.',
        'Fehlt bei geforderter Eignung der Haken, sagt die Prüfung „unklar“. Die App prüft die Eignung nicht selbst.',
        'Bestehende Regeln und Komponenten bleiben gültig und ändern ihr Ergebnis nicht.'
      ] },
      { version: '2.0.11', datum: '2026-11-03', punkte: [
        'Orte: zusätzlich Adresse, Ansprechpartner und Telefon.',
        'Standorte: zusätzlich Länge, Breite, Tiefe und Höhe des Platzes.',
        'Regeln für Pflichtausrüstung: Zu einem Gebiet legst du fest, was am Fahrzeug sein muss, zum Beispiel Rettungsweste oder Feuerlöscher, wahlweise nur für bestimmte Fahrzeugarten.',
        'Die Prüfung bei der Aktivität zeigt die Pflichtausrüstung des Gebiets. Sie sucht in den eingetragenen Komponenten des Fahrzeugs. Ist etwas nicht eingetragen, sagt sie „unklar“ und nicht „fehlt“, weil sie nicht weiß, was wirklich an Bord liegt.',
        'Befähigung und Pflichtausrüstung sind zwei Arten von Regeln im selben Gebiet. Die Regeln sind weiter von dir eingetragen.'
      ] },
      { version: '2.0.10', datum: '2026-11-03', punkte: [
        'Orte und Standorte: Ein Ort (zum Beispiel ein Hafen) hat Standorte (zum Beispiel Liegeplatz 12). Alles gehört deinem eigenen Datenraum.',
        'Heimatstandort am Fahrzeug: Du wählst ihn aus deinen Standorten. Änderungen bleiben im Verlauf sichtbar.',
        'Gebiete mit Regeln: Eine Regel sagt „Wenn Gebiet, Fahrzeugart und Ausrüstung passen, genügt einer dieser Nachweise“. Die Regeln sind von dir eingetragen.',
        'Bei der Aktivität wählst du das Gebiet aus der Liste. Die Prüfung nutzt die Regeln des Gebiets zusätzlich zu den Anforderungen am Fahrzeug.',
        'Kennt die App für ein Gebiet und dein Fahrzeug keine Regel, sagt sie höchstens „unklar“ und nie „erlaubt“.',
        'Noch nicht dabei: Quelle und Prüfdatum je Regel, Reisecheck, weitere Länder.'
      ] },
      { version: '2.0.9', datum: '2026-11-03', punkte: [
        'Sicherungsdatei: ein Tipp erstellt eine Datei mit allen deinen Daten. Sie lässt sich speichern oder teilen, zum Beispiel in die Cloud.',
        'Wahlweise mit Schlüsselwort verschlüsselt. Darin stehen auch Ausweisdaten und Scans.',
        'Dokumente und Scans kannst du mitsichern oder weglassen. Vorher siehst du, wie groß es wird.',
        'Wiederherstellen: Die App zeigt zuerst, was in der Sicherung steht und was ersetzt wird. Erst nach deiner Bestätigung wird etwas verändert, und zwar ganz oder gar nicht.',
        'Die App erinnert an die Sicherung, nach 14, 30 oder 90 Tagen oder gar nicht.'
      ] },
      { version: '2.0.8', datum: '2026-11-03', punkte: [
        'Aktivitäten (Urlaub, Törn, Ausfahrt, Wasserski, Segeln, Rallye): Name, Art, Fahrzeug, Zeitraum mit freiwilliger Uhrzeit, Gebiet, geplante Strecke oder Betriebsstunden, Tiere und Notiz.',
        'Besatzung aus den Personen: Skipper oder Fahrer, Stellvertreter und Crew. Jede Person steht einmal da, bei Bedarf mit „dabei von bis“.',
        'Zu jedem Zeitpunkt ist genau eine Person verantwortlich. Jeder Wechsel wird mit Zeitpunkt festgehalten.',
        'Prüfung bei der Planung: Befähigung von Skipper oder Fahrer und Stellvertretern (erlaubt, nicht erlaubt, unklar, mit „geprüft am“), Fristen bis zum Ende des Zeitraums und Überschneidungen am Fahrzeug.',
        'Am Fahrzeug legst du fest, welche Nachweise ein Skipper oder Fahrer braucht.',
        'Aktivitäten lassen sich jederzeit stornieren und wiederherstellen. Nichts wird gelöscht.'
      ] },
      { version: '2.0.7', datum: '2026-11-03', punkte: [
        'Personen mit Funktionen (Skipper, Fahrer, Crew, Beifahrer, Gast) und Tiere mit Tierart und Chipnummer.',
        'Nachweise an Personen, Tieren und Fahrzeugen, mit „gültig bis“, Status und optionalem Scan oder Foto, das nur auf dem Gerät bleibt.',
        'Die Liste der Nachweisarten ist offen: Du legst eigene Arten an oder übernimmst Vorschläge für Deutschland und die EU. Jeder Vorschlag nennt seine Quelle und wie weit er geprüft ist.',
        'Vorschläge: Führerschein, Personalausweis, Reisepass, Sportbootführerschein, Funkzeugnisse, Heimtierausweis, Tollwutimpfung, Zulassungsbescheinigung Teil I und II, Hauptuntersuchung, Internationaler Bootsschein und mehr.',
        'Die Fahrzeugliste zeigt auch abgelaufene und bald ablaufende Nachweise.'
      ] },
      { version: '2.0.6', datum: '2026-11-03', punkte: [
        'Dokumente an Fahrzeug und Komponente: Bedienungsanleitung, Ersatzteilliste, Wartungsanleitung, Kaufbeleg, Garantie, Foto oder Sonstiges.',
        'Als Datei vom Gerät (auch ohne Internet da) oder als Link ins Internet.',
        'Am Fahrzeug gibt es eine Gesamtliste aller Dokumente, nach Komponente geordnet und mit Suche.',
        'In den Einstellungen siehst du, wie viel Speicher die Dokumente belegen und wie viel Platz der Browser erlaubt.'
      ] },
      { version: '2.0.5', datum: '2026-11-03', punkte: [
        'Fristen am Fahrzeug und an jeder Komponente: nach Zeit (Monate oder Jahre), nach Zähler (Strecke oder Betriebsstunden) oder nach beidem. Was zuerst eintritt, löst die Fälligkeit aus.',
        'Zähler am Fahrzeug oder pro Komponente, zum Beispiel pro Motor, mit Verlauf der Zählerstände.',
        'Jede Frist zeigt, ob sie in Ordnung, bald fällig oder überfällig ist. In der Fahrzeugliste siehst du es auf einen Blick.',
        'Wirkung bei Überfälligkeit (nur warnen, eingeschränkt, Sperre) und Vorwarnung sind einstellbar.',
        '„Erledigt eintragen“ setzt die Rechnung einer Frist neu an, frühere Erledigungen bleiben sichtbar.'
      ] },
      { version: '2.0.4', datum: '2026-11-03', punkte: [
        'Hauptkomponenten (Schale 3): Motor, Getriebe, Heizung, Klima, Stromversorgung, Wasserversorgung und Sonstiges.',
        'Darunter lässt sich beliebig tief aufschlüsseln, zum Beispiel Motor, Einspritzung, Pumpe.',
        'Zu jedem Teil: Hersteller, Modell, Seriennummer, Baujahr, Einbau, Ausbau und technische Merkmale.',
        'Änderungen bleiben wie beim Fahrzeug im Verlauf sichtbar.',
        'Wenn eine neue Version bereitsteht, erscheint ein Hinweis zum Neuladen.'
      ] },
      { version: '2.0.3', datum: '2026-11-03', punkte: [
        'Startseite neu gestaltet: Die Buchstaben V, T und D des Logos stehen vor den drei Teilen des Kernsatzes.',
        'Infotext: „Reisen planen“.',
        'Das Logo ist an einer einzigen Stelle abgelegt und gilt auf der Startseite, in der Kopfzeile und als App-Symbol.'
      ] },
      { version: '2.0.2', datum: '2026-11-03', punkte: [
        'Startseite mit Logo, Kernsatz und den Knöpfen „Programm starten“ und „Neu im Programm“.',
        'Hauptmenü mit Stammdaten, Funktionen und Einstellungen.',
        'Stammdaten mit den Fahrzeugen. Personen und Tiere folgen.',
        'Einstellungen mit Hinweisen zu deinen Daten.'
      ] },
      { version: '2.0.1', datum: '2026-11-03', punkte: [
        'Fahrzeugliste und äußere Hülle für sieben Fahrzeugarten.',
        'Eingaben von Hand, jede Änderung bleibt im Verlauf sichtbar.',
        'Funktioniert ohne Internet, die Daten liegen auf dem Gerät.'
      ] }
    ]
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
