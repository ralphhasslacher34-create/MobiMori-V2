/*
 * Grundcheck (Schritt 11b, seit 2.0.40): die reinen Regeln, ohne Speicher und ohne Netz.
 *
 * Festlegungen vom 05.11.2026:
 *  - Der Check braucht kein Aktivitätsdatum und keine Besatzung. Er fragt: Was braucht dieses Fahrzeug an seinem
 *    Heimatort (Heimatland) legal an Papieren und Grundausrüstung?
 *  - Jeder Punkt hat Quelle und Stand. Verglichen wird mit dem, was am Fahrzeug eingetragen ist:
 *    vorhanden, zu wenig, fehlt oder unklar. Es wird nichts gesperrt, und es ist keine rechtsgültige Aussage.
 *  - Fehlt etwas, führt ein Link direkt in die Komponentenliste (Ausrüstung) oder zu den Nachweisen (Papiere).
 *  - Der Dienst kann (Stand V1) nur freie Texte liefern, keine Felder für Menge und Bezugsgröße. Deshalb verlangt
 *    die Anfrage ein festes Zeilenformat „Name | Menge | je Fahrzeug oder je Person | Erklärung“. Was sich nicht
 *    in diesem Format lesen lässt, zählt als „unklar“ und wird nicht geraten.
 *  - Die vorhandene Rechnung für Pflichtausrüstung (MM.Orte.ausruestungPruefen) wird wiederverwendet.
 *  - „Je Person“ rechnet mit den Plätzen am Fahrzeug (Feld „Personen / Plätze“), nicht mit einer Besatzung.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Reihenfolge = Dringlichkeit: Was fehlt, steht oben. */
  var STATUS = ['fehlt', 'zu_wenig', 'unklar', 'vorhanden'];
  var STATUS_TEXT = { vorhanden: 'Vorhanden', zu_wenig: 'Zu wenig', fehlt: 'Fehlt', unklar: 'Unklar' };
  var ARTEN = ['papier', 'ausruestung'];
  var ARTEN_TEXT = { papier: 'Papiere', ausruestung: 'Ausrüstung' };

  var MAX_PUNKTE = 40;

  function text(x) { return x === null || x === undefined ? '' : String(x).trim(); }
  function klein(s) { return text(s).toLowerCase(); }

  /* Die Aufgabe an den Dienst. Sie steht in der Anfrage, weil der Dienst selbst (V1) nicht geändert wird. */
  var AUFGABE = {
    zweck: 'GRUNDCHECK: Prüfe NICHT eine Reise, sondern nur, was dieses Fahrzeug an seinem Heimatort (trip.areas, Land) dauerhaft ' +
      'an Papieren und Grundausrüstung mitführen muss. Es gibt keine Besatzung und keine Personen. Lass Befähigungen, Grenzen, Schengen, ' +
      'Tiere, Maut und Reiseregeln weg. Nimm nur Dinge auf, die für diese Fahrzeugart im Heimatland amtlich vorgeschrieben sind ' +
      '(Fahrzeugpapiere, Warndreieck, Warnweste, Verbandskasten, Feuerlöscher, Rettungsmittel und Ähnliches, je nach Fahrzeugart). ' +
      'Pflicht und Quelle zuerst, keine Empfehlungen als Pflicht ausgeben.',
    format: 'Jede Anforderung hat subjectKey „vehicle“ und subjectType „Fahrzeug“. Das Feld requirement hat GENAU dieses Format mit senkrechten Strichen: ' +
      '„Name | Menge | je Fahrzeug | kurze Erklärung“ oder „Name | Menge | je Person | kurze Erklärung“. Menge ist eine ganze Zahl ab 1. ' +
      '„je Person“ gilt, wenn die Menge von der Zahl der Personen im Fahrzeug abhängt (zum Beispiel Warnweste je Person). ' +
      'Das Feld proofKey ist „Papier“ für Dokumente oder „Ausrüstung“ für Gegenstände. Ein Name steht für genau einen Gegenstand oder ein Papier ' +
      '(zum Beispiel „Zulassungsbescheinigung Teil 1“, „Zulassungsbescheinigung Teil 2“, „Warndreieck“, „Warnweste“, „Feuerlöscher“). ' +
      'Keine Anforderung erfinden. Was nicht sicher ist, mit status „Prüfen“ und niedrigem Vertrauen angeben.'
  };

  /* ---------- Anfrage ---------- */

  /*
   * e: { heute: 'JJJJ-MM-TT', land: 'Deutschland', fahrzeug: { artName, welt, werte, komponenten:[{name,anzahl}], nachweise:[...] } }
   * Rückgabe: { ok, fehler[], anfrage } – es gehen nur Angaben ohne Namen und ohne Nummern hinaus.
   */
  function anfrageBauen(e) {
    e = e || {};
    var fehler = [];
    var fz = e.fahrzeug || null;
    var land = text(e.land);
    if (!fz) fehler.push('Das Fahrzeug wurde nicht gefunden.');
    if (!land) fehler.push('Das Heimatland ist noch nicht bekannt. Wähle zuerst den Heimatstandort des Fahrzeugs, dessen Ort geprüft ist (Stammdaten › Orte).');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text(e.heute))) fehler.push('Das heutige Datum fehlt.');
    if (fehler.length) return { ok: false, fehler: fehler };
    var vehicle = MM.Reisecheck.fahrzeugBlock(fz);
    return { ok: true, fehler: [], anfrage: {
      trip: { title: 'Grundcheck', start: e.heute + 'T00:00:00', end: e.heute + 'T23:59:00', trafficModes: MM.Reisecheck.verkehrsarten(fz.welt), checkMode: 'free',
        areas: [{ key: 'G1', name: land, type: 'Land', path: land }] },
      vehicle: vehicle, persons: [], animals: [], locale: 'de-DE',
      basicCheck: { task: AUFGABE.zweck, format: AUFGABE.format, homeCountry: land },
      researchPolicy: { currentWebResearchRequired: true, preferOfficialSources: true, officialSourcesForMandatoryItems: true,
        uncertaintyMustBeVisible: true, doNotInferComplianceWhenEvidenceIsMissing: true } } };
  }

  function vorschau(anfrage) {
    var v = anfrage.vehicle, z = [];
    z.push('Heimatland: ' + anfrage.trip.areas[0].name);
    z.push('Fahrzeug: ' + [v.profile, v.manufacturer, v.model].filter(Boolean).join(' ') + (v.lengthM ? ', ' + String(v.lengthM).replace('.', ',') + ' m lang' : ''));
    if (v.seats) z.push('Plätze: ' + v.seats);
    if (v.components.length) z.push('Teile am Fahrzeug: ' + v.components.length + ' (nur Bezeichnung und Anzahl)');
    z.push('Keine Besatzung, keine Namen, keine Nummern.');
    return z;
  }

  /* ---------- Antwort lesen ---------- */

  /* „Name | Menge | je Fahrzeug | Erklärung“. Alles andere ist nicht lesbar und wird nicht geraten. */
  function zeileLesen(roh) {
    var t = text(roh);
    var teile = t.split('|').map(text);
    if (teile.length < 3 || !teile[0]) return null;
    var m = /^\d+$/.test(teile[1]) ? Number(teile[1]) : null;
    var b = klein(teile[2]);
    var bezug = b === 'je person' ? 'person' : (b === 'je fahrzeug' ? 'fahrzeug' : null);
    if (!m || m < 1 || !bezug) return null;
    return { name: teile[0], menge: m, bezug: bezug, erklaerung: teile.slice(3).join(' | ') };
  }

  function artVon(proofKey) {
    var k = klein(proofKey);
    if (k.indexOf('papier') === 0) return 'papier';
    if (k.indexOf('ausr') === 0) return 'ausruestung';
    return null;
  }

  /*
   * Macht aus dem gespeicherten Ergebnis des Dienstes die Punkte des Grundchecks.
   *  { punkte: [{ id, name, menge, bezug, art, erklaerung, kategorie, quellen, stand }], nichtLesbar: [{ id, text, quellen }] }
   * Nur Anforderungen am Fahrzeug zählen. „Nicht relevant“ fällt weg.
   */
  function punkteLesen(ergebnis, dienst) {
    var punkte = [], nicht = [], gesehen = {};
    ((ergebnis && ergebnis.anforderungen) || []).forEach(function (a) {
      if (a.status === 'Nicht relevant') return;
      if (a.subjektArt !== 'Fahrzeug' && a.subjekt !== 'vehicle') return;
      var z = zeileLesen(a.anforderung), art = artVon(a.nachweisArt);
      var stand = (a.quellen || []).map(function (q) { return q.stand; }).filter(Boolean)[0] || (dienst && dienst.recherchiertAm ? String(dienst.recherchiertAm).slice(0, 10) : '');
      if (!z || !art) { nicht.push({ id: a.id, text: a.anforderung, kategorie: a.kategorie, quellen: a.quellen || [], stand: stand }); return; }
      var schl = art + ':' + klein(z.name);
      if (gesehen[schl]) return;
      gesehen[schl] = true;
      punkte.push({ id: a.id, name: z.name, menge: z.menge, bezug: z.bezug, art: art, erklaerung: z.erklaerung, kategorie: a.kategorie,
        vertrauen: a.vertrauen, widerspruch: !!a.widerspruch, quellen: a.quellen || [], stand: stand });
    });
    return { punkte: punkte.slice(0, MAX_PUNKTE), nichtLesbar: nicht.slice(0, 20) };
  }

  /* ---------- Vergleich mit dem Fahrzeug ---------- */

  /* Zum Suchen in den Namen der Komponenten: ohne Klammern, ohne Zusätze. */
  function suchbegriff(name) { return text(name).replace(/\([^)]*\)/g, ' ').replace(/\s+/g, ' ').trim(); }

  /* Wörter für den Papiervergleich: „Teil 1“ und „Teil I“ sind dasselbe. */
  var ZAHLWORT = { '1': 'i', '2': 'ii', '3': 'iii' };
  function woerter(s) {
    return text(s).toLowerCase().replace(/\([^)]*\)/g, ' ').replace(/[^a-z0-9äöüß ]+/g, ' ').split(/\s+/).filter(Boolean).map(function (w) { return ZAHLWORT[w] || w; });
  }
  function papierPasst(papierName, artName) {
    var n = woerter(papierName), a = woerter(artName);
    if (!n.length || !a.length) return false;
    return n.every(function (w) { return a.indexOf(w) >= 0; });
  }

  function linkZuKomponente(fahrzeugId, punkt, anzahl) {
    return '#/fahrzeug/' + encodeURIComponent(fahrzeugId) + '/komponente/neu?name=' + encodeURIComponent(suchbegriff(punkt.name)) + '&anzahl=' + encodeURIComponent(String(anzahl));
  }

  /*
   * p.punkte       aus punkteLesen
   * p.komponenten  [{ name, anzahl, geprueft }]  nur eingebaute
   * p.nachweise    [{ artName, gescannt }]  am Fahrzeug
   * p.plaetze      Zahl der Plätze am Fahrzeug oder null
   * p.fahrzeugId   für die Links
   * Ergebnis: [{ punkt, status, soll, ist, text, link: { href, text } | null }], nach Dringlichkeit sortiert
   */
  function vergleichen(p) {
    var plaetze = Number(p.plaetze) >= 1 ? Math.floor(Number(p.plaetze)) : null;
    var fid = p.fahrzeugId;
    var zeilen = (p.punkte || []).map(function (pt) {
      if (pt.art === 'papier') {
        var treffer = (p.nachweise || []).filter(function (n) { return papierPasst(pt.name, n.artName); });
        if (!treffer.length) return { punkt: pt, status: 'fehlt', soll: pt.menge, ist: 0, text: '„' + pt.name + '“ ist am Fahrzeug nicht als Nachweis eingetragen.',
          link: { href: '#/fahrzeug/' + encodeURIComponent(fid) + '/nachweis/neu', text: 'Nachweis eintragen' } };
        if (!treffer.some(function (n) { return n.gescannt; })) return { punkt: pt, status: 'unklar', soll: pt.menge, ist: treffer.length,
          text: '„' + pt.name + '“ ist eingetragen, aber es hängt noch kein Foto oder Scan daran.', link: null };
        return { punkt: pt, status: 'vorhanden', soll: pt.menge, ist: treffer.length, text: '„' + pt.name + '“ ist als Nachweis mit Foto oder Scan eingetragen.', link: null };
      }
      /* Ausrüstung: die vorhandene Rechnung der Pflichtausrüstung. Je Person braucht die Plätze am Fahrzeug. */
      var e = MM.Orte.ausruestungPruefen({ regel: { pflichtAusruestung: suchbegriff(pt.name), menge: pt.menge, bezug: pt.bezug },
        komponenten: p.komponenten || [], personen: plaetze || 0 });
      if (e.status === 'keine_besatzung') return { punkt: pt, status: 'unklar', soll: null, ist: e.ist,
        text: '„' + pt.name + '“: ' + pt.menge + ' je Person. Am Fahrzeug sind die Plätze nicht eingetragen, deshalb lässt sich die Menge nicht rechnen.',
        link: { href: '#/fahrzeug/' + encodeURIComponent(fid) + '/aendern', text: 'Plätze am Fahrzeug eintragen' } };
      var soll = e.soll, sollText = pt.bezug === 'person' ? soll + ' (' + pt.menge + ' je Person, ' + plaetze + (plaetze === 1 ? ' Platz' : ' Plätze') + ')' : String(soll);
      if (e.status === 'nicht_eingetragen') return { punkt: pt, status: 'fehlt', soll: soll, ist: 0,
        text: '„' + pt.name + '“ ist am Fahrzeug nicht eingetragen. Soll: ' + sollText + '.', link: { href: linkZuKomponente(fid, pt, soll), text: 'Als Komponente eintragen' } };
      if (e.status === 'zu_wenig') return { punkt: pt, status: 'zu_wenig', soll: soll, ist: e.ist,
        text: '„' + pt.name + '“: eingetragen sind ' + e.ist + ', Soll ist ' + sollText + '.', link: { href: linkZuKomponente(fid, pt, soll), text: 'Menge ergänzen' } };
      return { punkt: pt, status: 'vorhanden', soll: soll, ist: e.ist, text: '„' + pt.name + '“: ' + e.ist + ' von ' + sollText + ' eingetragen.', link: null };
    });
    return zeilen.map(function (z, i) { return { z: z, i: i }; }).sort(function (x, y) {
      return STATUS.indexOf(x.z.status) - STATUS.indexOf(y.z.status) || x.i - y.i;
    }).map(function (x) { return x.z; });
  }

  function zusammenfassung(zeilen) {
    var z = { fehlt: 0, zu_wenig: 0, unklar: 0, vorhanden: 0 };
    (zeilen || []).forEach(function (x) { z[x.status]++; });
    return z;
  }

  function zaehlText(z) {
    var t = [];
    if (z.vorhanden) t.push(z.vorhanden + ' vorhanden');
    if (z.zu_wenig) t.push(z.zu_wenig + ' zu wenig');
    if (z.fehlt) t.push(z.fehlt + (z.fehlt === 1 ? ' fehlt' : ' fehlen'));
    if (z.unklar) t.push(z.unklar + ' unklar');
    return t.length ? t.join(' · ') : 'Keine Punkte';
  }

  MM.Grundcheck = {
    STATUS: STATUS, STATUS_TEXT: STATUS_TEXT, ARTEN: ARTEN, ARTEN_TEXT: ARTEN_TEXT, AUFGABE: AUFGABE,
    anfrageBauen: anfrageBauen, vorschau: vorschau, zeileLesen: zeileLesen, punkteLesen: punkteLesen,
    suchbegriff: suchbegriff, papierPasst: papierPasst, vergleichen: vergleichen, zusammenfassung: zusammenfassung, zaehlText: zaehlText
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
