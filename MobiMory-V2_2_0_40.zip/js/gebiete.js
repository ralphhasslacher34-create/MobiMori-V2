/*
 * Gebiete aus Orten (seit 2.0.39): Hierarchie Land > Region > Kreis (Straße) und Land > Revier (Wasser).
 *
 * Aus den V2-Festlegungen vom 05.11.2026:
 *  - Der Nutzer gibt nur Orte ein. Aus dem Ort entsteht das Gebiet (zum Beispiel Deutschland, Baden-Württemberg).
 *  - Jedes Gebiet wird beim ersten Mal gespeichert und danach wiederverwendet (Gebietsbibliothek).
 *  - Gebiet je Art: nur Landfahrzeuge im Konto = nur Straßen-Gebiet, nur Wasserfahrzeuge = nur Revier
 *    (Binnenwasserstraße), beide = beide. Im Check zählt das Fahrzeug der Aktivität.
 *  - Fehlt etwas (Ort nicht geprüft, kein Revier), sagt die App „unklar“ und sperrt nichts.
 *
 * Hier steht nur Beschreibung und Rechnung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var EBENEN = [
    { wert: 'land', label: 'Land' },
    { wert: 'region', label: 'Region (zum Beispiel Bundesland)' },
    { wert: 'kreis', label: 'Kreis oder Département' },
    { wert: 'revier', label: 'Revier (Binnenwasserstraße)' }
  ];
  /* Welche Ebenen zählen für welche Art von Fahrzeug. Luftfahrzeuge: nur das Land, weil dafür noch nichts festgelegt ist. */
  var EBENEN_JE_WELT = { land: ['land', 'region', 'kreis'], wasser: ['land', 'revier'], luft: ['land'] };

  function ebeneLabel(wert) { for (var i = 0; i < EBENEN.length; i++) { if (EBENEN[i].wert === wert) return EBENEN[i].label; } return null; }
  function ebenenFuer(welt) { return (EBENEN_JE_WELT[welt] || EBENEN_JE_WELT.land).slice(); }

  /* Die Ebenen, die ein Konto braucht: nur Landfahrzeuge = Straßen-Gebiet, nur Wasserfahrzeuge = Revier, beide = beide. Ohne Fahrzeug: alle. */
  function ebenenFuerKonto(welten) {
    var w = (welten || []).filter(function (x, i, a) { return a.indexOf(x) === i; });
    if (!w.length) return EBENEN.map(function (e) { return e.wert; });
    var ebenen = {};
    w.forEach(function (x) { ebenenFuer(x).forEach(function (e) { ebenen[e] = true; }); });
    return EBENEN.map(function (e) { return e.wert; }).filter(function (e) { return ebenen[e]; });
  }

  function normal(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim().toLowerCase(); }

  /* Der Schlüssel macht ein Gebiet wiederfindbar: gleiche Kette, gleicher Schlüssel. */
  function schluessel(elternSchluessel, ebene, name, code) {
    if (ebene === 'land') return 'land:' + (code ? String(code).toLowerCase() : normal(name));
    return (elternSchluessel || '') + '/' + ebene + ':' + normal(name);
  }

  function nachId(liste) { var m = {}; (liste || []).forEach(function (x) { m[x.objekt.id] = x; }); return m; }

  /* Der Weg von oben (Land) bis zu diesem Gebiet: [{ id, name, ebene }]. Ein Gebiet ohne Ebene (eigenes Gebiet) steht allein. */
  function pfad(liste, id) {
    var m = nachId(liste), weg = [], z = id, n = 0;
    while (z && m[z] && n++ < 10) {
      var w = m[z].aktuell.werte;
      weg.unshift({ id: z, name: w.bezeichnung, ebene: w.ebene || null });
      z = w.elternId || null;
    }
    return weg;
  }

  function pfadText(kette, trenner) { return (kette || []).map(function (g) { return g.name; }).join(trenner || ' › '); }

  /*
   * Die Gebiete einer Aktivität aus ihren Orten (Start, Ziel, Zwischenziele).
   *  p.gebiete  Liste der Gebiete ({ objekt, aktuell })
   *  p.orte     [{ name, werte }]  die Orte der Aktivität (werte mit gebietId und revierId)
   *  p.welt     'land' | 'wasser' | 'luft'  die Art des Fahrzeugs der Aktivität
   * Ergebnis: { ketten: [[{ id, name, ebene }]], ids: [id], ohneGebiet: [Ortsnamen], ohneRevier: [Ortsnamen] }
   */
  function kettenAusOrten(p) {
    var welt = p.welt || 'land', erlaubt = ebenenFuer(welt), m = nachId(p.gebiete);
    var ketten = [], gesehen = {}, ids = [], ohneGebiet = [], ohneRevier = [];
    function aufnehmen(kette) {
      if (!kette.length) return;
      var k = kette.map(function (g) { return g.id; }).join('>');
      if (gesehen[k]) return;
      gesehen[k] = true; ketten.push(kette);
      kette.forEach(function (g) { if (ids.indexOf(g.id) < 0) ids.push(g.id); });
    }
    (p.orte || []).forEach(function (o) {
      var w = o.werte || {};
      if (!w.gebietId || !m[w.gebietId]) { if (ohneGebiet.indexOf(o.name) < 0) ohneGebiet.push(o.name); return; }
      var weg = pfad(p.gebiete, w.gebietId);
      var kette = weg.filter(function (g) { return g.ebene && g.ebene !== 'revier' && erlaubt.indexOf(g.ebene) >= 0; });
      if (welt === 'wasser') {
        if (w.revierId && m[w.revierId]) {
          var rw = pfad(p.gebiete, w.revierId).filter(function (g) { return g.ebene === 'revier'; });
          kette = kette.concat(rw);
        } else if (ohneRevier.indexOf(o.name) < 0) ohneRevier.push(o.name);
      }
      /* Ein eigenes Gebiet ohne Ebene bleibt als einzelnes Glied erhalten. */
      if (!kette.length && weg.length && !weg[weg.length - 1].ebene) kette = [weg[weg.length - 1]];
      aufnehmen(kette);
    });
    return { ketten: ketten, ids: ids, ohneGebiet: ohneGebiet, ohneRevier: ohneRevier };
  }

  MM.Gebiete = {
    EBENEN: EBENEN, ebeneLabel: ebeneLabel, ebenenFuer: ebenenFuer, ebenenFuerKonto: ebenenFuerKonto,
    normal: normal, schluessel: schluessel, pfad: pfad, pfadText: pfadText, kettenAusOrten: kettenAusOrten
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
