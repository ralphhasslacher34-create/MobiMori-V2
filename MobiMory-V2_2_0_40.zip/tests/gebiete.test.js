'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/gebiete.js');
const MM = globalThis.MM;
const G = MM.Gebiete;

const gebiet = (id, name, ebene, eltern) => ({ objekt: { id }, aktuell: { werte: { bezeichnung: name, ebene: ebene || null, elternId: eltern || null } } });
const GEBIETE = [
  gebiet('de', 'Deutschland', 'land'), gebiet('bw', 'Baden-Württemberg', 'region', 'de'), gebiet('bb', 'Landkreis Böblingen', 'kreis', 'bw'),
  gebiet('en', 'Enzkreis', 'kreis', 'bw'), gebiet('rh', 'Rhein', 'revier', 'de'), gebiet('eigen', 'Kroatien, Adria')
];
const ort = (name, w) => ({ name, werte: w });

test('Gebiet je Art im Konto: nur Land = Straße, nur Wasser = Revier, beide = beide, ohne Fahrzeug alles', () => {
  assert.deepEqual(G.ebenenFuerKonto(['land']), ['land', 'region', 'kreis']);
  assert.deepEqual(G.ebenenFuerKonto(['wasser']), ['land', 'revier']);
  assert.deepEqual(G.ebenenFuerKonto(['land', 'wasser']), ['land', 'region', 'kreis', 'revier']);
  assert.deepEqual(G.ebenenFuerKonto(['wasser', 'land', 'wasser']), ['land', 'region', 'kreis', 'revier']);
  assert.deepEqual(G.ebenenFuerKonto([]), ['land', 'region', 'kreis', 'revier']);
  assert.deepEqual(G.ebenenFuer('luft'), ['land']);
  assert.deepEqual(G.ebenenFuer('unbekannt'), ['land', 'region', 'kreis']);
});

test('Schlüssel: gleiche Kette ergibt denselben Schlüssel, Groß- und Kleinschreibung und Leerzeichen zählen nicht', () => {
  const land = G.schluessel('', 'land', 'Deutschland', 'DE');
  assert.equal(land, 'land:de');
  assert.equal(G.schluessel('', 'land', ' Deutschland ', null), 'land:deutschland');
  const r1 = G.schluessel(land, 'region', 'Baden-Württemberg'), r2 = G.schluessel(land, 'region', '  baden-württemberg ');
  assert.equal(r1, r2);
  assert.notEqual(G.schluessel(land, 'kreis', 'Rhein'), G.schluessel(land, 'revier', 'Rhein'), 'Ebene gehört zum Schlüssel');
});

test('Weg von oben, auch bei einem eigenen Gebiet ohne Ebene', () => {
  assert.deepEqual(G.pfad(GEBIETE, 'en').map(g => g.name), ['Deutschland', 'Baden-Württemberg', 'Enzkreis']);
  assert.equal(G.pfadText(G.pfad(GEBIETE, 'en')), 'Deutschland › Baden-Württemberg › Enzkreis');
  assert.equal(G.pfadText(G.pfad(GEBIETE, 'en'), ', '), 'Deutschland, Baden-Württemberg, Enzkreis');
  assert.deepEqual(G.pfad(GEBIETE, 'eigen').map(g => g.ebene), [null]);
  assert.deepEqual(G.pfad(GEBIETE, 'gibt-es-nicht'), []);
});

test('Landfahrzeug: Land, Region, Kreis der Orte; gleiche Ketten zählen einmal', () => {
  const r = G.kettenAusOrten({ gebiete: GEBIETE, welt: 'land', orte: [
    ort('Start', { gebietId: 'bb' }), ort('Ziel', { gebietId: 'bb' }), ort('Halt', { gebietId: 'en', revierId: 'rh' })] });
  assert.equal(r.ketten.length, 2);
  assert.deepEqual(r.ketten[0].map(g => g.name), ['Deutschland', 'Baden-Württemberg', 'Landkreis Böblingen']);
  assert.deepEqual(r.ids, ['de', 'bw', 'bb', 'en']);
  assert.deepEqual(r.ohneGebiet, []); assert.deepEqual(r.ohneRevier, [], 'beim Landfahrzeug zählt kein Revier');
});

test('Wasserfahrzeug: Land und Revier, ohne Revier sagt die App es', () => {
  const r = G.kettenAusOrten({ gebiete: GEBIETE, welt: 'wasser', orte: [
    ort('Hafen', { gebietId: 'bb', revierId: 'rh' }), ort('Anleger', { gebietId: 'en' })] });
  assert.deepEqual(r.ketten[0].map(g => g.name), ['Deutschland', 'Rhein']);
  assert.deepEqual(r.ketten[1].map(g => g.name), ['Deutschland']);
  assert.deepEqual(r.ohneRevier, ['Anleger']);
});

test('Luftfahrzeug: nur das Land; Orte ohne Gebiet sind unklar; eigenes Gebiet bleibt', () => {
  const l = G.kettenAusOrten({ gebiete: GEBIETE, welt: 'luft', orte: [ort('Platz', { gebietId: 'bb' })] });
  assert.deepEqual(l.ketten[0].map(g => g.name), ['Deutschland']);
  const u = G.kettenAusOrten({ gebiete: GEBIETE, welt: 'land', orte: [ort('Unbekannt', {}), ort('Weg', { gebietId: 'gelöscht' }), ort('Eigen', { gebietId: 'eigen' })] });
  assert.deepEqual(u.ohneGebiet, ['Unbekannt', 'Weg']);
  assert.deepEqual(u.ketten[0].map(g => g.name), ['Kroatien, Adria']);
});
