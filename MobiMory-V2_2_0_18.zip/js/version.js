/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.18';
  MM.STUFE = 'Cockpit im Vollbild mit frei belegbaren Schnellknöpfen';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
