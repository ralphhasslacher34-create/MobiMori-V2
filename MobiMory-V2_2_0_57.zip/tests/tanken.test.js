'use strict';
/* 2.0.51: Tanken komplett: Füllstand, Verbrauch, Reichweite, Kostenposten (Kostenart „Treibstoff und Energie“).
   Festlegungen vom 09.11.2026: Füllstand einmal angeben, nicht voll = Stand plus Menge (nur gerechnet), Verbrauch je Verbraucher aus Füllstand oder Betriebsstunden. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/aktionen.js');
require('../js/baukasten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/karte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const T = MM.Tanken, B = MM.Baukasten;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

/* ---------- Rechenregeln ---------- */

const grund = (o) => Object.assign({ kapazitaet: 80, alt: { fuellstand: 60, art: 'angegeben', zeit: '2026-11-08T12:00', stunden: { m1: 100 } },
  menge: 30, voll: true, zeit: '2026-11-10T12:00', verbraucher: [{ id: 'm1', name: 'Motor', aus: 'fuellstand', stunden: 110 }] }, o);

test('Voll getankt: Tank ist voll, Verbrauch = alter Stand minus (Tankinhalt minus Menge), je Tag', () => {
  const e = T.berechnen(grund());
  assert.equal(e.setzen, true);
  assert.equal(e.fuellstand, 80);
  assert.equal(e.art, 'voll');
  assert.equal(e.verbrauch.liter, 10);
  assert.equal(e.verbrauch.lProTag, 5);
  assert.equal(e.verbrauch.summe, false);
  assert.deepEqual(e.reichweite, [{ name: 'Motor', wert: 16, einheit: 'Tage' }]);
});

test('Verbrauch aus Betriebsstunden: Liter je Betriebsstunde, Reichweite in Betriebsstunden', () => {
  const e = T.berechnen(grund({ verbraucher: [{ id: 'm1', name: 'Motor', aus: 'stunden', stunden: 105 }] }));
  assert.equal(e.verbrauch.einzeln[0].lProStunde, 2);
  assert.equal(e.verbrauch.einzeln[0].stunden, 5);
  assert.deepEqual(e.reichweite.map(x => x.einheit), ['Betriebsstunden', 'Tage']);
  assert.equal(e.reichweite[0].wert, 40);
});

test('Betriebsstunden fehlen: nichts wird geraten, es gibt nur den Verbrauch je Tag und einen Hinweis', () => {
  const e = T.berechnen(grund({ alt: { fuellstand: 60, art: 'angegeben', zeit: '2026-11-08T12:00', stunden: {} }, verbraucher: [{ id: 'm1', name: 'Motor', aus: 'stunden', stunden: 105 }] }));
  assert.equal(e.verbrauch.einzeln[0].lProStunde, undefined);
  assert.equal(e.verbrauch.lProTag, 5);
  assert.ok(e.hinweise.some(h => /Betriebsstunden/.test(h)));
});

test('Mehrere Verbraucher an einem Tank: der Füllstand gibt nur die Summe', () => {
  const e = T.berechnen(grund({ verbraucher: [{ id: 'm1', name: 'Motor', aus: 'stunden', stunden: 105 }, { id: 'h1', name: 'Heizung', aus: 'fuellstand', stunden: null }] }));
  assert.equal(e.verbrauch.summe, true);
  assert.equal(e.verbrauch.lProTag, 5);
  assert.ok(e.verbrauch.einzeln.every(x => x.lProStunde === undefined && x.lProTag === undefined));
  assert.ok(e.hinweise.some(h => /nur die Summe/.test(h)));
  assert.equal(e.reichweite[0].name, 'alle Verbraucher zusammen');
});

test('Nicht voll getankt: Füllstand plus Menge, mit Hinweis „nur gerechnet“; kein neuer Verbrauch', () => {
  const e = T.berechnen(grund({ voll: false, menge: 10 }));
  assert.equal(e.setzen, true);
  assert.equal(e.fuellstand, 70);
  assert.equal(e.art, 'gerechnet');
  assert.equal(e.verbrauch, null);
  assert.ok(e.hinweise.some(h => /nur gerechnet/.test(h)));
});

test('Nicht voll getankt: mehr als der Tankinhalt wird begrenzt, mit Hinweis', () => {
  const e = T.berechnen(grund({ voll: false, menge: 40 }));
  assert.equal(e.fuellstand, 80);
  assert.ok(e.hinweise.some(h => /begrenzt/.test(h)));
});

test('Noch kein Füllstand angegeben: nicht voll rechnet nichts, es kommt der Hinweis, den Stand einmal anzugeben', () => {
  const e = T.berechnen(grund({ voll: false, alt: {} }));
  assert.equal(e.setzen, false);
  assert.equal(e.fuellstand, null);
  assert.ok(e.hinweise.some(h => /einmal beim Tank an/.test(h)));
});

test('Voll getankt ohne früheren Stand: Tank ist voll, Verbrauch wird noch nicht gerechnet', () => {
  const e = T.berechnen(grund({ alt: {} }));
  assert.equal(e.fuellstand, 80);
  assert.equal(e.verbrauch, null);
  assert.ok(e.hinweise.some(h => /Verbrauch noch nicht gerechnet/.test(h)));
});

test('Voll getankt ohne Tankinhalt: kein Füllstand, Hinweis', () => {
  const e = T.berechnen(grund({ kapazitaet: null }));
  assert.equal(e.setzen, false);
  assert.ok(e.hinweise.some(h => /Tankinhalt/.test(h)));
});

test('Letzter Stand war nur gerechnet: kein Verbrauch aus einem ungenauen Stand', () => {
  const e = T.berechnen(grund({ alt: { fuellstand: 60, art: 'gerechnet', zeit: '2026-11-08T12:00' } }));
  assert.equal(e.verbrauch, null);
  assert.equal(e.fuellstand, 80);
  assert.ok(e.hinweise.some(h => /nur gerechnet/.test(h)));
});

test('Menge passt nicht zum Stand (negativer Verbrauch): keine Rechnung, Hinweis', () => {
  const e = T.berechnen(grund({ menge: 5 }));
  assert.equal(e.verbrauch, null);
  assert.ok(e.hinweise.some(h => /passt nicht/.test(h)));
});

test('Tanken liegt vor dem letzten Stand (nachgetragen): Füllstand bleibt', () => {
  const e = T.berechnen(grund({ zeit: '2026-11-01T12:00' }));
  assert.equal(e.setzen, false);
  assert.ok(e.hinweise.some(h => /vor dem letzten Füllstand/.test(h)));
});

test('Tankinhalt wird nur in Litern gelesen', () => {
  assert.equal(T.kapazitaet({ merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] }), 80);
  assert.equal(T.kapazitaet({ merkmale: [{ name: 'tankinhalt', wert: '45,5', einheit: '' }] }), 45.5);
  assert.equal(T.kapazitaet({ merkmale: [{ name: 'Tankinhalt', wert: '11', einheit: 'kg' }] }), null);
  assert.equal(T.kapazitaet({ merkmale: [] }), null);
  assert.equal(T.kapazitaet({}), null);
});

/* ---------- Baukasten: nur Einträge in den Listen ---------- */

test('Baukasten: Fragen Tank, Menge, Literpreis, Voll getankt und Wirkungen Füllstand, Verbrauch, Reichweite stehen in den Listen', () => {
  assert.equal(B.frage('tank').typ, 'auswahl');
  assert.equal(B.frage('menge').typ, 'zahl');
  assert.equal(B.frage('literpreis').typ, 'zahl');
  assert.equal(B.frage('voll').typ, 'janein');
  ['fuellstand', 'verbrauch', 'reichweite', 'kostenTreibstoff'].forEach(id => assert.ok(B.wirkung(id), id));
  assert.ok(lesen('js/baukasten.js').includes("{ id: 'fuellstand', name: 'Füllstand setzen'"));
});

test('Vorlage „Tanken“: ein Anfang, kein Zwang; die Haken sind danach änderbar', () => {
  const v = B.vorlage('tanken');
  assert.deepEqual(v.fragen, ['tank', 'menge', 'betrag', 'literpreis', 'voll']);
  assert.deepEqual(v.wirkungen, ['kostenTreibstoff', 'fuellstand', 'verbrauch', 'reichweite']);
  assert.deepEqual(B.fehlendeFragen({ fragen: v.fragen, wirkungen: v.wirkungen }), []);
  assert.equal(B.vorlage('gibtsnicht'), null);
  v.fragen.push('x');
  assert.equal(B.vorlage('tanken').fragen.length, 5, 'Änderungen an der Kopie ändern die Vorlage nicht');
});

test('Wirkungen bauen aufeinander auf und der Kostenposten braucht Betrag oder Literpreis', () => {
  assert.ok(B.fehlendeFragen({ fragen: ['tank', 'menge', 'voll'], wirkungen: ['verbrauch'] }).some(m => /Füllstand setzen/.test(m)));
  assert.ok(B.fehlendeFragen({ fragen: ['tank', 'menge', 'voll'], wirkungen: ['fuellstand', 'reichweite'] }).some(m => /Verbrauch rechnen/.test(m)));
  assert.ok(B.fehlendeFragen({ fragen: ['tank'], wirkungen: ['fuellstand'] }).some(m => /Menge/.test(m)));
  assert.ok(B.fehlendeFragen({ fragen: ['menge'], wirkungen: ['kostenTreibstoff'] }).some(m => /Betrag.*oder.*Literpreis/.test(m)));
  assert.deepEqual(B.fehlendeFragen({ fragen: ['literpreis'], wirkungen: ['kostenTreibstoff'] }), []);
});

/* ---------- Datenschicht ---------- */

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 8, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.uhr = uhr;
  return d;
}
const TAG = 86400000;

async function boot() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: fz, vonDatum: '2026-11-08', vonZeit: '09:00', bisDatum: '2026-11-20', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok, JSON.stringify(r));
  const tank = await d.komponenteAnlegen(fz, null, 'tank', { bezeichnung: 'Dieseltank', stoff: 'Diesel', merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] });
  assert.ok(tank.ok, JSON.stringify(tank));
  const motor = await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Motor', verbraucher: 'ja', stoff: 'Diesel', quellen: [tank.id], verbrauchAus: 'stunden' });
  assert.ok(motor.ok, JSON.stringify(motor));
  const art = await d.ereignisartAnlegen({ bezeichnung: 'Tanken', fragen: B.vorlage('tanken').fragen, wirkungen: B.vorlage('tanken').wirkungen });
  assert.ok(art.ok, JSON.stringify(art));
  return { d, id: r.id, fz, tank: tank.id, motor: motor.id, art: art.id };
}
async function tankenEreignis(c) {
  const e = await c.d.ereignisSchnell(c.id, 'Tanken', { artId: c.art, ortName: 'Horrheim' });
  assert.ok(e.ok, JSON.stringify(e));
  return e.id;
}
const tankWerte = async (c) => (await c.d.komponenteLaden(c.tank)).aktuell.werte;

test('Verbraucher: „Verbrauch rechnen aus“ wird gespeichert und bleibt bei jeder Änderung', async () => {
  const c = await boot();
  assert.equal((await c.d.komponenteLaden(c.motor)).aktuell.werte.verbrauchAus, 'stunden');
  const r = await c.d.komponenteAendern(c.motor, { bezeichnung: 'Motor Steuerbord' });
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal((await c.d.komponenteLaden(c.motor)).aktuell.werte.verbrauchAus, 'stunden');
  const aend = await c.d.komponenteAendern(c.motor, { bezeichnung: 'Motor Steuerbord', verbraucher: 'ja', stoff: 'Diesel', quellen: [c.tank], verbrauchAus: 'fuellstand' });
  assert.ok(aend.ok && aend.geaendert, JSON.stringify(aend));
  assert.equal((await c.d.komponenteLaden(c.motor)).aktuell.werte.verbrauchAus, 'fuellstand');
  const schlecht = await c.d.komponenteAendern(c.motor, { bezeichnung: 'Motor', verbraucher: 'ja', stoff: 'Diesel', quellen: [c.tank], verbrauchAus: 'quatsch' });
  assert.equal(schlecht.ok, false);
  assert.ok(schlecht.fehler.verbrauchAus);
});

test('Füllstand einmal angeben: gespeichert mit Art „angegeben“, geprüft gegen den Tankinhalt, bleibt bei anderen Änderungen', async () => {
  const c = await boot();
  const zuViel = await c.d.komponenteAendern(c.tank, { bezeichnung: 'Dieseltank', stoff: 'Diesel', fuellstand: '90', merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] });
  assert.equal(zuViel.ok, false);
  assert.ok(zuViel.fehler.fuellstand);
  const kein = await c.d.komponenteAendern(c.tank, { bezeichnung: 'Dieseltank', stoff: 'Diesel', fuellstand: 'viel', merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] });
  assert.ok(kein.fehler.fuellstand);
  const ok = await c.d.komponenteAendern(c.tank, { bezeichnung: 'Dieseltank', stoff: 'Diesel', fuellstand: '60', merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] });
  assert.ok(ok.ok && ok.geaendert, JSON.stringify(ok));
  const w = await tankWerte(c);
  assert.equal(w.fuellstand, 60);
  assert.equal(w.fuellstandArt, 'angegeben');
  assert.match(w.fuellstandZeit, /^2026-11-08T\d\d:\d\d$/);
  const umbenannt = await c.d.komponenteAendern(c.tank, { bezeichnung: 'Hauptdieseltank', stoff: 'Diesel', merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] });
  assert.ok(umbenannt.ok, JSON.stringify(umbenannt));
  const w2 = await tankWerte(c);
  assert.equal(w2.bezeichnung, 'Hauptdieseltank');
  assert.equal(w2.fuellstand, 60, 'der Füllstand geht beim Umbenennen nicht verloren');
});

async function stand(c, liter) {
  const r = await c.d.komponenteAendern(c.tank, { bezeichnung: 'Dieseltank', stoff: 'Diesel', fuellstand: String(liter), merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] });
  assert.ok(r.ok, JSON.stringify(r));
}

test('Tanken: ein Tipp legt Kostenposten (Treibstoff und Energie) an, setzt den Füllstand, rechnet Verbrauch und Reichweite', async () => {
  const c = await boot();
  const zaehler = (await c.d.motorZaehler(c.fz, c.motor)).id;
  assert.ok((await c.d.zaehlerStandEintragen(zaehler, { wert: '100', datum: '2026-11-08' })).ok);
  await stand(c, 60);
  c.d.uhr.ms += 2 * TAG;
  assert.ok((await c.d.zaehlerStandEintragen(zaehler, { wert: '105', datum: '2026-11-10' })).ok);
  const id = await tankenEreignis(c);
  const r = await c.d.ereignisAblaufAusfuehren(id, { tankId: c.tank, menge: '30', betrag: '', literpreis: '1,80', voll: 'ja' });
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal(r.kostenNeu, true);
  assert.equal(r.betrag, 54);
  const kosten = await c.d.kostenListe(c.fz);
  const posten = kosten.find(k => k.objekt.id === r.kostenId);
  assert.equal(posten.aktuell.werte.kostenart, 'treibstoff');
  assert.equal(posten.aktuell.werte.betrag, 54);
  assert.equal(posten.aktuell.werte.gruppe, 'variabel');
  const w = await tankWerte(c);
  assert.equal(w.fuellstand, 80);
  assert.equal(w.fuellstandArt, 'voll');
  assert.equal(w.verbrauch.liter, 10);
  assert.equal(w.verbrauch.lProTag, 5);
  assert.equal(w.verbrauch.einzeln[0].lProStunde, 2, 'Motor rechnet aus Betriebsstunden: 10 l in 5 h');
  assert.deepEqual(w.reichweite.map(x => x.einheit), ['Betriebsstunden', 'Tage']);
  assert.equal(w.reichweite[0].wert, 40);
  assert.equal(w.fuellstandStunden[c.motor], 105);
  const e = (await c.d.ereignisLaden(id)).aktuell.werte;
  assert.equal(e.tankId, c.tank);
  assert.equal(e.tankName, 'Dieseltank');
  assert.equal(e.menge, 30);
  assert.equal(e.literpreis, 1.8);
  assert.equal(e.voll, 'ja');
  assert.equal(e.fuellstandNach, 80);
  assert.equal(e.betrag, 54);
  assert.ok(r.tank.zeilen.some(z => /Füllstand Dieseltank: 80 l/.test(z)));
  assert.ok(r.tank.zeilen.some(z => /Verbrauch/.test(z)));
  assert.ok(r.tank.zeilen.some(z => /Reichweite/.test(z)));
});

test('Tanken: zweimal abschicken verbucht nichts doppelt (Füllstand, Verbrauch, Kostenposten)', async () => {
  const c = await boot();
  await stand(c, 60);
  c.d.uhr.ms += 2 * TAG;
  const id = await tankenEreignis(c);
  const r1 = await c.d.ereignisAblaufAusfuehren(id, { tankId: c.tank, menge: '30', betrag: '50', voll: 'ja' });
  assert.ok(r1.ok, JSON.stringify(r1));
  const eintraege = async () => (await c.d.komponenteLaden(c.tank)).aktuell.nr;
  const n = await eintraege();
  const r2 = await c.d.ereignisAblaufAusfuehren(id, { tankId: c.tank, menge: '30', betrag: '50', voll: 'ja' });
  assert.ok(r2.ok, JSON.stringify(r2));
  assert.equal(r2.tankSchonGebucht, true);
  assert.equal(r2.kostenNeu, false);
  assert.equal(await eintraege(), n);
  assert.equal((await c.d.kostenListe(c.fz)).length, 1);
});

test('Tanken nicht voll: Stand plus Menge, Hinweis „nur gerechnet“, Art „gerechnet“', async () => {
  const c = await boot();
  await stand(c, 40);
  c.d.uhr.ms += TAG;
  const id = await tankenEreignis(c);
  const r = await c.d.ereignisAblaufAusfuehren(id, { tankId: c.tank, menge: '15', betrag: '27', voll: 'nein' });
  assert.ok(r.ok, JSON.stringify(r));
  const w = await tankWerte(c);
  assert.equal(w.fuellstand, 55);
  assert.equal(w.fuellstandArt, 'gerechnet');
  assert.ok(r.tank.hinweise.some(h => /nur gerechnet/.test(h)));
  assert.equal(w.verbrauch, undefined);
});

test('Tanken ohne angegebenen Füllstand und nicht voll: Kostenposten ja, Füllstand bleibt leer, Hinweis', async () => {
  const c = await boot();
  const id = await tankenEreignis(c);
  const r = await c.d.ereignisAblaufAusfuehren(id, { tankId: c.tank, menge: '20', betrag: '36', voll: 'nein' });
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal(r.kostenNeu, true);
  assert.equal((await tankWerte(c)).fuellstand, undefined);
  assert.ok(r.tank.hinweise.some(h => /einmal beim Tank an/.test(h)));
});

test('Tanken: Pflichtangaben und falsche Eingaben, nichts wird halb gespeichert', async () => {
  const c = await boot();
  const id = await tankenEreignis(c);
  const ohne = await c.d.ereignisAblaufAusfuehren(id, { betrag: '30' });
  assert.equal(ohne.ok, false);
  assert.ok(ohne.fehler.tank && ohne.fehler.menge && ohne.fehler.voll);
  const kaputt = await c.d.ereignisAblaufAusfuehren(id, { tankId: c.tank, menge: 'viel', literpreis: '-1', betrag: '30', voll: 'vielleicht' });
  assert.ok(kaputt.fehler.menge && kaputt.fehler.literpreis && kaputt.fehler.voll);
  const fremd = await c.d.ereignisAblaufAusfuehren(id, { tankId: c.motor, menge: '10', betrag: '30', voll: 'ja' });
  assert.equal(fremd.ok, false);
  assert.ok(fremd.fehler.tank, 'ein Motor ist kein Tank');
  const keinBetrag = await c.d.ereignisAblaufAusfuehren(id, { tankId: c.tank, menge: '10', voll: 'ja' });
  assert.ok(keinBetrag.fehler.betrag);
  const nurPreis = await c.d.ereignisAblaufAusfuehren(id, { tankId: c.tank, literpreis: '1,8', voll: 'ja' });
  assert.ok(nurPreis.fehler.menge);
  assert.equal((await c.d.kostenListe(c.fz)).length, 0);
  assert.equal((await c.d.komponenteLaden(c.tank)).aktuell.nr, 1);
  assert.equal((await c.d.ereignisLaden(id)).aktuell.werte.tankGebucht, undefined);
});

test('Betrag oder Literpreis: ein eingetragener Betrag gilt, sonst Menge mal Literpreis', async () => {
  const c = await boot();
  const id1 = await tankenEreignis(c);
  const r1 = await c.d.ereignisAblaufAusfuehren(id1, { tankId: c.tank, menge: '10', betrag: '20', literpreis: '1,50', voll: 'nein' });
  assert.equal(r1.betrag, 20);
  const id2 = await tankenEreignis(c);
  const r2 = await c.d.ereignisAblaufAusfuehren(id2, { tankId: c.tank, menge: '10', literpreis: '1,799', voll: 'nein' });
  assert.equal(r2.betrag, 17.99);
});

test('Eine Art ohne Tanken-Bausteine bleibt, wie sie war (Kostenposten ohne Kostenart, keine Tankbuchung)', async () => {
  const c = await boot();
  const a = await c.d.ereignisartAnlegen({ bezeichnung: 'Marina', fragen: ['betrag'], wirkungen: ['kosten'] });
  const e = await c.d.ereignisSchnell(c.id, 'Marina', { artId: a.id, ortName: 'Horrheim' });
  const r = await c.d.ereignisAblaufAusfuehren(e.id, { betrag: '12' });
  assert.ok(r.ok, JSON.stringify(r));
  const p = (await c.d.kostenListe(c.fz)).find(k => k.objekt.id === r.kostenId);
  assert.ok(!p.aktuell.werte.kostenart);
  assert.equal(r.tank, null);
});

/* ---------- Seiten (festgelegt im Programm) ---------- */

const ansicht = lesen('js/ansicht.js');
function funktion(name) {
  const start = ansicht.indexOf('  function ' + name + '(');
  assert.ok(start >= 0, 'Funktion fehlt: ' + name);
  return ansicht.slice(start, ansicht.indexOf('\n  }\n', start));
}

test('Seite nach dem Antippen: Fragen Tank, Menge, Literpreis, Voll getankt und das Ergebnis mit Hinweisen', () => {
  const f = funktion('cockpitAktionSeite');
  ["fid === 'tank'", "fid === 'menge'", "fid === 'literpreis'", "fid === 'voll'"].forEach(t => assert.ok(f.includes(t), t));
  assert.ok(f.includes('daten.versorgungKette('));
  assert.ok(f.includes('tankId: v.tankId'));
  assert.ok(f.includes('be.ergebnis.tank.hinweise'));
  assert.ok(f.includes('be.ergebnis.tank.zeilen'));
});

test('Tank-Formular: Füllstand einmal angeben; Verbraucher: Verbrauch rechnen aus; Vorlage bei der Art', () => {
  const k = funktion('seiteKomponentenFormular');
  assert.ok(k.includes("name: 'fuellstand'"));
  assert.ok(k.includes("name: 'verbrauchAus'"));
  assert.ok(k.includes("input[name=\"verbrauchAus\"]:checked"));
  const a = funktion('ereignisartFormular');
  assert.ok(a.includes("key: 'vorlage'"));
  assert.ok(a.includes('MM.Baukasten.vorlage('));
});

test('Neue Datei js/tanken.js ist in index.html und im Service Worker eingetragen', () => {
  assert.ok(lesen('index.html').includes('<script src="js/tanken.js"></script>'));
  assert.ok(lesen('sw.js').includes("'js/tanken.js'"));
});

test('Version 2.0.57 überall gleich', () => {
  assert.equal(MM.VERSION, '2.0.57');
  assert.equal(MM.STUFE, 'Störung als Zusammenstellung');
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.57';"));
  assert.equal(JSON.parse(lesen('package.json')).version, '2.0.57');
  assert.ok(lesen('README.md').includes('Version 2.0.57'));
  assert.ok(lesen('CHANGELOG.md').startsWith('# Änderungen\n\n## 2.0.57'));
  assert.ok(lesen('js/texte.js').includes("version: '2.0.57'"));
  assert.ok(lesen('docs/SCHRITTE.md').includes('| 12d |'));
});
