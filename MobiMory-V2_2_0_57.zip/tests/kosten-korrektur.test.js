'use strict';
/* 2.0.46, Schritt 11h: Kostenblock – gleiche Kennung nur nach Rückfrage, Kostenposten löschen, abgegebene Fahrzeuge in der Kosten-Liste. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/austausch.js');
require('../js/daten.js');
const MM = globalThis.MM;
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

function geraet() {
  let t = 0;
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 7, 12, 0, t++)).toISOString() });
}
const datei = (inhalt, name) => { const b = new Blob([inhalt], { type: 'application/pdf' }); Object.defineProperty(b, 'name', { value: name || 'beleg.pdf' }); return b; };
const fehlerVon = r => r.fehler || {};

/* ================= Punkt 2: gleiche Kennung ================= */
test('Anlegen: gleiches Kennzeichen wird nicht angelegt, sondern gemeldet (ohne Rücksicht auf Groß/Klein, Leerzeichen, Striche)', async () => {
  const d = geraet(); await d.starten();
  const erst = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC', kennzeichen: 'HN-AB 123' });
  assert.ok(erst.ok);
  for (const k of ['HN-AB 123', 'hn ab 123', 'HNAB123', 'hn-ab-123', 'HN.AB.123']) {
    const r = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC zweiter', kennzeichen: k });
    assert.equal(r.ok, false, k);
    assert.equal(r.doppelt.length, 1);
    assert.equal(r.doppelt[0].id, erst.id);
    assert.equal(r.doppelt[0].name, 'LMC');
    assert.equal(r.doppelt[0].abgegeben, false);
    assert.match(r.fehler.allgemein, /Es gibt schon ein Fahrzeug mit der Kennung/);
    assert.ok(r.fehler.allgemein.includes('„LMC“'));
  }
  assert.equal((await d.fahrzeugListe({ alle: true })).length, 1, 'nichts wurde angelegt');
});

test('Anlegen: mit „trotzdem“ wird angelegt, ohne gleiche Kennung gibt es keine Rückfrage', async () => {
  const d = geraet(); await d.starten();
  await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC', kennzeichen: 'HN-AB 123' });
  assert.ok((await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Anderes', kennzeichen: 'HN-AB 124' })).ok, 'andere Kennung');
  assert.ok((await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Ohne Kennung' })).ok, 'ohne Kennung nie ein Treffer');
  assert.ok((await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Ohne Kennung zwei' })).ok, 'ohne Kennung nie ein Treffer');
  const r = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC bewusst', kennzeichen: 'HN-AB 123' }, { trotzdem: true });
  assert.ok(r.ok);
  assert.equal((await d.fahrzeugListe({ alle: true })).length, 5);
});

test('Anlegen: Fehler in den Angaben kommen vor der Rückfrage, FIN und Registriernummer zählen als Kennung', async () => {
  const d = geraet(); await d.starten();
  await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC', kennzeichen: 'HN-AB 123', fin: 'WDB1234567A000001' });
  const ohneName = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: '', kennzeichen: 'HN-AB 123' });
  assert.ok(fehlerVon(ohneName).bezeichnung, 'zuerst die Angaben prüfen');
  assert.equal(ohneName.doppelt, undefined);
  const mitFin = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Zweites', fin: 'wdb 1234567a000001' });
  assert.equal(mitFin.ok, false);
  assert.equal(mitFin.doppelt.length, 1);
  const boot = await d.fahrzeugAnlegen('boot', { bezeichnung: 'Seestern', registriernummer: 'D-1234' });
  assert.ok(boot.ok);
  const noch = await d.fahrzeugAnlegen('boot', { bezeichnung: 'Seestern 2', registriernummer: 'd 1234' });
  assert.equal(noch.ok, false);
});

test('Anlegen: auch ein abgegebenes Fahrzeug mit gleicher Kennung führt zur Rückfrage und ist als abgegeben gekennzeichnet', async () => {
  const d = geraet(); await d.starten();
  const a = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC alt', kennzeichen: 'HN-AB 123' });
  await d.fahrzeugAbgeben(a.id, { datum: '2026-11-01', grund: 'verkauft' });
  const r = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC neu', kennzeichen: 'HN-AB 123' });
  assert.equal(r.ok, false);
  assert.equal(r.doppelt[0].abgegeben, true);
  assert.equal(r.doppelt[0].abgabeDatum, '2026-11-01');
  assert.match(r.fehler.allgemein, /abgegeben am/);
});

test('Anlegen: mehrere Treffer werden alle genannt', async () => {
  const d = geraet(); await d.starten();
  await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC eins', kennzeichen: 'HN-AB 123' });
  await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC zwei', kennzeichen: 'HN-AB 123' }, { trotzdem: true });
  const r = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC drei', kennzeichen: 'HN-AB 123' });
  assert.equal(r.doppelt.length, 2);
  assert.match(r.fehler.allgemein, /2 Fahrzeuge/);
});

test('Die Vergleichsregel der Kennung ist dieselbe wie beim Import', async () => {
  const d = geraet(); await d.starten();
  const proben = ['HN-AB 123', 'hn ab 123', ' D-1234 ', 'w.d.b-123', 'x'];
  for (const p of proben) {
    await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'F ' + p, kennzeichen: p }, { trotzdem: true });
    const t = await d.kennungTreffer({ kennzeichen: MM.Austausch.kennungNorm(p) });
    assert.ok(t.length >= 1, 'Import-Schreibweise trifft: ' + p);
  }
});

test('Import: gleiche Kennung ist schon in der Vorschau „vorhanden“ und wird nicht angelegt (Befund 2.0.45)', async () => {
  const d = geraet(); await d.starten();
  await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC', kennzeichen: 'HN-AB 123' });
  const opt = { zeilen: [['Neues', 'HN AB 123'], ['Anderes', 'HN-AB 999']], zuordnung: ['bezeichnung', 'kennzeichen'], artId: 'wohnmobil' };
  const v = await d.importVorschau(opt);
  assert.equal(v.zeilen[0].status, 'vorhanden');
  assert.equal(v.zeilen[1].status, 'neu');
  const r = await d.importFahrzeuge(opt);
  assert.equal(r.anzahl, 1);
  assert.equal((await d.fahrzeugListe({ alle: true })).length, 2);
});

/* ================= Punkt 2: Übergabe ================= */
async function uebergabeDatei() {
  const quelle = geraet(); await quelle.starten();
  const id = (await quelle.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC', kennzeichen: 'HN-AB 123' })).id;
  await quelle.fahrzeugAbgeben(id, { datum: '2026-11-01', grund: 'verkauft' });
  const u = await quelle.uebergabeErzeugen(id, { mitDateien: false });
  assert.ok(u.ok);
  return { quelle, id, bytes: u.bytes };
}

test('Übergabe: Vorschau nennt das vorhandene Fahrzeug mit gleicher Kennung, Einspielen fragt erst', async () => {
  const { quelle, id, bytes } = await uebergabeDatei();
  const g = await quelle.uebergabeLesen(bytes);
  const v = await quelle.uebergabeVorschau(g);
  assert.equal(v.kennungTreffer.length, 1);
  assert.equal(v.kennungTreffer[0].id, id);
  assert.equal(v.kennungTreffer[0].abgegeben, true);
  assert.match(v.kennungText, /Es gibt schon ein Fahrzeug mit der Kennung „HN-AB 123“/);
  const vorher = (await quelle.fahrzeugListe({ alle: true })).length;
  const r = await quelle.uebergabeEinspielen(g);
  assert.equal(r.ok, false);
  assert.equal(r.doppelt.length, 1);
  assert.ok(fehlerVon(r).allgemein);
  assert.equal((await quelle.fahrzeugListe({ alle: true })).length, vorher, 'nichts angelegt');
  const trotzdem = await quelle.uebergabeEinspielen(g, { trotzdem: true });
  assert.ok(trotzdem.ok);
  assert.equal((await quelle.fahrzeugListe({ alle: true })).length, vorher + 1);
});

test('Übergabe: auf einem Gerät ohne dieses Fahrzeug keine Rückfrage', async () => {
  const { quelle, bytes } = await uebergabeDatei();
  const ziel = geraet(); await ziel.starten();
  const g = await ziel.uebergabeLesen(bytes);
  const v = await ziel.uebergabeVorschau(g);
  assert.equal(v.kennungTreffer.length, 0);
  assert.equal(v.kennungText, null);
  assert.ok((await ziel.uebergabeEinspielen(g)).ok);
  /* schon übernommen: wie bisher die Frage nach „nochmal“, und mit „nochmal“ geht es ohne weitere Kennungsfrage */
  const noch = await ziel.uebergabeEinspielen(g);
  assert.equal(noch.schonDa, true);
  assert.ok((await ziel.uebergabeEinspielen(g, { nochmal: true })).ok);
  assert.ok(quelle);
});

/* ================= Punkt 4: Kostenposten löschen ================= */
async function mitPosten() {
  const d = geraet(); await d.starten();
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil', kennzeichen: 'HN-AB 123' })).id;
  const falsch = await d.kostenAnlegen(wm, { gruppe: 'fix', bezeichnung: 'Versicherung falsch', kostenart: 'versicherung', betrag: '999', rhythmus: 'jaehrlich', datum: '2026-01-01' });
  const richtig = await d.kostenAnlegen(wm, { gruppe: 'fix', bezeichnung: 'Versicherung', kostenart: 'versicherung', betrag: '499', rhythmus: 'jaehrlich', datum: '2026-01-01' });
  assert.ok(falsch.ok && richtig.ok);
  return { d, wm, falsch: falsch.id, richtig: richtig.id };
}

test('Löschen: der Posten verschwindet mit seinem Verlauf, andere Posten und die Auswertung bleiben', async () => {
  const { d, wm, falsch, richtig } = await mitPosten();
  await d.kostenAendern(falsch, { gruppe: 'fix', bezeichnung: 'Versicherung falsch', kostenart: 'versicherung', betrag: '888', rhythmus: 'jaehrlich', datum: '2026-01-01' });
  assert.equal((await d.speicher.wo('verlaeufe', 'objektId', falsch)).length, 2);
  assert.equal((await d.kostenAuswertung(wm, 2026)).gesamt.summe, 888 + 499, 'vorher zählen beide');
  const r = await d.kostenLoeschen(falsch);
  assert.deepEqual(r, { ok: true, belege: 0 });
  assert.equal(await d.kostenLaden(falsch), null);
  assert.equal((await d.speicher.wo('verlaeufe', 'objektId', falsch)).length, 0, 'Verlauf ist weg');
  const liste = await d.kostenListe(wm);
  assert.deepEqual(liste.map(x => x.objekt.id), [richtig]);
  assert.ok((await d.kostenLaden(richtig)));
  assert.equal((await d.kostenAuswertung(wm, 2026)).gesamt.summe, 499, 'nur noch der richtige Posten zählt');
});

test('Löschen: Fotos und Belege des Postens gehen mit (samt Dateien und Verlauf), die von anderen Posten bleiben', async () => {
  const { d, wm, falsch, richtig } = await mitPosten();
  const b1 = await d.dokumentAnlegen(wm, null, { quelle: 'datei', art: 'bedienung', bezeichnung: 'Beleg 1', datei: datei('abc', 'b1.pdf') }, null, falsch);
  const b2 = await d.dokumentAnlegen(wm, null, { quelle: 'datei', art: 'bedienung', bezeichnung: 'Beleg 2', datei: datei('abcd', 'b2.pdf') }, null, falsch);
  const b3 = await d.dokumentAnlegen(wm, null, { quelle: 'datei', art: 'bedienung', bezeichnung: 'Beleg anderer', datei: datei('abcde', 'b3.pdf') }, null, richtig);
  assert.ok(b1.ok && b2.ok && b3.ok, JSON.stringify([b1, b2, b3]));
  assert.equal((await d.kostenLaden(falsch)).dokumente.length, 2);
  const r = await d.kostenLoeschen(falsch);
  assert.deepEqual(r, { ok: true, belege: 2 });
  const alleDok = await d.speicher.alle('dokumente');
  assert.deepEqual(alleDok.map(x => x.id), [b3.id]);
  assert.equal((await d.speicher.alle('dateien')).length, 1);
  assert.deepEqual((await d.speicher.alle('dateien')).map(x => x.dokumentId), [b3.id]);
  const verl = (await d.speicher.alle('verlaeufe')).filter(e => e.objektTyp === 'dokument').map(e => e.objektId);
  assert.deepEqual(verl, [b3.id]);
  assert.equal((await d.kostenLaden(richtig)).dokumente.length, 1);
});

test('Löschen: unbekannter Posten und Posten eines fremden Datenraums werden abgewiesen', async () => {
  const { d } = await mitPosten();
  assert.ok(fehlerVon(await d.kostenLoeschen('gibt-es-nicht')).allgemein);
  const fremd = new MM.Daten.Daten(d.speicher, { jetzt: () => new Date().toISOString() });
  await fremd.starten();
  fremd.datenraumId = 'anderer-raum';
  const alle = await d.speicher.alle('kosten');
  const r = await fremd.kostenLoeschen(alle[0].id);
  assert.ok(fehlerVon(r).allgemein);
  assert.equal((await d.speicher.alle('kosten')).length, 2, 'nichts gelöscht');
});

test('Löschen: ein Betrag der Reisekasse zählt danach nicht mehr in der Kasse', async () => {
  const d = geraet(); await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const art = arten.find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const akt = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: art, fahrzeugId: boot, vonDatum: '2026-07-01', bisDatum: '2026-07-10', verantwortlichId: anna });
  assert.ok(akt.ok, JSON.stringify(akt));
  const k = await d.kostenAnlegen(boot, { gruppe: 'reisekasse', bezeichnung: 'Pizza', betrag: '20', datum: '2026-07-02', aktivitaetId: akt.id });
  assert.ok(k.ok, JSON.stringify(k));
  const vorher = await d.kostenListe(boot);
  assert.equal(vorher.length, 1);
  assert.deepEqual(await d.kostenLoeschen(k.id), { ok: true, belege: 0 });
  assert.equal((await d.kostenListe(boot)).length, 0);
});

/* ================= Seiten (im Quelltext geprüft, es gibt keinen Browser im Test) ================= */
const ansicht = lesen('js/ansicht.js');
function funktion(name) {
  const start = ansicht.indexOf('  function ' + name + '(');
  assert.ok(start >= 0, 'Funktion fehlt: ' + name);
  const ende = ansicht.indexOf('\n  }\n', start);
  return ansicht.slice(start, ende);
}

test('Kosten-Liste: abgegebene Fahrzeuge stehen getrennt, eingeklappt und gekennzeichnet', () => {
  const f = funktion('seiteKostenUebersicht');
  assert.match(f, /x\.fahrzeug\.abgabe/);
  assert.ok(f.includes("'Abgegebene Fahrzeuge ('"));
  assert.ok(f.includes("' · abgegeben ('"));
  assert.match(f, /h\('details', \{ class: 'ausgebaut' \}/);
});

test('Seite des Postens: Korrigieren, Ausblenden und Löschen stehen zusammen, Löschen fragt vorher', () => {
  const f = funktion('seitePosten');
  assert.ok(f.includes("'Falsch eingegeben?'"));
  assert.ok(f.includes("text: 'Korrigieren'"));
  assert.ok(f.includes("text: 'Löschen'"));
  assert.match(f, /global\.confirm\(frage\)/);
  assert.match(f, /daten\.kostenLoeschen\(id\)/);
  assert.ok(f.indexOf('global.confirm') < f.indexOf('daten.kostenLoeschen'), 'erst fragen, dann löschen');
  assert.match(f, /class: 'knopf gefahr'/);
  assert.ok(!f.includes("text: 'Angaben ändern'"), 'der Knopf heißt jetzt Korrigieren');
});

test('Kosten-Seiten: Hinweis, dass man den Posten antippt, um ihn zu korrigieren oder zu löschen', () => {
  assert.ok(funktion('kostenGruppeBereich').includes('Falsch eingetragen? Tippe den Posten an'));
});

test('Fahrzeug-Formular und Übernahme: Rückfrage bei gleicher Kennung', () => {
  const f = ansicht.slice(ansicht.indexOf('function rueckfrageBox'), ansicht.indexOf('function rueckfrageBox') + 2500);
  assert.ok(f.includes("'Trotzdem neu anlegen'") && f.includes("'Kennung ändern'") && f.includes('öffnen'));
  assert.match(ansicht, /daten\.fahrzeugAnlegen\(zustand\.art, zustand\.werte, \{ trotzdem: zustand\.trotzdem \}\)/);
  assert.match(ansicht, /!r\.ok && r\.doppelt/);
  const u = funktion('seiteUebernehmen');
  assert.ok(u.includes("'Trotzdem übernehmen'"));
  assert.match(u, /uebergabeEinspielen\(g, \{ nochmal: !!nochmal, trotzdem: kennungDa \}\)/);
});

test('Version 2.0.46 überall', () => {
  assert.equal(MM.VERSION, '2.0.57');
});
