/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.86';
  MM.STUFE = 'Leihe vereinfacht: kein eigener Plan, Check und Tagebuch für Leihreisen; Planung und Fahrzeugseiten unverändert';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
