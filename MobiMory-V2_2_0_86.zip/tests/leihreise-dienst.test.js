'use strict';
/* 2.0.79 (Bau 3, Dienst 13f-4): Zwei Zeiträume je Freigabe (Planung, Verleih), Schreibsperre vor dem Verleih, Reisecheck des Gastes über das Kontingent des Besitzers. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

const APP = 'https://app.example.org';
const PW = 'Sehr-sicheres-Passwort-1';
const TAG = 24 * 60 * 60 * 1000;
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) {
  return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1',
    RECHERCHE_URL: 'https://recherche.example.org', RECHERCHE_TOKEN: 'geheim-token-1' }, extra || {});
}
function uhr() { const u = { t: Date.UTC(2026, 10, 11, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
function recherche() {
  const r = { aufrufe: [] };
  r.fetch = async (url, opt) => { r.aufrufe.push({ url, body: JSON.parse(opt.body) }); return new Response(JSON.stringify({ ok: true, requirements: [{ id: 'a' }], model: 'm' }), { status: 200 }); };
  return r;
}
async function roh(env, u, methode, weg, body, token, optionen) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  return d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, Object.assign({ jetzt: u.jetzt }, optionen || {}));
}
async function ruf(env, u, methode, weg, body, token, optionen) { const r = await roh(env, u, methode, weg, body, token, optionen); return { status: r.status, json: await r.json() }; }
async function konto(env, u, email) {
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email, passwort: PW });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode });
  return b.json.token;
}
function satz(tabelle, o) { return { tabelle, id: o.id, basis: 0, nutzlast: JSON.stringify(o) }; }
async function besitzer(env, u) {
  const tok = await konto(env, u, 'besitzer@example.org');
  const r = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [
    satz('fahrzeuge', { id: 'fz-1', datenraumId: '@', art: 'wohnmobil', erstelltAm: 1 }),
    satz('eintraege', { id: 'en-1', fahrzeugId: 'fz-1', nr: 1, werte: { bezeichnung: 'Mein Wohnmobil', kennzeichen: 'LB-AB 123', marke: 'Fiat' }, erstelltAm: 1 }),
    satz('zaehler', { id: 'za-1', fahrzeugId: 'fz-1', komponenteId: null, art: 'strecke', erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-za-1', objektTyp: 'zaehler', objektId: 'za-1', nr: 1, werte: { bezeichnung: 'Kilometerstand' }, erstelltAm: 1 }),
    satz('zaehlerstaende', { id: 'zs-1', zaehlerId: 'za-1', nr: 1, wert: 51000, datum: '2026-10-01', erstelltAm: 1 })
  ] }, tok);
  assert.equal(r.status, 200, JSON.stringify(r.json));
  return { tok };
}
async function einladen(env, u, tok, extra) {
  return ruf(env, u, 'POST', '/freigabe/einladen', Object.assign({ fahrzeugId: 'fz-1', email: 'gast@example.org', bis: '2027-03-31', nachweisArt: 'Führerschein', nachweisBis: '', bestaetigt: true }, extra || {}), tok);
}
async function freigabe(env, u, b, extra) {
  const gast = await konto(env, u, 'gast@example.org');
  const e = await einladen(env, u, b.tok, extra);
  assert.equal(e.status, 200, JSON.stringify(e.json));
  const a = await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, gast);
  assert.equal(a.status, 200, JSON.stringify(a.json));
  return { gast, id: e.json.id };
}
const MIT = { rechte: 'mitnutzen', gastName: 'Anna' };
const PLAN = { planAb: '2026-11-11', ab: '2026-11-20' };
const ANFRAGE = { trip: { areas: [{ name: 'Schweden' }], von: '2027-06-01' }, vehicle: { art: 'wohnmobil' } };

test('Einladung: „Planung ab“ wird geprüft; gleich dem Verleih oder leer heißt keine Planung vor dem Verleih', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  const nach = await einladen(env, u, b.tok, { planAb: '2026-11-25', ab: '2026-11-20' });
  assert.equal(nach.status, 400); assert.equal(nach.json.feld, 'planAb');
  const vorbei = await einladen(env, u, b.tok, { planAb: '2026-11-01', ab: '2026-11-20' });
  assert.equal(vorbei.status, 400); assert.equal(vorbei.json.feld, 'planAb');
  const kaputt = await einladen(env, u, b.tok, { planAb: '31.12.2026', ab: '2026-11-20' });
  assert.equal(kaputt.status, 400); assert.equal(kaputt.json.feld, 'planAb');
  const zuFrueh = await einladen(env, u, b.tok, { planAb: '2026-11-11', ab: '2027-12-20', bis: '2028-01-31' });
  assert.equal(zuFrueh.status, 400); assert.match(zuFrueh.json.error, /Monate/);
  const gleich = await einladen(env, u, b.tok, { planAb: '2026-11-20', ab: '2026-11-20' });
  assert.equal(gleich.status, 200, JSON.stringify(gleich.json)); assert.equal(gleich.json.planAb, null);
  const ok = await einladen(env, u, b.tok, Object.assign({ email: 'zweite@example.org' }, PLAN));
  assert.equal(ok.status, 200, JSON.stringify(ok.json)); assert.equal(ok.json.planAb, '2026-11-11');
  const liste = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, b.tok)).json;
  assert.equal(liste.verleih.planung, true);
  const z = liste.gegeben.find((x) => x.email === 'zweite@example.org');
  assert.equal(z.planAb, '2026-11-11'); assert.equal(z.status, 'eingeladen');
  assert.equal(liste.gegeben.find((x) => x.email === 'gast@example.org').planAb, null);
});

test('Zwei Zeiträume: In der Planung sieht der Gast das Fahrzeug, trägt aber nichts ein; im Verleih gelten seine Rechte', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b, Object.assign({}, PLAN, MIT));
  const liste = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, g.gast)).json;
  assert.equal(liste.erhalten[0].status, 'planung'); assert.equal(liste.erhalten[0].planAb, '2026-11-11'); assert.equal(liste.erhalten[0].ab, '2026-11-20');
  const f = await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast);
  assert.equal(f.status, 200, JSON.stringify(f.json));
  assert.equal(f.json.phase, 'planung'); assert.equal(f.json.nutzungAb, '2026-11-20'); assert.equal(f.json.planAb, '2026-11-11'); assert.equal(f.json.rechte, 'mitnutzen');
  assert.ok(f.json.datensaetze.some((x) => x.tabelle === 'fahrzeuge'));
  assert.equal(f.json.eigene, undefined, 'in der Planung gibt es keine Einträge im Fahrzeug');
  /* Eintragen und Kontroll-Code gehen erst im Verleih */
  const e = await ruf(env, u, 'POST', '/geteilt/erfassen', { freigabe: g.id, art: 'kilometer', zaehlerId: 'za-1', wert: 51800, datum: '2026-11-11' }, g.gast);
  assert.equal(e.status, 403); assert.match(e.json.error, /ab 2026-11-20/); assert.match(e.json.error, /planen/);
  assert.equal((await ruf(env, u, 'POST', '/geteilt/kontrolle', { freigabe: g.id }, g.gast)).status, 403);
  const raum = env.DB.roh.prepare("SELECT COUNT(*) AS n FROM abgleich WHERE tabelle = 'zaehlerstaende'").get().n;
  assert.equal(raum, 1, 'im Fahrzeug des Besitzers ist nichts dazugekommen');
  /* Beginn des Verleihs */
  u.t = Date.UTC(2026, 10, 20, 8, 0, 0);
  const l2 = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, g.gast)).json;
  assert.equal(l2.erhalten[0].status, 'aktiv');
  const f2 = await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast);
  assert.equal(f2.json.phase, 'nutzung'); assert.deepEqual(f2.json.eigene, []);
  const ok = await ruf(env, u, 'POST', '/geteilt/erfassen', { freigabe: g.id, art: 'kilometer', zaehlerId: 'za-1', wert: 51800, datum: '2026-11-20' }, g.gast);
  assert.equal(ok.status, 200, JSON.stringify(ok.json));
  assert.equal((await ruf(env, u, 'POST', '/geteilt/kontrolle', { freigabe: g.id }, g.gast)).status, 200);
});

test('Vor dem Planungsbeginn gilt die Freigabe noch nicht; ohne „Planung ab“ bleibt alles wie bisher', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b, { planAb: '2026-11-15', ab: '2026-11-20' });
  assert.equal((await ruf(env, u, 'GET', '/freigabe/liste', undefined, g.gast)).json.erhalten[0].status, 'wartet');
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast)).status, 403);
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE, freigabe: g.id }, g.gast, { fetch: recherche().fetch })).status, 403);
  u.t = Date.UTC(2026, 10, 15, 8, 0, 0);
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast)).json.phase, 'planung');
  /* Freigabe ohne Planung: vor dem Verleih gesperrt wie bisher */
  const env2 = umgebung(), u2 = uhr(), b2 = await besitzer(env2, u2), g2 = await freigabe(env2, u2, b2, { ab: '2026-11-20' });
  assert.equal((await ruf(env2, u2, 'GET', '/geteilt/fahrzeug?freigabe=' + g2.id, undefined, g2.gast)).status, 403);
});

test('Widerruf und fremdes Konto: Weder Planung noch Check gehen danach', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b, PLAN), rc = recherche();
  const fremd = await konto(env, u, 'fremd@example.org');
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE, freigabe: g.id }, fremd, { fetch: rc.fetch })).status, 403);
  assert.equal((await ruf(env, u, 'POST', '/freigabe/widerrufen', { id: g.id }, b.tok)).status, 200);
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast)).status, 403);
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE, freigabe: g.id }, g.gast, { fetch: rc.fetch })).status, 403);
  assert.equal(rc.aufrufe.length, 0);
});

test('Reisecheck des Gastes: zählt zum Kontingent des Besitzers, der Gast sieht keine Zahlen, ein gespeicherter Check zählt nie', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b, PLAN), rc = recherche();
  const dr = env.DB.roh.prepare('SELECT d.id AS id FROM datenraum d JOIN nutzer n ON n.id = d.nutzer_id WHERE n.email = ?').get('besitzer@example.org').id;
  const drGast = env.DB.roh.prepare('SELECT d.id AS id FROM datenraum d JOIN nutzer n ON n.id = d.nutzer_id WHERE n.email = ?').get('gast@example.org');
  const c = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE, freigabe: g.id }, g.gast, { fetch: rc.fetch });
  assert.equal(c.status, 200, JSON.stringify(c.json));
  assert.equal(c.json.kontingent, null, 'der Gast sieht die Zahlen des Besitzers nie');
  assert.equal(rc.aufrufe.length, 1);
  const zeilen = env.DB.roh.prepare('SELECT datenraum_id, status FROM check_nutzung').all();
  assert.equal(zeilen.length, 1); assert.equal(zeilen[0].datenraum_id, dr, 'gezählt beim Besitzer'); assert.equal(zeilen[0].status, 'ok');
  if (drGast) assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM check_nutzung WHERE datenraum_id = ?').get(drGast.id).n, 0);
  /* Der Besitzer hat in der Testwoche einen Check: Der nächste frische Check wird abgelehnt, ohne Zahlen */
  const voll = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: { trip: { areas: [{ name: 'Norwegen' }] } }, freigabe: g.id }, g.gast, { fetch: rc.fetch });
  assert.equal(voll.status, 402); assert.match(voll.json.error, /Besitzers/); assert.ok(!/\d+ von \d+/.test(voll.json.error), 'keine Zahlen des Besitzers');
  assert.equal(rc.aufrufe.length, 1);
  /* Gespeichert: zählt nicht, auch nicht bei aufgebrauchtem Kontingent */
  const g2 = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE, quelle: 'gespeichert', freigabe: g.id }, g.gast, { fetch: rc.fetch });
  assert.equal(g2.status, 200); assert.equal(g2.json.gespeichert, true);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM check_nutzung').get().n, 1);
});

test('Reisecheck des Gastes: schlägt die Recherche fehl, wird nichts gezählt; hat der Besitzer keine Online-Stufe, sagt der Dienst es ohne Namen der Stufe', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b, PLAN);
  const kaputt = async () => new Response(JSON.stringify({ error: 'KI nicht erreichbar' }), { status: 500 });
  const f = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE, freigabe: g.id }, g.gast, { fetch: kaputt });
  assert.equal(f.status, 502);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM check_nutzung').get().n, 0, 'ein Fehlversuch zählt nicht');
  env.DB.roh.prepare('DELETE FROM testwoche').run();
  const ohne = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE, freigabe: g.id }, g.gast, { fetch: recherche().fetch });
  assert.equal(ohne.status, 402); assert.match(ohne.json.error, /Besitzers/); assert.ok(!/Basic/.test(ohne.json.error));
  /* Der Besitzer selbst prüft weiter ohne „freigabe“ wie bisher */
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, b.tok, { fetch: recherche().fetch })).status, 402);
});

test('Ohne die SQL-Zeile 13f-4 geht alles wie bisher; wer „Planung ab“ angibt, bekommt den Hinweis in einfachen Worten', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  env.DB.roh.exec('ALTER TABLE freigabe DROP COLUMN plan_ab');
  const mit = await einladen(env, u, b.tok, PLAN);
  assert.equal(mit.status, 503); assert.match(mit.json.error, /13f-4/);
  const g = await freigabe(env, u, b, { email: 'gast@example.org', ab: '2026-11-11' });
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast)).json.phase, 'nutzung');
  const liste = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, b.tok)).json;
  assert.equal(liste.verleih.planung, false); assert.equal(liste.gegeben[0].planAb, null);
  assert.equal((await ruf(env, u, 'GET', '/gesundheit')).json.planung, false);
});

test('Dienst 13f-4: Version, eine SQL-Zeile auch im Schema, Gesundheit, Anleitung', async () => {
  const d = await laden();
  assert.equal(d.VERSION, '13f-9');
  const env = umgebung(), u = uhr();
  const g = (await ruf(env, u, 'GET', '/gesundheit')).json;
  assert.equal(g.version, '13f-9'); assert.equal(g.planung, true); assert.equal(g.stoerungsmail, true);
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13f-4.sql'), 'utf8').trim().split('\n');
  assert.equal(sql.length, 1); assert.equal(sql[0], 'ALTER TABLE freigabe ADD COLUMN plan_ab INTEGER;');
  assert.ok(fs.readFileSync(path.join(__dirname, '..', 'server', 'schema.sql'), 'utf8').includes(sql[0]));
  const anleitung = fs.readFileSync(path.join(__dirname, '..', 'server', 'EINRICHTUNG.md'), 'utf8');
  assert.ok(anleitung.includes('Update auf 13f-4')); assert.ok(anleitung.includes('13f-4.sql'));
});
