'use strict';
/* 2.0.86: Leihe vereinfacht. Kein eigener Plan, Check und Tagebuch der Leihreise mehr; das alte Dokument „leihreisen“ wird beim Start gelöscht. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'logbuch', 'status', 'reiseorte', 'freigaben', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

test('Das alte Dokument „leihreisen“ wird beim Start gelöscht, andere Einstellungen bleiben', async () => {
  const sp = new MM.Speicher.MemorySpeicher();
  await sp.speichern('einstellungen', { id: 'leihreisen', reisen: { 'fr-1': { tagebuch: [{ id: 'x', text: 'alt' }] } } });
  await sp.speichern('einstellungen', { id: 'andere', wert: 1 });
  const d = new MM.Daten.Daten(sp, {});
  await d.starten();
  assert.ok(!(await sp.holen('einstellungen', 'leihreisen')));
  assert.equal((await sp.holen('einstellungen', 'andere')).wert, 1);
  await d.starten();
});

test('Keine Spur der Leihreise mehr in Code, Seiten und Dienst-Wegen', () => {
  const a = lesen('js/ansicht.js'), d = lesen('js/daten.js'), i = lesen('index.html'), s = lesen('sw.js');
  assert.ok(!fs.existsSync(path.join(__dirname, '..', 'js/leihreise.js')));
  assert.ok(!/leihreise|Leihreise|#\/leihreise/.test(a + i + s));
  assert.ok(!/Daten\.prototype\.leihreise/.test(d));
  assert.equal(MM.Leihreise, undefined);
});

test('Texte der Planung vor dem Verleih nennen keinen Plan, Check oder Tagebuch mehr', () => {
  assert.match(MM.Freigaben.phaseText('planung', '2026-11-20', null), /Der Verleih beginnt am 20\.11\.2026/);
  assert.match(MM.Freigaben.phaseText('nutzung', '2026-11-20', '2026-11-15'), /Seit 20\.11\.2026 gelten deine Rechte \(die Planung lief ab 15\.11\.2026\)/);
  const alle = MM.Freigaben.phaseText('planung', '2026-11-20', null) + MM.Freigaben.TEXT_PLANUNG_FREIGABE;
  assert.ok(!/Tagebuch|Reisecheck|Reisechecks|planen/.test(alle));
});
