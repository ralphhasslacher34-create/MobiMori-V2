/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.35';
  MM.STUFE = 'Wetter und Karte als Ereignisse';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
