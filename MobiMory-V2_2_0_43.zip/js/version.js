/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.43';
  MM.STUFE = 'Etappen: Mehrtagesreisen mit Start, Ziel, Wetter und Kosten je Tag';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
