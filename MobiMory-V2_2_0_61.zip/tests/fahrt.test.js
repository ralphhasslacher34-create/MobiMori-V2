'use strict';
/* Geschwindigkeit aus dem GPS (2.0.44): Regeln ohne Speicher und Netz. */
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/fahrzeugarten.js');
require('../js/logbuch.js');
require('../js/fahrt.js');
const F = globalThis.MM.Fahrt;

const T0 = new Date(2026, 10, 5, 8, 0, 0).getTime();
const BREITE0 = 48.0, LAENGE = 8.0, M_PRO_GRAD = 111195;
/* Ein Punkt, der sich mit v Metern pro Sekunde nach Norden bewegt (Zeit t in Sekunden ab T0). */
const fix = (t, strecke, extra) => Object.assign({ breite: BREITE0 + strecke / M_PRO_GRAD, laenge: LAENGE, genauigkeit: 5, zeitMs: T0 + t * 1000, geschwindigkeit: null }, extra || {});
/* Fahren: 10 Minuten mit 10 m/s (36 km/h), alle 5 Sekunden ein Punkt */
function fahren(f, von, dauer, v, welt, zaehlen, mitGeraet) {
  let s = (von.strecke || 0);
  for (let t = von.t; t <= von.t + dauer; t += 5) {
    s = (von.strecke || 0) + v * (t - von.t);
    f = F.punkt(f, fix(t, s, mitGeraet ? { geschwindigkeit: v } : {}), welt || 'land', zaehlen !== false);
  }
  return { f, t: von.t + dauer, strecke: s };
}

test('Neuer Zustand: noch nichts gestartet, alle Werte offen', () => {
  const w = F.werte(F.neu(), T0);
  assert.equal(w.gestartet, false); assert.equal(w.fahrendKmh, null); assert.equal(w.tagKmh, null); assert.equal(w.aktuellKmh, null);
});

test('Ø fahrend und Ø Tag: Stehen zählt nur beim Tag', () => {
  let r = fahren(F.neu(), { t: 0 }, 600, 10);
  let w = F.werte(r.f, T0 + 600 * 1000);
  assert.ok(Math.abs(w.fahrendKmh - 36) < 1.5, 'fahrend ' + w.fahrendKmh);
  assert.ok(Math.abs(w.tagKmh - 36) < 1.5);
  assert.ok(Math.abs(w.km - 6) < 0.15);
  /* 10 Minuten stehen (kleine GPS-Schwankung): der Weg bleibt gleich, der Tag wird länger */
  let f = r.f;
  for (let t = 605; t <= 1200; t += 5) f = F.punkt(f, fix(t, r.strecke + (t % 2 ? 2 : -2)), 'land', true);
  w = F.werte(f, T0 + 1200 * 1000);
  assert.ok(Math.abs(w.km - 6) < 0.15, 'Stehen zählt keine Strecke: ' + w.km);
  assert.ok(Math.abs(w.fahrendKmh - 36) < 1.5);
  assert.ok(Math.abs(w.tagKmh - 18) < 1, 'Tag ' + w.tagKmh);
  assert.ok(w.tagDatum === '2026-11-05');
});

test('Der Tag beginnt mit der ersten Bewegung, nicht mit dem ersten GPS-Punkt', () => {
  let f = F.neu();
  for (let t = 0; t <= 300; t += 5) f = F.punkt(f, fix(t, 0), 'land', true);   /* steht 5 Minuten */
  assert.equal(F.werte(f, T0 + 300000).gestartet, false);
  const r = fahren(f, { t: 305, strecke: 0 }, 300, 10);
  const w = F.werte(r.f, T0 + 605 * 1000);
  assert.ok(w.gestartet);
  assert.ok(Math.abs(w.gesamtMs - 305 * 1000) < 15000, 'Gesamtzeit ' + w.gesamtMs);
});

test('Standzeit vor dem Losfahren zählt nicht als Fahrzeit', () => {
  let f = F.neu();
  for (let t = 0; t <= 480; t += 5) f = F.punkt(f, fix(t, (t % 2 ? 3 : -3)), 'land', true);   /* 8 Minuten Stehen mit GPS-Schwankung */
  const r = fahren(f, { t: 485, strecke: 0 }, 300, 10);
  const w = F.werte(r.f, T0 + 785 * 1000);
  assert.ok(w.fahrMs < 305 * 1000 && w.fahrMs > 270 * 1000, 'Fahrzeit ' + w.fahrMs);
  assert.ok(Math.abs(w.fahrendKmh - 36) < 3, 'fahrend ' + w.fahrendKmh);
  assert.ok(w.gesamtMs < 310 * 1000, 'Der Tag beginnt mit der Bewegung: ' + w.gesamtMs);
});

test('Ist das Fahrzeug nicht in Fahrt, wird nichts gezählt und der Tag beginnt nicht', () => {
  const r = fahren(F.neu(), { t: 0 }, 300, 10, 'land', false);
  const w = F.werte(r.f, T0 + 300000);
  assert.equal(w.gestartet, false); assert.equal(w.km, 0);
});

test('Aktuell: bevorzugt vom Gerät, sonst aus zwei Punkten, nach 20 Sekunden ohne Punkt offen', () => {
  let f = F.punkt(F.neu(), fix(0, 0, { geschwindigkeit: 5 }), 'land', true);
  assert.ok(Math.abs(F.werte(f, T0 + 1000).aktuellKmh - 18) < 0.01);
  assert.equal(F.werte(f, T0 + 25000).aktuellKmh, null);
  /* Stillstand vom Gerät (0,2 m/s) zählt als 0 */
  f = F.punkt(f, fix(5, 0, { geschwindigkeit: 0.2 }), 'land', true);
  assert.equal(F.werte(f, T0 + 6000).aktuellKmh, 0);
  /* ohne Wert vom Gerät: gerechnet über mindestens 10 Sekunden */
  let g = F.neu();
  for (let t = 0; t <= 30; t += 5) g = F.punkt(g, fix(t, 10 * t), 'land', true);
  assert.ok(Math.abs(F.werte(g, T0 + 31000).aktuellKmh - 36) < 3, String(F.werte(g, T0 + 31000).aktuellKmh));
});

test('Schlechte Punkte, Lücken und Sprünge zählen nicht', () => {
  let f = F.punkt(F.neu(), fix(0, 0), 'land', true);
  f = F.punkt(f, fix(5, 50, { genauigkeit: 80 }), 'land', true);
  assert.equal(f.km, 0); assert.equal(f.verworfen, 1);
  /* Sprung: 5 km in 5 Sekunden */
  f = F.punkt(f, fix(10, 5000), 'land', true);
  assert.equal(f.km, 0); assert.ok(f.verworfen >= 2);
  /* Lücke über 10 Minuten: nichts wird geschätzt */
  f = F.punkt(F.punkt(F.neu(), fix(0, 0), 'land', true), fix(1200, 8000), 'land', true);
  assert.equal(f.km, 0); assert.equal(f.luecken, 1);
  /* ungültige Eingaben */
  assert.equal(F.punkt(F.neu(), null, 'land', true).km, 0);
  assert.equal(F.punkt(F.neu(), { breite: 'x', laenge: 1, zeitMs: 1 }, 'land', true).km, 0);
});

test('Der alte Zustand bleibt unverändert', () => {
  const f0 = F.punkt(F.neu(), fix(0, 0), 'land', true);
  const kopie = JSON.stringify(f0);
  F.punkt(f0, fix(5, 100), 'land', true);
  assert.equal(JSON.stringify(f0), kopie);
});

test('Tagesabschluss: die Werte bleiben stehen, die nächste Bewegung beginnt neu', () => {
  const r = fahren(F.neu(), { t: 0 }, 600, 10);
  const zu = F.abschliessen(r.f, T0 + 600 * 1000);
  assert.equal(zu.abgeschlossen, true);
  const spaeter = F.werte(zu, T0 + 5 * 3600 * 1000);
  const gleich = F.werte(zu, T0 + 600 * 1000);
  assert.equal(spaeter.tagKmh, gleich.tagKmh); assert.equal(spaeter.gesamtMs, gleich.gesamtMs);
  assert.equal(F.abschliessen(zu, T0 + 99999999).schlussMs, zu.schlussMs, 'ein zweiter Abschluss ändert nichts');
  assert.equal(F.abschliessen(F.neu(), T0).abgeschlossen, false, 'ohne Bewegung gibt es nichts abzuschließen');
  /* am nächsten Tag */
  const T1 = 24 * 3600;
  let f = zu;
  for (let t = T1; t <= T1 + 300; t += 5) f = F.punkt(f, fix(t, 20000 + 10 * (t - T1)), 'land', true);
  const w = F.werte(f, T0 + (T1 + 300) * 1000);
  assert.equal(f.abgeschlossen, false);
  assert.ok(w.km < 3.5 && w.km > 2.5, 'neue Zählung: ' + w.km);
  assert.equal(w.tagDatum, '2026-11-06');
});

test('Anzeige: Reihenfolge der Tipps, Einheit, Beschriftung, kein Wert heißt Strich', () => {
  /* seit 2.0.61 sechs Stufen: Aktuell, Ø fahrend, Ø Tag, ETA, Rest, Gefahren */
  assert.deepEqual([F.naechsterModus('aktuell'), F.naechsterModus('fahrend'), F.naechsterModus('tag'), F.naechsterModus('eta'), F.naechsterModus('rest'), F.naechsterModus('gefahren'), F.naechsterModus('unsinn')],
    ['fahrend', 'tag', 'eta', 'rest', 'gefahren', 'aktuell', 'aktuell']);
  const w = { aktuellKmh: 18.52, fahrendKmh: 9.26, tagKmh: null };
  assert.deepEqual(F.anzeige(w, 'wasser', 'aktuell'), { name: 'Aktuell', wert: '10,0 kn' });
  assert.deepEqual(F.anzeige(w, 'land', 'aktuell'), { name: 'Aktuell', wert: '18,5 km/h' });
  assert.deepEqual(F.anzeige(w, 'land', 'fahrend'), { name: 'Ø fahrend', wert: '9,3 km/h' });
  assert.deepEqual(F.anzeige(w, 'land', 'tag'), { name: 'Ø Tag', wert: '–' });
  assert.equal(F.einheit('luft'), 'kn'); assert.equal(F.einheit('land'), 'km/h');
});

test('Eintragstext: Tagesabschluss und Zwischenwert', () => {
  const w = { aktuellKmh: 20, fahrendKmh: 9.26, tagKmh: 5.556, km: 55.6, fahrMs: 6 * 3600000, gesamtMs: 10 * 3600000 };
  const tag = F.eintragText(w, 'wasser', 'tag');
  assert.match(tag, /^Geschwindigkeit \(Tagesabschluss\): Ø fahrend 5,0 kn, Ø Tag 3,0 kn, Strecke 30,0 sm, Fahrzeit 6 h 00 min, Gesamtzeit 10 h 00 min\./);
  const zw = F.eintragText(w, 'land', 'rhythmus');
  assert.match(zw, /^Geschwindigkeit \(automatisch\): aktuell 20,0 km\/h, Ø fahrend 9,3 km\/h, Ø Tag 5,6 km\/h, Strecke 55,6 km/);
  assert.match(F.eintragText({ aktuellKmh: null, fahrendKmh: null, tagKmh: null, km: 0, fahrMs: 0, gesamtMs: 0 }, 'land', 'rhythmus'), /aktuell noch offen/);
});

test('Rhythmus: wann ein Zwischenwert fällig ist', () => {
  const jetzt = T0 + 3 * 3600000;
  assert.equal(F.faellig(0, null, null, jetzt), false, 'Rhythmus aus');
  assert.equal(F.faellig(60, null, null, jetzt), true, 'noch kein Eintrag');
  assert.equal(F.faellig(60, jetzt - 30 * 60000, null, jetzt), false);
  assert.equal(F.faellig(60, jetzt - 61 * 60000, null, jetzt), true);
  assert.equal(F.faellig(60, jetzt - 61 * 60000, jetzt - 10000, jetzt), false, 'gerade erst versucht');
  const e = [{ artName: 'Wetter', datum: '2026-11-05', zeit: '10:00' }, { artName: 'Geschwindigkeit', datum: '2026-11-05', zeit: '09:30' }, { artName: 'geschwindigkeit', datum: '2026-11-05', zeit: '09:45' }];
  assert.equal(F.letzterEintragMs(e), new Date(2026, 10, 5, 9, 45).getTime());
  assert.equal(F.letzterEintragMs([{ artName: 'Wetter', datum: '2026-11-05', zeit: '10:00' }]), null);
});

test('Die Ereignisart „Geschwindigkeit“ liegt auf keinem Knopf', () => {
  const L = globalThis.MM.Logbuch;
  const arten = ['Abfahrt', 'Geschwindigkeit', 'Wetter'].map((n, i) => ({ objekt: { id: 'ea' + i }, aktuell: { werte: { bezeichnung: n, ausgeblendet: 'nein', zuordnung: L.zuordnungFuerKnoten(['alle']) } } }));
  const a = L.schnellAngebot(arten, null);
  assert.deepEqual(a.ereignisse.map(x => x.name), ['Abfahrt', 'Wetter']);
  assert.equal(L.istGeschwindigkeitsArt(' GESCHWINDIGKEIT '), true);
});
