/*
 * Wachen (seit 2.0.120): Ankerwache (Wasserfahrzeug, Status „vor Anker“) und Standortwache / Alarmanlage (alle Fahrzeuge, Status „Stillstand“ oder „festgemacht“).
 * Reine Rechnung ohne Speicher und ohne Oberfläche. Die Wache braucht kein Internet: Sie vergleicht nur die GPS-Position mit dem Mittelpunkt.
 *
 * Das Dokument „wache-<aktivitätId>“ (Tabelle einstellungen) enthält:
 *   art: 'anker' | 'standort', an: true/false, wachepos: { breite, laenge } (privat, nur verschlüsselt im Abgleich),
 *   radius: Meter, seit: ms, ton: true/false, ueberwachen: true/false (Warnung, wenn der Wächter sich nicht mehr meldet),
 *   zaehler: aufeinanderfolgende Punkte außerhalb, alarm: null | { zeitMs, abstand, breite, laenge }, letzterPunktMs
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var RADIEN = { anker: [30, 50, 80, 120], standort: [20, 50, 100, 250] };
  var MIN_RADIUS = 10, MAX_RADIUS = 1000;
  /* So viele Punkte nacheinander müssen außerhalb liegen, bevor Alarm kommt (ein einzelner GPS-Ausreißer löst nichts aus). */
  var PUNKTE_FUER_ALARM = 3;
  /* Ein Punkt zählt nur dann als „außerhalb“, wenn er auch nach Abzug seiner Ungenauigkeit außerhalb liegt. Schlechter als dieser Wert: ignoriert. */
  var MAX_UNGENAU_M = 100;
  var AUSFALL_MS = 15 * 60 * 1000;

  function id(aktId) { return 'wache-' + aktId; }

  function meter(b1, l1, b2, l2) {
    var R = 6371000, r = Math.PI / 180;
    var dB = (b2 - b1) * r, dL = (l2 - l1) * r;
    var a = Math.sin(dB / 2) * Math.sin(dB / 2) + Math.cos(b1 * r) * Math.cos(b2 * r) * Math.sin(dL / 2) * Math.sin(dL / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
  }

  /* Richtung vom Mittelpunkt zur Position, in Grad (0 = Nord). */
  function richtungGrad(b1, l1, b2, l2) {
    var r = Math.PI / 180, dL = (l2 - l1) * r;
    var y = Math.sin(dL) * Math.cos(b2 * r), x = Math.cos(b1 * r) * Math.sin(b2 * r) - Math.sin(b1 * r) * Math.cos(b2 * r) * Math.cos(dL);
    return (Math.atan2(y, x) / r + 360) % 360;
  }
  var HIMMEL = ['N', 'NO', 'O', 'SO', 'S', 'SW', 'W', 'NW'];
  function himmelsrichtung(grad) { return HIMMEL[Math.round(grad / 45) % 8]; }

  function radiusOk(r) { return typeof r === 'number' && isFinite(r) && r >= MIN_RADIUS && r <= MAX_RADIUS; }

  /* Faustregel für den Ankerradius: Kette = 5 × Tiefe, dazu die Bootslänge. Nur ein Vorschlag; die Tiefe tippt der Nutzer selbst ein. */
  function radiusVorschlag(tiefeM, laengeM) {
    if (!(tiefeM > 0)) return null;
    var r = Math.round(5 * tiefeM + (laengeM > 0 ? laengeM : 0));
    return Math.max(MIN_RADIUS, Math.min(MAX_RADIUS, r));
  }

  function artFuer(welt, statusId) {
    if (welt === 'wasser' && statusId === 'vor-anker') return 'anker';
    if (statusId === 'stillstand' || statusId === 'festgemacht') return 'standort';
    return null;
  }

  function neu(art, fix, radius, optionen) {
    var o = optionen || {};
    if (art !== 'anker' && art !== 'standort') throw new Error('Unbekannte Art der Wache.');
    if (!fix || typeof fix.breite !== 'number' || typeof fix.laenge !== 'number') throw new Error('Ohne Position kann die Wache nicht starten.');
    if (!radiusOk(radius)) throw new Error('Der Radius muss zwischen ' + MIN_RADIUS + ' und ' + MAX_RADIUS + ' Metern liegen.');
    return {
      art: art, an: true, wachepos: { breite: fix.breite, laenge: fix.laenge }, radius: Math.round(radius),
      seit: typeof o.zeitMs === 'number' ? o.zeitMs : Date.now(), ton: o.ton !== false, ueberwachen: !!o.ueberwachen,
      zaehler: 0, alarm: null, letzterPunktMs: typeof o.zeitMs === 'number' ? o.zeitMs : Date.now()
    };
  }

  /* Wirkt ein neuer GPS-Punkt auf die Wache? Liefert eine neue Wache (das Original bleibt unverändert) und ein Ergebnis:
   * { abstand, richtung (Grad Mittelpunkt → Position), ausserhalb, neuerAlarm } */
  function punkt(w, fix) {
    if (!w || !w.an || !w.wachepos || !fix) return { wache: w, abstand: null, ausserhalb: false, neuerAlarm: false };
    var n = JSON.parse(JSON.stringify(w));
    n.letzterPunktMs = typeof fix.zeitMs === 'number' ? fix.zeitMs : Date.now();
    var abstand = meter(w.wachepos.breite, w.wachepos.laenge, fix.breite, fix.laenge);
    var ungenau = typeof fix.genauigkeit === 'number' && isFinite(fix.genauigkeit) ? fix.genauigkeit : 0;
    var res = { wache: n, abstand: abstand, richtung: richtungGrad(w.wachepos.breite, w.wachepos.laenge, fix.breite, fix.laenge), ausserhalb: false, neuerAlarm: false };
    if (ungenau > MAX_UNGENAU_M) return res; /* zu ungenau, weder Alarm noch Entwarnung */
    var aus = abstand - ungenau > w.radius;
    res.ausserhalb = aus;
    if (!aus) { n.zaehler = 0; return res; }
    n.zaehler = (w.zaehler || 0) + 1;
    if (n.zaehler >= PUNKTE_FUER_ALARM && !w.alarm) {
      n.alarm = { zeitMs: n.letzterPunktMs, abstand: Math.round(abstand), breite: fix.breite, laenge: fix.laenge };
      res.neuerAlarm = true;
    } else if (w.alarm) {
      /* Alarm läuft schon: Abstand mitführen, damit die Anzeige stimmt. */
      n.alarm = { zeitMs: w.alarm.zeitMs, abstand: Math.round(abstand), breite: fix.breite, laenge: fix.laenge };
    }
    return res;
  }

  /* Alarm zur Kenntnis genommen (Ton aus), die Wache bleibt an. */
  function quittieren(w) {
    if (!w || !w.alarm) return w;
    var n = JSON.parse(JSON.stringify(w)); n.alarm.quittiert = true; return n;
  }
  function ausschalten(w) {
    if (!w) return w;
    var n = JSON.parse(JSON.stringify(w)); n.an = false; n.alarm = null; n.zaehler = 0; return n;
  }

  /* Hat sich der Wächter länger nicht gemeldet? Nur eine Warnung (kein Alarm), und nur wenn der Nutzer das eingeschaltet hat. */
  function wachterAusgefallen(w, jetztMs) {
    if (!w || !w.an || !w.ueberwachen) return false;
    return (jetztMs - (w.letzterPunktMs || w.seit || 0)) > AUSFALL_MS;
  }

  function abstandText(m) {
    if (m === null || m === undefined) return '–';
    return m >= 1000 ? (Math.round(m / 100) / 10).toString().replace('.', ',') + ' km' : Math.round(m) + ' m';
  }

  MM.Wache = {
    id: id, meter: meter, richtungGrad: richtungGrad, himmelsrichtung: himmelsrichtung, radiusOk: radiusOk, radiusVorschlag: radiusVorschlag,
    artFuer: artFuer, neu: neu, punkt: punkt, quittieren: quittieren, ausschalten: ausschalten, wachterAusgefallen: wachterAusgefallen, abstandText: abstandText,
    RADIEN: RADIEN, MIN_RADIUS: MIN_RADIUS, MAX_RADIUS: MAX_RADIUS, PUNKTE_FUER_ALARM: PUNKTE_FUER_ALARM, MAX_UNGENAU_M: MAX_UNGENAU_M, AUSFALL_MS: AUSFALL_MS
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
