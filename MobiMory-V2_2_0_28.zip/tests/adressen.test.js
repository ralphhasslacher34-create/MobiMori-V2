'use strict';
/* 2.0.25, Schritt 7b: Werkstatt – Adressen (Werkstätten, Lieferanten, Händler) und der Verweis vom Vorgang. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/reiseorte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const W = MM.Werkstatt;

/* feste Uhr: 3. November 2026, 12:00 Ortszeit */
const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  return { d, boot, wm };
}
const mueller = { bezeichnung: 'Autohaus Müller', art: 'werkstatt', telefon: '07042 12345', email: 'info@mueller.example', strasse: 'Hauptstraße 1', plz: '74372', ort: 'Sersheim' };

/* ---------- Beschreibung ---------- */
test('Arten und Felder einer Adresse: Werkstatt, Lieferant, Händler; alles außer Name und Art freiwillig', () => {
  assert.deepEqual(W.ADRESSARTEN.map(a => a.wert), ['werkstatt', 'lieferant', 'haendler']);
  assert.deepEqual(W.adressFelder().map(f => f.key), ['art', 'ansprechpartner', 'telefon', 'email', 'strasse', 'plz', 'ort', 'land', 'webseite', 'notiz']);
  assert.ok(W.felderAlle().some(f => f.key === 'adresseId'), 'der Verweis steht im Verlauf des Vorgangs');
  assert.deepEqual(W.felder('arbeit').map(f => f.key), ['beschreibung', 'auswirkung', 'gemeldetAm', 'ausfuehrung', 'arbeit'], 'die Felder der Arbeit bleiben, der Verweis wird gesondert geprüft');
});

/* ---------- Anlegen, ändern, Liste ---------- */
test('Adresse anlegen: Name und Art sind Pflicht, Telefon und E-Mail werden geprüft', async () => {
  const { d } = await neu();
  const f = async roh => (await d.adresseAnlegen(roh)).fehler || {};
  assert.ok((await f({ bezeichnung: ' ', art: 'werkstatt' })).bezeichnung);
  assert.ok((await f({ bezeichnung: 'X' })).art, 'ohne Art geht es nicht');
  assert.ok((await f({ bezeichnung: 'X', art: 'kneipe' })).art);
  assert.ok((await f({ bezeichnung: 'X', art: 'werkstatt', email: 'keine-adresse' })).email);
  assert.ok((await f({ bezeichnung: 'X', art: 'werkstatt', telefon: 'abc' })).telefon);
  assert.equal((await d.adressenListe()).length, 0, 'bei Fehlern wird nichts gespeichert');
  const r = await d.adresseAnlegen({ bezeichnung: 'Nur Name', art: 'haendler' });
  assert.ok(r.ok, 'alles andere ist freiwillig');
});

test('Gleicher Name mit gleicher Art wird abgelehnt, mit anderer Art ist er erlaubt', async () => {
  const { d } = await neu();
  assert.ok((await d.adresseAnlegen(mueller)).ok);
  assert.ok((await d.adresseAnlegen(Object.assign({}, mueller, { bezeichnung: 'autohaus müller' }))).fehler.bezeichnung);
  assert.ok((await d.adresseAnlegen(Object.assign({}, mueller, { art: 'haendler' }))).ok);
  assert.equal((await d.adressenListe()).length, 2);
});

test('Adresse ändern: neuer Stand im Verlauf, ohne Änderung nichts, Ausblenden bleibt sichtbar in der Liste', async () => {
  const { d } = await neu();
  const id = (await d.adresseAnlegen(mueller)).id;
  const a = await d.adresseLaden(id);
  assert.equal(a.aktuell.werte.art, 'werkstatt');
  assert.equal(a.aktuell.werte.ausgeblendet, 'nein');
  assert.equal((await d.adresseAendern(id, mueller)).geaendert, false);
  const r = await d.adresseAendern(id, Object.assign({}, mueller, { telefon: '07042 99999', ausgeblendet: 'ja' }));
  assert.ok(r.ok && r.geaendert);
  const b = await d.adresseLaden(id);
  assert.equal(b.verlauf.length, 2);
  assert.ok(b.verlauf[0].aenderungen.some(u => u.key === 'telefon' && u.alt === '07042 12345' && u.neu === '07042 99999'));
  assert.equal((await d.adressenListe())[0].aktuell.werte.ausgeblendet, 'ja', 'ausgeblendet, aber nicht gelöscht');
  assert.ok((await d.adresseAendern(id, { bezeichnung: '', art: 'werkstatt' })).fehler.bezeichnung);
  assert.ok((await d.adresseAendern('gibt-es-nicht', mueller)).fehler.allgemein);
  assert.equal(await d.adresseLaden('gibt-es-nicht'), null);
});

test('Liste: nach Namen sortiert', async () => {
  const { d } = await neu();
  await d.adresseAnlegen({ bezeichnung: 'Zeta', art: 'lieferant' });
  await d.adresseAnlegen({ bezeichnung: 'Alpha', art: 'haendler' });
  await d.adresseAnlegen({ bezeichnung: 'Mitte', art: 'werkstatt' });
  assert.deepEqual((await d.adressenListe()).map(x => x.aktuell.werte.bezeichnung), ['Alpha', 'Mitte', 'Zeta']);
});

/* ---------- Verweis vom Vorgang ---------- */
test('Arbeit mit Werkstatt: der Vorgang verweist auf die Adresse, sie ist mit dem Namen im Vorgang zu sehen', async () => {
  const { d, wm } = await neu();
  const adr = (await d.adresseAnlegen(mueller)).id;
  const r = await d.vorgangAnlegen(wm, null, 'arbeit', { bezeichnung: 'HU vorbereiten', ausfuehrung: 'werkstatt', adresseId: adr });
  assert.ok(r.ok);
  const v = await d.vorgangLaden(r.id);
  assert.equal(v.aktuell.werte.adresseId, adr);
  assert.equal(v.adresse.aktuell.werte.bezeichnung, 'Autohaus Müller');
  const a = await d.adresseLaden(adr);
  assert.deepEqual(a.vorgaenge.map(x => [x.id, x.bezeichnung, x.status, x.fahrzeugName]), [[r.id, 'HU vorbereiten', 'offen', 'Wohnmobil']]);
  assert.equal((await d.adressenListe())[0].anzahlVorgaenge, 1);
});

test('Der Verweis ist freiwillig; eine unbekannte Adresse wird abgelehnt; bei einer Störung bleibt er leer', async () => {
  const { d, boot } = await neu();
  const adr = (await d.adresseAnlegen(mueller)).id;
  const ohne = await d.vorgangAnlegen(boot, null, 'arbeit', { bezeichnung: 'Ölwechsel', ausfuehrung: 'selbst' });
  assert.ok(ohne.ok);
  assert.equal((await d.vorgangLaden(ohne.id)).aktuell.werte.adresseId, null);
  assert.equal((await d.vorgangLaden(ohne.id)).adresse, null);
  const f = await d.vorgangAnlegen(boot, null, 'arbeit', { bezeichnung: 'X', ausfuehrung: 'werkstatt', adresseId: 'ad_gibt_es_nicht' });
  assert.ok(f.fehler.adresseId);
  assert.equal((await d.vorgaengeListe(boot)).length, 1, 'bei Fehlern wird nichts gespeichert');
  const st = await d.vorgangAnlegen(boot, null, 'stoerung', { bezeichnung: 'Motor aus', auswirkung: 'nicht', adresseId: adr });
  assert.ok(st.ok);
  assert.equal((await d.vorgangLaden(st.id)).aktuell.werte.adresseId, null, 'eine Störung hat noch keine Werkstatt');
});

test('Aus der Störung eine Arbeit machen: Adresse wählbar, der Verlauf zeigt ihren Namen', async () => {
  const { d, boot } = await neu();
  const adr = (await d.adresseAnlegen(mueller)).id;
  const id = (await d.vorgangAnlegen(boot, null, 'stoerung', { bezeichnung: 'Kühlwasser', auswirkung: 'nicht' })).id;
  assert.ok((await d.vorgangZuArbeit(id, { ausfuehrung: 'werkstatt', adresseId: 'weg' })).fehler.adresseId);
  assert.equal((await d.vorgangLaden(id)).aktuell.werte.art, 'stoerung', 'bei Fehlern bleibt alles, wie es war');
  const r = await d.vorgangZuArbeit(id, { ausfuehrung: 'werkstatt', arbeit: 'Kühler prüfen', adresseId: adr });
  assert.ok(r.ok && r.geaendert);
  const v = await d.vorgangLaden(id);
  assert.equal(v.aktuell.werte.adresseId, adr);
  const u = v.verlauf[0].aenderungen.find(x => x.key === 'adresseId');
  assert.equal(MM.Hilfen.wert(u.feld, u.neu), 'Autohaus Müller', 'im Verlauf steht der Name, nicht die Kennung');
  assert.equal(MM.Hilfen.wert(u.feld, u.alt), null);
});

test('Vorgang ändern: Adresse wechseln oder entfernen; Vorgänge aus 2.0.24 ohne Verweis bleiben unverändert', async () => {
  const { d, boot } = await neu();
  const a1 = (await d.adresseAnlegen(mueller)).id;
  const a2 = (await d.adresseAnlegen({ bezeichnung: 'Bootsbedarf Nord', art: 'lieferant' })).id;
  const id = (await d.vorgangAnlegen(boot, null, 'arbeit', { bezeichnung: 'Impeller', ausfuehrung: 'selbst', adresseId: a1 })).id;
  let r = await d.vorgangAendern(id, { bezeichnung: 'Impeller', ausfuehrung: 'selbst', auswirkung: 'keine', gemeldetAm: '2026-11-03', adresseId: a2 });
  assert.ok(r.ok && r.geaendert);
  assert.equal((await d.vorgangLaden(id)).aktuell.werte.adresseId, a2);
  assert.equal((await d.adresseLaden(a1)).vorgaenge.length, 0, 'die frühere Adresse zeigt ihn nicht mehr');
  assert.equal((await d.adresseLaden(a2)).vorgaenge.length, 1);
  r = await d.vorgangAendern(id, { bezeichnung: 'Impeller', ausfuehrung: 'selbst', auswirkung: 'keine', gemeldetAm: '2026-11-03', adresseId: '' });
  assert.ok(r.ok && r.geaendert);
  assert.equal((await d.vorgangLaden(id)).aktuell.werte.adresseId, null);
  assert.ok((await d.vorgangAendern(id, { bezeichnung: 'Impeller', ausfuehrung: 'selbst', adresseId: 'weg' })).fehler.adresseId);

  /* ein Vorgang aus 2.0.24 hat keinen Wert adresseId: Speichern ohne Änderung ist keine Änderung */
  const alt = (await d.vorgangAnlegen(boot, null, 'arbeit', { bezeichnung: 'Alt', ausfuehrung: 'selbst' })).id;
  const vl = (await d.speicher.alle('verlaeufe')).find(e => e.objektId === alt);
  delete vl.werte.adresseId; await d.speicher.speichern('verlaeufe', vl);
  const g = await d.vorgangAendern(alt, { bezeichnung: 'Alt', ausfuehrung: 'selbst', auswirkung: 'keine', gemeldetAm: '2026-11-03' });
  assert.ok(g.ok); assert.equal(g.geaendert, false);
});

test('Ausgeblendete Adresse: nicht neu wählbar, am Vorgang bleibt sie und bleibt änderbar', async () => {
  const { d, boot } = await neu();
  const a1 = (await d.adresseAnlegen(mueller)).id;
  const id = (await d.vorgangAnlegen(boot, null, 'arbeit', { bezeichnung: 'Zündkerzen', ausfuehrung: 'werkstatt', adresseId: a1 })).id;
  await d.adresseAendern(a1, Object.assign({}, mueller, { ausgeblendet: 'ja' }));
  assert.ok((await d.vorgangAnlegen(boot, null, 'arbeit', { bezeichnung: 'Neu', ausfuehrung: 'werkstatt', adresseId: a1 })).fehler.adresseId, 'neu nicht wählbar');
  const r = await d.vorgangAendern(id, { bezeichnung: 'Zündkerzen wechseln', ausfuehrung: 'werkstatt', auswirkung: 'keine', gemeldetAm: '2026-11-03', adresseId: a1 });
  assert.ok(r.ok, 'am Vorgang, an dem sie schon hängt, bleibt sie erlaubt');
  assert.equal((await d.vorgangLaden(id)).adresse.aktuell.werte.bezeichnung, 'Autohaus Müller', 'und wird weiter angezeigt');
});

/* ---------- Speicher und Sicherung ---------- */
test('Speicher: Tabelle adressen, die Sicherung enthält sie und stellt sie samt Verweis wieder her', async () => {
  assert.equal(MM.Speicher.DB_VERSION, 13);
  assert.ok(MM.Speicher.TABELLEN.includes('adressen'));
  const { d, boot } = await neu();
  const adr = (await d.adresseAnlegen(mueller)).id;
  const vid = (await d.vorgangAnlegen(boot, null, 'arbeit', { bezeichnung: 'Ölwechsel', ausfuehrung: 'werkstatt', adresseId: adr })).id;
  const s = await d.sicherungErzeugen({ mitDateien: false });
  assert.equal(s.zahlen.adressen, 1);

  const b = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => JETZT });
  await b.starten();
  const g = await b.sicherungLesen(s.bytes, '');
  assert.equal((await b.sicherungVorschau(g)).zahlen.adressen, 1);
  await b.sicherungEinspielen(g);
  const a = await b.adresseLaden(adr);
  assert.equal(a.aktuell.werte.bezeichnung, 'Autohaus Müller');
  assert.equal(a.vorgaenge[0].id, vid);
  assert.equal((await b.vorgangLaden(vid)).adresse.objekt.id, adr);
});

test('Eine Sicherung ohne die Tabelle adressen (aus 2.0.24) lässt sich einspielen', async () => {
  const { d, boot } = await neu();
  await d.vorgangAnlegen(boot, null, 'stoerung', { bezeichnung: 'Licht', auswirkung: 'keine' });
  const s = await d.sicherungErzeugen({ mitDateien: false });
  const g = await d.sicherungLesen(s.bytes, '');
  delete g.kopf.tabellen.adressen; if (g.kopf.zaehlung) delete g.kopf.zaehlung.adressen; g.kopf.dbVersion = 10;
  const b = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => JETZT });
  await b.starten();
  await b.sicherungEinspielen(g);
  assert.equal((await b.adressenListe()).length, 0);
  assert.equal((await b.vorgaengeListe(boot)).length, 1);
});
