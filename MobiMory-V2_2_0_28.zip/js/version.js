/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.28';
  MM.STUFE = 'Reiseorte: Orte mit Position und Ausstattung, Besuche, Frage nach der Ankunft, Reiseplan, Kosten pro Ort und Reise';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
