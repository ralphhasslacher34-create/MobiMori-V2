'use strict';
/* 2.0.64 (Schritt 13a): Konto in der App. Prüfungen, Geräte-Dokument, Anmelden, Abmelden, Löschen, Sicherung ohne Anmeldung,
   dazu ein Durchlauf App gegen den Konto-Dienst (mit der nachgebauten Datenbank). */
const t = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const testMitDienst = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const test = t;
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'konto', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM, K = MM.Konto;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

async function neu(optionen) {
  let n = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), Object.assign({ jetzt: () => new Date(Date.UTC(2026, 10, 10, 12, 0, n++)).toISOString() }, optionen || {}));
  await d.starten();
  return d;
}

/* ---------- Prüfungen ---------- */
test('Adresse des Dienstes: https nötig, Pfad „gesundheit“ und „konto“ fallen weg, localhost zum Entwickeln erlaubt', () => {
  assert.deepEqual(K.dienstAdresse('https://Konto.Beispiel.workers.dev/'), { ok: true, url: 'https://konto.beispiel.workers.dev' });
  assert.equal(K.dienstAdresse('https://konto.beispiel.workers.dev/gesundheit').url, 'https://konto.beispiel.workers.dev');
  assert.equal(K.dienstAdresse('https://konto.beispiel.workers.dev/konto/anmelden').url, 'https://konto.beispiel.workers.dev');
  assert.equal(K.dienstAdresse('http://localhost:8787').url, 'http://localhost:8787');
  assert.equal(K.dienstAdresse('http://konto.beispiel.de').ok, false);
  assert.equal(K.dienstAdresse('https://keinpunkt').ok, false);
  assert.equal(K.dienstAdresse('https://a b.de').ok, false);
  assert.equal(K.dienstAdresse('').ok, false);
});

test('E-Mail, Passwort, Code und Löschwort werden geprüft', () => {
  assert.equal(K.email('  Ralph@Example.DE ').email, 'ralph@example.de');
  assert.equal(K.email('ohne-at').ok, false); assert.equal(K.email('').ok, false);
  assert.equal(K.passwort('kurz').ok, false);
  assert.equal(K.passwort('genau-zehn').ok, true);
  assert.equal(K.passwort(' ein Passwort mit Leerzeichen ').passwort, ' ein Passwort mit Leerzeichen ', 'das Passwort wird nicht getrimmt');
  assert.equal(K.passwort('ä'.repeat(101)).ok, false, '202 Bytes sind zu lang');
  assert.equal(K.passwort('ä'.repeat(100)).ok, true);
  assert.equal(K.code(' 123 456 ').code, '123456'); assert.equal(K.code('12345').ok, false); assert.equal(K.code('abcdef').ok, false);
  assert.equal(K.loeschWort('löschen').ok, true); assert.equal(K.loeschWort('LOESCHEN').ok, true); assert.equal(K.loeschWort('ja').ok, false);
});

test('Fehlertexte sind in einfachen Worten', () => {
  assert.match(K.fehlerText({ status: 403 }), /App-Adresse/);
  assert.equal(K.fehlerText({ status: 401, message: 'E-Mail oder Passwort passen nicht.' }), 'E-Mail oder Passwort passen nicht.');
  assert.match(K.fehlerText({ name: 'AbortError' }), /zu lange/);
  assert.match(K.fehlerText(new Error('weg')), /Keine Verbindung/);
});

/* ---------- Gerät: Adresse und Anmeldung ---------- */
function falscherDienst() {
  const aufrufe = [];
  const f = async (url, methode, token, body) => { aufrufe.push({ url, methode, token, body }); const e = new Error('nicht erreichbar'); throw e; };
  f.aufrufe = aufrufe; return f;
}

test('Ohne Adresse: Einstellung leer, kein Senden, Hinweis', async () => {
  const d = await neu();
  assert.deepEqual(await d.kontoEinstellung(), { dienstUrl: '', eingerichtet: false, angemeldet: false, email: '', datenraumId: '', seit: null });
  const r = await d.kontoRegistrieren({ email: 'a@example.org', passwort: 'Sehr-sicheres-Passwort-1' });
  assert.equal(r.ok, false); assert.match(r.fehler.allgemein, /Adresse des Dienstes/);
});

test('Adresse speichern: Fehler ans Feld, gültige wird bereinigt gespeichert', async () => {
  const d = await neu();
  const schlecht = await d.kontoDienstSpeichern('http://konto.beispiel.de');
  assert.equal(schlecht.ok, false); assert.ok(schlecht.fehler.dienstUrl);
  const gut = await d.kontoDienstSpeichern('https://konto.beispiel.workers.dev/');
  assert.deepEqual(gut, { ok: true, abgemeldet: false });
  const e = await d.kontoEinstellung();
  assert.equal(e.dienstUrl, 'https://konto.beispiel.workers.dev'); assert.equal(e.eingerichtet, true); assert.equal(e.angemeldet, false);
});

test('Eingaben werden vor dem Senden geprüft, es geht nichts hinaus', async () => {
  const f = falscherDienst();
  const d = await neu({ kontoAnfrage: f });
  await d.kontoDienstSpeichern('https://konto.beispiel.workers.dev');
  const a = await d.kontoRegistrieren({ email: 'quatsch', passwort: 'kurz' });
  assert.deepEqual(Object.keys(a.fehler).sort(), ['email', 'passwort']);
  const b = await d.kontoCodePruefen({ email: 'a@example.org', code: '12' });
  assert.ok(b.fehler.code);
  const c = await d.kontoAnmelden({ email: 'a@example.org', passwort: '' });
  assert.ok(c.fehler.passwort);
  const e = await d.kontoPasswortSetzen({ passwort: 'kurz' });
  assert.ok(e.fehler.passwort);
  const g = await d.kontoLoeschen({ bestaetigung: 'nein' });
  assert.ok(g.fehler.bestaetigung);
  assert.equal(f.aufrufe.length, 0);
});

test('Ohne Netz: verständliche Meldung, keine Anmeldung gespeichert', async () => {
  const d = await neu({ kontoAnfrage: falscherDienst() });
  await d.kontoDienstSpeichern('https://konto.beispiel.workers.dev');
  const r = await d.kontoAnmelden({ email: 'a@example.org', passwort: 'Sehr-sicheres-Passwort-1' });
  assert.equal(r.ok, false); assert.match(r.fehler.allgemein, /Keine Verbindung/);
  assert.equal((await d.kontoEinstellung()).angemeldet, false);
});

test('Verbindung testen: sagt, was am Dienst fehlt', async () => {
  const d = await neu({ holeJson: async () => ({ ok: true, dienst: 'mobimory-konto', version: '13a-1', datenbank: true, tabellen: false, pepper: false, mail: false, entwicklung: false }) });
  await d.kontoDienstSpeichern('https://konto.beispiel.workers.dev');
  const r = await d.kontoVerbindung();
  assert.equal(r.ok, false); assert.match(r.fehler, /Tabellen/); assert.match(r.fehler, /PASSWORT_PEPPER/); assert.match(r.fehler, /E-Mail-Versand/);
  const gut = await neu({ holeJson: async () => ({ ok: true, dienst: 'mobimory-konto', version: '13a-1', datenbank: true, tabellen: true, pepper: true, mail: true, entwicklung: false }) });
  await gut.kontoDienstSpeichern('https://konto.beispiel.workers.dev');
  assert.equal((await gut.kontoVerbindung()).ok, true);
  const test = await neu({ holeJson: async () => ({ ok: true, dienst: 'mobimory-konto', version: '13a-1', datenbank: true, tabellen: true, pepper: true, mail: false, entwicklung: true }) });
  await test.kontoDienstSpeichern('https://konto.beispiel.workers.dev');
  const rt = await test.kontoVerbindung(); assert.equal(rt.ok, true); assert.equal(rt.entwicklung, true);
  const fremd = await neu({ holeJson: async () => ({ ok: true, dienst: 'recherche' }) });
  await fremd.kontoDienstSpeichern('https://konto.beispiel.workers.dev');
  assert.match((await fremd.kontoVerbindung()).fehler, /kein Konto-Dienst/);
  const stumm = await neu({ holeJson: async () => { throw new Error('weg'); } });
  await stumm.kontoDienstSpeichern('https://konto.beispiel.workers.dev');
  assert.match((await stumm.kontoVerbindung()).fehler, /antwortet nicht/);
});

/* ---------- Durchlauf gegen den Dienst ---------- */
async function verbinden(extra) {
  const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
  const dienst = await import('../server/konto-dienst.mjs');
  const env = Object.assign({ DB: neueDatenbank(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: 'https://app.example.org', ENTWICKLUNG: '1' }, extra || {});
  let uhr = Date.UTC(2026, 10, 10, 12, 0, 0);
  const anfragen = [];
  const f = async (url, methode, token, body) => {
    anfragen.push({ url, methode, token, body });
    const kopf = { Origin: 'https://app.example.org', 'CF-Connecting-IP': '203.0.113.7' };
    if (body !== undefined && body !== null) kopf['Content-Type'] = 'application/json';
    if (token) kopf.Authorization = 'Bearer ' + token;
    const r = await dienst.behandeln(new Request(url, { method: methode, headers: kopf, body: body === undefined || body === null ? undefined : JSON.stringify(body) }), env, { jetzt: () => uhr });
    const j = await r.json();
    if (!r.ok) { const e = new Error(j.error); e.status = r.status; e.feld = j.feld; throw e; }
    return j;
  };
  const d = await neu({ kontoAnfrage: f });
  await d.kontoDienstSpeichern('https://konto.example.workers.dev');
  return { d, env, anfragen, zeit: (ms) => { uhr += ms; } };
}

testMitDienst('Neues Konto mit Passwort: Code kommt, Bestätigen meldet an, Gerät merkt sich Anmeldung', async () => {
  const { d, anfragen } = await verbinden();
  const r = await d.kontoRegistrieren({ email: 'Anna@Example.org', passwort: 'Sehr-sicheres-Passwort-1' });
  assert.equal(r.ok, true); assert.match(r.entwicklungsCode, /^\d{6}$/);
  assert.equal((await d.kontoEinstellung()).angemeldet, false, 'vor dem Code nicht angemeldet');
  const falsch = await d.kontoCodePruefen({ email: 'anna@example.org', code: r.entwicklungsCode === '000000' ? '111111' : '000000' });
  assert.equal(falsch.ok, false); assert.ok(falsch.fehler.code);
  const ok = await d.kontoCodePruefen({ email: 'anna@example.org', code: r.entwicklungsCode });
  assert.deepEqual([ok.ok, ok.email, ok.passwortGesetzt], [true, 'anna@example.org', true]);
  const e = await d.kontoEinstellung();
  assert.deepEqual([e.angemeldet, e.email], [true, 'anna@example.org']); assert.ok(e.datenraumId); assert.ok(e.seit);
  assert.ok(!('token' in e) && !JSON.stringify(e).includes((await d.rcGeraet()).kontoToken), 'die Anzeige enthält nie den Schlüssel');
  /* Zum Registrieren und Code-Prüfen geht kein Schlüssel hinaus */
  assert.ok(anfragen.filter(a => /registrieren|code-pruefen/.test(a.url)).every(a => !a.token));
});

testMitDienst('Anmelden mit Code, Passwort setzen, Abmelden, wieder mit Passwort anmelden', async () => {
  const { d, anfragen } = await verbinden();
  const c = await d.kontoCodeAnfordern({ email: 'neu@example.org' });
  const a = await d.kontoCodePruefen({ email: 'neu@example.org', code: c.entwicklungsCode });
  assert.equal(a.ok, true); assert.equal(a.passwortGesetzt, false);
  assert.equal((await d.kontoPasswortSetzen({ passwort: 'Ein-neues-Passwort-2' })).ok, true);
  const mitToken = anfragen.find(x => /passwort-setzen/.test(x.url)); assert.ok(mitToken.token, 'Passwort setzen geht mit Schlüssel');
  const ab = await d.kontoAbmelden();
  assert.deepEqual(ab, { ok: true, serverAbgemeldet: true });
  assert.equal((await d.kontoEinstellung()).angemeldet, false);
  assert.equal((await d.kontoEinstellung()).eingerichtet, true, 'die Adresse bleibt');
  const falsch = await d.kontoAnmelden({ email: 'neu@example.org', passwort: 'Falsches-Passwort-9' });
  assert.equal(falsch.ok, false); assert.match(falsch.fehler.allgemein, /passen nicht/);
  const gut = await d.kontoAnmelden({ email: 'neu@example.org', passwort: 'Ein-neues-Passwort-2' });
  assert.equal(gut.ok, true); assert.equal((await d.kontoEinstellung()).angemeldet, true);
});

testMitDienst('Abmelden geht auch ohne Netz: Anmeldung ist auf dem Gerät sofort weg', async () => {
  const { d, anfragen } = await verbinden();
  const c = await d.kontoCodeAnfordern({ email: 'neu@example.org' });
  await d.kontoCodePruefen({ email: 'neu@example.org', code: c.entwicklungsCode });
  const alt = d.kontoAnfrageFn;
  d.kontoAnfrageFn = async () => { throw new Error('kein Netz'); };
  const ab = await d.kontoAbmelden();
  assert.deepEqual(ab, { ok: true, serverAbgemeldet: false });
  assert.equal((await d.kontoEinstellung()).angemeldet, false);
  d.kontoAnfrageFn = alt;
});

testMitDienst('Sitzung prüfen: gilt, läuft ab (dann geht die Anmeldung vom Gerät), ohne Netz bleibt sie', async () => {
  const { d, zeit } = await verbinden();
  const c = await d.kontoCodeAnfordern({ email: 'neu@example.org' });
  await d.kontoCodePruefen({ email: 'neu@example.org', code: c.entwicklungsCode });
  const gilt = await d.kontoSitzungPruefen();
  assert.deepEqual([gilt.ok, gilt.angemeldet], [true, true]);
  const alt = d.kontoAnfrageFn;
  d.kontoAnfrageFn = async () => { throw new Error('kein Netz'); };
  const offline = await d.kontoSitzungPruefen();
  assert.deepEqual([offline.ok, offline.angemeldet, offline.offline], [false, true, true]);
  assert.equal((await d.kontoEinstellung()).angemeldet, true, 'ohne Netz bleibt die Anmeldung');
  d.kontoAnfrageFn = alt;
  zeit(91 * 24 * 3600 * 1000);
  const ab = await d.kontoSitzungPruefen();
  assert.deepEqual([ab.angemeldet, ab.abgelaufen], [false, true]);
  assert.equal((await d.kontoEinstellung()).angemeldet, false);
});

testMitDienst('Konto löschen: Dienst bestätigt, Anmeldung geht, Daten auf dem Gerät bleiben', async () => {
  const { d, env } = await verbinden();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Meine Boje' })).id;
  const c = await d.kontoCodeAnfordern({ email: 'neu@example.org' });
  await d.kontoCodePruefen({ email: 'neu@example.org', code: c.entwicklungsCode });
  const nein = await d.kontoLoeschen({ bestaetigung: 'vielleicht' });
  assert.equal(nein.ok, false);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM nutzer').get().n, 1);
  const ja = await d.kontoLoeschen({ bestaetigung: 'löschen' });
  assert.equal(ja.ok, true);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM nutzer').get().n, 0);
  assert.equal((await d.kontoEinstellung()).angemeldet, false);
  assert.ok(await d.fahrzeugLaden(boot), 'das Fahrzeug auf dem Gerät ist noch da');
});

testMitDienst('Schlägt das Löschen beim Dienst fehl, bleibt die Anmeldung auf dem Gerät', async () => {
  const { d } = await verbinden();
  const c = await d.kontoCodeAnfordern({ email: 'neu@example.org' });
  await d.kontoCodePruefen({ email: 'neu@example.org', code: c.entwicklungsCode });
  d.kontoAnfrageFn = async () => { throw new Error('kein Netz'); };
  const r = await d.kontoLoeschen({ bestaetigung: 'LÖSCHEN' });
  assert.equal(r.ok, false);
  assert.equal((await d.kontoEinstellung()).angemeldet, true);
});

testMitDienst('Andere Adresse des Dienstes beendet die Anmeldung auf dem Gerät, dieselbe nicht', async () => {
  const { d } = await verbinden();
  const c = await d.kontoCodeAnfordern({ email: 'neu@example.org' });
  await d.kontoCodePruefen({ email: 'neu@example.org', code: c.entwicklungsCode });
  assert.deepEqual(await d.kontoDienstSpeichern('https://konto.example.workers.dev/'), { ok: true, abgemeldet: false });
  assert.equal((await d.kontoEinstellung()).angemeldet, true);
  assert.deepEqual(await d.kontoDienstSpeichern('https://anderer.example.workers.dev'), { ok: true, abgemeldet: true });
  const e = await d.kontoEinstellung();
  assert.deepEqual([e.angemeldet, e.email, e.datenraumId], [false, '', '']);
});

testMitDienst('Die Sicherungsdatei enthält weder Schlüssel noch Adresse des Dienstes noch E-Mail-Adresse', async () => {
  const { d } = await verbinden();
  await d.fahrzeugAnlegen('boot', { bezeichnung: 'Meine Boje' });
  const c = await d.kontoCodeAnfordern({ email: 'geheim-konto@example.org' });
  await d.kontoCodePruefen({ email: 'geheim-konto@example.org', code: c.entwicklungsCode });
  const token = (await d.rcGeraet()).kontoToken;
  assert.ok(token && token.length > 30);
  const s = await d.sicherungErzeugen({ mitDateien: false });
  const text = Buffer.from(s.bytes).toString('latin1') + Buffer.from(s.bytes).toString('utf8');
  assert.ok(!text.includes(token)); assert.ok(!text.includes('geheim-konto@example.org')); assert.ok(!text.includes('konto.example.workers.dev'));
  const ohne = await d.sicherungErzeugen({ mitDateien: false });
  assert.ok(ohne.bytes.length > 0);
});

/* ---------- Dateien ---------- */
test('Konto-Modul steht in index.html (vor daten.js) und im Service Worker, Kachel und Seite sind eingebaut', () => {
  const idx = lesen('index.html');
  assert.ok(idx.indexOf('js/konto.js') > 0 && idx.indexOf('js/konto.js') < idx.indexOf('js/daten.js'));
  assert.match(lesen('sw.js'), /'js\/konto\.js'/);
  const a = lesen('js/ansicht.js');
  assert.ok(a.includes("kachel('Konto'") && a.includes("teile[0] === 'konto'") && a.includes('function seiteKonto'));
});

test('Server-Dateien sind da, der Server steht nicht in der App und nicht im Offline-Speicher', () => {
  ['server/konto-dienst.mjs', 'server/schema.sql', 'server/wrangler.jsonc', 'server/EINRICHTUNG.md'].forEach(f => assert.ok(fs.existsSync(path.join(__dirname, '..', f)), f + ' fehlt'));
  assert.ok(!lesen('sw.js').includes('server/'));
  assert.ok(!lesen('.github/workflows/veroeffentlichen.yml').includes('server'), 'der Server wird nicht mit der App veröffentlicht');
  assert.match(lesen('.github/workflows/veroeffentlichen.yml'), /node-version: 22/);
});

test('Im Dienst steht kein Geheimnis: Pepper, Schlüssel und Passwörter kommen nur aus der Umgebung', () => {
  const s = lesen('server/konto-dienst.mjs');
  assert.ok(!/PASSWORT_PEPPER\s*[:=]\s*['"][^'"]{8,}/.test(s));
  assert.ok(!/sk-[A-Za-z0-9]{10,}/.test(s));
  assert.ok(!/ENTWICKLUNG\s*=\s*['"]1['"]\s*[,;]/.test(lesen('server/wrangler.jsonc')), 'ENTWICKLUNG steht nicht in der Konfiguration des echten Dienstes');
});
