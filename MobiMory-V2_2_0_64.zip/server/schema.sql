-- MobiMory Konto-Dienst, Schritt 13a (seit 2.0.64)
-- In der Cloudflare-Datenbank (D1) einmal ausführen. Mehrfaches Ausführen schadet nicht.
-- Gespeichert wird nur das Nötige: E-Mail-Adresse, Passwort-Abdruck (nie das Passwort selbst),
-- Sitzungen (nur ein Abdruck des Schlüssels), Codes (nur ein Abdruck) und Zähler gegen Durchprobieren.

CREATE TABLE IF NOT EXISTS nutzer (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  passwort_hash TEXT,
  passwort_wartend TEXT,
  erstellt_am INTEGER NOT NULL,
  bestaetigt_am INTEGER,
  letzte_anmeldung INTEGER
);

-- Jeder Nutzer hat genau einen eigenen Datenraum (auch kostenlos).
CREATE TABLE IF NOT EXISTS datenraum (
  id TEXT PRIMARY KEY,
  nutzer_id TEXT NOT NULL UNIQUE REFERENCES nutzer(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  erstellt_am INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sitzung (
  token_hash TEXT PRIMARY KEY,
  nutzer_id TEXT NOT NULL REFERENCES nutzer(id) ON DELETE CASCADE,
  erstellt_am INTEGER NOT NULL,
  laeuft_ab INTEGER NOT NULL,
  geraet TEXT
);
CREATE INDEX IF NOT EXISTS sitzung_nutzer ON sitzung(nutzer_id);

CREATE TABLE IF NOT EXISTS code (
  email TEXT PRIMARY KEY,
  zweck TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  laeuft_ab INTEGER NOT NULL,
  versuche INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS drossel (
  schluessel TEXT PRIMARY KEY,
  anzahl INTEGER NOT NULL,
  fenster_bis INTEGER NOT NULL
);
