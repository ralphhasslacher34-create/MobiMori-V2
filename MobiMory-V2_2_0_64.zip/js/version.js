/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.64';
  MM.STUFE = 'Konto: Server-Grundlage, Anmelden mit Passwort und mit Code';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
