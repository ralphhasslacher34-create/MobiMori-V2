# Schritte beim Aufbau von V2

Grundlage ist das Dokument „MobiMory V2 – Festlegungen und Datenstruktur“.
Jeder Schritt baut auf dem letzten auf und endet mit einem sichtbaren Ergebnis.

| Schritt | Inhalt | Stand |
|---|---|---|
| 1 | Fahrzeug: Fahrzeugliste (Schale 1) und äußere Hülle (Schale 2), Handeingabe, Verlauf, offline | fertig (2.0.1) |
| 1a | Ansicht der äußeren Schalen: Startseite, Hauptmenü, Stammdaten, Neu im Programm, Einstellungen | fertig (2.0.2) |
| 2 | Hauptkomponenten (Schale 3), beliebig tief verschachtelt, mit Hersteller, Modell, Seriennummer, Baujahr, Einbau, technischen Merkmalen | fertig (2.0.4) |
| 3 | Fristen an Fahrzeug und Komponenten (Kalender und Zähler), Zählerstände von Hand, Erledigungen | fertig (2.0.5) |
| 3a | Dokumente an Fahrzeug und Komponente (Datei oder Link), Gesamtliste | fertig (2.0.6) |
| 3b | Personen, Tiere und Nachweise (offene Nachweisarten mit Vorschlägen DE/EU) | fertig (2.0.7) |
| 4 | Aktivität mit gemeinsamem Kern (Besatzung aus den Personen, Prüfung bei der Planung) | fertig (2.0.8) |
| 4b | Sicherungsdatei: sichern, verschlüsseln, wiederherstellen, Erinnerung | fertig (2.0.9) |
| 4a | Orte und Gebiete mit Regeln (Stufe 1: eigene Regeln, einfache Gebietsliste) | fertig (2.0.10, erweitert in 2.0.11 und 2.0.12) |
| 4c | Testrunde mit echten Daten (Wohnmobil und Boot) | gemacht, einziger offener Punkt war die Ausrüstung |
| 4d | Ausrüstung nachbessern: Anzahl, Bezugsgröße (Fahrzeug oder Person), Soll gegen Ist, Eignung als Hinweis mit Haken | fertig (2.0.12), noch nicht getestet |
| 5 | Logbuch-Kern: Tagesabschnitte, Ereignisse, Nachtragen | fertig (2.0.13), noch nicht getestet |
| 5a | Cockpit und klassisches Logbuch: Bedienung, Wechsel mit Prüfung, Tagesabschluss | fertig (2.0.14), noch nicht getestet |
| 5b | Ereignisse je Fahrzeugart (Baum, vererbt, änderbar) und Logbuch ohne Planung starten | fertig (2.0.15), noch nicht getestet |
| 5c | Fahrzeugarten selbst verwalten: Untergruppen anlegen, umbenennen, ausblenden, löschen (nur Unbenutztes), bereinigen | fertig (2.0.16), noch nicht getestet |
| 5d | Art der Aktivität richtet sich nach dem Fahrzeug (Zuordnung wie bei den Ereignissen); Logbuch jetzt starten mit Wahl der Art | fertig (2.0.17), noch nicht getestet |
| 5e | Cockpit im Vollbild ohne Scrollen, bis zu 8 frei belegbare Schnellknöpfe je Fahrzeugart plus „Sonstige Ereignisse“ (3 mal 3) | fertig (2.0.18), noch nicht getestet |
| 6 | Zähler automatisch, erster Teil: ein Schalter und ein Zähler je Motor (Start/Stopp, Betriebsstunden), Kurzname, Leiste im Cockpit, Liste ab drei Motoren, Stoppzeit korrigieren | fertig (2.0.19), noch nicht getestet |
| 6b | Motorhinweis je Fahrzeugart („Kein Motor läuft“), Betriebsstunden und Kilometer zusammen in der Anzeige, Knopfzahl je Gerät (bis 15, Spalten nach Bildschirmbreite) | fertig (2.0.20), noch nicht getestet |
| 6c | Position bei jedem Eintrag im Logbuch (GPS oder von Hand, Herkunft, Ortsname, Namen lernen, Gerät) | fertig (2.0.21), noch nicht getestet |
| 6a | Zähler automatisch, zweiter Teil: Motorstopp-Frage nach Ankunft, Anlegen oder Anker werfen (Vorschlag der Stoppzeit, Wartezeit (Timer) vom Nutzer eingestellt) | fertig (2.0.22), noch nicht getestet |
| 6d | Status des Fahrzeugs und Regeln der Ereignisse: Land 2 Status, Wasser 3 Status, Knöpfe grau mit Grund, Regel an der Art, Nachtragen nie gesperrt | fertig (2.0.23), noch nicht getestet |
| 7a | Werkstatt, Vorgang: Störung melden, Arbeit daraus machen (selbst oder Werkstatt), offen oder erledigt, am Fahrzeug oder an der Komponente; Warnung bei versprochenen Aktivitäten (trotzdem nutzen oder absagen) | fertig (2.0.24), noch nicht getestet |
| 7b | Werkstatt, Adressen: eine zentrale Liste für Werkstätten, Lieferanten und Händler, der Vorgang verweist darauf | fertig (2.0.25), noch nicht getestet |
| 7c | Werkstatt, Dokumente und Bilder: Reparaturbuch, Anleitung und Ersatzteilliste an der Komponente, Bilder und Belege am Vorgang (über die vorhandene Datei-Liste) | fertig (2.0.26), noch nicht getestet |
| 7d | Werkstatt, Störung im Logbuch: Das Ereignis „Störung“ legt den Werkstatt-Vorgang an (eine Störung für beide), mit Einschränkung und Warnung, auch unterwegs im Cockpit | fertig (2.0.26), noch nicht getestet |
| 8 | Kosten: eine Kosten-Liste mit Fixkosten, variablen Kosten und Instandhaltung (Beträge am Vorgang, an der Aktivität, an der Komponente), Wertverlust, Auswertung pro Fahrzeug und Jahr, Vergleich mit Mieten oder Chartern | fertig (2.0.27), noch nicht getestet |
| 8a | Reiseorte: Orte mit Art, Position und Ausstattung, Frage nach der Ankunft (immer freiwillig), Besuche mit Historie, Kosten pro Ort und pro Reise, Start, Ziel und Zwischenziele in der Aktivität mit Plan gegen Ist | fertig (2.0.28), noch nicht getestet |
| 8c | Kostenzeilen und Reisekasse: mehrere Kostenzeilen je Besuch, offene Kostenarten (eigene Arten auch im Formular), Zahlungsmittel („Bezahlt mit“), Gruppe Reisekasse an der Aktivität mit Foto, Notiz und Ort, Bargeldkasse je Währung (Anfangsbestand, Einzahlung, Kassensturz, Kurs aus den Einzahlungen), Reiseauswertung (Fahrzeug und Reisekasse getrennt, Fixkosten-Anteil ein- und ausschaltbar, pro Tag und Person, nach Zahlungsmittel) | fertig (2.0.29), noch nicht getestet |
| 8b | Import und Export: Fahrzeuge aus Excel oder CSV übernehmen (Spalten zuordnen, Vorschau, nichts wird überschrieben), Fahrzeuge, Kosten und Orte als Excel oder CSV ausgeben. Routen in Routenformaten gehören zu Schritt 9 | fertig (2.0.30), noch nicht getestet |
| 8d | Aufräumen: neues Logo, Kachelseiten füllen den Platz, Kassenbuch unter Funktionen, alle Arten-Listen (Aktivitäten, Ereignisse, Kostenarten und Zahlungsmittel) zentral in den Stammdaten | fertig (2.0.31), noch nicht am Tablet getestet |
| 8e | Kacheln lesbar: Text nie abgeschnitten, Titel bleiben ganze Wörter, Beschreibungen brechen an Silben um, Schrift und Spaltenzahl passen sich an (2.0.32) | erledigt |
| 9 | Route, GPX, Wetter und Tide: Routendatei einlesen (GPX, KML, GeoJSON), Fahrzeit und Ankunftszeit, Wetter am Punkt zur Ankunftszeit, Wellen und Wasserstand bei Wasserfahrzeugen, Abfahrt früher oder später, Kilometer über GPS, „Traffic“ wird „Travel“ | fertig (2.0.33), noch nicht getestet |
| 9b | Karte im Vollbild (Route, Start, Ziel, Wetterpunkte, gefahrener Weg, Position, Verspätung), „Wetter jetzt“ im Cockpit als Logbuch-Eintrag, Wetter im Rhythmus, Offline-Karte entlang der Route | fertig (2.0.34), noch nicht am Tablet getestet |
| 11 | Reisecheck | offen |
| 12 | Konten, Server und Stufen, danach Verleih | offen |
| 13 | Smart Capture (Fahrzeugschein und Nachweise einlesen) | offen |
| 14 | Wasserski, später Segeln (Sonderaktivitäten, am Ende; früher Nummer 10) | offen |

Die Reihenfolge ab Schritt 5 hat der Nutzer am 03.11.2026 festgelegt.

## Noch nicht drin, weil sie auf anderen Teilen aufbauen
- Weitere feste Standorte der äußeren Hülle: Der Heimatstandort ist seit 2.0.10 da, weitere folgen nach Bedarf.
- Konto und Anmeldung, Server, Sicherung: kommen später. Schritt 1 arbeitet nur lokal (Basis-Version).
- Kostenentwicklung über mehrere Jahre, Diagramme und Kostenvorschau für eine geplante Aktivität: noch nicht festgelegt.
- Fristen, Kosten und Nachweise an den Komponenten: kommen mit den jeweiligen Schritten.
- Feste Merkmal-Kataloge je Komponente (bisher frei eintragbar): im Festlegungsdokument noch nicht besprochen.
- Dokumente auf dem Server und auf mehreren Geräten (Original auf dem Server, Kopie „offline verfügbar“ auf dem Gerät): kommt mit Konten und Server.
- Smart Capture (Fahrzeugschein einlesen): eigener Schritt, nutzt die Ablage für Dateien.
- Vorschläge für Nachweisarten aus weiteren Ländern: kommen nach Bedarf, Land für Land, jeweils mit Quelle und Prüfdatum.
- Prüfung „erlaubt, nicht erlaubt, unklar“ für Skipper und Fahrer: kommt mit der Aktivität.
- Tiere als Bezugsgröße der Pflichtausrüstung: nicht vorgesehen, es ist keine Pflicht bekannt.
- Prüfung gegen Anforderungen eines Gebiets: seit 2.0.10 mit eigenen Regeln. Ein Gebiet nur als Text wird weiter nicht geprüft.
- Prüfung zum Tagesbeginn: seit 2.0.13 je Tag festgehalten. Prüfung bei jedem Wechsel des Verantwortlichen unterwegs: seit 2.0.14 beim Wechsel festgehalten.
- Automatische Sicherung und Umzug zwischen mehreren Geräten ohne Datei: kommt mit Konten und Server.
- Regeln mit Quelle und Prüfdatum (Stufe 2) und weitere Länder sowie Motorleistung und Gewicht als Bedingungen (Stufe 3): erst nach der Testrunde.
