/*
 * Karte (seit 2.0.34, Schritt 9b): reine Beschreibung und Rechnung, ohne Browser und ohne Netz.
 *
 *  - QUELLE: die eine Stelle, an der die Kartenquelle steht. Alle Teile der App fragen hier (eine Quelle für alle Funktionen).
 *  - Kacheln: welche Kacheln braucht ein Streifen entlang der Route, wie viele sind es, wie groß wird das ungefähr.
 *  - Weg: der tatsächlich gefahrene Weg aus den GPS-Punkten, dünn gehalten.
 *  - Position auf der Route: wo liegst du, wie weit neben der Route, wie viel früher oder später als geplant.
 *  - Wetter jetzt: der Text für das Logbuch und der Rhythmus der automatischen Abfrage.
 *
 * Das Zeichnen der Karte (Leaflet) steht in js/kartenansicht.js, das Ablegen der Kacheln in js/kartenablage.js.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /*
   * Die Quelle der Kartenkacheln. Gewechselt wird nur hier.
   * Stand der Prüfung (04.11.2026): Die Standard-Kacheln von OpenStreetMap sind für Tests im kleinen Rahmen gedacht. Das Herunterladen
   * großer Gebiete und die Auslieferung in einer App für viele Nutzer ist dort nicht vorgesehen. Vor der Veröffentlichung in einem App-Store
   * muss die Quelle gewechselt werden (Anbieter mit passenden Bedingungen, oder eigene Kacheln). Darum begrenzt die App den Abruf hart.
   */
  var QUELLE = {
    name: 'OpenStreetMap, Standard-Kacheln',
    url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    nachweis: '© OpenStreetMap-Mitwirkende',
    nachweisLink: 'https://www.openstreetmap.org/copyright',
    minZoom: 2, maxZoom: 19,
    kachelBytes: 20000,   /* Schätzung je Kachel, nur für die Anzeige vorab */
    maxKacheln: 300,      /* mehr holt die App nie auf einmal */
    parallel: 2, pauseMs: 250
  };

  var STUFEN = [
    { wert: 'grob', label: 'Grob: Übersicht der ganzen Reise', zMin: 5, zMax: 9 },
    { wert: 'mittel', label: 'Mittel: Orte und größere Straßen', zMin: 5, zMax: 11 },
    { wert: 'fein', label: 'Fein: Straßen, Häfen, Stellplätze', zMin: 5, zMax: 13 }
  ];
  /* Bis zu dieser Stufe wird ein Streifen von einer Kachel beiderseits der Route geholt, darüber nur die Kacheln direkt an der Route. */
  var PUFFER_BIS_ZOOM = 11;

  function runde(n, stellen) { var f = Math.pow(10, stellen); return Math.round(n * f) / f; }
  function zahl(x) { var n = typeof x === 'number' ? x : parseFloat(String(x).replace(',', '.')); return isFinite(n) ? n : null; }
  function gueltig(b, l) { return typeof b === 'number' && typeof l === 'number' && b >= -90 && b <= 90 && l >= -180 && l <= 180; }
  function dz(n) { return String(n).replace('.', ','); }
  function z2(n) { return (n < 10 ? '0' : '') + n; }

  function entfernungKm(b1, l1, b2, l2) {
    var R = 6371.0088, rad = Math.PI / 180;
    var dB = (b2 - b1) * rad, dL = (l2 - l1) * rad;
    var a = Math.sin(dB / 2) * Math.sin(dB / 2) + Math.cos(b1 * rad) * Math.cos(b2 * rad) * Math.sin(dL / 2) * Math.sin(dL / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
  }

  /* ---------- Kacheln ---------- */
  function kachelUrl(z, x, y) { return QUELLE.url.replace('{z}', z).replace('{x}', x).replace('{y}', y); }
  function kachelKey(z, x, y) { return z + '/' + x + '/' + y; }

  /* Kommazahl der Kachel (Bruchteil inbegriffen) zu Breite und Länge */
  function kachelKomma(breite, laenge, z) {
    var n = Math.pow(2, z), b = Math.max(-85.0511, Math.min(85.0511, breite)), rad = b * Math.PI / 180;
    return { x: (laenge + 180) / 360 * n, y: (1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2 * n };
  }
  function kachelNr(breite, laenge, z) {
    var n = Math.pow(2, z), k = kachelKomma(breite, laenge, z);
    return { x: Math.max(0, Math.min(n - 1, Math.floor(k.x))), y: Math.max(0, Math.min(n - 1, Math.floor(k.y))) };
  }

  /*
   * Die Kacheln entlang einer Linie von Punkten für die Zoomstufen zMin bis zMax.
   * Rückgabe: { kacheln: [{ z, x, y }], zuViele } – zuViele ist wahr, wenn die Rechnung vorzeitig abgebrochen wurde (weit über der Grenze).
   */
  function korridorKacheln(punkte, zMin, zMax, abbruchBei) {
    var gesehen = {}, liste = [], zuViele = false, grenze = abbruchBei || 20000;
    var gut = (punkte || []).filter(function (p) { return p && gueltig(p.breite, p.laenge); });
    if (!gut.length) return { kacheln: [], zuViele: false };
    var z;
    for (z = zMin; z <= zMax && !zuViele; z++) {
      var n = Math.pow(2, z), puffer = z <= PUFFER_BIS_ZOOM ? 1 : 0;
      var kk = gut.map(function (p) { return kachelKomma(p.breite, p.laenge, z); });
      var nimm = function (cx, cy) {
        var dx, dy;
        for (dx = -puffer; dx <= puffer; dx++) {
          for (dy = -puffer; dy <= puffer; dy++) {
            var x = cx + dx, y = cy + dy;
            if (x < 0 || x >= n || y < 0 || y >= n) continue;
            var k = kachelKey(z, x, y);
            if (!gesehen[k]) { gesehen[k] = true; liste.push({ z: z, x: x, y: y }); }
          }
        }
      };
      var i;
      for (i = 0; i < kk.length && !zuViele; i++) {
        if (i === 0) nimm(Math.floor(kk[0].x), Math.floor(kk[0].y));
        if (i > 0) {
          var a = kk[i - 1], b = kk[i];
          var schritte = Math.max(1, Math.ceil(Math.max(Math.abs(b.x - a.x), Math.abs(b.y - a.y)) * 2));
          var s;
          for (s = 1; s <= schritte; s++) {
            var t = s / schritte;
            nimm(Math.floor(a.x + (b.x - a.x) * t), Math.floor(a.y + (b.y - a.y) * t));
            if (liste.length > grenze) { zuViele = true; break; }
          }
        }
        if (liste.length > grenze) zuViele = true;
      }
    }
    liste.sort(function (p, q) { return p.z - q.z || p.x - q.x || p.y - q.y; });
    return { kacheln: liste, zuViele: zuViele };
  }

  function stufeVon(wert) { for (var i = 0; i < STUFEN.length; i++) if (STUFEN[i].wert === wert) return STUFEN[i]; return null; }

  function grenzen(punkte) {
    var g = null;
    (punkte || []).forEach(function (p) {
      if (!p || !gueltig(p.breite, p.laenge)) return;
      if (!g) g = { sued: p.breite, nord: p.breite, west: p.laenge, ost: p.laenge };
      else { g.sued = Math.min(g.sued, p.breite); g.nord = Math.max(g.nord, p.breite); g.west = Math.min(g.west, p.laenge); g.ost = Math.max(g.ost, p.laenge); }
    });
    return g;
  }

  /*
   * Was würde der Abruf für diese Stufe bringen? Ohne Netz, nur gerechnet.
   * Ergebnis: { ok, stufe, anzahl, bytes, mb, kacheln, grenzen } oder { ok: false, grund, anzahl? }
   */
  function planung(punkte, stufenWert) {
    var stufe = stufeVon(stufenWert);
    if (!stufe) return { ok: false, grund: 'Diese Stufe gibt es nicht.' };
    var g = grenzen(punkte);
    if (!g) return { ok: false, grund: 'Es gibt noch keine Punkte, für die eine Karte geholt werden kann. Lies eine Route ein oder trage bei Start und Ziel eine Position ein.' };
    var k = korridorKacheln(punkte, stufe.zMin, stufe.zMax, QUELLE.maxKacheln * 5);
    var anzahl = k.zuViele ? null : k.kacheln.length;
    if (k.zuViele || anzahl > QUELLE.maxKacheln) {
      return { ok: false, zuGross: true, anzahl: anzahl, grund: 'Der Streifen entlang der Route ist für diese Stufe zu groß' + (anzahl !== null ? ' (' + anzahl + ' Kacheln, erlaubt sind ' + QUELLE.maxKacheln + ')' : '') + '. Wähle eine gröbere Stufe.' };
    }
    var bytes = anzahl * QUELLE.kachelBytes;
    return { ok: true, stufe: stufe.wert, anzahl: anzahl, bytes: bytes, mb: runde(bytes / 1048576, 1), kacheln: k.kacheln, grenzen: g };
  }

  /* Größe als Text, zum Beispiel „2,4 MB“ */
  function groesseText(bytes) {
    var n = Number(bytes) || 0;
    if (n < 1024) return n + ' Byte';
    if (n < 1048576) return dz(runde(n / 1024, 0)) + ' KB';
    return dz(runde(n / 1048576, 1)) + ' MB';
  }

  /* ---------- Der gefahrene Weg ---------- */
  var MAX_WEG = 4000;
  var WEG_LUECKE_MS = 10 * 60 * 1000;

  function wegNeu() { return { punkte: [], verworfen: 0 }; }

  /*
   * Ein GPS-Punkt kommt zum Weg dazu, wenn er genau genug ist (höchstens 50 m), weit genug vom letzten Punkt entfernt ist
   * (so weit wie die Ungenauigkeit, mindestens 20 m, höchstens 100 m) und die Geschwindigkeit dazwischen glaubhaft ist.
   * Nach einer Lücke von mehr als 10 Minuten (App im Hintergrund) beginnt ein neues Stück, es wird keine gerade Linie dazwischen gezogen.
   * weg: { punkte: [[breite, laenge, sek, stueck]], verworfen }. Ergebnis ist ein neuer Weg, der alte bleibt unverändert.
   */
  function wegPunkt(weg, fix, welt) {
    var w = { punkte: (weg && weg.punkte ? weg.punkte : []).slice(), verworfen: weg && weg.verworfen ? weg.verworfen : 0 };
    if (!fix || !gueltig(fix.breite, fix.laenge)) return w;
    var gen = typeof fix.genauigkeit === 'number' && isFinite(fix.genauigkeit) ? fix.genauigkeit : 25;
    if (gen > 50) { w.verworfen++; return w; }
    var sek = Math.round(fix.zeitMs / 1000), b = runde(fix.breite, 5), l = runde(fix.laenge, 5);
    var n = w.punkte.length;
    if (!n) { w.punkte.push([b, l, sek, 0]); return w; }
    var l0 = w.punkte[n - 1], stueck = l0[3] || 0;
    if (fix.zeitMs - l0[2] * 1000 > WEG_LUECKE_MS) { w.punkte.push([b, l, sek, stueck + 1]); return w; }
    var d = entfernungKm(l0[0], l0[1], b, l) * 1000;
    if (d < Math.max(20, Math.min(100, gen))) return w;
    var std = (fix.zeitMs - l0[2] * 1000) / 3600000;
    if (std > 0 && (d / 1000) / std > (welt === 'wasser' ? 80 : 150)) { w.verworfen++; return w; }
    w.punkte.push([b, l, sek, stueck]);
    if (w.punkte.length > MAX_WEG) {
      /* Zu viele Punkte: jeder zweite fällt weg, der erste und der letzte bleiben */
      w.punkte = w.punkte.filter(function (p, i) { return i === 0 || i === w.punkte.length - 1 || i % 2 === 0; });
    }
    return w;
  }

  /* Die Stücke des Wegs als Listen von [breite, laenge], getrennt an den Lücken */
  function wegStuecke(weg) {
    var res = [], akt = null, letztes = null;
    ((weg && weg.punkte) || []).forEach(function (p) {
      var s = p[3] || 0;
      if (akt === null || s !== letztes) { akt = []; res.push(akt); letztes = s; }
      akt.push([p[0], p[1]]);
    });
    return res;
  }
  function wegLaengeKm(weg) {
    var sum = 0, p0 = null;
    ((weg && weg.punkte) || []).forEach(function (p) {
      if (p0 && (p0[3] || 0) === (p[3] || 0)) sum += entfernungKm(p0[0], p0[1], p[0], p[1]);
      p0 = p;
    });
    return runde(sum, 2);
  }

  /* ---------- Position auf der Route ---------- */
  /*
   * Der nächste Punkt der Route zu einer Position. punkte: [{ breite, laenge, km }].
   * Ergebnis: { km (Stelle der Route), abstandKm (neben der Route), index (Abschnitt) } oder null.
   */
  function aufRoute(punkte, breite, laenge) {
    if (!punkte || punkte.length < 2 || !gueltig(breite, laenge)) return null;
    var kx = 111.320 * Math.cos(breite * Math.PI / 180), ky = 110.574, bester = null;
    for (var i = 1; i < punkte.length; i++) {
      var a = punkte[i - 1], b = punkte[i];
      var ax = (a.laenge - laenge) * kx, ay = (a.breite - breite) * ky, bx = (b.laenge - laenge) * kx, by = (b.breite - breite) * ky;
      var dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
      var t = l2 ? Math.max(0, Math.min(1, -(ax * dx + ay * dy) / l2)) : 0;
      var ex = ax + t * dx, ey = ay + t * dy, d = Math.sqrt(ex * ex + ey * ey);
      if (!bester || d < bester.abstandKm) bester = { km: a.km + t * (b.km - a.km), abstandKm: d, index: i };
    }
    return { km: runde(bester.km, 2), abstandKm: runde(bester.abstandKm, 2), index: bester.index };
  }

  /*
   * Wie viele Minuten bist du später (plus) oder früher (minus) als geplant? Verglichen wird die Uhrzeit, zu der du an dieser
   * Stelle der Route sein solltest, mit jetzt. Ohne Antwort (null), wenn die Fahrt noch nicht begonnen hat, du zu weit neben der Route
   * bist (mehr als maxAbstandKm), kein Tempo bekannt ist oder die Abweichung unglaubwürdig ist (über 12 Stunden).
   */
  function verspaetungMin(opt) {
    if (!opt || !opt.position || !(opt.kmh > 0) || typeof opt.abfahrtMs !== 'number' || typeof opt.jetztMs !== 'number') return null;
    if (opt.jetztMs < opt.abfahrtMs) return null;
    var max = typeof opt.maxAbstandKm === 'number' ? opt.maxAbstandKm : 3;
    if (opt.position.abstandKm > max) return null;
    var sollMs = opt.abfahrtMs + opt.position.km / opt.kmh * 3600000;
    var min = Math.round((opt.jetztMs - sollMs) / 60000);
    if (Math.abs(min) > 720) return null;
    return min;
  }
  function verspaetungText(min) {
    if (min === null || min === undefined) return '';
    if (Math.abs(min) < 5) return 'im Plan';
    var h = Math.floor(Math.abs(min) / 60), m = Math.abs(min) % 60;
    var t = (h ? h + ' h ' : '') + (m ? m + ' min' : '');
    return t.trim() + (min > 0 ? ' später als geplant' : ' früher als geplant');
  }

  /* ---------- Wetter jetzt ---------- */
  function windText(einheit) { return einheit === 'kn' ? 'kn' : 'km/h'; }

  /* Die Wetter-Teile in einer Zeile. w: Ergebnis von MM.Routen.wetterZurZeit, m: von meerZurZeit (oder null). */
  function wetterTeile(w, m, einheit) {
    var t = [];
    if (w) {
      if (w.himmel) t.push(w.himmel);
      if (w.temperatur !== null && w.temperatur !== undefined) t.push(dz(w.temperatur) + ' °C');
      if (w.wind !== null && w.wind !== undefined) t.push('Wind ' + dz(w.wind) + ' ' + windText(einheit) + (w.windRichtung !== null && w.windRichtung !== undefined && MM.Routen ? ' aus ' + MM.Routen.himmelsrichtung(w.windRichtung) : ''));
      if (w.boeen !== null && w.boeen !== undefined) t.push('Böen ' + dz(w.boeen) + ' ' + windText(einheit));
      if (w.regenMm !== null && w.regenMm !== undefined) t.push('Regen ' + dz(w.regenMm) + ' mm');
      if (w.regenWahrscheinlichkeit !== null && w.regenWahrscheinlichkeit !== undefined) t.push('Regenwahrscheinlichkeit ' + w.regenWahrscheinlichkeit + ' %');
    }
    if (m) {
      if (m.welle !== null && m.welle !== undefined) t.push('Welle ' + dz(m.welle) + ' m');
      if (m.wasserstand !== null && m.wasserstand !== undefined) t.push('Wasserstand ' + dz(m.wasserstand) + ' m' + (m.trend ? ' ' + m.trend : ''));
    }
    return t;
  }

  /*
   * Der Text für den Logbuch-Eintrag „Wetter“. Genannt wird, woher der Wert kommt (Modellwert der Stunde, nicht gemessen).
   * Leer (null), wenn es gar keine Werte gibt.
   */
  function wetterJetztText(w, m, einheit, automatisch) {
    var t = wetterTeile(w, m, einheit);
    if (!t.length) return null;
    return (automatisch ? 'Wetter (automatisch): ' : 'Wetter: ') + t.join(', ') + '. Modellwert der aktuellen Stunde (Open-Meteo), nicht gemessen.';
  }

  /* ---------- Rhythmus der automatischen Abfrage ---------- */
  var RHYTHMEN = [
    { wert: 0, label: 'Aus' },
    { wert: 30, label: 'Alle 30 Minuten' },
    { wert: 60, label: 'Jede Stunde' },
    { wert: 120, label: 'Alle 2 Stunden' },
    { wert: 180, label: 'Alle 3 Stunden' },
    { wert: 360, label: 'Alle 6 Stunden' }
  ];
  function rhythmusGueltig(v) {
    var n = zahl(v);
    if (n === null) return null;
    for (var i = 0; i < RHYTHMEN.length; i++) if (RHYTHMEN[i].wert === n) return n;
    return null;
  }

  var WETTER_ART = 'Wetter';
  function istWetterArt(name) { return String(name || '').trim().toLowerCase() === WETTER_ART.toLowerCase(); }

  function ereignisMs(e) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(e && e.datum || '')), t = /^(\d{2}):(\d{2})/.exec(String(e && e.zeit || ''));
    if (!m) return null;
    return new Date(+m[1], +m[2] - 1, +m[3], t ? +t[1] : 0, t ? +t[2] : 0, 0, 0).getTime();
  }
  /* Wann war der letzte Logbuch-Eintrag „Wetter“ (Millisekunden) oder null. Wird immer aus den Ereignissen gelesen, nie gemerkt. */
  function letztesWetterMs(ereignisse) {
    var letzte = null;
    (ereignisse || []).forEach(function (e) {
      if (!istWetterArt(e.artName)) return;
      var ms = ereignisMs(e);
      if (ms !== null && (letzte === null || ms > letzte)) letzte = ms;
    });
    return letzte;
  }
  /*
   * Ist die automatische Abfrage fällig? minuten: Rhythmus (0 = aus), letzteMs: letzter Eintrag, versuchMs: letzter Versuch (auch ein
   * fehlgeschlagener), damit ohne Netz nicht jede Minute neu gefragt wird (frühestens nach 10 Minuten wieder).
   */
  var NEUER_VERSUCH_MS = 10 * 60 * 1000;
  function wetterFaellig(minuten, letzteMs, versuchMs, jetztMs) {
    if (!(minuten > 0)) return false;
    if (versuchMs !== null && versuchMs !== undefined && jetztMs - versuchMs < NEUER_VERSUCH_MS) return false;
    if (letzteMs === null || letzteMs === undefined) return true;
    return jetztMs - letzteMs >= minuten * 60000;
  }

  /* Die Abfrage für „Wetter jetzt“: Open-Meteo, nur der heutige und der morgige Tag (die Stunde „jetzt“ liegt darin). */
  function wetterJetztUrl(breite, laenge, windEinheit) {
    return MM.Routen.wetterUrl(breite, laenge, windEinheit).replace('forecast_days=16', 'forecast_days=2');
  }
  function meerJetztUrl(breite, laenge) {
    return MM.Routen.marineUrl(breite, laenge).replace('forecast_days=8', 'forecast_days=2');
  }

  /* ---------- Texte für die Karte ---------- */
  function wetterPunktText(zeile, windEinheit) {
    var t = wetterTeile(zeile && zeile.wetter, zeile && zeile.meer, windEinheit);
    if (zeile && zeile.tide) {
      var s = [];
      if (zeile.tide.hoch) s.push('Hochwasser ' + MM.Routen.sekText(zeile.tide.hoch.sek));
      if (zeile.tide.niedrig) s.push('Niedrigwasser ' + MM.Routen.sekText(zeile.tide.niedrig.sek));
      if (s.length) t.push(s.join(', '));
    }
    return t;
  }
  function etaText(ms) { var d = new Date(ms); return z2(d.getHours()) + ':' + z2(d.getMinutes()); }

  MM.Karte = {
    QUELLE: QUELLE, STUFEN: STUFEN, RHYTHMEN: RHYTHMEN, MAX_WEG: MAX_WEG, WETTER_ART: WETTER_ART,
    kachelUrl: kachelUrl, kachelKey: kachelKey, kachelNr: kachelNr, kachelKomma: kachelKomma, korridorKacheln: korridorKacheln, stufeVon: stufeVon,
    grenzen: grenzen, planung: planung, groesseText: groesseText,
    wegNeu: wegNeu, wegPunkt: wegPunkt, wegStuecke: wegStuecke, wegLaengeKm: wegLaengeKm,
    aufRoute: aufRoute, verspaetungMin: verspaetungMin, verspaetungText: verspaetungText,
    wetterTeile: wetterTeile, wetterJetztText: wetterJetztText, wetterPunktText: wetterPunktText, etaText: etaText,
    rhythmusGueltig: rhythmusGueltig, istWetterArt: istWetterArt, letztesWetterMs: letztesWetterMs, wetterFaellig: wetterFaellig,
    wetterJetztUrl: wetterJetztUrl, meerJetztUrl: meerJetztUrl, entfernungKm: entfernungKm
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
