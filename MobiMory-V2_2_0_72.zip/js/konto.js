/*
 * Konto (Schritt 13a, seit 2.0.64): Prüfungen und Texte für die Anmeldung beim MobiMory-Konto-Dienst.
 * Die App arbeitet weiter ohne Konto und ohne Netz. Das Konto ist ein Zusatz.
 * Reine Funktionen, kein Netz, kein Speicher. Das Senden und Speichern steht in daten.js.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var MIN_PASSWORT = 10;
  var MAX_PASSWORT_BYTES = 200;
  var LOESCH_WORT = 'LÖSCHEN';
  /* Feste Adresse des Konto-Dienstes (seit 2.0.68). Eine andere Adresse gibt es nur im Entwickler-Bereich. */
  var STANDARD_DIENST = 'https://konto.mobimory.com';
  /* Die Grenzen je Stufe (Richtwerte, Nutzer 12.11.2026). Der Dienst hat dieselben Zahlen, ein Test vergleicht beide. */
  var STUFEN = {
    basic: { name: 'Basic', geraete: 2, checks: 0, fahrzeuge: 1, online: false },
    test: { name: 'Testwoche', geraete: 4, checks: 1, fahrzeuge: 3, online: true },
    mittel: { name: 'Mittel', geraete: 4, checks: 3, fahrzeuge: 3, online: true },
    voll: { name: 'Voll', geraete: 10, checks: 10, fahrzeuge: null, online: true },
    entwickler: { name: 'Entwickler', geraete: null, checks: null, fahrzeuge: null, online: true }
  };

  /* Die Angebote zum Bezahlen (seit 2.0.72, Festlegung des Nutzers 12.11.2026): nur Jahreszahlung, kein Abo. Cent. Der Dienst hat dieselben Preise, ein Test vergleicht beide. */
  var PRODUKTE = {
    mittel: { name: 'Mittel', cent: 12 * 499, monat: 499, art: 'stufe' },
    voll: { name: 'Voll', cent: 12 * 999, monat: 999, art: 'stufe' },
    recherche5: { name: '5 zusätzliche Online-Recherchen', cent: 999, art: 'checks', anzahl: 5 }
  };

  function text(x) { return x === null || x === undefined ? '' : String(x).trim(); }

  function euro(cent) { return (Math.round(cent) / 100).toFixed(2).replace('.', ',') + ' €'; }

  /* Welche Angebote passen zu dieser Stufe? s kommt von daten.kontoStufe(). Entwickler braucht nichts, Mittel nicht bei laufendem Voll,
     Recherchen nur mit Online-Stufe (Testwoche, Mittel, Voll). */
  function angebote(s) {
    var id = s && s.stufe ? s.stufe.id : '', online = !!(s && s.grenzen && s.grenzen.online), z = [];
    if (id === 'entwickler') return z;
    function stufenText(k) { var g = STUFEN[k]; return 'Bis zu ' + g.geraete + ' Geräte, ' + (g.fahrzeuge === null ? 'beliebig viele Fahrzeuge' : g.fahrzeuge + ' Fahrzeuge') + ', ' + g.checks + ' Online-Checks im Jahr.'; }
    if (id !== 'voll') z.push({ id: 'mittel', titel: 'Mittel für ein Jahr', preis: euro(PRODUKTE.mittel.cent) + ' (12 × ' + euro(PRODUKTE.mittel.monat) + ')', text: stufenText('mittel') });
    z.push({ id: 'voll', titel: 'Voll für ein Jahr', preis: euro(PRODUKTE.voll.cent) + ' (12 × ' + euro(PRODUKTE.voll.monat) + ')', text: stufenText('voll') });
    if (online) z.push({ id: 'recherche5', titel: PRODUKTE.recherche5.name, preis: euro(PRODUKTE.recherche5.cent), text: 'Sie werden benutzt, wenn dein Kontingent aufgebraucht ist. Sie verfallen nicht.' });
    return z;
  }

  function ibanGruppen(iban) { return String(iban || '').replace(/\s+/g, '').replace(/(.{4})/g, '$1 ').trim(); }

  /* Die Angaben zur Überweisung für die Anzeige. r kommt von daten.kontoBestellen(…, 'ueberweisung'). */
  function ueberweisungZeilen(r) {
    var z = ['Bitte überweise ' + r.betrag + ' an:', 'Empfänger: ' + r.empfaenger, 'IBAN: ' + ibanGruppen(r.iban)];
    if (r.bic) z.push('BIC: ' + r.bic);
    z.push('Verwendungszweck: ' + r.verwendungszweck);
    z.push('Bitte genau diesen Verwendungszweck angeben, damit die Zahlung zugeordnet wird. Nach dem Geldeingang wird dein Konto freigeschaltet, du bekommst dann eine E-Mail mit dem Beleg.');
    if (r.mail) z.push('Diese Angaben hast du auch per E-Mail bekommen.');
    return z;
  }

  /* Adresse des Konto-Dienstes: https, mit Punkt im Namen. Nur beim Entwickeln am eigenen Rechner ist http://localhost erlaubt. */
  function dienstAdresse(roh) {
    var t = text(roh);
    if (!t) return { ok: false, fehler: 'Bitte die Adresse des Konto-Dienstes eintragen.' };
    if (/\s/.test(t)) return { ok: false, fehler: 'Die Adresse darf keine Leerzeichen enthalten.' };
    var lokal = /^http:\/\/(localhost|127\.0\.0\.1)(:\d{1,5})?(\/|$)/i.test(t);
    if (!lokal && !/^https:\/\//i.test(t)) return { ok: false, fehler: 'Die Adresse muss mit https:// beginnen.' };
    var m = /^(https?):\/\/([^\/?#]+)([^?#]*)/i.exec(t);
    if (!m || !/^[a-z0-9.\-]+(:\d{1,5})?$/i.test(m[2]) || (!lokal && m[2].indexOf('.') < 0)) return { ok: false, fehler: 'Das ist keine gültige Adresse.' };
    var pfad = m[3].replace(/\/+$/, '').replace(/\/(gesundheit|konto)(\/.*)?$/i, '');
    return { ok: true, url: m[1].toLowerCase() + '://' + m[2].toLowerCase() + pfad };
  }

  function email(roh) {
    var t = text(roh).toLowerCase();
    if (!t) return { ok: false, fehler: 'Bitte die E-Mail-Adresse eintragen.' };
    if (t.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(t)) return { ok: false, fehler: 'Das ist keine gültige E-Mail-Adresse.' };
    return { ok: true, email: t };
  }

  function byteLaenge(s) {
    var n = 0;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c < 0x80) n += 1; else if (c < 0x800) n += 2;
      else if (c >= 0xd800 && c <= 0xdbff) { n += 4; i++; } else n += 3;
    }
    return n;
  }

  /* Das Passwort wird nicht getrimmt: Leerzeichen gehören dazu. */
  function passwort(roh) {
    var p = roh === null || roh === undefined ? '' : String(roh);
    if (!p) return { ok: false, fehler: 'Bitte ein Passwort eintragen.' };
    if (p.length < MIN_PASSWORT) return { ok: false, fehler: 'Das Passwort ist zu kurz. Es braucht mindestens ' + MIN_PASSWORT + ' Zeichen.' };
    if (byteLaenge(p) > MAX_PASSWORT_BYTES) return { ok: false, fehler: 'Das Passwort ist zu lang.' };
    return { ok: true, passwort: p };
  }

  function code(roh) {
    var t = text(roh).replace(/\s+/g, '');
    if (!/^\d{6}$/.test(t)) return { ok: false, fehler: 'Der Code besteht aus sechs Ziffern.' };
    return { ok: true, code: t };
  }

  function loeschWort(roh) {
    return text(roh).toUpperCase() === LOESCH_WORT || text(roh).toUpperCase() === 'LOESCHEN' ? { ok: true } : { ok: false, fehler: 'Zum Löschen bitte das Wort ' + LOESCH_WORT + ' eintippen.' };
  }

  /* Der Dienst schickt seine Fehler als { ok: false, error, feld? }. Das Gerät sagt in einfachen Worten, was los ist. */
  function fehlerText(err) {
    var s = err && err.status, m = err && err.message ? String(err.message) : '';
    if (s === 403) return m && !/App-Adresse/.test(m) ? m : 'Der Dienst lehnt diese App-Adresse ab. Im Dienst muss sie bei ERLAUBTE_URSPRUENGE stehen.';
    if (s === 401 || s === 400 || s === 402 || s === 404 || s === 429 || s === 502 || s === 503) return m || 'Der Dienst hat die Anfrage abgelehnt.';
    if (s) return 'Der Dienst konnte die Anfrage nicht ausführen' + (m ? ': ' + m : '.');
    if (err && err.name === 'AbortError') return 'Der Dienst hat zu lange gebraucht. Versuche es später noch einmal.';
    return 'Keine Verbindung zum Dienst. Prüfe das Netz und die Adresse. Ohne Netz geht das Anmelden nicht, die App selbst läuft weiter.';
  }

  /* Texte zur Stufe für die Konto-Seite. s kommt von daten.kontoStufe(), datum formatiert ein Datum (ms oder Text). */
  function stufeZeilen(s, datum) {
    var st = s.stufe, g = s.grenzen, n = s.nutzung, z = [];
    var fmt = typeof datum === 'function' ? datum : function (x) { return new Date(x).toISOString().slice(0, 10); };
    z.push('Stufe: ' + st.name + (st.bis ? ' (bis ' + fmt(new Date(st.bis).toISOString().slice(0, 10)) + ')' : ''));
    z.push(g.geraete === null ? 'Geräte: ' + n.geraete + ' angemeldet, ohne Grenze.' : 'Geräte: ' + n.geraete + ' von höchstens ' + g.geraete + ' angemeldet.');
    z.push('Fahrzeuge: ' + (g.fahrzeuge === null ? 'unbegrenzt' : 'bis ' + g.fahrzeuge) + '.');
    if (g.online && g.checks === null) z.push('Online-Checks: ' + n.checks + ' benutzt, ohne Grenze.');
    else if (g.online) z.push('Online-Checks: ' + n.checks + ' von ' + g.checks + ' in den letzten 12 Monaten benutzt, ' + n.checksFrei + ' frei. Jeder frische Check zählt, egal welcher. Ein gespeicherter Check zählt nicht.');
    else z.push('Online-Checks: In dieser Stufe nicht dabei. Mit Mittel oder Voll gibt es sie, siehe unten.');
    if (n.extra > 0) z.push('Zusätzliche Recherchen: ' + n.extra + ' übrig. Sie werden benutzt, wenn dein Kontingent aufgebraucht ist.');
    if (st.id === 'test') z.push('Nach der Testwoche bleibt Basic, wenn du nichts wählst. Deine Daten auf dem Gerät bleiben in jedem Fall.');
    return z;
  }

  MM.Konto = {
    STANDARD_DIENST: STANDARD_DIENST, STUFEN: STUFEN, PRODUKTE: PRODUKTE, angebote: angebote, euro: euro, ueberweisungZeilen: ueberweisungZeilen, stufeZeilen: stufeZeilen, MIN_PASSWORT: MIN_PASSWORT, LOESCH_WORT: LOESCH_WORT, GERAET_NAME_MAX: 60,
    dienstAdresse: dienstAdresse, email: email, passwort: passwort, code: code, loeschWort: loeschWort, fehlerText: fehlerText,
    TEXT_BEZAHLEN: 'Du zahlst einmal für ein Jahr. Es ist kein Abo, es wird nichts automatisch abgebucht. Vor dem Ablauf bekommst du eine Erinnerung per E-Mail. Nach jeder Zahlung kommt ein Beleg per E-Mail. Mit PayPal wird sofort freigeschaltet, bei einer Überweisung nach dem Geldeingang. Wenn die Zeit abläuft, bleibt dein Konto auf Basic, deine Daten auf dem Gerät bleiben.',
    TEXT_LOKAL: 'Deine Daten liegen auf diesem Gerät. Ein Konto brauchst du nur, wenn du später auf mehreren Geräten arbeiten, sichern oder teilen willst.',
    TEXT_DATEN: 'Auf dem Server speichert der Dienst deine E-Mail-Adresse, einen Abdruck des Passworts (nie das Passwort selbst) und deinen Datenraum. Beim Abgleich kommen Fahrzeuge, Komponenten, Fristen, Störungen, Aktivitäten, Besatzung, Ereignisse, Zähler und Prüfergebnisse dazu. Nachweise samt Scan, Geburtsdatum, Wohnort, GPS-Spur, Fotos und Notizen bleiben auf deinen Geräten.',
    TEXT_ABGLEICH: 'Hier gleichst du deine Fahrzeugdaten und deine Bilder und Dokumente mit anderen Geräten ab, auf denen du mit demselben Konto angemeldet bist. Geht ein Gerät kaputt, sind die Bilder nicht verloren. Der Abgleich läuft nur, wenn du auf den Knopf tippst. Ohne Netz arbeitest du wie bisher weiter.',
    TEXT_DATEIEN: 'Fotos und Dokumente liegen beim Dienst im Dateispeicher in der EU. Scans von Nachweisen (zum Beispiel Führerschein) gehen nur verschlüsselt mit deinem Schlüsselwort hinaus, der Dienst kann sie nicht lesen. Ohne Schlüsselwort bleiben sie auf diesem Gerät. Dasselbe Schlüsselwort brauchst du auf dem anderen Gerät, um sie zu öffnen. Notizen, Geburtsdatum, Wohnort, die GPS-Spur sowie Nummer und Aussteller der Nachweise bleiben immer auf dem Gerät. Bei der Übergabe eines Fahrzeugs gehen die Bilder nicht mit.',
    TEXT_ABGLEICH_REGELN: 'Wird dieselbe Sache auf zwei Geräten geändert, gilt bei Verläufen der zuletzt gemachte Eintrag, und der frühere bleibt im Verlauf sichtbar. Bei allem anderen gilt der Stand, der zuerst beim Dienst war, deine Fassung wird aufgehoben. Wurde etwas auf einem Gerät gelöscht und auf dem anderen geändert, bleibt es erhalten. Nach einer Wiederherstellung aus einer Sicherung gleicht der nächste Abgleich wieder mit dem Dienst ab, bei Unterschieden gilt dessen Stand.',
    TEXT_SICHERUNG: 'Die Sicherung enthält alle deine Daten auf diesem Gerät, aber ohne Dokumente, Scans und Fotos (die liegen als Dateien auf deinem Konto, siehe Abgleich). Sie wird auf deinem Gerät mit deinem Schlüsselwort verschlüsselt, bevor sie zum Dienst geht. Der Dienst kann sie nicht lesen. Das Schlüsselwort kennt nur du. Vergisst du es, kann niemand die Sicherung öffnen, auch ich nicht.',
    TEXT_ABMELDEN: 'Beim Abmelden bleiben alle Daten auf diesem Gerät. Nur die Verbindung zum Konto wird beendet.'
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
