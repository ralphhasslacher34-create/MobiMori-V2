# Konto-Dienst: Einrichtung und Updates (Stand 2.0.72, Schritt 13e-4)

## Was gerade läuft

| | Echter Dienst | Test-Dienst |
|---|---|---|
| Worker | `mobimory-konto` unter **konto.mobimory.com** | `winter-violet-1a11` |
| Datenbank (D1, EU) | `mobimory-konten` | `mobimory-konten-test` (andere ID, nicht verwechseln) |
| Dateispeicher (R2, EU) | `mobimory-daten` | `mobimory-daten-test` |
| Einstellungen | `wrangler-konto.jsonc` (mit Cron-Auslöser) | `wrangler.jsonc` |
| Tarif | Workers Paid, Email Sending für mobimory.com (3 000 Mails im Monat enthalten) | – |
| Variablen | `ABSENDER` = konto@mobimory.com, `ERLAUBTE_URSPRUENGE` = https://app.mobimory.com | `ENTWICKLUNG` = 1 |
| Geheimnis | `PASSWORT_PEPPER` (nie ändern, anderer Wert als beim Test-Dienst) | eigener Wert |
| Bindungen | `DB`, `DATEN`, `EMAIL` | `DB`, `DATEN` |

- Deploy-Befehl des echten Dienstes: `npx wrangler deploy --config wrangler-konto.jsonc` (Zweig `main`, Root `/`, Build command leer).
- **Die Variable `ENTWICKLUNG` gibt es im echten Dienst nie.**
- Die App läuft unter **app.mobimory.com**. Der Workflow `veroeffentlichen.yml` macht nur noch Tests.
- Beide Dienste bauen aus derselben Datei `konto-dienst.mjs` im Hauptverzeichnis des Repositorys. Wird sie ersetzt, aktualisieren sich beide.

## Update einspielen (immer so)

1. **Neue SQL-Zeilen** (falls die Version welche hat): D1 → Datenbank → **Console**, **jede Zeile einzeln**. Die Zeilen stehen in einer eigenen Datei in `server/` (`13c.sql`, `13d.sql`, `13e.sql`, `13e-3.sql`, `13e-4.sql`).
2. **Dateien ins Hauptverzeichnis des Repositorys** (bei GitHub immer **Upload files**, „Create new file“ legt nur leere Dateien an): `konto-dienst.mjs` und, falls geändert, `wrangler-konto.jsonc`. **Zuerst die alte Datei löschen, dann die neue hochladen** und den Dateinamen prüfen (kein Leerzeichen). Sonst baut Cloudflare weiter aus der alten Datei.
3. Cloudflare baut nach ein bis zwei Minuten selbst (Worker → **Deployments**).
4. **Prüfen:** `konto.mobimory.com/gesundheit` aufrufen. Die Version muss stimmen, alles muss `true` sein, `entwicklung` muss `false` sein.

## Update auf 13e (Stufen, Kontingent, Online-Checks, seit 2.0.69)

1. **Tabellen:** Die 6 Zeilen aus `server/13e.sql` in der D1-Console von `mobimory-konten` ausführen, jede einzeln.
2. **Recherche-Dienst eintragen:** Im Worker `mobimory-konto` unter **Settings → Variables and Secrets**:
   - Typ **Text**: `RECHERCHE_URL` = Adresse des Recherche-Dienstes (`https://mobimory-research….workers.dev`, ohne `/research`).
   - Typ **Secret**: `RECHERCHE_TOKEN` = dasselbe Passwort wie `MOBIMORY_TOKEN` im Recherche-Dienst.
   - Sie bleiben bei jedem Bau erhalten (`keep_vars`).
   - Im **Recherche-Dienst** muss bei `ALLOWED_ORIGINS` `https://app.mobimory.com` stehen.
3. **Ihr Konto auf Entwickler (ohne Grenzen) setzen** (Konten von vor 13e gelten sonst als Basic). In der D1-Console, mit Ihrer Mail-Adresse statt `ihre@adresse`:
   `INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) SELECT id, 'entwickler', NULL, 0 FROM nutzer WHERE email = 'ihre@adresse';`
   Für andere Konten `'mittel'` oder `'voll'` (`'entwickler'` nur für Sie). Ein Ablauf steht in `gueltig_bis` (Millisekunden seit 1970), `NULL` heißt ohne Ablauf.
4. `konto-dienst.mjs` hochladen (Update einspielen, Schritt 2 bis 4). `/gesundheit` muss `"version":"13e-3"`, `"stufen":true` und `"recherche":true` zeigen.
5. App (ZIP) hochladen, am Tablet neu laden, unter Reisecheck › Zustimmung einmal neu zustimmen.

Der Test-Dienst baut dieselbe Datei. Seine Datenbank hat die 13e-Tabellen nur, wenn Sie die 6 Zeilen dort auch ausführen. Ohne sie funktioniert dort das Anmelden weiter, Online-Checks und Stufen nicht.

Wie es arbeitet:
- Die App spricht nur mit `konto.mobimory.com`. Der Dienst prüft Stufe und Kontingent, zählt und ruft den Recherche-Dienst auf. Dessen Passwort kennt nur der Konto-Dienst.
- Testwoche: 7 Tage, 1 Check, einmal je Mail-Adresse. Danach Basic.
- Stufen und Grenzen stehen in `server/konto-dienst.mjs` (`STUFEN`) und `js/konto.js`. Ein Test vergleicht beide.

## Update auf 13e-3 (Kosten-Wächter, seit 2.0.71)

1. **Tabelle:** Die eine Zeile aus `server/13e-3.sql` in der D1-Console von `mobimory-konten` ausführen.
2. **Variable für den Empfänger:** Im Worker `mobimory-konto` unter **Settings → Variables and Secrets** Typ **Text**: `WAECHTER_EMAIL` = Ihre Mail-Adresse. Ohne sie wird nur geprüft, es kommt keine Mail.
3. **Kosten je Check eintragen:** Typ **Text** `KOSTEN_CHECK` = der echte Wert aus der OpenAI-Abrechnung in Euro (zum Beispiel `0,40`). Ohne die Variable rechnet der Wächter mit 0,45 € und schreibt „Schätzwert“ in die Mail.
4. **Eigene Test-Konten und geschenkte Voll-Konten ausnehmen:** Typ **Text** `WAECHTER_AUSGENOMMEN` = Mail-Adressen, durch Komma getrennt. Diese Konten zählen weder als Testwochen-Kosten noch als Einnahmen. Das Entwickler-Konto ist immer ausgenommen.
5. **Dateien hochladen** (Update einspielen, Schritt 2 bis 4): `konto-dienst.mjs` und **`wrangler-konto.jsonc`** (sie enthält jetzt den Cron-Auslöser `*/15 * * * *`).
6. **Prüfen:** `/gesundheit` zeigt `"version":"13e-3"` und `"waechter":true`. Im Worker unter **Settings → Triggers** steht der Cron-Auslöser alle 15 Minuten, unter **Logs** erscheint alle 15 Minuten eine Zeile „Kosten-Wächter: geprüft=true …“.

Weitere Variablen (alle freiwillig, die Standardwerte stehen in Klammern): `WAECHTER_ANTEIL` (0,2 = 20 %), `WAECHTER_TAGE` (30), `WAECHTER_CHECKS_TAG` (10), `WAECHTER_TESTWOCHEN_TAG` (5). Ein ungültiger Wert fällt still auf den Standard zurück.

Wie er arbeitet:
- Mit Einnahmen (seit 2.0.72 die echten Belege der letzten 365 Tage durch 12) warnt er, wenn die Testwochen-Kosten über 20 % der Einnahmen liegen. Ohne Einnahmen warnt er bei mehr als 10 Testwochen-Checks in 24 Stunden. Immer warnt er bei mehr als 5 neuen Testwochen in 24 Stunden.
- Nach einer Mail kommt höchstens eine weitere pro Stunde. Die Mail nennt nur Zahlen und den Zeitraum.
- Geschenkte Konten haben keinen Beleg und zählen deshalb nicht als Einnahme. Eigene Test-Konten trotzdem in `WAECHTER_AUSGENOMMEN` eintragen (wegen der Testwochen-Kosten).
- **Zusätzlich, ohne Programm:** Bei OpenAI unter „Billing“ oder „Limits“ eine Obergrenze für die Monatskosten setzen. Das ist der härteste Schutz und greift auch bei Fehlern im Dienst.

## Update auf 13e-4 (Bezahlung, seit 2.0.72)

Reihenfolge: erst Tabellen, dann Variablen, dann Dateien, dann prüfen. **Zuerst nur mit PayPal-Sandbox (Testgeld) ausprobieren, erst danach auf echtes Geld umstellen.**

1. **Tabellen:** Die 6 Zeilen aus `server/13e-4.sql` in der D1-Console von `mobimory-konten` ausführen, jede einzeln.
2. **Variablen** im Worker `mobimory-konto` unter **Settings → Variables and Secrets**, Typ **Text**:
   - `UEBERWEISUNG_INHABER` = Name des Kontoinhabers, `UEBERWEISUNG_IBAN` = Ihre IBAN, freiwillig `UEBERWEISUNG_BIC`.
   - `BELEG_ANSCHRIFT` = Ihr Name und Ihre Anschrift für den Beleg, in einer Zeile mit Komma (zum Beispiel `Ralph Hasslacher, Straße Nr., 74372 Sersheim`). Vom Steuerberater prüfen lassen.
   - Freiwillig `BELEG_KOPIE` = Ihre Mail-Adresse (Sie bekommen jeden Beleg in Kopie).
3. **Geheimnis** (Typ **Secret**): `FREISCHALT_TOKEN` = ein langes zufälliges Passwort (mindestens 20 Zeichen). Damit melden Sie sich auf der Freischalt-Seite an. Nicht in eine Datei oder einen Chat schreiben.
4. **PayPal-Sandbox (Test):** Bei developer.paypal.com anmelden, **Apps & Credentials**, oben **Sandbox**, eine App anlegen. Dort stehen **Client ID** und **Secret**. Im Worker: `PAYPAL_CLIENT_ID` (Typ Text) und `PAYPAL_SECRET` (Typ **Secret**). `PAYPAL_LIVE` **nicht** setzen: Dann geht der Dienst an die Sandbox. Zum Bezahlen ein Sandbox-Käuferkonto nehmen (developer.paypal.com → Testing tools → Sandbox accounts).
5. **Dateien hochladen** (Update einspielen, Schritt 2 bis 4): `konto-dienst.mjs`. Die Datei `wrangler-konto.jsonc` ist unverändert.
6. **Prüfen:** `/gesundheit` zeigt `"version":"13e-4"` und bei `bezahlung` alles `true`; `paypalEchtgeld` muss im Test `false` sein.
7. **Sandbox-Test:** In der App unter Konto › Stufe wählen › Mit PayPal bezahlen, mit dem Sandbox-Käuferkonto zahlen, zurück zur App: Die Stufe steht auf Mittel. Eine Mail mit dem Beleg kommt an. Außerdem Überweisung ausprobieren: Angaben kommen per Mail, auf `https://konto.mobimory.com/freischalten` (Passwort = `FREISCHALT_TOKEN`) erscheint die Bestellung, „Geld ist da: freischalten“.
8. **Auf echtes Geld umstellen** (erst wenn das PayPal-Businesskonto fertig ist): Bei developer.paypal.com oben auf **Live** wechseln, die Live-App anlegen, `PAYPAL_CLIENT_ID` und `PAYPAL_SECRET` durch die Live-Werte ersetzen und `PAYPAL_LIVE` = `1` setzen (Typ Text). `/gesundheit` zeigt dann `"paypalEchtgeld":true`. Einen ersten Echt-Kauf mit 9,99 € selbst machen (und über PayPal zurückbuchen).

Die Variablen `PREIS_MITTEL` und `PREIS_VOLL` werden nicht mehr gebraucht und dürfen im Worker gelöscht werden.

Wie es arbeitet:
- Der Dienst schaltet nur frei, wenn PayPal die Zahlung **abgeschlossen** meldet und Betrag und Währung stimmen. Zahlungsdaten speichert er nie. Je Zahlung bleibt eine Zeile in der Tabelle `beleg` (Buchhaltung), auch wenn das Konto gelöscht wird.
- Freischalten von Hand (Überweisung) nur auf der Seite `/freischalten`. Wer das Passwort acht Mal falsch eingibt, wird 15 Minuten gesperrt.
- Die Erinnerungen (30 und 7 Tage vor dem Ablauf) verschickt der Cron-Auslöser mit, in den Logs steht „Erinnerungen: gesendet=…“.
- Preise stehen in `server/konto-dienst.mjs` (`PRODUKTE`) und `js/konto.js`. Ein Test vergleicht beide.
- Offen: Löschung der Serverdaten 12 Monate nach Ablauf, Erstattungen von Hand (PayPal-Konto, danach Stufe per SQL zurücksetzen).

## Hinweise

- **Geheimnis:** `PASSWORT_PEPPER` gehört nie in eine Datei, nie in GitHub und nie in einen Chat. Ohne ihn passt kein Passwort mehr.
- **Passwort-Abdruck:** Cloudflare erlaubt höchstens 100 000 Runden, OWASP empfiehlt 600 000. Gehört auf die Liste für den Datenschutz-Fachmann vor dem öffentlichen Start.
- **Wenn etwas schiefgeht:** Worker → **Logs**. Die Meldung abschreiben.
- **Neu von Null** (nur falls je nötig): `server/schema.sql` enthält alle Tabellen, die Einstellungen stehen in `wrangler-konto.jsonc`. Datenbank und Bucket nur beim Anlegen mit Jurisdiktion **EU**.
