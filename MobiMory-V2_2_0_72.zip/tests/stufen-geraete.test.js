'use strict';
/* 2.0.68 (Schritt 13e): Das Gerät gegen den Dienst. Online-Checks laufen über das Konto, gezählt wird auf dem Server, gespeicherte Checks zählen nicht,
   Gerätekennung, Stufe auf dem Gerät, Direktverbindung nur im Entwickler-Modus, Oberfläche ohne Passwortfeld. Der Recherche-Dienst ist ein Platzhalter. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'reisecheck', 'grundcheck', 'konto', 'daten']
  .forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

const APP = 'https://app.example.org';
const TAG = 24 * 60 * 60 * 1000;
const JETZT = new Date(2026, 10, 5, 12, 0, 0).toISOString();
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
const ANF = (x) => Object.assign({ id: 'r1', area: 'Papiere', category: 'Pflicht', subjectKey: 'P1', subjectType: 'Person', trafficMode: 'Wasser', requirement: 'Führerschein für P1', proofKey: 'FS',
  status: 'Erfüllt', evidence: 'P1 hat Führerschein', explanation: 'passt', confidence: 'hoch', conflict: false, sources: [{ title: 'Amt', url: 'https://amt.example/x', publisher: 'Amt', official: true, updated: '' }] }, x || {});
const ANTWORT = { ok: true, model: 'm1', requestId: 'q1', researchedAt: '2026-11-05T11:00:00Z', result: { summary: 'Fertig', researchStatus: 'vollständig', warnings: [], route: { routingStatus: 'plausibel', summary: '', assumptions: [], routeWarnings: [] }, requirements: [ANF(), ANF({ id: 'r2', subjectKey: 'A1', requirement: 'Impfung für A1', status: 'Fehlt' })] } };

function recherche() {
  const r = { aufrufe: [] };
  r.fetch = async (url, opt) => { r.aufrufe.push({ url, token: opt.headers['X-Mobimory-Token'], body: JSON.parse(opt.body) }); return new Response(JSON.stringify(ANTWORT), { status: 200 }); };
  return r;
}
function umgebung(extra) {
  return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1',
    RECHERCHE_URL: 'https://recherche.example.org', RECHERCHE_TOKEN: 'geheim-token-1' }, extra || {});
}
function uhr() { const u = { t: Date.UTC(2026, 10, 5, 12, 0, 0) }; u.jetzt = () => u.t; return u; }

/* Ein Gerät mit vollständigem Datenbestand (Boot, Besatzung, Aktivität) und der Verbindung zum Konto-Dienst in diesem Prozess. */
async function geraet(env, u, rc, opt) {
  const o = opt || {};
  const d0 = await laden();
  const f = async (url, methode, token, body) => {
    const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.7' };
    if (body !== undefined && body !== null) kopf['Content-Type'] = 'application/json';
    if (token) kopf.Authorization = 'Bearer ' + token;
    const r = await d0.behandeln(new Request(url, { method: methode, headers: kopf, body: body === undefined || body === null ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt, fetch: rc.fetch });
    const j = await r.json();
    if (!r.ok) { const e = new Error(j.error); e.status = r.status; e.feld = j.feld; throw e; }
    return j;
  };
  const gesendet = [];
  let n = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), {
    jetzt: () => new Date(new Date(JETZT).getTime() + (n++) * 1000).toISOString(), kontoAnfrage: f,
    holeJson: async () => ({ ok: true, configured: true, model: 'm1' }),
    sendeJson: async (url, token, body) => { gesendet.push({ url, token, body }); return ANTWORT; }
  });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Seeschwalbe', marke: 'Bavaria', laenge: '9,5', registriernummer: 'KN-1234' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const fsa = (await d.nachweisartAusVorschlag('DE_FEV_FUEHRERSCHEIN_EU')).id;
  await d.nachweisAnlegen('person', anna, fsa, { nummer: 'GEHEIM-1', gueltigBis: '2030-01-01' });
  const gebiet = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = arten.find((a) => a.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const akt = await d.aktivitaetAnlegen({ bezeichnung: 'Sommertörn', artId, fahrzeugId: boot, vonDatum: '2026-11-10', bisDatum: '2026-11-17', verantwortlichId: anna, gebietId: gebiet });
  assert.equal(akt.ok, true, JSON.stringify(akt));
  return { d, id: akt.id, boot, gesendet };
}
async function anmelden(c, email) {
  const a = await c.d.kontoCodeAnfordern({ email });
  assert.equal(a.ok, true, JSON.stringify(a));
  const b = await c.d.kontoCodePruefen({ email, code: a.entwicklungsCode });
  assert.equal(b.ok, true, JSON.stringify(b));
}
function stufeSetzen(env, email, stufe) {
  const x = env.DB.roh.prepare('SELECT id FROM nutzer WHERE email = ?').get(email);
  env.DB.roh.prepare('INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) VALUES (?, ?, NULL, 1)').run(x.id, stufe);
}

test('Online-Check über das Konto: Der Dienst zählt, der Recherche-Dienst wird vom Konto-Dienst gerufen, das Gerät kennt dessen Passwort nie', async () => {
  const env = umgebung(), u = uhr(), rc = recherche();
  const c = await geraet(env, u, rc);
  await anmelden(c, 'ralph@example.org');
  const cfg = await c.d.reisecheckEinstellung();
  assert.equal(cfg.ueberKonto, true); assert.equal(cfg.bereit, true); assert.equal(cfg.eingerichtet, false); assert.equal(cfg.direkt, false);
  assert.equal(MM.Reisecheck.ZUSTIMMUNG_VERSION, 2);
  assert.equal((await c.d.reisecheckZustimmen()).ok, true);
  const r = await c.d.reisecheckStarten(c.id);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(rc.aufrufe.length, 1); assert.equal(rc.aufrufe[0].url, 'https://recherche.example.org/research'); assert.equal(rc.aufrufe[0].token, 'geheim-token-1');
  assert.equal(c.gesendet.length, 0, 'nichts geht direkt vom Gerät an den Recherche-Dienst');
  const rec = (await c.d.reisecheckLaden(r.id)).check;
  assert.equal(rec.gespeichert, undefined); assert.equal(rec.ergebnis.zusammenfassung, 'Fertig');
  /* Kontingent der Testwoche (1) ist verbraucht: der zweite frische Check kommt mit der Meldung des Dienstes zurück und kostet nichts */
  const zwei = await c.d.reisecheckStarten(c.id);
  assert.equal(zwei.ok, false); assert.equal(zwei.art, 'kontingent'); assert.match(zwei.fehler.allgemein, /1 von 1 Online-Checks/);
  assert.equal(rc.aufrufe.length, 1);
  assert.equal((await c.d.reisecheckListe(c.id)).length, 1);
  const st = await c.d.kontoStufe();
  assert.equal(st.ok, true); assert.equal(st.stufe.id, 'test'); assert.equal(st.nutzung.checks, 1); assert.equal(st.nutzung.checksFrei, 0);
  const zeilen = MM.Konto.stufeZeilen(st, MM.Hilfen.datum);
  assert.match(zeilen[0], /Stufe: Testwoche \(bis /); assert.match(zeilen.join('\n'), /1 von 1 in den letzten 12 Monaten benutzt, 0 frei/); assert.match(zeilen.join('\n'), /Geräte: 1 von höchstens 4/);
});

test('Gespeicherter Check: kommt vom Dienst, zählt nicht, trägt Stand und Hinweis; ohne Treffer klare Meldung', async () => {
  const env = umgebung(), u = uhr(), rc = recherche();
  const c = await geraet(env, u, rc);
  await anmelden(c, 'ralph@example.org');
  await c.d.reisecheckZustimmen();
  stufeSetzen(env, 'ralph@example.org', 'mittel');
  const nix = await c.d.reisecheckStarten(c.id, null, { quelle: 'gespeichert' });
  assert.equal(nix.ok, false); assert.equal(nix.art, 'nichtgespeichert'); assert.match(nix.fehler.allgemein, /noch keinen gespeicherten Check/);
  assert.equal((await c.d.reisecheckStarten(c.id)).ok, true);
  u.t += 2 * TAG;
  const g = await c.d.reisecheckStarten(c.id, null, { quelle: 'gespeichert' });
  assert.equal(g.ok, true, JSON.stringify(g));
  const rec = (await c.d.reisecheckLaden(g.id)).check;
  assert.equal(rec.gespeichert, true); assert.match(rec.gespeichertStand, /^2026-11-05T/);
  assert.equal(rc.aufrufe.length, 1, 'der gespeicherte Check ruft die Recherche nicht auf');
  assert.equal((await c.d.kontoStufe()).nutzung.checks, 1, 'und zählt nicht');
  const ansicht = lesen('js/ansicht.js');
  assert.match(ansicht, /Das ist ein gespeicherter Check/); assert.match(ansicht, /Gespeicherten Check holen \(zählt nicht\)/);
});

test('Grundcheck und Tagcheck über das Konto zählen genauso (jeder Online-Check zählt, egal welcher)', async () => {
  const env = umgebung(), u = uhr(), rc = recherche();
  const c = await geraet(env, u, rc);
  await anmelden(c, 'ralph@example.org');
  await c.d.reisecheckZustimmen();
  stufeSetzen(env, 'ralph@example.org', 'mittel');
  const g = await c.d.grundcheckStarten(c.boot);
  if (g.ok === false && g.art === 'daten') { assert.ok(true, 'Heimatstandort fehlt in diesem Datenbestand: kein Aufruf'); assert.equal(rc.aufrufe.length, 0); return; }
  assert.equal(g.ok, true, JSON.stringify(g));
  assert.equal((await c.d.kontoStufe()).nutzung.checks, 1);
});

test('Ohne Konto kein Online-Check; ohne Zustimmung auch nicht; die Zustimmung braucht Konto oder Direktverbindung', async () => {
  const env = umgebung(), u = uhr(), rc = recherche();
  const c = await geraet(env, u, rc);
  const z = await c.d.reisecheckZustimmen();
  assert.equal(z.ok, false); assert.match(z.fehler.allgemein, /Konto/);
  const r = await c.d.reisecheckStarten(c.id);
  assert.equal(r.ok, false); assert.equal(r.art, 'einrichtung'); assert.match(r.fehler.allgemein, /MobiMory-Konto/);
  await anmelden(c, 'ralph@example.org');
  const ohne = await c.d.reisecheckStarten(c.id);
  assert.equal(ohne.ok, false); assert.equal(ohne.art, 'zustimmung');
  assert.equal(rc.aufrufe.length, 0); assert.equal(c.gesendet.length, 0);
  /* abgemeldet: wieder kein Check */
  await c.d.kontoAbmelden();
  assert.equal((await c.d.reisecheckStarten(c.id)).art, 'einrichtung');
});

test('Direktverbindung gibt es nur im Entwickler-Modus: gespeicherte Adresse und Passwort allein reichen nicht, ausschalten geht, gespeicherte Checks nur über das Konto', async () => {
  const env = umgebung(), u = uhr(), rc = recherche();
  const c = await geraet(env, u, rc);
  assert.equal((await c.d.reisecheckEinrichten({ dienstUrl: 'https://dienst.example.dev', passwort: 'geheim1234' })).ok, true);
  let cfg = await c.d.reisecheckEinstellung();
  assert.equal(cfg.entwickler, true); assert.equal(cfg.direkt, true); assert.equal(cfg.bereit, true);
  assert.equal((await c.d.reisecheckZustimmen()).ok, true);
  const r = await c.d.reisecheckStarten(c.id);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(c.gesendet.length, 1); assert.equal(rc.aufrufe.length, 0, 'direkt: nicht über den Konto-Dienst, nicht gezählt');
  const g = await c.d.reisecheckStarten(c.id, null, { quelle: 'gespeichert' });
  assert.equal(g.ok, false); assert.match(g.fehler.allgemein, /nur über das Konto/);
  await c.d.reisecheckDirektAus();
  cfg = await c.d.reisecheckEinstellung();
  assert.equal(cfg.direkt, false); assert.equal(cfg.bereit, false); assert.equal(cfg.hatPasswort, true, 'Adresse und Passwort bleiben gespeichert');
  const nach = await c.d.reisecheckStarten(c.id);
  assert.equal(nach.ok, false); assert.equal(nach.art, 'einrichtung');
  assert.equal(c.gesendet.length, 1);
  /* ein Gerät mit alter Einrichtung (Adresse und Passwort aus der Zeit vor 2.0.68, ohne Entwickler-Modus) geht nicht an der Zählung vorbei */
  const alt = await geraet(env, u, rc);
  await alt.d.rcSchreiben({ reisecheckDienstUrl: 'https://dienst.example.dev', reisecheckToken: 'geheim1234' });
  const ac = await alt.d.reisecheckEinstellung();
  assert.equal(ac.direkt, false); assert.equal(ac.eingerichtet, false); assert.equal(ac.bereit, false);
  await anmelden(alt, 'alt@example.org'); await alt.d.reisecheckZustimmen();
  assert.equal((await alt.d.reisecheckStarten(alt.id)).ok, true);
  assert.equal(alt.gesendet.length, 0); assert.equal(rc.aufrufe.length, 1, 'der Check ging über den Konto-Dienst und wurde gezählt');
});

test('Gerätekennung: Jedes Gerät hat eine zufällige Kennung, die bleibt; erneutes Anmelden ersetzt die Sitzung, ein zweites Gerät zählt extra', async () => {
  const env = umgebung(), u = uhr(), rc = recherche();
  const a = await geraet(env, u, rc), b = await geraet(env, u, rc);
  const na = await a.d.kontoGeraetName(), nb = await b.d.kontoGeraetName();
  assert.match(na, /^MobiMory 2\.0\.72 #[a-f0-9]{8}$/); assert.match(nb, /^MobiMory 2\.0\.72 #[a-f0-9]{8}$/);
  assert.notEqual(na, nb); assert.equal(await a.d.kontoGeraetName(), na, 'die Kennung bleibt');
  await anmelden(a, 'ralph@example.org');
  await anmelden(b, 'ralph@example.org');
  u.t += 2 * TAG;
  await anmelden(a, 'ralph@example.org');
  const zeilen = env.DB.roh.prepare('SELECT geraet FROM sitzung').all().map((x) => x.geraet).sort();
  assert.equal(zeilen.length, 2, 'zwei Geräte, auch nach dem erneuten Anmelden');
  assert.deepEqual(zeilen, [na, nb].sort());
  assert.ok(!JSON.stringify(await a.d.rcGeraet()).includes('geheim'));
});

test('Geräte-Grenze auf dem Gerät: Das fünfte Gerät bekommt die Meldung des Dienstes in einfachen Worten', async () => {
  const env = umgebung(), u = uhr(), rc = recherche();
  for (let i = 0; i < 4; i++) { const c = await geraet(env, u, rc); await anmelden(c, 'viele@example.org'); u.t += 14 * 60 * 1000; }
  const f = await geraet(env, u, rc);
  const a = await f.d.kontoCodeAnfordern({ email: 'viele@example.org' });
  const b = await f.d.kontoCodePruefen({ email: 'viele@example.org', code: a.entwicklungsCode });
  assert.equal(b.ok, false); assert.match(b.fehler.allgemein, /Stufe Testwoche sind höchstens 4 Geräte erlaubt/);
  assert.equal((await f.d.kontoEinstellung()).angemeldet, false);
});

test('Stufen: Die Zahlen in der App und im Dienst sind gleich; Basic, Test, Mittel und Voll wie festgelegt', async () => {
  const d = await laden();
  assert.deepEqual(MM.Konto.STUFEN, d.STUFEN);
  assert.deepEqual(MM.Konto.STUFEN.basic, { name: 'Basic', geraete: 2, checks: 0, fahrzeuge: 1, online: false });
  assert.deepEqual(MM.Konto.STUFEN.mittel, { name: 'Mittel', geraete: 4, checks: 3, fahrzeuge: 3, online: true });
  assert.deepEqual(MM.Konto.STUFEN.voll, { name: 'Voll', geraete: 10, checks: 10, fahrzeuge: null, online: true });
  assert.equal(MM.Konto.STUFEN.test.checks, 1); assert.equal(d.TESTWOCHE_TAGE, 7); assert.equal(d.CHECK_ZEITRAUM_TAGE, 365);
});

test('Oberfläche: Konto nur mit Code (kein Passwortfeld), Dienst-Adressen nur im Entwickler-Bereich, alte Hinweise weg', () => {
  const a = lesen('js/ansicht.js');
  const von = a.indexOf('  function seiteKonto() {'), bis = a.indexOf('/* ---------- Reisecheck (seit 2.0.38', von);
  const konto = a.slice(von, bis);
  ['ko-pw-a', 'ko-pw-r', 'ko-pw-neu', 'Anmelden mit Passwort', 'Neues Konto mit Passwort', 'Passwort setzen oder ändern', 'ko-url', 'workers.dev'].forEach((x) => assert.ok(!konto.includes(x), x));
  assert.match(konto, /Anmelden mit Code|Code schicken/); assert.match(konto, /stufeKasten\(\)/);
  const ent = a.slice(a.indexOf('  function seiteEntwickler() {'), von === -1 ? undefined : a.indexOf('  function seiteKonto() {'));
  assert.match(ent, /ko-url/); assert.match(ent, /reisecheck\/dienst\/direkt/);
  assert.match(a, /teile\[0\] === 'entwickler'\) p = seiteEntwickler\(\)/); assert.match(a, /kachel\('Entwickler'/);
  /* Reisecheck: Adresse und Passwort nur mit Entwickler-Modus oder über den Entwickler-Bereich */
  const dienst = a.slice(a.indexOf('  function seiteReisecheckDienst('), a.indexOf('  var meldungRc'));
  assert.match(dienst, /zeigeFelder/); assert.match(dienst, /!zeigeFelder \? null/);
  ['Der Dienst ist noch nicht eingerichtet', 'Dienst einrichten'].forEach((x) => assert.ok(!a.includes(x), x));
  /* Standard-Adresse */
  assert.equal(MM.Konto.STANDARD_DIENST, 'https://konto.mobimory.com');
  assert.ok(!lesen('js/ansicht.js').includes('Zurzeit zählt er nicht'));
});

test('Stufe Entwickler auf dem Gerät: Texte „ohne Grenze“, Stufe in App und Dienst gleich', async () => {
  const d = await laden();
  assert.deepEqual(MM.Konto.STUFEN.entwickler, d.STUFEN.entwickler);
  assert.deepEqual(MM.Konto.STUFEN.entwickler, { name: 'Entwickler', geraete: null, checks: null, fahrzeuge: null, online: true });
  const env = umgebung(), u = uhr(), rc = recherche();
  const c = await geraet(env, u, rc);
  await anmelden(c, 'ralph@example.org');
  stufeSetzen(env, 'ralph@example.org', 'entwickler');
  await c.d.reisecheckZustimmen();
  assert.equal((await c.d.reisecheckStarten(c.id)).ok, true);
  const st = await c.d.kontoStufe();
  const z = MM.Konto.stufeZeilen(st, MM.Hilfen.datum).join('\n');
  assert.match(z, /Stufe: Entwickler/); assert.match(z, /Geräte: 1 angemeldet, ohne Grenze/); assert.match(z, /Online-Checks: 1 benutzt, ohne Grenze/); assert.match(z, /Fahrzeuge: unbegrenzt/);
});
