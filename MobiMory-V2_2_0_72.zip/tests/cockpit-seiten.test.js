'use strict';
/* 2.0.61: Wechselfeld mit ETA, Rest und Gefahren, Umschalter km und sm, Cockpit in Seiten, Knöpfe Logbuch und Hauptmenü in der Kopfzeile. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'texte', 'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'fahrt', 'reisecheck', 'karte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM, F = MM.Fahrt;
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const ansicht = lesen('js/ansicht.js');
function funktion(name) {
  const start = ansicht.indexOf('  function ' + name + '(');
  assert.ok(start >= 0, 'Funktion fehlt: ' + name);
  return ansicht.slice(start, ansicht.indexOf('\n  }\n', start));
}

const JETZT = new Date(2026, 10, 9, 10, 0, 0).getTime();
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(JETZT + (t++) * 1000).toISOString() });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil', reisegeschwindigkeit: '80', hoechstgeschwindigkeit: '120' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'] })).id;
  const art = (await d.aktivitaetsartenListe()).find(a => a.aktuell.werte.bezeichnung === 'Urlaub').objekt.id;
  const s = (await d.ortAnlegen({ bezeichnung: 'Stuttgart', positionBreite: '48,78', positionLaenge: '9,18' })).id;
  const z = (await d.ortAnlegen({ bezeichnung: 'München', positionBreite: '48,14', positionLaenge: '11,58' })).id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Tagesreise', artId: art, fahrzeugId: fz, vonDatum: '2026-11-09', vonZeit: '08:00', bisDatum: '2026-11-09', verantwortlichId: anna, startOrtId: s, zielOrtId: z });
  assert.equal(r.ok, true, JSON.stringify(r));
  await d.tagesabschnitteVorbereiten(r.id);
  const tag = (await d.logbuchLaden(r.id)).abschnitte[0].objekt.id;
  return { d, akt: r.id, tag, fz };
}

/* ---------- 1. Wechselfeld ---------- */
test('Wechselfeld: nur die Geschwindigkeiten, ETA, Rest und Gefahren sind feste Kennzahlen auf Seite 1', () => {
  assert.deepEqual(F.MODI, ['aktuell', 'fahrend', 'tag']);
  let m = 'aktuell'; const reihe = [];
  for (let i = 0; i < 4; i++) { reihe.push(m); m = F.naechsterModus(m); }
  assert.deepEqual(reihe, ['aktuell', 'fahrend', 'tag', 'aktuell']);
  const f = funktion('cockpitVollbild');
  const s1 = f.slice(f.indexOf('var seite1'), f.indexOf('var seite2'));
  assert.ok(s1.includes('kennzahlen'));
  assert.match(f, /var kennzahlen = kennzahlenBauen\(\);/);
  const kb = funktion('kennzahlenBauen');
  assert.ok(kb.includes("['eta', 'ETA']") && kb.includes("['rest', 'Rest']") && kb.includes("['gefahren', 'Gefahren']"));
  assert.match(funktion('tempoAktualisieren'), /kennzahlenAktualisieren\(\)/);
  assert.match(funktion('kennzahlenAktualisieren'), /einheit: anzeigeEinheit/);
  assert.match(lesen('css/styles.css'), /\.cv-kennzahlen \{[^}]*repeat\(3/);
});
test('Wechselfeld: Namen und Werte von ETA, Rest und Gefahren', () => {
  const w = { aktuellKmh: 18.52, fahrendKmh: null, tagKmh: 40, km: 37.04, gestartet: true };
  const etaMs = new Date(2026, 10, 9, 14, 5).getTime();
  const e = { eta: { ok: true, etaMs, fahrzeitMin: 90 }, restKm: 18.52 };
  assert.deepEqual(F.anzeige(w, 'land', 'eta', { einheit: 'km', eta: e, jetztMs: JETZT }), { name: 'ETA', wert: '14:05 Uhr' });
  assert.deepEqual(F.anzeige(w, 'land', 'rest', { einheit: 'km', eta: e }), { name: 'Rest', wert: '18,5 km' });
  assert.deepEqual(F.anzeige(w, 'land', 'rest', { einheit: 'sm', eta: e }), { name: 'Rest', wert: '10,0 sm' });
  assert.deepEqual(F.anzeige(w, 'land', 'gefahren', { einheit: 'km' }), { name: 'Gefahren', wert: '37,0 km' });
  assert.deepEqual(F.anzeige(w, 'land', 'gefahren', { einheit: 'sm' }), { name: 'Gefahren', wert: '20,0 sm' });
});
test('Wechselfeld: ETA an einem anderen Tag nennt das Datum, ohne Uhrzeit des Beginns steht die Fahrzeit', () => {
  const w = { gestartet: false, km: 0 };
  const morgen = new Date(2026, 10, 10, 6, 30).getTime();
  assert.equal(F.anzeige(w, 'land', 'eta', { einheit: 'km', eta: { eta: { ok: true, etaMs: morgen, fahrzeitMin: 600 } }, jetztMs: JETZT }).wert, '10.11. 06:30 Uhr');
  assert.equal(F.anzeige(w, 'land', 'eta', { einheit: 'km', eta: { eta: { ok: true, etaMs: null, fahrzeitMin: 130 } } }).wert, '2 h 10 min Fahrzeit');
});
test('Wechselfeld: ohne Ziel, ohne Position oder ohne Start steht „–“', () => {
  const w = { aktuellKmh: null, fahrendKmh: null, tagKmh: null, km: 0, gestartet: false };
  ['aktuell', 'fahrend', 'tag', 'eta', 'rest', 'gefahren'].forEach(m => assert.equal(F.anzeige(w, 'land', m, { einheit: 'km' }).wert, '–', m));
  assert.equal(F.anzeige(w, 'land', 'eta', { einheit: 'km', eta: { eta: { ok: false, grund: 'x' }, restKm: null } }).wert, '–');
  assert.equal(F.anzeige(w, 'land', 'rest', { einheit: 'km', eta: { eta: { ok: true, etaMs: 1, fahrzeitMin: 1 }, restKm: null } }).wert, '–');
});
test('Wechselfeld: Gefahren ist der zurückgelegte Weg seit Start des Tages (MM.Fahrt)', () => {
  const fix = (t, breite) => ({ breite, laenge: 9, genauigkeit: 5, zeitMs: JETZT + t * 1000, geschwindigkeit: null });
  let f = F.neu();
  for (let t = 0; t <= 300; t += 10) f = F.punkt(f, fix(t, 48 + t * 0.00015), 'land', true);
  const w = F.werte(f, JETZT + 300 * 1000);
  assert.ok(w.gestartet && w.km > 4, 'km ' + w.km);
  assert.equal(F.anzeige(w, 'land', 'gefahren', { einheit: 'km' }).wert, F.streckeEinheitText(w.km, 'km'));
});

/* ---------- 2. Umschalter km und sm ---------- */
test('Einheit: nur km oder sm, erster Start km, ein Tipp wechselt', () => {
  assert.equal(F.EINHEIT_STANDARD, 'km');
  assert.equal(F.einheitGueltig('km'), 'km'); assert.equal(F.einheitGueltig('sm'), 'sm');
  ['kn', 'KM', '', null, undefined, 5].forEach(x => assert.equal(F.einheitGueltig(x), null));
  assert.equal(F.naechsteEinheit('km'), 'sm'); assert.equal(F.naechsteEinheit('sm'), 'km'); assert.equal(F.naechsteEinheit(null), 'km');
  assert.equal(F.geschwEinheit('km'), 'km/h'); assert.equal(F.geschwEinheit('sm'), 'kn');
});
test('Einheit: Geschwindigkeit in km/h oder kn, Strecke in km oder sm, 1 sm = 1,852 km', () => {
  assert.equal(F.geschwindigkeitText(18.52, 'km'), '18,5 km/h');
  assert.equal(F.geschwindigkeitText(18.52, 'sm'), '10,0 kn');
  assert.equal(F.streckeEinheitText(185.2, 'km'), '185,2 km');
  assert.equal(F.streckeEinheitText(185.2, 'sm'), '100,0 sm');
});
test('Einheit: gilt für jedes Fahrzeug gleich, die Welt entscheidet nichts mehr (Wechselfeld)', () => {
  const w = { aktuellKmh: 18.52, fahrendKmh: null, tagKmh: null, km: 0, gestartet: false };
  assert.equal(F.anzeige(w, 'wasser', 'aktuell', { einheit: 'km' }).wert, '18,5 km/h');
  assert.equal(F.anzeige(w, 'land', 'aktuell', { einheit: 'sm' }).wert, '10,0 kn');
  assert.equal(F.anzeige(w, 'luft', 'aktuell', { einheit: 'km' }).wert, '18,5 km/h');
});
test('Das Logbuch ändert sich nicht: Der Eintrag „Geschwindigkeit“ bleibt nach der Welt', () => {
  const w = { aktuellKmh: 18.52, fahrendKmh: 9.26, tagKmh: 9.26, km: 18.52, fahrMs: 3600000, gesamtMs: 7200000 };
  assert.match(F.eintragText(w, 'wasser', 'rhythmus'), /aktuell 10,0 kn/);
  assert.match(F.eintragText(w, 'wasser', 'tag'), /Strecke 10,0 sm/);
  assert.match(F.eintragText(w, 'land', 'tag'), /Ø Tag 9,3 km\/h/);
  assert.match(F.eintragText(w, 'land', 'tag'), /Strecke 18,5 km/);
});
test('Einheit und Seite werden auf dem Gerät gemerkt, ohne andere Geräteeinstellungen zu verlieren', async () => {
  const { d } = await neu();
  assert.deepEqual(await d.geraetAnzeige(), { einheit: 'km', seite: null });
  assert.equal((await d.geraetKnoepfeSetzen(5)).ok, true);
  assert.equal((await d.geraetEinheitSetzen('sm')).ok, true);
  assert.equal((await d.geraetCockpitSeiteSetzen(2)).ok, true);
  assert.deepEqual(await d.geraetAnzeige(), { einheit: 'sm', seite: 2 });
  assert.equal((await d.geraetEinstellungen()).knoepfe, 5);
  assert.equal((await d.geraetEinheitSetzen('km')).ok, true);
  assert.deepEqual(await d.geraetAnzeige(), { einheit: 'km', seite: 2 });
});
test('Einheit und Seite: Ungültiges wird abgelehnt und ändert nichts', async () => {
  const { d } = await neu();
  await d.geraetEinheitSetzen('sm'); await d.geraetCockpitSeiteSetzen(1);
  const a = await d.geraetEinheitSetzen('kn'); assert.equal(a.ok, false); assert.ok(a.fehler.einheit);
  for (const x of [3, -1, 1.5, 'x', null]) assert.equal((await d.geraetCockpitSeiteSetzen(x)).ok, false, String(x));
  assert.deepEqual(await d.geraetAnzeige(), { einheit: 'sm', seite: 1 });
});
test('Einheit und Seite liegen im Dokument „geraet“ und damit nicht in der Sicherung', async () => {
  const { d } = await neu();
  await d.geraetEinheitSetzen('sm'); await d.geraetCockpitSeiteSetzen(2);
  const dok = await d.speicher.holen('einstellungen', 'geraet');
  assert.equal(dok.anzeigeEinheit, 'sm'); assert.equal(dok.cockpitSeite, 2);
});

/* ---------- ETA und Rest: eine Rechnung für Cockpit, Tag-Seite und Ablegen ---------- */
test('ETA: etaZumZiel und etaAusKontext rechnen dasselbe', async () => {
  const { d, akt, tag } = await neu();
  const live = { unterwegs: true, tagKmh: 60, fahrendKmh: 62, aktuellKmh: 61, position: { breite: 48.5, laenge: 10 } };
  const alt = await d.etaZumZiel(akt, tag, { live, jetztMs: JETZT });
  const k = await d.etaKontext(akt, tag, {});
  assert.equal(k.ok, true); assert.equal(k.zielName, 'München'); assert.equal(k.reiseKmh, 80);
  const neuRes = MM.Etappen.etaAusKontext(k, live, JETZT);
  assert.deepEqual(neuRes.eta, alt.eta);
  assert.equal(alt.zielName, 'München'); assert.equal(alt.ok, true);
});
test('Rest: Entfernung von der jetzigen Position zum Ziel, auch bevor die Fahrt zählt', async () => {
  const { d, akt, tag } = await neu();
  const k = await d.etaKontext(akt, tag, {});
  const vorStart = MM.Etappen.etaAusKontext(k, { unterwegs: false, position: { breite: 48.14, laenge: 10.58 } }, JETZT);
  assert.ok(vorStart.restKm > 60 && vorStart.restKm < 90, 'Rest ' + vorStart.restKm);
  assert.equal(vorStart.restArt, 'luftlinie');
  const amZiel = MM.Etappen.etaAusKontext(k, { unterwegs: true, tagKmh: 50, position: { breite: 48.14, laenge: 11.58 } }, JETZT);
  assert.equal(amZiel.restKm, 0);
  assert.equal(MM.Etappen.etaAusKontext(k, { unterwegs: false }, JETZT).restKm, null);
});
test('ETA und Rest: ohne Ziel gibt es keinen Kontext, im Cockpit steht „–“', async () => {
  const { d, akt } = await neu();
  const k = await d.etaKontext(akt, null, {});
  assert.equal(k.ok, false); assert.match(k.grund, /kein Ziel/);
  const z = await d.etaZumZiel(akt, null, {});
  assert.equal(z.ok, false);
  assert.equal(F.anzeige({ gestartet: false, km: 0 }, 'land', 'eta', { einheit: 'km', eta: null }).wert, '–');
  assert.equal(F.anzeige({ gestartet: false, km: 0 }, 'land', 'rest', { einheit: 'km', eta: null }).wert, '–');
});

/* ---------- 3. Seiten ---------- */
test('Seiten: drei Seiten, gespeichert wird nur eine vorhandene', () => {
  assert.equal(MM.Logbuch.COCKPIT_SEITEN, 3);
  [0, 1, 2, '1'].forEach(x => assert.notEqual(MM.Logbuch.cockpitSeiteGueltig(x), null));
  [3, -1, 1.5, 'x', null, undefined, ''].forEach(x => assert.equal(MM.Logbuch.cockpitSeiteGueltig(x), null));
});
test('Seiten: Info, Knöpfe und unterer Bereich, jede ein eigener Block', () => {
  const f = funktion('cockpitVollbild');
  assert.match(f, /var seite1 = h\('div', \{ class: 'cv-seite'/);
  assert.match(f, /var seite2 = h\('div', \{ class: 'cv-seite'/);
  assert.match(f, /var seite3 = h\('div', \{ class: 'cv-seite'/);
  /* Seite 1: oberer Bereich mit Position, Wechselfeld und Umschalter (positionZeile) */
  assert.ok(f.indexOf('cv-status') > f.indexOf('var seite1') && f.indexOf('cv-status') < f.indexOf('var seite2'));
  assert.match(funktion('positionZeile'), /tempoKnopfBauen\(\)[\s\S]*einheitKnopfBauen\(\)/);
  /* Seite 2: die Knöpfe */
  const s2 = f.slice(f.indexOf('var seite2'), f.indexOf('var seite3'));
  assert.ok(s2.includes("'cv-raster'") && s2.includes('knoepfe'));
  /* Seite 3: der heutige untere Bereich */
  const s3 = f.slice(f.indexOf('var seite3'), f.indexOf('var seitenEl'));
  ['motorLeiste', 'verbraucherLeiste', 'nachtankWarnung', 'cv-fuss', 'fussKnoepfe'].forEach(t => assert.ok(s3.includes(t), t));
});
test('Seiten: Punkte unten, Tipp auf einen Punkt springt, Wischen merkt die Seite', () => {
  const f = funktion('cockpitVollbild');
  assert.match(f, /class: 'cv-punkt'[\s\S]*onclick: function \(\) \{ seiteWaehlen\(i, true\); \}/);
  assert.match(f, /aria-current/);
  assert.match(f, /addEventListener\('scroll'/);
  assert.match(f, /geraetCockpitSeiteSetzen\(n\)/);
  assert.match(f, /seitenEl\.scrollLeft = seitenNr \* seitenEl\.clientWidth/);
  /* Die Seite bleibt beim Neuzeichnen und beim Zurückkommen stehen */
  assert.match(f, /MM\.Logbuch\.cockpitSeiteGueltig\(cockpitSeiteNr\)/);
  assert.match(funktion('zeigeJetzt'), /geraetAnzeige\(\)/);
  assert.match(funktion('zeigeJetzt'), /cockpitSeiteNr === null/);
});
test('Seiten: Meldungen und Fragen stehen über den Seiten und gehen nicht verloren', () => {
  const f = funktion('cockpitVollbild');
  const el = f.slice(f.indexOf("var el = h('div', { class: 'cockpit-voll'"));
  const reihe = ['kopf', 'cv-meldung', 'cv-hinweis', 'frageKarten', 'seitenEl', 'punkteEl'].map(t => el.indexOf(t));
  assert.ok(reihe.every(i => i >= 0), String(reihe));
  assert.deepEqual(reihe, reihe.slice().sort((a, b) => a - b));
});
test('Seiten: Das Wischen ist reines CSS-Einrasten, jede Seite füllt die Breite', () => {
  const css = lesen('css/styles.css');
  assert.match(css, /\.cv-seiten \{[^}]*scroll-snap-type: x mandatory/);
  assert.match(css, /\.cv-seite \{[^}]*flex: 0 0 100%/);
  assert.match(css, /\.cv-seite \{[^}]*scroll-snap-align: start/);
  assert.match(css, /\.cv-seiten \{[^}]*flex: 1 1 auto; min-height: 0/);
  assert.match(css, /\.cv-punkt \{[^}]*height: 2\.6rem/);
  assert.match(css, /\.cv-punkt\.aktiv \.cv-punkt-bild/);
});

/* ---------- 4. Logbuch und Hauptmenü ---------- */
test('Kopfzeile: „Logbuch“ und „Hauptmenü“ stehen über den Seiten, also auf jeder Seite am selben Platz', () => {
  const f = funktion('cockpitVollbild');
  const kopf = f.slice(f.indexOf("var kopf = h('div', { class: 'cv-kopf' }"), f.indexOf('var seite1'));
  assert.match(kopf, /text: 'Logbuch'[\s\S]*reiterWahl\[id\] = 'logbuch'/);
  assert.match(kopf, /href: '#\/auswahl', text: 'Hauptmenü'/);
  assert.ok(f.indexOf("var kopf = ") < f.indexOf('var seite1'));
  /* nicht in einer der Seiten */
  ['seite1', 'seite2', 'seite3'].forEach(n => {
    const teil = f.slice(f.indexOf('var ' + n), f.indexOf('var ' + n) + 3000);
    const bis = teil.indexOf(';\n    var ', 10);
    assert.ok(!teil.slice(0, bis).includes("'#/auswahl'"), n);
  });
  /* der alte Knopf unten ist weg, es gibt ihn nur noch einmal */
  assert.equal((ansicht.match(/Logbuch und Angaben/g) || []).length, 0);
});
test('Kopfzeile: Das Hauptmenü ist eine Adresse, die der Router kennt', () => {
  assert.match(ansicht, /teile\[0\] === 'auswahl'\) p = seiteHauptmenue\(\)/);
});

/* ---------- Einheit auch auf der Tag-Seite und nach dem Ablegen ---------- */
test('Einheit: ETA auf der Tag-Seite und nach dem Ablegen nutzt dieselbe Wahl, nicht die Welt des Fahrzeugs', () => {
  assert.match(funktion('etaGeschwText'), /MM\.Fahrt\.geschwindigkeitText\(kmh, anzeigeEinheit\)/);
  const z = funktion('etaZeilen');
  assert.match(z, /MM\.Fahrt\.streckeEinheitText\(e\.km, anzeigeEinheit\)/);
  assert.ok(!/welt/.test(z), 'etaZeilen kennt die Welt nicht mehr');
  assert.ok(!/Fahrt\.einheit\(/.test(ansicht.slice(ansicht.indexOf('function etaLive'), ansicht.indexOf('function etaBlock'))));
  /* ETA im Cockpit und die Tag-Seite rechnen mit derselben Funktion */
  assert.match(funktion('cockpitEta'), /MM\.Etappen\.etaAusKontext\(/);
  assert.match(funktion('tempoAktualisieren'), /einheit: anzeigeEinheit/);
});
test('Einheit: der Umschalter steht im Cockpit, wechselt mit einem Tipp und merkt sich die Wahl', () => {
  assert.match(funktion('einheitWechseln'), /MM\.Fahrt\.naechsteEinheit\(anzeigeEinheit\)/);
  assert.match(funktion('einheitWechseln'), /geraetEinheitSetzen\(wahl\)/);
  assert.match(funktion('einheitWechseln'), /tempoAktualisieren\(\)/);
  assert.match(funktion('zeigeJetzt'), /anzeigeEinheit = g\.einheit/);
  assert.match(funktion('zeigeJetzt'), /anzeigeSpeichern/);
  assert.ok(!funktion('gpsZeichnen').includes("h('button'"));
});
test('ETA und Rest: Der Kontext wird einmal geholt und beim Verlassen des Cockpits verworfen', () => {
  assert.match(ansicht, /daten\.etaKontext\(id, heuteTagId, \{\}\)/);
  assert.match(ansicht, /if \(!\(teile\[0\] === 'aktivitaet' && teile\[1\] && !teile\[2\]\)\) etaKtx = null;/);
});

/* ---------- Version und Texte ---------- */
test('Version 2.0.72 überall gleich, Neu im Programm und Cockpit-Text stimmen', () => {
  assert.equal(MM.VERSION, '2.0.72');
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.72';"));
  assert.equal(JSON.parse(lesen('package.json')).version, '2.0.72');
  assert.ok(lesen('README.md').includes('Version 2.0.72'));
  assert.ok(lesen('CHANGELOG.md').startsWith('# Änderungen\n\n## 2.0.72'));
  assert.ok(lesen('js/texte.js').includes("version: '2.0.72'"));
  assert.ok(lesen('docs/SCHRITTE.md').includes('2.0.72'));
  assert.equal(MM.Texte.NEUERUNGEN[0].version, '2.0.72');
  assert.equal(MM.Texte.NEUERUNGEN[1].version, '2.0.71');
  assert.equal(MM.Texte.NEUERUNGEN[2].version, '2.0.70');
  assert.equal(MM.Texte.NEUERUNGEN[3].version, '2.0.69');
  assert.equal(MM.Texte.NEUERUNGEN[4].version, '2.0.68');
  assert.equal(MM.Texte.NEUERUNGEN[5].version, '2.0.67');
  assert.equal(MM.Texte.NEUERUNGEN[6].version, '2.0.66');
  assert.equal(MM.Texte.NEUERUNGEN[7].version, '2.0.65');
  assert.equal(MM.Texte.NEUERUNGEN[8].version, '2.0.64');
  assert.equal(MM.Texte.NEUERUNGEN[9].version, '2.0.63');
  assert.ok(MM.Texte.NEUERUNGEN[10].punkte.join(' ').includes('Seite 1'));
  const neu = MM.Texte.NEUERUNGEN[11];
  assert.equal(neu.version, '2.0.61');
  const text = neu.punkte.join(' ');
  ['ETA', 'Rest', 'Gefahren', 'km', 'sm', 'Seite', 'Logbuch', 'Hauptmenü'].forEach(t => assert.ok(text.includes(t), t));
});
