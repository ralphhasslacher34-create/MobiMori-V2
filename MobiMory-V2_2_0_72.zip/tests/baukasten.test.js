'use strict';
/* 2.0.50: Baukasten-Gerüst: Festhalten, Fragen, Wirkungen. Die Aktionen aus 2.0.47 gehen darin auf. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/aktionen.js');
require('../js/baukasten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/karte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const B = MM.Baukasten;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 8, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.uhr = uhr;
  return d;
}
const foto = (inhalt, name) => { const b = new Blob([inhalt], { type: 'image/jpeg' }); Object.defineProperty(b, 'name', { value: name || 'foto.jpg' }); return b; };
async function mitAktivitaet() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: boot, vonDatum: '2026-11-08', vonZeit: '09:00', bisDatum: '2026-11-10', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok);
  return { d, id: r.id, boot };
}
const kostenDes = async (c) => (await c.d.kostenListe(c.boot));

/* ---------- Regeln ---------- */

test('Fragen und Wirkungen: die Liste steht an einer Stelle, Reihenfolge der Liste', () => {
  assert.deepEqual(B.fragen().map(x => x.id), ['text', 'foto', 'vorgang', 'tank', 'stoff', 'menge', 'betrag', 'literpreis', 'voll', 'ziel', 'zielOrt', 'einschraenkung', 'frist', 'verbraucher', 'ort', 'ausstattung', 'besuchKosten']);
  assert.deepEqual(B.wirkungen().map(x => x.id), ['kosten', 'navi', 'kostenTreibstoff', 'fuellstand', 'verbrauch', 'reichweite', 'vorgang', 'vorgangFrist', 'besuch', 'verbraucherEin', 'verbraucherAus']);
  assert.deepEqual(B.wirkung('kosten').braucht, ['betrag']);
  assert.deepEqual(B.wirkung('navi').braucht, ['ziel']);
  assert.equal(B.frage('gibtsnicht'), null);
  /* Eingabe in anderer Reihenfolge, mit Doppelten und Unbekanntem: sauber und in der Reihenfolge der Liste */
  assert.deepEqual(B.fragenNormal(['ziel', 'text', 'text', 'quatsch']), ['text', 'ziel']);
  assert.deepEqual(B.fragenNormal(undefined), []);
  assert.deepEqual(B.wirkungenNormal('kosten'), []);
});

test('Baukasten ist erweiterbar: neue Bausteine ohne Umbau, vorhandene Kennungen werden nicht überschrieben', () => {
  assert.equal(B.frageRegistrieren({ id: 'testfrage', name: 'Testfrage' }), true);
  assert.equal(B.frage('testfrage').name, 'Testfrage');
  assert.equal(B.frageRegistrieren({ id: 'text', name: 'Anderes' }), false);
  assert.equal(B.frage('text').name, 'Text');
  assert.equal(B.wirkungRegistrieren({ id: 'testwirkung', name: 'Testwirkung', braucht: ['testfrage'] }), true);
  assert.deepEqual(B.wirkung('testwirkung').braucht, ['testfrage']);
  assert.equal(B.wirkungRegistrieren({ id: 'kosten', name: 'Anderes' }), false);
  assert.equal(B.wirkungRegistrieren({ id: '', name: 'x' }), false);
});

test('Die Aktionen aus 2.0.47 gehen im Baukasten auf: jede ist eine Zusammenstellung', () => {
  assert.deepEqual(B.zusammenstellung({ aktion: 'text' }), { fragen: ['text'], wirkungen: [] });
  assert.deepEqual(B.zusammenstellung({ aktion: 'foto' }), { fragen: ['foto'], wirkungen: [] });
  assert.deepEqual(B.zusammenstellung({ aktion: 'navi' }), { fragen: ['ziel'], wirkungen: ['navi'] });
  assert.deepEqual(B.zusammenstellung({ aktion: 'gibtsnicht' }), { fragen: [], wirkungen: [] });
  assert.deepEqual(B.zusammenstellung({}), { fragen: [], wirkungen: [] });
  assert.deepEqual(B.zusammenstellung(undefined), { fragen: [], wirkungen: [] });
  assert.equal(B.hatAblauf({ aktion: 'navi' }), true);
  assert.equal(B.hatAblauf({}), false);
  /* alle eingebauten Aktionen sind in sich stimmig */
  MM.Aktionen.liste().filter(a => ['text', 'foto', 'navi'].includes(a.id)).forEach(a => {
    assert.deepEqual(B.fehlendeFragen({ fragen: a.fragen, wirkungen: a.wirkungen }), [], a.id);
  });
});

test('Fragen und Wirkungen haben Vorrang vor dem alten Feld; leer heißt „nichts“, auch wenn „aktion“ noch da ist', () => {
  assert.deepEqual(B.zusammenstellung({ aktion: 'text', fragen: ['betrag'], wirkungen: ['kosten'] }), { fragen: ['betrag'], wirkungen: ['kosten'] });
  assert.deepEqual(B.zusammenstellung({ aktion: 'text', fragen: [], wirkungen: [] }), { fragen: [], wirkungen: [] });
  assert.equal(B.hatAblauf({ aktion: 'text', fragen: [], wirkungen: [] }), false);
});

test('Eine Wirkung braucht ihre Frage: Meldung in einfachen Worten', () => {
  assert.deepEqual(B.fehlendeFragen({ fragen: [], wirkungen: [] }), []);
  assert.deepEqual(B.fehlendeFragen({ fragen: ['betrag'], wirkungen: ['kosten'] }), []);
  const m = B.fehlendeFragen({ fragen: ['text'], wirkungen: ['kosten', 'navi'] });
  assert.equal(m.length, 2);
  assert.ok(m[0].includes('Kostenposten anlegen') && m[0].includes('Betrag'));
  assert.ok(m[1].includes('Navigations-App öffnen') && m[1].includes('Ziel'));
});

test('Das Muster in Worten: Festhalten, Fragen, Wirkungen', () => {
  assert.equal(B.ablaufText({ fragen: [], wirkungen: [] }), '');
  assert.equal(B.ablaufText({ fragen: ['text', 'betrag'], wirkungen: ['kosten'] }), 'Festhalten: Ort und Zeit → Fragen: Text, Betrag → Wirkungen: Kostenposten anlegen');
  assert.equal(B.ablaufText({ fragen: ['foto'], wirkungen: [] }), 'Festhalten: Ort und Zeit → Fragen: Foto');
});

/* ---------- Ereignisart ---------- */

test('Ereignisart mit Fragen und Wirkungen: anlegen, Vorrang vor dem alten Feld, Wirkung ohne Frage wird abgelehnt', async () => {
  const c = await mitAktivitaet();
  const ok = await c.d.ereignisartAnlegen({ bezeichnung: 'Marina', fragen: ['betrag', 'text'], wirkungen: ['kosten'] });
  assert.ok(ok.ok);
  const w = (await c.d.ereignisartLaden(ok.id)).aktuell.werte;
  assert.deepEqual(w.fragen, ['text', 'betrag']);
  assert.deepEqual(w.wirkungen, ['kosten']);
  const schlecht = await c.d.ereignisartAnlegen({ bezeichnung: 'Hafen', fragen: ['text'], wirkungen: ['kosten'] });
  assert.equal(schlecht.ok, false);
  assert.ok(schlecht.fehler.wirkungen.includes('Betrag'));
  /* nichts gewählt: kein Zusatzfeld, der Knopf bleibt wie bisher */
  const leer = await c.d.ereignisartAnlegen({ bezeichnung: 'Brücke', fragen: [], wirkungen: [] });
  assert.ok(leer.ok);
  const wl = (await c.d.ereignisartLaden(leer.id)).aktuell.werte;
  assert.equal(Object.prototype.hasOwnProperty.call(wl, 'fragen'), false);
  assert.equal(Object.prototype.hasOwnProperty.call(wl, 'wirkungen'), false);
});

test('Ändern: Eine Art mit altem Feld „aktion“ wird nicht umgeschrieben, solange die Wahl gleich bleibt', async () => {
  const c = await mitAktivitaet();
  const a = await c.d.ereignisartAnlegen({ bezeichnung: 'Schleuse', aktion: 'navi' });
  /* So schickt das Formular die Zusammenstellung der Art zurück */
  const gleich = await c.d.ereignisartAendern(a.id, { bezeichnung: 'Schleuse', fragen: ['ziel'], wirkungen: ['navi'] });
  assert.equal(gleich.geaendert, false);
  const w = (await c.d.ereignisartLaden(a.id)).aktuell.werte;
  assert.equal(w.aktion, 'navi');
  assert.equal(Object.prototype.hasOwnProperty.call(w, 'fragen'), false);
  /* andere Wahl: die neuen Felder gelten, das alte bleibt unberührt stehen */
  const anders = await c.d.ereignisartAendern(a.id, { bezeichnung: 'Schleuse', fragen: ['text', 'betrag'], wirkungen: ['kosten'] });
  assert.equal(anders.geaendert, true);
  const w2 = (await c.d.ereignisartLaden(a.id)).aktuell.werte;
  assert.deepEqual(w2.fragen, ['text', 'betrag']);
  assert.equal(w2.aktion, 'navi');
  assert.deepEqual(B.zusammenstellung(w2), { fragen: ['text', 'betrag'], wirkungen: ['kosten'] });
  /* leere Wahl nimmt alles weg, auch die Zusammenstellung aus dem alten Feld */
  const weg = await c.d.ereignisartAendern(a.id, { bezeichnung: 'Schleuse', fragen: [], wirkungen: [] });
  assert.equal(weg.geaendert, true);
  assert.equal(B.hatAblauf((await c.d.ereignisartLaden(a.id)).aktuell.werte), false);
  /* ohne Angabe bleibt, was ist */
  const bleibt = await c.d.ereignisartAendern(a.id, { bezeichnung: 'Schleuse' });
  assert.equal(bleibt.geaendert, false);
  /* eine Art ohne alles bleibt bei leerer Wahl unverändert */
  const b = await c.d.ereignisartAnlegen({ bezeichnung: 'Brücke' });
  assert.equal((await c.d.ereignisartAendern(b.id, { bezeichnung: 'Brücke', fragen: [], wirkungen: [] })).geaendert, false);
  /* Wirkung ohne Frage wird auch beim Ändern abgelehnt */
  const nein = await c.d.ereignisartAendern(b.id, { bezeichnung: 'Brücke', fragen: [], wirkungen: ['navi'] });
  assert.equal(nein.ok, false);
  assert.ok(nein.fehler.wirkungen);
});

test('Der Verlauf der Art zeigt Fragen und Wirkungen mit Namen', async () => {
  const c = await mitAktivitaet();
  const a = await c.d.ereignisartAnlegen({ bezeichnung: 'Marina' });
  await c.d.ereignisartAendern(a.id, { bezeichnung: 'Marina', fragen: ['betrag'], wirkungen: ['kosten'] });
  const x = await c.d.ereignisartLaden(a.id);
  const u = x.verlauf[0].aenderungen.find(k => k.key === 'fragen');
  assert.ok(u);
  assert.equal(MM.Hilfen.wert(u.feld, u.neu), 'Betrag');
});

test('Der Knopf trägt „Ablauf“ mit: alte Aktion und neue Zusammenstellung, sonst nicht', async () => {
  const c = await mitAktivitaet();
  await c.d.ereignisartAnlegen({ bezeichnung: 'Alt', aktion: 'foto' });
  await c.d.ereignisartAnlegen({ bezeichnung: 'Neu', fragen: ['betrag'], wirkungen: ['kosten'] });
  await c.d.ereignisartAnlegen({ bezeichnung: 'Nichts' });
  const sk = await c.d.schnellknoepfeFuerFahrzeugart('boot');
  const von = n => sk.angebot.ereignisse.find(x => x.name === n);
  assert.equal(von('Alt').ablauf, true);
  assert.equal(von('Neu').ablauf, true);
  assert.equal(von('Neu').aktion, '');
  assert.equal(von('Nichts').ablauf, false);
});

/* ---------- Ablauf: Fragen und Wirkungen ---------- */

async function ereignisMit(c, art) {
  const a = await c.d.ereignisartAnlegen(Object.assign({ bezeichnung: 'Marina' }, art));
  assert.ok(a.ok, JSON.stringify(a));
  const e = await c.d.ereignisSchnell(c.id, 'Marina', { artId: a.id, ortName: 'Horrheim' });
  assert.ok(e.ok, JSON.stringify(e));
  return e.id;
}

test('Kostenposten als Wirkung: Betrag und Text kommen zum Eintrag, der Posten steht bei den variablen Kosten', async () => {
  const c = await mitAktivitaet();
  const id = await ereignisMit(c, { fragen: ['text', 'betrag'], wirkungen: ['kosten'] });
  const r = await c.d.ereignisAblaufAusfuehren(id, { text: 'Liegeplatz Steg 4', betrag: '45,50' });
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal(r.kostenNeu, true);
  assert.equal(r.betrag, 45.5);
  const e = (await c.d.ereignisLaden(id)).aktuell.werte;
  assert.equal(e.text, 'Liegeplatz Steg 4');
  assert.equal(e.betrag, 45.5);
  assert.equal(e.kostenId, r.kostenId);
  const posten = await c.d.kostenLaden(r.kostenId);
  const w = posten.aktuell.werte;
  assert.equal(w.gruppe, 'variabel');
  assert.equal(w.bezeichnung, 'Marina');
  assert.equal(w.betrag, 45.5);
  assert.equal(w.datum, e.datum);
  assert.equal(w.aktivitaetId, c.id);
  assert.equal(w.ortText, 'Horrheim');
  assert.ok(w.abschnittId);
  assert.equal(posten.objekt.fahrzeugId, c.boot);
  /* Der Eintrag zählt nicht als „korrigiert“ */
  const ev = (await c.d.logbuchLaden(c.id)).abschnitte.flatMap(t => t.ereignisse).find(x => x.id === id);
  assert.equal(ev.geaendert, false);
});

test('Ein Kostenposten je Eintrag: ein zweites Abschicken legt keinen zweiten an', async () => {
  const c = await mitAktivitaet();
  const id = await ereignisMit(c, { fragen: ['betrag'], wirkungen: ['kosten'] });
  const r1 = await c.d.ereignisAblaufAusfuehren(id, { betrag: '12,00' });
  assert.equal(r1.kostenNeu, true);
  const r2 = await c.d.ereignisAblaufAusfuehren(id, { betrag: '12,00' });
  assert.ok(r2.ok);
  assert.equal(r2.kostenNeu, false);
  assert.equal(r2.kostenId, r1.kostenId);
  const liste = (await kostenDes(c)).filter(k => k.aktuell.werte.bezeichnung === 'Marina');
  assert.equal(liste.length, 1);
});

test('Prüfung kommt vor dem Speichern: ohne Betrag oder mit falschem Betrag wird nichts gespeichert', async () => {
  const c = await mitAktivitaet();
  const id = await ereignisMit(c, { fragen: ['text', 'foto', 'betrag'], wirkungen: ['kosten'] });
  const vorher = (await c.d.ereignisLaden(id)).verlauf.length;
  const ohne = await c.d.ereignisAblaufAusfuehren(id, { text: 'Hallo', datei: foto('bild') });
  assert.equal(ohne.ok, false);
  assert.ok(ohne.fehler.betrag);
  const falsch = await c.d.ereignisAblaufAusfuehren(id, { text: 'Hallo', datei: foto('bild'), betrag: '-5' });
  assert.equal(falsch.ok, false);
  assert.ok(falsch.fehler.betrag);
  const buchstaben = await c.d.ereignisAblaufAusfuehren(id, { betrag: 'abc' });
  assert.equal(buchstaben.ok, false);
  assert.equal((await c.d.ereignisLaden(id)).verlauf.length, vorher);
  assert.equal(await c.d.ereignisDateiHolen(id), null);
  assert.equal((await kostenDes(c)).length, 0);
  /* nach der Korrektur geht es mit demselben Foto */
  const gut = await c.d.ereignisAblaufAusfuehren(id, { text: 'Hallo', datei: foto('bild', 'm.jpg'), betrag: '9,90' });
  assert.ok(gut.ok, JSON.stringify(gut));
  assert.equal((await c.d.ereignisDateiHolen(id)).name, 'm.jpg');
});

test('Nur eine Frage: die Meldung nennt ihr Feld; mehrere: eine allgemeine Meldung', async () => {
  const c = await mitAktivitaet();
  const t = await ereignisMit(c, { fragen: ['text'] });
  const rt = await c.d.ereignisAblaufAusfuehren(t, { text: '  ' });
  assert.equal(rt.ok, false);
  assert.ok(rt.fehler.text);
  const c2 = await mitAktivitaet();
  const f = await ereignisMit(c2, { fragen: ['foto'] });
  const rf = await c2.d.ereignisAblaufAusfuehren(f, {});
  assert.ok(rf.fehler.datei);
  const c3 = await mitAktivitaet();
  const m = await ereignisMit(c3, { fragen: ['text', 'foto'] });
  const rm = await c3.d.ereignisAblaufAusfuehren(m, {});
  assert.ok(rm.fehler.allgemein);
});

test('Antworten zu Fragen, die die Art nicht stellt, werden nicht beachtet', async () => {
  const c = await mitAktivitaet();
  const id = await ereignisMit(c, { fragen: ['text'] });
  const r = await c.d.ereignisAblaufAusfuehren(id, { text: 'Nur Text', betrag: '99', ziel: 'Irgendwo', datei: foto('x') });
  assert.ok(r.ok);
  const w = (await c.d.ereignisLaden(id)).aktuell.werte;
  assert.equal(w.text, 'Nur Text');
  assert.equal(w.betrag, undefined);
  assert.equal(w.ziel, undefined);
  assert.equal(await c.d.ereignisDateiHolen(id), null);
});

test('Navigation als Wirkung: das Ziel ist Pflicht, steht als Zeile im Text und als Ziel am Eintrag; Text bleibt dabei', async () => {
  const c = await mitAktivitaet();
  const id = await ereignisMit(c, { fragen: ['text', 'ziel'], wirkungen: ['navi'] });
  const ohne = await c.d.ereignisAblaufAusfuehren(id, { text: 'Los geht es' });
  assert.equal(ohne.ok, false);
  assert.ok(ohne.fehler.ziel);
  const r = await c.d.ereignisAblaufAusfuehren(id, { text: 'Los geht es', ziel: ' Hafen Horrheim ' });
  assert.ok(r.ok);
  assert.equal(r.navi, true);
  assert.equal(r.ziel, 'Hafen Horrheim');
  let w = (await c.d.ereignisLaden(id)).aktuell.werte;
  assert.equal(w.ziel, 'Hafen Horrheim');
  assert.equal(w.text, 'Los geht es\nNavigation zu: Hafen Horrheim');
  /* ein neues Ziel ersetzt die Zeile, der Text bleibt */
  const r2 = await c.d.ereignisAblaufAusfuehren(id, { text: 'Los geht es', ziel: 'Marina Nord' });
  assert.ok(r2.ok);
  w = (await c.d.ereignisLaden(id)).aktuell.werte;
  assert.equal(w.ziel, 'Marina Nord');
  assert.equal(w.text, 'Los geht es\nNavigation zu: Marina Nord');
});

test('Die alte Aktion Navigation verhält sich wie in 2.0.47: nur ein Ziel, Zeile „Navigation zu:“', async () => {
  const c = await mitAktivitaet();
  const a = await c.d.ereignisartAnlegen({ bezeichnung: 'Schleuse', aktion: 'navi' });
  const e = await c.d.ereignisSchnell(c.id, 'Schleuse', { artId: a.id });
  const r = await c.d.ereignisAblaufAusfuehren(e.id, { ziel: 'Schleuse Lauffen' });
  assert.ok(r.ok);
  assert.equal(r.navi, true);
  assert.equal((await c.d.ereignisLaden(e.id)).aktuell.werte.text, 'Navigation zu: Schleuse Lauffen');
  assert.equal((await kostenDes(c)).length, 0);
});

test('Alte Aktionen Text und Foto laufen über denselben Weg', async () => {
  const c = await mitAktivitaet();
  const at = await c.d.ereignisartAnlegen({ bezeichnung: 'Notiz2', aktion: 'text' });
  const af = await c.d.ereignisartAnlegen({ bezeichnung: 'Bild2', aktion: 'foto' });
  const et = await c.d.ereignisSchnell(c.id, 'x', { artId: at.id });
  const ef = await c.d.ereignisSchnell(c.id, 'x', { artId: af.id });
  assert.ok((await c.d.ereignisAblaufAusfuehren(et.id, { text: 'Tor 2' })).ok);
  assert.equal((await c.d.ereignisLaden(et.id)).aktuell.werte.text, 'Tor 2');
  assert.ok((await c.d.ereignisAblaufAusfuehren(ef.id, { datei: foto('d', 'h.jpg') })).ok);
  assert.equal((await c.d.ereignisDateiHolen(ef.id)).name, 'h.jpg');
  /* ein zweites Foto wird nicht angenommen, die Meldung sagt es */
  const nochmal = await c.d.ereignisAblaufAusfuehren(ef.id, { datei: foto('d2', 'zwei.jpg') });
  assert.equal(nochmal.ok, false);
  assert.ok(nochmal.fehler.datei);
});

test('Ohne Zusammenstellung, unbekanntes Ereignis, stornierte Aktivität: abgewiesen', async () => {
  const c = await mitAktivitaet();
  const a = await c.d.ereignisartAnlegen({ bezeichnung: 'Leer' });
  const e = await c.d.ereignisSchnell(c.id, 'Leer', { artId: a.id });
  const r = await c.d.ereignisAblaufAusfuehren(e.id, { text: 'x' });
  assert.equal(r.ok, false);
  assert.ok(r.fehler.allgemein);
  const nix = await c.d.ereignisAblaufAusfuehren('gibt-es-nicht', { text: 'x' });
  assert.equal(nix.ok, false);
  const id = await ereignisMit(c, { fragen: ['betrag'], wirkungen: ['kosten'] });
  const st = await c.d.aktivitaetStornieren(c.id, 'Test');
  assert.ok(st.ok, JSON.stringify(st));
  const r2 = await c.d.ereignisAblaufAusfuehren(id, { betrag: '5' });
  assert.equal(r2.ok, false);
  assert.ok(r2.fehler.allgemein.includes('storniert'));
  assert.equal((await kostenDes(c)).length, 0);
});

test('Betrag im Eintrag: Verlauf zeigt „angelegt“ statt der Kennung des Kostenpostens', async () => {
  const c = await mitAktivitaet();
  const id = await ereignisMit(c, { fragen: ['betrag'], wirkungen: ['kosten'] });
  await c.d.ereignisAblaufAusfuehren(id, { betrag: '20' });
  const x = await c.d.ereignisLaden(id);
  const alle = x.verlauf.flatMap(v => v.aenderungen);
  const k = alle.find(u => u.key === 'kostenId');
  assert.ok(k);
  assert.equal(k.neu, 'angelegt');
});

/* ---------- Quelltext ---------- */

test('Oberfläche im Quelltext: Block „Nach dem Antippen“, Muster, Ergebnis-Seite, Modul eingetragen', () => {
  const ansicht = lesen('js/ansicht.js');
  assert.ok(ansicht.includes("'Nach dem Antippen (freiwillig)'"));
  assert.ok(ansicht.includes("key: 'fragen'") && ansicht.includes("key: 'wirkungen'"));
  assert.ok(ansicht.includes('Das hat die App getan'));
  assert.ok(ansicht.includes('daten.ereignisAblaufAusfuehren('));
  assert.ok(!ansicht.includes("'Aktion beim Antippen (freiwillig)'"));
  assert.ok(lesen('index.html').includes('js/baukasten.js'));
  assert.ok(lesen('sw.js').includes("'js/baukasten.js'"));
  assert.ok(lesen('index.html').indexOf('js/baukasten.js') < lesen('index.html').indexOf('js/daten.js'));
  assert.ok(lesen('docs/SCHRITTE.md').includes('| 12c |'));
});

test('Version 2.0.72 überall gleich', () => {
  assert.equal(MM.VERSION, '2.0.72');
  assert.ok(MM.STUFE.includes('Konto'));
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.72';"));
  assert.equal(JSON.parse(lesen('package.json')).version, '2.0.72');
  assert.ok(lesen('README.md').includes('Version 2.0.72'));
  assert.ok(lesen('CHANGELOG.md').startsWith('# Änderungen\n\n## 2.0.72'));
  assert.ok(lesen('js/texte.js').includes("version: '2.0.72'"));
});
