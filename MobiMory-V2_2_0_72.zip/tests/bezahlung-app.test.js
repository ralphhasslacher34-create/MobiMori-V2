'use strict';
/* 2.0.72: Bezahlen in der App. Angebote je Stufe, Preise gleich wie beim Dienst, Überweisungs-Angaben, Bestellung über den Dienst. */
const t = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = t;
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'konto', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM, K = MM.Konto;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

async function neu() {
  let n = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 12, 12, 0, n++)).toISOString() });
  await d.starten();
  return d;
}
const S = (id, online) => ({ ok: true, stufe: { id, name: id }, grenzen: { geraete: 2, checks: 0, fahrzeuge: 1, online: online }, nutzung: { geraete: 1, checks: 0, checksFrei: 0, extra: 0 } });

test('Preise: Die App hat dieselben Preise und Arten wie der Dienst (Jahreszahlung, 12 × 4,99 € und 12 × 9,99 €, 5 Recherchen für 9,99 €)', async () => {
  const d = await import('../server/konto-dienst.mjs');
  assert.deepEqual(Object.keys(K.PRODUKTE), Object.keys(d.PRODUKTE));
  Object.keys(d.PRODUKTE).forEach((k) => {
    assert.equal(K.PRODUKTE[k].cent, d.PRODUKTE[k].cent, k);
    assert.equal(K.PRODUKTE[k].art, d.PRODUKTE[k].art, k);
  });
  assert.equal(K.PRODUKTE.mittel.cent, 5988); assert.equal(K.PRODUKTE.voll.cent, 11988); assert.equal(K.PRODUKTE.recherche5.cent, 999); assert.equal(K.PRODUKTE.recherche5.anzahl, d.PRODUKTE.recherche5.anzahl);
  assert.equal(K.euro(5988), '59,88 €'); assert.equal(K.euro(999), '9,99 €');
});

test('Angebote: Welche Stufe sieht was; Entwickler nichts, Mittel nicht bei Voll, Recherchen nur mit Online-Stufe', () => {
  const ids = (s) => K.angebote(s).map((a) => a.id);
  assert.deepEqual(ids(S('basic', false)), ['mittel', 'voll']);
  assert.deepEqual(ids(S('test', true)), ['mittel', 'voll', 'recherche5']);
  assert.deepEqual(ids(S('mittel', true)), ['mittel', 'voll', 'recherche5']);
  assert.deepEqual(ids(S('voll', true)), ['voll', 'recherche5']);
  assert.deepEqual(ids(S('entwickler', true)), []);
  const m = K.angebote(S('basic', false))[0];
  assert.equal(m.preis, '59,88 € (12 × 4,99 €)'); assert.match(m.text, /Bis zu 4 Geräte, 3 Fahrzeuge, 3 Online-Checks im Jahr/);
  const v = K.angebote(S('basic', false))[1];
  assert.equal(v.preis, '119,88 € (12 × 9,99 €)'); assert.match(v.text, /10 Geräte, beliebig viele Fahrzeuge, 10 Online-Checks/);
  assert.equal(K.angebote(S('mittel', true))[2].preis, '9,99 €');
  assert.match(K.TEXT_BEZAHLEN, /kein Abo/); assert.match(K.TEXT_BEZAHLEN, /Beleg/); assert.match(K.TEXT_BEZAHLEN, /Erinnerung/);
});

test('Überweisung: Die Anzeige nennt Betrag, Empfänger, IBAN in Vierergruppen und den Verwendungszweck', () => {
  const z = K.ueberweisungZeilen({ betrag: '59,88 €', empfaenger: 'Ralph Hasslacher', iban: 'DE02120300000000202051', bic: 'BYLADEM1001', verwendungszweck: 'MM-ABCD2345', mail: true });
  assert.equal(z[0], 'Bitte überweise 59,88 € an:'); assert.equal(z[1], 'Empfänger: Ralph Hasslacher'); assert.equal(z[2], 'IBAN: DE02 1203 0000 0000 2020 51');
  assert.equal(z[3], 'BIC: BYLADEM1001'); assert.equal(z[4], 'Verwendungszweck: MM-ABCD2345');
  assert.match(z[5], /Beleg/); assert.match(z[6], /auch per E-Mail/);
  const o = K.ueberweisungZeilen({ betrag: '9,99 €', empfaenger: 'X', iban: 'DE02120300000000202051', verwendungszweck: 'MM-ZZZZ2345', mail: false });
  assert.equal(o.length, 5); assert.ok(!o.some((x) => /BIC/.test(x)));
});

test('Stufe: Nachgekaufte Recherchen stehen in den Zeilen, der Hinweis „Bezahlen kommt später“ ist weg', () => {
  const s = Object.assign(S('mittel', true), { stufe: { id: 'mittel', name: 'Mittel', bis: null }, grenzen: { geraete: 4, checks: 3, fahrzeuge: 3, online: true }, nutzung: { geraete: 1, checks: 3, checksFrei: 0, extra: 4 } });
  const z = K.stufeZeilen(s);
  assert.ok(z.some((x) => /Zusätzliche Recherchen: 4 übrig/.test(x)));
  const b = K.stufeZeilen(S('basic', false).stufe ? Object.assign(S('basic', false), { stufe: { id: 'basic', name: 'Basic', bis: null } }) : null);
  assert.ok(!b.some((x) => /späteren Schritt/.test(x)));
  assert.ok(!b.some((x) => /Zusätzliche Recherchen/.test(x)));
});

test('Bestellen: Das Gerät schickt Angebot und Weg an den Dienst und gibt die Antwort zurück; Fehler werden in einfachen Worten gemeldet', async () => {
  const d = await neu();
  const aufrufe = [];
  d.kontoAnfrageFn = async (url, methode, token, body) => { aufrufe.push({ url, methode, body }); return { ok: true, weg: body.weg, betrag: '59,88 €', url: 'https://www.paypal.com/checkoutnow?token=X' }; };
  const r = await d.kontoBestellen('mittel', 'paypal');
  assert.equal(r.ok, true); assert.equal(r.url, 'https://www.paypal.com/checkoutnow?token=X');
  assert.equal(aufrufe.length, 1); assert.equal(aufrufe[0].methode, 'POST'); assert.match(aufrufe[0].url, /\/bezahlen\/starten$/); assert.deepEqual(aufrufe[0].body, { produkt: 'mittel', weg: 'paypal' });
  d.kontoAnfrageFn = async () => { const e = new Error('Du hast bereits Voll.'); e.status = 400; throw e; };
  const f = await d.kontoBestellen('mittel', 'paypal');
  assert.equal(f.ok, false); assert.equal(f.fehler, 'Du hast bereits Voll.'); assert.equal(f.abgelaufen, false);
  d.kontoAnfrageFn = async () => { const e = new Error('weg'); e.status = 401; throw e; };
  assert.equal((await d.kontoBestellen('voll', 'ueberweisung')).abgelaufen, true);
  d.kontoAnfrageFn = async () => { throw new Error('kein Netz'); };
  const n = await d.kontoBestellen('voll', 'paypal');
  assert.equal(n.ok, false); assert.match(n.fehler, /Keine Verbindung/);
});

test('Oberfläche: Die Konto-Seite hat den Bereich „Stufe wählen oder verlängern“ mit PayPal und Überweisung, sonst nichts wird gespeichert', () => {
  const a = lesen('js/ansicht.js');
  assert.ok(a.includes('function bezahlenKasten'));
  assert.ok(a.includes("box.appendChild(bezahlenKasten(r))"));
  assert.ok(a.includes('Mit PayPal bezahlen')); assert.ok(a.includes('Per Überweisung'));
  assert.ok(a.includes("daten.kontoBestellen(a.id, weg)"));
  const dt = lesen('js/daten.js');
  assert.ok(/kontoBestellen = function/.test(dt));
});
