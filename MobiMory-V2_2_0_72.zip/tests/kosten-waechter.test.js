'use strict';
/* 2.0.71 (Dienst 13e-3): Kosten-Wächter für die Testwochen. Seit 2.0.72 (Dienst 13e-4) rechnen die Einnahmen aus den Belegen. Dienst mit nachgebauter Datenbank, die Mail ist ein Platzhalter. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');

const TAG = 24 * 60 * 60 * 1000;
const STUNDE = 60 * 60 * 1000;
const JETZT = Date.UTC(2026, 10, 12, 12, 0, 0);
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }

/* Umgebung mit Mail-Platzhalter. Er merkt sich, was gesendet wurde; mit post.fehler = true schlägt das Senden fehl. */
function umgebung(extra) {
  const post = { gesendet: [], fehler: false };
  const env = Object.assign({
    DB: neueDatenbank(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: 'https://app.example.org',
    ABSENDER: 'konto@example.org', WAECHTER_EMAIL: 'chef@example.org',
    EMAIL: { send: async (m) => { if (post.fehler) throw new Error('Versand kaputt'); post.gesendet.push(m); } }
  }, extra || {});
  env.post = post;
  return env;
}

let zaehler = 0;
/* Legt ein Konto samt Datenraum an (ohne Anmeldung). Mit testwocheStart bekommt es eine Testwoche, mit stufe einen Eintrag in stufe_konto. */
function konto(env, email, opt) {
  const o = opt || {};
  zaehler += 1;
  const id = 'n' + zaehler, dr = 'd' + zaehler, db = env.DB.roh;
  db.prepare('INSERT INTO nutzer (id, email, erstellt_am, bestaetigt_am) VALUES (?, ?, ?, ?)').run(id, email, JETZT - 40 * TAG, JETZT - 40 * TAG);
  db.prepare('INSERT INTO datenraum (id, nutzer_id, name, erstellt_am) VALUES (?, ?, ?, ?)').run(dr, id, 'Raum', JETZT - 40 * TAG);
  if (o.testwocheStart !== undefined) db.prepare('INSERT INTO testwoche (email_hash, nutzer_id, start_am, ende_am) VALUES (?, ?, ?, ?)').run('h' + zaehler, id, o.testwocheStart, o.testwocheStart + 7 * TAG);
  if (o.stufe) db.prepare('INSERT INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) VALUES (?, ?, ?, ?)').run(id, o.stufe, o.bis === undefined ? null : o.bis, 1);
  return { id, dr };
}
let nr = 0;
function checks(env, k, anzahl, am, stufe, status) {
  for (let i = 0; i < anzahl; i++) {
    nr += 1;
    env.DB.roh.prepare('INSERT INTO check_nutzung (id, datenraum_id, art, stufe, am, status) VALUES (?, ?, ?, ?, ?, ?)').run('c' + nr, k.dr, 'reise', stufe || 'test', am, status || 'ok');
  }
}
/* Ein Beleg (Einnahme): cent, Datum. Seit 2.0.72 zählen die Einnahmen aus „beleg“, nicht mehr aus den Konten. */
let belegNr = 0;
function beleg(env, email, cent, am) {
  belegNr += 1;
  env.DB.roh.prepare('INSERT INTO beleg (nummer, am, email, produkt, cent, weg, referenz) VALUES (?, ?, ?, ?, ?, ?, ?)').run('MM-2026-' + belegNr, am, email, 'mittel', cent, 'paypal', 'ref' + belegNr);
}
async function pruefen(env, jetzt) { const d = await laden(); return d.waechterPruefen(env, env.DB, jetzt === undefined ? JETZT : jetzt); }

test('Wächter: Die SQL-Datei hat eine Zeile und steht auch im Schema; Version 13e-4', async () => {
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13e-3.sql'), 'utf8').trim().split('\n');
  assert.equal(sql.length, 1);
  assert.match(sql[0], /^CREATE TABLE IF NOT EXISTS waechter_stand /);
  assert.ok(fs.readFileSync(path.join(__dirname, '..', 'server', 'schema.sql'), 'utf8').includes(sql[0]));
  const d = await laden();
  assert.equal(d.VERSION, '13e-4');
});

test('Wächter: Ohne Einnahmen gilt die feste Obergrenze von 10 Testwochen-Checks in 24 Stunden', async () => {
  const env = umgebung();
  const k = konto(env, 'a@example.org', { testwocheStart: JETZT - 3 * TAG });
  checks(env, k, 10, JETZT - 2 * STUNDE);
  let r = await pruefen(env);
  assert.equal(r.geprueft, true); assert.equal(r.warnung, false); assert.equal(r.mail, 'keine');
  assert.equal(env.post.gesendet.length, 0);
  checks(env, k, 1, JETZT - 1 * STUNDE);
  r = await pruefen(env);
  assert.equal(r.warnung, true); assert.deepEqual(r.gruende, ['checks-tag']); assert.equal(r.mail, 'gesendet');
  assert.equal(env.post.gesendet.length, 1);
  assert.equal(env.post.gesendet[0].to, 'chef@example.org');
  assert.equal(env.post.gesendet[0].from, 'konto@example.org');
});

test('Wächter: Die Mail nennt nur Zahlen und den Zeitraum, keine Adressen und keine Namen', async () => {
  const env = umgebung();
  const k = konto(env, 'geheim.person@example.org', { testwocheStart: JETZT - 3 * TAG });
  checks(env, k, 11, JETZT - 1 * STUNDE);
  await pruefen(env);
  const m = env.post.gesendet[0];
  assert.ok(m.text.includes('11'));
  assert.ok(m.text.includes('2026-10-13 bis 2026-11-12'));
  assert.ok(!/geheim|person|example\.org/i.test(m.text.replace('chef@example.org', '')), 'keine Adresse in der Mail');
  assert.ok(!m.text.includes('n1') || !/\bn1\b/.test(m.text), 'keine Kennung');
  assert.ok(/Schätzwert/.test(m.text), 'ohne KOSTEN_CHECK steht der Hinweis auf den Schätzwert da');
  const env2 = umgebung({ KOSTEN_CHECK: '0,31' });
  const k2 = konto(env2, 'b@example.org', { testwocheStart: JETZT - 3 * TAG });
  checks(env2, k2, 11, JETZT - 1 * STUNDE);
  await pruefen(env2);
  assert.ok(!/Schätzwert/.test(env2.post.gesendet[0].text));
  assert.ok(env2.post.gesendet[0].text.includes('0,31 € je Check'));
});

test('Wächter: Nach einer Mail höchstens eine weitere pro Stunde', async () => {
  const env = umgebung();
  const k = konto(env, 'a@example.org', { testwocheStart: JETZT - 3 * TAG });
  checks(env, k, 12, JETZT - 1 * STUNDE);
  assert.equal((await pruefen(env, JETZT)).mail, 'gesendet');
  assert.equal((await pruefen(env, JETZT + 15 * 60 * 1000)).mail, 'gedrosselt');
  assert.equal((await pruefen(env, JETZT + 59 * 60 * 1000)).mail, 'gedrosselt');
  assert.equal((await pruefen(env, JETZT + 61 * 60 * 1000)).mail, 'gesendet');
  assert.equal(env.post.gesendet.length, 2);
});

test('Wächter: Schlägt das Senden fehl, gibt es keine Bremse; der nächste Lauf versucht es wieder', async () => {
  const env = umgebung();
  const k = konto(env, 'a@example.org', { testwocheStart: JETZT - 3 * TAG });
  checks(env, k, 12, JETZT - 1 * STUNDE);
  env.post.fehler = true;
  assert.equal((await pruefen(env, JETZT)).mail, 'fehlgeschlagen');
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM waechter_stand').get().n, 0);
  env.post.fehler = false;
  assert.equal((await pruefen(env, JETZT + 15 * 60 * 1000)).mail, 'gesendet');
});

test('Wächter: Ohne Empfänger-Adresse wird nur geprüft, nichts gesendet', async () => {
  const env = umgebung({ WAECHTER_EMAIL: undefined });
  const k = konto(env, 'a@example.org', { testwocheStart: JETZT - 3 * TAG });
  checks(env, k, 12, JETZT - 1 * STUNDE);
  const r = await pruefen(env);
  assert.equal(r.warnung, true); assert.equal(r.mail, 'kein-empfaenger');
  assert.equal(env.post.gesendet.length, 0);
  const env2 = umgebung({ WAECHTER_EMAIL: 'keine-adresse' });
  const k2 = konto(env2, 'b@example.org', { testwocheStart: JETZT - 3 * TAG });
  checks(env2, k2, 12, JETZT - 1 * STUNDE);
  assert.equal((await pruefen(env2)).mail, 'kein-empfaenger');
});

test('Wächter: Mit Einnahmen zählt der Anteil der Kosten, nicht die feste Obergrenze', async () => {
  /* Ein Beleg über 60 € im Jahr = 5 € im Monat, Schwelle 20 % = 1 €, ein Check = 0,45 €: zwei Checks (0,90 €) gehen, drei (1,35 €) nicht. */
  const env = umgebung();
  konto(env, 'zahler@example.org', { stufe: 'mittel', bis: JETZT + 100 * TAG });
  beleg(env, 'zahler@example.org', 6000, JETZT - 10 * TAG);
  const k = konto(env, 'test@example.org', { testwocheStart: JETZT - 20 * TAG });
  checks(env, k, 2, JETZT - 10 * TAG);
  let r = await pruefen(env);
  assert.equal(r.warnung, false);
  assert.equal(r.werte.kontenMittel, 1); assert.equal(r.werte.einnahmenMonat, 5);
  assert.ok(Math.abs(r.werte.anteil - 0.18) < 1e-9);
  checks(env, k, 1, JETZT - 10 * TAG);
  r = await pruefen(env);
  assert.equal(r.warnung, true); assert.deepEqual(r.gruende, ['kosten-anteil']); assert.equal(r.mail, 'gesendet');
  assert.ok(env.post.gesendet[0].text.includes('27 %'));

  /* Viele Checks an einem Tag lösen mit Einnahmen nicht die feste Obergrenze aus, wenn der Anteil klein bleibt. */
  const env2 = umgebung();
  for (let i = 0; i < 10; i++) { konto(env2, 'v' + i + '@example.org', { stufe: 'voll', bis: null }); beleg(env2, 'v' + i + '@example.org', 12000, JETZT - 30 * TAG); }
  const k2 = konto(env2, 'test@example.org', { testwocheStart: JETZT - 2 * TAG });
  checks(env2, k2, 12, JETZT - 1 * STUNDE);
  r = await pruefen(env2);
  assert.equal(r.werte.einnahmenMonat, 100); assert.equal(r.werte.testChecks24, 12);
  assert.equal(r.warnung, false);
});

test('Wächter: Belege, die älter als 365 Tage sind, bringen keine Einnahmen, dann gilt wieder die feste Obergrenze; ein Konto ohne Beleg (Geschenk) auch nicht', async () => {
  const env = umgebung();
  konto(env, 'alt@example.org', { stufe: 'mittel', bis: JETZT - 1 * TAG });
  beleg(env, 'alt@example.org', 6000, JETZT - 400 * TAG);
  konto(env, 'geschenk2@example.org', { stufe: 'voll', bis: JETZT + 200 * TAG });
  const k = konto(env, 'test@example.org', { testwocheStart: JETZT - 2 * TAG });
  checks(env, k, 11, JETZT - 1 * STUNDE);
  const r = await pruefen(env);
  assert.equal(r.werte.einnahmenMonat, 0); assert.deepEqual(r.gruende, ['checks-tag']);
});

test('Wächter: Mehr als 5 neue Testwochen in 24 Stunden lösen eine Warnung aus, auch ohne einen einzigen Check', async () => {
  const env = umgebung();
  for (let i = 0; i < 5; i++) konto(env, 't' + i + '@example.org', { testwocheStart: JETZT - 2 * STUNDE });
  assert.equal((await pruefen(env)).warnung, false);
  konto(env, 't5@example.org', { testwocheStart: JETZT - 3 * STUNDE });
  const r = await pruefen(env);
  assert.equal(r.warnung, true); assert.deepEqual(r.gruende, ['testwochen-tag']); assert.equal(r.werte.neueTestwochen24, 6);
  assert.ok(/6 neue Testwochen/.test(env.post.gesendet[0].text));
  /* Ältere Testwochen als 24 Stunden zählen für diesen Wert nicht. */
  const env2 = umgebung();
  for (let i = 0; i < 8; i++) konto(env2, 'u' + i + '@example.org', { testwocheStart: JETZT - 2 * TAG });
  assert.equal((await pruefen(env2)).warnung, false);
});

test('Wächter: Das Entwickler-Konto und ausgenommene Adressen zählen nicht, auch nicht bei den Einnahmen', async () => {
  const env = umgebung({ WAECHTER_AUSGENOMMEN: 'Eigener.Test@example.org, geschenk@example.org' });
  const dev = konto(env, 'ich@example.org', { stufe: 'entwickler', testwocheStart: JETZT - 2 * TAG });
  const eigen = konto(env, 'eigener.test@example.org', { testwocheStart: JETZT - 2 * TAG });
  konto(env, 'geschenk@example.org', { stufe: 'voll', bis: JETZT + 300 * TAG });
  beleg(env, 'Geschenk@example.org', 12000, JETZT - 5 * TAG);
  checks(env, dev, 20, JETZT - 1 * STUNDE);
  checks(env, eigen, 20, JETZT - 1 * STUNDE);
  const r = await pruefen(env);
  assert.equal(r.werte.testChecks, 0); assert.equal(r.werte.neueTestwochen24, 0);
  assert.equal(r.werte.kontenVoll, 0); assert.equal(r.werte.einnahmenMonat, 0);
  assert.equal(r.warnung, false);
  /* Ohne die Ausnahme-Liste zählen die Test-Checks des eigenen Kontos, das Entwickler-Konto bleibt draußen. */
  const env2 = umgebung();
  const dev2 = konto(env2, 'ich@example.org', { stufe: 'entwickler', testwocheStart: JETZT - 2 * TAG });
  const eigen2 = konto(env2, 'eigener.test@example.org', { testwocheStart: JETZT - 2 * TAG });
  checks(env2, dev2, 20, JETZT - 1 * STUNDE);
  checks(env2, eigen2, 20, JETZT - 1 * STUNDE);
  const r2 = await pruefen(env2);
  assert.equal(r2.werte.testChecks, 20); assert.equal(r2.warnung, true);
});

test('Wächter: Es zählen nur frische Testwochen-Checks im Zeitraum; Fehlgeschlagene und Checks anderer Stufen nicht', async () => {
  const env = umgebung();
  const k = konto(env, 'a@example.org', { testwocheStart: JETZT - 40 * TAG });
  checks(env, k, 5, JETZT - 31 * TAG);
  checks(env, k, 5, JETZT - 1 * STUNDE, 'test', 'laeuft');
  checks(env, k, 5, JETZT - 1 * STUNDE, 'test', 'fehler');
  checks(env, k, 5, JETZT - 1 * STUNDE, 'mittel');
  checks(env, k, 5, JETZT - 1 * STUNDE, 'voll');
  const r = await pruefen(env);
  assert.equal(r.werte.testChecks, 5); assert.equal(r.werte.testChecks24, 5);
  assert.equal(r.werte.kosten, 5 * 0.45);
});

test('Wächter: Variablen ändern Kosten, Schwellen und Zeitraum; ungültige Werte fallen auf den Standard zurück', async () => {
  const env = umgebung({ KOSTEN_CHECK: '1', WAECHTER_ANTEIL: '0,5', WAECHTER_TAGE: '60', WAECHTER_CHECKS_TAG: '2', WAECHTER_TESTWOCHEN_TAG: '1' });
  konto(env, 'zahler@example.org', { stufe: 'mittel', bis: null });
  beleg(env, 'zahler@example.org', 12000, JETZT - 40 * TAG);
  const k = konto(env, 'a@example.org', { testwocheStart: JETZT - 2 * TAG });
  checks(env, k, 11, JETZT - 40 * TAG);
  const r = await pruefen(env);
  /* Einnahmen im Zeitraum: 10 € je Monat mal 2 Monate = 20 €, Kosten 11 €, Anteil 55 % > 50 %. */
  assert.equal(r.werte.einstellungen.tage, 60);
  assert.equal(r.werte.einnahmenZeitraum, 20); assert.equal(r.werte.kosten, 11);
  assert.deepEqual(r.gruende, ['kosten-anteil']);
  const falsch = umgebung({ KOSTEN_CHECK: 'viel', WAECHTER_ANTEIL: '0', WAECHTER_TAGE: '9999', WAECHTER_CHECKS_TAG: '', WAECHTER_TESTWOCHEN_TAG: 'x' });
  const w = (await pruefen(falsch)).werte.einstellungen;
  const d = await laden();
  assert.deepEqual(w, { kostenCheck: d.WAECHTER_STANDARD.kostenCheck, anteil: 0.2, tage: 30, checksTag: 10, testwochenTag: 5 });
});

test('Wächter: Fehlen die Tabellen, wird nichts geprüft und nichts gesendet; ohne die Wächter-Tabelle auch keine Mail', async () => {
  const env = umgebung();
  env.DB.roh.exec('DROP TABLE check_nutzung');
  const r = await pruefen(env);
  assert.equal(r.geprueft, false); assert.equal(r.warnung, false); assert.equal(env.post.gesendet.length, 0);
  const env2 = umgebung();
  const k = konto(env2, 'a@example.org', { testwocheStart: JETZT - 3 * TAG });
  checks(env2, k, 12, JETZT - 1 * STUNDE);
  env2.DB.roh.exec('DROP TABLE waechter_stand');
  const r2 = await pruefen(env2);
  assert.equal(r2.warnung, true); assert.equal(r2.mail, 'fehlgeschlagen'); assert.equal(env2.post.gesendet.length, 0);
});

test('Wächter: Der Cron-Auslöser läuft über „scheduled“, wartet über waitUntil und wirft nie', async () => {
  const d = await laden();
  assert.equal(typeof d.default.scheduled, 'function');
  const env = umgebung();
  const k = konto(env, 'a@example.org', { testwocheStart: Date.now() - 3 * TAG });
  checks(env, k, 12, Date.now() - 1 * STUNDE);
  const warte = [];
  await d.default.scheduled({}, env, { waitUntil: (p) => warte.push(p) });
  assert.equal(warte.length, 1);
  await Promise.all(warte);
  assert.equal(env.post.gesendet.length, 1);
  /* Ohne Datenbank wirft der Auslöser nicht über die Grenze. */
  const kaputt = { DB: { prepare() { throw new Error('Datenbank weg'); } } };
  const w2 = [];
  await d.default.scheduled({}, kaputt, { waitUntil: (p) => w2.push(p) });
  await Promise.all(w2);
});

test('Wächter: Gesundheit zeigt „waechter“ nur mit Tabelle, Empfänger und Mail-Bindung', async () => {
  const d = await laden();
  async function g(env) {
    const r = await d.behandeln(new Request('https://konto.example.workers.dev/gesundheit', { headers: { Origin: 'https://app.example.org' } }), env, { jetzt: () => JETZT });
    return (await r.json());
  }
  assert.equal((await g(umgebung())).waechter, true);
  assert.equal((await g(umgebung({ WAECHTER_EMAIL: undefined }))).waechter, false);
  assert.equal((await g(umgebung({ EMAIL: undefined }))).waechter, false);
  const ohneTabelle = umgebung(); ohneTabelle.DB.roh.exec('DROP TABLE waechter_stand');
  assert.equal((await g(ohneTabelle)).waechter, false);
});
