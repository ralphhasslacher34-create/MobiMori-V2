'use strict';
/* 2.0.72 (Dienst 13e-4): Bezahlung. PayPal (Bestellung, Rückkehr, Abschluss), Überweisung mit Freischalt-Seite, Beleg, nachgekaufte Recherchen,
   Erinnerung vor dem Ablauf. Dienst mit nachgebauter Datenbank, PayPal, Recherche-Dienst und Mail sind Platzhalter. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

const APP = 'https://app.example.org';
const DIENST = 'https://konto.example.workers.dev';
const TAG = 24 * 60 * 60 * 1000;
const ADMIN = 'admin-passwort-' + 'x'.repeat(20);
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) {
  return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1',
    RECHERCHE_URL: 'https://recherche.example.org', RECHERCHE_TOKEN: 'geheim-token-1',
    PAYPAL_CLIENT_ID: 'client-id-123', PAYPAL_SECRET: 'secret-456',
    UEBERWEISUNG_INHABER: 'Ralph Hasslacher', UEBERWEISUNG_IBAN: 'DE02 1203 0000 0000 2020 51', FREISCHALT_TOKEN: ADMIN,
    BELEG_ANSCHRIFT: 'Ralph Hasslacher\nMusterstraße 1\n74372 Sersheim' }, extra || {});
}
function uhr() { const u = { t: Date.UTC(2026, 10, 12, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
/* Mail-Platzhalter: wird erst nach dem Anmelden eingehängt (im Test-Dienst kommt der Anmelde-Code sonst nicht in der Antwort). */
function mail(env) { const post = { gesendet: [], fehler: false }; env.ABSENDER = 'konto@example.org'; env.EMAIL = { send: async (m) => { if (post.fehler) throw new Error('kaputt'); post.gesendet.push(m); } }; return post; }

/* PayPal-Platzhalter. modus: ok, betrag (falscher Betrag), offen (Zahlung nicht fertig), schon (zweiter Abschluss), nichts (kein Link in der Antwort). */
function paypal() {
  const p = { aufrufe: [], modus: 'ok', n: 0, bestellt: null };
  p.fetch = async (url, o) => {
    p.aufrufe.push({ url, methode: o.method, kopf: o.headers, body: o.body });
    if (/\/v1\/oauth2\/token$/.test(url)) return new Response(JSON.stringify({ access_token: 'zugang' }), { status: 200 });
    if (/\/v2\/checkout\/orders$/.test(url) && o.method === 'POST') {
      p.bestellt = JSON.parse(o.body); p.n += 1; p.orderId = 'ORDER' + p.n;
      if (p.modus === 'nichts') return new Response(JSON.stringify({ id: p.orderId, links: [] }), { status: 200 });
      return new Response(JSON.stringify({ id: p.orderId, status: 'PAYER_ACTION_REQUIRED', links: [{ rel: 'self', href: 'https://api-m.sandbox.paypal.com/v2/checkout/orders/' + p.orderId }, { rel: 'payer-action', href: 'https://www.sandbox.paypal.com/checkoutnow?token=' + p.orderId }] }), { status: 200 });
    }
    const betrag = p.modus === 'betrag' ? '1.00' : p.bestellt.purchase_units[0].amount.value;
    const fertig = { id: p.orderId, status: 'COMPLETED', purchase_units: [{ payments: { captures: [{ id: 'CAP' + p.n, status: p.modus === 'offen' ? 'PENDING' : 'COMPLETED', amount: { currency_code: 'EUR', value: betrag } }] } }] };
    if (/\/capture$/.test(url)) {
      p.abschluesse = (p.abschluesse || 0) + 1;
      if (p.modus === 'schon' && p.abschluesse > 1) return new Response(JSON.stringify({ name: 'UNPROCESSABLE_ENTITY', details: [{ issue: 'ORDER_ALREADY_CAPTURED' }] }), { status: 422 });
      return new Response(JSON.stringify(fertig), { status: 201 });
    }
    return new Response(JSON.stringify(fertig), { status: 200 });
  };
  return p;
}
function recherche() {
  const r = { aufrufe: [], modus: 'ok' };
  r.fetch = async (url, opt) => {
    r.aufrufe.push({ url });
    if (r.modus === 'fehler') return new Response(JSON.stringify({ error: 'KI nicht erreichbar' }), { status: 500 });
    return new Response(JSON.stringify({ ok: true, requirements: [{ id: 'a' }], model: 'm' }), { status: 200 });
  };
  return r;
}

async function roh(env, u, methode, weg, body, token, optionen, kopfExtra) {
  const d = await laden();
  const kopf = Object.assign({ Origin: APP, 'CF-Connecting-IP': '203.0.113.5' }, kopfExtra || {});
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  return d.behandeln(new Request(DIENST + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }),
    env, Object.assign({ jetzt: u.jetzt }, optionen || {}));
}
async function ruf(env, u, methode, weg, body, token, optionen, kopfExtra) { const r = await roh(env, u, methode, weg, body, token, optionen, kopfExtra); return { status: r.status, json: await r.json() }; }
async function anmelden(env, u, email, geraet) {
  u.t += 13 * 60 * 1000;
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email });
  return ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode, geraet });
}
async function konto(env, u, email) { const r = await anmelden(env, u, email, 'Test #' + '0123456789abcdef'.slice(0, 8)); assert.equal(r.status, 200, JSON.stringify(r.json)); return r.json.token; }
function nutzerId(env, email) { return env.DB.roh.prepare('SELECT id FROM nutzer WHERE email = ?').get(email).id; }
function stufeSetzen(env, email, stufe, bis) {
  env.DB.roh.prepare('INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) VALUES (?, ?, ?, ?)').run(nutzerId(env, email), stufe, bis === undefined ? null : bis, 1);
}
function stufeLesen(env, email) { return env.DB.roh.prepare('SELECT stufe, gueltig_bis FROM stufe_konto WHERE nutzer_id = ?').get(nutzerId(env, email)); }
function plusJahr(ms) { const d = new Date(ms); d.setUTCFullYear(d.getUTCFullYear() + 1); return d.getTime(); }
async function bezahlen(env, u, tok, produkt, pp) { return ruf(env, u, 'POST', '/bezahlen/starten', { produkt, weg: 'paypal' }, tok, { fetch: pp.fetch }); }
async function zurueck(env, u, pp, bid) { const r = await roh(env, u, 'GET', '/bezahlen/paypal/zurueck?b=' + bid + '&token=' + pp.orderId, undefined, undefined, { fetch: pp.fetch }); return { status: r.status, text: await r.text() }; }
function offeneId(env) { return env.DB.roh.prepare('SELECT id FROM bestellung ORDER BY erstellt_am DESC').get().id; }

test('Dienst 13e-4: Version, sechs SQL-Zeilen im Schema, Preise', async () => {
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13e-4.sql'), 'utf8').trim().split('\n');
  assert.equal(sql.length, 6);
  sql.forEach((z) => assert.match(z, /^CREATE (TABLE|INDEX) IF NOT EXISTS /));
  const schema = fs.readFileSync(path.join(__dirname, '..', 'server', 'schema.sql'), 'utf8');
  sql.forEach((z) => assert.ok(schema.includes(z)));
  const d = await laden();
  assert.equal(d.VERSION, '13e-4');
  assert.deepEqual(Object.keys(d.PRODUKTE), ['mittel', 'voll', 'recherche5']);
  assert.equal(d.PRODUKTE.mittel.cent, 12 * 499); assert.equal(d.PRODUKTE.voll.cent, 12 * 999); assert.equal(d.PRODUKTE.recherche5.cent, 999); assert.equal(d.PRODUKTE.recherche5.anzahl, 5);
});

test('PayPal: Bestellung anlegen, bezahlen, Rückkehr schaltet Mittel für ein Jahr frei und schickt den Beleg', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  const tok = await konto(env, u, 'kunde@example.org');
  const post = mail(env);
  const s = await bezahlen(env, u, tok, 'mittel', pp);
  assert.equal(s.status, 200, JSON.stringify(s.json));
  assert.equal(s.json.weg, 'paypal'); assert.equal(s.json.betrag, '59,88 €');
  assert.match(s.json.url, /^https:\/\/www\.sandbox\.paypal\.com\/checkoutnow\?token=ORDER1$/);
  /* Anfrage an PayPal: Sandbox, EUR, Betrag, Rückkehr-Adresse mit unserer Nummer, Kennung zum Wiederholen */
  const best = pp.aufrufe.find((a) => /\/v2\/checkout\/orders$/.test(a.url));
  assert.ok(best.url.startsWith('https://api-m.sandbox.paypal.com/'));
  const b = JSON.parse(best.body);
  assert.equal(b.intent, 'CAPTURE'); assert.equal(b.purchase_units[0].amount.value, '59.88'); assert.equal(b.purchase_units[0].amount.currency_code, 'EUR');
  const bid = offeneId(env);
  assert.match(bid, /^MM-[A-Z0-9]{8}$/);
  assert.equal(b.payment_source.paypal.experience_context.return_url, 'https://konto.mobimory.com/bezahlen/paypal/zurueck?b=' + bid);
  assert.equal(best.kopf['PayPal-Request-Id'], bid);
  assert.equal(env.DB.roh.prepare('SELECT paypal_id FROM bestellung WHERE id = ?').get(bid).paypal_id, 'ORDER1');
  assert.equal(stufeLesen(env, 'kunde@example.org'), undefined, 'vor dem Bezahlen keine Freischaltung');
  /* Rückkehr von PayPal */
  const z = await zurueck(env, u, pp, bid);
  assert.equal(z.status, 200); assert.match(z.text, /Danke, die Zahlung ist angekommen/); assert.match(z.text, /MM-2026-0001/);
  const st = stufeLesen(env, 'kunde@example.org');
  assert.equal(st.stufe, 'mittel'); assert.equal(st.gueltig_bis, plusJahr(u.t));
  const bel = env.DB.roh.prepare('SELECT * FROM beleg').all();
  assert.equal(bel.length, 1); assert.equal(bel[0].nummer, 'MM-2026-0001'); assert.equal(bel[0].cent, 5988); assert.equal(bel[0].weg, 'paypal'); assert.equal(bel[0].referenz, 'CAP1'); assert.equal(bel[0].email, 'kunde@example.org');
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM bestellung').get().n, 0);
  /* Beleg-Mail */
  assert.equal(post.gesendet.length, 1);
  const m = post.gesendet[0];
  assert.equal(m.to, 'kunde@example.org'); assert.match(m.subject, /MM-2026-0001/);
  assert.ok(m.text.includes('59,88 €')); assert.ok(m.text.includes('§ 19 UStG')); assert.ok(m.text.includes('Musterstraße 1')); assert.ok(m.text.includes('12.11.2027'));
  assert.ok(m.text.includes('kein Abo'));
  /* Die Seite zweimal öffnen bucht nicht zweimal */
  const z2 = await zurueck(env, u, pp, bid);
  assert.match(z2.text, /Schon verbucht/);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM beleg').get().n, 1); assert.equal(post.gesendet.length, 1);
  /* Die Stufe sieht die App beim Dienst */
  const sx = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(sx.json.stufe.id, 'mittel'); assert.equal(sx.json.stufe.bis, plusJahr(u.t));
});

test('PayPal: Ist die Bestellung schon abgeschlossen (zweiter Aufruf bei PayPal), wird sie nur einmal verbucht', async () => {
  const env = umgebung(), u = uhr(), pp = paypal(); pp.modus = 'schon';
  const tok = await konto(env, u, 'kunde@example.org');
  await bezahlen(env, u, tok, 'voll', pp);
  const bid = offeneId(env);
  /* Der erste Abschluss klappt, aber die Datenbank-Seite geht verloren: Bestellung wieder anlegen und noch einmal öffnen */
  const row = env.DB.roh.prepare('SELECT * FROM bestellung WHERE id = ?').get(bid);
  await zurueck(env, u, pp, bid);
  env.DB.roh.prepare('INSERT INTO bestellung (id, nutzer_id, email, produkt, cent, weg, paypal_id, erstellt_am) VALUES (?, ?, ?, ?, ?, ?, ?, ?)').run(row.id, row.nutzer_id, row.email, row.produkt, row.cent, row.weg, row.paypal_id, row.erstellt_am);
  const z = await zurueck(env, u, pp, bid);
  assert.match(z.text, /Danke/);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM beleg').get().n, 1);
  assert.equal(stufeLesen(env, 'kunde@example.org').stufe, 'voll');
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM bestellung').get().n, 0);
});

test('PayPal: Falscher Betrag, nicht fertige Zahlung oder fehlender Link schalten nichts frei', async () => {
  for (const modus of ['betrag', 'offen']) {
    const env = umgebung(), u = uhr(), pp = paypal(); pp.modus = modus;
    const tok = await konto(env, u, 'kunde@example.org');
    await bezahlen(env, u, tok, 'mittel', pp);
    const z = await zurueck(env, u, pp, offeneId(env));
    assert.match(z.text, modus === 'betrag' ? /Betrag stimmt nicht/ : /nicht abgeschlossen/);
    assert.equal(stufeLesen(env, 'kunde@example.org'), undefined);
    assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM beleg').get().n, 0);
  }
  const env = umgebung(), u = uhr(), pp = paypal(); pp.modus = 'nichts';
  const tok = await konto(env, u, 'kunde@example.org');
  const s = await bezahlen(env, u, tok, 'mittel', pp);
  assert.equal(s.status, 502);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM bestellung').get().n, 0, 'die halbe Bestellung wird entfernt');
  /* Unbekannte oder fremde Nummer */
  const x = await roh(env, u, 'GET', '/bezahlen/paypal/zurueck?b=MM-ABCDEFGH', undefined, undefined, { fetch: pp.fetch });
  assert.match(await x.text(), /Schon verbucht/);
  const y = await roh(env, u, 'GET', '/bezahlen/paypal/zurueck?b=falsch', undefined, undefined, { fetch: pp.fetch });
  assert.equal(y.status, 404);
  const a = await roh(env, u, 'GET', '/bezahlen/paypal/abbruch', undefined, undefined, {});
  assert.match(await a.text(), /Bezahlen abgebrochen/);
});

test('Bezahlen: Ohne Anmeldung nicht, ohne PayPal-Zugang eine klare Meldung, unbekanntes Angebot und Zahlungsweg werden abgewiesen', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  assert.equal((await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal' }, undefined, { fetch: pp.fetch })).status, 401);
  const tok = await konto(env, u, 'kunde@example.org');
  assert.equal((await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'gratis', weg: 'paypal' }, tok, { fetch: pp.fetch })).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'bitcoin' }, tok, { fetch: pp.fetch })).status, 400);
  assert.equal(pp.aufrufe.length, 0);
  const ohne = umgebung({ PAYPAL_CLIENT_ID: undefined });
  const u2 = uhr();
  const tok2 = await konto(ohne, u2, 'kunde@example.org');
  const r = await ruf(ohne, u2, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal' }, tok2, { fetch: pp.fetch });
  assert.equal(r.status, 503); assert.match(r.json.error, /PayPal ist im Dienst noch nicht eingerichtet/);
  /* Der Zugang zu PayPal wird abgelehnt: keine halbe Bestellung bleibt */
  const kaputt = async () => new Response('{}', { status: 401 });
  const k = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal' }, tok, { fetch: kaputt });
  assert.equal(k.status, 502); assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM bestellung').get().n, 0);
});

test('Bezahlen: Verlängern rechnet ab dem Ablauf, Mittel nicht bei laufendem Voll, Entwickler und Basic ohne Online kaufen nicht alles', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  const tok = await konto(env, u, 'kunde@example.org');
  mail(env);
  const bis = u.t + 20 * TAG;
  stufeSetzen(env, 'kunde@example.org', 'mittel', bis);
  await bezahlen(env, u, tok, 'mittel', pp);
  await zurueck(env, u, pp, offeneId(env));
  assert.equal(stufeLesen(env, 'kunde@example.org').gueltig_bis, plusJahr(bis), 'ein Jahr ab dem alten Ablauf');
  /* Wechsel auf Voll beginnt heute */
  await bezahlen(env, u, tok, 'voll', pp);
  await zurueck(env, u, pp, offeneId(env));
  const st = stufeLesen(env, 'kunde@example.org');
  assert.equal(st.stufe, 'voll'); assert.equal(st.gueltig_bis, plusJahr(u.t));
  /* Mittel kaufen, solange Voll läuft: nein */
  const r = await bezahlen(env, u, tok, 'mittel', pp);
  assert.equal(r.status, 400); assert.match(r.json.error, /bereits Voll/);
  /* Entwickler: nichts kaufen */
  stufeSetzen(env, 'kunde@example.org', 'entwickler', null);
  assert.equal((await bezahlen(env, u, tok, 'voll', pp)).status, 400);
  assert.equal(stufeLesen(env, 'kunde@example.org').stufe, 'entwickler');
  /* Basic (Testwoche vorbei): Recherchen nicht, Mittel schon */
  const env2 = umgebung(), u2 = uhr();
  const tok2 = await konto(env2, u2, 'basic@example.org');
  u2.t += 10 * TAG;
  const tok3 = (await anmelden(env2, u2, 'basic@example.org', 'Tab #aaaaaaaa')).json.token;
  const x = await bezahlen(env2, u2, tok3, 'recherche5', pp);
  assert.equal(x.status, 400); assert.match(x.json.error, /ab der Stufe Mittel/);
  assert.equal((await bezahlen(env2, u2, tok3, 'mittel', pp)).status, 200);
  assert.ok(tok2);
});

test('Bezahlen: Kein Entwickler-Konto wird von einer Zahlung überschrieben, Beleg und Gutschrift sind in einem Schritt', async () => {
  const env = umgebung(), u = uhr();
  await konto(env, u, 'ich@example.org');
  stufeSetzen(env, 'ich@example.org', 'entwickler', null);
  const d = await laden();
  /* direkt über die Freischalt-Seite wird abgewiesen */
  const r = await ruf(env, u, 'POST', '/freischalten/direkt', { email: 'ich@example.org', produkt: 'mittel' }, ADMIN);
  assert.equal(r.status, 400);
  assert.equal(stufeLesen(env, 'ich@example.org').stufe, 'entwickler');
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM beleg').get().n, 0);
  assert.ok(d.PRODUKTE);
});

test('Überweisung: Bestellung mit Verwendungszweck und Mail, Freischalten nur mit dem Passwort, danach Beleg und Stufe', async () => {
  const env = umgebung(), u = uhr();
  const tok = await konto(env, u, 'kunde@example.org');
  const post = mail(env);
  const s = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'voll', weg: 'ueberweisung' }, tok);
  assert.equal(s.status, 200, JSON.stringify(s.json));
  assert.equal(s.json.betrag, '119,88 €'); assert.equal(s.json.iban, 'DE02120300000000202051'); assert.equal(s.json.empfaenger, 'Ralph Hasslacher');
  assert.match(s.json.verwendungszweck, /^MM-[A-Z0-9]{8}$/); assert.equal(s.json.mail, true);
  assert.equal(post.gesendet.length, 1); assert.ok(post.gesendet[0].text.includes(s.json.verwendungszweck)); assert.ok(post.gesendet[0].text.includes('119,88 €'));
  assert.equal(stufeLesen(env, 'kunde@example.org'), undefined, 'ohne Geldeingang keine Freischaltung');
  /* Ohne oder mit falschem Passwort */
  assert.equal((await ruf(env, u, 'POST', '/freischalten/liste', {}, undefined)).status, 401);
  assert.equal((await ruf(env, u, 'POST', '/freischalten/liste', {}, 'falsch')).status, 401);
  assert.equal((await ruf(env, u, 'POST', '/freischalten/bestaetigen', { referenz: s.json.referenz }, 'falsch')).status, 401);
  assert.equal(stufeLesen(env, 'kunde@example.org'), undefined);
  /* Liste */
  const l = await ruf(env, u, 'POST', '/freischalten/liste', {}, ADMIN);
  assert.equal(l.status, 200); assert.equal(l.json.bestellungen.length, 1);
  assert.deepEqual(l.json.bestellungen[0], { id: s.json.referenz, email: 'kunde@example.org', angebot: 'Voll (ein Jahr)', betrag: '119,88 €', datum: '12.11.2026' });
  /* Freischalten */
  const f = await ruf(env, u, 'POST', '/freischalten/bestaetigen', { referenz: s.json.referenz.toLowerCase() }, ADMIN);
  assert.equal(f.status, 200); assert.equal(f.json.nummer, 'MM-2026-0001');
  const st = stufeLesen(env, 'kunde@example.org'); assert.equal(st.stufe, 'voll'); assert.equal(st.gueltig_bis, plusJahr(u.t));
  const bel = env.DB.roh.prepare('SELECT weg, cent, referenz FROM beleg').get();
  assert.deepEqual({ weg: bel.weg, cent: bel.cent, referenz: bel.referenz }, { weg: 'ueberweisung', cent: 11988, referenz: s.json.referenz });
  assert.equal(post.gesendet.length, 2); assert.equal(post.gesendet[1].to, 'kunde@example.org'); assert.ok(post.gesendet[1].text.includes('Überweisung'));
  /* zweimal bestätigen geht nicht */
  assert.equal((await ruf(env, u, 'POST', '/freischalten/bestaetigen', { referenz: s.json.referenz }, ADMIN)).status, 404);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM beleg').get().n, 1);
});

test('Überweisung: Höchstens fünf offene, nicht eingerichtet meldet es, Löschen und Direkt-Freischalten funktionieren, Beleg-Nummern zählen fortlaufend', async () => {
  const env = umgebung(), u = uhr();
  const tok = await konto(env, u, 'kunde@example.org');
  mail(env);
  for (let i = 0; i < 5; i++) assert.equal((await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'ueberweisung' }, tok)).status, 200);
  const sechs = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'ueberweisung' }, tok);
  assert.equal(sechs.status, 400); assert.match(sechs.json.error, /Geldeingang/);
  const id = env.DB.roh.prepare('SELECT id FROM bestellung').get().id;
  assert.equal((await ruf(env, u, 'POST', '/freischalten/loeschen', { referenz: id }, ADMIN)).status, 200);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM bestellung').get().n, 4);
  /* direkt freischalten: kein Konto -> 404, mit Konto geht es, zweite Nummer */
  assert.equal((await ruf(env, u, 'POST', '/freischalten/direkt', { email: 'niemand@example.org', produkt: 'mittel' }, ADMIN)).status, 404);
  const d1 = await ruf(env, u, 'POST', '/freischalten/direkt', { email: 'Kunde@Example.org', produkt: 'mittel' }, ADMIN);
  assert.equal(d1.status, 200, JSON.stringify(d1.json)); assert.equal(d1.json.nummer, 'MM-2026-0001');
  const d2 = await ruf(env, u, 'POST', '/freischalten/direkt', { email: 'kunde@example.org', produkt: 'mittel' }, ADMIN);
  assert.equal(d2.json.nummer, 'MM-2026-0002');
  assert.equal(stufeLesen(env, 'kunde@example.org').gueltig_bis, plusJahr(plusJahr(u.t)), 'zweimal Mittel: zwei Jahre');
  /* nicht eingerichtet */
  const ohne = umgebung({ UEBERWEISUNG_IBAN: undefined, FREISCHALT_TOKEN: undefined }), u2 = uhr();
  const tok2 = await konto(ohne, u2, 'kunde@example.org');
  const r = await ruf(ohne, u2, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'ueberweisung' }, tok2);
  assert.equal(r.status, 503); assert.match(r.json.error, /Überweisung ist im Dienst noch nicht eingerichtet/);
  assert.equal((await ruf(ohne, u2, 'POST', '/freischalten/liste', {}, 'irgendwas-langes-xxxxxxxxxxxxxxxx')).status, 503);
});

test('Freischalt-Seite: Die Seite selbst enthält keine Daten, die Bremse greift nach acht falschen Versuchen, derselbe Ursprung braucht keine Freigabe', async () => {
  const env = umgebung(), u = uhr();
  const s = await roh(env, u, 'GET', '/freischalten');
  assert.equal(s.status, 200); assert.match(s.headers.get('Content-Type'), /text\/html/);
  const html = await s.text();
  assert.ok(html.includes('Freischalten')); assert.ok(!html.includes(ADMIN)); assert.ok(!html.includes('DE02'));
  assert.match(s.headers.get('Content-Security-Policy'), /connect-src 'self'/);
  /* Aufruf vom eigenen Ursprung der Seite (Origin = Adresse des Dienstes) */
  const own = await ruf(env, u, 'POST', '/freischalten/liste', {}, ADMIN, undefined, { Origin: DIENST });
  assert.equal(own.status, 200);
  /* Ein fremder Ursprung wird weiter abgelehnt */
  const fremd = await ruf(env, u, 'POST', '/freischalten/liste', {}, ADMIN, undefined, { Origin: 'https://boese.example.net' });
  assert.equal(fremd.status, 403);
  for (let i = 0; i < 8; i++) assert.equal((await ruf(env, u, 'POST', '/freischalten/liste', {}, 'falsch-' + i)).status, 401);
  assert.equal((await ruf(env, u, 'POST', '/freischalten/liste', {}, 'falsch-9')).status, 429);
});

test('Recherchen: 5 für 9,99 € werden gutgeschrieben, nach dem Kontingent benutzt und bei einem Fehler zurückgegeben', async () => {
  const env = umgebung(), u = uhr(), pp = paypal(), rc = recherche();
  const tok = await konto(env, u, 'kunde@example.org');
  mail(env);
  stufeSetzen(env, 'kunde@example.org', 'mittel', u.t + 100 * TAG);
  const dr = env.DB.roh.prepare('SELECT id FROM datenraum').get().id;
  for (let i = 0; i < 3; i++) env.DB.roh.prepare('INSERT INTO check_nutzung (id, datenraum_id, art, stufe, am, status) VALUES (?, ?, ?, ?, ?, ?)').run('c' + i, dr, 'reise', 'mittel', u.t - 1 * TAG, 'ok');
  const ANFRAGE = { trip: { areas: [{ name: 'Schweden' }], von: '2027-06-01' }, vehicle: { art: 'wohnmobil' } };
  const voll = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, tok, { fetch: rc.fetch });
  assert.equal(voll.status, 402); assert.match(voll.json.error, /5 zusätzliche Recherchen kaufen/);
  /* kaufen */
  const s = await bezahlen(env, u, tok, 'recherche5', pp);
  assert.equal(s.json.betrag, '9,99 €');
  const bid = offeneId(env);
  assert.equal(JSON.parse(pp.aufrufe.find((a) => /orders$/.test(a.url)).body).purchase_units[0].amount.value, '9.99');
  await zurueck(env, u, pp, bid);
  assert.equal(env.DB.roh.prepare('SELECT anzahl FROM check_extra').get().anzahl, 5);
  assert.equal(stufeLesen(env, 'kunde@example.org').stufe, 'mittel'); assert.equal(stufeLesen(env, 'kunde@example.org').gueltig_bis, u.t + 100 * TAG, 'die Stufe bleibt unberührt');
  let st = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(st.json.nutzung.extra, 5); assert.equal(st.json.nutzung.checks, 3); assert.equal(st.json.nutzung.checksFrei, 0);
  /* ein Check benutzt eine nachgekaufte Recherche, zählt aber nicht zum Kontingent der Stufe */
  const c = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, tok, { fetch: rc.fetch });
  assert.equal(c.status, 200, JSON.stringify(c.json));
  assert.equal(c.json.kontingent.genutzt, 3); assert.equal(c.json.kontingent.extraFrei, 4);
  assert.equal(env.DB.roh.prepare("SELECT COUNT(*) AS n FROM check_nutzung WHERE stufe = 'extra'").get().n, 1);
  assert.equal(env.DB.roh.prepare('SELECT anzahl FROM check_extra').get().anzahl, 4);
  /* schlägt die Recherche fehl, bekommt er die Recherche zurück */
  rc.modus = 'fehler';
  const f = await ruf(env, u, 'POST', '/check/senden', { art: 'tag', anfrage: ANFRAGE }, tok, { fetch: rc.fetch });
  assert.equal(f.status, 502);
  assert.equal(env.DB.roh.prepare('SELECT anzahl FROM check_extra').get().anzahl, 4);
  assert.equal(env.DB.roh.prepare("SELECT COUNT(*) AS n FROM check_nutzung WHERE stufe = 'extra'").get().n, 1);
  /* ein gespeicherter Check kostet nichts */
  rc.modus = 'ok';
  const g = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE, quelle: 'gespeichert' }, tok, { fetch: rc.fetch });
  assert.equal(g.status, 200); assert.equal(env.DB.roh.prepare('SELECT anzahl FROM check_extra').get().anzahl, 4);
  /* Beleg über 9,99 € */
  assert.equal(env.DB.roh.prepare('SELECT cent FROM beleg').get().cent, 999);
});

test('Recherchen: Solange das Kontingent reicht, bleiben die nachgekauften unberührt; leere nachgekaufte bringen die alte Meldung', async () => {
  const env = umgebung(), u = uhr(), rc = recherche();
  const tok = await konto(env, u, 'kunde@example.org');
  stufeSetzen(env, 'kunde@example.org', 'voll', u.t + 100 * TAG);
  env.DB.roh.prepare('INSERT INTO check_extra (nutzer_id, anzahl) VALUES (?, ?)').run(nutzerId(env, 'kunde@example.org'), 2);
  const ANFRAGE = { trip: { areas: [{ name: 'Schweden' }], von: '2027-06-01' }, vehicle: { art: 'wohnmobil' } };
  const c = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, tok, { fetch: rc.fetch });
  assert.equal(c.status, 200); assert.equal(c.json.kontingent.genutzt, 1); assert.equal(c.json.kontingent.extraFrei, undefined);
  assert.equal(env.DB.roh.prepare('SELECT anzahl FROM check_extra').get().anzahl, 2);
  env.DB.roh.prepare('UPDATE check_extra SET anzahl = 0').run();
  const dr = env.DB.roh.prepare('SELECT id FROM datenraum').get().id;
  for (let i = 0; i < 9; i++) env.DB.roh.prepare('INSERT INTO check_nutzung (id, datenraum_id, art, stufe, am, status) VALUES (?, ?, ?, ?, ?, ?)').run('x' + i, dr, 'tag', 'voll', u.t - 1 * TAG, 'ok');
  const z = await ruf(env, u, 'POST', '/check/senden', { art: 'tag', anfrage: ANFRAGE }, tok, { fetch: rc.fetch });
  assert.equal(z.status, 402); assert.match(z.json.error, /Kontingent ist aufgebraucht/);
});

test('Erinnerung: 30 Tage und 7 Tage vor dem Ablauf je eine Mail mit PayPal-Link, nie doppelt, nie zu früh', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  await konto(env, u, 'kunde@example.org');
  await konto(env, u, 'spaet@example.org');
  await konto(env, u, 'frei@example.org');
  const post = mail(env);
  const d = await laden();
  stufeSetzen(env, 'kunde@example.org', 'mittel', u.t + 20 * TAG);
  stufeSetzen(env, 'spaet@example.org', 'voll', u.t + 60 * TAG);
  stufeSetzen(env, 'frei@example.org', 'entwickler', null);
  let r = await d.erinnerungenSenden(env, env.DB, u.t);
  assert.deepEqual(r, { gesendet: 1, fehler: 0 });
  assert.equal(post.gesendet[0].to, 'kunde@example.org');
  const text = post.gesendet[0].text;
  assert.match(post.gesendet[0].subject, /Mittel läuft bald ab/);
  assert.ok(text.includes('32.12.2026') === false && text.includes('02.12.2026'), 'Ablaufdatum 02.12.2026');
  assert.ok(text.includes('59,88 €')); assert.ok(text.includes('12 × 4,99 €')); assert.ok(text.includes('kein Abo'));
  const link = /https:\/\/konto\.mobimory\.com\/bezahlen\/verlaengern\?t=[A-Za-z0-9_.-]+/.exec(text);
  assert.ok(link, 'Link in der Mail');
  /* gleicher Tag noch einmal: nichts */
  r = await d.erinnerungenSenden(env, env.DB, u.t + 1 * TAG);
  assert.equal(r.gesendet, 0);
  /* 6 Tage vor Ablauf: die zweite Mail */
  r = await d.erinnerungenSenden(env, env.DB, u.t + 14 * TAG);
  assert.equal(r.gesendet, 1); assert.match(post.gesendet[1].text, /in 6 Tagen/);
  r = await d.erinnerungenSenden(env, env.DB, u.t + 15 * TAG);
  assert.equal(r.gesendet, 0);
  /* Wer erst kurz vor Ablauf in den Zeitraum kommt, bekommt nur die 7-Tage-Mail */
  r = await d.erinnerungenSenden(env, env.DB, u.t + 56 * TAG);
  assert.equal(r.gesendet, 1); assert.equal(post.gesendet[2].to, 'spaet@example.org'); assert.match(post.gesendet[2].text, /in 4 Tagen/);
  /* Nach dem Ablauf keine Erinnerung mehr */
  r = await d.erinnerungenSenden(env, env.DB, u.t + 100 * TAG);
  assert.equal(r.gesendet, 0);
  /* Der Link leitet zu PayPal */
  const u2 = Object.assign({}, u);
  const wegLink = link[0].replace('https://konto.mobimory.com', '');
  const g = await roh(env, u2, 'GET', wegLink, undefined, undefined, { fetch: pp.fetch });
  assert.equal(g.status, 302); assert.match(g.headers.get('Location'), /^https:\/\/www\.sandbox\.paypal\.com\/checkoutnow\?token=ORDER1$/);
  assert.equal(JSON.parse(pp.aufrufe.find((a) => /orders$/.test(a.url)).body).purchase_units[0].amount.value, '59.88');
  assert.equal(env.DB.roh.prepare('SELECT email, produkt FROM bestellung').get().email, 'kunde@example.org');
  /* verfälscht oder abgelaufen */
  const kaputt = await roh(env, u2, 'GET', wegLink.slice(0, -3) + 'abc', undefined, undefined, { fetch: pp.fetch });
  assert.equal(kaputt.status, 400);
  const spaeter = uhr(); spaeter.t = u.t + 200 * TAG;
  const alt = await roh(env, spaeter, 'GET', wegLink, undefined, undefined, { fetch: pp.fetch });
  assert.equal(alt.status, 400); assert.match(await alt.text(), /gilt nicht mehr/);
});

test('Erinnerung: Schlägt die Mail fehl, wird es beim nächsten Lauf noch einmal versucht; ohne PayPal steht kein Link in der Mail', async () => {
  const env = umgebung({ PAYPAL_CLIENT_ID: undefined }), u = uhr();
  await konto(env, u, 'kunde@example.org');
  const post = mail(env);
  const d = await laden();
  stufeSetzen(env, 'kunde@example.org', 'mittel', u.t + 5 * TAG);
  post.fehler = true;
  let r = await d.erinnerungenSenden(env, env.DB, u.t);
  assert.deepEqual(r, { gesendet: 0, fehler: 1 });
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM erinnerung').get().n, 0);
  post.fehler = false;
  r = await d.erinnerungenSenden(env, env.DB, u.t + 15 * 60 * 1000);
  assert.equal(r.gesendet, 1);
  assert.ok(!post.gesendet[0].text.includes('/bezahlen/verlaengern')); assert.ok(post.gesendet[0].text.includes('Konto › Deine Stufe'));
});

test('Erinnerung: Der Cron-Auslöser sendet sie mit und wirft nie', async () => {
  const d = await laden();
  const env = umgebung(), u = { t: Date.now() };
  const uh = { jetzt: () => u.t };
  await konto(env, uh, 'kunde@example.org');
  const post = mail(env);
  stufeSetzen(env, 'kunde@example.org', 'voll', Date.now() + 3 * TAG);
  const warte = [];
  await d.default.scheduled({}, env, { waitUntil: (p) => warte.push(p) });
  await Promise.all(warte);
  assert.equal(post.gesendet.filter((m) => /läuft bald ab/.test(m.subject)).length, 1);
  const kaputt = { DB: { prepare() { throw new Error('Datenbank weg'); } } };
  const w2 = [];
  await d.default.scheduled({}, kaputt, { waitUntil: (p) => w2.push(p) });
  await Promise.all(w2);
});

test('Wächter: Einnahmen sind die echten Belege, Bezahlen füllt sie', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  const tok = await konto(env, u, 'kunde@example.org');
  mail(env);
  await bezahlen(env, u, tok, 'mittel', pp);
  await zurueck(env, u, pp, offeneId(env));
  const d = await laden();
  const r = await d.waechterPruefen(env, env.DB, u.t);
  assert.equal(r.geprueft, true);
  assert.equal(Math.round(r.werte.einnahmenMonat * 100), 499, '59,88 € durch 12 = 4,99 €');
  assert.equal(r.werte.kontenMittel, 1);
});

test('Gesundheit: Bezahlung meldet nur ja oder nein, nie einen Wert', async () => {
  const d = await laden();
  async function g(env) { const r = await d.behandeln(new Request(DIENST + '/gesundheit', { headers: { Origin: APP } }), env, { jetzt: () => Date.UTC(2026, 10, 12) }); return r.json(); }
  const voll = await g(umgebung());
  assert.deepEqual(voll.bezahlung, { tabellen: true, paypal: true, paypalEchtgeld: false, ueberweisung: true, freischalten: true, beleg: true });
  assert.ok(!JSON.stringify(voll).includes('client-id-123')); assert.ok(!JSON.stringify(voll).includes('DE02')); assert.ok(!JSON.stringify(voll).includes(ADMIN));
  const leer = await g(umgebung({ PAYPAL_CLIENT_ID: undefined, UEBERWEISUNG_IBAN: undefined, FREISCHALT_TOKEN: undefined, BELEG_ANSCHRIFT: undefined, PAYPAL_LIVE: '1' }));
  assert.deepEqual(leer.bezahlung, { tabellen: true, paypal: false, paypalEchtgeld: true, ueberweisung: false, freischalten: false, beleg: false });
  const ohneTabellen = umgebung(); ohneTabellen.DB.roh.exec('DROP TABLE zaehler');
  assert.equal((await g(ohneTabellen)).bezahlung.tabellen, false);
});

test('Echtgeld: Mit PAYPAL_LIVE geht der Dienst an die echte PayPal-Adresse, sonst an die Sandbox', async () => {
  const env = umgebung({ PAYPAL_LIVE: '1' }), u = uhr(), pp = paypal();
  const tok = await konto(env, u, 'kunde@example.org');
  await bezahlen(env, u, tok, 'mittel', pp);
  assert.ok(pp.aufrufe.every((a) => a.url.startsWith('https://api-m.paypal.com/')));
  assert.equal(pp.aufrufe[0].kopf.Authorization, 'Basic ' + Buffer.from('client-id-123:secret-456').toString('base64'));
});

test('Aufräumen und Löschen: Alte offene Bestellungen verschwinden, beim Löschen eines Kontos bleiben nur die Belege', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  const tok = await konto(env, u, 'kunde@example.org');
  mail(env);
  await bezahlen(env, u, tok, 'mittel', pp);            /* offene PayPal-Bestellung */
  await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'ueberweisung' }, tok);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM bestellung').get().n, 2);
  u.t += 4 * TAG;
  await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'andere@example.org' });
  assert.equal(env.DB.roh.prepare("SELECT COUNT(*) AS n FROM bestellung WHERE weg = 'paypal'").get().n, 0, 'PayPal-Bestellungen nach 3 Tagen weg');
  assert.equal(env.DB.roh.prepare("SELECT COUNT(*) AS n FROM bestellung WHERE weg = 'ueberweisung'").get().n, 1, 'Überweisungen warten länger');
  u.t += 61 * TAG;
  await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'andere2@example.org' });
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM bestellung').get().n, 0);
  /* Löschen: Belege bleiben (Buchhaltung), Gutschrift und Erinnerungen gehen mit dem Konto */
  const tok2 = tok; /* die Anmeldung gilt 90 Tage und wird verlängert */
  stufeSetzen(env, 'kunde@example.org', 'mittel', u.t + 100 * TAG);
  await bezahlen(env, u, tok2, 'recherche5', pp);
  await zurueck(env, u, pp, offeneId(env));
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM check_extra').get().n, 1);
  const l = await ruf(env, u, 'POST', '/konto/loeschen', { bestaetigung: 'LÖSCHEN' }, tok2);
  assert.equal(l.status, 200);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM check_extra').get().n, 0);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM beleg').get().n, 1);
});
