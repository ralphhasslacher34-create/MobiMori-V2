'use strict';
/* 2.0.68 (Schritt 13e): Stufen, Testwoche, Geräte-Grenze, Online-Checks über den Konto-Dienst mit Zählung auf dem Server, gespeicherte Checks.
   Dienst mit nachgebauter Datenbank, der Recherche-Dienst ist ein Platzhalter. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

const APP = 'https://app.example.org';
const PW = 'Sehr-sicheres-Passwort-1';
const TAG = 24 * 60 * 60 * 1000;
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) {
  return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1',
    RECHERCHE_URL: 'https://recherche.example.org', RECHERCHE_TOKEN: 'geheim-token-1' }, extra || {});
}
function uhr() { const u = { t: Date.UTC(2026, 10, 12, 12, 0, 0) }; u.jetzt = () => u.t; return u; }

/* Platzhalter für den Recherche-Dienst: zählt die Aufrufe und merkt sich, was ankam. */
function recherche() {
  const r = { aufrufe: [], modus: 'ok' };
  r.fetch = async (url, opt) => {
    r.aufrufe.push({ url, token: opt.headers['X-Mobimory-Token'], origin: opt.headers.Origin, body: JSON.parse(opt.body) });
    if (r.modus === 'netz') throw new Error('kein Netz');
    if (r.modus === 'fehler') return new Response(JSON.stringify({ error: 'KI nicht erreichbar' }), { status: 500 });
    if (r.modus === 'text') return new Response('<html>kaputt</html>', { status: 200 });
    return new Response(JSON.stringify({ ok: true, requirements: [{ id: 'a' }], model: 'm' }), { status: 200 });
  };
  return r;
}

async function roh(env, u, methode, weg, body, token, optionen) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  return d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }),
    env, Object.assign({ jetzt: u.jetzt }, optionen || {}));
}
async function ruf(env, u, methode, weg, body, token, optionen) { const r = await roh(env, u, methode, weg, body, token, optionen); return { status: r.status, json: await r.json() }; }
/* Anmelden per Code, wie es die App tut (mit Gerätekennung). */
async function anmelden(env, u, email, geraet) {
  u.t += 13 * 60 * 1000; /* die Bremse erlaubt fünf Codes je Stunde und Adresse */
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email });
  return ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode, geraet });
}
async function konto(env, u, email) { const r = await anmelden(env, u, email, 'Test #' + '0123456789abcdef'.slice(0, 8)); assert.equal(r.status, 200, JSON.stringify(r.json)); return r.json.token; }
function stufeSetzen(env, email, stufe, bis) {
  const n = env.DB.roh.prepare('SELECT id FROM nutzer WHERE email = ?').get(email);
  env.DB.roh.prepare('INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) VALUES (?, ?, ?, ?)').run(n.id, stufe, bis === undefined ? null : bis, 1);
}
const ANFRAGE = { trip: { areas: [{ name: 'Schweden' }], von: '2027-06-01' }, vehicle: { art: 'wohnmobil' } };

test('Dienst: Version 13e-4, Gesundheit meldet Stufen und Recherche; die SQL-Datei hat sechs einzelne Zeilen', async () => {
  const env = umgebung(), u = uhr();
  const g = await ruf(env, u, 'GET', '/gesundheit');
  assert.equal(g.json.version, '13e-4'); assert.equal(g.json.stufen, true); assert.equal(g.json.recherche, true);
  const ohne = await ruf(umgebung({ RECHERCHE_URL: undefined }), u, 'GET', '/gesundheit');
  assert.equal(ohne.json.recherche, false);
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13e.sql'), 'utf8').trim().split('\n');
  assert.equal(sql.length, 6);
  sql.forEach((z) => assert.match(z, /^CREATE (TABLE|INDEX) IF NOT EXISTS /));
  assert.ok(fs.readFileSync(path.join(__dirname, '..', 'server', 'schema.sql'), 'utf8').includes(sql[0]));
});

test('Testwoche: Neue Nutzer bekommen sieben Tage auf Mittel-Niveau mit einem Check, danach Basic; einmal je E-Mail-Adresse', async () => {
  const env = umgebung(), u = uhr();
  const tok = await konto(env, u, 'neu@example.org');
  let s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.stufe.id, 'test'); assert.equal(s.json.stufe.bis, u.t + 7 * TAG);
  assert.deepEqual(s.json.grenzen, { geraete: 4, checks: 1, fahrzeuge: 3, online: true });
  assert.equal(s.json.nutzung.checksFrei, 1);
  /* nach der Testwoche: Basic, ohne Online */
  u.t += 8 * TAG;
  const tok2 = (await anmelden(env, u, 'neu@example.org', 'Tab #aaaaaaaa')).json.token;
  s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok2);
  assert.equal(s.json.stufe.id, 'basic'); assert.deepEqual(s.json.grenzen, { geraete: 2, checks: 0, fahrzeuge: 1, online: false });
  /* Konto löschen und neu anlegen: keine zweite Testwoche */
  const l = await ruf(env, u, 'POST', '/konto/loeschen', { bestaetigung: 'LÖSCHEN' }, tok2);
  assert.equal(l.status, 200);
  const tok3 = (await anmelden(env, u, 'neu@example.org', 'Tab #bbbbbbbb')).json.token;
  s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok3);
  assert.equal(s.json.stufe.id, 'basic');
  /* in der Datenbank steht nur ein Abdruck, nie die Adresse */
  const z = env.DB.roh.prepare('SELECT * FROM testwoche').all();
  assert.equal(z.length, 1); assert.ok(!JSON.stringify(z).includes('neu@example.org'));
  /* Ein Konto, das schon vor 13e bestand und sich nur wieder anmeldet, bekommt keine Testwoche */
  const env2 = umgebung(); const u2 = uhr();
  await konto(env2, u2, 'alt@example.org');
  env2.DB.roh.exec('DELETE FROM testwoche');
  u2.t += 1 * TAG;
  const tokAlt = (await anmelden(env2, u2, 'alt@example.org', 'Tab #cccccccc')).json.token;
  assert.equal((await ruf(env2, u2, 'GET', '/konto/stufe', undefined, tokAlt)).json.stufe.id, 'basic');
});

test('Stufe: Mittel und Voll aus der Tabelle, abgelaufen zählt als nicht bezahlt; Zustand ohne Anmeldung wird abgewiesen', async () => {
  const env = umgebung(), u = uhr();
  const tok = await konto(env, u, 'zahler@example.org');
  stufeSetzen(env, 'zahler@example.org', 'mittel', u.t + 30 * TAG);
  let s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.stufe.id, 'mittel'); assert.equal(s.json.grenzen.checks, 3); assert.equal(s.json.grenzen.geraete, 4);
  stufeSetzen(env, 'zahler@example.org', 'voll', null);
  s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.stufe.id, 'voll'); assert.equal(s.json.grenzen.checks, 10); assert.equal(s.json.grenzen.geraete, 10); assert.equal(s.json.grenzen.fahrzeuge, null);
  stufeSetzen(env, 'zahler@example.org', 'voll', u.t - 1);
  s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.stufe.id, 'test');
  stufeSetzen(env, 'zahler@example.org', 'gold', null);
  assert.equal((await ruf(env, u, 'GET', '/konto/stufe', undefined, tok)).json.stufe.id, 'test');
  assert.equal((await ruf(env, u, 'GET', '/konto/stufe')).status, 401);
});

test('Geräte: Die Stufe begrenzt die Geräte, dasselbe Gerät zählt nur einmal, Abmelden macht einen Platz frei', async () => {
  const env = umgebung(), u = uhr();
  const mail = 'geraete@example.org';
  const toks = [];
  for (let i = 0; i < 4; i++) { const r = await anmelden(env, u, mail, 'MobiMory 2.0.69 #1000000' + i); assert.equal(r.status, 200, JSON.stringify(r.json)); toks.push(r.json.token); }
  const f = await anmelden(env, u, mail, 'MobiMory 2.0.69 #10000009');
  assert.equal(f.status, 403); assert.match(f.json.error, /höchstens 4 Geräte/); assert.equal(f.json.geraeteGrenze, 4);
  /* dasselbe Gerät noch einmal (auch mit neuer Versionsnummer): ersetzt die alte Sitzung */
  const nochmal = await anmelden(env, u, mail, 'MobiMory 2.0.99 #10000001');
  assert.equal(nochmal.status, 200);
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, toks[1])).status, 401);
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, nochmal.json.token)).status, 200);
  /* abmelden macht Platz */
  assert.equal((await ruf(env, u, 'POST', '/konto/abmelden', {}, toks[0])).status, 200);
  assert.equal((await anmelden(env, u, mail, 'MobiMory 2.0.69 #10000009')).status, 200);
  const s = await ruf(env, u, 'GET', '/konto/stufe', undefined, toks[2]);
  assert.equal(s.json.nutzung.geraete, 4);
  /* nach der Testwoche gilt Basic mit zwei Geräten, bezahlt Voll mit zehn */
  u.t += 8 * TAG;
  const env2 = umgebung(), u2 = uhr();
  await konto(env2, u2, 'basic@example.org');
  u2.t += 8 * TAG;
  assert.equal((await anmelden(env2, u2, 'basic@example.org', 'MobiMory #20000001')).status, 200);
  const dritt = await anmelden(env2, u2, 'basic@example.org', 'MobiMory #20000002');
  assert.equal(dritt.status, 403); assert.match(dritt.json.error, /Stufe Basic sind höchstens 2 Geräte/);
  stufeSetzen(env2, 'basic@example.org', 'voll', null);
  for (let i = 0; i < 8; i++) assert.equal((await anmelden(env2, u2, 'basic@example.org', 'MobiMory #3000000' + i)).status, 200, 'Gerät ' + i);
  assert.equal((await anmelden(env2, u2, 'basic@example.org', 'MobiMory #30000099')).status, 403);
});

test('Online-Check: Anmeldung, Art und Anfrage werden geprüft; der Recherche-Dienst bekommt Adresse, Passwort und die Anfrage unverändert', async () => {
  const env = umgebung(), u = uhr(), rc = recherche();
  const o = { fetch: rc.fetch };
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, undefined, o)).status, 401);
  const tok = await konto(env, u, 'check@example.org');
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'xyz', anfrage: ANFRAGE }, tok, o)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise' }, tok, o)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: [1] }, tok, o)).status, 400);
  assert.equal(rc.aufrufe.length, 0);
  const r = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, tok, o);
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.gespeichert, false); assert.equal(r.json.antwort.ok, true);
  assert.deepEqual(r.json.kontingent, { genutzt: 1, grenze: 1, stufe: 'test' });
  assert.equal(rc.aufrufe.length, 1);
  assert.equal(rc.aufrufe[0].url, 'https://recherche.example.org/research'); assert.equal(rc.aufrufe[0].token, 'geheim-token-1');
  assert.equal(rc.aufrufe[0].origin, APP, 'der Recherche-Dienst kennt nur erlaubte App-Adressen, der Konto-Dienst meldet sich mit der ersten');
  assert.deepEqual(rc.aufrufe[0].body, ANFRAGE);
  /* das Passwort des Recherche-Dienstes steht in keiner Antwort */
  assert.ok(!JSON.stringify(r.json).includes('geheim-token-1'));
});

test('Kontingent: Die Testwoche hat einen Check, danach 402 ohne Aufruf; Mittel hat drei, Voll zehn; Testwoche-Checks zählen nicht gegen Mittel', async () => {
  const env = umgebung(), u = uhr(), rc = recherche(); const o = { fetch: rc.fetch };
  const tok = await konto(env, u, 'zaehl@example.org');
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, tok, o)).status, 200);
  const zu = await ruf(env, u, 'POST', '/check/senden', { art: 'tag', anfrage: ANFRAGE }, tok, o);
  assert.equal(zu.status, 402); assert.match(zu.json.error, /1 von 1/); assert.equal(zu.json.genutzt, 1); assert.equal(zu.json.grenze, 1);
  assert.equal(rc.aufrufe.length, 1, 'ohne Kontingent geht nichts zum Recherche-Dienst');
  let s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.nutzung.checks, 1); assert.equal(s.json.nutzung.checksFrei, 0);
  /* bezahlt: Mittel mit drei Checks, der Check der Testwoche zählt nicht mit */
  stufeSetzen(env, 'zaehl@example.org', 'mittel', null);
  s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.nutzung.checks, 0); assert.equal(s.json.nutzung.checksFrei, 3);
  for (let i = 0; i < 3; i++) {
    const art = ['reise', 'tag', 'grund'][i];
    const r = await ruf(env, u, 'POST', '/check/senden', { art, anfrage: Object.assign({}, ANFRAGE, { n: i }) }, tok, o);
    assert.equal(r.status, 200, 'Check ' + i + ' ' + JSON.stringify(r.json)); assert.equal(r.json.kontingent.genutzt, i + 1);
  }
  const vier = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: Object.assign({}, ANFRAGE, { n: 9 }) }, tok, o);
  assert.equal(vier.status, 402); assert.match(vier.json.error, /3 von 3/);
  /* nach einem Jahr ist das Kontingent wieder frei */
  u.t += 366 * TAG;
  const tokNeu = (await anmelden(env, u, 'zaehl@example.org', 'Tab #dddddddd')).json.token;
  assert.equal((await ruf(env, u, 'GET', '/konto/stufe', undefined, tokNeu)).json.nutzung.checksFrei, 3);
  /* Voll: zehn */
  stufeSetzen(env, 'zaehl@example.org', 'voll', null);
  assert.equal((await ruf(env, u, 'GET', '/konto/stufe', undefined, tokNeu)).json.nutzung.checksFrei, 10);
});

test('Kontingent: Basic hat keine Online-Checks, jedes Konto hat sein eigenes Kontingent, die Zählung liegt auf dem Server', async () => {
  const env = umgebung(), u = uhr(), rc = recherche(); const o = { fetch: rc.fetch };
  const a = await konto(env, u, 'a@example.org'), b = await konto(env, u, 'b@example.org');
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, a, o)).status, 200);
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, b, o)).status, 200, 'das zweite Konto hat ein eigenes Kontingent');
  u.t += 8 * TAG;
  const basic = (await anmelden(env, u, 'a@example.org', 'Tab #eeeeeeee')).json.token;
  const r = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, basic, o);
  assert.equal(r.status, 402); assert.match(r.json.error, /ab der Stufe Mittel/); assert.equal(r.json.stufe, 'basic');
  assert.equal(rc.aufrufe.length, 2);
  /* eine neue Anmeldung setzt keinen Zähler zurück: er liegt in der Datenbank des Dienstes */
  assert.equal(env.DB.roh.prepare("SELECT COUNT(*) AS n FROM check_nutzung WHERE status = 'ok'").get().n, 2);
});

test('Fehler bei der Recherche: Der Check wird nicht gezählt (Netz, Fehlerantwort, kein JSON, Dienst nicht eingetragen)', async () => {
  const env = umgebung(), u = uhr(), rc = recherche(); const o = { fetch: rc.fetch };
  const tok = await konto(env, u, 'fehler@example.org');
  for (const modus of ['netz', 'fehler', 'text']) {
    rc.modus = modus;
    const r = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, tok, o);
    assert.equal(r.status, 502, modus); assert.match(r.json.error, /nicht gezählt/);
    if (modus === 'fehler') assert.match(r.json.error, /KI nicht erreichbar/);
    assert.equal((await ruf(env, u, 'GET', '/konto/stufe', undefined, tok)).json.nutzung.checks, 0, modus);
  }
  rc.modus = 'ok';
  const ohne = umgebung({ RECHERCHE_URL: undefined });
  const tok2 = await konto(ohne, u, 'ohne@example.org');
  const r = await ruf(ohne, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, tok2, o);
  assert.equal(r.status, 503); assert.match(r.json.error, /noch nicht eingetragen/);
  assert.equal((await ruf(ohne, u, 'GET', '/konto/stufe', undefined, tok2)).json.nutzung.checks, 0);
  /* danach klappt es, das Kontingent ist noch da */
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, tok, o)).status, 200);
});

test('Check-Datenbank: Das Ergebnis wird gespeichert, ein gespeicherter Check zählt nicht, die Reihenfolge der Felder spielt keine Rolle, ohne Treffer 404', async () => {
  const env = umgebung(), u = uhr(), rc = recherche(); const o = { fetch: rc.fetch };
  const tok = await konto(env, u, 'db@example.org');
  stufeSetzen(env, 'db@example.org', 'mittel', null);
  const frisch = await ruf(env, u, 'POST', '/check/senden', { art: 'grund', anfrage: { b: 2, a: { y: 1, x: 2 } } }, tok, o);
  assert.equal(frisch.status, 200);
  u.t += 3 * TAG;
  const g = await ruf(env, u, 'POST', '/check/senden', { art: 'grund', anfrage: { a: { x: 2, y: 1 }, b: 2 }, quelle: 'gespeichert' }, tok, o);
  assert.equal(g.status, 200); assert.equal(g.json.gespeichert, true); assert.equal(g.json.antwort.ok, true);
  assert.ok(g.json.stand < u.t, 'der Stand ist das Datum des frischen Checks');
  assert.match(g.json.hinweis, /veraltet/); assert.match(g.json.hinweis, /2026-11-12/);
  assert.equal(rc.aufrufe.length, 1, 'der gespeicherte Check ruft den Recherche-Dienst nicht auf');
  assert.equal((await ruf(env, u, 'GET', '/konto/stufe', undefined, tok)).json.nutzung.checks, 1, 'und zählt nicht');
  const nix = await ruf(env, u, 'POST', '/check/senden', { art: 'grund', anfrage: { z: 1 }, quelle: 'gespeichert' }, tok, o);
  assert.equal(nix.status, 404); assert.equal(rc.aufrufe.length, 1);
  /* gleiche Anfrage, andere Art: anderer Eintrag */
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: { b: 2, a: { y: 1, x: 2 } }, quelle: 'gespeichert' }, tok, o)).status, 404);
  /* auch ein gespeicherter Check braucht Mittel oder besser */
  u.t += 8 * TAG;
  stufeSetzen(env, 'db@example.org', 'mittel', u.t - 1);
  const tokB = (await anmelden(env, u, 'db@example.org', 'Tab #ffffffff')).json.token;
  assert.equal((await ruf(env, u, 'POST', '/check/senden', { art: 'grund', anfrage: { a: { x: 2, y: 1 }, b: 2 }, quelle: 'gespeichert' }, tokB, o)).status, 402);
});

test('Check: Zu viele Checks hintereinander werden gebremst, ein falscher Platzhalter wird nicht mitgezählt', async () => {
  const env = umgebung(), u = uhr(), rc = recherche(); const o = { fetch: rc.fetch };
  const tok = await konto(env, u, 'bremse@example.org');
  stufeSetzen(env, 'bremse@example.org', 'voll', null);
  rc.modus = 'fehler';
  let letzter;
  for (let i = 0; i < 9; i++) letzter = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: ANFRAGE }, tok, o);
  assert.equal(letzter.status, 429); assert.match(letzter.json.error, /zu viele Checks/);
});

test('Stufe Entwickler: Geräte und Online-Checks ohne Grenze, nur die Bremse gegen zu viele Checks hintereinander bleibt, Zählung läuft weiter', async () => {
  const env = umgebung(), u = uhr(), rc = recherche(); const o = { fetch: rc.fetch };
  const mail = 'entwickler@example.org';
  const tok = await konto(env, u, mail);
  stufeSetzen(env, mail, 'entwickler', null);
  let s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.stufe.id, 'entwickler'); assert.equal(s.json.stufe.name, 'Entwickler');
  assert.deepEqual(s.json.grenzen, { geraete: null, checks: null, fahrzeuge: null, online: true });
  assert.equal(s.json.nutzung.checksFrei, null);
  /* zwölf Checks, mit Pausen wegen der Bremse (8 je 10 Minuten) */
  for (let i = 0; i < 12; i++) {
    if (i % 6 === 5) u.t += 11 * 60 * 1000;
    const r = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: Object.assign({}, ANFRAGE, { n: i }) }, tok, o);
    assert.equal(r.status, 200, 'Check ' + i + ' ' + JSON.stringify(r.json)); assert.equal(r.json.kontingent.grenze, null); assert.equal(r.json.kontingent.stufe, 'entwickler');
  }
  assert.equal(rc.aufrufe.length, 12);
  s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.nutzung.checks, 12);
  /* zwölf Geräte */
  for (let i = 0; i < 12; i++) assert.equal((await anmelden(env, u, mail, 'MobiMory #4000000' + (i < 10 ? '0' + i : i))).status, 200, 'Gerät ' + i);
  /* die Bremse gilt auch hier */
  let letzter;
  for (let i = 0; i < 9; i++) letzter = await ruf(env, u, 'POST', '/check/senden', { art: 'reise', anfrage: Object.assign({}, ANFRAGE, { n: 100 + i }) }, tok, o);
  assert.equal(letzter.status, 429);
  /* nur ein Eintrag per SQL: Eine Stufe mit unbekanntem Namen wirkt nicht */
  stufeSetzen(env, mail, 'unbegrenzt', null);
  assert.equal((await ruf(env, u, 'GET', '/konto/stufe', undefined, tok)).json.stufe.id, 'test');
});
