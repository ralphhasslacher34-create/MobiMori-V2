'use strict';
/* 2.0.91 (Bau C): Schadensbericht. Prüfung, Vorschlag aus dem Logbuch, Speichern ohne Löschen, Belege vom Vorgang, PDF, Einbau. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'reiseorte', 'pdf', 'reisebuch', 'schadensbericht', 'daten']
  .forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const S = MM.Schadensbericht;
const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');
const JPEG = Uint8Array.from([0xFF, 0xD8, 0xFF, 0xC0, 0x00, 0x11, 0x08, 0x00, 0x03, 0x00, 0x02, 0x03, 1, 0x11, 0, 2, 0x11, 0, 3, 0x11, 0, 0xFF, 0xD9]);
const datei = (inhalt, name, typ) => { const b = new Blob([inhalt], { type: typ || 'image/jpeg' }); Object.defineProperty(b, 'name', { value: name || 'foto.jpg' }); return b; };

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 15, 12, 0, 0).getTime() };
  let t = 0;
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
}
async function neu() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const auto = (await d.fahrzeugAnlegen('auto', { bezeichnung: 'Golf', kennzeichen: 'LB-RH 123', versicherung: 'HUK-Coburg', versicherungsnummer: 'VS-4711', schadenTelefon: '0800 1234' })).id;
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  return { d, auto, boot };
}
const GUT = { schadenart: 'haftpflicht', datum: '2026-11-10', hergang: 'Ein Auto ist mir hinten aufgefahren.' };

test('Prüfung: Pflicht sind Schadenart, Datum (nicht in der Zukunft) und Hergang; Uhrzeit und Länge werden geprüft', () => {
  assert.equal(S.pruefen({}, '2026-11-15').ok, false);
  const p = S.pruefen(GUT, '2026-11-15');
  assert.ok(p.ok); assert.equal(p.werte.hergang, GUT.hergang);
  assert.match(S.pruefen({ ...GUT, datum: '2026-11-16' }, '2026-11-15').fehler.datum, /Zukunft/);
  assert.match(S.pruefen({ ...GUT, schadenart: 'blitz' }, '2026-11-15').fehler.schadenart, /Art des Schadens/);
  assert.match(S.pruefen({ ...GUT, zeit: '25:00' }, '2026-11-15').fehler.zeit, /Uhrzeit/);
  assert.ok(S.pruefen({ ...GUT, zeit: '09:05' }, '2026-11-15').ok);
  assert.match(S.pruefen({ ...GUT, hergang: 'x'.repeat(2001) }, '2026-11-15').fehler.hergang, /höchstens/);
  assert.equal(S.pruefen({ ...GUT, verletzte: 'nein', verletzteText: 'Anna' }, '2026-11-15').werte.verletzteText, '', 'Text zu Verletzten nur bei „Ja“');
  assert.equal(S.ARTEN.length, 7);
});

test('Bericht: nur gefüllte Zeilen, Gegner nur wenn eingetragen, Belege und Bilder getrennt', () => {
  const b = S.bauen({ werte: { ...GUT, ort: 'A8 Stuttgart', zeit: '08:30' }, fahrzeug: { name: 'Golf', artName: 'Auto', kennzeichen: 'LB-RH 123' },
    belege: [{ id: 'do1', bezeichnung: 'Schaden', art: 'Foto', istBild: true }, { id: 'do2', bezeichnung: 'Kostenvoranschlag', art: 'Beleg', istBild: false }] });
  const alle = b.abschnitte.flatMap((a) => a.zeilen.map((z) => a.titel + '|' + z[0] + '|' + z[1]));
  assert.ok(alle.includes('Fahrzeug|Kennzeichen|LB-RH 123'));
  assert.ok(alle.some((z) => /^Ereignis\|Datum\|/.test(z)) && alle.includes('Ereignis|Uhrzeit|08:30 Uhr'));
  assert.ok(!b.abschnitte.some((a) => a.titel === 'Unfallgegner'), 'ohne Gegner kein Abschnitt');
  assert.deepEqual(b.bildIds, ['do1']); assert.equal(b.belege.length, 2);
  assert.match(S.dateiName(b, '.pdf'), /^Schadensbericht_Golf\.pdf$/);
  const g = S.bauen({ werte: { ...GUT, gegnerName: 'Max Muster' }, fahrzeug: { name: 'Golf' }, belege: [] });
  assert.ok(g.abschnitte.some((a) => a.titel === 'Unfallgegner'));
});

test('PDF: Seite mit Text, ein JPEG-Foto wird eingebettet, ein fehlendes Foto wird vermerkt', () => {
  const b = S.bauen({ werte: GUT, fahrzeug: { name: 'Golf' }, belege: [{ id: 'a', bezeichnung: 'Foto 1', art: 'Foto', istBild: true }, { id: 'b', bezeichnung: 'Foto 2', art: 'Foto', istBild: true }] });
  const p = S.pdf(b, { a: JPEG }, { datum: '2026-11-15T10:00:00.000Z' });
  assert.equal(p.bilder, 1); assert.equal(p.ohneBild, 1);
  assert.ok(Buffer.from(p.bytes).toString('latin1').startsWith('%PDF-1.4'));
});

test('Vorschlag: aus dem Logbuch Datum, Zeit und Ort; sonst der Tag der Meldung; ohne Vorgang leer', () => {
  assert.deepEqual(S.vorschlag({ datum: '2026-11-10', zeit: '08:30', ortName: 'Heilbronn' }, null), { ...S.leer(), datum: '2026-11-10', zeit: '08:30', ort: 'Heilbronn' });
  assert.equal(S.vorschlag({ datum: '2026-11-10', zeit: '08:30', breite: 48.5, laenge: 9.1 }, null).ort, 'Position 48,50000 / 9,10000');
  assert.equal(S.vorschlag(null, { gemeldetAm: '2026-11-12' }).datum, '2026-11-12');
  assert.equal(S.vorschlag(null, null).datum, '');
});

test('Speichern: anlegen, ändern, ausblenden; nichts wird gelöscht; Versicherung aus den Fahrzeugangaben', async () => {
  const { d, auto, boot } = await neu();
  const v = await d.schadensberichtVorschlag(auto, null);
  assert.ok(v.ok); assert.equal(v.fahrzeug.kennzeichen, 'LB-RH 123'); assert.equal(v.werte.versicherung, 'HUK-Coburg', 'Versicherung kommt aus den Fahrzeugangaben'); assert.equal(v.werte.schadennummer, 'VS-4711');
  assert.equal((await d.schadensberichtVorschlag(boot, null)).werte.versicherung, '', 'ohne Eintrag nichts erfunden');
  assert.equal((await d.schadensberichtAnlegen(auto, null, { schadenart: 'kasko' })).ok, false);
  const r = await d.schadensberichtAnlegen(auto, null, GUT);
  assert.ok(r.ok);
  assert.equal((await d.schadensberichteListe(auto)).length, 1); assert.equal((await d.schadensberichteListe(boot)).length, 0);
  assert.equal((await d.schadensberichtAendern(r.id, null, { ...GUT, ort: 'A81' })).ok, true);
  assert.equal((await d.schadensberichtLaden(r.id)).werte.ort, 'A81');
  assert.ok((await d.schadensberichtAusblenden(r.id, true)).ok);
  assert.equal((await d.schadensberichteListe(auto)).length, 0);
  assert.equal((await d.schadensberichteListe(auto, true)).length, 1, 'ausgeblendet, nicht gelöscht');
  assert.equal((await d.schadensberichtLaden(r.id)).fahrzeug.name, 'Golf');
  assert.equal((await d.schadensberichteAnzahl())[auto], undefined);
  assert.equal((await d.schadensberichtAnlegen('gibt-es-nicht', null, GUT)).ok, false);
});

test('Belege: Dokumente des Vorgangs erscheinen im Bericht ohne Dopplung; ein Vorgang eines anderen Fahrzeugs wird abgelehnt; PDF mit Foto', async () => {
  const { d, auto, boot } = await neu();
  const vg = (await d.vorgangAnlegen(auto, null, 'stoerung', { bezeichnung: 'Heckschaden', auswirkung: 'bedingt' })).id;
  const fremd = (await d.vorgangAnlegen(boot, null, 'stoerung', { bezeichnung: 'Leck', auswirkung: 'keine' })).id;
  assert.ok((await d.dokumentAnlegen(auto, null, { quelle: 'datei', datei: datei(JPEG, 'heck.jpg'), art: 'foto', bezeichnung: 'Heck' }, vg)).ok);
  assert.ok((await d.dokumentAnlegen(auto, null, { quelle: 'datei', datei: datei('PDF', 'kv.pdf', 'application/pdf'), art: 'beleg', bezeichnung: 'Kostenvoranschlag' }, vg)).ok);
  const vs = await d.schadensberichtVorschlag(auto, vg);
  assert.ok(vs.ok); assert.equal(vs.vorgangName, 'Heckschaden'); assert.equal(vs.werte.datum, '2026-11-15', 'ohne Logbuch: der Tag der Meldung');
  assert.equal((await d.schadensberichtVorschlag(auto, fremd)).ok, false);
  assert.equal((await d.schadensberichtAnlegen(auto, fremd, GUT)).ok, false);
  const r = await d.schadensberichtAnlegen(auto, vg, GUT);
  const roh = await d.schadensberichtLaden(r.id);
  assert.equal(roh.vorgang.name, 'Heckschaden'); assert.equal(roh.belege.length, 2);
  assert.equal(roh.belege.filter((b) => b.istBild).length, 1);
  const dokuAnzahl = (await d.dokumenteListe(auto)).length;
  const pdf = await d.schadensberichtPdf(r.id);
  assert.ok(pdf.ok); assert.equal(pdf.mime, 'application/pdf'); assert.equal(pdf.name, 'Schadensbericht_Golf.pdf');
  assert.equal((await d.dokumenteListe(auto)).length, dokuAnzahl, 'das PDF legt nichts doppelt ab');
  assert.equal((await d.schadensberichtPdf('xx')).ok, false);
});

test('Aus dem Logbuch: Datum, Uhrzeit und Ort der Störung kommen in den Vorschlag', async () => {
  const { d, boot } = await neu();
  const art = (await d.aktivitaetsartenListe()).find((x) => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const a = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: art, fahrzeugId: boot, vonDatum: '2026-11-15', vonZeit: '09:00', bisDatum: '2026-11-16', bisZeit: '17:00', verantwortlichId: anna });
  assert.ok(a.ok);
  const e = await d.ereignisSchnell(a.id, 'Störung', { text: 'Ruderschaden', auswirkung: 'bedingt', position: { breite: 48.5, laenge: 9.1, genauigkeit: 10 } });
  assert.ok(e.ok);
  const vs = await d.schadensberichtVorschlag(boot, e.vorgangId);
  assert.ok(vs.ok); assert.match(vs.werte.datum, /^\d{4}-\d{2}-\d{2}$/); assert.match(vs.werte.zeit, /^\d{2}:\d{2}$/);
  assert.match(vs.werte.ort, /^Position 48,50000 \/ 9,10000$/);
});

test('Einbau: Modul in index.html und Service Worker, Kachel mit Link, Routen, Knopf bei der Störung, Texte, Version', () => {
  assert.ok(lesen('index.html').indexOf('js/schadensbericht.js') > lesen('index.html').indexOf('js/reisebuch.js'));
  assert.ok(lesen('sw.js').includes("'js/schadensbericht.js'"));
  const a = lesen('js/ansicht.js');
  ['#/schadensbericht', 'function seiteSchadensberichte()', 'function schadensberichtFormular(', 'function seiteSchadensbericht(', "teile[2] === 'schadensberichte'", "'/schadensbericht/neu'", "text: 'Schadensbericht' }));", "f.typ === 'mehrzeilig'"]
    .forEach((s) => assert.ok(a.includes(s), s));
  assert.equal(MM.VERSION, '2.0.99');
  assert.match(MM.Texte.NEUERUNGEN[8].punkte.join(' '), /Schadensbericht/); assert.match(MM.Texte.NEUERUNGEN[8].punkte.join(' '), /Europäischen Unfallbericht/);
  assert.ok(lesen('CHANGELOG.md').includes('## 2.0.91\n- **Bau C: Schadensbericht**') && lesen('CHANGELOG.md').includes('## 2.0.92\n- **Fahrzeugangaben: Versicherung**') && lesen('CHANGELOG.md').includes('## 2.0.93\n- **Schadensbericht: Störung automatisch, Fotos im Bericht**'));
  assert.equal(MM.Texte.NEUERUNGEN[8].version, '2.0.91'); assert.match(MM.Texte.NEUERUNGEN[7].punkte.join(' '), /Versicherungsnummer/);
  assert.ok(lesen('docs/SCHRITTE.md').includes('| Bau C |'));
  assert.ok(lesen('js/daten.js').includes('function jpegAusBlob('), 'gemeinsame Foto-Verkleinerung');
});

test('Fahrzeugangaben: Versicherung, Versicherungsnummer und Telefon für Schadenmeldungen gibt es bei allen Arten; der Bericht zeigt das Telefon', async () => {
  ['auto', 'motorrad', 'wohnmobil', 'wohnwagen', 'oldtimer', 'boot', 'segelboot', 'flugzeug'].forEach((a) => {
    const keys = MM.Fahrzeugarten.art(a).felder.map((f) => f.key || f);
    ['versicherung', 'versicherungsnummer', 'schadenTelefon'].forEach((k) => assert.ok(keys.includes(k), a + ': ' + k));
  });
  const { d, auto } = await neu();
  const r = await d.schadensberichtAnlegen(auto, null, GUT);
  const roh = await d.schadensberichtLaden(r.id);
  assert.equal(roh.fahrzeug.schadenTelefon, '0800 1234');
  const alle = S.bauen(roh).abschnitte.flatMap((a) => a.zeilen.map((z) => z[0] + '|' + z[1]));
  assert.ok(alle.includes('Telefon für Schadenmeldungen|0800 1234'));
});

/* ---------- 2.0.93: Störung automatisch, Fotos im Bericht ---------- */
const stoerungen = async (d, fz) => (await d.vorgaengeListe(fz)).filter((x) => x.aktuell.werte.art === 'stoerung');

test('2.0.93: Jeder neue Bericht legt genau eine Störung an (Schadenart, Datum, Hergang gekürzt, Fahrzeug bleibt nutzbar)', async () => {
  const { d, auto } = await neu();
  const lang = 'Ein Auto ist mir hinten aufgefahren. '.repeat(20);
  const r = await d.schadensberichtAnlegen(auto, null, { ...GUT, schadenart: 'wild', hergang: lang });
  assert.ok(r.ok); assert.equal(r.stoerungNeu, true); assert.ok(r.vorgangId);
  const l = await stoerungen(d, auto);
  assert.equal(l.length, 1);
  const w = l[0].aktuell.werte;
  assert.equal(w.bezeichnung, 'Schaden: Wildschaden, 10.11.2026');
  assert.equal(w.auswirkung, 'keine', 'ein Bericht sperrt das Fahrzeug nicht');
  assert.equal(w.gemeldetAm, '2026-11-10'); assert.equal(w.status, 'offen');
  assert.ok(w.beschreibung.length <= 200 && w.beschreibung.endsWith('…'), 'Hergang gekürzt');
  assert.equal((await d.schadensberichtLaden(r.id)).vorgang.id, r.vorgangId);
  assert.equal((await d.schadensberichtAnlegen(auto, null, { schadenart: 'kasko' })).ok, false);
  assert.equal((await stoerungen(d, auto)).length, 1, 'ein fehlerhafter Bericht legt keine Störung an');
});

test('2.0.93: Aus einer vorhandenen Störung entsteht keine zweite; beim Ändern bleibt der Bericht an seiner Störung', async () => {
  const { d, auto } = await neu();
  const vg = (await d.vorgangAnlegen(auto, null, 'stoerung', { bezeichnung: 'Heckschaden', auswirkung: 'bedingt' })).id;
  const r = await d.schadensberichtAnlegen(auto, vg, GUT);
  assert.ok(r.ok); assert.equal(r.stoerungNeu, false); assert.equal(r.vorgangId, vg);
  assert.equal((await stoerungen(d, auto)).length, 1);
  assert.ok((await d.schadensberichtAendern(r.id, null, { ...GUT, ort: 'A81' })).ok);
  assert.equal((await d.schadensberichtLaden(r.id)).vorgang.id, vg, 'ohne neue Wahl bleibt die Störung');
  assert.equal((await stoerungen(d, auto)).length, 1);
});

test('2.0.93: Ein Foto liegt als Dokument an der Störung, erscheint im Bericht und wird nicht doppelt abgelegt', async () => {
  const { d, auto } = await neu();
  const r = await d.schadensberichtAnlegen(auto, null, GUT);
  const f1 = await d.schadensberichtFotoAnlegen(r.id, { datei: datei(JPEG, 'k1.jpg') });
  assert.ok(f1.ok); assert.equal(f1.vorgangId, r.vorgangId); assert.equal(f1.stoerungNeu, false);
  const f2 = await d.schadensberichtFotoAnlegen(r.id, { datei: datei('PDF', 'kv.pdf', 'application/pdf') });
  assert.ok(f2.ok);
  const roh = await d.schadensberichtLaden(r.id);
  assert.equal(roh.belege.length, 2); assert.equal(roh.belege.filter((b) => b.istBild).length, 1);
  const doks = (await d.dokumenteListe(auto)).filter((x) => x.vorgangId === r.vorgangId);
  assert.equal(doks.length, 2, 'genau ein Dokument je Datei, keine zweite Ablage');
  assert.equal((await d.schadensberichtPdf(r.id)).bilder, 1);
  assert.equal((await d.dokumenteListe(auto)).length, 2, 'das PDF legt nichts dazu');
  assert.equal((await stoerungen(d, auto)).length, 1);
});

test('2.0.93: Ein Bericht ohne Störung (von Hand, vor diesem Bau) bekommt sie beim ersten Foto, genau einmal', async () => {
  const { d, auto } = await neu();
  await d.speicher.speichern('einstellungen', { id: 'schadensberichte', berichte: [{ id: 'sb-alt', fahrzeugId: auto, vorgangId: null, erstelltAm: '2026-11-14T10:00:00.000Z', geaendertAm: '2026-11-14T10:00:00.000Z', ausgeblendet: false, werte: S.leer({ ...GUT }) }] });
  assert.equal((await stoerungen(d, auto)).length, 0);
  const f1 = await d.schadensberichtFotoAnlegen('sb-alt', { datei: datei(JPEG, 'a.jpg') });
  assert.ok(f1.ok); assert.equal(f1.stoerungNeu, true);
  assert.equal((await stoerungen(d, auto)).length, 1);
  const f2 = await d.schadensberichtFotoAnlegen('sb-alt', { datei: datei(JPEG, 'b.jpg') });
  assert.ok(f2.ok); assert.equal(f2.stoerungNeu, false); assert.equal(f2.vorgangId, f1.vorgangId);
  assert.equal((await stoerungen(d, auto)).length, 1, 'keine zweite Störung');
  assert.equal((await d.schadensberichtLaden('sb-alt')).belege.length, 2);
});

test('2.0.93: Foto ohne Datei oder zu unbekanntem Bericht wird abgelehnt und legt nichts an', async () => {
  const { d, auto } = await neu();
  await d.speicher.speichern('einstellungen', { id: 'schadensberichte', berichte: [{ id: 'sb-alt', fahrzeugId: auto, vorgangId: null, erstelltAm: '2026-11-14T10:00:00.000Z', geaendertAm: '2026-11-14T10:00:00.000Z', ausgeblendet: false, werte: S.leer({ ...GUT }) }] });
  assert.equal((await d.schadensberichtFotoAnlegen('sb-alt', {})).ok, false);
  assert.equal((await d.schadensberichtFotoAnlegen('sb-alt', { datei: datei('', 'leer.jpg') })).ok, false);
  assert.equal((await d.schadensberichtFotoAnlegen('gibt-es-nicht', { datei: datei(JPEG) })).ok, false);
  assert.equal((await stoerungen(d, auto)).length, 0);
});

test('2.0.93: Einbau: Knöpfe „Foto aufnehmen“ und „Aus Datei“ auf der Berichtsseite, Kamera-Feld, Texte, Changelog', () => {
  const a = lesen('js/ansicht.js');
  ["text: 'Foto aufnehmen'", "text: 'Aus Datei'", "capture: 'environment'", 'daten.schadensberichtFotoAnlegen(id', "'– neue Störung automatisch anlegen –'"].forEach((s) => assert.ok(a.includes(s), s));
  assert.ok(lesen('js/daten.js').includes('Daten.prototype.schadensberichtFotoAnlegen'));
  assert.match(MM.Texte.NEUERUNGEN[6].punkte.join(' '), /automatisch eine Störung/); assert.match(MM.Texte.NEUERUNGEN[6].punkte.join(' '), /Foto aufnehmen/);
  assert.ok(lesen('CHANGELOG.md').includes('Einschränkung „Fahrzeug bleibt nutzbar“'));
});

test('2.0.95: Einbau: Foto-Feld im Formular des Berichts („Foto aufnehmen“, „Aus Datei“), Fotos werden beim Speichern an die Störung gehängt', () => {
  const a = lesen('js/ansicht.js');
  const form = a.slice(a.indexOf('function schadensberichtFormular'), a.indexOf('function seiteSchadensbericht('));
  /* Das Feld steht im Abschnitt „Fotos und Belege“ des Formulars, vor der Auswahl der Störung */
  assert.match(form, /titel: 'Fotos und Belege'[^\n]*felder: \[\{ key: 'fotos', label: 'Foto oder Beleg hinzufügen', typ: 'fotos'/);
  /* Beim Speichern: erst der Bericht, dann je Datei schadensberichtFotoAnlegen mit der Bericht-ID */
  assert.ok(form.includes('daten.schadensberichtFotoAnlegen(res.id, { datei: f })'));
  assert.ok(form.indexOf('schadensberichtAnlegen(k.fid, vid, w)') < form.indexOf('schadensberichtFotoAnlegen(res.id'));
  /* Die Engine kennt den Typ, die Eingabefelder haben keinen Namen (sonst würde lesen() nur eine Datei erfassen) */
  const el = a.slice(a.indexOf('function fotosElement'), a.indexOf('function einfachFormular'));
  ["text: 'Foto aufnehmen'", "text: 'Aus Datei'", "capture: 'environment'", 'multiple: true', "text: 'Entfernen'"].forEach((s) => assert.ok(el.includes(s), s));
  assert.ok(!/name: f\.key/.test(el));
  assert.ok(a.includes("if (f.typ === 'fotos')"));
  assert.ok(lesen('css/styles.css').includes('.foto-gewaehlt'));
  assert.match(MM.Texte.NEUERUNGEN[4].punkte.join(' '), /Formular/); assert.match(MM.Texte.NEUERUNGEN[4].punkte.join(' '), /Foto aufnehmen/);
  assert.ok(lesen('CHANGELOG.md').includes('Im Formular „Neuer Schadensbericht“'));
});
