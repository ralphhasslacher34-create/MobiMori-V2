/*
 * Smart Capture, Stufe 1: die Bildschirme. Kamera mit Zielrahmen, Datei-Import, Ergebnis mit Korrektur je Feld, Speichern nach Bestätigung.
 * Die Bausteine (h, seite, krumen, daten, melden) reicht js/ansicht.js über MM.AnsichtKit herein.
 * Rechnen und Lesen steht in js/erfassung.js (Logik) und js/erfassung-motor.js (Texterkennung, nur im Browser).
 *
 * Die Erkennung ist eine Hilfe. Sie ist keine rechtsgültige Aussage. Nichts wird gespeichert, bevor der Nutzer bestätigt hat.
 *
 * Seit 2.0.98: Ohne Konto kein Smart Capture. Mit Konto ab Stufe Mittel liest der Lesedienst (Google über den Konto-Dienst), wenn der Nutzer allgemein zugestimmt hat;
 * vor jedem Foto kommt ein kurzer Hinweis mit „Abbrechen“. Die Erkennung auf dem Gerät bleibt die Notlösung (Grenze erreicht, keine Zustimmung, kein Netz).
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Der Stand der laufenden Erfassung (nur im Arbeitsspeicher, nichts davon bleibt, wenn man weggeht). */
  var sitzung = null;
  function neueSitzung() { return { seiten: [], fotos: [], bild: null, artId: null, felder: {}, vorgaben: null, pruefung: null, person: null, fahrzeug: null }; }

  /* Was geht gerade: Ergebnis von daten.lesedienstStatus() (modus gesperrt, geraet oder google). Wird beim Öffnen der Seite geholt. */
  var dienst = null;

  function kit() { return MM.AnsichtKit; }
  function E() { return MM.Erfassung; }

  /* ---------- Hilfen ---------- */
  function datumAnzeige(wert, typ) { return typ === 'datum' ? E().datumAnzeige(wert) : (wert || ''); }
  function datumEingabe(text) {
    var d = E().datumLesen(text, 'geburt');
    return d && d.iso ? d.iso : null;
  }
  function blobAlsDatei(blob, name) {
    try { return new global.File([blob], name, { type: blob.type || 'image/jpeg' }); } catch (e) { blob.name = name; return blob; }
  }
  function wartePunkte(text) { var k = kit(); return k.h('p', { class: 'hinweis', role: 'status', text: text }); }

  /* ---------- Start ---------- */
  function datumKurz(iso) { return iso ? E().datumAnzeige(String(iso).slice(0, 10)) : ''; }

  /* Zustimmung zum Lesedienst: Text, Knopf, später Widerruf. */
  function zustimmungBereich(k, d) {
    var h = k.h, daten = k.daten(), K = MM.Konto, z = [];
    if (d.zugestimmt) {
      z.push(h('p', { class: 'hilfe', text: 'Du hast dem Lesedienst am ' + datumKurz(d.zugestimmtAm) + ' zugestimmt.' }));
      z.push(h('button', { type: 'button', class: 'knopf leise', text: 'Zustimmung widerrufen', onclick: function () { daten.lesedienstWiderrufen().then(function () { k.neuZeichnen(); }); } }));
    } else {
      z.push(h('p', { class: 'hilfe', text: K.TEXT_LESEDIENST_ZUSTIMMUNG }));
      z.push(h('button', { type: 'button', class: 'knopf', text: 'Ich stimme zu', onclick: function () { daten.lesedienstZustimmen().then(function () { k.neuZeichnen(); }); } }));
    }
    return h('div', { class: 'feld' }, z);
  }

  function dienstZeilen(k, d) {
    var h = k.h, K = MM.Konto, z = [];
    if (d.modus === 'google') {
      z.push(h('p', null, K.TEXT_LESEDIENST_KURZ));
      z.push(h('p', { class: 'hinweis', role: 'status', text: d.frei === null ? 'Dein Kontingent: ohne Grenze.' : 'Noch ' + d.frei + ' von ' + d.grenze + ' Scans in diesem Monat frei. Ein Foto ist ein Scan, Vorder- und Rückseite zählen als zwei.' }));
      z.push(zustimmungBereich(k, d));
    } else {
      z.push(h('p', null, 'MobiMory liest die Angaben auf deinem Gerät. Das Bild verlässt das Gerät nicht.'));
      if (d.text) z.push(h('p', { class: 'hinweis', role: 'status', text: d.text }));
      if (d.grund === 'zustimmung') { z.push(h('p', null, K.TEXT_LESEDIENST_KURZ)); z.push(zustimmungBereich(k, d)); }
    }
    return z;
  }

  function seiteGesperrt(k, d) {
    var h = k.h;
    k.seite('Dokument erfassen', [
      k.krumen([['Hauptmenü', '#/auswahl'], ['Nur für Entwickler', '#/nur-entwickler'], ['Dokument erfassen']]),
      h('h1', { text: 'Dokument erfassen' }),
      h('p', { class: 'fehlerkasten', role: 'status', text: d.text || 'Smart Capture ist gerade nicht möglich.' }),
      h('p', null, 'Smart Capture gibt es nur mit einem MobiMory-Konto ab der Stufe Mittel.'),
      h('div', { class: 'er-knoepfe' }, h('a', { class: 'knopf', href: '#/konto', text: 'Zum Konto' }))
    ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/funktionen', text: 'Zurück' })));
  }

  function seiteStart() {
    var k = kit(), h = k.h;
    sitzung = neueSitzung();
    return k.daten().lesedienstStatus().then(function (d) {
      dienst = d;
      if (d.modus === 'gesperrt') { seiteGesperrt(k, d); return; }
      var status = h('p', { class: 'hinweis', role: 'status' });
      var datei = h('input', { type: 'file', accept: 'image/*', class: 'datei-versteckt', id: 'er-datei', onchange: function (e) { var f = e.target.files && e.target.files[0]; if (f) lesenUndZeigen(f, status); } });
      var kameraEin = h('input', { type: 'file', accept: 'image/*', capture: 'environment', class: 'datei-versteckt', id: 'er-kamera', onchange: function (e) { var f = e.target.files && e.target.files[0]; if (f) lesenUndZeigen(f, status); } });
      var kamera = h('button', { type: 'button', class: 'knopf', text: 'Mit der Kamera aufnehmen', onclick: function () { kameraOeffnen(status, kameraEin); } });
      var live = h('div', { id: 'er-live' });
      k.seite('Dokument erfassen', [
        k.krumen([['Hauptmenü', '#/auswahl'], ['Nur für Entwickler', '#/nur-entwickler'], ['Dokument erfassen']]),
        h('h1', { text: 'Dokument erfassen' }),
        h('p', null, 'Fotografiere einen Ausweis, Führerschein, Schein oder eine Zulassungsbescheinigung, oder wähle ein Foto oder einen Scan aus.')
      ].concat(dienstZeilen(k, d), [
        h('p', { class: 'hinweis', text: 'Tipp: Lege das Dokument flach auf einen einfarbigen, dunklen oder farbigen Untergrund, ohne Spiegelung. Bei Heften erst die Seite mit deinen Angaben, danach bei Bedarf eine weitere Seite.' }),
        live, status, kameraEin, datei,
        h('div', { class: 'er-knoepfe' }, kamera, h('button', { type: 'button', class: 'knopf leise', text: 'Aus Datei', onclick: function () { datei.click(); } })),
        h('p', { class: 'hinweis', text: 'Das Lesen ist eine Hilfe und keine rechtsgültige Aussage. Prüfe jede Angabe, bevor du speicherst.' })
      ]), h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/funktionen', text: 'Zurück' })));
    });
  }

  /* ---------- Kamera mit Zielrahmen ---------- */
  var strom = null, zaehler = null;
  function kameraStoppen() {
    if (zaehler) { global.clearInterval(zaehler); zaehler = null; }
    if (strom) { strom.getTracks().forEach(function (t) { t.stop(); }); strom = null; }
  }

  /* Rückmeldung zum Bild: Licht, Spiegelung, Schärfe, Abstand. Gibt die Texte, leer heißt „passt“. */
  function bildUrteil(video) {
    var b = 160, hh = Math.max(1, Math.round(160 * video.videoHeight / video.videoWidth)), c = global.document.createElement('canvas');
    c.width = b; c.height = hh;
    var x = c.getContext('2d'), d, i, g = [], mittel = 0, hell = 0, lap = 0, n;
    x.drawImage(video, 0, 0, b, hh);
    d = x.getImageData(0, 0, b, hh).data; n = b * hh;
    for (i = 0; i < n; i++) { var v = 0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2]; g.push(v); mittel += v; if (v >= 250) hell++; }
    mittel /= n;
    var xx, yy, s = 0, s2 = 0, cnt = 0;
    for (yy = 1; yy < hh - 1; yy++) for (xx = 1; xx < b - 1; xx++) {
      var l = 4 * g[yy * b + xx] - g[yy * b + xx - 1] - g[yy * b + xx + 1] - g[(yy - 1) * b + xx] - g[(yy + 1) * b + xx];
      s += l; s2 += l * l; cnt++;
    }
    lap = s2 / cnt - (s / cnt) * (s / cnt);
    var r = E().dokumentBereich({ data: d, width: b, height: hh }), anteil = r ? r.anteil : 0, t = [];
    if (mittel < 70) t.push('Zu dunkel. Bitte mehr Licht.');
    else if (mittel > 215) t.push('Zu hell. Bitte etwas abschatten.');
    if (hell / n > 0.05) t.push('Spiegelung. Bitte das Dokument leicht kippen oder das Licht wechseln.');
    if (lap < 120) t.push('Unscharf. Bitte ruhig halten.');
    if (r && anteil < 0.28) t.push('Zu weit weg. Bitte näher heran.');
    if (r && anteil > 0.9) t.push('Zu nah. Das ganze Dokument soll im Bild sein.');
    return t;
  }

  function kameraOeffnen(status, ausweichInput) {
    var k = kit(), h = k.h, ziel = global.document.getElementById('er-live');
    if (!global.navigator.mediaDevices || !global.navigator.mediaDevices.getUserMedia) { ausweichInput.click(); return; }
    ziel.textContent = '';
    status.textContent = 'Kamera wird gestartet …';
    global.navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 2560 }, height: { ideal: 1920 } }, audio: false }).then(function (s) {
      strom = s;
      var video = h('video', { class: 'er-video', autoplay: '', playsinline: '', muted: '' });
      video.srcObject = s; video.muted = true;
      var rahmen = h('div', { class: 'er-rahmen', 'aria-hidden': 'true' });
      var rueck = h('p', { class: 'er-rueck', role: 'status', text: 'Dokument in den Rahmen legen.' });
      var knopf = h('button', { type: 'button', class: 'knopf', text: 'Aufnehmen', onclick: function () {
        if (!video.videoWidth) return;
        var c = global.document.createElement('canvas'); c.width = video.videoWidth; c.height = video.videoHeight;
        c.getContext('2d').drawImage(video, 0, 0);
        c.toBlob(function (bl) { kameraStoppen(); ziel.textContent = ''; lesenUndZeigen(bl, status); }, 'image/jpeg', 0.92);
      } });
      var zu = h('button', { type: 'button', class: 'knopf leise', text: 'Kamera schließen', onclick: function () { kameraStoppen(); ziel.textContent = ''; status.textContent = ''; } });
      ziel.appendChild(h('div', { class: 'er-kamera' }, video, rahmen));
      ziel.appendChild(rueck);
      ziel.appendChild(h('div', { class: 'er-knoepfe' }, knopf, zu));
      status.textContent = '';
      zaehler = global.setInterval(function () {
        if (!video.videoWidth) return;
        var t = bildUrteil(video);
        rueck.textContent = t.length ? t[0] : 'Passt. Jetzt aufnehmen.';
        rueck.classList.toggle('er-gut', !t.length);
      }, 600);
    }).catch(function () {
      status.textContent = 'Die Kamera ist nicht freigegeben. Du kannst stattdessen ein Foto aufnehmen oder eine Datei wählen.';
      ausweichInput.click();
    });
  }

  /* ---------- Lesen ---------- */
  /* Vor jedem Foto an den Lesedienst: kurzer Hinweis mit „Abbrechen“. Gibt 'google', 'geraet' oder 'abbruch'. Ohne Lesedienst gleich 'geraet'. */
  function vorLesenFragen(status) {
    if (!dienst || dienst.modus !== 'google') return Promise.resolve('geraet');
    var k = kit(), h = k.h;
    return new Promise(function (ok) {
      var rest = dienst.frei === null ? '' : ' Danach sind noch ' + Math.max(0, dienst.frei - 1) + ' von ' + dienst.grenze + ' Scans in diesem Monat frei.';
      var feld = h('div', { class: 'feld', role: 'alertdialog', 'aria-label': 'Foto senden' });
      function wahl(w) { if (feld.parentNode) feld.parentNode.removeChild(feld); ok(w); }
      feld.appendChild(h('p', { class: 'hinweis', text: MM.Konto.TEXT_LESEN_HINWEIS + ' Es zählt als 1 Scan.' + rest }));
      feld.appendChild(h('div', { class: 'er-knoepfe' },
        h('button', { type: 'button', class: 'knopf', text: 'Foto senden und lesen', onclick: function () { wahl('google'); } }),
        h('button', { type: 'button', class: 'knopf leise', text: 'Stattdessen auf dem Gerät lesen', onclick: function () { wahl('geraet'); } }),
        h('button', { type: 'button', class: 'knopf leise', text: 'Abbrechen', onclick: function () { wahl('abbruch'); } })));
      status.textContent = '';
      if (status.parentNode) status.parentNode.insertBefore(feld, status.nextSibling);
    });
  }

  /* Liest mit dem Lesedienst. Ist er nicht erreichbar oder die Grenze erreicht, liest das Gerät (mit Hinweis im Ergebnis). Abgelaufene Anmeldung und fehlende Zustimmung stoppen. */
  function googleLesen(blob, meld) {
    var daten = kit().daten();
    return MM.ErfassungMotor.lesenGoogle(blob, meld, function (b64) { return daten.lesedienstSenden(b64); }).then(function (r) {
      var kg = r.kontingent;
      if (kg && dienst) { dienst.genutzt = kg.genutzt; dienst.frei = kg.grenze === null ? null : Math.max(0, kg.grenze - kg.genutzt); }
      return r;
    }, function (e) {
      if (e && (e.art === 'anmeldung' || e.art === 'zustimmung')) throw e;
      if (e && e.art === 'kontingent' && dienst) { dienst.frei = 0; dienst.modus = 'geraet'; dienst.grund = 'limit'; }
      sitzung.dienstHinweis = 'Der Lesedienst wurde nicht benutzt: ' + (e && e.message ? e.message : 'nicht erreichbar') + ' Dieses Foto wurde auf dem Gerät gelesen, das ist weniger genau.';
      return MM.ErfassungMotor.lesen(blob, meld);
    });
  }

  function lesenUndZeigen(blob, status) {
    kameraStoppen();
    var meld = function (t) { status.textContent = t; };
    sitzung = sitzung || neueSitzung();
    return vorLesenFragen(status).then(function (wahl) {
      if (wahl === 'abbruch') { meld('Abgebrochen. Das Foto wurde nicht gesendet.'); return null; }
      meld('Wird gelesen. Das dauert einige Sekunden.');
      var daten = kit().daten();
      return (wahl === 'google' ? googleLesen(blob, meld) : MM.ErfassungMotor.lesen(blob, meld)).then(function (r) {
        var heute = daten.heute();
        var erg = E().seiteLesen(r.seite, { heute: heute });
        sitzung = sitzung || neueSitzung();
        /* Jedes Foto bleibt als eigene Seite erhalten (Seite 1, Seite 2 …), damit man auf jeder Seite Stellen markieren kann. */
        var foto = { nr: sitzung.fotos.length + 1, bild: r.bild, seite: r.seite, google: r.quelle === 'google' };
        sitzung.fotos.push(foto);
        var haupt = { seite: r.seite, bild: r.bild, ergebnis: erg, reihen: r.reihen || null, foto: foto.nr };
        sitzung.seiten.push(haupt);
        (r.weitere || []).forEach(function (sp) { sitzung.seiten.push({ seite: sp, bild: r.bild, ergebnis: E().seiteLesen(sp, { heute: heute }), reihen: r.reihen || null, foto: foto.nr }); });
        if (!sitzung.bild) sitzung.bild = r.bild;
        if (r.quelle === 'google') sitzung.mitDienst = true;
        /* Maschinenzeile des Ausweises: gezielt noch einmal lesen, die Zeichen sind eng begrenzt (nur bei der Erkennung auf dem Gerät, Google liest sie mit) */
        var mrzNoetig = r.quelle !== 'google' && ((erg.artId === 'DE_PAUSWG_PERSONALAUSWEIS' && !erg.felder.gueltigBis) || (!erg.artId && !sitzung.seiten.some(function (s) { return s.ergebnis.artId; })));
        var davor = mrzNoetig ? MM.ErfassungMotor.mrzLesen(r.bild, { x0: 0, y0: 0.45, x1: 1, y1: 1 }).then(function (z) {
          var m = E().mrzLesen(z, heute);
          if (m) { if (!erg.artId) { erg.artId = 'DE_PAUSWG_PERSONALAUSWEIS'; erg.treffer = [{ artId: erg.artId, punkte: 10 }]; } mrzEinfuegen(erg, m); }
        }, function () {}) : Promise.resolve();
        return davor.then(function () { return vorlagenAnwenden(r, erg, foto, haupt); });
      }).then(function () { return ergebnisAufbauen(); }).then(function () { global.location.hash = '#/erfassung/ergebnis'; });
    }).catch(function (e) {
      var art = e && e.art;
      meld(art === 'anmeldung' ? 'Deine Anmeldung ist abgelaufen. Bitte melde dich unter Konto neu an.' : (art === 'zustimmung' ? 'Ohne deine Zustimmung wird kein Foto gesendet.' : 'Das Lesen hat nicht geklappt: ' + (e && e.message ? e.message : 'unbekannter Fehler') + ' Du kannst es noch einmal versuchen.'));
    });
  }

  function mrzEinfuegen(erg, m) {
    var k = erg.felder, ein = function (rolle, wert, konf, ok, hinweis) { (k[rolle] = k[rolle] || []).push({ wert: wert, konf: konf, quelle: 'mrz', ok: ok, hinweis: hinweis }); };
    if (m.nachname) ein('nachname', m.nachname.charAt(0) + m.nachname.slice(1).toLowerCase(), 80, true, 'Aus der Maschinenzeile (dort steht ß als „SS“).');
    if (m.vorname) ein('vorname', m.vorname.charAt(0) + m.vorname.slice(1).toLowerCase(), 80, true, 'Aus der Maschinenzeile.');
    if (m.geburt) ein('geburtsdatum', m.geburt, m.pruefziffern.geburt ? 97 : 45, !!m.pruefziffern.geburt, m.pruefziffern.geburt ? 'Prüfziffer der Maschinenzeile stimmt.' : 'Prüfziffer stimmt nicht.');
    if (m.ablauf) ein('gueltigBis', m.ablauf, m.pruefziffern.ablauf ? 97 : 45, !!m.pruefziffern.ablauf, m.pruefziffern.ablauf ? 'Prüfziffer der Maschinenzeile stimmt.' : 'Prüfziffer stimmt nicht.');
    if (m.nummer && m.nummer.length === 9) ein('nummer', m.nummer, m.pruefziffern.nummer ? 97 : 40, !!m.pruefziffern.nummer, m.pruefziffern.nummer ? 'Prüfziffer der Maschinenzeile stimmt.' : 'Prüfziffer stimmt nicht.');
  }

  /* Die Art, die schon auf einer früheren Seite dieser Sitzung erkannt wurde (die Rückseite erkennt sich oft nicht selbst). */
  function sitzungArt() {
    var art = null;
    sitzung.seiten.forEach(function (s) { if (!art && s.ergebnis && s.ergebnis.artId) art = s.ergebnis.artId; });
    return art;
  }

  /* Gelernte Stellen (Vorlage) nutzen: ab dem zweiten Mal dieser Art reicht das Scannen.
     Lesedienst (seit 2.0.99): Die Stelle gilt je Art und Seite (Seite 1, Seite 2) und ist auf den Textrahmen des Dokuments bezogen, nicht auf das ganze Foto.
     Das Ergebnis steht in haupt.gelernt und wird beim Zusammenführen der Seiten wie eine Lesung mit der Quelle „Gelernte Stelle“ gezählt. */
  function vorlagenAnwenden(r, erg, foto, haupt) {
    var daten = kit().daten();
    if (r.quelle === 'google') {
      var gArt = erg.artId || sitzungArt();
      if (!gArt) return Promise.resolve();
      return daten.erfassungVorlagen().then(function (v) {
        var vorl = v[gArt + ':g' + foto.nr], rahmen = E().textRahmen(r.seite);
        if (!vorl || !rahmen) return;
        var a = E().ARTEN[gArt], gel = {};
        Object.keys(vorl.felder).forEach(function (rolle) {
          var an = a.angaben.filter(function (x) { return x.rolle === rolle; })[0];
          if (!an) return;
          var sicher = erg.artId === gArt && (erg.felder[rolle] || []).some(function (c) { return c.ok !== false && c.konf >= 70; });
          if (sicher) return;
          var c = feldAusText(an, E().rechteckText(r.seite, E().boxAbsolut(vorl.felder[rolle], rahmen)));
          if (c) gel[rolle] = c;
        });
        if (Object.keys(gel).length) haupt.gelernt = gel;
      });
    }
    var gArt2 = erg.artId || sitzungArt();
    if (!gArt2) return Promise.resolve();
    return daten.erfassungVorlagen().then(function (v) {
      var vorl = v[gArt2 + (foto.nr > 1 ? ':s' + foto.nr : '')];
      if (!vorl) return;
      var a = E().ARTEN[gArt2], rollen = Object.keys(vorl.felder), i = 0;
      function weiter() {
        if (i >= rollen.length) return Promise.resolve();
        var rolle = rollen[i++], an = a.angaben.filter(function (x) { return x.rolle === rolle; })[0];
        var vorhanden = (erg.felder[rolle] || []).some(function (c) { return c.ok !== false && c.konf >= 70; });
        if (!an || vorhanden) return weiter();
        return MM.ErfassungMotor.rechteckLesen(r.bild, vorl.felder[rolle]).then(function (text) {
          var c = feldAusText(an, text);
          if (c) (erg.felder[rolle] = erg.felder[rolle] || []).push(c);
        }, function () {}).then(weiter);
      }
      return weiter();
    });
  }
  function feldAusText(an, text) {
    text = E().saeubern(text);
    if (!text) return null;
    if (an.typ === 'datum') {
      var d = E().datumLesen(text, an.rolle === 'geburtsdatum' ? 'geburt' : (an.rolle === 'gueltigBis' ? 'ablauf' : 'ausgestellt'));
      return d && d.iso ? { wert: d.iso, konf: 80, quelle: 'lernen', ok: true, hinweis: 'Von der gelernten Stelle gelesen.' } : { wert: text, konf: 30, quelle: 'lernen', ok: false, hinweis: 'Von der gelernten Stelle gelesen, aber kein gültiges Datum.' };
    }
    return { wert: text, konf: 80, quelle: 'lernen', ok: true, hinweis: 'Von der gelernten Stelle gelesen.' };
  }

  /* Aus allen gelesenen Seiten den Entwurf machen und Person oder Fahrzeug zuordnen. */
  function ergebnisAufbauen() {
    var daten = kit().daten();
    /* Art: die mit den meisten Trefferpunkten über alle Seiten, sonst die erste erkannte */
    var punkte = {}, art = null;
    sitzung.seiten.forEach(function (s) { (s.ergebnis.treffer || []).forEach(function (t) { punkte[t.artId] = (punkte[t.artId] || 0) + t.punkte; }); });
    Object.keys(punkte).forEach(function (id) { if (!art || punkte[id] > punkte[art]) art = id; });
    if (!sitzung.artGewaehlt) sitzung.artId = art;
    var gleicheArt = sitzung.seiten.map(function (s) { return s.ergebnis; }).filter(function (e) { return e.artId === sitzung.artId || (e.artId === null && false); });
    /* Seiten, die als andere Art erkannt wurden, aber Felder der gewählten Art liefern können, neu lesen */
    var alle = sitzung.seiten.map(function (s) { return s.ergebnis.artId === sitzung.artId ? s.ergebnis : (sitzung.artId ? E().seiteLesen(s.seite, { heute: daten.heute(), artId: sitzung.artId }) : s.ergebnis); });
    alle = alle.map(function (e, i) {
      var g = sitzung.seiten[i] && sitzung.seiten[i].gelernt;
      if (!g || !sitzung.artId) return e;
      var f = Object.assign({}, e.felder);
      Object.keys(g).forEach(function (rolle) { f[rolle] = (f[rolle] || []).concat([g[rolle]]); });
      return Object.assign({}, e, { felder: f });
    });
    var entwurf = sitzung.artId ? E().zusammenfuehren(alle) : {};
    /* Hat der Nutzer schon etwas von Hand geändert, bleibt es */
    Object.keys(sitzung.felder).forEach(function (rolle) { if (sitzung.felder[rolle].hand) entwurf[rolle] = sitzung.felder[rolle]; });
    sitzung.felder = entwurf;
    /* Das Original: die Seite mit den meisten gelesenen Feldern */
    var beste = 0, bi = 0;
    sitzung.seiten.forEach(function (s, i) { var n = Object.keys(s.ergebnis.felder || {}).length; if (n > beste) { beste = n; bi = i; } });
    sitzung.bild = sitzung.seiten[bi] ? sitzung.seiten[bi].bild : sitzung.bild;
    if (!sitzung.artId) return Promise.resolve();
    var a = E().ARTEN[sitzung.artId];
    if (a.gehoertZu === 'person') {
      return daten.erfassungPersonen().then(function (personen) {
        sitzung.personen = personen;
        var ident = { nachname: wertVon('nachname'), vorname: wertVon('vorname'), geburtsdatum: wertVon('geburtsdatum') };
        sitzung.zuordnung = E().personZuordnen(ident, personen);
        if (!sitzung.personWahlHand) sitzung.person = sitzung.zuordnung.art === 'gleich' ? sitzung.zuordnung.person.id : (sitzung.zuordnung.art === 'rueckfrage' ? '?' : 'neu');
      });
    }
    /* Fahrzeuge entstehen nur neu aus dem Papier (Festlegung 16.11.2026), ein vorhandenes Fahrzeug wird nicht ergänzt. */
    sitzung.fahrzeug = 'neu';
    return motorenVorgabe(daten);
  }
  /* Wie viele Motoren sind zu erwarten: laut Einstellung der Fahrzeugart (Hat einen Motor) einer, sonst keiner. Eine Eingabe des Nutzers bleibt. */
  function artenFuer() { return sitzung.artId === 'DE_IBS' ? [['boot', 'Boot'], ['sportboot', 'Sportboot']] : [['auto', 'Auto'], ['motorrad', 'Motorrad'], ['wohnmobil', 'Wohnmobil'], ['wohnwagen', 'Wohnwagen'], ['oldtimer', 'Oldtimer']]; }
  function motorenVorgabe(daten) {
    var arten = artenFuer();
    if (!sitzung.fahrzeugArt || !arten.some(function (a) { return a[0] === sitzung.fahrzeugArt; })) sitzung.fahrzeugArt = arten[0][0];
    if (sitzung.motorenHand) return Promise.resolve();
    return daten.fahrzeugartMotor(sitzung.fahrzeugArt).then(function (m) { sitzung.motoren = m && m.hat ? 1 : 0; }, function () { sitzung.motoren = 1; });
  }
  function wertVon(rolle) { var f = sitzung.felder[rolle]; return f ? f.wert : ''; }

  /* ---------- Ergebnis ---------- */
  var STATUS_TEXT = { sicher: 'Sicher gelesen', unsicher: 'Bitte prüfen', fehlt: 'Nicht gelesen' };
  var QUELLE_TEXT = { mrz: 'Maschinenzeile', marke: 'Feldnummer', beschriftung: 'Beschriftung', muster: 'Muster', lernen: 'Gelernte Stelle', tabelle: 'Tabelle', hand: 'Von dir' };

  function seiteErgebnis() {
    var k = kit(), h = k.h;
    if (!sitzung || !sitzung.seiten.length) { global.location.hash = '#/erfassung'; return Promise.resolve(); }
    var daten = k.daten(), art = sitzung.artId ? E().ARTEN[sitzung.artId] : null, heute = daten.heute();
    var inhalt = [k.krumen([['Hauptmenü', '#/auswahl'], ['Nur für Entwickler', '#/nur-entwickler'], ['Dokument erfassen', '#/erfassung'], ['Ergebnis']]), h('h1', { text: 'Das habe ich gelesen' })];
    sitzung.fotos.forEach(function (f) { f.url = f.url || global.URL.createObjectURL(f.bild); });
    sitzung.fotos.forEach(function (f) {
      if (sitzung.fotos.length > 1) inhalt.push(h('p', { class: 'hinweis', text: 'Seite ' + f.nr + ' von ' + sitzung.fotos.length }));
      inhalt.push(h('img', { class: 'vorschau-bild', alt: 'Dein Scan, Seite ' + f.nr, src: f.url }));
    });
    if (sitzung.dienstHinweis) inhalt.push(h('p', { class: 'fehlerkasten', role: 'status', text: sitzung.dienstHinweis }));
    else if (sitzung.mitDienst) inhalt.push(h('p', { class: 'hinweis', text: 'Gelesen mit dem Lesedienst (Google). Das Foto wurde dort nicht gespeichert.' }));

    /* Art wählen, wenn nichts erkannt wurde oder falsch */
    var artWahl = h('select', { id: 'er-art', onchange: function (e) { sitzung.artId = e.target.value || null; sitzung.artGewaehlt = true; sitzung.felder = {}; ergebnisAufbauen().then(function () { k.neuZeichnen(); }); } },
      h('option', { value: '', text: art ? 'Andere Art wählen …' : 'Bitte die Art des Dokuments wählen' }),
      E().artIds().map(function (id) { return h('option', { value: id, text: E().artName(id), selected: id === sitzung.artId ? '' : null }); }));
    inhalt.push(h('div', { class: 'feld' }, h('label', { for: 'er-art', text: 'Art des Dokuments' }), h('div', { class: 'eingabe' }, artWahl)));
    if (!art) {
      inhalt.push(h('p', { class: 'fehlerkasten', text: 'Ich konnte die Art des Dokuments nicht sicher erkennen. Wähle sie oben aus. Danach lese ich noch einmal.' }));
      inhalt.push(h('p', { class: 'hinweis', text: 'Tipp: Ein schärferes Foto, bei dem das ganze Dokument im Bild ist, hilft.' }));
      k.seite('Ergebnis', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/erfassung', text: 'Neu aufnehmen' })));
      return Promise.resolve();
    }

    /* Prüfung */
    var werte = {};
    art.angaben.forEach(function (an) { var f = sitzung.felder[an.rolle]; if (f && f.wert) werte[an.rolle] = f.wert; });
    var probleme = E().plausibel(sitzung.artId, werte, heute);
    var problemJe = {}; probleme.forEach(function (p) { (problemJe[p.rolle] = problemJe[p.rolle] || []).push(p); });
    var wenigGelesen = Object.keys(werte).length < Math.min(3, art.angaben.length);

    inhalt.push(h('p', { class: 'hinweis', text: 'Jede Angabe kannst du einzeln ändern, ohne neu zu scannen. Gespeichert wird erst, wenn du unten bestätigst.' }));
    if (wenigGelesen) inhalt.push(h('p', { class: 'fehlerkasten', text: 'Es wurde nur wenig gelesen. Du kannst fehlende Angaben von Hand eintragen oder eine bessere Aufnahme machen.' }));

    var liste = h('div', { class: 'formular' });
    art.angaben.forEach(function (an) {
      var f = sitzung.felder[an.rolle] || { wert: '', status: 'fehlt', hinweis: 'Nicht gelesen. Bitte eintragen.', quelle: '' };
      var id = 'er-f-' + an.rolle;
      var status = f.status, pr = problemJe[an.rolle] || [];
      var ein = h('input', { id: id, type: 'text', value: datumAnzeige(f.wert, an.typ), inputmode: an.typ === 'zahl' ? 'numeric' : null, autocomplete: 'off',
        onchange: function (e) {
          var t = e.target.value.trim(), neu = t;
          if (an.typ === 'datum') { neu = datumEingabe(t) || t; }
          sitzung.felder[an.rolle] = { wert: neu, status: t ? 'sicher' : 'fehlt', hinweis: t ? 'Von dir eingetragen.' : '', quelle: 'hand', hand: true, konf: 100 };
          k.neuZeichnen();
        } });
      var ueber = h('div', { class: 'er-zeile' });
      ueber.appendChild(h('span', { class: 'er-status er-' + status, text: (status === 'sicher' ? '✓ ' : status === 'unsicher' ? '⚠ ' : '○ ') + STATUS_TEXT[status] }));
      if (f.quelle && QUELLE_TEXT[f.quelle]) ueber.appendChild(h('span', { class: 'hinweis', text: ' · ' + QUELLE_TEXT[f.quelle] }));
      var feld = h('div', { class: 'feld' + (status !== 'sicher' || pr.length ? ' hat-fehler' : '') }, h('label', { for: id, text: an.label + (an.papier ? ' (Feld ' + an.papier + ')' : '') }), h('div', { class: 'eingabe' }, ein), ueber);
      if (f.hinweis) feld.appendChild(h('p', { class: 'hilfe', text: f.hinweis }));
      pr.forEach(function (p) { feld.appendChild(h('p', { class: p.hell ? 'hilfe' : 'fehler', text: p.text })); });
      if (an.typ === 'datum') feld.appendChild(h('p', { class: 'hilfe', text: 'Schreibe das Datum als Tag.Monat.Jahr, zum Beispiel 12.08.1964.' }));
      feld.appendChild(h('button', { type: 'button', class: 'knopf leise er-lernen', text: 'Stelle auf dem Bild markieren', onclick: function () { markieren(an, sitzung.fotos); } }));
      liste.appendChild(feld);
    });
    inhalt.push(liste);

    /* Person oder Fahrzeug */
    if (art.gehoertZu === 'person') inhalt.push(personBereich(k));
    else inhalt.push(fahrzeugBereich(k, art));

    inhalt.push(h('div', { class: 'er-knoepfe' }, h('button', { type: 'button', class: 'knopf leise', text: 'Weitere Seite aufnehmen', onclick: function () { seitenWeiter(); } })));

    var meldungsFeld = h('p', { class: 'fehler', role: 'alert' });
    var speichern = h('button', { type: 'button', class: 'knopf', text: 'Angaben sind richtig, speichern', onclick: function () { speichernKlick(meldungsFeld, speichern); } });
    inhalt.push(meldungsFeld);
    inhalt.push(h('p', { class: 'hinweis', text: 'Das Lesen ist eine Hilfe und keine rechtsgültige Aussage. Der Original-Scan wird beim Nachweis aufbewahrt.' }));
    k.seite('Ergebnis', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/erfassung', text: 'Verwerfen' }), speichern));
    return Promise.resolve();
  }

  function personBereich(k) {
    var h = k.h, z = sitzung.zuordnung || { art: 'neu' }, w = h('div', { class: 'feld' }), name = [wertVon('vorname'), wertVon('nachname')].filter(Boolean).join(' ');
    w.appendChild(h('label', { text: 'Zu welcher Person gehört das?' }));
    if (z.art === 'gleich') w.appendChild(h('p', { class: 'hilfe', text: 'Name und Geburtsdatum passen zu „' + z.person.name + '“. Das Dokument wird dort abgelegt.' }));
    else if (z.art === 'rueckfrage') w.appendChild(h('p', { class: 'hilfe', text: 'Das könnte „' + z.person.name + '“ sein, aber nicht alles passt genau. Bitte wähle.' }));
    else w.appendChild(h('p', { class: 'hilfe', text: 'Es gibt noch keine passende Person. Mit „Neue Person“ wird sie aus diesem Dokument angelegt.' }));
    var opt = [];
    (sitzung.personen || []).forEach(function (p) { opt.push(h('option', { value: p.id, text: p.name, selected: sitzung.person === p.id ? '' : null })); });
    opt.push(h('option', { value: 'neu', text: 'Neue Person' + (name ? ': ' + name : ''), selected: sitzung.person === 'neu' ? '' : null }));
    if (sitzung.person === '?') opt.unshift(h('option', { value: '?', text: 'Bitte wählen …', selected: '' }));
    w.appendChild(h('div', { class: 'eingabe' }, h('select', { id: 'er-person', 'aria-label': 'Person', onchange: function (e) { sitzung.person = e.target.value; sitzung.personWahlHand = true; } }, opt)));
    return w;
  }
  function fahrzeugBereich(k, art) {
    var h = k.h, w = h('div', { class: 'feld' });
    w.appendChild(h('label', { text: 'Neues Fahrzeug' }));
    w.appendChild(h('p', { class: 'hilfe', text: 'Das Fahrzeug wird aus diesem Papier neu angelegt, der Scan hängt als Nachweis daran.' }));
    var arten = artenFuer();
    if (!sitzung.fahrzeugArt || !arten.some(function (a) { return a[0] === sitzung.fahrzeugArt; })) sitzung.fahrzeugArt = arten[0][0];
    w.appendChild(h('div', { class: 'eingabe' }, h('select', { id: 'er-fzart', 'aria-label': 'Fahrzeugart', onchange: function (e) {
      sitzung.fahrzeugArt = e.target.value;
      motorenVorgabe(k.daten()).then(function () { k.neuZeichnen(); });
    } }, arten.map(function (a) { return h('option', { value: a[0], text: a[1], selected: sitzung.fahrzeugArt === a[0] ? '' : null }); }))));
    var vorschlag = sitzung.fahrzeugName || [wertVon('marke'), wertVon('modell')].filter(Boolean).join(' ') || wertVon('kennzeichen') || '';
    w.appendChild(h('div', { class: 'eingabe' }, h('input', { id: 'er-fzname', type: 'text', placeholder: 'Bezeichnung des Fahrzeugs', value: vorschlag, 'aria-label': 'Bezeichnung des Fahrzeugs', onchange: function (e) { sitzung.fahrzeugName = e.target.value; } })));
    var n = sitzung.motoren === undefined ? 1 : sitzung.motoren;
    var opt = [0, 1, 2, 3, 4].map(function (i) { return h('option', { value: String(i), text: i === 0 ? 'Kein Motor' : (i === 1 ? '1 Motor' : i + ' Motoren'), selected: n === i ? '' : null }); });
    w.appendChild(h('label', { for: 'er-motoren', text: 'Motoren, die mit angelegt werden' }));
    w.appendChild(h('div', { class: 'eingabe' }, h('select', { id: 'er-motoren', 'aria-label': 'Anzahl der Motoren', onchange: function (e) { sitzung.motoren = parseInt(e.target.value, 10); sitzung.motorenHand = true; } }, opt)));
    w.appendChild(h('p', { class: 'hilfe', text: 'Jeder Motor wird eine Komponente „Motor“. Leistung, Hubraum und Kraftstoff aus dem Papier stehen bei jedem Motor; bei mehreren änderst du sie später je Motor.' }));
    return w;
  }

  function seitenWeiter() {
    global.location.hash = '#/erfassung/weiter';
  }
  function seiteWeiter() {
    var k = kit(), h = k.h, status = h('p', { class: 'hinweis', role: 'status' });
    if (!dienst || dienst.modus === 'gesperrt' || !sitzung) { global.location.hash = '#/erfassung'; return Promise.resolve(); }
    var datei = h('input', { type: 'file', accept: 'image/*', class: 'datei-versteckt', onchange: function (e) { var f = e.target.files && e.target.files[0]; if (f) lesenUndZeigen(f, status); } });
    var kameraEin = h('input', { type: 'file', accept: 'image/*', capture: 'environment', class: 'datei-versteckt', onchange: function (e) { var f = e.target.files && e.target.files[0]; if (f) lesenUndZeigen(f, status); } });
    var live = h('div', { id: 'er-live' });
    k.seite('Weitere Seite', [
      k.krumen([['Hauptmenü', '#/auswahl'], ['Nur für Entwickler', '#/nur-entwickler'], ['Dokument erfassen', '#/erfassung'], ['Weitere Seite']]),
      h('h1', { text: 'Weitere Seite (Seite ' + (sitzung.fotos.length + 1) + ')' }),
      h('p', null, 'Zum Beispiel die Rückseite oder die Innenseite eines Hefts. Die Angaben beider Seiten werden zusammengeführt.')
    ].concat(dienst.modus === 'google' ? [h('p', { class: 'hinweis', role: 'status', text: dienst.frei === null ? 'Dein Kontingent: ohne Grenze.' : 'Noch ' + dienst.frei + ' von ' + dienst.grenze + ' Scans in diesem Monat frei. Jede Seite ist ein Scan.' })] : [], [
      h('p', { class: 'hinweis', text: 'Tipp: Lege das Dokument wie bei der ersten Seite flach auf einen einfarbigen Untergrund, ohne Spiegelung.' }),
      live, status, kameraEin, datei,
      h('div', { class: 'er-knoepfe' }, h('button', { type: 'button', class: 'knopf', text: 'Mit der Kamera aufnehmen', onclick: function () { kameraOeffnen(status, kameraEin); } }), h('button', { type: 'button', class: 'knopf leise', text: 'Aus Datei', onclick: function () { datei.click(); } }))
    ]), h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/erfassung/ergebnis', text: 'Zurück zum Ergebnis' })));
    return Promise.resolve();
  }

  /* Eine Stelle auf dem Bild markieren: ein Rechteck ziehen, der Text darin wird gelesen und als Angabe übernommen.
     Gespeichert wird nur die Stelle (Bruchteile des Dokuments) als Vorlage, nie der Text. */
  function markieren(an, fotos) {
    var k = kit(), h = k.h, doc = global.document, foto = fotos[fotos.length - 1];
    var dlg = h('div', { class: 'er-markieren', role: 'dialog', 'aria-label': 'Stelle markieren' });
    var bildEl = h('img', { src: foto.url, alt: 'Dein Scan, Seite ' + foto.nr, draggable: 'false' });
    var rahmen = h('div', { class: 'er-box' });
    var kopf = h('p', { class: 'hinweis', text: 'Ziehe mit dem Finger ein Rechteck um „' + an.label + '“ auf dem Bild.' });
    var ok = h('button', { type: 'button', class: 'knopf', text: 'Diese Stelle lesen', onclick: function () { fertig(); } });
    var zu = h('button', { type: 'button', class: 'knopf leise', text: 'Abbrechen', onclick: function () { dlg.remove(); } });
    /* Bei mehreren Seiten: erst die Seite wählen, auf der die Stelle liegt (Standard: die Seite, auf der das Feld schon gelesen wurde, sonst die letzte) */
    var seitenWahl = fotos.length > 1 ? h('select', { id: 'er-markseite', 'aria-label': 'Seite wählen', onchange: function (e) { foto = fotos[parseInt(e.target.value, 10)]; bildEl.src = foto.url; bildEl.alt = 'Dein Scan, Seite ' + foto.nr; rahmen.style.display = 'none'; box = null; } },
      fotos.map(function (f, i) { return h('option', { value: String(i), text: 'Seite ' + f.nr, selected: i === fotos.length - 1 ? '' : null }); })) : null;
    var flaeche = h('div', { class: 'er-flaeche' }, bildEl, rahmen);
    dlg.appendChild(kopf); if (seitenWahl) dlg.appendChild(h('div', { class: 'eingabe' }, seitenWahl)); dlg.appendChild(flaeche); dlg.appendChild(h('div', { class: 'er-knoepfe' }, ok, zu));
    doc.body.appendChild(dlg);
    var start = null, box = null;
    function pos(e) { var r = bildEl.getBoundingClientRect(); return { x: Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)), y: Math.max(0, Math.min(1, (e.clientY - r.top) / r.height)) }; }
    flaeche.addEventListener('pointerdown', function (e) { start = pos(e); box = null; flaeche.setPointerCapture(e.pointerId); e.preventDefault(); });
    flaeche.addEventListener('pointermove', function (e) {
      if (!start) return;
      var p = pos(e); box = { x0: Math.min(start.x, p.x), y0: Math.min(start.y, p.y), x1: Math.max(start.x, p.x), y1: Math.max(start.y, p.y) };
      rahmen.style.left = (box.x0 * 100) + '%'; rahmen.style.top = (box.y0 * 100) + '%'; rahmen.style.width = ((box.x1 - box.x0) * 100) + '%'; rahmen.style.height = ((box.y1 - box.y0) * 100) + '%'; rahmen.style.display = 'block';
    });
    flaeche.addEventListener('pointerup', function () { start = null; });
    function fertig() {
      if (!box || (box.x1 - box.x0) < 0.02 || (box.y1 - box.y0) < 0.01) { kopf.textContent = 'Bitte zuerst ein Rechteck ziehen.'; return; }
      kopf.textContent = 'Wird gelesen …';
      var f0 = foto, google = !!f0.google && !!f0.seite;
      (google ? Promise.resolve(E().rechteckText(f0.seite, box)) : MM.ErfassungMotor.rechteckLesen(f0.bild, box)).then(function (text) {
        var c = feldAusText(an, text);
        dlg.remove();
        if (!c) { sitzung.felder[an.rolle] = { wert: '', status: 'fehlt', hinweis: 'An dieser Stelle wurde nichts gelesen.', quelle: '' }; }
        else sitzung.felder[an.rolle] = { wert: c.wert, status: c.ok === false ? 'unsicher' : 'sicher', hinweis: c.hinweis, quelle: 'lernen', konf: c.konf };
        if (c && c.ok !== false) {
          if (!google) k.daten().erfassungVorlageMerken(sitzung.artId + (f0.nr > 1 ? ':s' + f0.nr : ''), an.rolle, box);
          else { var rahmenText = E().textRahmen(f0.seite); if (rahmenText) k.daten().erfassungVorlageMerken(sitzung.artId + ':g' + f0.nr, an.rolle, E().boxRelativ(box, rahmenText)); }
        }
        k.neuZeichnen();
      }, function () { kopf.textContent = 'Das Lesen hat nicht geklappt.'; });
    }
  }

  /* ---------- Speichern ---------- */
  function speichernKlick(fehlerFeld, knopf) {
    var k = kit(), daten = k.daten(), art = E().ARTEN[sitzung.artId], werte = {};
    fehlerFeld.textContent = '';
    art.angaben.forEach(function (an) { var f = sitzung.felder[an.rolle]; if (f && f.wert) werte[an.rolle] = f.wert; });
    var fehler = E().plausibel(sitzung.artId, werte, daten.heute()).filter(function (p) { return !p.hell; });
    if (fehler.length) { fehlerFeld.textContent = 'Bitte zuerst korrigieren: ' + fehler.map(function (p) { return p.text; }).join(' '); return; }
    if (art.gehoertZu === 'person' && sitzung.person === '?') { fehlerFeld.textContent = 'Bitte wähle, zu welcher Person das Dokument gehört.'; return; }
    if (art.gehoertZu === 'person' && sitzung.person === 'neu' && !(werte.nachname || werte.vorname)) { fehlerFeld.textContent = 'Für eine neue Person fehlt der Name. Bitte trage ihn ein.'; return; }
    if (Object.keys(werte).length === 0) { fehlerFeld.textContent = 'Es ist nichts eingetragen. Bitte trage mindestens eine Angabe ein.'; return; }
    knopf.disabled = true;
    var opt = { vorschlagId: sitzung.artId, werte: werte, datei: blobAlsDatei(sitzung.bild, 'scan-' + sitzung.artId.toLowerCase() + '.jpg') };
    if (art.gehoertZu === 'person') { if (sitzung.person !== 'neu') opt.personId = sitzung.person; }
    else { opt.fahrzeugArt = sitzung.fahrzeugArt; opt.bezeichnung = (global.document.getElementById('er-fzname') || {}).value || sitzung.fahrzeugName || ''; opt.motoren = sitzung.motoren === undefined ? 1 : sitzung.motoren; }
    daten.erfassungSpeichern(opt).then(function (r) {
      knopf.disabled = false;
      if (!r.ok && r.doppelt) { fehlerFeld.textContent = (r.fehler && r.fehler.allgemein) || 'Es gibt schon ein Fahrzeug mit dieser Kennung.'; return; }
      if (!r.ok) { var f = r.fehler || {}; fehlerFeld.textContent = f.allgemein || Object.keys(f).map(function (x) { return f[x]; }).join(' ') || 'Das Speichern hat nicht geklappt.'; return; }
      var mot = r.motoren ? ' ' + (r.motoren === 1 ? 'Ein Motor wurde als Komponente angelegt.' : r.motoren + ' Motoren wurden als Komponenten angelegt.') : '';
      k.melden((r.neu ? (r.besitzerTyp === 'person' ? 'Person angelegt und Nachweis gespeichert.' : 'Fahrzeug angelegt und Nachweis gespeichert.') : 'Nachweis gespeichert.') + mot + (r.motorenFehler ? ' Ein Motor konnte nicht angelegt werden.' : ''));
      sitzung = null;
      global.location.hash = (r.besitzerTyp === 'person' ? '#/person/' : '#/fahrzeug/') + encodeURIComponent(r.besitzerId);
    }, function () { knopf.disabled = false; fehlerFeld.textContent = 'Das Speichern hat nicht geklappt. Auf dem Gerät ist vielleicht zu wenig Platz.'; });
  }

  /* ---------- Einstieg aus dem Router ---------- */
  function zeige(teile) {
    kameraStoppen();
    if (teile[1] === 'ergebnis') return seiteErgebnis();
    if (teile[1] === 'weiter') return seiteWeiter();
    return seiteStart();
  }

  MM.ErfassungAnsicht = { zeige: zeige, kameraStoppen: kameraStoppen, bildUrteil: bildUrteil };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
