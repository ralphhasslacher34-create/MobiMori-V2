'use strict';
/* 2.0.55: Schalter für jeden Verbraucher wie beim Motor (Auswahl je Fahrzeug im Cockpit) und Checkliste der Komponenten bei der
 * Fahrzeuganlage (Komponentenliste mit Vorlage, eigenen Einträgen und Ausblenden). Der Motor bleibt, wie er war. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/aktionen.js');
require('../js/baukasten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/karte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const K = MM.Komponenten;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 9, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (std, min) => { uhr.ms = new Date(2026, 10, 9, std, min, 0).getTime(); t = 0; };
  return d;
}

/* Wohnmobil mit Motor, Heizung (Gas), Kühlschrank (ohne Kurznamen) und einem Wassertank (kein Verbraucher). */
async function wohnmobil() {
  const d = neueDaten();
  await d.starten();
  const fz = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const motor = (await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Motor' })).id;
  const heizung = (await d.komponenteAnlegen(fz, null, 'heizung', { bezeichnung: 'Standheizung', kurzname: 'HEIZ', verbraucher: 'ja', stoff: 'Gas (Flüssiggas)' })).id;
  const kuehl = (await d.komponenteAnlegen(fz, null, 'sonstiges', { bezeichnung: 'Kühlschrank', verbraucher: 'ja' })).id;
  const wasser = (await d.komponenteAnlegen(fz, null, 'wasser', { bezeichnung: 'Wassertank', verbraucher: 'nein' })).id;
  return { d, fz, motor, heizung, kuehl, wasser };
}

/* ---------- Ziel 1: Schalter je Verbraucher ---------- */

test('Jeder Verbraucher hat von selbst einen Schalter, ohne Zuordnung; Motor und Nicht-Verbraucher gehören nicht dazu', async () => {
  const c = await wohnmobil();
  const liste = await c.d.verbraucherSchalter(c.fz);
  assert.deepEqual(liste.map(x => x.komponenteId).sort(), [c.heizung, c.kuehl].sort());
  assert.ok(liste.every(x => x.imCockpit === true), 'ohne Auswahl stehen alle im Cockpit');
  assert.ok(liste.every(x => x.laeuft === false));
  const motoren = await c.d.motorenListe(c.fz);
  assert.deepEqual(motoren.map(x => x.komponenteId), [c.motor]);
});

test('Der Name auf dem Schalter: Kurzname, sonst die ganze Bezeichnung (kein Vorschlag aus drei Buchstaben)', async () => {
  const c = await wohnmobil();
  const liste = await c.d.verbraucherSchalter(c.fz);
  assert.equal(liste.find(x => x.komponenteId === c.heizung).kurz, 'HEIZ');
  assert.equal(liste.find(x => x.komponenteId === c.kuehl).kurz, 'Kühlschrank');
});

test('Ein neu angelegter Verbraucher hat sofort seinen Schalter im Cockpit', async () => {
  const c = await wohnmobil();
  const boiler = (await c.d.komponenteAnlegen(c.fz, null, 'wasser', { bezeichnung: 'Boiler', verbraucher: 'ja' })).id;
  const liste = await c.d.verbraucherSchalter(c.fz);
  const b = liste.find(x => x.komponenteId === boiler);
  assert.ok(b && b.imCockpit);
});

test('Start und Stopp über den Schalter: Lauf, Dauer, Betriebsstunden-Zähler', async () => {
  const c = await wohnmobil();
  c.d.stelle(8, 0);
  const an = await c.d.verbraucherStart(c.heizung);
  assert.ok(an.ok, JSON.stringify(an));
  assert.equal((await c.d.verbraucherSchalter(c.fz)).find(x => x.komponenteId === c.heizung).laeuft, true);
  const nochmal = await c.d.verbraucherStart(c.heizung);
  assert.equal(nochmal.ok, false, 'doppelt einschalten wird abgewiesen');
  c.d.stelle(10, 30);
  const aus = await c.d.verbraucherStopp(c.heizung);
  assert.ok(aus.ok, JSON.stringify(aus));
  assert.ok(Math.abs(aus.stunden - 2.5) < 0.01, 'Dauer ' + aus.stunden);
  const z = (await c.d.zaehlerListe(c.fz)).find(x => x.komponenteId === c.heizung && x.art === 'stunden');
  assert.ok(Math.abs(z.stand.wert - 2.5) < 0.01);
  const x = (await c.d.verbraucherSchalter(c.fz)).find(v => v.komponenteId === c.heizung);
  assert.equal(x.laeuft, false);
  assert.equal(x.laeufe.length, 1);
});

test('Zwei Verbraucher laufen unabhängig voneinander, der Motor läuft daneben', async () => {
  const c = await wohnmobil();
  assert.ok((await c.d.verbraucherStart(c.heizung)).ok);
  assert.ok((await c.d.verbraucherStart(c.kuehl)).ok);
  assert.ok((await c.d.motorStart(c.motor)).ok);
  const v = await c.d.verbraucherSchalter(c.fz);
  assert.ok(v.every(x => x.laeuft));
  assert.ok((await c.d.verbraucherStopp(c.heizung)).ok);
  assert.equal((await c.d.verbraucherSchalter(c.fz)).find(x => x.komponenteId === c.kuehl).laeuft, true);
  assert.equal((await c.d.motorenListe(c.fz))[0].laeuft, true);
});

test('Auswahl im Cockpit je Fahrzeug: ausblenden, wieder zeigen; nichts geht verloren', async () => {
  const c = await wohnmobil();
  const aus = await c.d.verbraucherImCockpit(c.fz, c.kuehl, false);
  assert.ok(aus.ok && aus.geaendert);
  let liste = await c.d.verbraucherSchalter(c.fz);
  assert.equal(liste.find(x => x.komponenteId === c.kuehl).imCockpit, false);
  assert.equal(liste.find(x => x.komponenteId === c.heizung).imCockpit, true);
  assert.equal(liste.length, 2, 'der Verbraucher bleibt in der Liste');
  const nochmal = await c.d.verbraucherImCockpit(c.fz, c.kuehl, false);
  assert.ok(nochmal.ok && !nochmal.geaendert);
  assert.ok((await c.d.verbraucherImCockpit(c.fz, c.kuehl, true)).geaendert);
  liste = await c.d.verbraucherSchalter(c.fz);
  assert.equal(liste.find(x => x.komponenteId === c.kuehl).imCockpit, true);
});

test('Die Auswahl gilt je Fahrzeug: derselbe Verbraucher am zweiten Fahrzeug bleibt davon unberührt', async () => {
  const c = await wohnmobil();
  const fz2 = (await c.d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Zweites' })).id;
  const h2 = (await c.d.komponenteAnlegen(fz2, null, 'heizung', { bezeichnung: 'Heizung', verbraucher: 'ja' })).id;
  await c.d.verbraucherImCockpit(c.fz, c.heizung, false);
  assert.equal((await c.d.verbraucherSchalter(fz2)).find(x => x.komponenteId === h2).imCockpit, true);
});

test('Auswahl: ein Motor, ein Nicht-Verbraucher oder eine Komponente eines anderen Fahrzeugs wird abgewiesen', async () => {
  const c = await wohnmobil();
  const fz2 = (await c.d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Zweites' })).id;
  assert.equal((await c.d.verbraucherImCockpit(c.fz, c.motor, false)).ok, false);
  assert.equal((await c.d.verbraucherImCockpit(c.fz, c.wasser, false)).ok, false);
  assert.equal((await c.d.verbraucherImCockpit(fz2, c.heizung, false)).ok, false);
});

test('Ein ausgeblendeter Verbraucher hat keinen Schalter, außer er läuft noch; ein ausgebauter ebenso', async () => {
  const c = await wohnmobil();
  assert.ok((await c.d.verbraucherStart(c.kuehl)).ok);
  const ausblenden = await c.d.komponenteAusblenden(c.kuehl, true);
  assert.ok(ausblenden.ok, JSON.stringify(ausblenden));
  assert.ok((await c.d.verbraucherSchalter(c.fz)).some(x => x.komponenteId === c.kuehl && x.laeuft), 'läuft noch, Schalter bleibt');
  assert.ok((await c.d.verbraucherStopp(c.kuehl)).ok);
  assert.ok(!(await c.d.verbraucherSchalter(c.fz)).some(x => x.komponenteId === c.kuehl));
});

test('Zusammenarbeit mit Tanken: Verbrauch des Verbrauchers am Tank aus den Betriebsstunden', async () => {
  const c = await wohnmobil();
  const gas = (await c.d.komponenteAnlegen(c.fz, null, 'tank', { bezeichnung: 'Gasflasche', stoff: 'Gas (Flüssiggas)', merkmale: [{ name: 'Tankinhalt', wert: '11', einheit: 'l' }] })).id;
  const h = (await c.d.komponenteAnlegen(c.fz, null, 'heizung', { bezeichnung: 'Gasheizung', verbraucher: 'ja', stoff: 'Gas (Flüssiggas)', quellen: [gas], verbrauchAus: 'stunden' })).id;
  const liste = await c.d.verbraucherSchalter(c.fz);
  assert.ok(liste.some(x => x.komponenteId === h));
  const kette = MM.Versorgung.kette(await c.d.komponentenListe(c.fz));
  assert.ok(kette.tanks.some(t => t.verbraucher.some(v => v.id === h)));
});

test('Motor unverändert: Kurzname, Leiste und Schalter wie bisher', async () => {
  const c = await wohnmobil();
  const m = (await c.d.motorenListe(c.fz))[0];
  assert.equal(m.kurz, MM.Komponenten.kurznameVorschlag('Motor'));
  assert.deepEqual(MM.Motoren.schalter(m), { name: m.kurz, aktion: 'Start', zustand: 'aus' });
  assert.equal(MM.Motoren.leiste([m]).modus, 'einzeln');
  assert.ok((await c.d.motorStart(c.motor)).ok);
  assert.equal((await c.d.motorenListe(c.fz))[0].laeuft, true);
});

test('Sicherung: die Auswahl der Schalter und die Komponentenliste sind Dokumente in „einstellungen“ und gehen mit', async () => {
  const c = await wohnmobil();
  await c.d.verbraucherImCockpit(c.fz, c.kuehl, false);
  await c.d.komponentenListeAnlegen({ bezeichnung: 'Bugstrahlruder', art: 'sonstiges', verbraucher: 'ja' });
  await c.d.komponentenListeAusblenden('boiler', true);
  const ids = (await c.d.speicher.alle('einstellungen')).map(x => x.id);
  assert.ok(ids.includes('cockpit-verbraucher'));
  assert.ok(ids.includes('komponentenliste'));
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  const gelesen = await c.d.sicherungLesen(s.bytes);
  const sicherIds = gelesen.kopf.tabellen.einstellungen.map(x => x.id);
  assert.ok(sicherIds.includes('cockpit-verbraucher') && sicherIds.includes('komponentenliste'), 'in der Sicherung enthalten');
  /* Einspielen in ein leeres Programm */
  const d2 = neueDaten();
  await d2.starten();
  await d2.sicherungEinspielen(gelesen);
  const neu = await d2.komponentenListeVorlage();
  assert.ok(neu.some(x => x.label === 'Bugstrahlruder' && x.eigen));
  assert.equal(neu.find(x => x.wert === 'boiler').ausgeblendet, true);
  assert.equal((await d2.verbraucherSchalter(c.fz)).length, 2, 'dasselbe Fahrzeug mit denselben Komponenten');
  assert.equal((await d2.verbraucherSchalter(c.fz)).find(x => x.komponenteId === c.kuehl).imCockpit, false);
});

/* ---------- Ziel 2: Komponentenliste und Checkliste ---------- */

test('Komponentenliste: die Vorlage ist der Anfang, Einträge haben Art und Verbraucher-Angabe', () => {
  const liste = K.listeEintraege(null);
  assert.ok(liste.length >= 10);
  ['Motor', 'Tank (Kraftstoff)', 'Wassertank (Frischwasser)', 'Abwassertank', 'Heizung', 'Boiler'].forEach(n => assert.ok(liste.some(x => x.label === n), n));
  assert.ok(liste.every(x => K.art(x.art) && (x.verbraucher === 'ja' || x.verbraucher === 'nein') && x.eigen === false && x.ausgeblendet === false));
  assert.equal(liste.find(x => x.wert === 'heizung').verbraucher, 'ja');
  assert.equal(liste.find(x => x.wert === 'wassertank').verbraucher, 'nein');
  assert.equal(new Set(liste.map(x => x.wert)).size, liste.length, 'Kennungen sind eindeutig');
});

test('Angebot je Fahrzeugart: Wohnmobil und Boot bekommen Heizung und Wassertank, ein Auto nicht; Motor folgt der Einstellung der Art', async () => {
  const d = neueDaten();
  await d.starten();
  const namen = async (art) => (await d.komponentenAngebot(art)).map(x => x.wert);
  const wm = await namen('wohnmobil'), boot = await namen('boot'), auto = await namen('auto'), wagen = await namen('wohnwagen'), jolle = await namen('segelboot-jolle');
  ['motor', 'heizung', 'wassertank', 'abwassertank', 'boiler', 'tank'].forEach(w => assert.ok(wm.includes(w), 'Wohnmobil ' + w));
  ['motor', 'heizung', 'wassertank', 'tank'].forEach(w => assert.ok(boot.includes(w), 'Boot ' + w));
  assert.ok(!auto.includes('heizung') && !auto.includes('wassertank'));
  assert.ok(auto.includes('motor') && auto.includes('tank'));
  /* Motor: im Code steht „Wohnwagen und Jolle haben keinen Motor“ */
  assert.ok(!wagen.includes('motor') && !jolle.includes('motor'));
  assert.ok(wagen.includes('heizung'));
  /* Stellt der Nutzer für den Wohnwagen „hat einen Motor“ ein, erscheint er */
  await d.fahrzeugartMotorSetzen('wohnwagen', 'ja');
  assert.ok((await namen('wohnwagen')).includes('motor'));
});

test('Eigene Einträge: anlegen, doppelt abgewiesen, erscheinen bei jeder Fahrzeugart, ausblenden und wieder einblenden', async () => {
  const d = neueDaten();
  await d.starten();
  const neu = await d.komponentenListeAnlegen({ bezeichnung: 'Bugstrahlruder', art: 'sonstiges', verbraucher: 'ja' });
  assert.ok(neu.ok, JSON.stringify(neu));
  const doppelt = await d.komponentenListeAnlegen({ bezeichnung: 'bugstrahlruder', art: 'sonstiges', verbraucher: 'ja' });
  assert.equal(doppelt.ok, false);
  assert.match(doppelt.fehler.bezeichnung, /gibt es schon/);
  const vorlageDoppelt = await d.komponentenListeAnlegen({ bezeichnung: 'Heizung', art: 'heizung', verbraucher: 'ja' });
  assert.equal(vorlageDoppelt.ok, false);
  for (const art of ['auto', 'boot', 'flugzeug']) assert.ok((await d.komponentenAngebot(art)).some(x => x.wert === neu.id), art);
  assert.ok((await d.komponentenListeAusblenden(neu.id, true)).ok);
  assert.ok(!(await d.komponentenAngebot('boot')).some(x => x.wert === neu.id));
  assert.equal((await d.komponentenListeVorlage()).find(x => x.wert === neu.id).ausgeblendet, true, 'bleibt in der Liste, nichts wird gelöscht');
  assert.ok((await d.komponentenListeAusblenden(neu.id, false)).ok);
  assert.ok((await d.komponentenAngebot('boot')).some(x => x.wert === neu.id));
  assert.equal((await d.komponentenListeAusblenden('gibt-es-nicht', true)).ok, false);
});

test('Eigene Einträge: ohne Name, ohne Art oder ohne Verbraucher-Angabe gibt es Fehler und nichts wird gespeichert', async () => {
  const d = neueDaten();
  await d.starten();
  const r = await d.komponentenListeAnlegen({ bezeichnung: '', art: 'unbekannt', verbraucher: '' });
  assert.equal(r.ok, false);
  assert.ok(r.fehler.bezeichnung && r.fehler.art && r.fehler.verbraucher);
  assert.equal((await d.komponentenListeVorlage()).filter(x => x.eigen).length, 0);
  const lang = await d.komponentenListeAnlegen({ bezeichnung: 'x'.repeat(61), art: 'sonstiges', verbraucher: 'nein' });
  assert.equal(lang.ok, false);
});

test('Ausgeblendeter Vorlagen-Eintrag erscheint nicht mehr im Angebot, bleibt aber in der Liste', async () => {
  const d = neueDaten();
  await d.starten();
  await d.komponentenListeAusblenden('boiler', true);
  assert.ok(!(await d.komponentenAngebot('wohnmobil')).some(x => x.wert === 'boiler'));
  assert.equal((await d.komponentenListeVorlage()).find(x => x.wert === 'boiler').ausgeblendet, true);
});

test('Angehakte Komponenten werden angelegt, Verbraucher gleich als Verbraucher mit Schalter', async () => {
  const d = neueDaten();
  await d.starten();
  const fz = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const angebot = await d.komponentenAngebot('wohnmobil');
  const heizung = angebot.find(x => x.wert === 'heizung'), wasser = angebot.find(x => x.wert === 'wassertank');
  /* so legt die Abfrage der Checkliste sie an: Art und Name aus der Liste, Verbraucher aus dem Eintrag */
  const r1 = await d.komponenteAnlegen(fz, null, heizung.art, { bezeichnung: heizung.label, verbraucher: heizung.verbraucher });
  const r2 = await d.komponenteAnlegen(fz, null, wasser.art, { bezeichnung: wasser.label });
  assert.ok(r1.ok && r2.ok, JSON.stringify([r1, r2]));
  const schalter = await d.verbraucherSchalter(fz);
  assert.deepEqual(schalter.map(x => x.name), ['Heizung']);
  assert.ok(schalter[0].imCockpit);
});

test('Nichts angehakt geht: ein Fahrzeug ohne Komponenten ist gültig', async () => {
  const d = neueDaten();
  await d.starten();
  const r = await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' });
  assert.ok(r.ok);
  assert.equal((await d.komponentenListe(r.id)).length, 0);
  assert.equal((await d.verbraucherSchalter(r.id)).length, 0);
});

/* ---------- Oberfläche (Texte im Quelltext; die Seiten werden zusätzlich in einer jsdom-Simulation durchgeklickt) ---------- */

test('Oberfläche: Cockpit mit Verbraucher-Reihe, Motorseite mit Schalter je Verbraucher, Checkliste vor den Angaben', () => {
  const a = lesen('js/ansicht.js');
  assert.ok(a.includes("daten.verbraucherSchalter(a.fahrzeug.id)"), 'Cockpit lädt die Verbraucher-Schalter');
  assert.ok(a.includes("'cv-motoren cv-verbraucher'"));
  assert.ok(a.includes('function verbraucherSchalten(m)'));
  assert.ok(a.includes("'Im Cockpit zeigen'") && a.includes("'Nicht im Cockpit zeigen'"));
  assert.ok(a.indexOf('teile.push(checkliste());') < a.indexOf("key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Wie du das Fahrzeug nennst"), 'Checkliste steht vor den Details');
  assert.ok(a.includes("hashParam('anlage') === 'ja'"));
  assert.ok(lesen('css/styles.css').includes('.cv-verbraucher'));
});

test('Die Schalter-Funktionen des Motors heißen weiter wie bisher, die Läufe haben keinen zweiten Weg', () => {
  const d = lesen('js/daten.js');
  ['motorStart', 'motorStopp', 'motorLaufKorrigieren', 'motorZaehler', 'motorenListe', 'verbraucherStart', 'verbraucherStopp'].forEach(n => assert.ok(d.includes('Daten.prototype.' + n + ' = '), n));
  assert.ok(!d.includes('Daten.prototype.verbraucherSchalterStart'));
});

test('Version 2.0.56 überall gleich', () => {
  assert.equal(MM.VERSION, '2.0.56');
  assert.match(MM.STUFE, /Verbrauch/);
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.56';"));
  assert.equal(JSON.parse(lesen('package.json')).version, '2.0.56');
  assert.ok(lesen('README.md').includes('Version 2.0.56'));
  assert.ok(lesen('CHANGELOG.md').startsWith('# Änderungen\n\n## 2.0.56'));
  assert.ok(lesen('js/texte.js').includes("version: '2.0.56'"));
});

test('2.0.55: Tank-Fehler geht ans Feld tankId, Schalter im Cockpit klein', () => {
  assert.ok(lesen('js/ansicht.js').includes('res.fehler.tankId = res.fehler.tank'));
  assert.ok(/\.cv-motor \{[^}]*min-height: 2\.6rem/.test(lesen('css/styles.css')));
});
