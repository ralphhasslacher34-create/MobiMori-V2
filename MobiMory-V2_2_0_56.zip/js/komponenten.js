/*
 * Komponenten: Hauptkomponenten (Schale 3) und alles darunter (Schale 4 und tiefer).
 *
 * Es gibt nur EINE Liste für alle Komponenten. Jede Komponente "gehört zu"
 * einem Fahrzeug oder zu einer anderen Komponente. So lässt sich beliebig
 * tief aufschlüsseln: Motor, Einspritzung, Pumpe, ...
 *
 * Die Felder sind, wie bei den Fahrzeugarten, als Daten beschrieben.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Nur Hauptkomponenten haben eine Art. Die Reihenfolge ist die Anzeigereihenfolge.
     Der Tank (seit 2.0.48) ist die Quelle in der Kette Tank, Verbraucher (siehe js/versorgung.js). */
  var ARTEN = [
    { id: 'motor', name: 'Motor' },
    { id: 'getriebe', name: 'Getriebe' },
    { id: 'tank', name: 'Tank' },
    { id: 'heizung', name: 'Heizung' },
    { id: 'klima', name: 'Klima' },
    { id: 'strom', name: 'Stromversorgung' },
    { id: 'wasser', name: 'Wasserversorgung' },
    { id: 'sonstiges', name: 'Sonstiges' }
  ];

  var GRUPPEN = [
    { id: 'teil', titel: 'Teil' },
    { id: 'einbau', titel: 'Einbau' },
    { id: 'merkmale', titel: 'Technische Merkmale' }
  ];

  var FELDER = [
    { key: 'hersteller', label: 'Hersteller', typ: 'text', gruppe: 'teil' },
    { key: 'modell', label: 'Modell', typ: 'text', gruppe: 'teil' },
    { key: 'seriennummer', label: 'Seriennummer', typ: 'text', gruppe: 'teil' },
    { key: 'kurzname', label: 'Kurzname', typ: 'text', gruppe: 'teil', maxLaenge: 8,
      hilfe: 'Höchstens 8 Zeichen. Steht auf kleinen Knöpfen, zum Beispiel auf dem Motorschalter im Cockpit. Die App macht aus der Bezeichnung einen Vorschlag, du kannst ihn ändern.' },
    { key: 'baujahr', label: 'Baujahr', typ: 'ganzzahl', gruppe: 'teil', min: 1800 },
    { key: 'anzahl', label: 'Anzahl', typ: 'ganzzahl', gruppe: 'teil', min: 1,
      hilfe: 'Wie viele Stück dieser Art eingebaut sind, zum Beispiel 6 Rettungswesten. Leer zählt als 1.' },
    { key: 'eignungGeprueft', label: 'Eignung geprüft', typ: 'auswahl', gruppe: 'teil', leerText: 'Nein, noch nicht geprüft',
      optionen: [{ wert: 'ja', label: 'Ja, geprüft' }],
      hilfe: 'Nur wichtig, wenn eine Regel eine bestimmte Eignung verlangt, zum Beispiel „Automatik, 150 N“.' },
    { key: 'eingebautAm', label: 'Eingebaut am', typ: 'datum', gruppe: 'einbau' },
    { key: 'einbauort', label: 'Einbauort', typ: 'text', gruppe: 'einbau', hilfe: 'Zum Beispiel Motorraum oder Heck' },
    { key: 'ausgebautAm', label: 'Ausgebaut am', typ: 'datum', gruppe: 'einbau',
      hilfe: 'Nur eintragen, wenn das Teil nicht mehr im Fahrzeug ist' },
    { key: 'merkmale', label: 'Technische Merkmale', typ: 'liste', gruppe: 'merkmale',
      hilfe: 'Jedes Merkmal hat einen Namen, einen Wert und eine Einheit, zum Beispiel „Leistung“, „110“, „kW“. Bei Verbrauch und ähnlichem kommt eine Bezugsgröße dazu, zum Beispiel „100 km“.' }
  ];

  /*
   * Vorlagen für die offenen Listen der Merkmale und der Einheiten (seit 2.0.45).
   * Die Vorlage ist nur der Anfang: Der Nutzer kann eigene Einträge anlegen und jeden Eintrag ausblenden.
   * Die App trägt nichts von selbst in eine Komponente ein. Eine Einheit steht erst dann an einem Merkmal, wenn der Nutzer sie wählt.
   * Kennung eines mitgelieferten Eintrags = sein Name (Merkmal) oder sein Zeichen (Einheit).
   */
  var MERKMAL_VORLAGE = [
    { wert: 'Leistung', einheit: 'kW', bezug: '' },
    { wert: 'Hubraum', einheit: 'cm³', bezug: '' },
    { wert: 'Drehzahl', einheit: '1/min', bezug: '' },
    { wert: 'Verbrauch', einheit: 'l', bezug: 'Betriebsstunde' },
    { wert: 'Tankinhalt', einheit: 'l', bezug: '' },
    { wert: 'Kapazität', einheit: 'Ah', bezug: '' },
    { wert: 'Spannung', einheit: 'V', bezug: '' },
    { wert: 'Stromstärke', einheit: 'A', bezug: '' },
    { wert: 'Gewicht', einheit: 'kg', bezug: '' },
    { wert: 'Länge', einheit: 'mm', bezug: '' },
    { wert: 'Durchmesser', einheit: 'mm', bezug: '' },
    { wert: 'Druck', einheit: 'bar', bezug: '' },
    { wert: 'Ölmenge', einheit: 'l', bezug: '' },
    { wert: 'Auftrieb', einheit: 'N', bezug: '' }
  ];
  var EINHEITEN_VORLAGE = ['kW', 'PS', 'l', 'ml', 'kg', 'g', 'bar', 'V', 'A', 'Ah', 'W', 'N', 'mm', 'cm', 'm', 'cm³', 'l/h', '1/min', '°C', 'Stück', 'Prozent'];
  var MAX_EINHEIT = 20, MAX_BEZUG = 40, MAX_MERKMAL = 60;

  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }

  /*
   * Kurzname: aus der Bezeichnung entsteht eine Zeichenfolge, die immer auf einen kleinen Knopf passt.
   * Bekannte Wörter haben feste Kürzel (Steuerbord = STB), Zahlen bleiben ganz, andere Wörter
   * werden auf 3 Buchstaben gekürzt. Wird es länger als 8 Zeichen, werden sie auf 2 gekürzt,
   * zuletzt wird abgeschnitten. Das Ergebnis ist ein Vorschlag, der Nutzer bestätigt oder ändert ihn.
   */
  var MAX_KURZNAME = 8;
  var KUERZEL = { motor: 'MO', backbord: 'BB', steuerbord: 'STB', links: 'LI', rechts: 'RE', mitte: 'MI', hilfsmotor: 'HIMO', aussenborder: 'AB', hauptmotor: 'HMO', generator: 'GEN' };

  function sauber(wort) {
    return String(wort).toUpperCase().replace(/Ä/g, 'A').replace(/Ö/g, 'O').replace(/Ü/g, 'U').replace(/ß/g, 'SS')
      .replace(/[^A-Z0-9]/g, '');
  }

  function kurznameVorschlag(name) {
    var woerter = String(name == null ? '' : name).split(/[\s\-_\/,.;:]+/).filter(Boolean);
    var teile = woerter.map(function (w) {
      var schluessel = w.toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
      var bekannt = KUERZEL[schluessel];
      var s = sauber(w);
      return { bekannt: bekannt || null, zahl: /^\d+$/.test(s), s: s };
    }).filter(function (t) { return t.s; });
    function bauen(laenge) {
      return teile.map(function (t) { return t.bekannt ? t.bekannt : (t.zahl ? t.s : t.s.slice(0, laenge)); }).join('');
    }
    var r = bauen(3);
    if (r.length > MAX_KURZNAME) r = bauen(2);
    if (r.length > MAX_KURZNAME) r = r.slice(0, MAX_KURZNAME);
    return r;
  }

  /* Was auf dem Knopf steht: der gespeicherte Kurzname, sonst der Vorschlag aus der Bezeichnung. */
  function kurzAnzeige(werte) {
    var k = werte && werte.kurzname ? String(werte.kurzname).trim() : '';
    return k || kurznameVorschlag(werte ? werte.bezeichnung : '');
  }

  /* Nur Hauptkomponenten der Art Motor haben einen Schalter. */
  function istMotor(komponente) { return !!komponente && !komponente.parentId && komponente.art === 'motor'; }

  /* Kann diese Komponente ein- und ausgeschaltet werden (Lauf mit Start, Stopp, Betriebsstunden)? Jeder Motor, und jeder Verbraucher
   * (Komponente mit „Verbraucher: ja“), seit 2.0.52. werte: die aktuellen Werte der Komponente. */
  function kannLaufen(komponente, werte) { return istMotor(komponente) || (!!komponente && !!werte && werte.verbraucher === 'ja'); }

  function art(id) {
    for (var i = 0; i < ARTEN.length; i++) { if (ARTEN[i].id === id) return ARTEN[i]; }
    return null;
  }

  function felder() { return FELDER.map(kopie); }

  function gruppen() {
    return GRUPPEN.map(function (g) {
      return { id: g.id, titel: g.titel, felder: FELDER.filter(function (f) { return f.gruppe === g.id; }).map(kopie) };
    });
  }

  function artIndex(id) {
    for (var i = 0; i < ARTEN.length; i++) { if (ARTEN[i].id === id) return i; }
    return ARTEN.length;
  }

  /*
   * Ausgeblendete Komponenten (seit 2.0.45): Eine ausgeblendete Hauptkomponente verdeckt alles darunter.
   * liste: wie daten.komponentenListe ({ komponente, aktuell }). Ergebnis: die Liste ohne Ausgeblendete und ohne Verdeckte.
   * Ausgeblendete zählen nicht für die Ausrüstungsprüfung, den Grundcheck, den Reisecheck und den Motorschalter.
   */
  function istAusgeblendet(komponente) { return !!(komponente && komponente.ausgeblendet); }

  function verdecktIds(liste) {
    var nachId = {};
    (liste || []).forEach(function (x) { nachId[x.komponente.id] = x; });
    var verdeckt = {};
    (liste || []).forEach(function (x) {
      var k = x.komponente, schutz = 0, hoch = k;
      while (hoch && schutz++ < 50) {
        if (hoch.ausgeblendet) { verdeckt[k.id] = true; break; }
        hoch = hoch.parentId ? (nachId[hoch.parentId] ? nachId[hoch.parentId].komponente : null) : null;
      }
    });
    return verdeckt;
  }

  function aktive(liste) {
    var v = verdecktIds(liste);
    return (liste || []).filter(function (x) { return !v[x.komponente.id]; });
  }

  /* Alle Kennungen einer Komponente und alles darunter (beliebig tief). */
  function mitUnterkomponenten(liste, id) {
    var ids = [id], i = 0;
    while (i < ids.length && ids.length < 5000) {
      var aktuell = ids[i++];
      (liste || []).forEach(function (x) { if (x.komponente.parentId === aktuell && ids.indexOf(x.komponente.id) < 0) ids.push(x.komponente.id); });
    }
    return ids;
  }

  /* Ein Merkmal zum Anzeigen: „Leistung: 110 kW“ oder „Verbrauch: 8 l, bezogen auf 100 km“. Alte Zeilen ohne Einheit bleiben wie sie waren. */
  function merkmalWert(z) {
    var t = String(z.wert) + (z.einheit ? ' ' + z.einheit : '');
    return t + (z.bezug ? ', bezogen auf ' + z.bezug : '');
  }
  function merkmalText(z) { return z.name + ': ' + merkmalWert(z); }

  function gleichText(a, b) { return String(a == null ? '' : a).trim().toLowerCase() === String(b == null ? '' : b).trim().toLowerCase(); }

  /*
   * Die Listen aus Vorlage, eigenen Einträgen und Ausgeblendeten. dok: das gespeicherte Dokument (oder null).
   * Merkmale: [{ wert, label, einheit, bezug, eigen, ausgeblendet }]; Einheiten: [{ wert, label, eigen, ausgeblendet }]
   */
  function merkmaleListe(dok) {
    var versteckt = (dok && dok.ausgeblendet) || [];
    var liste = MERKMAL_VORLAGE.map(function (m) {
      return { wert: m.wert, label: m.wert, einheit: m.einheit, bezug: m.bezug, eigen: false, ausgeblendet: versteckt.indexOf(m.wert) >= 0 };
    });
    ((dok && dok.eigene) || []).forEach(function (m) {
      liste.push({ wert: m.wert, label: m.label, einheit: m.einheit || '', bezug: m.bezug || '', eigen: true, ausgeblendet: versteckt.indexOf(m.wert) >= 0 });
    });
    return liste;
  }

  function einheitenListe(dok) {
    var versteckt = (dok && dok.ausgeblendet) || [];
    var liste = EINHEITEN_VORLAGE.map(function (e) { return { wert: e, label: e, eigen: false, ausgeblendet: versteckt.indexOf(e) >= 0 }; });
    ((dok && dok.eigene) || []).forEach(function (e) { liste.push({ wert: e.wert, label: e.label, eigen: true, ausgeblendet: versteckt.indexOf(e.wert) >= 0 }); });
    return liste;
  }

  /*
   * Die Komponentenliste für die Checkliste bei der Fahrzeuganlage (seit 2.0.53).
   * Wie die Liste der Stoffe: mitgelieferte Vorlage als Anfang, eigene Einträge, Ausblenden (nichts wird gelöscht).
   * Gespeichert wird nur, was der Nutzer ändert: Dokument „komponentenliste“ { eigene: [...], ausgeblendet: [...] }.
   * Eintrag: { wert, label, art (Art der Hauptkomponente), verbraucher: 'ja' | 'nein' }.
   * Welche Einträge zu welcher Fahrzeugart angeboten werden: „welten“ und „arten“ (Fahrzeugart oder eine ihrer Obergruppen).
   * Im Code steht dazu nur der Motor je Fahrzeugart (js/motoren.js). Alles andere hier ist ein VORSCHLAG und kein Wissen der App.
   * Wer keine Einschränkung hat, wird bei jeder Art angeboten.
   */
  var LISTE_VORLAGE = [
    { wert: 'motor', label: 'Motor', art: 'motor', verbraucher: 'ja' },
    { wert: 'getriebe', label: 'Getriebe', art: 'getriebe', verbraucher: 'nein' },
    { wert: 'tank', label: 'Tank (Kraftstoff)', art: 'tank', verbraucher: 'nein' },
    { wert: 'gasflasche', label: 'Gasflasche', art: 'tank', verbraucher: 'nein', arten: ['wohnmobil', 'wohnwagen'], welten: ['wasser'] },
    { wert: 'wassertank', label: 'Wassertank (Frischwasser)', art: 'wasser', verbraucher: 'nein', arten: ['wohnmobil', 'wohnwagen'], welten: ['wasser'] },
    { wert: 'abwassertank', label: 'Abwassertank', art: 'wasser', verbraucher: 'nein', arten: ['wohnmobil', 'wohnwagen'], welten: ['wasser'] },
    { wert: 'heizung', label: 'Heizung', art: 'heizung', verbraucher: 'ja', arten: ['wohnmobil', 'wohnwagen'], welten: ['wasser'] },
    { wert: 'boiler', label: 'Boiler', art: 'wasser', verbraucher: 'ja', arten: ['wohnmobil', 'wohnwagen'], welten: ['wasser'] },
    { wert: 'kuehlschrank', label: 'Kühlschrank', art: 'sonstiges', verbraucher: 'ja', arten: ['wohnmobil', 'wohnwagen'], welten: ['wasser'] },
    { wert: 'klima', label: 'Klimaanlage', art: 'klima', verbraucher: 'ja', welten: ['land', 'wasser'] },
    { wert: 'generator', label: 'Generator', art: 'sonstiges', verbraucher: 'ja', arten: ['wohnmobil'], welten: ['wasser'] },
    { wert: 'batterie', label: 'Batterie / Stromversorgung', art: 'strom', verbraucher: 'nein' }
  ];
  var MAX_LISTE_NAME = 60;

  function listeEintraege(dok) {
    var versteckt = (dok && Array.isArray(dok.ausgeblendet)) ? dok.ausgeblendet : [];
    var liste = LISTE_VORLAGE.map(function (e) {
      var k = kopie(e); k.eigen = false; k.ausgeblendet = versteckt.indexOf(e.wert) >= 0; return k;
    });
    ((dok && dok.eigene) || []).forEach(function (e) {
      liste.push({ wert: e.wert, label: e.label, art: e.art, verbraucher: e.verbraucher === 'ja' ? 'ja' : 'nein', eigen: true, ausgeblendet: versteckt.indexOf(e.wert) >= 0 });
    });
    return liste;
  }

  /* Was die Checkliste für eine Fahrzeugart anbietet. motorJa: false, wenn die Art laut Einstellung keinen Motor hat (dann fehlt der Eintrag Motor).
   * vorfahren: Liste aus der Art und ihren Obergruppen (MM.Fahrzeugarten.vorfahren), welt: ihre Welt. Eigene Einträge gelten für jede Art. */
  function listeAngebot(eintraege, vorfahren, welt, motorJa) {
    return (eintraege || []).filter(function (e) {
      if (e.ausgeblendet) return false;
      if (e.eigen) return true;
      if (e.art === 'motor' && motorJa === false) return false;
      if (!e.arten && !e.welten) return true;
      if (e.arten && e.arten.some(function (a) { return (vorfahren || []).indexOf(a) >= 0; })) return true;
      /* Der Eintrag gilt für ganze Welten nur, wenn „arten“ fehlt oder die Welt ausdrücklich genannt ist */
      return !!(e.welten && e.welten.indexOf(welt) >= 0);
    });
  }

  MM.Komponenten = {
    LISTE_VORLAGE: LISTE_VORLAGE,
    MAX_LISTE_NAME: MAX_LISTE_NAME,
    listeEintraege: listeEintraege,
    listeAngebot: listeAngebot,
    arten: function () { return ARTEN.slice(); },
    art: art,
    artIndex: artIndex,
    felder: felder,
    gruppen: gruppen,
    MAX_KURZNAME: MAX_KURZNAME,
    kurznameVorschlag: kurznameVorschlag,
    kurzAnzeige: kurzAnzeige,
    istMotor: istMotor,
    kannLaufen: kannLaufen,
    istAusgeblendet: istAusgeblendet,
    verdecktIds: verdecktIds,
    aktive: aktive,
    mitUnterkomponenten: mitUnterkomponenten,
    merkmalWert: merkmalWert,
    merkmalText: merkmalText,
    gleichText: gleichText,
    MERKMAL_VORLAGE: MERKMAL_VORLAGE,
    EINHEITEN_VORLAGE: EINHEITEN_VORLAGE,
    MAX_EINHEIT: MAX_EINHEIT,
    MAX_BEZUG: MAX_BEZUG,
    MAX_MERKMAL: MAX_MERKMAL,
    merkmaleListe: merkmaleListe,
    einheitenListe: einheitenListe
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));

/*
 * Versorgung: Verbraucher, Quelle (Tank) und die Kette dazwischen (seit 2.0.48). Nur Regeln, kein Speicher, kein Netz.
 * Steht in dieser Datei, weil es zu den Komponenten gehört (Tank ist eine Art, Verbraucher und Quelle sind Angaben der Komponente)
 * und weil jede Stelle, die Komponenten speichert, diese Regeln braucht.
 *
 * Festlegungen des Nutzers (08.11.2026, Ereignis-Baukasten):
 *  - Tanks sind Komponenten mit Inhalt. Es gibt vier Kombinationen: ein Motor ein Tank, zwei Motoren ein Tank,
 *    ein Motor mehrere Tanks, zwei Motoren mehrere Tanks.
 *  - Verbraucher sind nicht nur Motoren und je Fahrzeug verschieden (Wohnmobil: Heizung mit Gas, keine Verbindung zum Dieseltank;
 *    Boot: Standheizung mit Diesel, am selben oder an einem eigenen Tank). MobiMory muss beides abbilden.
 *  - Beim Anlegen einer Komponente beginnt die Verkettung mit einer kurzen Abfrage: Ist es ein Verbraucher, was verbraucht er
 *    (Treibstoff, Gas, Strom …), woher kommt es.
 *  - Strom kommt als eigene spätere Stufe. Darum gibt es für „Strom“ hier noch keine Quelle.
 *  - Listen sind offen: Die Vorlage ist nur der Anfang, jeder Nutzer kann Einträge anlegen und ausblenden.
 *
 * Gespeichert wird in den Werten der Komponente (Verlauf wie bei jedem anderen Feld):
 *   verbraucher: 'ja' | 'nein' | null (null = noch nicht beantwortet)
 *   stoff:       Name aus der Liste der Stoffe (bei einem Verbraucher: was er verbraucht; bei einem Tank: was drin ist)
 *   quellen:     Kennungen der Tanks, aus denen ein Verbraucher versorgt wird (kann mehrere sein)
 *   verbrauchAus: 'fuellstand' | 'stunden' (seit 2.0.51, nur Verbraucher): woraus sein Verbrauch gerechnet wird
 *   Tank (seit 2.0.51): fuellstand, fuellstandArt, fuellstandZeit, fuellstandStunden, verbrauch, reichweite (siehe js/tanken.js)
 * Ein Tank ist eine Hauptkomponente der Art „Tank“.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var STROM = 'Strom';
  var MAX_STOFF = 30;

  /* Nur die Vorlage. Kennung eines mitgelieferten Eintrags = sein Name (wie bei den Einheiten). */
  var STOFF_VORLAGE = ['Diesel', 'Benzin', 'Gas (Flüssiggas)', 'Erdgas (CNG)', STROM];

  /* Angezeigt im Verlauf der Komponente (die Felder selbst prüft die Datenschicht, nicht die Feldliste der Komponenten). */
  var ANZEIGE_FELDER = [
    { key: 'verbraucher', label: 'Verbraucher', typ: 'text' },
    { key: 'stoff', label: 'Stoff', typ: 'text' },
    { key: 'quellen', label: 'Quelle (Tank)', typ: 'text' },
    /* seit 2.0.51 */
    { key: 'verbrauchAus', label: 'Verbrauch rechnen aus', typ: 'text' },
    { key: 'fuellstand', label: 'Füllstand (l)', typ: 'zahl' }
  ];

  /* Woraus der Verbrauch eines Verbrauchers gerechnet wird (seit 2.0.51, je Verbraucher wählbar): 'fuellstand' (Standard) oder 'stunden'. */
  function verbrauchAus(werte) { return werte && werte.verbrauchAus === 'stunden' ? 'stunden' : 'fuellstand'; }

  function gleichText(a, b) { return String(a == null ? '' : a).trim().toLowerCase() === String(b == null ? '' : b).trim().toLowerCase(); }

  /* Die Liste der Stoffe aus Vorlage, eigenen Einträgen und Ausgeblendeten. dok: das gespeicherte Dokument (oder null). */
  function stoffeListe(dok) {
    var versteckt = (dok && dok.ausgeblendet) || [];
    var liste = STOFF_VORLAGE.map(function (s) { return { wert: s, label: s, eigen: false, ausgeblendet: versteckt.indexOf(s) >= 0 }; });
    ((dok && dok.eigene) || []).forEach(function (s) { liste.push({ wert: s.wert, label: s.label, eigen: true, ausgeblendet: versteckt.indexOf(s.wert) >= 0 }); });
    return liste;
  }

  function istTank(komponente) { return !!komponente && !komponente.parentId && komponente.art === 'tank'; }
  function istStrom(stoff) { return gleichText(stoff, STROM); }

  function quellenIds(werte) {
    var q = werte && werte.quellen;
    return Array.isArray(q) ? q.filter(function (x) { return typeof x === 'string' && x; }) : [];
  }

  /* Das Merkmal „Tankinhalt“ einer Komponente als Text („80 l“) oder null. Gesucht wird der Name, ohne Groß- und Kleinschreibung. */
  function tankinhalt(werte) {
    var z = ((werte && werte.merkmale) || []).filter(function (m) { return gleichText(m && m.name, 'Tankinhalt'); })[0];
    return z ? MM.Komponenten.merkmalWert(z) : null;
  }

  function nachName(a, b) { return String(a.name).localeCompare(String(b.name), 'de', { numeric: true, sensitivity: 'base' }); }

  /*
   * Die Kette eines Fahrzeugs. liste: wie daten.komponentenListe ({ komponente, aktuell }).
   * Ausgeblendete (samt allem darunter) und ausgebaute Teile zählen nicht, wie bei den anderen Prüfungen.
   * Ergebnis:
   *   tanks:    [{ id, name, stoff, inhalt, verbraucher: [{ id, name, stoff }] }], nach Namen
   *   ohneQuelle: Verbraucher ohne Tank (und nicht Strom): [{ id, name, stoff, grund: 'keine' | 'inaktiv' }]
   *   strom:    Verbraucher mit Strom (die Quelle kommt in einer späteren Stufe): [{ id, name }]
   *   offen:    Hauptkomponenten (keine Tanks), bei denen „Verbraucher?“ noch nicht beantwortet ist: [{ id, name }]
   *   umwandelbar: Komponenten mit dem Merkmal „Tankinhalt“, die noch kein Tank sind: [{ id, name, inhalt, istTeil, ueber }]
   *   leer:     es gibt weder einen Tank noch einen Verbraucher
   */
  function kette(liste) {
    var alle = liste || [];
    var aktive = MM.Komponenten.aktive(alle).filter(function (x) { return !x.aktuell.werte.ausgebautAm; });
    var nachId = {};
    alle.forEach(function (x) { nachId[x.komponente.id] = x; });
    var tankListe = aktive.filter(function (x) { return istTank(x.komponente); });
    var tankNachId = {};
    var tanks = tankListe.map(function (x) {
      var tw = x.aktuell.werte;
      var t = { id: x.komponente.id, name: tw.bezeichnung, stoff: tw.stoff || null, inhalt: tankinhalt(tw), verbraucher: [],
        fuellstand: typeof tw.fuellstand === 'number' ? tw.fuellstand : null, fuellstandArt: tw.fuellstandArt || null, fuellstandZeit: tw.fuellstandZeit || null,
        verbrauch: tw.verbrauch || null, reichweite: tw.reichweite || null };
      tankNachId[t.id] = t;
      return t;
    }).sort(nachName);

    var ohneQuelle = [], strom = [], offen = [], umwandelbar = [];
    aktive.forEach(function (x) {
      var w = x.aktuell.werte, k = x.komponente;
      if (istTank(k)) return;
      var eintrag = { id: k.id, name: w.bezeichnung, stoff: w.stoff || null, aus: verbrauchAus(w) };
      if (w.verbraucher === 'ja') {
        if (istStrom(w.stoff)) { strom.push({ id: k.id, name: w.bezeichnung }); return; }
        var ids = quellenIds(w);
        var treffer = ids.filter(function (id) { return tankNachId[id]; });
        treffer.forEach(function (id) { tankNachId[id].verbraucher.push(eintrag); });
        if (!treffer.length) ohneQuelle.push({ id: k.id, name: w.bezeichnung, stoff: w.stoff || null, grund: ids.length ? 'inaktiv' : 'keine' });
      } else if (!w.verbraucher && !k.parentId) {
        offen.push({ id: k.id, name: w.bezeichnung });
      }
      /* Ein Motor wird nie zum Tank angeboten; ein Verbraucher auch nicht. */
      if (w.verbraucher !== 'ja' && !(k.art === 'motor' && !k.parentId)) {
        var inhalt = tankinhalt(w);
        if (inhalt) {
          var eltern = k.parentId && nachId[k.parentId] ? nachId[k.parentId].aktuell.werte.bezeichnung : null;
          umwandelbar.push({ id: k.id, name: w.bezeichnung, inhalt: inhalt, istTeil: !!k.parentId, ueber: eltern });
        }
      }
    });
    tanks.forEach(function (t) { t.verbraucher.sort(nachName); });
    ohneQuelle.sort(nachName); strom.sort(nachName); offen.sort(nachName); umwandelbar.sort(nachName);
    var hatVerbraucher = ohneQuelle.length > 0 || strom.length > 0 || tanks.some(function (t) { return t.verbraucher.length > 0; });
    return { tanks: tanks, ohneQuelle: ohneQuelle, strom: strom, offen: offen, umwandelbar: umwandelbar, leer: !tanks.length && !hatVerbraucher };
  }

  /* Welche Verbraucher beziehen aus diesem Tank (oder aus einem Teil darunter)? Zählt alle Komponenten, auch ausgeblendete. */
  function verbraucherVon(liste, tankIds) {
    var ids = Array.isArray(tankIds) ? tankIds : [tankIds];
    return (liste || []).filter(function (x) {
      return quellenIds(x.aktuell.werte).some(function (q) { return ids.indexOf(q) >= 0; });
    });
  }

  MM.Versorgung = {
    STROM: STROM,
    MAX_STOFF: MAX_STOFF,
    STOFF_VORLAGE: STOFF_VORLAGE.slice(),
    ANZEIGE_FELDER: ANZEIGE_FELDER,
    stoffeListe: stoffeListe,
    istTank: istTank,
    istStrom: istStrom,
    quellenIds: quellenIds,
    verbrauchAus: verbrauchAus,
    tankinhalt: tankinhalt,
    kette: kette,
    verbraucherVon: verbraucherVon,
    gleichText: gleichText
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
