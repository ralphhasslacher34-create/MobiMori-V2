/* Kleine Helfer zum Anzeigen von Werten (deutsche Schreibweise). */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  function zahl(n) {
    return Number(n).toLocaleString('de-DE', { maximumFractionDigits: 2 });
  }

  /* 1234.5 -> "1.234,50 €" (immer zwei Nachkommastellen) */
  function euro(n) {
    return Number(n).toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
  }

  /* "2026-11-03" -> "03.11.2026" */
  function datum(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
    return m ? m[3] + '.' + m[2] + '.' + m[1] : '';
  }

  /* "2026-11-03T12:30:00.000Z" -> "03.11.2026, 13:30" (Ortszeit des Geräts) */
  function zeitpunkt(iso) {
    var d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return z(d.getDate()) + '.' + z(d.getMonth() + 1) + '.' + d.getFullYear() +
      ', ' + z(d.getHours()) + ':' + z(d.getMinutes());
  }

  /* Wert eines Feldes zum Anzeigen; null, wenn nichts eingetragen ist. */
  function wert(feld, w) {
    if (w === null || w === undefined || w === '') return null;
    if (feld.typ === 'mehrfach') {
      if (!Array.isArray(w) || !w.length) return null;
      /* Mit Optionen (Ausstattung): die Beschriftung statt der Kennung */
      return w.map(function (x) {
        var o = (feld.optionen || []).filter(function (op) { return typeof op === 'object' && op.wert === x; })[0];
        return o ? o.label : x;
      }).join(', ');
    }
    if (feld.koordinate && typeof w === 'number') return w.toFixed(5).replace('.', ',');
    if (feld.typ === 'zeilen') {
      if (!Array.isArray(w) || !w.length) return null;
      return w.map(function (z) { return z.label + (z.papier ? ' (' + z.papier + ')' : ''); }).join('; ');
    }
    if (feld.typ === 'liste') {
      if (!Array.isArray(w) || !w.length) return null;
      /* Merkmale (seit 2.0.45) können eine Einheit und eine Bezugsgröße haben; alte Zeilen haben nur Name und Wert. */
      return w.map(function (z) { return z.name + ': ' + z.wert + (z.einheit ? ' ' + z.einheit : '') + (z.bezug ? ', bezogen auf ' + z.bezug : ''); }).join('; ');
    }
    if (feld.typ === 'auswahl' && feld.optionen) {
      for (var i = 0; i < feld.optionen.length; i++) {
        var o = feld.optionen[i];
        if (typeof o === 'object' && o.wert === w) return o.label;
      }
    }
    if (feld.typ === 'zeit') return String(w) + ' Uhr';
    if (feld.typ === 'datum') return datum(w);
    if (feld.typ === 'zahl' && feld.einheit === '€') return euro(w);
    if (feld.typ === 'zahl') return zahl(w) + (feld.einheit ? ' ' + feld.einheit : '');
    if (feld.typ === 'ganzzahl') return String(w);
    return String(w);
  }

  /* 1536 -> "1,5 KB", 5242880 -> "5 MB" */
  function groesse(bytes) {
    var n = Number(bytes);
    if (!isFinite(n) || n < 0) return '';
    if (n < 1024) return n + ' Byte';
    if (n < 1024 * 1024) return zahl(n / 1024) + ' KB';
    if (n < 1024 * 1024 * 1024) return zahl(n / 1024 / 1024) + ' MB';
    return zahl(n / 1024 / 1024 / 1024) + ' GB';
  }

  /* Kachelseiten (seit 2.0.31): Wie viele Spalten und welche Zeilenhöhe füllen den freien Platz gut?
     p: breite, hoehe (freier Platz für die Kacheln), anzahl, rem, abstand, alles in Pixeln.
     Ergebnis: { spalten, zeilen, hoehe }, die Höhe je Zeile in Pixeln. Kacheln werden nicht schmaler als 8,5 rem,
     nicht niedriger als 4,8 rem und nicht höher als 15 rem. Mit hoechstSpalten (seit 2.0.32) lässt sich die Spaltenzahl begrenzen, wenn der Text sonst nicht passt. Bevorzugt werden Kacheln mit einem Seitenverhältnis um 1,8, und leere Plätze im Raster werden vermieden. */
  function kachelRaster(p) {
    var rem = p.rem > 0 ? p.rem : 16, gap = p.abstand >= 0 ? p.abstand : 0.85 * rem;
    var n = Math.max(0, Math.floor(p.anzahl || 0)), minB = 8.5 * rem, minH = 4.8 * rem, maxH = 15 * rem;
    var breite = p.breite > 0 ? p.breite : minB, frei = p.hoehe > 0 ? p.hoehe : null;
    if (!n) return { spalten: 1, zeilen: 0, hoehe: Math.round(minH) };
    var maxS = Math.max(1, Math.min(n, Math.floor((breite + gap) / (minB + gap)))), beste = null;
    if (p.hoechstSpalten >= 1) maxS = Math.max(1, Math.min(maxS, Math.floor(p.hoechstSpalten)));
    for (var c = 1; c <= maxS; c++) {
      var zeilen = Math.ceil(n / c), w = (breite - (c - 1) * gap) / c;
      var hFrei = frei === null ? 2 * minH : (frei - (zeilen - 1) * gap) / zeilen;
      var h = Math.min(maxH, Math.max(minH, hFrei));
      var punkte = Math.abs(Math.log((w / h) / 1.8)) + 2 * (c * zeilen - n) / n + (hFrei < minH ? (minH - hFrei) / minH * 3 : 0);
      if (!beste || punkte < beste.punkte - 1e-9) beste = { spalten: c, zeilen: zeilen, hoehe: Math.round(h), punkte: punkte };
    }
    return { spalten: beste.spalten, zeilen: beste.zeilen, hoehe: beste.hoehe };
  }

  MM.Hilfen = { groesse: groesse, zahl: zahl, euro: euro, datum: datum, zeitpunkt: zeitpunkt, wert: wert, kachelRaster: kachelRaster };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
