ALTER TABLE freigabe ADD COLUMN nachweis_art TEXT;
ALTER TABLE freigabe ADD COLUMN nachweis_bis TEXT;
ALTER TABLE freigabe ADD COLUMN bestaetigt_am INTEGER;
