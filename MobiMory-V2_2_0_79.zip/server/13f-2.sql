ALTER TABLE freigabe ADD COLUMN rechte TEXT;
ALTER TABLE freigabe ADD COLUMN gast_name TEXT;
ALTER TABLE freigabe ADD COLUMN ausnahmen TEXT;
