/*
 * Hilfe zur Behebung einer Störung (Bau 2, seit 2.0.76). Reine Beschreibung und Rechnung, kein Speichern.
 *
 * Vier Teile, Ralph 14.11.2026:
 *  1. Anleitungen aus den Dokumenten des Fahrzeugs (Bedienungsanleitung, Reparaturbuch, Wartungsanleitung, Ersatzteilliste), passende zuerst.
 *  2. Werkstatt in der Nähe: eigene Werkstätten aus der Adressliste und ein Link zur Suche im Kartendienst (nur beim Antippen, die App schickt nichts).
 *  3. Notrufnummern und Pannenhilfe je Land.
 *  4. Reparaturgedächtnis: Hat der Nutzer früher eine Reparatur eingetragen und kommt eine ähnliche Störung wieder, zeigt MobiMory, was damals eingetragen wurde.
 *     Es werden nur Angaben gezeigt, die jemand eingetragen hat. MobiMory rät keine Ursachen.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Wörter, die nichts über die Störung sagen. */
  var STOPP = ['nicht', 'kein', 'keine', 'keiner', 'geht', 'gehen', 'wird', 'werden', 'habe', 'haben', 'sind', 'sein', 'mein', 'meine', 'dass', 'dies', 'diese', 'aber', 'auch', 'nach', 'beim', 'wenn', 'wieder', 'schon', 'noch', 'sehr', 'zeigt', 'macht', 'immer', 'ganz',
    'einmal', 'seit', 'fahrzeug', 'wohnmobil', 'auto', 'boot', 'problem', 'stoerung', 'defekt', 'kaputt', 'funktioniert', 'funktionieren', 'manchmal', 'plötzlich', 'ploetzlich', 'komisch', 'komische', 'irgendwie', 'etwas', 'wegen', 'ohne', 'oder', 'mehr', 'dann', 'mit', 'bitte', 'heute', 'gestern', 'jetzt'];
  var ARTEN_HILFE = ['bedienung', 'reparaturbuch', 'wartung', 'ersatzteile'];
  var MAX_AEHNLICH = 3, MAX_DOKUMENTE = 8;

  function sauber(t) {
    return String(t == null ? '' : t).toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
  }
  /* Die Stämme der Wörter (erste fünf Buchstaben): „Kühlschrank“ und „Kühlung“ treffen sich bei „kuehl“. */
  function staemme(text) {
    var res = [];
    sauber(text).split(/[^a-z0-9]+/).forEach(function (w) {
      if (w.length < 4 || STOPP.indexOf(w) >= 0 || /^\d+$/.test(w)) return;
      var s = w.slice(0, 5);
      if (res.indexOf(s) < 0) res.push(s);
    });
    return res;
  }
  function gemeinsam(a, b) { var n = 0; a.forEach(function (x) { if (b.indexOf(x) >= 0) n++; }); return n; }

  /* Frühere Vorgänge, die zur neuen Störung passen. neu: { id, bezeichnung, beschreibung, komponenteId }.
     alte: Liste mit { id, art, status, bezeichnung, beschreibung, arbeit, gemeldetAm, erledigtAm, erledigtNotiz, komponenteId }.
     Ein Treffer braucht mindestens ein gemeinsames Wort. Gleiche Komponente zählt für die Reihenfolge. */
  function aehnliche(neu, alte, max) {
    var n = neu || {}, suche = staemme((n.bezeichnung || '') + ' ' + (n.beschreibung || ''));
    if (!suche.length) return [];
    var res = [];
    (alte || []).forEach(function (a) {
      if (!a || a.id === n.id) return;
      var k = gemeinsam(suche, staemme((a.bezeichnung || '') + ' ' + (a.beschreibung || '') + ' ' + (a.arbeit || '') + ' ' + (a.erledigtNotiz || '')));
      if (!k) return;
      var punkte = k + (n.komponenteId && a.komponenteId === n.komponenteId ? 0.5 : 0);
      var damals = [];
      if (a.art === 'arbeit' && a.arbeit) damals.push(a.arbeit);
      if (a.erledigtNotiz) damals.push(a.erledigtNotiz);
      res.push({ id: a.id, art: a.art === 'arbeit' ? 'arbeit' : 'stoerung', status: a.status === 'erledigt' ? 'erledigt' : 'offen', titel: a.bezeichnung || '',
        gemeldetAm: a.gemeldetAm || null, erledigtAm: a.erledigtAm || null, damals: damals, punkte: punkte });
    });
    res.sort(function (x, y) {
      return y.punkte - x.punkte || String(y.erledigtAm || y.gemeldetAm || '').localeCompare(String(x.erledigtAm || x.gemeldetAm || ''));
    });
    return res.slice(0, max || MAX_AEHNLICH);
  }

  /* Dokumente, die bei einer Störung helfen können. dokumente: { id, bezeichnung, art, notiz }. Passende zuerst, dann nach Art. */
  function dokumente(liste, text) {
    var suche = staemme(text), res = [];
    (liste || []).forEach(function (d) {
      var r = ARTEN_HILFE.indexOf(d.art);
      if (r < 0) return;
      var passt = suche.length > 0 && gemeinsam(suche, staemme((d.bezeichnung || '') + ' ' + (d.notiz || ''))) > 0;
      res.push({ id: d.id, bezeichnung: d.bezeichnung || 'Dokument', art: d.art, notiz: d.notiz || '', passt: passt, rang: r });
    });
    res.sort(function (a, b) {
      return (b.passt ? 1 : 0) - (a.passt ? 1 : 0) || a.rang - b.rang || (a.bezeichnung < b.bezeichnung ? -1 : a.bezeichnung > b.bezeichnung ? 1 : 0);
    });
    return res.slice(0, MAX_DOKUMENTE);
  }

  /* Eigene Werkstätten aus der Adressliste. adressen: { id, bezeichnung, art, telefon, ort, ausgeblendet }. */
  function werkstaetten(adressen) {
    return (adressen || []).filter(function (a) { return a.art === 'werkstatt' && a.ausgeblendet !== 'ja'; })
      .map(function (a) { return { id: a.id, name: a.bezeichnung || 'Werkstatt', telefon: a.telefon || '', ort: a.ort || '' }; })
      .sort(function (a, b) { return a.name < b.name ? -1 : a.name > b.name ? 1 : 0; });
  }

  /* Link zur Werkstattsuche im Kartendienst. Er wird nur geöffnet, wenn der Nutzer ihn antippt. */
  function werkstattLink(ort) {
    var o = String(ort == null ? '' : ort).replace(/\s+/g, ' ').trim().slice(0, 80);
    return 'https://www.openstreetmap.org/search?query=' + encodeURIComponent('Autowerkstatt' + (o ? ' ' + o : ''));
  }

  /* Notrufnummern und Pannenhilfe. Stand 14.11.2026 aus den Angaben der Automobilclubs und der EU, ohne Gewähr: bitte vor der Reise prüfen. */
  var STAND = '14.11.2026';
  var CLUBS = [
    { name: 'ADAC Auslandsnotruf (für Mitglieder, rund um die Uhr)', nummer: '+49 89 22 22 22' },
    { name: 'ACE Euronotruf (für Mitglieder, rund um die Uhr)', nummer: '+49 711 530 34 35 36' },
    { name: 'AvD Auslandsnotruf (für Mitglieder)', nummer: '+49 69 6606 600' }
  ];
  var LAENDER = [
    { wert: 'de', land: 'Deutschland', rettung: '112', polizei: '110', feuer: '112', pannen: [{ name: 'ADAC Pannenhilfe (Inland, hilft im Pannenfall auch Nichtmitgliedern)', nummer: '089 20 20 40 00' }] },
    { wert: 'at', land: 'Österreich', rettung: '144', polizei: '133', feuer: '122', pannen: [{ name: 'ÖAMTC Pannenhilfe', nummer: '120' }, { name: 'ARBÖ Pannenhilfe', nummer: '123' }] },
    { wert: 'ch', land: 'Schweiz', rettung: '144', polizei: '117', feuer: '118', pannen: [], hinweis: 'Die 112 geht auch.' },
    { wert: 'dk', land: 'Dänemark', rettung: '112', polizei: '112', feuer: '112', pannen: [] },
    { wert: 'se', land: 'Schweden', rettung: '112', polizei: '112', feuer: '112', pannen: [] },
    { wert: 'no', land: 'Norwegen', rettung: '113', polizei: '112', feuer: '110', pannen: [], hinweis: 'Rettungsdienst 113, Polizei 112, Feuerwehr 110.' },
    { wert: 'fi', land: 'Finnland', rettung: '112', polizei: '112', feuer: '112', pannen: [] },
    { wert: 'eu', land: 'Anderes Land in der EU', rettung: '112', polizei: '112', feuer: '112', pannen: [], hinweis: 'Die 112 gilt in der ganzen EU. Einzelne Länder haben zusätzlich eigene Nummern.' }
  ];
  function land(wert) { for (var i = 0; i < LAENDER.length; i++) { if (LAENDER[i].wert === wert) return LAENDER[i]; } return LAENDER[0]; }

  /* Alles für eine Störung. eingabe: { text, komponenteId, id, vorgaenge, dokumente, adressen }. */
  function hilfe(eingabe) {
    var e = eingabe || {}, neu = { id: e.id || null, bezeichnung: e.bezeichnung || e.text || '', beschreibung: e.beschreibung || '', komponenteId: e.komponenteId || null };
    return { aehnliche: aehnliche(neu, e.vorgaenge || []), dokumente: dokumente(e.dokumente || [], neu.bezeichnung + ' ' + neu.beschreibung), werkstaetten: werkstaetten(e.adressen || []) };
  }

  MM.Behebung = { LAENDER: LAENDER, CLUBS: CLUBS, STAND: STAND, land: land, aehnliche: aehnliche, dokumente: dokumente, werkstaetten: werkstaetten, werkstattLink: werkstattLink, hilfe: hilfe, staemme: staemme, ARTEN_HILFE: ARTEN_HILFE };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
