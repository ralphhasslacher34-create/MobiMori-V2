/*
 * Leihreise (Bau 3, seit 2.0.79): reine Rechnung und Texte, kein Netz, kein Speicher. Das Speichern und Senden steht in daten.js.
 *
 * Festlegung (Nutzer, 14.11.2026): Eine Freigabe hat zwei Zeiträume.
 *  1. Zeitraum (Planung): Ab dem Beginn der Planung sieht die Person das Fahrzeug, plant ihre Reise, macht Reisechecks und führt ihr Reisetagebuch.
 *     Im Fahrzeug trägt sie nichts ein. Ihre Daten bleiben auf ihrem Gerät und in ihrer Sicherung, auch wenn die Freigabe endet.
 *  2. Zeitraum (Verleih): Ab dem Beginn des Verleihs gelten die festgelegten Rechte (nur ansehen oder mitnutzen).
 * Reisechecks der Person zählen zum Kontingent des Besitzers (Festlegung vom 12.11.), die Person hat keines.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var MAX_NAME = 80, MAX_GEBIET = 200, MAX_ORT = 80, MAX_NOTIZ = 1000, MAX_TEXT = 4000, MAX_PERSONEN = 8, MAX_TAGEBUCH = 500, MAX_CHECKS = 10;

  function text(x) { return x === null || x === undefined ? '' : String(x).trim(); }
  function tag(t) { return /^\d{4}-\d{2}-\d{2}$/.test(text(t)) && !isNaN(Date.parse(text(t))); }

  /* Besatzung als Text, eine Person je Zeile: „Name, Rolle, Nachweis“ (Rolle und Nachweis freiwillig). Rolle: Fahrer oder Mitfahrer. */
  var ROLLE_MIT = /^(mitfahr|beifahr|gast|passagier|crew|mannschaft)/i, ROLLE_FAHRER = /^(fahrer|skipper|kapit|steuer|pilot)/i;
  function besatzungLesen(roh) {
    var liste = [];
    text(roh).split(/\r?\n/).forEach(function (z) {
      var t = z.split(',').map(text);
      if (!t[0]) return;
      var rolle = 'Fahrer', rest = t.slice(1).filter(Boolean);
      if (rest.length && ROLLE_MIT.test(rest[0])) { rolle = 'Mitfahrer'; rest = rest.slice(1); }
      else if (rest.length && ROLLE_FAHRER.test(rest[0])) { rolle = rest[0].charAt(0).toUpperCase() + rest[0].slice(1); rest = rest.slice(1); }
      liste.push({ name: t[0], rolle: rolle, nachweis: rest.join(', ') });
    });
    return liste;
  }
  function besatzungText(liste) {
    return (liste || []).map(function (p) { return [p.name, p.rolle, p.nachweis].filter(Boolean).join(', '); }).join('\n');
  }

  /* Die Reise planen. g: { von, bis } = Verleihzeitraum (Tage). Die Reise muss darin liegen, weil nur dann das Fahrzeug da ist. */
  function planPruefen(roh, g) {
    roh = roh || {}; g = g || {};
    var fehler = {}, w = {};
    var name = text(roh.name);
    if (!name) fehler.name = 'Bitte der Reise einen Namen geben (zum Beispiel „Sommer an der Ostsee“).';
    else if (name.length > MAX_NAME) fehler.name = 'Der Name ist zu lang (höchstens ' + MAX_NAME + ' Zeichen).';
    else w.name = name;
    var von = text(roh.vonDatum), bis = text(roh.bisDatum);
    if (!tag(von)) fehler.vonDatum = 'Bitte den ersten Reisetag eingeben.';
    else if (g.von && von < g.von) fehler.vonDatum = 'Die Reise beginnt vor dem Verleih (ab ' + g.von + '). Vorher darfst du das Fahrzeug nicht nutzen.';
    else w.vonDatum = von;
    if (!tag(bis)) fehler.bisDatum = 'Bitte den letzten Reisetag eingeben.';
    else if (w.vonDatum && bis < w.vonDatum) fehler.bisDatum = 'Der letzte Tag liegt vor dem ersten.';
    else if (g.bis && bis > g.bis) fehler.bisDatum = 'Die Reise endet nach dem Verleih (bis ' + g.bis + ').';
    else w.bisDatum = bis;
    var gebiet = text(roh.gebiet);
    if (gebiet.length > MAX_GEBIET) fehler.gebiet = 'Der Text ist zu lang (höchstens ' + MAX_GEBIET + ' Zeichen).';
    else w.gebiet = gebiet;
    var start = text(roh.start), ziel = text(roh.ziel);
    if (start.length > MAX_ORT) fehler.start = 'Der Ort ist zu lang.'; else w.start = start;
    if (ziel.length > MAX_ORT) fehler.ziel = 'Der Ort ist zu lang.'; else w.ziel = ziel;
    if ((start && !ziel) || (!start && ziel)) fehler.ziel = 'Bitte Start und Ziel beide angeben oder beide leer lassen.';
    var notiz = text(roh.notiz);
    if (notiz.length > MAX_NOTIZ) fehler.notiz = 'Die Notiz ist zu lang (höchstens ' + MAX_NOTIZ + ' Zeichen).'; else w.notiz = notiz;
    var besatzung = besatzungLesen(roh.besatzung);
    if (!besatzung.length) fehler.besatzung = 'Bitte mindestens eine Person eintragen (eine Person je Zeile, zum Beispiel „Anna, Fahrer, Führerschein Klasse B“).';
    else if (besatzung.length > MAX_PERSONEN) fehler.besatzung = 'Es sind höchstens ' + MAX_PERSONEN + ' Personen möglich.';
    else if (besatzung.some(function (p) { return p.name.length > 40 || p.nachweis.length > 80; })) fehler.besatzung = 'Ein Name ist zu lang (höchstens 40 Zeichen) oder ein Nachweis (höchstens 80).';
    else w.besatzung = besatzung;
    return { ok: Object.keys(fehler).length === 0, werte: w, fehler: fehler };
  }

  /* Ein Eintrag im Reisetagebuch. Er bleibt auf dem Gerät der Person. */
  function tagebuchPruefen(roh, heute) {
    roh = roh || {};
    var fehler = {}, w = {};
    var datum = text(roh.datum) || heute;
    if (!tag(datum)) fehler.datum = 'Bitte das Datum als Tag eingeben.'; else w.datum = datum;
    var t = text(roh.text);
    if (!t) fehler.text = 'Bitte schreibe etwas auf.';
    else if (t.length > MAX_TEXT) fehler.text = 'Der Eintrag ist zu lang (höchstens ' + MAX_TEXT + ' Zeichen).';
    else w.text = t;
    return { ok: Object.keys(fehler).length === 0, werte: w, fehler: fehler };
  }

  /* Die Eingabe für MM.Reisecheck.anfrageBauen: Fahrzeug aus der Sicht des Gastes, Reise und Besatzung aus der Planung.
     fz: sicht.fahrzeug.check = { artName, welt, werte }. Nachweise und Komponenten des Fahrzeugs sieht der Gast nicht, sie fehlen in der Anfrage. */
  function checkEingabe(fz, fahrzeugName, plan) {
    if (!fz || !plan) return null;
    var wege = [];
    if (plan.start && plan.ziel) wege = [{ art: 'start', name: plan.start, land: '', breite: null, laenge: null }, { art: 'ziel', name: plan.ziel, land: '', breite: null, laenge: null }];
    return {
      vonDatum: plan.vonDatum, vonZeit: '', bisDatum: plan.bisDatum, bisZeit: '',
      fahrzeug: { name: fahrzeugName || 'Fahrzeug', artName: fz.artName || '', welt: fz.welt || 'land', werte: fz.werte || {}, komponenten: [], nachweise: [] },
      gebiete: [], gebietText: plan.gebiet || '', wegpunkte: wege,
      personen: (plan.besatzung || []).map(function (p) {
        return { name: p.name, rolle: p.rolle, funktionen: [], nachweise: p.nachweis ? [{ art: p.nachweis, gescannt: false, ausgestelltAm: null, gueltigBis: null, klassen: null }] : [] };
      }),
      tiere: []
    };
  }

  /* Die Phase in einfachen Worten. phase: 'planung' oder 'nutzung'. */
  function phaseText(phase, nutzungAb, planAb) {
    if (phase === 'planung') return 'Planung: Der Verleih beginnt am ' + MM.Hilfen.datum(nutzungAb) + '. Bis dahin kannst du das Fahrzeug ansehen, deine Reise planen, Reisechecks machen und Tagebuch führen. Im Fahrzeug eintragen kannst du erst ab dann.';
    return 'Verleih: Seit ' + MM.Hilfen.datum(nutzungAb) + ' gelten deine Rechte' + (planAb ? ' (die Planung lief ab ' + MM.Hilfen.datum(planAb) + ')' : '') + '.';
  }

  MM.Leihreise = {
    MAX_TAGEBUCH: MAX_TAGEBUCH, MAX_CHECKS: MAX_CHECKS, MAX_PERSONEN: MAX_PERSONEN,
    besatzungLesen: besatzungLesen, besatzungText: besatzungText, planPruefen: planPruefen, tagebuchPruefen: tagebuchPruefen, checkEingabe: checkEingabe, phaseText: phaseText,
    TEXT_PLANUNG: 'Hier planst du deine Reise mit dem geliehenen Fahrzeug, machst Reisechecks und führst dein Reisetagebuch. Plan, Checks und Tagebuch bleiben auf deinem Gerät und in deiner Sicherung. Der Besitzer sieht sie nicht und nichts davon geht in sein Fahrzeug. Auch wenn der Verleih endet, bleibt dein Tagebuch bei dir.',
    TEXT_CHECK: 'Der Reisecheck fragt online nach, was für deine Reise nötig ist. Er zählt zum Kontingent des Besitzers des Fahrzeugs, nicht zu deinem. Deshalb mach ihn bewusst und nicht für jede Kleinigkeit. Ein gespeicherter Check zählt nie. Von deinem Namen geht nichts hinaus, nur Decknamen (P1, P2).',
    TEXT_PLANUNG_FREIGABE: 'Planung vor dem Verleih (freiwillig): Ab diesem Tag sieht die Person das Fahrzeug, plant ihre Reise und macht Reisechecks (sie zählen zu deinem Kontingent). Eintragen im Fahrzeug kann sie erst ab dem Beginn des Verleihs.'
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
