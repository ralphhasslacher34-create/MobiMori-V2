'use strict';
/* 2.0.29, Schritt 8c: Kostenzeilen, offene Kostenarten, Zahlungsmittel, Reisekasse und Kassen. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/daten.js');
const MM = globalThis.MM;

/* feste Uhr: 3. November 2026, 12:00 Ortszeit */
const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = n => arten.find(x => x.aktuell.werte.bezeichnung === n).objekt.id;
  return { d, boot, wm, anna, artId };
}

const toern = (c, extra) => Object.assign({ bezeichnung: 'Sommertörn', artId: c.artId('Törn'), fahrzeugId: c.boot, vonDatum: '2026-07-01', bisDatum: '2026-07-10', verantwortlichId: c.anna }, extra || {});
async function mitTorn() { const c = await neu(); const a = await c.d.aktivitaetAnlegen(toern(c)); assert.ok(a.ok, JSON.stringify(a)); c.akt = a.id; return c; }
const eur = (c, w) => c.d.kasseInfo(c.akt, w || 'EUR');

/* ---------- offene Kostenarten ---------- */
test('Kostenarten: Startliste mit Kurtaxe und Reisekasse-Arten, eigene Art anlegen, ausblenden, doppelt nicht', async () => {
  const c = await neu();
  const l = await c.d.kostenartenListe();
  ['kurtaxe', 'muell', 'strom', 'wasser', 'duschmarken', 'rkessen'].forEach(w => assert.ok(l.some(a => a.wert === w), w));
  const r = await c.d.kostenartAnlegen('variabel', 'Hundesteuer Gemeinde');
  assert.ok(r.ok);
  assert.ok(!(await c.d.kostenartAnlegen('variabel', 'hundesteuer gemeinde')).ok, 'doppelt');
  assert.ok((await c.d.kostenartAnlegen('variabel', ' ')).fehler.bezeichnung);
  assert.ok((await c.d.kostenartAnlegen('wunsch', 'x')).fehler.gruppe);
  const k = await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'Hund', kostenart: r.id, betrag: '3' });
  assert.ok(k.ok, JSON.stringify(k));
  assert.ok((await c.d.kostenAnlegen(c.boot, { gruppe: 'fix', bezeichnung: 'x', kostenart: r.id, betrag: '3', rhythmus: 'jaehrlich' })).fehler.kostenart, 'Art gehört zu ihrer Gruppe');
  assert.ok((await c.d.kostenartAusblenden(r.id, true)).ok);
  assert.equal((await c.d.kostenartenListe()).find(a => a.wert === r.id).ausgeblendet, true);
  assert.equal((await c.d.kostenListe(c.boot))[0].artName, 'Hundesteuer Gemeinde', 'bleibt am Posten gültig');
  assert.ok((await c.d.kostenartAusblenden('kurtaxe', true)).ok);
  assert.equal((await c.d.kostenartenListe()).find(a => a.wert === 'kurtaxe').ausgeblendet, true);
});

test('Neue Art mitten im Formular: wird angelegt und genutzt, eine gleichnamige wird wiederverwendet', async () => {
  const c = await neu();
  const a = await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'Hafen', neueKostenart: 'Fährgebühr', betrag: '12' });
  assert.ok(a.ok, JSON.stringify(a));
  const b = await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'Hafen 2', neueKostenart: 'fährgebühr', betrag: '5' });
  const l = (await c.d.kostenartenListe()).filter(x => x.label.toLowerCase() === 'fährgebühr');
  assert.equal(l.length, 1);
  const liste = await c.d.kostenListe(c.boot);
  assert.ok(liste.every(x => x.aktuell.werte.kostenart === l[0].wert));
  const f = await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'x', neueKostenart: 'Gebühr', betrag: 'viel' });
  assert.ok(f.fehler.betrag);
  assert.ok(!(await c.d.kostenartenListe()).some(x => x.label === 'Gebühr'), 'bei einem Fehler wird nichts angelegt');
});

/* ---------- Zahlungsmittel ---------- */
test('Zahlungsmittel: Bar ist fest, eigene Bezeichnungen, nicht doppelt, ausblenden', async () => {
  const c = await neu();
  assert.deepEqual((await c.d.zahlungsmittelListe()).map(z => z.wert), ['bar']);
  const k = await c.d.zahlungsmittelAnlegen('Kreditkarte');
  assert.ok(k.ok);
  assert.ok(!(await c.d.zahlungsmittelAnlegen('kreditkarte')).ok);
  assert.ok(!(await c.d.zahlungsmittelAnlegen('Bar')).ok);
  assert.ok(!(await c.d.zahlungsmittelAusblenden('bar', true)).ok);
  const p = await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'Diesel', betrag: '50', bezahltMit: k.id });
  assert.ok(p.ok);
  assert.equal((await c.d.kostenListe(c.boot))[0].zahlungName, 'Kreditkarte');
  assert.ok((await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'x', betrag: '5', bezahltMit: 'zm-gibtsnicht' })).fehler.bezahltMit);
  const n = await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'x', betrag: '5', neuesZahlungsmittel: 'PayPal' });
  assert.ok(n.ok);
  assert.ok((await c.d.zahlungsmittelListe()).some(z => z.label === 'PayPal'));
});

/* ---------- Reisekasse-Ausgaben ---------- */
test('Reisekasse: gehört immer zu einer Aktivität, zählt nicht zu den Fahrzeugkosten', async () => {
  const c = await mitTorn();
  assert.ok((await c.d.kostenAnlegen(c.boot, { gruppe: 'reisekasse', bezeichnung: 'Eis', betrag: '4' })).fehler.aktivitaetId, 'ohne Aktivität');
  const r = await c.d.reiseAusgabeAnlegen(c.akt, { bezeichnung: 'Souvenir', kostenart: 'rksouvenir', betrag: '12,50', ortText: 'Rovinj, Markt', notiz: 'Magnet' });
  assert.ok(r.ok, JSON.stringify(r));
  const k = await c.d.kostenLaden(r.id);
  assert.equal(k.aktuell.werte.ortText, 'Rovinj, Markt');
  assert.equal(k.artName, 'Souvenirs und Geschenke');
  assert.ok((await c.d.kostenAnlegen(c.boot, { gruppe: 'fix', bezeichnung: 'x', betrag: '5', rhythmus: 'jaehrlich', ortText: 'x' })).fehler.ortText);
  assert.ok((await c.d.kostenAnlegen(c.wm, { gruppe: 'reisekasse', bezeichnung: 'x', betrag: '5', aktivitaetId: c.akt })).fehler.aktivitaetId, 'nur am eigenen Fahrzeug');
  const a = await c.d.kostenAuswertung(c.boot, 2026);
  assert.equal(a.gesamt.summe, 0, 'Fahrzeugkosten ohne Reisekasse');
  assert.equal(a.andere.length + Object.values(a.posten).flat().length, 0);
});

/* ---------- Kassen ---------- */
test('Kasse: Anfangsbestand, Einzahlung, Bar-Ausgaben ziehen ab, Stand wird gerechnet', async () => {
  const c = await mitTorn();
  assert.ok((await c.d.kasseBuchen(c.akt, { art: 'anfang', betrag: '0' })).fehler.betrag);
  assert.ok((await c.d.kasseBuchen(c.akt, { art: 'wunsch', betrag: '5' })).fehler.art);
  assert.ok((await c.d.kasseBuchen(c.akt, { art: 'anfang', betrag: '300', datum: '2026-07-01' })).ok);
  assert.ok((await c.d.kasseBuchen(c.akt, { art: 'anfang', betrag: '10' })).fehler.art, 'nur ein Anfangsbestand');
  await c.d.reiseAusgabeAnlegen(c.akt, { bezeichnung: 'Pizza', kostenart: 'rkessen', betrag: '24,50', bezahltMit: 'bar' });
  await c.d.reiseAusgabeAnlegen(c.akt, { bezeichnung: 'Kartenzahlung', kostenart: 'rkessen', betrag: '30' });
  assert.equal((await eur(c)).rechnung.stand, 275.5);
  assert.ok((await c.d.kasseBuchen(c.akt, { art: 'einzahlung', betrag: '200' })).ok, 'Einzahlung ist keine Ausgabe');
  const ki = await eur(c);
  assert.equal(ki.rechnung.stand, 475.5);
  assert.equal(ki.rechnung.einzahlungen, 200);
  const a = await c.d.reiseAuswertung(c.akt);
  assert.equal(a.gesamt.reisekasse.summe, 54.5, 'nur die Ausgaben zählen, nicht die Einzahlung');
});

test('Kassensturz: Differenz als eigener Eintrag, keine Differenz = nichts', async () => {
  const c = await mitTorn();
  await c.d.kasseBuchen(c.akt, { art: 'anfang', betrag: '100' });
  await c.d.reiseAusgabeAnlegen(c.akt, { bezeichnung: 'Brot', kostenart: 'rkeinkauf', betrag: '10', bezahltMit: 'bar' });
  assert.ok((await c.d.kassensturz(c.akt, { ist: '' })).fehler.ist);
  assert.equal((await c.d.kassensturz(c.akt, { ist: '90' })).geaendert, false);
  const r = await c.d.kassensturz(c.akt, { ist: '85,50' });
  assert.equal(r.differenz, -4.5);
  const ki = await eur(c);
  assert.equal(ki.rechnung.stand, 85.5);
  assert.equal(ki.rechnung.differenz, -4.5);
  assert.ok((await c.d.kassensturz(c.akt, { ist: '5', waehrung: 'NOK' })).fehler.waehrung, 'keine Kasse in NOK');
  assert.ok((await c.d.kasseBuchungAusblenden(r.id, true)).ok);
  assert.equal((await eur(c)).rechnung.stand, 90);
});

test('Fremdwährung: eigene Kasse, Kurs aus den Einzahlungen, gerechnete Beträge, Karte mit Euro nachtragen', async () => {
  const c = await mitTorn();
  assert.ok((await c.d.kasseBuchen(c.akt, { art: 'anfang', waehrung: 'nok', betrag: '1150' })).fehler.euro, 'Euro-Betrag ist Pflicht');
  assert.ok((await c.d.kasseBuchen(c.akt, { art: 'anfang', waehrung: 'KRONE', betrag: '1' })).fehler.waehrung);
  assert.ok((await c.d.kasseBuchen(c.akt, { art: 'anfang', waehrung: 'nok', betrag: '1150', euro: '100' })).ok);
  let ki = await eur(c, 'NOK');
  assert.equal(ki.rechnung.kurs.einheitenProEuro, 11.5);
  assert.equal(MM.Reisekasse.kursText('NOK', ki.rechnung.kurs), '1 € = 11,50 NOK');
  await c.d.kasseBuchen(c.akt, { art: 'einzahlung', waehrung: 'NOK', betrag: '1000', euro: '100' });
  ki = await eur(c, 'NOK');
  assert.equal(Math.round(ki.rechnung.kurs.einheitenProEuro * 100) / 100, 10.75, 'Durchschnitt: 2150 NOK für 200 €');
  /* bar in NOK */
  const bar = await c.d.reiseAusgabeAnlegen(c.akt, { bezeichnung: 'Fisch', kostenart: 'rkessen', waehrung: 'NOK', betragWaehrung: '215', bezahltMit: 'bar' });
  assert.ok(bar.ok, JSON.stringify(bar));
  const w = (await c.d.kostenLaden(bar.id)).aktuell.werte;
  assert.equal(w.betrag, 20);
  assert.equal(w.grundlage, 'gerechnet');
  assert.equal(w.waehrung, 'NOK');
  assert.equal((await eur(c, 'NOK')).rechnung.stand, 2150 - 215);
  assert.equal((await eur(c)).rechnung.ausgaben, 0, 'die Euro-Kasse bleibt unberührt');
  /* Karte in NOK: gerechnet, dann Euro nachtragen */
  const karte = await c.d.reiseAusgabeAnlegen(c.akt, { bezeichnung: 'Café', kostenart: 'rkessen', waehrung: 'NOK', betragWaehrung: '108' });
  assert.equal((await c.d.kostenLaden(karte.id)).aktuell.werte.grundlage, 'gerechnet');
  assert.equal((await eur(c, 'NOK')).rechnung.stand, 1935, 'Karte zieht nicht aus der Kasse ab');
  const nach = await c.d.kostenAendern(karte.id, { bezeichnung: 'Café', kostenart: 'rkessen', waehrung: 'NOK', betragWaehrung: '108', betrag: '9,80', datum: '2026-07-03' });
  assert.ok(nach.ok, JSON.stringify(nach));
  const w2 = (await c.d.kostenLaden(karte.id)).aktuell.werte;
  assert.equal(w2.betrag, 9.8);
  assert.equal(w2.grundlage, 'eingegeben');
  /* ohne Kurs und ohne Euro: Fehler */
  const c2 = await mitTorn();
  assert.ok((await c2.d.reiseAusgabeAnlegen(c2.akt, { bezeichnung: 'x', waehrung: 'SEK', betragWaehrung: '50' })).fehler.betrag);
  assert.ok((await c2.d.reiseAusgabeAnlegen(c2.akt, { bezeichnung: 'x', waehrung: 'SEK', betragWaehrung: '50', bezahltMit: 'bar', betrag: '4' })).fehler.bezahltMit, 'bar braucht die Kasse');
  assert.ok((await c2.d.reiseAusgabeAnlegen(c2.akt, { bezeichnung: 'x', waehrung: 'SEK', betragWaehrung: '50', betrag: '4,30' })).ok, 'mit Euro-Betrag ohne Kasse');
});

test('Ändern einer gerechneten Fremdwährungsausgabe ohne neuen Betrag behält den Euro-Wert', async () => {
  const c = await mitTorn();
  await c.d.kasseBuchen(c.akt, { art: 'anfang', waehrung: 'NOK', betrag: '1000', euro: '100' });
  const p = await c.d.reiseAusgabeAnlegen(c.akt, { bezeichnung: 'A', waehrung: 'NOK', betragWaehrung: '100' });
  await c.d.kasseBuchen(c.akt, { art: 'einzahlung', waehrung: 'NOK', betrag: '1000', euro: '50' });
  const r = await c.d.kostenAendern(p.id, { bezeichnung: 'A neu', waehrung: 'NOK', betragWaehrung: '100' });
  assert.ok(r.ok);
  const w = (await c.d.kostenLaden(p.id)).aktuell.werte;
  assert.equal(w.betrag, 10, 'unverändert, der Kurs hat sich inzwischen geändert');
  assert.equal(w.grundlage, 'gerechnet');
});

/* ---------- Besuch mit Kostenzeilen ---------- */
test('Besuch mit mehreren Zeilen: jede Zeile ein eigener Posten, neue Art, Fehler nennen die Zeile, nichts halb gespeichert', async () => {
  const c = await mitTorn();
  const ok = await c.d.besuchAnlegen(c.akt, { neuerOrtName: 'Hafen Rovinj', neuerOrtArt: 'hafen', datum: '2026-07-04',
    zeilen: [{ kostenart: 'unterwegs', betrag: '42' }, { kostenart: 'strom', betrag: '6,50' }, { neueKostenart: 'Duschen extra', betrag: '3' }, { betrag: '', kostenart: '' }] });
  assert.ok(ok.ok, JSON.stringify(ok));
  assert.equal(ok.kostenIds.length, 3);
  const liste = (await c.d.kostenListe(c.boot)).filter(x => x.aktuell.werte.besuchId === ok.id);
  assert.equal(liste.length, 3);
  assert.ok(liste.every(x => x.aktuell.werte.aktivitaetId === c.akt && x.aktuell.werte.ortId === ok.ortId && x.aktuell.werte.datum === '2026-07-04'));
  assert.deepEqual(liste.map(x => x.artName).sort(), ['Duschen extra', 'Liegeplatz, Hafen, Parkplatz oder Garage unterwegs', 'Stromzuschlag']);
  const a = await c.d.reiseAuswertung(c.akt);
  assert.equal(a.summe, 51.5);
  assert.equal(a.orte[0].summe, 51.5);
  /* Fehler */
  const vorher = (await c.d.kostenartenListe()).length;
  const f = await c.d.besuchAnlegen(c.akt, { neuerOrtName: 'Hafen Pula', datum: '2026-07-05', zeilen: [{ kostenart: 'strom', betrag: '5' }, { neueKostenart: 'Neu X', betrag: 'viel' }] });
  assert.equal(f.ok, false);
  assert.match(f.fehler.zeilen, /^Zeile 2:/);
  assert.equal((await c.d.kostenartenListe()).length, vorher, 'keine neue Art bei Fehler');
  assert.ok(!(await c.d.orteListe()).some(o => o.aktuell.werte.bezeichnung === 'Hafen Pula'), 'kein Ort bei Fehler');
  const nurArt = await c.d.besuchAnlegen(c.akt, { neuerOrtName: 'Hafen Pula', datum: '2026-07-05', zeilen: [{ kostenart: 'strom', betrag: '' }] });
  assert.match(nurArt.fehler.zeilen, /^Zeile 1:/);
});

test('Besuch: ein Betrag wie bisher bleibt möglich, Besuch in Fremdwährung und bar aus der Kasse', async () => {
  const c = await mitTorn();
  const alt = await c.d.besuchAnlegen(c.akt, { neuerOrtName: 'Hafen A', datum: '2026-07-02', betrag: '20' });
  assert.ok(alt.ok && alt.kostenId);
  await c.d.kasseBuchen(c.akt, { art: 'anfang', waehrung: 'NOK', betrag: '2000', euro: '200' });
  const nok = await c.d.besuchAnlegen(c.akt, { neuerOrtName: 'Hafen B', datum: '2026-07-03', waehrung: 'NOK', bezahltMit: 'bar',
    zeilen: [{ kostenart: 'unterwegs', betrag: '300' }, { kostenart: 'strom', betrag: '50' }] });
  assert.ok(nok.ok, JSON.stringify(nok));
  assert.equal((await eur(c, 'NOK')).rechnung.stand, 1650);
  const l = (await c.d.kostenListe(c.boot)).filter(x => x.aktuell.werte.besuchId === nok.id).map(x => x.aktuell.werte.betrag).sort((a, b) => a - b);
  assert.deepEqual(l, [5, 30]);
});

/* ---------- Fotos an Posten ---------- */
test('Foto an einem Posten: Datei hängt am Posten, nicht an Fahrzeug oder Komponente, fremder Posten geht nicht', async () => {
  const c = await mitTorn();
  const p = await c.d.reiseAusgabeAnlegen(c.akt, { bezeichnung: 'Souvenir', kostenart: 'rksouvenir', betrag: '8' });
  const datei = { name: 'foto.jpg', type: 'image/jpeg', size: 10 };
  const d = await c.d.dokumentAnlegen(c.boot, null, { quelle: 'datei', art: 'foto', bezeichnung: '', datei: datei }, null, p.id);
  assert.ok(d.ok, JSON.stringify(d));
  assert.equal((await c.d.dokumenteFuerKosten(p.id)).length, 1);
  assert.equal((await c.d.kostenLaden(p.id)).dokumente.length, 1);
  const x = await c.d.dokumentAnlegen(c.wm, null, { quelle: 'datei', art: 'foto', bezeichnung: '', datei: datei }, null, p.id);
  assert.equal(x.ok, false);
});

/* ---------- Reiseauswertung ---------- */
test('Reiseauswertung: Fahrzeug und Reisekasse getrennt, Fixanteil zum Ausschalten, pro Tag und Person, nach Zahlungsmittel', async () => {
  const c = await mitTorn();
  await c.d.kostenAnlegen(c.boot, { gruppe: 'fix', bezeichnung: 'Liegeplatz', kostenart: 'stellplatz', betrag: '3650', rhythmus: 'jaehrlich', datum: '2026-01-01' });
  await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'Diesel', kostenart: 'treibstoff', betrag: '100', aktivitaetId: c.akt, datum: '2026-07-02', bezahltMit: 'bar' });
  const zm = (await c.d.zahlungsmittelAnlegen('Kreditkarte')).id;
  await c.d.reiseAusgabeAnlegen(c.akt, { bezeichnung: 'Essen', kostenart: 'rkessen', betrag: '60', bezahltMit: zm });
  await c.d.reiseAusgabeAnlegen(c.akt, { bezeichnung: 'Eis', kostenart: 'rkessen', betrag: '10' });
  const a = await c.d.reiseAuswertung(c.akt);
  const g = a.gesamt;
  assert.equal(g.fahrzeug.summe, 100);
  assert.equal(g.reisekasse.summe, 70);
  assert.equal(g.tage, 10);
  assert.equal(g.fixAnteil.summe, 100, '3650 € im Jahr, 10 Tage');
  assert.equal(g.fixAnteil.eingerechnet, true);
  assert.equal(g.gesamt, 270);
  assert.equal(g.ohneFix, 170);
  assert.equal(g.proTag, 27);
  assert.equal(g.personen, 1);
  assert.equal(g.proPerson, 270);
  assert.deepEqual(g.nachZahlungsmittel.map(x => [x.label, x.summe]), [['Bar', 100], ['Kreditkarte', 60], ['ohne Angabe', 10]].sort((x, y) => y[1] - x[1]));
  const ohne = await c.d.reiseAuswertung(c.akt, { fixEin: false });
  assert.equal(ohne.gesamt.gesamt, 170);
  assert.equal(ohne.gesamt.fixAnteil.eingerechnet, false);
  assert.equal(ohne.gesamt.fixAnteil.summe, 100, 'die Zeile bleibt sichtbar');
});

/* ---------- Speicher und Sicherung ---------- */
test('Sicherung enthält Kassen, Buchungen, eigene Arten und Zahlungsmittel', async () => {
  const c = await mitTorn();
  await c.d.kasseBuchen(c.akt, { art: 'anfang', betrag: '100' });
  await c.d.kostenartAnlegen('reisekasse', 'Trinkgeld');
  await c.d.zahlungsmittelAnlegen('Girokarte');
  ['kostenarten', 'zahlungsmittel', 'kassen', 'kassenbuchungen'].forEach(t => assert.ok(MM.Speicher.TABELLEN.includes(t), t));
  const alle = await c.d.speicher.alleTabellen();
  assert.equal(alle.kassen.length, 1);
  assert.equal(alle.kassenbuchungen.length, 1);
  assert.equal(alle.kostenarten.length, 1);
  assert.equal(alle.zahlungsmittel.length, 1);
});
