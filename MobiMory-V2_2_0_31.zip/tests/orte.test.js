'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/orte.js');
const MM = globalThis.MM;

const regel = (extra) => Object.assign({ id: 'r1', bezeichnung: 'Funkzeugnis', fahrzeugArten: [], ausruestung: null, artIds: ['a1'], gilt: 'ja' }, extra || {});

test('Ausrüstung: leer passt immer, sonst muss ein Komponentenname den Text enthalten (Groß/Klein egal)', () => {
  assert.equal(MM.Orte.ausruestungVorhanden('', []), true);
  assert.equal(MM.Orte.ausruestungVorhanden(null, []), true);
  assert.equal(MM.Orte.ausruestungVorhanden('Funkanlage', ['Motor', 'UKW-Funkanlage Icom']), true);
  assert.equal(MM.Orte.ausruestungVorhanden('funkanlage', ['FUNKANLAGE']), true);
  assert.equal(MM.Orte.ausruestungVorhanden('Funkanlage', ['Motor', 'Heizung']), false);
  assert.equal(MM.Orte.ausruestungVorhanden('Funkanlage', []), false);
});

test('Regeln auswerten: ohne Bedingung greift die Regel für jedes Fahrzeug', () => {
  const r = MM.Orte.regelnAuswerten({ regeln: [regel()], fahrzeugArt: 'wohnmobil', komponentenNamen: [] });
  assert.equal(r.greifen.length, 1);
  assert.equal(r.nichtGreifen.length, 0);
});

test('Regeln auswerten: Fahrzeugart als Bedingung, mit Grund wenn sie nicht greift', () => {
  const regeln = [regel({ fahrzeugArten: ['boot'] })];
  assert.equal(MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'boot', komponentenNamen: [] }).greifen.length, 1);
  const r = MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'auto', komponentenNamen: [] });
  assert.equal(r.greifen.length, 0);
  assert.equal(r.nichtGreifen.length, 1);
  assert.match(r.nichtGreifen[0].grund, /Boot/);
});

test('Regeln auswerten: Ausrüstung als Bedingung, abgeschaltete Regeln fehlen ganz', () => {
  const regeln = [regel({ ausruestung: 'Funkanlage' }), regel({ id: 'r2', gilt: 'nein' })];
  const mit = MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'boot', komponentenNamen: ['Funkanlage Icom'] });
  assert.deepEqual(mit.greifen.map(x => x.id), ['r1']);
  assert.equal(mit.nichtGreifen.length, 0);
  const ohne = MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'boot', komponentenNamen: ['Motor'] });
  assert.equal(ohne.greifen.length, 0);
  assert.equal(ohne.nichtGreifen.length, 1);
  assert.match(ohne.nichtGreifen[0].grund, /Funkanlage/);
});

test('Regeln auswerten: Fahrzeugart und Ausrüstung müssen beide passen', () => {
  const regeln = [regel({ fahrzeugArten: ['boot'], ausruestung: 'Funk' })];
  assert.equal(MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'boot', komponentenNamen: ['Funk'] }).greifen.length, 1);
  assert.equal(MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'auto', komponentenNamen: ['Funk'] }).greifen.length, 0);
  assert.equal(MM.Orte.regelnAuswerten({ regeln, fahrzeugArt: 'boot', komponentenNamen: [] }).greifen.length, 0);
});

/* ---------- Pflichtausrüstung: Soll gegen Ist (2.0.12) ---------- */
const westen = (extra) => Object.assign({ pflichtAusruestung: 'Rettungsweste', menge: 1, bezug: 'fahrzeug', eignung: null }, extra || {});

test('Ausrüstung Soll/Ist: nichts eingetragen ist „nicht eingetragen“, mit Soll im Text', () => {
  const r = MM.Orte.ausruestungPruefen({ regel: westen({ menge: 2 }), komponenten: [{ name: 'Motor' }], personen: 3 });
  assert.equal(r.status, 'nicht_eingetragen');
  assert.equal(r.soll, 2);
  assert.equal(r.ist, 0);
  assert.match(r.text, /Soll: 2/);
});

test('Ausrüstung Soll/Ist: eine Komponente ohne Anzahl zählt als 1 (alte Daten bleiben gleich)', () => {
  const r = MM.Orte.ausruestungPruefen({ regel: { pflichtAusruestung: 'Rettungsweste' }, komponenten: [{ name: 'Rettungsweste Set' }], personen: 0 });
  assert.equal(r.status, 'eingetragen');
  assert.equal(r.soll, 1);
  assert.equal(r.ist, 1);
});

test('Ausrüstung Soll/Ist: Anzahl mehrerer Komponenten wird summiert, zu wenig ist „zu_wenig“ mit den Zahlen', () => {
  const komp = [{ name: 'Rettungsweste Erwachsene', anzahl: 3 }, { name: 'Rettungsweste Kinder', anzahl: 2 }, { name: 'Feuerlöscher', anzahl: 9 }];
  const gut = MM.Orte.ausruestungPruefen({ regel: westen({ menge: 5 }), komponenten: komp, personen: 0 });
  assert.equal(gut.status, 'eingetragen');
  assert.equal(gut.ist, 5);
  const knapp = MM.Orte.ausruestungPruefen({ regel: westen({ menge: 6 }), komponenten: komp, personen: 0 });
  assert.equal(knapp.status, 'zu_wenig');
  assert.match(knapp.text, /Eingetragen sind 5, Soll ist 6/);
  assert.match(knapp.text, /Es fehlen 1/);
});

test('Ausrüstung Soll/Ist: je Person wird mit der Besatzung multipliziert, ohne Besatzung „unklar“', () => {
  const komp = [{ name: 'Rettungsweste', anzahl: 4 }];
  const regel = westen({ bezug: 'person', menge: 1 });
  assert.equal(MM.Orte.ausruestungPruefen({ regel, komponenten: komp, personen: 4 }).status, 'eingetragen');
  const zu = MM.Orte.ausruestungPruefen({ regel, komponenten: komp, personen: 5 });
  assert.equal(zu.status, 'zu_wenig');
  assert.equal(zu.soll, 5);
  assert.match(zu.text, /1 je Person, 5 Personen/);
  const zwei = MM.Orte.ausruestungPruefen({ regel: westen({ bezug: 'person', menge: 2 }), komponenten: komp, personen: 2 });
  assert.equal(zwei.soll, 4);
  assert.equal(zwei.status, 'eingetragen');
  const keine = MM.Orte.ausruestungPruefen({ regel, komponenten: komp, personen: 0 });
  assert.equal(keine.status, 'keine_besatzung');
  assert.equal(keine.soll, 0);
});

test('Ausrüstung Soll/Ist: Eignung verlangt den Haken, sonst „eignung_offen“; ohne Eignung spielt der Haken keine Rolle', () => {
  const regel = westen({ menge: 4, eignung: 'Automatik, 150 N' });
  const offen = MM.Orte.ausruestungPruefen({ regel, komponenten: [{ name: 'Rettungsweste', anzahl: 4 }], personen: 0 });
  assert.equal(offen.status, 'eignung_offen');
  assert.match(offen.text, /Automatik, 150 N/);
  assert.match(offen.text, /erst 0 von 4/);
  const teils = MM.Orte.ausruestungPruefen({ regel, komponenten: [{ name: 'Rettungsweste alt', anzahl: 2 }, { name: 'Rettungsweste neu', anzahl: 2, geprueft: 'ja' }], personen: 0 });
  assert.equal(teils.status, 'eignung_offen');
  assert.equal(teils.istGeprueft, 2);
  const ok = MM.Orte.ausruestungPruefen({ regel, komponenten: [{ name: 'Rettungsweste', anzahl: 4, geprueft: 'ja' }], personen: 0 });
  assert.equal(ok.status, 'eingetragen');
  assert.match(ok.text, /als geprüft eingetragen/);
  const ohne = MM.Orte.ausruestungPruefen({ regel: westen({ menge: 4 }), komponenten: [{ name: 'Rettungsweste', anzahl: 4 }], personen: 0 });
  assert.equal(ohne.status, 'eingetragen');
});

test('Ausrüstung Soll/Ist: Zu wenig geht vor der Eignung; ungültige Mengen zählen als 1', () => {
  const r = MM.Orte.ausruestungPruefen({ regel: westen({ menge: 3, eignung: 'X' }), komponenten: [{ name: 'Rettungsweste', anzahl: 1, geprueft: 'ja' }], personen: 0 });
  assert.equal(r.status, 'zu_wenig');
  assert.equal(MM.Orte.menge({ menge: 0 }), 1);
  assert.equal(MM.Orte.menge({ menge: 2.5 }), 1);
  assert.equal(MM.Orte.menge({}), 1);
  assert.equal(MM.Orte.menge({ menge: 6 }), 6);
  assert.equal(MM.Orte.bezugsgroesse({ bezug: 'tier' }), 'fahrzeug');
  assert.equal(MM.Orte.bezugsgroesse({ bezug: 'person' }), 'person');
});
