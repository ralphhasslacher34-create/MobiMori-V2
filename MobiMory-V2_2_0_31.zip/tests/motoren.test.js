'use strict';
/* 2.0.19: Rechnung für die Motorschalter und der Vorschlag für den Kurznamen (ohne Speicher). */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/komponenten.js');
require('../js/motoren.js');
const MM = globalThis.MM;
const M = MM.Motoren;
const K = MM.Komponenten;

test('Kurzname: Vorschlag aus der Bezeichnung, bekannte Wörter haben feste Kürzel', () => {
  assert.equal(K.kurznameVorschlag('Motor Steuerbord'), 'MOSTB');
  assert.equal(K.kurznameVorschlag('Motor Backbord'), 'MOBB');
  assert.equal(K.kurznameVorschlag('Motor 1'), 'MO1');
  assert.equal(K.kurznameVorschlag('Motor 2'), 'MO2');
  assert.equal(K.kurznameVorschlag('Hilfsmotor'), 'HIMO');
});

test('Kurzname: Umlaute, Sonderzeichen, leere Eingabe, immer höchstens 8 Zeichen', () => {
  assert.equal(K.kurznameVorschlag('Außenborder'), 'AB');
  assert.equal(K.kurznameVorschlag('Ärmel-Öl Übung'), 'ARMOLUBU'.slice(0, 8));
  assert.equal(K.kurznameVorschlag(''), '');
  assert.equal(K.kurznameVorschlag(null), '');
  ['Volvo Penta D3-110 Steuerbord', 'Ein sehr langer Name für einen Motor im Heck', 'Dieselmotor Steuerbord', 'Aggregat Wohnraum'].forEach(n => {
    const k = K.kurznameVorschlag(n);
    assert.ok(k.length > 0 && k.length <= K.MAX_KURZNAME, n + ' -> ' + k);
    assert.match(k, /^[A-Z0-9]+$/);
  });
});

test('Kurzname: Anzeige nimmt den gespeicherten Namen, sonst den Vorschlag', () => {
  assert.equal(K.kurzAnzeige({ bezeichnung: 'Motor Steuerbord', kurzname: 'SB' }), 'SB');
  assert.equal(K.kurzAnzeige({ bezeichnung: 'Motor Steuerbord', kurzname: null }), 'MOSTB');
  assert.equal(K.kurzAnzeige({ bezeichnung: 'Motor Steuerbord' }), 'MOSTB');
  assert.equal(K.kurzAnzeige({ bezeichnung: 'Motor 1', kurzname: '  ' }), 'MO1');
});

test('Das Feld Kurzname gehört zu den Feldern der Komponenten und ist auf 8 Zeichen begrenzt', () => {
  const f = K.felder().find(x => x.key === 'kurzname');
  assert.ok(f);
  assert.equal(f.maxLaenge, 8);
  assert.equal(f.typ, 'text');
});

test('Nur Hauptkomponenten der Art Motor haben einen Schalter', () => {
  assert.equal(K.istMotor({ parentId: null, art: 'motor' }), true);
  assert.equal(K.istMotor({ parentId: null, art: 'getriebe' }), false);
  assert.equal(K.istMotor({ parentId: 'x', art: null }), false);
  assert.equal(K.istMotor(null), false);
});

test('Laufzeit: Stunden auf zwei Stellen, nie negativ', () => {
  assert.equal(M.laufStunden('2026-11-04T10:00:00.000Z', '2026-11-04T11:30:00.000Z'), 1.5);
  assert.equal(M.laufStunden('2026-11-04T10:00:00.000Z', '2026-11-04T10:20:00.000Z'), 0.33);
  assert.equal(M.laufStunden('2026-11-04T10:00:00.000Z', '2026-11-04T10:00:00.000Z'), 0);
  assert.equal(M.laufStunden('2026-11-04T11:00:00.000Z', '2026-11-04T10:00:00.000Z'), null);
  assert.equal(M.laufStunden('kaputt', '2026-11-04T10:00:00.000Z'), null);
});

test('Texte für Laufzeiten', () => {
  assert.equal(M.stundenText(1.42), '1 h 25 min');
  assert.equal(M.stundenText(0.2), '12 min');
  assert.equal(M.stundenText(2), '2 h');
  assert.equal(M.stundenText(0), '0 min');
  assert.equal(M.dauerText(90 * 60 * 1000), '1 h 30 min');
});

test('Ortszeit und ISO-Zeitpunkt passen zusammen, falsche Angaben werden erkannt', () => {
  const iso = M.zeitpunktAusOrtszeit('2026-11-04', '14:30');
  assert.ok(iso);
  assert.equal(M.ortsdatum(iso), '2026-11-04');
  assert.equal(M.ortszeit(iso), '14:30');
  assert.equal(M.zeitpunktAusOrtszeit('2026-02-30', '14:30'), null);
  assert.equal(M.zeitpunktAusOrtszeit('2026-11-04', '25:00'), null);
  assert.equal(M.zeitpunktAusOrtszeit('', '14:30'), null);
});

test('Leiste: kein Motor, ein oder zwei Schalter, ab drei ein Sammelschalter', () => {
  const m = (laeuft) => ({ laeuft: !!laeuft });
  assert.equal(M.leiste([]).modus, 'keine');
  assert.equal(M.leiste(undefined).modus, 'keine');
  assert.equal(M.leiste([m()]).modus, 'einzeln');
  assert.equal(M.leiste([m(), m(true)]).modus, 'einzeln');
  const drei = M.leiste([m(), m(true), m(true)]);
  assert.equal(drei.modus, 'sammel');
  assert.equal(drei.laufen, 2);
  assert.equal(drei.text, '2 von 3 laufen');
  assert.equal(M.leiste([m(), m(), m(), m()]).text, 'keiner läuft');
});

test('Schalter: Name und Start, läuft der Motor, Stopp', () => {
  assert.deepEqual(M.schalter({ kurz: 'MOSTB', laeuft: false }), { name: 'MOSTB', aktion: 'Start', zustand: 'aus' });
  assert.deepEqual(M.schalter({ kurz: 'MOSTB', laeuft: true }), { name: 'MOSTB', aktion: 'Stopp', zustand: 'laeuft' });
});

test('Doppelte Kurznamen werden erkannt (ohne auf Groß- und Kleinschreibung zu achten)', () => {
  assert.deepEqual(M.doppelteKurznamen([{ kurz: 'MO' }, { kurz: 'mo' }, { kurz: 'BB' }]), ['MO']);
  assert.deepEqual(M.doppelteKurznamen([{ kurz: 'MO1' }, { kurz: 'MO2' }]), []);
});
