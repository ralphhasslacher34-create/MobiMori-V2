/* Offline-Betrieb: Die App-Dateien werden beim ersten Besuch gemerkt. */
/* Die Versionsnummer steht hier noch einmal, damit der Browser eine neue Version
   sicher erkennt. Ein Test sorgt dafür, dass sie zu js/version.js passt. */
var VERSION = '2.0.31';
var CACHE = 'mobimory-v2-' + VERSION;
var DATEIEN = [
  './', 'index.html', 'manifest.webmanifest',
  'css/styles.css', 'icons/icon.svg',
  'js/version.js', 'js/texte.js', 'js/fahrzeugarten.js', 'js/komponenten.js', 'js/fristen.js', 'js/dokumente.js', 'js/nachweis-vorschlaege.js', 'js/nachweise.js', 'js/aktivitaeten.js', 'js/logbuch.js', 'js/motoren.js', 'js/status.js', 'js/werkstatt.js', 'js/kosten.js', 'js/reisekasse.js', 'js/reiseorte.js', 'js/austausch.js', 'js/personen.js', 'js/orte.js', 'js/sicherung.js', 'js/speicher.js', 'js/hilfen.js',
  'js/daten.js', 'js/ansicht.js', 'js/start.js'
];

self.addEventListener('install', function (e) {
  /* cache: 'reload' holt jede Datei frisch vom Server und nicht aus dem Zwischenspeicher des Browsers */
  e.waitUntil(caches.open(CACHE).then(function (c) {
    return c.addAll(DATEIEN.map(function (u) { return new Request(u, { cache: 'reload' }); }));
  }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (namen) {
    return Promise.all(namen.filter(function (n) { return n !== CACHE; }).map(function (n) { return caches.delete(n); }));
  }).then(function () { return self.clients.claim(); }));
});

self.addEventListener('fetch', function (e) {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(function (treffer) {
    return treffer || fetch(e.request).catch(function () {
      if (e.request.mode === 'navigate') return caches.match('index.html');
    });
  }));
});
