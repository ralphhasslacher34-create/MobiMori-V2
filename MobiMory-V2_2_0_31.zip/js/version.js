/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.31';
  MM.STUFE = 'Aufräumen: neues Logo, Kachelseiten füllen den Platz, Kassenbuch unter Funktionen, alle Arten-Listen in den Stammdaten';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
