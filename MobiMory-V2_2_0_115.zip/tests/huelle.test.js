'use strict';
/* 2.0.110: Android-Hülle (Capacitor) – Erkennung, Dauerdienst für GPS-Punkte, Einbau. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/texte.js');
require('../js/huelle.js');
const MM = globalThis.MM;
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const warte = () => new Promise(r => setImmediate(r));

function falschesPlugin() {
  const p = { gestartet: [], entfernt: [], cb: null, optionen: null, einst: 0 };
  p.addWatcher = (o, cb) => { p.optionen = o; p.cb = cb; return Promise.resolve('w1'); };
  p.removeWatcher = o => { p.entfernt.push(o.id); return Promise.resolve(); };
  p.openSettings = () => { p.einst++; return Promise.resolve(); };
  return p;
}
const capMit = (plug, nativ = true) => ({ isNativePlatform: () => nativ, registerPlugin: n => { assert.equal(n, 'BackgroundGeolocation'); return plug; } });

test('Im Browser ist es keine Hülle und es passiert nichts', async () => {
  assert.equal(MM.Huelle.istHuelle(), false, 'Node hat kein Capacitor');
  const a = MM.Huelle.erzeugen({});
  assert.equal(a.istHuelle(), false); assert.equal(a.verfuegbar(), false);
  await assert.rejects(a.starten(() => {}, () => {}));
  assert.doesNotThrow(() => a.stoppen());
  assert.equal(a.einstellungen(), false);
  const b = MM.Huelle.erzeugen({ Capacitor: { isNativePlatform: () => false, registerPlugin: () => { throw new Error('nicht aufrufen'); } } });
  assert.equal(b.istHuelle(), false); assert.equal(b.verfuegbar(), false);
});

test('In der Hülle startet der Dauerdienst mit Benachrichtigung und liefert Punkte im Format der App', async () => {
  const pl = falschesPlugin();
  const h = MM.Huelle.erzeugen({ Capacitor: capMit(pl) });
  assert.equal(h.istHuelle(), true); assert.equal(h.verfuegbar(), true);
  const punkte = [], fehler = [];
  const id = await h.starten(p => punkte.push(p), f => fehler.push(f));
  assert.equal(id, 'w1'); assert.equal(h.laeuft(), true);
  assert.equal(pl.optionen.backgroundTitle, 'MobiMory zeichnet auf');
  assert.ok(pl.optionen.backgroundMessage.length > 10);
  assert.equal(pl.optionen.requestPermissions, true); assert.equal(pl.optionen.stale, false);
  pl.cb({ latitude: 48.95, longitude: 9.06, accuracy: 6, speed: 3.5, time: 1760000000000, altitude: null, bearing: null });
  pl.cb({ latitude: 48.96, longitude: 9.07, accuracy: 9, speed: null, time: null });
  pl.cb({ latitude: 'x', longitude: 9 });
  assert.deepEqual(punkte[0], { breite: 48.95, laenge: 9.06, genauigkeit: 6, geschwindigkeit: 3.5, zeitMs: 1760000000000 });
  assert.equal(punkte[1].geschwindigkeit, null); assert.equal(punkte[1].zeitMs, null);
  assert.equal(punkte.length, 2, 'ein Punkt ohne Zahlen wird übergangen');
  assert.equal(fehler.length, 0);
  assert.equal(MM.Huelle.erzeugen({}).punkt({ latitude: 1, longitude: 2, speed: -1 }).geschwindigkeit, null, 'negative Geschwindigkeit gilt als unbekannt');
});

test('Zweimal starten startet nur einen Dienst; Stoppen beendet ihn', async () => {
  const pl = falschesPlugin(); let n = 0; const orig = pl.addWatcher; pl.addWatcher = (o, cb) => { n++; return orig(o, cb); };
  const h = MM.Huelle.erzeugen({ Capacitor: capMit(pl) });
  await h.starten(() => {}, () => {}); await h.starten(() => {}, () => {});
  assert.equal(n, 1);
  h.stoppen(); assert.deepEqual(pl.entfernt, ['w1']); assert.equal(h.laeuft(), false);
  const punkte = []; pl.cb && pl.cb({ latitude: 1, longitude: 2 });
  assert.equal(punkte.length, 0);
  await h.starten(() => {}, () => {}); assert.equal(n, 2, 'nach dem Stoppen geht ein neuer Start');
});

test('Wird gestoppt, bevor der Dienst fertig gestartet ist, wird er gleich wieder beendet', async () => {
  const pl = falschesPlugin();
  const h = MM.Huelle.erzeugen({ Capacitor: capMit(pl) });
  const z = h.starten(() => {}, () => {});
  h.stoppen();
  await z; await warte();
  assert.deepEqual(pl.entfernt, ['w1']); assert.equal(h.laeuft(), false);
});

test('Verweigerte Erlaubnis meldet „verweigert“, andere Fehler nicht', async () => {
  const pl = falschesPlugin(); const fehler = [];
  pl.addWatcher = () => Promise.reject(Object.assign(new Error('Permission denied.'), { code: 'NOT_AUTHORIZED' }));
  const h = MM.Huelle.erzeugen({ Capacitor: capMit(pl) });
  await assert.rejects(h.starten(() => {}, f => fehler.push(f)));
  assert.deepEqual(fehler, [{ verweigert: true }]); assert.equal(h.laeuft(), false);
  const pl2 = falschesPlugin(); const f2 = [];
  const h2 = MM.Huelle.erzeugen({ Capacitor: capMit(pl2) });
  await h2.starten(() => {}, f => f2.push(f));
  pl2.cb(undefined, Object.assign(new Error('x'), { code: 'NOT_AUTHORIZED' })); pl2.cb(undefined, new Error('anders'));
  assert.deepEqual(f2, [{ verweigert: true }, { verweigert: false }]);
  assert.equal(h2.einstellungen(), true); assert.equal(pl2.einst, 1);
});

test('Die App nimmt die Punkte im Browser und in der Hülle über dieselbe Stelle', () => {
  const a = lesen('js/ansicht.js');
  assert.match(a, /function gpsPunktAnnehmen\(/);
  assert.match(a, /function gpsFehlerAnnehmen\(/);
  assert.match(a, /MM\.Huelle\.istHuelle\(\) && MM\.Huelle\.verfuegbar\(\)/);
  assert.match(a, /MM\.Huelle\.starten\(/);
  assert.match(a, /gpsPunktAnnehmen\(p\.coords\.latitude, p\.coords\.longitude, p\.coords\.accuracy, p\.coords\.speed\)/, 'Browser bleibt wie bisher');
  assert.match(a, /if \(gpsWatchId === 'huelle'\) \{ MM\.Huelle\.stoppen\(\)/, 'Dauerdienst endet mit dem Cockpit');
  assert.match(a, /navigator\.geolocation/, 'Browser-Weg ist noch da');
});

test('Hinweistexte: in der Hülle „auch im Hintergrund“, im Browser unverändert', () => {
  const T = MM.Texte.AUFZEICHNUNG;
  assert.match(T.huelle.cockpit, /Hintergrund/); assert.match(T.huelle.kurz, /Hintergrund/);
  assert.match(T.cockpit, /nur bei offener App/);
  const a = lesen('js/ansicht.js');
  assert.match(a, /T\.huelle\.cockpit/); assert.match(a, /AUFZEICHNUNG\.huelle\.kurz/);
});

test('Einbau: Modul in index.html und Service Worker, Version, Neuerungen, Changelog', () => {
  assert.match(lesen('index.html'), /js\/huelle\.js/); assert.match(lesen('sw.js'), /js\/huelle\.js/);
  assert.ok(lesen('index.html').indexOf('js/huelle.js') < lesen('index.html').indexOf('js/ansicht.js'));
  assert.equal(MM.Texte.NEUERUNGEN[5].version, '2.0.110');
  assert.match(MM.Texte.NEUERUNGEN[5].punkte.join(' '), /Android-App/);
  assert.match(lesen('CHANGELOG.md'), /## 2\.0\.110\n- \*\*Android-Hülle/);
});

test('Hülle: Konfiguration, Manifest, GitHub-Bau und Anleitung stimmen', () => {
  const c = JSON.parse(lesen('capacitor.config.json'));
  assert.equal(c.appId, 'com.mobimory.app'); assert.equal(c.appName, 'MobiMory'); assert.equal(c.webDir, 'www');
  const p = JSON.parse(lesen('package.json'));
  assert.equal(p.devDependencies['@capacitor-community/background-geolocation'], '1.3.1');
  ['@capacitor/core', '@capacitor/android', '@capacitor/cli'].forEach(k => assert.ok(p.devDependencies[k], k));
  assert.ok(fs.existsSync(path.join(__dirname, '..', 'package-lock.json')), 'für npm ci');
  const m = lesen('android/app/src/main/AndroidManifest.xml');
  assert.match(m, /android\.permission\.INTERNET/); assert.match(m, /android\.permission\.CAMERA/);
  const w = lesen('.github/workflows/android-apk.yml');
  assert.match(w, /assembleDebug/); assert.match(w, /upload-artifact/); assert.match(w, /cap sync android/); assert.match(w, /MobiMory-APK/);
  assert.match(w, /cp -r index\.html manifest\.webmanifest sw\.js css js icons lib www\//);
  assert.match(lesen('.gitignore'), /^www\/$/m);
  assert.ok(fs.existsSync(path.join(__dirname, '..', 'docs', 'ANDROID.md')));
  assert.ok(fs.existsSync(path.join(__dirname, '..', 'android', 'gradlew')));
});
