# Schritte beim Aufbau von V2

Grundlage ist das Dokument „MobiMory V2 – Festlegungen und Datenstruktur“.
Jeder Schritt baut auf dem letzten auf und endet mit einem sichtbaren Ergebnis.

| Schritt | Inhalt | Stand |
|---|---|---|
| 1 | Fahrzeug: Fahrzeugliste (Schale 1) und äußere Hülle (Schale 2), Handeingabe, Verlauf, offline | fertig (2.0.1) |
| 1a | Ansicht der äußeren Schalen: Startseite, Hauptmenü, Stammdaten, Neu im Programm, Einstellungen | fertig (2.0.2) |
| 2 | Hauptkomponenten (Schale 3), beliebig tief verschachtelt, mit Hersteller, Modell, Seriennummer, Baujahr, Einbau, technischen Merkmalen | fertig (2.0.4) |
| 3 | Fristen an Fahrzeug und Komponenten (Kalender und Zähler), Zählerstände von Hand, Erledigungen | fertig (2.0.5) |
| 3a | Dokumente an Fahrzeug und Komponente (Datei oder Link), Gesamtliste | fertig (2.0.6) |
| 3b | Personen, Tiere und Nachweise (offene Nachweisarten mit Vorschlägen DE/EU) | fertig (2.0.7) |
| 4 | Aktivität mit gemeinsamem Kern (Besatzung aus den Personen, Prüfung bei der Planung) | fertig (2.0.8) |
| 4b | Sicherungsdatei: sichern, verschlüsseln, wiederherstellen, Erinnerung | fertig (2.0.9) |
| 4a | Orte und Gebiete mit Regeln (Stufe 1: eigene Regeln, einfache Gebietsliste) | fertig (2.0.10, erweitert in 2.0.11 und 2.0.12) |
| 4c | Testrunde mit echten Daten (Wohnmobil und Boot) | gemacht, einziger offener Punkt war die Ausrüstung |
| 4d | Ausrüstung nachbessern: Anzahl, Bezugsgröße (Fahrzeug oder Person), Soll gegen Ist, Eignung als Hinweis mit Haken | fertig (2.0.12), noch nicht getestet |
| 5 | Logbuch-Kern: Tagesabschnitte, Ereignisse, Nachtragen | fertig (2.0.13), noch nicht getestet |
| 5a | Cockpit und klassisches Logbuch: Bedienung, Wechsel mit Prüfung, Tagesabschluss | fertig (2.0.14), noch nicht getestet |
| 5b | Ereignisse je Fahrzeugart (Baum, vererbt, änderbar) und Logbuch ohne Planung starten | fertig (2.0.15), noch nicht getestet |
| 5c | Fahrzeugarten selbst verwalten: Untergruppen anlegen, umbenennen, ausblenden, löschen (nur Unbenutztes), bereinigen | fertig (2.0.16), noch nicht getestet |
| 5d | Art der Aktivität richtet sich nach dem Fahrzeug (Zuordnung wie bei den Ereignissen); Logbuch jetzt starten mit Wahl der Art | fertig (2.0.17), noch nicht getestet |
| 5e | Cockpit im Vollbild ohne Scrollen, bis zu 8 frei belegbare Schnellknöpfe je Fahrzeugart plus „Sonstige Ereignisse“ (3 mal 3) | fertig (2.0.18), noch nicht getestet |
| 6 | Zähler automatisch, erster Teil: ein Schalter und ein Zähler je Motor (Start/Stopp, Betriebsstunden), Kurzname, Leiste im Cockpit, Liste ab drei Motoren, Stoppzeit korrigieren | fertig (2.0.19), noch nicht getestet |
| 6b | Motorhinweis je Fahrzeugart („Kein Motor läuft“), Betriebsstunden und Kilometer zusammen in der Anzeige, Knopfzahl je Gerät (bis 15, Spalten nach Bildschirmbreite) | fertig (2.0.20), noch nicht getestet |
| 6c | Position bei jedem Eintrag im Logbuch (GPS oder von Hand, Herkunft, Ortsname, Namen lernen, Gerät) | fertig (2.0.21), noch nicht getestet |
| 6a | Zähler automatisch, zweiter Teil: Motorstopp-Frage nach Ankunft, Anlegen oder Anker werfen (Vorschlag der Stoppzeit, Wartezeit (Timer) vom Nutzer eingestellt) | fertig (2.0.22), noch nicht getestet |
| 6d | Status des Fahrzeugs und Regeln der Ereignisse: Land 2 Status, Wasser 3 Status, Knöpfe grau mit Grund, Regel an der Art, Nachtragen nie gesperrt | fertig (2.0.23), noch nicht getestet |
| 7a | Werkstatt, Vorgang: Störung melden, Arbeit daraus machen (selbst oder Werkstatt), offen oder erledigt, am Fahrzeug oder an der Komponente; Warnung bei versprochenen Aktivitäten (trotzdem nutzen oder absagen) | fertig (2.0.24), noch nicht getestet |
| 7b | Werkstatt, Adressen: eine zentrale Liste für Werkstätten, Lieferanten und Händler, der Vorgang verweist darauf | fertig (2.0.25), noch nicht getestet |
| 7c | Werkstatt, Dokumente und Bilder: Reparaturbuch, Anleitung und Ersatzteilliste an der Komponente, Bilder und Belege am Vorgang (über die vorhandene Datei-Liste) | fertig (2.0.26), noch nicht getestet |
| 7d | Werkstatt, Störung im Logbuch: Das Ereignis „Störung“ legt den Werkstatt-Vorgang an (eine Störung für beide), mit Einschränkung und Warnung, auch unterwegs im Cockpit | fertig (2.0.26), noch nicht getestet |
| 8 | Kosten: eine Kosten-Liste mit Fixkosten, variablen Kosten und Instandhaltung (Beträge am Vorgang, an der Aktivität, an der Komponente), Wertverlust, Auswertung pro Fahrzeug und Jahr, Vergleich mit Mieten oder Chartern | fertig (2.0.27), noch nicht getestet |
| 8a | Reiseorte: Orte mit Art, Position und Ausstattung, Frage nach der Ankunft (immer freiwillig), Besuche mit Historie, Kosten pro Ort und pro Reise, Start, Ziel und Zwischenziele in der Aktivität mit Plan gegen Ist | fertig (2.0.28), noch nicht getestet |
| 8c | Kostenzeilen und Reisekasse: mehrere Kostenzeilen je Besuch, offene Kostenarten (eigene Arten auch im Formular), Zahlungsmittel („Bezahlt mit“), Gruppe Reisekasse an der Aktivität mit Foto, Notiz und Ort, Bargeldkasse je Währung (Anfangsbestand, Einzahlung, Kassensturz, Kurs aus den Einzahlungen), Reiseauswertung (Fahrzeug und Reisekasse getrennt, Fixkosten-Anteil ein- und ausschaltbar, pro Tag und Person, nach Zahlungsmittel) | fertig (2.0.29), noch nicht getestet |
| 8b | Import und Export: Fahrzeuge aus Excel oder CSV übernehmen (Spalten zuordnen, Vorschau, nichts wird überschrieben), Fahrzeuge, Kosten und Orte als Excel oder CSV ausgeben. Routen in Routenformaten gehören zu Schritt 9 | fertig (2.0.30), noch nicht getestet |
| 8d | Aufräumen: neues Logo, Kachelseiten füllen den Platz, Kassenbuch unter Funktionen, alle Arten-Listen (Aktivitäten, Ereignisse, Kostenarten und Zahlungsmittel) zentral in den Stammdaten | fertig (2.0.31), noch nicht am Tablet getestet |
| 8e | Kacheln lesbar: Text nie abgeschnitten, Titel bleiben ganze Wörter, Beschreibungen brechen an Silben um, Schrift und Spaltenzahl passen sich an (2.0.32) | erledigt |
| 9 | Route, GPX, Wetter und Tide: Routendatei einlesen (GPX, KML, GeoJSON), Fahrzeit und Ankunftszeit, Wetter am Punkt zur Ankunftszeit, Wellen und Wasserstand bei Wasserfahrzeugen, Abfahrt früher oder später, Kilometer über GPS, „Traffic“ wird „Travel“ | fertig (2.0.33), noch nicht getestet |
| 9b | Karte im Vollbild (Route, Start, Ziel, Wetterpunkte, gefahrener Weg, Position, Verspätung), „Wetter jetzt“ im Cockpit als Logbuch-Eintrag, Wetter im Rhythmus, Offline-Karte entlang der Route | fertig (2.0.34), noch nicht am Tablet getestet |
| 9c | Wetter und Karte als normale Ereignisse (Knopf im Cockpit oder unter „Sonstige Ereignisse“) statt fester Zeile; Standardbelegung der Schnellknöpfe um Wetter und Karte erweitert | fertig (2.0.35), noch nicht am Tablet getestet |
| 9d | Abstand der Wetterpunkte einstellbar (nach km, sm oder Fahrzeit, Voreinstellung Wasser 10 sm, sonst 1 Stunde) | fertig (2.0.36), noch nicht am Tablet getestet |
| 10 | Besitzerwechsel: Fahrzeugart nachträglich ändern (mit Warnung, nichts geht verloren), Fahrzeug abgeben (verkauft, verschenkt, verschrottet), Technik-Akte als PDF (letzte HU bis Abgabe, höchstens 24 Monate), Übergabedatei mit der ganzen technischen Historie, Fahrzeug übernehmen | fertig (2.0.37), noch nicht am Tablet getestet |
| 11 | Reisecheck: Online-Recherche über den Dienst aus V1 mit anonymisierter Anfrage, Zustimmung mit Protokoll, Ergebnis mit Quellen je Aktivität gespeichert; Highlights, Länder-Ampel und Kontingent folgen später | fertig (2.0.38), noch nicht am Tablet getestet |
| 11a | Orte und Gebiete: Ort eingeben, App prüft ihn (Auswahlliste bei mehrfachem Namen) und erzeugt das Gebiet Land > Region > Kreis; Gebietsbibliothek (einmal gespeichert, wiederverwendet); Gebiet je Art (Straße: Land, Region, Kreis; Wasser: Land und Revier); Regeln der Gebiete der Orte in der Prüfung und im Reisecheck | fertig (2.0.39), noch nicht am Tablet getestet |
| 11b | Grundcheck: Was braucht das Fahrzeug an seinem Heimatort (Papiere und Grundausrüstung, mit Quelle und Stand)? Vergleich mit den Eintragungen (vorhanden, zu wenig, fehlt, unklar), Link zum Eintragen (Komponente mit Name und Menge vorbelegt), Feld „Personen / Plätze“, wiederholbar, keine Zählung im Reisecheck-Kontingent | fertig (2.0.40), noch nicht am Tablet getestet |
| 11c | „Habe ich unter anderem Namen“: Der Nutzer setzt bei einem Punkt des Grundchecks (Ausrüstung oder Papier) seine eigene Bezeichnung gleich (zum Beispiel Rettungsweste = Persönliche Schwimmhilfe), je Land und Fahrzeugart gemerkt, gilt auch bei der Pflichtausrüstung im Reisecheck; nichts wird geraten | fertig (2.0.41), noch nicht am Tablet getestet |
| 11d | Revier als Auswahlliste im Formular des Ortes (vorhandene Reviere des Landes, „Neues Revier eintragen“, „kein Revier“); der Ort als unterste Ebene der Kette (Land, Revier, Ort; Land, Region, Kreis, Ort), aber nur mit eigenen Regeln des Ortes, ohne eigene Regel gelten die Regeln der Ebenen darüber; gilt bei der Prüfung und im Reisecheck | fertig (2.0.42), noch nicht am Tablet getestet |
| 11e | Etappen (Mehrtagesreisen): Tag = Etappe mit Start- und Zielort aus der Ortsliste, Wetter je Tag (aus den zwei Orten, von Hand änderbar), Kosten je Tag, Reisecheck je Tag, Zusammenfassung der Reise oben an der Aktivität | fertig (2.0.43), noch nicht am Tablet getestet |
| 11f | Cockpit und Mehrtagesaktivität aufräumen: Wetter-Meldung verschwindet von selbst; Wechselfeld für die Geschwindigkeit (Aktuell, Ø fahrend, Ø Tag), gespeichert beim Tagesabschluss und im Rhythmus des Wetters; Tag der Reise im Kalender wählen (Tag 1 bis Tag X) | fertig (2.0.44), noch nicht am Tablet getestet |
| 11g | Komponenten löschen (unbenutzt), ausblenden (benutzt) und verschieben; Merkmale mit Liste, Einheit und Bezugsgröße; zusammengehörige Fahrzeuge („Gehört zu“) mit ihren Fristen in der Planung | fertig (2.0.45), noch nicht am Tablet getestet |
| 11h | Kostenblock: abgegebene Fahrzeuge in der Kosten-Liste gekennzeichnet; gleiche Kennung nur nach Rückfrage (Anlegen, Übergabe); Kostenposten löschen und gut auffindbar korrigieren; Punkt „fehlende Fixkosten“ erst nach Klärung am Gerät | fertig (2.0.46, ohne den Punkt „fehlende Fixkosten“), noch nicht am Tablet getestet |
| 12 | Ereignis-Knöpfe als Baukasten: jede Art kann beim Antippen eine Aktion auslösen (Textfeld, Foto, Navigations-App, Liste erweiterbar); Foto mit Kamera oder Datei | fertig (2.0.47), noch nicht am Gerät getestet |
| 12a | Verbraucher und Quelle: Art „Tank“, Stoff (offene Liste), Verbraucher mit Quelle (mehrere Tanks möglich), Übersicht der Kette am Fahrzeug, Tank-Vorschlag bei „Tankinhalt“; Strom später | fertig (2.0.48), noch nicht am Gerät getestet |
| 12b | Korrektur zu 12a: weiteren Tank anlegen, ohne das Formular zu verlieren (Entwurf im Speicher, Rückkehr mit `weiter=`); Foto mit zwei klaren Knöpfen („Foto jetzt aufnehmen“, „Vorhandenes Bild wählen“) | fertig (2.0.49), noch nicht am Gerät getestet |
| 12c | Baukasten-Gerüst nach dem Gesamtbild: Muster jedes Knopfes Festhalten (Ort und Zeit) → Fragen (Text, Foto, Betrag, Ziel) → Wirkungen (Kostenposten anlegen, Navigations-App öffnen); die Aktionen aus 12 gehen darin auf; Listen erweiterbar. Danach: Tanken komplett 2.0.51, Störung 2.0.52, Aufenthalte 2.0.53 | fertig (2.0.50), noch nicht am Gerät getestet |
| 13 | Konten, Server und Stufen, danach Verleih | offen |
| 14 | Smart Capture (Fahrzeugschein und Nachweise einlesen) | offen |
| 15 | Wasserski, später Segeln (Sonderaktivitäten, am Ende; früher Nummer 10) | offen |

Die Reihenfolge ab Schritt 5 hat der Nutzer am 03.11.2026 festgelegt.

## Noch nicht drin, weil sie auf anderen Teilen aufbauen
- Weitere feste Standorte der äußeren Hülle: Der Heimatstandort ist seit 2.0.10 da, weitere folgen nach Bedarf.
- Konto und Anmeldung, Server, Sicherung: kommen später. Schritt 1 arbeitet nur lokal (Basis-Version).
- Kostenentwicklung über mehrere Jahre, Diagramme und Kostenvorschau für eine geplante Aktivität: noch nicht festgelegt.
- Fristen, Kosten und Nachweise an den Komponenten: kommen mit den jeweiligen Schritten.
- Dokumente auf dem Server und auf mehreren Geräten (Original auf dem Server, Kopie „offline verfügbar“ auf dem Gerät): kommt mit Konten und Server.
- Smart Capture (Fahrzeugschein einlesen): eigener Schritt, nutzt die Ablage für Dateien.
- Vorschläge für Nachweisarten aus weiteren Ländern: kommen nach Bedarf, Land für Land, jeweils mit Quelle und Prüfdatum.
- Prüfung „erlaubt, nicht erlaubt, unklar“ für Skipper und Fahrer: kommt mit der Aktivität.
- Tiere als Bezugsgröße der Pflichtausrüstung: nicht vorgesehen, es ist keine Pflicht bekannt.
- Prüfung gegen Anforderungen eines Gebiets: seit 2.0.10 mit eigenen Regeln. Ein Gebiet nur als Text wird weiter nicht geprüft.
- Prüfung zum Tagesbeginn: seit 2.0.13 je Tag festgehalten. Prüfung bei jedem Wechsel des Verantwortlichen unterwegs: seit 2.0.14 beim Wechsel festgehalten.
- Automatische Sicherung und Umzug zwischen mehreren Geräten ohne Datei: kommt mit Konten und Server.
- Regeln mit Quelle und Prüfdatum (Stufe 2) und weitere Länder sowie Motorleistung und Gewicht als Bedingungen (Stufe 3): erst nach der Testrunde.
