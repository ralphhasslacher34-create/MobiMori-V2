/* Gerüst des Ereignis-Baukastens (seit 2.0.50). Nur Regeln, kein Speicher und kein Netz.
 * Gesamtbild Ereignis-Baukasten: Jeder Knopf folgt demselben Muster.
 *   1. Festhalten  Ort und Zeit, immer (macht der Knopf selbst, hier nichts einzustellen)
 *   2. Fragen      nur, was die App nicht wissen kann (Text, Foto, Betrag, Ziel)
 *   3. Wirkungen   was die App danach selbst tut (Kostenposten anlegen, Navigations-App öffnen)
 * Welche Fragen und Wirkungen es gibt, steht nur in den Listen FRAGEN und WIRKUNGEN unten. Eine neue kommt als eine weitere Zeile
 * dazu (oder mit MM.Baukasten.frageRegistrieren / wirkungRegistrieren), der Aufbau ändert sich nicht. Tanken, Störung und Aufenthalte
 * (spätere Stufen) sind dann nur Zusammenstellungen aus diesen Bausteinen.
 *
 * Die Zusammenstellung einer Ereignisart liegt in den Feldern „fragen“ und „wirkungen“ (Listen von Kennungen).
 * Die Aktionen aus 2.0.47 (js/aktionen.js: Text, Foto, Navigation) gehen darin auf: Eine Art, die nur das alte Feld „aktion“ hat,
 * bekommt ihre Zusammenstellung daraus (Text = Frage Text, Foto = Frage Foto, Navigation = Frage Ziel + Wirkung Navigation).
 * Nichts wird umgeschrieben, solange der Nutzer die Art nicht ändert.
 *
 * Eintrag Frage:   { id, name, hilfe }
 * Eintrag Wirkung: { id, name, hilfe, braucht: [Kennungen der Fragen, ohne die sie nichts tun kann] } */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var FRAGEN = [
    { id: 'text', name: 'Text', hilfe: 'Ein Textfeld. Der Text kommt zum Eintrag.' },
    { id: 'foto', name: 'Foto', hilfe: 'Foto aufnehmen oder ein vorhandenes Bild wählen. Das Foto kommt zum Eintrag.' },
    { id: 'betrag', name: 'Betrag', hilfe: 'Ein Betrag in Euro. Er kommt zum Eintrag.' },
    { id: 'ziel', name: 'Ziel', hilfe: 'Ein Ziel (Ort, Adresse oder Koordinaten), mit dem Ziel des Tages vorbelegt, wenn es eines gibt.' }
  ];

  var WIRKUNGEN = [
    { id: 'kosten', name: 'Kostenposten anlegen', braucht: ['betrag'],
      hilfe: 'Aus dem Betrag legt die App einen Posten bei den variablen Kosten an, am Fahrzeug und an der Reise, mit dem Namen der Art und dem Datum des Eintrags.' },
    { id: 'navi', name: 'Navigations-App öffnen', braucht: ['ziel'],
      hilfe: 'Die App übergibt nur das Ziel. Das Gerät entscheidet, welche Navigations-App öffnet.' }
  ];

  function kopie(o) { return Object.assign({}, o, o.braucht ? { braucht: o.braucht.slice() } : {}); }
  function liste(reg) { return reg.map(kopie); }
  function finde(reg, id) {
    var s = String(id === undefined || id === null ? '' : id);
    var x = reg.filter(function (a) { return a.id === s; })[0];
    return x ? kopie(x) : null;
  }
  function registrieren(reg, a) {
    if (!a || !a.id || !a.name || finde(reg, a.id)) return false;
    var neu = { id: String(a.id), name: String(a.name), hilfe: a.hilfe || '' };
    if (a.braucht) neu.braucht = a.braucht.map(String);
    reg.push(neu);
    return true;
  }

  function fragen() { return liste(FRAGEN); }
  function wirkungen() { return liste(WIRKUNGEN); }
  function frage(id) { return finde(FRAGEN, id); }
  function wirkung(id) { return finde(WIRKUNGEN, id); }
  function frageRegistrieren(a) { return registrieren(FRAGEN, a); }
  function wirkungRegistrieren(a) { return registrieren(WIRKUNGEN, a); }

  /* Nur bekannte Kennungen, ohne Doppelte, in der Reihenfolge der Liste (nicht der Eingabe). */
  function normalListe(reg, roh) {
    var gewaehlt = Array.isArray(roh) ? roh.map(String) : [];
    return reg.filter(function (a) { return gewaehlt.indexOf(a.id) >= 0; }).map(function (a) { return a.id; });
  }
  function fragenNormal(roh) { return normalListe(FRAGEN, roh); }
  function wirkungenNormal(roh) { return normalListe(WIRKUNGEN, roh); }

  /* Die Zusammenstellung einer Ereignisart: { fragen: [...], wirkungen: [...] }.
   * Hat die Art eines der Felder „fragen“ oder „wirkungen“, gilt das. Sonst kommt sie aus dem alten Feld „aktion“ (2.0.47). */
  function zusammenstellung(werte) {
    var w = werte || {};
    if (w.fragen !== undefined || w.wirkungen !== undefined) return { fragen: fragenNormal(w.fragen), wirkungen: wirkungenNormal(w.wirkungen) };
    var a = MM.Aktionen ? MM.Aktionen.art(w.aktion) : null;
    return a ? { fragen: fragenNormal(a.fragen), wirkungen: wirkungenNormal(a.wirkungen) } : { fragen: [], wirkungen: [] };
  }
  function leer(z) { return !z || (!z.fragen.length && !z.wirkungen.length); }
  /* Löst der Knopf nach Wo und Wann noch etwas aus? Nur dann kommt die Seite nach dem Antippen. */
  function hatAblauf(werte) { return !leer(zusammenstellung(werte)); }
  function gleich(a, b) { return JSON.stringify(a.fragen) === JSON.stringify(b.fragen) && JSON.stringify(a.wirkungen) === JSON.stringify(b.wirkungen); }

  /* Eine Wirkung braucht ihre Fragen. Gibt für jede fehlende Frage eine Meldung zurück (leere Liste = in Ordnung). */
  function fehlendeFragen(z) {
    var meldungen = [];
    if (!z) return meldungen;
    z.wirkungen.forEach(function (wid) {
      var w = wirkung(wid);
      (w && w.braucht || []).forEach(function (fid) {
        if (z.fragen.indexOf(fid) < 0) {
          var f = frage(fid);
          meldungen.push('„' + w.name + '“ braucht die Frage „' + (f ? f.name : fid) + '“. Bitte ankreuzen.');
        }
      });
    });
    return meldungen;
  }

  /* Das Muster in Worten, für Listen und Seiten. Ohne Fragen und Wirkungen: ''. */
  function ablaufText(z) {
    if (leer(z)) return '';
    var teile = ['Festhalten: Ort und Zeit'];
    if (z.fragen.length) teile.push('Fragen: ' + z.fragen.map(function (i) { var f = frage(i); return f ? f.name : i; }).join(', '));
    if (z.wirkungen.length) teile.push('Wirkungen: ' + z.wirkungen.map(function (i) { var w = wirkung(i); return w ? w.name : i; }).join(', '));
    return teile.join(' → ');
  }

  MM.Baukasten = {
    fragen: fragen, wirkungen: wirkungen, frage: frage, wirkung: wirkung,
    frageRegistrieren: frageRegistrieren, wirkungRegistrieren: wirkungRegistrieren,
    fragenNormal: fragenNormal, wirkungenNormal: wirkungenNormal,
    zusammenstellung: zusammenstellung, hatAblauf: hatAblauf, leer: leer, gleich: gleich,
    fehlendeFragen: fehlendeFragen, ablaufText: ablaufText
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
