/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.50';
  MM.STUFE = 'Baukasten-Gerüst: Festhalten, Fragen, Wirkungen';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
