'use strict';
/* 2.0.47: Ereignis-Knöpfe als Baukasten: Aktion an der Ereignisart, Text und Foto nach dem Antippen, Kamera, Navigation (mit Speicher). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/aktionen.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/reiseorte.js');
require('../js/karte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const A = MM.Aktionen;

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 8, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.uhr = uhr;
  return d;
}
const foto = (inhalt, name) => { const b = new Blob([inhalt], { type: 'image/jpeg' }); Object.defineProperty(b, 'name', { value: name || 'foto.jpg' }); return b; };

async function mitAktivitaet() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: boot, vonDatum: '2026-11-08', vonZeit: '09:00', bisDatum: '2026-11-10', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok);
  return { d, id: r.id, boot };
}
const eventsVon = async (c) => (await c.d.logbuchLaden(c.id)).abschnitte.flatMap(t => t.ereignisse);

test('Liste der Aktionen: Textfeld, Foto, Navigation; unbekannt ist „keine“', () => {
  assert.deepEqual(A.liste().map(x => x.id), ['text', 'foto', 'navi']);
  assert.equal(A.normal('foto'), 'foto');
  assert.equal(A.normal('gibtsnicht'), '');
  assert.equal(A.normal(undefined), '');
  assert.equal(A.normal(''), '');
  assert.equal(A.name('navi'), 'Navigations-App des Geräts öffnen');
  assert.equal(A.art('x'), null);
});

test('Baukasten ist erweiterbar: eine neue Aktion kommt dazu, eine vorhandene Kennung wird nicht überschrieben', () => {
  assert.equal(A.registrieren({ id: 'testaktion', name: 'Testaktion' }), true);
  assert.equal(A.normal('testaktion'), 'testaktion');
  assert.equal(A.registrieren({ id: 'text', name: 'Anderes' }), false);
  assert.equal(A.name('text'), 'Textfeld öffnen');
  assert.equal(A.registrieren({ id: '', name: 'x' }), false);
});

test('Navigation: nur das Ziel wird übergeben, je nach Gerät anders', () => {
  assert.equal(A.naviLink('', 'Android'), null);
  assert.equal(A.naviLink('   ', 'Android'), null);
  assert.equal(A.naviLink('Hafen Horrheim', 'Mozilla/5.0 (Linux; Android 14)'), 'geo:0,0?q=Hafen%20Horrheim');
  assert.equal(A.naviLink('Hafen Horrheim', 'Mozilla/5.0 (iPhone; CPU iPhone OS 17)'), 'https://maps.apple.com/?daddr=Hafen%20Horrheim');
  assert.equal(A.naviLink('48.9,9.0', 'Mozilla/5.0 (Windows NT 10.0)'), 'https://www.google.com/maps/dir/?api=1&destination=48.9%2C9.0');
});

test('Ereignisart mit Aktion: anlegen, ohne Angabe bleibt, ändern, wegnehmen; Unbekanntes wird keine Aktion', async () => {
  const c = await mitAktivitaet();
  const a1 = await c.d.ereignisartAnlegen({ bezeichnung: 'Schleuse', aktion: 'text' });
  assert.ok(a1.ok);
  assert.equal((await c.d.ereignisartLaden(a1.id)).aktuell.werte.aktion, 'text');
  const a2 = await c.d.ereignisartAnlegen({ bezeichnung: 'Brücke' });
  assert.equal(Object.prototype.hasOwnProperty.call((await c.d.ereignisartLaden(a2.id)).aktuell.werte, 'aktion'), false);
  const a3 = await c.d.ereignisartAnlegen({ bezeichnung: 'Fähre', aktion: 'gibtsnicht' });
  assert.equal(Object.prototype.hasOwnProperty.call((await c.d.ereignisartLaden(a3.id)).aktuell.werte, 'aktion'), false);
  /* ohne Angabe bleibt die Aktion */
  const r1 = await c.d.ereignisartAendern(a1.id, { bezeichnung: 'Schleuse' });
  assert.equal(r1.geaendert, false);
  assert.equal((await c.d.ereignisartLaden(a1.id)).aktuell.werte.aktion, 'text');
  /* andere Aktion */
  const r2 = await c.d.ereignisartAendern(a1.id, { bezeichnung: 'Schleuse', aktion: 'foto' });
  assert.equal(r2.geaendert, true);
  assert.equal((await c.d.ereignisartLaden(a1.id)).aktuell.werte.aktion, 'foto');
  /* wegnehmen */
  const r3 = await c.d.ereignisartAendern(a1.id, { bezeichnung: 'Schleuse', aktion: '' });
  assert.equal(r3.geaendert, true);
  assert.equal((await c.d.ereignisartLaden(a1.id)).aktuell.werte.aktion, '');
  /* eine Art ohne Aktion bleibt bei leerer Wahl unverändert */
  const r4 = await c.d.ereignisartAendern(a2.id, { bezeichnung: 'Brücke', aktion: '' });
  assert.equal(r4.geaendert, false);
});

test('Der Knopf trägt die Aktion seiner Art mit, ohne Aktion bleibt es leer', async () => {
  const c = await mitAktivitaet();
  await c.d.ereignisartAnlegen({ bezeichnung: 'Schleuse', aktion: 'navi' });
  await c.d.ereignisartAnlegen({ bezeichnung: 'Brücke' });
  const sk = await c.d.schnellknoepfeFuerFahrzeugart('boot');
  const schleuse = sk.angebot.ereignisse.find(x => x.name === 'Schleuse');
  const bruecke = sk.angebot.ereignisse.find(x => x.name === 'Brücke');
  assert.equal(schleuse.aktion, 'navi');
  assert.equal(bruecke.aktion, '');
});

test('Textfeld: Wo und Wann stehen zuerst fest, der Text kommt dazu und zählt nicht als korrigiert', async () => {
  const c = await mitAktivitaet();
  const art = await c.d.ereignisartAnlegen({ bezeichnung: 'Schleuse', aktion: 'text' });
  const e = await c.d.ereignisSchnell(c.id, 'Schleuse', { artId: art.id });
  assert.ok(e.ok);
  let liste = await eventsVon(c);
  let ev = liste.find(x => x.id === e.id);
  assert.equal(ev.text, null);
  assert.equal(ev.geaendert, false);
  const r = await c.d.ereignisAktionSpeichern(e.id, { text: '  Tor 2, 20 Minuten Wartezeit  ' });
  assert.ok(r.ok);
  assert.equal(r.geaendert, true);
  ev = (await eventsVon(c)).find(x => x.id === e.id);
  assert.equal(ev.text, 'Tor 2, 20 Minuten Wartezeit');
  assert.equal(ev.geaendert, false, 'eine Aktion ist keine Korrektur');
  /* Verlauf: zwei Stände, der zweite mit Quelle „aktion“ */
  const geladen = await c.d.ereignisLaden(e.id);
  assert.equal(geladen.verlauf.length, 2);
  /* eine echte Änderung danach zählt als korrigiert */
  const w = geladen.aktuell.werte;
  const ae = await c.d.ereignisAendern(e.id, { artId: w.artId, datum: w.datum, zeit: w.zeit, text: 'Tor 3' });
  assert.ok(ae.ok);
  ev = (await eventsVon(c)).find(x => x.id === e.id);
  assert.equal(ev.geaendert, true);
});

test('Foto: kommt zum Ereignis, nur eine Datei, leere Datei und zweite Datei werden abgewiesen', async () => {
  const c = await mitAktivitaet();
  const art = await c.d.ereignisartAnlegen({ bezeichnung: 'Hafen', aktion: 'foto' });
  const e = await c.d.ereignisSchnell(c.id, 'Hafen', { artId: art.id });
  assert.ok(e.ok);
  assert.equal((await eventsVon(c)).find(x => x.id === e.id).hatFoto, false);
  const leer = await c.d.ereignisAktionSpeichern(e.id, { datei: foto('') });
  assert.equal(leer.ok, false);
  assert.ok(leer.fehler.datei);
  const r = await c.d.ereignisAktionSpeichern(e.id, { datei: foto('bilddaten', 'hafen.jpg') });
  assert.ok(r.ok);
  const ev = (await eventsVon(c)).find(x => x.id === e.id);
  assert.equal(ev.hatFoto, true);
  assert.equal(ev.geaendert, false);
  const datei = await c.d.ereignisDateiHolen(e.id);
  assert.equal(datei.name, 'hafen.jpg');
  const zweite = await c.d.ereignisAktionSpeichern(e.id, { datei: foto('mehr', 'zwei.jpg') });
  assert.equal(zweite.ok, false);
  assert.ok(zweite.fehler.datei);
  assert.equal((await c.d.ereignisDateiHolen(e.id)).name, 'hafen.jpg');
});

test('Aktion ohne Inhalt ändert nichts; unbekanntes Ereignis wird abgewiesen', async () => {
  const c = await mitAktivitaet();
  const art = await c.d.ereignisartAnlegen({ bezeichnung: 'Schleuse', aktion: 'text' });
  const e = await c.d.ereignisSchnell(c.id, 'Schleuse', { artId: art.id });
  const r = await c.d.ereignisAktionSpeichern(e.id, { text: '   ' });
  assert.ok(r.ok);
  assert.equal(r.geaendert, false);
  assert.equal((await c.d.ereignisLaden(e.id)).verlauf.length, 1);
  const nix = await c.d.ereignisAktionSpeichern('gibt-es-nicht', { text: 'x' });
  assert.equal(nix.ok, false);
  const lang = await c.d.ereignisAktionSpeichern(e.id, { text: 'x'.repeat(2001) });
  assert.equal(lang.ok, false);
  assert.ok(lang.fehler.text);
});

test('Ein Knopf ohne Aktion bleibt wie bisher: kein Zusatzfeld an der Art, Ereignis wie vorher', async () => {
  const c = await mitAktivitaet();
  const e = await c.d.ereignisSchnell(c.id, 'Abfahrt', {});
  assert.ok(e.ok);
  const art = (await c.d.ereignisartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Abfahrt');
  assert.equal(Object.prototype.hasOwnProperty.call(art.aktuell.werte, 'aktion'), false);
  assert.equal((await c.d.ereignisLaden(e.id)).verlauf.length, 1);
});

test('Oberfläche im Quelltext: Aktion bei der Art, Kamera beim Foto, Seite der Aktion, Route, Modul eingetragen', () => {
  const ansicht = fs.readFileSync(path.join(__dirname, '../js/ansicht.js'), 'utf8');
  /* seit 2.0.50 heißt der Block „Nach dem Antippen“ (Fragen und Wirkungen), die Aktion geht darin auf */
  assert.ok(ansicht.includes("'Nach dem Antippen (freiwillig)'"));
  assert.ok(ansicht.includes("capture: 'environment'"));
  assert.ok(ansicht.includes('function cockpitAktionSeite('));
  assert.ok(ansicht.includes("teile[3] === 'aktion'"));
  assert.ok(/kamera: true/.test(ansicht));
  const html = fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8');
  const sw = fs.readFileSync(path.join(__dirname, '../sw.js'), 'utf8');
  assert.ok(html.includes('js/aktionen.js'));
  assert.ok(sw.includes("'js/aktionen.js'"));
});
