# Schritte beim Aufbau von V2

Grundlage ist das Dokument „MobiMory V2 – Festlegungen und Datenstruktur“.
Jeder Schritt baut auf dem letzten auf und endet mit einem sichtbaren Ergebnis.

| Schritt | Inhalt | Stand |
|---|---|---|
| 1 | Fahrzeug: Fahrzeugliste (Schale 1) und äußere Hülle (Schale 2), Handeingabe, Verlauf, offline | fertig (2.0.1) |
| 1a | Ansicht der äußeren Schalen: Startseite, Hauptmenü, Stammdaten, Neu im Programm, Einstellungen | fertig (2.0.2) |
| 2 | Hauptkomponenten (Schale 3), beliebig tief verschachtelt, mit Hersteller, Modell, Seriennummer, Baujahr, Einbau, technischen Merkmalen | fertig (2.0.4) |
| 3 | Fristen an Fahrzeug und Komponenten (Kalender und Zähler), Zählerstände von Hand, Erledigungen | fertig (2.0.5) |
| 3a | Dokumente an Fahrzeug und Komponente (Datei oder Link), Gesamtliste | fertig (2.0.6) |
| 3b | Personen, Tiere und Nachweise (offene Nachweisarten mit Vorschlägen DE/EU) | fertig (2.0.7) |
| 4 | Aktivität mit gemeinsamem Kern (Besatzung aus den Personen, Prüfung bei der Planung) | fertig (2.0.8) |
| 4b | Sicherungsdatei: sichern, verschlüsseln, wiederherstellen, Erinnerung | fertig (2.0.9) |
| 4a | Orte und Gebiete mit Regeln (Stufe 1: eigene Regeln, einfache Gebietsliste) | fertig (2.0.10, erweitert in 2.0.11 und 2.0.12) |
| 4c | Testrunde mit echten Daten (Wohnmobil und Boot) | gemacht, einziger offener Punkt war die Ausrüstung |
| 4d | Ausrüstung nachbessern: Anzahl, Bezugsgröße (Fahrzeug oder Person), Soll gegen Ist, Eignung als Hinweis mit Haken | fertig (2.0.12), noch nicht getestet |
| 5 | Logbuch-Kern: Tagesabschnitte, Ereignisse, Nachtragen | fertig (2.0.13), noch nicht getestet |
| 5a | Cockpit und klassisches Logbuch: Bedienung, Wechsel mit Prüfung, Tagesabschluss | fertig (2.0.14), noch nicht getestet |
| 5b | Ereignisse je Fahrzeugart (Baum, vererbt, änderbar) und Logbuch ohne Planung starten | fertig (2.0.15), noch nicht getestet |
| 5c | Fahrzeugarten selbst verwalten: Untergruppen anlegen, umbenennen, ausblenden, löschen (nur Unbenutztes), bereinigen | fertig (2.0.16), noch nicht getestet |
| 5d | Art der Aktivität richtet sich nach dem Fahrzeug (Zuordnung wie bei den Ereignissen); Logbuch jetzt starten mit Wahl der Art | fertig (2.0.17), noch nicht getestet |
| 5e | Cockpit im Vollbild ohne Scrollen, bis zu 8 frei belegbare Schnellknöpfe je Fahrzeugart plus „Sonstige Ereignisse“ (3 mal 3) | fertig (2.0.18), noch nicht getestet |
| 6 | Zähler automatisch, erster Teil: ein Schalter und ein Zähler je Motor (Start/Stopp, Betriebsstunden), Kurzname, Leiste im Cockpit, Liste ab drei Motoren, Stoppzeit korrigieren | fertig (2.0.19), noch nicht getestet |
| 6b | Motorhinweis je Fahrzeugart („Kein Motor läuft“), Betriebsstunden und Kilometer zusammen in der Anzeige, Knopfzahl je Gerät (bis 15, Spalten nach Bildschirmbreite) | fertig (2.0.20), noch nicht getestet |
| 6a | Zähler automatisch, zweiter Teil: Motorstopp-Frage nach Ankunft, Anlegen oder Anker werfen (Vorschlag der Stoppzeit, Timer vom Nutzer eingestellt) | offen |
| 7 | Werkstatt: Störungen, Arbeiten, Aufgaben | offen |
| 8 | Kosten | offen |
| 9 | Route, GPX, Wetter und Tide | offen |
| 10 | Wasserski, später Segeln | offen |
| 11 | Reisecheck | offen |
| 12 | Konten, Server und Stufen, danach Verleih | offen |
| 13 | Smart Capture (Fahrzeugschein und Nachweise einlesen) | offen |

Die Reihenfolge ab Schritt 5 hat der Nutzer am 03.11.2026 festgelegt.

## Noch nicht drin, weil sie auf anderen Teilen aufbauen
- Weitere feste Standorte der äußeren Hülle: Der Heimatstandort ist seit 2.0.10 da, weitere folgen nach Bedarf.
- Konto und Anmeldung, Server, Sicherung: kommen später. Schritt 1 arbeitet nur lokal (Basis-Version).
- Wertverlauf und Kosten: kommen mit der Kostenstruktur.
- Fristen, Kosten und Nachweise an den Komponenten: kommen mit den jeweiligen Schritten.
- Feste Merkmal-Kataloge je Komponente (bisher frei eintragbar): im Festlegungsdokument noch nicht besprochen.
- Funktionen, Personen und Tiere: Kacheln sind da und zeigen „kommt“.
- Dokumente auf dem Server und auf mehreren Geräten (Original auf dem Server, Kopie „offline verfügbar“ auf dem Gerät): kommt mit Konten und Server.
- Smart Capture (Fahrzeugschein einlesen): eigener Schritt, nutzt die Ablage für Dateien.
- Vorschläge für Nachweisarten aus weiteren Ländern: kommen nach Bedarf, Land für Land, jeweils mit Quelle und Prüfdatum.
- Prüfung „erlaubt, nicht erlaubt, unklar“ für Skipper und Fahrer: kommt mit der Aktivität.
- Tiere als Bezugsgröße der Pflichtausrüstung: nicht vorgesehen, es ist keine Pflicht bekannt.
- Prüfung gegen Anforderungen eines Gebiets: seit 2.0.10 mit eigenen Regeln. Ein Gebiet nur als Text wird weiter nicht geprüft.
- Prüfung zum Tagesbeginn: seit 2.0.13 je Tag festgehalten. Prüfung bei jedem Wechsel des Verantwortlichen unterwegs: seit 2.0.14 beim Wechsel festgehalten.
- Automatische Sicherung und Umzug zwischen mehreren Geräten ohne Datei: kommt mit Konten und Server.
- Regeln mit Quelle und Prüfdatum (Stufe 2) und weitere Länder sowie Motorleistung und Gewicht als Bedingungen (Stufe 3): erst nach der Testrunde.
