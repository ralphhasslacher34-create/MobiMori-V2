'use strict';
/* 2.0.106: Quelle jedes Eintrags und Herkunft von Datum, Uhrzeit und Position. */
const test = require('node:test');
const assert = require('node:assert/strict');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'reiseorte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;

test('Quelle und Herkunft: Texte und Zeilen', () => {
  const L = MM.Logbuch;
  assert.equal(L.quelleText('nutzer'), 'Nutzer'); assert.equal(L.quelleText('app'), 'App'); assert.equal(L.quelleText('dienst'), 'Dienst');
  assert.equal(L.quelleText('fahrzeug', 'Bordnetz-Brücke'), 'Fahrzeug (Bordnetz-Brücke)');
  assert.equal(L.quelleText('unsinn'), 'Nutzer', 'unbekannt gilt wie Nutzer');
  assert.equal(L.zeitHerkunftText('geraet'), 'automatisch (Gerätezeit)'); assert.equal(L.zeitHerkunftText('gps'), 'automatisch (GPS)');
  assert.equal(L.zeitHerkunftText('hand'), 'von Hand'); assert.equal(L.zeitHerkunftText(null), 'nicht festgehalten');
  assert.equal(L.positionHerkunftText('gps'), 'automatisch (GPS)'); assert.equal(L.positionHerkunftText('hand'), 'von Hand');
  assert.deepEqual(L.herkunftZeilen({ quelle: 'app', zeitHerkunft: 'geraet' }), [['Quelle', 'App'], ['Datum und Uhrzeit', 'automatisch (Gerätezeit)']], 'ohne Position keine Positionszeile');
  assert.deepEqual(L.herkunftZeilen({ quelle: 'nutzer', zeitHerkunft: 'hand', breite: 1, laenge: 2, positionQuelle: 'gps' }).pop(), ['Position', 'automatisch (GPS)']);
});

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 3, 12, 0, 0).getTime() };
  let t = 0;
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
}
async function mitAktivitaet() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  await d.ereignisartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: boot, vonDatum: '2026-11-03', vonZeit: '09:00', bisDatum: '2026-11-05', bisZeit: '17:30', verantwortlichId: anna });
  return { d, id: r.id };
}
const eventsVon = async (c) => (await c.d.logbuchLaden(c.id)).abschnitte.flatMap(t => t.ereignisse);

test('Quelle: Ein Knopf im Cockpit ist vom Nutzer, die Zeit „jetzt“ kommt von der Gerätezeit; die Position vom GPS', async () => {
  const c = await mitAktivitaet();
  const r = await c.d.ereignisSchnell(c.id, 'Abfahrt', { position: { breite: 48.1, laenge: 9.1, genauigkeit: 5 } });
  assert.ok(r.ok);
  const e = (await eventsVon(c))[0];
  assert.equal(e.quelle, 'nutzer'); assert.equal(e.zeitHerkunft, 'geraet'); assert.equal(e.positionQuelle, 'gps');
  const detail = await c.d.ereignisLaden(r.id);
  assert.equal(detail.aktuell.werte.quelle, 'nutzer');
});

test('Quelle: Das Formular mit der Zeit der Seite ist Gerätezeit, mit geänderter Zeit von Hand, ein Nachtrag von Hand', async () => {
  const c = await mitAktivitaet();
  const t = await c.d.heutigerTag(c.id);
  const art = (await c.d.ereignisartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Abfahrt').objekt.id;
  const a = await c.d.ereignisAnlegen(t.abschnittId, { artId: art, datum: '2026-11-03', zeit: '12:00' }, { zeitHerkunft: 'geraet' });
  const b = await c.d.ereignisAnlegen(t.abschnittId, { artId: art, datum: '2026-11-03', zeit: '12:00' });
  const n = await c.d.ereignisAnlegen(t.abschnittId, { artId: art, datum: '2026-11-03', zeit: '10:00' }, { nachtragen: true });
  assert.ok(a.ok && b.ok && n.ok);
  const w = async id => (await c.d.ereignisLaden(id)).aktuell.werte;
  assert.equal((await w(a.id)).zeitHerkunft, 'geraet');
  assert.equal((await w(b.id)).zeitHerkunft, 'hand', 'ohne Angabe gilt: von Hand');
  assert.equal((await w(n.id)).zeitHerkunft, 'hand'); assert.equal((await w(n.id)).nachgetragen, 'ja');
  assert.equal((await w(n.id)).quelle, 'nutzer');
});

test('Quelle: Eine Korrektur der Uhrzeit macht sie zu „von Hand“, die Quelle bleibt', async () => {
  const c = await mitAktivitaet();
  const r = await c.d.ereignisSchnell(c.id, 'Abfahrt', { quelle: 'app' });
  assert.equal((await c.d.ereignisLaden(r.id)).aktuell.werte.zeitHerkunft, 'geraet');
  const w = (await c.d.ereignisLaden(r.id)).aktuell.werte;
  const a = await c.d.ereignisAendern(r.id, { artId: w.artId, datum: w.datum, zeit: '11:30', text: w.text || '' });
  assert.ok(a.ok);
  const neu = (await c.d.ereignisLaden(r.id)).aktuell.werte;
  assert.equal(neu.zeitHerkunft, 'hand'); assert.equal(neu.quelle, 'app', 'die Quelle bleibt, wie sie war');
});

test('Quelle: Das Geschwindigkeits- und Wetter-Eintragen der App ist „App“, der Wetter-Knopf vom Nutzer', async () => {
  const c = await mitAktivitaet();
  const fahrt = { startMs: Date.now() - 600000, tagDatum: '2026-11-03' };
  const art = await c.d.geschwindigkeitsArtSichern();
  const r = await c.d.ereignisSchnell(c.id, MM.Logbuch.GESCHWINDIGKEIT_ART, { artId: art, text: 'Geschwindigkeit (Rhythmus): test', quelle: 'app' });
  assert.ok(r.ok);
  const e = (await eventsVon(c)).find(x => x.artName === 'Geschwindigkeit');
  assert.equal(e.quelle, 'app'); assert.equal(e.zeitHerkunft, 'geraet');
  assert.ok(fahrt);
});

test('Quelle: „Fahrzeug“ und „Dienst“ sind als Werte möglich, der Name des Geräts bleibt nur beim Fahrzeug', async () => {
  const c = await mitAktivitaet();
  const t = await c.d.heutigerTag(c.id);
  const art = (await c.d.ereignisartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Notiz').objekt.id;
  const f = await c.d.ereignisAnlegen(t.abschnittId, { artId: art, datum: '2026-11-03', zeit: '12:00' }, { quelle: 'fahrzeug', quelleName: 'Temperaturfühler Motor', zeitHerkunft: 'geraet' });
  const s = await c.d.ereignisAnlegen(t.abschnittId, { artId: art, datum: '2026-11-03', zeit: '12:01' }, { quelle: 'dienst', quelleName: 'ignoriert', zeitHerkunft: 'geraet' });
  const ev = await eventsVon(c);
  const ef = ev.find(x => x.id === f.id), es = ev.find(x => x.id === s.id);
  assert.equal(MM.Logbuch.quelleText(ef.quelle, ef.quelleName), 'Fahrzeug (Temperaturfühler Motor)');
  assert.equal(es.quelle, 'dienst'); assert.equal(es.quelleName, null);
});

test('Herkunft: Der Wechsel der Verantwortung trägt die Herkunft seiner Zeit; eine spätere Korrektur macht sie „von Hand“', async () => {
  const c = await mitAktivitaet();
  const ben = (await c.d.personAnlegen({ bezeichnung: 'Ben', funktionen: ['Skipper'] })).id;
  await c.d.besatzungHinzufuegen(c.id, ben, { rolle: 'stellvertreter' });
  await c.d.heutigerTag(c.id);
  const r = await c.d.verantwortungWechseln(c.id, ben, { abDatum: '2026-11-03', abZeit: '12:05', zeitHerkunft: 'geraet' });
  assert.ok(r.ok);
  let w = (await eventsVon(c)).find(e => e.art === 'wechsel');
  assert.equal(w.zeitHerkunft, 'geraet'); assert.equal(w.quelle, 'nutzer');
  assert.ok((await c.d.wechselAendern(r.verantwortungId, { abDatum: '2026-11-03', abZeit: '12:03' })).ok);
  w = (await eventsVon(c)).find(e => e.art === 'wechsel');
  assert.equal(w.zeitHerkunft, 'hand');
});
