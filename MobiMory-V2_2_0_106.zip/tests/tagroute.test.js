'use strict';
/* 2.0.90: Route planen je Tag. Start und Ziel vom Tag, Maße vom Fahrzeug, Zählung je Tag, eigenes Dokument, Karte des Tages, GPX, Wasserfahrzeug, Fehler. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche',
  'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'etappen', 'konto', 'daten'].forEach((m) => require('../js/' + m + '.js'));
const MM = globalThis.MM;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const JETZT = new Date(2026, 10, 15, 12, 0, 0).toISOString();

async function neu(kontoFn, fahrzeugArt, fzWerte) {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  if (kontoFn) { d.kontoAnfrageFn = kontoFn; await d.rcSchreiben({ kontoToken: 'tok', kontoEmail: 'a@example.org' }); }
  const fz = (await d.fahrzeugAnlegen(fahrzeugArt || 'wohnmobil', Object.assign({ bezeichnung: 'Fahrzeug', hoehe: '3,1', breite: '2,3', laenge: '7,4', gesamtgewicht: '4500', achsen: '2' }, fzWerte || {}))).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = arten.find((a) => a.aktuell.werte.bezeichnung === 'Urlaub').objekt.id;
  async function ort(name, b, l) { const r = await d.ortAnlegen({ bezeichnung: name, positionBreite: b === null ? '' : String(b), positionLaenge: l === null ? '' : String(l) }); assert.equal(r.ok, true, JSON.stringify(r)); return r.id; }
  const orte = { s: await ort('Stuttgart', 48.78, 9.18), u: await ort('Ulm', 48.4, 9.99), m: await ort('München', 48.14, 11.58), frei: await ort('Nirgendwo', null, null) };
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Reise', artId, fahrzeugId: fz, vonDatum: '2026-11-20', vonZeit: '08:00', bisDatum: '2026-11-21', verantwortlichId: anna, startOrtId: orte.s, zielOrtId: orte.m, zwischenzielIds: [orte.u] });
  assert.equal(r.ok, true, JSON.stringify(r));
  await d.tagesabschnitteVorbereiten(r.id);
  const lb = await d.logbuchLaden(r.id);
  const tage = lb.abschnitte.map((x) => x.objekt.id);
  const wv = (datum, extra) => Object.assign({ datum, beginnZeit: '08:00', endeZeit: '12:00' }, extra || {});
  return { d, fz, akt: r.id, orte, tage, wv };
}
const antwortVon = (a, b, km) => ({ ok: true, route: { punkte: [{ breite: a[0], laenge: a[1] }, { breite: (a[0] + b[0]) / 2, laenge: (a[1] + b[1]) / 2 }, { breite: b[0], laenge: b[1] }], laengeKm: km, dauerMin: Math.round(km), warnungen: [] }, kontingent: { genutzt: 1, grenze: 10, stufe: 'test' } });

test('Tage planen: Start und Ziel je Tag (Tag 2 startet am Ziel des Vortags), jede Planung geht einzeln an den Dienst, eigenes Dokument je Tag, die Route der Aktivität bleibt unberührt', async () => {
  const aufrufe = []; let genutzt = 0;
  const c = await neu(async (url, methode, token, body) => {
    aufrufe.push({ url, methode, token, body }); genutzt++;
    const r = antwortVon([body.von.breite, body.von.laenge], [body.nach.breite, body.nach.laenge], 100 + genutzt);
    r.route.warnungen = genutzt === 1 ? [{ code: 'violatedVehicleRestriction', stufe: 'kritisch', titel: 'x', grund: 'y', ort: { breite: 48.6, laenge: 9.5 } }] : [];
    r.kontingent = { genutzt, grenze: 10, stufe: 'test' }; return r;
  });
  assert.equal((await c.d.abschnittAendern(c.tage[0], c.wv('2026-11-20', { zielOrtId: c.orte.u }))).ok, true);
  assert.equal((await c.d.abschnittAendern(c.tage[1], c.wv('2026-11-21', { zielOrtId: c.orte.m }))).ok, true);
  const v0 = await c.d.tagRouteAnsicht(c.tage[0]);
  assert.equal(v0.ok, true); assert.equal(v0.planung.moeglich, true); assert.equal(v0.planung.start.name, 'Stuttgart'); assert.equal(v0.planung.ziel.name, 'Ulm'); assert.deepEqual(v0.planung.fehler, []); assert.equal(v0.route, null);
  const v1 = await c.d.tagRouteAnsicht(c.tage[1]);
  assert.equal(v1.planung.start.name, 'Ulm'); assert.equal(v1.planung.ziel.name, 'München');
  const r0 = await c.d.tagRoutePlanen(c.tage[0]);
  assert.equal(r0.ok, true, JSON.stringify(r0)); assert.equal(r0.laengeKm, 101); assert.equal(r0.warnungen.length, 1); assert.equal(r0.kontingent.genutzt, 1);
  const r1 = await c.d.tagRoutePlanen(c.tage[1]);
  assert.equal(r1.ok, true); assert.equal(r1.laengeKm, 102); assert.equal(r1.kontingent.genutzt, 2);
  /* fünf Tage wären fünf Routen: hier zwei Tage, zwei Aufrufe, je ohne Zwischenziele */
  assert.equal(aufrufe.length, 2);
  assert.equal(aufrufe[0].url.endsWith('/route/planen'), true); assert.equal(aufrufe[0].methode, 'POST'); assert.equal(aufrufe[0].token, 'tok');
  assert.deepEqual(aufrufe[0].body.von, { breite: 48.78, laenge: 9.18 }); assert.deepEqual(aufrufe[0].body.nach, { breite: 48.4, laenge: 9.99 }); assert.deepEqual(aufrufe[0].body.via, []);
  assert.deepEqual(aufrufe[0].body.fahrzeug, { hoehe: 3.1, breite: 2.3, laenge: 7.4, gesamtgewicht: 4500, achsen: 2 });
  assert.deepEqual(aufrufe[1].body.von, { breite: 48.4, laenge: 9.99 }); assert.deepEqual(aufrufe[1].body.nach, { breite: 48.14, laenge: 11.58 });
  const n0 = await c.d.tagRouteAnsicht(c.tage[0]);
  assert.equal(n0.route.laengeKm, 101); assert.equal(n0.route.warnungen[0].code, 'violatedVehicleRestriction'); assert.equal(n0.route.veraltet, false); assert.equal(n0.route.startName, 'Stuttgart');
  assert.equal((await c.d.tagRouteAnsicht(c.tage[1])).route.laengeKm, 102);
  /* nichts in die Routen der Aktivität gemischt */
  const ra = await c.d.routeAnsicht(c.akt);
  assert.equal(ra.route, null); assert.equal((await c.d.routenListe(c.akt)).length, 0);
  assert.ok(await c.d.einstellungLesen('tagroute-' + c.tage[0])); assert.ok(await c.d.einstellungLesen('tagroute-' + c.tage[1]));
  /* neue Planung ersetzt die frühere des Tages */
  const r0b = await c.d.tagRoutePlanen(c.tage[0]);
  assert.equal(r0b.ok, true); assert.equal((await c.d.tagRouteAnsicht(c.tage[0])).route.laengeKm, 103); assert.equal(aufrufe.length, 3);
});

test('Veraltet: ändert sich das Ziel des Tages, sagt die Ansicht „neu planen“', async () => {
  const c = await neu(async (u, m, t, body) => antwortVon([body.von.breite, body.von.laenge], [body.nach.breite, body.nach.laenge], 90));
  await c.d.abschnittAendern(c.tage[0], c.wv('2026-11-20', { zielOrtId: c.orte.u }));
  assert.equal((await c.d.tagRoutePlanen(c.tage[0])).ok, true);
  await c.d.abschnittAendern(c.tage[0], c.wv('2026-11-20', { zielOrtId: c.orte.m }));
  const v = await c.d.tagRouteAnsicht(c.tage[0]);
  assert.equal(v.route.veraltet, true);
  const kd = await c.d.tagKartenDaten(c.tage[0]);
  assert.equal(kd.veraltet, true);
});

test('Fehler: ohne Ziel, ohne Position, gleicher Ort, nicht angemeldet, Kontingent: nichts oder nur das Nötige geht an den Dienst', async () => {
  let aufrufe = 0, antwort = async () => { throw Object.assign(new Error('Dein Kontingent ist aufgebraucht: 10 von 10 geplanten Routen.'), { status: 402 }); };
  const c = await neu(async (...x) => { aufrufe++; return antwort(...x); });
  /* Tag 2: mehrtägige Reise, kein Ziel eingetragen */
  const ohneZiel = await c.d.tagRoutePlanen(c.tage[1]);
  assert.equal(ohneZiel.ok, false); assert.match(ohneZiel.fehler.allgemein, /kein Zielort bekannt/); assert.equal(aufrufe, 0);
  await c.d.abschnittAendern(c.tage[0], c.wv('2026-11-20', { zielOrtId: c.orte.frei }));
  const ohnePos = await c.d.tagRoutePlanen(c.tage[0]);
  assert.equal(ohnePos.ok, false); assert.match(ohnePos.fehler.allgemein, /Zielort „Nirgendwo“ hat keine Position/); assert.equal(aufrufe, 0);
  await c.d.abschnittAendern(c.tage[0], c.wv('2026-11-20', { startOrtId: c.orte.s, zielOrtId: c.orte.s }));
  const gleich = await c.d.tagRoutePlanen(c.tage[0]);
  assert.equal(gleich.ok, false); assert.match(gleich.fehler.allgemein, /derselbe Ort/); assert.equal(aufrufe, 0);
  await c.d.abschnittAendern(c.tage[0], c.wv('2026-11-20', { zielOrtId: c.orte.u }));
  const voll = await c.d.tagRoutePlanen(c.tage[0]);
  assert.equal(voll.ok, false); assert.equal(voll.art, 'kontingent'); assert.match(voll.fehler.allgemein, /aufgebraucht/); assert.equal(aufrufe, 1);
  assert.equal((await c.d.tagRouteAnsicht(c.tage[0])).route, null);
  assert.equal((await c.d.tagRoutePlanen('nix')).ok, false);
  const o = await neu(); /* nicht angemeldet */
  await o.d.abschnittAendern(o.tage[0], o.wv('2026-11-20', { zielOrtId: o.orte.u }));
  const x = await o.d.tagRoutePlanen(o.tage[0]);
  assert.equal(x.ok, false); assert.equal(x.art, 'anmeldung'); assert.match(x.fehler.allgemein, /Melde dich zuerst an/);
});

test('Fehlende Maße werden genannt und gespeichert; GPX des Tages mit Namen; Karte des Tages mit Route, Start, Ziel und Warnstellen, ohne Wetter', async () => {
  const c = await neu(async (u, m, t, body) => {
    const r = antwortVon([body.von.breite, body.von.laenge], [body.nach.breite, body.nach.laenge], 95);
    r.route.warnungen = [{ code: 'violatedBlockedRoad', stufe: 'hinweis', ort: { breite: 48.6, laenge: 9.5 } }, { code: 'x', stufe: 'hinweis', titel: 'ohne Stelle' }]; return r;
  }, 'wohnmobil', { breite: '', gesamtgewicht: '' });
  await c.d.abschnittAendern(c.tage[0], c.wv('2026-11-20', { zielOrtId: c.orte.u }));
  const v = await c.d.tagRouteAnsicht(c.tage[0]);
  assert.deepEqual(v.planung.fehlend, ['Breite', 'Zulässiges Gesamtgewicht']);
  const r = await c.d.tagRoutePlanen(c.tage[0]);
  assert.equal(r.ok, true); assert.deepEqual(r.fehlend, ['Breite', 'Zulässiges Gesamtgewicht']);
  assert.deepEqual((await c.d.tagRouteAnsicht(c.tage[0])).route.fehlend, ['Breite', 'Zulässiges Gesamtgewicht']);
  const g = await c.d.tagRouteGpx(c.tage[0]);
  assert.equal(g.ok, true); assert.match(g.name, /^Stuttgart-Ulm-2026-11-20\.gpx$/); assert.match(g.text, /<rtept lat="48.78" lon="9.18"><name>Stuttgart<\/name>/); assert.match(g.text, /<name>Ulm<\/name>/);
  assert.equal((await c.d.tagRouteGpx(c.tage[1])).ok, false);
  const kd = await c.d.tagKartenDaten(c.tage[0]);
  assert.equal(kd.ok, true); assert.equal(kd.nurRoute, true); assert.equal(kd.wetter, null); assert.equal(kd.weg, null); assert.deepEqual(kd.ereignisse, []);
  assert.equal(kd.route.punkte.length, 3); assert.equal(kd.route.laengeKm, 95); assert.equal(kd.route.warnstellen.length, 1);
  assert.deepEqual(kd.planOrte.map((o) => o.rolle + ':' + o.name), ['start:Stuttgart', 'ziel:Ulm']);
  /* Tag ohne Planung: Karte nur mit Start und Ziel */
  await c.d.abschnittAendern(c.tage[1], c.wv('2026-11-21', { zielOrtId: c.orte.m }));
  const k2 = await c.d.tagKartenDaten(c.tage[1]);
  assert.equal(k2.route, null); assert.equal(k2.planOrte.length, 2);
  assert.equal((await c.d.tagKartenDaten('nix')).ok, false);
});

test('Sicherung: das Dokument der Tagesroute liegt in „einstellungen“ und kommt mit', async () => {
  const c = await neu(async (u, m, t, body) => antwortVon([body.von.breite, body.von.laenge], [body.nach.breite, body.nach.laenge], 80));
  await c.d.abschnittAendern(c.tage[0], c.wv('2026-11-20', { zielOrtId: c.orte.u }));
  await c.d.tagRoutePlanen(c.tage[0]);
  const alle = await c.d.speicher.alle('einstellungen');
  assert.ok(alle.some((e) => e.id === 'tagroute-' + c.tage[0] && e.punkte.length === 3));
});

test('Wasserfahrzeug: keine Berechnung, Navi-Link mit dem Ziel des Tages; Planen wird abgelehnt und nichts gesendet', async () => {
  let aufrufe = 0;
  const c = await neu(async () => { aufrufe++; return {}; }, 'boot', {});
  await c.d.abschnittAendern(c.tage[0], c.wv('2026-11-20', { zielOrtId: c.orte.u }));
  const v = await c.d.tagRouteAnsicht(c.tage[0]);
  assert.equal(v.planung.moeglich, false); assert.equal(v.planung.welt, 'wasser'); assert.equal(v.planung.navi.link, 'geo:48.4,9.99?q=48.4,9.99(Ulm)'); assert.match(v.planung.grund, /dieses Tages/);
  const r = await c.d.tagRoutePlanen(c.tage[0]);
  assert.equal(r.ok, false); assert.equal(aufrufe, 0);
});

test('Einbau: Block und Karte des Tages, Route, Kartenansicht ohne Wetter-Knopf, Texte, Version 2.0.94, Schritte', () => {
  const a = lesen('js/ansicht.js');
  ['tagRouteBlock', 'daten.tagRoutePlanen(tagId)', 'Tag planen (zählt 1 Route)', 'Karte des Tages ansehen', "teile[2] === 'karte') p = seiteTagKarte", 'function seiteTagKarte', 'daten.tagKartenDaten(tagId)'].forEach((s) => assert.ok(a.includes(s), s));
  const k = lesen('js/kartenansicht.js');
  assert.ok(k.includes('opt.wetterJetzt ? el(') && k.includes('opt.offline ? el(') && k.includes('kd.nurRoute'));
  assert.equal(MM.VERSION, '2.0.106'); assert.ok(MM.STUFE.includes('Planung'));
  assert.equal(MM.Texte.NEUERUNGEN[16].version, '2.0.90'); assert.match(MM.Texte.NEUERUNGEN[16].punkte.join(' '), /Tag planen/); assert.match(MM.Texte.NEUERUNGEN[16].punkte.join(' '), /Karte des Tages/);
  assert.ok(lesen('CHANGELOG.md').includes('## 2.0.90\n- **Bau: Route planen je Tag**'));
  assert.ok(lesen('docs/SCHRITTE.md').includes('| 13f-15 |'));
  assert.ok(lesen('server/EINRICHTUNG.md').startsWith('# Konto-Dienst: Einrichtung und Updates (Stand 2.0.106, Schritt 13g)'));
  assert.match(lesen('README.md').split('\n')[5], /Version 2\.0\.106/);
});
