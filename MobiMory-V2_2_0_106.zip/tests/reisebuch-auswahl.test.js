'use strict';
/* 2.0.106: Reisebuch mit Auswahl, Vorlagen, gespeicherten Zusammenstellungen, Titelseite und Seitenzahlen. */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'etappen', 'reisecheck', 'pdf', 'reisebuch', 'daten']
  .forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const R = MM.Reisebuch;
const alsText = (b) => Buffer.from(b).toString('latin1');

test('Optionen: die drei alten Standards bleiben, alles Neue ist aus, Titelseite braucht keinen Schalter', () => {
  const o = R.optionen(null);
  assert.equal(o.bilder, true); assert.equal(o.kosten, false); assert.equal(o.notizen, true);
  ['alleEintraege', 'nurMitInhalt', 'position', 'herkunft', 'datumJeEintrag', 'ruderzeiten', 'motorzeiten', 'druckDatum'].forEach((k) => assert.equal(o[k], false, k));
  assert.equal(o.tagestexte, true);
  assert.equal(R.optionen({ notizen: false }).tagestexte, false, 'Texte folgen den Notizen, wenn nichts anderes gewählt ist');
  assert.equal(R.optionen({ notizen: false, tagestexte: true }).tagestexte, true);
  assert.ok(!R.SCHALTER.some((s) => /titel|seitenzahl/i.test(s.key)), 'Titelseite und Seitenzahlen sind nicht abwählbar');
});

test('Vorlagen: Reisetagebuch und Vollständiges Logbuch', () => {
  assert.deepEqual(R.VORLAGEN.map((v) => v.id).slice(0, 2), ['tagebuch', 'logbuch']);
  const l = R.vorlage('logbuch').optionen;
  ['alleEintraege', 'position', 'herkunft', 'datumJeEintrag', 'ruderzeiten', 'motorzeiten', 'druckDatum'].forEach((k) => assert.equal(l[k], true, k));
  assert.equal(l.kosten, false, 'Kosten nur auf Wunsch');
  assert.equal(R.vorlage('tagebuch').optionen.nurMitInhalt, true);
  assert.equal(R.vorlage('tagebuch').optionen.herkunft, false);
  assert.equal(R.vorlage('gibtsnicht'), null);
});

test('Zusammenstellungen: speichern, gleicher Name überschreibt, Name prüfen, Grenze', () => {
  let n = 0; const id = () => 'z' + (++n);
  const a = R.zusammenstellungNeu(null, '  Für die   Versicherung ', { herkunft: true, bilder: false }, 'T1', id);
  assert.ok(a.ok);
  assert.equal(a.dokument.vorlagen[0].name, 'Für die Versicherung');
  const b = R.zusammenstellungNeu(a.dokument, 'für die versicherung', { position: true }, 'T2', id);
  assert.equal(b.dokument.vorlagen.length, 1, 'gleicher Name überschreibt'); assert.equal(b.id, a.id);
  assert.equal(b.dokument.vorlagen[0].optionen.position, true); assert.equal(b.dokument.vorlagen[0].optionen.herkunft, false);
  assert.equal(R.zusammenstellungNeu(null, '   ', {}, 'T', id).ok, false);
  assert.equal(R.zusammenstellungNeu(null, 'x'.repeat(61), {}, 'T', id).ok, false);
  let dok = null;
  for (let i = 0; i < R.MAX_ZUSAMMENSTELLUNGEN; i++) dok = R.zusammenstellungNeu(dok, 'Z' + i, {}, 'T', id).dokument;
  assert.equal(R.zusammenstellungNeu(dok, 'Eine zu viel', {}, 'T', id).ok, false);
  assert.deepEqual(R.zusammenstellungenListe(a.dokument).map((x) => x.name), ['Für die Versicherung']);
});

function neueDaten() {
  let t = 0; const J = new Date(2026, 10, 3, 12, 0, 0).getTime();
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(J + (t++) * 1000).toISOString(), holeJson: async () => { throw new Error('kein Netz'); } });
}
async function boot() {
  const d = neueDaten();
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen(); await d.ereignisartenAusVorschlaegen();
  const b = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const ben = (await d.personAnlegen({ bezeichnung: 'Ben' })).id;
  const art = (await d.aktivitaetsartenListe()).find((a) => a.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn Nord', artId: art, fahrzeugId: b, vonDatum: '2026-11-03', vonZeit: '09:00', bisDatum: '2026-11-03', bisZeit: '18:00', verantwortlichId: anna });
  assert.ok((await d.besatzungHinzufuegen(r.id, ben, { rolle: 'crew' })).ok);
  const t = await d.heutigerTag(r.id);
  const ea = await d.ereignisartenListe();
  const abf = ea.find((x) => x.aktuell.werte.bezeichnung === 'Abfahrt').objekt.id;
  await d.ereignisSchnell(r.id, 'Abfahrt', { position: { breite: 48.1, laenge: 9.1, genauigkeit: 5 } });
  await d.ereignisAnlegen(t.abschnittId, { artId: abf, datum: '2026-11-03', zeit: '11:00', text: 'Mit Text' });
  return { d, id: r.id };
}

test('Daten: Reisebuch liefert Einträge aller Arten und die Zeiten; Ausgabe folgt den Schaltern', async () => {
  const { d, id } = await boot();
  const roh = await d.reisebuchLaden(id);
  const ev = roh.tage[0].ereignisse;
  assert.ok(ev.some((e) => e.quelle === 'nutzer' && e.zeitHerkunft === 'geraet'), 'Quelle und Herkunft kommen mit');
  assert.ok(ev.some((e) => e.positionQuelle === 'gps' && typeof e.breite === 'number'));
  assert.ok(Array.isArray(roh.ruderzeiten)); assert.ok(Array.isArray(roh.motorzeiten));

  const knapp = R.bauen(roh, { nurMitInhalt: true });
  assert.equal(knapp.tage[0].ereignisse.length, 1, 'nur der Eintrag mit Text');
  const alle = R.bauen(roh, { alleEintraege: true });
  assert.ok(alle.tage[0].ereignisse.length >= 2);
  assert.ok(alle.tage[0].ereignisse.every((e) => !e.zusatz || !/Quelle/.test(JSON.stringify(e.zusatz))), 'ohne Schalter keine Herkunft');
  const voll = R.bauen(roh, R.vorlage('logbuch').optionen, { datum: '2026-11-17T10:30:00Z' });
  assert.ok(voll.tage[0].ereignisse.every((e) => e.zusatz && JSON.stringify(e.zusatz).includes('Quelle') || /Quelle/.test(String(e.zusatz))), 'bei jedem Eintrag die Herkunft');
  assert.ok(voll.tage[0].ereignisse.every((e) => e.wann), 'bei jedem Eintrag Datum und Uhrzeit');
  assert.ok(voll.ruder && voll.ruder.zeilen.length >= 1);
  assert.match(voll.druckDatum, /^Ausgedruckt am .*10:30 Uhr$/);
  assert.equal(R.bauen(roh, {}, { datum: '2026-11-17T10:30:00Z' }).druckDatum, '', 'Ausdruckdatum nur auf Wunsch');
  assert.equal(R.bauen(roh, { tage: false }).tage.length, 0);
  assert.equal(R.bauen(roh, { ruderzeiten: false }).ruder, null);
});

test('Daten: Zusammenstellung speichern, später laden und löschen; PDF hat Titelseite, Seitenzahl und Ausdruckdatum; nichts wird verändert', async () => {
  const { d, id } = await boot();
  const vorher = JSON.stringify([await d.speicher.alle('verlaeufe'), await d.speicher.alle('ereignisse'), await d.speicher.alle('aktivitaeten')]);
  const s = await d.reisebuchZusammenstellungSpeichern('Mein Logbuch', R.vorlage('logbuch').optionen);
  assert.ok(s.ok);
  const liste = await d.reisebuchZusammenstellungen();
  assert.equal(liste.length, 1); assert.equal(liste[0].name, 'Mein Logbuch'); assert.equal(liste[0].optionen.herkunft, true);
  const p = await d.reisebuchPdf(id, liste[0].optionen);
  assert.ok(p.ok);
  const t = alsText(p.bytes);
  assert.match(t, /Seite 1 von/);
  assert.match(t, /Ausgedruckt am|Ausdruck/);
  assert.match(t, /Quelle/);
  assert.ok((await d.reisebuchZusammenstellungLoeschen(liste[0].id)).ok);
  assert.equal((await d.reisebuchZusammenstellungen()).length, 0);
  const nachher = JSON.stringify([await d.speicher.alle('verlaeufe'), await d.speicher.alle('ereignisse'), await d.speicher.alle('aktivitaeten')]);
  assert.equal(nachher, vorher, 'Das Reisebuch ändert keine Reisedaten');
});
