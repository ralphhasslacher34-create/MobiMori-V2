/*
 * Motoren: Rechnung für die Motorschalter (Start und Stopp) und die Betriebsstunden.
 *
 * Aus den V2-Festlegungen (Schritt 6, Zähler automatisch):
 *  - Jeder Motor hat seinen eigenen Schalter und Zähler, es gibt keinen Sammelschalter „alle“.
 *  - Motor aus: Schalter grau, mit Namen und „Start“. Motor läuft: Schalter rot, mit „Stopp“.
 *  - Bis zu zwei Motoren haben einen festen Schalter in der unteren Leiste des Cockpits.
 *    Ab drei Motoren steht dort ein einziger Schalter „Motoren“ (mit der Zahl der laufenden),
 *    der eine Liste mit allen Motoren und deren Schaltern öffnet.
 *  - Die Handeingabe bleibt übergeordnet; eine Korrektur ist jederzeit möglich.
 *
 * Seit 2.0.20 zusätzlich:
 *  - Jede Fahrzeugart legt fest, ob sie normalerweise einen Motor hat (änderbar, erbt nach unten).
 *    Das ist nur ein Hinweis: Wer „Abfahrt“ oder „Ablegen“ tippt, ohne dass ein Motor läuft, wird nicht gebremst,
 *    der Eintrag wird gespeichert und oben steht „Kein Motor läuft“.
 *  - Betriebsstunden und Kilometer stehen zusammen in der Anzeige, jeweils mit der Quelle des Stands
 *    (von Hand, Motorschalter, Korrektur, später GPS). GPS ist nie Voraussetzung.
 *
 * Hier steht nur Rechnung und Beschreibung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Bis zu so vielen Motoren hat jeder einen eigenen Schalter in der Leiste. */
  var MAX_EINZELN = 2;
  var MS_STUNDE = 3600 * 1000;

  function runde(n) { return Math.round(n * 100) / 100; }

  /* Betriebsstunden zwischen zwei Zeitpunkten (ISO), auf zwei Stellen gerundet. Null bei Unsinn. */
  function laufStunden(startIso, stoppIso) {
    var a = new Date(startIso).getTime(), b = new Date(stoppIso).getTime();
    if (isNaN(a) || isNaN(b)) return null;
    if (b < a) return null;
    return runde((b - a) / MS_STUNDE);
  }

  /* 1,42 h -> „1 h 25 min“, 0,2 h -> „12 min“ */
  function stundenText(stunden) {
    var min = Math.round(Number(stunden) * 60);
    if (!isFinite(min) || min < 0) return '';
    var h = Math.floor(min / 60), m = min % 60;
    if (h === 0) return m + ' min';
    return h + ' h' + (m ? ' ' + m + ' min' : '');
  }

  /* Dauer in Millisekunden -> Text („1 h 25 min“) */
  function dauerText(ms) { return stundenText(ms / MS_STUNDE); }

  /* Ortszeit (Datum und Uhrzeit, wie im Formular) -> ISO-Zeitpunkt. Null, wenn die Angabe nicht stimmt. */
  function zeitpunktAusOrtszeit(datum, zeit) {
    var d = /^(\d{4})-(\d{2})-(\d{2})$/.exec(datum || ''), z = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(zeit || '');
    if (!d || !z) return null;
    var t = new Date(+d[1], +d[2] - 1, +d[3], +z[1], +z[2], 0, 0);
    if (t.getFullYear() !== +d[1] || t.getMonth() !== +d[2] - 1 || t.getDate() !== +d[3]) return null;
    return t.toISOString();
  }

  function zwei(n) { return (n < 10 ? '0' : '') + n; }
  /* ISO-Zeitpunkt -> Datum (JJJJ-MM-TT) und Uhrzeit (HH:MM) in Ortszeit */
  function ortsdatum(iso) { var t = new Date(iso); return t.getFullYear() + '-' + zwei(t.getMonth() + 1) + '-' + zwei(t.getDate()); }
  function ortszeit(iso) { var t = new Date(iso); return zwei(t.getHours()) + ':' + zwei(t.getMinutes()); }

  /*
   * Wie sieht die untere Leiste des Cockpits aus?
   *  keine:   kein Motor in den Komponenten (kein Schalter)
   *  einzeln: ein bis zwei Motoren, je ein fester Schalter
   *  sammel:  drei oder mehr Motoren, ein Schalter „Motoren“ mit „x von y laufen“
   * motoren: Liste mit dem Feld „laeuft“.
   */
  function leiste(motoren) {
    var liste = motoren || [];
    var laufen = liste.filter(function (m) { return m.laeuft; }).length;
    var modus = !liste.length ? 'keine' : (liste.length <= MAX_EINZELN ? 'einzeln' : 'sammel');
    var text = null;
    if (modus === 'sammel') text = laufen === 0 ? 'keiner läuft' : laufen + ' von ' + liste.length + ' laufen';
    return { modus: modus, laufen: laufen, gesamt: liste.length, text: text };
  }

  /* Beschriftung eines Schalters: Name und „Start“ oder „Stopp“, dazu der Zustand für die Farbe. */
  function schalter(motor) {
    return { name: motor.kurz, aktion: motor.laeuft ? 'Stopp' : 'Start', zustand: motor.laeuft ? 'laeuft' : 'aus' };
  }

  /* Kurznamen, die bei mehreren Motoren eines Fahrzeugs gleich sind (Hinweis, damit Schalter nicht verwechselt werden). */
  function doppelteKurznamen(motoren) {
    var zaehl = {};
    (motoren || []).forEach(function (m) { var k = String(m.kurz).toUpperCase(); zaehl[k] = (zaehl[k] || 0) + 1; });
    return Object.keys(zaehl).filter(function (k) { return zaehl[k] > 1; });
  }

  /* ---------- Hat die Fahrzeugart einen Motor? (seit 2.0.20) ---------- */
  /*
   * Mitgelieferte Voreinstellung je Art (nur eine Starthilfe, der Nutzer ändert sie je Art).
   * Gespeichert wird nur, was der Nutzer selbst einstellt: { artId: 'ja' | 'nein' }.
   * Es gilt der Wert der Art selbst, sonst der nächsten Obergruppe, bei der der Nutzer etwas eingestellt hat.
   * Hat er auf dem ganzen Weg nach oben nichts eingestellt, gilt die mitgelieferte Voreinstellung der Art oder
   * der nächsten Obergruppe, sonst „ja“.
   */
  var MOTOR_STANDARD = {
    land: 'ja', wasser: 'ja', luft: 'ja',
    auto: 'ja', motorrad: 'ja', wohnmobil: 'ja', wohnwagen: 'nein', oldtimer: 'ja',
    boot: 'ja', sportboot: 'ja', wasserskiboot: 'ja', wohnboot: 'ja', motorschiff: 'ja',
    segelboot: 'ja', 'segelboot-jolle': 'nein', flugzeug: 'ja'
  };

  function istJaNein(w) { return w === 'ja' || w === 'nein'; }

  /*
   * dokument: { werte: { artId: 'ja'|'nein' } } oder null.
   * Ergebnis: { hat, von, eigene, standard }
   *   hat      true oder false
   *   von      Kennung der Art, deren Einstellung gilt (null, wenn nur die allgemeine Voreinstellung „ja“ gilt)
   *   eigene   der Nutzer hat bei dieser Art selbst etwas eingestellt
   *   standard der Wert kommt aus der mitgelieferten Voreinstellung (nichts vom Nutzer eingestellt)
   */
  function motorArt(dokument, artId) {
    var werte = (dokument && dokument.werte) || {};
    var weg = MM.Fahrzeugarten.vorfahren(artId);
    var i;
    for (i = 0; i < weg.length; i++) {
      if (istJaNein(werte[weg[i]])) return { hat: werte[weg[i]] === 'ja', von: weg[i], eigene: i === 0, standard: false };
    }
    for (i = 0; i < weg.length; i++) {
      if (istJaNein(MOTOR_STANDARD[weg[i]])) return { hat: MOTOR_STANDARD[weg[i]] === 'ja', von: weg[i], eigene: false, standard: true };
    }
    return { hat: true, von: null, eigene: false, standard: true };
  }

  /* Neues Dokument mit der Einstellung für diese Art (wert 'ja' oder 'nein'); 'zurueck' nimmt sie wieder weg. */
  function motorDokumentSetzen(dokument, artId, wert) {
    var neu = { id: 'fahrzeugart-motor', werte: Object.assign({}, (dokument && dokument.werte) || {}) };
    if (istJaNein(wert)) neu.werte[artId] = wert; else delete neu.werte[artId];
    return neu;
  }

  /* Ereignisse, bei denen die App auf den Motor hinweist (Name der Ereignisart, Groß- und Kleinschreibung egal). */
  var HINWEIS_EREIGNISSE = ['abfahrt', 'ablegen'];
  var HINWEIS_KEIN_MOTOR = 'Kein Motor läuft';

  /*
   * Der Hinweis, den das Cockpit nach „Abfahrt“ oder „Ablegen“ zeigt. Null, wenn kein Hinweis nötig ist.
   * Er sperrt nichts und fragt nichts: Der Eintrag ist da schon gespeichert. Ein Wasserfahrzeug kann auch ohne Motor
   * ablegen und treiben, die Verantwortung bleibt beim Fahrer.
   *  hatMotor: Ergebnis von motorArt(...).hat; motoren: Liste wie daten.motorenListe (Feld „laeuft“)
   */
  function motorHinweis(hatMotor, ereignisName, motoren) {
    if (!hatMotor) return null;
    var n = String(ereignisName || '').trim().toLowerCase();
    if (HINWEIS_EREIGNISSE.indexOf(n) < 0) return null;
    var laeuft = (motoren || []).some(function (m) { return m.laeuft; });
    return laeuft ? null : HINWEIS_KEIN_MOTOR;
  }

  /* ---------- Beide Zähler in der Anzeige (seit 2.0.20) ---------- */
  /* Woher kommt ein Zählerstand? kurz für die Statuszeile, lang für die Zählerseite. */
  var QUELLEN = {
    hand: { kurz: 'Hand', lang: 'per Handeingabe' },
    schalter: { kurz: 'Schalter', lang: 'vom Motorschalter gerechnet' },
    korrektur: { kurz: 'Korrektur', lang: 'nach Korrektur der Stoppzeit' },
    gps: { kurz: 'GPS', lang: 'per GPS' }
  };
  function quelleText(quelle, lang) {
    var q = QUELLEN[quelle] || QUELLEN.hand;
    return lang ? q.lang : q.kurz;
  }

  /*
   * Die Zähler für die Anzeige: ein Eintrag je Motor mit Betriebsstunden, dazu die Kilometer.
   *  motoren: daten.motorenListe; strecke: daten.streckenZaehler (oder null); welt: Welt des Fahrzeugs
   * Jeder Eintrag: { art: 'stunden'|'strecke', name, wert, einheit, datum, quelle, leer }
   *  leer = es gibt keinen Stand (dann ist wert null)
   * Kilometer stehen bei Landfahrzeugen immer da (auch ohne Zähler, dann mit leer), sonst nur, wenn es einen Zähler gibt.
   * Betriebsstunden stehen nur bei Fahrzeugen mit Motor in den Komponenten.
   */
  function zaehlerAnzeige(motoren, strecke, welt) {
    var liste = [];
    var mitStand = 0;
    (motoren || []).forEach(function (m) {
      if (m.zaehler && m.zaehler.stand) {
        mitStand++;
        liste.push({ art: 'stunden', name: m.kurz, wert: m.zaehler.stand.wert, einheit: m.zaehler.einheit || 'h',
          datum: m.zaehler.stand.datum, quelle: m.zaehler.stand.quelle || 'hand', leer: false });
      }
    });
    if ((motoren || []).length && !mitStand) liste.push({ art: 'stunden', name: 'Betriebsstunden', wert: null, einheit: 'h', datum: null, quelle: null, leer: true });
    if (strecke && strecke.stand) {
      liste.push({ art: 'strecke', name: 'Kilometer', wert: strecke.stand.wert, einheit: strecke.einheit || 'km',
        datum: strecke.stand.datum, quelle: strecke.stand.quelle || 'hand', leer: false });
    } else if (strecke || welt === 'land') {
      liste.push({ art: 'strecke', name: 'Kilometer', wert: null, einheit: 'km', datum: null, quelle: null, leer: true });
    }
    return liste;
  }

  MM.Motoren = {
    MOTOR_STANDARD: MOTOR_STANDARD,
    HINWEIS_KEIN_MOTOR: HINWEIS_KEIN_MOTOR,
    motorArt: motorArt,
    motorDokumentSetzen: motorDokumentSetzen,
    motorHinweis: motorHinweis,
    quelleText: quelleText,
    zaehlerAnzeige: zaehlerAnzeige,
    MAX_EINZELN: MAX_EINZELN,
    laufStunden: laufStunden,
    stundenText: stundenText,
    dauerText: dauerText,
    zeitpunktAusOrtszeit: zeitpunktAusOrtszeit,
    ortsdatum: ortsdatum,
    ortszeit: ortszeit,
    leiste: leiste,
    schalter: schalter,
    doppelteKurznamen: doppelteKurznamen,
    runde: runde
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
