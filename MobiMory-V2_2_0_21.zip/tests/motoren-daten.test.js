'use strict';
/* 2.0.19: Motorschalter mit Speicher: Start, Stopp, Betriebsstunden, Korrektur, Kurzname, Sicherung. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;

/* Uhr von Hand stellbar (Ortszeit), jeder Aufruf eine Millisekunde später. */
function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 4, 9, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (jahr, monat, tag, std, min) => { uhr.ms = new Date(jahr, monat - 1, tag, std, min, 0).getTime(); t = 0; };
  return d;
}
async function katamaran() {
  const d = neueDaten();
  await d.starten();
  const fz = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Kat' })).id;
  const stb = (await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Motor Steuerbord' })).id;
  const bb = (await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Motor Backbord' })).id;
  const getriebe = (await d.komponenteAnlegen(fz, null, 'getriebe', { bezeichnung: 'Getriebe' })).id;
  return { d, fz, stb, bb, getriebe };
}
const zeiten = (l) => l.map(x => x.name);
const motorVon = async (d, fz, id) => (await d.motorenListe(fz)).find(x => x.komponenteId === id);

test('Die Motorliste enthält nur Hauptkomponenten der Art Motor, mit Kurzname', async () => {
  const { d, fz } = await katamaran();
  const liste = await d.motorenListe(fz);
  assert.deepEqual(zeiten(liste).sort(), ['Motor Backbord', 'Motor Steuerbord']);
  const stb = liste.find(x => x.name === 'Motor Steuerbord');
  assert.equal(stb.kurz, 'MOSTB');
  assert.equal(stb.kurzname, null);
  assert.equal(stb.laeuft, false);
  assert.equal(stb.zaehler, null, 'der Zähler entsteht erst beim ersten Start');
});

test('Ohne Motor in den Komponenten gibt es keinen Schalter', async () => {
  const d = neueDaten(); await d.starten();
  const fz = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'WoMo' })).id;
  await d.komponenteAnlegen(fz, null, 'getriebe', { bezeichnung: 'Getriebe' });
  assert.deepEqual(await d.motorenListe(fz), []);
});

test('Start: der Motor läuft, der Zähler „Betriebsstunden“ entsteht am Motor, ein zweiter Start wird abgelehnt', async () => {
  const { d, fz, stb } = await katamaran();
  const r = await d.motorStart(stb);
  assert.ok(r.ok);
  const m = (await d.motorenListe(fz)).find(x => x.komponenteId === stb);
  assert.equal(m.laeuft, true);
  assert.equal(m.seit, r.start);
  assert.equal(m.zaehler.einheit, 'h');
  const zl = await d.zaehlerListe(fz);
  assert.equal(zl.length, 1);
  assert.equal(zl[0].bezeichnung, 'Betriebsstunden');
  assert.equal(zl[0].komponenteId, stb);
  assert.equal(zl[0].art, 'stunden');
  const nochmal = await d.motorStart(stb);
  assert.equal(nochmal.ok, false);
  assert.match(nochmal.fehler.allgemein, /läuft schon/);
});

test('Nur ein Motor lässt sich schalten, kein Getriebe und keine unbekannte Komponente', async () => {
  const { d, getriebe } = await katamaran();
  assert.equal((await d.motorStart(getriebe)).ok, false);
  assert.equal((await d.motorStart('gibt-es-nicht')).ok, false);
  assert.equal((await d.motorStopp(getriebe)).ok, false);
});

test('Stopp ohne Start wird abgelehnt', async () => {
  const { d, stb } = await katamaran();
  const r = await d.motorStopp(stb);
  assert.equal(r.ok, false);
  assert.match(r.fehler.allgemein, /läuft nicht/);
});

test('Stopp rechnet Startstand plus Laufzeit, der alte Stand bleibt im Verlauf', async () => {
  const { d, fz, stb } = await katamaran();
  const z = (await d.zaehlerAnlegen(fz, stb, 'stunden', { bezeichnung: 'Betriebsstunden' })).id;
  await d.zaehlerStandEintragen(z, { wert: '1000', datum: '2026-11-01' });
  d.stelle(2026, 11, 4, 10, 0);
  await d.motorStart(stb);
  d.stelle(2026, 11, 4, 11, 30);
  const r = await d.motorStopp(stb);
  assert.ok(r.ok);
  assert.equal(r.stunden, 1.5);
  assert.equal(r.stand, 1001.5);
  assert.equal(r.ohneStartstand, false);
  const info = await d.zaehlerLaden(z);
  assert.equal(info.stand.wert, 1001.5);
  assert.equal(info.stand.quelle, 'schalter');
  assert.equal(info.stand.datum, '2026-11-04');
  assert.equal(info.staende.length, 2, 'der Handstand von vorher bleibt sichtbar');
  assert.equal(info.staende[1].wert, 1000);
  const m = (await d.motorenListe(fz)).find(x => x.komponenteId === stb);
  assert.equal(m.laeuft, false);
  assert.equal(m.laeufe.length, 1);
  assert.equal(m.laeufe[0].stunden, 1.5);
  assert.equal(m.laeufe[0].standNachher, 1001.5);
  assert.equal(m.zaehler.id, z, 'ein vorhandener Zähler wird benutzt, es entsteht keiner zusätzlich');
  assert.equal((await d.zaehlerListe(fz)).length, 1);
});

test('Ohne Startstand zählt der Zähler ab 0 und die App sagt es', async () => {
  const { d, stb } = await katamaran();
  d.stelle(2026, 11, 4, 10, 0);
  await d.motorStart(stb);
  d.stelle(2026, 11, 4, 10, 45);
  const r = await d.motorStopp(stb);
  assert.equal(r.stand, 0.75);
  assert.equal(r.ohneStartstand, true);
});

test('Jeder Motor hat seinen eigenen Schalter und Zähler, sie laufen zeitversetzt', async () => {
  const { d, fz, stb, bb } = await katamaran();
  d.stelle(2026, 11, 4, 10, 0);
  await d.motorStart(stb);
  d.stelle(2026, 11, 4, 10, 1);
  await d.motorStart(bb);
  let liste = await d.motorenListe(fz);
  assert.deepEqual(liste.map(x => x.laeuft), [true, true]);
  d.stelle(2026, 11, 4, 12, 0);
  await d.motorStopp(stb);
  liste = await d.motorenListe(fz);
  assert.equal(liste.find(x => x.komponenteId === stb).laeuft, false);
  assert.equal(liste.find(x => x.komponenteId === bb).laeuft, true);
  d.stelle(2026, 11, 4, 12, 1);
  await d.motorStopp(bb);
  liste = await d.motorenListe(fz);
  assert.equal(liste.find(x => x.komponenteId === stb).zaehler.stand.wert, 2);
  assert.equal(liste.find(x => x.komponenteId === bb).zaehler.stand.wert, 2);
  assert.notEqual(liste[0].zaehler.id, liste[1].zaehler.id);
  assert.equal((await d.zaehlerListe(fz)).length, 2);
});

test('Handeingabe hat Vorrang: ein während des Laufs eingetragener Stand ist die Grundlage', async () => {
  const { d, fz, stb } = await katamaran();
  d.stelle(2026, 11, 4, 10, 0);
  await d.motorStart(stb);
  const z = (await motorVon(d, fz, stb)).zaehler.id;
  await d.zaehlerStandEintragen(z, { wert: '500', datum: '2026-11-04' });
  d.stelle(2026, 11, 4, 11, 0);
  const r = await d.motorStopp(stb);
  assert.equal(r.stand, 501);
});

test('Ein ausgebauter Motor hat keinen Schalter, außer er läuft noch', async () => {
  const { d, fz, stb, bb } = await katamaran();
  d.stelle(2026, 11, 4, 10, 0);
  await d.motorStart(stb);
  const c = await d.komponenteLaden(stb);
  await d.komponenteAendern(stb, Object.assign({}, c.aktuell.werte, { ausgebautAm: '2026-11-04' }));
  const c2 = await d.komponenteLaden(bb);
  await d.komponenteAendern(bb, Object.assign({}, c2.aktuell.werte, { ausgebautAm: '2026-11-04' }));
  const liste = await d.motorenListe(fz);
  assert.deepEqual(zeiten(liste), ['Motor Steuerbord'], 'der laufende Motor bleibt stoppbar');
  assert.equal((await d.motorStart(bb)).ok, false);
});

test('Fristen rechnen mit dem Stand aus dem Motorschalter', async () => {
  const { d, fz, stb } = await katamaran();
  const z = (await d.zaehlerAnlegen(fz, stb, 'stunden', { bezeichnung: 'Betriebsstunden' })).id;
  await d.zaehlerStandEintragen(z, { wert: '95', datum: '2026-11-01' });
  await d.fristAnlegen(fz, stb, { bezeichnung: 'Ölwechsel', kategorie: 'wartung', zaehlerId: z, zaehlerWert: '100', zuletztStand: '0', zuletztAm: '2026-01-01' });
  d.stelle(2026, 11, 4, 8, 0);
  await d.motorStart(stb);
  d.stelle(2026, 11, 4, 14, 0);
  await d.motorStopp(stb);
  const f = (await d.fristenListe(fz))[0];
  assert.equal(f.zaehler.stand.wert, 101);
  assert.equal(f.status.zaehler.status, 'ueberfaellig');
});

test('Stoppzeit korrigieren: vergessenes Stoppen, der Zähler wird neu gerechnet, der alte Stand bleibt sichtbar', async () => {
  const { d, fz, stb } = await katamaran();
  const z = (await d.zaehlerAnlegen(fz, stb, 'stunden', { bezeichnung: 'Betriebsstunden' })).id;
  await d.zaehlerStandEintragen(z, { wert: '200', datum: '2026-11-01' });
  d.stelle(2026, 11, 4, 8, 0);
  await d.motorStart(stb);
  d.stelle(2026, 11, 4, 20, 0);          /* Stoppen vergessen, erst am Abend gemerkt */
  const stopp = await d.motorStopp(stb);
  assert.equal(stopp.stand, 212);
  const lauf = (await motorVon(d, fz, stb)).laeufe[0];
  assert.equal(lauf.korrigierbar, true);
  d.stelle(2026, 11, 4, 20, 5);
  const r = await d.motorLaufKorrigieren(lauf.id, { datum: '2026-11-04', zeit: '10:30' });
  assert.ok(r.ok); assert.equal(r.geaendert, true);
  assert.equal(r.stunden, 2.5);
  assert.equal(r.stand, 202.5);
  const info = await d.zaehlerLaden(z);
  assert.equal(info.stand.wert, 202.5);
  assert.equal(info.stand.quelle, 'korrektur');
  assert.deepEqual(info.staende.map(s => s.wert), [202.5, 212, 200], 'nichts wird überschrieben');
  const nach = (await motorVon(d, fz, stb)).laeufe[0];
  assert.equal(nach.stunden, 2.5);
  assert.equal(nach.korrigiert, true);
  assert.equal(MM.Motoren.ortszeit(nach.stopp), '10:30');
});

test('Stoppzeit korrigieren: falsche Angaben werden abgelehnt, nichts wird verändert', async () => {
  const { d, fz, stb } = await katamaran();
  d.stelle(2026, 11, 4, 8, 0);
  await d.motorStart(stb);
  d.stelle(2026, 11, 4, 10, 0);
  await d.motorStopp(stb);
  const lauf = (await motorVon(d, fz, stb)).laeufe[0];
  d.stelle(2026, 11, 4, 10, 5);
  const vorStart = await d.motorLaufKorrigieren(lauf.id, { datum: '2026-11-04', zeit: '07:00' });
  assert.equal(vorStart.ok, false); assert.match(vorStart.fehler.zeit, /vor dem Start/);
  const zukunft = await d.motorLaufKorrigieren(lauf.id, { datum: '2026-11-04', zeit: '18:00' });
  assert.equal(zukunft.ok, false); assert.match(zukunft.fehler.zeit, /Zukunft/);
  const leer = await d.motorLaufKorrigieren(lauf.id, { datum: '', zeit: '' });
  assert.equal(leer.ok, false); assert.ok(leer.fehler.zeit);
  const gleich = await d.motorLaufKorrigieren(lauf.id, { datum: '2026-11-04', zeit: '10:00' });
  assert.ok(gleich.ok); assert.equal(gleich.geaendert, false);
  assert.equal((await d.motorLaufKorrigieren('gibt-es-nicht', { datum: '2026-11-04', zeit: '09:00' })).ok, false);
  const m = await motorVon(d, fz, stb);
  assert.equal(m.laeufe[0].stunden, 2);
  assert.equal(m.zaehler.stand.wert, 2);
});

test('Stoppzeit korrigieren: nicht mehr möglich, wenn der Zählerstand danach von Hand geändert wurde', async () => {
  const { d, fz, stb } = await katamaran();
  d.stelle(2026, 11, 4, 8, 0);
  await d.motorStart(stb);
  d.stelle(2026, 11, 4, 12, 0);
  await d.motorStopp(stb);
  const m = await motorVon(d, fz, stb);
  await d.zaehlerStandEintragen(m.zaehler.id, { wert: '50', datum: '2026-11-04' });
  const nach = (await motorVon(d, fz, stb)).laeufe[0];
  assert.equal(nach.korrigierbar, false);
  d.stelle(2026, 11, 4, 12, 5);
  const r = await d.motorLaufKorrigieren(nach.id, { datum: '2026-11-04', zeit: '10:00' });
  assert.equal(r.ok, false);
  assert.match(r.fehler.allgemein, /von Hand/);
});

test('Stoppzeit korrigieren: nur der letzte Lauf eines Motors, ein laufender Motor nicht', async () => {
  const { d, fz, stb } = await katamaran();
  d.stelle(2026, 11, 4, 8, 0); await d.motorStart(stb);
  d.stelle(2026, 11, 4, 9, 0); await d.motorStopp(stb);
  d.stelle(2026, 11, 4, 10, 0); await d.motorStart(stb);
  d.stelle(2026, 11, 4, 11, 0);
  let liste = await motorVon(d, fz, stb);
  assert.equal(liste.laeufe[0] ? liste.laeufe[0].korrigierbar : false, false, 'solange ein Lauf offen ist, nichts korrigieren');
  assert.equal((await d.motorLaufKorrigieren(liste.laeufe[0].id, { datum: '2026-11-04', zeit: '08:30' })).ok, false);
  await d.motorStopp(stb);
  liste = await motorVon(d, fz, stb);
  assert.equal(liste.laeufe.length, 2);
  assert.equal(liste.laeufe[0].korrigierbar, true);
  assert.equal(liste.laeufe[1].korrigierbar, false);
  d.stelle(2026, 11, 4, 11, 5);
  const alt = await d.motorLaufKorrigieren(liste.laeufe[1].id, { datum: '2026-11-04', zeit: '08:30' });
  assert.equal(alt.ok, false);
  assert.match(alt.fehler.allgemein, /letzte Lauf/);
});

test('Kurzname: höchstens 8 Zeichen, gleicher Kurzname bei zwei Motoren wird abgelehnt', async () => {
  const { d, fz, stb, bb } = await katamaran();
  const lang = await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Hilfsmotor', kurzname: 'ZWÖLFZEICHEN' });
  assert.equal(lang.ok, false); assert.match(lang.fehler.kurzname, /höchstens 8/);
  const ok = await d.komponenteAendern(stb, Object.assign({}, (await d.komponenteLaden(stb)).aktuell.werte, { kurzname: 'SB' }));
  assert.ok(ok.ok);
  const doppelt = await d.komponenteAendern(bb, Object.assign({}, (await d.komponenteLaden(bb)).aktuell.werte, { kurzname: 'sb' }));
  assert.equal(doppelt.ok, false); assert.match(doppelt.fehler.kurzname, /schon den Kurznamen SB/);
  const neu = await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Hilfsmotor', kurzname: 'SB' });
  assert.equal(neu.ok, false);
  const liste = await d.motorenListe(fz);
  assert.equal(liste.find(x => x.komponenteId === stb).kurz, 'SB');
  assert.equal(liste.find(x => x.komponenteId === bb).kurz, 'MOBB');
});

test('Kurzname gilt nur bei Motoren als Schalterbeschriftung, andere Komponenten dürfen ihn ebenfalls haben', async () => {
  const { d, fz, getriebe } = await katamaran();
  const r = await d.komponenteAendern(getriebe, Object.assign({}, (await d.komponenteLaden(getriebe)).aktuell.werte, { kurzname: 'GTR' }));
  assert.ok(r.ok);
  assert.equal((await d.komponenteLaden(getriebe)).aktuell.werte.kurzname, 'GTR');
  assert.deepEqual((await d.motorenListe(fz)).map(x => x.kurz).sort(), ['MOBB', 'MOSTB']);
});

test('Die Läufe sind in der Sicherung und kommen beim Einspielen wieder', async () => {
  const { d, fz, stb } = await katamaran();
  d.stelle(2026, 11, 4, 8, 0); await d.motorStart(stb);
  d.stelle(2026, 11, 4, 9, 30); await d.motorStopp(stb);
  d.stelle(2026, 11, 4, 10, 0); await d.motorStart(stb);
  const s = await d.sicherungErzeugen({ mitDateien: false });
  const b = neueDaten();
  await b.starten();
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  const m = (await b.motorenListe(fz)).find(x => x.komponenteId === stb);
  assert.equal(m.laeuft, true, 'der laufende Motor läuft auch nach dem Einspielen');
  assert.equal(m.laeufe.length, 1);
  assert.equal(m.laeufe[0].stunden, 1.5);
  assert.equal(m.zaehler.stand.wert, 1.5);
});
