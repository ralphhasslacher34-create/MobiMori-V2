'use strict';
/* 2.0.21: Position bei Ereignissen (GPS oder von Hand), Ortsnamen lernen, Gerät. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;
const L = MM.Logbuch;

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 3, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (jahr, monat, tag, std, min) => { uhr.ms = new Date(jahr, monat - 1, tag, std, min, 0).getTime(); t = 0; };
  return d;
}
async function mitAktivitaet(d) {
  d = d || neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: boot, vonDatum: '2026-11-03', vonZeit: '09:00', bisDatum: '2026-11-05', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok, JSON.stringify(r));
  return { d, id: r.id };
}
async function notizArt(c) {
  await c.d.ereignisartenAusVorschlaegen();
  return (await c.d.ereignisartenListe()).find(a => a.aktuell.werte.bezeichnung === 'Notiz').objekt.id;
}
const ereignisse = async (c) => (await c.d.logbuchLaden(c.id)).abschnitte.flatMap(t => t.ereignisse);
const GAMSHEIM = { breite: 48.69, laenge: 7.88 };

/* ---------- Rechnen ---------- */

test('Koordinaten lesen: Dezimalgrad mit Komma oder Punkt, S und W mit Minus oder Buchstabe, Fehler mit Hilfe', () => {
  assert.deepEqual(L.koordinateLesen('48,8566', 'breite'), { wert: 48.8566 });
  assert.deepEqual(L.koordinateLesen(' 48.8566° ', 'breite'), { wert: 48.8566 });
  assert.deepEqual(L.koordinateLesen('-33,9', 'breite'), { wert: -33.9 });
  assert.deepEqual(L.koordinateLesen('33,9 S', 'breite'), { wert: -33.9 });
  assert.deepEqual(L.koordinateLesen('N 48,5', 'breite'), { wert: 48.5 });
  assert.deepEqual(L.koordinateLesen('2,35 W', 'laenge'), { wert: -2.35 });
  assert.deepEqual(L.koordinateLesen('7,88 O', 'laenge'), { wert: 7.88 });
  assert.deepEqual(L.koordinateLesen('7,88 E', 'laenge'), { wert: 7.88 });
  assert.deepEqual(L.koordinateLesen(-122.4, 'laenge'), { wert: -122.4 });
  assert.deepEqual(L.koordinateLesen('', 'laenge'), { leer: true });
  assert.deepEqual(L.koordinateLesen(null, 'laenge'), { leer: true });
  assert.deepEqual(L.koordinateLesen('  ', 'breite'), { leer: true });
  [['abc', 'breite'], ['48,8,5', 'breite'], ['91', 'breite'], ['-91', 'breite'], ['48 O', 'breite'], ['7 N', 'laenge'], ['-3 W', 'laenge'], ['12 S N', 'breite'], ['NaN', 'breite']].forEach(([x, art]) => {
    assert.ok(L.koordinateLesen(x, art).fehler, 'sollte ein Fehler sein: ' + x + ' als ' + art);
  });
  assert.ok(L.koordinateLesen('181', 'laenge').fehler);
  assert.ok(L.koordinateLesen(NaN, 'breite').fehler);
  assert.equal(L.koordinateLesen('180', 'laenge').wert, 180);
});

test('Position prüfen: Breite und Länge gehören zusammen; Herkunft GPS nur, wenn die Zahlen noch die vom GPS sind', () => {
  assert.deepEqual(L.positionPruefen({}).fehler, {});
  assert.equal(L.positionPruefen({}).werte.breite, null);
  assert.ok(L.positionPruefen({ breite: '48,5' }).fehler.laenge);
  assert.ok(L.positionPruefen({ laenge: '7,5' }).fehler.breite);
  assert.ok(L.positionPruefen({ breite: 'x', laenge: '7' }).fehler.breite);
  const hand = L.positionPruefen({ breite: '48,69', laenge: '7,88' }).werte;
  assert.equal(hand.positionQuelle, 'hand'); assert.equal(hand.positionGenauigkeit, null);
  const gps = L.positionPruefen({ breite: '48,69000', laenge: '7,88', gpsBreite: 48.69, gpsLaenge: 7.88, gpsGenauigkeit: 12.4 }).werte;
  assert.equal(gps.positionQuelle, 'gps'); assert.equal(gps.positionGenauigkeit, 12); assert.equal(gps.breite, 48.69);
  const geaendert = L.positionPruefen({ breite: '48,7', laenge: '7,88', gpsBreite: 48.69, gpsLaenge: 7.88, gpsGenauigkeit: 12 }).werte;
  assert.equal(geaendert.positionQuelle, 'hand', 'Handeingabe hat Vorrang'); assert.equal(geaendert.positionGenauigkeit, null);
  const n = L.positionPruefen({ ortName: '  Schleuse   Gamsheim ' }).werte;
  assert.equal(n.ortName, 'Schleuse Gamsheim'); assert.equal(n.ortNameQuelle, 'hand'); assert.equal(n.breite, null);
  assert.equal(L.positionPruefen({ ortName: 'X', ortNameQuelle: 'vorschlag' }).werte.ortNameQuelle, 'vorschlag');
  assert.equal(L.positionPruefen({ ortName: '   ' }).werte.ortName, null);
  assert.ok(L.positionPruefen({ ortName: 'x'.repeat(81) }).fehler.ortName);
});

test('Text, Entfernung und frische GPS-Position', () => {
  assert.equal(L.positionText(48.8566, 2.3522), '48,85660° N, 2,35220° O');
  assert.equal(L.positionText(-33.9, -70.5), '33,90000° S, 70,50000° W');
  assert.equal(L.positionText(null, 2), ''); assert.equal(L.positionText('1', '2'), '');
  assert.equal(Math.round(L.entfernungMeter(48.8566, 2.3522, 48.8606, 2.3376)), 1157);
  assert.equal(L.entfernungMeter(10, 10, 10, 10), 0);
  assert.equal(L.entfernungText(120.4), '120 m'); assert.equal(L.entfernungText(1500), '1,5 km');
  const fix = { breite: 1, laenge: 2, genauigkeit: 5, zeitMs: 1000000 };
  assert.equal(L.gpsFrisch(fix, 1000000 + 60000), fix);
  assert.equal(L.gpsFrisch(fix, 1000000 + L.GPS_FRISCH_MS), fix);
  assert.equal(L.gpsFrisch(fix, 1000000 + L.GPS_FRISCH_MS + 1), null, 'zu alt');
  assert.equal(L.gpsFrisch(fix, 1000000 - 60000), null, 'aus der Zukunft');
  assert.equal(L.gpsFrisch(null, 5), null); assert.equal(L.gpsFrisch({ breite: 1 }, 5), null);
});

test('Ortsnamen: nächster Name im Umfeld; weiter weg gibt es keinen; gleicher Name zählt hoch, neuer Name ergibt neuen Punkt', () => {
  let dok = L.ortLernen(null, 'Schleuse Gamsheim', 48.69, 7.88, 't1');
  assert.equal(dok.id, 'positionsnamen'); assert.equal(dok.punkte.length, 1);
  const nah = L.ortSuchen(dok.punkte, 48.6925, 7.8825);
  assert.equal(nah.name, 'Schleuse Gamsheim'); assert.ok(nah.abstand > 0 && nah.abstand < L.POSITION_RADIUS_M);
  assert.equal(L.ortSuchen(dok.punkte, 48.70, 7.88), null, 'über 1 km weg');
  assert.equal(L.ortSuchen([], 1, 1), null); assert.equal(L.ortSuchen(null, 1, 1), null);
  dok = L.ortLernen(dok, 'schleuse gamsheim', 48.6905, 7.8805, 't2');
  assert.equal(dok.punkte.length, 1, 'gleicher Name im Umfeld: kein neuer Punkt'); assert.equal(dok.punkte[0].n, 2); assert.equal(dok.punkte[0].zuletzt, 't2');
  dok = L.ortLernen(dok, 'Straßburg', 48.5734, 7.7521, 't3');
  dok = L.ortLernen(dok, 'Anleger Nord', 48.6901, 7.8801, 't4');
  assert.equal(dok.punkte.length, 3);
  assert.equal(L.ortSuchen(dok.punkte, 48.6901, 7.8801).name, 'Anleger Nord', 'der nähere Name gewinnt');
  assert.equal(L.ortSuchen(dok.punkte, 48.5735, 7.7522).name, 'Straßburg');
  const alt = JSON.stringify(dok); L.ortLernen(dok, 'Neu', 1, 1, 't5'); assert.equal(JSON.stringify(dok), alt, 'das Dokument wird nicht verändert');
  /* Obergrenze: die am längsten nicht benutzten fallen weg */
  let voll = null;
  for (let i = 0; i < 502; i++) voll = L.ortLernen(voll, 'Ort ' + i, 10 + i * 0.1, 10, 't' + String(i).padStart(4, '0'));
  assert.equal(voll.punkte.length, 500);
  assert.ok(!voll.punkte.some(p => p.name === 'Ort 0') && voll.punkte.some(p => p.name === 'Ort 501'));
});

/* ---------- Speichern ---------- */

test('Schnell-Eintrag mit GPS-Position: Position, Herkunft und Gerät stehen dabei; ohne Position wird trotzdem sofort gespeichert', async () => {
  const c = await mitAktivitaet();
  const r1 = await c.d.ereignisSchnell(c.id, 'Abfahrt', { position: { breite: 48.69, laenge: 7.88, genauigkeit: 8.2 } });
  assert.ok(r1.ok, JSON.stringify(r1)); assert.equal(r1.breite, 48.69); assert.equal(r1.ortName, null);
  const r2 = await c.d.ereignisSchnell(c.id, 'Notiz', { text: 'ohne GPS' });
  assert.ok(r2.ok); assert.equal(r2.breite, null);
  const e = await ereignisse(c);
  const mit = e.find(x => x.id === r1.id), ohne = e.find(x => x.id === r2.id);
  assert.equal(mit.breite, 48.69); assert.equal(mit.laenge, 7.88); assert.equal(mit.positionQuelle, 'gps'); assert.equal(mit.ortName, null);
  assert.equal(ohne.breite, null); assert.equal(ohne.positionQuelle, null);
  const x = await c.d.ereignisLaden(r1.id);
  assert.equal(x.aktuell.werte.positionGenauigkeit, 8);
  assert.equal(x.aktuell.werte.geraetId, await c.d.geraetKennung());
  assert.ok(/^ge-/.test(x.aktuell.werte.geraetId));
  assert.equal(await c.d.geraetKennung(), x.aktuell.werte.geraetId, 'die Kennung bleibt gleich');
});

test('Schnell-Eintrag bei früherer Uhrzeit (Nachtrag) bekommt keine GPS-Position', async () => {
  const c = await mitAktivitaet();
  const r = await c.d.ereignisSchnell(c.id, 'Notiz', { text: 'früher', zeit: '09:30', position: { breite: 48.69, laenge: 7.88, genauigkeit: 5 } });
  assert.ok(r.ok); assert.equal(r.breite, null);
});

test('Ungültige Position im Schnell-Eintrag wird nicht gespeichert, ein Eintrag ohne Position geht immer', async () => {
  const c = await mitAktivitaet();
  const r = await c.d.ereignisSchnell(c.id, 'Notiz', { text: 'x', position: { breite: 95, laenge: 7.88, genauigkeit: 5 } });
  assert.equal(r.ok, false); assert.ok(r.fehler.breite);
  const r2 = await c.d.ereignisSchnell(c.id, 'Notiz', { text: 'x', position: null });
  assert.ok(r2.ok);
});

test('Lernen: Bestätigter Name wird gemerkt; beim nächsten Schnell-Eintrag im Umfeld steht er als Vorschlag dabei, wird aber erst durch Bestätigung gelernt', async () => {
  const c = await mitAktivitaet();
  const tag = (await c.d.heutigerTag(c.id)).abschnittId;
  const art = await notizArt(c);
  assert.deepEqual(await c.d.positionsnamenListe(), []);
  const r1 = await c.d.ereignisAnlegen(tag, { artId: art, datum: '2026-11-03', zeit: '12:00', text: '', breite: '48,69', laenge: '7,88', ortName: 'Schleuse Gamsheim' });
  assert.ok(r1.ok, JSON.stringify(r1));
  let liste = await c.d.positionsnamenListe();
  assert.equal(liste.length, 1); assert.equal(liste[0].name, 'Schleuse Gamsheim'); assert.equal(liste[0].n, 1);
  assert.deepEqual(await c.d.ortNameVorschlag(48.6905, 7.8805), { name: 'Schleuse Gamsheim', abstand: Math.round(L.entfernungMeter(48.6905, 7.8805, 48.69, 7.88)) });
  assert.equal(await c.d.ortNameVorschlag(49, 8), null); assert.equal(await c.d.ortNameVorschlag(null, 8), null);
  const r2 = await c.d.ereignisSchnell(c.id, 'Ankunft', { position: { breite: 48.6905, laenge: 7.8805, genauigkeit: 6 } });
  assert.ok(r2.ok); assert.equal(r2.ortName, 'Schleuse Gamsheim'); assert.equal(r2.ortNameQuelle, 'vorschlag');
  const z = (await ereignisse(c)).find(e => e.id === r2.id);
  assert.equal(z.ortName, 'Schleuse Gamsheim'); assert.equal(z.ortNameQuelle, 'vorschlag');
  liste = await c.d.positionsnamenListe();
  assert.equal(liste[0].n, 1, 'ein Vorschlag allein wird nicht gelernt');
  /* Bestätigen über „Angaben ändern“: der Name gilt dann als vom Nutzer */
  const ae = await c.d.ereignisAendern(r2.id, { artId: z && (await c.d.ereignisLaden(r2.id)).aktuell.werte.artId, datum: z.datum, zeit: z.zeit, text: '', breite: '48,6905', laenge: '7,8805', ortName: 'Schleuse Gamsheim', gpsBreite: 48.6905, gpsLaenge: 7.8805, gpsGenauigkeit: 6 });
  assert.ok(ae.ok, JSON.stringify(ae));
  assert.equal((await c.d.ereignisLaden(r2.id)).aktuell.werte.ortNameQuelle, 'hand');
  assert.equal((await c.d.ereignisLaden(r2.id)).aktuell.werte.positionQuelle, 'gps', 'die Position bleibt GPS, wenn die Zahlen nicht geändert wurden');
  assert.equal((await c.d.positionsnamenListe())[0].n, 2);
});

test('Ohne Namen vom Nutzer: kein Vorschlag, wenn der Ort unbekannt ist; ein bewusst leeres Namensfeld bleibt leer', async () => {
  const c = await mitAktivitaet();
  const tag = (await c.d.heutigerTag(c.id)).abschnittId;
  const art = await notizArt(c);
  await c.d.ereignisAnlegen(tag, { artId: art, datum: '2026-11-03', zeit: '12:00', text: '', breite: '48,69', laenge: '7,88', ortName: 'Anleger' });
  const unbekannt = await c.d.ereignisSchnell(c.id, 'Ankunft', { position: { breite: 50, laenge: 9, genauigkeit: 5 } });
  assert.ok(unbekannt.ok); assert.equal(unbekannt.ortName, null);
  const leer = await c.d.ereignisSchnell(c.id, 'Ankunft', { ortName: '', position: { breite: 48.69, laenge: 7.88, genauigkeit: 5 } });
  assert.ok(leer.ok); assert.equal(leer.ortName, null, 'der Nutzer hat das Feld geleert');
  assert.equal((await c.d.positionsnamenListe()).length, 1);
});

test('Name ohne Position wird gespeichert, aber nicht gelernt; ein anderer Name im Umfeld ergibt einen neuen Punkt, der dann vorgeschlagen wird', async () => {
  const c = await mitAktivitaet();
  const tag = (await c.d.heutigerTag(c.id)).abschnittId;
  const art = await notizArt(c);
  const r = await c.d.ereignisAnlegen(tag, { artId: art, datum: '2026-11-03', zeit: '12:00', text: '', ortName: 'vor der Hafeneinfahrt' });
  assert.ok(r.ok); assert.deepEqual(await c.d.positionsnamenListe(), []);
  assert.equal((await ereignisse(c)).find(e => e.id === r.id).ortName, 'vor der Hafeneinfahrt');
  await c.d.ereignisAnlegen(tag, { artId: art, datum: '2026-11-03', zeit: '12:01', text: '', breite: '48,69', laenge: '7,88', ortName: 'Schleuse Gamsheim' });
  await c.d.ereignisAnlegen(tag, { artId: art, datum: '2026-11-03', zeit: '12:02', text: '', breite: '48,6901', laenge: '7,8801', ortName: 'Wartestelle' });
  assert.equal((await c.d.positionsnamenListe()).length, 2);
  assert.equal((await c.d.ortNameVorschlag(48.6901, 7.8801)).name, 'Wartestelle');
});

test('Position von Hand beim Eintragen und Nachtragen; Fehler sagen, was zu tun ist; nichts wird halb gespeichert', async () => {
  const c = await mitAktivitaet();
  const tag = (await c.d.heutigerTag(c.id)).abschnittId;
  const art = await notizArt(c);
  const vorher = (await ereignisse(c)).length;
  const falsch = await c.d.ereignisAnlegen(tag, { artId: art, datum: '2026-11-03', zeit: '12:00', text: '', breite: '48,69', laenge: '' });
  assert.equal(falsch.ok, false); assert.ok(falsch.fehler.laenge);
  const falsch2 = await c.d.ereignisAnlegen(tag, { artId: art, datum: '2026-11-03', zeit: '12:00', text: '', breite: 'abc', laenge: '7' });
  assert.ok(falsch2.fehler.breite);
  assert.equal((await ereignisse(c)).length, vorher, 'nichts gespeichert');
  assert.deepEqual(await c.d.positionsnamenListe(), []);
  const ok = await c.d.ereignisAnlegen(tag, { artId: art, datum: '2026-11-03', zeit: '10:15', text: 'früher', breite: '33,9 S', laenge: '70,5 W' }, { nachtragen: true });
  assert.ok(ok.ok, JSON.stringify(ok));
  const e = (await c.d.ereignisLaden(ok.id)).aktuell.werte;
  assert.equal(e.breite, -33.9); assert.equal(e.laenge, -70.5); assert.equal(e.positionQuelle, 'hand'); assert.equal(e.nachgetragen, 'ja');
});

test('Ändern: Position von Hand korrigieren; der frühere Stand bleibt im Verlauf; ohne Angabe zur Position bleibt sie unverändert', async () => {
  const c = await mitAktivitaet();
  const r = await c.d.ereignisSchnell(c.id, 'Abfahrt', { position: { breite: 48.69, laenge: 7.88, genauigkeit: 5 } });
  const w = (await c.d.ereignisLaden(r.id)).aktuell.werte;
  const basis = { artId: w.artId, datum: w.datum, zeit: w.zeit, text: 'nur Text' };
  assert.ok((await c.d.ereignisAendern(r.id, basis)).ok);
  const nachText = (await c.d.ereignisLaden(r.id)).aktuell.werte;
  assert.equal(nachText.breite, 48.69); assert.equal(nachText.positionQuelle, 'gps'); assert.equal(nachText.text, 'nur Text');
  const k = await c.d.ereignisAendern(r.id, Object.assign({}, basis, { breite: '48,70', laenge: '7,88', gpsBreite: 48.69, gpsLaenge: 7.88 }));
  assert.ok(k.ok); assert.equal(k.geaendert, true);
  const x = await c.d.ereignisLaden(r.id);
  assert.equal(x.aktuell.werte.breite, 48.7); assert.equal(x.aktuell.werte.positionQuelle, 'hand');
  const letzter = x.verlauf[x.verlauf.length - 1] || x.verlauf[0];
  const keys = x.verlauf.flatMap(v => v.aenderungen.map(u => u.key));
  assert.ok(keys.includes('breite'), 'die Änderung steht im Verlauf: ' + keys.join(','));
  const leeren = await c.d.ereignisAendern(r.id, Object.assign({}, basis, { breite: '', laenge: '' }));
  assert.ok(leeren.ok);
  assert.equal((await c.d.ereignisLaden(r.id)).aktuell.werte.breite, null, 'bewusst leeren geht');
});

test('Gerät: eigene Kennung, nicht in der Sicherung; nach dem Einspielen behält das Gerät seine Kennung, die gelernten Namen kommen mit', async () => {
  const a = await mitAktivitaet();
  const b = neueDaten(); await b.starten();
  const tag = (await a.d.heutigerTag(a.id)).abschnittId;
  const art = await notizArt(a);
  await a.d.ereignisAnlegen(tag, { artId: art, datum: '2026-11-03', zeit: '12:00', text: '', breite: '48,69', laenge: '7,88', ortName: 'Schleuse Gamsheim' });
  const idA = await a.d.geraetKennung(), idB = await b.geraetKennung();
  assert.notEqual(idA, idB);
  const s = await a.d.sicherungErzeugen({ mitDateien: false });
  const gelesen = await b.sicherungLesen(s.bytes, '');
  const ids = gelesen.kopf.tabellen.einstellungen.map(e => e.id);
  assert.ok(!ids.includes('geraet'), 'die Kennung gehört nicht in die Sicherung: ' + ids.join(','));
  assert.ok(ids.includes('positionsnamen'), 'die gelernten Namen gehören in die Sicherung');
  await b.sicherungEinspielen(gelesen);
  assert.equal(await b.geraetKennung(), idB);
  assert.equal((await b.positionsnamenListe())[0].name, 'Schleuse Gamsheim');
  assert.equal((await b.ortNameVorschlag(48.6902, 7.8802)).name, 'Schleuse Gamsheim');
  /* Die Kennung bleibt auch, wenn die Zahl der Knöpfe eingestellt wird */
  assert.ok((await b.geraetKnoepfeSetzen(5)).ok);
  assert.equal(await b.geraetKennung(), idB);
});

test('Texte: Die Neuerungen nennen Position, GPS und Ortsnamen; 2.0.21 steht oben', () => {
  require('../js/texte.js');
  const n = MM.Texte.NEUERUNGEN[0];
  assert.equal(n.version, '2.0.21');
  const alles = n.punkte.join(' ');
  ['Position', 'GPS', 'Ortsname', 'von Hand'].forEach(w => assert.ok(alles.includes(w), w));
});
