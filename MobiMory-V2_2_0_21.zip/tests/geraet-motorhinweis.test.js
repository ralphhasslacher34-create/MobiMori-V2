'use strict';
/* 2.0.20: Motorhinweis je Fahrzeugart, beide Zähler in der Anzeige, Knopfzahl je Gerät. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;
const M = MM.Motoren;
const L = MM.Logbuch;

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 4, 9, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (jahr, monat, tag, std, min) => { uhr.ms = new Date(jahr, monat - 1, tag, std, min, 0).getTime(); t = 0; };
  return d;
}
async function start() { const d = neueDaten(); await d.starten(); return d; }
const namen = l => l.map(x => x.name);

/* ---------- Hat die Fahrzeugart einen Motor? ---------- */

test('Voreinstellung je Art: Auto, Wohnmobil, Boot mit Motor, Wohnwagen und Jolle ohne, eine eigene Art unter Land mit Motor', async () => {
  assert.equal(M.motorArt(null, 'auto').hat, true);
  assert.equal(M.motorArt(null, 'wohnmobil').hat, true);
  assert.equal(M.motorArt(null, 'wasserskiboot').hat, true);
  assert.equal(M.motorArt(null, 'wohnwagen').hat, false);
  assert.equal(M.motorArt(null, 'segelboot-jolle').hat, false);
  const katamaran = M.motorArt(null, 'segelboot-katamaran');
  assert.equal(katamaran.hat, true); assert.equal(katamaran.von, 'segelboot'); assert.equal(katamaran.standard, true); assert.equal(katamaran.eigene, false);
  const d = await start();
  const r = await d.fahrzeugartAnlegen({ name: 'Aufsitzrasenmäher', eltern: 'land' });
  assert.ok(r.ok, JSON.stringify(r));
  const x = await d.fahrzeugartMotor(r.id);
  assert.equal(x.hat, true); assert.equal(x.von, 'land'); assert.equal(x.standard, true);
});

test('Einstellung des Nutzers: gilt für die Art, wird von Untergruppen übernommen, eine eigene Einstellung unten geht vor', async () => {
  const d = await start();
  assert.equal((await d.fahrzeugartMotor('segelboot-katamaran')).hat, true);
  assert.ok((await d.fahrzeugartMotorSetzen('segelboot', 'nein')).ok);
  const kat = await d.fahrzeugartMotor('segelboot-katamaran');
  assert.equal(kat.hat, false); assert.equal(kat.von, 'segelboot'); assert.equal(kat.eigene, false); assert.equal(kat.standard, false);
  assert.equal((await d.fahrzeugartMotor('segelboot')).eigene, true);
  assert.ok((await d.fahrzeugartMotorSetzen('segelboot-katamaran', 'ja')).ok);
  const kat2 = await d.fahrzeugartMotor('segelboot-katamaran');
  assert.equal(kat2.hat, true); assert.equal(kat2.eigene, true);
  assert.equal((await d.fahrzeugartMotor('segelboot-monohull')).hat, false, 'die Nachbar-Untergruppe übernimmt weiter von der Obergruppe');
  /* Der Nutzer ändert eine Obergruppe: sie kommt bei Untergruppen an, die nichts Eigenes haben (auch wenn die Voreinstellung der Untergruppe etwas anderes sagt) */
  assert.ok((await d.fahrzeugartMotorSetzen('wasser', 'nein')).ok);
  assert.equal((await d.fahrzeugartMotor('motorschiff')).hat, false);
  assert.equal((await d.fahrzeugartMotor('auto')).hat, true, 'Land bleibt unverändert');
});

test('Einstellung entfernen: die Art übernimmt wieder die Voreinstellung; Unsinn wird abgelehnt', async () => {
  const d = await start();
  await d.fahrzeugartMotorSetzen('wohnwagen', 'ja');
  assert.equal((await d.fahrzeugartMotor('wohnwagen')).hat, true);
  const z = await d.fahrzeugartMotorZuruecksetzen('wohnwagen');
  assert.ok(z.ok); assert.equal(z.geaendert, true);
  assert.equal((await d.fahrzeugartMotor('wohnwagen')).hat, false);
  assert.equal((await d.fahrzeugartMotorZuruecksetzen('wohnwagen')).geaendert, false);
  assert.equal((await d.fahrzeugartMotorSetzen('wohnwagen', 'vielleicht')).ok, false);
  assert.equal((await d.fahrzeugartMotorSetzen('gibt-es-nicht', 'ja')).ok, false);
});

/* ---------- Der Hinweis „Kein Motor läuft“ ---------- */

test('Hinweis: nur bei Abfahrt oder Ablegen, nur bei einer Art mit Motor, nur wenn kein Motor läuft', () => {
  const aus = [{ laeuft: false }, { laeuft: false }], an = [{ laeuft: false }, { laeuft: true }];
  assert.equal(M.motorHinweis(true, 'Abfahrt', aus), 'Kein Motor läuft');
  assert.equal(M.motorHinweis(true, 'Ablegen', aus), 'Kein Motor läuft');
  assert.equal(M.motorHinweis(true, ' abfahrt ', []), 'Kein Motor läuft', 'auch ohne eingetragenen Motor, Schreibweise egal');
  assert.equal(M.motorHinweis(true, 'Abfahrt', an), null, 'ein Motor läuft');
  assert.equal(M.motorHinweis(false, 'Abfahrt', aus), null, 'die Art hat normalerweise keinen Motor');
  assert.equal(M.motorHinweis(true, 'Ankunft', aus), null);
  assert.equal(M.motorHinweis(true, 'Anlegen', aus), null);
  assert.equal(M.motorHinweis(true, 'Tanken', aus), null);
  assert.equal(M.motorHinweis(true, '', aus), null);
  assert.equal(M.motorHinweis(true, undefined, aus), null);
});

test('Mit Speicher: Wohnmobil mit Motor, erst kein Motor läuft (Hinweis), nach dem Start nicht mehr; das Ereignis lässt sich immer speichern', async () => {
  const d = await start();
  const fz = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'WoMo' })).id;
  const mo = (await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Motor' })).id;
  const art = (await d.fahrzeugartMotor('wohnmobil')).hat;
  assert.equal(M.motorHinweis(art, 'Abfahrt', await d.motorenListe(fz)), 'Kein Motor läuft');
  assert.ok((await d.motorStart(mo)).ok);
  assert.equal(M.motorHinweis(art, 'Abfahrt', await d.motorenListe(fz)), null);
});

/* ---------- Beide Zähler ---------- */

test('Betriebsstunden und Kilometer: Anzeige mit Quelle, Kilometer bei Landfahrzeugen immer, sonst nur mit Zähler', () => {
  const motoren = [
    { kurz: 'MOSTB', zaehler: { stand: { wert: 123.5, datum: '2026-11-04', quelle: 'schalter' }, einheit: 'h' } },
    { kurz: 'MOBB', zaehler: { stand: { wert: 120, datum: '2026-10-01' }, einheit: 'h' } },
    { kurz: 'HILFS', zaehler: null }];
  const strecke = { stand: { wert: 45210, datum: '2026-11-03', quelle: 'hand' }, einheit: 'km' };
  const a = M.zaehlerAnzeige(motoren, strecke, 'land');
  assert.deepEqual(a.map(x => x.name), ['MOSTB', 'MOBB', 'Kilometer']);
  assert.equal(a[0].quelle, 'schalter'); assert.equal(a[1].quelle, 'hand', 'ohne Angabe gilt Hand'); assert.equal(a[2].wert, 45210); assert.equal(a[2].einheit, 'km');
  /* Land ohne Kilometer-Zähler: Eintrag „leer“ */
  const b = M.zaehlerAnzeige([], null, 'land');
  assert.equal(b.length, 1); assert.equal(b[0].art, 'strecke'); assert.equal(b[0].leer, true);
  /* Wasser ohne Kilometer-Zähler: keiner */
  assert.deepEqual(M.zaehlerAnzeige([], null, 'wasser'), []);
  /* Wasser mit Kilometer-Zähler (auch ohne Stand): steht da */
  assert.equal(M.zaehlerAnzeige([], { stand: null, einheit: 'km' }, 'wasser')[0].leer, true);
  /* Motor ohne jeden Stand: ein Eintrag „Betriebsstunden“, leer */
  const c = M.zaehlerAnzeige([{ kurz: 'MO', zaehler: null }], null, 'wasser');
  assert.deepEqual(c.map(x => [x.name, x.leer]), [['Betriebsstunden', true]]);
});

test('Quelle des Stands: kurz und lang, GPS ist als Beschriftung vorbereitet', () => {
  assert.equal(M.quelleText('hand'), 'Hand'); assert.equal(M.quelleText('hand', true), 'per Handeingabe');
  assert.equal(M.quelleText('schalter'), 'Schalter'); assert.equal(M.quelleText('schalter', true), 'vom Motorschalter gerechnet');
  assert.equal(M.quelleText('korrektur', true), 'nach Korrektur der Stoppzeit');
  assert.equal(M.quelleText('gps'), 'GPS');
  assert.equal(M.quelleText(undefined), 'Hand');
});

test('Kilometer-Zähler mit Speicher: keiner, dann mit Stand von Hand; ein Zähler an einer Komponente zählt nicht; der jüngste Stand gewinnt', async () => {
  const d = await start();
  const fz = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'WoMo' })).id;
  assert.equal(await d.streckenZaehler(fz), null);
  const mo = (await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Motor' })).id;
  await d.zaehlerAnlegen(fz, mo, 'strecke', { bezeichnung: 'Motor-Kilometer' });
  assert.equal(await d.streckenZaehler(fz), null, 'am Motor hängt kein Fahrzeug-Zähler');
  const z1 = (await d.zaehlerAnlegen(fz, null, 'strecke', { bezeichnung: 'Kilometerstand' })).id;
  const leer = await d.streckenZaehler(fz);
  assert.equal(leer.id, z1); assert.equal(leer.stand, null); assert.equal(leer.einheit, 'km');
  d.stelle(2026, 11, 3, 10, 0);
  assert.ok((await d.zaehlerStandEintragen(z1, { wert: 45210, datum: '2026-11-03' })).ok);
  const mit = await d.streckenZaehler(fz);
  assert.equal(mit.stand.wert, 45210); assert.equal(mit.stand.datum, '2026-11-03'); assert.equal(mit.stand.quelle, 'hand');
  d.stelle(2026, 11, 4, 9, 0);
  const z2 = (await d.zaehlerAnlegen(fz, null, 'strecke', { bezeichnung: 'Tageskilometer' })).id;
  assert.ok((await d.zaehlerStandEintragen(z2, { wert: 120, datum: '2026-11-04' })).ok);
  assert.equal((await d.streckenZaehler(fz)).id, z2, 'der Zähler mit dem jüngeren Stand');
});

test('Die Betriebsstunden eines Motors nennen die Quelle: Schalter, nach Korrektur, von Hand', async () => {
  const d = await start();
  const fz = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const mo = (await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Motor' })).id;
  d.stelle(2026, 11, 4, 8, 0); await d.motorStart(mo);
  d.stelle(2026, 11, 4, 9, 30); await d.motorStopp(mo);
  let m = (await d.motorenListe(fz))[0];
  assert.equal(m.zaehler.stand.quelle, 'schalter'); assert.equal(m.zaehler.stand.wert, 1.5);
  const lauf = m.laeufe[0].id;
  d.stelle(2026, 11, 4, 9, 45);
  assert.ok((await d.motorLaufKorrigieren(lauf, { datum: '2026-11-04', zeit: '09:00' })).ok);
  m = (await d.motorenListe(fz))[0];
  assert.equal(m.zaehler.stand.quelle, 'korrektur');
  assert.ok((await d.zaehlerStandEintragen(m.zaehler.id, { wert: 10, datum: '2026-11-04' })).ok);
  m = (await d.motorenListe(fz))[0];
  assert.equal(m.zaehler.stand.quelle, 'hand'); assert.equal(m.zaehler.stand.wert, 10);
  const a = M.zaehlerAnzeige([m], null, 'wasser');
  assert.equal(a[0].quelle, 'hand'); assert.equal(a[0].wert, 10);
});

/* ---------- Knopfzahl je Gerät ---------- */

test('Höchstzahl: ganze Zahl von 0 bis 15; Gerät zeigt die ersten Knöpfe, die Reihenfolge bleibt', () => {
  assert.equal(L.MAX_SCHNELL, 15);
  assert.equal(L.SCHNELL_GERAET_STANDARD, 8);
  assert.equal(L.geraetKnoepfeGueltig(0), 0); assert.equal(L.geraetKnoepfeGueltig('15'), 15); assert.equal(L.geraetKnoepfeGueltig(4), 4);
  [16, -1, 2.5, 'abc', '', null, undefined, NaN, Infinity].forEach(x => assert.equal(L.geraetKnoepfeGueltig(x), null, String(x)));
  const k = [1, 2, 3, 4, 5, 6].map(n => ({ key: 'k' + n }));
  assert.deepEqual(L.schnellAufGeraet(k, 4).map(x => x.key), ['k1', 'k2', 'k3', 'k4']);
  assert.equal(L.schnellAufGeraet(k, 0).length, 0);
  assert.equal(L.schnellAufGeraet(k, 15).length, 6);
  assert.equal(L.schnellAufGeraet(k, undefined).length, 6, 'ohne Angabe gilt die Vorgabe 8, es sind nur 6 da');
  assert.equal(L.schnellAufGeraet(new Array(12).fill({ key: 'x' }), undefined).length, 8);
});

async function katamaranMitAlles() {
  const d = await start();
  await d.ereignisartenAusVorschlaegen();
  await d.ereignisartenVorauswahlUebernehmen();
  const art = 'segelboot-katamaran';
  const alle = (await d.schnellknoepfeFuerFahrzeugart(art)).angebot.alle.map(x => x.key);
  return { d, art, alle };
}

test('Belegung bis zu 15 Knöpfe, das Gerät zeigt zunächst 8, der Rest liegt unter „Sonstige Ereignisse“', async () => {
  const { d, art, alle } = await katamaranMitAlles();
  assert.ok(alle.length >= 12, 'genug Angebot für den Test: ' + alle.length);
  const set = await d.schnellknoepfeSetzen(art, alle.slice(0, 12));
  assert.ok(set.ok, JSON.stringify(set)); assert.equal(set.anzahl, 12);
  const i = await d.schnellknoepfeFuerFahrzeugart(art);
  assert.equal(i.knoepfeAlle.length, 12);
  assert.equal(i.knoepfe.length, 8);
  assert.equal(i.geraetMax, 8); assert.equal(i.geraetGesetzt, false); assert.equal(i.versteckt, 4);
  assert.deepEqual(namen(i.knoepfe), namen(i.knoepfeAlle.slice(0, 8)));
  /* die vier nicht gezeigten Knöpfe liegen unter „Sonstige“ (Ereignisse und Funktionen zusammen) */
  const sonstigeKeys = i.sonstige.ereignisse.concat(i.sonstige.funktionen).map(x => x.key);
  i.knoepfeAlle.slice(8).forEach(x => assert.ok(sonstigeKeys.includes(x.key), x.name + ' fehlt unter Sonstige'));
  i.knoepfe.forEach(x => assert.ok(!sonstigeKeys.includes(x.key), x.name + ' darf nicht doppelt vorkommen'));
});

test('Die Einstellung des Geräts ändert, wie viele Knöpfe es zeigt (4, 15, 0); nichts geht verloren; die Belegung bleibt gleich', async () => {
  const { d, art, alle } = await katamaranMitAlles();
  await d.schnellknoepfeSetzen(art, alle.slice(0, 12));
  assert.ok((await d.geraetKnoepfeSetzen(4)).ok);
  let i = await d.schnellknoepfeFuerFahrzeugart(art);
  assert.equal(i.knoepfe.length, 4); assert.equal(i.geraetMax, 4); assert.equal(i.geraetGesetzt, true); assert.equal(i.knoepfeAlle.length, 12);
  assert.equal(i.sonstige.ereignisse.length + i.sonstige.funktionen.length, alle.length - 4, 'alles Übrige ist unter Sonstige zu finden');
  assert.ok((await d.geraetKnoepfeSetzen('15')).ok);
  i = await d.schnellknoepfeFuerFahrzeugart(art);
  assert.equal(i.knoepfe.length, 12); assert.equal(i.versteckt, 0);
  assert.ok((await d.geraetKnoepfeSetzen(0)).ok);
  i = await d.schnellknoepfeFuerFahrzeugart(art);
  assert.equal(i.knoepfe.length, 0); assert.equal(i.knoepfeAlle.length, 12);
  assert.equal(i.sonstige.ereignisse.length + i.sonstige.funktionen.length, alle.length);
  assert.deepEqual(await d.geraetEinstellungen(), { knoepfe: 0, knoepfeGesetzt: true });
});

test('Die Zahl für das Gerät wird geprüft: nichts außer 0 bis 15; ein Fehler ändert nichts', async () => {
  const d = await start();
  await d.geraetKnoepfeSetzen(6);
  for (const schlecht of [16, -1, 2.5, 'abc', '', null]) {
    const r = await d.geraetKnoepfeSetzen(schlecht);
    assert.equal(r.ok, false, String(schlecht)); assert.ok(r.fehler.geraet);
  }
  assert.equal((await d.geraetEinstellungen()).knoepfe, 6);
});

test('Bis zu 15 Knöpfe belegbar, ein 16. wird nicht angenommen (abgeschnitten); doppelte und fremde Einträge werden abgelehnt', async () => {
  const { d, art, alle } = await katamaranMitAlles();
  const mehr = alle.concat(alle.map(k => k + '-x')); /* mehr als 15 Angaben */
  const slots = mehr.slice(0, 15);
  const ok = await d.schnellknoepfeSetzen(art, slots.slice(0, alle.length));
  assert.ok(ok.ok); assert.ok(ok.anzahl <= 15);
  const doppelt = await d.schnellknoepfeSetzen(art, [alle[0], alle[0]]);
  assert.equal(doppelt.ok, false); assert.ok(doppelt.fehler.s2);
  const fremd = await d.schnellknoepfeSetzen(art, ['', '', '', '', '', '', '', '', '', '', '', '', '', '', 'e:gibt-es-nicht']);
  assert.equal(fremd.ok, false); assert.ok(fremd.fehler.s15, 'das 15. Feld gibt es und wird geprüft');
  const zuviel = await d.schnellknoepfeSetzen(art, new Array(16).fill('').map((x, n) => n === 15 ? 'e:gibt-es-nicht' : ''));
  assert.equal(zuviel.ok, true, 'ein 16. Feld gibt es nicht und wird nicht geprüft');
});

/* ---------- Gerät und Sicherung ---------- */

test('Die Einstellungen des Geräts stehen nicht in der Sicherung und werden beim Einspielen nicht überschrieben; die Motor-Einstellung der Art schon', async () => {
  const a = await start(), b = await start();
  await a.fahrzeugAnlegen('boot', { bezeichnung: 'Boot A' });
  await a.geraetKnoepfeSetzen(4);
  await a.fahrzeugartMotorSetzen('boot', 'nein');
  await b.geraetKnoepfeSetzen(12);
  const s = await a.sicherungErzeugen({ mitDateien: false });
  const gelesen = await b.sicherungLesen(s.bytes, '');
  const ids = gelesen.kopf.tabellen.einstellungen.map(e => e.id);
  assert.ok(!ids.includes('geraet'), 'das Gerät gehört nicht in die Sicherung: ' + ids.join(','));
  assert.ok(ids.includes('fahrzeugart-motor'), 'die Einstellung der Art gehört in die Sicherung');
  assert.equal(gelesen.kopf.zaehlung.einstellungen, gelesen.kopf.tabellen.einstellungen.length);
  await b.sicherungEinspielen(gelesen);
  assert.equal((await b.geraetEinstellungen()).knoepfe, 12, 'das Gerät B behält seine Zahl');
  assert.equal((await b.fahrzeugartMotor('boot')).hat, false, 'die Einstellung der Art kommt mit');
});

test('Einspielen einer Sicherung auf einem Gerät ohne eigene Einstellung: es bleibt bei der Vorgabe 8', async () => {
  const a = await start(), b = await start();
  await a.geraetKnoepfeSetzen(3);
  const s = await a.sicherungErzeugen({ mitDateien: false });
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  const e = await b.geraetEinstellungen();
  assert.equal(e.knoepfe, 8); assert.equal(e.knoepfeGesetzt, false);
});

test('Texte: Die Neuerungen von 2.0.20 nennen die drei Punkte', () => {
  require('../js/texte.js');
  const n = MM.Texte.NEUERUNGEN.find(x => x.version === '2.0.20');
  assert.ok(n, '2.0.20 steht in den Neuerungen');
  const alles = n.punkte.join(' ');
  assert.ok(alles.includes('Kein Motor läuft')); assert.ok(alles.includes('Kilometer')); assert.ok(alles.includes('auf diesem Gerät') || alles.includes('je Gerät'));
});
