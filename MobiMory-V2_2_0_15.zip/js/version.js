/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.15';
  MM.STUFE = 'Ereignisse je Fahrzeugart und Logbuch ohne Planung';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
