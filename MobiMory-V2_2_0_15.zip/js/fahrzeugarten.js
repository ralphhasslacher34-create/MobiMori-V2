/*
 * Fahrzeugarten und ihre Felder.
 *
 * Die Felder sind hier als DATEN beschrieben, nicht in der Oberfläche
 * festverdrahtet. So kann später eine vom Nutzer zusammengestellte
 * Fahrzeugart (zum Beispiel ein Monowheel) auf demselben Weg entstehen:
 * Sie ist dann nur eine weitere Liste von Feldern.
 *
 * Schale 1 = Fahrzeugliste (Bezeichnung, Art, Kennung)
 * Schale 2 = Äußere Hülle (alle Felder unten)
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var KRAFTSTOFFE = ['Benzin', 'Diesel', 'Autogas (LPG)', 'Erdgas (CNG)',
    'Elektro', 'Hybrid', 'Wasserstoff', 'Sonstiger'];

  var GRUPPEN = [
    { id: 'fahrzeug', titel: 'Fahrzeug' },
    { id: 'masse', titel: 'Maße' },
    { id: 'gewichte', titel: 'Gewichte' },
    { id: 'antrieb', titel: 'Kraftstoff und Geschwindigkeit' },
    { id: 'strasse', titel: 'Achsen und Maut' }
  ];

  var FELDER = {
    marke: { label: 'Marke', typ: 'text', gruppe: 'fahrzeug' },
    modell: { label: 'Modell', typ: 'text', gruppe: 'fahrzeug' },
    typ: { label: 'Typ', typ: 'text', gruppe: 'fahrzeug' },
    baujahr: { label: 'Baujahr', typ: 'ganzzahl', gruppe: 'fahrzeug', min: 1800 },
    erstzulassung: { label: 'Erstzulassung', typ: 'datum', gruppe: 'fahrzeug' },
    kennzeichen: { label: 'Kennzeichen', typ: 'text', gruppe: 'fahrzeug' },
    registriernummer: { label: 'Registriernummer', typ: 'text', gruppe: 'fahrzeug' },
    fin: { label: 'FIN (Fahrgestellnummer)', typ: 'text', gruppe: 'fahrzeug' },
    hin: { label: 'HIN (Rumpfnummer)', typ: 'text', gruppe: 'fahrzeug' },

    laenge: { label: 'Länge', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    breite: { label: 'Breite', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    hoehe: { label: 'Höhe', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    tiefgang: { label: 'Tiefgang', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    durchfahrtshoehe: { label: 'Durchfahrtshöhe', typ: 'zahl', einheit: 'm', gruppe: 'masse',
      hilfe: 'Höhe über dem Wasser, wichtig für Brücken' },

    leergewicht: { label: 'Leergewicht', typ: 'zahl', einheit: 'kg', gruppe: 'gewichte' },
    gesamtgewicht: { label: 'Zulässiges Gesamtgewicht', typ: 'zahl', einheit: 'kg', gruppe: 'gewichte' },

    kraftstoff: { label: 'Kraftstoff', typ: 'auswahl', optionen: KRAFTSTOFFE, gruppe: 'antrieb' },
    hoechstgeschwindigkeit: { label: 'Höchstgeschwindigkeit', typ: 'zahl', einheit: 'km/h', gruppe: 'antrieb' },
    reisegeschwindigkeit: { label: 'Reisegeschwindigkeit', typ: 'zahl', einheit: 'km/h', gruppe: 'antrieb',
      hilfe: 'Deine übliche Geschwindigkeit unterwegs' },

    achsen: { label: 'Achsen', typ: 'ganzzahl', gruppe: 'strasse', min: 1, max: 10 },
    mautklasse: { label: 'Mautklasse', typ: 'text', gruppe: 'strasse' }
  };

  var LAND = ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin',
    'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
    'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit', 'achsen', 'mautklasse'];

  var BOOT = ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'registriernummer', 'hin',
    'laenge', 'breite', 'tiefgang', 'durchfahrtshoehe', 'leergewicht', 'gesamtgewicht',
    'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit'];

  /*
   * Der Baum der Fahrzeugarten (seit 2.0.15).
   *  - GRUPPEN_KNOTEN sind nur Ordnung (Land, Wasser, Luft), kein Fahrzeug hat so eine Art.
   *  - Jede Art hat ein „eltern“. Die Wurzel heißt 'alle'.
   *  - Gespeichert wird an einem Fahrzeug weiter nur die Art-Kennung. Alte Fahrzeuge
   *    (zum Beispiel 'boot') bleiben unverändert gültig und stehen im Baum an ihrer Stelle.
   */
  var WURZEL = 'alle';
  var GRUPPEN_KNOTEN = [
    { id: 'land', name: 'Landfahrzeug', welt: 'land', eltern: WURZEL, felder: [], gruppe: true },
    { id: 'wasser', name: 'Wasserfahrzeug', welt: 'wasser', eltern: WURZEL, felder: [], gruppe: true },
    { id: 'luft', name: 'Luftfahrzeug', welt: 'luft', eltern: WURZEL, felder: [], gruppe: true }
  ];

  var ARTEN = [
    { id: 'auto', name: 'Auto', welt: 'land', eltern: 'land', kennung: 'kennzeichen', felder: LAND },
    { id: 'motorrad', name: 'Motorrad', welt: 'land', eltern: 'land', kennung: 'kennzeichen',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin',
        'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
        'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit'] },
    { id: 'wohnmobil', name: 'Wohnmobil', welt: 'land', eltern: 'land', kennung: 'kennzeichen', felder: LAND },
    { id: 'wohnwagen', name: 'Wohnwagen', welt: 'land', eltern: 'land', kennung: 'kennzeichen',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin',
        'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
        'hoechstgeschwindigkeit', 'achsen', 'mautklasse'] },
    { id: 'oldtimer', name: 'Oldtimer', welt: 'land', eltern: 'land', kennung: 'kennzeichen', felder: LAND },
    { id: 'boot', name: 'Boot', welt: 'wasser', eltern: 'wasser', kennung: 'registriernummer', felder: BOOT },
    { id: 'sportboot', name: 'Sportboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'wasserskiboot', name: 'Wasserskiboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'wohnboot', name: 'Motorboot zum Übernachten', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'motorschiff', name: 'Motorschiff', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot', name: 'Segelboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot-monohull', name: 'Segelboot Monohull', welt: 'wasser', eltern: 'segelboot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot-katamaran', name: 'Segelboot Katamaran', welt: 'wasser', eltern: 'segelboot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot-jolle', name: 'Segelboot Jolle oder Kleinboot', welt: 'wasser', eltern: 'segelboot', kennung: 'registriernummer', felder: BOOT },
    { id: 'flugzeug', name: 'Flugzeug', welt: 'luft', eltern: 'luft', kennung: 'registriernummer',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'registriernummer',
        'laenge', { key: 'breite', label: 'Spannweite' }, 'hoehe', 'leergewicht',
        { key: 'gesamtgewicht', label: 'Höchstzulässiges Abfluggewicht' },
        'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit'] }
  ];

  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }

  function art(id) {
    for (var i = 0; i < ARTEN.length; i++) { if (ARTEN[i].id === id) return ARTEN[i]; }
    for (var j = 0; j < GRUPPEN_KNOTEN.length; j++) { if (GRUPPEN_KNOTEN[j].id === id) return GRUPPEN_KNOTEN[j]; }
    return null;
  }

  function knoten(id) { return id === WURZEL ? { id: WURZEL, name: 'Alle Fahrzeuge', eltern: null, gruppe: true } : art(id); }

  /* Die Kennung selbst und alle Obergruppen bis zur Wurzel, zuerst die Art selbst. */
  function vorfahren(id) {
    var liste = [], k = knoten(id), schutz = 0;
    while (k && schutz++ < 20) { liste.push(k.id); k = k.eltern ? knoten(k.eltern) : null; }
    return liste;
  }

  function kinder(id) {
    return GRUPPEN_KNOTEN.concat(ARTEN).filter(function (a) { return a.eltern === id; });
  }

  /* Der ganze Baum von oben nach unten, mit Tiefe (Wurzel = 0), Reihenfolge wie angezeigt. */
  function baum() {
    var ergebnis = [];
    function gehe(id, tiefe) {
      var k = knoten(id);
      ergebnis.push({ id: k.id, name: k.name, welt: k.welt || null, tiefe: tiefe, gruppe: !!k.gruppe || kinder(k.id).length > 0, waehlbar: !k.gruppe });
      kinder(id).forEach(function (c) { gehe(c.id, tiefe + 1); });
    }
    gehe(WURZEL, 0);
    return ergebnis;
  }

  /* Alle Nachkommen (ohne die Art selbst). */
  function nachkommen(id) {
    var ergebnis = [];
    kinder(id).forEach(function (c) { ergebnis.push(c.id); nachkommen(c.id).forEach(function (n) { ergebnis.push(n); }); });
    return ergebnis;
  }

  function felder(artId) {
    var a = art(artId);
    if (!a) return [];
    return a.felder.map(function (eintrag) {
      var key = typeof eintrag === 'string' ? eintrag : eintrag.key;
      var f = kopie(FELDER[key]);
      if (typeof eintrag !== 'string') { for (var p in eintrag) { f[p] = eintrag[p]; } }
      f.key = key;
      return f;
    });
  }

  function gruppen(artId) {
    var alle = felder(artId);
    return GRUPPEN.map(function (g) {
      return { id: g.id, titel: g.titel, felder: alle.filter(function (f) { return f.gruppe === g.id; }) };
    }).filter(function (g) { return g.felder.length > 0; });
  }

  MM.Fahrzeugarten = {
    WURZEL: WURZEL,
    /* Alle Arten, die ein Fahrzeug haben kann, in der Reihenfolge des Baums. */
    alle: function () { return baum().filter(function (k) { return k.waehlbar; }).map(function (k) { return art(k.id); }); },
    baum: baum,
    knoten: knoten,
    vorfahren: vorfahren,
    kinder: kinder,
    nachkommen: nachkommen,
    /* Gilt die Art 'id' als Fall von 'gruppeId'? (Art selbst oder eine ihrer Obergruppen) */
    gehoertZu: function (id, gruppeId) { return vorfahren(id).indexOf(gruppeId) >= 0; },
    art: art,
    felder: felder,
    gruppen: gruppen,
    kennungFeld: function (artId) { var a = art(artId); return a ? a.kennung : null; }
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
