'use strict';
/* 2.0.115: Verantwortlicher Wechsel – ein Knopf für Skipper- und Rudergängerwechsel, mit Position, Kartenzeichen SW und RW. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status',
  'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'kartenereignisse', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = p => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 3, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (std, min) => { uhr.ms = new Date(2026, 10, 3, std, min, 0).getTime(); };
  return d;
}
async function mitFahrzeug(art) {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen(art || 'boot', { bezeichnung: 'Fahrzeug' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const ben = (await d.personAnlegen({ bezeichnung: 'Ben', funktionen: ['Skipper'] })).id;
  const cora = (await d.personAnlegen({ bezeichnung: 'Cora', funktionen: ['Crew'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Sommertörn', artId: toern, fahrzeugId: fz, vonDatum: '2026-11-03', vonZeit: '09:00', bisDatum: '2026-11-05', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok);
  assert.ok((await d.besatzungHinzufuegen(r.id, ben, { rolle: 'stellvertreter' })).ok);
  assert.ok((await d.besatzungHinzufuegen(r.id, cora, { rolle: 'crew' })).ok);
  await d.heutigerTag(r.id);
  return { d, id: r.id, anna, ben, cora };
}
const GPS = { breite: 43.80123, laenge: 15.95432, genauigkeit: 6.4 };
const JETZT = { abDatum: '2026-11-03', abZeit: '12:00', zeitHerkunft: 'geraet' };

test('Verantwortlicher Wechsel: beide Haken, zwei verschiedene Personen, ein Vorgang mit Position', async () => {
  const c = await mitFahrzeug();
  const r = await c.d.verantwortlicherWechsel(c.id, Object.assign({ skipperPersonId: c.ben, ruderPersonId: c.cora, position: GPS }, JETZT));
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal(r.position, true);
  const a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.verantwortlichJetzt.name, 'Ben'); assert.equal(a.rudergaengerJetzt.name, 'Cora');
  const v = a.verantwortung[1], ru = a.rudergaenger[0];
  assert.deepEqual([v.breite, v.laenge, v.positionQuelle], [43.80123, 15.95432, 'gps']);
  assert.deepEqual([ru.breite, ru.laenge, ru.positionQuelle], [43.80123, 15.95432, 'gps']);
});

test('Verantwortlicher Wechsel: nur der Rudergänger, nur der Skipper, oder dieselbe Person für beides', async () => {
  const c = await mitFahrzeug();
  assert.ok((await c.d.verantwortlicherWechsel(c.id, Object.assign({ ruderPersonId: c.cora, position: GPS }, JETZT))).ok);
  let a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.rudergaengerJetzt.name, 'Cora'); assert.equal(a.verantwortlichJetzt.name, 'Anna', 'der Skipper bleibt verantwortlich'); assert.equal(a.verantwortung.length, 1);
  c.d.stelle(12, 30);
  assert.ok((await c.d.verantwortlicherWechsel(c.id, { skipperPersonId: c.ben, abDatum: '2026-11-03', abZeit: '12:30', zeitHerkunft: 'geraet' })).ok);
  a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.verantwortlichJetzt.name, 'Ben'); assert.equal(a.rudergaengerJetzt.name, 'Cora', 'der Rudergänger bleibt');
  /* Personalunion: Anna wird wieder Skipper und steht am Ruder */
  c.d.stelle(13, 0);
  assert.ok((await c.d.verantwortlicherWechsel(c.id, { skipperPersonId: c.anna, ruderPersonId: c.anna, abDatum: '2026-11-03', abZeit: '13:00', zeitHerkunft: 'geraet' })).ok);
  a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.verantwortlichJetzt.name, 'Anna'); assert.equal(a.rudergaengerJetzt.name, 'Anna');
});

test('Verantwortlicher Wechsel: wird einer der beiden Wechsel abgelehnt, wird nichts gespeichert', async () => {
  const c = await mitFahrzeug();
  /* Cora ist Crew: als Skipper nicht erlaubt, als Rudergänger schon */
  const r = await c.d.verantwortlicherWechsel(c.id, Object.assign({ skipperPersonId: c.cora, ruderPersonId: c.ben }, JETZT));
  assert.equal(r.ok, false); assert.ok(r.fehler.skipperPersonId.includes('Stellvertreter'));
  const a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.verantwortung.length, 1); assert.equal(a.rudergaenger.length, 0, 'auch der Rudergänger-Wechsel wurde nicht gespeichert');
  assert.equal((await c.d.verantwortlicherWechsel(c.id, JETZT)).ok, false, 'ohne Auswahl geht es nicht');
  assert.ok((await c.d.verantwortlicherWechsel(c.id, Object.assign({ ruderPersonId: c.anna }, JETZT))).fehler.ruderPersonId, 'Anna steht schon am Ruder');
  assert.ok((await c.d.verantwortlicherWechsel(c.id, Object.assign({ skipperPersonId: c.anna }, JETZT))).fehler.skipperPersonId, 'Anna ist schon Skipper');
});

test('Verantwortlicher Wechsel: an Land nur der Fahrer, kein Rudergänger', async () => {
  const c = await mitFahrzeug('wohnmobil');
  const r = await c.d.verantwortlicherWechsel(c.id, Object.assign({ ruderPersonId: c.cora }, JETZT));
  assert.equal(r.ok, false); assert.ok(r.fehler.allgemein);
  const ok = await c.d.verantwortlicherWechsel(c.id, Object.assign({ skipperPersonId: c.ben, position: GPS }, JETZT));
  assert.ok(ok.ok, JSON.stringify(ok));
  const a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.verantwortlichJetzt.name, 'Ben'); assert.equal(a.verantwortung[1].positionQuelle, 'gps');
  assert.deepEqual(a.rudergaenger, []);
});

test('Position: GPS nur bei Gerätezeit, von Hand eintragbar (auch beim Nachtrag), falsche Eingabe wird abgelehnt', async () => {
  const c = await mitFahrzeug();
  /* Nachtrag (Zeit von Hand): die GPS-Position gilt nicht */
  let r = await c.d.verantwortlicherWechsel(c.id, { ruderPersonId: c.cora, abDatum: '2026-11-03', abZeit: '11:00', zeitHerkunft: 'hand', position: GPS });
  assert.ok(r.ok); assert.equal(r.position, false); assert.equal(r.nachgetragen, true);
  let a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.rudergaenger[0].breite, null);
  /* von Hand, auch beim Nachtrag */
  r = await c.d.verantwortlicherWechsel(c.id, { ruderPersonId: c.ben, abDatum: '2026-11-03', abZeit: '11:30', zeitHerkunft: 'hand', breite: '43,8', laenge: '15,9' });
  assert.ok(r.ok, JSON.stringify(r)); assert.equal(r.position, true);
  a = await c.d.aktivitaetLaden(c.id);
  assert.deepEqual([a.rudergaenger[1].breite, a.rudergaenger[1].laenge, a.rudergaenger[1].positionQuelle], [43.8, 15.9, 'hand']);
  /* Gerätezeit, aber die Position von Hand geändert: Herkunft „hand“ */
  c.d.stelle(12, 20);
  r = await c.d.verantwortlicherWechsel(c.id, { skipperPersonId: c.ben, abDatum: '2026-11-03', abZeit: '12:20', zeitHerkunft: 'geraet', position: GPS, breite: '43,9', laenge: '15,95432' });
  assert.ok(r.ok, JSON.stringify(r));
  a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.verantwortung[1].positionQuelle, 'hand');
  /* zu große Breite */
  r = await c.d.verantwortlicherWechsel(c.id, { ruderPersonId: c.cora, abDatum: '2026-11-03', abZeit: '12:40', zeitHerkunft: 'hand', breite: '95', laenge: '15' });
  assert.equal(r.ok, false); assert.ok(r.fehler.breite);
  /* ohne GPS und ohne Eingabe: ohne Position, aber gespeichert */
  c.d.stelle(12, 50);
  r = await c.d.verantwortlicherWechsel(c.id, { ruderPersonId: c.cora, abDatum: '2026-11-03', abZeit: '12:50', zeitHerkunft: 'geraet', position: null });
  assert.ok(r.ok); assert.equal(r.position, false);
});

test('Position: die alten Einzel-Funktionen nehmen sie ebenfalls, ohne Position bleibt alles wie bisher', async () => {
  const c = await mitFahrzeug();
  assert.ok((await c.d.verantwortungWechseln(c.id, c.ben, Object.assign({ position: GPS }, JETZT))).ok);
  c.d.stelle(12, 20);
  assert.ok((await c.d.rudergaengerWechseln(c.id, c.cora, { abDatum: '2026-11-03', abZeit: '12:20', zeitHerkunft: 'geraet', position: GPS })).ok);
  c.d.stelle(12, 40);
  assert.ok((await c.d.rudergaengerWechseln(c.id, c.anna, { abDatum: '2026-11-03', abZeit: '12:40', zeitHerkunft: 'geraet' })).ok);
  const a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.verantwortung[1].breite, 43.80123); assert.equal(a.rudergaenger[0].breite, 43.80123);
  assert.equal(a.rudergaenger[1].breite, null, 'Alt-Einträge und Einträge ohne Position bleiben ohne');
});

test('Logbuch und Karte: Wechsel tragen die Position, die Karte zeigt sie als Skipperwechsel (SW) und Rudergängerwechsel (RW)', async () => {
  const c = await mitFahrzeug();
  assert.ok((await c.d.verantwortlicherWechsel(c.id, Object.assign({ skipperPersonId: c.ben, ruderPersonId: c.cora, position: GPS }, JETZT))).ok);
  const ev = (await c.d.logbuchLaden(c.id)).abschnitte.flatMap(t => t.ereignisse);
  const w = ev.find(e => e.art === 'wechsel'), ru = ev.find(e => e.art === 'ruder');
  assert.deepEqual([w.breite, w.laenge, w.positionQuelle], [43.80123, 15.95432, 'gps']);
  assert.deepEqual([ru.breite, ru.laenge, ru.positionQuelle], [43.80123, 15.95432, 'gps']);
  const kd = await c.d.kartenDaten(c.id, 0);
  assert.ok(kd.ok, JSON.stringify(kd));
  const namen = kd.ereignisse.map(e => e.artName).sort();
  assert.deepEqual(namen, ['Rudergängerwechsel', 'Skipperwechsel']);
  const KE = MM.KartenEreignisse;
  assert.equal(KE.aussehen('Skipperwechsel').symbol, 'SW');
  assert.equal(KE.aussehen('Rudergängerwechsel').symbol, 'RW');
  assert.equal(KE.aussehen('Fahrerwechsel').symbol, 'FW');
  assert.equal(KE.wechselName('wechsel', 'wasser'), 'Skipperwechsel'); assert.equal(KE.wechselName('wechsel', 'land'), 'Fahrerwechsel'); assert.equal(KE.wechselName('ruder', 'wasser'), 'Rudergängerwechsel');
  /* ohne Position erscheint der Wechsel nicht auf der Karte */
  c.d.stelle(13, 0);
  assert.ok((await c.d.verantwortlicherWechsel(c.id, { ruderPersonId: c.anna, abDatum: '2026-11-03', abZeit: '13:00', zeitHerkunft: 'geraet' })).ok);
  assert.equal((await c.d.kartenDaten(c.id, 0)).ereignisse.length, 2);
});

test('Cockpit: ein Knopf „Verantwortlicher Wechsel“, die alte Adresse für Rudergänger führt auf dieselbe Seite', () => {
  const ansicht = lesen('js/ansicht.js'), logbuch = lesen('js/logbuch.js');
  assert.ok(logbuch.includes("{ id: 'wechsel', name: 'Verantwortlicher Wechsel' }"));
  assert.ok(!ansicht.includes("cockpit/rudergaenger', MM.Rudergaenger.NAME + ' wechseln'"), 'kein eigener Rudergänger-Knopf mehr im Cockpit');
  assert.ok(ansicht.includes("titel = 'Verantwortlicher Wechsel'"));
  assert.ok(ansicht.includes('daten.verantwortlicherWechsel(id, roh)'));
  assert.ok(ansicht.includes('roh.position = frischePosition()'), 'die Position kommt beim Festhalten vom GPS');
});
