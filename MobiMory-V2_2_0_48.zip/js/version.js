/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.48';
  MM.STUFE = 'Verbraucher und Quelle: Tank als Komponente, Stoff, Verbraucher mit Quelle, Übersicht der Kette am Fahrzeug';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
