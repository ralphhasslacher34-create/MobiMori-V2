/*
 * Etappen (Mehrtagesreisen), nur Regeln und Rechnung, kein Speichern, kein Netz.
 *
 * Festlegung (05.11.2026): Die Etappe ist der vorhandene Tagesabschnitt des Logbuchs. Es kommt keine zweite Struktur daneben.
 *  - Jeder Tag hat einen Startort und einen Zielort aus der Ortsliste. Die Orte der ganzen Reise (Start, Zwischenziele, Ziel)
 *    bleiben die Gesamtplanung, jeder Tag nimmt davon zwei.
 *  - Das Wetter eines Tages ergibt sich aus den zwei Orten des Tages (Abstandsregel wie bei der Route) und lässt sich von Hand ersetzen.
 *  - Kosten werden einem Tag zugeordnet. Die Reisesumme bleibt die Summe aller Tage (plus Posten ohne Tag).
 *  - Oben an der Aktivität steht die Zusammenfassung: alle Tage mit Strecke, Kosten, Ereignissen und Wetter, dazu die Gesamtsumme.
 *  - Fehlt etwas, sagt die App „unklar“. Nichts wird geraten.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var NAHE_KM = 5;           /* so nah muss ein Ort an der Route liegen, damit die Strecke auf der Route gerechnet wird */
  var RAD = Math.PI / 180;

  function zahl(n) { return typeof n === 'number' && isFinite(n) ? n : null; }
  function runde(n, s) { var f = Math.pow(10, s == null ? 1 : s); return Math.round(n * f) / f; }
  function hatPosition(o) { return !!o && zahl(o.breite) !== null && zahl(o.laenge) !== null; }

  function luftlinieKm(a, b) {
    if (!hatPosition(a) || !hatPosition(b)) return null;
    return MM.Routen.entfernungKm(a.breite, a.laenge, b.breite, b.laenge);
  }

  /*
   * Der Punkt der Route, der einem Ort am nächsten liegt: { km (Strecke ab Anfang der Route), abstandKm } oder null.
   * Gerechnet wird auf den Teilstücken zwischen den Routenpunkten (flache Näherung, für diese Abstände genau genug).
   */
  function naechsterAufRoute(punkte, ort) {
    if (!punkte || punkte.length < 2 || !hatPosition(ort)) return null;
    var best = null, kx = Math.cos(ort.breite * RAD) * 111.32, ky = 110.57, i;
    for (i = 0; i < punkte.length - 1; i++) {
      var p = punkte[i], q = punkte[i + 1];
      var ax = (p.laenge - ort.laenge) * kx, ay = (p.breite - ort.breite) * ky;
      var bx = (q.laenge - ort.laenge) * kx, by = (q.breite - ort.breite) * ky;
      var dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
      var t = l2 > 0 ? Math.max(0, Math.min(1, -(ax * dx + ay * dy) / l2)) : 0;
      var px = ax + t * dx, py = ay + t * dy, d = Math.sqrt(px * px + py * py);
      if (!best || d < best.abstandKm) best = { abstandKm: d, km: p.km + t * (q.km - p.km) };
    }
    return best;
  }

  /*
   * Die Strecke eines Tages. Mit Route (und beide Orte nah an der Route): die Strecke auf der Route zwischen den Orten.
   * Sonst die Luftlinie zwischen den Orten, so gekennzeichnet. Ohne Position eines Ortes: null (unklar).
   * Ergebnis: { km, art: 'route' | 'luftlinie' } oder null.
   */
  function strecke(routePunkte, start, ziel) {
    if (!hatPosition(start) || !hatPosition(ziel)) return null;
    var a = naechsterAufRoute(routePunkte, start), b = naechsterAufRoute(routePunkte, ziel);
    if (a && b && a.abstandKm <= NAHE_KM && b.abstandKm <= NAHE_KM) return { km: runde(Math.abs(b.km - a.km), 1), art: 'route' };
    return { km: runde(luftlinieKm(start, ziel), 1), art: 'luftlinie' };
  }

  /*
   * Die Punkte, für die das Wetter eines Tages geholt wird: Start, Ziel und dazwischen nach der Abstandsregel
   * (wie bei der Route), auf der geraden Linie zwischen den zwei Orten des Tages. Jeder: { nr, name, breite, laenge, km, minuten }.
   * Ohne Position eines Ortes oder ohne Geschwindigkeit: [].
   */
  function wetterMesspunkte(start, ziel, geschwindigkeit, einheit, regel) {
    if (!hatPosition(start) || !hatPosition(ziel)) return [];
    var d = luftlinieKm(start, ziel);
    var punkte = [{ breite: start.breite, laenge: start.laenge, km: 0, name: start.name || null },
      { breite: ziel.breite, laenge: ziel.laenge, km: d, name: ziel.name || null }];
    return MM.Routen.messpunkte(punkte, geschwindigkeit, einheit, regel);
  }

  /* Die Geschwindigkeit eines Tages in km/h: die der Route, sonst aus Strecke und Uhrzeiten des Tages (beides Angaben des Nutzers). Sonst null. */
  function geschwindigkeitFuerTag(routeKmh, streckeKm, beginnZeit, endeZeit) {
    if (zahl(routeKmh) !== null && routeKmh > 0) return { kmh: routeKmh, herkunft: 'route' };
    if (zahl(streckeKm) !== null && streckeKm > 0 && beginnZeit && endeZeit && endeZeit > beginnZeit) {
      var b = beginnZeit.split(':'), e = endeZeit.split(':');
      var min = (+e[0] * 60 + +e[1]) - (+b[0] * 60 + +b[1]);
      if (min > 0) return { kmh: streckeKm / (min / 60), herkunft: 'zeiten' };
    }
    return null;
  }

  /*
   * Was die App für den Tag weiß und was ihr fehlt.
   *  p: { datum, beginnZeit, endeZeit, start, ziel (Orte mit Name, Position), routePunkte, routeKmh }
   * Ergebnis: { strecke, kmh, herkunft, abfahrt, grund }. grund ist null, wenn das Wetter geholt werden kann, sonst der Satz, was fehlt („unklar“).
   * Die Abfahrt ist Datum und Beginn des Tages. Ohne Beginn wird keine Uhrzeit angenommen.
   */
  function tagesPlan(p) {
    var r = { strecke: null, kmh: null, herkunft: null, abfahrt: null, grund: null };
    if (!p.start || !p.ziel) { r.grund = 'Der Tag hat noch keinen Start- und Zielort.'; return r; }
    r.strecke = strecke(p.routePunkte, p.start, p.ziel);
    var ohnePos = !hatPosition(p.start) ? p.start : (!hatPosition(p.ziel) ? p.ziel : null);
    if (ohnePos) { r.grund = 'Bei „' + ohnePos.name + '“ fehlt die Position. Prüfe den Ort über die Ortssuche oder trage die Position ein.'; return r; }
    if (!p.beginnZeit) { r.grund = 'Bitte die Uhrzeit des Beginns beim Tag eintragen. Das Wetter gilt für die Ankunftszeit an jedem Punkt.'; return r; }
    r.abfahrt = p.datum + 'T' + p.beginnZeit;
    var g = geschwindigkeitFuerTag(p.routeKmh, r.strecke ? r.strecke.km : null, p.beginnZeit, p.endeZeit);
    if (!g) { r.grund = 'Es fehlt die Geschwindigkeit: Trage sie an der Route ein oder gib beim Tag Beginn und Ende (Uhrzeit) an.'; return r; }
    r.kmh = g.kmh; r.herkunft = g.herkunft;
    return r;
  }

  /* Zwei Orte für einen Tag: Auswahl aus der Gesamtplanung der Reise (Start, Zwischenziele, Ziel); ohne Planung alle Orte. */
  function ortOptionen(planIds, orte, gewaehlt) {
    var plan = (planIds || []).filter(function (id, i, l) { return id && l.indexOf(id) === i; });
    var nur = plan.length ? plan : null;
    return (orte || []).filter(function (o) {
      if (o.ausgeblendet && o.id !== gewaehlt) return false;
      return !nur || nur.indexOf(o.id) >= 0 || o.id === gewaehlt;
    }).map(function (o) { return { wert: o.id, label: o.name }; });
  }

  /*
   * Kosten den Tagen zuordnen.
   *  kosten [{ id, werte }]  alle Posten der Aktivität (alle Gruppen); ausgeblendete und Posten ohne Euro-Betrag zählen nicht (wie in der Reisesumme)
   *  tage   [{ id, datum }]
   * Zuordnung: 1. der Tag, den der Posten ausdrücklich hat (abschnittId); 2. sonst der einzige Tag mit dem Datum des Postens
   * (gekennzeichnet „nach Datum“); 3. sonst „ohne Tag“.
   * Ergebnis: { proTag: { tagId: { summe, anzahl, nachDatum } }, ohneTag: { summe, anzahl }, summe }
   */
  function kostenAnTage(kosten, tage) {
    var proTag = {}, ohne = { summe: 0, anzahl: 0 }, gesamt = 0, nachDatum = {};
    (tage || []).forEach(function (t) { proTag[t.id] = { summe: 0, anzahl: 0, nachDatum: 0 }; nachDatum[t.datum] = nachDatum[t.datum] === undefined ? t.id : null; });
    (kosten || []).forEach(function (k) {
      var w = k.werte || {}, b = zahl(Number(w.betrag));
      if (w.ausgeblendet === 'ja' || !(b > 0)) return;
      gesamt += b;
      var id = w.abschnittId && proTag[w.abschnittId] ? w.abschnittId : null, datum = false;
      if (!id && w.datum && nachDatum[w.datum]) { id = nachDatum[w.datum]; datum = true; }
      if (id) { proTag[id].summe += b; proTag[id].anzahl++; if (datum) proTag[id].nachDatum++; }
      else { ohne.summe += b; ohne.anzahl++; }
    });
    Object.keys(proTag).forEach(function (id) { proTag[id].summe = runde(proTag[id].summe, 2); });
    ohne.summe = runde(ohne.summe, 2);
    return { proTag: proTag, ohneTag: ohne, summe: runde(gesamt, 2) };
  }

  /* Die Ereignisse eines Tages kurz, zum Beispiel „Abfahrt, Wetter (3), Ankunft“. */
  function ereignisKurz(ereignisse) {
    var m = {}, reihe = [];
    (ereignisse || []).forEach(function (e) {
      if (e.art !== 'ereignis' || e.ausgeblendet) return;
      var n = e.artName || 'unbekannt';
      if (!m[n]) { m[n] = 0; reihe.push(n); }
      m[n]++;
    });
    return { anzahl: reihe.reduce(function (s, n) { return s + m[n]; }, 0), text: reihe.map(function (n) { return m[n] > 1 ? n + ' (' + m[n] + ')' : n; }).join(', ') };
  }

  /* Das Wetter eines Tages in einer Zeile aus den schwersten Werten, zum Beispiel „Böen bis 35 km/h, Regen bis 60 %, Welle bis 0,8 m“. */
  function wetterKurz(schwerste, windEinheit) {
    if (!schwerste) return null;
    var t = [];
    function n(x) { return String(x).replace('.', ','); }
    if (schwerste.boeen) t.push('Böen bis ' + n(schwerste.boeen.wert) + ' ' + (windEinheit === 'kn' ? 'kn' : 'km/h'));
    if (schwerste.regen) t.push('Regen bis ' + n(schwerste.regen.wert) + ' %');
    if (schwerste.welle) t.push('Welle bis ' + n(schwerste.welle.wert) + ' m');
    return t.length ? t.join(', ') : null;
  }

  /*
   * Die Zusammenfassung der ganzen Reise: eine Zeile je Tag und die Summen.
   *  p.tage   [{ id, datum, start, ziel, strecke, ereignisse, wetter, wetterHand, ... }] (schon vorbereitet, in der Reihenfolge der Tage)
   *  p.kosten das Ergebnis von kostenAnTage
   * Ergebnis: { zeilen, streckeSumme, streckeUnklar, kostenSumme }
   */
  function zusammenfassung(p) {
    var k = p.kosten || { proTag: {}, ohneTag: { summe: 0, anzahl: 0 }, summe: 0 };
    var summe = 0, unklar = 0;
    var zeilen = (p.tage || []).map(function (t) {
      var s = t.strecke && t.strecke.km !== null ? t.strecke : null;
      if (s) summe += s.km; else unklar++;
      return Object.assign({}, t, { kosten: k.proTag[t.id] || { summe: 0, anzahl: 0, nachDatum: 0 } });
    });
    return { zeilen: zeilen, streckeSumme: runde(summe, 1), streckeUnklar: unklar, kostenSumme: k.summe, ohneTag: k.ohneTag };
  }

  MM.Etappen = {
    NAHE_KM: NAHE_KM,
    luftlinieKm: luftlinieKm, naechsterAufRoute: naechsterAufRoute, strecke: strecke,
    wetterMesspunkte: wetterMesspunkte, geschwindigkeitFuerTag: geschwindigkeitFuerTag, tagesPlan: tagesPlan,
    ortOptionen: ortOptionen, kostenAnTage: kostenAnTage, ereignisKurz: ereignisKurz, wetterKurz: wetterKurz, zusammenfassung: zusammenfassung
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
