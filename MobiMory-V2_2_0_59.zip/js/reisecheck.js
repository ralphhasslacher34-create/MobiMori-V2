/*
 * Reisecheck (Schritt 11, seit 2.0.38): die reinen Regeln, ohne Speicher und ohne Netz.
 *
 * Der Reisecheck schickt eine ANONYMISIERTE Anfrage an einen Recherche-Dienst
 * (der Dienst fragt eine KI mit Internetsuche) und bekommt eine Liste von
 * Anforderungen zurück: Was ist für diese Reise nötig, und ist es erfüllt?
 *
 * Datenschutz (Festlegung): Es gehen nur Angaben ohne Namen und ohne Nummern
 * hinaus. Personen heißen P1, P2, Tiere A1, A2, das Fahrzeug „vehicle“. Namen,
 * Kennzeichen, FIN/HIN, Ausweis- und Chipnummern, Adressen, Telefon und E-Mail
 * verlassen das Gerät nicht. Die Zuordnung P1 → Name bleibt lokal.
 *
 * Die App trifft keine rechtsgültige Aussage. Der Check ist eine Hilfe für die
 * Planung, die Verantwortung bleibt beim Skipper oder Fahrer.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Reihenfolge = Dringlichkeit: Was fehlt, steht oben. */
  var STATUS = ['Fehlt', 'Prüfen', 'Erfüllt', 'Nicht relevant'];
  var KATEGORIEN = ['Pflicht', 'Wichtig', 'Empfohlen', 'Hinweis'];
  var VERTRAUEN = ['hoch', 'mittel', 'niedrig'];
  var SUBJEKTE = ['Person', 'Fahrzeug', 'Tier', 'Reise'];
  var RECHERCHE = ['vollständig', 'teilweise', 'fehlerhaft'];

  /* Steigt die Nummer, muss der Nutzer neu zustimmen. */
  var ZUSTIMMUNG_VERSION = 1;
  var ZUSTIMMUNG_TEXT = 'Für den Reisecheck schickt MobiMory Angaben zu deiner Reise an den Recherche-Dienst, den du eingerichtet hast. ' +
    'Der Dienst fragt damit eine KI mit Internetsuche, was für diese Reise nötig ist. ' +
    'Es gehen nur Angaben ohne Namen hinaus: Reisezeitraum, Gebiet, Orte (Ortsname, Land und grobe Lage), Art und Maße des Fahrzeugs, ' +
    'die Teile am Fahrzeug, die Besatzung als „Person 1“ und „Tier 1“ mit ihren Nachweisen und deren Ablaufdaten. ' +
    'Namen, Kennzeichen, FIN und HIN, Nummern von Ausweisen und Chips, Adressen, Telefonnummern und E-Mail-Adressen gehen nicht mit. ' +
    'Das Ergebnis ist eine Planungshilfe und keine rechtsgültige Auskunft. Du kannst die Zustimmung jederzeit widerrufen.';

  var MAX_TEXT = 700;
  var MAX_ANFORDERUNGEN = 150;
  var MAX_QUELLEN = 6;

  function text(x) { return x === null || x === undefined ? '' : String(x).trim(); }
  function zahl(x) {
    if (x === null || x === undefined || x === '') return null;
    var n = Number(x);
    return isFinite(n) ? n : null;
  }
  function gerundet(x, stellen) {
    var n = zahl(x);
    if (n === null) return null;
    var f = Math.pow(10, stellen);
    return Math.round(n * f) / f;
  }
  function kuerzen(s) { s = text(s); return s.length > MAX_TEXT ? s.slice(0, MAX_TEXT - 1) + '…' : s; }

  /* ---------- Einrichtung ---------- */

  /* Die Adresse des Dienstes. Nur https. Ein angehängtes /research oder /health wird entfernt. */
  function dienstAdresse(roh) {
    var t = text(roh);
    if (!t) return { ok: false, fehler: 'Bitte die Adresse des Recherche-Dienstes eintragen.' };
    if (/\s/.test(t)) return { ok: false, fehler: 'Die Adresse darf keine Leerzeichen enthalten.' };
    if (!/^https:\/\//i.test(t)) return { ok: false, fehler: 'Die Adresse muss mit https:// beginnen.' };
    var m = /^https:\/\/([^\/?#]+)([^?#]*)/i.exec(t);
    if (!m || !/^[a-z0-9.\-]+(:\d{1,5})?$/i.test(m[1]) || m[1].indexOf('.') < 0) return { ok: false, fehler: 'Das ist keine gültige Adresse.' };
    var pfad = m[2].replace(/\/+$/, '').replace(/\/(research|health)$/i, '');
    return { ok: true, url: 'https://' + m[1].toLowerCase() + pfad };
  }

  function tokenPruefen(roh) {
    var t = text(roh);
    if (!t) return { ok: false, fehler: 'Bitte das Passwort für den Dienst eintragen.' };
    if (/\s/.test(t)) return { ok: false, fehler: 'Das Passwort darf keine Leerzeichen enthalten.' };
    if (t.length < 8) return { ok: false, fehler: 'Das Passwort ist zu kurz. Es braucht mindestens 8 Zeichen.' };
    return { ok: true, token: t };
  }

  /* ---------- Anfrage ---------- */

  function verkehrsarten(welt) {
    if (welt === 'wasser') return ['Wasser'];
    if (welt === 'luft') return ['Luft'];
    return ['Strasse'];
  }

  function nachweisZeile(n) {
    return { type: text(n.art), scanned: !!n.gescannt, issued: text(n.ausgestelltAm) || null, validTo: text(n.gueltigBis) || null, classes: text(n.klassen) || null };
  }

  /* Das Fahrzeug im Format der V1-Anfrage. Es geht nie eine Nummer hinaus, nur ob es sie gibt. Gebraucht vom Reisecheck und vom Grundcheck. */
  function fahrzeugBlock(fz) {
    var v = fz.werte || {};
    return {
      key: 'vehicle', profile: text(fz.artName), type: fz.welt === 'wasser' ? 'Wasserfahrzeug' : (fz.welt === 'luft' ? 'Luftfahrzeug' : 'Landfahrzeug'),
      manufacturer: text(v.marke), model: text(v.modell), designation: text(v.typ), year: zahl(v.baujahr), firstRegistration: text(v.erstzulassung) || null,
      lengthM: zahl(v.laenge), widthM: zahl(v.breite), heightM: zahl(v.hoehe), draftM: zahl(v.tiefgang), clearanceM: zahl(v.durchfahrtshoehe),
      emptyWeightKg: zahl(v.leergewicht), grossWeightKg: zahl(v.gesamtgewicht), axles: zahl(v.achsen), fuel: text(v.kraftstoff), tollClass: text(v.mautklasse),
      maxSpeedKmh: zahl(v.hoechstgeschwindigkeit), seats: zahl(v.plaetze),
      /* Nur ob es sie gibt, nie die Nummer selbst. */
      hasRegistrationIdentifier: !!(text(v.kennzeichen) || text(v.registriernummer)), hasVIN: !!text(v.fin), hasHIN: !!text(v.hin),
      proofs: (fz.nachweise || []).map(nachweisZeile),
      components: (fz.komponenten || []).map(function (k) { return { name: text(k.name), count: zahl(k.anzahl) || 1 }; }).filter(function (k) { return k.name; })
  };
  }

  /*
   * Baut die Anfrage. e (alles schon aus der Datenschicht gelesen):
   *  vonDatum, vonZeit, bisDatum, bisZeit
   *  fahrzeug: { artName, welt, werte: {...technische Angaben...}, komponenten: [{ name, anzahl }], nachweise: [{ art, gueltigBis, ... }] }
   *  gebiete: [{ name }], gebietText
   *  wegpunkte: [{ art: 'start'|'zwischenziel'|'ziel', name, land, breite, laenge }]
   *  personen: [{ rolle, funktionen: [], nachweise: [...] }]
   *  tiere: [{ tierart, hatChip, nachweise: [...] }]
   * Rückgabe: { ok, fehler[], anfrage, namen } – namen bleibt auf dem Gerät.
   */
  function anfrageBauen(e) {
    e = e || {};
    var fehler = [];
    var fz = e.fahrzeug || null;
    if (!e.vonDatum || !e.bisDatum) fehler.push('Die Aktivität braucht Beginn und Ende.');
    if (!fz) fehler.push('Zur Aktivität gehört kein Fahrzeug.');
    var personen = e.personen || [], tiere = e.tiere || [];
    if (!personen.length) fehler.push('Die Besatzung ist leer. Der Check braucht mindestens eine Person.');

    var gebiete = (e.gebiete || []).map(function (g) { return text(g.name); }).filter(Boolean);
    if (!gebiete.length && text(e.gebietText)) gebiete = [text(e.gebietText)];
    var wege = (e.wegpunkte || []).filter(function (w) { return text(w.name); });
    if (!gebiete.length && wege.length < 2) fehler.push('Der Check braucht ein Gebiet oder Start und Ziel. Trage beides bei der Aktivität ein.');
    if (fehler.length) return { ok: false, fehler: fehler };

    var namen = { vehicle: fz.name || 'Fahrzeug', trip: 'Reise' };
    var vehicle = fahrzeugBlock(fz);

    var pRows = personen.map(function (p, i) {
      var key = 'P' + (i + 1);
      namen[key] = p.name || ('Person ' + (i + 1));
      return { key: key, role: text(p.rolle), functions: (p.funktionen || []).map(text).filter(Boolean), qualifications: (p.nachweise || []).map(nachweisZeile) };
    });
    var aRows = tiere.map(function (t, i) {
      var key = 'A' + (i + 1);
      namen[key] = t.name || ('Tier ' + (i + 1));
      return { key: key, species: text(t.tierart), hasChip: !!t.hatChip, proofs: (t.nachweise || []).map(nachweisZeile) };
    });

    var von = e.vonDatum + 'T' + (e.vonZeit || '00:00') + ':00';
    var bis = e.bisDatum + 'T' + (e.bisZeit || '23:59') + ':00';
    var trip = {
      title: 'Reisecheck', start: von, end: bis, trafficModes: verkehrsarten(fz.welt), checkMode: 'free',
      areas: gebiete.map(function (n, i) { return { key: 'G' + (i + 1), name: n, type: '', path: n }; })
    };
    if (wege.length >= 2) {
      var ws = wege.map(function (w, i) {
        return { order: i + 1, kind: text(w.art), label: text(w.name), standortName: '', ortName: text(w.name), country: text(w.land), address: '',
          lat: gerundet(w.breite, 2), lon: gerundet(w.laenge, 2) };
      });
      var laender = [];
      ws.forEach(function (w) { if (w.country && laender.indexOf(w.country) < 0) laender.push(w.country); });
      trip.checkMode = 'planned-usage';
      trip.routePlan = { waypoints: ws, locationContext: {
        allWaypointsResolved: ws.every(function (w) { return !!(w.country && w.ortName); }), knownCountries: laender, sameKnownCountry: laender.length === 1 ? laender[0] : '' } };
    }

    return { ok: true, fehler: [], namen: namen, anfrage: {
      trip: trip, vehicle: vehicle, persons: pRows, animals: aRows, locale: 'de-DE',
      researchPolicy: { currentWebResearchRequired: true, preferOfficialSources: true, officialSourcesForMandatoryItems: true,
        uncertaintyMustBeVisible: true, doNotInferComplianceWhenEvidenceIsMissing: true } } };
  }

  /* Ein kurzer, stabiler Fingerabdruck der Anfrage. Ändert sich etwas an den Daten, ändert er sich auch. */
  function fingerabdruck(anfrage) {
    var s = JSON.stringify(anfrage), h = 5381;
    for (var i = 0; i < s.length; i++) { h = ((h << 5) + h + s.charCodeAt(i)) | 0; }
    return (h >>> 0).toString(16) + '-' + s.length;
  }

  /* Was geht hinaus? In einfachen Zeilen, damit der Nutzer es vor dem Senden lesen kann. */
  function vorschau(anfrage) {
    var t = anfrage.trip, v = anfrage.vehicle, z = [];
    z.push('Zeitraum: ' + t.start.slice(0, 10) + ' bis ' + t.end.slice(0, 10));
    if (t.areas.length) z.push('Gebiet: ' + t.areas.map(function (a) { return a.name; }).join(', '));
    if (t.routePlan) z.push('Orte in der Reihenfolge: ' + t.routePlan.waypoints.map(function (w) { return w.ortName + (w.country ? ' (' + w.country + ')' : ''); }).join(' → '));
    z.push('Fahrzeug: ' + [v.profile, v.manufacturer, v.model].filter(Boolean).join(' ') + (v.lengthM ? ', ' + String(v.lengthM).replace('.', ',') + ' m lang' : ''));
    if (v.components.length) z.push('Teile am Fahrzeug: ' + v.components.length + ' (nur Bezeichnung und Anzahl)');
    anfrage.persons.forEach(function (p) {
      z.push(p.key + ' (' + (p.role || 'Besatzung') + '): ' + (p.qualifications.length ? p.qualifications.map(function (q) { return q.type + (q.validTo ? ' bis ' + q.validTo : ''); }).join(', ') : 'keine Nachweise'));
    });
    anfrage.animals.forEach(function (a) {
      z.push(a.key + ' (' + (a.species || 'Tier') + '): ' + (a.proofs.length ? a.proofs.map(function (q) { return q.type + (q.validTo ? ' bis ' + q.validTo : ''); }).join(', ') : 'keine Nachweise') + (a.hasChip ? ', mit Chip' : ''));
    });
    return z;
  }

  /* ---------- Antwort ---------- */

  function aus(liste, wert, vorgabe) { return liste.indexOf(wert) >= 0 ? wert : vorgabe; }

  function quelleLesen(q) {
    if (!q || typeof q !== 'object') return null;
    var url = text(q.url);
    if (!/^https?:\/\/[^\s]+$/i.test(url)) return null;
    return { titel: kuerzen(q.title) || url, url: url, herausgeber: kuerzen(q.publisher), amtlich: q.official === true, stand: kuerzen(q.updated) };
  }

  function anforderungLesen(a, i) {
    if (!a || typeof a !== 'object') return null;
    var req = kuerzen(a.requirement);
    if (!req) return null;
    var quellen = (Array.isArray(a.sources) ? a.sources : []).map(quelleLesen).filter(Boolean).slice(0, MAX_QUELLEN);
    return { id: text(a.id) || ('r' + (i + 1)), bereich: kuerzen(a.area), kategorie: aus(KATEGORIEN, a.category, 'Hinweis'),
      subjekt: text(a.subjectKey) || 'trip', subjektArt: aus(SUBJEKTE, a.subjectType, 'Reise'), verkehr: kuerzen(a.trafficMode),
      anforderung: req, nachweisArt: kuerzen(a.proofKey), status: aus(STATUS, a.status, 'Prüfen'),
      beleg: kuerzen(a.evidence), erklaerung: kuerzen(a.explanation), vertrauen: aus(VERTRAUEN, a.confidence, 'niedrig'),
      widerspruch: a.conflict === true, quellen: quellen };
  }

  /*
   * Prüft die Antwort des Dienstes und macht daraus unser eigenes Format.
   * Fehlt etwas Wichtiges, ist es ein Fehler und nichts wird gespeichert.
   */
  function antwortPruefen(roh) {
    if (!roh || typeof roh !== 'object') return { ok: false, fehler: 'Der Dienst hat nichts Brauchbares geantwortet.' };
    var r = roh.result;
    if (!r || typeof r !== 'object') return { ok: false, fehler: 'Die Antwort des Dienstes hat nicht das erwartete Format.' };
    if (!Array.isArray(r.requirements)) return { ok: false, fehler: 'Die Antwort des Dienstes enthält keine Liste von Anforderungen.' };
    var liste = r.requirements.slice(0, MAX_ANFORDERUNGEN).map(anforderungLesen).filter(Boolean);
    if (!liste.length) return { ok: false, fehler: 'Der Dienst hat keine Anforderungen gefunden. Versuche es später noch einmal.' };
    var route = r.route && typeof r.route === 'object' ? r.route : {};
    return { ok: true, ergebnis: {
      zusammenfassung: kuerzen(r.summary), recherche: aus(RECHERCHE, r.researchStatus, 'teilweise'),
      warnungen: (Array.isArray(r.warnings) ? r.warnings : []).map(kuerzen).filter(Boolean).slice(0, 20),
      route: { status: text(route.routingStatus), zusammenfassung: kuerzen(route.summary),
        annahmen: (Array.isArray(route.assumptions) ? route.assumptions : []).map(kuerzen).filter(Boolean).slice(0, 10),
        hinweise: (Array.isArray(route.routeWarnings) ? route.routeWarnings : []).map(kuerzen).filter(Boolean).slice(0, 10) },
      anforderungen: liste },
      dienst: { modell: kuerzen(roh.model), anfrageId: kuerzen(roh.requestId), recherchiertAm: text(roh.researchedAt) || null } };
  }

  /* ---------- Auswertung ---------- */

  function rang(liste, wert) { var i = liste.indexOf(wert); return i < 0 ? liste.length : i; }

  /*
   * Gesamtbild: „fehlt“, wenn bei Pflicht oder Wichtig etwas fehlt, „pruefen“, wenn dort etwas zu prüfen ist
   * oder die Recherche nicht vollständig war, sonst „ok“. Empfohlen und Hinweis färben das Gesamtbild nie.
   */
  function auswerten(ergebnis) {
    var zaehl = { Fehlt: 0, 'Prüfen': 0, 'Erfüllt': 0, 'Nicht relevant': 0 };
    var wichtig = { fehlt: 0, pruefen: 0 };
    (ergebnis.anforderungen || []).forEach(function (a) {
      zaehl[a.status]++;
      if (a.kategorie === 'Pflicht' || a.kategorie === 'Wichtig') {
        if (a.status === 'Fehlt') wichtig.fehlt++;
        else if (a.status === 'Prüfen') wichtig.pruefen++;
      }
    });
    var gesamt = wichtig.fehlt ? 'fehlt' : ((wichtig.pruefen || ergebnis.recherche !== 'vollständig') ? 'pruefen' : 'ok');
    return { gesamt: gesamt, zaehl: zaehl, wichtigFehlt: wichtig.fehlt, wichtigPruefen: wichtig.pruefen };
  }

  /* Die Anforderungen, sortiert nach Kategorie, dann nach Dringlichkeit. */
  function sortiert(ergebnis) {
    return (ergebnis.anforderungen || []).map(function (a, i) { return { a: a, i: i }; }).sort(function (x, y) {
      return rang(KATEGORIEN, x.a.kategorie) - rang(KATEGORIEN, y.a.kategorie) || rang(STATUS, x.a.status) - rang(STATUS, y.a.status) || x.i - y.i;
    }).map(function (x) { return x.a; });
  }

  /* P1 → „Anna“ nur auf dem Gerät, für die Anzeige. */
  function subjektName(namen, key) { return (namen && namen[key]) || (key === 'trip' ? 'Reise' : key); }

  var GESAMT_TEXT = {
    ok: 'Keine offenen Punkte bei Pflicht und Wichtig',
    pruefen: 'Einiges ist noch zu prüfen',
    fehlt: 'Bei Pflicht oder Wichtig fehlt etwas'
  };

  MM.Reisecheck = {
    STATUS: STATUS, KATEGORIEN: KATEGORIEN, ZUSTIMMUNG_VERSION: ZUSTIMMUNG_VERSION, ZUSTIMMUNG_TEXT: ZUSTIMMUNG_TEXT, GESAMT_TEXT: GESAMT_TEXT,
    dienstAdresse: dienstAdresse, tokenPruefen: tokenPruefen, verkehrsarten: verkehrsarten,
    anfrageBauen: anfrageBauen, fahrzeugBlock: fahrzeugBlock, fingerabdruck: fingerabdruck, vorschau: vorschau,
    antwortPruefen: antwortPruefen, auswerten: auswerten, sortiert: sortiert, subjektName: subjektName
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
