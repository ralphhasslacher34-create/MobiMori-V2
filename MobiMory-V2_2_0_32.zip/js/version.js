/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.32';
  MM.STUFE = 'Kacheln: Text wird nie abgeschnitten, Titel bleiben ganze Wörter, Kacheln wachsen mit dem Text';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
