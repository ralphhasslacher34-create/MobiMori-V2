'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;

async function neu() {
  let t = 0;
  const uhr = () => new Date(Date.UTC(2026, 10, 3, 12, 0, t++)).toISOString();
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: uhr });
  await d.starten();
  const fz = await d.fahrzeugAnlegen('boot', { bezeichnung: 'Fahrzeug B' });
  return { d, fid: fz.id };
}

test('Hauptkomponente anlegen: erscheint in der Liste, Eintrag Nr. 1, ohne übergeordnete', async () => {
  const { d, fid } = await neu();
  const r = await d.komponenteAnlegen(fid, null, 'motor', { bezeichnung: 'Motor Backbord', hersteller: 'Volvo' });
  assert.ok(r.ok);
  const liste = await d.komponentenListe(fid);
  assert.equal(liste.length, 1);
  assert.equal(liste[0].komponente.parentId, null);
  assert.equal(liste[0].komponente.art, 'motor');
  assert.equal(liste[0].aktuell.nr, 1);
  assert.equal(liste[0].aktuell.quelle, 'hand');
  assert.equal(liste[0].aktuell.werte.hersteller, 'Volvo');
});

test('Beliebig tief verschachteln: Motor, Einspritzung, Pumpe', async () => {
  const { d, fid } = await neu();
  const m = await d.komponenteAnlegen(fid, null, 'motor', { bezeichnung: 'Motor' });
  const e = await d.komponenteAnlegen(fid, m.id, null, { bezeichnung: 'Einspritzung' });
  const p = await d.komponenteAnlegen(fid, e.id, null, { bezeichnung: 'Pumpe' });
  assert.ok(m.ok && e.ok && p.ok);
  const c = await d.komponenteLaden(p.id);
  assert.equal(c.tiefe, 5);
  assert.deepEqual(c.weg.map(x => x.aktuell.werte.bezeichnung), ['Motor', 'Einspritzung']);
  const cm = await d.komponenteLaden(m.id);
  assert.equal(cm.tiefe, 3);
  assert.equal(cm.kinder.length, 1);
  assert.equal(cm.kinder[0].aktuell.werte.bezeichnung, 'Einspritzung');
  assert.equal(cm.kinder[0].anzahlKinder, 1);
  assert.equal(cm.kinder[0].komponente.art, null);
});

test('Pflichtangaben: Bezeichnung und bei Hauptkomponenten die Art', async () => {
  const { d, fid } = await neu();
  const a = await d.komponenteAnlegen(fid, null, 'motor', { bezeichnung: ' ' });
  assert.equal(a.ok, false); assert.ok(a.fehler.bezeichnung);
  const b = await d.komponenteAnlegen(fid, null, null, { bezeichnung: 'X' });
  assert.equal(b.ok, false); assert.ok(b.fehler.art);
  const c = await d.komponenteAnlegen(fid, null, 'ufo', { bezeichnung: 'X' });
  assert.equal(c.ok, false);
  assert.equal((await d.komponentenListe(fid)).length, 0);
});

test('Komponente gehört immer zum richtigen Fahrzeug', async () => {
  const { d, fid } = await neu();
  const anderes = await d.fahrzeugAnlegen('auto', { bezeichnung: 'Fahrzeug A' });
  const m = await d.komponenteAnlegen(fid, null, 'motor', { bezeichnung: 'Motor' });
  const falsch = await d.komponenteAnlegen(anderes.id, m.id, null, { bezeichnung: 'Pumpe' });
  assert.equal(falsch.ok, false);
  const keinFz = await d.komponenteAnlegen('gibt-es-nicht', null, 'motor', { bezeichnung: 'Motor' });
  assert.equal(keinFz.ok, false);
  assert.equal((await d.komponentenListe(anderes.id)).length, 0);
});

test('Änderung = neuer Eintrag "Korrektur zu"; der alte bleibt sichtbar', async () => {
  const { d, fid } = await neu();
  const { id } = await d.komponenteAnlegen(fid, null, 'motor', { bezeichnung: 'Motor', hersteller: 'Volvo' });
  const vorher = await d.komponenteLaden(id);
  const r = await d.komponenteAendern(id, { bezeichnung: 'Motor', hersteller: 'Yanmar' });
  assert.ok(r.ok && r.geaendert);
  const nachher = await d.komponenteLaden(id);
  assert.equal(nachher.verlauf.length, 2);
  assert.equal(nachher.aktuell.werte.hersteller, 'Yanmar');
  assert.equal(nachher.aktuell.korrekturZu, vorher.aktuell.id);
  assert.deepEqual(nachher.verlauf[1].eintrag, vorher.aktuell);
  assert.deepEqual(nachher.verlauf[0].aenderungen.map(a => [a.label, a.alt, a.neu]), [['Hersteller', 'Volvo', 'Yanmar']]);
});

test('Speichern ohne Änderung legt keinen neuen Eintrag an', async () => {
  const { d, fid } = await neu();
  const { id } = await d.komponenteAnlegen(fid, null, 'klima', { bezeichnung: 'Klima', merkmale: [{ name: 'Leistung', wert: '2 kW' }] });
  const r = await d.komponenteAendern(id, { bezeichnung: 'Klima', merkmale: [{ name: 'Leistung', wert: '2 kW' }] });
  assert.ok(r.ok);
  assert.equal(r.geaendert, false);
  assert.equal((await d.komponenteLaden(id)).verlauf.length, 1);
});

test('Technische Merkmale: leere Zeilen entfallen, halbe Zeilen werden abgelehnt', async () => {
  const { d } = await neu();
  const ok = d.pruefenKomponente({ bezeichnung: 'M', merkmale: [{ name: ' Leistung ', wert: '110 kW' }, { name: '', wert: '' }] });
  assert.ok(ok.ok);
  assert.deepEqual(ok.werte.merkmale, [{ name: 'Leistung', wert: '110 kW' }]);
  assert.ok(d.pruefenKomponente({ bezeichnung: 'M', merkmale: [{ name: 'Leistung', wert: '' }] }).fehler.merkmale);
  assert.ok(d.pruefenKomponente({ bezeichnung: 'M', merkmale: [{ name: '', wert: '5' }] }).fehler.merkmale);
});

test('Änderung der Merkmale erscheint im Verlauf lesbar', async () => {
  const { d, fid } = await neu();
  const { id } = await d.komponenteAnlegen(fid, null, 'motor', { bezeichnung: 'Motor' });
  await d.komponenteAendern(id, { bezeichnung: 'Motor', merkmale: [{ name: 'Leistung', wert: '110 kW' }, { name: 'Zylinder', wert: '4' }] });
  const c = await d.komponenteLaden(id);
  const u = c.verlauf[0].aenderungen[0];
  assert.equal(u.label, 'Technische Merkmale');
  assert.equal(MM.Hilfen.wert(u.feld, u.neu), 'Leistung: 110 kW; Zylinder: 4');
  assert.equal(MM.Hilfen.wert(u.feld, u.alt), null);
});

test('Einbau und Ausbau: Datum geprüft, Ausbau nicht vor Einbau', async () => {
  const { d } = await neu();
  assert.ok(d.pruefenKomponente({ bezeichnung: 'M', eingebautAm: '2020-05-01', ausgebautAm: '2019-01-01' }).fehler.ausgebautAm);
  assert.ok(d.pruefenKomponente({ bezeichnung: 'M', eingebautAm: '2020-05-01', ausgebautAm: '2021-01-01' }).ok);
  assert.ok(d.pruefenKomponente({ bezeichnung: 'M', eingebautAm: '2020-02-30' }).fehler.eingebautAm);
  assert.ok(d.pruefenKomponente({ bezeichnung: 'M', baujahr: '1500' }).fehler.baujahr);
});

test('Hauptkomponenten sind nach Art sortiert, Teile nach Bezeichnung', async () => {
  const { d, fid } = await neu();
  await d.komponenteAnlegen(fid, null, 'wasser', { bezeichnung: 'Frischwasser' });
  const m = await d.komponenteAnlegen(fid, null, 'motor', { bezeichnung: 'Motor' });
  await d.komponenteAnlegen(fid, null, 'heizung', { bezeichnung: 'Heizung' });
  await d.komponenteAnlegen(fid, m.id, null, { bezeichnung: 'Pumpe 10' });
  await d.komponenteAnlegen(fid, m.id, null, { bezeichnung: 'Pumpe 2' });
  const alle = await d.komponentenListe(fid);
  const haupt = d.sortiereKomponenten(alle.filter(x => !x.komponente.parentId));
  assert.deepEqual(haupt.map(x => x.aktuell.werte.bezeichnung), ['Motor', 'Heizung', 'Frischwasser']);
  const cm = await d.komponenteLaden(m.id);
  assert.deepEqual(cm.kinder.map(x => x.aktuell.werte.bezeichnung), ['Pumpe 2', 'Pumpe 10']);
});

test('Komponenten gehören zu ihrem Fahrzeug und trennen sich sauber', async () => {
  const { d, fid } = await neu();
  const a = await d.fahrzeugAnlegen('auto', { bezeichnung: 'Fahrzeug A' });
  await d.komponenteAnlegen(fid, null, 'motor', { bezeichnung: 'Motor Boot' });
  await d.komponenteAnlegen(a.id, null, 'motor', { bezeichnung: 'Motor Auto' });
  assert.deepEqual((await d.komponentenListe(fid)).map(x => x.aktuell.werte.bezeichnung), ['Motor Boot']);
  assert.deepEqual((await d.komponentenListe(a.id)).map(x => x.aktuell.werte.bezeichnung), ['Motor Auto']);
});

test('Art-Liste: sieben Arten in der festgelegten Reihenfolge', () => {
  assert.deepEqual(MM.Komponenten.arten().map(a => a.name),
    ['Motor', 'Getriebe', 'Heizung', 'Klima', 'Stromversorgung', 'Wasserversorgung', 'Sonstiges']);
});

test('Nach dem Löschen aller Daten sind auch die Komponenten weg', async () => {
  const { d, fid } = await neu();
  await d.komponenteAnlegen(fid, null, 'motor', { bezeichnung: 'Motor' });
  await d.allesLoeschen();
  assert.equal((await d.speicher.alle('komponenten')).length, 0);
  assert.equal((await d.speicher.alle('komponenteneintraege')).length, 0);
});
