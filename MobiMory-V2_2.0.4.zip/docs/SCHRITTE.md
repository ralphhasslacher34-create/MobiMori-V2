# Schritte beim Aufbau von V2

Grundlage ist das Dokument „MobiMory V2 – Festlegungen und Datenstruktur“.
Jeder Schritt baut auf dem letzten auf und endet mit einem sichtbaren Ergebnis.

| Schritt | Inhalt | Stand |
|---|---|---|
| 1 | Fahrzeug: Fahrzeugliste (Schale 1) und äußere Hülle (Schale 2), Handeingabe, Verlauf, offline | fertig (2.0.1) |
| 1a | Ansicht der äußeren Schalen: Startseite, Hauptmenü, Stammdaten, Neu im Programm, Einstellungen | fertig (2.0.2) |
| 2 | Hauptkomponenten (Schale 3), beliebig tief verschachtelt, mit Hersteller, Modell, Seriennummer, Baujahr, Einbau, technischen Merkmalen | fertig (2.0.4) |
| 3 | Fristen an Fahrzeug und Komponenten (Kalender und Zähler), Zählerstände | offen |
| … | Weitere Schritte nach der Reihenfolge im Festlegungsdokument | offen |

## Noch nicht drin, weil sie auf anderen Teilen aufbauen
- Feste Standorte der äußeren Hülle: kommen mit Orten und Standorten.
- Konto und Anmeldung, Server, Sicherung: kommen später. Schritt 1 arbeitet nur lokal (Basis-Version).
- Wertverlauf und Kosten: kommen mit der Kostenstruktur.
- Fristen, Kosten und Nachweise an den Komponenten: kommen mit den jeweiligen Schritten.
- Feste Merkmal-Kataloge je Komponente (bisher frei eintragbar): im Festlegungsdokument noch nicht besprochen.
- Funktionen, Personen und Tiere: Kacheln sind da und zeigen „kommt“.
