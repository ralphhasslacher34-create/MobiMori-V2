/*
 * Daten: die EINE Tür zu allen Fahrzeugdaten.
 *
 * Regeln aus den V2-Festlegungen, die hier gelten:
 *  - Eine Quelle: alle Teile der App fragen nur hier nach.
 *  - Handeingabe hat Vorrang. Es wird nichts überschrieben: Jede Änderung
 *    ist ein neuer Eintrag "Korrektur zu ...", der alte bleibt sichtbar.
 *  - Nichts wird gelöscht.
 *  - Jeder Eintrag nennt seine Herkunft (hier: "hand").
 *
 * Aufbau der gespeicherten Daten:
 *  datenraum   { id, name, erstelltAm }
 *  fahrzeug    { id, datenraumId, art, erstelltAm }
 *  eintrag     { id, fahrzeugId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  komponente  { id, fahrzeugId, parentId, art, erstelltAm }
 *              parentId = null: Hauptkomponente (dann gilt "art"), sonst gehört
 *              sie zu einer anderen Komponente ("gehört zu").
 *  komponenteneintrag { id, komponenteId, nr, werte, quelle, korrekturZu, erstelltAm }
 *
 * "werte" enthält Bezeichnung und alle Felder. Der aktuelle Stand ist der
 * Eintrag mit der höchsten Nummer.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  function neueId(praefix) {
    var c = global.crypto;
    if (c && typeof c.randomUUID === 'function') return praefix + '-' + c.randomUUID();
    return praefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function Daten(speicher, optionen) {
    this.speicher = speicher;
    this.jetzt = (optionen && optionen.jetzt) || function () { return new Date().toISOString(); };
    this.datenraumId = null;
  }

  /* Beim ersten Start entsteht der eigene Datenraum auf diesem Gerät. */
  Daten.prototype.starten = function () {
    var self = this;
    return this.speicher.alle('datenraeume').then(function (liste) {
      if (liste.length) { self.datenraumId = liste[0].id; return liste[0]; }
      var dr = { id: neueId('dr'), name: 'Mein Datenraum', erstelltAm: self.jetzt() };
      return self.speicher.speichern('datenraeume', dr).then(function () {
        self.datenraumId = dr.id;
        return dr;
      });
    });
  };

  /* ---------- Prüfen und in saubere Werte umwandeln ---------- */
  function pruefeWerte(felder, roh, jahr) {
    var werte = {};
    var fehler = {};
    roh = roh || {};

    var bez = String(roh.bezeichnung == null ? '' : roh.bezeichnung).trim();
    if (!bez) fehler.bezeichnung = 'Bitte eine Bezeichnung eingeben, zum Beispiel „Fahrzeug A“.';
    werte.bezeichnung = bez;

    felder.forEach(function (f) {
      if (f.typ === 'liste') {
        var zeilen = Array.isArray(roh[f.key]) ? roh[f.key] : [];
        var sauber = [];
        zeilen.forEach(function (z) {
          var n = String(z && z.name != null ? z.name : '').trim();
          var w = String(z && z.wert != null ? z.wert : '').trim();
          if (!n && !w) return;
          if (!n || !w) fehler[f.key] = 'Bitte bei jedem Merkmal Name und Wert eingeben.';
          sauber.push({ name: n, wert: w });
        });
        werte[f.key] = sauber;
        return;
      }

      var v = roh[f.key];
      v = (v === undefined || v === null) ? '' : v;
      if (typeof v === 'string') v = v.trim();

      if (f.typ === 'text') { werte[f.key] = v === '' ? null : String(v); return; }

      if (f.typ === 'auswahl') {
        if (v === '') { werte[f.key] = null; return; }
        if (f.optionen.indexOf(v) < 0) { fehler[f.key] = 'Bitte eine Möglichkeit aus der Liste wählen.'; }
        werte[f.key] = v;
        return;
      }

      if (f.typ === 'datum') {
        if (v === '') { werte[f.key] = null; return; }
        var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
        var d = m ? new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])) : null;
        if (!d || d.getUTCFullYear() !== +m[1] || d.getUTCMonth() !== +m[2] - 1 || d.getUTCDate() !== +m[3]) {
          fehler[f.key] = 'Bitte ein gültiges Datum eingeben.';
          werte[f.key] = null;
        } else { werte[f.key] = v; }
        return;
      }

      /* zahl und ganzzahl: Komma oder Punkt als Dezimalzeichen erlaubt */
      if (v === '') { werte[f.key] = null; return; }
      var text = String(v).replace(/\s/g, '').replace(',', '.');
      var n = /^-?\d+(\.\d+)?$/.test(text) ? Number(text) : NaN;
      if (isNaN(n)) {
        fehler[f.key] = f.typ === 'ganzzahl' ? 'Bitte eine ganze Zahl eingeben.' : 'Bitte eine Zahl eingeben, zum Beispiel 2,5.';
        werte[f.key] = null;
        return;
      }
      if (f.typ === 'ganzzahl' && Math.floor(n) !== n) { fehler[f.key] = 'Bitte eine ganze Zahl eingeben.'; werte[f.key] = null; return; }
      if (n < 0) { fehler[f.key] = 'Die Zahl darf nicht negativ sein.'; werte[f.key] = null; return; }
      if (f.key === 'baujahr' && (n < f.min || n > jahr + 1)) {
        fehler[f.key] = 'Bitte ein Baujahr zwischen ' + f.min + ' und ' + (jahr + 1) + ' eingeben.';
        werte[f.key] = null; return;
      }
      if (f.min !== undefined && f.key !== 'baujahr' && n < f.min) { fehler[f.key] = 'Der Wert muss mindestens ' + f.min + ' sein.'; werte[f.key] = null; return; }
      if (f.max !== undefined && n > f.max) { fehler[f.key] = 'Der Wert darf höchstens ' + f.max + ' sein.'; werte[f.key] = null; return; }
      werte[f.key] = n;
    });

    return { werte: werte, fehler: fehler, ok: Object.keys(fehler).length === 0 };
  }

  Daten.prototype.pruefen = function (artId, roh) {
    return pruefeWerte(MM.Fahrzeugarten.felder(artId), roh, new Date(this.jetzt()).getFullYear());
  };

  Daten.prototype.pruefenKomponente = function (roh) {
    var p = pruefeWerte(MM.Komponenten.felder(), roh, new Date(this.jetzt()).getFullYear());
    var w = p.werte;
    if (w.eingebautAm && w.ausgebautAm && w.ausgebautAm < w.eingebautAm && !p.fehler.ausgebautAm) {
      p.fehler.ausgebautAm = 'Der Ausbau kann nicht vor dem Einbau liegen.';
      p.ok = false;
    }
    return p;
  };

  /* ---------- Unterschiede zwischen zwei Ständen ---------- */
  function gleich(a, b) {
    if (a === b) return true;
    var la = Array.isArray(a) ? a : (a === null || a === undefined ? [] : null);
    var lb = Array.isArray(b) ? b : (b === null || b === undefined ? [] : null);
    if (la && lb) return JSON.stringify(la) === JSON.stringify(lb);
    return false;
  }

  function unterschiedeFelder(felder, alt, neu) {
    var liste = [{ key: 'bezeichnung', label: 'Bezeichnung' }].concat(felder);
    var res = [];
    liste.forEach(function (f) {
      var a = alt[f.key] === undefined ? null : alt[f.key];
      var n = neu[f.key] === undefined ? null : neu[f.key];
      if (!gleich(a, n)) res.push({ key: f.key, label: f.label, feld: f, alt: a, neu: n });
    });
    return res;
  }

  Daten.prototype.unterschiede = function (artId, alt, neu) {
    return unterschiedeFelder(MM.Fahrzeugarten.felder(artId), alt, neu);
  };

  function neuester(eintraege) {
    return eintraege.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
  }
  function nachNr(a, b) { return a.nr - b.nr; }

  /* ---------- Fahrzeuge ---------- */
  Daten.prototype.fahrzeugAnlegen = function (artId, roh) {
    if (!MM.Fahrzeugarten.art(artId)) {
      return Promise.resolve({ ok: false, fehler: { art: 'Bitte zuerst die Fahrzeugart wählen.' } });
    }
    var p = this.pruefen(artId, roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var jetzt = this.jetzt();
    var fahrzeug = { id: neueId('fz'), datenraumId: this.datenraumId, art: artId, erstelltAm: jetzt };
    var eintrag = { id: neueId('en'), fahrzeugId: fahrzeug.id, nr: 1, werte: p.werte,
      quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
    return this.speicher.mehrereSpeichern([
      { tabelle: 'fahrzeuge', objekt: fahrzeug },
      { tabelle: 'eintraege', objekt: eintrag }
    ]).then(function () { return { ok: true, id: fahrzeug.id }; });
  };

  /* Änderung = neuer Eintrag. Der alte bleibt unverändert erhalten. */
  Daten.prototype.fahrzeugAendern = function (fahrzeugId, roh) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      var p = self.pruefen(f.fahrzeug.art, roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var diff = self.unterschiede(f.fahrzeug.art, f.aktuell.werte, p.werte);
      if (!diff.length) return { ok: true, id: fahrzeugId, geaendert: false };
      var eintrag = { id: neueId('en'), fahrzeugId: fahrzeugId, nr: f.aktuell.nr + 1, werte: p.werte,
        quelle: 'hand', korrekturZu: f.aktuell.id, erstelltAm: self.jetzt() };
      return self.speicher.speichern('eintraege', eintrag)
        .then(function () { return { ok: true, id: fahrzeugId, geaendert: true }; });
    });
  };

  /* Alle Fahrzeuge des Datenraums, jeweils mit aktuellem Stand (Schale 1). */
  Daten.prototype.fahrzeugListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('fahrzeuge'), this.speicher.alle('eintraege')]).then(function (r) {
      var nachFahrzeug = {};
      r[1].forEach(function (e) { (nachFahrzeug[e.fahrzeugId] = nachFahrzeug[e.fahrzeugId] || []).push(e); });
      var liste = r[0].filter(function (f) { return f.datenraumId === self.datenraumId; })
        .map(function (f) { return { fahrzeug: f, aktuell: neuester(nachFahrzeug[f.id] || []) }; })
        .filter(function (x) { return x.aktuell; });
      liste.sort(function (a, b) {
        return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return liste;
    });
  };

  /* Ein Fahrzeug mit aktuellem Stand und dem ganzen Verlauf (neueste zuerst). */
  Daten.prototype.fahrzeugLaden = function (id) {
    var self = this;
    return Promise.all([this.speicher.holen('fahrzeuge', id), this.speicher.wo('eintraege', 'fahrzeugId', id)])
      .then(function (r) {
        var fahrzeug = r[0];
        if (!fahrzeug || !r[1].length) return null;
        var eintraege = r[1].slice().sort(nachNr);
        var verlauf = eintraege.map(function (e, i) {
          var vorher = i > 0 ? eintraege[i - 1] : null;
          return { eintrag: e, vorher: vorher,
            aenderungen: vorher ? self.unterschiede(fahrzeug.art, vorher.werte, e.werte) : [] };
        }).reverse();
        return { fahrzeug: fahrzeug, aktuell: eintraege[eintraege.length - 1], verlauf: verlauf };
      });
  };

  /* ---------- Komponenten (Schale 3 und tiefer) ---------- */

  /* Alle Komponenten eines Fahrzeugs mit aktuellem Stand, unsortiert. */
  Daten.prototype.komponentenListe = function (fahrzeugId) {
    return Promise.all([this.speicher.wo('komponenten', 'fahrzeugId', fahrzeugId), this.speicher.alle('komponenteneintraege')])
      .then(function (r) {
        var nach = {};
        r[1].forEach(function (e) { (nach[e.komponenteId] = nach[e.komponenteId] || []).push(e); });
        return r[0].map(function (k) {
          var eintraege = (nach[k.id] || []).slice().sort(nachNr);
          return { komponente: k, eintraege: eintraege, aktuell: eintraege[eintraege.length - 1] || null };
        }).filter(function (x) { return x.aktuell; });
      });
  };

  /* Reihenfolge: Hauptkomponenten nach Art, sonst nach Bezeichnung. */
  Daten.prototype.sortiereKomponenten = function (liste) {
    return liste.slice().sort(function (a, b) {
      var ia = MM.Komponenten.artIndex(a.komponente.art), ib = MM.Komponenten.artIndex(b.komponente.art);
      if (!a.komponente.parentId && !b.komponente.parentId && ia !== ib) return ia - ib;
      return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
  };

  /*
   * Neue Komponente. parentId = null: Hauptkomponente (art ist dann Pflicht),
   * sonst gehört sie zu der genannten Komponente (Art entfällt).
   */
  Daten.prototype.komponenteAnlegen = function (fahrzeugId, parentId, artId, roh) {
    var self = this;
    var p = this.pruefenKomponente(roh);
    var fehler = p.fehler;
    if (!parentId && !MM.Komponenten.art(artId)) fehler.art = 'Bitte zuerst die Art der Hauptkomponente wählen.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    return Promise.all([
      this.speicher.holen('fahrzeuge', fahrzeugId),
      parentId ? this.speicher.holen('komponenten', parentId) : Promise.resolve(null)
    ]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (parentId && (!r[1] || r[1].fahrzeugId !== fahrzeugId)) {
        return { ok: false, fehler: { allgemein: 'Die übergeordnete Komponente wurde nicht gefunden.' } };
      }
      var jetzt = self.jetzt();
      var k = { id: neueId('ko'), fahrzeugId: fahrzeugId, parentId: parentId || null,
        art: parentId ? null : artId, erstelltAm: jetzt };
      var e = { id: neueId('ke'), komponenteId: k.id, nr: 1, werte: p.werte,
        quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'komponenten', objekt: k },
        { tabelle: 'komponenteneintraege', objekt: e }
      ]).then(function () { return { ok: true, id: k.id }; });
    });
  };

  /* Änderung = neuer Eintrag, wie beim Fahrzeug. */
  Daten.prototype.komponenteAendern = function (komponenteId, roh) {
    var self = this;
    return this.komponenteLaden(komponenteId).then(function (c) {
      if (!c) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      var p = self.pruefenKomponente(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var diff = unterschiedeFelder(MM.Komponenten.felder(), c.aktuell.werte, p.werte);
      if (!diff.length) return { ok: true, id: komponenteId, geaendert: false };
      var e = { id: neueId('ke'), komponenteId: komponenteId, nr: c.aktuell.nr + 1, werte: p.werte,
        quelle: 'hand', korrekturZu: c.aktuell.id, erstelltAm: self.jetzt() };
      return self.speicher.speichern('komponenteneintraege', e)
        .then(function () { return { ok: true, id: komponenteId, geaendert: true }; });
    });
  };

  /*
   * Eine Komponente mit Stand, Verlauf, dem Weg von der Hauptkomponente bis
   * zu ihr (weg), den Teilen direkt darunter (kinder) und dem Fahrzeug.
   * tiefe: 3 = Hauptkomponente (Schale 3), 4 = Teil darunter, usw.
   */
  Daten.prototype.komponenteLaden = function (id) {
    var self = this;
    return this.speicher.holen('komponenten', id).then(function (k) {
      if (!k) return null;
      return Promise.all([self.komponentenListe(k.fahrzeugId), self.fahrzeugLaden(k.fahrzeugId)]).then(function (r) {
        var alle = r[0], fz = r[1];
        var nachId = {};
        alle.forEach(function (x) { nachId[x.komponente.id] = x; });
        var ich = nachId[id];
        if (!ich || !fz) return null;

        var weg = [];
        var p = ich.komponente.parentId;
        while (p && nachId[p]) { weg.unshift(nachId[p]); p = nachId[p].komponente.parentId; }

        function anzahlKinder(x) {
          return alle.filter(function (y) { return y.komponente.parentId === x.komponente.id; }).length;
        }
        var kinder = self.sortiereKomponenten(alle.filter(function (x) { return x.komponente.parentId === id; }))
          .map(function (x) { return { komponente: x.komponente, aktuell: x.aktuell, anzahlKinder: anzahlKinder(x) }; });

        var felder = MM.Komponenten.felder();
        var verlauf = ich.eintraege.map(function (e, i) {
          var vorher = i > 0 ? ich.eintraege[i - 1] : null;
          return { eintrag: e, vorher: vorher, aenderungen: vorher ? unterschiedeFelder(felder, vorher.werte, e.werte) : [] };
        }).reverse();

        return { komponente: ich.komponente, aktuell: ich.aktuell, verlauf: verlauf, weg: weg, kinder: kinder,
          fahrzeug: fz.fahrzeug, fahrzeugAktuell: fz.aktuell, tiefe: weg.length + 3 };
      });
    });
  };

  /* Nur für Tests auf dem eigenen Gerät. */
  Daten.prototype.allesLoeschen = function () {
    var self = this;
    return this.speicher.allesLoeschen().then(function () { return self.starten(); });
  };

  MM.Daten = { Daten: Daten };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
