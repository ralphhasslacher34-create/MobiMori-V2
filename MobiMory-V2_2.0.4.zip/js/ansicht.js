/*
 * Ansicht: was der Nutzer sieht.
 *
 * Seiten (Adresse hinter dem #):
 *   #/                         Startseite
 *   #/auswahl                  Hauptmenü (Stammdaten, Funktionen, Einstellungen)
 *   #/stammdaten               Stammdaten (Fahrzeuge, Personen, Tiere)
 *   #/fahrzeuge                Meine Fahrzeuge (Schale 1)
 *   #/neu-im-programm          Neu im Programm
 *   #/einstellungen            Einstellungen
 *   #/fahrzeug/<id>/komponente/neu   Hauptkomponente anlegen
 *   #/komponente/<id>          Komponente (Schale 3 und tiefer)
 *   #/komponente/<id>/neu      Teil darunter anlegen
 *   #/komponente/<id>/aendern  Komponente ändern
 *   #/neu                      Fahrzeug anlegen
 *   #/fahrzeug/<id>            Fahrzeug mit äußerer Hülle (Schale 2)
 *   #/fahrzeug/<id>/aendern    Angaben ändern
 *
 * Alle Texte kommen mit textContent in die Seite, nie als HTML.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  var doc = global.document;

  var daten = null;
  var wurzel = null;
  var meldung = null; /* wird einmal auf der nächsten Seite gezeigt */

  /* ---------- kleine Bauhelfer ---------- */
  function anhaengen(el, kind) {
    if (kind === null || kind === undefined || kind === false) return;
    if (Array.isArray(kind)) { kind.forEach(function (k) { anhaengen(el, k); }); return; }
    if (typeof kind === 'string' || typeof kind === 'number') { el.appendChild(doc.createTextNode(String(kind))); return; }
    el.appendChild(kind);
  }
  function h(tag, attrs) {
    var el = doc.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) return;
        if (k === 'text') el.textContent = v;
        else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
        else if (k === 'value') el.value = v;
        else el.setAttribute(k, v === true ? '' : v);
      });
    }
    for (var i = 2; i < arguments.length; i++) anhaengen(el, arguments[i]);
    return el;
  }

  function kopf() {
    return h('header', { class: 'kopf' },
      h('a', { href: '#/auswahl' }, h('img', { class: 'marke', src: 'icons/icon.svg', alt: '', width: '32', height: '32' }), 'MobiMory'),
      h('span', { class: 'version', text: 'Version ' + MM.VERSION }));
  }

  function fuss() {
    return h('footer', { class: 'fuss' }, h('p', { text: MM.Texte.COPYRIGHT }));
  }

  /* Wo-bin-ich-Zeile: Liste aus [Text, Adresse]; der letzte Eintrag hat keine Adresse. */
  function krumen(liste) {
    var nav = h('nav', { class: 'krumen', 'aria-label': 'Wo du bist' });
    liste.forEach(function (k, i) {
      if (i) nav.appendChild(doc.createTextNode(' › '));
      nav.appendChild(k[1] ? h('a', { href: k[1], text: k[0] }) : doc.createTextNode(k[0]));
    });
    return nav;
  }
  var WEG_FAHRZEUGE = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Fahrzeuge', '#/fahrzeuge']];

  function seite(titel, inhalt, leiste) {
    doc.title = titel + ' – MobiMory';
    wurzel.textContent = '';
    var main = h('main', { class: 'inhalt', id: 'inhalt' });
    if (meldung) { main.appendChild(h('p', { class: 'meldung', role: 'status', text: meldung })); meldung = null; }
    anhaengen(main, inhalt);
    wurzel.appendChild(kopf());
    wurzel.appendChild(main);
    wurzel.appendChild(fuss());
    if (leiste) wurzel.appendChild(leiste);
    var h1 = main.querySelector('h1');
    if (h1) { h1.setAttribute('tabindex', '-1'); h1.focus({ preventScroll: true }); }
    global.scrollTo(0, 0);
  }

  function schild(artId, kennung) {
    var a = MM.Fahrzeugarten.art(artId);
    if (!kennung) return h('span', { class: 'schild leer', text: 'ohne Kennung' });
    return h('span', { class: 'schild welt-' + a.welt, text: kennung });
  }
  function kennungVon(artId, werte) { return werte[MM.Fahrzeugarten.kennungFeld(artId)] || ''; }

  /* ---------- Seite: Meine Fahrzeuge ---------- */
  function seiteListe() {
    return daten.fahrzeugListe().then(function (liste) {
      var inhalt = [krumen(WEG_FAHRZEUGE.slice(0, 2).concat([['Fahrzeuge']])), h('h1', { text: 'Meine Fahrzeuge' })];
      if (!liste.length) {
        inhalt.push(h('div', { class: 'leer-hinweis' },
          h('p', { text: 'Hier ist noch kein Fahrzeug.' }),
          h('p', { text: 'Lege dein erstes Fahrzeug an. Es genügt zuerst die Bezeichnung und die Fahrzeugart. Alles andere kannst du jederzeit nachtragen.' })));
      } else {
        inhalt.push(h('ul', { class: 'liste' }, liste.map(function (x) {
          var a = MM.Fahrzeugarten.art(x.fahrzeug.art);
          return h('li', null, h('a', { class: 'zeile welt-' + a.welt, href: '#/fahrzeug/' + encodeURIComponent(x.fahrzeug.id) },
            h('span', { class: 'zeile-text' },
              h('strong', { class: 'zeile-name', text: x.aktuell.werte.bezeichnung }),
              h('span', { class: 'zeile-art', text: a.name })),
            schild(a.id, kennungVon(a.id, x.aktuell.werte))));
        })));
      }
      seite('Meine Fahrzeuge', inhalt,
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
          h('a', { class: 'knopf', href: '#/neu', text: 'Fahrzeug anlegen' })));
    });
  }

  /* ---------- Verlauf (gleich für Fahrzeuge und Komponenten) ---------- */
  function verlaufBlock(verlauf) {
    return h('details', { class: 'verlauf' },
      h('summary', { text: 'Verlauf der Eintragungen (' + verlauf.length + ')' }),
      h('ol', null, verlauf.map(function (v, i) {
        var e = v.eintrag;
        var kopfzeile = h('div', null,
          h('span', { class: 'wann', text: MM.Hilfen.zeitpunkt(e.erstelltAm) }),
          i === 0 ? h('span', { class: 'marke-aktuell', text: 'aktuell' }) : null);
        var text;
        if (!v.vorher) text = h('div', { text: 'Angelegt, per Handeingabe' });
        else text = h('div', null,
          h('span', { class: 'korrektur', text: 'Korrektur zu Eintrag vom ' + MM.Hilfen.zeitpunkt(v.vorher.erstelltAm) }),
          h('ul', null, v.aenderungen.map(function (u) {
            var alt = MM.Hilfen.wert(u.feld, u.alt), neu = MM.Hilfen.wert(u.feld, u.neu);
            return h('li', null, u.label + ': ',
              h('span', { class: 'alt', text: alt === null ? 'nicht angegeben' : alt }), ' → ',
              neu === null ? 'nicht angegeben' : neu);
          })));
        return h('li', { class: i === 0 ? 'aktuell' : null }, kopfzeile, text);
      })));
  }

  /* ---------- Liste von Komponenten (Hauptkomponenten oder Teile) ---------- */
  function komponentenKarte(x, anzahlKinder) {
    var w = x.aktuell.werte;
    var art = x.komponente.parentId ? null : MM.Komponenten.art(x.komponente.art);
    var zeile2 = [art ? art.name : null, [w.hersteller, w.modell].filter(Boolean).join(' ')].filter(Boolean).join(', ');
    return h('li', null, h('a', { class: 'teil', href: '#/komponente/' + encodeURIComponent(x.komponente.id) },
      h('span', { class: 'teil-text' },
        h('strong', { class: 'teil-name', text: w.bezeichnung }),
        zeile2 ? h('span', { class: 'teil-info', text: zeile2 }) : null),
      anzahlKinder ? h('span', { class: 'teil-zahl', text: anzahlKinder === 1 ? '1 Teil darunter' : anzahlKinder + ' Teile darunter' }) : null));
  }

  /* Eingebaute zuerst, ausgebaute eingeklappt darunter. */
  function komponentenListeBlock(eintraege, anzahlVon) {
    var drin = eintraege.filter(function (x) { return !x.aktuell.werte.ausgebautAm; });
    var raus = eintraege.filter(function (x) { return x.aktuell.werte.ausgebautAm; });
    return [
      drin.length ? h('ul', { class: 'teile' }, drin.map(function (x) { return komponentenKarte(x, anzahlVon(x)); })) : null,
      raus.length ? h('details', { class: 'ausgebaut' },
        h('summary', { text: 'Ausgebaut (' + raus.length + ')' }),
        h('ul', { class: 'teile' }, raus.map(function (x) { return komponentenKarte(x, anzahlVon(x)); }))) : null
    ];
  }

  /* ---------- Seite: Fahrzeug mit Schalen ---------- */
  function seiteFahrzeug(id) {
    return Promise.all([daten.fahrzeugLaden(id), daten.komponentenListe(id)]).then(function (r) {
      var f = r[0], komp = r[1];
      if (!f) { return seite('Nicht gefunden', [h('h1', { text: 'Fahrzeug nicht gefunden' }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]); }
      var a = MM.Fahrzeugarten.art(f.fahrzeug.art);
      var w = f.aktuell.werte;

      var gruppen = MM.Fahrzeugarten.gruppen(a.id).map(function (g) {
        var gefuellt = [], offen = [];
        g.felder.forEach(function (fe) {
          var t = MM.Hilfen.wert(fe, w[fe.key]);
          if (t === null) offen.push(fe.label); else gefuellt.push([h('dt', { text: fe.label }), h('dd', { text: t })]);
        });
        return h('section', { class: 'gruppe' },
          h('h3', { text: g.titel }),
          gefuellt.length ? h('dl', { class: 'daten' }, gefuellt) : null,
          offen.length ? h('p', { class: 'offen', text: 'Noch nicht angegeben: ' + offen.join(', ') }) : null);
      });

      var haupt = daten.sortiereKomponenten(komp.filter(function (x) { return !x.komponente.parentId; }));
      function kinderVon(x) { return komp.filter(function (y) { return y.komponente.parentId === x.komponente.id; }).length; }
      var s3 = h('section', { class: 'schale s3 live', 'aria-label': 'Hauptkomponenten' },
        h('div', { class: 'schale-name', text: 'Dritte Schale' }),
        h('h2', { text: 'Hauptkomponenten' }),
        haupt.length ? komponentenListeBlock(haupt, kinderVon)
          : h('p', { class: 'leer-text', text: 'Noch keine Hauptkomponente. Lege zum Beispiel Motor, Getriebe oder Heizung an. Darunter lässt sich beliebig tief aufschlüsseln.' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(id) + '/komponente/neu', text: 'Hauptkomponente hinzufügen' }));

      var s2 = h('section', { class: 'schale s2', 'aria-label': 'Äußere Hülle' },
        h('div', { class: 'schale-kopf' },
          h('div', { class: 'schale-name', text: 'Zweite Schale' }),
          h('h2', { text: 'Äußere Hülle' })),
        gruppen,
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(f.aktuell.erstelltAm) + ', per Handeingabe' }),
        s3);

      var s1 = h('div', { class: 'schale s1' },
        h('div', { class: 'schale-kopf' },
          h('div', { class: 'schale-name', text: 'Erste Schale: ' + a.name }),
          h('div', { class: 'fahrzeug-kopf' },
            h('h1', { text: w.bezeichnung }),
            schild(a.id, kennungVon(a.id, w)))),
        s2);

      var verlauf = verlaufBlock(f.verlauf);

      seite(w.bezeichnung, [
        krumen(WEG_FAHRZEUGE.concat([[w.bezeichnung]])),
        s1, verlauf
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/fahrzeuge', text: 'Zur Liste' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
    });
  }

  /* ---------- Seite: anlegen / ändern ---------- */
  function feldElement(f, wert, fehler, aenderung) {
    var id = 'f-' + f.key;
    var eingabe;
    if (f.typ === 'auswahl') {
      eingabe = h('select', { id: id, name: f.key, onchange: aenderung },
        h('option', { value: '', text: '– bitte wählen –' }),
        f.optionen.map(function (o) { return h('option', { value: o, text: o }); }));
      eingabe.value = wert || '';
    } else if (f.typ === 'datum') {
      eingabe = h('input', { id: id, name: f.key, type: 'date', value: wert || '', oninput: aenderung });
    } else {
      eingabe = h('input', { id: id, name: f.key, type: 'text', autocomplete: 'off', autocapitalize: f.typ === 'text' ? 'sentences' : 'off',
        inputmode: f.typ === 'zahl' ? 'decimal' : (f.typ === 'ganzzahl' ? 'numeric' : null),
        value: wert === null || wert === undefined ? '' : String(wert).replace('.', f.typ === 'zahl' ? ',' : '.'),
        'aria-describedby': f.hilfe ? id + '-h' : null, 'aria-invalid': fehler ? 'true' : null, oninput: aenderung });
    }
    return h('div', { class: 'feld' + (fehler ? ' hat-fehler' : '') },
      h('label', { for: id, text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', id: id + '-h', text: f.hilfe }) : null,
      h('div', { class: 'eingabe' }, eingabe, f.einheit ? h('span', { class: 'einheit', text: f.einheit }) : null),
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null);
  }

  function seiteFormular(modus, fahrzeugId) {
    var laden = modus === 'aendern' ? daten.fahrzeugLaden(fahrzeugId) : Promise.resolve(null);
    return laden.then(function (vorhanden) {
      if (modus === 'aendern' && !vorhanden) return seiteFahrzeug(fahrzeugId);
      var zustand = {
        art: vorhanden ? vorhanden.fahrzeug.art : null,
        werte: vorhanden ? Object.assign({}, vorhanden.aktuell.werte) : {},
        fehler: {}
      };
      var titel = modus === 'aendern' ? 'Angaben ändern' : 'Fahrzeug anlegen';
      var behaelter = h('div');

      function lesen() {
        /* Eingaben aus dem Formular in den Zustand übernehmen */
        var felder = behaelter.querySelectorAll('input[name], select[name]');
        Array.prototype.forEach.call(felder, function (el) {
          if (el.type === 'radio') return;
          zustand.werte[el.name] = el.value;
        });
      }

      function speichern(ev) {
        ev.preventDefault();
        lesen();
        var p = modus === 'aendern'
          ? daten.fahrzeugAendern(fahrzeugId, zustand.werte)
          : daten.fahrzeugAnlegen(zustand.art, zustand.werte);
        p.then(function (r) {
          if (!r.ok) {
            zustand.fehler = r.fehler;
            zeichne();
            var ersterFehler = behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten');
            if (ersterFehler) { ersterFehler.focus ? ersterFehler.focus() : null; }
            return;
          }
          meldung = modus === 'aendern'
            ? (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.')
            : 'Fahrzeug angelegt.';
          global.location.hash = '#/fahrzeug/' + encodeURIComponent(r.id);
        }).catch(fehlerSeite);
      }

      function zeichne() {
        behaelter.textContent = '';
        var teile = [];
        if (modus === 'neu' && !zustand.art) {
          teile.push(h('p', { text: 'Wähle zuerst die Fahrzeugart. Dann erscheinen die passenden Felder. Nur die Bezeichnung ist Pflicht.' }));
        }
        var fk = Object.keys(zustand.fehler);
        if (fk.length) {
          teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
            text: fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.' }));
        }

        /* Fahrzeugart: beim Anlegen wählbar, danach fest */
        if (modus === 'neu') {
          teile.push(h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
            h('legend', { class: 'fest-art', text: 'Fahrzeugart' }),
            zustand.fehler.art ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.art }) : null,
            h('div', { class: 'artwahl' }, MM.Fahrzeugarten.alle().map(function (a) {
              var r = h('input', { type: 'radio', name: 'art', value: a.id, onchange: function () {
                lesen(); zustand.art = a.id; zustand.fehler = {}; zeichne();
                var b = behaelter.querySelector('#f-bezeichnung'); if (b) b.focus({ preventScroll: true });
              } });
              if (zustand.art === a.id) r.checked = true;
              return h('label', { class: 'welt-' + a.welt }, r, h('span', { text: a.name }));
            }))));
        } else {
          teile.push(h('p', null, 'Fahrzeugart: ', h('span', { class: 'fest-art', text: MM.Fahrzeugarten.art(zustand.art).name }),
            h('span', { class: 'hilfe', text: ' (lässt sich nicht ändern)' })));
        }

        if (zustand.art) {
          teile.push(feldElement({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Wie du das Fahrzeug nennst, zum Beispiel „Fahrzeug A“' },
            zustand.werte.bezeichnung, zustand.fehler.bezeichnung));
          MM.Fahrzeugarten.gruppen(zustand.art).forEach(function (g) {
            teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
              h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }),
              g.felder.map(function (f) { return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key]); })));
          });
        }
        anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
      }

      zeichne();
      seite(titel, [
        krumen(WEG_FAHRZEUGE.concat([[titel]])),
        h('h1', { text: titel }),
        behaelter
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: modus === 'aendern' ? '#/fahrzeug/' + encodeURIComponent(fahrzeugId) : '#/fahrzeuge', text: 'Abbrechen' }),
        h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
    });
  }

  /* ---------- Seite: Komponente (Schale 3 und tiefer) ---------- */
  function komponentenKrumen(c, mitSelbst) {
    var liste = WEG_FAHRZEUGE.slice(0, 3);
    liste.push([c.fahrzeugAktuell.werte.bezeichnung, '#/fahrzeug/' + encodeURIComponent(c.fahrzeug.id)]);
    c.weg.forEach(function (x) { liste.push([x.aktuell.werte.bezeichnung, '#/komponente/' + encodeURIComponent(x.komponente.id)]); });
    if (mitSelbst) liste.push([c.aktuell.werte.bezeichnung]);
    return liste;
  }
  function adresseUeber(c) {
    var eltern = c.weg.length ? c.weg[c.weg.length - 1] : null;
    return eltern ? '#/komponente/' + encodeURIComponent(eltern.komponente.id) : '#/fahrzeug/' + encodeURIComponent(c.fahrzeug.id);
  }

  function seiteKomponente(id) {
    return daten.komponenteLaden(id).then(function (c) {
      if (!c) {
        return seite('Nicht gefunden', [h('h1', { text: 'Komponente nicht gefunden' }),
          h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
      }
      var w = c.aktuell.werte;
      var art = c.komponente.parentId ? null : MM.Komponenten.art(c.komponente.art);
      var eltern = c.weg.length ? c.weg[c.weg.length - 1].aktuell.werte.bezeichnung : c.fahrzeugAktuell.werte.bezeichnung;

      var gruppen = MM.Komponenten.gruppen().map(function (g) {
        var gefuellt = [], offen = [];
        g.felder.forEach(function (fe) {
          var t = MM.Hilfen.wert(fe, w[fe.key]);
          if (t === null) { offen.push(fe.label); return; }
          if (fe.typ === 'liste') {
            w[fe.key].forEach(function (z) { gefuellt.push([h('dt', { text: z.name }), h('dd', { text: z.wert })]); });
          } else gefuellt.push([h('dt', { text: fe.label }), h('dd', { text: t })]);
        });
        return h('section', { class: 'gruppe' },
          h('h3', { text: g.titel }),
          gefuellt.length ? h('dl', { class: 'daten' }, gefuellt) : null,
          offen.length ? h('p', { class: 'offen', text: 'Noch nicht angegeben: ' + offen.join(', ') }) : null);
      });

      var teile = h('section', { class: 'teile-block' },
        h('h2', { text: 'Teile darunter' }),
        c.kinder.length ? komponentenListeBlock(c.kinder, function (x) { return x.anzahlKinder; })
          : h('p', { class: 'leer-text', text: 'Noch kein Teil darunter. Du kannst beliebig tief weiter aufschlüsseln.' }),
        h('a', { class: 'knopf', href: '#/komponente/' + encodeURIComponent(id) + '/neu', text: 'Teil hinzufügen' }));

      var spaeter = h('section', { class: 'schale s3', 'aria-label': 'Folgt' },
        h('p', { text: 'Fristen, Kosten und Nachweise zu diesem Teil folgen in späteren Schritten.' }));

      var karte = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Schale ' + c.tiefe + (art ? ': ' + art.name : ': Teil') }),
        h('h1', { text: w.bezeichnung }),
        h('p', { class: 'gehoert', text: 'gehört zu: ' + eltern }),
        w.ausgebautAm ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Ausgebaut am ' + MM.Hilfen.datum(w.ausgebautAm) + '. Dieses Teil ist nicht mehr im Fahrzeug.' }) : null,
        gruppen,
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(c.aktuell.erstelltAm) + ', per Handeingabe' }),
        teile, spaeter);

      seite(w.bezeichnung, [krumen(komponentenKrumen(c, true)), karte, verlaufBlock(c.verlauf)],
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: adresseUeber(c), text: 'Zurück' }),
          h('a', { class: 'knopf', href: '#/komponente/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
    });
  }

  /* ---------- Seite: Komponente anlegen / ändern ---------- */
  function merkmaleElement(f, zeilen, fehler, hinzu, weg) {
    return h('fieldset', { class: 'feld liste' + (fehler ? ' hat-fehler' : '') },
      h('legend', { class: 'feld-label', text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
      h('div', { class: 'merkmale' }, zeilen.map(function (z, i) {
        return h('div', { class: 'merkmal-zeile' },
          h('input', { class: 'merkmal-name', type: 'text', autocomplete: 'off', placeholder: 'Merkmal', 'aria-label': 'Merkmal ' + (i + 1), value: z.name }),
          h('input', { class: 'merkmal-wert', type: 'text', autocomplete: 'off', placeholder: 'Wert', 'aria-label': 'Wert ' + (i + 1), value: z.wert }),
          h('button', { type: 'button', class: 'knopf leise klein', text: 'Entfernen', onclick: function () { weg(i); } }));
      })),
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null,
      h('button', { type: 'button', class: 'knopf leise', text: 'Merkmal hinzufügen', onclick: hinzu }));
  }

  /* modus: 'neu-haupt' (id = Fahrzeug), 'neu-teil' (id = übergeordnete Komponente), 'aendern' (id = Komponente) */
  function seiteKomponentenFormular(modus, id) {
    var laden;
    if (modus === 'neu-haupt') laden = daten.fahrzeugLaden(id).then(function (f) { return f ? { fz: f, c: null } : null; });
    else laden = daten.komponenteLaden(id).then(function (c) { return c ? { fz: null, c: c } : null; });

    return laden.then(function (k) {
      if (!k) return seite('Nicht gefunden', [h('h1', { text: 'Nicht gefunden' }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
      var c = k.c;
      var fahrzeugId = k.fz ? k.fz.fahrzeug.id : c.fahrzeug.id;
      var titel = modus === 'neu-haupt' ? 'Hauptkomponente hinzufügen' : (modus === 'neu-teil' ? 'Teil hinzufügen' : 'Angaben ändern');

      var zurueck, weg;
      if (modus === 'neu-haupt') {
        zurueck = '#/fahrzeug/' + encodeURIComponent(fahrzeugId);
        weg = WEG_FAHRZEUGE.slice(0, 3).concat([[k.fz.aktuell.werte.bezeichnung, zurueck], [titel]]);
      } else if (modus === 'neu-teil') {
        zurueck = '#/komponente/' + encodeURIComponent(id);
        weg = komponentenKrumen(c, false).concat([[c.aktuell.werte.bezeichnung, zurueck], [titel]]);
      } else {
        zurueck = '#/komponente/' + encodeURIComponent(id);
        weg = komponentenKrumen(c, false).concat([[c.aktuell.werte.bezeichnung, zurueck], [titel]]);
      }

      var zustand = {
        art: modus === 'aendern' ? c.komponente.art : null,
        werte: modus === 'aendern' ? JSON.parse(JSON.stringify(c.aktuell.werte)) : { merkmale: [] },
        fehler: {}
      };
      if (!Array.isArray(zustand.werte.merkmale)) zustand.werte.merkmale = [];
      var istHaupt = modus === 'neu-haupt' || (modus === 'aendern' && !c.komponente.parentId);
      var behaelter = h('div');

      function lesen() {
        Array.prototype.forEach.call(behaelter.querySelectorAll('input[name], select[name]'), function (el) {
          if (el.type !== 'radio') zustand.werte[el.name] = el.value;
        });
        if (behaelter.querySelector('.merkmale')) {
          zustand.werte.merkmale = Array.prototype.map.call(behaelter.querySelectorAll('.merkmal-zeile'), function (z) {
            return { name: z.querySelector('.merkmal-name').value, wert: z.querySelector('.merkmal-wert').value };
          });
        }
      }

      function speichern(ev) {
        ev.preventDefault();
        lesen();
        var p;
        if (modus === 'neu-haupt') p = daten.komponenteAnlegen(fahrzeugId, null, zustand.art, zustand.werte);
        else if (modus === 'neu-teil') p = daten.komponenteAnlegen(fahrzeugId, id, null, zustand.werte);
        else p = daten.komponenteAendern(id, zustand.werte);
        p.then(function (r) {
          if (!r.ok) {
            zustand.fehler = r.fehler;
            zeichne();
            var erster = behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten');
            if (erster && erster.focus) erster.focus();
            return;
          }
          if (modus === 'aendern') meldung = r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.';
          else meldung = modus === 'neu-haupt' ? 'Hauptkomponente angelegt.' : 'Teil angelegt.';
          global.location.hash = zurueck;
        }).catch(fehlerSeite);
      }

      function zeichne() {
        behaelter.textContent = '';
        var teile = [];
        if (modus === 'neu-haupt' && !zustand.art) {
          teile.push(h('p', { text: 'Wähle zuerst die Art. Dann erscheinen die Felder. Nur die Bezeichnung ist Pflicht.' }));
        }
        var fk = Object.keys(zustand.fehler);
        if (fk.length) {
          teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
            text: zustand.fehler.allgemein ? zustand.fehler.allgemein : (fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.') }));
        }

        if (modus === 'neu-haupt') {
          teile.push(h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
            h('legend', { class: 'fest-art', text: 'Art der Hauptkomponente' }),
            zustand.fehler.art ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.art }) : null,
            h('div', { class: 'artwahl' }, MM.Komponenten.arten().map(function (a) {
              var r = h('input', { type: 'radio', name: 'art', value: a.id, onchange: function () {
                lesen(); zustand.art = a.id; zustand.fehler = {};
                if (!String(zustand.werte.bezeichnung || '').trim() && a.id !== 'sonstiges') zustand.werte.bezeichnung = a.name;
                zeichne();
                var b = behaelter.querySelector('#f-bezeichnung'); if (b) b.focus({ preventScroll: true });
              } });
              if (zustand.art === a.id) r.checked = true;
              return h('label', null, r, h('span', { text: a.name }));
            }))));
        } else if (modus === 'aendern' && istHaupt) {
          teile.push(h('p', null, 'Art: ', h('span', { class: 'fest-art', text: MM.Komponenten.art(zustand.art).name }),
            h('span', { class: 'hilfe', text: ' (lässt sich nicht ändern)' })));
        } else if (modus === 'neu-teil') {
          teile.push(h('p', { class: 'gehoert', text: 'gehört zu: ' + c.aktuell.werte.bezeichnung }));
        }

        if (modus !== 'neu-haupt' || zustand.art) {
          teile.push(feldElement({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text',
            hilfe: istHaupt ? 'Zum Beispiel „Motor Backbord“. Bei zwei gleichen Teilen hilft ein Zusatz.' : 'Zum Beispiel „Einspritzpumpe“' },
            zustand.werte.bezeichnung, zustand.fehler.bezeichnung));
          MM.Komponenten.gruppen().forEach(function (g) {
            teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
              h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }),
              g.felder.map(function (f) {
                if (f.typ === 'liste') {
                  return merkmaleElement(f, zustand.werte.merkmale || [], zustand.fehler[f.key],
                    function () {
                      lesen(); zustand.werte.merkmale.push({ name: '', wert: '' }); zeichne();
                      var alle = behaelter.querySelectorAll('.merkmal-name'); if (alle.length) alle[alle.length - 1].focus();
                    },
                    function (i) { lesen(); zustand.werte.merkmale.splice(i, 1); zeichne(); });
                }
                return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key]);
              })));
          });
        }
        anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
      }

      zeichne();
      seite(titel, [krumen(weg), h('h1', { text: titel }), behaelter],
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: zurueck, text: 'Abbrechen' }),
          h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
    });
  }

  /* ---------- Startseite ---------- */
  function seiteStart() {
    doc.title = 'MobiMory';
    wurzel.textContent = '';
    var saetze = MM.Texte.KERNSATZ.split('. ').map(function (t, i, a) { return i < a.length - 1 ? t + '.' : t; });
    wurzel.appendChild(h('main', { class: 'start', id: 'inhalt' },
      h('div', { class: 'start-logo' },
        h('img', { src: 'icons/icon.svg', alt: '', width: '112', height: '112' }),
        h('p', { class: 'start-name', text: 'MobiMory' }),
        h('p', { class: 'start-vtd', text: 'Vehicle, Traffic and Data' })),
      h('h1', { class: 'kernsatz' }, saetze.map(function (z, i) {
        return h('span', { class: 'satz' },
          h('span', { class: 'chip', 'aria-hidden': 'true', text: 'VTD'.charAt(i) }),
          h('span', { text: z + ' ' }));
      })),
      h('p', { class: 'infotext', text: MM.Texte.INFOTEXT }),
      h('div', { class: 'start-knoepfe' },
        h('a', { class: 'knopf gross', href: '#/auswahl', text: 'Programm starten' }),
        h('a', { class: 'knopf leise gross', href: '#/neu-im-programm', text: 'Neu im Programm' })),
      h('footer', { class: 'start-fuss' },
        h('p', { text: MM.Texte.COPYRIGHT }),
        h('p', { text: 'Version ' + MM.VERSION }))));
    global.scrollTo(0, 0);
    return Promise.resolve();
  }

  /* ---------- Kacheln ---------- */
  function kachel(titel, text, href) {
    var inhalt = [h('span', { class: 'kachel-titel', text: titel }), h('span', { class: 'kachel-text', text: text })];
    if (href) return h('a', { class: 'kachel', href: href }, inhalt);
    return h('div', { class: 'kachel bald' }, inhalt, h('span', { class: 'kachel-bald', text: 'kommt' }));
  }

  /* ---------- Hauptmenü (äußerste Schale nach der Startseite) ---------- */
  function seiteHauptmenue() {
    seite('Hauptmenü', [
      h('h1', { text: 'Hauptmenü' }),
      h('div', { class: 'kacheln' },
        kachel('Stammdaten', 'Fahrzeuge, Personen und Tiere', '#/stammdaten'),
        kachel('Funktionen', 'Aktivitäten, Reisecheck, Werkstatt und mehr'),
        kachel('Einstellungen', 'Deine Daten und Hinweise zum Programm', '#/einstellungen')),
      h('p', { class: 'zur-start' }, h('a', { href: '#/', text: 'Zur Startseite' }))
    ]);
    return Promise.resolve();
  }

  /* ---------- Stammdaten ---------- */
  function seiteStammdaten() {
    return daten.fahrzeugListe().then(function (liste) {
      var n = liste.length;
      var text = n === 0 ? 'Noch kein Fahrzeug angelegt' : (n === 1 ? '1 Fahrzeug' : n + ' Fahrzeuge');
      seite('Stammdaten', [
        krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten']]),
        h('h1', { text: 'Stammdaten' }),
        h('div', { class: 'kacheln' },
          kachel('Fahrzeuge', text, '#/fahrzeuge'),
          kachel('Personen', 'Besatzung und Nachweise'),
          kachel('Tiere', 'Tiere an Bord'))
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/auswahl', text: 'Zurück' })));
    });
  }

  /* ---------- Neu im Programm ---------- */
  function seiteNeuerungen() {
    seite('Neu im Programm', [
      h('h1', { text: 'Neu im Programm' }),
      h('div', { class: 'neuerungen' }, MM.Texte.NEUERUNGEN.map(function (v) {
        return h('section', { class: 'neuerung' },
          h('h2', { text: 'Version ' + v.version }),
          h('p', { class: 'datum', text: MM.Hilfen.datum(v.datum) }),
          h('ul', null, v.punkte.map(function (t) { return h('li', { text: t }); })));
      }))
    ], h('div', { class: 'leiste' },
      h('a', { class: 'knopf leise', href: '#/', text: 'Zur Startseite' }),
      h('a', { class: 'knopf', href: '#/auswahl', text: 'Programm starten' })));
    return Promise.resolve();
  }

  /* ---------- Einstellungen ---------- */
  function seiteEinstellungen() {
    seite('Einstellungen', [
      krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen']]),
      h('h1', { text: 'Einstellungen' }),
      h('section', { class: 'block' },
        h('h2', { text: 'Deine Daten' }),
        h('p', { text: 'Deine Daten liegen nur auf diesem Gerät. Eine automatische Sicherung gibt es in dieser Stufe noch nicht: Geht das Gerät kaputt, sind die Daten weg.' })),
      h('section', { class: 'block' },
        h('h2', { text: 'Über MobiMory' }),
        h('p', { text: 'Version ' + MM.VERSION + ' (' + MM.STUFE + ')' }),
        h('p', { text: MM.Texte.COPYRIGHT }),
        h('p', { class: 'hinweis', text: 'MobiMory ist eine Hilfestellung und trifft keine rechtliche Aussage. Die letzte Verantwortung hat der verantwortliche Skipper bzw. Fahrer.' })),
      h('details', { class: 'block test' },
        h('summary', { text: 'Nur für Tests' }),
        h('p', { text: 'Löscht alle Fahrzeuge auf diesem Gerät. Das lässt sich nicht rückgängig machen.' }),
        h('button', { class: 'knopf gefahr', type: 'button', text: 'Alle Daten auf diesem Gerät löschen',
          onclick: function () {
            if (global.confirm('Wirklich alle Daten auf diesem Gerät löschen?')) {
              daten.allesLoeschen().then(function () { meldung = 'Alle Daten auf diesem Gerät wurden gelöscht.'; return zeige(); }).catch(fehlerSeite);
            }
          } }))
    ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/auswahl', text: 'Zurück' })));
    return Promise.resolve();
  }

  function fehlerSeite(err) {
    wurzel.textContent = '';
    wurzel.appendChild(kopf());
    wurzel.appendChild(h('main', { class: 'fehlerseite' },
      h('h1', { text: 'Das hat nicht geklappt' }),
      h('p', { text: (err && err.message) ? err.message : 'Es ist ein unbekannter Fehler aufgetreten.' }),
      h('p', null, h('a', { class: 'knopf', href: '#/auswahl', text: 'Zum Hauptmenü' }))));
  }

  /* ---------- Weiterleitung nach der Adresse ---------- */
  function zeige() {
    var hash = (global.location.hash || '#/').replace(/^#/, '');
    var teile = hash.split('/').filter(Boolean);
    var p;
    if (teile.length === 0) p = seiteStart();
    else if (teile[0] === 'auswahl') p = seiteHauptmenue();
    else if (teile[0] === 'stammdaten') p = seiteStammdaten();
    else if (teile[0] === 'fahrzeuge') p = seiteListe();
    else if (teile[0] === 'neu-im-programm') p = seiteNeuerungen();
    else if (teile[0] === 'einstellungen') p = seiteEinstellungen();
    else if (teile[0] === 'neu') p = seiteFormular('neu');
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'neu') p = seiteKomponentenFormular('neu-teil', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'aendern') p = seiteKomponentenFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1]) p = seiteKomponente(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'komponente' && teile[3] === 'neu') p = seiteKomponentenFormular('neu-haupt', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'aendern') p = seiteFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1]) p = seiteFahrzeug(decodeURIComponent(teile[1]));
    else p = seiteStart();
    return p.catch(fehlerSeite);
  }

  function starten(d, el) {
    daten = d; wurzel = el;
    global.addEventListener('hashchange', zeige);
    return zeige();
  }

  MM.Ansicht = { starten: starten, fehler: function (el, err) { wurzel = el; fehlerSeite(err); } };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
