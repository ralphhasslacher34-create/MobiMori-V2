/*
 * Fahrzeugarten und ihre Felder.
 *
 * Die Felder sind hier als DATEN beschrieben, nicht in der Oberfläche
 * festverdrahtet. So kann später eine vom Nutzer zusammengestellte
 * Fahrzeugart (zum Beispiel ein Monowheel) auf demselben Weg entstehen:
 * Sie ist dann nur eine weitere Liste von Feldern.
 *
 * Schale 1 = Fahrzeugliste (Bezeichnung, Art, Kennung)
 * Schale 2 = Äußere Hülle (alle Felder unten)
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var KRAFTSTOFFE = ['Benzin', 'Diesel', 'Autogas (LPG)', 'Erdgas (CNG)',
    'Elektro', 'Hybrid', 'Wasserstoff', 'Sonstiger'];

  var GRUPPEN = [
    { id: 'fahrzeug', titel: 'Fahrzeug' },
    { id: 'masse', titel: 'Maße' },
    { id: 'gewichte', titel: 'Gewichte' },
    { id: 'antrieb', titel: 'Kraftstoff und Geschwindigkeit' },
    { id: 'strasse', titel: 'Achsen und Maut' }
  ];

  var FELDER = {
    marke: { label: 'Marke', typ: 'text', gruppe: 'fahrzeug' },
    modell: { label: 'Modell', typ: 'text', gruppe: 'fahrzeug' },
    typ: { label: 'Typ', typ: 'text', gruppe: 'fahrzeug' },
    baujahr: { label: 'Baujahr', typ: 'ganzzahl', gruppe: 'fahrzeug', min: 1800 },
    erstzulassung: { label: 'Erstzulassung', typ: 'datum', gruppe: 'fahrzeug' },
    kennzeichen: { label: 'Kennzeichen', typ: 'text', gruppe: 'fahrzeug' },
    registriernummer: { label: 'Registriernummer', typ: 'text', gruppe: 'fahrzeug' },
    fin: { label: 'FIN (Fahrgestellnummer)', typ: 'text', gruppe: 'fahrzeug' },
    hin: { label: 'HIN (Rumpfnummer)', typ: 'text', gruppe: 'fahrzeug' },

    laenge: { label: 'Länge', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    breite: { label: 'Breite', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    hoehe: { label: 'Höhe', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    tiefgang: { label: 'Tiefgang', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    durchfahrtshoehe: { label: 'Durchfahrtshöhe', typ: 'zahl', einheit: 'm', gruppe: 'masse',
      hilfe: 'Höhe über dem Wasser, wichtig für Brücken' },

    leergewicht: { label: 'Leergewicht', typ: 'zahl', einheit: 'kg', gruppe: 'gewichte' },
    gesamtgewicht: { label: 'Zulässiges Gesamtgewicht', typ: 'zahl', einheit: 'kg', gruppe: 'gewichte' },

    kraftstoff: { label: 'Kraftstoff', typ: 'auswahl', optionen: KRAFTSTOFFE, gruppe: 'antrieb' },
    hoechstgeschwindigkeit: { label: 'Höchstgeschwindigkeit', typ: 'zahl', einheit: 'km/h', gruppe: 'antrieb' },
    reisegeschwindigkeit: { label: 'Reisegeschwindigkeit', typ: 'zahl', einheit: 'km/h', gruppe: 'antrieb',
      hilfe: 'Deine übliche Geschwindigkeit unterwegs' },

    achsen: { label: 'Achsen', typ: 'ganzzahl', gruppe: 'strasse', min: 1, max: 10 },
    mautklasse: { label: 'Mautklasse', typ: 'text', gruppe: 'strasse' }
  };

  var LAND = ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin',
    'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
    'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit', 'achsen', 'mautklasse'];

  var ARTEN = [
    { id: 'auto', name: 'Auto', welt: 'land', kennung: 'kennzeichen', felder: LAND },
    { id: 'motorrad', name: 'Motorrad', welt: 'land', kennung: 'kennzeichen',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin',
        'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
        'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit'] },
    { id: 'wohnmobil', name: 'Wohnmobil', welt: 'land', kennung: 'kennzeichen', felder: LAND },
    { id: 'wohnwagen', name: 'Wohnwagen', welt: 'land', kennung: 'kennzeichen',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin',
        'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
        'hoechstgeschwindigkeit', 'achsen', 'mautklasse'] },
    { id: 'oldtimer', name: 'Oldtimer', welt: 'land', kennung: 'kennzeichen', felder: LAND },
    { id: 'boot', name: 'Boot', welt: 'wasser', kennung: 'registriernummer',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'registriernummer', 'hin',
        'laenge', 'breite', 'tiefgang', 'durchfahrtshoehe', 'leergewicht', 'gesamtgewicht',
        'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit'] },
    { id: 'flugzeug', name: 'Flugzeug', welt: 'luft', kennung: 'registriernummer',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'registriernummer',
        'laenge', { key: 'breite', label: 'Spannweite' }, 'hoehe', 'leergewicht',
        { key: 'gesamtgewicht', label: 'Höchstzulässiges Abfluggewicht' },
        'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit'] }
  ];

  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }

  function art(id) {
    for (var i = 0; i < ARTEN.length; i++) { if (ARTEN[i].id === id) return ARTEN[i]; }
    return null;
  }

  function felder(artId) {
    var a = art(artId);
    if (!a) return [];
    return a.felder.map(function (eintrag) {
      var key = typeof eintrag === 'string' ? eintrag : eintrag.key;
      var f = kopie(FELDER[key]);
      if (typeof eintrag !== 'string') { for (var p in eintrag) { f[p] = eintrag[p]; } }
      f.key = key;
      return f;
    });
  }

  function gruppen(artId) {
    var alle = felder(artId);
    return GRUPPEN.map(function (g) {
      return { id: g.id, titel: g.titel, felder: alle.filter(function (f) { return f.gruppe === g.id; }) };
    }).filter(function (g) { return g.felder.length > 0; });
  }

  MM.Fahrzeugarten = {
    alle: function () { return ARTEN.slice(); },
    art: art,
    felder: felder,
    gruppen: gruppen,
    kennungFeld: function (artId) { var a = art(artId); return a ? a.kennung : null; }
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
