/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.4';
  MM.STUFE = 'Schritt 2: Hauptkomponenten (Schale 3 und tiefer)';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
