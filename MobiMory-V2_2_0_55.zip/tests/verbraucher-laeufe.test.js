'use strict';
/* 2.0.52: Ein und Aus für jeden Verbraucher. Gezeigt an einer Heizung (kein Motor): Start, Stopp, Dauer, Betriebsstunden-Zähler,
 * Korrektur, doppeltes Einschalten abgewiesen, Bausteine im Baukasten, Zusammenarbeit mit Tanken. Der Motor bleibt, wie er war. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/aktionen.js');
require('../js/baukasten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/karte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const B = MM.Baukasten;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 9, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.uhr = uhr;
  d.stelle = (std, min) => { uhr.ms = new Date(2026, 10, 9, std, min, 0).getTime(); t = 0; };
  return d;
}

/* Boot mit Motor, Dieseltank, Standheizung (Diesel, am selben Tank, Verbrauch aus Betriebsstunden) und den zwei Ereignisarten „Heizung an“ und „Heizung aus“. */
async function boot() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: fz, vonDatum: '2026-11-08', vonZeit: '09:00', bisDatum: '2026-11-20', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok, JSON.stringify(r));
  const tank = await d.komponenteAnlegen(fz, null, 'tank', { bezeichnung: 'Dieseltank', stoff: 'Diesel', merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] });
  assert.ok(tank.ok, JSON.stringify(tank));
  const heizung = await d.komponenteAnlegen(fz, null, 'heizung', { bezeichnung: 'Standheizung', verbraucher: 'ja', stoff: 'Diesel', quellen: [tank.id], verbrauchAus: 'stunden' });
  assert.ok(heizung.ok, JSON.stringify(heizung));
  const motor = await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Motor' });
  assert.ok(motor.ok, JSON.stringify(motor));
  const getriebe = await d.komponenteAnlegen(fz, null, 'getriebe', { bezeichnung: 'Getriebe' });
  const an = await d.ereignisartAnlegen({ bezeichnung: 'Heizung an', fragen: B.vorlage('heizungAn').fragen, wirkungen: B.vorlage('heizungAn').wirkungen });
  const aus = await d.ereignisartAnlegen({ bezeichnung: 'Heizung aus', fragen: B.vorlage('heizungAus').fragen, wirkungen: B.vorlage('heizungAus').wirkungen });
  assert.ok(an.ok && aus.ok, JSON.stringify([an, aus]));
  return { d, id: r.id, fz, tank: tank.id, heizung: heizung.id, motor: motor.id, getriebe: getriebe.id, an: an.id, aus: aus.id };
}
const lauf = async (c, id) => (await c.d.verbraucherListe(c.fz)).find(x => x.komponenteId === id || (id === undefined && x.komponenteId === c.heizung));
const zaehlerStand = async (c, komponenteId) => {
  const z = (await c.d.zaehlerListe(c.fz)).find(x => x.komponenteId === komponenteId && x.art === 'stunden');
  return z && z.stand ? z.stand.wert : null;
};
async function knopf(c, art, zeit) {
  const e = await c.d.ereignisSchnell(c.id, art === 'an' ? 'Heizung an' : 'Heizung aus', zeit ? { artId: c[art], zeit } : { artId: c[art] });
  assert.ok(e.ok, JSON.stringify(e));
  return e.id;
}

/* ---------- Bausteine im Baukasten ---------- */

test('Baukasten: Frage „Verbraucher“ und Wirkungen „einschalten“ und „ausschalten“ stehen nur als Einträge in den Listen', () => {
  assert.equal(B.frage('verbraucher').typ, 'auswahl');
  assert.deepEqual(B.wirkung('verbraucherEin').braucht, ['verbraucher']);
  assert.deepEqual(B.wirkung('verbraucherAus').braucht, ['verbraucher']);
  assert.ok(lesen('js/baukasten.js').includes("{ id: 'verbraucherEin', name: 'Verbraucher einschalten'"));
  assert.ok(lesen('js/baukasten.js').includes("{ id: 'verbraucherAus', name: 'Verbraucher ausschalten'"));
  assert.deepEqual(B.vorlage('heizungAn'), { id: 'heizungAn', name: 'Verbraucher einschalten (zum Beispiel Heizung an)', fragen: ['verbraucher'], wirkungen: ['verbraucherEin'] });
  assert.deepEqual(B.fehlendeFragen({ fragen: ['verbraucher'], wirkungen: ['verbraucherEin'] }), []);
  assert.deepEqual(B.fehlendeFragen({ fragen: ['verbraucher'], wirkungen: ['verbraucherAus'] }), []);
});

test('Baukasten: ohne die Frage „Verbraucher“ gibt es eine Meldung, und Ein und Aus zugleich passen nicht zusammen', () => {
  assert.ok(B.fehlendeFragen({ fragen: [], wirkungen: ['verbraucherEin'] }).some(m => /Verbraucher einschalten.*Verbraucher/.test(m)));
  const beide = B.fehlendeFragen({ fragen: ['verbraucher'], wirkungen: ['verbraucherEin', 'verbraucherAus'] });
  assert.equal(beide.length, 1, 'die Meldung kommt nur einmal');
  assert.match(beide[0], /passen nicht zusammen/);
  assert.match(B.ablaufText({ fragen: ['verbraucher'], wirkungen: ['verbraucherEin'] }), /Fragen: Verbraucher → Wirkungen: Verbraucher einschalten/);
});

test('Die Ereignisart mit beiden Wirkungen wird nicht gespeichert, mit einer schon', async () => {
  const c = await boot();
  const schlecht = await c.d.ereignisartAnlegen({ bezeichnung: 'Heizung hin und her', fragen: ['verbraucher'], wirkungen: ['verbraucherEin', 'verbraucherAus'] });
  assert.equal(schlecht.ok, false);
  assert.match(schlecht.fehler.wirkungen, /passen nicht zusammen/);
  const ohne = await c.d.ereignisartAnlegen({ bezeichnung: 'Heizung ohne Frage', fragen: [], wirkungen: ['verbraucherEin'] });
  assert.equal(ohne.ok, false);
  assert.match(ohne.fehler.wirkungen, /braucht die Frage/);
});

/* ---------- Datenschicht: Ein und Aus für einen Verbraucher, der kein Motor ist ---------- */

test('Eine Heizung ein- und ausschalten: Start, Stopp, Dauer, Betriebsstunden-Zähler der Heizung', async () => {
  const c = await boot();
  c.d.stelle(8, 0);
  const s = await c.d.verbraucherStart(c.heizung);
  assert.ok(s.ok, JSON.stringify(s));
  assert.equal(s.name, 'Standheizung');
  let x = await lauf(c);
  assert.equal(x.laeuft, true);
  assert.equal(x.istMotor, false);
  assert.ok(x.zaehler, 'der Zähler entsteht beim ersten Start und gehört der Heizung');
  c.d.stelle(9, 30);
  const e = await c.d.verbraucherStopp(c.heizung);
  assert.ok(e.ok, JSON.stringify(e));
  assert.equal(e.stunden, 1.5);
  assert.equal(e.stand, 1.5);
  assert.equal(e.ohneStartstand, true);
  x = await lauf(c);
  assert.equal(x.laeuft, false);
  assert.equal(x.laeufe.length, 1);
  assert.equal(x.laeufe[0].stunden, 1.5);
  assert.equal(x.laeufe[0].standNachher, 1.5);
  assert.equal(await zaehlerStand(c, c.heizung), 1.5);
  c.d.stelle(10, 0); await c.d.verbraucherStart(c.heizung);
  c.d.stelle(10, 30); const zweiter = await c.d.verbraucherStopp(c.heizung);
  assert.equal(zweiter.stand, 2, 'der Zähler summiert die Läufe');
  const staende = await c.d.speicher.alle('zaehlerstaende');
  assert.deepEqual(staende.filter(z => z.quelle === 'schalter').map(z => z.wert).sort(), [1.5, 2]);
  assert.match(staende.find(z => z.wert === 1.5).notiz, /^Lauf /, 'bei einem Verbraucher steht „Lauf“, nicht „Motorlauf“');
});

test('Doppeltes Einschalten wird abgewiesen, Ausschalten ohne Lauf auch', async () => {
  const c = await boot();
  const aus = await c.d.verbraucherStopp(c.heizung);
  assert.equal(aus.ok, false);
  assert.equal(aus.fehler.allgemein, 'Dieser Verbraucher läuft nicht.');
  assert.ok((await c.d.verbraucherStart(c.heizung)).ok);
  const nochmal = await c.d.verbraucherStart(c.heizung);
  assert.equal(nochmal.ok, false);
  assert.equal(nochmal.fehler.allgemein, 'Dieser Verbraucher läuft schon.');
  assert.equal((await c.d.speicher.holen('einstellungen', 'motorlaeufe')).laeufe.length, 1);
});

test('Nur Verbraucher und Motoren lassen sich einschalten; die Motorfunktionen bleiben beim Motor', async () => {
  const c = await boot();
  const g = await c.d.verbraucherStart(c.getriebe);
  assert.equal(g.ok, false);
  assert.equal(g.fehler.allgemein, 'Dieser Verbraucher wurde nicht gefunden.');
  const tankStart = await c.d.verbraucherStart(c.tank);
  assert.equal(tankStart.ok, false);
  const h = await c.d.motorStart(c.heizung);
  assert.equal(h.ok, false, 'der Motorschalter schaltet keine Heizung');
  assert.equal(h.fehler.allgemein, 'Dieser Motor wurde nicht gefunden.');
  const m = await c.d.verbraucherStart(c.motor);
  assert.ok(m.ok, 'ein Motor ist ein Verbraucher mit dieser Fähigkeit');
  assert.equal((await c.d.motorStart(c.motor)).fehler.allgemein, 'Dieser Motor läuft schon.');
  assert.ok((await c.d.motorStopp(c.motor)).ok);
});

test('Motorliste und Verbraucherliste: der Motor bleibt allein im Cockpit, die Heizung steht bei den weiteren Verbrauchern', async () => {
  const c = await boot();
  assert.deepEqual((await c.d.motorenListe(c.fz)).map(x => x.name), ['Motor']);
  assert.deepEqual(await c.d.verbraucherListe(c.fz), [], 'ohne Lauf steht die Heizung noch nicht bei den weiteren Verbrauchern');
  const auswahl = await c.d.verbraucherAuswahl(c.fz);
  assert.deepEqual(auswahl.map(x => x.name).sort(), ['Motor', 'Standheizung'], 'für die Frage im Baukasten: Verbraucher und Motoren, kein Tank, kein Getriebe');
  await c.d.verbraucherStart(c.heizung);
  assert.equal((await c.d.verbraucherListe(c.fz)).length, 1);
  assert.deepEqual((await c.d.motorenListe(c.fz)).map(x => x.name), ['Motor']);
  assert.equal((await c.d.verbraucherAuswahl(c.fz)).find(x => x.id === c.heizung).laeuft, true);
});

test('Die Zeiten sind korrigierbar, die Rechnung folgt dem korrigierten Wert, der alte Stand bleibt im Verlauf', async () => {
  const c = await boot();
  c.d.stelle(8, 0); await c.d.verbraucherStart(c.heizung);
  c.d.stelle(11, 0); await c.d.verbraucherStopp(c.heizung);
  assert.equal(await zaehlerStand(c, c.heizung), 3);
  const id = (await lauf(c)).laeufe[0].id;
  assert.equal((await lauf(c)).laeufe[0].korrigierbar, true);
  const zuFrueh = await c.d.verbraucherLaufKorrigieren(id, { datum: '2026-11-09', zeit: '07:00' });
  assert.equal(zuFrueh.ok, false);
  assert.match(zuFrueh.fehler.zeit, /nicht vor dem Start/);
  const zukunft = await c.d.verbraucherLaufKorrigieren(id, { datum: '2026-11-09', zeit: '23:00' });
  assert.match(zukunft.fehler.zeit, /Zukunft/);
  const k = await c.d.verbraucherLaufKorrigieren(id, { datum: '2026-11-09', zeit: '09:30' });
  assert.ok(k.ok && k.geaendert, JSON.stringify(k));
  assert.equal(k.stand, 1.5);
  assert.equal(await zaehlerStand(c, c.heizung), 1.5);
  const x = await lauf(c);
  assert.equal(x.laeufe[0].korrigiert, true);
  assert.equal(x.laeufe[0].stunden, 1.5);
  const staende = await c.d.speicher.alle('zaehlerstaende');
  assert.deepEqual(staende.map(z => z.wert).sort(), [1.5, 3], 'der alte Stand 3 bleibt im Verlauf');
  assert.match(staende.find(z => z.quelle === 'korrektur').notiz, /^Korrektur: Verbraucher gestoppt /);
  const gleich = await c.d.verbraucherLaufKorrigieren(id, { datum: '2026-11-09', zeit: '09:30' });
  assert.equal(gleich.geaendert, false);
  /* Die alten Namen leiten weiter */
  const ueber = await c.d.motorLaufKorrigieren(id, { datum: '2026-11-09', zeit: '09:45' });
  assert.ok(ueber.ok && ueber.stand === 1.75, JSON.stringify(ueber));
});

test('Nach einem von Hand geänderten Zählerstand lässt sich der Lauf nicht mehr korrigieren', async () => {
  const c = await boot();
  c.d.stelle(8, 0); await c.d.verbraucherStart(c.heizung);
  c.d.stelle(9, 0); await c.d.verbraucherStopp(c.heizung);
  const z = (await c.d.zaehlerListe(c.fz)).find(x => x.komponenteId === c.heizung && x.art === 'stunden');
  assert.ok((await c.d.zaehlerStandEintragen(z.zaehler.id, { wert: '50', datum: '2026-11-09' })).ok);
  const r = await c.d.verbraucherLaufKorrigieren((await lauf(c)).laeufe[0].id, { datum: '2026-11-09', zeit: '08:30' });
  assert.equal(r.ok, false);
  assert.match(r.fehler.allgemein, /Zählerstand geändert/);
});

test('Die Läufe der Heizung sind in der Sicherung und kommen beim Einspielen wieder', async () => {
  const c = await boot();
  c.d.stelle(8, 0); await c.d.verbraucherStart(c.heizung);
  c.d.stelle(9, 0); await c.d.verbraucherStopp(c.heizung);
  c.d.stelle(9, 30); await c.d.verbraucherStart(c.heizung);
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  const b = neueDaten();
  await b.starten();
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  const x = (await b.verbraucherListe(c.fz)).find(y => y.komponenteId === c.heizung);
  assert.equal(x.laeuft, true);
  assert.equal(x.laeufe.length, 1);
  assert.equal(x.laeufe[0].stunden, 1);
  assert.equal(x.zaehler.stand.wert, 1);
});

test('Benutzt: Läufe einer Heizung heißen „Lauf“, die eines Motors „Motorlauf“', async () => {
  const c = await boot();
  await c.d.verbraucherStart(c.heizung);
  await c.d.verbraucherStopp(c.heizung);
  await c.d.verbraucherStart(c.motor);
  await c.d.verbraucherStopp(c.motor);
  const h = await c.d.komponenteVerwendung(c.heizung);
  assert.ok(h.gruende.some(g => /1 Lauf$/.test(g)), JSON.stringify(h.gruende));
  const m = await c.d.komponenteVerwendung(c.motor);
  assert.ok(m.gruende.some(g => /1 Motorlauf$/.test(g)), JSON.stringify(m.gruende));
});

/* ---------- „Heizung an“ und „Heizung aus“ als Knöpfe aus dem Baukasten, ohne eigenen Code für die Heizung ---------- */

test('Heizung an und Heizung aus: zwei Ereignisse, die Zeiten der Ereignisse sind Start und Stopp', async () => {
  const c = await boot();
  const ein = await knopf(c, 'an', '10:00');
  const r1 = await c.d.ereignisAblaufAusfuehren(ein, { verbraucherId: c.heizung });
  assert.ok(r1.ok, JSON.stringify(r1));
  assert.equal(r1.lauf.art, 'ein');
  assert.equal(r1.lauf.name, 'Standheizung');
  assert.equal(r1.lauf.vomEreignis, true, 'die Zeit des Ereignisses gilt als Start');
  assert.equal(MM.Motoren.ortszeit(r1.lauf.start), '10:00');
  assert.equal((await lauf(c)).laeuft, true);
  const e1 = (await c.d.ereignisLaden(ein)).aktuell.werte;
  assert.equal(e1.verbraucherId, c.heizung);
  assert.equal(e1.verbraucherName, 'Standheizung');
  assert.equal(e1.laufArt, 'ein');
  assert.equal(e1.laufGebucht, true);
  const aus = await knopf(c, 'aus', '11:30');
  const r2 = await c.d.ereignisAblaufAusfuehren(aus, { verbraucherId: c.heizung });
  assert.ok(r2.ok, JSON.stringify(r2));
  assert.equal(r2.lauf.art, 'aus');
  assert.equal(r2.lauf.stunden, 1.5);
  assert.equal(r2.lauf.stand, 1.5);
  assert.equal(MM.Motoren.ortszeit(r2.lauf.stopp), '11:30');
  const x = await lauf(c);
  assert.equal(x.laeuft, false);
  assert.equal(x.laeufe[0].stunden, 1.5);
  assert.equal(await zaehlerStand(c, c.heizung), 1.5);
  const stand = (await c.d.speicher.alle('zaehlerstaende')).find(z => z.wert === 1.5);
  assert.match(stand.notiz, /Stoppzeit vom Ereignis übernommen/);
});

test('Heizung an zweimal: der zweite Knopf wird abgewiesen und nichts wird doppelt gebucht', async () => {
  const c = await boot();
  const a1 = await knopf(c, 'an');
  assert.ok((await c.d.ereignisAblaufAusfuehren(a1, { verbraucherId: c.heizung })).ok);
  const a2 = await knopf(c, 'an');
  const r = await c.d.ereignisAblaufAusfuehren(a2, { verbraucherId: c.heizung });
  assert.equal(r.ok, false);
  assert.match(r.fehler.verbraucher, /Standheizung.*läuft schon/);
  assert.equal((await c.d.ereignisLaden(a2)).aktuell.werte.laufGebucht, undefined, 'am zweiten Eintrag steht kein Lauf');
  assert.equal((await c.d.speicher.holen('einstellungen', 'motorlaeufe')).laeufe.length, 1);
});

test('Heizung aus ohne Lauf: Meldung am Feld, nichts wird gebucht', async () => {
  const c = await boot();
  const r = await c.d.ereignisAblaufAusfuehren(await knopf(c, 'aus'), { verbraucherId: c.heizung });
  assert.equal(r.ok, false);
  assert.match(r.fehler.verbraucher, /Standheizung.*läuft nicht/);
  assert.equal(await zaehlerStand(c, c.heizung), null);
});

test('Ohne Auswahl, mit fremdem Verbraucher oder mit einem Getriebe: Meldung, nichts wird gebucht', async () => {
  const c = await boot();
  const id = await knopf(c, 'an');
  const keine = await c.d.ereignisAblaufAusfuehren(id, {});
  assert.equal(keine.ok, false);
  assert.ok(keine.fehler.verbraucher);
  const getriebe = await c.d.ereignisAblaufAusfuehren(id, { verbraucherId: c.getriebe });
  assert.equal(getriebe.ok, false);
  assert.match(getriebe.fehler.verbraucher, /Verbraucher dieses Fahrzeugs/);
  const anderes = (await c.d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Mobil' })).id;
  const fremd = (await c.d.komponenteAnlegen(anderes, null, 'heizung', { bezeichnung: 'Fremdheizung', verbraucher: 'ja' })).id;
  const r = await c.d.ereignisAblaufAusfuehren(id, { verbraucherId: fremd });
  assert.equal(r.ok, false);
  assert.match(r.fehler.verbraucher, /dieses Fahrzeugs/);
  assert.equal((await c.d.speicher.holen('einstellungen', 'motorlaeufe')), null, 'kein Lauf entstanden');
});

test('Zweimal abschicken bucht den Lauf nicht noch einmal', async () => {
  const c = await boot();
  const ein = await knopf(c, 'an');
  const r1 = await c.d.ereignisAblaufAusfuehren(ein, { verbraucherId: c.heizung });
  assert.ok(r1.ok);
  assert.equal(r1.laufSchonGebucht, false);
  const r2 = await c.d.ereignisAblaufAusfuehren(ein, { verbraucherId: c.heizung });
  assert.ok(r2.ok, JSON.stringify(r2));
  assert.equal(r2.laufSchonGebucht, true);
  assert.equal(r2.lauf, null);
  assert.equal((await c.d.speicher.holen('einstellungen', 'motorlaeufe')).laeufe.length, 1);
});

test('Eine Zeit des Ereignisses in der Zukunft oder vor dem Start gilt nicht: dann zählt jetzt', async () => {
  const c = await boot();
  c.d.stelle(10, 0);
  const ein = await knopf(c, 'an', '10:00');
  assert.ok((await c.d.ereignisAblaufAusfuehren(ein, { verbraucherId: c.heizung })).ok);
  /* Aus mit einer Zeit vor dem Start (09:00 < 10:00:00.xxx): es gilt jetzt */
  const aus = await knopf(c, 'aus', '09:00');
  const r = await c.d.ereignisAblaufAusfuehren(aus, { verbraucherId: c.heizung });
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal(r.lauf.vomEreignis, false);
  assert.ok(r.lauf.stunden < 0.01, 'kaum Laufzeit, weil jetzt nur Millisekunden nach dem Start liegt');
});

test('Ein Ereignis mit Verbraucher und Betrag: beides läuft, der Kostenposten entsteht auch', async () => {
  const c = await boot();
  const art = await c.d.ereignisartAnlegen({ bezeichnung: 'Heizung an mit Gas gekauft', fragen: ['verbraucher', 'betrag'], wirkungen: ['verbraucherEin', 'kosten'] });
  assert.ok(art.ok, JSON.stringify(art));
  const e = await c.d.ereignisSchnell(c.id, 'x', { artId: art.id });
  const r = await c.d.ereignisAblaufAusfuehren(e.id, { verbraucherId: c.heizung, betrag: '12,50' });
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal(r.kostenNeu, true);
  assert.equal(r.lauf.art, 'ein');
});

/* ---------- Zusammenarbeit mit Tanken: Liter je Betriebsstunde für die Heizung ---------- */

test('Tanken findet den Betriebsstunden-Zähler der Heizung und liefert Liter je Betriebsstunde', async () => {
  const c = await boot();
  const tanken = await c.d.ereignisartAnlegen({ bezeichnung: 'Tanken', fragen: B.vorlage('tanken').fragen, wirkungen: B.vorlage('tanken').wirkungen });
  assert.ok(tanken.ok, JSON.stringify(tanken));
  c.d.stelle(7, 0);
  const z = (await c.d.verbraucherZaehler(c.fz, c.heizung)).id;
  assert.ok((await c.d.zaehlerStandEintragen(z, { wert: '100', datum: '2026-11-09' })).ok);
  const stand = await c.d.komponenteAendern(c.tank, { bezeichnung: 'Dieseltank', stoff: 'Diesel', fuellstand: '60', merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] });
  assert.ok(stand.ok, JSON.stringify(stand));
  /* Heizung läuft 2 Stunden, über die Knöpfe */
  c.d.stelle(8, 0);
  assert.ok((await c.d.ereignisAblaufAusfuehren(await knopf(c, 'an', '08:00'), { verbraucherId: c.heizung })).ok);
  c.d.stelle(10, 0);
  const aus = await c.d.ereignisAblaufAusfuehren(await knopf(c, 'aus', '10:00'), { verbraucherId: c.heizung });
  assert.ok(aus.ok, JSON.stringify(aus));
  assert.equal(aus.lauf.stand, 102, 'der Lauf zählt auf den vorhandenen Stand');
  const te = await c.d.ereignisSchnell(c.id, 'Tanken', { artId: tanken.id });
  const r = await c.d.ereignisAblaufAusfuehren(te.id, { tankId: c.tank, menge: '30', literpreis: '1,80', voll: 'ja' });
  assert.ok(r.ok, JSON.stringify(r));
  const w = (await c.d.komponenteLaden(c.tank)).aktuell.werte;
  assert.equal(w.verbrauch.liter, 10, 'vorher 60 l, getankt 30 l, jetzt voll mit 80 l');
  const heizung = w.verbrauch.einzeln.find(x => x.id === c.heizung);
  assert.equal(heizung.lProStunde, 5, '10 l in 2 Betriebsstunden');
});

/* ---------- Nichts ändert sich für den Motor ---------- */

test('Der Motor wird weiter mit seinen Namen und Texten geschaltet', async () => {
  const c = await boot();
  c.d.stelle(8, 0); const s = await c.d.motorStart(c.motor);
  assert.ok(s.ok);
  assert.equal(s.name, 'Motor');
  c.d.stelle(9, 15);
  const e = await c.d.motorStopp(c.motor);
  assert.equal(e.stunden, 1.25);
  assert.equal((await c.d.speicher.alle('zaehlerstaende'))[0].notiz.indexOf('Motorlauf '), 0);
  assert.equal((await c.d.motorStopp(c.motor)).fehler.allgemein, 'Dieser Motor läuft nicht.');
  assert.equal((await c.d.motorenListe(c.fz))[0].laeufe[0].stunden, 1.25);
});

test('Version 2.0.55 überall gleich', () => {
  assert.equal(MM.VERSION, '2.0.55');
  assert.equal(MM.STUFE, 'Motor- und Verbraucher-Schalter in einer Reihe');
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.55';"));
  assert.equal(JSON.parse(lesen('package.json')).version, '2.0.55');
  assert.ok(lesen('README.md').includes('Version 2.0.55'));
  assert.ok(lesen('CHANGELOG.md').startsWith('# Änderungen\n\n## 2.0.55'));
  assert.ok(lesen('js/texte.js').includes("version: '2.0.55'"));
  assert.ok(lesen('docs/SCHRITTE.md').includes('| 12e |'));
});
