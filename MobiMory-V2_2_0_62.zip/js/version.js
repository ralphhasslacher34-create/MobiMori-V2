/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.62';
  MM.STUFE = 'Cockpit in Seiten, ETA, Rest und Gefahren, Einheit km und sm';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
