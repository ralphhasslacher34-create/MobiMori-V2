'use strict';
/* 2.0.57: Verbrauch in allen Einheiten (l/Betriebsstunde, l/km, l/sm, l/Tag), einstellbar, Durchschnitt je Aktivität. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/aktionen.js');
require('../js/baukasten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/karte.js');
require('../js/daten.js');
const MM = globalThis.MM;

const T = MM.Tanken, V = MM.Verbrauch, B = MM.Baukasten;
const TAG = 86400000;

/* ---------- Reine Rechnung ---------- */

test('Einheiten: Voreinstellung automatisch, unbekannte Werte fallen darauf zurück, die Einstellung wird gesetzt', () => {
  assert.equal(V.einheitAus(null), 'auto');
  assert.equal(V.einheitAus({ werte: { einheit: 'quatsch' } }), 'auto');
  assert.deepEqual(V.EINHEITEN.map(e => e.wert), ['auto', 'stunde', 'km', 'sm', 'tag']);
  const d = V.dokumentSetzen(null, 'sm');
  assert.equal(d.id, 'verbrauch-einheit');
  assert.equal(V.einheitAus(d), 'sm');
  assert.equal(V.einheitAus(V.dokumentSetzen(d, 'quatsch')), 'auto');
});

test('Strecke: nur ein echter Zuwachs zweier Stände zählt, sonst null (nichts wird geraten)', () => {
  assert.equal(V.strecke(1000, 1100), 100);
  assert.equal(V.strecke(null, 1100), null);
  assert.equal(V.strecke(1000, undefined), null);
  assert.equal(V.strecke(1000, 1000), null);
  assert.equal(V.strecke(1100, 1000), null);
  assert.equal(V.strecke('1000', 1100), null);
});

const motorOhneKm = { id: 'm', name: 'Motor', aus: 'stunden', stunden: 105, motor: true };
function tankung(extra) {
  return T.berechnen(Object.assign({
    kapazitaet: 80, alt: { fuellstand: 60, art: 'angegeben', zeit: '2026-11-08T12:00', stunden: { m: 100 }, strecke: 1000 },
    menge: 30, voll: true, zeit: '2026-11-10T12:00', verbraucher: [motorOhneKm], strecke: 1100
  }, extra || {}));
}

test('Verbrauch je Kilometer und je Seemeile kommt aus dem Kilometerzähler, zusammen mit Betriebsstunden und Tag', () => {
  const e = tankung();
  assert.equal(e.verbrauch.liter, 10);
  assert.equal(e.verbrauch.lProTag, 5);
  assert.equal(e.verbrauch.einzeln[0].lProStunde, 2);
  assert.equal(e.verbrauch.km, 100);
  assert.equal(e.verbrauch.lProKm, 0.1);
  assert.equal(e.verbrauch.lProSm, 0.185);
  assert.equal(e.strecke, 1100);
  const z = T.verbrauchZeilen(e.verbrauch);
  assert.ok(z[0].includes('5 l je Tag'));
  assert.ok(z.some(x => /l je Betriebsstunde/.test(x)));
  assert.ok(z.some(x => /0,1 l je km \(100 km\)/.test(x)));
  assert.ok(z.some(x => /0,19 l je sm \(54 sm\)/.test(x)), z.join(' | '));
});

test('Die gewählte Einheit steht vorn, gerechnet wird trotzdem alles', () => {
  const v = tankung().verbrauch;
  const ohne = T.verbrauchZeilen(v);
  const kmVorn = T.verbrauchZeilen(v, 'km');
  assert.equal(kmVorn.length, ohne.length);
  assert.match(kmVorn[1], /je km/);
  assert.match(T.verbrauchZeilen(v, 'sm')[1], /je sm/);
  assert.match(T.verbrauchZeilen(v, 'stunde')[1], /Betriebsstunde/);
  assert.match(T.verbrauchKurz(v, 'km'), /^Verbrauch: 0,1 l je km$/);
  assert.match(T.verbrauchKurz(v, 'sm'), /l je sm/);
  assert.match(T.verbrauchKurz(v, 'tag'), /5 l je Tag/);
  assert.match(T.verbrauchKurz(v, 'auto'), /2 l je Betriebsstunde/);
  assert.equal(T.verbrauchKurz(null, 'km'), null);
});

test('Ist die gewählte Einheit nicht zu rechnen, steht die nächste vorn (kein Kilometerzähler: Tag statt km)', () => {
  const v = tankung({ strecke: null }).verbrauch;
  assert.equal(v.km, undefined);
  assert.match(T.verbrauchKurz(v, 'km'), /2 l je Betriebsstunde/);
  const ohneStunden = tankung({ strecke: null, verbraucher: [Object.assign({}, motorOhneKm, { aus: 'fuellstand', stunden: null })] }).verbrauch;
  assert.match(T.verbrauchKurz(ohneStunden, 'km'), /5 l je Tag/);
});

test('Entfernung zählt nur mit Motor am Tank: eine Heizung am eigenen Tank bekommt keinen Verbrauch je km', () => {
  const heizung = { id: 'h', name: 'Heizung', aus: 'fuellstand', stunden: null };
  const e = tankung({ verbraucher: [heizung] });
  assert.equal(e.verbrauch.liter, 10);
  assert.equal(e.verbrauch.km, undefined);
  assert.equal(e.verbrauch.lProKm, undefined);
  assert.ok(!e.hinweise.some(h => /Kilometer/.test(h)));
});

test('Fehlender oder nicht gewachsener Kilometerstand: Hinweis statt falscher Zahl; ganz ohne Zähler kein Hinweis', () => {
  const nichtGewachsen = tankung({ strecke: 1000 });
  assert.equal(nichtGewachsen.verbrauch.lProKm, undefined);
  assert.ok(nichtGewachsen.hinweise.some(h => /Kilometerzähler/.test(h)));
  const jetztFehlt = tankung({ strecke: null });
  assert.ok(jetztFehlt.hinweise.some(h => /Kilometerzähler/.test(h)));
  const nie = tankung({ strecke: null, alt: { fuellstand: 60, art: 'angegeben', zeit: '2026-11-08T12:00', stunden: { m: 100 } } });
  assert.equal(nie.verbrauch.liter, 10);
  assert.ok(!nie.hinweise.some(h => /Kilometer/.test(h)));
});

test('Reichweite kommt auch in km und sm, wenn der Verbrauch je km bekannt ist', () => {
  const e = tankung();
  assert.deepEqual(e.reichweite.map(x => x.einheit), ['Betriebsstunden', 'km', 'sm', 'Tage']);
  assert.equal(e.reichweite[1].wert, 800);
  assert.equal(e.reichweite[2].wert, Math.round(80 / 0.185));
  assert.match(T.reichweiteZeilen(e.reichweite).join(' '), /Reichweite Entfernung: etwa 800 km/);
});

test('Durchschnitt: Summe der Verbräuche geteilt durch Zeit, Stunden und Strecke; fehlt bei einer Tankung etwas, wird es nicht gerechnet', () => {
  const eins = { liter: 10, tage: 2, km: 100, summe: false, einzeln: [{ id: 'm', name: 'Motor', stunden: 5 }] };
  const zwei = { liter: 20, tage: 3, km: 300, summe: false, einzeln: [{ id: 'm', name: 'Motor', stunden: 10 }] };
  const d = V.durchschnitt([eins, zwei]);
  assert.equal(d.liter, 30);
  assert.equal(d.tage, 5);
  assert.equal(d.lProTag, 6);
  assert.equal(d.km, 400);
  assert.equal(d.lProKm, 0.075);
  assert.equal(d.lProSm, 0.139);
  assert.deepEqual(d.einzeln, [{ id: 'm', name: 'Motor', stunden: 15, lProStunde: 2 }]);
  const teil = V.durchschnitt([eins, Object.assign({}, zwei, { km: undefined, einzeln: [] })]);
  assert.equal(teil.lProKm, null);
  assert.deepEqual(teil.einzeln, []);
  assert.equal(V.durchschnitt([]), null);
  assert.equal(V.durchschnitt(null), null);
  const summe = V.durchschnitt([Object.assign({}, eins, { summe: true })]);
  assert.deepEqual(summe.einzeln, [], 'bei mehreren Verbrauchern gibt der Füllstand nur eine Summe');
  const z = V.durchschnittZeilen(d, 'km');
  assert.match(z[0], /30 l in 5 Tagen \(6 l je Tag, Durchschnitt aus 2 Tankungen\)/);
  assert.match(z[1], /je km/);
  assert.equal(V.durchschnittZeilen(null, 'km').length, 0);
});

/* ---------- Datenschicht ---------- */

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 8, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.uhr = uhr;
  return d;
}

async function boot(mitKm) {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: fz, vonDatum: '2026-11-08', vonZeit: '09:00', bisDatum: '2026-11-20', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok, JSON.stringify(r));
  const tank = await d.komponenteAnlegen(fz, null, 'tank', { bezeichnung: 'Dieseltank', stoff: 'Diesel', merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] });
  const motor = await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Motor', verbraucher: 'ja', stoff: 'Diesel', quellen: [tank.id], verbrauchAus: 'stunden' });
  assert.ok(motor.ok, JSON.stringify(motor));
  const art = await d.ereignisartAnlegen({ bezeichnung: 'Tanken', fragen: B.vorlage('tanken').fragen, wirkungen: B.vorlage('tanken').wirkungen });
  const c = { d, id: r.id, fz, tank: tank.id, motor: motor.id, art: art.id };
  c.stunden = (await d.motorZaehler(fz, motor.id)).id;
  assert.ok((await d.zaehlerStandEintragen(c.stunden, { wert: '100', datum: '2026-11-08' })).ok);
  if (mitKm) {
    c.km = (await d.zaehlerAnlegen(fz, null, 'strecke', { bezeichnung: 'Kilometerstand' })).id;
    assert.ok((await d.zaehlerStandEintragen(c.km, { wert: '1000', datum: '2026-11-08' })).ok);
  }
  const s = await d.komponenteAendern(tank.id, { bezeichnung: 'Dieseltank', stoff: 'Diesel', fuellstand: '60', merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] });
  assert.ok(s.ok, JSON.stringify(s));
  return c;
}
const tankWerte = async (c) => (await c.d.komponenteLaden(c.tank)).aktuell.werte;
async function tanken(c, menge) {
  const e = await c.d.ereignisSchnell(c.id, 'Tanken', { artId: c.art, ortName: 'Horrheim' });
  assert.ok(e.ok, JSON.stringify(e));
  const r = await c.d.ereignisAblaufAusfuehren(e.id, { tankId: c.tank, menge: String(menge), betrag: '', literpreis: '1,80', voll: 'ja' });
  assert.ok(r.ok, JSON.stringify(r));
  return { id: e.id, r };
}

test('Tank angeben hält den Kilometerstand fest, Tanken rechnet Verbrauch je km und je sm und merkt ihn sich am Eintrag', async () => {
  const c = await boot(true);
  assert.equal((await tankWerte(c)).fuellstandStrecke, 1000);
  c.d.uhr.ms += 2 * TAG;
  assert.ok((await c.d.zaehlerStandEintragen(c.stunden, { wert: '105', datum: '2026-11-10' })).ok);
  assert.ok((await c.d.zaehlerStandEintragen(c.km, { wert: '1100', datum: '2026-11-10' })).ok);
  const { id, r } = await tanken(c, 30);
  const w = await tankWerte(c);
  assert.equal(w.verbrauch.lProKm, 0.1);
  assert.equal(w.verbrauch.lProSm, 0.185);
  assert.equal(w.fuellstandStrecke, 1100, 'der nächste Verbrauch beginnt bei diesem Stand');
  assert.ok(r.tank.zeilen.some(z => /l je km/.test(z)));
  assert.ok(r.tank.zeilen.some(z => /l je sm/.test(z)));
  assert.ok(r.tank.zeilen.some(z => /l je Betriebsstunde/.test(z)));
  assert.deepEqual(w.reichweite.map(x => x.einheit), ['Betriebsstunden', 'km', 'sm', 'Tage']);
  const e = (await c.d.ereignisLaden(id)).aktuell.werte;
  assert.equal(e.verbrauch.km, 100);
  assert.equal(e.verbrauch.liter, 10);
});

test('Die Einstellung bestimmt die Reihenfolge in der Ergebnis-Seite nach dem Tanken', async () => {
  const c = await boot(true);
  assert.equal(await c.d.verbrauchEinheit(), 'auto');
  assert.ok((await c.d.verbrauchEinheitSetzen('km')).ok);
  assert.equal(await c.d.verbrauchEinheit(), 'km');
  c.d.uhr.ms += 2 * TAG;
  assert.ok((await c.d.zaehlerStandEintragen(c.stunden, { wert: '105', datum: '2026-11-10' })).ok);
  assert.ok((await c.d.zaehlerStandEintragen(c.km, { wert: '1100', datum: '2026-11-10' })).ok);
  const { r } = await tanken(c, 30);
  const v = r.tank.zeilen.filter(z => /Verbrauch|l je/.test(z));
  assert.match(v[1], /l je km/);
});

test('Einstellung: ungültige Einheit wird abgelehnt, die gültige bleibt gespeichert und ist in der Sicherung', async () => {
  const c = await boot(false);
  const schlecht = await c.d.verbrauchEinheitSetzen('meilen');
  assert.equal(schlecht.ok, false);
  assert.equal(await c.d.verbrauchEinheit(), 'auto');
  assert.ok((await c.d.verbrauchEinheitSetzen('sm')).ok);
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  const b = neueDaten();
  await b.starten();
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  assert.equal(await b.verbrauchEinheit(), 'sm');
});

test('Ohne Kilometerzähler ändert sich nichts: kein Verbrauch je km, keine Hinweise dazu, Reichweite wie bisher', async () => {
  const c = await boot(false);
  c.d.uhr.ms += 2 * TAG;
  assert.ok((await c.d.zaehlerStandEintragen(c.stunden, { wert: '105', datum: '2026-11-10' })).ok);
  const { r } = await tanken(c, 30);
  const w = await tankWerte(c);
  assert.equal(w.verbrauch.lProTag, 5);
  assert.equal(w.verbrauch.einzeln[0].lProStunde, 2);
  assert.equal(w.verbrauch.lProKm, undefined);
  assert.equal(w.fuellstandStrecke, undefined);
  assert.deepEqual(w.reichweite.map(x => x.einheit), ['Betriebsstunden', 'Tage']);
  assert.ok(!r.tank.hinweise.some(h => /Kilometer/.test(h)));
});

test('Kilometerstand nicht gewachsen: Hinweis statt falscher Zahl, der Verbrauch je Tag und je Stunde bleibt', async () => {
  const c = await boot(true);
  c.d.uhr.ms += 2 * TAG;
  assert.ok((await c.d.zaehlerStandEintragen(c.stunden, { wert: '105', datum: '2026-11-10' })).ok);
  const { r } = await tanken(c, 30);
  const w = await tankWerte(c);
  assert.equal(w.verbrauch.lProTag, 5);
  assert.equal(w.verbrauch.lProKm, undefined);
  assert.ok(r.tank.hinweise.some(h => /Kilometerzähler/.test(h)));
});

test('Durchschnitt je Aktivität: aus allen Tankungen der Aktivität, nichts davor und nichts von anderen Aktivitäten', async () => {
  const c = await boot(true);
  assert.equal(await c.d.aktivitaetVerbrauch(c.id), null, 'noch nichts gerechnet');
  c.d.uhr.ms += 2 * TAG;
  assert.ok((await c.d.zaehlerStandEintragen(c.stunden, { wert: '105', datum: '2026-11-10' })).ok);
  assert.ok((await c.d.zaehlerStandEintragen(c.km, { wert: '1100', datum: '2026-11-10' })).ok);
  await tanken(c, 30);
  c.d.uhr.ms += 3 * TAG;
  assert.ok((await c.d.zaehlerStandEintragen(c.stunden, { wert: '115', datum: '2026-11-13' })).ok);
  assert.ok((await c.d.zaehlerStandEintragen(c.km, { wert: '1400', datum: '2026-11-13' })).ok);
  await tanken(c, 20);
  const d = await c.d.aktivitaetVerbrauch(c.id);
  assert.equal(d.anzahl, 2);
  assert.equal(d.liter, 30);
  assert.equal(d.tage, 5);
  assert.equal(d.lProTag, 6);
  assert.equal(d.km, 400);
  assert.equal(d.lProKm, 0.075);
  assert.equal(d.einzeln[0].stunden, 15);
  assert.equal(d.einzeln[0].lProStunde, 2);
  assert.equal(await c.d.aktivitaetVerbrauch('gibt-es-nicht'), null);
});

/* ---------- Dateien ---------- */

const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

test('Neues Modul steht in index.html (vor tanken.js) und im Service Worker, Version 2.0.62 überall', () => {
  const idx = lesen('index.html');
  assert.ok(idx.indexOf('js/verbrauch.js') > 0 && idx.indexOf('js/verbrauch.js') < idx.indexOf('js/tanken.js'));
  assert.match(lesen('sw.js'), /'js\/verbrauch\.js'/);
  assert.equal(MM.VERSION, '2.0.62');
  assert.match(lesen('sw.js'), /2\.0\.62/);
  assert.equal(JSON.parse(lesen('package.json')).version, '2.0.62');
  assert.match(lesen('README.md'), /2\.0\.62/);
  assert.match(lesen('CHANGELOG.md'), /## .*2\.0\.62/);
  assert.match(lesen('js/texte.js'), /version: '2\.0\.62'/);
});
