'use strict';
/* 2.0.113: Update-Prüfung der Android-App, Release-Signatur, Download-Ordner. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/texte.js');
require('../js/huelle.js');
require('../js/aktualisierung.js');
const MM = globalThis.MM;
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

function dokument() {
  const kinder = [];
  const el = (tag) => ({ tag, children: [], listeners: {}, className: '', attrs: {}, textContent: '', parentNode: null,
    setAttribute(k, v) { this.attrs[k] = v; }, addEventListener(n, f) { this.listeners[n] = f; },
    appendChild(c) { c.parentNode = this; this.children.push(c); return c; },
    removeChild(c) { this.children = this.children.filter(x => x !== c); c.parentNode = null; } });
  const body = el('body');
  return { body, createElement: el, querySelector(sel) { return body.children.find(c => '.' + c.className === sel) || null; } };
}
function capMit(get) { return { isNativePlatform: () => true, Plugins: { CapacitorHttp: { get } } }; }
const ANTWORT = (v, apk) => ({ status: 200, data: { version: v, apk: apk || 'https://mobimory.com/MobiMory.apk' } });

test('Versionen werden als Zahlen verglichen', () => {
  const A = MM.Aktualisierung;
  assert.equal(A.vergleichen('2.0.9', '2.0.10'), -1);
  assert.equal(A.vergleichen('2.0.113', '2.0.113'), 0);
  assert.equal(A.vergleichen('2.1.0', '2.0.200'), 1);
  assert.equal(A.vergleichen('Quatsch', '2.0.1'), 0);
  assert.equal(A.vergleichen('2.0.113', null), 0);
});

test('Die Angaben aus der Versions-Datei: nur gültige Version und Link auf mobimory.com', () => {
  const A = MM.Aktualisierung;
  assert.deepEqual(A.lesen(ANTWORT('2.0.114')), { version: '2.0.114', apk: 'https://mobimory.com/MobiMory.apk' });
  assert.deepEqual(A.lesen({ status: 200, data: '{"version":"2.0.114","apk":"https://mobimory.com/MobiMory.apk"}' }).version, '2.0.114', 'Text wird gelesen');
  assert.equal(A.lesen(ANTWORT('2.0.114', 'https://fremd.example.org/MobiMory.apk')), null, 'fremde Adresse wird nicht angenommen');
  assert.equal(A.lesen(ANTWORT('2.0.114', 'http://mobimory.com/MobiMory.apk')), null, 'nur https');
  assert.equal(A.lesen(ANTWORT('2.0.114', 'https://mobimory.com.evil.example/x.apk')), null, 'Ähnliche Adresse zählt nicht');
  assert.equal(A.lesen(ANTWORT('neu')), null);
  assert.equal(A.lesen({ status: 404, data: '' }), null);
  assert.equal(A.lesen({ status: 200, data: 'kein json' }), null);
  assert.equal(A.lesen(null), null);
});

test('Im Browser: keine Abfrage, keine Meldung', async () => {
  let aufrufe = 0;
  const ohne = MM.Aktualisierung.erzeugen({}, '2.0.113');
  assert.equal(await ohne.pruefen(), null);
  const web = MM.Aktualisierung.erzeugen({ Capacitor: { isNativePlatform: () => false, Plugins: { CapacitorHttp: { get: () => { aufrufe++; } } } } }, '2.0.113');
  assert.equal(await web.pruefen(), null); assert.equal(aufrufe, 0);
  const doc = dokument();
  await MM.Aktualisierung.beimStart({ document: doc, Capacitor: { isNativePlatform: () => false } }, '2.0.113');
  assert.equal(doc.body.children.length, 0);
});

test('In der Hülle: fragt die Versions-Datei auf mobimory.com und meldet neuere Versionen', async () => {
  let opt = null;
  const a = MM.Aktualisierung.erzeugen({ Capacitor: capMit(o => { opt = o; return Promise.resolve(ANTWORT('2.0.114')); }) }, '2.0.113');
  const r = await a.pruefen();
  assert.match(opt.url, /^https:\/\/mobimory\.com\/version\.json\?t=\d+$/);
  assert.deepEqual(r, { neu: true, version: '2.0.114', apk: 'https://mobimory.com/MobiMory.apk' });
  const gleich = await MM.Aktualisierung.erzeugen({ Capacitor: capMit(() => Promise.resolve(ANTWORT('2.0.113'))) }, '2.0.113').pruefen();
  assert.equal(gleich.neu, false);
  const aelter = await MM.Aktualisierung.erzeugen({ Capacitor: capMit(() => Promise.resolve(ANTWORT('2.0.100'))) }, '2.0.113').pruefen();
  assert.equal(aelter.neu, false, 'eine ältere Datei löst keinen Hinweis aus');
});

test('Fehler im Netz oder in der Datei: still, nichts wird gezeigt', async () => {
  for (const get of [() => Promise.reject(new Error('offline')), () => { throw new Error('kaputt'); }, () => Promise.resolve({ status: 500, data: '' }), () => Promise.resolve(undefined)]) {
    const doc = dokument();
    const r = await MM.Aktualisierung.beimStart({ document: doc, Capacitor: capMit(get) }, '2.0.113');
    assert.equal(r, null); assert.equal(doc.body.children.length, 0);
  }
  const ohneNetz = await MM.Aktualisierung.erzeugen({ Capacitor: { isNativePlatform: () => true } }, '2.0.113').pruefen();
  assert.equal(ohneNetz, null, 'ohne Netz-Modul keine Abfrage');
});

test('Hinweis: ein Hinweis mit Herunterladen (öffnet den Link) und Später (schließt)', async () => {
  const doc = dokument(); const adresse = { href: '' };
  await MM.Aktualisierung.beimStart({ document: doc, location: adresse, Capacitor: capMit(() => Promise.resolve(ANTWORT('2.0.114'))) }, '2.0.113');
  assert.equal(doc.body.children.length, 1);
  const box = doc.body.children[0];
  assert.equal(box.className, 'apk-hinweis');
  assert.equal(box.children[0].textContent, 'Neue Version 2.0.114 von MobiMory verfügbar.');
  assert.equal(box.children[1].textContent, 'Herunterladen'); assert.equal(box.children[2].textContent, 'Später');
  /* ein zweiter Aufruf legt keinen zweiten Hinweis an */
  await MM.Aktualisierung.beimStart({ document: doc, location: adresse, Capacitor: capMit(() => Promise.resolve(ANTWORT('2.0.114'))) }, '2.0.113');
  assert.equal(doc.body.children.length, 1);
  box.children[1].listeners.click();
  assert.equal(adresse.href, 'https://mobimory.com/MobiMory.apk');
  box.children[2].listeners.click();
  assert.equal(doc.body.children.length, 0);
});

test('Einbau: Skript in index.html und Service-Worker-Liste, Start prüft nur mit dem Modul, Stil vorhanden', () => {
  assert.match(lesen('index.html'), /<script src="js\/huelle\.js"><\/script>\s*<script src="js\/aktualisierung\.js"><\/script>/);
  assert.ok(lesen('sw.js').includes("'js/aktualisierung.js'"));
  assert.match(lesen('js/start.js'), /MM\.Aktualisierung\.beimStart\(global, MM\.VERSION\)/);
  assert.match(lesen('css/styles.css'), /\.apk-hinweis \{/);
  assert.equal(MM.Texte.NEUERUNGEN[18].version, '2.0.113');
  assert.match(MM.Texte.NEUERUNGEN[18].punkte.join(' '), /Neue Version verfügbar/);
});

test('Release-Signatur: Schlüssel nur aus der Umgebung, ohne Schlüssel bleibt die Test-Signatur', () => {
  const g = lesen('android/app/build.gradle');
  assert.match(g, /System\.getenv\('MM_KEYSTORE_FILE'\)/); assert.match(g, /System\.getenv\('MM_KEYSTORE_PASSWORD'\)/);
  assert.match(g, /keyAlias 'mobimory'/); assert.match(g, /signingConfig signingConfigs\.release/);
  assert.match(g, /storeFile file\('debug\.keystore'\)/, 'Test-Signatur bleibt');
  assert.doesNotMatch(g, /storePassword '(?!android')/, 'kein Kennwort im Repository');
  assert.ok(!fs.readdirSync(path.join(__dirname, '..', 'android', 'app')).some(f => /release.*\.(jks|keystore)$/i.test(f)), 'kein Release-Schlüssel im Repository');
});

test('Bau-Ablauf: Test-APK ohne Schlüssel, Download-Ordner mit Schlüssel', () => {
  const w = lesen('.github/workflows/android-apk.yml');
  assert.match(w, /assembleDebug/); assert.match(w, /assembleRelease/); assert.match(w, /MobiMory-APK/); assert.match(w, /MobiMory-Download/);
  assert.match(w, /secrets\.MM_KEYSTORE_BASE64/); assert.match(w, /secrets\.MM_KEYSTORE_PASSWORD/);
  assert.match(w, /MobiMory-V2_\*\.zip/, 'baut aus der neuesten ZIP');
  assert.match(w, /apk:'https:\/\/mobimory\.com\/MobiMory\.apk'/);
  assert.ok(fs.existsSync(path.join(__dirname, '..', 'docs', 'download.html')));
  const d = lesen('docs/download.html');
  assert.match(d, /href="MobiMory\.apk"/); assert.match(d, /fetch\('version\.json'/);
  assert.doesNotMatch(d, /https?:\/\/(?!app\.mobimory\.com)/, 'keine fremden Adressen auf der Download-Seite');
});
