'use strict';
/* 2.0.125: Handbuch. Texte nur in js/handbuch.js, Deutsch und Englisch vollständig, PDF aus der App, Seiten und Einbau. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'texte', 'fahrzeugarten', 'pdf', 'handbuch'].forEach((m) => require('../js/' + m + '.js'));
const MM = globalThis.MM;
const H = MM.Handbuch;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

test('Gliederung: 21 Kapitel nach Aufgaben, Zähler-Kapitel bewusst nicht dabei, Kapitel-IDs eindeutig', () => {
  const ids = H.KAPITEL.map((k) => k.id);
  assert.equal(ids.length, 21);
  assert.equal(new Set(ids).size, 21);
  assert.deepEqual(ids.slice(0, 9), ['schnellstart', 'einrichten', 'stammdaten', 'erfassen', 'fahrzeug', 'personen', 'orte', 'listen', 'planen']);
  assert.equal(ids.includes('zaehler'), false);
  assert.deepEqual(H.SPRACHEN.map((s) => s.id), ['de', 'en']);
});

test('Jede Sprache ist vollständig: Titel, Absätze, Listen und Bildunterschriften in de und en, gleich viele Punkte', () => {
  H.KAPITEL.forEach((k) => {
    H.SPRACHEN.forEach((s) => assert.ok(k.titel[s.id] && k.titel[s.id].length > 3, k.id + ' Titel ' + s.id));
    assert.ok(k.bloecke.length >= 3, k.id);
    k.bloecke.forEach((b, i) => {
      assert.ok(['p', 'kopf', 'schritte', 'liste', 'hinweis', 'bild'].includes(b.typ), k.id + ' ' + i);
      if (b.typ === 'schritte' || b.typ === 'liste') {
        assert.ok(Array.isArray(b.de) && Array.isArray(b.en) && b.de.length > 0, k.id + ' ' + i);
        assert.equal(b.de.length, b.en.length, k.id + ' Block ' + i + ': gleich viele Punkte');
        b.de.concat(b.en).forEach((t) => assert.ok(typeof t === 'string' && t.length > 2));
      } else {
        assert.ok(typeof b.de === 'string' && b.de.length > 2 && typeof b.en === 'string' && b.en.length > 2, k.id + ' ' + i);
        assert.notEqual(b.de, b.en, k.id + ' Block ' + i + ' wirkt unübersetzt');
      }
      if (b.typ === 'bild') assert.ok(H.BILDER.includes(b.id), b.id);
    });
  });
  H.SPRACHEN.forEach((s) => Object.keys(H.UI.de).forEach((key) => assert.ok(H.UI[s.id][key], 'UI ' + s.id + ' ' + key)));
});

test('Inhalt: die festgelegten Themen stehen drin (19 Arten, Schlüsselwort, iPad, Home-Bildschirm, Nachrichten, Reihenfolge Aktivität – Route – Tag)', () => {
  const alles = (sp) => H.inhaltsliste(sp).map((k) => H.kapitel(k.id, sp)).map((k) => k.titel + ' ' + k.bloecke.map((b) => (b.text || '') + ' ' + (b.punkte || []).join(' ')).join(' ')).join(' ');
  const de = alles('de'), en = alles('en');
  ['19 Fahrzeugarten', 'Schlüsselwort', 'iPad', 'Home-Bildschirm', 'Nachrichten auf diesem Gerät erlauben', 'Standortwache', 'Grundcheck', 'Reisecheck', 'Wetter', 'Tide', 'Stammdaten', 'Browser', 'Android'].forEach((w) => assert.ok(de.includes(w), 'de ' + w));
  ['19 vehicle types', 'keyword', 'iPad', 'Home Screen', 'Allow messages on this device', 'location watch', 'basic check', 'trip check', 'weather', 'tide', 'master data', 'Android'].forEach((w) => assert.ok(en.includes(w), 'en ' + w));
  const plan = H.kapitel('planen', 'de').bloecke.map((b) => b.text || '').join('|');
  assert.ok(plan.indexOf('1. Die Aktivität') < plan.indexOf('2. Die Route') && plan.indexOf('2. Die Route') < plan.indexOf('3. Der Tag'));
});

test('Alle 19 Fahrzeugarten stehen im Kapitel Fahrzeug (aus MM.Fahrzeugarten, nicht geraten)', () => {
  const arten = MM.Fahrzeugarten.alle();
  assert.equal(arten.length, 19);
  const text = H.kapitel('fahrzeug', 'de').bloecke.map((b) => (b.text || '') + ' ' + (b.punkte || []).join(' ')).join(' ').toLowerCase();
  arten.forEach((a) => assert.ok(text.includes(a.name.toLowerCase().replace(' monohull', '').replace('segelboot katamaran', 'segelboot katamaran')), 'fehlt: ' + a.name));
});

test('Kapitel und Sprache: unbekannte Sprache fällt auf Deutsch, unbekanntes Kapitel gibt null, Nachbarn stimmen', () => {
  assert.equal(H.sprache('fr'), 'de'); assert.equal(H.sprache('en'), 'en');
  assert.equal(H.kapitel('gibtsnicht', 'de'), null);
  const k = H.kapitel('karte', 'en');
  assert.equal(k.nr, 13); assert.equal(k.vorher.id, 'unterwegs'); assert.equal(k.naechstes.id, 'tanken');
  assert.equal(H.kapitel('schnellstart', 'de').vorher, null);
  assert.equal(H.kapitel('verleih', 'de').naechstes.id, 'faq');
  assert.equal(H.kapitel('faq', 'de').naechstes, null);
  assert.deepEqual(H.inhaltsliste('de').map((x) => x.nr), Array.from({ length: 21 }, (_, i) => i + 1));
});

test('PDF: wird in der App erzeugt (ohne Netz), deutsch und englisch, mit und ohne Bilder', () => {
  const jpeg = fs.readFileSync(path.join(__dirname, '..', 'handbuch', 'schnellstart.jpg'));
  const de = H.pdf('de', {}, { version: '2.0.131' });
  assert.equal(Buffer.from(de.bytes.slice(0, 5)).toString('latin1'), '%PDF-');
  assert.ok(de.bytes.length > 8000); assert.equal(de.bilder, 0); assert.equal(de.ohneBild, H.BILDER.length);
  assert.equal(de.name, 'MobiMory_Handbuch_2.0.131.pdf');
  const en = H.pdf('en', { schnellstart: new Uint8Array(jpeg) }, { version: '2.0.131' });
  assert.equal(en.name, 'MobiMory_Manual_2.0.131.pdf'); assert.equal(en.bilder, 1); assert.equal(en.ohneBild, H.BILDER.length - 1);
  assert.ok(Buffer.from(en.bytes).toString('latin1').includes('%%EOF'));
});

test('Einbau: Skript in index.html und sw.js, Bilder im Zwischenspeicher, Seiten und Route, Menü bei „Über MobiMory“, Neuerung mit „Wo und wie“', () => {
  assert.ok(lesen('index.html').includes('<script src="js/handbuch.js"></script>'));
  const sw = lesen('sw.js');
  assert.ok(sw.includes("'js/handbuch.js'"));
  H.BILDER.forEach((b) => { assert.ok(sw.includes("'handbuch/" + b + ".jpg'"), b); assert.ok(fs.existsSync(path.join(__dirname, '..', 'handbuch', b + '.jpg')), 'Bild ' + b); assert.ok(fs.statSync(path.join(__dirname, '..', 'handbuch', b + '.jpg')).size > 5000); });
  const a = lesen('js/ansicht.js');
  assert.ok(a.includes("teile[0] === 'handbuch'") && a.includes('function seiteHandbuch'));
  assert.ok(a.includes("kachel('Handbuch · Manual'"));
  assert.ok(a.includes('MM.Handbuch.pdf(sp, bilder'));
  const n = MM.Texte.NEUERUNGEN[5];
  assert.equal(n.version, '2.0.126');
  assert.ok(n.punkte.some((p) => p.includes('Handbuch') && p.includes('Wo und wie: Einstellungen › Über MobiMory › Handbuch')));
  assert.ok(n.punkte.some((p) => p.includes('32 Bilder')));
  assert.ok(MM.Texte.NEUERUNGEN[6].punkte.some((p) => p.includes('Fehler behoben') && p.includes('Wo und wie')));
  assert.ok(lesen('CHANGELOG.md').startsWith('# Änderungen\n\n## 2.0.131'));
});

test('Stammdaten-Kapitel (2.0.127): Namen kommen aus dem Code, fünf Erfassungswege, jedes Kapitel hat ein Bild', () => {
  ['hilfen', 'komponenten', 'personen', 'orte', 'fristen', 'dokumente'].forEach((m) => require('../js/' + m + '.js'));
  const txt = (id, sp) => H.kapitel(id, sp || 'de').bloecke.map((b) => (b.text || '') + ' ' + (b.punkte || []).join(' ')).join(' ');
  MM.Komponenten.arten().forEach((a) => assert.ok(txt('fahrzeug').includes(a.name) || txt('fahrzeug').includes(a.name.replace('Stromversorgung', 'Stromversorgung')), 'Komponentenart ' + a.name));
  MM.Fahrzeugarten.gruppen('motorboot').forEach((g) => assert.ok(txt('fahrzeug').includes(g.titel), 'Gruppe ' + g.titel));
  MM.Personen.FUNKTIONEN.forEach((x) => assert.ok(txt('personen').includes(x), 'Funktion ' + x));
  MM.Personen.TIERARTEN.forEach((x) => assert.ok(txt('personen').includes(x), 'Tierart ' + x));
  MM.Dokumente.ARTEN.forEach((a) => assert.ok(txt('fahrzeug').includes(a.label), 'Dokumentart ' + a.label));
  MM.Fristen.WIRKUNGEN.forEach((w) => assert.ok(txt('fahrzeug').toLowerCase().includes(w.label.toLowerCase().replace('nur warnen', 'nur warnen')), 'Wirkung ' + w.label));
  MM.Orte.ORTARTEN.forEach((o) => assert.ok(txt('orte').toLowerCase().includes(o.label.split(' (')[0].toLowerCase()), 'Ortart ' + o.label));
  ['von Hand', 'Schnellstart', 'Dokument erfassen', 'Excel', 'Übergabedatei', 'Gibt es das schon'].forEach((w) => assert.ok(txt('erfassen').includes(w), 'Weg ' + w));
  assert.ok(txt('erfassen', 'en').includes('handover file') && txt('erfassen', 'en').includes('Excel'));
  H.KAPITEL.filter((k) => k.id !== 'faq').forEach((k) => assert.ok(k.bloecke.some((b) => b.typ === 'bild'), 'Kapitel ohne Bild: ' + k.id));
  assert.equal(H.BILDER.length, 32);
});

test('Stil: keine Texte aus dem Handbuch enthalten das Wort „Peilung“', () => {
  ['js/handbuch.js'].forEach((f) => assert.equal(/peilung/i.test(lesen(f)), false, f));
});
