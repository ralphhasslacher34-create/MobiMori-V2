'use strict';
/* 2.0.83 (Bau 2), seit 2.0.84 Code-Feld bei jedem Angebot und Mail beim Anlegen: Gutscheincodes in der App. Texte und Preise (konto.js), Anfragen an den Dienst (daten.js), das Code-Feld beim Bezahlen und die
   Admin-Seite (echte Funktionen aus ansicht.js mit einem kleinen Ersatz für den Browser), Einbau. */
const t = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = t;
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'konto', 'texte', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM, K = MM.Konto;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

async function neu() {
  let n = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 15, 12, 0, n++)).toISOString() });
  await d.starten();
  return d;
}
const tick = async () => { for (let i = 0; i < 12; i++) await new Promise((r) => setImmediate(r)); };

const RABATT = { ok: true, art: 'rabatt', code: 'WILLKOMMEN', prozent: 20, preise: {
  mittel: { code: 'WILLKOMMEN', prozent: 20, preis: '59,88 €', rabatt: '−11,98 €', betrag: '47,90 €', cent: 4790 },
  voll: { code: 'WILLKOMMEN', prozent: 20, preis: '119,88 €', rabatt: '−23,98 €', betrag: '95,90 €', cent: 9590 } } };
const FREI = { ok: true, art: 'frei', code: 'ABCD-EFGH', stufe: 'voll', stufeName: 'Voll', monate: 3, bis: '15.02.2027', verlaengert: false, ersetzt: null };

test('Texte: Prozent mit Komma, Preis mit Rabatt nur für Angebote mit Preis, Zeilen für Rabatt- und Geschenkcode', () => {
  assert.equal(K.prozentText(20), '20 %'); assert.equal(K.prozentText(12.5), '12,5 %'); assert.equal(K.prozentText('7.25'), '7,25 %');
  const mittel = K.angebote({ stufe: { id: 'basic' }, grenzen: { online: false } })[0];
  assert.equal(K.rabattPreis(RABATT, mittel), 'Mittel für ein Jahr: 47,90 € statt 59,88 € (Code WILLKOMMEN, 20 % Rabatt)');
  assert.equal(K.rabattPreis(RABATT, { id: 'recherche5', titel: 'x' }), null);
  assert.equal(K.rabattPreis(FREI, mittel), null); assert.equal(K.rabattPreis(null, mittel), null);
  assert.match(K.codeZeilen(RABATT)[0], /20 % Rabatt auf deinen ersten Kauf/); assert.match(K.TEXT_CODE_WO, /bei dem Angebot/);
  const f = K.codeZeilen(FREI); assert.match(f[0], /schenkt dir Voll für 3 Monate, ohne Bezahlen\. Danach gilt deine Stufe bis 15\.02\.2027/); assert.equal(f.length, 1);
  assert.match(K.codeZeilen(Object.assign({}, FREI, { monate: 1, verlaengert: true }))[0], /für 1 Monat,/);
  assert.match(K.codeZeilen(Object.assign({}, FREI, { verlaengert: true }))[1], /angehängt/);
  assert.match(K.codeZeilen(Object.assign({}, FREI, { ersetzt: 'Mittel' }))[1], /restliche Zeit.*Mittel.*nicht angerechnet/s);
  assert.deepEqual(K.codeZeilen(null), []);
  assert.ok(K.codeEingabe('abcd-efgh')); assert.ok(K.codeEingabe(' WILLKOMMEN ')); assert.ok(!K.codeEingabe('')); assert.ok(!K.codeEingabe('ab')); assert.ok(!K.codeEingabe('a$bcd'));
  assert.match(K.TEXT_CODE, /Neukunden/); assert.match(K.TEXT_CODE, /Recherchen/); assert.match(K.TEXT_CODE, /Geschenkcode/);
});

test('Anfragen: Bestellen schickt den Code nur mit, wenn einer da ist; Prüfen, Einlösen, Liste, Anlegen und Löschen gehen an die richtigen Adressen', async () => {
  const d = await neu(), auf = [];
  d.kontoAnfrageFn = async (url, methode, token, body) => { auf.push({ url: url.replace(/^.*\.com/, ''), methode, body }); return { ok: true, code: 'ABCD-EFGH', codes: [{ code: 'X' }] }; };
  await d.kontoBestellen('mittel', 'paypal');
  await d.kontoBestellen('voll', 'ueberweisung', 'WILLKOMMEN');
  assert.deepEqual(auf[0].body, { produkt: 'mittel', weg: 'paypal' }); assert.deepEqual(auf[1].body, { produkt: 'voll', weg: 'ueberweisung', code: 'WILLKOMMEN' });
  const p = await d.gutscheinPruefen('abc'); assert.equal(p.ok, true);
  await d.gutscheinEinloesen('abc');
  assert.equal(auf[2].url, '/gutschein/pruefen'); assert.deepEqual(auf[2].body, { code: 'abc' }); assert.equal(auf[3].url, '/gutschein/einloesen');
  const l = await d.gutscheinListe(); assert.equal(l.ok, true); assert.equal(l.codes.length, 1); assert.equal(auf[4].methode, 'GET'); assert.equal(auf[4].url, '/gutschein/liste');
  const a = await d.gutscheinAnlegen({ prozent: '12,5', laeuftAb: '2027-06-30', grenze: '50', code: '', stufe: '', monate: '', notiz: 'XY' });
  assert.equal(a.ok, true); assert.equal(a.code, 'ABCD-EFGH');
  assert.deepEqual(auf[5].body, { prozent: '12,5', laeuftAb: '2027-06-30', grenze: '50', notiz: 'XY' }, 'leere Felder gehen nicht mit'); assert.equal(a.mail, null, 'ohne Empfänger keine Angabe zur Mail');
  d.kontoAnfrageFn = async (url, methode, token, body) => { auf.push({ url, methode, body }); return { ok: true, code: 'ZZZZ-1111', mail: false }; };
  const am = await d.gutscheinAnlegen({ prozent: '100', laeuftAb: '2027-06-30', stufe: 'voll', monate: 3, empfaenger: 'a@b.de' });
  assert.equal(am.mail, false); assert.equal(auf[auf.length - 1].body.empfaenger, 'a@b.de');
  d.kontoAnfrageFn = async (url, methode, token, body) => { auf.push({ url, methode, body }); return { ok: true, code: 'ABCD-EFGH', codes: [{ code: 'X' }] }; };
  await d.gutscheinLoeschen('ABCD-EFGH'); assert.deepEqual(auf[auf.length - 1].body, { code: 'ABCD-EFGH' });
  /* Fehler in einfachen Worten, Anmeldung abgelaufen, Fehler eines Feldes */
  d.kontoAnfrageFn = async () => { const e = new Error('Dieser Code ist abgelaufen.'); e.status = 400; throw e; };
  const f = await d.gutscheinPruefen('x'); assert.equal(f.ok, false); assert.equal(f.fehler, 'Dieser Code ist abgelaufen.'); assert.equal(f.abgelaufen, false);
  d.kontoAnfrageFn = async () => { const e = new Error('weg'); e.status = 401; throw e; };
  assert.equal((await d.gutscheinEinloesen('x')).abgelaufen, true);
  d.kontoAnfrageFn = async () => { const e = new Error('Das Ablaufdatum fehlt.'); e.status = 400; e.feld = 'laeuftAb'; throw e; };
  const g = await d.gutscheinAnlegen({ prozent: 10 }); assert.equal(g.ok, false); assert.equal(g.fehler.laeuftAb, 'Das Ablaufdatum fehlt.');
  d.kontoAnfrageFn = async () => { const e = new Error('Der Rabatt muss …'); e.status = 400; e.feld = 'prozent'; throw e; };
  assert.equal((await d.gutscheinAnlegen({ prozent: 50 })).fehler.prozent, 'Der Rabatt muss …');
});

/* ---- Die echten Funktionen der Seiten (aus ansicht.js herausgeschnitten) mit einem kleinen Ersatz für den Browser ---- */
function neuesElement(tag) {
  const e = { tag, kinder: [], attrs: {}, handlers: {}, style: {}, value: '', disabled: false };
  e.appendChild = (k) => { e.kinder.push(k); return k; };
  e.addEventListener = (n, f) => { (e.handlers[n] = e.handlers[n] || []).push(f); };
  Object.defineProperty(e, 'textContent', { get() { return text(e); }, set(v) { e.kinder = v === '' || v === null ? [] : [String(v)]; } });
  return e;
}
function hBauen() {
  return function h(tag, attrs) {
    const e = neuesElement(tag);
    if (attrs) Object.keys(attrs).forEach((k) => { const v = attrs[k]; if (v === null || v === undefined || v === false) return; if (k === 'text') e.kinder.push(String(v)); else { e.attrs[k] = v; if (k === 'value') e.value = v; } });
    const rein = (k) => { if (k === null || k === undefined) return; if (Array.isArray(k)) k.forEach(rein); else e.kinder.push(k); };
    for (let i = 2; i < arguments.length; i++) rein(arguments[i]);
    return e;
  };
}
function text(e) { return typeof e === 'string' ? e : (e && e.kinder ? e.kinder.map(text).join(' ') : ''); }
function finde(e, fn, aus) { aus = aus || []; if (!e || typeof e === 'string' || !e.kinder) return aus; if (fn(e)) aus.push(e); e.kinder.forEach((k) => finde(k, fn, aus)); return aus; }
const knopf = (wurzel, beschriftung) => finde(wurzel, (e) => e.tag === 'button' && text(e) === beschriftung);
const klick = (e) => (e.handlers.click || []).forEach((f) => f());
function schnitt(von, bis) {
  const q = lesen('js/ansicht.js'), a = q.indexOf(von), b = q.indexOf(bis, a);
  assert.ok(a > 0 && b > a, von);
  return q.slice(a, b);
}
function feldBauen(h) {
  return {
    kontoFeld: (id, beschriftung, typ, wert) => { const eingabe = h('input', { type: typ, id, value: wert || '' }), tel = h('p', { class: 'fehler' }); return { eingabe, tel, feld: h('div', { class: 'feld' }, eingabe, tel) }; },
    auswahlFeld: (id, beschriftung, optionen, wert) => { const eingabe = h('select', { id, value: String(wert) }), tel = h('p', { class: 'fehler' }); return { eingabe, tel, feld: h('div', { class: 'feld' }, eingabe, tel) }; }
  };
}

function kastenBauen(d, fenster, nachher) {
  const h = hBauen(), f = feldBauen(h);
  const quelle = schnitt('  function bezahlenKasten(stufe, nachher) {', '  /* ---------- Entwickler (seit 2.0.68)');
  const bauen = new Function('MM', 'h', 'daten', 'kontoFeld', 'window', quelle + '\n  return bezahlenKasten;');
  return bauen(MM, h, d, f.kontoFeld, fenster)({ ok: true, stufe: { id: 'basic', name: 'Basic', bis: null }, grenzen: { geraete: 2, checks: 0, fahrzeuge: 1, online: false } }, nachher);
}

test('Code-Feld steht bei jedem Angebot: Rabattcode ändert nur den Preis dieses Angebots, Bestellen schickt den Code mit, Ändern des Codes nimmt den Preis zurück', async () => {
  const d = { gutscheinPruefen: async () => RABATT, kontoBestellen: async (...a) => { d.bestellt = a; return { ok: true, url: 'https://paypal.example/x' }; } };
  const fenster = { location: { assign: (u) => { fenster.ziel = u; } } };
  const kasten = kastenBauen(d, fenster, () => {});
  const felder = finde(kasten, (e) => e.tag === 'input');
  assert.equal(felder.length, 2, 'ein Feld je Angebot (Mittel, Voll), nicht eins für alle'); assert.deepEqual(felder.map((f) => f.attrs.id), ['bz-code-mittel', 'bz-code-voll']);
  assert.match(text(kasten), /Mittel für ein Jahr: 59,88 €/); assert.ok(!/statt/.test(text(kasten)), 'ohne Code die normalen Preise');
  assert.match(text(kasten), /Hast du einen Gutscheincode\? Trage ihn unten bei dem Angebot ein/);
  /* Das Feld gehört zum Angebot: Es steht im selben Block wie der Preis des Angebots */
  const bloecke = finde(kasten, (e) => e.attrs && e.attrs.class === 'block');
  assert.equal(bloecke.length, 2); assert.ok(finde(bloecke[0], (e) => e === felder[0]).length === 1 && /Mittel für ein Jahr/.test(text(bloecke[0])));
  assert.ok(finde(bloecke[1], (e) => e === felder[1]).length === 1 && /Voll für ein Jahr/.test(text(bloecke[1])));
  felder[0].value = 'willkommen';
  klick(knopf(kasten, 'Code prüfen')[0]); await tick();
  assert.match(text(bloecke[0]), /Mittel für ein Jahr: 47,90 € statt 59,88 € \(Code WILLKOMMEN, 20 % Rabatt\)/);
  assert.match(text(bloecke[0]), /20 % Rabatt auf deinen ersten Kauf/);
  assert.match(text(bloecke[1]), /Voll für ein Jahr: 119,88 €/); assert.ok(!/statt/.test(text(bloecke[1])), 'Voll bleibt ohne eigene Prüfung beim Listenpreis');
  klick(knopf(bloecke[0], 'Mit PayPal bezahlen')[0]); await tick();
  assert.deepEqual(d.bestellt, ['mittel', 'paypal', 'willkommen']); assert.equal(fenster.ziel, 'https://paypal.example/x');
  klick(knopf(bloecke[1], 'Mit PayPal bezahlen')[0]); await tick();
  assert.deepEqual(d.bestellt, ['voll', 'paypal', ''], 'Voll wurde nicht geprüft, also kein Code');
  /* Voll mit eigenem Code */
  felder[1].value = 'willkommen'; klick(knopf(kasten, 'Code prüfen')[1]); await tick();
  assert.match(text(bloecke[1]), /Voll für ein Jahr: 95,90 € statt 119,88 €/);
  klick(knopf(bloecke[1], 'Per Überweisung')[0]); await tick();
  assert.deepEqual(d.bestellt, ['voll', 'ueberweisung', 'willkommen']);
  /* Code geändert: Preis zurück, Bestellung ohne Code */
  felder[0].value = 'anderer'; (felder[0].handlers.input || []).forEach((f) => f());
  assert.ok(!/statt/.test(text(bloecke[0])));
  d.bestellt = null; klick(knopf(bloecke[0], 'Per Überweisung')[0]); await tick();
  assert.deepEqual(d.bestellt, ['mittel', 'ueberweisung', '']);
});

test('Code-Feld: Recherchen haben kein Feld; Rabattcode ohne Preis für das Angebot sagt es', async () => {
  const d = { gutscheinPruefen: async () => ({ ok: true, art: 'rabatt', code: 'W', prozent: 20, preise: { voll: RABATT.preise.voll } }) };
  const h = hBauen(), f = feldBauen(h);
  const quelle = schnitt('  function bezahlenKasten(stufe, nachher) {', '  /* ---------- Entwickler (seit 2.0.68)');
  const bauen = new Function('MM', 'h', 'daten', 'kontoFeld', 'window', quelle + '\n  return bezahlenKasten;');
  const kasten = bauen(MM, h, d, f.kontoFeld, {})({ ok: true, stufe: { id: 'mittel', name: 'Mittel', bis: null }, grenzen: { geraete: 4, checks: 3, fahrzeuge: 3, online: true } }, () => {});
  const bloecke = finde(kasten, (e) => e.attrs && e.attrs.class === 'block');
  assert.equal(bloecke.length, 4, 'Mittel (verlängern), Voll, Recherchen, Routen');
  const felder = finde(kasten, (e) => e.tag === 'input');
  assert.equal(felder.length, 2, 'nur Mittel und Voll haben ein Feld'); assert.equal(knopf(bloecke[2], 'Code prüfen').length, 0); assert.equal(finde(bloecke[2], (e) => e.tag === 'input').length, 0); assert.equal(knopf(bloecke[3], 'Code prüfen').length, 0); assert.equal(finde(bloecke[3], (e) => e.tag === 'input').length, 0);
  felder[0].value = 'willkommen'; klick(knopf(bloecke[0], 'Code prüfen')[0]); await tick();
  assert.match(text(bloecke[0]), /Dieser Code gilt für dieses Angebot nicht\./); assert.ok(!/statt/.test(text(bloecke[0])));
  assert.equal(knopf(bloecke[0], 'Mit PayPal bezahlen').length, 1, 'normal bezahlen bleibt möglich');
});

test('Code-Feld: Fehler des Dienstes stehen unter dem Feld; leere Eingabe wird nicht gesendet', async () => {
  let gesendet = 0;
  const d = { gutscheinPruefen: async () => { gesendet++; return { ok: false, fehler: 'Dieser Code ist abgelaufen.' }; } };
  const kasten = kastenBauen(d, { location: {} }, () => {});
  const eingabe = finde(kasten, (e) => e.tag === 'input')[0];
  klick(knopf(kasten, 'Code prüfen')[0]); await tick();
  assert.equal(gesendet, 0); assert.match(text(kasten), /Bitte einen Code eintragen/);
  eingabe.value = 'ALT10'; klick(knopf(kasten, 'Code prüfen')[0]); await tick();
  assert.equal(gesendet, 1); assert.match(text(kasten), /Dieser Code ist abgelaufen\./); assert.ok(!/statt/.test(text(kasten)));
});

test('Geschenkcode: Bei dem passenden Angebot nur „Code einlösen“ und keine Bezahl-Knöpfe (sonst verlangt PayPal den vollen Preis); beim anderen Angebot der Hinweis', async () => {
  const nachher = []; const d = { gutscheinPruefen: async () => FREI, gutscheinEinloesen: async (c) => { d.eingeloest = c; return { ok: true, stufeName: 'Voll', bisText: '15.02.2027' }; }, kontoBestellen: async () => { throw new Error('darf nicht bestellt werden'); } };
  const kasten = kastenBauen(d, { location: {} }, (m) => nachher.push(m));
  const felder = finde(kasten, (e) => e.tag === 'input'), bloecke = finde(kasten, (e) => e.attrs && e.attrs.class === 'block');
  assert.equal(knopf(kasten, 'Mit PayPal bezahlen').length, 2);
  /* Der Code (Voll) wird bei Mittel eingegeben: Hinweis, keine Bezahl-Knöpfe, kein Einlösen */
  felder[0].value = 'ABCDEFGH'; klick(knopf(kasten, 'Code prüfen')[0]); await tick();
  assert.match(text(bloecke[0]), /gilt nicht für dieses Angebot, sondern für Voll\. Bitte trage ihn dort ein/);
  assert.equal(knopf(bloecke[0], 'Mit PayPal bezahlen').length, 0); assert.equal(knopf(bloecke[0], 'Per Überweisung').length, 0); assert.equal(knopf(bloecke[0], 'Code einlösen').length, 0);
  assert.equal(knopf(bloecke[1], 'Mit PayPal bezahlen').length, 1, 'Voll ist unberührt');
  /* Bei Voll: einlösen, kein Bezahlen */
  felder[1].value = 'ABCDEFGH'; klick(knopf(kasten, 'Code prüfen')[1]); await tick();
  assert.match(text(bloecke[1]), /schenkt dir Voll für 3 Monate/); assert.equal(knopf(bloecke[1], 'Code einlösen').length, 1);
  assert.equal(knopf(bloecke[1], 'Mit PayPal bezahlen').length, 0, 'bei einem 100-%-Code kein PayPal');
  assert.equal(knopf(bloecke[1], 'Per Überweisung').length, 0);
  /* Code wieder ändern: Bezahl-Knöpfe sind zurück */
  felder[1].value = 'XYZ123'; (felder[1].handlers.input || []).forEach((f) => f());
  assert.equal(knopf(bloecke[1], 'Mit PayPal bezahlen').length, 1); assert.equal(knopf(bloecke[1], 'Code einlösen').length, 0);
  felder[1].value = 'ABCDEFGH'; klick(knopf(kasten, 'Code prüfen')[1]); await tick();
  klick(knopf(bloecke[1], 'Code einlösen')[0]); await tick();
  assert.equal(d.eingeloest, 'ABCDEFGH'); assert.deepEqual(nachher, ['Der Code ist eingelöst: Voll gilt bis 15.02.2027.']);
});

test('Admin-Seite: Nicht-Admins sehen nur den Hinweis; Admins sehen die Liste, legen Rabatt- und Geschenkcodes an und löschen mit Rückfrage', async () => {
  const quelle = 'var meldungKonto = "";\n' + schnitt('  var meldungGutschein = \'\';', '  /* ---------- Fahrzeug abgeben: Fahrzeug wählen');
  const CODES = [
    { code: 'WILLKOMMEN', prozent: 20, stufe: null, monate: null, grenze: 100, eingeloest: 3, laeuftAb: '2027-06-30', abgelaufen: false, aufgebraucht: false, notiz: 'Kanal XY' },
    { code: 'ABCD-EFGH', prozent: 100, stufe: 'voll', monate: 3, grenze: 1, eingeloest: 0, laeuftAb: '2027-06-30', abgelaufen: false, aufgebraucht: false, notiz: 'für Tanja' },
    { code: 'ALT10', prozent: 10, stufe: null, monate: null, grenze: 1, eingeloest: 0, laeuftAb: '2026-01-01', abgelaufen: true, aufgebraucht: false, notiz: '' }];
  const d = { listen: 0, gutscheinListe: async () => { d.listen++; return { ok: true, codes: CODES }; }, gutscheinAnlegen: async (a) => { d.angelegt = a; return { ok: true, code: 'NEU1-2345' }; }, gutscheinLoeschen: async (c) => { d.geloescht = c; return { ok: true }; } };
  function lauf(rolle, bestaetigt) {
    const h = hBauen(), f = feldBauen(h), seiten = [], fenster = { hash: '', confirm: () => bestaetigt !== false, location: {} };
    const baue = new Function('MM', 'h', 'daten', 'krumen', 'seite', 'nurEntwickler', 'auswahlFeld', 'kontoFeld', 'fehlerSeite', 'global', quelle + '\n  return seiteGutscheine;');
    const fn = baue(MM, h, d, () => h('nav'), (titel, inhalt) => { seiten.push({ titel, inhalt }); }, (titel, bauen) => Promise.resolve(bauen(rolle)), f.auswahlFeld, f.kontoFeld, (e) => { throw e; }, fenster);
    return { fn, seiten, fenster };
  }
  /* Entwickler */
  const e = lauf('entwickler'); await e.fn();
  assert.match(e.seiten[0].inhalt.map(text).join(' '), /nur Admins/); assert.equal(d.listen, 0, 'der Dienst wird nicht gefragt');
  /* Admin */
  const a = lauf('admin'); await a.fn();
  const alles = a.seiten[0].inhalt.map(text).join(' | ').replace(/\s+/g, ' ');
  assert.match(alles, /WILLKOMMEN – Rabatt 20 % für Neukunden/); assert.match(alles, /3 von 100 eingelöst, gültig bis 2027-06-30, Kanal XY/);
  assert.match(alles, /ABCD-EFGH – Geschenk: Voll für 3 Monate/); assert.match(alles, /abgelaufen am 2026-01-01/);
  /* Rabattcode anlegen (Standardwerte der Maske) */
  const wurzel = { kinder: a.seiten[0].inhalt, tag: 'x', attrs: {} };
  const eingaben = finde(wurzel, (x) => x.tag === 'input');
  const nach = (id) => eingaben.find((x) => x.attrs.id === id);
  nach('gs-proz').value = '12,5'; nach('gs-grz').value = '50'; nach('gs-code').value = 'youtube'; nach('gs-notiz').value = 'XY';
  await new Promise((r) => { d.gutscheinAnlegen = async (x) => { d.angelegt = x; r(); return { ok: true, code: 'YOUTUBE' }; }; klick(knopf(wurzel, 'Code anlegen')[0]); });
  assert.deepEqual(d.angelegt, { prozent: '12,5', grenze: '50', code: 'youtube', stufe: '', monate: '', laeuftAb: nach('gs-ablauf').value, notiz: 'XY', empfaenger: '' });
  assert.match(nach('gs-ablauf').value, /^\d{4}-\d{2}-\d{2}$/);
  /* Geschenkcode anlegen */
  const art = finde(wurzel, (x) => x.tag === 'select' && x.attrs.id === 'gs-art')[0];
  art.value = 'frei'; (art.handlers.change || []).forEach((fn) => fn());
  assert.equal(nach('gs-proz').value && finde(wurzel, (x) => x.attrs && x.attrs.class === 'feld' && x.kinder.includes(nach('gs-proz')))[0].style.display, 'none', 'Rabatt-Felder weg');
  finde(wurzel, (x) => x.tag === 'select' && x.attrs.id === 'gs-stufe')[0].value = 'voll'; finde(wurzel, (x) => x.tag === 'select' && x.attrs.id === 'gs-monate')[0].value = '6';
  await new Promise((r) => { d.gutscheinAnlegen = async (x) => { d.angelegt = x; r(); return { ok: true, code: 'ZZZZ-2345' }; }; klick(knopf(wurzel, 'Code anlegen')[0]); });
  assert.equal(d.angelegt.prozent, '100'); assert.equal(d.angelegt.grenze, '1'); assert.equal(d.angelegt.code, ''); assert.equal(d.angelegt.stufe, 'voll'); assert.equal(d.angelegt.monate, 6);
  /* Mit E-Mail des Empfängers: die Seite meldet, ob die Mail raus ging */
  nach('gs-empf').value = 'tanja@example.org';
  await new Promise((r) => { d.gutscheinAnlegen = async (x) => { d.angelegt = x; r(); return { ok: true, code: 'MAIL-0001', mail: true }; }; klick(knopf(wurzel, 'Code anlegen')[0]); });
  assert.equal(d.angelegt.empfaenger, 'tanja@example.org'); await tick();
  assert.match(a.seiten[a.seiten.length - 1].inhalt.map(text).join(' '), /Neuer Code: MAIL-0001\. Er steht auch in der Liste\. Mail gesendet\./);
  const w2 = { kinder: a.seiten[a.seiten.length - 1].inhalt, tag: 'x', attrs: {} };
  finde(w2, (x) => x.tag === 'input' && x.attrs.id === 'gs-empf')[0].value = 'tanja@example.org';
  await new Promise((r) => { d.gutscheinAnlegen = async (x) => { d.angelegt = x; r(); return { ok: true, code: 'MAIL-0002', mail: false }; }; klick(knopf(w2, 'Code anlegen')[0]); }); await tick();
  assert.match(a.seiten[a.seiten.length - 1].inhalt.map(text).join(' '), /Mail ging nicht raus\. Der Code ist trotzdem angelegt/);
  /* ungültige Adresse: Fehler steht am Feld */
  const w3 = { kinder: a.seiten[a.seiten.length - 1].inhalt, tag: 'x', attrs: {} };
  d.gutscheinAnlegen = async () => ({ ok: false, fehler: { empfaenger: 'Die E-Mail-Adresse des Empfängers ist ungültig.' } });
  klick(knopf(w3, 'Code anlegen')[0]); await tick();
  assert.match(text(w3), /Adresse des Empfängers ist ungültig/);
  /* Löschen mit Rückfrage; bei „Abbrechen“ passiert nichts */
  const n = lauf('admin', false); await n.fn(); d.geloescht = null;
  klick(knopf({ kinder: n.seiten[0].inhalt, tag: 'x', attrs: {} }, 'Löschen')[0]); await tick();
  assert.equal(d.geloescht, null);
  const y = lauf('admin', true); await y.fn();
  await new Promise((r) => { d.gutscheinLoeschen = async (c) => { d.geloescht = c; r(); return { ok: true }; }; klick(knopf({ kinder: y.seiten[0].inhalt, tag: 'x', attrs: {} }, 'Löschen')[0]); });
  assert.equal(d.geloescht, 'WILLKOMMEN');
});

test('Admin-Seite: Fehler des Dienstes (SQL-Zeilen fehlen) stehen in einfachen Worten da, nichts stürzt ab', async () => {
  const quelle = 'var meldungKonto = "";\n' + schnitt('  var meldungGutschein = \'\';', '  /* ---------- Fahrzeug abgeben: Fahrzeug wählen');
  const d = { gutscheinListe: async () => ({ ok: false, fehler: { allgemein: 'Gutscheincodes gehen noch nicht: Im Dienst fehlen die SQL-Zeilen aus 13f-8.sql.' } }) };
  const h = hBauen(), f = feldBauen(h), seiten = [];
  const baue = new Function('MM', 'h', 'daten', 'krumen', 'seite', 'nurEntwickler', 'auswahlFeld', 'kontoFeld', 'fehlerSeite', 'global', quelle + '\n  return seiteGutscheine;');
  await baue(MM, h, d, () => h('nav'), (tt, inhalt) => seiten.push(inhalt), (tt, bauen) => Promise.resolve(bauen('admin')), f.auswahlFeld, f.kontoFeld, (e) => { throw e; }, {})();
  assert.match(seiten[0].map(text).join(' '), /13f-8\.sql/); assert.match(seiten[0].map(text).join(' '), /Update auf 13f-8/);
});

test('Einbau: Kachel und Route, Texte, Changelog, Schritte, Dienst-Anleitung, Version 2.0.94', () => {
  const a = lesen('js/ansicht.js');
  assert.ok(a.includes("'#/gutscheine'")); assert.ok(a.includes("teile[0] === 'gutscheine') p = seiteGutscheine()"));
  assert.ok(a.includes('daten.gutscheinPruefen(') && a.includes('daten.gutscheinEinloesen(') && a.includes('daten.gutscheinAnlegen(') && a.includes('daten.gutscheinLoeschen('));
  assert.ok(!a.includes("kontoFeld('bz-code'"), 'kein gemeinsames Code-Feld über den Angeboten mehr');
  assert.ok(a.includes("kontoFeld('bz-code-' + a.id"));
  assert.equal(MM.VERSION, '2.0.131');
  assert.equal(MM.Texte.NEUERUNGEN[47].version, '2.0.84'); assert.match(MM.Texte.NEUERUNGEN[47].punkte.join(' '), /Gutscheincode/); assert.match(MM.Texte.NEUERUNGEN[47].punkte.join(' '), /13f-9/);
  assert.equal(MM.Texte.NEUERUNGEN[48].version, '2.0.83'); assert.match(MM.Texte.NEUERUNGEN[48].punkte.join(' '), /13f-8\.sql/);
  assert.ok(lesen('CHANGELOG.md').includes('## 2.0.84\n- **Bau: Fehler Gutscheincode und Mail beim Anlegen**'));
  assert.ok(lesen('CHANGELOG.md').includes('## 2.0.83\n- **Bau 2: Gutscheincodes beim Bezahlen**'));
  assert.ok(lesen('docs/SCHRITTE.md').includes('| 13f-8 |') && lesen('docs/SCHRITTE.md').includes('| 13f-9 |'));
  assert.ok(lesen('server/EINRICHTUNG.md').startsWith('# Konto-Dienst: Einrichtung und Updates (Stand 2.0.131, Schritt 13h)'));
});
