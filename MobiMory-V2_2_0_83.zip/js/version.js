/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.83';
  MM.STUFE = 'Gutscheincodes beim Bezahlen: Rabatt für Neukunden und Geschenkcodes, Planung und Fahrzeugseiten unverändert';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
