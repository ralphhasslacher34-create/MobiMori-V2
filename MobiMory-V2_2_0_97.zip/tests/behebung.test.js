'use strict';
/* 2.0.76 (Bau 2): Hilfe zur Behebung. Reine Regeln (MM.Behebung) und die Anzeige im Quelltext, dazu die Anzeige mit einem kleinen Ersatz für den Browser. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'dokumente', 'werkstatt', 'hilfen', 'behebung', 'freigaben'].forEach((n) => { try { require('../js/' + n + '.js'); } catch (e) { /* freigaben braucht weitere Module */ } });
['fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'freigaben'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const B = MM.Behebung;
const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

const ALT = [
  { id: 'a1', art: 'arbeit', status: 'erledigt', bezeichnung: 'Kühlschrank läuft nicht', beschreibung: '', arbeit: 'Sicherung getauscht', gemeldetAm: '2026-07-30', erledigtAm: '2026-08-01', erledigtNotiz: 'Hat 15 A gebraucht', komponenteId: 'kp-1' },
  { id: 'a2', art: 'stoerung', status: 'erledigt', bezeichnung: 'Kühlung zu schwach', beschreibung: 'bei Hitze', arbeit: '', gemeldetAm: '2026-06-01', erledigtAm: '2026-06-03', erledigtNotiz: 'Lüftungsgitter gereinigt', komponenteId: null },
  { id: 'a3', art: 'stoerung', status: 'offen', bezeichnung: 'Licht im Bad flackert', beschreibung: '', arbeit: '', gemeldetAm: '2026-10-01', komponenteId: null },
  { id: 'a4', art: 'stoerung', status: 'erledigt', bezeichnung: 'Motor springt schlecht an', beschreibung: '', arbeit: '', gemeldetAm: '2026-05-01', erledigtAm: '2026-05-02', erledigtNotiz: 'Batterie ersetzt', komponenteId: null }
];

test('Ähnliche Fälle: gemeinsames Wort genügt, Endungen stören nicht, Füllwörter zählen nicht, die Störung selbst wird übergangen', () => {
  const r = B.aehnliche({ id: 'neu', bezeichnung: 'Kühlschrank geht nicht', komponenteId: 'kp-1' }, ALT);
  assert.deepEqual(r.map((x) => x.id), ['a1', 'a2'], '„Kühlschrank“ und „Kühlung“ teilen „kühl“; „geht nicht“ zählt nicht');
  assert.deepEqual(r[0].damals, ['Sicherung getauscht', 'Hat 15 A gebraucht']);
  assert.equal(r[0].status, 'erledigt'); assert.equal(r[0].erledigtAm, '2026-08-01');
  assert.deepEqual(r[1].damals, ['Lüftungsgitter gereinigt']);
  assert.deepEqual(B.aehnliche({ id: 'a1', bezeichnung: 'Kühlschrank' }, ALT).map((x) => x.id), ['a2'], 'sich selbst nie');
  assert.deepEqual(B.aehnliche({ bezeichnung: 'Es geht nicht und ist kaputt' }, ALT), [], 'nur Füllwörter');
  assert.deepEqual(B.aehnliche({ bezeichnung: '' }, ALT), []);
  assert.deepEqual(B.aehnliche({ bezeichnung: 'Motor' }, ALT).map((x) => x.id), ['a4']);
});

test('Ähnliche Fälle: gleiche Komponente zählt zuerst, dann das neuere Datum; höchstens drei; offene Fälle haben nichts „Damals“', () => {
  const liste = [
    { id: 'x1', art: 'stoerung', status: 'erledigt', bezeichnung: 'Heizung bleibt kalt', erledigtAm: '2026-01-01', komponenteId: null },
    { id: 'x2', art: 'stoerung', status: 'erledigt', bezeichnung: 'Heizung bleibt kalt', erledigtAm: '2026-03-01', komponenteId: null },
    { id: 'x3', art: 'stoerung', status: 'erledigt', bezeichnung: 'Heizung bleibt kalt', erledigtAm: '2026-02-01', komponenteId: 'kp-9' },
    { id: 'x4', art: 'stoerung', status: 'offen', bezeichnung: 'Heizung bleibt kalt', gemeldetAm: '2026-04-01', komponenteId: null }
  ];
  const r = B.aehnliche({ bezeichnung: 'Heizung kalt', komponenteId: 'kp-9' }, liste);
  assert.deepEqual(r.map((x) => x.id), ['x3', 'x4', 'x2'], 'x3 gleiche Komponente, dann neuere zuerst');
  assert.deepEqual(r[1].damals, []); assert.equal(r[1].status, 'offen');
  assert.equal(B.aehnliche({ bezeichnung: 'Heizung' }, liste, 1).length, 1);
});

test('Dokumente: nur Anleitungen, passende zuerst, dann Bedienung vor Reparaturbuch vor Wartung vor Ersatzteilen', () => {
  const l = [
    { id: 'd1', bezeichnung: 'Kaufvertrag', art: 'beleg' }, { id: 'd2', bezeichnung: 'Ersatzteile Truma', art: 'ersatzteile' }, { id: 'd3', bezeichnung: 'Bedienung Wohnmobil', art: 'bedienung' },
    { id: 'd4', bezeichnung: 'Reparaturbuch', art: 'reparaturbuch' }, { id: 'd5', bezeichnung: 'Kühlschrank Dometic', art: 'wartung', notiz: 'Seite 12' }, { id: 'd6', bezeichnung: 'Foto', art: 'foto' }, { id: 'd7', bezeichnung: 'Heizung', art: 'wartung' }
  ];
  const r = B.dokumente(l, 'Kühlschrank geht nicht');
  assert.deepEqual(r.map((x) => x.id), ['d5', 'd3', 'd4', 'd7', 'd2']);
  assert.equal(r[0].passt, true); assert.equal(r[1].passt, false);
  assert.deepEqual(B.dokumente(l, '').map((x) => x.id), ['d3', 'd4', 'd7', 'd5', 'd2'], 'ohne Text nur nach Art, dann nach Namen');
  assert.deepEqual(B.dokumente([], 'x'), []);
});

test('Werkstätten: nur Werkstätten, nicht ausgeblendet, nach Namen; der Link zur Suche trägt nur, was der Nutzer eintippt', () => {
  const a = [{ id: '1', bezeichnung: 'Zeta', art: 'werkstatt', telefon: '07042 1', ort: 'Sersheim' }, { id: '2', bezeichnung: 'Alpha', art: 'werkstatt' }, { id: '3', bezeichnung: 'Teile24', art: 'lieferant' }, { id: '4', bezeichnung: 'Weg', art: 'werkstatt', ausgeblendet: 'ja' }];
  assert.deepEqual(B.werkstaetten(a).map((x) => x.name), ['Alpha', 'Zeta']);
  assert.equal(B.werkstattLink(''), 'https://www.openstreetmap.org/search?query=Autowerkstatt');
  assert.equal(B.werkstattLink('  Malmö  '), 'https://www.openstreetmap.org/search?query=Autowerkstatt%20Malm%C3%B6');
  assert.ok(B.werkstattLink('x'.repeat(500)).length < 200);
  assert.equal(B.werkstattLink('a&b=c').includes('&'), false, 'Sonderzeichen werden verpackt');
});

test('Notrufnummern: geprüfte Angaben für die Länder, Norwegen anders, übrige EU 112; die Clubs mit Auslandsnummer', () => {
  const nr = (w) => { const l = B.land(w); return [l.rettung, l.polizei, l.feuer].join('/'); };
  assert.equal(nr('de'), '112/110/112'); assert.equal(nr('at'), '144/133/122'); assert.equal(nr('ch'), '144/117/118');
  assert.equal(nr('dk'), '112/112/112'); assert.equal(nr('se'), '112/112/112'); assert.equal(nr('fi'), '112/112/112');
  assert.equal(nr('no'), '113/112/110'); assert.equal(nr('eu'), '112/112/112');
  assert.equal(B.land('xx').wert, 'de', 'unbekannt: Deutschland');
  assert.ok(B.land('at').pannen.some((p) => p.nummer === '120'));
  assert.equal(B.CLUBS[0].nummer, '+49 89 22 22 22'); assert.ok(B.CLUBS.every((c) => /^\+49 /.test(c.nummer)));
  assert.deepEqual(B.LAENDER.map((l) => l.wert), ['de', 'at', 'ch', 'dk', 'se', 'no', 'fi', 'eu']);
  assert.equal(B.STAND, '2026-11-14'.split('-').reverse().join('.'));
});

test('hilfe: fasst die drei Listen zusammen', () => {
  const h = B.hilfe({ bezeichnung: 'Kühlschrank geht nicht', vorgaenge: ALT, dokumente: [{ id: 'd', bezeichnung: 'Kühlschrank', art: 'bedienung' }], adressen: [{ id: 'w', bezeichnung: 'Werkstatt Müller', art: 'werkstatt' }] });
  assert.equal(h.aehnliche.length, 2); assert.equal(h.dokumente.length, 1); assert.equal(h.werkstaetten.length, 1);
  assert.deepEqual(B.hilfe({}), { aehnliche: [], dokumente: [], werkstaetten: [] });
});

test('Gast-Sicht: frühere Vorgänge ohne Beträge und ohne Notiz; ohne die Tabelle bleibt die Liste leer', () => {
  const satz = (tabelle, o) => ({ tabelle, id: o.id, nutzlast: JSON.stringify(o) });
  const d = [satz('fahrzeuge', { id: 'fz-1', art: 'wohnmobil' }), satz('vorgaenge', { id: 'vg-1', komponenteId: 'kp-1' }),
    satz('verlaeufe', { id: 've-1', objektTyp: 'vorgang', objektId: 'vg-1', nr: 1, werte: { bezeichnung: 'Licht', art: 'arbeit', status: 'erledigt', arbeit: 'Birne', gemeldetAm: '2026-07-30', erledigtAm: '2026-08-01' } }),
    satz('verlaeufe', { id: 've-2', objektTyp: 'vorgang', objektId: 'vg-1', nr: 2, werte: { bezeichnung: 'Licht', art: 'arbeit', status: 'erledigt', arbeit: 'Birne und Fassung', gemeldetAm: '2026-07-30', erledigtAm: '2026-08-02' } })];
  const s = MM.Freigaben.sicht(d, '2026-11-14');
  assert.equal(s.vorgaenge.length, 1);
  assert.deepEqual(Object.keys(s.vorgaenge[0]).sort(), ['arbeit', 'art', 'beschreibung', 'bezeichnung', 'erledigtAm', 'erledigtNotiz', 'gemeldetAm', 'id', 'komponenteId', 'status']);
  assert.equal(s.vorgaenge[0].arbeit, 'Birne und Fassung', 'der neueste Stand');
  assert.equal(s.vorgaenge[0].erledigtNotiz, '');
  assert.deepEqual(MM.Freigaben.sicht([satz('fahrzeuge', { id: 'fz-1' })], '2026-11-14').vorgaenge, []);
});

/* ---- Anzeige: ein kleiner Ersatz für den Browser, nur so viel wie behebungBlock braucht ---- */
function neuesElement(tag) {
  const e = { tag, kinder: [], attrs: {}, ereignisse: {}, textContent: '' };
  e.appendChild = (k) => { e.kinder.push(k); return k; };
  e.setAttribute = (k, v) => { e.attrs[k] = v; };
  e.addEventListener = (n, f) => { e.ereignisse[n] = f; };
  Object.defineProperty(e, 'textContent', { get() { return e._t !== undefined ? e._t : e.kinder.map((k) => (typeof k === 'string' ? k : k.textContent)).join(''); }, set(v) { e._t = undefined; e.kinder = v ? [String(v)] : []; } });
  return e;
}
function anzeigeLaden() {
  const quelle = lesen('js/ansicht.js');
  const start = quelle.indexOf('  function behebungBlock(o) {');
  const ende = quelle.indexOf('\n  }\n', start);
  assert.ok(start > 0 && ende > start);
  const doc = { createTextNode: (t) => String(t), createElement: neuesElement };
  function h(tag, attrs) {
    const e = neuesElement(tag);
    if (attrs) Object.keys(attrs).forEach((k) => { if (k === 'text') e.kinder.push(String(attrs[k])); else if (attrs[k] !== null && attrs[k] !== undefined) e.attrs[k] = attrs[k]; });
    for (let i = 2; i < arguments.length; i++) { const k = arguments[i]; (Array.isArray(k) ? k : [k]).forEach((x) => { if (x !== null && x !== undefined) e.kinder.push(x); }); }
    return e;
  }
  function kontoFeld(id) { const eingabe = neuesElement('input'); eingabe.value = ''; return { eingabe, tel: neuesElement('p'), feld: h('div', null, eingabe) }; }
  function auswahlFeld(id, b, opt, wert) { const eingabe = neuesElement('select'); eingabe.value = wert; return { eingabe, tel: neuesElement('p'), feld: h('div', null, eingabe) }; }
  // eslint-disable-next-line no-new-func
  const f = new Function('MM', 'h', 'doc', 'kontoFeld', 'auswahlFeld', quelle.slice(start, ende) + '\n  }\n  return behebungBlock;');
  return f(MM, h, doc, kontoFeld, auswahlFeld);
}
const text = (e) => (typeof e === 'string' ? e : e.kinder.map(text).join(''));
const finde = (e, fn, aus) => { aus = aus || []; if (typeof e === 'string') return aus; if (fn(e)) aus.push(e); e.kinder.forEach((k) => finde(k, fn, aus)); return aus; };

test('Anzeige beim Besitzer: ähnliche Fälle mit „Damals eingetragen“, Anleitungen mit Link, eigene Werkstatt mit Telefon, Notruf Deutschland', () => {
  const block = anzeigeLaden()({ kennung: 'x', id: 'neu', bezeichnung: 'Kühlschrank geht nicht', vorgaenge: ALT, dokumente: [{ id: 'd5', bezeichnung: 'Kühlschrank Dometic', art: 'wartung' }],
    adressen: [{ id: 'w', bezeichnung: 'Werkstatt Müller', art: 'werkstatt', telefon: '07042 12345', ort: 'Sersheim' }],
    vorgangLink: (a) => '#/vorgang/' + a.id, dokumentElement: (d) => ({ tag: 'a', kinder: [d.bezeichnung], attrs: { href: '#/dokument/' + d.id } }) });
  const t = text(block.element);
  assert.match(t, /MobiMory rät keine Ursachen/);
  assert.match(t, /Kühlschrank läuft nicht/); assert.match(t, /Damals eingetragen: Sicherung getauscht\. Hat 15 A gebraucht/); assert.match(t, /erledigt am 01\.08\.2026/);
  assert.match(t, /Kühlschrank Dometic/); assert.match(t, /passt zu deiner Beschreibung/);
  assert.match(t, /Werkstatt Müller in Sersheim: 07042 12345/);
  assert.ok(finde(block.element, (e) => e.tag === 'a' && e.attrs.href === 'tel:0704212345').length === 1, 'Telefon zum Antippen');
  assert.ok(finde(block.element, (e) => e.tag === 'a' && e.attrs.href === '#/vorgang/a1').length === 1);
  assert.match(t, /Rettungsdienst: 112/); assert.match(t, /Polizei: 110/); assert.match(t, /ADAC Auslandsnotruf/); assert.match(t, /\+49 89 22 22 22/);
  assert.match(t, /Stand 14\.11\.2026, ohne Gewähr/);
  const such = finde(block.element, (e) => e.tag === 'a' && /openstreetmap/.test(e.attrs.href || ''))[0];
  assert.equal(such.attrs.target, '_blank'); assert.match(such.attrs.rel, /noopener/);
});

test('Anzeige beim Gast: aktualisiert sich beim Tippen; ohne Treffer ein ruhiger Satz; Werkstätten des Besitzers werden nicht gezeigt', () => {
  const block = anzeigeLaden()({ kennung: 'g', vorgaenge: ALT, dokumente: [], adressen: [], ohneAdressen: true });
  assert.match(text(block.element), /Sobald du oben beschreibst/);
  assert.match(text(block.element), /Keine Bedienungs- oder Wartungsanleitung/);
  assert.match(text(block.element), /Die Werkstätten des Besitzers siehst du hier nicht/);
  block.aktualisieren('Motor springt schlecht an', '');
  assert.match(text(block.element), /Motor springt schlecht an/); assert.match(text(block.element), /Damals eingetragen: Batterie ersetzt/);
  block.aktualisieren('Wasserpumpe brummt', '');
  assert.match(text(block.element), /Dazu ist nichts Ähnliches eingetragen/);
});

test('Anzeige: Land wechseln ändert die Notrufnummern (Norwegen); der Ort ändert den Suchlink', () => {
  const block = anzeigeLaden()({ kennung: 'n', vorgaenge: [], dokumente: [], adressen: [] });
  const sel = finde(block.element, (e) => e.tag === 'select')[0];
  sel.value = 'no'; sel.ereignisse.change();
  assert.match(text(block.element), /Rettungsdienst: 113/); assert.match(text(block.element), /Feuerwehr: 110/);
  const ort = finde(block.element, (e) => e.tag === 'input')[0];
  ort.value = 'Bergen'; ort.ereignisse.input();
  assert.match(finde(block.element, (e) => e.tag === 'a' && /openstreetmap/.test(e.attrs.href || ''))[0].attrs.href, /Autowerkstatt%20Bergen/);
});

test('Einbau: Besitzer-Seite einer offenen Störung, Gast unter „Störung melden“, Modul in index.html und Service Worker, Version 2.0.94', () => {
  const a = lesen('js/ansicht.js');
  ['hilfeNoetig', "kennung: 'vg-bh'", "kennung: 'gm-bh'", 'hilfeNachziehen', "'Hilfe zur Behebung'", 'Der Besitzer bekommt eine Info-Mail'].forEach((s) => assert.ok(a.includes(s), s));
  assert.ok(lesen('index.html').indexOf('js/behebung.js') > lesen('index.html').indexOf('js/werkstatt.js'));
  assert.ok(lesen('sw.js').includes("'js/behebung.js'"));
  assert.equal(MM.VERSION, '2.0.97');
  assert.match(lesen('js/texte.js'), /version: '2\.0\.79'/);
  assert.match(lesen('CHANGELOG.md'), /^# Änderungen\n\n## 2\.0\.97/);
});
