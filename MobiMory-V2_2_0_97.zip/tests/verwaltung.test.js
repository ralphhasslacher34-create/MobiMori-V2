'use strict';
/* 2.0.94 (Dienst 13f-11): Verwaltung. Statistik der Konten nach Stufe (Admin und Entwickler), Zahlungseingänge buchen und freischalten mit der Rolle Admin
   (kein zweites Passwort). Dienst mit nachgebauter Datenbank, Mail ist ein Platzhalter. Dazu die Seite in der App (echte Funktion aus ansicht.js mit kleinem Browser-Ersatz). */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');
const APP = 'https://app.example.org';
const DIENST = 'https://konto.example.workers.dev';
const TAG = 24 * 60 * 60 * 1000;
const ADMIN = 'admin-passwort-' + 'x'.repeat(20);
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) {
  return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1',
    RECHERCHE_URL: 'https://recherche.example.org', RECHERCHE_TOKEN: 'geheim-token-1',
    PAYPAL_CLIENT_ID: 'client-id-123', PAYPAL_SECRET: 'secret-456',
    UEBERWEISUNG_INHABER: 'Ralph Hasslacher', UEBERWEISUNG_IBAN: 'DE02 1203 0000 0000 2020 51', FREISCHALT_TOKEN: ADMIN,
    BELEG_ANSCHRIFT: 'Ralph Hasslacher\nMusterstraße 1\n74372 Sersheim' }, extra || {});
}
function uhr() { const u = { t: Date.UTC(2026, 10, 12, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
/* Mail-Platzhalter: wird erst nach dem Anmelden eingehängt (im Test-Dienst kommt der Anmelde-Code sonst nicht in der Antwort). */
function mail(env) { const post = { gesendet: [], fehler: false }; env.ABSENDER = 'konto@example.org'; env.EMAIL = { send: async (m) => { if (post.fehler) throw new Error('kaputt'); post.gesendet.push(m); } }; return post; }

/* PayPal-Platzhalter. modus: ok, betrag (falscher Betrag), offen (Zahlung nicht fertig), schon (zweiter Abschluss), nichts (kein Link in der Antwort). */
function paypal() {
  const p = { aufrufe: [], modus: 'ok', n: 0, bestellt: null };
  p.fetch = async (url, o) => {
    p.aufrufe.push({ url, methode: o.method, kopf: o.headers, body: o.body });
    if (/\/v1\/oauth2\/token$/.test(url)) return new Response(JSON.stringify({ access_token: 'zugang' }), { status: 200 });
    if (/\/v2\/checkout\/orders$/.test(url) && o.method === 'POST') {
      p.bestellt = JSON.parse(o.body); p.n += 1; p.orderId = 'ORDER' + p.n;
      if (p.modus === 'nichts') return new Response(JSON.stringify({ id: p.orderId, links: [] }), { status: 200 });
      return new Response(JSON.stringify({ id: p.orderId, status: 'PAYER_ACTION_REQUIRED', links: [{ rel: 'self', href: 'https://api-m.sandbox.paypal.com/v2/checkout/orders/' + p.orderId }, { rel: 'payer-action', href: 'https://www.sandbox.paypal.com/checkoutnow?token=' + p.orderId }] }), { status: 200 });
    }
    const betrag = p.modus === 'betrag' ? '1.00' : p.bestellt.purchase_units[0].amount.value;
    const fertig = { id: p.orderId, status: 'COMPLETED', purchase_units: [{ payments: { captures: [{ id: 'CAP' + p.n, status: p.modus === 'offen' ? 'PENDING' : 'COMPLETED', amount: { currency_code: 'EUR', value: betrag } }] } }] };
    if (/\/capture$/.test(url)) {
      p.abschluesse = (p.abschluesse || 0) + 1;
      if (p.modus === 'schon' && p.abschluesse > 1) return new Response(JSON.stringify({ name: 'UNPROCESSABLE_ENTITY', details: [{ issue: 'ORDER_ALREADY_CAPTURED' }] }), { status: 422 });
      return new Response(JSON.stringify(fertig), { status: 201 });
    }
    return new Response(JSON.stringify(fertig), { status: 200 });
  };
  return p;
}
function recherche() {
  const r = { aufrufe: [], modus: 'ok' };
  r.fetch = async (url, opt) => {
    r.aufrufe.push({ url });
    if (r.modus === 'fehler') return new Response(JSON.stringify({ error: 'KI nicht erreichbar' }), { status: 500 });
    return new Response(JSON.stringify({ ok: true, requirements: [{ id: 'a' }], model: 'm' }), { status: 200 });
  };
  return r;
}

async function roh(env, u, methode, weg, body, token, optionen, kopfExtra) {
  const d = await laden();
  const kopf = Object.assign({ Origin: APP, 'CF-Connecting-IP': '203.0.113.5' }, kopfExtra || {});
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  return d.behandeln(new Request(DIENST + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }),
    env, Object.assign({ jetzt: u.jetzt }, optionen || {}));
}
async function ruf(env, u, methode, weg, body, token, optionen, kopfExtra) { const r = await roh(env, u, methode, weg, body, token, optionen, kopfExtra); return { status: r.status, json: await r.json() }; }
async function anmelden(env, u, email, geraet) {
  u.t += 13 * 60 * 1000;
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email });
  return ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode, geraet });
}
async function konto(env, u, email) { const r = await anmelden(env, u, email, 'Test #' + '0123456789abcdef'.slice(0, 8)); assert.equal(r.status, 200, JSON.stringify(r.json)); return r.json.token; }
function nutzerId(env, email) { return env.DB.roh.prepare('SELECT id FROM nutzer WHERE email = ?').get(email).id; }
function stufeSetzen(env, email, stufe, bis) {
  env.DB.roh.prepare('INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) VALUES (?, ?, ?, ?)').run(nutzerId(env, email), stufe, bis === undefined ? null : bis, 1);
}
function stufeLesen(env, email) { return env.DB.roh.prepare('SELECT stufe, gueltig_bis FROM stufe_konto WHERE nutzer_id = ?').get(nutzerId(env, email)); }

function plusJahr(ms) { const d = new Date(ms); d.setUTCFullYear(d.getUTCFullYear() + 1); return d.getTime(); }
function rolleSetzen(env, email, funktion) { env.DB.roh.prepare('INSERT OR REPLACE INTO rolle (email, name, funktion) VALUES (?, ?, ?)').run(email, 'Test', funktion); }
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

test('Dienst 13f-11: Version, keine neue SQL-Zeile, Gesundheit, Anleitung', async () => {
  const d = await laden();
  assert.equal(d.VERSION, '13f-11');
  const ein = lesen('server/EINRICHTUNG.md');
  assert.ok(ein.includes('## Update auf 13f-11 (Verwaltung in der App, seit 2.0.94)'));
  assert.ok(ein.includes('Keine neue SQL-Zeile'));
  assert.ok(!fs.existsSync(path.join(__dirname, '..', 'server', '13f-11.sql')));
});

test('Statistik: Konten nach Stufe von heute (Test, Mittel, Voll, Entwickler, Basic), abgelaufene getrennt, Nicht-Bestätigte zählen nicht', async () => {
  const env = umgebung(), u = uhr();
  const chef = await konto(env, u, 'chef@example.org'); rolleSetzen(env, 'chef@example.org', 'admin'); stufeSetzen(env, 'chef@example.org', 'entwickler', null);
  await konto(env, u, 'test@example.org');
  await konto(env, u, 'mittel@example.org'); stufeSetzen(env, 'mittel@example.org', 'mittel', u.t + 300 * TAG);
  await konto(env, u, 'voll@example.org'); stufeSetzen(env, 'voll@example.org', 'voll', u.t + 300 * TAG);
  await konto(env, u, 'alt@example.org'); stufeSetzen(env, 'alt@example.org', 'mittel', u.t - 1000);
  /* ein Konto, das nie bestätigt wurde */
  u.t += 13 * 60 * 1000;
  await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'offen@example.org' });
  const s1 = await ruf(env, u, 'GET', '/verwaltung/statistik', undefined, chef);
  assert.equal(s1.status, 200, JSON.stringify(s1.json));
  /* Testwochen laufen noch: Das abgelaufene Mittel-Konto zählt als Test (wie die Stufe im Dienst), nicht als Mittel */
  assert.deepEqual({ konten: s1.json.konten, test: s1.json.test, mittel: s1.json.mittel, voll: s1.json.voll, entwickler: s1.json.entwickler, basic: s1.json.basic, abgelaufen: s1.json.abgelaufen },
    { konten: 5, test: 2, mittel: 1, voll: 1, entwickler: 1, basic: 0, abgelaufen: 1 });
  assert.match(s1.json.stand, /^\d{2}\.\d{2}\.\d{4}$/);
  assert.ok(!JSON.stringify(s1.json).includes('@'), 'keine Adressen in der Antwort');
  /* Nach der Testwoche (7 Tage) sind sie Basic; bezahlte bleiben */
  u.t += 8 * TAG;
  const chef2 = (await anmelden(env, u, 'chef@example.org', 'Test #abcdef01')).json.token;
  const s2 = await ruf(env, u, 'GET', '/verwaltung/statistik', undefined, chef2);
  assert.equal(s2.status, 200, JSON.stringify(s2.json));
  assert.deepEqual({ konten: s2.json.konten, test: s2.json.test, mittel: s2.json.mittel, voll: s2.json.voll, entwickler: s2.json.entwickler, basic: s2.json.basic, abgelaufen: s2.json.abgelaufen },
    { konten: 5, test: 0, mittel: 1, voll: 1, entwickler: 1, basic: 2, abgelaufen: 1 });
  /* Summe stimmt immer */
  assert.equal(s2.json.test + s2.json.mittel + s2.json.voll + s2.json.entwickler + s2.json.basic, s2.json.konten);
});

test('Rechte: Statistik sehen Admin und Entwickler, alle anderen nicht; Zahlungseingänge nur Admins; ohne Anmeldung 401', async () => {
  const env = umgebung(), u = uhr();
  const admin = await konto(env, u, 'chef@example.org'); rolleSetzen(env, 'chef@example.org', 'admin');
  const ent = await konto(env, u, 'dev@example.org'); rolleSetzen(env, 'dev@example.org', 'entwickler');
  const kunde = await konto(env, u, 'kunde@example.org'); mail(env);
  assert.equal((await ruf(env, u, 'GET', '/verwaltung/statistik')).status, 401);
  assert.equal((await ruf(env, u, 'GET', '/verwaltung/statistik', undefined, kunde)).status, 403);
  assert.equal((await ruf(env, u, 'GET', '/verwaltung/statistik', undefined, ent)).status, 200);
  assert.equal((await ruf(env, u, 'GET', '/verwaltung/statistik', undefined, admin)).status, 200);
  for (const [m, w, b] of [['GET', '/verwaltung/bestellungen'], ['POST', '/verwaltung/bestaetigen', { referenz: 'MM-ABCDEFGH' }], ['POST', '/verwaltung/direkt', { email: 'kunde@example.org', produkt: 'mittel' }], ['POST', '/verwaltung/loeschen', { referenz: 'MM-ABCDEFGH' }]]) {
    assert.equal((await ruf(env, u, m, w, b, undefined)).status, 401, w + ' ohne Anmeldung');
    assert.equal((await ruf(env, u, m, w, b, kunde)).status, 403, w + ' Kunde');
    assert.equal((await ruf(env, u, m, w, b, ent)).status, 403, w + ' Entwickler');
  }
  assert.equal((await ruf(env, u, 'GET', '/verwaltung/bestellungen', undefined, admin)).status, 200);
  /* Das Passwort der Freischalt-Seite öffnet die Verwaltung nicht */
  assert.equal((await ruf(env, u, 'GET', '/verwaltung/bestellungen', undefined, ADMIN)).status, 401);
});

test('Zahlungseingang: Überweisung bestellt, Admin sieht sie, schaltet frei (Stufe, Beleg, Mail), zweites Mal geht nicht; Löschen schaltet nichts frei', async () => {
  const env = umgebung(), u = uhr();
  const admin = await konto(env, u, 'chef@example.org'); rolleSetzen(env, 'chef@example.org', 'admin');
  const tok = await konto(env, u, 'kunde@example.org');
  const post = mail(env);
  const s = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'voll', weg: 'ueberweisung' }, tok);
  assert.equal(s.status, 200, JSON.stringify(s.json));
  const l = await ruf(env, u, 'GET', '/verwaltung/bestellungen', undefined, admin);
  assert.equal(l.status, 200); assert.equal(l.json.bestellungen.length, 1);
  assert.deepEqual(l.json.bestellungen[0], { id: s.json.referenz, email: 'kunde@example.org', angebot: 'Voll (ein Jahr)', betrag: '119,88 €', datum: '12.11.2026' });
  const f = await ruf(env, u, 'POST', '/verwaltung/bestaetigen', { referenz: s.json.referenz }, admin);
  assert.equal(f.status, 200, JSON.stringify(f.json)); assert.equal(f.json.nummer, 'MM-2026-0001');
  const st = env.DB.roh.prepare('SELECT stufe, gueltig_bis FROM stufe_konto WHERE nutzer_id = ?').get(nutzerId(env, 'kunde@example.org'));
  assert.equal(st.stufe, 'voll'); assert.equal(st.gueltig_bis, plusJahr(u.t));
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM beleg').get().n, 1);
  assert.equal(post.gesendet[post.gesendet.length - 1].to, 'kunde@example.org'); assert.ok(post.gesendet[post.gesendet.length - 1].text.includes('Überweisung'));
  assert.equal((await ruf(env, u, 'POST', '/verwaltung/bestaetigen', { referenz: s.json.referenz }, admin)).status, 404);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM beleg').get().n, 1);
  assert.equal((await ruf(env, u, 'GET', '/verwaltung/bestellungen', undefined, admin)).json.bestellungen.length, 0);
  /* Statistik zählt den Kunden jetzt bei Voll */
  assert.equal((await ruf(env, u, 'GET', '/verwaltung/statistik', undefined, admin)).json.voll, 1);
  /* Löschen */
  const s2 = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'recherche5', weg: 'ueberweisung' }, tok);
  assert.equal(s2.status, 200, JSON.stringify(s2.json));
  assert.equal((await ruf(env, u, 'POST', '/verwaltung/loeschen', { referenz: 'zu-kurz' }, admin)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/verwaltung/loeschen', { referenz: s2.json.referenz }, admin)).status, 200);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM bestellung').get().n, 0);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM beleg').get().n, 1, 'Löschen schaltet nichts frei');
});

test('Direkt freischalten: ohne Konto 404, mit Konto Beleg und zweite Nummer, ungültiges Angebot abgelehnt; die Freischalt-Seite mit Passwort geht unverändert weiter', async () => {
  const env = umgebung(), u = uhr();
  const admin = await konto(env, u, 'chef@example.org'); rolleSetzen(env, 'chef@example.org', 'admin');
  await konto(env, u, 'kunde@example.org'); mail(env);
  assert.equal((await ruf(env, u, 'POST', '/verwaltung/direkt', { email: 'niemand@example.org', produkt: 'mittel' }, admin)).status, 404);
  assert.equal((await ruf(env, u, 'POST', '/verwaltung/direkt', { email: 'kunde@example.org', produkt: 'gibtsnicht' }, admin)).status, 400);
  const d1 = await ruf(env, u, 'POST', '/verwaltung/direkt', { email: 'Kunde@Example.org', produkt: 'mittel' }, admin);
  assert.equal(d1.status, 200, JSON.stringify(d1.json)); assert.equal(d1.json.nummer, 'MM-2026-0001');
  const d2 = await ruf(env, u, 'POST', '/freischalten/direkt', { email: 'kunde@example.org', produkt: 'mittel' }, ADMIN);
  assert.equal(d2.status, 200, JSON.stringify(d2.json)); assert.equal(d2.json.nummer, 'MM-2026-0002');
  assert.equal((await ruf(env, u, 'POST', '/freischalten/liste', {}, ADMIN)).status, 200);
});

/* ---------- App: Daten und Seite ---------- */
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'konto', 'texte', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
async function neuDaten() {
  let n = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 15, 12, 0, n++)).toISOString() });
  await d.starten();
  return d;
}
const tick = async () => { for (let i = 0; i < 12; i++) await new Promise((r) => setImmediate(r)); };

test('App-Anfragen: Statistik, offene Überweisungen, Freischalten, Direkt, Löschen gehen an die richtigen Adressen; Fehler in einfachen Worten, Anmeldung abgelaufen', async () => {
  const d = await neuDaten(), auf = [];
  d.kontoAnfrageFn = async (url, methode, token, body) => { auf.push({ url: url.replace(/^.*\.com/, ''), methode, body }); return { ok: true, stand: '15.11.2026', konten: 7, test: 2, mittel: 3, voll: 1, entwickler: 1, basic: 0, abgelaufen: 0, bestellungen: [{ id: 'MM-AAAAAAAA' }], nummer: 'MM-2026-0001', bis: 1 }; };
  const st = await d.verwaltungStatistik();
  assert.deepEqual(st, { ok: true, stand: '15.11.2026', konten: 7, test: 2, mittel: 3, voll: 1, entwickler: 1, basic: 0, abgelaufen: 0 });
  assert.equal(auf[0].url, '/verwaltung/statistik'); assert.equal(auf[0].methode, 'GET');
  const b = await d.verwaltungBestellungen(); assert.equal(b.bestellungen.length, 1); assert.equal(auf[1].url, '/verwaltung/bestellungen');
  const f = await d.verwaltungBestaetigen('MM-AAAAAAAA'); assert.equal(f.ok, true); assert.equal(f.nummer, 'MM-2026-0001');
  assert.equal(auf[2].url, '/verwaltung/bestaetigen'); assert.equal(auf[2].methode, 'POST'); assert.deepEqual(auf[2].body, { referenz: 'MM-AAAAAAAA' });
  await d.verwaltungDirekt('a@b.de', 'voll'); assert.equal(auf[3].url, '/verwaltung/direkt'); assert.deepEqual(auf[3].body, { email: 'a@b.de', produkt: 'voll' });
  await d.verwaltungLoeschen('MM-AAAAAAAA'); assert.equal(auf[4].url, '/verwaltung/loeschen'); assert.deepEqual(auf[4].body, { referenz: 'MM-AAAAAAAA' });
  /* fehlende Zahlen werden zu 0 */
  d.kontoAnfrageFn = async () => ({ ok: true });
  assert.deepEqual(await d.verwaltungStatistik(), { ok: true, stand: '', konten: 0, test: 0, mittel: 0, voll: 0, entwickler: 0, basic: 0, abgelaufen: 0 });
  d.kontoAnfrageFn = async () => { const e = new Error('Zahlungseingänge buchen und freischalten dürfen nur Administratoren.'); e.status = 403; throw e; };
  const x = await d.verwaltungStatistik(); assert.equal(x.ok, false); assert.match(x.fehler.allgemein, /nur Administratoren/); assert.ok(!x.abgelaufen);
  assert.equal((await d.verwaltungBestaetigen('MM-AAAAAAAA')).ok, false);
  d.kontoAnfrageFn = async () => { const e = new Error('weg'); e.status = 401; throw e; };
  assert.equal((await d.verwaltungStatistik()).abgelaufen, true); assert.equal((await d.verwaltungBestaetigen('MM-AAAAAAAA')).abgelaufen, true);
});

function neuesElement(tag) {
  const e = { tag, kinder: [], attrs: {}, handlers: {}, style: {}, value: '', disabled: false };
  e.appendChild = (k) => { e.kinder.push(k); return k; };
  e.addEventListener = (n, f) => { (e.handlers[n] = e.handlers[n] || []).push(f); };
  Object.defineProperty(e, 'textContent', { get() { return text(e); }, set(v) { e.kinder = v === '' || v === null ? [] : [String(v)]; } });
  return e;
}
function hBauen() {
  return function h(tag, attrs) {
    const e = neuesElement(tag);
    if (attrs) Object.keys(attrs).forEach((k) => { const v = attrs[k]; if (v === null || v === undefined || v === false) return; if (k === 'text') e.kinder.push(String(v)); else { e.attrs[k] = v; if (k === 'value') e.value = v; } });
    const rein = (k) => { if (k === null || k === undefined) return; if (Array.isArray(k)) k.forEach(rein); else e.kinder.push(k); };
    for (let i = 2; i < arguments.length; i++) rein(arguments[i]);
    return e;
  };
}
function text(e) { return typeof e === 'string' ? e : (e && e.kinder ? e.kinder.map(text).join(' ') : ''); }
function finde(e, fn, aus) { aus = aus || []; if (!e || typeof e === 'string' || !e.kinder) return aus; if (fn(e)) aus.push(e); e.kinder.forEach((k) => finde(k, fn, aus)); return aus; }
const knopf = (wurzel, beschriftung) => finde(wurzel, (e) => e.tag === 'button' && text(e) === beschriftung);
const klick = (e) => (e.handlers.click || []).forEach((f) => f());
function feldBauen(h) {
  return {
    kontoFeld: (id, beschriftung, typ, wert) => { const eingabe = h('input', { type: typ, id, value: wert || '' }), tel = h('p', { class: 'fehler' }); return { eingabe, tel, feld: h('div', { class: 'feld' }, eingabe, tel) }; },
    auswahlFeld: (id, beschriftung, optionen, wert) => { const eingabe = h('select', { id, value: String(wert) }), tel = h('p', { class: 'fehler' }); return { eingabe, tel, feld: h('div', { class: 'feld' }, eingabe, tel) }; }
  };
}
function schnitt(von, bis) {
  const q = lesen('js/ansicht.js'), a = q.indexOf(von), b = q.indexOf(bis, a);
  assert.ok(a > 0 && b > a, von);
  return q.slice(a, b);
}
const STAT = { ok: true, stand: '15.11.2026', konten: 7, test: 2, mittel: 3, voll: 1, entwickler: 1, basic: 0, abgelaufen: 1 };
const BEST = [{ id: 'MM-AAAAAAAA', email: 'kunde@example.org', angebot: 'Voll (ein Jahr)', betrag: '119,88 €', datum: '12.11.2026' }];

function lauf(d, rolle, bestaetigt) {
  const quelle = 'var meldungKonto = "";\n' + schnitt("  var meldungVerwaltung = '';", '  /* ---------- Fahrzeug abgeben: Fahrzeug wählen');
  const h = hBauen(), f = feldBauen(h), seiten = [], fenster = { hash: '', confirm: () => bestaetigt !== false, location: {} };
  const baue = new Function('MM', 'h', 'daten', 'krumen', 'seite', 'nurEntwickler', 'auswahlFeld', 'kontoFeld', 'fehlerSeite', 'global', quelle + '\n  return seiteVerwaltung;');
  const fn = baue(MM, h, d, () => h('nav'), (titel, inhalt) => { seiten.push({ titel, inhalt }); }, (titel, bauen) => Promise.resolve(bauen(rolle)), f.auswahlFeld, f.kontoFeld, (e) => { throw e; }, fenster);
  return { fn, seiten, fenster };
}
const alle = (s) => s.inhalt.map(text).join(' | ').replace(/\s+/g, ' ');

test('Seite Verwaltung, Admin: Statistik mit Test, Mittel, Voll, offene Überweisungen mit Rückfrage beim Freischalten und Löschen, Direkt freischalten', async () => {
  const d = { fragen: 0, verwaltungStatistik: async () => STAT, verwaltungBestellungen: async () => { d.fragen++; return { ok: true, bestellungen: BEST }; },
    verwaltungBestaetigen: async (r) => { d.frei = r; return { ok: true, nummer: 'MM-2026-0001' }; }, verwaltungLoeschen: async (r) => { d.weg = r; return { ok: true }; },
    verwaltungDirekt: async (m, p) => { d.direkt = [m, p]; return { ok: true, nummer: 'MM-2026-0002' }; } };
  const a = lauf(d, 'admin'); await a.fn();
  const t1 = alle(a.seiten[0]);
  assert.match(t1, /Konten insgesamt: 7/); assert.match(t1, /Test \(Testwoche läuft\): 2/); assert.match(t1, /Mittel: 3/); assert.match(t1, /Voll: 1/); assert.match(t1, /Entwickler: 1/); assert.match(t1, /Ohne Stufe \(Basic\): 0/);
  assert.match(t1, /Stand 15\.11\.2026/); assert.match(t1, /aktuell 1 abgelaufen/);
  assert.match(t1, /MM-AAAAAAAA – kunde@example\.org/); assert.match(t1, /Voll \(ein Jahr\), 119,88 €, bestellt am 12\.11\.2026/);
  /* Freischalten: bei „Abbrechen“ passiert nichts */
  const n = lauf(d, 'admin', false); await n.fn();
  klick(knopf({ kinder: n.seiten[0].inhalt, tag: 'x', attrs: {} }, 'Geld ist da: freischalten')[0]); await tick();
  assert.equal(d.frei, undefined);
  /* Freischalten mit „Ja“: Meldung mit Beleg, Seite lädt neu */
  const y = lauf(d, 'admin', true); await y.fn(); const vorher = d.fragen;
  const w = { kinder: y.seiten[0].inhalt, tag: 'x', attrs: {} };
  await new Promise((r) => { d.verwaltungBestaetigen = async (ref) => { d.frei = ref; r(); return { ok: true, nummer: 'MM-2026-0001' }; }; klick(knopf(w, 'Geld ist da: freischalten')[0]); });
  assert.equal(d.frei, 'MM-AAAAAAAA'); await tick();
  assert.equal(d.fragen, vorher + 1, 'die Liste wird neu geladen');
  assert.match(alle(y.seiten[y.seiten.length - 1]), /Freigeschaltet: kunde@example\.org, Beleg MM-2026-0001/);
  /* Löschen */
  const w2 = { kinder: y.seiten[0].inhalt, tag: 'x', attrs: {} };
  await new Promise((r) => { d.verwaltungLoeschen = async (ref) => { d.weg = ref; r(); return { ok: true }; }; klick(knopf(w2, 'Löschen')[0]); });
  assert.equal(d.weg, 'MM-AAAAAAAA');
  /* Direkt freischalten (das letzte Formular der Seite: der erste Knopf gleichen Namens gehört zur Bestellung) */
  const w3 = { kinder: y.seiten[0].inhalt, tag: 'x', attrs: {} };
  finde(w3, (x) => x.tag === 'input' && x.attrs.id === 'vw-mail')[0].value = 'neu@example.org';
  finde(w3, (x) => x.tag === 'select' && x.attrs.id === 'vw-prod')[0].value = 'route100';
  const dk = knopf(w3, 'Geld ist da: freischalten'); assert.equal(dk.length, 2);
  await new Promise((r) => { d.verwaltungDirekt = async (m, p) => { d.direkt = [m, p]; r(); return { ok: true, nummer: 'MM-2026-0002' }; }; klick(dk[1]); });
  assert.deepEqual(d.direkt, ['neu@example.org', 'route100']);
});

test('Seite Verwaltung, Entwickler: nur die Statistik, Zahlungseingänge nur mit Hinweis, der Dienst wird dafür nicht gefragt', async () => {
  const d = { fragen: 0, verwaltungStatistik: async () => STAT, verwaltungBestellungen: async () => { d.fragen++; return { ok: true, bestellungen: BEST }; } };
  const e = lauf(d, 'entwickler'); await e.fn();
  const t1 = alle(e.seiten[0]);
  assert.match(t1, /Konten insgesamt: 7/); assert.match(t1, /dürfen nur Admins/); assert.equal(d.fragen, 0);
  assert.equal(knopf({ kinder: e.seiten[0].inhalt, tag: 'x', attrs: {} }, 'Geld ist da: freischalten').length, 0);
});

test('Seite Verwaltung: Fehler des Dienstes in einfachen Worten, Anmeldung abgelaufen führt zum Konto, ohne Rolle gibt es die Seite nicht', async () => {
  const d = { verwaltungStatistik: async () => ({ ok: false, fehler: { allgemein: 'Der Dienst hat nicht geantwortet.' } }), verwaltungBestellungen: async () => ({ ok: false, fehler: { allgemein: 'Der Dienst hat nicht geantwortet.' } }) };
  const a = lauf(d, 'admin'); await a.fn();
  const t1 = alle(a.seiten[0]); assert.match(t1, /Die Statistik|Der Dienst hat nicht geantwortet/); assert.match(t1, /Update auf 13f-11/);
  const d2 = { verwaltungStatistik: async () => ({ ok: false, abgelaufen: true, fehler: { allgemein: 'Deine Anmeldung ist abgelaufen. Bitte melde dich neu an.' } }), verwaltungBestellungen: async () => ({ ok: false, abgelaufen: true, fehler: { allgemein: 'x' } }) };
  const b = lauf(d2, 'admin'); await b.fn();
  assert.match(alle(b.seiten[0]), /Anmeldung ist abgelaufen/); assert.equal(knopf({ kinder: b.seiten[0].inhalt, tag: 'x', attrs: {} }, 'Zum Konto').length, 0, 'Zum Konto ist ein Link');
  assert.ok(finde({ kinder: b.seiten[0].inhalt, tag: 'x', attrs: {} }, (x) => x.tag === 'a' && x.attrs.href === '#/konto').length === 1);
});

test('Einbau: Kachel führt zu #/verwaltung, Route, Version 2.0.94, Neu im Programm, Changelog, Schritte', () => {
  const a = lesen('js/ansicht.js');
  assert.ok(a.includes("kachel('Verwaltung', 'Statistik, Zahlungseingänge, Freischaltung', '#/verwaltung')"));
  assert.ok(!a.includes("Zahlungseingänge, Freischaltung', null)"));
  assert.ok(a.includes("teile[0] === 'verwaltung') p = seiteVerwaltung()"));
  assert.equal(MM.VERSION, '2.0.97');
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.97';")); assert.equal(JSON.parse(lesen('package.json')).version, '2.0.97');
  assert.ok(lesen('README.md').includes('Version 2.0.97'));
  assert.ok(lesen('CHANGELOG.md').includes('## 2.0.94\n- **Bau: Verwaltung**'));
  assert.equal(MM.Texte.NEUERUNGEN[3].version, '2.0.94'); assert.match(MM.Texte.NEUERUNGEN[3].punkte.join(' '), /Verwaltung/);
  assert.ok(lesen('docs/SCHRITTE.md').includes('| Verwaltung | Kachel „Verwaltung“'));
  assert.ok(lesen('server/EINRICHTUNG.md').startsWith('# Konto-Dienst: Einrichtung und Updates (Stand 2.0.95, Schritt 13f-11)'));
});
