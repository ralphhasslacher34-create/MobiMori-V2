'use strict';
/* 2.0.24, Schritt 7a: Werkstatt – Vorgänge (Störungen und Arbeiten), Warnung bei versprochenen Aktivitäten. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/daten.js');
const MM = globalThis.MM;
const W = MM.Werkstatt;

/* feste Uhr: 3. November 2026, 12:00 Ortszeit */
const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const motor = (await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor Backbord' })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = n => arten.find(x => x.aktuell.werte.bezeichnung === n).objekt.id;
  return { d, boot, wm, anna, motor, artId };
}
const toern = (c, extra) => Object.assign({ bezeichnung: 'Sommertörn', artId: c.artId('Törn'), fahrzeugId: c.boot, vonDatum: '2026-12-01', bisDatum: '2026-12-10', verantwortlichId: c.anna }, extra || {});

/* ---------- Regeln ohne Speicher ---------- */
test('Einsatzfähigkeit: nur offene Vorgänge mit Einschränkung bremsen, „nicht“ schlägt „bedingt“', () => {
  assert.equal(W.einsatz([]), 'ok');
  assert.equal(W.einsatz([{ status: 'offen', auswirkung: 'keine' }]), 'ok');
  assert.equal(W.einsatz([{ status: 'offen', auswirkung: 'bedingt' }]), 'bedingt');
  assert.equal(W.einsatz([{ status: 'erledigt', auswirkung: 'nicht' }]), 'ok');
  assert.equal(W.einsatz([{ status: 'offen', auswirkung: 'bedingt' }, { status: 'offen', auswirkung: 'nicht' }]), 'nicht');
  assert.equal(W.bremst({ status: 'offen', auswirkung: 'nicht' }), true);
  assert.equal(W.bremst({ status: 'erledigt', auswirkung: 'nicht' }), false);
});

test('Felder: Störung ohne Ausführung, Arbeit mit Ausführung und Aufgabe', () => {
  assert.deepEqual(W.felder('stoerung').map(f => f.key), ['beschreibung', 'auswirkung', 'gemeldetAm']);
  assert.deepEqual(W.felder('arbeit').map(f => f.key), ['beschreibung', 'auswirkung', 'gemeldetAm', 'ausfuehrung', 'arbeit']);
});

/* ---------- Anlegen und Prüfen ---------- */
test('Störung melden: Pflichtangaben, Einschränkung muss gewählt werden, Datum nicht in der Zukunft', async () => {
  const c = await neu();
  const f = async roh => (await c.d.vorgangAnlegen(c.boot, null, 'stoerung', roh)).fehler || {};
  assert.ok((await f({ bezeichnung: ' ', auswirkung: 'nicht' })).bezeichnung);
  assert.ok((await f({ bezeichnung: 'Motor aus' })).auswirkung, 'bei einer Störung wählt der Nutzer die Einschränkung selbst');
  assert.ok((await f({ bezeichnung: 'Motor aus', auswirkung: 'viel' })).auswirkung);
  assert.ok((await f({ bezeichnung: 'Motor aus', auswirkung: 'nicht', gemeldetAm: '2026-12-24' })).gemeldetAm);
  assert.ok((await c.d.vorgangAnlegen('gibt-es-nicht', null, 'stoerung', { bezeichnung: 'x', auswirkung: 'keine' })).fehler.allgemein);
  assert.ok((await c.d.vorgangAnlegen(c.boot, c.motor + 'x', 'stoerung', { bezeichnung: 'x', auswirkung: 'keine' })).fehler.allgemein);
  assert.ok((await c.d.vorgangAnlegen(c.boot, null, 'wunsch', { bezeichnung: 'x' })).fehler.allgemein);
  assert.equal((await c.d.vorgaengeListe(c.boot)).length, 0, 'bei Fehlern wird nichts gespeichert');
});

test('Störung melden: wird offen gespeichert, Datum heute, am Fahrzeug oder an der Komponente', async () => {
  const c = await neu();
  const r = await c.d.vorgangAnlegen(c.boot, c.motor, 'stoerung', { bezeichnung: 'Motor springt schlecht an', auswirkung: 'bedingt', beschreibung: 'Nur kalt' });
  assert.ok(r.ok);
  const v = await c.d.vorgangLaden(r.id);
  const w = v.aktuell.werte;
  assert.deepEqual([w.art, w.status, w.auswirkung, w.gemeldetAm, w.beschreibung, w.ausfuehrung, w.arbeit], ['stoerung', 'offen', 'bedingt', '2026-11-03', 'Nur kalt', null, null]);
  assert.equal(v.komponente.id, c.motor);
  assert.equal(v.komponenteAktuell.werte.bezeichnung, 'Motor Backbord');
  assert.equal(v.fahrzeug.id, c.boot);
  assert.equal(v.verlauf.length, 1);
  const l = await c.d.vorgaengeListe(c.boot);
  assert.equal(l[0].besitzer, 'Motor Backbord');
  assert.equal((await c.d.vorgaengeListe(c.wm)).length, 0, 'gehört nur zum Boot');
});

test('Arbeit planen: Ausführung ist Pflicht, die Einschränkung ist ohne Angabe „keine“', async () => {
  const c = await neu();
  assert.ok((await c.d.vorgangAnlegen(c.wm, null, 'arbeit', { bezeichnung: 'Ölwechsel' })).fehler.ausfuehrung);
  const r = await c.d.vorgangAnlegen(c.wm, null, 'arbeit', { bezeichnung: 'Ölwechsel', ausfuehrung: 'selbst', arbeit: 'Öl und Filter' });
  assert.ok(r.ok);
  const w = (await c.d.vorgangLaden(r.id)).aktuell.werte;
  assert.deepEqual([w.art, w.auswirkung, w.ausfuehrung, w.arbeit], ['arbeit', 'keine', 'selbst', 'Öl und Filter']);
});

/* ---------- Störung wird Arbeit, erledigen, wieder öffnen ---------- */
test('Aus der Störung eine Arbeit machen: selbst oder Werkstatt, der Verlauf zeigt den Schritt', async () => {
  const c = await neu();
  const id = (await c.d.vorgangAnlegen(c.boot, null, 'stoerung', { bezeichnung: 'Kühlwasser', auswirkung: 'nicht' })).id;
  assert.ok((await c.d.vorgangZuArbeit(id, {})).fehler.ausfuehrung);
  assert.ok((await c.d.vorgangZuArbeit(id, { ausfuehrung: 'jemand' })).fehler.ausfuehrung);
  const r = await c.d.vorgangZuArbeit(id, { ausfuehrung: 'werkstatt', arbeit: 'Kühler prüfen lassen' });
  assert.ok(r.ok && r.geaendert);
  const v = await c.d.vorgangLaden(id);
  assert.deepEqual([v.aktuell.werte.art, v.aktuell.werte.ausfuehrung, v.aktuell.werte.arbeit, v.aktuell.werte.auswirkung, v.aktuell.werte.status],
    ['arbeit', 'werkstatt', 'Kühler prüfen lassen', 'nicht', 'offen']);
  assert.equal(v.verlauf.length, 2);
  assert.ok(v.verlauf[0].aenderungen.some(u => u.key === 'art' && u.alt === 'stoerung' && u.neu === 'arbeit'));
  assert.ok((await c.d.vorgangZuArbeit(id, { ausfuehrung: 'selbst' })).fehler.allgemein, 'ist schon eine Arbeit');
});

test('Erledigen: Datum, Notiz, nicht vor dem Eintrag, nicht in der Zukunft; wieder öffnen', async () => {
  const c = await neu();
  const id = (await c.d.vorgangAnlegen(c.boot, null, 'stoerung', { bezeichnung: 'Licht', auswirkung: 'bedingt', gemeldetAm: '2026-11-01' })).id;
  assert.ok((await c.d.vorgangErledigen(id, { datum: '2026-12-24' })).fehler.datum);
  assert.ok((await c.d.vorgangErledigen(id, { datum: '2026-10-31' })).fehler.datum);
  const r = await c.d.vorgangErledigen(id, { notiz: 'Birne getauscht' });
  assert.ok(r.ok);
  let w = (await c.d.vorgangLaden(id)).aktuell.werte;
  assert.deepEqual([w.status, w.erledigtAm, w.erledigtNotiz], ['erledigt', '2026-11-03', 'Birne getauscht']);
  assert.ok((await c.d.vorgangErledigen(id, {})).fehler.allgemein, 'schon erledigt');
  assert.ok((await c.d.vorgangAendern(id, { bezeichnung: 'Licht', auswirkung: 'keine' })).fehler.allgemein, 'erledigt: erst wieder öffnen');
  assert.ok((await c.d.vorgangWiederOeffnen(id)).ok);
  w = (await c.d.vorgangLaden(id)).aktuell.werte;
  assert.deepEqual([w.status, w.erledigtAm, w.erledigtNotiz], ['offen', null, null]);
  assert.ok((await c.d.vorgangWiederOeffnen(id)).fehler.allgemein, 'ist nicht erledigt');
  assert.equal((await c.d.vorgangLaden(id)).verlauf.length, 3, 'nichts wird überschrieben');
});

test('Angaben ändern: neuer Eintrag im Verlauf, ohne Änderung kein neuer Eintrag', async () => {
  const c = await neu();
  const id = (await c.d.vorgangAnlegen(c.boot, null, 'stoerung', { bezeichnung: 'Pumpe', auswirkung: 'keine', beschreibung: 'tropft' })).id;
  const gleich = await c.d.vorgangAendern(id, { bezeichnung: 'Pumpe', auswirkung: 'keine', beschreibung: 'tropft', gemeldetAm: '2026-11-03' });
  assert.ok(gleich.ok && gleich.geaendert === false);
  const r = await c.d.vorgangAendern(id, { bezeichnung: 'Bilgenpumpe', auswirkung: 'bedingt', beschreibung: 'tropft', gemeldetAm: '2026-11-03' });
  assert.ok(r.ok && r.geaendert);
  const v = await c.d.vorgangLaden(id);
  assert.equal(v.aktuell.werte.bezeichnung, 'Bilgenpumpe');
  assert.equal(v.aktuell.werte.art, 'stoerung', 'Art und Stand ändern sich nur über die eigenen Schritte');
  assert.deepEqual(v.verlauf[0].aenderungen.map(u => u.key).sort(), ['auswirkung', 'bezeichnung']);
  assert.ok((await c.d.vorgangAendern('gibt-es-nicht', { bezeichnung: 'x' })).fehler.allgemein);
});

/* ---------- Liste und Übersicht ---------- */
test('Liste: was bremst, steht oben, Erledigtes unten; Übersicht zählt offene und bremsende', async () => {
  const c = await neu();
  const a = (await c.d.vorgangAnlegen(c.boot, null, 'stoerung', { bezeichnung: 'A klein', auswirkung: 'keine' })).id;
  const b = (await c.d.vorgangAnlegen(c.boot, null, 'stoerung', { bezeichnung: 'B bedingt', auswirkung: 'bedingt' })).id;
  const n = (await c.d.vorgangAnlegen(c.boot, c.motor, 'stoerung', { bezeichnung: 'C nicht', auswirkung: 'nicht' })).id;
  const e = (await c.d.vorgangAnlegen(c.boot, null, 'stoerung', { bezeichnung: 'D weg', auswirkung: 'nicht' })).id;
  await c.d.vorgangErledigen(e, {});
  const l = await c.d.vorgaengeListe(c.boot);
  assert.deepEqual(l.map(x => x.aktuell.werte.bezeichnung), ['C nicht', 'B bedingt', 'A klein', 'D weg']);
  const u = await c.d.vorgaengeUebersicht();
  assert.deepEqual(u[c.boot], { offen: 3, nicht: 1, bedingt: 1 });
  assert.deepEqual(u[c.wm], { offen: 0, nicht: 0, bedingt: 0 });
  assert.ok(a && b && n);
});

/* ---------- Warnung bei versprochenen Aktivitäten ---------- */
test('Warnung: bremsender Vorgang und geplante Aktivität am selben Fahrzeug, nicht bei anderen Fahrzeugen', async () => {
  const c = await neu();
  const akt = (await c.d.aktivitaetAnlegen(toern(c))).id;
  await c.d.aktivitaetAnlegen(toern(c, { bezeichnung: 'Wohnmobil-Urlaub', fahrzeugId: c.wm, artId: c.artId('Urlaub') }));
  let w = await c.d.vorgangWarnung(c.boot);
  assert.equal(w.stufe, 'ok');
  assert.equal(w.aktivitaeten.length, 0);

  const v = (await c.d.vorgangAnlegen(c.boot, c.motor, 'stoerung', { bezeichnung: 'Motor aus', auswirkung: 'nicht' })).id;
  w = await c.d.vorgangWarnung(c.boot);
  assert.equal(w.stufe, 'nicht');
  assert.deepEqual(w.vorgaenge.map(x => x.vorgang.id), [v]);
  assert.deepEqual(w.aktivitaeten.map(x => [x.aktivitaet.objekt.id, x.trotzdem]), [[akt, false]]);
  assert.equal((await c.d.vorgangWarnung(c.wm)).stufe, 'ok', 'das Wohnmobil ist nicht betroffen');
});

test('Warnung: keine Einschränkung, erledigt, storniert oder vorbei lösen keine Warnung aus', async () => {
  const c = await neu();
  const akt = (await c.d.aktivitaetAnlegen(toern(c))).id;
  const vorbei = (await c.d.aktivitaetAnlegen(toern(c, { bezeichnung: 'Alt', vonDatum: '2026-10-01', bisDatum: '2026-10-02' }))).id;
  const frei = (await c.d.vorgangAnlegen(c.boot, null, 'stoerung', { bezeichnung: 'Kratzer', auswirkung: 'keine' })).id;
  assert.equal((await c.d.vorgangWarnung(c.boot)).stufe, 'ok');
  const v = (await c.d.vorgangAnlegen(c.boot, null, 'stoerung', { bezeichnung: 'Leck', auswirkung: 'bedingt' })).id;
  let w = await c.d.vorgangWarnung(c.boot);
  assert.deepEqual(w.aktivitaeten.map(x => x.aktivitaet.objekt.id), [akt], 'die vergangene Aktivität zählt nicht');
  await c.d.aktivitaetStornieren(akt, 'Leck');
  assert.equal((await c.d.vorgangWarnung(c.boot)).aktivitaeten.length, 0, 'storniert: nichts mehr versprochen');
  await c.d.aktivitaetWiederherstellen(akt);
  assert.equal((await c.d.vorgangWarnung(c.boot)).aktivitaeten.length, 1);
  await c.d.vorgangErledigen(v, {});
  w = await c.d.vorgangWarnung(c.boot);
  assert.equal(w.stufe, 'ok');
  assert.equal(w.aktivitaeten.length, 0);
  assert.ok(frei && vorbei);
});

test('Entscheidung: trotzdem nutzen wird festgehalten, ist zurücknehmbar und gilt je Vorgang', async () => {
  const c = await neu();
  const akt = (await c.d.aktivitaetAnlegen(toern(c))).id;
  const v1 = (await c.d.vorgangAnlegen(c.boot, null, 'stoerung', { bezeichnung: 'Leck', auswirkung: 'bedingt' })).id;
  assert.ok((await c.d.vorgangEntscheiden(v1, akt, 'vielleicht')).fehler.allgemein);
  assert.ok((await c.d.vorgangEntscheiden('gibt-es-nicht', akt, 'trotzdem')).fehler.allgemein);
  assert.ok((await c.d.vorgangEntscheiden(v1, 'gibt-es-nicht', 'trotzdem')).fehler.allgemein);
  assert.ok((await c.d.vorgangEntscheiden(v1, akt, 'trotzdem')).ok);
  assert.equal((await c.d.vorgangWarnung(c.boot)).aktivitaeten[0].trotzdem, true);
  assert.equal((await c.d.vorgangLaden(v1)).entscheidungen[akt].entscheidung, 'trotzdem');

  /* ein zweiter bremsender Vorgang: die frühere Entscheidung deckt ihn nicht ab */
  const v2 = (await c.d.vorgangAnlegen(c.boot, null, 'stoerung', { bezeichnung: 'Ruder', auswirkung: 'nicht' })).id;
  assert.equal((await c.d.vorgangWarnung(c.boot)).aktivitaeten[0].trotzdem, false);
  assert.ok((await c.d.vorgangEntscheiden(v2, akt, 'trotzdem')).ok);
  assert.equal((await c.d.vorgangWarnung(c.boot)).aktivitaeten[0].trotzdem, true);

  /* zurücknehmen: es wird nichts gelöscht, die neueste Entscheidung zählt */
  assert.ok((await c.d.vorgangEntscheiden(v2, akt, 'offen')).ok);
  assert.equal((await c.d.vorgangWarnung(c.boot)).aktivitaeten[0].trotzdem, false);
  assert.equal((await c.d.vorgangLaden(v2)).entscheidungen[akt].entscheidung, 'offen');
  assert.equal((await c.d.speicher.alle('vorgangsentscheidungen')).length, 3);
});

/* ---------- Speicher und Sicherung ---------- */
test('Speicher: Datenbank-Version 11 mit den Tabellen, die Sicherung enthält die Vorgänge und stellt sie wieder her', async () => {
  assert.equal(MM.Speicher.DB_VERSION, 11);
  assert.ok(MM.Speicher.TABELLEN.includes('vorgaenge') && MM.Speicher.TABELLEN.includes('vorgangsentscheidungen'));
  const c = await neu();
  const akt = (await c.d.aktivitaetAnlegen(toern(c))).id;
  const id = (await c.d.vorgangAnlegen(c.boot, c.motor, 'stoerung', { bezeichnung: 'Motor aus', auswirkung: 'nicht' })).id;
  await c.d.vorgangEntscheiden(id, akt, 'trotzdem');
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  assert.equal(s.zahlen.vorgaenge, 1);

  const b = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => JETZT });
  await b.starten();
  const g = await b.sicherungLesen(s.bytes, '');
  assert.equal((await b.sicherungVorschau(g)).zahlen.vorgaenge, 1);
  await b.sicherungEinspielen(g);
  const v = await b.vorgangLaden(id);
  assert.equal(v.aktuell.werte.bezeichnung, 'Motor aus');
  assert.equal(v.entscheidungen[akt].entscheidung, 'trotzdem');
});
