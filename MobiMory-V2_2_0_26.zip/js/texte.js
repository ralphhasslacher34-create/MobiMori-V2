/*
 * Texte, die das Programm von sich selbst zeigt: Kernsatz, Infotext,
 * Copyright und die Liste "Neu im Programm". Nur hier ändern.
 * Das Logo ist die Datei icons/icon.svg (zugleich das App-Symbol).
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  MM.Texte = {
    KERNSATZ: 'Dein Fahrzeug. Dein Weg. Deine Daten.',
    INFOTEXT: 'Fahrzeuge verwalten, Reisen planen und Erinnerungen festhalten. Auf Land, zu Wasser und in der Luft.',
    COPYRIGHT: '© 2026 Ralph Hasslacher',

    /* Neueste Version zuerst. Die oberste muss zu MM.VERSION passen (wird getestet). */
    NEUERUNGEN: [
      { version: '2.0.26', datum: '2026-11-04', punkte: [
        'Dokumente und Bilder am Vorgang: Auf der Seite eines Vorgangs in der Werkstatt legst du Fotos vom Schaden, Rechnungen und Belege ab, als Datei oder als Link. Das geht auch bei einem erledigten Vorgang, denn die Rechnung kommt oft erst später.',
        'Neue Art von Dokument: Reparaturbuch. Bedienungsanleitung und Ersatzteilliste gab es schon an der Komponente. Die Gesamtliste aller Dokumente eines Fahrzeugs zeigt auch die Dokumente der Vorgänge („am Vorgang: …“), die Suche findet sie ebenfalls.',
        'Störung im Logbuch: Das Ereignis „Störung“ ist jetzt dieselbe Störung wie in der Werkstatt. Im Cockpit tippst du einmal auf „Störung“. Die Störung steht mit Uhrzeit und Position im Logbuch und zugleich als Vorgang in der Werkstatt. Die Warnung bei versprochenen Aktivitäten gilt damit auch unterwegs.',
        'Die Einschränkung ist vorbelegt mit „Fahrzeug bleibt nutzbar“, du änderst sie beim Vorgang in der Werkstatt. Die Störung hängt am Fahrzeug. Beim Nachtragen gilt dasselbe, der Vorgang bekommt dann das Datum des Ereignisses. Im Ereignis steht ein Link zum Vorgang, im Vorgang ein Link zum Ereignis.',
        'Eine ältere Störung im Logbuch bleibt, wie sie ist, sie wird nicht nachträglich zum Vorgang. Die Art eines bestehenden Ereignisses lässt sich nicht auf „Störung“ umstellen, weil sonst die Werkstatt ausgelassen würde.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher ist unverändert. Die Dokumente und Verweise sind in der Sicherung enthalten. Noch nicht dabei: Beträge und Kosten (Schritt 8).'
      ] },
      { version: '2.0.25', datum: '2026-11-04', punkte: [
        'Adressen: Unter „Stammdaten“ gibt es jetzt „Adressen“, eine einzige Liste für Werkstätten, Lieferanten und Händler. Sie gilt für alle deine Fahrzeuge. Du legst Name und Art fest, alles andere ist freiwillig: Ansprechpartner, Telefon, E-Mail, Anschrift, Webseite und Notiz.',
        'Die Werkstatt verweist darauf: Bei einer Arbeit („Wer macht die Arbeit?“) und beim Umwandeln einer Störung in eine Arbeit kannst du eine Adresse aus der Liste wählen. Auf der Seite des Vorgangs steht sie mit Link, auf der Seite der Adresse siehst du alle Vorgänge, die darauf verweisen.',
        'Nichts wird gelöscht: Eine Adresse lässt sich ändern oder ausblenden, der frühere Stand bleibt im Verlauf sichtbar. Eine ausgeblendete Adresse lässt sich nicht neu wählen, bleibt aber an den Vorgängen, an denen sie schon hängt.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher bekommt eine neue Tabelle für die Adressen. Die Adressen sind in der Sicherung enthalten. Noch nicht dabei: Dokumente und Bilder am Vorgang sowie die Kosten.'
      ] },
      { version: '2.0.24', datum: '2026-11-04', punkte: [
        'Werkstatt: Unter „Funktionen“ gibt es jetzt die Werkstatt. Dort meldest du Störungen und planst Arbeiten, am ganzen Fahrzeug oder an einer einzelnen Komponente. Auch auf der Seite des Fahrzeugs und der Komponente steht ein Block „Werkstatt“.',
        'Störung melden: Du sagst kurz, was los ist, und wie weit das Fahrzeug eingeschränkt ist: bleibt nutzbar, nur bedingt einsatzfähig oder nicht einsatzfähig.',
        'Aus der Störung eine Arbeit machen: Du legst fest, ob du die Arbeit selbst erledigst oder eine Werkstatt sie macht. Die Störung bleibt im Verlauf sichtbar. Ist alles gemacht, trägst du „Erledigt“ ein. Ein erledigter Vorgang lässt sich wieder öffnen, nichts wird gelöscht.',
        'Warnung bei versprochenen Aktivitäten: Ist das Fahrzeug nicht oder nur bedingt einsatzfähig, aber für die nächste Zeit eingeplant, warnt die App und fragt, ob es trotzdem genutzt werden kann oder abgesagt werden muss. „Trotzdem nutzen“ wird festgehalten und lässt sich zurücknehmen. „Absagen“ führt zum Stornieren der Aktivität. Die Entscheidung triffst immer du.',
        'Bestehende Daten und Sicherungen bleiben gültig. Die Vorgänge sind in der Sicherung enthalten. Noch nicht dabei: Adressen von Werkstätten und Lieferanten, Dokumente und Bilder am Vorgang sowie die Kosten. Sie folgen in den nächsten Stufen.'
      ] },
      { version: '2.0.23', datum: '2026-11-04', punkte: [
        'Status des Fahrzeugs: Jedes Fahrzeug hat jetzt immer einen Status, und was als Nächstes geht, hängt nur davon ab. Landfahrzeug: Stillstand oder In Fahrt (Abfahrt, Ankunft im Wechsel). Wasserfahrzeug: Festgemacht, In Fahrt oder Vor Anker (Ablegen, Anlegen, Anker werfen, Anker lichten). Am Steg geht nur Ablegen, vor Anker nur Anker lichten.',
        'Im Cockpit steht der Status in der Statuszeile, zum Beispiel „Status In Fahrt seit 09:00 Uhr (Abfahrt)“. Ein Knopf, der zum Status nicht passt, ist grau und nennt den Grund, zum Beispiel „erst Ablegen“. Notiz, Foto, Tanken und andere Ereignisse stören den Status nicht.',
        'Der Status gehört zum Fahrzeug, nicht zur Aktivität: Liegt das Boot nach einem Törn vor Anker, geht es im nächsten Törn mit Anker lichten weiter. Beim allerersten Mal ist der Knopf frei, der den Anfang macht (Abfahrt oder Ablegen).',
        'Vergessen? Trage das fehlende Ereignis mit der echten Uhrzeit nach. Das Nachtragen wird nie gesperrt, und der Status wird nach der Uhrzeit neu gerechnet, nicht nach der Reihenfolge des Eintippens.',
        'Die Regel hängt an der Art des Ereignisses, nicht am Namen: Auf der Seite „Arten von Ereignissen“ gibt es bei jeder Art den Abschnitt „Status des Fahrzeugs (freiwillig)“ mit „Möglich im Status“ und „Danach Status“. So gilt die Regel auch für eigene Arten. Für die sechs bekannten Namen gibt es eine Starthilfe, bei „Ändert den Status nicht“ wird die Art nie gesperrt.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Luftfahrzeuge haben keine Status und werden nie gesperrt. Das echte Aussehen der grauen Knöpfe am Tablet ist nicht geprüft.'
      ] },
      { version: '2.0.22', datum: '2026-11-04', punkte: [
        'Motorstopp-Frage: Tippst du Ankunft, Anlegen oder Anker werfen und ein Motor läuft noch, fragt das Cockpit oben „Fahrzeug am Ziel, Motor stoppen?“. Der Eintrag ist da schon gespeichert, die Frage sperrt nichts. Mit „Motor stoppen“ stoppt der Motor sofort (bei zwei Motoren je Motor ein Knopf), mit „Läuft weiter“ bleibt er an.',
        'Läuft der Motor nach der Frage weiter, schlägt die App nach der Wartezeit die Zeit der Ankunft als Stoppzeit vor, zum Beispiel „Stopp um 12:00 Uhr übernehmen“. Übernimmst du sie, rechnet die App die Betriebsstunden bis zu dieser Zeit und nicht bis jetzt. Die Stoppzeit lässt sich danach wie bisher noch korrigieren.',
        'Die Wartezeit stellst du selbst ein, auf der Seite „Motoren“ unter „Motorstopp-Frage“ (1 bis 1440 Minuten, Vorgabe 15). Sie gilt nur für dieses Gerät und ist nicht in der Sicherung.',
        'Ausgelöst wird die Frage immer von einem Ereignis am Ziel, nie von der Laufzeit des Motors: Bootsmotoren laufen auf langen Törns 24 bis 30 Stunden normal. Geht es nach der Ankunft mit Abfahrt, Ablegen oder Anker lichten weiter, fragt die App nichts. Wurde der Motor erst nach der Ankunft gestartet, auch nicht. Die Frage hängt an den Ereignissen im Logbuch: Auch eine nachgetragene oder ausgeblendete Ankunft wird berücksichtigt.',
        'Sagst du bei der Frage „Läuft weiter“, kommt sie für diese Ankunft nicht wieder. Der Vorschlag nach der Wartezeit kommt trotzdem noch einmal. Sagst du auch dort „Läuft weiter“, ist die Sache für diese Ankunft erledigt. Eine neue Ankunft fragt wieder.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Noch nicht dabei: Motor Start und Stopp als Ereignisse im Logbuch, Korrektur der Startzeit, Kilometer über GPS.'
      ] },
      { version: '2.0.21', datum: '2026-11-04', punkte: [
        'Position bei jedem Eintrag: Ein Ereignis im Logbuch kann jetzt eine Position tragen (Breite und Länge), dazu die Herkunft (vom GPS oder von Hand) und freiwillig einen Ortsnamen. Bei Tipps im Cockpit nimmt die App die GPS-Position dieses Geräts, wenn sie frisch ist (höchstens 2 Minuten alt). Sie wartet nie auf das GPS und fragt nie nach: Ohne GPS wird der Eintrag trotzdem sofort gespeichert, nur ohne Position.',
        'Im Cockpit steht in der Statuszeile die aktuelle Position, bei einem bekannten Ort mit dessen Namen. Beim ersten Mal fragt der Browser, ob dieses Gerät den Standort nutzen darf. Sagst du Nein, geht alles weiter, nur ohne Position.',
        'Von Hand: Im Formular „Ereignis eintragen“, „Nachtragen“ und „Angaben ändern“ gibt es den Abschnitt „Ort und Position“ mit Breite, Länge (Dezimalgrad, zum Beispiel 48,8566; Süd und West mit Minuszeichen oder S und W) und Ortsname. Beim Nachtragen gibt es keine GPS-Position, sie wird nur von Hand eingetragen. Änderst du eine GPS-Position, gilt sie danach als von Hand eingetragen. Die Handeingabe hat Vorrang.',
        'Die App lernt Ortsnamen: Gibst du zu einer Position einen Namen ein oder bestätigst ihn, merkt sich die App ihn für diese Gegend (Umkreis etwa 500 Meter, es kommt nicht auf den Meter an). Bei einer späteren Position im Umfeld schlägt sie den Namen vor, zum Beispiel „Schleuse Gamsheim“. Im Cockpit steht ein vorgeschlagener Name als „Vorschlag“ am Eintrag, gelernt wird er erst, wenn du ihn unter „Angaben ändern“ bestätigst.',
        'Am Ereignis steht außerdem, von welchem Gerät es kam (dieses Gerät oder ein anderes). Wer den Eintrag gemacht hat (Nutzer), folgt mit den Konten. Die gelernten Ortsnamen sind in der Sicherung, die Gerätekennung nicht.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Noch nicht dabei: die Frage „Motor stoppen?“ nach Ankunft (nächste Stufe), Kilometer über GPS, Karte, Route und Wetter am Wegpunkt (Schritt 9). Die gelernten Namen sind noch nicht mit den Orten und Standorten aus den Stammdaten verknüpft, weil diese noch keine Koordinaten haben.'
      ] },
      { version: '2.0.20', datum: '2026-11-04', punkte: [
        'Hinweis „Kein Motor läuft“: Jede Fahrzeugart legt fest, ob sie normalerweise einen Motor hat. Du kannst das je Art ändern (Stammdaten › Fahrzeugarten › Art), eine Untergruppe übernimmt es von der Obergruppe, bis du etwas Eigenes einstellst. Tippst du im Cockpit „Abfahrt“ oder „Ablegen“, ohne dass ein Motor läuft, speichert die App den Eintrag trotzdem sofort. Oben steht nur der Hinweis „Kein Motor läuft“. Es gibt keine Rückfrage und keine Sperre.',
        'Betriebsstunden und Kilometer stehen jetzt zusammen in der Statuszeile des Cockpits, jeweils mit der Quelle des Stands (Hand oder Schalter) und dem Datum. Auf der Seite „Motoren“ gibt es dazu eine Karte „Kilometer“. Die Kilometer trägst du von Hand ein. GPS kann später eine weitere Quelle sein und ist nie Voraussetzung. Ein Handeintrag hat wie bei den Betriebsstunden Vorrang.',
        'Knopfzahl je Gerät: Je Fahrzeugart lassen sich bis zu 15 Knöpfe belegen (bisher 8). Wie viele davon dieses Gerät zeigt, stellst du auf der Seite „Schnellknöpfe“ unter „Auf diesem Gerät“ ein. Bis du etwas einstellst, sind es 8, wie bisher. Die übrigen Knöpfe liegen unter „Sonstige Ereignisse“ und gehen nicht verloren. Die Einstellung gilt nur für das einzelne Gerät und ist nicht in der Sicherung.',
        'Die Spalten im Cockpit richten sich nach der Breite des Bildschirms: Handy 2, Tablet 3, großer Bildschirm 4 (ab 1400 Pixel Breite). Die Zeilen teilen sich weiter die Höhe, es wird nicht gescrollt.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Noch nicht dabei: die Frage „Motor stoppen?“ nach Ankunft, Anlegen oder Anker werfen (nächste Stufe), Kilometer über GPS.'
      ] },
      { version: '2.0.19', datum: '2026-11-04', punkte: [
        'Motorschalter im Cockpit: Jeder Motor hat seinen eigenen Schalter und seinen eigenen Zähler für die Betriebsstunden, einen Sammelschalter „alle“ gibt es nicht. Grau heißt Motor aus (Name und „Start“), rot heißt Motor läuft (Name und „Stopp“). Die Schalter stehen in einer Leiste unter den Knöpfen, oben in der Statuszeile steht, welcher Motor seit wann läuft.',
        'Die Motoren kommen aus den Komponenten: Jede Hauptkomponente der Art Motor bekommt einen Schalter, ein ausgebauter Motor nicht. Beim ersten Start legt die App den Zähler „Betriebsstunden“ am Motor an. Beim Stopp rechnet sie den letzten Stand plus die Laufzeit. Trägst du einen Stand von Hand ein, hat er Vorrang, ab ihm wird weitergerechnet. Ohne Startstand zählt der Zähler ab 0 und die App sagt es dir.',
        'Neues Feld „Kurzname“ bei den Komponenten (höchstens 8 Zeichen). Bei einem Motor macht die App aus der Bezeichnung einen Vorschlag, zum Beispiel wird aus „Motor Steuerbord“ MOSTB. Du siehst ihn im Feld und kannst ihn ändern. Einen selbst geänderten Kurznamen überschreibt die App nicht mehr. Zwei Motoren desselben Fahrzeugs dürfen nicht denselben Kurznamen haben.',
        'Ein oder zwei Motoren haben je einen festen Schalter. Ab drei Motoren steht in der Leiste ein einziger Schalter „Motoren“ mit der Anzeige, wie viele laufen. Ein Tipp darauf öffnet eine Liste mit allen Motoren, jeder mit eigenem Schalter, Zähler und den letzten Läufen. Die Ereignisknöpfe bleiben unverändert.',
        'Stoppen vergessen? Auf der Seite „Motoren“ gibt es bei dem letzten Lauf den Knopf „Stoppzeit korrigieren“. Du trägst ein, wann der Motor wirklich gestoppt wurde, der Stand wird neu gerechnet, und der alte Stand bleibt im Verlauf des Zählers sichtbar. Wurde der Zählerstand danach von Hand geändert, geht das nicht mehr, dann trägst du den richtigen Stand von Hand ein.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Die Läufe sind in der Sicherung enthalten. Noch nicht dabei: die Frage „Motor stoppen?“ nach Ankunft, Anlegen oder Anker werfen (kommt als nächste Stufe).'
      ] },
      { version: '2.0.18', datum: '2026-11-04', punkte: [
        'Das Cockpit füllt jetzt den ganzen Bildschirm: kein Menü, kein Scrollen, große Knöpfe in drei Spalten. Oben steht, wer gerade verantwortlich ist und welcher Tag heute ist, unten der letzte Eintrag und ein paar kleine Knöpfe (Tagesabschluss, Knöpfe ändern, Logbuch und Angaben). Läuft die Aktivität, öffnet sich das Cockpit von selbst.',
        'Schnellknöpfe frei belegbar: Im Cockpit stehen bis zu 8 Knöpfe, die du je Fahrzeugart selbst wählst, dazu fest „Sonstige Ereignisse“ (3 mal 3 Knöpfe). Ein Tipp auf ein Ereignis speichert es sofort mit der Uhrzeit von jetzt. Notiz, Foto und Verantwortung wechseln sind ebenfalls frei wählbar.',
        'Alles, was nicht auf einem Knopf liegt, findest du unter „Sonstige Ereignisse“, auch Notiz, Foto und Verantwortung wechseln, wenn du sie vom Knopf genommen hast.',
        'Eingestellt wird es unter Stammdaten › Fahrzeugarten › Art › „Schnellknöpfe im Cockpit“ oder im Cockpit mit „Knöpfe ändern“. Eine Untergruppe übernimmt die Knöpfe der Obergruppe, bis du etwas Eigenes einstellst. Das Wasserskiboot kann so andere Knöpfe haben als der Katamaran.',
        'Bis du etwas einstellst, gelten die bisherigen Knöpfe: Abfahrt, Ankunft, Notiz, Foto, Verantwortung wechseln. Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Die Einstellung ist in der Sicherung enthalten.'
      ] },
      { version: '2.0.17', datum: '2026-11-04', punkte: [
        'Die Art der Aktivität richtet sich nach dem Fahrzeug: Bei jeder Art von Aktivität legst du fest, für welche Fahrzeugarten sie gilt (Baum mit Häkchen, wie bei den Ereignissen). Mit dem Wohnmobil gibt es dann zum Beispiel kein Wasserski.',
        'Logbuch jetzt starten: Neues Feld „Aktivität“. Es zeigt nur Arten, die zum gewählten Fahrzeug passen, „Ausfahrt“ ist vorausgewählt, wenn sie passt. Der Name des Logbuchs folgt der gewählten Art, zum Beispiel „Törn Kat 04.11.2026“.',
        'Auch beim Planen und Ändern einer Aktivität stehen nur die Arten zur Wahl, die zum Fahrzeug passen. Eine Art, die schon an der Aktivität hängt, bleibt wählbar.',
        'Unter „Arten von Aktivitäten“ zeigt jede Art „Gilt für: …“. Der Knopf „Vorschläge für Fahrzeugarten übernehmen“ setzt eine Starthilfe (Wasserski nur für Wasserskiboote, Segeln nur für Segelboote, Törn für Wasserfahrzeuge, Rallye für Landfahrzeuge, Urlaub und Ausfahrt für alle), aber nur dort, wo du noch nichts eingestellt hast. Alles ist jederzeit änderbar.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Ältere Arten ohne Zuordnung gelten wie bisher für alle.'
      ] },
      { version: '2.0.16', datum: '2026-11-04', punkte: [
        'Fahrzeugarten selbst verwalten: Unter Stammdaten › Fahrzeugarten siehst du den ganzen Baum. Du kannst Untergruppen anlegen (zum Beispiel Trimaran unter Segelboot oder Aufsitzrasenmäher unter Landfahrzeug), Arten umbenennen und ausblenden.',
        'Eine neue Art übernimmt die Felder und die Ereignisse der Gruppe, unter der sie steht. Bei den Arten von Ereignissen kannst du das wie gewohnt ändern.',
        'Ausblenden geht immer. Eine ausgeblendete Art (und alles darunter) bieten neue Fahrzeuge nicht mehr an, bestehende Fahrzeuge bleiben unverändert.',
        'Löschen geht nur bei Arten, die kein Fahrzeug benutzt (auch keine Untergruppe davon). Was benutzt wird, lässt sich nur ausblenden.',
        'Ungebrauchtes löschen: ein Knopf räumt den Baum auf. Er löscht alles, was kein Fahrzeug benutzt, und zeigt vorher, was weggeht. Wer nur Oldtimer braucht, behält nur die Oldtimer. Gelöschte Vorschläge lassen sich zurückholen.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Eigene Arten sind in der Sicherung enthalten.'
      ] },
      { version: '2.0.15', datum: '2026-11-04', punkte: [
        'Logbuch ohne Planung: Auf der Seite „Aktivitäten“ und beim Fahrzeug gibt es den Knopf „Logbuch jetzt starten“. Du wählst Fahrzeug und wer verantwortlich ist (Stellvertreter und Crew sind freiwillig), der Beginn ist jetzt, und das Cockpit läuft sofort. Es entsteht eine ganz normale Aktivität der Art „Ausfahrt“, mit derselben Prüfung.',
        'Ereignisse gelten für Fahrzeugarten: Bei jeder Art von Ereignis legst du fest, für welche Fahrzeugarten sie gilt. Cockpit und Logbuch zeigen dann nur die Ereignisse, die zum Fahrzeug passen. Ein Häkchen an einer Gruppe gilt für alles darunter, einzelne Arten kannst du abwählen oder wieder ankreuzen.',
        'Fahrzeugarten als Baum: Wasserfahrzeug enthält jetzt Boot mit Sportboot, Wasserskiboot, Motorboot zum Übernachten, Motorschiff und Segelboot (Monohull, Katamaran, Jolle oder Kleinboot). Bestehende Fahrzeuge der Art „Boot“ bleiben gültig. Regeln für „Boot“ gelten auch für diese Untergruppen.',
        'Neue Vorschläge für Ereignisse mit Zuordnung (Tanken, Anlegen, Ablegen, Anker werfen, Anker lichten, Schleuse, Segel setzen, Segel bergen, Wasserski-Lauf) unter „Arten von Ereignissen“. Ältere Ereignisarten gelten wie bisher für alle.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt.'
      ] },
      { version: '2.0.14', datum: '2026-11-03', punkte: [
        'Bei der Aktivität gibt es jetzt zwei Reiter: „Cockpit“ zum schnellen Eintragen unterwegs und „Logbuch“ zum Nachlesen, Korrigieren und Nachtragen. Beide zeigen dieselben Einträge. Läuft die Aktivität gerade, öffnet sich das Cockpit zuerst, sonst das Logbuch.',
        'Cockpit mit großen Knöpfen: Ein Tipp auf Abfahrt oder Ankunft speichert sofort mit der Uhrzeit von jetzt, ohne Formular. Dazu Ereignis, Notiz und Foto. Das Cockpit zeigt den heutigen Tag, die letzten Einträge und wer gerade verantwortlich ist, seit wann. Der heutige Tag wird beim ersten Eintrag von selbst angelegt.',
        'Verantwortung wechseln im Cockpit: ein Tipp auf den Namen, Zeit jetzt. Die App prüft dabei die Befähigung der übernehmenden Person und hält das Ergebnis mit „geprüft am“ beim Wechsel fest. Sie weist nur hin und sperrt nichts. Ein vergessener Wechsel lässt sich mit der echten Uhrzeit nachtragen.',
        'Nachtrag wird erkannt: Weicht die Uhrzeit um mehr als 5 Minuten von jetzt ab, steht das Ereignis automatisch als „nachgetragen am …“ da. Der Knopf „Nachtragen“ bleibt.',
        'Klassisches Logbuch: alle Tage und Ereignisse der Reihe nach wie auf Papier, mit der festgehaltenen Prüfung zum Tagesbeginn beim Tag. Hier wird geändert, nachgetragen und ausgeblendet. Der Verlauf bleibt erhalten, nichts wird gelöscht.',
        'Tagesabschluss: tatsächliches Ziel und eine Notiz zum Tag. Der Zählerstand am Ende kommt später mit dem Schritt „Zähler automatisch“.',
        'Größere Knöpfe und klarere Gestaltung für Tablet und Smartphone.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt.'
      ] },
      { version: '2.0.13', datum: '2026-11-03', punkte: [
        'Logbuch-Kern an der Aktivität: Ein Tagesabschnitt je Tag mit Datum, Beginn und Ende (Uhrzeit freiwillig), von wo nach wo (als Text) und Notiz.',
        'Die App bereitet die Tage aus dem Zeitraum der Aktivität auf Knopfdruck vor. Jeder Tag lässt sich ändern, von Hand ergänzen und ausblenden. Nichts wird gelöscht.',
        'Prüfung zum Tagesbeginn: Die Prüfung der Aktivität wird für den Tag festgehalten, mit „geprüft am“ und dem Verantwortlichen dieses Tages. Spätere Änderungen verändern das Festgehaltene nicht.',
        'Ereignisse in einem Tag: Zeitpunkt, Art, Text und ein Foto, alles außer Zeitpunkt und Art freiwillig. Die Arten sind eine offene Liste mit Vorschlägen (Abfahrt, Ankunft, Wechsel des Verantwortlichen, Störung, Notiz).',
        'Ein Wechsel des Verantwortlichen erscheint von selbst als Ereignis. Du kannst Zeitpunkt und Notiz korrigieren, der frühere Stand bleibt im Verlauf. Die Verantwortung der Aktivität folgt der Korrektur.',
        'Nachtragen: Ein Ereignis mit dem echten Zeitpunkt später eintragen. Es steht dann als „nachgetragen am …“ da.',
        'Bestehende Daten und Sicherungen bleiben gültig. Die Sicherung enthält Tage, Ereignisse, Prüfungen und Fotos.',
        'Noch nicht dabei: Wetter und Wegpunkte, Motor Start und Stopp, Störung als Werkstattvorgang, Orte als Start und Ziel, Kosten.'
      ] },
      { version: '2.0.12', datum: '2026-11-03', punkte: [
        'Komponenten haben eine Anzahl (zum Beispiel 6 Rettungswesten) und den Haken „Eignung geprüft“.',
        'Regeln für Pflichtausrüstung nennen jetzt eine Menge, die Bezugsgröße (je Fahrzeug oder je Person an Bord) und freiwillig die geforderte Eignung, zum Beispiel „Automatik, 150 N“.',
        'Die Prüfung bei der Aktivität vergleicht Soll und Ist und nennt die Zahlen, zum Beispiel „Eingetragen sind 5, Soll ist 6“. Bei „je Person“ zählt die Besatzung der Aktivität.',
        'Fehlt bei geforderter Eignung der Haken, sagt die Prüfung „unklar“. Die App prüft die Eignung nicht selbst.',
        'Bestehende Regeln und Komponenten bleiben gültig und ändern ihr Ergebnis nicht.'
      ] },
      { version: '2.0.11', datum: '2026-11-03', punkte: [
        'Orte: zusätzlich Adresse, Ansprechpartner und Telefon.',
        'Standorte: zusätzlich Länge, Breite, Tiefe und Höhe des Platzes.',
        'Regeln für Pflichtausrüstung: Zu einem Gebiet legst du fest, was am Fahrzeug sein muss, zum Beispiel Rettungsweste oder Feuerlöscher, wahlweise nur für bestimmte Fahrzeugarten.',
        'Die Prüfung bei der Aktivität zeigt die Pflichtausrüstung des Gebiets. Sie sucht in den eingetragenen Komponenten des Fahrzeugs. Ist etwas nicht eingetragen, sagt sie „unklar“ und nicht „fehlt“, weil sie nicht weiß, was wirklich an Bord liegt.',
        'Befähigung und Pflichtausrüstung sind zwei Arten von Regeln im selben Gebiet. Die Regeln sind weiter von dir eingetragen.'
      ] },
      { version: '2.0.10', datum: '2026-11-03', punkte: [
        'Orte und Standorte: Ein Ort (zum Beispiel ein Hafen) hat Standorte (zum Beispiel Liegeplatz 12). Alles gehört deinem eigenen Datenraum.',
        'Heimatstandort am Fahrzeug: Du wählst ihn aus deinen Standorten. Änderungen bleiben im Verlauf sichtbar.',
        'Gebiete mit Regeln: Eine Regel sagt „Wenn Gebiet, Fahrzeugart und Ausrüstung passen, genügt einer dieser Nachweise“. Die Regeln sind von dir eingetragen.',
        'Bei der Aktivität wählst du das Gebiet aus der Liste. Die Prüfung nutzt die Regeln des Gebiets zusätzlich zu den Anforderungen am Fahrzeug.',
        'Kennt die App für ein Gebiet und dein Fahrzeug keine Regel, sagt sie höchstens „unklar“ und nie „erlaubt“.',
        'Noch nicht dabei: Quelle und Prüfdatum je Regel, Reisecheck, weitere Länder.'
      ] },
      { version: '2.0.9', datum: '2026-11-03', punkte: [
        'Sicherungsdatei: ein Tipp erstellt eine Datei mit allen deinen Daten. Sie lässt sich speichern oder teilen, zum Beispiel in die Cloud.',
        'Wahlweise mit Schlüsselwort verschlüsselt. Darin stehen auch Ausweisdaten und Scans.',
        'Dokumente und Scans kannst du mitsichern oder weglassen. Vorher siehst du, wie groß es wird.',
        'Wiederherstellen: Die App zeigt zuerst, was in der Sicherung steht und was ersetzt wird. Erst nach deiner Bestätigung wird etwas verändert, und zwar ganz oder gar nicht.',
        'Die App erinnert an die Sicherung, nach 14, 30 oder 90 Tagen oder gar nicht.'
      ] },
      { version: '2.0.8', datum: '2026-11-03', punkte: [
        'Aktivitäten (Urlaub, Törn, Ausfahrt, Wasserski, Segeln, Rallye): Name, Art, Fahrzeug, Zeitraum mit freiwilliger Uhrzeit, Gebiet, geplante Strecke oder Betriebsstunden, Tiere und Notiz.',
        'Besatzung aus den Personen: Skipper oder Fahrer, Stellvertreter und Crew. Jede Person steht einmal da, bei Bedarf mit „dabei von bis“.',
        'Zu jedem Zeitpunkt ist genau eine Person verantwortlich. Jeder Wechsel wird mit Zeitpunkt festgehalten.',
        'Prüfung bei der Planung: Befähigung von Skipper oder Fahrer und Stellvertretern (erlaubt, nicht erlaubt, unklar, mit „geprüft am“), Fristen bis zum Ende des Zeitraums und Überschneidungen am Fahrzeug.',
        'Am Fahrzeug legst du fest, welche Nachweise ein Skipper oder Fahrer braucht.',
        'Aktivitäten lassen sich jederzeit stornieren und wiederherstellen. Nichts wird gelöscht.'
      ] },
      { version: '2.0.7', datum: '2026-11-03', punkte: [
        'Personen mit Funktionen (Skipper, Fahrer, Crew, Beifahrer, Gast) und Tiere mit Tierart und Chipnummer.',
        'Nachweise an Personen, Tieren und Fahrzeugen, mit „gültig bis“, Status und optionalem Scan oder Foto, das nur auf dem Gerät bleibt.',
        'Die Liste der Nachweisarten ist offen: Du legst eigene Arten an oder übernimmst Vorschläge für Deutschland und die EU. Jeder Vorschlag nennt seine Quelle und wie weit er geprüft ist.',
        'Vorschläge: Führerschein, Personalausweis, Reisepass, Sportbootführerschein, Funkzeugnisse, Heimtierausweis, Tollwutimpfung, Zulassungsbescheinigung Teil I und II, Hauptuntersuchung, Internationaler Bootsschein und mehr.',
        'Die Fahrzeugliste zeigt auch abgelaufene und bald ablaufende Nachweise.'
      ] },
      { version: '2.0.6', datum: '2026-11-03', punkte: [
        'Dokumente an Fahrzeug und Komponente: Bedienungsanleitung, Ersatzteilliste, Wartungsanleitung, Kaufbeleg, Garantie, Foto oder Sonstiges.',
        'Als Datei vom Gerät (auch ohne Internet da) oder als Link ins Internet.',
        'Am Fahrzeug gibt es eine Gesamtliste aller Dokumente, nach Komponente geordnet und mit Suche.',
        'In den Einstellungen siehst du, wie viel Speicher die Dokumente belegen und wie viel Platz der Browser erlaubt.'
      ] },
      { version: '2.0.5', datum: '2026-11-03', punkte: [
        'Fristen am Fahrzeug und an jeder Komponente: nach Zeit (Monate oder Jahre), nach Zähler (Strecke oder Betriebsstunden) oder nach beidem. Was zuerst eintritt, löst die Fälligkeit aus.',
        'Zähler am Fahrzeug oder pro Komponente, zum Beispiel pro Motor, mit Verlauf der Zählerstände.',
        'Jede Frist zeigt, ob sie in Ordnung, bald fällig oder überfällig ist. In der Fahrzeugliste siehst du es auf einen Blick.',
        'Wirkung bei Überfälligkeit (nur warnen, eingeschränkt, Sperre) und Vorwarnung sind einstellbar.',
        '„Erledigt eintragen“ setzt die Rechnung einer Frist neu an, frühere Erledigungen bleiben sichtbar.'
      ] },
      { version: '2.0.4', datum: '2026-11-03', punkte: [
        'Hauptkomponenten (Schale 3): Motor, Getriebe, Heizung, Klima, Stromversorgung, Wasserversorgung und Sonstiges.',
        'Darunter lässt sich beliebig tief aufschlüsseln, zum Beispiel Motor, Einspritzung, Pumpe.',
        'Zu jedem Teil: Hersteller, Modell, Seriennummer, Baujahr, Einbau, Ausbau und technische Merkmale.',
        'Änderungen bleiben wie beim Fahrzeug im Verlauf sichtbar.',
        'Wenn eine neue Version bereitsteht, erscheint ein Hinweis zum Neuladen.'
      ] },
      { version: '2.0.3', datum: '2026-11-03', punkte: [
        'Startseite neu gestaltet: Die Buchstaben V, T und D des Logos stehen vor den drei Teilen des Kernsatzes.',
        'Infotext: „Reisen planen“.',
        'Das Logo ist an einer einzigen Stelle abgelegt und gilt auf der Startseite, in der Kopfzeile und als App-Symbol.'
      ] },
      { version: '2.0.2', datum: '2026-11-03', punkte: [
        'Startseite mit Logo, Kernsatz und den Knöpfen „Programm starten“ und „Neu im Programm“.',
        'Hauptmenü mit Stammdaten, Funktionen und Einstellungen.',
        'Stammdaten mit den Fahrzeugen. Personen und Tiere folgen.',
        'Einstellungen mit Hinweisen zu deinen Daten.'
      ] },
      { version: '2.0.1', datum: '2026-11-03', punkte: [
        'Fahrzeugliste und äußere Hülle für sieben Fahrzeugarten.',
        'Eingaben von Hand, jede Änderung bleibt im Verlauf sichtbar.',
        'Funktioniert ohne Internet, die Daten liegen auf dem Gerät.'
      ] }
    ]
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
