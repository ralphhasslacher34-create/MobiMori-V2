/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.26';
  MM.STUFE = 'Werkstatt: Dokumente und Bilder am Vorgang, Störung im Logbuch';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
