/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.30';
  MM.STUFE = 'Import und Export: Fahrzeuge aus Excel oder CSV übernehmen, Fahrzeuge, Kosten und Orte als Excel oder CSV ausgeben';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
