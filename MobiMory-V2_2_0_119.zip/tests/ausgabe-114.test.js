'use strict';
/* 2.0.114: Speichern, Teilen und Öffnen in der Android-Hülle, Ablegen/Anlegen bei Wasserfahrzeugen, keine Peilung mehr, Über MobiMory ohne Satz. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

['version', 'texte', 'huelle', 'karte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status', 'motoren',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'reisecheck', 'grundcheck', 'konto', 'austausch', 'daten']
  .forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

function huelleMit(aufrufe, optionen) {
  const o = optionen || {};
  const plugins = {
    Filesystem: {
      rmdir: async (a) => { aufrufe.push(['rmdir', a.path, a.directory]); },
      writeFile: async (a) => { aufrufe.push(['write', a.path, a.directory, Buffer.from(a.data, 'base64')]); return { uri: 'file:///data/user/0/com.mobimory.app/cache/' + a.path }; }
    },
    Share: { share: async (a) => { aufrufe.push(['share', a.files[0], a.title]); if (o.abbruch) throw new Error('Share canceled'); } },
    FileOpener: { open: async (a) => { aufrufe.push(['open', a.filePath, a.contentType, a.openWithDefault]); } }
  };
  return MM.Huelle.erzeugen({ btoa: globalThis.btoa, Capacitor: { isNativePlatform: () => true, registerPlugin: (n) => plugins[n] } });
}

test('Hülle: Datei wird in den Zwischenspeicher geschrieben und über das Teilen-Fenster ausgegeben', async () => {
  const a = []; const h = huelleMit(a);
  assert.equal(h.dateienVerfuegbar(), true);
  const r = await h.dateiAusgeben(new Uint8Array([0, 1, 2, 250, 255]), 'MobiMory-Sicherung.mmsicherung', 'application/octet-stream', 'teilen');
  assert.deepEqual(r, { ok: true, modus: 'teilen' });
  assert.deepEqual(a.map((x) => x[0]), ['rmdir', 'write', 'share']);
  assert.equal(a[1][2], 'CACHE');
  assert.deepEqual([...a[1][3]], [0, 1, 2, 250, 255], 'die Bytes kommen unverändert an');
  assert.equal(a[2][1], 'file:///data/user/0/com.mobimory.app/cache/ausgabe/MobiMory-Sicherung.mmsicherung');
});

test('Hülle: Text (GPX), Blob und ArrayBuffer werden richtig geschrieben, Umlaute bleiben', async () => {
  const a = []; const h = huelleMit(a);
  await h.dateiAusgeben('<gpx>Süd</gpx>', 'r.gpx', 'application/gpx+xml');
  assert.equal(a.find((x) => x[0] === 'write')[3].toString('utf8'), '<gpx>Süd</gpx>');
  const b = []; const h2 = huelleMit(b);
  await h2.dateiAusgeben(new Blob([new Uint8Array([9, 8, 7])]), 'x.bin', 'application/octet-stream');
  assert.deepEqual([...b.find((x) => x[0] === 'write')[3]], [9, 8, 7]);
  const c = []; const h3 = huelleMit(c);
  await h3.dateiAusgeben(new Uint8Array([1, 2, 3]).buffer, 'y.bin');
  assert.deepEqual([...c.find((x) => x[0] === 'write')[3]], [1, 2, 3]);
});

test('Hülle: große Dateien (mehrere MB) gehen durch', async () => {
  const a = []; const h = huelleMit(a);
  const gross = new Uint8Array(3 * 1024 * 1024).map((_, i) => i % 251);
  await h.dateiAusgeben(gross, 'gross.pdf', 'application/pdf');
  const raus = a.find((x) => x[0] === 'write')[3];
  assert.equal(raus.length, gross.length); assert.equal(raus[123456], gross[123456]);
});

test('Hülle: Öffnen übergibt den Pfad ohne file:// und die Art der Datei', async () => {
  const a = []; const h = huelleMit(a);
  const r = await h.dateiAusgeben(new Uint8Array([1]), 'Rechnung.pdf', 'application/pdf', 'oeffnen');
  assert.deepEqual(r, { ok: true, modus: 'oeffnen' });
  const o = a.find((x) => x[0] === 'open');
  assert.equal(o[1], '/data/user/0/com.mobimory.app/cache/ausgabe/Rechnung.pdf'); assert.equal(o[2], 'application/pdf'); assert.equal(o[3], true);
  assert.ok(!a.some((x) => x[0] === 'share'));
});

test('Hülle: Dateinamen werden bereinigt, Abbruch im Teilen-Fenster wird als Ablehnung weitergegeben', async () => {
  const h = huelleMit([]);
  assert.equal(h.dateiname('a/b\\c:d*e?.pdf'), 'a_b_c_d_e_.pdf'); assert.equal(h.dateiname('..'), 'datei'); assert.equal(h.dateiname(''), 'datei');
  const a = []; const h2 = huelleMit(a, { abbruch: true });
  await assert.rejects(h2.dateiAusgeben(new Uint8Array([1]), 'a.pdf', 'application/pdf'), /cancel/i);
});

test('Im Browser tut die Ausgabe nichts und meldet es', async () => {
  const b = MM.Huelle.erzeugen({});
  assert.equal(b.dateienVerfuegbar(), false);
  await assert.rejects(b.dateiAusgeben(new Uint8Array([1]), 'a.pdf'), /nicht da/);
});

test('Code: alle Wege zum Speichern, Öffnen und Teilen prüfen die Hülle, Browser-Weg bleibt', () => {
  const a = lesen('js/ansicht.js');
  assert.match(a, /function inHuelle\(\)/); assert.match(a, /function huelleAusgeben\(/);
  const ds = a.slice(a.indexOf('  function dateiSpeichern('), a.indexOf('  function seiteSichern('));
  assert.match(ds, /if \(inHuelle\(\)\) \{ huelleAusgeben\(bytes, name/); assert.match(ds, /createObjectURL/);
  const dO = a.slice(a.indexOf('  function dateiOeffnen('), a.indexOf('  /* ---------- Seite: Dokument ----------'));
  assert.match(dO, /inHuelle\(\)/); assert.match(dO, /speichern \? 'teilen' : 'oeffnen'/); assert.match(dO, /global\.open\(url/);
  const gz = a.slice(a.indexOf('  function geteiltDateiZeile('), a.indexOf('  /* Die Ansicht eines freigegebenen Fahrzeugs.'));
  assert.match(gz, /inHuelle\(\)/); assert.match(gz, /sichern \? 'teilen' : 'oeffnen'/);
  assert.match(lesen('css/styles.css'), /\.kurzmeldung \{/);
});

test('Plugins: package.json, Lock-Datei und Hülle kennen Filesystem, Share und File-Opener', () => {
  const p = JSON.parse(lesen('package.json')), l = JSON.parse(lesen('package-lock.json'));
  ['@capacitor/filesystem', '@capacitor/share', '@capacitor-community/file-opener'].forEach((n) => {
    assert.ok(p.devDependencies[n], n);
    assert.ok(l.packages['node_modules/' + n], 'Lock: ' + n);
  });
  assert.equal(l.version, '2.0.119'); assert.equal(l.packages[''].version, '2.0.119');
  assert.ok(!lesen('sw.js').includes('huelle-datei'), 'keine neue Hülle-Datei in der Service-Worker-Liste nötig');
});

test('Ablegen und Anlegen: Wasserfahrzeuge bekommen sie als Standard-Knöpfe, Landfahrzeuge Abfahrt und Ankunft', async () => {
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(2026, 10, 19, 8, 0, 0).toISOString() });
  await d.starten();
  const boot = await d.schnellknoepfeFuerFahrzeugart('boot');
  const bn = boot.knoepfeAlle.map((k) => k.name);
  assert.deepEqual(bn.slice(0, 2), ['Ablegen', 'Anlegen']);
  assert.ok(!bn.includes('Abfahrt') && !bn.includes('Ankunft'));
  assert.ok(!boot.angebot.alle.some((x) => x.name === 'Abfahrt' || x.name === 'Ankunft'), 'auch nicht unter „Sonstige Ereignisse“');
  const auto = await d.schnellknoepfeFuerFahrzeugart('auto');
  const an = auto.knoepfeAlle.map((k) => k.name);
  assert.deepEqual(an.slice(0, 2), ['Abfahrt', 'Ankunft']);
  assert.ok(!an.includes('Ablegen') && !an.includes('Anlegen'));
  const arten = (await d.ereignisartenListe()).map((x) => x.aktuell.werte.bezeichnung);
  assert.equal(arten.filter((n) => n === 'Ablegen').length, 1); assert.equal(arten.filter((n) => n === 'Anlegen').length, 1);
  await d.schnellknoepfeFuerFahrzeugart('segelboot-katamaran');
  assert.equal((await d.ereignisartenListe()).filter((x) => x.aktuell.werte.bezeichnung === 'Ablegen').length, 1, 'es gibt sie nur einmal');
});

test('Ablegen und Anlegen: der Status des Boots wechselt (Festgemacht → In Fahrt → Festgemacht), Abfahrt gilt beim Boot nicht', () => {
  const S = MM.Status;
  const ablegen = S.regelFuer({ bezeichnung: 'Ablegen' }, 'wasser'), anlegen = S.regelFuer({ bezeichnung: 'Anlegen' }, 'wasser'), abfahrt = S.regelFuer({ bezeichnung: 'Abfahrt' }, 'wasser');
  const arten = { ablegen: { bezeichnung: 'Ablegen' }, anlegen: { bezeichnung: 'Anlegen' } };
  const ev = (art, zeit) => ({ artName: art, zeitpunkt: zeit });
  const st0 = S.rechnen([], arten, 'wasser', '2026-11-19T12:00');
  assert.equal(st0.wirksam, 'festgemacht');
  assert.equal(S.pruefen(ablegen, st0, []).erlaubt, true);
  const st1 = S.rechnen([ev('Ablegen', '2026-11-19T09:00')], arten, 'wasser', '2026-11-19T12:00');
  assert.equal(st1.wirksam, 'in-fahrt');
  const st2 = S.rechnen([ev('Ablegen', '2026-11-19T09:00'), ev('Anlegen', '2026-11-19T11:00')], arten, 'wasser', '2026-11-19T12:00');
  assert.equal(st2.wirksam, 'festgemacht');
  const mitAbfahrt = S.rechnen([ev('Abfahrt', '2026-11-19T09:00')], { abfahrt: { bezeichnung: 'Abfahrt' } }, 'wasser', '2026-11-19T12:00');
  assert.equal(mitAbfahrt.wirksam, 'festgemacht', 'mit „Abfahrt“ blieb das Boot auf Festgemacht (der Fehler, den es vor 2.0.114 gab)');
  assert.equal(abfahrt, null);
});

test('Peilung auf eine Tonne ist ersatzlos entfernt', () => {
  ['js/ansicht.js', 'js/daten.js', 'js/logbuch.js', 'js/kartenansicht.js', 'js/kartenereignisse.js', 'css/styles.css', 'js/texte.js'].forEach((f) => {
    assert.ok(!/peilung/i.test(lesen(f)), f + ' enthält noch „Peilung“');
  });
  assert.equal(MM.Logbuch.PEILUNG_ART, undefined); assert.equal(MM.Daten.Daten.prototype.peilungEintragen, undefined);
  assert.ok(!/peilung/i.test(MM.Texte.NEUERUNGEN.map((n) => n.punkte.join(' ')).join(' ')));
});

test('Über MobiMory: nur die Versionsnummer, kein langer Satz mehr', () => {
  assert.equal(MM.STUFE, undefined);
  assert.ok(!lesen('js/version.js').includes('STUFE'));
  assert.ok(lesen('js/ansicht.js').includes("h('p', { text: 'Version ' + MM.VERSION }),"));
  assert.equal(MM.VERSION, '2.0.119');
});
