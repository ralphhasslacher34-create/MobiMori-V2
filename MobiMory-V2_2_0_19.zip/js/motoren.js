/*
 * Motoren: Rechnung für die Motorschalter (Start und Stopp) und die Betriebsstunden.
 *
 * Aus den V2-Festlegungen (Schritt 6, Zähler automatisch):
 *  - Jeder Motor hat seinen eigenen Schalter und Zähler, es gibt keinen Sammelschalter „alle“.
 *  - Motor aus: Schalter grau, mit Namen und „Start“. Motor läuft: Schalter rot, mit „Stopp“.
 *  - Bis zu zwei Motoren haben einen festen Schalter in der unteren Leiste des Cockpits.
 *    Ab drei Motoren steht dort ein einziger Schalter „Motoren“ (mit der Zahl der laufenden),
 *    der eine Liste mit allen Motoren und deren Schaltern öffnet.
 *  - Die Handeingabe bleibt übergeordnet; eine Korrektur ist jederzeit möglich.
 *
 * Hier steht nur Rechnung und Beschreibung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Bis zu so vielen Motoren hat jeder einen eigenen Schalter in der Leiste. */
  var MAX_EINZELN = 2;
  var MS_STUNDE = 3600 * 1000;

  function runde(n) { return Math.round(n * 100) / 100; }

  /* Betriebsstunden zwischen zwei Zeitpunkten (ISO), auf zwei Stellen gerundet. Null bei Unsinn. */
  function laufStunden(startIso, stoppIso) {
    var a = new Date(startIso).getTime(), b = new Date(stoppIso).getTime();
    if (isNaN(a) || isNaN(b)) return null;
    if (b < a) return null;
    return runde((b - a) / MS_STUNDE);
  }

  /* 1,42 h -> „1 h 25 min“, 0,2 h -> „12 min“ */
  function stundenText(stunden) {
    var min = Math.round(Number(stunden) * 60);
    if (!isFinite(min) || min < 0) return '';
    var h = Math.floor(min / 60), m = min % 60;
    if (h === 0) return m + ' min';
    return h + ' h' + (m ? ' ' + m + ' min' : '');
  }

  /* Dauer in Millisekunden -> Text („1 h 25 min“) */
  function dauerText(ms) { return stundenText(ms / MS_STUNDE); }

  /* Ortszeit (Datum und Uhrzeit, wie im Formular) -> ISO-Zeitpunkt. Null, wenn die Angabe nicht stimmt. */
  function zeitpunktAusOrtszeit(datum, zeit) {
    var d = /^(\d{4})-(\d{2})-(\d{2})$/.exec(datum || ''), z = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(zeit || '');
    if (!d || !z) return null;
    var t = new Date(+d[1], +d[2] - 1, +d[3], +z[1], +z[2], 0, 0);
    if (t.getFullYear() !== +d[1] || t.getMonth() !== +d[2] - 1 || t.getDate() !== +d[3]) return null;
    return t.toISOString();
  }

  function zwei(n) { return (n < 10 ? '0' : '') + n; }
  /* ISO-Zeitpunkt -> Datum (JJJJ-MM-TT) und Uhrzeit (HH:MM) in Ortszeit */
  function ortsdatum(iso) { var t = new Date(iso); return t.getFullYear() + '-' + zwei(t.getMonth() + 1) + '-' + zwei(t.getDate()); }
  function ortszeit(iso) { var t = new Date(iso); return zwei(t.getHours()) + ':' + zwei(t.getMinutes()); }

  /*
   * Wie sieht die untere Leiste des Cockpits aus?
   *  keine:   kein Motor in den Komponenten (kein Schalter)
   *  einzeln: ein bis zwei Motoren, je ein fester Schalter
   *  sammel:  drei oder mehr Motoren, ein Schalter „Motoren“ mit „x von y laufen“
   * motoren: Liste mit dem Feld „laeuft“.
   */
  function leiste(motoren) {
    var liste = motoren || [];
    var laufen = liste.filter(function (m) { return m.laeuft; }).length;
    var modus = !liste.length ? 'keine' : (liste.length <= MAX_EINZELN ? 'einzeln' : 'sammel');
    var text = null;
    if (modus === 'sammel') text = laufen === 0 ? 'keiner läuft' : laufen + ' von ' + liste.length + ' laufen';
    return { modus: modus, laufen: laufen, gesamt: liste.length, text: text };
  }

  /* Beschriftung eines Schalters: Name und „Start“ oder „Stopp“, dazu der Zustand für die Farbe. */
  function schalter(motor) {
    return { name: motor.kurz, aktion: motor.laeuft ? 'Stopp' : 'Start', zustand: motor.laeuft ? 'laeuft' : 'aus' };
  }

  /* Kurznamen, die bei mehreren Motoren eines Fahrzeugs gleich sind (Hinweis, damit Schalter nicht verwechselt werden). */
  function doppelteKurznamen(motoren) {
    var zaehl = {};
    (motoren || []).forEach(function (m) { var k = String(m.kurz).toUpperCase(); zaehl[k] = (zaehl[k] || 0) + 1; });
    return Object.keys(zaehl).filter(function (k) { return zaehl[k] > 1; });
  }

  MM.Motoren = {
    MAX_EINZELN: MAX_EINZELN,
    laufStunden: laufStunden,
    stundenText: stundenText,
    dauerText: dauerText,
    zeitpunktAusOrtszeit: zeitpunktAusOrtszeit,
    ortsdatum: ortsdatum,
    ortszeit: ortszeit,
    leiste: leiste,
    schalter: schalter,
    doppelteKurznamen: doppelteKurznamen,
    runde: runde
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
