-- MobiMory Konto-Dienst, Schritt 13a (seit 2.0.64)
-- In der Cloudflare-Datenbank (D1) einmal ausführen. Mehrfaches Ausführen schadet nicht.
-- Gespeichert wird nur das Nötige: E-Mail-Adresse, Passwort-Abdruck (nie das Passwort selbst),
-- Sitzungen (nur ein Abdruck des Schlüssels), Codes (nur ein Abdruck) und Zähler gegen Durchprobieren.

CREATE TABLE IF NOT EXISTS nutzer (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  passwort_hash TEXT,
  passwort_wartend TEXT,
  erstellt_am INTEGER NOT NULL,
  bestaetigt_am INTEGER,
  letzte_anmeldung INTEGER
);

-- Jeder Nutzer hat genau einen eigenen Datenraum (auch kostenlos).
CREATE TABLE IF NOT EXISTS datenraum (
  id TEXT PRIMARY KEY,
  nutzer_id TEXT NOT NULL UNIQUE REFERENCES nutzer(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  erstellt_am INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sitzung (
  token_hash TEXT PRIMARY KEY,
  nutzer_id TEXT NOT NULL REFERENCES nutzer(id) ON DELETE CASCADE,
  erstellt_am INTEGER NOT NULL,
  laeuft_ab INTEGER NOT NULL,
  geraet TEXT
);
CREATE INDEX IF NOT EXISTS sitzung_nutzer ON sitzung(nutzer_id);

CREATE TABLE IF NOT EXISTS code (
  email TEXT PRIMARY KEY,
  zweck TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  laeuft_ab INTEGER NOT NULL,
  versuche INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS drossel (
  schluessel TEXT PRIMARY KEY,
  anzahl INTEGER NOT NULL,
  fenster_bis INTEGER NOT NULL
);

-- ===== Schritt 13b (seit 2.0.65): Abgleich zwischen Geräten und verschlüsselte Sicherung =====
-- Diese Tabellen kommen zu den fünf oben dazu. Vorhandene Daten bleiben. Mehrfaches Ausführen schadet nicht.

-- Zähler der Änderungen je Datenraum und eine Kennung, die sich ändert, wenn der Datenraum auf dem Server geleert wird.
CREATE TABLE IF NOT EXISTS abgleich_stand (
  datenraum_id TEXT PRIMARY KEY REFERENCES datenraum(id) ON DELETE CASCADE,
  seq INTEGER NOT NULL DEFAULT 0,
  epoche TEXT NOT NULL
);

-- Ein Datensatz je Objekt. „nutzlast“ ist der Text, den die App schickt (ohne die Angaben, die lokal bleiben). Gelöschtes bleibt als Marke.
CREATE TABLE IF NOT EXISTS abgleich (
  datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE,
  tabelle TEXT NOT NULL,
  objekt_id TEXT NOT NULL,
  seq INTEGER NOT NULL,
  geloescht INTEGER NOT NULL DEFAULT 0,
  fahrzeug_id TEXT,
  nutzlast TEXT,
  geaendert_am INTEGER NOT NULL,
  PRIMARY KEY (datenraum_id, tabelle, objekt_id)
);
CREATE INDEX IF NOT EXISTS abgleich_seq ON abgleich(datenraum_id, seq);

-- Verschlüsselte Sicherung der App. Der Dienst sieht nur Größe und Zeit, nie den Inhalt (er ist mit dem Schlüsselwort des Nutzers verschlüsselt).
CREATE TABLE IF NOT EXISTS sicherung (
  id TEXT PRIMARY KEY,
  datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE,
  erstellt_am INTEGER NOT NULL,
  app TEXT,
  groesse INTEGER NOT NULL,
  teile INTEGER NOT NULL,
  summe TEXT NOT NULL,
  fertig INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS sicherung_raum ON sicherung(datenraum_id);

CREATE TABLE IF NOT EXISTS sicherungsteil (
  sicherung_id TEXT NOT NULL REFERENCES sicherung(id) ON DELETE CASCADE,
  nr INTEGER NOT NULL,
  daten TEXT NOT NULL,
  PRIMARY KEY (sicherung_id, nr)
);

-- ===== Schritt 13d (seit 2.0.66): Dateien in R2 =====
-- Eine Zeile je Datei, die im Dateispeicher (R2) liegt. Der Inhalt selbst liegt nicht in der Datenbank.
-- Diese Anweisung steht bewusst in einer einzigen Zeile (für die D1-Console am Tablet). Mehrfaches Ausführen schadet nicht.
CREATE TABLE IF NOT EXISTS datei (datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, tabelle TEXT NOT NULL, objekt_id TEXT NOT NULL, groesse INTEGER NOT NULL, verschluesselt INTEGER NOT NULL DEFAULT 0, erstellt_am INTEGER NOT NULL, PRIMARY KEY (datenraum_id, tabelle, objekt_id));

-- ===== Schritt 13c (seit 2.0.67): Freigaben und Kontroll-Freigabe =====
-- Eine Freigabe: Fahrzeug, E-Mail-Adresse des Gastes, Zeitraum, Abdruck des Codes (nie der Code selbst). Eine Kontroll-Freigabe: kurzer Code für Kontrollen.
-- Diese Anweisungen stehen bewusst je in einer einzigen Zeile (für die D1-Console am Tablet; Datei server/13c.sql). Mehrfaches Ausführen schadet nicht.
CREATE TABLE IF NOT EXISTS freigabe (id TEXT PRIMARY KEY, datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, fahrzeug_id TEXT NOT NULL, email TEXT NOT NULL, code_hash TEXT NOT NULL, gast_nutzer_id TEXT REFERENCES nutzer(id) ON DELETE CASCADE, erstellt_am INTEGER NOT NULL, ab_am INTEGER NOT NULL, laeuft_ab INTEGER NOT NULL, einladung_bis INTEGER NOT NULL, angenommen_am INTEGER, widerrufen_am INTEGER);
CREATE INDEX IF NOT EXISTS freigabe_raum ON freigabe(datenraum_id);
CREATE INDEX IF NOT EXISTS freigabe_gast ON freigabe(gast_nutzer_id);
CREATE INDEX IF NOT EXISTS freigabe_code ON freigabe(code_hash);
CREATE TABLE IF NOT EXISTS kontrolle (id TEXT PRIMARY KEY, datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, fahrzeug_id TEXT NOT NULL, code_hash TEXT NOT NULL, erstellt_am INTEGER NOT NULL, laeuft_ab INTEGER NOT NULL, widerrufen_am INTEGER);
CREATE INDEX IF NOT EXISTS kontrolle_raum ON kontrolle(datenraum_id);
CREATE INDEX IF NOT EXISTS kontrolle_code ON kontrolle(code_hash);

-- 13e (seit 2.0.68): Stufen, Testwoche, Online-Checks und die gespeicherten Ergebnisse
CREATE TABLE IF NOT EXISTS stufe_konto (nutzer_id TEXT PRIMARY KEY REFERENCES nutzer(id) ON DELETE CASCADE, stufe TEXT NOT NULL, gueltig_bis INTEGER, geaendert_am INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS testwoche (email_hash TEXT PRIMARY KEY, nutzer_id TEXT NOT NULL, start_am INTEGER NOT NULL, ende_am INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS testwoche_nutzer ON testwoche(nutzer_id);
CREATE TABLE IF NOT EXISTS check_nutzung (id TEXT PRIMARY KEY, datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, art TEXT NOT NULL, stufe TEXT NOT NULL, am INTEGER NOT NULL, status TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS check_nutzung_raum ON check_nutzung(datenraum_id, am);
CREATE TABLE IF NOT EXISTS check_ergebnis (schluessel TEXT PRIMARY KEY, art TEXT NOT NULL, antwort TEXT NOT NULL, erstellt_am INTEGER NOT NULL);

-- 13e-3 (seit 2.0.71): Kosten-Wächter, merkt sich, wann die letzte Warn-Mail rausging
CREATE TABLE IF NOT EXISTS waechter_stand (schluessel TEXT PRIMARY KEY, wert INTEGER NOT NULL);

-- 13e-4 (seit 2.0.72): Bezahlung. Jede Zeile einzeln in der D1-Console ausführen (steht auch in 13e-4.sql).
CREATE TABLE IF NOT EXISTS bestellung (id TEXT PRIMARY KEY, nutzer_id TEXT NOT NULL REFERENCES nutzer(id) ON DELETE CASCADE, email TEXT NOT NULL, produkt TEXT NOT NULL, cent INTEGER NOT NULL, weg TEXT NOT NULL, paypal_id TEXT, erstellt_am INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS bestellung_nutzer ON bestellung(nutzer_id);
CREATE TABLE IF NOT EXISTS beleg (nummer TEXT PRIMARY KEY, am INTEGER NOT NULL, email TEXT NOT NULL, produkt TEXT NOT NULL, cent INTEGER NOT NULL, weg TEXT NOT NULL, referenz TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS check_extra (nutzer_id TEXT PRIMARY KEY REFERENCES nutzer(id) ON DELETE CASCADE, anzahl INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS erinnerung (nutzer_id TEXT NOT NULL REFERENCES nutzer(id) ON DELETE CASCADE, gueltig_bis INTEGER NOT NULL, tage INTEGER NOT NULL, PRIMARY KEY (nutzer_id, gueltig_bis, tage));
CREATE TABLE IF NOT EXISTS zaehler (schluessel TEXT PRIMARY KEY, wert INTEGER NOT NULL);

-- 13e-5 (seit 2.0.73): Rollen-Tabelle. Admin und Entwickler sehen den Bereich „Nur für Entwickler“, ändern dürfen nur Admins. Steht auch in 13e-5.sql.
CREATE TABLE IF NOT EXISTS rolle (email TEXT PRIMARY KEY, name TEXT NOT NULL, funktion TEXT NOT NULL CHECK (funktion IN ('admin', 'entwickler')));

-- 13f-1 (seit 2.0.74, Bau B Verleih): Der Halter bestätigt bei jeder Einladung, dass er den Nachweis der Person gesehen hat (Art, gültig bis, Zeitpunkt). Steht auch in 13f-1.sql.
ALTER TABLE freigabe ADD COLUMN nachweis_art TEXT;
ALTER TABLE freigabe ADD COLUMN nachweis_bis TEXT;
ALTER TABLE freigabe ADD COLUMN bestaetigt_am INTEGER;

-- 13f-2 (seit 2.0.75, Bau 1 Mitnutzung): Rechte der Freigabe („lesen“ oder „mitnutzen“), Name des Gastes an seinen Einträgen, ausgenommene Dokumente (Liste als Text). Steht auch in 13f-2.sql.
ALTER TABLE freigabe ADD COLUMN rechte TEXT;
ALTER TABLE freigabe ADD COLUMN gast_name TEXT;
ALTER TABLE freigabe ADD COLUMN ausnahmen TEXT;

-- 13f-4 (seit 2.0.79, Bau 3 Planung): Beginn der Planung vor dem Verleih (Datum als Millisekunden, leer = keine Planung vor dem Verleih). Steht auch in 13f-4.sql.
ALTER TABLE freigabe ADD COLUMN plan_ab INTEGER;

-- 13f-8 (seit 2.0.83, Bau 2 Gutscheincodes): Codes, Einlösungen und je zwei Spalten an Bestellung und Beleg. Jede Zeile einzeln in der D1-Console ausführen (steht auch in 13f-8.sql).
CREATE TABLE IF NOT EXISTS gutschein (code TEXT PRIMARY KEY, prozent REAL NOT NULL, stufe TEXT, monate INTEGER, grenze INTEGER NOT NULL, eingeloest INTEGER NOT NULL DEFAULT 0, laeuft_ab INTEGER NOT NULL, erstellt_am INTEGER NOT NULL, erstellt_von TEXT NOT NULL, notiz TEXT);
CREATE TABLE IF NOT EXISTS gutschein_einloesung (code TEXT NOT NULL, nutzer_id TEXT NOT NULL, am INTEGER NOT NULL, art TEXT NOT NULL, referenz TEXT, PRIMARY KEY (code, nutzer_id));
ALTER TABLE bestellung ADD COLUMN gutschein TEXT;
ALTER TABLE bestellung ADD COLUMN liste_cent INTEGER;
ALTER TABLE beleg ADD COLUMN gutschein TEXT;
ALTER TABLE beleg ADD COLUMN liste_cent INTEGER;

-- 13f-10 (seit 2.0.88, Routenplanung): Zählung der geplanten Routen und nachgekaufte Routen. Jede Zeile einzeln in der D1-Console ausführen (steht auch in 13f-10.sql).
CREATE TABLE IF NOT EXISTS route_nutzung (id TEXT PRIMARY KEY, datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, stufe TEXT NOT NULL, am INTEGER NOT NULL, status TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS route_nutzung_raum ON route_nutzung(datenraum_id, am);
CREATE TABLE IF NOT EXISTS route_extra (nutzer_id TEXT PRIMARY KEY REFERENCES nutzer(id) ON DELETE CASCADE, anzahl INTEGER NOT NULL);

-- 13g (seit 2.0.98, Lesedienst für Smart Capture): Zählung der gelesenen Fotos je Konto und Monat. Jede Zeile einzeln in der D1-Console ausführen (steht auch in 13g.sql).
CREATE TABLE IF NOT EXISTS lese_nutzung (id TEXT PRIMARY KEY, datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, stufe TEXT NOT NULL, am INTEGER NOT NULL, status TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS lese_nutzung_raum ON lese_nutzung(datenraum_id, am);
CREATE TABLE IF NOT EXISTS push_ziel (id TEXT PRIMARY KEY, nutzer_id TEXT NOT NULL REFERENCES nutzer(id) ON DELETE CASCADE, geraet TEXT NOT NULL, art TEXT NOT NULL, ziel TEXT NOT NULL, erstellt_am INTEGER NOT NULL, UNIQUE(nutzer_id, geraet));
CREATE INDEX IF NOT EXISTS push_ziel_nutzer ON push_ziel(nutzer_id);

-- 13i (seit 2.0.132, Fahrzeug wiederfinden): die letzte Meldung je wachendem Gerät (verschlüsselt). Steht auch in 13i.sql.
CREATE TABLE IF NOT EXISTS wache_lage (nutzer_id TEXT NOT NULL REFERENCES nutzer(id) ON DELETE CASCADE, geraet TEXT NOT NULL, alarm_am INTEGER NOT NULL, daten TEXT NOT NULL, seit INTEGER NOT NULL, am INTEGER NOT NULL, beendet INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (nutzer_id, geraet));
