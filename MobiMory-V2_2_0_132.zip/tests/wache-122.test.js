'use strict';
/* 2.0.123: „Ton aus“ hält, Alarm-Anzeige ohne Neuaufbau, Push-Diagnose und Test-Nachricht. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
require('../js/version.js');
require('../js/wache.js');
const MM = globalThis.MM;
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

test('Ton aus: die Marke quittiert bleibt bei weiteren Punkten außerhalb erhalten', () => {
  const W = MM.Wache;
  let w = W.neu('standort', { breite: 49, laenge: 9 }, 10, { zeitMs: 1 });
  const fix = (i) => ({ breite: 49.001, laenge: 9, zeitMs: 1000 + i });
  let neuerAlarm = 0;
  for (let i = 0; i < 3; i++) { const r = W.punkt(w, fix(i)); w = r.wache; if (r.neuerAlarm) neuerAlarm++; }
  assert.equal(neuerAlarm, 1); assert.ok(w.alarm);
  w = W.quittieren(w); assert.equal(w.alarm.quittiert, true);
  for (let i = 3; i < 8; i++) { const r = W.punkt(w, fix(i)); w = r.wache; assert.equal(r.neuerAlarm, false); assert.equal(w.alarm.quittiert, true, 'Punkt ' + i); }
  assert.ok(w.alarm.abstand > 10, 'Abstand wird weiter mitgeführt');
});

test('Einbau: Alarm-Anzeige wird nicht neu aufgebaut, Karte öffnen quittiert, Block Nachrichten auf jeder Wache-Seite', () => {
  const a = lesen('js/ansicht.js');
  const i = a.indexOf('function wacheAlarmZeigen()'), j = a.indexOf('function wacheBeenden()');
  const f = a.slice(i, j);
  assert.match(f, /querySelector\('\.wache-abstand'\)/); assert.match(f, /replaceChild\(wacheBild/);
  assert.ok(f.indexOf('replaceChild') < f.indexOf("wacheAlarmEl = h('div'"), 'Erneuern kommt vor dem Neuaufbau und kehrt zurück');
  const karte = f.slice(f.indexOf("text: 'Karte öffnen'"), f.indexOf("text: 'Wache beenden'"));
  assert.match(karte, /quittieren/); assert.match(karte, /wacheTonStopp/);
  assert.match(a, /kconcat\(zeil, \[nBlock\]\)|kopfTeil\.concat\(zeil, \[nBlock\]\)/);
  assert.match(a, /Test-Nachricht an meine anderen Geräte/); assert.match(a, /noch nicht für Nachrichten angemeldet/);
});

['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'konto', 'abgleich', 'huelle', 'daten'].forEach((n) => require('../js/' + n + '.js'));

function datenMit(antworten) {
  const aufrufe = [];
  const d = Object.create(MM.Daten.Daten.prototype);
  d.kontoSenden = (m, p, b) => { aufrufe.push({ m, p, b }); return Promise.resolve(antworten[m + ' ' + p] || { ok: true, json: {} }); };
  d.geraetKennung = () => Promise.resolve('geraetKennung1');
  d.rcGeraet = () => Promise.resolve({ kontoToken: 'tok' });
  return { d, aufrufe };
}

test('Daten: Alarm-Ergebnis nennt Fehleranzahl und Grund, Test-Nachricht sendet test: true', async () => {
  const x = datenMit({ 'POST /alarm/senden': { ok: true, json: { ok: true, push: 0, fehler: 1, mail: true, ziele: 1, grund: ['fcm 403'] } } });
  const r = await x.d.alarmSenden({ art: 'standort' });
  assert.deepEqual([r.ok, r.push, r.fehlerAnzahl, r.grund, r.mail], [true, 0, 1, ['fcm 403'], true]);
  const t = await x.d.testNachricht();
  assert.equal(t.ok, true); assert.equal(x.aufrufe[1].b.test, true); assert.equal(x.aufrufe[1].b.geraet, 'geraetKennung1');
  const ohne = datenMit({}); ohne.d.rcGeraet = () => Promise.resolve({});
  assert.equal((await ohne.d.testNachricht()).ok, false);
});

test('Daten: pushStatus zeigt, ob das Gerät angemeldet ist', async () => {
  const x = datenMit({}); x.d.rcGeraet = () => Promise.resolve({ kontoToken: 't', pushAngemeldetAm: 5, pushArt: 'fcm' });
  assert.deepEqual(await x.d.pushStatus(), { angemeldetAm: 5, art: 'fcm', konto: true });
  x.d.rcGeraet = () => Promise.resolve({});
  assert.deepEqual(await x.d.pushStatus(), { angemeldetAm: null, art: null, konto: false });
});

test('Dienst: Antwort nennt Ziele und Grund, Test-Nachricht ohne E-Mail', async (t) => {
  let sqliteDa = true; try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
  if (!sqliteDa) return t.skip('node:sqlite fehlt');
  const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
  const dienst = await import('../server/konto-dienst.mjs');
  const APP = 'https://app.example.org', PW = 'Sehr-sicheres-Passwort-1';
  const env = { DB: neueDatenbank(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1', FCM_KONTO: JSON.stringify({ client_email: 'x@y', private_key: 'kaputt', project_id: 'p' }) };
  const u = { t: Date.UTC(2026, 10, 10, 12, 0, 0) }; u.jetzt = () => u.t;
  async function ruf(methode, weg, body, token) {
    const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
    if (body !== undefined) kopf['Content-Type'] = 'application/json';
    if (token) kopf.Authorization = 'Bearer ' + token;
    const r = await dienst.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, u.jetzt);
    return { status: r.status, json: await r.json() };
  }
  const a = await ruf('POST', '/konto/registrieren', { email: 'w@example.org', passwort: PW });
  const b = await ruf('POST', '/konto/code-pruefen', { email: 'w@example.org', code: a.json.entwicklungsCode });
  const z = await ruf('POST', '/konto/anmelden', { email: 'w@example.org', passwort: PW, geraet: 'Tablet' });
  await ruf('POST', '/push/anmelden', { geraet: 'geraetB2', art: 'fcm', ziel: 'F'.repeat(40) + ':APA91b' }, z.json.token);
  const r = await ruf('POST', '/alarm/senden', { geraet: 'geraetA1' }, b.json.token);
  assert.equal(r.status, 200); assert.equal(r.json.ziele, 1); assert.equal(r.json.push, 0); assert.equal(r.json.fehler, 1);
  assert.match(r.json.grund[0], /^fcm: Anmeldung bei Google abgelehnt|^fcm: Fehler/);
  const t2 = await ruf('POST', '/alarm/senden', { geraet: 'geraetA1', test: true }, b.json.token);
  assert.equal(t2.json.mail, false); assert.equal(t2.json.ziele, 1);
});

test('Einbau: Version 2.0.123 überall', () => {
  assert.equal(MM.VERSION, '2.0.132'); assert.equal(MM.Texte.NEUERUNGEN[10].version, '2.0.122');
  assert.match(MM.Texte.NEUERUNGEN[10].punkte.join(' '), /Ton aus/);
  assert.ok(lesen('CHANGELOG.md').startsWith('# Änderungen\n\n## 2.0.132'));
  assert.match(lesen('server/EINRICHTUNG.md'), /Update 2\.0\.122/);
});
