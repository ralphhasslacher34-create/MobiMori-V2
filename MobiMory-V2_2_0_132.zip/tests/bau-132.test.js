'use strict';
/* 2.0.132: Cockpit-Wechsel bei Booten, Wassertanks, Alarmton der Wache, Fahrzeug wiederfinden. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
require('../js/version.js');
require('../js/cockpitwechsel.js');
const MM = globalThis.MM;
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

test('Cockpit-Wechsel: nur sichtbare Fragen halten an', () => {
  const f = MM.CockpitWechsel.frageOffen;
  assert.equal(f([]), false);
  assert.equal(f([null, { hidden: true }, null]), false);
  assert.equal(f([null, { hidden: false }]), true);
  assert.match(lesen('js/ansicht.js'), /arbeitet \|\| MM\.CockpitWechsel\.frageOffen\(frageKarten\)/);
});

test('Kartenansicht des Wechsels: „Person über Bord“ bei Wasserfahrzeugen', () => {
  assert.match(lesen('js/ansicht.js'), /a\.fahrzeug\.welt === 'wasser' \? \{ element: mobKnopf\(id\) \} : null/);
  assert.match(lesen('js/kartenansicht.js'), /if \(k\.element\)/);
});

['fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'texte', 'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'fahrt', 'reisecheck', 'karte', 'daten'].forEach(n => require('../js/' + n + '.js'));

test('Checkliste: Wassertanks werden als Tank mit Inhalt angelegt', () => {
  const l = MM.Komponenten.LISTE_VORLAGE, w = n => l.find(x => x.wert === n);
  assert.deepEqual([w('wassertank').art, w('wassertank').stoff], ['tank', 'Frischwasser']);
  assert.deepEqual([w('abwassertank').art, w('abwassertank').stoff], ['tank', 'Grauwasser']);
  assert.equal(MM.Komponenten.anlageZeilen([{ eintrag: w('wassertank'), anzahl: 1 }])[0].stoff, 'Frischwasser');
});

test('Bereits angelegte Wassertanks: anzeigen, kennzeichnen, dann auffüllen und entleeren', async () => {
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date().toISOString() });
  await d.starten();
  const fz = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const frisch = (await d.komponenteAnlegen(fz, null, 'wasser', { bezeichnung: 'Wassertank (Frischwasser)', verbraucher: 'nein' })).id;
  const ab = (await d.komponenteAnlegen(fz, null, 'wasser', { bezeichnung: 'Abwassertank', verbraucher: 'nein' })).id;
  await d.komponenteAnlegen(fz, null, 'wasser', { bezeichnung: 'Wasserpumpe', verbraucher: 'nein' });
  let k = await d.versorgungKette(fz);
  assert.deepEqual(k.wasserOffen.map(x => x.id).sort(), [frisch, ab].sort());
  assert.equal((await d.vorgangAuswahl(fz)).length, 0);
  assert.equal((await d.wassertankKennzeichnen(frisch, 'Benzin')).ok, false);
  assert.equal((await d.wassertankKennzeichnen(frisch, 'Frischwasser')).ok, true);
  assert.equal((await d.wassertankKennzeichnen(ab, 'Schwarzwasser (Fäkalien)')).ok, true);
  assert.deepEqual((await d.vorgangAuswahl(fz)).map(x => x.id), ['frischwasser', 'schwarzwasser']);
  k = await d.versorgungKette(fz);
  assert.equal(k.wasserOffen.length, 0);
  assert.equal(k.tanks.length, 2);
});

test('Wache: Alarmton bei der Ankerwache vorgewählt, bei der Standortwache nicht', () => {
  const a = lesen('js/ansicht.js');
  assert.match(a, /id: 'wache-ton', checked: art === 'anker'/);
  assert.doesNotMatch(a, /Kein lauter Alarm am Fahrzeug/);
});

require('../js/wache.js');
require('../js/wiederfinden.js');
const W = MM.Wiederfinden;

test('Weg seit dem Alarm: Stehen verlängert ihn nicht, er bleibt begrenzt, Anfang und Ende bleiben', () => {
  let s = W.punktDazu([], { breite: 48, laenge: 9, zeitMs: 1 });
  s = W.punktDazu(s, { breite: 48.00001, laenge: 9, zeitMs: 2 });
  assert.equal(s.length, 1);
  for (let i = 1; i <= 1500; i++) s = W.punktDazu(s, { breite: 48 + i * 0.001, laenge: 9, zeitMs: 10 + i });
  assert.ok(s.length <= W.MAX_PUNKTE);
  assert.equal(s[0][2], 1);
  assert.equal(s[s.length - 1][2], 1510);
});

test('Koordinaten und Kartenlink für die Polizei', () => {
  const p = { breite: 48.123456, laenge: 9.5, zeitMs: Date.UTC(2026, 10, 27, 12) };
  assert.equal(W.koordinaten(p), '48.12346, 9.50000');
  assert.match(W.kartenLink(p), /^https:\/\/www\.openstreetmap\.org\/\?mlat=48\.12346&mlon=9\.50000#map=17/);
  assert.ok(W.meldungText(p).includes(W.kartenLink(p)));
});
