'use strict';
/* 2.0.130: Hafen-/Stellplatzknöpfe, Kreuzen, Fahrtarten, Steuerkurs und Versatz, Person über Bord. */
const test = require('node:test');
const assert = require('node:assert/strict');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status',
  'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'kartenereignisse', 'texte', 'segeln', 'seemann', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const S = MM.Seemann;

test('Versatz: Steuerkurs gegen den gefahrenen Weg, erst ab 50 m; negativ ist Backbord', () => {
  const start = { breite: 54, laenge: 10 };
  assert.equal(S.versatz(0, start, { breite: 54.0001, laenge: 10 }), null);
  const v = S.versatz(10, start, { breite: 54.01, laenge: 10 });
  assert.equal(v.versatz, -10);
  assert.match(S.versatzText(v.versatz), /Backbord/);
});

test('Kreuzen: Plan wird geprüft, Zeit läuft ab, Wende oder Halse', () => {
  assert.equal(S.kreuzPlan({ richtung: 'auf', wiederholt: 'ja', art: 'zeit', wert: '0' }).ok, false);
  const p = S.kreuzPlan({ richtung: 'auf', wiederholt: 'ja', art: 'zeit', wert: '10' });
  assert.ok(p.ok);
  const z = S.kreuzStart(p.plan, 1000);
  assert.match(S.kreuzRest(z, 1000).text, /^Wende in/);
  assert.equal(S.kreuzRest(z, 1000 + 10 * 60000).faellig, true);
  assert.equal(S.manoeverName(S.kreuzPlan({ richtung: 'vor', art: 'strecke', wert: '2' }).plan), 'Halse');
});

test('Suchbereich: mit Wind ein Fächer in Windrichtung, ohne Wind ein wachsender Kreis', () => {
  const basis = { breite: 54, laenge: 10, seitMs: 0, jetztMs: 3600000, driftProzent: 1.2, driftWinkel: 30 };
  const f = S.suchbereich(Object.assign({ windKn: 20, windAus: 270 }, basis));
  assert.equal(f.art, 'faecher');
  assert.ok(Math.abs(f.richtung - 90) < 2);
  assert.ok(Math.abs(f.meter - 0.012 * 20 * 1852) < 5);
  const k = S.suchbereich(basis);
  assert.equal(k.art, 'kreis');
  assert.ok(k.radius > S.suchbereich(Object.assign({}, basis, { jetztMs: 600000 })).radius);
});

test('Fahrtarten: Segel und Motor ergeben Segeln, Motorfahrt, Motorsegeln', () => {
  const h = 3600000;
  const a = S.fahrtAbschnitte({ fahrt: [{ ms: 0, unterwegs: true }, { ms: 4 * h, unterwegs: false }], motorlaeufe: [{ von: 0, bis: 2 * h }],
    segel: [{ ms: h, wirkung: 'setzen', ids: ['g'], name: 'Groß' }, { ms: 3 * h, wirkung: 'bergen', ids: ['g'], name: 'Groß' }], endeMs: 5 * h, aenderungen: [] });
  assert.deepEqual(a.map((x) => x.art), ['motor', 'motorsegeln', 'segeln']);
});

test('Anhalten gilt nur während der Fahrt; Hafenknöpfe belegen keinen Schnellknopf', async () => {
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(2026, 10, 25, 8, 0, 0).toISOString() });
  await d.starten();
  assert.deepEqual((await d.ablaufArten('wohnmobil', 'land')).map((x) => x.name), ['Abfahrt', 'Anhalten', 'Ankunft']);
  const k = await d.schnellknoepfeFuerFahrzeugart('wohnmobil');
  assert.ok(!k.knoepfe.some((x) => MM.Logbuch.ABLAUF.land.includes(x.name)));
});

test('Kreuzen: eine gefahrene Wende wird erkannt und zählt neu', () => {
  const z = S.kreuzStart(S.kreuzPlan({ richtung: 'auf', wiederholt: 'ja', art: 'zeit', wert: '10' }).plan, 0);
  const m = S.kreuzMerker();
  let erkannt = 0, breite = 54;
  for (let t = 0; t <= 300; t += 2) {
    breite += 0.00005;
    if (S.kreuzPunkt(z, m, { zeitMs: t * 1000, breite, laenge: 10, kurs: t < 100 ? 45 : 315, geschwindigkeit: 3 }, { ruhigSek: 30, ruhigGrad: 10 }) === 'gedreht') erkannt++;
  }
  assert.equal(erkannt, 1);
  assert.equal(z.schlag, 2);
});

test('Wind von Hand: Beaufort nur bis 12', async () => {
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher());
  await d.starten();
  const r = await d.mobAngaben('gibt-es-nicht', { windStaerke: '15', windRichtung: 'W' });
  assert.ok(r.fehler.windStaerke);
});

test('Abgleich: App und Dienst nehmen Kreuzen und Fahrtarten an; Positionen bleiben auf dem Gerät', () => {
  const fs = require('fs'), path = require('path');
  const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');
  const muster = (t) => /EINSTELLUNG_ID = \/(.+?)\/;/.exec(t)[1];
  const app = muster(lesen('js/abgleich.js'));
  assert.equal(app, muster(lesen('server/konto-dienst.mjs')));
  const re = new RegExp(app);
  assert.ok(re.test('kreuzen-x') && re.test('fahrtart-x'));
  assert.ok(!re.test('steuerkurs-x') && !re.test('mobweg-x'));
});
