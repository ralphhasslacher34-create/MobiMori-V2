'use strict';
/* 2.0.98 (13g): Lesedienst für Smart Capture im Konto-Dienst. Google ist nachgebaut. Nur bezahlte Stufen, Monatsgrenze je Stufe, nichts gespeichert,
   kein Zählen bei Fehlern, Zustimmung Pflicht, Schlüssel nie in der Antwort. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

const APP = 'https://app.example.org';
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) {
  return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1', GOOGLE_VISION_KEY: 'google-schluessel-geheim-1' }, extra || {});
}
function uhr() { const u = { t: Date.UTC(2026, 10, 16, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
/* Ein winziges, gültig beginnendes JPEG in Base64 (nur die Anfangsbytes zählen, Google ist nachgebaut). */
const BILD = '/9j/' + 'A'.repeat(200);

function google() {
  const r = { aufrufe: [], modus: 'ok' };
  const wort = (t, x, y, k, br) => ({ boundingBox: { vertices: [{ x, y }, { x: x + 50, y }, { x: x + 50, y: y + 20 }, { x, y: y + 20 }] }, confidence: k,
    symbols: t.split('').map((c, i, a) => ({ text: c, property: i === a.length - 1 && br ? { detectedBreak: { type: br } } : undefined })) });
  r.fetch = async (url, init) => {
    r.aufrufe.push({ url, init });
    if (r.modus === 'netz') throw new Error('kein Netz');
    if (r.modus === 'fehler') return new Response(JSON.stringify({ error: { message: 'API key not valid: google-schluessel-geheim-1' } }), { status: 403 });
    if (r.modus === 'bildfehler') return new Response(JSON.stringify({ responses: [{ error: { code: 3, message: 'Bad image data.' } }] }), { status: 200 });
    if (r.modus === 'leer') return new Response(JSON.stringify({ responses: [{}] }), { status: 200 });
    return new Response(JSON.stringify({ responses: [{ fullTextAnnotation: { text: 'Name\nErika Mustermann', pages: [{ width: 2200, height: 1400, blocks: [{ paragraphs: [{ words: [
      wort('Name', 100, 100, 0.99, 'EOL_SURE_SPACE'), wort('Erika', 100, 140, 0.97, 'SPACE'), wort('Mustermann', 170, 140, 0.9, 'EOL_SURE_SPACE')] }] }] }] } }] }), { status: 200 });
  };
  return r;
}
async function roh(env, u, methode, weg, body, token, optionen) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  return d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, Object.assign({ jetzt: u.jetzt }, optionen || {}));
}
async function ruf(env, u, methode, weg, body, token, optionen) { const r = await roh(env, u, methode, weg, body, token, optionen); return { status: r.status, json: await r.json() }; }
async function konto(env, u, email) {
  u.t += 13 * 60 * 1000;
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode, geraet: 'Test #01234567' });
  assert.equal(b.status, 200, JSON.stringify(b.json)); return b.json.token;
}
function stufeSetzen(env, email, stufe) {
  const n = env.DB.roh.prepare('SELECT id FROM nutzer WHERE email = ?').get(email);
  env.DB.roh.prepare('INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) VALUES (?, ?, ?, ?)').run(n.id, stufe, null, 1);
}
const ANF = { bild: BILD, zustimmung: true };

test('Dienst 13g: Grenzen je Stufe, SQL-Datei im Schema, Gesundheit, Anleitung', async () => {
  const d = await laden();
  assert.equal(d.VERSION, '13i');
  assert.deepEqual(['basic', 'test', 'mittel', 'voll', 'entwickler'].map((k) => d.STUFEN[k].scans), [0, 10, 50, 100, null]);
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13g.sql'), 'utf8').split('\n').filter((z) => z.trim());
  assert.equal(sql.length, 2);
  const schema = fs.readFileSync(path.join(__dirname, '..', 'server', 'schema.sql'), 'utf8');
  sql.forEach((z) => assert.ok(schema.includes(z)));
  assert.ok(fs.readFileSync(path.join(__dirname, '..', 'server', 'EINRICHTUNG.md'), 'utf8').includes('## Update auf 13g'));
  const u = uhr();
  const g = (await ruf(umgebung(), u, 'GET', '/gesundheit')).json;
  assert.equal(g.version, '13i'); assert.deepEqual(g.lesen, { tabelle: true, schluessel: true });
  assert.equal((await ruf(umgebung({ GOOGLE_VISION_KEY: undefined }), u, 'GET', '/gesundheit')).json.lesen.schluessel, false);
});

test('Lesen: Mittel liest, Antwort mit Wörtern und Positionen, Aufruf an Google über die EU-Adresse, Kontingent zählt, nichts gespeichert', async () => {
  const env = umgebung(), u = uhr(), g = google(), o = { fetch: g.fetch };
  const tok = await konto(env, u, 'a@example.org'); stufeSetzen(env, 'a@example.org', 'mittel');
  assert.equal((await ruf(env, u, 'POST', '/lesen/senden', ANF, undefined, o)).status, 401);
  const r = await ruf(env, u, 'POST', '/lesen/senden', ANF, tok, o);
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.ok, true); assert.equal(r.json.breite, 2200); assert.equal(r.json.hoehe, 1400);
  assert.deepEqual(r.json.woerter.map((w) => w.t), ['Name', 'Erika', 'Mustermann']);
  assert.deepEqual(r.json.woerter[1], { t: 'Erika', v: [100, 140, 150, 140, 150, 160, 100, 160], k: 97, e: 0 });
  assert.deepEqual(r.json.woerter.map((w) => w.e), [1, 0, 1]);
  assert.deepEqual(r.json.kontingent, { genutzt: 1, grenze: 50, stufe: 'mittel', monat: '2026-11' });
  assert.equal(g.aufrufe.length, 1);
  assert.ok(g.aufrufe[0].url.startsWith('https://eu-vision.googleapis.com/v1/images:annotate?key='));
  const k = JSON.parse(g.aufrufe[0].init.body).requests[0];
  assert.equal(k.features[0].type, 'DOCUMENT_TEXT_DETECTION'); assert.deepEqual(k.imageContext.languageHints, ['de']); assert.equal(k.image.content, BILD);
  assert.ok(!JSON.stringify(r.json).includes('google-schluessel'));
  /* gespeichert wird nur die Zählzeile, kein Bild und kein Text */
  const zeilen = env.DB.roh.prepare('SELECT * FROM lese_nutzung').all();
  assert.equal(zeilen.length, 1); assert.deepEqual(Object.keys(zeilen[0]).sort(), ['am', 'datenraum_id', 'id', 'status', 'stufe']); assert.equal(zeilen[0].status, 'ok');
  const s = (await ruf(env, u, 'GET', '/konto/stufe', undefined, tok)).json;
  assert.equal(s.grenzen.scans, 50); assert.equal(s.nutzung.scans, 1); assert.equal(s.nutzung.scansFrei, 49); assert.equal(s.nutzung.scansMonat, '2026-11');
});

test('Lesen: Basic ohne Lesedienst, Zustimmung und Bild sind Pflicht, Schlüssel fehlt, keine Anfrage an Google', async () => {
  const env = umgebung(), u = uhr(), g = google(), o = { fetch: g.fetch };
  const tok = await konto(env, u, 'a@example.org');
  /* frisches Konto = Testwoche */
  u.t += 8 * 24 * 60 * 60 * 1000;
  const tok2 = await konto(env, u, 'a@example.org');
  const basic = await ruf(env, u, 'POST', '/lesen/senden', ANF, tok2, o);
  assert.equal(basic.status, 402); assert.equal(basic.json.stufe, 'basic');
  stufeSetzen(env, 'a@example.org', 'mittel');
  assert.equal((await ruf(env, u, 'POST', '/lesen/senden', { bild: BILD }, tok2, o)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/lesen/senden', { bild: BILD, zustimmung: 'ja' }, tok2, o)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/lesen/senden', { zustimmung: true }, tok2, o)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/lesen/senden', { zustimmung: true, bild: 'kein-bild' }, tok2, o)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/lesen/senden', { zustimmung: true, bild: 'AAAA'.repeat(100) }, tok2, o)).status, 400);
  const ohneKey = await ruf(umgebung({ GOOGLE_VISION_KEY: '' }), u, 'POST', '/lesen/senden', ANF, tok2, o);
  assert.ok([401, 503].includes(ohneKey.status));
  assert.equal(g.aufrufe.length, 0);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM lese_nutzung').get().n, 0);
});

test('Lesen: Mittel hat 50 im Monat, danach 402 mit Zahlen, im nächsten Monat wieder frei; Voll 100; Entwickler unbegrenzt; Preisermäßigung ändert nichts', async () => {
  const env = umgebung(), u = uhr(), g = google(), o = { fetch: g.fetch };
  const tok = await konto(env, u, 'a@example.org'); stufeSetzen(env, 'a@example.org', 'mittel');
  const raum = env.DB.roh.prepare('SELECT d.id AS id FROM datenraum d JOIN nutzer n ON n.id = d.nutzer_id WHERE n.email = ?').get('a@example.org').id;
  const fuellen = (n, am) => { for (let i = 0; i < n; i++) env.DB.roh.prepare('INSERT INTO lese_nutzung (id, datenraum_id, stufe, am, status) VALUES (?, ?, ?, ?, ?)').run('x' + am + '-' + i, raum, 'mittel', am, 'ok'); };
  fuellen(49, Date.UTC(2026, 10, 2));
  fuellen(80, Date.UTC(2026, 9, 20));           /* Oktober zählt nicht */
  const ok = await ruf(env, u, 'POST', '/lesen/senden', ANF, tok, o);
  assert.equal(ok.status, 200); assert.equal(ok.json.kontingent.genutzt, 50);
  const zu = await ruf(env, u, 'POST', '/lesen/senden', ANF, tok, o);
  assert.equal(zu.status, 402); assert.equal(zu.json.grund, 'limit'); assert.deepEqual([zu.json.genutzt, zu.json.grenze], [50, 50]); assert.match(zu.json.error, /50 von 50/);
  assert.equal(g.aufrufe.length, 1);
  u.t = Date.UTC(2026, 11, 1, 0, 5, 0);
  const tok2 = await konto(env, u, 'a@example.org');
  assert.equal((await ruf(env, u, 'POST', '/lesen/senden', ANF, tok2, o)).status, 200, 'neuer Monat, neue 50');
  /* Voll: 100 */
  stufeSetzen(env, 'a@example.org', 'voll');
  fuellen(98, Date.UTC(2026, 11, 3));
  assert.equal((await ruf(env, u, 'POST', '/lesen/senden', ANF, tok2, o)).json.kontingent.grenze, 100);
  assert.equal((await ruf(env, u, 'POST', '/lesen/senden', ANF, tok2, o)).status, 402);
  /* Entwickler: ohne Grenze */
  stufeSetzen(env, 'a@example.org', 'entwickler');
  const e = await ruf(env, u, 'POST', '/lesen/senden', ANF, tok2, o);
  assert.equal(e.status, 200); assert.equal(e.json.kontingent.grenze, null);
});

test('Lesen: Fehler bei Google und Zeitüberschreitung werden nicht gezählt, ein Foto ohne Text zählt; der Schlüssel taucht nie in einer Antwort auf', async () => {
  const env = umgebung(), u = uhr(), g = google(), o = { fetch: g.fetch };
  const tok = await konto(env, u, 'a@example.org'); stufeSetzen(env, 'a@example.org', 'mittel');
  for (const modus of ['netz', 'fehler', 'bildfehler']) {
    g.modus = modus;
    const r = await ruf(env, u, 'POST', '/lesen/senden', ANF, tok, o);
    assert.equal(r.status, 502, modus); assert.match(r.json.error, /nicht gezählt/); assert.ok(!JSON.stringify(r.json).includes('google-schluessel'));
    assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM lese_nutzung').get().n, 0, modus);
  }
  /* Ein Foto ohne erkennbaren Text ist kein Fehler: leere Antwort, gezählt (Google rechnet es ab) */
  g.modus = 'leer';
  const leer = await ruf(env, u, 'POST', '/lesen/senden', ANF, tok, o);
  assert.equal(leer.status, 200); assert.deepEqual(leer.json.woerter, []); assert.equal(leer.json.kontingent.genutzt, 1);
  g.modus = 'ok';
  assert.equal((await ruf(env, u, 'POST', '/lesen/senden', ANF, tok, o)).status, 200);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM lese_nutzung').get().n, 2);
});

test('Lesen: Bremse bei zu vielen Fotos hintereinander', async () => {
  const env = umgebung(), u = uhr(), g = google(), o = { fetch: g.fetch };
  const tok = await konto(env, u, 'a@example.org'); stufeSetzen(env, 'a@example.org', 'entwickler');
  let letzter;
  for (let i = 0; i < 21; i++) letzter = await ruf(env, u, 'POST', '/lesen/senden', ANF, tok, o);
  assert.equal(letzter.status, 429);
});

test('visionAuswerten: Wörter, Sicherheit, Zeilenende, fehlende Eckpunkte werden übersprungen, Länge begrenzt', async () => {
  const d = await laden();
  const e = d.visionAuswerten({ responses: [{ fullTextAnnotation: { text: 'x', pages: [{ width: 10, height: 20, blocks: [{ paragraphs: [{ words: [
    { symbols: [{ text: 'A' }, { text: 'B', property: { detectedBreak: { type: 'LINE_BREAK' } } }], confidence: 0.5, boundingBox: { vertices: [{ x: 1 }, { x: 5, y: 1 }, { x: 5, y: 9 }, { x: 1, y: 9 }] } },
    { symbols: [{ text: 'C' }], boundingBox: { vertices: [{ x: 1, y: 1 }] } },
    { symbols: [], boundingBox: { vertices: [] } }] }] }] }] } }] });
  assert.deepEqual(e.woerter, [{ t: 'AB', v: [1, 0, 5, 1, 5, 9, 1, 9], k: 50, e: 1 }]);
  assert.throws(() => d.visionAuswerten({}), /keine lesbare Antwort/);
});

test('Lesen: Die Testwoche hat 10 Scans für die ganze Woche, der elfte wird abgelehnt; das Limit hängt an der Stufe', async () => {
  const env = umgebung(), u = uhr(), g = google(), o = { fetch: g.fetch };
  u.t = Date.UTC(2026, 10, 28, 12, 0, 0);
  const tok = await konto(env, u, 'w@example.org');
  for (let i = 0; i < 10; i++) { const r = await ruf(env, u, 'POST', '/lesen/senden', ANF, tok, o); assert.equal(r.status, 200, 'Scan ' + (i + 1)); u.t += 60 * 60 * 1000; }
  /* Monatswechsel mitten in der Testwoche: das Kontingent der Testwoche beginnt nicht neu */
  u.t = Date.UTC(2026, 11, 1, 1, 0, 0);
  const elf = await ruf(env, u, 'POST', '/lesen/senden', ANF, tok, o);
  assert.equal(elf.status, 402); assert.equal(elf.json.grund, 'limit'); assert.equal(elf.json.stufe, 'test'); assert.deepEqual([elf.json.genutzt, elf.json.grenze], [10, 10]); assert.match(elf.json.error, /Testwoche/);
  const st = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok, o);
  assert.equal(st.json.grenzen.scans, 10); assert.equal(st.json.nutzung.scans, 10);
});
