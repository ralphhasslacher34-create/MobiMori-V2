'use strict';
/* 2.0.132 (Dienst 13i): Fahrzeug wiederfinden. Zwei Geräte mit der echten Datenschicht gegen den echten Dienst. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'texte', 'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'fahrt', 'reisecheck', 'karte', 'konto', 'abgleich', 'wache', 'wiederfinden', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;

const APP = 'https://app.example.org', PW = 'Sehr-sicheres-Passwort-1';
let dienst;

async function aufbau() {
  dienst = dienst || await import('../server/konto-dienst.mjs');
  const u = { t: Date.UTC(2026, 10, 27, 12) };
  const env = { DB: neueDatenbank(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' };
  async function ruf(methode, weg, body, token) {
    const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
    if (body !== undefined) kopf['Content-Type'] = 'application/json';
    if (token) kopf.Authorization = 'Bearer ' + token;
    const r = await dienst.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: () => u.t });
    return { status: r.status, json: await r.json() };
  }
  const a = await ruf('POST', '/konto/registrieren', { email: 'weg@example.org', passwort: PW });
  const b = await ruf('POST', '/konto/code-pruefen', { email: 'weg@example.org', code: a.json.entwicklungsCode });
  const z = await ruf('POST', '/konto/anmelden', { email: 'weg@example.org', passwort: PW, geraet: 'Handy' });
  async function geraet(token, wort) {
    const gesendet = [];
    const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(u.t).toISOString() });
    d.kontoAnfrageFn = async (url, methode, tk, body) => {
      const x = new URL(url);
      gesendet.push(JSON.stringify(body || null));
      const r = await ruf(methode, x.pathname + x.search, body === null ? undefined : body, tk);
      if (r.status >= 400) { const e = new Error(r.json.error); e.status = r.status; throw e; }
      return r.json;
    };
    await d.rcSchreiben({ kontoToken: token, kontoDatenraumId: 'dr-test', geheimWort: wort });
    return { d, gesendet, id: await d.geraetKennung() };
  }
  return { u, env, ruf, geraet, boot: await geraet(b.json.token, 'mein-geheimes-wort'), handy: await geraet(z.json.token, 'mein-geheimes-wort'), token: z.json.token };
}

const paket = (breite) => ({ aktId: 'ak1', art: 'standort', radius: 50, mitte: { breite: 48, laenge: 9 }, spur: [[48, 9, 1], [breite, 9, 2]], pos: { breite: breite, laenge: 9, genauigkeit: 5, zeitMs: 2 } });

test('Position geht verschlüsselt zum Dienst, das Handy sieht sie, Beenden am Handy kommt beim Gerät an', async () => {
  const c = await aufbau();
  assert.deepEqual(await c.boot.d.wachePositionSenden(paket(48.001), 1000), { ok: true, beendet: false });
  assert.ok(!c.boot.gesendet.join('').includes('48.001'), 'keine Position im Klartext');
  const zeile = await c.env.DB.prepare('SELECT daten FROM wache_lage').first();
  assert.match(zeile.daten, /^v1\./);
  c.u.t += 30000;
  let l = await c.handy.d.wacheLagen();
  assert.equal(l.ok, true); assert.equal(l.lagen.length, 1);
  assert.equal(l.lagen[0].geraet, c.boot.id);
  assert.equal(l.lagen[0].alterMs, 30000);
  assert.equal(l.lagen[0].paket.pos.breite, 48.001);
  assert.equal((await c.boot.d.wacheLagen()).lagen.length, 0, 'das wachende Gerät sieht sich nicht selbst');
  assert.equal((await c.handy.d.wacheFernBeenden(c.boot.id, 1000)).ok, true);
  assert.equal((await c.env.DB.prepare('SELECT daten FROM wache_lage').first()).daten, '', 'Positionen sind gelöscht');
  assert.equal((await c.handy.d.wacheLagen()).lagen.length, 0);
  assert.deepEqual(await c.boot.d.wachePositionSenden(paket(48.002), 1000), { ok: true, beendet: true });
  assert.deepEqual(await c.boot.d.wachePositionSenden(paket(48.003), 2000), { ok: true, beendet: false }, 'ein neuer Alarm zählt wieder');
});

test('Anderes oder kein Schlüsselwort, Klartext, fremdes Konto, Aufräumen', async () => {
  const c = await aufbau();
  await c.boot.d.wachePositionSenden(paket(48.001), 1000);
  const anders = await c.geraet(c.token, 'ein-anderes-wort');
  const l = await anders.d.wacheLagen();
  assert.equal(l.lagen.length, 1); assert.equal(l.lagen[0].paket, null);
  const ohne = await c.geraet(c.token, null);
  assert.equal((await ohne.d.wachePositionSenden(paket(48), 5)).ok, false);
  assert.equal(ohne.gesendet.length, 0);
  assert.equal((await c.ruf('POST', '/wache/position', { geraet: 'geraetX1', alarmAm: 1, daten: '48.1,9.1' }, c.token)).status, 400);
  assert.equal((await c.ruf('GET', '/wache/lage')).status, 401);
  c.u.t += 3 * 24 * 3600 * 1000;
  assert.equal((await c.handy.d.wacheLagen()).lagen.length, 0, 'nach zwei Tagen ohne Meldung wird nichts mehr gezeigt');
  assert.equal((await c.ruf('GET', '/gesundheit')).json.wiederfinden, true);
});
