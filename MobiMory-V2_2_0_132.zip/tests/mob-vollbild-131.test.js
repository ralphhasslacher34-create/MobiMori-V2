'use strict';
/* 2.0.131: „Person über Bord“ im Vollbild. */
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/bildschirm.js');
const V = globalThis.MM.Vollbild;

function dok() {
  const d = { an: 0, aus: 0, fullscreenElement: null };
  d.documentElement = { requestFullscreen() { d.an++; d.fullscreenElement = this; return Promise.resolve(); } };
  d.exitFullscreen = () => { d.aus++; d.fullscreenElement = null; return Promise.resolve(); };
  return d;
}

test('Browser: Vollbild an und wieder aus, ein fremdes Vollbild bleibt', () => {
  const d = dok(), v = V.erzeugen({ document: d });
  v.an(); v.an(); v.aus(); v.aus();
  assert.deepEqual([d.an, d.aus], [1, 1]);
  d.fullscreenElement = {};
  v.an(); v.aus();
  assert.equal(d.aus, 1);
});

test('iPhone ohne Vollbild und abgelehnter Aufruf: kein Fehler', () => {
  const v = V.erzeugen({ document: { documentElement: {} } });
  v.an(); v.aus();
  V.erzeugen({ document: { documentElement: { requestFullscreen: () => Promise.reject(new Error('nein')) } } }).an();
});

test('Android-App: Systemleisten aus und wieder ein', () => {
  const r = [];
  const v = V.erzeugen({ document: dok(), Capacitor: { isNativePlatform: () => true, Plugins: { SystemBars: { hide: () => { r.push('hide'); }, show: () => { r.push('show'); } } } } });
  v.an(); v.aus(); v.aus();
  assert.deepEqual(r, ['hide', 'show']);
});
