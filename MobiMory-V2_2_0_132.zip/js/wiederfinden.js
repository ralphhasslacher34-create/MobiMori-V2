/*
 * Fahrzeug wiederfinden (seit 2.0.132): Nach einem Alarm meldet das wachende Gerät alle 30 Sekunden seinen Weg, das Handy zeigt ihn auf der Karte.
 * Reine Rechnung ohne Speicher, Netz und Oberfläche. Der Weg steht im Wache-Dokument unter „spur“ (dieser Schlüssel verlässt das Gerät nie
 * mit dem Abgleich) und geht zum Dienst nur als Block, der mit dem Schlüsselwort verschlüsselt ist.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var ABSTAND_MS = 30 * 1000;
  var MAX_PUNKTE = 600;
  var STUMM_MS = 2 * 60 * 1000;

  function aad(geraet) { return 'wache/' + geraet; }

  /* Einen Punkt an den Weg hängen: [breite, laenge, zeitMs]. Steht das Fahrzeug (unter 10 m), wird der Weg nicht länger. Ist er zu lang,
     wird die ältere Hälfte ausgedünnt, Anfang und neueste Punkte bleiben. */
  function punktDazu(spur, fix) {
    var s = (spur || []).slice();
    if (!fix || typeof fix.breite !== 'number' || typeof fix.laenge !== 'number') return s;
    var p = [Number(fix.breite.toFixed(5)), Number(fix.laenge.toFixed(5)), fix.zeitMs || Date.now()];
    var letzte = s[s.length - 1];
    if (letzte && MM.Wache.meter(letzte[0], letzte[1], p[0], p[1]) < 10) return s;
    s.push(p);
    if (s.length > MAX_PUNKTE) {
      var halb = Math.floor(s.length / 2);
      s = s.filter(function (x, i) { return i === 0 || i >= halb || i % 2 === 0; });
    }
    return s;
  }

  /* Was verschlüsselt zum Dienst geht. fix: die aktuelle Position mit ihrer Zeit (auch wenn das Fahrzeug steht). */
  function paket(w, aktId, spur, fix) {
    return {
      aktId: aktId, art: w.art, radius: w.radius, mitte: w.wachepos, spur: spur,
      pos: { breite: Number(fix.breite.toFixed(5)), laenge: Number(fix.laenge.toFixed(5)), genauigkeit: fix.genauigkeit, zeitMs: fix.zeitMs }
    };
  }

  /* Ein geöffnetes Paket prüfen. Gibt es zurück oder null. */
  function lesen(text) {
    var o;
    try { o = JSON.parse(text); } catch (e) { return null; }
    if (!o || !o.pos || !isFinite(o.pos.breite) || !isFinite(o.pos.laenge) || !Array.isArray(o.spur)) return null;
    return o;
  }

  function koordinaten(pos) { return pos.breite.toFixed(5) + ', ' + pos.laenge.toFixed(5); }
  function kartenLink(pos) {
    var b = pos.breite.toFixed(5), l = pos.laenge.toFixed(5);
    return 'https://www.openstreetmap.org/?mlat=' + b + '&mlon=' + l + '#map=17/' + b + '/' + l;
  }
  function alterText(ms) {
    var s = Math.max(0, Math.round(ms / 1000));
    if (s < 90) return s + ' Sekunden';
    var m = Math.round(s / 60);
    return m < 90 ? m + ' Minuten' : Math.round(m / 60) + ' Stunden';
  }
  /* Der Text, den man der Polizei geben kann. */
  function meldungText(pos) {
    return 'Standort meines Fahrzeugs am ' + new Date(pos.zeitMs).toLocaleString('de-DE') + ':\n' + koordinaten(pos) + '\n' + kartenLink(pos);
  }

  MM.Wiederfinden = {
    ABSTAND_MS: ABSTAND_MS, MAX_PUNKTE: MAX_PUNKTE, STUMM_MS: STUMM_MS,
    aad: aad, punktDazu: punktDazu, paket: paket, lesen: lesen, koordinaten: koordinaten, kartenLink: kartenLink, alterText: alterText, meldungText: meldungText
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
