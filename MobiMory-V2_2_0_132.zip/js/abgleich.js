/*
 * Abgleich zwischen Geräten (Schritt 13b, seit 2.0.65): reine Rechnung, kein Netz, kein Speicher.
 *
 * Festlegung vom 20.11.2026 (seit 2.0.119, ersetzt die vom 03.11.): MobiMory läuft synchron auf allen angemeldeten Geräten. Jeder erzeugte oder
 * erfasste Datensatz geht zum Dienst und ist auf jedem Gerät abrufbar: Fahrzeuge und Komponenten, Fristen und Störungen, Aktivitäten und Besatzung,
 * Anforderungen, Ereignisse und Zähler, Belegung, Prüfergebnis, Dokumente, Kosten, Routen, Besuche, Reisechecks, Nachweise, Orte, Standorte, Gebiete,
 * Personen, Tiere, Adressen und einige Einstellungen (Wechselpunkte, Tagesrouten, Kartenauswahl, Cockpit-Wechsel). Die Dateien selbst (Fotos, Scans,
 * Dokumente) und die GPS-Spur gehen getrennt hinaus (Daten.dateienAbgleichen).
 *
 * Alles Empfindliche (Notizen, Telefon, E-Mail, Adresse, Geburtsdatum, Wohnort, Chipnummer, Ansprechpartner, Nummer, Aussteller und Klassen der Nachweise,
 * Namen im Reisecheck) geht nur mit Schlüsselwort hinaus, verschlüsselt in einem Block „@geheim“ (MM.Geheim). Ohne Schlüsselwort auf dem Gerät bleibt es
 * auf dem Gerät. Der Dienst lehnt diese Angaben im Klartext weiter ab.
 *
 * Jeder Datensatz geht als Text (kanonisches JSON) hinaus. Die empfindlichen Felder werden vorher herausgenommen und als Block angehängt, beim Zurückholen
 * wieder eingesetzt (Block geöffnet) oder aus der lokalen Fassung ergänzt (Block noch verschlossen, der Block bleibt dann unverändert am Datensatz
 * im Feld „geheim“). Der Dienst prüft die Datenarten und Schlüssel noch einmal (server/konto-dienst.mjs).
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Schlüssel, die nie im Klartext zum Dienst gehen (in jeder Tiefe). Die gleiche Liste steht im Dienst; ein Test vergleicht beide. */
  var LOKALE_SCHLUESSEL = ['notiz', 'abschlussNotiz', 'erledigtNotiz', 'email', 'telefon', 'chipnummer', 'adresse', 'ansprechpartner',
    'geburtsdatum', 'wohnort', 'inhalt', 'spur', 'geheim', 'wachepos'];
  /* Davon gehen nie hinaus, auch nicht verschlüsselt: Datei-Inhalt (eigener Weg), GPS-Spur (eigener Weg) und der ungeöffnete Block selbst. */
  var NIE_SCHLUESSEL = ['inhalt', 'spur', 'geheim'];
  /* Der Rest geht verschlüsselt mit dem Schlüsselwort hinaus. */
  var PRIVAT_SCHLUESSEL = LOKALE_SCHLUESSEL.filter(function (n) { return NIE_SCHLUESSEL.indexOf(n) < 0; });
  /* Diese Dokumente aus „einstellungen“ gehen mit (gerätespezifisch bleiben Anmeldung, Sicherungs-Erinnerung, Offline-Karte, Wetter und die GPS-Dokumente). */
  var EINSTELLUNG_ID = /^(wechselpunkte-|tagroute-|wechsel-|wache-|kreuzen-|fahrtart-|kartenwahl|wortpruefung$)/;
  var EINSTELLUNG_PRUEFUNG = 'wortpruefung';
  var PRUEFTEXT = 'MobiMory-Schluesselwort-in-Ordnung';

  /* Lokale Tabellen, die abgeglichen werden, und die Datenart, zu der sie gehören. */
  var TABELLEN = {
    fahrzeuge: 'fahrzeuge', eintraege: 'fahrzeuge', komponenten: 'fahrzeuge', komponenteneintraege: 'fahrzeuge',
    zaehler: 'zaehler', zaehlerstaende: 'zaehler',
    fristen: 'fristen', durchfuehrungen: 'fristen',
    vorgaenge: 'stoerungen', vorgangsentscheidungen: 'stoerungen',
    aktivitaeten: 'aktivitaeten', aktivitaetsarten: 'aktivitaeten', besatzung: 'aktivitaeten', verantwortung: 'aktivitaeten',
    tagesabschnitte: 'ereignisse', ereignisse: 'ereignisse', ereignisarten: 'ereignisse',
    tagespruefungen: 'pruefung',
    dokumente: 'dokumente', dateien: 'dokumente', ereignisdateien: 'dokumente',
    nachweisarten: 'nachweise', nachweise: 'nachweise', nachweisdateien: 'nachweise',
    kosten: 'kosten', kostenstamm: 'kosten', kostenarten: 'kosten', zahlungsmittel: 'kosten', kassen: 'kosten', kassenbuchungen: 'kosten',
    routen: 'reisen', besuche: 'reisen', reisechecks: 'reisen',
    personen: 'stamm', tiere: 'stamm', adressen: 'stamm', orte: 'stamm', standorte: 'stamm', gebiete: 'stamm', regeln: 'stamm',
    anforderungen: 'aktivitaeten', einstellungen: 'einstellungen',
    verlaeufe: 'verlaeufe'
  };
  var ARTEN = {
    fahrzeuge: 'Fahrzeuge und Komponenten', zaehler: 'Zähler', fristen: 'Fristen', stoerungen: 'Störungen und Werkstatt',
    aktivitaeten: 'Aktivitäten und Besatzung', ereignisse: 'Logbuch und Ereignisse', pruefung: 'Prüfergebnisse',
    dokumente: 'Dokumente und Bilder (Angaben dazu)', nachweise: 'Nachweise', kosten: 'Kosten und Reisekasse',
    reisen: 'Routen, Besuche und Reisechecks',
    stamm: 'Orte, Standorte, Gebiete, Personen, Tiere und Adressen', einstellungen: 'Einstellungen (Wechselpunkte, Tagesrouten, Kartenauswahl, Cockpit-Wechsel)',
    verlaeufe: 'Änderungsverläufe'
  };
  var TABELLEN_NAMEN = {
    fahrzeuge: 'Fahrzeug', eintraege: 'Fahrzeugangaben', komponenten: 'Komponente', komponenteneintraege: 'Komponentenangaben', zaehler: 'Zähler',
    zaehlerstaende: 'Zählerstand', fristen: 'Frist', durchfuehrungen: 'Erledigung', vorgaenge: 'Vorgang', vorgangsentscheidungen: 'Entscheidung im Vorgang',
    aktivitaeten: 'Aktivität', aktivitaetsarten: 'Art der Aktivität', besatzung: 'Besatzung', verantwortung: 'Verantwortung', anforderungen: 'Anforderung', standorte: 'Standort', einstellungen: 'Einstellung',
    tagesabschnitte: 'Tag der Aktivität', ereignisse: 'Ereignis', ereignisarten: 'Art des Ereignisses', tagespruefungen: 'Prüfergebnis',
    personen: 'Person', tiere: 'Tier', adressen: 'Adresse', orte: 'Ort', gebiete: 'Gebiet', regeln: 'Regel', verlaeufe: 'Änderung',
    dokumente: 'Dokument', dateien: 'Datei zum Dokument', ereignisdateien: 'Foto zum Ereignis', nachweisarten: 'Nachweisart', nachweise: 'Nachweis',
    nachweisdateien: 'Scan zum Nachweis', kosten: 'Kostenposten', kostenstamm: 'Fixkosten-Vorlage', kostenarten: 'Kostenart', zahlungsmittel: 'Zahlungsmittel',
    kassen: 'Kasse', kassenbuchungen: 'Kassenbuchung', routen: 'Route', besuche: 'Besuch', reisechecks: 'Reisecheck'
  };

  /* Tabellen, deren Datensatz nur die Angaben zu einer Datei trägt. Der Inhalt („inhalt“) geht getrennt hinaus. */
  var DATEI_TABELLEN = ['dateien', 'nachweisdateien', 'ereignisdateien'];
  /* Scans von Nachweisen (Führerschein und Ähnliches) gehen nur verschlüsselt mit dem Schlüsselwort des Nutzers hinaus. */
  var VERSCHLUESSELTE_DATEIEN = ['nachweisdateien'];
  /* Zusätzliche Felder je Tabelle, die lokal bleiben (neben LOKALE_SCHLUESSEL): Im Reisecheck die Namen hinter den Decknamen der Anfrage. */
  var EXTRA_LOKAL = { reisechecks: ['namen'] };

  /* Verlauf-Typen, die abgeglichen werden. Wert: erlaubte Felder in „werte“ (null = alle außer den lokalen Schlüsseln). */
  var VERLAUF_TYPEN = {
    zaehler: null, frist: null, vorgang: null, aktivitaet: null, besatzung: null, verantwortung: null, tagesabschnitt: null, ereignis: null,
    aktivitaetsart: null, ereignisart: null, ort: null, gebiet: null, regel: null,
    person: ['bezeichnung', 'funktionen', 'ausgeblendet'],
    tier: ['bezeichnung', 'tierart', 'ausgeblendet'],
    adresse: ['bezeichnung', 'art', 'plz', 'ort', 'land', 'ausgeblendet'],
    dokument: null, kosten: null, kostenstamm: null, kostenart: null, zahlungsmittel: null, kassenbuchung: null, besuch: null, route: null, nachweisart: null,
    nachweis: ['ausgestelltAm', 'gueltigBis', 'dateiName', 'dateiTyp', 'dateiGroesse']
  };

  var MAX_NUTZLAST = 256 * 1024;
  var MAX_PAKET_BYTES = 900 * 1024;
  var MAX_DATEI_BYTES = 20 * 1024 * 1024;
  var MAX_KONFLIKTE = 30;

  function istObjekt(o) { return o !== null && typeof o === 'object' && !Array.isArray(o); }
  function lokal(k) { return LOKALE_SCHLUESSEL.indexOf(k) >= 0; }
  function privat(k) { return PRIVAT_SCHLUESSEL.indexOf(k) >= 0; }
  function nie(k) { return NIE_SCHLUESSEL.indexOf(k) >= 0; }
  function nurDateiUndSpur(k) { return k === 'inhalt' || k === 'spur'; }

  /* Tiefe Kopie ohne die lokalen Schlüssel. Dateien (Blob) und Binärdaten gehören nicht hierher. */
  function bereinigen(o) {
    if (Array.isArray(o)) return o.map(bereinigen);
    if (istObjekt(o)) {
      var k = {};
      Object.keys(o).forEach(function (n) { if (!lokal(n)) k[n] = bereinigen(o[n]); });
      return k;
    }
    return o;
  }

  /* Kanonischer Text: gleiche Daten ergeben auf jedem Gerät denselben Text. */
  function kanonisch(o) {
    if (Array.isArray(o)) return '[' + o.map(kanonisch).join(',') + ']';
    if (istObjekt(o)) return '{' + Object.keys(o).sort().filter(function (n) { return o[n] !== undefined; }).map(function (n) { return JSON.stringify(n) + ':' + kanonisch(o[n]); }).join(',') + '}';
    return JSON.stringify(o === undefined ? null : o);
  }

  /* Schneller Abdruck (cyrb53) nur zum Erkennen von Änderungen, keine Sicherheitsfunktion. */
  function abdruck(text) {
    var h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (var i = 0; i < text.length; i++) {
      var c = text.charCodeAt(i);
      h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36) + ':' + text.length;
  }

  function schluessel(tabelle, id) { return tabelle + '/' + id; }

  /* Gehört dieser Datensatz zum Abgleich? (Tabelle, Kennung, Art des Verlaufs, Kennung des Einstellungs-Dokuments) */
  function dazu(tabelle, rec) {
    if (!Object.prototype.hasOwnProperty.call(TABELLEN, tabelle) || !rec || typeof rec.id !== 'string') return false;
    if (tabelle === 'einstellungen' && !EINSTELLUNG_ID.test(rec.id)) return false;
    if (tabelle === 'verlaeufe' && !Object.prototype.hasOwnProperty.call(VERLAUF_TYPEN, rec.objektTyp)) return false;
    return true;
  }

  /* Zählt ein Schreibvorgang als Änderung für den automatischen Abgleich? (Tabelle und Kennung; GPS-Dokumente und das Geräte-Dokument zählen nicht) */
  function zaehltAlsAenderung(tabelle, id) {
    if (!Object.prototype.hasOwnProperty.call(TABELLEN, tabelle)) return false;
    return tabelle !== 'einstellungen' || EINSTELLUNG_ID.test(String(id));
  }

  /* Nur die empfindlichen Teile eines Wertes, in derselben Form (gleiche Pfade). Nichts Empfindliches darin: undefined. */
  function privatTeil(o) {
    if (Array.isArray(o)) {
      var da = false, r = o.map(function (x) { var p = privatTeil(x); if (p !== undefined) da = true; return p === undefined ? null : p; });
      return da ? r : undefined;
    }
    if (istObjekt(o)) {
      var k = {}, hat = false;
      Object.keys(o).forEach(function (n) {
        if (privat(n)) { if (o[n] !== undefined && o[n] !== null && o[n] !== '') { k[n] = o[n]; hat = true; } }
        else if (!nie(n)) { var p = privatTeil(o[n]); if (p !== undefined) { k[n] = p; hat = true; } }
      });
      return hat ? k : undefined;
    }
    return undefined;
  }

  function hatInhalt(v) { return v !== undefined && v !== null && v !== '' && !(istObjekt(v) && !Object.keys(v).length) && !(Array.isArray(v) && !v.length); }

  /*
   * Was von diesem Datensatz nur verschlüsselt hinausgeht: { aad, text } oder null, wenn es nichts Empfindliches gibt.
   *   p: die empfindlichen Felder mit ihren Pfaden, x: Zusatzfelder (Namen im Reisecheck), w: Angaben im Verlauf, die nicht zu den erlaubten gehören.
   */
  function geheimTeil(tabelle, rec) {
    if (!dazu(tabelle, rec) || tabelle === 'tagespruefungen') return null;
    var g = {}, hat = false;
    var p = privatTeil(rec);
    if (p !== undefined) { g.p = p; hat = true; }
    var ex = EXTRA_LOKAL[tabelle];
    if (ex) {
      var x = {};
      ex.forEach(function (n) { if (hatInhalt(rec[n])) x[n] = rec[n]; });
      if (Object.keys(x).length) { g.x = x; hat = true; }
    }
    if (tabelle === 'verlaeufe') {
      var erlaubt = VERLAUF_TYPEN[rec.objektTyp];
      if (erlaubt && istObjekt(rec.werte)) {
        var w = {};
        Object.keys(rec.werte).forEach(function (n) {
          if (erlaubt.indexOf(n) < 0 && !lokal(n) && rec.werte[n] !== undefined) w[n] = bereinigen(rec.werte[n]);
        });
        if (Object.keys(w).length) { g.w = w; hat = true; }
      }
    }
    return hat ? { aad: tabelle + '/' + rec.id, text: kanonisch(g) } : null;
  }

  /* Der Block aus einem Dienst-Text, oder null. */
  function geheimBlock(nutzlast) {
    if (typeof nutzlast !== 'string' || nutzlast.indexOf('"@geheim"') < 0) return null;
    try { var o = JSON.parse(nutzlast); return typeof o['@geheim'] === 'string' ? o['@geheim'] : null; } catch (e) { return null; }
  }

  /*
   * Der Dienst-Text eines Datensatzes, oder null, wenn er nicht dazugehört (Verlauf einer lokalen Art).
   * block: der verschlüsselte Block (aus MM.Geheim, zu geheimTeil). Ohne block gehen die empfindlichen Angaben nicht hinaus.
   */
  function fuerDienst(tabelle, rec, datenraumId, block) {
    if (!dazu(tabelle, rec)) return null;
    var k = bereinigen(rec);
    (EXTRA_LOKAL[tabelle] || []).forEach(function (n) { delete k[n]; });
    if (k.datenraumId !== undefined && k.datenraumId === datenraumId) k.datenraumId = '@';
    if (tabelle === 'verlaeufe') {
      var erlaubt = VERLAUF_TYPEN[rec.objektTyp];
      if (erlaubt && istObjekt(k.werte)) {
        var w = {};
        erlaubt.forEach(function (n) { if (k.werte[n] !== undefined) w[n] = k.werte[n]; });
        k.werte = w;
      }
    }
    if (tabelle === 'tagespruefungen') {
      /* Vom Prüfergebnis geht nur „ja oder nein, geprüft am“ hinaus, ohne Namen, Gründe und Listen. */
      var s = istObjekt(rec.stand) ? rec.stand : {};
      k.stand = { geprueftAm: s.geprueftAm || null, tagesbeginn: s.tagesbeginn || null, ergebnis: s.befaehigung && s.befaehigung.ergebnis ? s.befaehigung.ergebnis : (s.ergebnis || null),
        fristen: s.fristen ? { betroffen: s.fristen.betroffen || 0, sperre: s.fristen.sperre || 0, eingeschraenkt: s.fristen.eingeschraenkt || 0 } : null };
    }
    if (typeof block === 'string' && block) k['@geheim'] = block;
    var text = kanonisch(k);
    return { tabelle: tabelle, id: rec.id, nutzlast: text, abdruck: abdruck(text), zuGross: text.length > MAX_NUTZLAST, mitBlock: !!k['@geheim'] };
  }

  /* Aus dem Prüfergebnis vom Dienst wieder die Form machen, die die Seiten erwarten (ohne die Angaben, die lokal bleiben). */
  function pruefungAuffuellen(stand) {
    var s = istObjekt(stand) ? stand : {};
    return { geprueftAm: s.geprueftAm || null, tagesbeginn: s.tagesbeginn || null, verantwortlich: null,
      befaehigung: { ergebnis: s.ergebnis || null, gebiet: null, gebietHinweis: null, personen: [] }, ausruestung: null,
      fristen: { betroffen: s.fristen ? s.fristen.betroffen : 0, sperre: s.fristen ? s.fristen.sperre : 0, eingeschraenkt: s.fristen ? s.fristen.eingeschraenkt : 0, liste: [], gesamt: 0 } };
  }

  /* Setzt die lokalen Felder der eigenen Fassung in die Fassung vom Dienst ein (gleicher Pfad). */
  function lokaleFelderEinsetzen(entfernt, eigene, welche) {
    var ist = welche || lokal;
    if (Array.isArray(entfernt) && Array.isArray(eigene)) {
      return entfernt.map(function (x, i) { return i < eigene.length ? lokaleFelderEinsetzen(x, eigene[i], ist) : x; });
    }
    if (istObjekt(entfernt) && istObjekt(eigene)) {
      var k = {};
      Object.keys(entfernt).forEach(function (n) { k[n] = lokaleFelderEinsetzen(entfernt[n], eigene[n], ist); });
      Object.keys(eigene).forEach(function (n) { if (ist(n) && k[n] === undefined) k[n] = eigene[n]; });
      return k;
    }
    return entfernt;
  }

  /*
   * Der Datensatz für diesen Speicher aus dem Dienst-Text. eigene: die vorhandene lokale Fassung (oder null).
   * geheim: { ok: true, daten } mit dem geöffneten Block, oder { ok: false } (kein Schlüsselwort oder falsch). Ohne Block im Text spielt es keine Rolle.
   * Ist der Block nicht geöffnet, bleiben die empfindlichen Angaben der eigenen Fassung stehen und der Block liegt am Datensatz im Feld „geheim“.
   */
  function vonDienst(tabelle, nutzlast, datenraumId, eigene, geheim) {
    var o = JSON.parse(nutzlast);
    var blockText = typeof o['@geheim'] === 'string' ? o['@geheim'] : null;
    delete o['@geheim'];
    if (o.datenraumId === '@') o.datenraumId = datenraumId;
    if (tabelle === 'tagespruefungen') {
      o.stand = eigene && istObjekt(eigene.stand) && eigene.stand.geprueftAm === (o.stand && o.stand.geprueftAm) ? eigene.stand : pruefungAuffuellen(o.stand);
    }
    var offen = !!(blockText && geheim && geheim.ok && istObjekt(geheim.daten));
    var res, g = offen ? geheim.daten : null;
    if (offen) {
      res = o;
      if (g.w && istObjekt(res.werte)) Object.keys(g.w).forEach(function (n) { if (res.werte[n] === undefined) res.werte[n] = g.w[n]; });
      if (g.p !== undefined) res = lokaleFelderEinsetzen(res, g.p, privat);
      if (g.x) Object.keys(g.x).forEach(function (n) { res[n] = g.x[n]; });
      if (eigene) res = lokaleFelderEinsetzen(res, eigene, nurDateiUndSpur);
    } else {
      res = eigene ? lokaleFelderEinsetzen(o, eigene) : o;
    }
    if (blockText && !offen) res.geheim = blockText; else delete res.geheim;
    (EXTRA_LOKAL[tabelle] || []).forEach(function (n) {
      if (offen) res[n] = g.x && g.x[n] !== undefined ? g.x[n] : {};
      else res[n] = eigene && eigene[n] !== undefined ? eigene[n] : {};
    });
    /* Datei-Angaben ohne Inhalt: Der Inhalt kommt beim Abgleich der Dateien nach. */
    if (DATEI_TABELLEN.indexOf(tabelle) >= 0 && res.inhalt === undefined) res.inhalt = null;
    return res;
  }

  /* Ein gelesener Block (Text) wird wieder zur Form der Daten. Ergebnis: { ok, daten } */
  function blockLesen(text) {
    try { var d = JSON.parse(text); return istObjekt(d) ? { ok: true, daten: d } : { ok: false }; } catch (e) { return { ok: false }; }
  }

  /* Hat dieser lokale Datensatz empfindliche Angaben, die jetzt nur hier liegen? (für die Meldung, wenn ein Gerät ohne Wort etwas ändert) */
  function hatPrivates(tabelle, rec) { return !!geheimTeil(tabelle, rec); }

  /*
   * Doppelte Nummern im Änderungsverlauf eines Objekts (zwei Geräte haben unabhängig die nächste Nummer vergeben):
   * Alle Einträge bleiben, die Nummern werden nach dem Zeitpunkt der Änderung neu vergeben. Der zuletzt gemachte Eintrag gilt.
   * Gibt die Einträge zurück, deren Nummer sich ändert (Kopien).
   */
  function nummernNeu(verlaeufe, gruppe) {
    var nach = {}, feld = gruppe || 'objektId';
    verlaeufe.forEach(function (e) { (nach[e[feld]] = nach[e[feld]] || []).push(e); });
    var geaendert = [];
    Object.keys(nach).forEach(function (oid) {
      var l = nach[oid], gesehen = {}, doppelt = false;
      l.forEach(function (e) { if (gesehen[e.nr]) doppelt = true; gesehen[e.nr] = true; });
      if (!doppelt) return;
      l.slice().sort(function (a, b) {
        var za = String(a.erstelltAm || ''), zb = String(b.erstelltAm || '');
        if (za !== zb) return za < zb ? -1 : 1;
        if (a.nr !== b.nr) return a.nr - b.nr;
        return a.id < b.id ? -1 : (a.id > b.id ? 1 : 0);
      }).forEach(function (e, i) { if (e.nr !== i + 1) geaendert.push(Object.assign({}, e, { nr: i + 1 })); });
    });
    return geaendert;
  }

  /* ---------- Anzeige und Hilfen ---------- */
  function zuBase64(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i += 8192) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
    return global.btoa(s);
  }
  function ausBase64(text) {
    var b = global.atob(text), out = new Uint8Array(b.length);
    for (var i = 0; i < b.length; i++) out[i] = b.charCodeAt(i);
    return out;
  }

  /* Wie viele Datensätze je Datenart? zaehlung: { schluessel: abdruck } */
  function zusammenfassung(liste) {
    var z = {};
    liste.forEach(function (x) { var a = TABELLEN[x.tabelle] || 'sonst'; z[a] = (z[a] || 0) + 1; });
    return Object.keys(ARTEN).filter(function (a) { return z[a]; }).map(function (a) { return { art: a, name: ARTEN[a], anzahl: z[a] }; });
  }

  MM.Abgleich = {
    LOKALE_SCHLUESSEL: LOKALE_SCHLUESSEL.slice(), TABELLEN: Object.assign({}, TABELLEN), ARTEN: Object.assign({}, ARTEN), TABELLEN_NAMEN: Object.assign({}, TABELLEN_NAMEN),
    VERLAUF_TYPEN: Object.keys(VERLAUF_TYPEN), NACHWEIS_FELDER: VERLAUF_TYPEN.nachweis.slice(), DATEI_TABELLEN: DATEI_TABELLEN.slice(), VERSCHLUESSELTE_DATEIEN: VERSCHLUESSELTE_DATEIEN.slice(),
    EXTRA_LOKAL: Object.assign({}, EXTRA_LOKAL), MAX_PAKET_BYTES: MAX_PAKET_BYTES, MAX_DATEI_BYTES: MAX_DATEI_BYTES, MAX_NUTZLAST: MAX_NUTZLAST, MAX_KONFLIKTE: MAX_KONFLIKTE,
    SENDE_PAKET: 40, HOL_SEITE: 60, TEIL_BYTES: 256 * 1024, MAX_SICHERUNG_BYTES: 8 * 1024 * 1024,
    bereinigen: bereinigen, kanonisch: kanonisch, abdruck: abdruck, schluessel: schluessel, fuerDienst: fuerDienst, vonDienst: vonDienst,
    lokaleFelderEinsetzen: lokaleFelderEinsetzen, nummernNeu: nummernNeu, geheimTeil: geheimTeil, geheimBlock: geheimBlock, zaehltAlsAenderung: zaehltAlsAenderung, blockLesen: blockLesen, hatPrivates: hatPrivates, dazu: dazu,
    PRIVAT_SCHLUESSEL: PRIVAT_SCHLUESSEL.slice(), NIE_SCHLUESSEL: NIE_SCHLUESSEL.slice(), EINSTELLUNG_ID: EINSTELLUNG_ID, EINSTELLUNG_PRUEFUNG: EINSTELLUNG_PRUEFUNG, PRUEFTEXT: PRUEFTEXT, NUMMERN_TABELLEN: { verlaeufe: 'objektId', eintraege: 'fahrzeugId', komponenteneintraege: 'komponenteId', zaehlerstaende: 'zaehlerId' }, zuBase64: zuBase64, ausBase64: ausBase64, zusammenfassung: zusammenfassung,
    tabellenListe: function () { return Object.keys(TABELLEN); }
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
