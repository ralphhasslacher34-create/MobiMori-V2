/*
 * Cockpit-Wechsel (seit 2.0.104): Das offene Cockpit wechselt regelmäßig zwischen Ansichten, damit der Bildschirm geschont wird
 * und man trotzdem alles sieht (erste Seite, Knöpfe, unterer Bereich, Karte, Ereignisse).
 *
 * Regeln (von Ralph festgelegt):
 *  - Standardmäßig aus. Takt 10 bis 120 Sekunden in 10er-Schritten, Grundeinstellung 30 Sekunden mit den Seiten des Cockpits.
 *  - Jeder wählt selbst, welche Ansichten vorkommen und in welcher Reihenfolge.
 *  - Die Einstellung gehört zur Aktivität und bleibt erhalten (Dokument „wechsel-<aktivitaetId>“ in „einstellungen“).
 *  - Der Wechsel pausiert, sobald jemand tippt oder eine Frage / ein Eingabefeld offen ist, und läuft nach einer Ruhezeit weiter.
 *  - Der Wechsel läuft nur bei offener App (sichtbares Dokument).
 *
 * Hier steht nur die Rechnung und die Steuerung. Die Umgebung (Zeit, Zeitgeber, Dokument) wird übergeben, damit sie sich testen lässt.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var TAKT_MIN = 10, TAKT_MAX = 120, TAKT_SCHRITT = 10, TAKT_STANDARD = 30;
  /* Ruhezeit nach dem letzten Tippen, bevor der Wechsel weiterläuft (Sekunden). */
  var RUHEZEIT = 60;

  /* Die möglichen Ansichten. „seite“: Nummer der Cockpit-Seite (0-basiert), sonst eine eigene Fläche über den Seiten. */
  var ANSICHTEN = [
    { id: 'info', name: 'Info (erste Seite)', kurz: 'Info', seite: 0 },
    { id: 'knoepfe', name: 'Knöpfe', kurz: 'Knöpfe', seite: 1 },
    { id: 'mehr', name: 'Motoren, Zähler und Tagesabschluss', kurz: 'Mehr', seite: 2 },
    { id: 'karte', name: 'Karte', kurz: 'Karte', seite: null },
    { id: 'ereignisse', name: 'Ereignisse', kurz: 'Ereignisse', seite: null }
  ];
  var STANDARD_ANSICHTEN = ['info', 'knoepfe', 'mehr'];

  function ansichtBekannt(id) { return ANSICHTEN.some(function (a) { return a.id === id; }); }
  function ansichtHolen(id) { return ANSICHTEN.filter(function (a) { return a.id === id; })[0] || null; }

  /* Ein gültiger Takt in Sekunden oder null. */
  function taktGueltig(wert) {
    if (wert === null || wert === undefined || wert === '') return null;
    var n = Number(wert);
    if (!isFinite(n) || Math.floor(n) !== n || n < TAKT_MIN || n > TAKT_MAX || (n - TAKT_MIN) % TAKT_SCHRITT !== 0) return null;
    return n;
  }
  function taktListe() {
    var l = [];
    for (var s = TAKT_MIN; s <= TAKT_MAX; s += TAKT_SCHRITT) l.push(s);
    return l;
  }
  function taktText(s) { return s % 60 === 0 ? (s / 60 === 1 ? '1 Minute' : (s / 60) + ' Minuten') : (s > 60 ? Math.floor(s / 60) + ' Min. ' + (s % 60) + ' Sek.' : s + ' Sekunden'); }

  /* Eine Liste von Ansichten: nur bekannte, jede höchstens einmal, in der gegebenen Reihenfolge. Leer bleibt leer. */
  function ansichtenGueltig(liste) {
    var aus = [];
    (Array.isArray(liste) ? liste : []).forEach(function (id) {
      if (ansichtBekannt(id) && aus.indexOf(id) < 0) aus.push(id);
    });
    return aus;
  }

  function standard() { return { an: false, takt: TAKT_STANDARD, ansichten: STANDARD_ANSICHTEN.slice() }; }

  /* Aus einem gespeicherten Dokument (oder nichts) eine vollständige Einstellung machen. */
  function lesen(dok) {
    var s = standard();
    if (!dok) return s;
    var takt = taktGueltig(dok.takt);
    if (takt !== null) s.takt = takt;
    if (Array.isArray(dok.ansichten)) {
      var l = ansichtenGueltig(dok.ansichten);
      if (l.length) s.ansichten = l;
    }
    s.an = dok.an === true;
    return s;
  }

  /* Die Eingabe aus dem Formular prüfen: { ok, einstellung } oder { ok: false, fehler }. werte.platz1 … platz5 sind Ansichten oder leer. */
  function ausFormular(werte) {
    var w = werte || {}, fehler = {};
    var takt = taktGueltig(w.takt);
    if (takt === null) fehler.takt = 'Bitte einen Takt aus der Liste wählen (10 bis 120 Sekunden).';
    var plaetze = [w.platz1, w.platz2, w.platz3, w.platz4, w.platz5];
    var l = ansichtenGueltig(plaetze);
    if (!l.length) fehler.platz1 = 'Bitte mindestens eine Ansicht wählen.';
    if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
    return { ok: true, einstellung: { an: w.an === 'an' || w.an === true, takt: takt, ansichten: l } };
  }

  /* Die nächste Ansicht nach der aktuellen (am Ende wieder die erste). Ist die aktuelle nicht in der Liste, kommt die erste. */
  function naechste(ansichten, aktuell) {
    if (!ansichten || !ansichten.length) return null;
    var i = ansichten.indexOf(aktuell);
    return ansichten[(i + 1) % ansichten.length];
  }

  /*
   * Die Steuerung. umgebung: { jetzt(), setzeZeitgeber(fn, ms), loescheZeitgeber(id), sichtbar(), pausiert() }.
   * beiWechsel(ansichtId) zeigt die Ansicht. Ein Aufruf von eingabe() meldet ein Tippen (Pause bis zur Ruhezeit).
   */
  function steuerung(umgebung, beiWechsel) {
    var u = umgebung, einst = null, aktuell = null, timer = null, letzteEingabeMs = -Infinity, laeuft = false;

    function planen(ms) {
      if (timer !== null) { u.loescheZeitgeber(timer); timer = null; }
      if (!laeuft) return;
      timer = u.setzeZeitgeber(tick, ms);
    }
    function tick() {
      timer = null;
      if (!laeuft || !einst) return;
      /* Nicht wechseln: App nicht sichtbar, Frage oder Eingabefeld offen, oder es wurde gerade getippt. */
      var seitEingabe = u.jetzt() - letzteEingabeMs;
      if (!u.sichtbar() || (u.pausiert && u.pausiert())) { planen(Math.min(einst.takt, 10) * 1000); return; }
      if (seitEingabe < RUHEZEIT * 1000) { planen(Math.max(1000, RUHEZEIT * 1000 - seitEingabe)); return; }
      var n = naechste(einst.ansichten, aktuell);
      if (n === null) return;
      aktuell = n;
      beiWechsel(n);
      planen(einst.takt * 1000);
    }

    return {
      /* Einstellung setzen und (bei „an“) loslaufen. start: die Ansicht, die gerade zu sehen ist. */
      starten: function (einstellung, start) {
        einst = einstellung;
        laeuft = !!(einstellung && einstellung.an && einstellung.ansichten && einstellung.ansichten.length);
        aktuell = start && einstellung && einstellung.ansichten.indexOf(start) >= 0 ? start : (einstellung && einstellung.ansichten ? einstellung.ansichten[0] : null);
        if (laeuft) planen(einstellung.takt * 1000); else planen(0);
        return aktuell;
      },
      anhalten: function () { laeuft = false; planen(0); },
      eingabe: function () { letzteEingabeMs = u.jetzt(); },
      aktuell: function () { return aktuell; },
      laeuft: function () { return laeuft; },
      /* Zum Merken über ein neues Zeichnen des Cockpits hinweg */
      setzeAktuell: function (id) { aktuell = id; }
    };
  }

  /* Ist im Cockpit eine Frage offen? Ausgeblendete Karten zählen nicht (seit 2.0.132: die Karte zum Kreuzen steht bei Booten immer, aber versteckt). */
  function frageOffen(karten) { return (karten || []).some(function (f) { return !!f && !f.hidden; }); }

  MM.CockpitWechsel = {
    TAKT_MIN: TAKT_MIN, TAKT_MAX: TAKT_MAX, TAKT_SCHRITT: TAKT_SCHRITT, TAKT_STANDARD: TAKT_STANDARD, RUHEZEIT: RUHEZEIT,
    ANSICHTEN: ANSICHTEN, STANDARD_ANSICHTEN: STANDARD_ANSICHTEN,
    ansichtBekannt: ansichtBekannt, ansichtHolen: ansichtHolen, taktGueltig: taktGueltig, taktListe: taktListe, taktText: taktText,
    ansichtenGueltig: ansichtenGueltig, standard: standard, lesen: lesen, ausFormular: ausFormular, naechste: naechste, steuerung: steuerung,
    frageOffen: frageOffen
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
