/*
 * Texte, die das Programm von sich selbst zeigt: Kernsatz, Infotext,
 * Copyright und die Liste "Neu im Programm". Nur hier ändern.
 * Das Logo ist die Datei icons/icon.svg (zugleich das App-Symbol).
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  MM.Texte = {
    KERNSATZ: 'Dein Fahrzeug. Dein Weg. Deine Daten.',
    INFOTEXT: 'Fahrzeuge verwalten, Reisen planen und Erinnerungen festhalten. Auf Land, zu Wasser und in der Luft.',
    COPYRIGHT: '© 2026 Ralph Hasslacher',

    /* Hinweis zur Aufzeichnung (seit 2.0.101, Hintergrund-Aufzeichnung Teil 1). Kilometerzählung und GPS laufen nur bei offener App.
       Die Texte stehen hier an einer Stelle: im Cockpit, bei der Aktivität und auf der Startseite, später auch für Homepage und Store. */
    AUFZEICHNUNG: {
      kurz: 'Die Aufzeichnung läuft nur bei offener App.',
      cockpit: 'Aufzeichnung nur bei offener App: Kilometer und GPS werden nur gezählt, solange MobiMory im Vordergrund offen ist. Wechselst du in eine andere App oder wird der Bildschirm gesperrt, wird in dieser Zeit nichts aufgezeichnet.',
      wachhalten: 'MobiMory hält den Bildschirm an, solange das Cockpit offen ist.',
      ohneWachhalten: 'Dieser Browser kann den Bildschirm nicht wachhalten. Lass ihn selbst an und die App offen.',
      lang: 'Kilometerzählung und GPS-Aufzeichnung laufen nur, solange MobiMory offen ist. Im Cockpit hält die App den Bildschirm an. Wechselst du in eine andere App oder sperrst du den Bildschirm, wird in dieser Zeit nichts aufgezeichnet. Eine Aufzeichnung im Hintergrund gibt es erst mit der Android-App (geplant für Version 2.1).',
      /* Für Homepage und Store (die Seiten selbst entstehen woanders) */
      werbung: 'Aufgezeichnet wird bei offener App: Kilometer und GPS zählen, solange MobiMory geöffnet ist. Der Bildschirm bleibt im Cockpit an.',
      store: 'Hinweis: Die Aufzeichnung von Strecke und Position läuft nur bei geöffneter App, nicht im Hintergrund.',
      /* In der Android-App (seit 2.0.110) */
      huelle: {
        kurz: 'In der Android-App läuft die Aufzeichnung auch im Hintergrund.',
        cockpit: 'Aufzeichnung auch im Hintergrund: In der Android-App zählen Kilometer und GPS weiter, wenn du in eine andere App wechselst oder den Bildschirm sperrst. Solange das Cockpit offen ist, zeigt Android dafür die Benachrichtigung „MobiMory zeichnet auf“.'
      }
    },

    /* Update-Hinweis in der Android-App (seit 2.0.113) */
    AKTUALISIERUNG: {
      hinweis: 'Neue Version {version} von MobiMory verfügbar.',
      herunterladen: 'Herunterladen',
      spaeter: 'Später'
    },

    /* Neueste Version zuerst. Die oberste muss zu MM.VERSION passen (wird getestet). */
    NEUERUNGEN: [
    { version: '2.0.132', datum: '2026-11-27', punkte: [
      'Fahrzeug wiederfinden: Nach einem Wache-Alarm siehst du dein Fahrzeug am Handy live auf der Karte, mit der Strecke seit dem Alarm. Dafür braucht es Konto, Schlüsselwort, GPS und Internet.',
      'Wassertanks kannst du unter „Ver- und Entsorgung“ auffüllen und entleeren.',
      'Wache: Der Alarmton ist bei der Standortwache aus und bei der Ankerwache an vorgewählt.',
      'Wasserfahrzeuge: Der Cockpit-Wechsel läuft wieder, und „Person über Bord“ ist auch in seiner Karte.'
    ] },
    { version: '2.0.131', datum: '2026-11-25', punkte: [
      '„Person über Bord“ kommt sofort im Vollbild: große Karte, Entfernung und Kurs oben klein, unten eine Knopfreihe.'
    ] },
    { version: '2.0.130', datum: '2026-11-25', punkte: [
      'Ablegen, Anlegen und Anker (an Land: Abfahrt, Anhalten, Ankunft) stehen jetzt oben auf der dritten Cockpit-Seite. Du siehst nur, was gerade passt.',
      'Kreuzen: Unter „Kurswechsel“ mit Countdown bis zur nächsten Wende oder Halse, auch vorab planbar.',
      'Segelboot: Segeln, Motorfahrt und Motorsegeln mit Strecken im Logbuch. Steuerkurs eingeben und den Versatz sehen.',
      '„Person über Bord“ öffnet eine Karte mit Weg des Boots, „Person gesichtet“ und einem geschätzten Suchbereich. Es ersetzt keinen Notruf.'
    ] },
    { version: '2.0.129', datum: '2026-11-25', punkte: [
      'Segelboot: Segel und Mast/Rigg legst du als Komponenten an, mit Fristen. Reffart, Reffstufen und Segelfläche sind Merkmale.',
      'Segelmanöver mit einem Druck, zum Beispiel Wende, Halse oder Reffen. MobiMory hält Kurs und Fahrt vorher und nachher fest und erkennt das Ende selbst.',
      '„Person über Bord“ steht bei Wasserfahrzeugen oben im Cockpit und zeigt Abstand und Richtung zurück. Es ersetzt keinen Notruf.',
      'Neu unter Einstellungen: „Segeln“ (Windeinheit, Erkennung der Manöver).'
    ] },
      { version: '2.0.128', datum: '2026-11-24', punkte: [
        'Handbuch viel genauer: In fast allen Kapiteln steht jetzt Schritt für Schritt, was du antippst, zum Beispiel beim Scannen von Dokumenten, beim Anlegen von Komponenten, Fristen und Zählern, bei Personen und Nachweisen, Orten und Gebieten, beim Logbuch, bei der Karte und der Reisekasse. Neu ist das Kapitel „Häufige Fragen“.',
        'Hilfe direkt in der App: Auf den wichtigsten Seiten steht unter der Überschrift „? Hilfe“. Tippe darauf, dann siehst du in zwei, drei Sätzen, worum es geht, und kommst mit einem Tipp in die ganze Anleitung.'
      ] },
      { version: '2.0.127', datum: '2026-11-22', punkte: [
        'Fehler behoben, Update kam nicht an: Seit 2.0.125 blieben viele Geräte auf der alten Version, weil die Bilder des Handbuchs nicht mit ins Internet gestellt wurden. Das ist jetzt behoben, das Update installiert sich wieder von selbst. Wer noch auf einer alten Version ist: Seite einmal schließen und neu öffnen, dann holt sich MobiMory die neue Version.'
      ] },
      { version: '2.0.126', datum: '2026-11-22', punkte: [
        'Handbuch viel ausführlicher bei den Stammdaten: Neu sind die Kapitel „Meine Stammdaten“, „Ich bringe meine Daten in MobiMory: fünf Wege“, „Ich pflege mein Fahrzeug“, „Personen, Tiere und Nachweise“, „Orte, Gebiete und Adressen“ und „Auswahllisten“. Sie erklären, wie du Personen und Fahrzeuge erfasst (von Hand, Schnellstart, Dokument erfassen mit Scan, Excel oder CSV, Übergabedatei), was unter einem Fahrzeug hängt (Äußere Hülle, Hauptkomponenten, Teile, Fristen, Dokumente, Nachweise, Anforderungen, Heimatstandort) und was die übrigen Stammdaten sind. Wo und wie: Einstellungen › Über MobiMory › Handbuch.',
        'Zu jedem Kapitel gibt es jetzt ein Bild, bei mehreren wichtigen Seiten mehrere: insgesamt 32 Bilder, aus der echten App erzeugt. Das PDF enthält sie auch. Dazu im Kapitel „Ich will tanken“ der Hinweis, dass „Ver- und Entsorgung“ erst nach „Vorschläge für Fahrzeugarten übernehmen“ (Stammdaten › Arten von Ereignissen) zur Verfügung steht.'
      ] },
      { version: '2.0.125', datum: '2026-11-22', punkte: [
        'Handbuch: MobiMory hat jetzt eine Bedienungsanleitung, geordnet nach Aufgaben („Ich will tanken“, „Ich will eine Route planen“) – vom Schnellstart über Einrichten auf Browser, Android und iPad, Stammdaten und die 19 Fahrzeugarten, Route, Reisecheck, Wetter, Cockpit, Karte, Wache bis zu Reisebuch, mehreren Geräten und Verleih. Fünf Bilder zeigen die Schlüsselstellen. Es gibt das Handbuch auf Deutsch und Englisch (Umschalter oben). Wo und wie: Einstellungen › Über MobiMory › Handbuch. Dort speicherst du es auch als PDF zum Drucken; das PDF erzeugt die App selbst, auch ohne Internet.',
        'Fehler behoben, Strecke und Ankunftszeit bei Rundreisen: Für Straßenfahrzeuge rechnen die Strecke des Tages und die ETA jetzt mit der geplanten Tagesroute und nicht mehr mit der Route der ganzen Aktivität. Vorher zeigte eine Rundreise (zum Beispiel Sersheim – Pisa – zurück) für Tag 1 die Strecke der ganzen Reise. Ist der Tag noch nicht geplant, steht bei der ETA „unklar“ mit dem Hinweis, den Tag zu planen. Das gilt auch für die ETA und den Rest im Cockpit. Wo und wie: auf der Seite des Tages „Tag planen“, danach stimmen Strecke und ETA. Wasserfahrzeuge rechnen wie bisher.'
      ] },
      { version: '2.0.124', datum: '2026-11-22', punkte: [
        'Geführter Start: Beim ersten Öffnen fragt MobiMory, wie du loslegen willst – „Ich lege eine Person und Fahrzeuge an“ oder „Ich melde mich mit einem Konto an“. Danach geht es in drei kurzen Schritten: Person, Fahrzeug, erste Aktivität. Am Ende landest du im Cockpit deiner ersten Aktivität. Wo und wie: Hauptmenü › Schnellstart – du kannst ihn überspringen und jederzeit neu aufrufen.',
        'Weniger, aber klarer: Es gibt jetzt 19 Fahrzeugarten – 8 an Land (Auto, Motorrad, Transporter, Lkw, Wohnmobil, Wohnwagen, Anhänger, Bootstrailer), 10 auf dem Wasser (Motorboot, Segelboot Monohull, Katamaran, Jolle, Schlauchboot/RIB, Jetski, Hausboot, Beiboot/Dinghy, Paddel-/Ruderboot, Sonstiges Wasserfahrzeug) und das Flugzeug. „Oldtimer“ ist jetzt ein Zustand, Wasserski und Übernachten bleiben als Eignung wählbar.',
      ] },
      { version: '2.0.123', datum: '2026-11-22', punkte: [
        'Mehr Zwischenziele und eine feste Reihenfolge: Bei „Aktivität planen“ und „Aktivität ändern“ sind die Zwischenziele jetzt eine nummerierte Liste (Reiseplan). Mit „Hoch“ und „Runter“ stellst du die Reihenfolge ein, mit „Hinzufügen“ und „Entfernen“ änderst du die Orte. Die Planung fährt sie genau in dieser Reihenfolge an, auch Karte, Reisebuch und Plan gegen Ist nutzen sie so. Bestehende Aktivitäten behalten ihre Zwischenziele in der bisherigen Reihenfolge.',
        'So viele Zwischenziele, wie die Aktivität Tage hat: gezählt von Datum bis Datum, beide Tage zählen (21 Tage = 21 Zwischenziele), höchstens 25. Die Karte zeigt die Zwischenziele mit ihrer Nummer. Die Zwischenziele brauchen einen Ort mit Position (zum Beispiel Bozen statt „Südtirol“).',
        'Zwischenziele für einen einzelnen Tag: Auf der Seite eines Tages (Abschnitt „Route des Tages“) wählst du bis zu 10 Zwischenziele in ihrer Reihenfolge und tippst „Zwischenziele speichern“. „Tag planen“ nimmt sie mit, die Karte des Tages zeigt sie. Die Planung zählt weiter 1 Route. Dafür muss der Dienst neu hochgeladen werden (server/EINRICHTUNG.md, „Update 2.0.123“).',
      ] },
      { version: '2.0.122', datum: '2026-11-21', punkte: [
        'Alarm der Wache: „Ton aus“ hält jetzt, und die Knöpfe reagieren zuverlässig. Vorher kam der Alarm nach jedem neuen GPS-Punkt wieder. „Karte öffnen“ stellt den Ton ebenfalls ab.',
        'Nachrichten prüfen: Auf der Wache-Seite steht, ob dieses Gerät für Nachrichten angemeldet ist, und es gibt eine Test-Nachricht an deine anderen Geräte. Nach einem Alarm zeigt die Alarm-Anzeige, an wie viele Geräte die Nachricht ging und ob die E-Mail gesendet wurde. Für die Gründe bei Fehlern muss der Dienst neu hochgeladen werden.',
      ] },
      { version: '2.0.121', datum: '2026-11-20', punkte: [
        'Alarm-Nachrichten auch in der Android-App: Auf der Wache-Seite „Nachrichten auf diesem Gerät erlauben“ tippen und die Android-Frage mit „Zulassen“ beantworten. Löst danach auf einem anderen Gerät eine Wache aus, kommt hier eine Nachricht mit Alarmton an. Voraussetzung: Konto angemeldet und der Dienst auf Stand 13h mit Firebase-Schlüssel.',
      ] },
      { version: '2.0.120', datum: '2026-11-20', punkte: [
        'Weg und Kilometer stimmen jetzt auf allen Geräten: Läuft die Aufzeichnung auf zwei Geräten, werden Weg und Kilometer beim Abgleich zusammengeführt statt überschrieben. Die gerade Linie bei kurzer Abwesenheit füllt sich, sobald das andere Gerät abgleicht. Das offene Cockpit übernimmt Neues von anderen Geräten.',
        'Ankerwache und Standortwache (Alarmanlage): Im Cockpit gibt es den Knopf „Wache“. Vor Anker merkt sich die App die Position und schlägt Alarm, wenn das Fahrzeug über den gewählten Radius hinaustreibt, mit Ton, Abstand, Richtung und einer Zeichnung des Versatzes. Bei Stillstand oder festgemacht überwacht die Standortwache jedes Fahrzeug. Die Wache braucht kein Internet. Im Browser muss der Bildschirm an bleiben; sicherer ist die Android-Hülle.',
        'Nachrichten auf deine anderen Geräte: Löst eine Wache aus, geht eine Nachricht an deine anderen angemeldeten Geräte (wenn dort Nachrichten erlaubt sind) und eine E-Mail an dein Konto. Das ist eine Zusatzwarnung und braucht Internet. Dafür muss der Dienst auf den Stand 13h gebracht werden.',
        'Bildschirm: Dauerhaft an bleibt er nur bei „In Fahrt“, an Land und auf dem Wasser. Sonst gilt die Bildschirmzeit deines Geräts.',
      ] },
      { version: '2.0.119', datum: '2026-11-20', punkte: [
        'Synchron auf allen Geräten: Was du auf einem Gerät einträgst, ist auf deinen anderen angemeldeten Geräten da. In der Testwoche und mit Mittel oder Voll gleicht die App von allein ab, solange sie offen ist: kurz nach einer Änderung, sonst fragt sie jede Minute, ob es etwas Neues gibt. Der erste Abgleich auf einem neuen Gerät ist von Hand (Konto › Jetzt abgleichen). Mit Basic gleichst du nur von Hand ab.',
        'Schlüsselwort für alles Private: Notizen, Telefonnummern, E-Mail- und Postadressen, Nachweis-Nummern, Namen im Reisecheck, Scans und die GPS-Spur gehen nur verschlüsselt zum Dienst, der Dienst kann sie nicht lesen. Du gibst das Wort einmal je Gerät ein, es bleibt auf dem Gerät gespeichert. Vergisst du es und hast kein Gerät mehr mit gespeichertem Wort, sind diese Angaben nicht mehr zu öffnen.',
        'Mehr geht mit: Standorte, Anforderungen, Wechselpunkte, Tagesrouten, Kartenauswahl und Cockpit-Wechsel sind jetzt auf allen Geräten gleich. Die GPS-Spur (Strecke, Fahrtwerte, gefahrener Weg) geht verschlüsselt mit, gebündelt beim Seitenwechsel oder wenn die App ausgeblendet wird, nicht Punkt für Punkt.'
      ] },
      { version: '2.0.118', datum: '2026-11-19', punkte: [
        'Karte: Liegt ein Wetterpunkt genau auf einem Wechselpunkt, bleibt der Wechselpunkt auf der Route und der Wetterpunkt steht daneben. Beide lassen sich einzeln antippen. Im Feld „Ereignisse“ gibt es neu „Punkte der Route“ mit den Schaltern „Wetterpunkte“ und „Wechselpunkte“.',
        'Weniger Wechselpunkte: Auf der Seite „Route und Wetter“ kannst du einen Mindestabstand in Seemeilen und eine Kursänderung in Grad einstellen. Punkte, die näher beieinander liegen, werden zusammengefasst. Ein Punkt mit deutlicher Kursänderung, der erste, der letzte und jeder Punkt mit eigenem Namen bleiben immer. Die Datei selbst bleibt unverändert. Ohne Eingabe ändert sich nichts.',
        'Reisegeschwindigkeit: Trägst du bei der Route nichts ein, nimmt die App die Reisegeschwindigkeit deines Fahrzeugs, unterwegs den gemessenen Durchschnitt. Darunter steht, woher der Wert kommt. Ein eigener Wert gilt immer vor dem vorbelegten.'
      ] },
      { version: '2.0.117', datum: '2026-11-19', punkte: [
        'Wechselpunkte von Hand: Auf der Seite „Route und Wetter“ kannst du einen Wechselpunkt selbst eintragen. Du tippst Breite und Länge ein oder nimmst die aktuelle Position, der Name ist freiwillig. Der Punkt steht in der Reihenfolge nach dem nächsten Punkt der Route, du kannst ihn umbenennen und löschen. Auch bei einer aufgezeichneten Spur gibt es so Wechselpunkte (mindestens zwei). Soll-Kurs, Abstand, Cockpit-Zeile und Karte arbeiten wie bei den Punkten aus der Datei.',
        'Position nachträglich ändern: Wer bei einem Ereignis (auch bei einem Kurswechsel) die Position ändert, muss dazuschreiben, warum. Der Verlauf hält genau fest, wer es war (der Verantwortliche), wann, warum, und die alte und neue Position. Das steht im Abschnitt „Änderungen der Position“ und im Reisebuch.',
        'Geräte im Konto: Unter Konto siehst du jetzt alle angemeldeten Geräte und kannst jedes andere abmelden. Ist die erlaubte Zahl an Geräten erreicht, fragt dich die App beim Anmelden, ob das älteste Gerät abgemeldet werden soll. Dafür muss der Konto-Dienst auf den neuen Stand gebracht werden.'
      ] },
      { version: '2.0.116', datum: '2026-11-19', punkte: [
        'Kurswechsel (nur Wasserfahrzeuge): Neuer Knopf im Cockpit. Du tippst „Kurswechsel festhalten“, wählst einen Grund (geplant, Plan geändert, Hindernis, Wetter, Strömung/Wind, falscher Kurs, sonstiges) und schreibst bei Bedarf eine Notiz. Datum, Uhrzeit und Position trägt MobiMory selbst ein, auf der Karte erscheint das Zeichen „KW“. Der Kurs kommt nur vom GPS (Kurs über Grund) und gilt erst, wenn das Fahrzeug fährt.',
        'Wechselpunkte: Die Routenpunkte deiner GPX-Datei (zum Beispiel aus NavShip) sind jetzt die Wechselpunkte. Auf der Seite der Route siehst du sie mit Soll-Kurs und Entfernung und kannst jedem einen eigenen Namen geben. Mehrere Punkte an derselben Stelle zählen als ein Wechselpunkt. Eine aufgezeichnete Spur hat keine Wechselpunkte: Dafür brauchst du eine geplante Route aus deiner Navi-App. Ältere Routen bitte noch einmal einlesen.',
        'Cockpit und Karte: Eine Zeile unter der Position meldet den nächsten Wechselpunkt mit Abstand in Seemeilen und Soll-Kurs, ab 2 Seemeilen hervorgehoben. Auf der Karte stehen die Wechselpunkte als Nummern, die blaue Linie ist der Soll-Kurs, die orange der gefahrene Weg.'
      ] },
      { version: '2.0.115', datum: '2026-11-19', punkte: [
        'Verantwortlicher Wechsel: Im Cockpit gibt es jetzt nur noch einen Knopf für den Wechsel von Skipper und Rudergänger. Bei Wasserfahrzeugen setzt du einen oder beide Haken („Rudergänger“, „Skipper“) und tippst, wer jetzt am Ruder steht und wer neuer Skipper ist. Das kann dieselbe Person sein. Neuer Skipper kann nur ein Stellvertreter werden, ans Ruder kann jede Person an Bord. Der Skipper bleibt verantwortlich, auch wenn jemand anderes am Ruder steht. An Land gibt es nur den Wechsel des Fahrers.',
        'Position: Beim Festhalten des Wechsels speichert MobiMory die Position des Fahrzeugs mit Datum und Uhrzeit. Du kannst sie von Hand eintragen oder ändern, auch beim Nachtragen.',
        'Karte: Wechsel mit Position erscheinen mit dem Zeichen „SW“ (Skipperwechsel) und „RW“ (Rudergängerwechsel), an Land mit „FW“ (Fahrerwechsel). Unter „Ereignisse“ wählst du, ob du sie sehen willst.'
      ] },
      { version: '2.0.114', datum: '2026-11-19', punkte: [
        'Android-App: Speichern, Teilen und Öffnen funktionieren jetzt. Sicherung, Tabellen, PDF, GPX-Routen, Dokumente und Fotos gibst du über das Teilen-Fenster von Android aus (zum Beispiel „In Downloads speichern“, Mail oder Cloud). PDF und Bilder öffnest du direkt.',
        'Cockpit: Die grüne Meldung nach einem Tipp (zum Beispiel Tanken oder Wetter) verschwindet nach spätestens 60 Sekunden von selbst.',
        'Wasserfahrzeuge: Im Cockpit heißen die Knöpfe „Ablegen“ und „Anlegen“ statt „Abfahrt“ und „Ankunft“.',
        '„Über MobiMory“ zeigt nur noch die Versionsnummer. Was neu ist, steht hier unter „Neu in MobiMory“.'
      ] },
      { version: '2.0.113', datum: '2026-11-18', punkte: [
        'Android-App: Beim Start prüft die App jetzt, ob es eine neuere Version gibt. Wenn ja, erscheint oben „Neue Version verfügbar“ mit einem Knopf zum Herunterladen. Die Datei öffnet sich im Browser deines Geräts, dort tippst du sie an und installierst sie. Deine Daten bleiben dabei erhalten.',
        'Die Android-App gibt es jetzt als Download auf mobimory.com, mit Kurzanleitung zum Installieren.'
      ] },
      { version: '2.0.112', datum: '2026-11-18', punkte: [
        'Android-App: Korrektur im Bau der App-Datei (APK), damit sie sich als Update über die alte installieren lässt. Für dich als Nutzer ändert sich nichts.'
      ] },
      { version: '2.0.111', datum: '2026-11-18', punkte: [
        'Gefahrener Weg in der Karte: Die Karte im Cockpit-Wechsel und die Karte der Aktivität zeichnen den Strich des gefahrenen Wegs jetzt beim Fahren mit. Vorher bewegte sich nur dein Positionspunkt, der Strich erschien erst, wenn du die Karte neu geöffnet hast.',
        'Android-App: Die Anmeldung per E-Mail-Code funktioniert jetzt auch in der Android-App.'
      ] },
      { version: '2.0.110', datum: '2026-11-18', punkte: [
        'Android-App (Teil 1): MobiMory gibt es jetzt zusätzlich als Android-App. Der Browser und der PC bleiben wie bisher. Die App zeichnet Position und Kilometer auch auf, wenn du in eine andere App wechselst oder den Bildschirm sperrst. Solange das Cockpit offen ist, zeigt Android dafür die Benachrichtigung „MobiMory zeichnet auf“. Verlässt du das Cockpit, endet der Dauerdienst.',
        'Der Hinweis zur Aufzeichnung in der Android-App sagt jetzt, dass die Aufzeichnung auch im Hintergrund läuft. Im Browser steht weiter „nur bei offener App“.',
        'Apple (iPhone, iPad) kommt später. Dort gilt bis dahin die Web-App mit der Einschränkung „nur bei offener App“.'
      ] },
      { version: '2.0.109', datum: '2026-11-17', punkte: [
        'Karte im Wechsel: Wenn das Cockpit automatisch auf die Karte wechselt, füllt sie jetzt den ganzen Bildschirm, genau wie beim Knopf „Karte“. Oben steht die Leiste mit Logbuch, Hauptmenü, Zurück, Folgen, Alles zeigen, Wetter jetzt, Offline-Karte und Ereignisse. „Zurück“ bringt dich auf die Cockpit-Seite.'
      ] },
      { version: '2.0.108', datum: '2026-11-17', punkte: [
        'Karte: Die Karte füllt jetzt die ganze Seite. Die Knöpfe stehen als schmale Leiste oben, Position und gefahrener Weg als eine Zeile unten. Antippen der Zeile zeigt alles Weitere.',
        'Ereignisse auf der Karte: Einträge mit Position erscheinen mit eigenem Zeichen auf der Karte, zum Beispiel ! für eine Störung oder M für den Motor. Unter „Ereignisse“ wählst du, welche Arten du sehen willst: einmal als Vorauswahl für alle Aktivitäten und bei jeder Aktivität extra.',
        'Wasserfahrzeuge: Auf Wunsch zeigt die Karte Seezeichen (Tonnen, Leuchtfeuer, Häfen) von OpenSeaMap. Das ist nur eine Information und keine amtliche Karte, es gibt keine Wassertiefen. Für die Navigation bleibt deine Navi-App und die amtliche Seekarte zuständig. Die Seezeichen werden beim Holen der Offline-Karte mitgeholt.',
        'Reisetagebuch: Neu sind die „Übersichtskarte der Reise“ und eine „Karte je Tag“. Die Karte wird als Bild bei der Reise gespeichert, damit sie später auch ohne Internet gleich aussieht. Auf dem Bild stehen das Datum, woher die Positionen stammen und die Quelle der Karte. Du findest die Schalter im Reisebuch unter „Karten“, mit „Karten neu zeichnen“ erneuerst du sie.'
      ] },
      { version: '2.0.107', datum: '2026-11-17', punkte: [
        'Motor und Verbraucher: Wenn du im Cockpit einen Motor oder Verbraucher ein- oder ausschaltest, schreibt MobiMory dazu einen Eintrag ins Logbuch („Motor Backbord gestartet“). Der Eintrag hat die Quelle „Nutzer“, die Zeit von der Uhr des Geräts und, wenn das Gerät eine Position hat, die GPS-Position im Moment des Tippens. So lässt sich später genau nachweisen, wann und wo du den Motor ein- oder ausgeschaltet hast. Die Läufe und die Betriebsstunden bleiben wie bisher. Kommt die Zeit schon von einem anderen Eintrag (zum Beispiel Ankunft), gibt es keinen zweiten.',
        'Im Reisebuch stehen diese Einträge nur bei „Jeder Eintrag einzeln“, also im Vollständigen Logbuch, nicht im Reisetagebuch.'
      ] },
      { version: '2.0.106', datum: '2026-11-17', punkte: [
        'Rudergänger: Bei Wasserfahrzeugen gibt es jetzt neben „Verantwortung wechseln“ einen eigenen Wechsel des Rudergängers. Der Skipper bleibt verantwortlich, auch wenn jemand anderes am Ruder steht, und steht am Anfang selbst am Ruder. Ans Ruder kann jede Person, die dabei ist, MobiMory prüft dabei nichts. Der Knopf „Rudergänger wechseln“ steht im Cockpit auf der Seite mit den Knöpfen, oben stehen Skipper und Rudergänger. Jeder Wechsel kommt von selbst ins Logbuch, und auf der Aktivität siehst du, wer wie lange am Ruder war.',
        'Reisebuch mit Auswahl: Du wählst nach der Reise, was ins Buch kommt: zum Beispiel nur Bilder und die Texte aus dem Tagesabschluss (Reisetagebuch) oder jeden einzelnen Schritt mit Datum, Uhrzeit, Position, Motorlaufzeiten, Wetter und Störungen (Vollständiges Logbuch). Dazu gibt es fertige Zusammenstellungen, und eigene kannst du mit Namen speichern und bei jeder Reise wieder nehmen. Jedes Buch hat eine Titelseite und Seitenzahlen; beim vollständigen Logbuch steht auch das Datum des Ausdrucks darauf.',
        'Quelle und Herkunft: Bei jedem Eintrag steht jetzt, ob er von dir, von der App oder (später) von einem Dienst oder dem Fahrzeug kommt, und ob Datum, Uhrzeit und Position automatisch oder von Hand sind. Das siehst du im Logbuch und in jeder Ausgabe des Reisebuchs.'
      ] },
      { version: '2.0.105', datum: '2026-11-17', punkte: [
        'Korrektur: Der Knopf für den Wechsel der Cockpit-Ansichten heißt jetzt „Ansichten-Wechsel“ und öffnet die richtige Einstellung (vorher kam „Verantwortung wechseln“).'
      ] },
      { version: '2.0.104', datum: '2026-11-17', punkte: [
        'Cockpit-Wechsel: Das Cockpit kann von selbst zwischen den Seiten, der Karte und den letzten Ereignissen wechseln. Das schont den Bildschirm, und du siehst trotzdem alles. Du stellst den Takt (10 bis 120 Sekunden) und die Ansichten mit Reihenfolge selbst ein, unten auf der dritten Seite unter „Ansichten-Wechsel“. Standard ist aus. Sobald du tippst oder eine Frage offen ist, bleibt der Wechsel stehen und läuft nach einer Minute Ruhe weiter. Er läuft nur bei offener App. Ohne Internet bleibt die Karte im Wechsel mit dem Hinweis „Kein Internet“.',
        'Alle Daten löschen: Bist du mit einem Konto angemeldet, fragt die App jetzt, ob auch beim Dienst gelöscht wird. Sonst kämen die Daten beim nächsten Abgleich zurück, auch auf deinen anderen Geräten. Auf anderen Geräten löschst du weiterhin selbst.'
      ] },
      { version: '2.0.103', datum: '2026-11-17', punkte: [
        'Cockpit aufgeräumt: Der Fahrzeugname steht nicht mehr doppelt oben, wenn er schon im Titel der Aktivität vorkommt. Bei den Motorstunden steht nur noch der Stand, die Klammer mit Quelle und Datum ist weg (sie steht weiter auf der Seite der Motoren).',
        'Fahrzeuge besser einordnen: Jedes Fahrzeug hat jetzt eine Einordnung mit Antrieb (mit oder ohne), Zustand (neu, gebraucht, Oldtimer), Auslegung (Personen, Lasten oder beides) und Eignung zum Ankreuzen, zum Beispiel Übernachten, Kochen, Anhänger ziehen, Segeln oder Wasserski. Nach der Art ist schon etwas vorbelegt, du änderst es. Fehlt ein Punkt, ergänzt du einen eigenen. Bei Wasserfahrzeugen rechnet MobiMory aus der Länge die Größenklasse (Klein bis 6 m, Mittel bis 9 m, Groß bis 15 m, Sehr groß ab 15 m).',
        'Neue Fahrzeugarten: Transporter, Lkw, Anhänger, Bootstrailer und Zeltanhänger sowie Motorboot, Schlauchboot oder RIB, Jetski, Hausboot, Beiboot, Paddel- oder Ruderboot und Sonstiges Wasserfahrzeug. Deine bisherigen Fahrzeuge und Arten bleiben unverändert.',
        'Anhänger und Trailer: Du legst fest, von welchen deiner Fahrzeuge ein Anhänger gezogen werden kann. Beim Bootstrailer legst du dazu fest, welche deiner Boote und Beiboote darauf passen. Beides kann bei jedem Trailer anders sein. Zugfahrzeuge haben Felder für die zulässige Anhängelast und Stützlast.',
      ] },
      { version: '2.0.102', datum: '2026-11-17', punkte: [
        'Scannen für alle: Dokument erfassen, der Scan beim Anlegen von Fahrzeug, Person und Komponenten und „Rechnung scannen“ sind nicht mehr nur für Entwickler da. Du findest „Dokument erfassen“ unter „Funktionen“. Der Lesedienst braucht ein Konto ab der Stufe Mittel (Testwoche 10, Mittel 50, Voll 100 Scans im Monat).',
        'Neue Startseite auf mobimory.com mit dem Stand dieser Version (Scannen, Reisecheck mit gespeicherten Regeln, Routen und Scans je Stufe).',
      ] },
      { version: '2.0.101', datum: '2026-11-17', punkte: [
        'Bildschirm bleibt an: Solange das Cockpit offen ist, hält MobiMory den Bildschirm wach. Geht die App in den Hintergrund, gibt der Browser das frei, beim Zurückkommen setzt MobiMory es neu. Kann dein Browser das nicht, steht ein Hinweis im Cockpit.',
        'Deutlicher Hinweis zur Aufzeichnung: Kilometerzählung und GPS laufen nur, solange MobiMory offen ist. Der Hinweis steht im Cockpit und bei der Aktivität. Eine Aufzeichnung im Hintergrund kommt erst mit der Android-App (Version 2.1).',
        'Reisecheck und Regeln: Nach einem Reisecheck speichert MobiMory die Ergebnisse als Regeln in den betroffenen Orten und Gebieten, jeweils mit dem Datum des Checks (Status, Belege und Namen bleiben im Check). Reist du später wieder in dasselbe Gebiet, zeigt die Seite „Reisecheck“ zuerst einen Überblick aus diesen Regeln mit „Stand: Datum, die Daten können veraltet sein“. Ein neuer Online-Check ist dann nicht zwingend nötig. Die Regeln siehst du beim Gebiet und beim Ort, du kannst sie abschalten.',
        'Ortserkennung genauer: Ein Ort wird jetzt nur noch erkannt, wenn du höchstens 150 Meter entfernt bist (vorher 300). Der Umkreis für gelernte Namensvorschläge bleibt bei 500 Meter.',
        'Alte App, neuer Dienst: Die App nennt dem Konto-Dienst ihre Version. Ist sie zu alt, erscheint „Bitte zuerst aktualisieren“ mit der Anleitung. Deine Daten auf dem Gerät bleiben.',
      ] },
      { version: '2.0.100', datum: '2026-11-16', punkte: [
        'Der Scan beginnt jetzt dort, wo er hingehört: beim Anlegen eines Fahrzeugs (nach der Art), bei der Person (erstes Dokument: Personalausweis, danach Führerschein und Befähigungen) und bei den Kosten („Rechnung scannen“). Du wählst, welches Dokument gescannt wird, und fehlende Angaben ergänzt du von Hand.',
        'Der Internationale Bootsschein wird vollständig gelesen: Bootsname, Heimathafen, Hersteller, Baujahr, Maße, Tiefgang, Verdrängung, Baumaterial, Bau-Nr. (HIN), Nummer, Ausstellung und Gültigkeit. Die Motoren (Anzahl, Fabrikat, Nummern, Baujahr) legt MobiMory gleich als Komponenten an. Steht die Leistung nur einmal für alle Motoren da, teilt MobiMory sie auf und merkt es sich; du kannst sie später korrigieren.',
        'Unbekannte Dokumente: Du scannst sie als „Anderes Dokument“, ordnest beim ersten Mal die erkannten Angaben von Hand zu und MobiMory lernt daraus (erkennt das Dokument und liest es beim nächsten Mal).',
        'Rechnungen: Betrag, Datum, Rechnungsnummer und Lieferant werden gelesen und als Kostenposten eingetragen, die Rechnung hängt als Beleg daran. Bedienungsanleitungen, Ersatzteillisten und Ähnliches legst du wie bisher als Foto oder PDF ab (neu: Foto direkt aufnehmen oder PDF wählen), ohne Texterkennung.',
      ] },
      { version: '2.0.99', datum: '2026-11-16', punkte: [
        'Dokument erfassen: Die Rückseite wird jetzt mit derselben Kamera und dem Zielrahmen aufgenommen wie die Vorderseite. Beide Seiten bleiben im Ergebnis sichtbar, und du kannst auf jeder Seite Stellen markieren. MobiMory merkt sich die Stellen auch beim Lesedienst.',
        'Fahrzeuge werden aus dem Papier neu angelegt. Die Motoren legt MobiMory gleich als Komponenten mit an (Leistung, Hubraum, Kraftstoff). Bei der Zulassungsbescheinigung I werden dafür Hubraum, Nennleistung und Kraftstoff gelesen.'
      ] },
      { version: '2.0.98', datum: '2026-11-16', punkte: [
        'Dokument erfassen liest jetzt mit dem Lesedienst von Google (Rechenzentrum in der EU), viel genauer als die Erkennung auf dem Gerät. Das gibt es nur mit einem Konto der Stufe Mittel (50 Scans im Monat) oder Voll (100). Ohne Konto gibt es Dokument erfassen nicht.',
        'Dafür stimmst du einmal zu (jederzeit widerrufbar). Vor jedem Foto fragt MobiMory noch einmal und du kannst abbrechen oder auf dem Gerät lesen. Das Foto wird bei Google und bei MobiMory nicht gespeichert. Ist die Grenze erreicht oder fehlt das Netz, liest das Gerät.',
        'Neu beim Führerschein: Die Tabelle der Rückseite (Klasse, Datum, Schlüsselzahl) wird gelesen. Das ß im Namen wird mit der Maschinenzeile abgeglichen. Unter Konto siehst du, wie viele Scans noch frei sind. Dazu braucht der Konto-Dienst die Tabelle 13g.sql und den Geheimwert GOOGLE_VISION_KEY (siehe server/EINRICHTUNG.md, „Update auf 13g“).'
      ] },
      { version: '2.0.97', datum: '2026-11-16', punkte: [
        'Dokument erfassen ist noch in Erprobung und deshalb nur noch im Bereich „Nur für Entwickler“ sichtbar, bis die Erkennung zuverlässig funktioniert. Unter „Funktionen“ ist die Kachel weg.',
        'Besser lesen: Wenn die kleinen Beschriftungen auf dem Ausweis nicht lesbar sind (Muster, Hologramm), werden Name, Vorname und Geburtsort nach der Reihenfolge auf dem Ausweis zugeordnet und immer als „Bitte prüfen“ markiert. Schwache Fotos werden mit mehreren Bildaufbereitungen gelesen, bei falschem Ausschnitt wird das ganze Bild geprüft.',
        'Gelernte Stellen zählen weniger als gelesene Beschriftungen und gelten nie als „sicher“. Liefert eine gelernte Stelle denselben Text wie eine andere Angabe, wird sie verworfen. Im Entwickler-Bereich gibt es „Gelernte Stellen“ zum Zurücksetzen.'
      ] },
      { version: '2.0.96', datum: '2026-11-15', punkte: [
        'Dokument erfassen (Smart Capture, Stufe 1): Unter „Funktionen“ fotografierst du einen Personalausweis, Führerschein, Sportbootführerschein, ein Funkzeugnis, das Bodensee-Schifferpatent, den Fachkundenachweis Sprengstoffrecht oder eine Zulassungsbescheinigung Teil I, oder du wählst ein Foto oder einen Scan aus. MobiMory liest die Angaben auf deinem Gerät, das Bild verlässt es nicht.',
        'Die Kamera zeigt einen Zielrahmen und sagt dir, wenn das Dokument zu weit weg, zu dunkel, unscharf oder spiegelnd ist. Gelesen wird nach Bedeutung (Feldnummer, Beschriftung, Maschinenzeile des Ausweises), nicht nach fester Stelle.',
        'Das Ergebnis zeigt alle Angaben. Unsichere sind markiert, jede kannst du einzeln ändern oder die Stelle auf dem Bild markieren, ohne neu zu scannen. Gespeichert wird erst nach deiner Bestätigung, der Original-Scan bleibt beim Nachweis.',
        'Das erste Dokument legt die Person an (Name, Vorname, Geburtsdatum, Geburtsort). Weitere Nachweise werden ihr zugeordnet, wenn Name und Geburtsdatum passen, bei Zweifel fragt MobiMory. Eine Zulassungsbescheinigung oder ein Bootsschein legt das Fahrzeug an.',
        'Das Lesen ist eine Hilfe und keine rechtsgültige Aussage. Neue Nachweisarten: Bodensee-Schifferpatent und Fachkundenachweis Sprengstoffrecht (Signalmittel). Personalausweis, Sportbootführerschein und UKW-Funkzeugnis haben jetzt Felder für Name, Vorname, Geburtsdatum und Geburtsort.'
      ] },
      { version: '2.0.95', datum: '2026-11-15', punkte: [
        'Schadensbericht: Im Formular, schon beim Anlegen, stehen jetzt „Foto aufnehmen“ (Kamera) und „Aus Datei“ im Abschnitt „Fotos und Belege“. Die Fotos hängen beim Speichern an der Störung des Berichts und stehen im Bericht. In 2.0.93 fehlten die Knöpfe im Formular.'
      ] },
      { version: '2.0.94', datum: '2026-11-15', punkte: [
        'Nur für Admins und Entwickler: Die Kachel „Verwaltung“ unter „Nur für Entwickler“ zeigt, wie viele Konten es gibt und wie viele davon Test, Mittel und Voll haben. Admins buchen dort auch Zahlungseingänge von Überweisungen und schalten frei, ohne die Seite im Browser.'
      ] },
      { version: '2.0.93', datum: '2026-11-15', punkte: [
        'Schadensbericht: Beim Speichern legt MobiMory automatisch eine Störung in der Werkstatt dazu (Schadenart und Datum, Hergang gekürzt). Das Fahrzeug bleibt dabei nutzbar. Gehört der Bericht schon zu einer Störung, entsteht keine zweite.',
        'Neu auf der Seite des Berichts: „Foto aufnehmen“ (Kamera) und „Aus Datei“. Die Fotos liegen als Dokumente an der Störung, es gibt keine zweite Ablage. Bei Berichten, die es schon ohne Störung gibt, entsteht sie beim ersten Foto.'
      ] },
      { version: '2.0.92', datum: '2026-11-15', punkte: [
        'Neu bei den Fahrzeugangaben: Versicherung, Versicherungsnummer und Telefon für Schadenmeldungen (freiwillig, für alle Fahrzeugarten). Im Schadensbericht werden Versicherung und Nummer automatisch vorgefüllt, das Telefon steht im Bericht.'
      ] },
      { version: '2.0.91', datum: '2026-11-15', punkte: [
        'Neu: Schadensbericht. Unter Funktionen › Schadensbericht wählst du das Fahrzeug und legst einen Bericht an, von Hand oder direkt bei einer Störung („Schadensbericht“). Fahrzeug und Kennzeichen trägt MobiMory selbst ein; entstand die Störung im Logbuch, kommen Datum, Uhrzeit und Ort von dort. Hergang, Beteiligte, Zeugen und Polizei-Aktenzeichen trägst du ein.',
        'Der Bericht ist eine Seite und ein PDF zum Drucken oder Mailen. Fotos, Kostenvoranschlag, Gutachten und Rechnungen legst du wie bisher als Dokument am Werkstatt-Vorgang ab; sie stehen im Bericht, ohne dass du sie doppelt einträgst.',
        'Wichtig: Das ist ein eigenes Formular. Es ersetzt nicht den Europäischen Unfallbericht mit Skizze und beiden Unterschriften. Die meisten Versicherer haben ein Online-Formular: Dort tippst du die Angaben aus deinem Bericht ab. Die Versicherung steht nicht in den Fahrzeugangaben, du trägst sie im Bericht ein.'
      ] },
      { version: '2.0.90', datum: '2026-11-15', punkte: [
        'Neu: Tag planen. Auf der Seite eines Tages plant MobiMory für Straßenfahrzeuge nur diesen Tag, vom Start zum Ziel des Tages, mit den Maßen und Gewichten deines Fahrzeugs. Du siehst Länge, Fahrzeit und Warnungen und kannst die Tagesroute als GPX-Datei sichern. Jede geplante Tagesroute zählt 1 Route: fünf Tage sind fünf Routen.',
        'Neu: Karte des Tages. „Karte des Tages ansehen“ zeigt die Tagesroute mit Start, Ziel und Warnstellen.',
        'So geht es: Aktivität mit Fahrzeug anlegen, beim Tag Start und Ziel mit Position haben (der Start ist sonst das Ziel des Vortags), den Tag öffnen und „Tag planen“ tippen.'
      ] },
      { version: '2.0.89', datum: '2026-11-15', punkte: [
        'Karte: Warnstellen einer geplanten Route stehen jetzt als orange „!“ auf der Karte. Antippen zeigt den Text der Warnung.',
        'So nutzt du die Routenplanung: Aktivität mit Fahrzeug, Startort und Zielort anlegen (beide Orte mit Position), dann „Route und Wetter“ öffnen und „Route planen“ tippen. Über „Karte ansehen“ siehst du die Route und die Warnstellen.'
      ] },
      { version: '2.0.88', datum: '2026-11-15', punkte: [
        'Neu: Route planen. Für Autos, Wohnmobile und andere Straßenfahrzeuge plant MobiMory eine Route von Start über die Zwischenziele zum Ziel der Aktivität, mit den Maßen und Gewichten deines Fahrzeugs, mit Warnungen (zum Beispiel eine Brücke, die niedriger ist als dein Fahrzeug). Du kannst sie als GPX-Datei sichern.',
        'Die Routenplanung gibt es ab der Stufe Mittel und in der Testwoche (10, 100 oder 1000 Routen im Jahr, 100 weitere Routen für 9,99 €). Bei Wasserfahrzeugen öffnet MobiMory eine Navigations-App deines Geräts.',
        'Die Warnungen sind nur so gut wie die Straßendaten. Achte unterwegs auf Schilder, Brücken und Tunnel.'
      ] },
      { version: '2.0.87', datum: '2026-11-15', punkte: [
        'Meine Fahrzeuge: Beendete Leihen stehen jetzt eingeklappt unter „Beendete Leihen“. Nichts wird gelöscht, alles bleibt lesbar.',
        'Am geliehenen Fahrzeug darfst du weiter eigene Komponenten anlegen und ändern. Fristen und Dokumente des Besitzers siehst du nur lesend.'
      ] },
      { version: '2.0.86', datum: '2026-11-15', punkte: [
        'Die Leihe ist einfacher geworden: Eine Reise mit einem geliehenen Fahrzeug machst du jetzt wie jede andere Reise, mit Logbuch und Reisebuch. „Meine Reise“ mit eigenem Plan, Reisecheck und Tagebuch gibt es nicht mehr.',
        'Alte Einträge dazu (Plan, Check und Tagebuch der Leihreise) werden beim Start einmalig vom Gerät gelöscht.',
        'Unverändert: Fahrzeug des Besitzers ansehen, die Planung vor dem Verleih und der Online-Check am geliehenen Fahrzeug.'
      ] },
      { version: '2.0.85', datum: '2026-11-15', punkte: [
        'Neu im Reisebuch: die Zahlen dieser Reise. Gefahrene Strecke und gefahrene Zeit (aus den Tagesabschlüssen), getankte Liter je Stoff und der gerechnete Verbrauch, Auffüllen und Entleeren von Wasser, getauschte Flaschen, Störungen und die Nächte nach Platzart: beim Boot im Hafen, vor Anker und frei liegend, beim Wohnmobil auf Campingplatz, auf Stellplatz und frei stehend.',
        'Je Tag stehen jetzt auch das tatsächliche Ziel und die Notiz aus dem Tagesabschluss im Buch. Die Notiz kommt nur mit, wenn „Mit Notizen und Texten“ gewählt ist.',
        'Das PDF hat jetzt eine eigene Titelseite mit Titel, Zeitraum, Fahrzeug, Route und Besatzung. Die Reise beginnt danach auf Seite 2.',
        'Was nicht vorhanden ist, fehlt im Buch: Ohne Tagesabschluss gibt es keine gefahrene Strecke, nichts wird geschätzt. Die geplante Strecke heißt jetzt „Geplante Strecke“.'
      ] },
      { version: '2.0.84', datum: '2026-11-15', punkte: [
        'Behoben: Das Feld „Gutscheincode“ steht jetzt direkt bei dem Angebot (Mittel oder Voll), das du haben willst, nicht mehr weit oben. Ein Rabattcode zeigt den neuen Preis genau dort.',
        'Behoben: Bei einem Geschenkcode (100 %) gibt es keinen Knopf „Mit PayPal bezahlen“ mehr. Dort steht nur „Code einlösen“, sonst wurde der volle Preis verlangt. Gilt der Code für das andere Angebot, sagt dir die App das.',
        'Für den Betreiber: Beim Anlegen eines Codes kann eine E-Mail-Adresse eingetragen werden. Der Dienst schickt den Code dann per Mail (persönlicher Code an die Person, Code für viele an den, der ihn verteilt). Die Adresse wird nicht gespeichert. Dafür den Konto-Dienst 13f-9 neu bereitstellen, die SQL-Datei bleibt gleich.'
      ] },
      { version: '2.0.83', datum: '2026-11-15', punkte: [
        'Neu: Gutscheincodes beim Bezahlen. Unter Konto › Deine Stufe gibt es das Feld „Gutscheincode“. Ein Rabattcode (bis 25 %) senkt den Preis beim ersten Kauf von Mittel oder Voll, bei PayPal und bei Überweisung. Er gilt nur für Neukunden, nicht beim Verlängern, nicht beim Wechsel von Mittel auf Voll und nicht für zusätzliche Recherchen.',
        'Ein Geschenkcode (100 %) schaltet Mittel oder Voll für einige Monate ohne Bezahlen frei. Hast du die Stufe schon, wird die Zeit angehängt. Auf dem Beleg steht der Rabatt als eigene Zeile.',
        'Für den Betreiber: Admins legen die Codes unter „Nur für Entwickler“ › „Gutscheincodes“ an. Dafür muss im Konto-Dienst die neue SQL-Datei 13f-8.sql eingespielt und der Dienst neu bereitgestellt werden. Ohne das läuft das Bezahlen wie bisher.'
      ] },
      { version: '2.0.82', datum: '2026-11-15', punkte: [
        'Behoben: Fehlt einem Fahrzeug die Fahrzeugart, zum Beispiel nach einer Übergabe oder Freigabe, stürzt die App an keiner Stelle mehr ab. Das Fahrzeug erscheint mit „Art unbekannt“, Planung, Werkstatt, Kosten und Fahrzeugseite bleiben benutzbar.'
      ] },
      { version: '2.0.81', datum: '2026-11-15', punkte: [
        'Neu: das Reisebuch. Aus jeder deiner Reisen macht MobiMory ein Buch: die Reise, Tag für Tag mit den Ereignissen im Logbuch, die besuchten Orte und deine Fotos. Du findest es unter „Funktionen“ › „Reisebuch“ und bei der Reise selbst.',
        'Du kannst das Buch in der App lesen, ausdrucken oder als PDF speichern. Fotos, Notizen und Kosten schaltest du einzeln dazu oder weg. Kosten stehen nur drin, wenn du es willst.',
        'Das Reisebuch ändert nichts an deinen Daten und schickt nichts ins Netz. Fotos, die nicht auf diesem Gerät liegen, fehlen im Buch.'
      ] },
      { version: '2.0.80', datum: '2026-11-15', punkte: [
        'Geliehene Fahrzeuge stehen jetzt in deiner Fahrzeugliste, in einem eigenen Block „Geliehen“. Sobald die Planung oder der Verleih beginnt, legt MobiMory das Fahrzeug dort für dich an. Logbuch, Reisen, Aktivitäten, Kosten und Reisechecks führst du darüber wie bei einem eigenen Fahrzeug.',
        'Alles, was du bei einem geliehenen Fahrzeug einträgst, bleibt bei dir. Der Besitzer sieht es nie, und seine Fahrzeug-Historie samt Kosten bleibt unverändert. Nur wenn er dir „mitnutzen“ erlaubt hat, trägst du Kilometer, Fahrzeugkosten und Störungen für ihn auf der Seite „Beim Besitzer eintragen“ ein. Diese Einträge stehen dann in seiner Historie.',
        'Geliehene Fahrzeuge zählen nicht zur Fahrzeuggrenze deiner Stufe. Online-Checks dafür zählen zum Kontingent des Besitzers, du hast dafür keines.',
        'Endet die Leihe, verschwindet das Fahrzeug nicht. Es wird inaktiv: Du kannst nichts Neues anlegen und keine Online-Checks machen, alles Eingetragene bleibt lesbar. Leihst du dasselbe Fahrzeug später wieder, wird derselbe Platz wieder aktiv.',
        'Eine neue SQL-Zeile oder ein neuer Konto-Dienst ist nicht nötig.'
      ] },
      { version: '2.0.79', datum: '2026-11-14', punkte: [
        'Planung vor dem Verleih: Beim Verleih kannst du jetzt zwei Zeiträume festlegen. Ab „Planung ab“ sieht die Person das Fahrzeug, plant ihre Reise, macht Reisechecks und führt ihr Reisetagebuch. Im Fahrzeug eintragen kann sie erst ab dem Beginn des Verleihs, dann gelten die Rechte wie bisher.',
        'Meine Reise: Die Person öffnet das geteilte Fahrzeug und tippt auf „Meine Reise“. Dort gibt sie Reise, Reisetage, Gebiet und Besatzung ein, startet den Reisecheck und schreibt Tagebuch. Plan, Checks und Tagebuch bleiben auf ihrem Gerät und in ihrer Sicherung, auch wenn der Verleih endet. Du als Besitzer siehst sie nicht.',
        'Reisechecks der Person zählen zu deinem Kontingent, die Person hat keines. Sie sieht deine Zahlen nie. Ein gespeicherter Check zählt nicht.',
        'Beim Konto-Dienst ist eine neue SQL-Zeile nötig (13f-4). Ohne sie bleibt alles wie bisher, nur „Planung ab“ geht dann nicht.'
      ] },
      { version: '2.0.76', datum: '2026-11-14', punkte: [
        'Störung melden mit Info-Mail: Meldet eine Person, der du ein Fahrzeug zum Mitnutzen gegeben hast, eine Störung, bekommst du eine E-Mail. Sie ist nur zur Information, du musst nichts tun. Die Störung steht bei dir unter Werkstatt, mit dem Namen der Person.',
        'Hilfe zur Behebung: Bei einer offenen Störung zeigt MobiMory Anleitungen aus den Dokumenten des Fahrzeugs (Bedienungsanleitung, Reparaturbuch, Wartungsanleitung, Ersatzteilliste), deine eigenen Werkstätten, einen Link zur Werkstattsuche im Kartendienst sowie Notrufnummern und Pannenhilfe für Deutschland, Österreich, die Schweiz, Dänemark, Schweden, Norwegen und Finnland. Die Nummern sind nach bestem Wissen geprüft, bitte vor der Reise nachsehen.',
        'Reparaturgedächtnis: Hast du früher eine ähnliche Störung oder Arbeit eingetragen, zeigt MobiMory sie mit dem, was damals eingetragen wurde (zum Beispiel was getauscht wurde). MobiMory rät keine Ursachen, es zeigt nur, was eingetragen ist. Je genauer du eine Erledigung beschreibst, desto besser hilft es beim nächsten Mal.',
        'Wer ein Fahrzeug mitnutzen darf, sieht auch die früheren Störungen und Arbeiten (nur Texte, keine Beträge, die Notiz zur Erledigung bleibt auf deinem Gerät) und bekommt dieselbe Hilfe. Beim Konto-Dienst ist keine neue SQL-Zeile nötig, nur die neue Datei konto-dienst.mjs (13f-3).'
      ] },
      { version: '2.0.75', datum: '2026-11-14', punkte: [
        'Mitnutzung: Beim Verleih kannst du jetzt wählen, ob die Person das Fahrzeug nur ansehen oder mitnutzen darf. Mit Mitnutzen trägt sie Kilometerstände, Fahrzeugkosten (Diesel, Maut, Reparatur) und Störungen ein. Die Einträge erscheinen in deinem Fahrzeug, mit ihrem Namen daran.',
        'Fixkosten legst nur du an. Reisekosten wie Campingplatz, Essen und Souvenirs gehören nicht ins Fahrzeug. Kosten und Aktivitäten von dir sieht die Person nicht.',
        'Die Person kann einen Kontroll-Code erzeugen, zum Beispiel für den Campingplatz. Er gilt nie länger als die Freigabe, du siehst ihn in deiner Liste und kannst ihn widerrufen.',
        'Einzelne Dokumente (zum Beispiel den Kaufvertrag) kannst du bei der Einladung ausnehmen. Beim Konto-Dienst sind drei neue SQL-Zeilen nötig (13f-2).'
      ] },
      { version: '2.0.74', datum: '2026-11-14', punkte: [
        'Verleih mit Regeln: Gäste gibt es ab der Stufe Mittel (auch in der Testwoche), mit Basic geht das nicht. Wie viele Gäste du einladen kannst, hängt von deinen Geräten ab: Geräte deiner Stufe minus die Geräte, die du selbst nutzt (Mittel 4, Voll 10). Ein Gast zählt einmal, auch bei mehreren Fahrzeugen.',
        'Nachweis des Halters: Bevor du ein Fahrzeug verleihst, bestätigst du, dass du den Nachweis der Person gesehen hast (Führerschein, Bootsführerschein oder ein anderer). Gespeichert werden nur die Art und „gültig bis“, kein Scan und keine Nummer. Läuft der Nachweis vor dem Ende der Freigabe ab, geht der Verleih nicht.',
        'Prüfung vor dem Senden: Die App sagt dir, wenn im Zeitraum eine eigene Planung liegt, das Fahrzeug schon an jemand anderen verliehen ist oder eine Frist (zum Beispiel die Hauptuntersuchung) fällig wird. Das ist nur eine Warnung. Du wählst „Trotzdem verleihen“ oder „Absage“, deine eigene Planung hat Vorrang.',
        'Stornieren: Eine Freigabe lässt sich jederzeit stornieren, der Zugriff endet sofort. Beim Konto-Dienst ist eine neue SQL-Zeile nötig (13f-1).'
      ] },
      { version: '2.0.73', datum: '2026-11-14', punkte: [
        'Das Menü ist neu geordnet. Funktionen: Aktivitäten, Reisecheck, Cockpit und Logbuch, Werkstatt, Kassenbuch, Kosten, Verleih, Fahrzeug abgeben, Kontrollpapiere und (bald) Schadensbericht.',
        'Die Seite „Freigaben“ ist geteilt: Fahrzeug an eine Person einladen und den Code einlösen findest du jetzt unter Verleih, den Kontroll-Code für Papiere und Prüfergebnis unter Kontrollpapiere. „Fahrzeug abgeben“ ist eine eigene Kachel.',
        'Einstellungen sind jetzt Kacheln: Deine Daten (Konto, Sicherung, Speicher, Alle Daten löschen), Anzeige (Wetter und Karten, Verbrauchseinheit) und Über MobiMory. Das Konto steht jetzt unter Einstellungen › Deine Daten.',
        'Import, Export und „Übergabedatei einlesen“ findest du jetzt bei den Fahrzeugen (Stammdaten › Fahrzeuge).',
        'Die Kachel „Entwickler“ ist für normale Nutzer weg. Den Bereich „Nur für Entwickler“ sehen nur Admins und Entwickler, die in der Rollen-Tabelle beim Dienst stehen. Nur Admins ändern die Tabelle.'
      ] },
      { version: '2.0.72', datum: '2026-11-12', punkte: [
        'Bezahlen: Unter Funktionen › Konto gibt es jetzt „Stufe wählen oder verlängern“. Mittel kostet 59,88 € im Jahr (12 × 4,99 €), Voll 119,88 € im Jahr (12 × 9,99 €). Du zahlst mit PayPal (sofort freigeschaltet) oder per Überweisung (freigeschaltet nach dem Geldeingang). Es ist kein Abo: Es wird nichts automatisch abgebucht.',
        'Nach jeder Zahlung bekommst du einen Beleg per E-Mail. Vor dem Ablauf kommt je eine Erinnerung 30 und 7 Tage vorher, mit einem Link zum Verlängern. Läuft die Zeit ab, bleibt dein Konto auf Basic, deine Daten auf dem Gerät bleiben.',
        'Zusätzliche Online-Recherchen: 5 Stück für 9,99 €. Sie werden benutzt, wenn dein Kontingent aufgebraucht ist, und verfallen nicht.',
        'Der Kosten-Wächter rechnet jetzt mit den echten Einnahmen aus den Belegen.'
      ] },
      { version: '2.0.71', datum: '2026-11-12', punkte: [
        'Für dich ändert sich in der App nichts. Beim Konto-Dienst läuft jetzt ein Kosten-Wächter: Er prüft alle 15 Minuten, ob die Testwochen im Verhältnis zu den Einnahmen zu viel kosten oder ob auffällig viele neue Testwochen beginnen, und meldet das dem Betreiber per Mail. In der Mail stehen nur Zahlen, keine Namen und keine Adressen.'
      ] },
      { version: '2.0.70', datum: '2026-11-12', punkte: [
        'Fahrzeug-Grenze je Stufe: Basic 1 Fahrzeug, Mittel 3, Voll unbegrenzt, Testwoche 3. Fahrzeuge, die zu einem anderen gehören (zum Beispiel Beiboot oder Anhänger), zählen mit, abgegebene Fahrzeuge nicht. Ohne Konto gilt Basic.',
        'Ist die Grenze erreicht, bekommst du beim Anlegen (auch beim Import aus einer Tabelle und beim Übernehmen einer Übergabe-Datei) einen Hinweis mit deiner Stufe. Es wird nichts gelöscht und nichts gesperrt: Deine vorhandenen Fahrzeuge bleiben immer erhalten, es kommt nur kein neues dazu.',
        'Die App merkt sich die Grenze deiner Stufe, damit sie auch ohne Netz gilt.'
      ] },
      { version: '2.0.69', datum: '2026-11-12', punkte: [
        'Neue Stufe „Entwickler“ ohne Grenzen für Geräte und Online-Checks. Sie ist nur für den Entwickler und wird nur beim Dienst eingetragen, in der App kann sie niemand wählen.',
        'Die Version 2.0.68 wurde nicht ausgeliefert. Alles aus 2.0.68 (Stufen, Testwoche, Online-Checks über das Konto, gespeicherte Checks, Anmeldung nur mit Code, Entwickler-Bereich) steckt in dieser Version.'
      ] },
      { version: '2.0.68', datum: '2026-11-12', punkte: [
        'Stufen: Basic (kostenlos, nur auf dem Gerät), Mittel und Voll. Neue Konten bekommen eine Testwoche auf Mittel-Niveau mit einem Online-Check, einmal je E-Mail-Adresse. Unter Funktionen › Konto siehst du deine Stufe, deine Geräte und deine Online-Checks.',
        'Online-Checks laufen jetzt über dein Konto. Jeder frische Check zählt zum Kontingent (Mittel 3, Voll 10 in 12 Monaten), egal ob Reisecheck, Tagcheck oder Grundcheck. Gezählt wird beim Dienst. Schlägt eine Recherche fehl, wird der Check nicht gezählt.',
        'Gespeicherte Checks: Das Ergebnis wird mit Datum gespeichert. Mit „Gespeicherten Check holen“ bekommst du es ohne Zählung. Es kann veraltet sein, eine Aktualisierung ist nicht garantiert.',
        'Die Anmeldung geht nur noch per Code aus der E-Mail, das Passwortfeld entfällt. Die Adresse des Dienstes ist fest (konto.mobimory.com). Eigene Adressen gibt es nur noch unter Funktionen › Entwickler. Die Zustimmung für Online-Checks ist neu formuliert und muss einmal erneut gegeben werden.'
      ] },
      { version: '2.0.67', datum: '2026-11-11', punkte: [
        'Freigaben: Unter Funktionen › Freigaben gibst du ein Fahrzeug für eine andere Person frei, nur zum Lesen, für einen Zeitraum von höchstens 12 Monaten. Die Person bekommt einen Code, meldet sich mit ihrer E-Mail-Adresse an und trägt ihn ein. Sie sieht das Fahrzeug, die Fristen und Zähler, die Dokumente samt Dateien und das letzte Prüfergebnis. Kosten, Notizen, Nachweise, Reisechecks, Aktivitäten, Ereignisse und Standorte sieht sie nie. Du kannst die Freigabe jederzeit widerrufen, der Zugriff endet dann sofort.',
        'Kontroll-Freigabe: Für eine Kontrolle erzeugst du einen kurzen Code, der höchstens 7 Tage gilt. Wer ihn hat, sieht ohne eigenes Konto nur das Fahrzeug, die Dokumente und das letzte Prüfergebnis. Du kannst den Link teilen und den Code widerrufen.',
        'Was ein Gast sieht, wird nur angezeigt und nicht auf seinem Gerät gespeichert. Der Dienst prüft bei jeder Anfrage, ob die Freigabe noch gilt.'
      ] },
      { version: '2.0.66', datum: '2026-11-10', punkte: [
        'Bilder und Dokumente auf allen Geräten: Beim Abgleich unter Funktionen › Konto gehen jetzt auch Fotos, Dokumente und Scans mit. Geht ein Handy oder Tablet kaputt, sind die Bilder nicht verloren. Sie liegen beim Dienst im Dateispeicher in der EU. Eine Datei darf höchstens 20 MB groß sein.',
        'Scans von Nachweisen (zum Beispiel Führerschein) gehen nur verschlüsselt mit deinem Schlüsselwort hinaus, der Dienst kann sie nicht lesen. Das Schlüsselwort tippst du beim Abgleich ein, es wird nie gespeichert. Ohne Schlüsselwort bleiben die Scans auf dem Gerät. Auf dem anderen Gerät brauchst du dasselbe Wort, um sie zu holen.',
        'Auch Kosten und Reisekasse, Routen, Besuche und Reisechecks sind jetzt auf allen Geräten da, dazu die Nachweisarten und die Gültigkeit der Nachweise. Nummer, Aussteller und Klassen der Nachweise, Notizen, Geburtsdatum, Wohnort, die GPS-Spur und die Namen im Reisecheck bleiben auf dem Gerät. Bei der Übergabe eines Fahrzeugs gehen die Bilder nicht mit.',
        'Fehlt auf einem Gerät noch eine Datei, steht dort ein Hinweis, und der Abgleich holt sie. Wird ein Dokument gelöscht, verschwindet auch die Datei beim Dienst.'
      ] },
      { version: '2.0.65', datum: '2026-11-10', punkte: [
        'Abgleich zwischen Geräten: Unter Funktionen › Konto gibt es jetzt „Jetzt abgleichen“. Fahrzeuge und Komponenten, Fristen und Störungen, Aktivitäten und Besatzung, Ereignisse und Zähler, Belegung und Prüfergebnisse gehen zum Dienst und kommen auf deinen anderen Geräten an, auf denen du mit demselben Konto angemeldet bist. Der Abgleich läuft nur auf Knopfdruck, ohne Netz arbeitest du wie bisher.',
        'Was auf deinen Geräten bleibt: Nachweise samt Scan, Geburtsdatum, Wohnort, GPS-Spur, Fotos, Notizen, Kosten, Routen und Dokumente. Von Personen, Tieren, Orten und Werkstätten gehen nur die öffentlichen Angaben mit (Name, Funktionen, Art, Ort), nie Telefon, E-Mail, Adresse oder Notiz. Vom Prüfergebnis geht nur „ja oder nein, geprüft am“ mit.',
        'Bei Änderungen auf zwei Geräten bleibt nichts verloren: Bei Verläufen gilt der zuletzt gemachte Eintrag, der frühere bleibt sichtbar. Bei anderen Daten gilt der Stand, der zuerst beim Dienst war, deine Fassung liegt unter „Konflikte“ und lässt sich wieder einsetzen.',
        'Sicherung beim Dienst: Die Sicherung (ohne Dokumente, Scans und Fotos) wird auf deinem Gerät mit deinem Schlüsselwort verschlüsselt und dann hochgeladen. Der Dienst kann sie nicht lesen. Die letzten zwei Sicherungen bleiben dort, du kannst sie wiederherstellen oder löschen. Vergisst du das Schlüsselwort, kann niemand die Sicherung öffnen.',
        'Dazu: „Verbindung testen“ sagt jetzt klar, wenn der Dienst die Adresse der App ablehnt. Beim Test-Dienst steht auf der Code-Seite nicht mehr, dass eine E-Mail geschickt wurde.'
      ] },
      { version: '2.0.64', datum: '2026-11-10', punkte: [
        'Konto, erste Grundlage: Unter Funktionen gibt es jetzt „Konto“. Dort trägst du die Adresse des Konto-Dienstes ein (ein kleiner Dienst bei Cloudflare, Rechenzentrum in der EU) und kannst dich anmelden: mit E-Mail und Passwort, oder mit E-Mail und einem Code, der zehn Minuten gilt. Bei einem neuen Konto bestätigt der Code per E-Mail, dass die Adresse dir gehört. Anmelden mit Google und Apple folgt später.',
        'Was auf dem Server liegt: nur deine E-Mail-Adresse, ein Abdruck des Passworts (nie das Passwort selbst) und dein eigener Datenraum. Fahrzeuge, Dokumente und der Abgleich zwischen Geräten gehen noch nicht hinaus, das kommt in den nächsten Schritten. Ohne Konto arbeitet MobiMory unverändert nur auf deinem Gerät, auch ohne Netz.',
        'Du kannst dich jederzeit abmelden (die Daten auf dem Gerät bleiben), ein Passwort setzen oder ändern und das Konto beim Dienst löschen. Die Anmeldung gehört zum Gerät und steht nicht in der Sicherungsdatei.'
      ] },
      { version: '2.0.63', datum: '2026-11-10', punkte: [
        'Ver- und Entsorgung: Im Cockpit gibt es einen Knopf „Ver- und Entsorgung“. Die erste Frage ist „Was?“: Treibstoff tanken, Gasflasche tauschen, Frischwasser auffüllen, Grauwasser, Schwarzwasser oder Chemietoilette entleeren. Angeboten wird nur, was dein Fahrzeug als Tank hat. Die Liste kannst du unter „Merkmale und Einheiten“ erweitern. Tanken ist darin enthalten und lässt sich zusätzlich als eigener Knopf ins Cockpit legen.',
        'Tankvorgang ändern: Ein Tankvorgang wird nicht gelöscht. Am Ereignis kannst du ihn ändern (Menge, Preis, Tank, voll getankt), auch auf 0 Liter. Dann geht der Tank auf den Stand davor zurück und alles danach wird neu gerechnet. Der alte Stand bleibt im Verlauf. Nachtragen mit früherer Uhrzeit wird zeitlich richtig einsortiert.',
        'Gas in kg: Jeder Stoff kann eine Dichte (kg je Liter) haben, für Gas ist ein Wert als Vorlage eingetragen. Mit Dichte gibst du die Menge in Liter oder kg ein, der Preis so, wie du bezahlt hast. Die Kraftstoffart wird mit dem Stoff des Tanks vorbelegt, bei einer anderen Wahl gibt es nur einen Hinweis.',
        'Reisecheck für einen Tag nimmt Start und Ziel des Tages auch dann, wenn du sie nicht von Hand eingetragen hast. „Verbraucher einschalten“ im Baukasten fragt wie der Schalter im Cockpit, womit es läuft und woher der Strom kommt. „Angaben ändern“ beim Fahrzeug warnt bei gleichem Kennzeichen, gleicher FIN oder HIN eines anderen Fahrzeugs. Kostenposten ohne Anteil im Jahr bleiben in ihrer Gruppe sichtbar, mit Grund.'
      ] },
      { version: '2.0.62', datum: '2026-11-09', punkte: [
        'Cockpit, Seite 1: ETA, Rest und Gefahren stehen jetzt groß und fest nebeneinander unter den Angaben, nicht mehr im Wechselfeld. Das Wechselfeld zeigt wieder nur die Geschwindigkeiten: Aktuell, Ø fahrend, Ø Tag. Der Umschalter km und sm gilt für beide. Ohne Ziel, ohne GPS-Position oder ohne Start steht „–“. Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.61', datum: '2026-11-09', punkte: [
        'Cockpit, Wechselfeld: Das Wechselfeld in der Kopfzeile hat jetzt sechs Stufen, jeder Tipp schaltet weiter: Aktuell, Ø fahrend, Ø Tag, ETA, Rest, Gefahren und wieder Aktuell. ETA ist die Ankunft am Ziel des Tages und wird laufend neu gerechnet. Rest ist die Entfernung von deiner jetzigen Position bis zum Ziel. Gefahren ist der Weg, den du seit dem Start des Tages zurückgelegt hast. Ohne Ziel oder ohne GPS-Position steht „–“.',
        'Umschalter km und sm: Neben dem Wechselfeld steht ein Knopf „km“ oder „sm“. Ein Tipp wechselt zwischen km (km/h) und sm (Knoten). Das gilt für die Geschwindigkeit, ETA, Rest und Gefahren, auch für die ETA auf der Tag-Seite und nach dem Ablegen. Das Gerät merkt sich deine Wahl, beim ersten Start steht km. Am Fahrzeug oder am Revier gibt es dazu keine Einstellung und keine Frage mehr: Auf dem Wasser wird nicht mehr von selbst auf Knoten und Seemeilen umgestellt. Das Logbuch ändert sich nicht, der Eintrag „Geschwindigkeit“ bleibt, wie er ist.',
        'Cockpit in Seiten: Seite 1 ist die Info (oberer Bereich mit Wechselfeld und Umschalter), Seite 2 sind die Knöpfe, Seite 3 ist der untere Bereich (Motoren, Zähler, Tagesabschluss). Du wischst nach links und rechts, unten zeigen Punkte die Seite, ein Tipp auf einen Punkt springt dorthin. Das Cockpit öffnet auf der Seite, die du zuletzt benutzt hast. Meldungen und Fragen (zum Beispiel nach dem Motor) stehen auf jeder Seite oben.',
        'Logbuch und Hauptmenü: Beide Knöpfe stehen auf jeder Seite des Cockpits an derselben Stelle ganz oben. Der frühere Knopf „Logbuch und Angaben“ unten heißt jetzt „Logbuch“ und steht oben. Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.60', datum: '2026-11-09', punkte: [
        'Checkliste bei der Fahrzeuganlage: Zu jedem Eintrag gibt es eine Anzahl (leer = 1). Aus 2 Motoren werden zwei Zeilen („Motor 1“, „Motor 2“), die du beim Abfragen umbenennst, zum Beispiel „Motor Backbord“. Jede Zeile hat eigene Betriebsstunden. Rettungswesten zählst du als Sätze: Jeder Satz ist eine Zeile mit der Stückzahl im Feld „Anzahl“ und eigenem Prüfdatum.',
        'Komponentenliste (Stammdaten › Merkmale und Einheiten): Eigene Einträge lassen sich löschen, solange nichts daraus angelegt wurde und keine Komponente so heißt. Mitgelieferte und benutzte Einträge lassen sich nur ausblenden, damit Historie und Berechnungen heil bleiben.',
        'Neue Einträge der Liste: Kommt bei einem Update ein neuer Eintrag dazu, steht er als „neu“ da, mit Annehmen oder Ausblenden. Er erscheint erst in der Checkliste, wenn du ihn annimmst. Was du angelegt, geändert oder ausgeblendet hast, bleibt, wie es war. Ausgeblendete Einträge kommen nicht zurück.',
        'Reisetage: Tag 1 startet am Start der Reise, jeder weitere Tag am Ziel des Vortags (dort, wo du angelegt hast, sonst am geplanten Ziel). Eine eintägige Reise übernimmt Start und Ziel der Reise. Die App zeigt dazu, woher der Ort kommt. Du kannst jeden Tag von Hand ändern, dein Eintrag gilt immer zuerst. Gespeichert wird nichts davon, es wird jedes Mal neu abgeleitet.',
        'Ablegen: Neue Vorlage „Ablegen“ bei „Arten von Ereignissen“ mit der neuen Frage „Ziel (Ort aus der Liste)“. Das Ziel kommt nur aus der Ortsliste (Orte mit Position). Fehlt der Ort, legst du ihn direkt im Feld neu an (Name und Position). Der Text ist freiwillig, Ablegen lässt sich auch leer speichern. Bei einer eintägigen Reise ist das Ziel der Planung schon eingetragen. Bei einer mehrtägigen Reise wählst du das Wunschziel beim Ablegen. Das tatsächliche Ziel legst du beim Anlegen fest, dort beginnt der nächste Tag. Die Frage „Ziel“ mit Text für die Navigation bleibt, wie sie war. Eine schon vorhandene Art „Ablegen“ stellst du bei Bedarf selbst auf die neue Vorlage um.',
        'ETA, die voraussichtliche Ankunft, steht beim Tag und nach dem Ablegen. Vor dem Start gilt die Reisegeschwindigkeit des Fahrzeugs (fehlt sie, steht „unklar“). Unterwegs gilt Ø Tag, sobald genug Fahrt da ist, bis dahin die Reisegeschwindigkeit. Die Höchstgeschwindigkeit wird nie zum Rechnen genommen, die aktuelle Geschwindigkeit nur angezeigt. Die ETA nennt, womit sie gerechnet hat. Strömung, Schleusen, Pausen und Tide sind nicht enthalten. Auf der Luftlinie ist sie eher zu optimistisch, das steht dabei. Das ist eine Hilfestellung und keine rechtliche Aussage.',
        'Behoben: Bei Generator und EFOY war „Liefert Strom als“ in der Checkliste nicht vorbelegt. Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.59', datum: '2026-11-09', punkte: [
        'Strom, erste Stufe: Spannungen sind eine offene Liste (12 V, 24 V, 110/120 V, 220/230/240 V, 380/400 V). Eigene legst du unter Stammdaten › Merkmale und Einheiten an, jede lässt sich ausblenden. Eine Netz-Liste am Fahrzeug gibt es nicht: Die Netze ergeben sich aus den Verbrauchern.',
        'Mehrere Versorgungen je Verbraucher: Ein Kühlschrank kann mit Gas, 12 V und 230 V laufen. Im Formular des Verbrauchers trägst du die weiteren Versorgungen ein. Beim Einschalten wählst du, womit er läuft, und die Laufzeit zählt zu dieser Versorgung. Auf der Seite der Komponente steht die Laufzeit je Versorgung.',
        'Quelle des Stroms: Bei Wechselstrom wählst du beim Einschalten Landstrom, Generator oder Wechselrichter, bei Gleichstrom gilt die Batterie. Die App hält die Quelle am Lauf fest. Ein neues Feld „Liefert Strom als“ sagt, welches Teil Generator, Brennstoffzelle (EFOY) oder Wechselrichter ist.',
        'Generator und EFOY sind Verbraucher mit Tank. Wie beim Diesel rechnet die App Verbrauch und Reichweite. Ist der Tank nach den Betriebsstunden voraussichtlich leer, warnt das Cockpit, dass nachgetankt werden muss. Ohne Reichweite rechnet die App nichts.',
        'Landstrom im Aufenthalt: Beim Festhalten eines Ortes gibt es den Haken „Landstrom angeschlossen“. Die Landstrom-Zeit läuft von der Ankunft bis zur Abfahrt. Beim Münzautomaten trägst du ein, ob er Zeit oder kWh verkauft, dazu Menge und Betrag. Bei Zeit rechnet die App „Strom aus um …“ und die Restzeit, bei kWh gibt es nur Betrag und Menge. Der Betrag wird ein Kostenposten (Stromzuschlag).',
        'Batterie ist nur ein Bauteil (Kapazität, Spannung). Es gibt keinen Ladezustand und keine Rechnung. Ein Geber kann später Werte liefern, die Ablage dafür ist vorbereitet.',
        'Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.58', datum: '2026-11-09', punkte: [
        'Aufenthalte als Zusammenstellung: Du kannst dir einen Knopf bauen, der einen Aufenthalt festhält. Bei „Arten von Ereignissen“ gibt es dafür die Vorlage „Aufenthalt“: Nach dem Antippen kommt die Seite „Ort festhalten“, dieselbe wie bei einer Ankunft. Dort bestätigst du den Ort oder legst einen neuen an, gibst die Ausstattung an und trägst Kosten ein (Liegeplatz, Strom, Wasser, Gebühr). Es entsteht der Besuch im Ortsverlauf, der Plan wird gegen das Ist gehalten, die Kosten werden Posten an Reise und Ort.',
        'Dauer des Aufenthalts: Beim Besuch, in der Liste der Besuche am Ort und in der Liste der Besuche einer Reise steht jetzt, wie lange du dort warst: von der Ankunft (Ankunft, Anlegen, Anker werfen) bis zur nächsten Abfahrt (Abfahrt, Ablegen, Anker lichten). Das gilt auch für Besuche von früher. Auch über Mitternacht stimmt die Zahl. Gibt es noch keine Abfahrt, steht „Noch keine Abfahrt festgehalten“, keine Zahl.',
        'Die kleine Frage nach einer Ankunft im Cockpit bleibt, wie sie war. Bestehende Besuche bleiben gültig. Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben, wie sie waren.'
      ] },
      { version: '2.0.57', datum: '2026-11-09', punkte: [
        'Literpreis: Beim Tanken steht der Literpreis jetzt mit drei Stellen hinter dem Komma, zum Beispiel 1,759. Vorher wurde er in der Anzeige auf 1,76 gerundet. Gespeichert war er schon immer genau. Menge, Füllstand und Beträge bleiben wie sie waren.',
        'Störung als Zusammenstellung: Du kannst dir einen Knopf bauen, der eine Störung meldet. Bei „Arten von Ereignissen“ gibt es dafür die Vorlage „Störung“: Nach dem Antippen fragt die App nach Beschreibung, Foto, Einschränkung und „Reparieren bis“ und legt den Vorgang in der Werkstatt an. Das Fahrzeug zeigt dann, wie weit es eingeschränkt ist.',
        'Frist für die Reparatur: Jeder Vorgang kann ein Datum „Reparieren bis“ haben (freiwillig, auch bei „Angaben ändern“). Ist es vorbei und der Vorgang noch offen, steht in der Werkstatt-Liste „überfällig“ und beim Vorgang ein Hinweis.',
        'Das Ereignis „Störung“ im Logbuch funktioniert wie bisher. Bestehende Störungen und Vorgänge bleiben gültig. Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben, wie sie waren.'
      ] },
      { version: '2.0.56', datum: '2026-11-09', punkte: [
        'Verbrauch in allen Einheiten: Nach dem Tanken rechnet die App alles, was sich rechnen lässt: Liter je Betriebsstunde, Liter je Kilometer, Liter je Seemeile und Liter je Tag. Die Betriebsstunden und die Kilometer kommen aus den Zählern, die du dort auch korrigieren kannst.',
        'Einstellungen › Verbrauch: Hier wählst du, welche Einheit vorn steht. Gerechnet wird immer alles, die Auswahl ändert nur die Reihenfolge. Die Reichweite kommt zusätzlich in Kilometern und Seemeilen, wenn der Verbrauch je Kilometer bekannt ist.',
        'Aktivität: Auf der Seite der Aktivität steht der Durchschnitt aus allen Tankungen dieser Aktivität.',
        'Fehlt etwas, zum Beispiel der Kilometerstand, steht ein Hinweis statt einer falschen Zahl. Ohne Kilometerzähler ändert sich nichts. Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig. Am Gerät noch nicht getestet.'
      ] },
      { version: '2.0.55', datum: '2026-11-09', punkte: [
        'Im Cockpit stehen Motor- und Verbraucher-Schalter in einer gemeinsamen Reihe nebeneinander und gehen in die nächste Zeile, wenn der Platz nicht reicht. Vorher standen Motoren und Verbraucher in zwei Reihen untereinander.'
      ] },
      { version: '2.0.54', datum: '2026-11-09', punkte: [
        'Die Schalter für Motor und Verbraucher im Cockpit sind viel kleiner, so groß wie die übrigen Knöpfe. Name und Start oder Stopp stehen nebeneinander, mehrere Schalter passen in eine Reihe.',
        'Wenn beim Tanken kein Tank gewählt ist, steht die Meldung jetzt direkt beim Feld „Tank“.'
      ] },
      { version: '2.0.53', datum: '2026-11-09', punkte: [
        'Jeder Verbraucher hat jetzt wie der Motor seinen eigenen Schalter (Start und Stopp), ohne dass du etwas zuordnen musst. Ein neuer Verbraucher, zum Beispiel eine Heizung, steht von selbst im Cockpit, in einer eigenen Reihe unter den Motoren.',
        'Welche Verbraucher-Schalter im Cockpit stehen, wählst du je Fahrzeug auf der Seite „Motoren und Verbraucher“ („Im Cockpit zeigen“ oder „Nicht im Cockpit zeigen“). Es wird nichts gelöscht.',
        'Beim Anlegen eines Fahrzeugs gibt es nach der Fahrzeugart eine Checkliste: Du hakst an, welche Komponenten das Fahrzeug hat (Motor, Tank, Wassertank, Heizung, Boiler …). Danach fragt die App sie nacheinander ab. Du kannst überspringen oder alles abwählen.',
        'Die Komponentenliste ist offen: Vorlage als Anfang, eigene Einträge, Ausblenden. Du findest sie unter „Merkmale und Einheiten“. Welche Einträge zu welcher Fahrzeugart passen, ist ein Vorschlag.',
        'Für den Motor ändert sich nichts. Alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.52', datum: '2026-11-09', punkte: [
        'Ein und Aus gilt jetzt für jeden Verbraucher, nicht nur für Motoren. Die App merkt sich, wann ein Verbraucher eingeschaltet und ausgeschaltet wurde, rechnet die Dauer und zählt die Betriebsstunden mit.',
        'Du baust dir die Knöpfe selbst, zum Beispiel „Heizung an“ und „Heizung aus“, bei den Arten von Ereignissen (Stammdaten). Dort gibt es die Frage „Verbraucher“ und die Wirkungen „Verbraucher einschalten“ und „Verbraucher ausschalten“, dazu zwei Vorlagen, die nur die Haken setzen. Eine Art kann nicht beides zugleich.',
        'Die Zeit des Eintrags ist Start und Stopp des Laufs. Läuft der Verbraucher schon, oder läuft er nicht, sagt die App es dir und bucht nichts doppelt. Die Zeiten lassen sich korrigieren, die Betriebsstunden folgen dem korrigierten Wert.',
        'Beim Tanken rechnet die App für eine Heizung, bei der „Verbrauch rechnen aus Betriebsstunden“ eingestellt ist, automatisch Liter je Betriebsstunde. Die weiteren Verbraucher mit Läufen stehen auf der Seite „Motoren“.',
        'Für den Motor ändert sich nichts: Schalter, Kurzname, Motorstopp-Frage und Zähler bleiben wie bisher. Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.51', datum: '2026-11-09', punkte: [
        'Tanken komplett: Ein Tipp auf „Tanken“ rechnet alles. Du gibst Tank, Menge, Betrag (oder Literpreis) und „voll getankt“ an, die App legt den Kostenposten an (Kostenart „Treibstoff und Energie“), setzt den Füllstand des Tanks und rechnet Verbrauch und Reichweite.',
        'Du stellst es bei der Art „Tanken“ ein (Stammdaten, „Arten von Ereignissen“). Dort gibt es die Vorlage „Tanken“, sie setzt nur die Haken. Du kannst jeden Haken ändern.',
        'Den Füllstand gibst du einmal beim Tank an (Feld „Füllstand jetzt“). Voll getankt setzt den Tank auf seinen Tankinhalt. Nicht voll getankt: Stand plus Menge, mit dem Hinweis, dass der Stand dann nur gerechnet ist.',
        'Beim Verbraucher wählst du „Verbrauch rechnen aus“: aus dem Füllstand (Liter je Tag) oder aus den Betriebsstunden (Liter je Betriebsstunde). Hängen mehrere Verbraucher am selben Tank, gibt der Füllstand nur die Summe.',
        'Fehlt etwas (Tankinhalt, früherer Stand, Betriebsstunden), rät die App nicht. Sie sagt, was fehlt. Ein Tankvorgang wird je Eintrag nur einmal verbucht. Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.50', datum: '2026-11-08', punkte: [
        'Baukasten-Gerüst: Jeder Knopf folgt jetzt demselben Muster. Erst hält er Ort und Zeit fest (immer), dann fragt er, was die App nicht wissen kann, dann tut die App selbst, was daraus folgt. Das ist das Gerüst für Tanken, Störung und Aufenthalte, die in den nächsten Stufen kommen.',
        'Du stellst es bei der Art des Ereignisses ein (Stammdaten, „Arten von Ereignissen“, Block „Nach dem Antippen“): Fragen sind Text, Foto, Betrag und Ziel. Wirkungen sind „Kostenposten anlegen“ (aus dem Betrag, bei den variablen Kosten, am Fahrzeug und an der Reise) und „Navigations-App öffnen“.',
        'Die Aktionen aus 2.0.47 (Textfeld, Foto, Navigation) gehen darin auf. Eine Art, die schon eine Aktion hat, zeigt sie als Fragen und Wirkungen und verhält sich genauso wie bisher. Nichts wird umgeschrieben, solange du die Art nicht änderst.',
        'Ein Kostenposten wird je Eintrag nur einmal angelegt. Der Eintrag im Logbuch zeigt den Betrag und führt zum Kostenposten.',
        'Ohne Haken bleibt jeder Knopf wie bisher. Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.49', datum: '2026-11-08', punkte: [
        'Weiteren Tank anlegen: Im Formular einer Komponente steht unter der Liste der Tanks immer der Knopf „Weiteren Tank anlegen“, auch wenn es schon einen Tank gibt. Das gilt beim Anlegen und beim Ändern.',
        'Deine Eingaben im Formular gehen dabei nicht verloren. Nach dem Speichern des Tanks (oder mit „Abbrechen“) kommst du zum ursprünglichen Formular zurück, und der neue Tank steht schon in der Liste. Angekreuzt wird er nicht von selbst. Gespeichert wird erst, wenn du im Formular auf „Speichern“ tippst.',
        'Foto: Statt zwei gleich aussehender Felder gibt es jetzt zwei klare Knöpfe: „Foto jetzt aufnehmen“ öffnet die Kamera, „Vorhandenes Bild wählen“ öffnet die Galerie. Darunter steht, welche Datei gewählt ist. Das gilt beim Foto im Cockpit, beim Ereignis eintragen und bei der Aktion „Foto“.',
        'Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.48', datum: '2026-11-08', punkte: [
        'Verbraucher und Quelle: MobiMory kann jetzt abbilden, was woher versorgt wird. Neu ist die Art „Tank“ (Hauptkomponente) mit einem Inhalt, zum Beispiel Diesel oder Gas.',
        'Beim Anlegen oder Ändern einer Komponente kommt eine kurze, freiwillige Frage: Ist es ein Verbraucher (Ja, Nein, noch offen)? Bei „Ja“ wählst du, was er verbraucht, und aus welchem Tank er bezieht. Es sind mehrere Tanks möglich, und mehrere Verbraucher dürfen am selben Tank hängen. Nichts wird von selbst eingetragen.',
        'Stoffe (Diesel, Benzin, Gas, Strom …) kommen aus einer offenen Liste. Eigene Stoffe legst du im Formular oder unter Stammdaten › Merkmale und Einheiten an und kannst jeden ausblenden. Zu Strom siehe Version 2.0.59.',
        'Am Fahrzeug zeigt der Block „Verbrauch und Versorgung“ die Kette: Tanks mit ihren Verbrauchern, Verbraucher ohne Quelle und offene Fragen.',
        'Komponenten mit dem Merkmal „Tankinhalt“ werden dir als möglicher Tank angeboten. Du entscheidest, der Verlauf hält es fest.',
        'Ein Tank, aus dem noch ein Verbraucher bezieht, lässt sich nur ausblenden, nicht löschen oder unter ein Teil verschieben.',
        'Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.47', datum: '2026-11-08', punkte: [
        'Ereignis-Knöpfe als Baukasten: Ein Knopf hält weiter zuerst Wo und Wann fest. Neu kann jede Art von Ereignis zusätzlich eine Aktion auslösen. Du stellst sie bei der Art ein (Stammdaten, „Arten von Ereignissen“, Block „Aktion beim Antippen“). Ohne Aktion bleibt der Knopf genau wie bisher.',
        'Zur Auswahl stehen: Textfeld öffnen, Foto aufnehmen oder wählen, Navigations-App des Geräts öffnen. Nach dem Antippen ist der Eintrag schon gespeichert, danach kommt die Aktion. Du kannst sie überspringen. Text und Foto kommen zum Eintrag dazu und zählen im Logbuch nicht als „korrigiert“.',
        'Navigation: Die App übergibt nur das Ziel, das Gerät entscheidet, welche Navigations-App öffnet. Auf Android und auf Apple kann das verschieden aussehen. Das Ziel steht danach als Text beim Eintrag.',
        'Welche Aktionen es gibt, steht nur in einer Liste. Weitere Aktionen kommen später dazu, ohne dass sich der Aufbau ändert. Jeder Nutzer weist seinen Knöpfen die Aktionen selbst zu.',
        'Foto mit Kamera: Beim Foto im Cockpit und beim Ereignis eintragen öffnet „Foto jetzt aufnehmen“ direkt die Kamera. Alternativ wählst du wie bisher ein vorhandenes Bild. Das Gerät fragt beim ersten Mal nach der Erlaubnis für die Kamera. Es geht auch ohne Internet.',
        'Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.46', datum: '2026-11-07', punkte: [
        'Kosten, Liste der Fahrzeuge: Abgegebene Fahrzeuge stehen nicht mehr zwischen den aktiven. Sie stehen unten, eingeklappt unter „Abgegebene Fahrzeuge“, und sind als abgegeben gekennzeichnet (verkauft, verschenkt … am Datum). Ihre Kosten bleiben erhalten.',
        'Gleiches Fahrzeug nicht doppelt: Beim Anlegen eines Fahrzeugs und beim Einlesen einer Übergabedatei prüft die App Kennzeichen, Registriernummer, FIN und HIN (ohne Leerzeichen, Striche und Punkte, Groß und klein egal) gegen alle vorhandenen Fahrzeuge, auch die abgegebenen. Gibt es das schon, wird nichts angelegt, sondern gefragt: das vorhandene Fahrzeug öffnen, die Kennung ändern oder trotzdem neu anlegen. Die Übernahme aus Excel oder CSV prüfte schon vorher und zeigt „Gibt es schon“ in der Vorschau, das bleibt so.',
        'Kostenposten korrigieren und löschen: Auf der Seite eines Postens steht jetzt unter dem Posten „Falsch eingegeben?“ mit den drei Knöpfen Korrigieren, Ausblenden und Löschen. Löschen fragt vorher nach, nennt Posten und Betrag und weist auf mitgelöschte Fotos und Belege hin. Gelöscht wird endgültig, samt Verlauf. Auch Ausgaben der Reisekasse lassen sich löschen, die Kasse rechnet danach ohne den Betrag. In den Listen der Kosten steht der Hinweis, dass man den Posten antippt, um ihn zu korrigieren oder zu löschen.',
        'Nicht geändert: Der Sprung ins Jahr des Postens nach „Eingetragen“ und die eingeklappten „Weiteren Posten ohne Anteil“. Die Ursache der scheinbar fehlenden Fixkosten wird erst am Gerät geklärt. Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.45', datum: '2026-11-07', punkte: [
        'Komponenten löschen oder ausblenden: Auf der Seite der Komponente steht der Block „Verwalten“. Was nirgends benutzt wird (keine Frist, kein Zähler, kein Motorlauf, keine Kosten, kein Vorgang, kein Dokument, keine Gleichsetzung bei der Pflichtausrüstung, auch nicht an einem Teil darunter), lässt sich löschen, mit Rückfrage und dem Hinweis, wie viele Teile darunter mit verschwinden. Was benutzt wird, lässt sich nur ausblenden und wieder einblenden. Eine ausgeblendete Hauptkomponente verdeckt alles darunter. Ausgeblendete Komponenten zählen nicht für die Pflichtausrüstung, den Grundcheck, den Reisecheck und den Motorschalter im Cockpit (ein Motor, der noch läuft, bleibt sichtbar). Sie stehen eingeklappt unter „Ausgeblendet“. „Ausgebaut am“ bleibt etwas anderes.',
        'Komponente verschieben: Hast du ein Teil unter die falsche Komponente gehängt, geht es auch dann zu korrigieren, wenn es schon benutzt wird. „Verschieben“ nimmt die Komponente mit allen Teilen darunter unter eine andere Komponente desselben Fahrzeugs oder direkt unters Fahrzeug (dann wird sie Hauptkomponente und braucht eine Art, vorgeschlagen ist „Sonstiges“). Fristen, Zähler, Kosten, Dokumente und Vorgänge bleiben dran. Nicht möglich: unter sich selbst, unter ein eigenes Teil, in ein anderes Fahrzeug. Der Verlauf hält fest, von wo nach wo.',
        'Merkmale mit Liste und Einheit: Jedes Merkmal hat jetzt Name, Wert, Einheit und, wenn es passt, eine Bezugsgröße, zum Beispiel „Verbrauch, 8, l, bezogen auf 100 km“. Der Name kommt aus einer Merkmal-Liste (Vorschläge beim Tippen), die Einheit aus einer Einheiten-Liste. Beide Listen sind offen: eigene Einträge anlegen, auch mitten im Formular, und jeden Eintrag ausblenden (Stammdaten › Merkmale und Einheiten). Die Vorlage ist nur der Anfang, die App trägt nichts von selbst ein. Eine Einheit gibt es nur aus der Liste, damit „kn“ und „Knoten“ nicht durcheinandergehen. Wählst du ein bekanntes Merkmal, steht die Einheit schon da und lässt sich ändern. Alte Merkmale ohne Einheit bleiben, wie sie sind, und lassen sich später ergänzen.',
        'Zusammengehörige Fahrzeuge: Im Formular des Fahrzeugs gibt es „Gehört zu“, für jede Fahrzeugart: der Trailer zum Boot, das Dinghy zur Yacht, der Motorradanhänger zum Wohnmobil. Jedes Fahrzeug bleibt ein eigenes Fahrzeug mit eigenen Daten. „Gehört zu“ lässt sich jederzeit ändern (steht im Verlauf), auch als Kette (Motorrad auf Anhänger am Wohnmobil). Kein Fahrzeug gehört zu sich selbst, Kreise sind nicht möglich. Am Anhänger steht „Gehört zu“, am Hauptfahrzeug die Liste der dazugehörigen Fahrzeuge mit Sprung dorthin. Gibst du das Hauptfahrzeug ab, bleibt der Anhänger bestehen und verliert nur die Zuordnung, mit Hinweis.',
        'Planung: Die Prüfung einer Aktivität zeigt zusätzlich die Fristen aller dazugehörigen Fahrzeuge im Zeitraum, getrennt nach Fahrzeug („Dazugehörige Fahrzeuge: Fristen bis zum Ende“), mit derselben Rechnung wie beim Hauptfahrzeug. Das ist ein Hinweis, nichts wird gesperrt. Befähigung, Pflichtausrüstung und Gebiet gelten weiter für das Fahrzeug der Aktivität.',
        'Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig. Die Übergabedatei eines abgegebenen Fahrzeugs enthält keinen Verweis auf andere Fahrzeuge.'
      ] },
      { version: '2.0.44', datum: '2026-11-05', punkte: [
        'Cockpit, Wetter: Die Meldung zum Wetter bleibt nicht mehr stehen. Sie verschwindet nach ein paar Sekunden von selbst, oder du tippst sie an. Der Eintrag „Wetter“ im Logbuch ändert sich nicht, er ist weiterhin der Stand zu diesem Zeitpunkt.',
        'Cockpit, Kopfzeile: Neben der Position und der GPS-Strecke steht ein Wechselfeld für die Geschwindigkeit. Jeder Tipp schaltet weiter: Aktuell, Ø fahrend, Ø Tag und wieder Aktuell. Beim Start steht „Aktuell“ da. Auf dem Wasser in Knoten, sonst in km/h.',
        'So wird gerechnet: Ø fahrend ist die Strecke geteilt durch die Zeit, in der sich das Fahrzeug wirklich bewegt hat. Ø Tag ist die Strecke geteilt durch die ganze Zeit seit der ersten Bewegung, also mit Schleusen, Pausen und Stopps. Der Tag läuft von der ersten Bewegung bis zum Tagesabschluss. Gezählt wird nach denselben Regeln wie die GPS-Strecke, nur in Fahrt.',
        'Speichern: Beim Tagesabschluss schreibt die App die Werte des Tages als Eintrag „Geschwindigkeit“ ins Logbuch (Ø fahrend, Ø Tag, Strecke, Fahrzeit, Gesamtzeit). Danach bleibt der Wert dieses Tages stehen, und die nächste Bewegung beginnt eine neue Zählung. Zwischenwerte kommen im selben Rhythmus wie der Wetterbericht dazu. Der Rhythmus ist einer für alle automatischen Einträge und lässt sich unter „Wetter im Rhythmus“ einstellen. Dafür braucht es kein Netz.',
        'Aktivität über mehrere Tage: Statt aller Tage untereinander steht oben ein Knopf mit dem gewählten Reisetag, zum Beispiel „Tag 3 von 8“. Dahinter liegt ein Kalender, der am ersten Reisetag beginnt und am letzten endet, nicht beim heutigen Datum. Tage mit einem Eintrag im Logbuch sind hervorgehoben. Nach dem Antippen schließt sich der Kalender, und es steht nur dieser Tag in der Zusammenfassung und im Logbuch. Während der Reise ist der heutige Reisetag vorgewählt, sonst Tag 1. Pfeile für den vorigen und nächsten Tag gibt es in dieser Stufe nicht.',
        'Korrektur: In „Neu im Programm“ zu 2.0.43 stand „2 bis 30 Tage“. Das war nur ein Beispiel. Eine Reise kann beliebig viele Tage haben. Der Speicher wurde nicht umgestellt, alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.43', datum: '2026-11-05', punkte: [
        'Etappen: Eine Aktivität kann mehrere Tage dauern. Jeder Tag im Logbuch ist eine Etappe mit eigenem Startort und Zielort, eigenem Wetter und eigenen Kosten. Es gibt keine zweite Struktur daneben, die Etappe ist der Tag, den du schon kennst.',
        'Start und Ziel: Beim Tag wählst du Startort und Zielort aus der Ortsliste. Zur Wahl stehen die Orte der Gesamtplanung der Reise (Start, Zwischenziele, Ziel). Ein früher eingetragener Text bleibt erhalten.',
        'Wetter je Tag: Die App holt das Wetter für die Punkte zwischen den zwei Orten des Tages zur Ankunftszeit (Abstandsregel wie bei der Route). Du kannst es jederzeit von Hand ersetzen. Fehlt etwas, zum Beispiel die Uhrzeit des Beginns, sagt die App „unklar“ und nennt, was fehlt.',
        'Kosten je Tag: Beim Eintragen von Kosten einer Aktivität wählst du den Tag der Reise. Ohne Angabe ordnet die App den Betrag dem Tag mit gleichem Datum zu, wenn es genau einen gibt, sonst steht er „ohne Tag“. Die Reisesumme bleibt die Summe aller Tage.',
        'Reisecheck je Tag: Auf der Seite eines Tages gibt es „Reisecheck für diesen Tag“ mit den zwei Orten dieses Tages, zusätzlich zum Gesamtcheck. Er zählt zurzeit nicht im Kontingent, das wird mit dem Kostenmodell entschieden.',
        'Zusammenfassung: Oben an der Aktivität stehen alle Tage mit Start und Ziel, Strecke, Kosten, Ereignissen und Wetter, dazu die Gesamtsumme der Reise. Die Strecke rechnet die App auf der Route, wenn beide Orte an ihr liegen, sonst als Luftlinie zwischen den Orten (so gekennzeichnet).'
      ] },
      { version: '2.0.42', datum: '2026-11-05', punkte: [
        'Revier als Auswahlliste: Beim Ort wählst du das Revier jetzt aus einer Liste. Sie zeigt die Reviere, die du in diesem Land schon eingetragen hast. Ein neues Revier legst du mit „Neues Revier eintragen“ an, danach steht es beim nächsten Ort in der Liste. „Kein Revier“ leert das Revier des Ortes.',
        'Der Ort ist jetzt die unterste Ebene: Ein Ort bekommt nur dann eigene Regeln, wenn du ihm welche anlegst (auf der Seite des Ortes: „Eigene Regel für diesen Ort“). Dann sieht die Kette beim Boot so aus: Land, Revier, Ort. Bei Landfahrzeugen: Land, Region, Kreis, Ort. Ohne eigene Regel gelten die Regeln der Ebenen darüber.',
        'So hältst du fest, dass am selben Revier an einem bestimmten Ort etwas anderes gilt, zum Beispiel am Rhein bei Bonn etwas anderes als bei Köln. Frankreich und Deutschland trennt schon das Land. Die Regeln des Ortes gelten zusätzlich zu denen des Reviers, bei der Prüfung und im Reisecheck (dort steht der Ort hinten an der Kette).',
        'Eine eigene Regel gibt es erst, wenn der Ort über die Ortssuche geprüft ist, weil sie unter dem Land des Ortes hängt. Es wird nichts gesperrt. Benennst du den Ort um oder prüfst ihn neu, zieht sein Regel-Gebiet mit, die Regeln bleiben.'
      ] },
      { version: '2.0.41', datum: '2026-11-05', punkte: [
        'Grundcheck: „Habe ich unter anderem Namen“. Heißt ein Punkt bei dir anders, zum Beispiel „Persönliche Schwimmhilfe“ statt „Rettungsweste“, wählst du bei diesem Punkt deine Bezeichnung aus der Liste. Damit bestätigst du selbst, dass beides dasselbe ist. Die App rät nichts und setzt nie von selbst etwas gleich.',
        'Die Zuordnung gilt für das Land und die Fahrzeugart. In einem anderen Land oder bei einer anderen Fahrzeugart wählst du neu. Mit „Aufheben“ nimmst du sie zurück.',
        'Die App merkt sich die Zuordnung und nimmt sie im Grundcheck und bei der Pflichtausrüstung im Reisecheck. Anzahl und Haken „Eignung geprüft“ deiner Komponente zählen dabei mit.',
        'Der Grundcheck sucht in allen Ebenen deiner Komponentenliste, nicht nur in den Hauptkomponenten. Ausgebaute Teile zählen nicht.'
      ] },
      { version: '2.0.40', datum: '2026-11-05', punkte: [
        'Grundcheck: Am Fahrzeug gibt es jetzt „Grundcheck“. Er sagt, was dein Fahrzeug an seinem Heimatort (Heimatland) an Papieren und Grundausrüstung braucht, zum Beispiel Zulassungsbescheinigung Teil 1 und 2, Warndreieck, Warnweste, Feuerlöscher. Jeder Punkt hat Quelle und Stand. Er braucht kein Datum und keine Besatzung.',
        'Die App vergleicht mit dem, was am Fahrzeug eingetragen ist: vorhanden, zu wenig, fehlt oder unklar. Es wird nichts gesperrt, und es ist keine rechtsgültige Aussage.',
        'Fehlt etwas, führt ein Knopf direkt zum Eintragen. Bei Ausrüstung öffnet sich die Komponentenliste mit Name und Menge schon vorgefüllt, du bestätigst nur. So entsteht nach und nach die Grundausrüstung deines Fahrzeugs. Papiere trägst du als Nachweis am Fahrzeug ein, mit Foto oder Scan.',
        'Neu am Fahrzeug: das Feld „Personen / Plätze“. Damit rechnet der Grundcheck Ausrüstung „je Person“, zum Beispiel Warnwesten. Ohne diese Angabe sagt er „unklar“ und rät nichts.',
        'Das Heimatland kommt vom Heimatstandort des Fahrzeugs (Ort, der über die Ortssuche geprüft ist). Ziehst du um, wählst du den neuen Heimatstandort und wiederholst den Grundcheck. Frühere Checks bleiben erhalten.',
        'Der Grundcheck nutzt den Dienst und die Zustimmung des Reisecheck. Es geht nur das Fahrzeug ohne Namen und ohne Nummern hinaus. Er zählt nicht zum Reisecheck-Kontingent, die Entscheidung kommt mit dem Kostenmodell.'
      ] },
      { version: '2.0.39', datum: '2026-11-05', punkte: [
        'Orte und Gebiete: Du gibst nur noch Orte ein. Die App prüft den Ort mit einer Suche (Netz nötig) und macht daraus das Gebiet: Land, Region, Kreis oder Département, zum Beispiel Deutschland, Baden-Württemberg, Landkreis Böblingen.',
        'Gibt es den Namen mehrfach, bekommst du eine Auswahlliste, zum Beispiel Eutingen bei Herrenberg oder bei Pforzheim. Du wählst, und die App legt den Ort mit Position an.',
        'Jedes Gebiet wird beim ersten Mal gespeichert und danach wiederverwendet. So wächst eine Gebietsbibliothek für den Reisecheck. Ein Gebiet, das du früher selbst angelegt hast und das so heißt, übernimmt die Ebene, seine Regeln bleiben.',
        'Das Gebiet richtet sich nach dem Fahrzeug: Landfahrzeuge zählen mit Land, Region und Kreis (Straße), Wasserfahrzeuge mit Land und Revier (Binnenwasserstraße, zum Beispiel Rhein, beim Ort einzutragen). Hast du nur Landfahrzeuge, siehst du nur das Straßen-Gebiet, nur Wasserfahrzeuge nur das Revier. In der Prüfung zählt das Fahrzeug der Aktivität.',
        'Die Regeln der Gebiete der Orte (Start, Ziel, Zwischenziele) gelten bei der Prüfung und gehen mit den Gebieten in den Reisecheck. Ist ein Ort nicht geprüft oder fehlt das Revier, sagt die App „unklar“. Es wird nichts gesperrt, und du kannst Orte weiter ohne Prüfung anlegen.'
      ] },
      { version: '2.0.38', datum: '2026-11-05', punkte: [
        'Reisecheck: Für jede Aktivität kannst du online prüfen lassen, was für die Reise nötig ist (Papiere, Ausrüstung, Einreise, Hinweise). Das Ergebnis steht nach Pflicht, Wichtig, Empfohlen und Hinweisen, jeweils mit Quellen und Stand.',
        'Vorher siehst du unter „Was geht an den Dienst?“, was hinausgeht. Es gehen keine Namen und keine Nummern mit. Die Besatzung heißt dort nur „Person 1“ und „Tier 1“, ihre Nachweise mit Ablaufdatum werden verglichen.',
        'Du richtest den Dienst einmal ein (Adresse und Passwort, nur auf diesem Gerät, nicht in der Sicherung) und stimmst ausdrücklich zu. Die Zustimmung kannst du jederzeit widerrufen. Sie wird mit Datum festgehalten.',
        'Ändert sich nach einem Check etwas an Besatzung, Nachweisen, Fahrzeug oder Zeitraum, zeigt die App „Daten seitdem geändert“. Alle Checks einer Aktivität bleiben erhalten.',
        'Der Reisecheck ist eine Planungshilfe und keine rechtsgültige Auskunft. Die Verantwortung bleibt beim Skipper oder Fahrer.',
        'Noch nicht dabei: Highlight-Vorschläge, Ampel der Behörden je Land, Kontingent und Bezahlstufe (kommen mit Konten und Server).'
      ] },
      { version: '2.0.37', datum: '2026-11-04', punkte: [
        'Fahrzeugart ändern: Unter „Angaben ändern“ kannst du jetzt auch die Fahrzeugart wechseln, zum Beispiel wenn du beim Anlegen die falsche Gruppe gewählt hast. Vor dem Speichern zeigt die App, was sich ändert, und du bestätigst es.',
        'Nichts geht dabei verloren: Angaben, die es bei der neuen Art nicht gibt, bleiben gespeichert und sind nur ausgeblendet. Wechselst du zurück, sind sie wieder da. Der frühere Stand steht im Verlauf des Fahrzeugs. Bereits erfasste Ereignisse im Logbuch, die nicht mehr zur Art passen, bleiben erhalten und sind mit „Gehört nicht mehr zur Fahrzeugart“ markiert.',
        'Fahrzeug abgeben: Auf der Fahrzeugseite gibt es „Fahrzeug abgeben“ (verkauft, verschenkt, verschrottet, mit Datum). Das Fahrzeug verschwindet aus allen Auswahllisten, bleibt bei dir aber lesbar. Du findest es in der Fahrzeugliste unter „Abgegebene Fahrzeuge“ und kannst es jederzeit wieder aktiv setzen. Aktivitäten, Logbuch, Kosten und Reisekasse bleiben bei dir.',
        'Technik-Akte als PDF: Zum Ausdrucken für den Kaufvertrag. Sie zeigt die technische Historie von der letzten HU bis zur Abgabe, höchstens 24 Monate: letzte HU, Zählerstände, erledigte und offene Fristen, Störungen und Arbeiten, Hauptkomponenten. Ist keine HU erfasst, beginnt sie mit dem Anlegen des Fahrzeugs (aber nicht früher als 24 Monate vor der Abgabe). Eine überfällige HU steht deutlich im PDF.',
        'Übergabedatei für den neuen Besitzer: Sie enthält die ganze technische Historie (Komponenten und Ausrüstung, Zähler, Fristen und Prüfungen, Störungen und Arbeiten, Dokumente, auf Wunsch mit den Dateien, auf Wunsch mit Schlüsselwort). Nicht enthalten sind Aktivitäten, Logbuch, Kosten, Reisekasse, Personen und Besatzung.',
        'Fahrzeug übernehmen: Der neue Besitzer liest die Übergabedatei unter Einstellungen oder in der Fahrzeugliste ein. Das Fahrzeug wird als neues Fahrzeug angelegt, mit der ganzen technischen Historie. Vorhandenes wird nicht verändert.',
        'Der Speicher wurde nicht umgestellt. Alle Daten und Sicherungen bleiben gültig. Eine Übergabedatei lässt sich nicht aus Versehen als Sicherung einspielen.'
      ] },
      { version: '2.0.36', datum: '2026-11-04', punkte: [
        'Neu: Den Abstand der Wetterpunkte an der Route stellst du selbst ein, wie in der ersten Version: nach Entfernung (alle x km oder x sm) oder nach Fahrzeit (alle x Stunden). Du findest das bei den Angaben zur Route unter „Abstand der Wetterpunkte“.',
        'Ohne eigene Eingabe gilt die Voreinstellung: auf dem Wasser alle 10 sm, sonst jede Stunde. Start, Ziel und benannte Wegpunkte bekommen immer Wetter. Ändert sich der Abstand, rechnet die App die Punkte neu, die Route bleibt dieselbe. Das Wetter musst du danach neu holen.',
        'Mit eigenem Abstand nimmt die App höchstens 24 Wetterpunkte je Route.'
      ] },
      { version: '2.0.35', datum: '2026-11-04', punkte: [
        'Geändert: „Wetter“ und „Karte“ sind keine festen Knöpfe mehr, sondern ganz normale Ereignisse. Du legst sie wie alle anderen als Knopf auf den Cockpit-Bildschirm oder lässt sie unter „Sonstige Ereignisse“ liegen. Sie gelten für alle Fahrzeugarten und sind im Standard schon auf Knöpfen.',
        '„Wetter“ holt das Wetter an deinem Standort und speichert es im Logbuch. „Karte“ öffnet nur die Karte und schreibt nichts ins Logbuch. Die feste Zeile im Cockpit ist weg, das Cockpit hat wieder den ganzen Platz für deine Knöpfe.',
        'Wer sie nicht will, blendet die Art aus oder löscht sie unter „Arten von Ereignissen“. Die App legt sie danach nicht noch einmal an.'
      ] },
      { version: '2.0.34', datum: '2026-11-04', punkte: [
        'Neu im Cockpit: „Wetter jetzt“ holt das Wetter an deinem Standort (Quelle Open-Meteo, Modellwert der aktuellen Stunde) und schreibt es als Eintrag „Wetter“ ins Logbuch, mit Datum, Uhrzeit und Position. Bei Wasserfahrzeugen kommen Wellen und Wasserstand dazu. Ohne Netz oder ohne GPS-Position wird nichts gespeichert.',
        'Wetter im Rhythmus: Unter Einstellungen stellst du ein, dass die App das Wetter zusätzlich selbst holt (alle 30 Minuten bis alle 6 Stunden). Das läuft nur, solange das Cockpit oder die Karte offen ist, das Fahrzeug in Fahrt ist und das Gerät GPS und Netz hat. Die Einstellung gilt nur für dieses Gerät.',
        'Neu: Karte im Vollbild, im Cockpit über „Karte“. Sie zeigt die geplante Route, Start, Ziel und Zwischenziele, die Wetterpunkte (grau, wenn du sie schon passiert hast), deine „Wetter jetzt“-Einträge, deinen tatsächlich gefahrenen Weg und deine Position. Der Weg wird aufgezeichnet, solange das Cockpit oder die Karte offen ist und das Fahrzeug in Fahrt ist.',
        'Auf der Karte siehst du, wo du auf der Route liegst, wie weit daneben, und ob du früher oder später bist als geplant. Bist du später, rechnet die App die Wetterpunkte vor dir für die neue Ankunftszeit neu.',
        'Offline-Karte: Unter „Karte“, „Offline-Karte“ holst du für eine Aktivität nur den Streifen entlang der Route (Stufen grob, mittel, fein, die Größe wird vorher angezeigt) und kannst ihn wieder löschen. Die Kacheln liegen nur auf diesem Gerät und nicht in der Sicherungsdatei.',
        'Die Kartenquelle (OpenStreetMap, Standard-Kacheln) ist für Tests im kleinen Rahmen gedacht. Die App begrenzt den Abruf deshalb hart. Vor der Veröffentlichung in einem App-Store wird die Quelle gewechselt, das ist an einer einzigen Stelle möglich.',
        'Die Karte selbst zeichnet Leaflet 1.9.4 (liegt in der App, kein Abruf von außen). Alle Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt.'
      ] },
      { version: '2.0.33', datum: '2026-11-04', punkte: [
        'Neu: Route und Wetter. An jeder Aktivität liest du eine Routendatei ein (GPX, KML oder GeoJSON). MobiMory plant keine Route und navigiert nicht, es rechnet nur mit der Route, die du mitbringst. Eine frühere Route bleibt erhalten.',
        'Mit Reisegeschwindigkeit (Knoten oder km/h) und Abfahrt rechnet die App Fahrzeit und Ankunftszeit an den Punkten der Route. Den Abstand der Wetterpunkte stellst du selbst ein (nach km, sm oder Fahrzeit). Die Länge der Route kannst du als geplante Strecke der Aktivität übernehmen, die Route lässt sich als GPX-Datei wieder ausgeben.',
        'Wetter am Punkt zur Ankunftszeit (Quelle Open-Meteo): Himmel, Temperatur, Wind, Böen, Regen. Bei Wasserfahrzeugen dazu Wellen, Wasserstand sowie Hoch- und Niedrigwasser. Das sind Prognosen und Modellwerte, keine Garantie und keine amtlichen Gezeitentafeln. Der geholte Stand bleibt im Gerät und ist auch ohne Netz sichtbar. Zum Abrufen braucht das Gerät Netz.',
        'Abfahrt früher oder später: ein Vergleich von zwei Stunden früher bis zwei Stunden später zeigt, wann die Böen, Wellen und der Regen am geringsten sind.',
        'Kilometer über GPS: Im Cockpit zählt die App die Strecke, solange das Fahrzeug „in Fahrt“ ist und das Cockpit offen und der Bildschirm an ist. Mit „GPS-Strecke übernehmen“ kommt sie auf Wunsch in den Streckenzähler. Dafür muss der Tachostand vorher von Hand eingetragen sein, deine Handeingabe hat immer Vorrang. Ohne GPS bleibt alles wie bisher von Hand.',
        'Auf der Startseite steht jetzt „Vehicle, Travel and Data“.',
        'Der Speicher bekommt eine neue Tabelle (Routen). Alle Daten und Sicherungen bleiben gültig, die Sicherung enthält die Routen.'
      ] },
      { version: '2.0.32', datum: '2026-11-04', punkte: [
        'Kacheln sind lesbar: Der Text wird nie mehr abgeschnitten. Braucht eine Kachel mehr Platz, wird sie höher.',
        'Titel bleiben ganze Wörter. Passt einer nicht in die Kachel, wird die Schrift etwas kleiner, und wenn es immer noch eng ist, gibt es weniger Spalten. Die Kacheln füllen weiter den freien Platz, solange der Text vollständig lesbar bleibt.',
        'Die kleinere Beschreibung unter dem Titel bricht nur noch an Silbengrenzen um, nicht mehr mitten im Wort an irgendeiner Stelle.',
        'Am Speicher hat sich nichts geändert. Alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.31', datum: '2026-11-04', punkte: [
        'Neues Logo: das M ist runder, mit der gestrichelten Linie und den drei Kreisen V, T und D. Es steht auf der Startseite, im Kopf und als App-Symbol. Die Datei ist icons/icon.svg.',
        'Alle Auswahlseiten füllen den Bildschirm: Hauptmenü, Stammdaten und Funktionen zeigen ihre Kacheln wie das Cockpit in einem Raster. Wenige Kacheln werden groß (bis zu einer sinnvollen Höhe), mehr Kacheln werden kleiner und rücken nebeneinander. So muss man kaum noch scrollen, und keine Kachel ist übertrieben breit. Beim Drehen des Geräts passt sich das Raster an.',
        'Neu unter Funktionen: das Kassenbuch. Es zeigt die Kassen aller Aktivitäten mit ihrem Stand. Ein Tipp öffnet die Reisekasse der Aktivität. Die Reisekasse an der Aktivität bleibt wie bisher.',
        'Alle Listen stehen jetzt zentral in den Stammdaten: Arten von Aktivitäten, Arten von Ereignissen (Logbuch und Cockpit) sowie Kostenarten und Zahlungsmittel. An den bisherigen Stellen (Aktivitäten, Logbuch, Kosten) bleibt der Link zur selben Liste. Es gibt keine zweite Liste.',
        'Am Speicher hat sich nichts geändert. Alle Daten und Sicherungen bleiben gültig.'
      ] },
      { version: '2.0.30', datum: '2026-11-04', punkte: [
        'Fahrzeuge aus Excel oder CSV übernehmen: Unter Einstellungen gibt es „Aus Excel oder CSV übernehmen“ (auch in der Fahrzeugliste als Link). Jede Zeile der Tabelle wird ein Fahrzeug. Du wählst die Datei, die App ordnet die Spalten nach ihren Überschriften zu, du prüfst und änderst die Zuordnung und wählst die Fahrzeugart. Stehen verschiedene Arten in der Tabelle, liest die App sie aus einer Spalte.',
        'Erst die Vorschau, dann das Übernehmen: Die Vorschau zeigt je Zeile, ob das Fahrzeug neu ist, es schon gibt (gleiches Kennzeichen, gleiche Registriernummer, FIN oder HIN, sonst gleiche Bezeichnung), in der Tabelle doppelt steht oder einen Fehler hat. Erst „Übernehmen“ legt etwas an, alle neuen in einem Zug. Vorhandene Fahrzeuge werden nie überschrieben.',
        'Deutsche Schreibweise wird verstanden: „1.234,5“, „3.500 kg“, „7,5 m“, „03.11.2019“, beim Kraftstoff auch „Super“ oder „LPG“. CSV aus deutschem Excel (Semikolon, Windows-Zeichensatz) geht genauso wie UTF-8. Eine Datei darf bis zu 1.000 Zeilen haben.',
        'Daten ausgeben: Unter Einstellungen gibt es „Als Excel oder CSV ausgeben“. Du wählst Fahrzeuge, Kosten (alle Fahrzeuge, auch die Reisekasse) und Orte. Excel enthält ein Blatt je Tabelle mit echten Zahlen und Daten. CSV enthält eine Tabelle mit Semikolon und Komma, so öffnet deutsches Excel sie ohne Umwege. Die Fahrzeug-Tabelle lässt sich wieder übernehmen.',
        'Die Tabelle ist keine Sicherung und nicht verschlüsselt. Zum Sichern aller Daten bleibt die Sicherungsdatei unter Einstellungen.',
        'Bestehende Daten und Sicherungen bleiben gültig, am Speicher hat sich nichts geändert. Noch nicht dabei: Übernehmen von Kosten, Orten oder Komponenten aus einer Tabelle, das alte Excel-Format .xls (bitte in Excel als .xlsx oder CSV speichern), Import und Export von Routen (Schritt 9) und eine Umwandlung von Bildformaten (Fotos werden so abgelegt, wie das Gerät sie liefert). Das echte Aussehen am Tablet ist nicht geprüft.'
      ] },
      { version: '2.0.29', datum: '2026-11-04', punkte: [
        'Mehrere Kostenzeilen je Besuch: Beim Festhalten eines Ortes trägst du jetzt so viele Zeilen ein, wie du brauchst, zum Beispiel Liegegebühr, Stromzuschlag, Wasserzuschlag, Müllentsorgung, Kurtaxe. Jede Zeile wird ein eigener Posten in der Kosten-Liste, mit demselben Ort, derselben Aktivität und demselben Datum. Die Summe steht unter den Zeilen.',
        'Offene Kostenarten: Die Arten sind keine feste Liste mehr. Du legst eigene Arten an, auch mitten im Formular („Oder neue Art anlegen“). Kurtaxe, Müllentsorgung, Stromzuschlag, Wasserzuschlag und Duschmarken sind als Vorschläge schon da. Benutzte Arten werden nur ausgeblendet, nicht gelöscht. Unter „Kosten“ gibt es die Seite „Arten und Zahlungsmittel“.',
        'Reisekasse: Neue Gruppe für Ausgaben der Reise, die nicht das Fahrzeug betreffen: Einkauf, Essen gehen, Souvenirs, Eintritte, Unterkunft an Land, Gebühren. Sie gehört zur Aktivität und zählt nie in die Fahrzeugkosten. Jede Ausgabe kann Notiz, Ort (aus der Orte-Liste oder als Text) und ein Foto oder einen Beleg haben, das Foto am Posten.',
        'Bezahlt mit: Freiwillig bei jeder Ausgabe. Eine eigene Liste mit Bezeichnungen wie „Girokarte“ oder „Kreditkarte“, keine Karten- oder Kontonummern. „Bar“ ist fest und gehört zur Kasse.',
        'Bargeldkasse je Währung: Zu Reisebeginn trägst du den Anfangsbestand ein. Bei „Bar“ zieht die App den Betrag von der Kasse ab, du siehst jederzeit den Stand. Geld, das du später holst, ist eine Einzahlung und keine Ausgabe, so zählt es nicht doppelt. Beim Kassensturz trägst du ein, was wirklich da ist, die App speichert die Differenz als eigenen Eintrag. Jede Währung hat ihre eigene Kasse.',
        'Kurs ohne Internet: Beim Anfangsbestand und bei jeder Einzahlung in Fremdwährung trägst du ein, wie viel Euro du dafür bezahlt hast (zum Beispiel 100 € für 1.150 NOK). Daraus rechnet die App den Durchschnittskurs. Beträge, die sie damit umrechnet, sind als „gerechnet“ gekennzeichnet. Bei einer Kartenzahlung in Fremdwährung trägst du den Euro-Betrag von der Abrechnung später nach, dann gilt er als eingegeben.',
        'Auswertung der Reise: Auf der Seite „Reisekasse“ der Aktivität siehst du Fahrzeug und Reisekasse getrennt, die Gesamtsumme, pro Tag, pro Person und pro Tag und Person, die Reisekasse nach Art und alles nach Zahlungsmittel. Der Anteil der Fixkosten des Fahrzeugs für die Reisetage steht als eigene Zeile und lässt sich ein- und ausschalten.',
        'Bestehende Daten und Sicherungen bleiben gültig. Der Speicher bekommt vier neue Tabellen (eigene Kostenarten, Zahlungsmittel, Kassen, Kassenbuchungen), sie sind in der Sicherung enthalten. Noch nicht dabei: Import und Export (Schritt 8b) und das Löschen von Arten (sie werden ausgeblendet).'
      ] },
      { version: '2.0.28', datum: '2026-11-04', punkte: [
        'Reiseorte: Orte haben jetzt eine Art (Stellplatz, Campingplatz, Hafen, Ankerplatz …), eine Position und eine Ausstattung (Strom, Wasser, Entsorgung, WLAN und mehr). Die gelernten Ortsnamen aus dem Logbuch lassen sich mit einem Tipp als Orte mit Position übernehmen.',
        'Frage nach der Ankunft: Nach Ankunft, Anlegen oder Anker werfen fragt das Cockpit, ob du den Ort festhalten willst. Die Frage ist immer freiwillig und sperrt nichts. Kennt die App den Ort an der Position, schlägt sie ihn vor. Mit „Nicht jetzt“ kommt die Frage nicht wieder.',
        'Besuch: Jeder festgehaltene Besuch bleibt gespeichert, mit Datum, Aktivität, Ausstattung und Kosten. Die Ausstattung gilt auch für den Ort, beim nächsten Mal siehst du sie schon. Ein Ort ohne Position bekommt die der Ankunft.',
        'Kosten unterwegs: Gibst du bei einem Besuch einen Betrag an, steht er als variabler Posten in der Kosten-Liste, verknüpft mit Aktivität und Ort. Es gibt keine zweite Buchführung. Am Ort siehst du, wie oft du dort warst und was du insgesamt und zuletzt bezahlt hast.',
        'Reiseplan: Eine Aktivität kann Start, Ziel und Zwischenziele als Orte haben. Bei der Ankunft zeigt die App, ob es dein geplantes Ziel war. Auf der Seite der Aktivität steht Plan gegen Ist und was die Reise gekostet hat, nach Art aufgegliedert.',
        'Später teilbar wären nur Name, Art, Position und Ausstattung eines Ortes. Deine Notizen, Kosten und Besuche bleiben nur bei dir. Veröffentlicht wird nichts, das kommt erst mit Konten und Server.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher bekommt eine neue Tabelle (Besuche), sie ist in der Sicherung enthalten. Noch nicht dabei: Route, Fahrzeit und Ankunftszeit (Schritt 9) und Import und Export (Schritt 8b). Das echte Aussehen am Tablet ist nicht geprüft.'
      ] },
      { version: '2.0.27', datum: '2026-11-04', punkte: [
        'Kosten: Unter „Funktionen“ gibt es jetzt „Kosten“, eine einzige Liste für alle deine Fahrzeuge. Jeder Betrag gehört zu einer von drei Gruppen: Fixkosten (immer gleich, zum Beispiel Liegeplatz oder Garage am Heimatort, Versicherung, HU, Gasprüfung, Feuerlöscher), variable Kosten (entstehen erst bei der Nutzung, zum Beispiel Treibstoff, Parkplätze und Häfen auf Reisen) und Instandhaltung (Wartung und Reparatur).',
        'Dazu kommt der Wertverlust als vierte Gruppe. Den trägst du nicht ein, die App rechnet ihn aus dem Wert des Fahrzeugs und einem Prozentsatz pro Jahr, den du in den Kostenstammdaten angibst. Ohne Angabe rechnet sie ohne Wertveränderung. Ist der Wert älter als ein Jahr, fragt sie, ob er noch stimmt.',
        'Beträge in der Werkstatt: Auf der Seite eines Vorgangs trägst du Teile, Arbeit oder die Rechnung der Werkstatt ein. Der Betrag steht nur in der Kosten-Liste und gehört zur Instandhaltung, es gibt keine zweite Buchführung. Auch an einer Aktivität (variable Kosten) und an einer Komponente kannst du Beträge eintragen.',
        'Wiederkehrende Kosten: Ein Fixbetrag kann einmalig sein oder jeden Monat, alle 3 oder 6 Monate, jedes Jahr oder alle 2 Jahre fällig werden, mit Beginn und freiwilligem Ende. Die App verteilt ihn auf die Monate, in denen er gilt. Auch geschätzte Beträge und Beträge in der Zukunft sind möglich.',
        'Auswertung pro Fahrzeug und Jahr: Gesamtkosten, davon bis heute und noch zu erwarten, pro Monat, pro Nutzungstag (genutzte Tage aus den Aktivitäten) und pro Kilometer (aus dem Kilometerstand). Bei jedem Wert steht, ob er eingegeben, geschätzt oder gerechnet ist. Über die Pfeile wechselst du das Jahr.',
        'Vergleich mit Mieten oder Chartern: Trägst du in den Kostenstammdaten ein, was ein gemietetes oder gechartertes Fahrzeug der gleichen Klasse pro Tag kostet, zeigt die App, wie deine Kosten bis heute dazu stehen und ab wie vielen Nutzungstagen im Jahr das eigene Fahrzeug günstiger ist. Das ist nur eine Rechnung mit deinen Angaben.',
        'Nichts wird gelöscht: Ein Posten lässt sich ändern oder ausblenden, der frühere Stand bleibt im Verlauf sichtbar. Ausgeblendete Posten rechnen nicht mit.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher bekommt zwei neue Tabellen (Kostenposten und Kostenstammdaten). Beides ist in der Sicherung enthalten. Noch nicht dabei: Import und Export (Schritt 8a), Kostenentwicklung über mehrere Jahre. Das echte Aussehen am Tablet ist nicht geprüft.'
      ] },
      { version: '2.0.26', datum: '2026-11-04', punkte: [
        'Dokumente und Bilder am Vorgang: Auf der Seite eines Vorgangs in der Werkstatt legst du Fotos vom Schaden, Rechnungen und Belege ab, als Datei oder als Link. Das geht auch bei einem erledigten Vorgang, denn die Rechnung kommt oft erst später.',
        'Neue Art von Dokument: Reparaturbuch. Bedienungsanleitung und Ersatzteilliste gab es schon an der Komponente. Die Gesamtliste aller Dokumente eines Fahrzeugs zeigt auch die Dokumente der Vorgänge („am Vorgang: …“), die Suche findet sie ebenfalls.',
        'Störung im Logbuch: Das Ereignis „Störung“ ist jetzt dieselbe Störung wie in der Werkstatt. Im Cockpit tippst du einmal auf „Störung“. Die Störung steht mit Uhrzeit und Position im Logbuch und zugleich als Vorgang in der Werkstatt. Die Warnung bei versprochenen Aktivitäten gilt damit auch unterwegs.',
        'Die Einschränkung ist vorbelegt mit „Fahrzeug bleibt nutzbar“, du änderst sie beim Vorgang in der Werkstatt. Die Störung hängt am Fahrzeug. Beim Nachtragen gilt dasselbe, der Vorgang bekommt dann das Datum des Ereignisses. Im Ereignis steht ein Link zum Vorgang, im Vorgang ein Link zum Ereignis.',
        'Eine ältere Störung im Logbuch bleibt, wie sie ist, sie wird nicht nachträglich zum Vorgang. Die Art eines bestehenden Ereignisses lässt sich nicht auf „Störung“ umstellen, weil sonst die Werkstatt ausgelassen würde.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher ist unverändert. Die Dokumente und Verweise sind in der Sicherung enthalten. Noch nicht dabei: Beträge und Kosten (Schritt 8).'
      ] },
      { version: '2.0.25', datum: '2026-11-04', punkte: [
        'Adressen: Unter „Stammdaten“ gibt es jetzt „Adressen“, eine einzige Liste für Werkstätten, Lieferanten und Händler. Sie gilt für alle deine Fahrzeuge. Du legst Name und Art fest, alles andere ist freiwillig: Ansprechpartner, Telefon, E-Mail, Anschrift, Webseite und Notiz.',
        'Die Werkstatt verweist darauf: Bei einer Arbeit („Wer macht die Arbeit?“) und beim Umwandeln einer Störung in eine Arbeit kannst du eine Adresse aus der Liste wählen. Auf der Seite des Vorgangs steht sie mit Link, auf der Seite der Adresse siehst du alle Vorgänge, die darauf verweisen.',
        'Nichts wird gelöscht: Eine Adresse lässt sich ändern oder ausblenden, der frühere Stand bleibt im Verlauf sichtbar. Eine ausgeblendete Adresse lässt sich nicht neu wählen, bleibt aber an den Vorgängen, an denen sie schon hängt.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher bekommt eine neue Tabelle für die Adressen. Die Adressen sind in der Sicherung enthalten. Noch nicht dabei: Dokumente und Bilder am Vorgang sowie die Kosten.'
      ] },
      { version: '2.0.24', datum: '2026-11-04', punkte: [
        'Werkstatt: Unter „Funktionen“ gibt es jetzt die Werkstatt. Dort meldest du Störungen und planst Arbeiten, am ganzen Fahrzeug oder an einer einzelnen Komponente. Auch auf der Seite des Fahrzeugs und der Komponente steht ein Block „Werkstatt“.',
        'Störung melden: Du sagst kurz, was los ist, und wie weit das Fahrzeug eingeschränkt ist: bleibt nutzbar, nur bedingt einsatzfähig oder nicht einsatzfähig.',
        'Aus der Störung eine Arbeit machen: Du legst fest, ob du die Arbeit selbst erledigst oder eine Werkstatt sie macht. Die Störung bleibt im Verlauf sichtbar. Ist alles gemacht, trägst du „Erledigt“ ein. Ein erledigter Vorgang lässt sich wieder öffnen, nichts wird gelöscht.',
        'Warnung bei versprochenen Aktivitäten: Ist das Fahrzeug nicht oder nur bedingt einsatzfähig, aber für die nächste Zeit eingeplant, warnt die App und fragt, ob es trotzdem genutzt werden kann oder abgesagt werden muss. „Trotzdem nutzen“ wird festgehalten und lässt sich zurücknehmen. „Absagen“ führt zum Stornieren der Aktivität. Die Entscheidung triffst immer du.',
        'Bestehende Daten und Sicherungen bleiben gültig. Die Vorgänge sind in der Sicherung enthalten. Noch nicht dabei: Adressen von Werkstätten und Lieferanten, Dokumente und Bilder am Vorgang sowie die Kosten. Sie folgen in den nächsten Stufen.'
      ] },
      { version: '2.0.23', datum: '2026-11-04', punkte: [
        'Status des Fahrzeugs: Jedes Fahrzeug hat jetzt immer einen Status, und was als Nächstes geht, hängt nur davon ab. Landfahrzeug: Stillstand oder In Fahrt (Abfahrt, Ankunft im Wechsel). Wasserfahrzeug: Festgemacht, In Fahrt oder Vor Anker (Ablegen, Anlegen, Anker werfen, Anker lichten). Am Steg geht nur Ablegen, vor Anker nur Anker lichten.',
        'Im Cockpit steht der Status in der Statuszeile, zum Beispiel „Status In Fahrt seit 09:00 Uhr (Abfahrt)“. Ein Knopf, der zum Status nicht passt, ist grau und nennt den Grund, zum Beispiel „erst Ablegen“. Notiz, Foto, Tanken und andere Ereignisse stören den Status nicht.',
        'Der Status gehört zum Fahrzeug, nicht zur Aktivität: Liegt das Boot nach einem Törn vor Anker, geht es im nächsten Törn mit Anker lichten weiter. Beim allerersten Mal ist der Knopf frei, der den Anfang macht (Abfahrt oder Ablegen).',
        'Vergessen? Trage das fehlende Ereignis mit der echten Uhrzeit nach. Das Nachtragen wird nie gesperrt, und der Status wird nach der Uhrzeit neu gerechnet, nicht nach der Reihenfolge des Eintippens.',
        'Die Regel hängt an der Art des Ereignisses, nicht am Namen: Auf der Seite „Arten von Ereignissen“ gibt es bei jeder Art den Abschnitt „Status des Fahrzeugs (freiwillig)“ mit „Möglich im Status“ und „Danach Status“. So gilt die Regel auch für eigene Arten. Für die sechs bekannten Namen gibt es eine Starthilfe, bei „Ändert den Status nicht“ wird die Art nie gesperrt.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Luftfahrzeuge haben keine Status und werden nie gesperrt. Das echte Aussehen der grauen Knöpfe am Tablet ist nicht geprüft.'
      ] },
      { version: '2.0.22', datum: '2026-11-04', punkte: [
        'Motorstopp-Frage: Tippst du Ankunft, Anlegen oder Anker werfen und ein Motor läuft noch, fragt das Cockpit oben „Fahrzeug am Ziel, Motor stoppen?“. Der Eintrag ist da schon gespeichert, die Frage sperrt nichts. Mit „Motor stoppen“ stoppt der Motor sofort (bei zwei Motoren je Motor ein Knopf), mit „Läuft weiter“ bleibt er an.',
        'Läuft der Motor nach der Frage weiter, schlägt die App nach der Wartezeit die Zeit der Ankunft als Stoppzeit vor, zum Beispiel „Stopp um 12:00 Uhr übernehmen“. Übernimmst du sie, rechnet die App die Betriebsstunden bis zu dieser Zeit und nicht bis jetzt. Die Stoppzeit lässt sich danach wie bisher noch korrigieren.',
        'Die Wartezeit stellst du selbst ein, auf der Seite „Motoren“ unter „Motorstopp-Frage“ (1 bis 1440 Minuten, Vorgabe 15). Sie gilt nur für dieses Gerät und ist nicht in der Sicherung.',
        'Ausgelöst wird die Frage immer von einem Ereignis am Ziel, nie von der Laufzeit des Motors: Bootsmotoren laufen auf langen Törns 24 bis 30 Stunden normal. Geht es nach der Ankunft mit Abfahrt, Ablegen oder Anker lichten weiter, fragt die App nichts. Wurde der Motor erst nach der Ankunft gestartet, auch nicht. Die Frage hängt an den Ereignissen im Logbuch: Auch eine nachgetragene oder ausgeblendete Ankunft wird berücksichtigt.',
        'Sagst du bei der Frage „Läuft weiter“, kommt sie für diese Ankunft nicht wieder. Der Vorschlag nach der Wartezeit kommt trotzdem noch einmal. Sagst du auch dort „Läuft weiter“, ist die Sache für diese Ankunft erledigt. Eine neue Ankunft fragt wieder.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Noch nicht dabei: Motor Start und Stopp als Ereignisse im Logbuch, Korrektur der Startzeit, Kilometer über GPS.'
      ] },
      { version: '2.0.21', datum: '2026-11-04', punkte: [
        'Position bei jedem Eintrag: Ein Ereignis im Logbuch kann jetzt eine Position tragen (Breite und Länge), dazu die Herkunft (vom GPS oder von Hand) und freiwillig einen Ortsnamen. Bei Tipps im Cockpit nimmt die App die GPS-Position dieses Geräts, wenn sie frisch ist (höchstens 2 Minuten alt). Sie wartet nie auf das GPS und fragt nie nach: Ohne GPS wird der Eintrag trotzdem sofort gespeichert, nur ohne Position.',
        'Im Cockpit steht in der Statuszeile die aktuelle Position, bei einem bekannten Ort mit dessen Namen. Beim ersten Mal fragt der Browser, ob dieses Gerät den Standort nutzen darf. Sagst du Nein, geht alles weiter, nur ohne Position.',
        'Von Hand: Im Formular „Ereignis eintragen“, „Nachtragen“ und „Angaben ändern“ gibt es den Abschnitt „Ort und Position“ mit Breite, Länge (Dezimalgrad, zum Beispiel 48,8566; Süd und West mit Minuszeichen oder S und W) und Ortsname. Beim Nachtragen gibt es keine GPS-Position, sie wird nur von Hand eingetragen. Änderst du eine GPS-Position, gilt sie danach als von Hand eingetragen. Die Handeingabe hat Vorrang.',
        'Die App lernt Ortsnamen: Gibst du zu einer Position einen Namen ein oder bestätigst ihn, merkt sich die App ihn für diese Gegend (Umkreis etwa 500 Meter, es kommt nicht auf den Meter an). Bei einer späteren Position im Umfeld schlägt sie den Namen vor, zum Beispiel „Schleuse Gamsheim“. Im Cockpit steht ein vorgeschlagener Name als „Vorschlag“ am Eintrag, gelernt wird er erst, wenn du ihn unter „Angaben ändern“ bestätigst.',
        'Am Ereignis steht außerdem, von welchem Gerät es kam (dieses Gerät oder ein anderes). Wer den Eintrag gemacht hat (Nutzer), folgt mit den Konten. Die gelernten Ortsnamen sind in der Sicherung, die Gerätekennung nicht.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Noch nicht dabei: die Frage „Motor stoppen?“ nach Ankunft (nächste Stufe), Kilometer über GPS, Karte, Route und Wetter am Wegpunkt (Schritt 9). Die gelernten Namen sind noch nicht mit den Orten und Standorten aus den Stammdaten verknüpft, weil diese noch keine Koordinaten haben.'
      ] },
      { version: '2.0.20', datum: '2026-11-04', punkte: [
        'Hinweis „Kein Motor läuft“: Jede Fahrzeugart legt fest, ob sie normalerweise einen Motor hat. Du kannst das je Art ändern (Stammdaten › Fahrzeugarten › Art), eine Untergruppe übernimmt es von der Obergruppe, bis du etwas Eigenes einstellst. Tippst du im Cockpit „Abfahrt“ oder „Ablegen“, ohne dass ein Motor läuft, speichert die App den Eintrag trotzdem sofort. Oben steht nur der Hinweis „Kein Motor läuft“. Es gibt keine Rückfrage und keine Sperre.',
        'Betriebsstunden und Kilometer stehen jetzt zusammen in der Statuszeile des Cockpits, jeweils mit der Quelle des Stands (Hand oder Schalter) und dem Datum. Auf der Seite „Motoren“ gibt es dazu eine Karte „Kilometer“. Die Kilometer trägst du von Hand ein. GPS kann später eine weitere Quelle sein und ist nie Voraussetzung. Ein Handeintrag hat wie bei den Betriebsstunden Vorrang.',
        'Knopfzahl je Gerät: Je Fahrzeugart lassen sich bis zu 15 Knöpfe belegen (bisher 8). Wie viele davon dieses Gerät zeigt, stellst du auf der Seite „Schnellknöpfe“ unter „Auf diesem Gerät“ ein. Bis du etwas einstellst, sind es 8, wie bisher. Die übrigen Knöpfe liegen unter „Sonstige Ereignisse“ und gehen nicht verloren. Die Einstellung gilt nur für das einzelne Gerät und ist nicht in der Sicherung.',
        'Die Spalten im Cockpit richten sich nach der Breite des Bildschirms: Handy 2, Tablet 3, großer Bildschirm 4 (ab 1400 Pixel Breite). Die Zeilen teilen sich weiter die Höhe, es wird nicht gescrollt.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Noch nicht dabei: die Frage „Motor stoppen?“ nach Ankunft, Anlegen oder Anker werfen (nächste Stufe), Kilometer über GPS.'
      ] },
      { version: '2.0.19', datum: '2026-11-04', punkte: [
        'Motorschalter im Cockpit: Jeder Motor hat seinen eigenen Schalter und seinen eigenen Zähler für die Betriebsstunden, einen Sammelschalter „alle“ gibt es nicht. Grau heißt Motor aus (Name und „Start“), rot heißt Motor läuft (Name und „Stopp“). Die Schalter stehen in einer Leiste unter den Knöpfen, oben in der Statuszeile steht, welcher Motor seit wann läuft.',
        'Die Motoren kommen aus den Komponenten: Jede Hauptkomponente der Art Motor bekommt einen Schalter, ein ausgebauter Motor nicht. Beim ersten Start legt die App den Zähler „Betriebsstunden“ am Motor an. Beim Stopp rechnet sie den letzten Stand plus die Laufzeit. Trägst du einen Stand von Hand ein, hat er Vorrang, ab ihm wird weitergerechnet. Ohne Startstand zählt der Zähler ab 0 und die App sagt es dir.',
        'Neues Feld „Kurzname“ bei den Komponenten (höchstens 8 Zeichen). Bei einem Motor macht die App aus der Bezeichnung einen Vorschlag, zum Beispiel wird aus „Motor Steuerbord“ MOSTB. Du siehst ihn im Feld und kannst ihn ändern. Einen selbst geänderten Kurznamen überschreibt die App nicht mehr. Zwei Motoren desselben Fahrzeugs dürfen nicht denselben Kurznamen haben.',
        'Ein oder zwei Motoren haben je einen festen Schalter. Ab drei Motoren steht in der Leiste ein einziger Schalter „Motoren“ mit der Anzeige, wie viele laufen. Ein Tipp darauf öffnet eine Liste mit allen Motoren, jeder mit eigenem Schalter, Zähler und den letzten Läufen. Die Ereignisknöpfe bleiben unverändert.',
        'Stoppen vergessen? Auf der Seite „Motoren“ gibt es bei dem letzten Lauf den Knopf „Stoppzeit korrigieren“. Du trägst ein, wann der Motor wirklich gestoppt wurde, der Stand wird neu gerechnet, und der alte Stand bleibt im Verlauf des Zählers sichtbar. Wurde der Zählerstand danach von Hand geändert, geht das nicht mehr, dann trägst du den richtigen Stand von Hand ein.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Die Läufe sind in der Sicherung enthalten. Noch nicht dabei: die Frage „Motor stoppen?“ nach Ankunft, Anlegen oder Anker werfen (kommt als nächste Stufe).'
      ] },
      { version: '2.0.18', datum: '2026-11-04', punkte: [
        'Das Cockpit füllt jetzt den ganzen Bildschirm: kein Menü, kein Scrollen, große Knöpfe in drei Spalten. Oben steht, wer gerade verantwortlich ist und welcher Tag heute ist, unten der letzte Eintrag und ein paar kleine Knöpfe (Tagesabschluss, Knöpfe ändern, Logbuch und Angaben). Läuft die Aktivität, öffnet sich das Cockpit von selbst.',
        'Schnellknöpfe frei belegbar: Im Cockpit stehen bis zu 8 Knöpfe, die du je Fahrzeugart selbst wählst, dazu fest „Sonstige Ereignisse“ (3 mal 3 Knöpfe). Ein Tipp auf ein Ereignis speichert es sofort mit der Uhrzeit von jetzt. Notiz, Foto und Verantwortung wechseln sind ebenfalls frei wählbar.',
        'Alles, was nicht auf einem Knopf liegt, findest du unter „Sonstige Ereignisse“, auch Notiz, Foto und Verantwortung wechseln, wenn du sie vom Knopf genommen hast.',
        'Eingestellt wird es unter Stammdaten › Fahrzeugarten › Art › „Schnellknöpfe im Cockpit“ oder im Cockpit mit „Knöpfe ändern“. Eine Untergruppe übernimmt die Knöpfe der Obergruppe, bis du etwas Eigenes einstellst. Das Wasserskiboot kann so andere Knöpfe haben als der Katamaran.',
        'Bis du etwas einstellst, gelten die bisherigen Knöpfe: Abfahrt, Ankunft, Notiz, Foto, Verantwortung wechseln. Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Die Einstellung ist in der Sicherung enthalten.'
      ] },
      { version: '2.0.17', datum: '2026-11-04', punkte: [
        'Die Art der Aktivität richtet sich nach dem Fahrzeug: Bei jeder Art von Aktivität legst du fest, für welche Fahrzeugarten sie gilt (Baum mit Häkchen, wie bei den Ereignissen). Mit dem Wohnmobil gibt es dann zum Beispiel kein Wasserski.',
        'Logbuch jetzt starten: Neues Feld „Aktivität“. Es zeigt nur Arten, die zum gewählten Fahrzeug passen, „Ausfahrt“ ist vorausgewählt, wenn sie passt. Der Name des Logbuchs folgt der gewählten Art, zum Beispiel „Törn Kat 04.11.2026“.',
        'Auch beim Planen und Ändern einer Aktivität stehen nur die Arten zur Wahl, die zum Fahrzeug passen. Eine Art, die schon an der Aktivität hängt, bleibt wählbar.',
        'Unter „Arten von Aktivitäten“ zeigt jede Art „Gilt für: …“. Der Knopf „Vorschläge für Fahrzeugarten übernehmen“ setzt eine Starthilfe (Wasserski nur für Wasserskiboote, Segeln nur für Segelboote, Törn für Wasserfahrzeuge, Rallye für Landfahrzeuge, Urlaub und Ausfahrt für alle), aber nur dort, wo du noch nichts eingestellt hast. Alles ist jederzeit änderbar.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Ältere Arten ohne Zuordnung gelten wie bisher für alle.'
      ] },
      { version: '2.0.16', datum: '2026-11-04', punkte: [
        'Fahrzeugarten selbst verwalten: Unter Stammdaten › Fahrzeugarten siehst du den ganzen Baum. Du kannst Untergruppen anlegen (zum Beispiel Trimaran unter Segelboot oder Aufsitzrasenmäher unter Landfahrzeug), Arten umbenennen und ausblenden.',
        'Eine neue Art übernimmt die Felder und die Ereignisse der Gruppe, unter der sie steht. Bei den Arten von Ereignissen kannst du das wie gewohnt ändern.',
        'Ausblenden geht immer. Eine ausgeblendete Art (und alles darunter) bieten neue Fahrzeuge nicht mehr an, bestehende Fahrzeuge bleiben unverändert.',
        'Löschen geht nur bei Arten, die kein Fahrzeug benutzt (auch keine Untergruppe davon). Was benutzt wird, lässt sich nur ausblenden.',
        'Ungebrauchtes löschen: ein Knopf räumt den Baum auf. Er löscht alles, was kein Fahrzeug benutzt, und zeigt vorher, was weggeht. Wer nur Oldtimer braucht, behält nur die Oldtimer. Gelöschte Vorschläge lassen sich zurückholen.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt. Eigene Arten sind in der Sicherung enthalten.'
      ] },
      { version: '2.0.15', datum: '2026-11-04', punkte: [
        'Logbuch ohne Planung: Auf der Seite „Aktivitäten“ und beim Fahrzeug gibt es den Knopf „Logbuch jetzt starten“. Du wählst Fahrzeug und wer verantwortlich ist (Stellvertreter und Crew sind freiwillig), der Beginn ist jetzt, und das Cockpit läuft sofort. Es entsteht eine ganz normale Aktivität der Art „Ausfahrt“, mit derselben Prüfung.',
        'Ereignisse gelten für Fahrzeugarten: Bei jeder Art von Ereignis legst du fest, für welche Fahrzeugarten sie gilt. Cockpit und Logbuch zeigen dann nur die Ereignisse, die zum Fahrzeug passen. Ein Häkchen an einer Gruppe gilt für alles darunter, einzelne Arten kannst du abwählen oder wieder ankreuzen.',
        'Fahrzeugarten als Baum: Wasserfahrzeug enthält jetzt Boot mit Sportboot, Wasserskiboot, Motorboot zum Übernachten, Motorschiff und Segelboot (Monohull, Katamaran, Jolle oder Kleinboot). Bestehende Fahrzeuge der Art „Boot“ bleiben gültig. Regeln für „Boot“ gelten auch für diese Untergruppen.',
        'Neue Vorschläge für Ereignisse mit Zuordnung (Tanken, Anlegen, Ablegen, Anker werfen, Anker lichten, Schleuse, Segel setzen, Segel bergen, Wasserski-Lauf) unter „Arten von Ereignissen“. Ältere Ereignisarten gelten wie bisher für alle.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt.'
      ] },
      { version: '2.0.14', datum: '2026-11-03', punkte: [
        'Bei der Aktivität gibt es jetzt zwei Reiter: „Cockpit“ zum schnellen Eintragen unterwegs und „Logbuch“ zum Nachlesen, Korrigieren und Nachtragen. Beide zeigen dieselben Einträge. Läuft die Aktivität gerade, öffnet sich das Cockpit zuerst, sonst das Logbuch.',
        'Cockpit mit großen Knöpfen: Ein Tipp auf Abfahrt oder Ankunft speichert sofort mit der Uhrzeit von jetzt, ohne Formular. Dazu Ereignis, Notiz und Foto. Das Cockpit zeigt den heutigen Tag, die letzten Einträge und wer gerade verantwortlich ist, seit wann. Der heutige Tag wird beim ersten Eintrag von selbst angelegt.',
        'Verantwortung wechseln im Cockpit: ein Tipp auf den Namen, Zeit jetzt. Die App prüft dabei die Befähigung der übernehmenden Person und hält das Ergebnis mit „geprüft am“ beim Wechsel fest. Sie weist nur hin und sperrt nichts. Ein vergessener Wechsel lässt sich mit der echten Uhrzeit nachtragen.',
        'Nachtrag wird erkannt: Weicht die Uhrzeit um mehr als 5 Minuten von jetzt ab, steht das Ereignis automatisch als „nachgetragen am …“ da. Der Knopf „Nachtragen“ bleibt.',
        'Klassisches Logbuch: alle Tage und Ereignisse der Reihe nach wie auf Papier, mit der festgehaltenen Prüfung zum Tagesbeginn beim Tag. Hier wird geändert, nachgetragen und ausgeblendet. Der Verlauf bleibt erhalten, nichts wird gelöscht.',
        'Tagesabschluss: tatsächliches Ziel und eine Notiz zum Tag. Der Zählerstand am Ende kommt später mit dem Schritt „Zähler automatisch“.',
        'Größere Knöpfe und klarere Gestaltung für Tablet und Smartphone.',
        'Bestehende Daten und Sicherungen bleiben gültig, der Speicher wurde nicht umgestellt.'
      ] },
      { version: '2.0.13', datum: '2026-11-03', punkte: [
        'Logbuch-Kern an der Aktivität: Ein Tagesabschnitt je Tag mit Datum, Beginn und Ende (Uhrzeit freiwillig), von wo nach wo (als Text) und Notiz.',
        'Die App bereitet die Tage aus dem Zeitraum der Aktivität auf Knopfdruck vor. Jeder Tag lässt sich ändern, von Hand ergänzen und ausblenden. Nichts wird gelöscht.',
        'Prüfung zum Tagesbeginn: Die Prüfung der Aktivität wird für den Tag festgehalten, mit „geprüft am“ und dem Verantwortlichen dieses Tages. Spätere Änderungen verändern das Festgehaltene nicht.',
        'Ereignisse in einem Tag: Zeitpunkt, Art, Text und ein Foto, alles außer Zeitpunkt und Art freiwillig. Die Arten sind eine offene Liste mit Vorschlägen (Abfahrt, Ankunft, Wechsel des Verantwortlichen, Störung, Notiz).',
        'Ein Wechsel des Verantwortlichen erscheint von selbst als Ereignis. Du kannst Zeitpunkt und Notiz korrigieren, der frühere Stand bleibt im Verlauf. Die Verantwortung der Aktivität folgt der Korrektur.',
        'Nachtragen: Ein Ereignis mit dem echten Zeitpunkt später eintragen. Es steht dann als „nachgetragen am …“ da.',
        'Bestehende Daten und Sicherungen bleiben gültig. Die Sicherung enthält Tage, Ereignisse, Prüfungen und Fotos.',
        'Noch nicht dabei: Wetter und Wegpunkte, Motor Start und Stopp, Störung als Werkstattvorgang, Orte als Start und Ziel, Kosten.'
      ] },
      { version: '2.0.12', datum: '2026-11-03', punkte: [
        'Komponenten haben eine Anzahl (zum Beispiel 6 Rettungswesten) und den Haken „Eignung geprüft“.',
        'Regeln für Pflichtausrüstung nennen jetzt eine Menge, die Bezugsgröße (je Fahrzeug oder je Person an Bord) und freiwillig die geforderte Eignung, zum Beispiel „Automatik, 150 N“.',
        'Die Prüfung bei der Aktivität vergleicht Soll und Ist und nennt die Zahlen, zum Beispiel „Eingetragen sind 5, Soll ist 6“. Bei „je Person“ zählt die Besatzung der Aktivität.',
        'Fehlt bei geforderter Eignung der Haken, sagt die Prüfung „unklar“. Die App prüft die Eignung nicht selbst.',
        'Bestehende Regeln und Komponenten bleiben gültig und ändern ihr Ergebnis nicht.'
      ] },
      { version: '2.0.11', datum: '2026-11-03', punkte: [
        'Orte: zusätzlich Adresse, Ansprechpartner und Telefon.',
        'Standorte: zusätzlich Länge, Breite, Tiefe und Höhe des Platzes.',
        'Regeln für Pflichtausrüstung: Zu einem Gebiet legst du fest, was am Fahrzeug sein muss, zum Beispiel Rettungsweste oder Feuerlöscher, wahlweise nur für bestimmte Fahrzeugarten.',
        'Die Prüfung bei der Aktivität zeigt die Pflichtausrüstung des Gebiets. Sie sucht in den eingetragenen Komponenten des Fahrzeugs. Ist etwas nicht eingetragen, sagt sie „unklar“ und nicht „fehlt“, weil sie nicht weiß, was wirklich an Bord liegt.',
        'Befähigung und Pflichtausrüstung sind zwei Arten von Regeln im selben Gebiet. Die Regeln sind weiter von dir eingetragen.'
      ] },
      { version: '2.0.10', datum: '2026-11-03', punkte: [
        'Orte und Standorte: Ein Ort (zum Beispiel ein Hafen) hat Standorte (zum Beispiel Liegeplatz 12). Alles gehört deinem eigenen Datenraum.',
        'Heimatstandort am Fahrzeug: Du wählst ihn aus deinen Standorten. Änderungen bleiben im Verlauf sichtbar.',
        'Gebiete mit Regeln: Eine Regel sagt „Wenn Gebiet, Fahrzeugart und Ausrüstung passen, genügt einer dieser Nachweise“. Die Regeln sind von dir eingetragen.',
        'Bei der Aktivität wählst du das Gebiet aus der Liste. Die Prüfung nutzt die Regeln des Gebiets zusätzlich zu den Anforderungen am Fahrzeug.',
        'Kennt die App für ein Gebiet und dein Fahrzeug keine Regel, sagt sie höchstens „unklar“ und nie „erlaubt“.',
        'Noch nicht dabei: Quelle und Prüfdatum je Regel, Reisecheck, weitere Länder.'
      ] },
      { version: '2.0.9', datum: '2026-11-03', punkte: [
        'Sicherungsdatei: ein Tipp erstellt eine Datei mit allen deinen Daten. Sie lässt sich speichern oder teilen, zum Beispiel in die Cloud.',
        'Wahlweise mit Schlüsselwort verschlüsselt. Darin stehen auch Ausweisdaten und Scans.',
        'Dokumente und Scans kannst du mitsichern oder weglassen. Vorher siehst du, wie groß es wird.',
        'Wiederherstellen: Die App zeigt zuerst, was in der Sicherung steht und was ersetzt wird. Erst nach deiner Bestätigung wird etwas verändert, und zwar ganz oder gar nicht.',
        'Die App erinnert an die Sicherung, nach 14, 30 oder 90 Tagen oder gar nicht.'
      ] },
      { version: '2.0.8', datum: '2026-11-03', punkte: [
        'Aktivitäten (Urlaub, Törn, Ausfahrt, Wasserski, Segeln, Rallye): Name, Art, Fahrzeug, Zeitraum mit freiwilliger Uhrzeit, Gebiet, geplante Strecke oder Betriebsstunden, Tiere und Notiz.',
        'Besatzung aus den Personen: Skipper oder Fahrer, Stellvertreter und Crew. Jede Person steht einmal da, bei Bedarf mit „dabei von bis“.',
        'Zu jedem Zeitpunkt ist genau eine Person verantwortlich. Jeder Wechsel wird mit Zeitpunkt festgehalten.',
        'Prüfung bei der Planung: Befähigung von Skipper oder Fahrer und Stellvertretern (erlaubt, nicht erlaubt, unklar, mit „geprüft am“), Fristen bis zum Ende des Zeitraums und Überschneidungen am Fahrzeug.',
        'Am Fahrzeug legst du fest, welche Nachweise ein Skipper oder Fahrer braucht.',
        'Aktivitäten lassen sich jederzeit stornieren und wiederherstellen. Nichts wird gelöscht.'
      ] },
      { version: '2.0.7', datum: '2026-11-03', punkte: [
        'Personen mit Funktionen (Skipper, Fahrer, Crew, Beifahrer, Gast) und Tiere mit Tierart und Chipnummer.',
        'Nachweise an Personen, Tieren und Fahrzeugen, mit „gültig bis“, Status und optionalem Scan oder Foto, das nur auf dem Gerät bleibt.',
        'Die Liste der Nachweisarten ist offen: Du legst eigene Arten an oder übernimmst Vorschläge für Deutschland und die EU. Jeder Vorschlag nennt seine Quelle und wie weit er geprüft ist.',
        'Vorschläge: Führerschein, Personalausweis, Reisepass, Sportbootführerschein, Funkzeugnisse, Heimtierausweis, Tollwutimpfung, Zulassungsbescheinigung Teil I und II, Hauptuntersuchung, Internationaler Bootsschein und mehr.',
        'Die Fahrzeugliste zeigt auch abgelaufene und bald ablaufende Nachweise.'
      ] },
      { version: '2.0.6', datum: '2026-11-03', punkte: [
        'Dokumente an Fahrzeug und Komponente: Bedienungsanleitung, Ersatzteilliste, Wartungsanleitung, Kaufbeleg, Garantie, Foto oder Sonstiges.',
        'Als Datei vom Gerät (auch ohne Internet da) oder als Link ins Internet.',
        'Am Fahrzeug gibt es eine Gesamtliste aller Dokumente, nach Komponente geordnet und mit Suche.',
        'In den Einstellungen siehst du, wie viel Speicher die Dokumente belegen und wie viel Platz der Browser erlaubt.'
      ] },
      { version: '2.0.5', datum: '2026-11-03', punkte: [
        'Fristen am Fahrzeug und an jeder Komponente: nach Zeit (Monate oder Jahre), nach Zähler (Strecke oder Betriebsstunden) oder nach beidem. Was zuerst eintritt, löst die Fälligkeit aus.',
        'Zähler am Fahrzeug oder pro Komponente, zum Beispiel pro Motor, mit Verlauf der Zählerstände.',
        'Jede Frist zeigt, ob sie in Ordnung, bald fällig oder überfällig ist. In der Fahrzeugliste siehst du es auf einen Blick.',
        'Wirkung bei Überfälligkeit (nur warnen, eingeschränkt, Sperre) und Vorwarnung sind einstellbar.',
        '„Erledigt eintragen“ setzt die Rechnung einer Frist neu an, frühere Erledigungen bleiben sichtbar.'
      ] },
      { version: '2.0.4', datum: '2026-11-03', punkte: [
        'Hauptkomponenten (Schale 3): Motor, Getriebe, Heizung, Klima, Stromversorgung, Wasserversorgung und Sonstiges.',
        'Darunter lässt sich beliebig tief aufschlüsseln, zum Beispiel Motor, Einspritzung, Pumpe.',
        'Zu jedem Teil: Hersteller, Modell, Seriennummer, Baujahr, Einbau, Ausbau und technische Merkmale.',
        'Änderungen bleiben wie beim Fahrzeug im Verlauf sichtbar.',
        'Wenn eine neue Version bereitsteht, erscheint ein Hinweis zum Neuladen.'
      ] },
      { version: '2.0.3', datum: '2026-11-03', punkte: [
        'Startseite neu gestaltet: Die Buchstaben V, T und D des Logos stehen vor den drei Teilen des Kernsatzes.',
        'Infotext: „Reisen planen“.',
        'Das Logo ist an einer einzigen Stelle abgelegt und gilt auf der Startseite, in der Kopfzeile und als App-Symbol.'
      ] },
      { version: '2.0.2', datum: '2026-11-03', punkte: [
        'Startseite mit Logo, Kernsatz und den Knöpfen „Programm starten“ und „Neu im Programm“.',
        'Hauptmenü mit Stammdaten, Funktionen und Einstellungen.',
        'Stammdaten mit den Fahrzeugen. Personen und Tiere folgen.',
        'Einstellungen mit Hinweisen zu deinen Daten.'
      ] },
      { version: '2.0.1', datum: '2026-11-03', punkte: [
        'Fahrzeugliste und äußere Hülle für sieben Fahrzeugarten.',
        'Eingaben von Hand, jede Änderung bleibt im Verlauf sichtbar.',
        'Funktioniert ohne Internet, die Daten liegen auf dem Gerät.'
      ] }
    ]
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
