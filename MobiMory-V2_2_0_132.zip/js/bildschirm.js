/*
 * Bildschirm bleibt an (seit 2.0.101): Solange das Cockpit aktiv ist, hält MobiMory den Bildschirm wach.
 * Grundlage ist die Bildschirm-Sperre des Browsers („Wake Lock“, navigator.wakeLock). Der Browser gibt sie von selbst frei, sobald die App
 * in den Hintergrund geht (anderer Tab, andere App, Bildschirm aus). Beim Zurückkommen setzt MobiMory sie neu.
 *
 * Wichtig für die Aufzeichnung: Kilometerzählung und GPS laufen nur bei offener App. Der wachgehaltene Bildschirm sorgt dafür, dass die App
 * dabei im Vordergrund bleibt. Eine Aufzeichnung im Hintergrund gibt es erst mit der Android-Hülle (Version 2.1).
 *
 * Nichts davon wirft einen Fehler: Kann der Browser es nicht oder lehnt er ab, läuft die App wie bisher, nur ohne wachen Bildschirm.
 * Hier steht nur die Verwaltung. Die Umgebung (navigator, document) wird übergeben, damit sie sich testen lässt.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* status: 'aus' (nicht gewünscht), 'wach' (Sperre gesetzt), 'wartet' (gewünscht, aber App gerade im Hintergrund oder Anfrage läuft),
     'abgelehnt' (der Browser hat die Sperre verweigert), 'nicht-moeglich' (der Browser kennt keine Bildschirm-Sperre) */
  function erzeugen(umgebung) {
    var nav = umgebung && umgebung.navigator, doc = umgebung && umgebung.document;
    var gewuenscht = false, sperre = null, anfrage = false, status = 'aus', lauscht = false, versuche = 0;

    function moeglich() { return !!(nav && nav.wakeLock && typeof nav.wakeLock.request === 'function'); }
    function sichtbar() { return !doc || doc.visibilityState === undefined || doc.visibilityState === 'visible'; }

    function setzen() {
      if (!gewuenscht || sperre || anfrage) return;
      if (!moeglich()) { status = 'nicht-moeglich'; return; }
      if (!sichtbar()) { status = 'wartet'; return; }
      anfrage = true; status = 'wartet'; versuche++;
      var eigene = versuche;
      var p;
      try { p = Promise.resolve(nav.wakeLock.request('screen')); } catch (e) { p = Promise.reject(e); }
      p.then(function (s) {
        anfrage = false;
        /* Wurde das Cockpit inzwischen verlassen, wird die gerade erhaltene Sperre sofort wieder abgegeben. */
        if (!gewuenscht || eigene !== versuche) {
          try { if (s && s.release) s.release(); } catch (e) { /* nichts zu tun */ }
          if (gewuenscht) setzen(); else status = 'aus';
          return;
        }
        sperre = s; status = 'wach';
        if (s && typeof s.addEventListener === 'function') {
          s.addEventListener('release', function () {
            if (sperre === s) { sperre = null; status = gewuenscht ? 'wartet' : 'aus'; }
          });
        }
      }, function () {
        anfrage = false; status = gewuenscht ? 'abgelehnt' : 'aus';
      });
    }

    function sichtbarkeit() {
      if (!gewuenscht) return;
      if (sichtbar()) setzen(); else if (!sperre) status = 'wartet';
    }

    function lauschen() {
      if (lauscht || !doc || typeof doc.addEventListener !== 'function') return;
      doc.addEventListener('visibilitychange', sichtbarkeit);
      lauscht = true;
    }

    return {
      moeglich: moeglich,
      /* Das Cockpit ist aktiv: Bildschirm wach halten. Mehrfach aufrufen ist harmlos. */
      an: function () { gewuenscht = true; lauschen(); setzen(); },
      /* Das Cockpit wird verlassen: Sperre freigeben. */
      aus: function () {
        gewuenscht = false; versuche++;
        var s = sperre; sperre = null; status = 'aus';
        if (s && typeof s.release === 'function') { try { var r = s.release(); if (r && typeof r.catch === 'function') r.catch(function () { /* nichts zu tun */ }); } catch (e) { /* nichts zu tun */ } }
      },
      status: function () { return status; },
      gewuenscht: function () { return gewuenscht; }
    };
  }

  /*
   * Vollbild (seit 2.0.131, „Person über Bord“): Browser- und Android-Leisten ausblenden, soweit das Gerät es zulässt.
   * Im Browser über die Vollbild-Funktion der Seite, in der Android-App über das Systemleisten-Plugin von Capacitor.
   * Kann das Gerät es nicht (iPhone) oder lehnt der Browser ab (Aufruf ohne Antippen), bleibt alles wie es ist, ohne Fehler.
   * Beendet wird nur ein Vollbild, das MobiMory selbst eingeschaltet hat.
   */
  function vollbildErzeugen(umgebung) {
    var doc = umgebung && umgebung.document, cap = umgebung && umgebung.Capacitor;
    var selbst = false, leisten = false, plug = null;
    function still(r) { if (r && typeof r.catch === 'function') r.catch(function () { /* nicht erlaubt */ }); }
    function systemleisten() {
      if (plug) return plug;
      try {
        if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return null;
        plug = (cap.Plugins && cap.Plugins.SystemBars) || (cap.registerPlugin ? cap.registerPlugin('SystemBars') : null);
      } catch (e) { plug = null; }
      return plug;
    }
    return {
      an: function () {
        var p = systemleisten();
        if (p) { try { still(p.hide()); leisten = true; } catch (e) { /* ohne */ } return; }
        var el = doc && doc.documentElement;
        if (!el || doc.fullscreenElement || doc.webkitFullscreenElement) return;
        var f = el.requestFullscreen || el.webkitRequestFullscreen;
        if (!f) return;
        try { selbst = true; still(f.call(el, { navigationUI: 'hide' })); } catch (e) { /* ohne Vollbild */ }
      },
      aus: function () {
        if (leisten) { leisten = false; try { still(systemleisten().show()); } catch (e) { /* nichts zu tun */ } }
        if (!selbst) return;
        selbst = false;
        if (!(doc.fullscreenElement || doc.webkitFullscreenElement)) return;
        var f = doc.exitFullscreen || doc.webkitExitFullscreen;
        try { if (f) still(f.call(doc)); } catch (e) { /* nichts zu tun */ }
      }
    };
  }

  MM.Bildschirm = erzeugen({ navigator: global.navigator, document: global.document });
  MM.Bildschirm.erzeugen = erzeugen;
  MM.Vollbild = vollbildErzeugen({ document: global.document, Capacitor: global.Capacitor });
  MM.Vollbild.erzeugen = vollbildErzeugen;
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
