/* Segeln (seit 2.0.129): Regeln für Segelmanöver. Nur Regeln und Rechnung, kein Speicher und kein Netz.
 * Festlegungen (25.11.2026): Ein Druck reicht, die App erkennt das Ende eines Kursmanövers selbst (erst deutliche Kursänderung, dann ruhiger Kurs bei
 * etwa gleicher Fahrt). Je Manöver Kurs und Fahrt vorher und nachher. Wind von Hand (Einheit einstellbar). Kein Pflichtknopf „Fertig“.
 * Das Kreuzen ist eine eigene spätere Stufe und steht hier nicht. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var DOKUMENT = 'segeln';
  var WIND_EINHEITEN = [{ wert: 'bft', label: 'Beaufort (Bft)' }, { wert: 'kn', label: 'Knoten (kn)' }, { wert: 'ms', label: 'Meter je Sekunde (m/s)' }, { wert: 'kmh', label: 'km/h' }];
  var WIND_KURZ = { bft: 'Bft', kn: 'kn', ms: 'm/s', kmh: 'km/h' };
  var HIMMEL = ['N', 'NNO', 'NO', 'ONO', 'O', 'OSO', 'SO', 'SSO', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
  var STANDARD = { windEinheit: 'bft', ruhigSek: 20, ruhigGrad: 10, treibKn: 1.5, driftProzent: 1.2, driftWinkel: 30 };
  var DREH_MIN = 15;            /* ab so vielen Grad gilt der Kurs als deutlich geändert */
  var STOPP_MS = 0.5;           /* „Fahrt fast null“ */
  var STOPP_SEK = 10;
  var LUECKE_MS = 10000;        /* größere Lücken im GPS unterbrechen die ruhige Phase */
  var ENDE_NACH_MS = 5 * 60 * 1000;
  var KN = 1.943844;

  /* Welche Wirkung wie endet. */
  var ENDE_ARTEN = { kursKurs: 'kurs', kursStopp: 'stopp', kursTreiben: 'treiben', kursSofort: 'sofort', kursHand: 'hand' };
  var SEGEL_WIRKUNGEN = { segelGesetzt: 'gesetzt', segelGeborgen: 'geborgen', segelGerefft: 'gerefft' };
  var FRAGEN_IDS = ['segel', 'reffstufe', 'wind', 'uebung', 'antrieb', 'logge', 'checkliste'];
  var WIRKUNG_IDS = Object.keys(ENDE_ARTEN).concat(Object.keys(SEGEL_WIRKUNGEN), ['bedingungen', 'mob', 'zwischenfall']);

  function zahlIn(w, min, max, std) { var n = Number(String(w === undefined || w === null ? '' : w).replace(',', '.')); return isFinite(n) && n >= min && n <= max ? n : std; }
  function einstellungen(dok) {
    var d = dok || {};
    return { windEinheit: WIND_KURZ[d.windEinheit] ? d.windEinheit : STANDARD.windEinheit, ruhigSek: zahlIn(d.ruhigSek, 5, 120, STANDARD.ruhigSek),
      ruhigGrad: zahlIn(d.ruhigGrad, 3, 45, STANDARD.ruhigGrad), treibKn: zahlIn(d.treibKn, 0.5, 5, STANDARD.treibKn),
      driftProzent: zahlIn(d.driftProzent, 0.1, 10, STANDARD.driftProzent), driftWinkel: zahlIn(d.driftWinkel, 5, 90, STANDARD.driftWinkel) };
  }

  /* Gehört die Zusammenstellung zu den Segelmanövern (dann hält die App auch Skipper und Rudergänger fest)? */
  function istManoever(z) {
    return !!z && (z.fragen.some(function (f) { return FRAGEN_IDS.indexOf(f) >= 0; }) || z.wirkungen.some(function (w) { return WIRKUNG_IDS.indexOf(w) >= 0; }));
  }
  /* Braucht es nach dem Antippen eine Seite? Nur bei Fragen oder bei Wirkungen, die nicht von selbst laufen. */
  function brauchtSeite(z) {
    return !!z && (z.fragen.length > 0 || z.wirkungen.some(function (w) { return WIRKUNG_IDS.indexOf(w) < 0; }));
  }
  function endeArt(z) {
    var w = (z && z.wirkungen || []).filter(function (x) { return ENDE_ARTEN[x]; })[0];
    return w ? ENDE_ARTEN[w] : (z && z.wirkungen.indexOf('mob') >= 0 ? 'hand' : null);
  }
  function segelWirkung(z) {
    var w = (z && z.wirkungen || []).filter(function (x) { return SEGEL_WIRKUNGEN[x]; })[0];
    return w ? SEGEL_WIRKUNGEN[w] : null;
  }

  /* ---------- Endeerkennung ---------- */
  function winkelAb(a, b) { var d = (b - a) % 360; if (d > 180) d -= 360; if (d < -180) d += 360; return d; }
  function grad360(g) { return ((Math.round(g) % 360) + 360) % 360; }
  function mittel(l) { return l.reduce(function (s, x) { return s + x; }, 0) / l.length; }

  /* art: 'kurs' | 'stopp' | 'treiben' | 'hand'. kursVor in Grad oder null, geschwVor in m/s oder null. */
  function laufNeu(art, startMs, kursVor, geschwVor) {
    return { art: art, startMs: startMs, kursVor: typeof kursVor === 'number' ? kursVor : null, geschwVor: typeof geschwVor === 'number' ? geschwVor : null,
      punkte: [], basis: typeof kursVor === 'number' ? kursVor : null, u: 0, letzterKurs: typeof kursVor === 'number' ? kursVor : null, ausschlag: 0 };
  }
  function ergebnis(z, status, endeMs, kursNach, geschwNach, drehwinkel) {
    return { status: status, kursNach: kursNach === null || kursNach === undefined ? null : grad360(kursNach), geschwNach: typeof geschwNach === 'number' ? Math.round(geschwNach * 100) / 100 : null,
      drehwinkel: typeof drehwinkel === 'number' ? Math.round(drehwinkel) : null, dauerS: Math.max(0, Math.round((endeMs - z.startMs) / 1000)) };
  }
  /* Ein neuer GPS-Punkt { zeitMs, kurs (oder null), geschwindigkeit (m/s oder null) }. Gibt das Ergebnis zurück, sobald das Ende erkannt ist, sonst null.
   * Der Zustand z wird fortgeschrieben. */
  function laufPunkt(z, fix, regel) {
    var r = regel || STANDARD;
    if (!z || z.art === 'hand' || !fix || typeof fix.zeitMs !== 'number' || fix.zeitMs < z.startMs) return null;
    var letzter = z.punkte[z.punkte.length - 1];
    if (letzter && fix.zeitMs <= letzter.t) return null;
    var v = typeof fix.geschwindigkeit === 'number' && isFinite(fix.geschwindigkeit) ? fix.geschwindigkeit : null;
    if (z.art === 'stopp' || z.art === 'treiben') {
      if (v === null) return null;
      z.punkte.push({ t: fix.zeitMs, v: v, k: typeof fix.kurs === 'number' ? fix.kurs : null });
      if (z.punkte.length > 400) z.punkte.shift();
      var grenze = z.art === 'stopp' ? STOPP_MS : r.treibKn / KN, noetig = (z.art === 'stopp' ? STOPP_SEK : r.ruhigSek) * 1000;
      var i = z.punkte.length - 1;
      if (z.punkte[i].v > grenze) return null;
      while (i > 0 && z.punkte[i - 1].v <= grenze && z.punkte[i].t - z.punkte[i - 1].t <= LUECKE_MS) i--;
      var teil = z.punkte.slice(i);
      if (teil.length < 3 || teil[teil.length - 1].t - teil[0].t < noetig) return null;
      return ergebnis(z, 'erkannt', teil[0].t, null, mittel(teil.map(function (p) { return p.v; })), null);
    }
    if (typeof fix.kurs !== 'number' || v === null || v < STOPP_MS) return null;
    if (z.basis === null) { z.basis = fix.kurs; z.letzterKurs = fix.kurs; }
    z.u += winkelAb(z.letzterKurs, fix.kurs); z.letzterKurs = fix.kurs;
    z.ausschlag = Math.max(z.ausschlag, Math.abs(z.u));
    z.punkte.push({ t: fix.zeitMs, v: v, u: z.u });
    if (z.punkte.length > 400) z.punkte.shift();
    var j = z.punkte.length - 1, uMin = z.u, uMax = z.u, vMin = v, vMax = v;
    while (j > 0) {
      var p = z.punkte[j - 1];
      if (z.punkte[j].t - p.t > LUECKE_MS) break;
      var nMin = Math.min(uMin, p.u), nMax = Math.max(uMax, p.u), mMin = Math.min(vMin, p.v), mMax = Math.max(vMax, p.v);
      if (nMax - nMin > r.ruhigGrad || mMax - mMin > Math.max(0.6, 0.25 * mMax)) break;
      uMin = nMin; uMax = nMax; vMin = mMin; vMax = mMax; j--;
    }
    var f = z.punkte.slice(j);
    if (f.length < 3 || f[f.length - 1].t - f[0].t < r.ruhigSek * 1000 || z.ausschlag < DREH_MIN) return null;
    /* Das Ende ist der Beginn der ruhigen Phase: den Auslauf der Drehung vorn abschneiden. */
    var mitte = mittel(f.slice(Math.floor(f.length / 2)).map(function (x) { return x.u; }));
    while (f.length > 3 && Math.abs(f[0].u - mitte) > r.ruhigGrad / 3) f.shift();
    var u = mittel(f.map(function (x) { return x.u; }));
    return ergebnis(z, 'erkannt', f[0].t, z.basis + u, mittel(f.map(function (x) { return x.v; })), z.kursVor === null ? null : u);
  }
  /* Nach einigen Minuten ohne Ende: „Ende nicht erkannt“. Von Hand beendete Manöver laufen weiter. */
  function laufZuLange(z, jetztMs) {
    return !!z && z.art !== 'hand' && jetztMs - z.startMs > ENDE_NACH_MS ? ergebnis(z, 'nicht erkannt', jetztMs, null, null, null) : null;
  }

  /* ---------- Texte ---------- */
  function zahlText(n, stellen) { return String(Math.round(n * Math.pow(10, stellen)) / Math.pow(10, stellen)).replace('.', ','); }
  function knText(ms) { return zahlText(ms * KN, 1) + ' kn'; }
  function kursText(g) { return ('00' + grad360(g)).slice(-3) + '°'; }
  function dauerText(s) { return s < 60 ? s + ' s' : Math.floor(s / 60) + ' min ' + (s % 60) + ' s'; }
  function windText(w) {
    var t = [];
    if (typeof w.windStaerke === 'number') t.push(zahlText(w.windStaerke, 1) + ' ' + (WIND_KURZ[w.windEinheit] || ''));
    if (w.windRichtung) t.push('aus ' + w.windRichtung);
    if (w.windArt) t.push(w.windArt);
    return t.length ? 'Wind (von Hand) ' + t.join(' ') : '';
  }
  /* Eine Zeile mit allem, was zum Manöver festgehalten ist. Fehlendes bleibt weg. */
  function zusammenfassung(w) {
    if (!w || !w.manoever) return '';
    var t = [];
    if (w.uebung === 'uebung') t.push('Übung'); else if (w.uebung === 'ernstfall') t.push('Ernstfall');
    if (w.zwischenfall) t.push('Zwischenfall');
    if (w.segelNamen) t.push('Segel: ' + w.segelNamen);
    if (w.reffstufe) t.push('Reffstufe: ' + w.reffstufe);
    if (w.antrieb) t.push('Antrieb: ' + (w.antrieb === 'segel' ? 'Segel' : 'Motor'));
    var vorher = typeof w.kursVor === 'number' ? kursText(w.kursVor) : null, nachher = typeof w.kursNach === 'number' ? kursText(w.kursNach) : null;
    if (vorher || nachher) t.push('Kurs ' + (vorher || '–') + (w.endeArt && w.endeArt !== 'sofort' ? ' → ' + (nachher || '–') : ''));
    if (typeof w.geschwVor === 'number' || typeof w.geschwNach === 'number') t.push('Fahrt ' + (typeof w.geschwVor === 'number' ? knText(w.geschwVor) : '–') + (w.endeArt && w.endeArt !== 'sofort' ? ' → ' + (typeof w.geschwNach === 'number' ? knText(w.geschwNach) : '–') : ''));
    if (typeof w.drehwinkel === 'number') t.push('Drehung ' + Math.abs(w.drehwinkel) + '° ' + (w.drehwinkel < 0 ? 'nach links' : 'nach rechts'));
    if (typeof w.dauerS === 'number' && w.endeStatus !== 'abgebrochen' && w.endeStatus !== 'nicht erkannt') t.push('Dauer ' + dauerText(w.dauerS));
    if (w.endeStatus === 'nicht erkannt') t.push('Ende nicht erkannt');
    if (w.endeStatus === 'abgebrochen') t.push('Messung abgebrochen');
    if (w.endeStatus === 'laeuft') t.push('läuft');
    var hand = windText(w); if (hand) t.push(hand);
    if (w.wetterText) t.push('Wetterdienst: ' + w.wetterText);
    if (w.logge) t.push('Logge ' + w.logge);
    if (w.sicht) t.push('Sicht ' + w.sicht);
    if (w.checklisteErledigt) t.push('Abgehakt: ' + w.checklisteErledigt);
    if (w.skipperName) t.push('Skipper: ' + w.skipperName);
    if (w.ruderName) t.push('Rudergänger: ' + w.ruderName);
    return t.join(' · ');
  }

  /* Bedingungen vom Wetterdienst: wetter und meer wie MM.Routen.wetterZurZeit und meerZurZeit, druck in hPa. Wind vom Dienst ist wahrer Wind. */
  function bedingungenText(wetter, meer, druck) {
    var t = [];
    if (wetter && typeof wetter.wind === 'number') t.push('Wind (wahr) ' + zahlText(wetter.wind, 0) + ' kn' + (typeof wetter.windRichtung === 'number' ? ' aus ' + himmel(wetter.windRichtung) : '') + (typeof wetter.boeen === 'number' ? ', Böen ' + zahlText(wetter.boeen, 0) + ' kn' : ''));
    if (wetter && wetter.himmel) t.push(wetter.himmel);
    if (meer && typeof meer.welle === 'number') t.push('Welle ' + zahlText(meer.welle, 1) + ' m');
    if (typeof druck === 'number') t.push('Luftdruck ' + Math.round(druck) + ' hPa');
    return t.join(', ');
  }
  function himmel(grad) { return HIMMEL[Math.round(grad360(grad) / 22.5) % 16]; }

  /* ---------- Reffstufen ---------- */
  /* Aus den Merkmalen eines Segels: „Reffstufen“ als Zahl (3) oder Liste (3/4, 1/2, 1/4 bzw. mit Komma getrennt), „Reffart“ als Text. */
  function reffstufen(merkmale) {
    function wert(name) {
      var m = (merkmale || []).filter(function (x) { return String(x.name || '').trim().toLowerCase() === name; })[0];
      return m ? String(m.wert).trim() : '';
    }
    var s = wert('reffstufen'), art = wert('reffart').toLowerCase();
    if (/^\d$/.test(s)) { var l = []; for (var i = 1; i <= Number(s); i++) l.push(i + '. Reff'); return l; }
    if (s) return s.split(/[,;]/).map(function (x) { return x.trim(); }).filter(Boolean);
    if (art.indexOf('roll') >= 0) return ['¾', '½', '¼'];
    return ['1. Reff', '2. Reff', '3. Reff'];
  }

  /* ---------- Zustand und Stunden je Segel ---------- */
  /* eintraege: [{ ms, wirkung: 'gesetzt' | 'geborgen' | 'gerefft', segelIds: [], reffstufe }]. Ergebnis je Kennung: { zustand, seitMs, reffstufe, stunden (abgeschlossen) }. */
  function segelStand(eintraege) {
    var st = {};
    (eintraege || []).slice().sort(function (a, b) { return a.ms - b.ms; }).forEach(function (e) {
      (e.segelIds || []).forEach(function (id) {
        var s = st[id] || (st[id] = { zustand: 'geborgen', seitMs: null, reffstufe: null, stunden: 0 });
        if (e.wirkung === 'geborgen') {
          if (s.seitMs !== null) s.stunden += (e.ms - s.seitMs) / 3600000;
          s.zustand = 'geborgen'; s.seitMs = null; s.reffstufe = null;
        } else {
          if (s.seitMs === null) s.seitMs = e.ms;
          s.zustand = e.wirkung; s.reffstufe = e.wirkung === 'gerefft' ? (e.reffstufe || null) : null;
        }
      });
    });
    Object.keys(st).forEach(function (k) { st[k].stunden = Math.round(st[k].stunden * 100) / 100; });
    return st;
  }
  function zustandText(s) { return !s || s.zustand === 'geborgen' ? 'geborgen' : (s.zustand === 'gerefft' ? 'gerefft' + (s.reffstufe ? ' (' + s.reffstufe + ')' : '') : 'gesetzt'); }

  /* ---------- Person über Bord: Richtung und Abstand zurück ---------- */
  function richtungGrad(vonB, vonL, nachB, nachL) {
    var rad = Math.PI / 180, dL = (nachL - vonL) * rad;
    var y = Math.sin(dL) * Math.cos(nachB * rad);
    var x = Math.cos(vonB * rad) * Math.sin(nachB * rad) - Math.sin(vonB * rad) * Math.cos(nachB * rad) * Math.cos(dL);
    return grad360(Math.atan2(y, x) / rad);
  }

  /* ---------- Mitgelieferte Manöver (jeder Nutzer kann sie ändern oder ausblenden) ---------- */
  var KURS = ['kursKurs', 'bedingungen'];
  var MOB_NAME = 'Person über Bord';
  var MANOEVER = [
    { name: 'Segel setzen', fragen: ['segel', 'wind'], wirkungen: ['kursSofort', 'bedingungen', 'segelGesetzt'] },
    { name: 'Segel bergen', fragen: ['segel', 'wind'], wirkungen: ['kursSofort', 'bedingungen', 'segelGeborgen'] },
    { name: 'Reffen', fragen: ['segel', 'reffstufe', 'wind'], wirkungen: ['kursSofort', 'bedingungen', 'segelGerefft'] },
    { name: 'Ausreffen', fragen: ['segel', 'reffstufe', 'wind'], wirkungen: ['kursSofort', 'bedingungen', 'segelGesetzt'] },
    { name: 'Gennaker/Spinnaker setzen', fragen: ['segel', 'wind'], wirkungen: ['kursSofort', 'bedingungen', 'segelGesetzt'] },
    { name: 'Gennaker/Spinnaker bergen', fragen: ['segel', 'wind'], wirkungen: ['kursSofort', 'bedingungen', 'segelGeborgen'] },
    { name: 'Gennaker halsen', fragen: ['segel'], wirkungen: KURS.concat(['segelGesetzt']) },
    { name: 'Anluven', fragen: [], wirkungen: KURS },
    { name: 'Abfallen', fragen: [], wirkungen: KURS },
    { name: 'Wende', fragen: [], wirkungen: KURS },
    { name: 'Halse', fragen: [], wirkungen: KURS },
    { name: 'Q-Wende', fragen: [], wirkungen: KURS },
    { name: 'Patenthalse', fragen: [], wirkungen: ['kursSofort', 'bedingungen', 'zwischenfall'] },
    { name: 'Beidrehen', fragen: [], wirkungen: ['kursTreiben', 'bedingungen'] },
    { name: 'Beidrehen aufheben', fragen: [], wirkungen: ['kursSofort', 'bedingungen'] },
    { name: 'Aufschießer', fragen: [], wirkungen: ['kursStopp', 'bedingungen'] },
    { name: 'Boje über Bord (Übung)', fragen: [], wirkungen: ['bedingungen', 'mob'] },
    { name: 'Kentern', fragen: [], wirkungen: ['kursSofort', 'bedingungen', 'zwischenfall'] },
    { name: 'Aufrichten', fragen: [], wirkungen: ['kursSofort', 'bedingungen', 'zwischenfall'] },
    { name: 'An die Boje', fragen: ['antrieb'], wirkungen: ['kursSofort', 'bedingungen'] },
    { name: 'Von der Boje', fragen: ['antrieb'], wirkungen: ['kursSofort', 'bedingungen'] }
  ];
  var MOB = { name: MOB_NAME, fragen: [], wirkungen: ['bedingungen', 'mob'] };

  MM.Segeln = {
    DOKUMENT: DOKUMENT, STANDARD: STANDARD, WIND_EINHEITEN: WIND_EINHEITEN, WIND_KURZ: WIND_KURZ, HIMMEL: HIMMEL, ENDE_NACH_MS: ENDE_NACH_MS,
    MANOEVER: MANOEVER, MOB: MOB, MOB_NAME: MOB_NAME,
    einstellungen: einstellungen, istManoever: istManoever, brauchtSeite: brauchtSeite, endeArt: endeArt, segelWirkung: segelWirkung,
    laufNeu: laufNeu, laufPunkt: laufPunkt, laufZuLange: laufZuLange, zusammenfassung: zusammenfassung, bedingungenText: bedingungenText,
    kursText: kursText, knText: knText, dauerText: dauerText, reffstufen: reffstufen, segelStand: segelStand, zustandText: zustandText, richtungGrad: richtungGrad
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
