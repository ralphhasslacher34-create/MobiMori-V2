/* Seemannschaft (seit 2.0.130): Regeln für Kreuzen, Fahrtarten, Steuerkurs und Versatz und den Suchbereich bei „Person über Bord“.
 * Nur Regeln und Rechnung, kein Speicher, kein Netz, keine Oberfläche. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var SM_M = 1852, KN = 1.943844, RAD = Math.PI / 180;

  function winkelAb(a, b) { var d = (b - a) % 360; if (d > 180) d -= 360; if (d < -180) d += 360; return d; }
  function grad360(g) { return ((Math.round(g) % 360) + 360) % 360; }
  function kursText(g) { return ('00' + grad360(g)).slice(-3) + '°'; }
  function zahlText(n, stellen) { return String(Math.round(n * Math.pow(10, stellen)) / Math.pow(10, stellen)).replace('.', ','); }
  /* Zahl aus Eingabe, null bei leer oder ungültig */
  function zahl(w) { var s = String(w === undefined || w === null ? '' : w).trim().replace(',', '.'); if (!s) return null; var n = Number(s); return isFinite(n) ? n : null; }
  function meter(b1, l1, b2, l2) {
    var dB = (b2 - b1) * RAD, dL = (l2 - l1) * RAD;
    var a = Math.sin(dB / 2) * Math.sin(dB / 2) + Math.cos(b1 * RAD) * Math.cos(b2 * RAD) * Math.sin(dL / 2) * Math.sin(dL / 2);
    return 2 * 6371000 * Math.asin(Math.min(1, Math.sqrt(a)));
  }
  function richtung(b1, l1, b2, l2) {
    var dL = (l2 - l1) * RAD;
    var y = Math.sin(dL) * Math.cos(b2 * RAD);
    var x = Math.cos(b1 * RAD) * Math.sin(b2 * RAD) - Math.sin(b1 * RAD) * Math.cos(b2 * RAD) * Math.cos(dL);
    return grad360(Math.atan2(y, x) / RAD);
  }

  /* ---------- Steuerkurs und Versatz ----------
   * Quellen: heute nur „hand“. „bordnetz“ (NMEA 2000) und „kompass“ (Tablet) sind vorbereitet und werden später gefüllt. */
  var KURS_QUELLEN = { hand: 'von Hand', bordnetz: 'Bordnetz', kompass: 'Tablet-Kompass' };
  var VERSATZ_MIN_M = 50;
  function quelleText(q) { return KURS_QUELLEN[q] || KURS_QUELLEN.hand; }
  /* Gradzahl 0 bis 360 aus der Eingabe, null bei leer, NaN bei ungültig */
  function gradEingabe(w) {
    var s = String(w === undefined || w === null ? '' : w).trim();
    if (!s) return null;
    var n = zahl(s.replace('°', ''));
    return n === null || n < 0 || n > 360 ? NaN : grad360(n);
  }
  /* Versatz über die ganze Strecke seit dem Setzen des Steuerkurses: Richtung vom Startpunkt zur jetzigen Position gegen den Steuerkurs.
   * Ergebnis: { versatz (Grad, negativ = Backbord), grund (Kurs über Grund), meter } oder null (noch zu kurz gefahren). */
  function versatz(steuer, start, jetzt) {
    if (typeof steuer !== 'number' || !start || !jetzt) return null;
    var m = meter(start.breite, start.laenge, jetzt.breite, jetzt.laenge);
    if (m < VERSATZ_MIN_M) return null;
    var g = richtung(start.breite, start.laenge, jetzt.breite, jetzt.laenge);
    return { versatz: Math.round(winkelAb(steuer, g)), grund: g, meter: Math.round(m) };
  }
  function versatzText(v) {
    if (v === null || v === undefined) return 'Versatz noch offen';
    return v === 0 ? 'kein Versatz' : 'Versatz ' + Math.abs(v) + '° nach ' + (v < 0 ? 'Backbord' : 'Steuerbord');
  }

  /* ---------- Kreuzen ----------
   * richtung 'auf' = gegen den Wind (Wende), 'vor' = vor dem Wind (Halse). art 'zeit' (Minuten) oder 'strecke' (Seemeilen). */
  var KREUZ_GRUND = 'Kreuzen';
  function manoeverName(p) { return p && p.richtung === 'vor' ? 'Halse' : 'Wende'; }
  function kreuzPlan(roh) {
    roh = roh || {};
    var f = {}, richtungW = roh.richtung === 'vor' ? 'vor' : (roh.richtung === 'auf' ? 'auf' : null), art = roh.art === 'strecke' ? 'strecke' : 'zeit', wert = zahl(roh.wert);
    if (!richtungW) f.richtung = 'Bitte wählen: gegen den Wind oder vor dem Wind.';
    if (wert === null || (art === 'zeit' ? wert < 0.5 || wert > 720 : wert < 0.05 || wert > 100)) f.wert = art === 'zeit' ? 'Bitte die Minuten eingeben (0,5 bis 720).' : 'Bitte die Seemeilen eingeben (0,05 bis 100).';
    var k1 = gradEingabe(roh.kurs1), k2 = gradEingabe(roh.kurs2);
    if (k1 !== null && isNaN(k1)) f.kurs1 = 'Kurs bitte 0 bis 360.';
    if (k2 !== null && isNaN(k2)) f.kurs2 = 'Kurs bitte 0 bis 360.';
    if (Object.keys(f).length) return { ok: false, fehler: f };
    return { ok: true, plan: { richtung: richtungW, wiederholt: roh.wiederholt === true || roh.wiederholt === 'ja', art: art, wert: wert, kurs1: k1, kurs2: k2 } };
  }
  function kreuzPlanText(p) {
    var t = (p.richtung === 'vor' ? 'vor dem Wind, ' : 'gegen den Wind, ') + manoeverName(p) + ' ' + (p.wiederholt ? 'wiederkehrend alle ' : 'einmalig nach ') +
      zahlText(p.wert, 2) + (p.art === 'zeit' ? ' min' : ' sm');
    if (p.kurs1 !== null || p.kurs2 !== null) t += ', Kurse ' + (p.kurs1 !== null ? kursText(p.kurs1) : '–') + ' / ' + (p.kurs2 !== null ? kursText(p.kurs2) : '–');
    return t;
  }
  /* Neu zählen ab jetzt (Beginn, Wende gefahren oder erkannt) */
  function kreuzNeuZaehlen(z, jetztMs, sm) { z.seitMs = jetztMs; z.sm = sm || 0; return z; }
  function kreuzStart(plan, jetztMs) { return Object.assign({}, plan, { aktiv: true, seitMs: jetztMs, sm: 0, schlag: 1, refKurs: null }); }
  /* Wie lange noch? { faellig, rest (Sekunden oder sm), text } */
  function kreuzRest(z, jetztMs) {
    if (!z || !z.aktiv) return null;
    var name = manoeverName(z), rest = z.art === 'zeit' ? Math.round(z.wert * 60 - (jetztMs - z.seitMs) / 1000) : z.wert - z.sm;
    if (rest <= 0.0001) return { faellig: true, rest: 0, text: 'Jetzt ' + name };
    var t = z.art === 'zeit' ? (rest >= 60 ? Math.floor(rest / 60) + ' min ' + (rest % 60) + ' s' : rest + ' s') : zahlText(rest, 2) + ' sm';
    return { faellig: false, rest: rest, text: name + ' in ' + t };
  }
  /* Der Kurs des nächsten Schlags, wenn Kurse angegeben sind */
  function kreuzNaechsterKurs(z) {
    if (!z) return null;
    var k = z.schlag % 2 === 1 ? z.kurs2 : z.kurs1;
    return typeof k === 'number' ? k : null;
  }
  /* Ab so vielen Grad gilt ein neuer, ruhiger Kurs als gefahrene Wende oder Halse. Mit beiden Kursen: die Hälfte ihres Unterschieds. */
  function kreuzSchwelle(z) {
    if (typeof z.kurs1 === 'number' && typeof z.kurs2 === 'number') { var d = Math.abs(winkelAb(z.kurs1, z.kurs2)); if (d >= 20) return Math.max(20, d / 2); }
    return z.richtung === 'vor' ? 30 : 50;
  }
  /* Merker im Speicher (nicht gesichert): { punkte: [], letzter } */
  function kreuzMerker() { return { punkte: [], letzter: null }; }
  /* Ein GPS-Punkt { zeitMs, breite, laenge, kurs, geschwindigkeit }. Schreibt z und m fort. Antwort: 'gedreht', wenn Wende/Halse erkannt wurde, sonst null.
   * regel: { ruhigSek, ruhigGrad } wie bei den Segelmanövern. */
  function kreuzPunkt(z, m, fix, regel) {
    if (!z || !z.aktiv || !fix || typeof fix.zeitMs !== 'number') return null;
    var l = m.letzter;
    if (l && fix.zeitMs <= l.zeitMs) return null;
    var faehrt = typeof fix.geschwindigkeit === 'number' && fix.geschwindigkeit >= 0.5;
    var weg = l && faehrt && fix.zeitMs - l.zeitMs <= 600000 && typeof fix.breite === 'number' ? meter(l.breite, l.laenge, fix.breite, fix.laenge) / SM_M : 0;
    m.letzter = fix;
    z.sm += weg;
    if (!faehrt || typeof fix.kurs !== 'number') return null;
    var p = m.punkte, vor = p[p.length - 1];
    if (vor && fix.zeitMs - vor.t > 10000) p.length = 0;
    var u = vor && p.length ? vor.u + winkelAb(vor.k, fix.kurs) : fix.kurs;
    p.push({ t: fix.zeitMs, k: fix.kurs, u: u, sm: z.sm });
    if (p.length > 400) p.shift();
    var r = regel || { ruhigSek: 20, ruhigGrad: 10 };
    var j = p.length - 1, min = u, max = u;
    while (j > 0) {
      var q = p[j - 1], a = Math.min(min, q.u), b = Math.max(max, q.u);
      if (b - a > r.ruhigGrad) break;
      min = a; max = b; j--;
    }
    var f = p.slice(j);
    if (f.length < 3 || f[f.length - 1].t - f[0].t < r.ruhigSek * 1000) return null;
    var mitte = grad360(f.reduce(function (s, x) { return s + x.u; }, 0) / f.length);
    if (typeof z.refKurs !== 'number') { z.refKurs = mitte; return null; }
    var d = winkelAb(z.refKurs, mitte);
    if (Math.abs(d) < kreuzSchwelle(z)) { z.refKurs = grad360(z.refKurs + d * 0.05); return null; }
    z.refKurs = mitte; z.schlag += 1;
    kreuzNeuZaehlen(z, f[0].t, z.sm - f[0].sm);
    return 'gedreht';
  }

  /* ---------- Fahrtarten: Segeln, Motorfahrt, Motorsegeln ---------- */
  var FAHRTARTEN = { segeln: 'Segeln', motor: 'Motorfahrt', motorsegeln: 'Motorsegeln' };
  /* o: { motorlaeufe: [{ von, bis|null }], segel: [{ ms, wirkung, ids: [], name }], fahrt: [{ ms, unterwegs }], endeMs, aenderungen: [{ von, bis, art }] }
   * Ergebnis: [{ von, bis, art, geaendert }] nach Zeit. Ohne Antrieb oder festgemacht/vor Anker entsteht kein Abschnitt. */
  function fahrtAbschnitte(o) {
    var ende = o.endeMs, marken = [];
    (o.motorlaeufe || []).forEach(function (l) { marken.push(l.von, l.bis === null || l.bis === undefined ? ende : l.bis); });
    (o.segel || []).forEach(function (e) { marken.push(e.ms); });
    (o.fahrt || []).forEach(function (e) { marken.push(e.ms); });
    (o.aenderungen || []).forEach(function (a) { marken.push(a.von, a.bis); });
    marken.push(ende);
    marken = marken.filter(function (x) { return x <= ende; }).sort(function (a, b) { return a - b; }).filter(function (x, i, l) { return i === 0 || x !== l[i - 1]; });
    var segel = (o.segel || []).slice().sort(function (a, b) { return a.ms - b.ms; }), fahrt = (o.fahrt || []).slice().sort(function (a, b) { return a.ms - b.ms; });
    var oben = {}, si = 0, fi = 0, unterwegs = true, aus = [];
    for (var i = 0; i + 1 < marken.length; i++) {
      var von = marken[i], bis = marken[i + 1];
      while (si < segel.length && segel[si].ms <= von) {
        var e = segel[si++], gennaker = /gennaker|spinnaker/i.test(e.name || '');
        var ids = e.ids && e.ids.length ? e.ids : [gennaker ? 'gennaker' : 'segel'];
        if (e.wirkung === 'geborgen') {
          if ((e.ids && e.ids.length) || gennaker) ids.forEach(function (id) { delete oben[id]; });
          else oben = {};
          if (e.ids && e.ids.length) { delete oben.segel; if (gennaker) delete oben.gennaker; }
        } else ids.forEach(function (id) { oben[id] = true; });
      }
      while (fi < fahrt.length && fahrt[fi].ms <= von) unterwegs = fahrt[fi++].unterwegs;
      var m = (o.motorlaeufe || []).some(function (l) { return l.von <= von && (l.bis === null || l.bis === undefined || l.bis >= bis); });
      var s = Object.keys(oben).length > 0;
      var art = unterwegs && (m || s) ? (m && s ? 'motorsegeln' : (s ? 'segeln' : 'motor')) : null, geaendert = false;
      (o.aenderungen || []).forEach(function (a) { if (von >= a.von && von < a.bis) { art = FAHRTARTEN[a.art] ? a.art : null; geaendert = true; } });
      if (!art) continue;
      var letzter = aus[aus.length - 1];
      if (letzter && letzter.bis === von && letzter.art === art && letzter.geaendert === geaendert) letzter.bis = bis;
      else aus.push({ von: von, bis: bis, art: art, geaendert: geaendert });
    }
    return aus.filter(function (a) { return a.bis - a.von >= 60000; });
  }
  /* Strecke in Seemeilen aus dem aufgezeichneten Weg [[breite, laenge, Sekunden]] je Abschnitt */
  function wegSm(punkte, von, bis) {
    var m = 0, vor = null;
    (punkte || []).forEach(function (p) {
      var t = p[2] * 1000;
      if (t < von || t > bis) return;
      if (vor && p[2] - vor[2] <= 600) m += meter(vor[0], vor[1], p[0], p[1]);
      vor = p;
    });
    return Math.round(m / SM_M * 100) / 100;
  }
  /* Summen je Fahrtart und Stunden unter Motor und unter Segel (Motorsegeln zählt bei beiden) */
  function fahrtSummen(abschnitte) {
    var s = { segeln: { ms: 0, sm: 0 }, motor: { ms: 0, sm: 0 }, motorsegeln: { ms: 0, sm: 0 } };
    (abschnitte || []).forEach(function (a) { s[a.art].ms += a.bis - a.von; s[a.art].sm += a.sm || 0; });
    Object.keys(s).forEach(function (k) { s[k].sm = Math.round(s[k].sm * 100) / 100; });
    s.motorStunden = Math.round((s.motor.ms + s.motorsegeln.ms) / 36000) / 100;
    s.segelStunden = Math.round((s.segeln.ms + s.motorsegeln.ms) / 36000) / 100;
    return s;
  }

  /* ---------- Person über Bord: Suchbereich (Schätzung) ----------
   * Drift = Winddrift (Anteil der Windgeschwindigkeit, mit dem Wind) + Strömung (Richtung, wohin sie setzt). Die Außenlinien drehen nur die Winddrift. */
  var MOB_STANDARD = { driftProzent: 1.2, driftWinkel: 30 };
  var MOB_ANNAHME_KN = 0.5, MOB_KREIS_MIN_M = 50;
  function windKn(staerke, einheit) {
    if (typeof staerke !== 'number' || !isFinite(staerke) || staerke < 0) return null;
    if (einheit === 'kn') return staerke;
    if (einheit === 'ms') return staerke * KN;
    if (einheit === 'kmh') return staerke / 1.852;
    return 0.836 * Math.pow(staerke, 1.5) * KN; /* Beaufort */
  }
  function ziel(b, l, grad, m) {
    return { breite: b + m * Math.cos(grad * RAD) / 111195, laenge: l + m * Math.sin(grad * RAD) / (111195 * Math.max(0.05, Math.cos(b * RAD))) };
  }
  function summe(a, b) {
    var n = a.kn * Math.cos(a.grad * RAD) + b.kn * Math.cos(b.grad * RAD), o = a.kn * Math.sin(a.grad * RAD) + b.kn * Math.sin(b.grad * RAD);
    return { kn: Math.sqrt(n * n + o * o), grad: (Math.atan2(o, n) / RAD + 360) % 360 };
  }
  /* o: { breite, laenge, seitMs, jetztMs, windKn, windAus (Grad), stromGrad, stromKn, driftProzent, driftWinkel }
   * Ergebnis: { art: 'faecher', punkt, links, mitte, rechts, richtung, meter } oder { art: 'kreis', mittel, radius, angenommen } */
  function suchbereich(o) {
    var std = Math.max(0, o.jetztMs - o.seitMs) / 3600000;
    var anteil = (typeof o.driftProzent === 'number' ? o.driftProzent : MOB_STANDARD.driftProzent) / 100;
    var winkel = typeof o.driftWinkel === 'number' ? o.driftWinkel : MOB_STANDARD.driftWinkel;
    var strom = typeof o.stromGrad === 'number' && typeof o.stromKn === 'number' && o.stromKn > 0 ? { grad: o.stromGrad, kn: o.stromKn } : { grad: 0, kn: 0 };
    var lee = typeof o.windKn === 'number' ? o.windKn * anteil : null;
    var punkt = { breite: o.breite, laenge: o.laenge };
    if (lee !== null && lee > 0 && typeof o.windAus === 'number') {
      var mit = (o.windAus + 180) % 360;
      var ende = function (d) { var v = summe({ grad: (mit + d + 360) % 360, kn: lee }, strom); return Object.assign(ziel(o.breite, o.laenge, v.grad, v.kn * std * SM_M), { grad: v.grad, meter: v.kn * std * SM_M }); };
      var m = ende(0);
      return { art: 'faecher', punkt: punkt, links: ende(-winkel), mitte: m, rechts: ende(winkel), richtung: grad360(m.grad), meter: Math.round(m.meter) };
    }
    var angenommen = lee === null;
    var mittel = strom.kn ? ziel(o.breite, o.laenge, strom.grad, strom.kn * std * SM_M) : punkt;
    return { art: 'kreis', mittel: { breite: mittel.breite, laenge: mittel.laenge }, radius: Math.round(Math.max(MOB_KREIS_MIN_M, (angenommen ? MOB_ANNAHME_KN : lee) * std * SM_M)), angenommen: angenommen };
  }

  MM.Seemann = {
    KURS_QUELLEN: KURS_QUELLEN, quelleText: quelleText, gradEingabe: gradEingabe, versatz: versatz, versatzText: versatzText, kursText: kursText, zahl: zahl,
    KREUZ_GRUND: KREUZ_GRUND, manoeverName: manoeverName, kreuzPlan: kreuzPlan, kreuzPlanText: kreuzPlanText, kreuzStart: kreuzStart, kreuzNeuZaehlen: kreuzNeuZaehlen, kreuzRest: kreuzRest,
    kreuzNaechsterKurs: kreuzNaechsterKurs, kreuzSchwelle: kreuzSchwelle, kreuzMerker: kreuzMerker, kreuzPunkt: kreuzPunkt,
    FAHRTARTEN: FAHRTARTEN, fahrtAbschnitte: fahrtAbschnitte, wegSm: wegSm, fahrtSummen: fahrtSummen,
    MOB_STANDARD: MOB_STANDARD, MOB_ANNAHME_KN: MOB_ANNAHME_KN, windKn: windKn, suchbereich: suchbereich, meter: meter, richtung: richtung
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
