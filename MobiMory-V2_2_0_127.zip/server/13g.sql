CREATE TABLE IF NOT EXISTS lese_nutzung (id TEXT PRIMARY KEY, datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, stufe TEXT NOT NULL, am INTEGER NOT NULL, status TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS lese_nutzung_raum ON lese_nutzung(datenraum_id, am);
