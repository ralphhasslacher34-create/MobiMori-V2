CREATE TABLE IF NOT EXISTS route_nutzung (id TEXT PRIMARY KEY, datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, stufe TEXT NOT NULL, am INTEGER NOT NULL, status TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS route_nutzung_raum ON route_nutzung(datenraum_id, am);
CREATE TABLE IF NOT EXISTS route_extra (nutzer_id TEXT PRIMARY KEY REFERENCES nutzer(id) ON DELETE CASCADE, anzahl INTEGER NOT NULL);
