CREATE TABLE IF NOT EXISTS gutschein (code TEXT PRIMARY KEY, prozent REAL NOT NULL, stufe TEXT, monate INTEGER, grenze INTEGER NOT NULL, eingeloest INTEGER NOT NULL DEFAULT 0, laeuft_ab INTEGER NOT NULL, erstellt_am INTEGER NOT NULL, erstellt_von TEXT NOT NULL, notiz TEXT);
CREATE TABLE IF NOT EXISTS gutschein_einloesung (code TEXT NOT NULL, nutzer_id TEXT NOT NULL, am INTEGER NOT NULL, art TEXT NOT NULL, referenz TEXT, PRIMARY KEY (code, nutzer_id));
ALTER TABLE bestellung ADD COLUMN gutschein TEXT;
ALTER TABLE bestellung ADD COLUMN liste_cent INTEGER;
ALTER TABLE beleg ADD COLUMN gutschein TEXT;
ALTER TABLE beleg ADD COLUMN liste_cent INTEGER;
