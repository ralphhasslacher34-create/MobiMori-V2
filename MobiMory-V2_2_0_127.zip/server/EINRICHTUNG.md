# Konto-Dienst: Einrichtung und Updates (Stand 2.0.127, Schritt 13h)

## Was gerade läuft

| | Echter Dienst | Test-Dienst |
|---|---|---|
| Worker | `mobimory-konto` unter **konto.mobimory.com** | `winter-violet-1a11` |
| Datenbank (D1, EU) | `mobimory-konten` | `mobimory-konten-test` (andere ID, nicht verwechseln) |
| Dateispeicher (R2, EU) | `mobimory-daten` | `mobimory-daten-test` |
| Einstellungen | `wrangler-konto.jsonc` (mit Cron-Auslöser) | `wrangler.jsonc` |
| Tarif | Workers Paid, Email Sending für mobimory.com (3 000 Mails im Monat enthalten) | – |
| Variablen | `ABSENDER` = konto@mobimory.com, `ERLAUBTE_URSPRUENGE` = https://app.mobimory.com | `ENTWICKLUNG` = 1 |
| Geheimnis | `PASSWORT_PEPPER` (nie ändern, anderer Wert als beim Test-Dienst) | eigener Wert |
| Bindungen | `DB`, `DATEN`, `EMAIL` | `DB`, `DATEN` |

- Deploy-Befehl des echten Dienstes: `npx wrangler deploy --config wrangler-konto.jsonc` (Zweig `main`, Root `/`, Build command leer).
- **Die Variable `ENTWICKLUNG` gibt es im echten Dienst nie.**
- Die App läuft unter **app.mobimory.com**. Der Workflow `veroeffentlichen.yml` macht nur noch Tests.
- Beide Dienste bauen aus derselben Datei `konto-dienst.mjs` im Hauptverzeichnis des Repositorys. Wird sie ersetzt, aktualisieren sich beide.

## Update einspielen (immer so)

1. **Neue SQL-Zeilen** (falls die Version welche hat): D1 → Datenbank → **Console**, **jede Zeile einzeln**. Die Zeilen stehen in einer eigenen Datei in `server/` (`13c.sql`, `13d.sql`, `13e.sql`, `13e-3.sql`, `13e-4.sql`, `13e-5.sql`).
2. **Dateien ins Hauptverzeichnis des Repositorys** (bei GitHub immer **Upload files**, „Create new file“ legt nur leere Dateien an): `konto-dienst.mjs` und, falls geändert, `wrangler-konto.jsonc`. **Zuerst die alte Datei löschen, dann die neue hochladen** und den Dateinamen prüfen (kein Leerzeichen). Sonst baut Cloudflare weiter aus der alten Datei.
3. Cloudflare baut nach ein bis zwei Minuten selbst (Worker → **Deployments**).
4. **Prüfen:** `konto.mobimory.com/gesundheit` aufrufen. Die Version muss stimmen, alles muss `true` sein, `entwicklung` muss `false` sein.

## Update 2.0.123: bis zu 25 Zwischenziele (Dienst bleibt 13h)

`konto-dienst.mjs` neu hochladen (Schritt 2 bis 4 wie oben, keine SQL-Zeile). Neu im Dienst: Eine Routenplanung darf bis zu 25 Zwischenziele haben (vorher 5). Welche Zahl für die einzelne Aktivität gilt (so viele wie Tage, höchstens 25) und dass ein Tag bis zu 10 hat, prüft die App. Die App 2.0.123 funktioniert mit dem alten Dienst nur bis 5 Zwischenziele: Bei mehr antwortet der alte Dienst mit „höchstens 5 Zwischenziele“ (Fehler 400) und zählt die Route nicht.

## Update 2.0.122: Push-Diagnose (Dienst bleibt 13h)

`konto-dienst.mjs` neu hochladen (Schritt 2 bis 4 wie oben, keine SQL-Zeile). Die App 2.0.122 funktioniert auch mit dem alten Dienst, zeigt dann aber bei Fehlern keinen Grund, und die Test-Nachricht würde den echten Alarmtext senden und eine E-Mail auslösen. Neu im Dienst: Die Antwort auf einen Alarm nennt die Zahl der Ziele und den Grund je Fehler (zum Beispiel „fcm 403“); „test“ sendet den Text „Das ist eine Test-Nachricht“ ohne E-Mail.

## Update 2.0.120: Alarm-Nachrichten (Dienst 13h)

Ohne dieses Update arbeiten die Wachen in der App trotzdem; nur die Nachrichten an die anderen Geräte und die E-Mail fehlen.

1. **Tabelle:** Die 2 Zeilen aus `server/13h.sql` in der D1-Console von `mobimory-konten` ausführen, jede einzeln. Beim Test-Dienst ebenso in dessen Datenbank.
2. **Dienst:** `konto-dienst.mjs` hochladen (Schritt 2 bis 4 wie oben). `/gesundheit` zeigt dann `"version":"13h"`.
3. **Push-Schlüssel (nur für Browser/Tablet):** Auf einem Rechner mit Node `node server/vapid-erzeugen.mjs` ausführen. Es erscheinen zwei Zeilen. Beim Dienst unter „Einstellungen, Variablen und Geheimnisse“ zwei **Geheimnisse** anlegen: `VAPID_PRIVAT` (die ganze Zeile nach dem Gleichheitszeichen, das `{…}`) und `VAPID_OEFFENTLICH`. Den privaten Wert niemandem zeigen.
4. **Android-Hülle (seit 2.0.121 in der App, noch nicht am Gerät geprüft):** Der Dienst bedient Firebase (FCM), sobald das Geheimnis `FCM_KONTO` (Schlüsseldatei des Firebase-Dienstkontos als Text) gesetzt und „Bereitstellen“ geklickt ist. Die App (APK ab 2.0.121) bringt Push-Plugin und `google-services.json` (Projekt `mobimory-f9936`) mit. Prüfen: Auf dem Gerät mit der APK auf der Wache-Seite „Nachrichten auf diesem Gerät erlauben“ tippen, Android-Frage erlauben; dann Alarm auf einem anderen Gerät auslösen.
5. **Erst den Dienst, dann die App.** Die E-Mail geht über den vorhandenen Versand.

## Update 2.0.119: Synchron auf allen Geräten (nur Code, keine SQL-Zeile)

Neu im Dienst: die Datenarten `standorte`, `anforderungen` und `einstellungen`, das verschlüsselte Feld `@geheim`, die Dateiart `gpsdaten`, das Kennzeichen `automatisch` im Stand. Der Dienst kann das Private nicht lesen.

- Einspielen: nur `konto-dienst.mjs` hochladen (Schritt 2 bis 4 wie oben).
- **Erst den Dienst, dann die App.** Danach, wenn alle Geräte die neue App haben, `APP_MINDESTVERSION` auf 2.0.119 anheben (nicht früher).
- Verträglichkeit: Eine ältere App läuft gegen den neuen Dienst weiter. Die neue App gegen den alten Dienst gleicht nur von Hand ab.

## Update 2.0.118: keine Änderung am Dienst

`server/konto-dienst.mjs` ist gegenüber 2.0.117 unverändert. Wer 2.0.117 schon eingespielt hat, muss bei Cloudflare nichts tun.

## Update 2.0.117: Geräteverwaltung (nur Code, keine SQL-Zeile)

Neu im Dienst: `GET /konto/geraete` (die angemeldeten Geräte des Kontos) und `POST /konto/geraet-abmelden` (ein anderes Gerät abmelden). Beim Anmelden kann die App „ältestes Gerät abmelden“ mitschicken (`aeltestesAbmelden: true`), wenn die Geräte-Grenze der Stufe erreicht ist. Die Fehlermeldung bei voller Grenze nennt jetzt das älteste Gerät (`geraeteVoll`, `aeltestes`), und ein richtiger Code bleibt dabei gültig.

- Einspielen: nur `konto-dienst.mjs` hochladen (Schritt 2 bis 4 wie oben). `/gesundheit` zeigt weiter `"version":"13g"`.
- Verträglichkeit: Eine ältere App ohne diese Aufrufe läuft unverändert weiter. Eine neue App gegen den alten Dienst sagt bei der Geräteliste, dass der Dienst erst aktualisiert werden muss.

## Update 2.0.101: Versionsverträglichkeit (nur Code, keine SQL-Zeile)

Ab 2.0.101 hängt die App an jede Anfrage ihre Versionsnummer an (`?app=2.0.101`). Der Dienst prüft sie bei allen Aufrufen aus der App:

- Der Dienst versteht jede App-Version ab der **Mindestversion**. Standard im Code: `2.0.100` (die letzte Version ohne Angabe). Eine App ohne Angabe gilt als 2.0.100.
- Ist die App älter, antwortet der Dienst mit Fehler 426. Die App zeigt „Bitte zuerst aktualisieren“ mit der Anleitung (App ganz schließen und mit Netz neu öffnen, im Browser Seite neu laden).
- Die Mindestversion lässt sich ohne neue Datei ändern: im Worker `mobimory-konto` unter **Settings → Variables and Secrets** die Variable `APP_MINDESTVERSION` (Text, zum Beispiel `2.1.0`) setzen. Ungültige Werte werden ignoriert.
- **Regel zum Anheben:** Die Mindestversion wird nur angehoben, wenn eine Änderung im Dienst alte Apps nicht mehr versteht. Vorher muss die neue App schon unter app.mobimory.com liegen, sonst sperrt sich jeder aus. Wer nach langer Pause kommt (zum Beispiel von 2.0.67 nach 2.1.25), bekommt den Hinweis und holt sich mit einem Neuöffnen die neue App.
- `/gesundheit` bleibt immer offen und zeigt `app.mindestversion`. Die Freischalt-Seite und die Verwaltung (kein Aufruf aus der App) werden nicht geprüft.
- Reihenfolge beim Einspielen: egal. Die Angabe ist ein Parameter und braucht keine neue CORS-Kopfzeile, eine neue App läuft auch gegen den alten Dienst, und der neue Dienst nimmt auch die alte App.
- Einspielen: nur `konto-dienst.mjs` hochladen (Schritt 2 bis 4 wie oben). `/gesundheit` zeigt weiter `"version":"13g"` und neu `"app":{"mindestversion":"2.0.100"}`.

## Update auf 13g (Lesedienst für Smart Capture, seit 2.0.98)

Reihenfolge: erst Tabelle, dann Geheimwert, dann Datei, dann prüfen.

1. **Tabelle:** Die 2 Zeilen aus `server/13g.sql` in der D1-Console von `mobimory-konten` ausführen, jede einzeln. Das Gleiche für den Test-Dienst, falls du dort testen willst (`mobimory-konten-test`).
2. **Geheimwert** im Worker `mobimory-konto` unter **Settings → Variables and Secrets**, Typ **Secret**: `GOOGLE_VISION_KEY` = der API-Schlüssel aus Google Cloud (in Google auf „Cloud Vision API“ beschränkt, das ist bestätigt). Nie in eine Datei oder in einen Chat schreiben. Der Wert bleibt bei jedem Bau erhalten (`keep_vars`).
3. **Datei hochladen** (Update einspielen, Schritt 2 bis 4): `konto-dienst.mjs`. `wrangler-konto.jsonc` bleibt unverändert.
4. **Prüfen:** `/gesundheit` zeigt `"version":"13g"` und bei `lesen` beide Werte `true` (`tabelle` und `schluessel`).
5. **Google:** In Google Cloud nach dem Ende des Testzeitraums ein bezahltes Konto hinterlegen, sonst stellt Google den Dienst ein. Unter „Abrechnung → Budgets und Benachrichtigungen“ ein Budget mit Mail-Warnung anlegen (zum Beispiel 10 €).

Wie es arbeitet:
- Die App schickt ein verkleinertes Foto (höchstens 2200 Bildpunkte, JPEG) an `konto.mobimory.com/lesen/senden`, nur mit der Zustimmung des Kunden. Der Dienst ruft Google Cloud Vision über die EU-Adresse `eu-vision.googleapis.com` auf und gibt Wörter mit Positionen zurück.
- **Der Dienst speichert weder das Foto noch den Text.** Gespeichert wird nur eine Zählzeile (Konto, Stufe, Zeitpunkt, Status) in `lese_nutzung`.
- Stufen: Testwoche 10 Scans für die ganze Woche, Mittel 50 Scans im Monat, Voll 100, Entwickler ohne Grenze. Ein Foto ist ein Scan, Vorder- und Rückseite zählen als zwei. Ein ermäßigter oder geschenkter Preis ändert die Grenze nicht. Basic hat keinen Lesedienst. Der Monat ist der Kalendermonat (UTC).
- Schlägt Google fehl oder antwortet nicht, wird der Scan nicht gezählt und die App liest auf dem Gerät.
- Googles 1000 kostenlose Einheiten im Monat gelten je Google-Abrechnungskonto, nicht je Kunde. Danach rechnet Google ab (Stand 16.11.2026 rund 1,50 US-Dollar je 1000, Preisseite nicht selbst gelesen).

## Update auf 13e (Stufen, Kontingent, Online-Checks, seit 2.0.69)

1. **Tabellen:** Die 6 Zeilen aus `server/13e.sql` in der D1-Console von `mobimory-konten` ausführen, jede einzeln.
2. **Recherche-Dienst eintragen:** Im Worker `mobimory-konto` unter **Settings → Variables and Secrets**:
   - Typ **Text**: `RECHERCHE_URL` = Adresse des Recherche-Dienstes (`https://mobimory-research….workers.dev`, ohne `/research`).
   - Typ **Secret**: `RECHERCHE_TOKEN` = dasselbe Passwort wie `MOBIMORY_TOKEN` im Recherche-Dienst.
   - Sie bleiben bei jedem Bau erhalten (`keep_vars`).
   - Im **Recherche-Dienst** muss bei `ALLOWED_ORIGINS` `https://app.mobimory.com` stehen.
3. **Ihr Konto auf Entwickler (ohne Grenzen) setzen** (Konten von vor 13e gelten sonst als Basic). In der D1-Console, mit Ihrer Mail-Adresse statt `ihre@adresse`:
   `INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) SELECT id, 'entwickler', NULL, 0 FROM nutzer WHERE email = 'ihre@adresse';`
   Für andere Konten `'mittel'` oder `'voll'` (`'entwickler'` nur für Sie). Ein Ablauf steht in `gueltig_bis` (Millisekunden seit 1970), `NULL` heißt ohne Ablauf.
4. `konto-dienst.mjs` hochladen (Update einspielen, Schritt 2 bis 4). `/gesundheit` muss `"version":"13e-3"`, `"stufen":true` und `"recherche":true` zeigen.
5. App (ZIP) hochladen, am Tablet neu laden, unter Reisecheck › Zustimmung einmal neu zustimmen.

Der Test-Dienst baut dieselbe Datei. Seine Datenbank hat die 13e-Tabellen nur, wenn Sie die 6 Zeilen dort auch ausführen. Ohne sie funktioniert dort das Anmelden weiter, Online-Checks und Stufen nicht.

Wie es arbeitet:
- Die App spricht nur mit `konto.mobimory.com`. Der Dienst prüft Stufe und Kontingent, zählt und ruft den Recherche-Dienst auf. Dessen Passwort kennt nur der Konto-Dienst.
- Testwoche: 7 Tage, 1 Check, einmal je Mail-Adresse. Danach Basic.
- Stufen und Grenzen stehen in `server/konto-dienst.mjs` (`STUFEN`) und `js/konto.js`. Ein Test vergleicht beide.

## Update auf 13e-3 (Kosten-Wächter, seit 2.0.71)

1. **Tabelle:** Die eine Zeile aus `server/13e-3.sql` in der D1-Console von `mobimory-konten` ausführen.
2. **Variable für den Empfänger:** Im Worker `mobimory-konto` unter **Settings → Variables and Secrets** Typ **Text**: `WAECHTER_EMAIL` = Ihre Mail-Adresse. Ohne sie wird nur geprüft, es kommt keine Mail.
3. **Kosten je Check eintragen:** Typ **Text** `KOSTEN_CHECK` = der echte Wert aus der OpenAI-Abrechnung in Euro (zum Beispiel `0,40`). Ohne die Variable rechnet der Wächter mit 0,45 € und schreibt „Schätzwert“ in die Mail.
4. **Eigene Test-Konten und geschenkte Voll-Konten ausnehmen:** Typ **Text** `WAECHTER_AUSGENOMMEN` = Mail-Adressen, durch Komma getrennt. Diese Konten zählen weder als Testwochen-Kosten noch als Einnahmen. Das Entwickler-Konto ist immer ausgenommen.
5. **Dateien hochladen** (Update einspielen, Schritt 2 bis 4): `konto-dienst.mjs` und **`wrangler-konto.jsonc`** (sie enthält jetzt den Cron-Auslöser `*/15 * * * *`).
6. **Prüfen:** `/gesundheit` zeigt `"version":"13e-3"` und `"waechter":true`. Im Worker unter **Settings → Triggers** steht der Cron-Auslöser alle 15 Minuten, unter **Logs** erscheint alle 15 Minuten eine Zeile „Kosten-Wächter: geprüft=true …“.

Weitere Variablen (alle freiwillig, die Standardwerte stehen in Klammern): `WAECHTER_ANTEIL` (0,2 = 20 %), `WAECHTER_TAGE` (30), `WAECHTER_CHECKS_TAG` (10), `WAECHTER_TESTWOCHEN_TAG` (5). Ein ungültiger Wert fällt still auf den Standard zurück.

Wie er arbeitet:
- Mit Einnahmen (seit 2.0.72 die echten Belege der letzten 365 Tage durch 12) warnt er, wenn die Testwochen-Kosten über 20 % der Einnahmen liegen. Ohne Einnahmen warnt er bei mehr als 10 Testwochen-Checks in 24 Stunden. Immer warnt er bei mehr als 5 neuen Testwochen in 24 Stunden.
- Nach einer Mail kommt höchstens eine weitere pro Stunde. Die Mail nennt nur Zahlen und den Zeitraum.
- Geschenkte Konten haben keinen Beleg und zählen deshalb nicht als Einnahme. Eigene Test-Konten trotzdem in `WAECHTER_AUSGENOMMEN` eintragen (wegen der Testwochen-Kosten).
- **Zusätzlich, ohne Programm:** Bei OpenAI unter „Billing“ oder „Limits“ eine Obergrenze für die Monatskosten setzen. Das ist der härteste Schutz und greift auch bei Fehlern im Dienst.

## Update auf 13e-4 (Bezahlung, seit 2.0.72)

Reihenfolge: erst Tabellen, dann Variablen, dann Dateien, dann prüfen. **Zuerst nur mit PayPal-Sandbox (Testgeld) ausprobieren, erst danach auf echtes Geld umstellen.**

1. **Tabellen:** Die 6 Zeilen aus `server/13e-4.sql` in der D1-Console von `mobimory-konten` ausführen, jede einzeln.
2. **Variablen** im Worker `mobimory-konto` unter **Settings → Variables and Secrets**, Typ **Text**:
   - `UEBERWEISUNG_INHABER` = Name des Kontoinhabers, `UEBERWEISUNG_IBAN` = Ihre IBAN, freiwillig `UEBERWEISUNG_BIC`.
   - `BELEG_ANSCHRIFT` = Ihr Name und Ihre Anschrift für den Beleg, in einer Zeile mit Komma (zum Beispiel `Ralph Hasslacher, Straße Nr., 74372 Sersheim`). Vom Steuerberater prüfen lassen.
   - Freiwillig `BELEG_KOPIE` = Ihre Mail-Adresse (Sie bekommen jeden Beleg in Kopie).
3. **Geheimnis** (Typ **Secret**): `FREISCHALT_TOKEN` = ein langes zufälliges Passwort (mindestens 20 Zeichen). Damit melden Sie sich auf der Freischalt-Seite an. Nicht in eine Datei oder einen Chat schreiben.
4. **PayPal-Sandbox (Test):** Bei developer.paypal.com anmelden, **Apps & Credentials**, oben **Sandbox**, eine App anlegen. Dort stehen **Client ID** und **Secret**. Im Worker: `PAYPAL_CLIENT_ID` (Typ Text) und `PAYPAL_SECRET` (Typ **Secret**). `PAYPAL_LIVE` **nicht** setzen: Dann geht der Dienst an die Sandbox. Zum Bezahlen ein Sandbox-Käuferkonto nehmen (developer.paypal.com → Testing tools → Sandbox accounts).
5. **Dateien hochladen** (Update einspielen, Schritt 2 bis 4): `konto-dienst.mjs`. Die Datei `wrangler-konto.jsonc` ist unverändert.
6. **Prüfen:** `/gesundheit` zeigt `"version":"13e-4"` und bei `bezahlung` alles `true`; `paypalEchtgeld` muss im Test `false` sein.
7. **Sandbox-Test:** In der App unter Konto › Stufe wählen › Mit PayPal bezahlen, mit dem Sandbox-Käuferkonto zahlen, zurück zur App: Die Stufe steht auf Mittel. Eine Mail mit dem Beleg kommt an. Außerdem Überweisung ausprobieren: Angaben kommen per Mail, auf `https://konto.mobimory.com/freischalten` (Passwort = `FREISCHALT_TOKEN`) erscheint die Bestellung, „Geld ist da: freischalten“.
8. **Auf echtes Geld umstellen** (erst wenn das PayPal-Businesskonto fertig ist): Bei developer.paypal.com oben auf **Live** wechseln, die Live-App anlegen, `PAYPAL_CLIENT_ID` und `PAYPAL_SECRET` durch die Live-Werte ersetzen und `PAYPAL_LIVE` = `1` setzen (Typ Text). `/gesundheit` zeigt dann `"paypalEchtgeld":true`. Einen ersten Echt-Kauf mit 9,99 € selbst machen (und über PayPal zurückbuchen).

Die Variablen `PREIS_MITTEL` und `PREIS_VOLL` werden nicht mehr gebraucht und dürfen im Worker gelöscht werden.

Wie es arbeitet:
- Der Dienst schaltet nur frei, wenn PayPal die Zahlung **abgeschlossen** meldet und Betrag und Währung stimmen. Zahlungsdaten speichert er nie. Je Zahlung bleibt eine Zeile in der Tabelle `beleg` (Buchhaltung), auch wenn das Konto gelöscht wird.
- Freischalten von Hand (Überweisung) nur auf der Seite `/freischalten`. Wer das Passwort acht Mal falsch eingibt, wird 15 Minuten gesperrt.
- Die Erinnerungen (30 und 7 Tage vor dem Ablauf) verschickt der Cron-Auslöser mit, in den Logs steht „Erinnerungen: gesendet=…“.
- Preise stehen in `server/konto-dienst.mjs` (`PRODUKTE`) und `js/konto.js`. Ein Test vergleicht beide.
- Offen: Löschung der Serverdaten 12 Monate nach Ablauf, Erstattungen von Hand (PayPal-Konto, danach Stufe per SQL zurücksetzen).

## Update auf 13f-11 (Verwaltung in der App, seit 2.0.94)

Die Kachel „Verwaltung“ unter „Nur für Entwickler“ zeigt die Statistik der Konten (Test, Mittel, Voll) und bucht Zahlungseingänge von Überweisungen. **Keine neue SQL-Zeile, kein neues Geheimnis.**

1. **Datei hochladen:** `konto-dienst.mjs` (Update einspielen, Schritt 2 bis 4).
2. **Prüfen:** `/gesundheit` zeigt `"version":"13f-11"`. In der App unter Nur für Entwickler › Verwaltung erscheinen die Zahlen.

Wer darf: die Statistik sehen Admin und Entwickler, Buchen und Freischalten nur Admins (Rolle aus der Tabelle `rolle`). Die Seite `/freischalten` mit Passwort funktioniert weiter.

## Update auf 13f-10 (Routenplanung, seit 2.0.88)

Die App kann für Autos, Wohnmobile und andere Straßenfahrzeuge eine Route planen. Der Dienst fragt dafür **HERE** (Routing API v8, Modus Lastwagen) und zählt die Routen. **Zwei neue Tabellen** und **ein Schlüssel**.

**A. HERE-Konto und Schlüssel (einmalig)**
1. Auf https://platform.here.com ein kostenloses Konto anlegen (Freemium-Tarif).
2. Im Projekt unter **Access Manager → Apps / API keys** einen **API-Schlüssel** erzeugen und kopieren.
3. Vor dem Start prüfen: **Preise** (Anfragen im Monat, Preis danach) und **Nutzungsbedingungen** (bezahlte App erlaubt? Route speichern erlaubt?). Die App speichert die geplante Route.

**B. Im Cloudflare-Dienst**
1. **SQL:** In der D1-Console von `mobimory-konten` die **drei Zeilen** aus `server/13f-10.sql` ausführen, **jede Zeile einzeln** (zwei `CREATE TABLE`, ein `CREATE INDEX`).
2. **Schlüssel eintragen:** Im Worker `mobimory-konto` unter **Settings → Variables and Secrets** einen Eintrag vom Typ **Secret** anlegen: Name `HERE_SCHLUESSEL`, Wert der kopierte Schlüssel. Er bleibt bei jedem Bau erhalten.
3. **Datei hochladen:** `konto-dienst.mjs` (Update einspielen, Schritt 2 bis 4).
4. **Prüfen:** `/gesundheit` zeigt `"version":"13f-10"` und `"routen":{"tabellen":true,"schluessel":true}`.

Ohne die SQL-Zeilen und ohne Schlüssel läuft alles andere wie bisher; wer plant, bekommt die Meldung, dass der Routen-Dienst noch nicht eingetragen ist.

Grenzen im Jahr: Testwoche 10, Mittel 100, Voll 1000 Routen (getrennt von den Online-Checks). Nachkauf: 100 Routen für 9,99 € (Angebot `route100`, ab Mittel oder in der Testwoche, kein Rabattcode). Schlägt HERE fehl oder gibt es keine Route, wird nicht gezählt. Bremse: 10 Routen in 10 Minuten.

## Update auf 13f-9 (Mail beim Anlegen eines Codes, seit 2.0.84)

Beim Anlegen eines Codes kann der Admin eine E-Mail-Adresse eintragen. Der Dienst schickt den Code dann per Mail. **Keine neue SQL-Zeile.**

1. **Datei hochladen:** nur `konto-dienst.mjs` (Update einspielen, Schritt 2 bis 4).
2. **Prüfen:** `/gesundheit` zeigt `"version":"13f-9"`.

Die Adresse wird nicht gespeichert. Geht die Mail nicht raus (zum Beispiel Mail-Versand nicht eingerichtet), ist der Code trotzdem angelegt und die Seite sagt es.

## Update auf 13f-8 (Gutscheincodes beim Bezahlen, seit 2.0.83)

Codes für Rabatt (bis 25 %, nur Neukunden, erster Kauf) und Geschenk (100 %, ohne Zahlung). Dafür zwei neue Tabellen und vier neue Spalten.

1. **SQL:** In der D1-Console von `mobimory-konten` die **sechs Zeilen** aus `server/13f-8.sql` ausführen, **jede Zeile einzeln** (zuerst die beiden `CREATE TABLE`, dann die vier `ALTER TABLE`).
2. **Datei hochladen:** `konto-dienst.mjs` (Update einspielen, Schritt 2 bis 4).
3. **Prüfen:** `/gesundheit` zeigt `"version":"13f-8"` und unter `bezahlung` den Eintrag `"gutscheine":true`.
4. **Codes anlegen:** In der App als Admin unter „Nur für Entwickler“ › „Gutscheincodes“.

Ohne die SQL-Zeilen läuft das Bezahlen wie bisher. Wer einen Code eingibt, bekommt den Hinweis, dass 13f-8.sql fehlt. Ein Geschenkcode (100 %) ruft PayPal nie auf, es fällt keine Gebühr an. Er erzeugt keinen Beleg, der Kunde bekommt eine Bestätigungs-Mail.

## Update auf 13f-4 (Planung vor dem Verleih, seit 2.0.79)

Eine Freigabe hat jetzt zwei Zeiträume. Ab dem Beginn der **Planung** sieht der Gast das Fahrzeug, plant seine Reise und macht Reisechecks, trägt aber nichts im Fahrzeug ein. Erst ab dem Beginn des **Verleihs** gelten seine Rechte (nur lesen oder mitnutzen). Dafür eine neue Spalte in der Tabelle `freigabe`.

1. **SQL:** In der D1-Console von `mobimory-konten` die Zeile aus `server/13f-4.sql` ausführen.
2. **Datei hochladen:** `konto-dienst.mjs` (Update einspielen, Schritt 2 bis 4).
3. **Prüfen:** `/gesundheit` zeigt `"version":"13f-4"` und `"planung":true`.

Ohne die SQL-Zeile bleibt alles wie bisher. Wer einen Planungsbeginn angibt, bekommt den Hinweis, dass die Zeile 13f-4 fehlt. Reisechecks des Gastes zählen zum Kontingent des Besitzers (Festlegung vom 12.11.). Der Gast sieht die Zahlen des Besitzers nie.

## Update auf 13f-3 (Störung mit Info-Mail, seit 2.0.76)

Meldet ein Gast mit „mitnutzen“ eine Störung, schickt der Dienst dem Besitzer eine Info-Mail. Der Gast sieht dafür die früheren Störungen und Arbeiten des Fahrzeugs (nur Texte, keine Beträge). **Keine neue SQL-Zeile.**

1. **Datei hochladen:** `konto-dienst.mjs` (Update einspielen, Schritt 2 bis 4).
2. **Prüfen:** `/gesundheit` zeigt `"version":"13f-3"` und `"stoerungsmail":true`.

Die Mail geht über denselben E-Mail-Dienst wie die Codes (Bindung `EMAIL`, Variable `ABSENDER`). Ist er nicht eingerichtet, wird die Störung trotzdem gespeichert, der Gast sieht dann den Hinweis, dass die Info-Mail nicht gesendet werden konnte. Höchstens 5 Mails je Freigabe und Stunde.

## Update auf 13f-2 (Mitnutzung, seit 2.0.75)

Eine Freigabe hat jetzt Rechte: „nur lesen“ (wie bisher) oder „mitnutzen“. Mit „mitnutzen“ trägt der Gast Kilometer, Fahrzeugkosten und Störungen ein und erzeugt Kontroll-Codes. Dafür drei neue Spalten in der Tabelle `freigabe`.

1. **SQL:** In der D1-Console von `mobimory-konten` die drei Zeilen aus `server/13f-2.sql` ausführen, **jede Zeile einzeln**.
2. **Datei hochladen:** `konto-dienst.mjs` (Update einspielen, Schritt 2 bis 4).
3. **Prüfen:** `/gesundheit` zeigt `"version":"13f-2"` und `"mitnutzung":true`.

Ohne die SQL-Zeilen bleibt alles wie bisher (nur lesen). Wer „mitnutzen“ einlädt, bekommt den Hinweis, dass die Zeile 13f-2 fehlt. Bestehende Freigaben bleiben „nur lesen“.

Regeln: Der Gast erfasst nur **neue** Einträge, er ändert nie einen Eintrag des Besitzers. Die Einträge liegen im Fahrzeug des Besitzers, mit dem Namen des Gastes (den der Besitzer bei der Einladung angibt), und kommen beim nächsten Abgleich auf die Geräte des Besitzers. Fixkosten legt nur der Besitzer an. Reisekosten (Campingplatz, Essen, Souvenirs) gehen nie ins Fahrzeug. Dokumente (zum Beispiel der Kaufvertrag) lassen sich je Freigabe ausnehmen. Kontroll-Codes des Gastes gelten nie länger als die Freigabe und stehen in der Liste des Besitzers (dort widerrufbar).

## Update auf 13f-1 (Verleih, seit 2.0.74)

Gäste nach Stufe und der Nachweis des Halters brauchen drei neue Spalten in der Tabelle `freigabe`.

1. **SQL:** In der D1-Console von `mobimory-konten` die drei Zeilen aus `server/13f-1.sql` ausführen, **jede Zeile einzeln**.
2. **Datei hochladen:** `konto-dienst.mjs` (Update einspielen, Schritt 2 bis 4).
3. **Prüfen:** `/gesundheit` zeigt `"version":"13f-1"` und `"verleih":true`. In der App steht unter Funktionen › Verleih bei „Fahrzeug verleihen“ die Zeile „Gäste: x von y Plätzen belegt“.

Ohne die SQL-Zeilen kann niemand ein Fahrzeug verleihen. Die App sagt dann, dass die Zeile 13f-1 fehlt. Bestehende Freigaben bleiben gültig, bei ihnen steht kein Nachweis.

Regeln: Gäste gibt es ab Mittel (Testwoche eingeschlossen). Plätze = Geräte der Stufe minus die angemeldeten Geräte des Besitzers (Mittel 4, Voll 10, Entwickler ohne Grenze).

## Update auf 13e-5 (Rollen-Tabelle, seit 2.0.73)

Wer den Bereich „Nur für Entwickler“ in der App sieht, steht jetzt in einer Tabelle `rolle` (E-Mail, Name, Funktion Admin oder Entwickler). Ändern dürfen sie nur Admins, in der App unter Nur für Entwickler › Rollen.

1. **Tabelle:** Die Zeile aus `server/13e-5.sql` in der D1-Console von `mobimory-konten` ausführen.
2. **Erster Admin** (einmal von Hand): Die Zeile aus `server/13e-5-erster-admin.sql` ausführen. Sie trägt `ralphhasslacher34@gmail.com` als Admin ein. Danach pflegst du die Tabelle in der App selbst.
3. **Datei hochladen:** `konto-dienst.mjs` (Update einspielen, Schritt 2 bis 4).
4. **Prüfen:** `/gesundheit` zeigt `"version":"13e-5"` und `"rollen":true`. In der App erscheint im Hauptmenü die Kachel „Nur für Entwickler“ (nach dem nächsten Öffnen von Konto oder dem Start der App mit Netz).

Die Stufe `entwickler` in `stufe_konto` bleibt wie sie ist (keine Grenzen, kauft nichts). Sie macht niemanden sichtbar zum Entwickler: Das bestimmt nur die Tabelle `rolle`.

## Hinweise

- **Geheimnis:** `PASSWORT_PEPPER` gehört nie in eine Datei, nie in GitHub und nie in einen Chat. Ohne ihn passt kein Passwort mehr.
- **Passwort-Abdruck:** Cloudflare erlaubt höchstens 100 000 Runden, OWASP empfiehlt 600 000. Gehört auf die Liste für den Datenschutz-Fachmann vor dem öffentlichen Start.
- **Wenn etwas schiefgeht:** Worker → **Logs**. Die Meldung abschreiben.
- **Neu von Null** (nur falls je nötig): `server/schema.sql` enthält alle Tabellen, die Einstellungen stehen in `wrangler-konto.jsonc`. Datenbank und Bucket nur beim Anlegen mit Jurisdiktion **EU**.
