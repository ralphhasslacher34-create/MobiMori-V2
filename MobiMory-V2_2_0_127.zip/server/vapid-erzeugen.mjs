/* Erzeugt das Schlüsselpaar für Push-Nachrichten (VAPID). Aufruf: node server/vapid-erzeugen.mjs
   Ausgabe: zwei Werte. VAPID_PRIVAT und VAPID_OEFFENTLICH als „Secret“ beim Konto-Dienst eintragen (siehe EINRICHTUNG.md). Den privaten Wert niemandem zeigen. */
const k = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
const privat = JSON.stringify(await crypto.subtle.exportKey('jwk', k.privateKey));
const roh = new Uint8Array(await crypto.subtle.exportKey('raw', k.publicKey));
console.log('VAPID_PRIVAT=' + privat);
console.log('VAPID_OEFFENTLICH=' + Buffer.from(roh).toString('base64url'));
