CREATE TABLE IF NOT EXISTS push_ziel (id TEXT PRIMARY KEY, nutzer_id TEXT NOT NULL REFERENCES nutzer(id) ON DELETE CASCADE, geraet TEXT NOT NULL, art TEXT NOT NULL, ziel TEXT NOT NULL, erstellt_am INTEGER NOT NULL, UNIQUE(nutzer_id, geraet));
CREATE INDEX IF NOT EXISTS push_ziel_nutzer ON push_ziel(nutzer_id);
