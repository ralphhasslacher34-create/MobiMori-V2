'use strict';
/* 2.0.125: Strecke und ETA eines Tages rechnen mit der Tagesroute, nicht mit der Route der ganzen Aktivität (Rundreise Sersheim – Meran – Pisa – Sersheim). */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status', 'motoren', 'personen',
  'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'orte', 'gebiete', 'ortssuche', 'reiseorte', 'routen', 'karte', 'etappen', 'konto', 'daten'].forEach((m) => require('../js/' + m + '.js'));
const MM = globalThis.MM;
const JETZT = new Date(2026, 10, 22, 12, 0, 0).toISOString();
const S = [48.96, 9.10], ME = [46.67, 11.16], PI = [43.72, 10.40], MITTE = [47.8, 10.1];
const GPX = `<gpx><rte><rtept lat="${S[0]}" lon="${S[1]}"><n>Sersheim</n></rtept><rtept lat="${ME[0]}" lon="${ME[1]}"><n>Meran</n></rtept><rtept lat="${PI[0]}" lon="${PI[1]}"><n>Pisa</n></rtept><rtept lat="${S[0]}" lon="${S[1]}"><n>Sersheim</n></rtept></rte></gpx>`;

async function neu(art) {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen(art || 'wohnmobil', { bezeichnung: 'Fahrzeug', reisegeschwindigkeit: '80', hoechstgeschwindigkeit: '110' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'] })).id;
  const artId = (await d.aktivitaetsartenListe()).find((a) => a.aktuell.werte.bezeichnung === 'Urlaub').objekt.id;
  const ort = async (n, p) => (await d.ortAnlegen({ bezeichnung: n, positionBreite: String(p[0]), positionLaenge: String(p[1]) })).id;
  const orte = { s: await ort('Sersheim', S), me: await ort('Meran', ME), pi: await ort('Pisa', PI) };
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Rundreise', artId, fahrzeugId: fz, vonDatum: '2026-11-23', vonZeit: '08:00', bisDatum: '2026-11-24', verantwortlichId: anna, startOrtId: orte.s, zielOrtId: orte.s, zwischenzielIds: [orte.me, orte.pi] });
  assert.equal(r.ok, true, JSON.stringify(r));
  await d.tagesabschnitteVorbereiten(r.id);
  const tage = (await d.logbuchLaden(r.id)).abschnitte.map((x) => x.objekt.id);
  assert.ok((await d.routeImportieren(r.id, GPX, 'rund.gpx')).ok);
  assert.equal((await d.abschnittAendern(tage[0], { datum: '2026-11-23', beginnZeit: '08:00', endeZeit: '18:00', startOrtId: orte.s, zielOrtId: orte.me })).ok, true);
  return { d, fz, akt: r.id, orte, tage };
}
const tagesroute = (c, extra) => c.d.einstellungSchreiben(Object.assign({ id: 'tagroute-' + c.tage[0], abschnittId: c.tage[0], punkte: [{ breite: S[0], laenge: S[1], name: 'Sersheim' }, { breite: MITTE[0], laenge: MITTE[1] }, { breite: ME[0], laenge: ME[1], name: 'Meran' }],
  laengeKm: 472.2, dauerMin: 366, startOrtId: c.orte.s, zielOrtId: c.orte.me, planViaOrtIds: [], viaOrtIds: [], geplantAm: '2026-11-22T13:05:00' }, extra || {}));

test('Straßenfahrzeug ohne Tagesroute: ETA „unklar, bitte Tag planen“, Strecke nur als Luftlinie, nie die Route der Aktivität', async () => {
  const c = await neu();
  const e = await c.d.etaZumZiel(c.akt, c.tage[0], {});
  assert.equal(e.ok, true); assert.equal(e.eta.ok, false);
  assert.match(e.eta.grund, /plane den Tag/);
  const z = (await c.d.reiseZusammenfassung(c.akt)).tage[0];
  assert.equal(z.strecke.art, 'luftlinie');
  assert.ok(z.strecke.km < 400, 'Luftlinie Sersheim – Meran, nicht die ganze Rundreise: ' + z.strecke.km);
});

test('Straßenfahrzeug mit Tagesroute: obere Strecke und ETA nehmen die Länge des Tages', async () => {
  const c = await neu();
  await tagesroute(c);
  const e = await c.d.etaZumZiel(c.akt, c.tage[0], {});
  assert.equal(e.eta.ok, true, JSON.stringify(e.eta));
  assert.equal(e.eta.km, 472.2); assert.equal(e.eta.art, 'route'); assert.equal(e.eta.fahrzeitMin, Math.round(472.2 / 80 * 60));
  const z = (await c.d.reiseZusammenfassung(c.akt)).tage[0];
  assert.deepEqual(z.strecke, { km: 472.2, art: 'route' });
  assert.equal((await c.d.reiseZusammenfassung(c.akt)).streckeSumme >= 472.2, true);
});

test('Live-ETA: der Rest wird auf der Tagesroute gerechnet', async () => {
  const c = await neu();
  await tagesroute(c);
  const live = await c.d.etaZumZiel(c.akt, c.tage[0], { live: { unterwegs: true, tagKmh: 80, position: { breite: MITTE[0], laenge: MITTE[1] } }, jetztMs: new Date('2026-11-23T12:00').getTime() });
  assert.equal(live.eta.ok, true);
  assert.equal(live.eta.art, 'route');
  assert.ok(live.eta.km > 150 && live.eta.km < 330, 'etwa die halbe Tagesroute: ' + live.eta.km);
  const k = await c.d.etaKontext(c.akt, c.tage[0], {});
  const r = MM.Etappen.etaAusKontext(k, { unterwegs: true, tagKmh: 80, position: { breite: ME[0], laenge: ME[1] } }, Date.now());
  assert.ok(r.restKm < 1, 'am Ziel: Rest fast 0, war ' + r.restKm);
});

test('Veraltete Tagesroute (Ziel des Tages geändert) und anderes Ziel beim Ablegen: unklar mit Grund', async () => {
  const c = await neu();
  await tagesroute(c);
  const anderes = await c.d.etaZumZiel(c.akt, c.tage[0], { zielOrtId: c.orte.pi });
  assert.equal(anderes.eta.ok, false); assert.match(anderes.eta.grund, /plane den Tag/);
  assert.equal((await c.d.abschnittAendern(c.tage[0], { datum: '2026-11-23', beginnZeit: '08:00', endeZeit: '18:00', startOrtId: c.orte.s, zielOrtId: c.orte.pi })).ok, true);
  const v = await c.d.etaZumZiel(c.akt, c.tage[0], {});
  assert.equal(v.eta.ok, false); assert.match(v.eta.grund, /geändert/);
  assert.notEqual((await c.d.reiseZusammenfassung(c.akt)).tage[0].strecke.art, 'route');
});

test('Wasserfahrzeug bleibt wie bisher: keine Tagesplanung, ETA auf Luftlinie', async () => {
  const c = await neu('motorboot');
  const e = await c.d.etaZumZiel(c.akt, c.tage[0], {});
  assert.equal(e.eta.ok, true, JSON.stringify(e.eta));
  assert.ok(['route', 'luftlinie'].includes(e.eta.art));
});

test('Rechnung: Rundreise-Route mit gleichem Start und Ende gibt keine Tagesstrecke; Tagesstrecke geht vor', () => {
  const ohne = MM.Etappen.tagesPlan({ datum: '2026-11-23', beginnZeit: '08:00', endeZeit: '', start: { name: 'a', breite: S[0], laenge: S[1] }, ziel: { name: 'b', breite: ME[0], laenge: ME[1] }, routePunkte: null, routeKmh: 80 });
  assert.equal(ohne.strecke.art, 'luftlinie');
  const mit = MM.Etappen.tagesPlan({ datum: '2026-11-23', beginnZeit: '08:00', endeZeit: '', start: { name: 'a', breite: S[0], laenge: S[1] }, ziel: { name: 'b', breite: ME[0], laenge: ME[1] }, routePunkte: null, tagStrecke: { km: 472.2 }, routeKmh: 80 });
  assert.deepEqual(mit.strecke, { km: 472.2, art: 'route' });
});
