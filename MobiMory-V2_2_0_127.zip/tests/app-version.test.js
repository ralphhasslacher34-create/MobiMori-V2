'use strict';
/* 2.0.101: Versionsverträglichkeit zwischen App und Konto-Dienst. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});

const APP = 'https://app.example.org';
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) { return Object.assign({ DB: neueDatenbank(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, extra || {}); }
async function ruf(env, methode, weg, opt) {
  const d = await laden(); const o = opt || {};
  const kopf = Object.assign({ 'CF-Connecting-IP': '203.0.113.5' }, o.ohneOrigin ? {} : { Origin: APP });
  if (o.body !== undefined) kopf['Content-Type'] = 'application/json';
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: o.body === undefined ? undefined : JSON.stringify(o.body) }), env, { jetzt: () => Date.UTC(2026, 10, 17, 8, 0, 0) });
  return { status: r.status, json: await r.json() };
}
const PW = 'Sehr-sicheres-Passwort-1';

test('Versionen vergleichen: Zahlen, nicht Text (2.0.100 ist kleiner als 2.1.25, 2.0.9 kleiner als 2.0.10)', async () => {
  const d = await laden();
  assert.equal(d.appVersionVergleich('2.0.67', '2.1.25'), -1);
  assert.equal(d.appVersionVergleich('2.0.9', '2.0.10'), -1);
  assert.equal(d.appVersionVergleich('2.1.0', '2.0.101'), 1);
  assert.equal(d.appVersionVergleich('2.0.101', '2.0.101'), 0);
  assert.equal(d.appVersionVergleich('Quatsch', '2.0.100'), 0, 'ungültig gilt als keine Angabe (2.0.100)');
  assert.deepEqual(d.appVersionTeile('2.0.101'), [2, 0, 101]); assert.equal(d.appVersionTeile('2.0'), null); assert.equal(d.appVersionTeile(null), null);
});

test('Mindestversion: Standard 2.0.100, mit gültiger Variable APP_MINDESTVERSION überschreibbar, Unsinn wird ignoriert', async () => {
  const d = await laden();
  assert.equal(d.appMindestversion({}), '2.0.100');
  assert.equal(d.appMindestversion({ APP_MINDESTVERSION: ' 2.1.0 ' }), '2.1.0');
  assert.equal(d.appMindestversion({ APP_MINDESTVERSION: 'neu' }), '2.0.100');
  assert.equal(d.appMindestversion(null), '2.0.100');
});

test('Standard: App ohne Angabe (alte App), mit 2.0.100 und mit 2.0.101 kommen durch', async () => {
  const env = umgebung();
  for (const q of ['', '?app=2.0.100', '?app=2.0.101', '?app=2.1.25']) {
    const r = await ruf(env, 'GET', '/konto/ich' + q);
    assert.notEqual(r.status, 426, q);
  }
});

test('Zu alte App: Antwort 426 mit „Bitte zuerst aktualisieren“ und der Mindestversion', async () => {
  const env = umgebung({ APP_MINDESTVERSION: '2.1.0' });
  const r = await ruf(env, 'GET', '/konto/ich?app=2.0.67');
  assert.equal(r.status, 426);
  assert.equal(r.json.ok, false); assert.equal(r.json.appZuAlt, true); assert.equal(r.json.mindestversion, '2.1.0');
  assert.match(r.json.error, /Bitte zuerst aktualisieren/);
  const ohne = await ruf(env, 'GET', '/konto/ich');
  assert.equal(ohne.status, 426, 'ohne Angabe gilt die App als 2.0.100');
  const ok = await ruf(env, 'GET', '/konto/ich?app=2.1.0'); assert.notEqual(ok.status, 426);
  const post = await ruf(env, 'POST', '/konto/anmelden?app=2.0.101', { body: { email: 'a@b.de', passwort: PW } });
  assert.equal(post.status, 426, 'auch bei POST mit Inhalt');
});

test('Gesundheit bleibt für jede App offen und nennt die Mindestversion; Aufrufe ohne Origin (Freischalt-Seite) werden nicht geprüft', async () => {
  const env = umgebung({ APP_MINDESTVERSION: '2.1.0' });
  const g = await ruf(env, 'GET', '/gesundheit?app=1.0.0');
  assert.equal(g.status, 200); assert.equal(g.json.app.mindestversion, '2.1.0');
  const seite = await ruf(env, 'POST', '/freischalten/liste', { ohneOrigin: true, body: {} });
  assert.notEqual(seite.status, 426);
});

test('Die App hängt ihre Version an jede Anfrage an und versteht die Antwort 426', async () => {
  require('../js/version.js'); require('../js/konto.js');
  const MM = globalThis.MM;
  const q = fs.readFileSync(path.join(__dirname, '..', 'js/daten.js'), 'utf8');
  assert.match(q, /function mitAppVersion\(url\)/);
  assert.equal((q.match(/url = mitAppVersion\(url\);/g) || []).length, 2, 'JSON- und Byte-Weg');
  assert.match(q, /app=' \+ encodeURIComponent\(MM\.VERSION\)/);
  const e1 = Object.assign(new Error('Bitte zuerst aktualisieren.'), { status: 426, appZuAlt: true });
  assert.equal(MM.Konto.fehlerText(e1), MM.Konto.TEXT_APP_ZU_ALT);
  assert.match(MM.Konto.TEXT_APP_ZU_ALT, /^Bitte zuerst aktualisieren/);
  assert.match(MM.Konto.fehlerText({ status: 403, message: 'Diese App-Adresse ist beim Dienst nicht erlaubt.' }), /ERLAUBTE_URSPRUENGE/, 'andere Fehler unverändert');
});

test('Der Standard der Mindestversion liegt unter der aktuellen App-Version (sonst sperrt sich die eigene App aus)', async () => {
  require('../js/version.js'); const d = await laden();
  assert.ok(d.appVersionVergleich(d.APP_MINDESTVERSION_STANDARD, globalThis.MM.VERSION) <= 0);
});
