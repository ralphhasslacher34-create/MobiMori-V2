'use strict';
/* 2.0.85: Reisebuch mit den Zahlen dieser Reise (Strecke, Zeit, Treibstoff, Versorgung, Störungen, Nächte nach Platzart, Tagesabschluss) und Titelseite. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'etappen', 'reisecheck', 'fahrt', 'pdf', 'reisebuch', 'daten']
  .forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');
const alsText = (b) => Buffer.from(b).toString('latin1');

const ev = (o) => Object.assign({ id: 'x' + Math.random(), abschnittId: 't1', artName: 'Notiz', datum: '2026-07-01', zeit: '10:00', text: '', ausgeblendet: false, tankGebucht: false, tankArt: null, menge: null, kraftstoff: '', tankName: '', verbrauch: null, einschraenkung: '' }, o);
const gesch = (id, abschnittId, km, fahrt, einheit) => ev({ id, abschnittId, artName: 'Geschwindigkeit', text: 'Geschwindigkeit (Tagesabschluss): Ø fahrend 80,0 km/h, Ø Tag 60,0 km/h, Strecke ' + km + ' ' + (einheit || 'km') + ', Fahrzeit ' + fahrt + ', Gesamtzeit 5 h 00 min. Aus den GPS-Punkten gerechnet, Luftlinie von Punkt zu Punkt.' });

const basis = (extra) => Object.assign({
  titel: 'Sommer', vonDatum: '2026-07-01', bisDatum: '2026-07-04', welt: 'land', einheit: 'km', fahrzeug: { name: 'Wohnmobil', artName: 'Wohnmobil' },
  start: '', ziel: '', zwischenziele: [], besatzung: [], tiere: [], streckeSumme: 0, besuche: [], kosten: null, ortarten: {}, rohEreignisse: [],
  tage: [1, 2, 3, 4].map((n) => ({ id: 't' + n, datum: '2026-07-0' + n, ereignisse: [], abschlussZiel: '', abschlussNotiz: '' }))
}, extra || {});

test('Strecke und Zeit: nur aus den Tagesabschlüssen, Summe und je Tag, ohne Geschwindigkeit in der Ereignisliste', () => {
  const roh = basis({ rohEreignisse: [gesch('g1', 't1', '120,5', '2 h 05 min'), gesch('g2', 't2', '1.050,0', '10 h 30 min'), ev({ abschnittId: 't1', text: 'Geschwindigkeit (automatisch): Strecke 5,0 km, Fahrzeit 1 h 00 min' })] });
  roh.tage[0].ereignisse = [{ id: 'g1', zeit: '23:59', art: 'Geschwindigkeit', text: 'x', ort: '', hatFoto: false, ausgeblendet: false }, { id: 'n1', zeit: '10:00', art: 'Notiz', text: 'ok', ort: '', hatFoto: false, ausgeblendet: false }];
  const b = MM.Reisebuch.bauen(roh);
  assert.ok(b.zahlen.some((z) => z[0] === 'Gefahrene Strecke' && z[1] === '1170,5 km'));
  assert.ok(b.zahlen.some((z) => z[0] === 'Gefahrene Zeit' && z[1] === '12 h 35 min'));
  assert.deepEqual(b.tage[0].zeilen.find((z) => z[0] === 'Gefahren'), ['Gefahren', '120,5 km in 2 h 05 min']);
  assert.deepEqual(b.tage[0].ereignisse.map((e) => e.art), ['Notiz'], 'der Tageswert steht in der Zeile, nicht noch einmal als Ereignis');
  const ohne = MM.Reisebuch.bauen(basis());
  assert.ok(!ohne.zahlen.some((z) => z[0] === 'Gefahrene Strecke'), 'ohne Tagesabschluss wird nichts geschätzt');
  assert.ok(!ohne.tage[0].zeilen.some((z) => z[0] === 'Gefahren'));
});

test('Strecke in Seemeilen bei Wasserfahrzeugen, ausgeblendete Einträge zählen nicht', () => {
  const roh = basis({ welt: 'wasser', rohEreignisse: [gesch('g1', 't1', '12,3', '3 h 00 min', 'sm'), Object.assign(gesch('g2', 't2', '99,0', '9 h 00 min', 'sm'), { ausgeblendet: true })] });
  const b = MM.Reisebuch.bauen(roh);
  assert.ok(b.zahlen.some((z) => z[0] === 'Gefahrene Strecke' && z[1] === '12,3 sm'));
  assert.ok(b.zahlen.some((z) => z[0] === 'Gefahrene Zeit' && z[1] === '3 h 00 min'));
});

test('Treibstoff, Versorgung und Entsorgung: Summen je Stoff, 0 Liter zählt nicht', () => {
  const t = (o) => ev(Object.assign({ tankGebucht: true, tankArt: 'auf' }, o));
  const roh = basis({ rohEreignisse: [
    t({ kraftstoff: 'Diesel', menge: 60, verbrauch: { liter: 50, tage: 2, km: 400 } }), t({ kraftstoff: 'Diesel', menge: 40.5, verbrauch: { liter: 30, tage: 1, km: 200 } }),
    t({ kraftstoff: 'Diesel', menge: 0 }), t({ kraftstoff: 'Frischwasser', menge: 80 }),
    t({ kraftstoff: 'Grauwasser', tankArt: 'leer', menge: null }), t({ kraftstoff: 'Schwarzwasser (Fäkalien)', tankArt: 'leer', menge: 20 }),
    t({ kraftstoff: 'Gas (Flüssiggas)', tankArt: 'flasche' }), t({ kraftstoff: 'Diesel', menge: 99, ausgeblendet: true })
  ] });
  const b = MM.Reisebuch.bauen(roh);
  const a = b.abschnitte.find((x) => x.titel === 'Treibstoff und Versorgung');
  const wert = (n) => (a.zeilen.find((z) => z[0] === n) || [])[1];
  assert.equal(wert('Getankt: Diesel'), '100,5 l (2 Tankungen)');
  assert.equal(wert('Aufgefüllt: Frischwasser'), '80 l (1-mal)');
  assert.equal(wert('Entleert: Grauwasser'), '1-mal');
  assert.equal(wert('Entleert: Schwarzwasser (Fäkalien)'), '1-mal, zusammen 20 l');
  assert.equal(wert('Flasche getauscht: Gas (Flüssiggas)'), '1-mal');
  assert.match(wert('Verbrauch, aus dem Füllstand gerechnet'), /^80 l in 3 Tagen \(26,67 l je Tag, 0,13 l je km\)$/);
  assert.ok(!JSON.stringify(a).includes('99'));
  assert.equal(MM.Reisebuch.bauen(basis()).abschnitte.filter((x) => x.titel === 'Treibstoff und Versorgung').length, 0);
});

test('Störungen: Anzahl und Liste, ausgeblendete nicht', () => {
  const roh = basis({ rohEreignisse: [ev({ artName: 'Störung', datum: '2026-07-02', zeit: '14:00', text: 'Kühlschrank aus', einschraenkung: 'kann weiterfahren' }), ev({ artName: 'Störung', text: 'GEHEIM', ausgeblendet: true }), ev({ artName: 'Notiz' })] });
  const b = MM.Reisebuch.bauen(roh);
  assert.ok(b.zahlen.some((z) => z[0] === 'Störungen' && z[1] === '1'));
  assert.equal(b.stoerungen.length, 1);
  assert.equal(b.stoerungen[0].text, 'Kühlschrank aus');
  assert.ok(!JSON.stringify(b).includes('GEHEIM'));
  assert.ok(MM.Reisebuch.bauen(basis()).zahlen.some((z) => z[0] === 'Störungen' && z[1] === 'keine'));
});

test('Nächte nach Platzart: Wohnmobil, Boot, frei nur mit Tagesabschluss, Heimat und letzter Tag ohne Angabe zählen nicht', () => {
  const besuche = [{ ortId: 'o1', datum: '2026-07-01', zeit: '18:00' }, { ortId: 'o2', datum: '2026-07-02', zeit: '17:00' }, { ortId: 'o1', datum: '2026-07-02', zeit: '09:00' }, { ortId: 'oh', datum: '2026-07-04', zeit: '20:00' }];
  const roh = basis({ besuche, ortarten: { o1: 'camping', o2: 'stellplatz', oh: 'heimat' } });
  roh.tage[2].abschlussZiel = 'am See';
  const b = MM.Reisebuch.bauen(roh);
  const n = b.abschnitte.find((x) => x.titel === 'Übernachtungen');
  assert.deepEqual(n.zeilen, [['Nächte auf Campingplatz', '1'], ['Nächte auf Stellplatz', '1'], ['Nächte frei stehend', '1']]);
  assert.match(n.hinweis, /„frei“/);
  assert.ok(b.zahlen.some((z) => z[0] === 'Nächte mit Platz' && z[1] === '3'));
  const boot = MM.Reisebuch.bauen(basis({ welt: 'wasser', besuche: [{ ortId: 'h', datum: '2026-07-01', zeit: '19:00' }, { ortId: 'a', datum: '2026-07-02', zeit: '19:00' }], ortarten: { h: 'hafen', a: 'anker' } }));
  const bn = boot.abschnitte.find((x) => x.titel === 'Übernachtungen');
  assert.deepEqual(bn.zeilen.slice(0, 3), [['Nächte im Hafen', '1'], ['Nächte vor Anker', '1'], ['Nächte frei liegend', '0']]);
  assert.deepEqual(bn.zeilen[3], ['Tage ohne Angabe', '1'], 'Tag 3 ohne Angabe; der letzte Tag zählt dabei nicht');
  const eintag = MM.Reisebuch.bauen(basis({ bisDatum: '2026-07-01', tage: [basis().tage[0]] }));
  assert.ok(!eintag.abschnitte.some((x) => x.titel === 'Übernachtungen'), 'Ein Tagesausflug hat keine Nacht');
});

test('Tagesabschluss: tatsächliches Ziel immer, Notiz nur mit Notizen; Kosten weiter nur auf Wunsch', () => {
  const roh = basis(); roh.tage[0].abschlussZiel = 'Ulm'; roh.tage[0].abschlussNotiz = 'Schöner Tag';
  const b = MM.Reisebuch.bauen(roh);
  assert.deepEqual(b.tage[0].zeilen.find((z) => z[0] === 'Tatsächliches Ziel'), ['Tatsächliches Ziel', 'Ulm']);
  assert.equal(b.tage[0].abschluss, 'Schöner Tag');
  assert.equal(MM.Reisebuch.bauen(roh, { notizen: false }).tage[0].abschluss, '');
  assert.equal(b.kosten, null);
});

test('PDF: eigene Titelseite, danach die Reise ab Seite 2; Zahlen und Störungen stehen im PDF', () => {
  const roh = basis({ rohEreignisse: [gesch('g1', 't1', '10,0', '1 h 00 min'), ev({ artName: 'Störung', text: 'Kühlschrank aus' })] });
  const b = MM.Reisebuch.bauen(roh);
  const p = MM.Reisebuch.pdf(b, {}, { datum: '2026-11-15T10:00:00Z' });
  const t = alsText(p.bytes);
  assert.match(t, /\/Count (\d+)/);
  assert.ok(Number(/\/Count (\d+)/.exec(t)[1]) >= 2, 'Titelseite plus Inhalt');
  assert.ok(t.includes('REISEBUCH') && t.includes('Sommer'));
  assert.ok(t.includes('Gefahrene Strecke') && t.includes('Kuehlschrank') === false);
  const d = MM.Pdf.neu({ fuss: 'x' });
  d.titelseite({ kopf: 'Reisebuch', titel: 'Ein sehr langer Titel für eine Reise rund um die Welt in achtzig Tagen und mehr', untertitel: '01.07.2026', zeilen: [['Fahrzeug', 'Wohnmobil']], fuss: 'Erstellt mit MobiMory' });
  assert.equal(d.seitenAnzahl(), 2, 'Nach der Titelseite beginnt eine neue Seite');
});

test('Seite und Daten: Abschnitte, Störungen und Tagesabschluss stehen in der Seite, die Daten liefern die Rohangaben', () => {
  const a = lesen('js/ansicht.js');
  assert.ok(a.includes("buch.abschnitte || []") && a.includes("h('h3', { text: 'Störungen' })") && a.includes("'Tagesabschluss: ' + t.abschluss"));
  const dd = lesen('js/daten.js');
  assert.ok(dd.includes('Daten.prototype.reiseRohEreignisse') && dd.includes("abschlussZiel: tw.zielTatsaechlich") && dd.includes('ortarten: ortarten, rohEreignisse: rohEv'));
});

async function reise() {
  let t = 0; const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(), holeJson: async () => { throw new Error('kein Netz'); } });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen(); await d.ereignisartenAusVorschlaegen();
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'] })).id;
  const artId = (await d.aktivitaetsartenListe()).find((x) => x.aktuell.werte.bezeichnung === 'Urlaub').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Reise', artId, fahrzeugId: wm, vonDatum: '2026-11-01', vonZeit: '08:00', bisDatum: '2026-11-02', verantwortlichId: anna });
  await d.tagesabschnitteVorbereiten(r.id);
  return { d, id: r.id };
}

test('Daten: Reisebuch liest Tagesabschluss, Tageswert und Störung aus einer echten Reise und ändert nichts', async () => {
  const { d, id } = await reise();
  const lb = await d.logbuchLaden(id);
  const tag = lb.abschnitte[0].objekt.id;
  assert.equal((await d.tagesabschlussSpeichern(tag, { zielTatsaechlich: 'Ulm', abschlussNotiz: 'Schön' })).ok, true);
  const gArt = await d.geschwindigkeitsArtSichern();
  const text = MM.Fahrt.eintragText({ aktuellKmh: 0, fahrendKmh: 80, tagKmh: 60, km: 123.4, fahrMs: 2 * 3600000 + 5 * 60000, gesamtMs: 5 * 3600000 }, 'land', 'tag');
  const rg = await d.ereignisAnlegen(tag, { artId: gArt, datum: '2026-11-01', zeit: '23:59', text }, { nachtragen: true }); assert.equal(rg.ok, true, JSON.stringify(rg));
  const sArt = (await d.ereignisartenListe()).find((x) => x.aktuell.werte.bezeichnung === 'Störung').objekt.id;
  assert.equal((await d.ereignisAnlegen(tag, { artId: sArt, datum: '2026-11-01', zeit: '14:00', text: 'Kühlschrank aus' })).ok, true);
  const vorher = JSON.stringify([await d.speicher.alle('verlaeufe'), await d.speicher.alle('ereignisse')]);
  const roh = await d.reisebuchLaden(id);
  assert.equal(roh.tage[0].abschlussZiel, 'Ulm');
  assert.equal(roh.tage[0].abschlussNotiz, 'Schön');
  assert.ok(roh.rohEreignisse.some((e) => e.artName === 'Geschwindigkeit'));
  const b = MM.Reisebuch.bauen(roh);
  assert.ok(b.zahlen.some((z) => z[0] === 'Gefahrene Strecke' && z[1] === '123,4 km'), JSON.stringify(b.zahlen));
  assert.ok(b.zahlen.some((z) => z[0] === 'Gefahrene Zeit' && z[1] === '2 h 05 min'));
  assert.ok(b.zahlen.some((z) => z[0] === 'Störungen' && z[1] === '1'));
  assert.deepEqual(b.tage[0].zeilen.find((z) => z[0] === 'Tatsächliches Ziel'), ['Tatsächliches Ziel', 'Ulm']);
  assert.ok(b.abschnitte.some((x) => x.titel === 'Übernachtungen'));
  const p = await d.reisebuchPdf(id, {});
  assert.equal(p.ok, true);
  assert.equal(JSON.stringify([await d.speicher.alle('verlaeufe'), await d.speicher.alle('ereignisse')]), vorher, 'Das Reisebuch ändert nichts');
});
