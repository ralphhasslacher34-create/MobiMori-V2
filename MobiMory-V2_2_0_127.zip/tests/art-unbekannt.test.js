'use strict';
/* 2.0.82: unbekannte Fahrzeugart darf nichts zum Absturz bringen (zum Beispiel nach Übergabe oder Freigabe, wenn dem Empfänger die Art fehlt). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'reisecheck', 'grundcheck', 'abgleich', 'freigaben', 'konto', 'daten']
  .forEach((n) => { try { require('../js/' + n + '.js'); } catch (e) { if (e.code !== 'MODULE_NOT_FOUND') throw e; } });
const MM = globalThis.MM;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

test('artSicher liefert für eine fehlende Art einen Platzhalter, für eine echte Art die Art', () => {
  const x = MM.Fahrzeugarten.artSicher('gibt-es-nicht');
  assert.equal(x.name, 'Art unbekannt');
  assert.equal(x.welt, 'land');
  assert.equal(x.id, 'gibt-es-nicht');
  assert.equal(MM.Fahrzeugarten.artSicher('motorboot').id, 'motorboot');
  assert.equal(MM.Fahrzeugarten.gruppen('gibt-es-nicht').length, 0);
});

test('keine Stelle im Code liest die Fahrzeugart direkt weiter, ohne zu prüfen', () => {
  ['js/ansicht.js', 'js/daten.js'].forEach((f) => {
    const treffer = lesen(f).split('\n').filter((z) => /Fahrzeugarten\.art\([^)]*\)\.[a-z]/.test(z) && !/Fahrzeugarten\.art\([^)]*\)\s*\?/.test(z));
    assert.deepEqual(treffer, [], f);
  });
});

async function geraet() {
  let n = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(2026, 10, 15, 12, 0, 0).getTime() + (n++) * 1000).toISOString() });
  await d.starten();
  return d;
}
async function unbekannt(d) {
  const r = await d.fahrzeugAnlegen('motorboot', { bezeichnung: 'Fremdboot' });
  const rec = await d.speicher.holen('fahrzeuge', r.id);
  await d.speicher.speichern('fahrzeuge', Object.assign({}, rec, { art: 'art-fehlt' }));
  return r.id;
}

test('Fahrzeug mit unbekannter Art: Status und Art-Wechsel stürzen nicht ab', async () => {
  const d = await geraet();
  const id = await unbekannt(d);
  const s = await d.fahrzeugStatus(id);
  assert.ok(s);
  const v = await d.artWechselVorschau(id, 'wohnmobil');
  assert.equal(v.ok, true);
  assert.equal(v.alt.name, 'Art unbekannt');
  const liste = await d.fahrzeugListe({ alle: true });
  assert.equal(liste.length, 1);
});
