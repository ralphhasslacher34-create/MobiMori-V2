'use strict';
/* 2.0.76 (Bau 2, Dienst 13f-3): Info-Mail an den Besitzer bei einer Störung des Gastes, frühere Störungen für Gäste mit „mitnutzen“. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

const APP = 'https://app.example.org';
const PW = 'Sehr-sicheres-Passwort-1';
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) { return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, extra || {}); }
/* Eine Mail-Attrappe: sammelt, was gesendet wird. */
function mitMail(fehler) {
  const mails = [];
  const env = umgebung();
  /* Die Mail-Attrappe wird erst nach dem Einrichten eingehängt (sonst kommen die Codes nur per Mail). */
  const an = () => { env.ABSENDER = 'info@mobimory.example'; env.EMAIL = { send: async (m) => { if (fehler && /Störung/.test(m.subject)) throw new Error('kaputt'); mails.push(m); } }; };
  return { env, mails, an, stoerungen: () => mails.filter((m) => /Störung/.test(m.subject)) };
}
function uhr() { const u = { t: Date.UTC(2026, 10, 11, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
async function roh(env, u, methode, weg, body, token) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  return d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
}
async function ruf(env, u, methode, weg, body, token) { const r = await roh(env, u, methode, weg, body, token); return { status: r.status, json: await r.json() }; }
async function konto(env, u, email) {
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email, passwort: PW });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode });
  return b.json.token;
}
function satz(tabelle, o) { return { tabelle, id: o.id, basis: 0, nutzlast: JSON.stringify(o) }; }
async function senden(env, u, tok, liste) {
  const r = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: liste }, tok);
  assert.equal(r.status, 200, JSON.stringify(r.json));
}
/* Besitzer mit einem Fahrzeug, früheren Störungen (eine erledigt mit Notiz, eine an einem anderen Fahrzeug) und einem Betrag. */
async function besitzer(env, u) {
  const tok = await konto(env, u, 'besitzer@example.org');
  await senden(env, u, tok, [
    satz('fahrzeuge', { id: 'fz-1', datenraumId: '@', art: 'wohnmobil', erstelltAm: 1 }),
    satz('fahrzeuge', { id: 'fz-2', datenraumId: '@', art: 'motorboot', erstelltAm: 1 }),
    satz('eintraege', { id: 'en-1', fahrzeugId: 'fz-1', nr: 1, werte: { bezeichnung: 'Mein Wohnmobil' }, erstelltAm: 1 }),
    satz('vorgaenge', { id: 'vg-1', fahrzeugId: 'fz-1', komponenteId: null, erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-vg-1', objektTyp: 'vorgang', objektId: 'vg-1', nr: 1, werte: { bezeichnung: 'Kühlschrank läuft nicht', art: 'arbeit', status: 'erledigt', auswirkung: 'keine', gemeldetAm: '2026-07-30', erledigtAm: '2026-08-01', ausfuehrung: 'selbst', arbeit: 'Sicherung getauscht' }, erstelltAm: 1 }),
    satz('vorgaenge', { id: 'vg-2', fahrzeugId: 'fz-2', komponenteId: null, erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-vg-2', objektTyp: 'vorgang', objektId: 'vg-2', nr: 1, werte: { bezeichnung: 'Bootsmotor raucht', art: 'stoerung', status: 'offen', auswirkung: 'nicht', gemeldetAm: '2026-09-01' }, erstelltAm: 1 }),
    satz('kosten', { id: 'ko-1', datenraumId: '@', fahrzeugId: 'fz-1', vorgangId: 'vg-1', erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-ko-1', objektTyp: 'kosten', objektId: 'ko-1', nr: 1, werte: { betrag: 4321.5, bezeichnung: 'Teuer' }, erstelltAm: 1 })
  ]);
  return tok;
}
async function gastFreigabe(env, u, tok, extra) {
  const gast = await konto(env, u, 'gast@example.org');
  const e = await ruf(env, u, 'POST', '/freigabe/einladen', Object.assign({ fahrzeugId: 'fz-1', email: 'gast@example.org', bis: '2027-03-31', nachweisArt: 'Führerschein', nachweisBis: '', bestaetigt: true }, extra || {}), tok);
  assert.equal(e.status, 200, JSON.stringify(e.json));
  const a = await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, gast);
  assert.equal(a.status, 200, JSON.stringify(a.json));
  return { gast, id: e.json.id };
}
const MIT = { rechte: 'mitnutzen', gastName: 'Anna' };
const melden = (env, u, g, extra) => ruf(env, u, 'POST', '/geteilt/erfassen', Object.assign({ freigabe: g.id, art: 'stoerung', bezeichnung: 'Kühlschrank geht nicht', beschreibung: 'Seit Malmö aus', auswirkung: 'bedingt' }, extra || {}), g.gast);
const nutz = (e) => JSON.parse(e.nutzlast);

test('Störung durch den Gast: Der Besitzer bekommt eine Info-Mail mit Namen, Fahrzeug, Text und Einschränkung', async () => {
  const m = mitMail(), u = uhr(), tok = await besitzer(m.env, u), g = await gastFreigabe(m.env, u, tok, MIT);
  m.an();
  const r = await melden(m.env, u, g);
  assert.equal(r.status, 200, JSON.stringify(r.json)); assert.equal(r.json.mail, true);
  const s = m.stoerungen();
  assert.equal(s.length, 1);
  assert.equal(s[0].to, 'besitzer@example.org');
  assert.match(s[0].subject, /Störung an „Mein Wohnmobil“ gemeldet/);
  assert.match(s[0].text, /Anna hat an „Mein Wohnmobil“ eine Störung gemeldet/);
  assert.match(s[0].text, /Kühlschrank geht nicht/); assert.match(s[0].text, /Seit Malmö aus/); assert.match(s[0].text, /nur bedingt einsatzfähig/);
  assert.match(s[0].text, /nur zur Information/);
  assert.ok(!/gast@example\.org/.test(s[0].text), 'mit Namen angegeben, die Adresse steht nicht drin');
});

test('Kilometer und Kosten lösen keine Mail aus, und die Antwort hat dann kein Feld „mail“', async () => {
  const m = mitMail(), u = uhr(), tok = await besitzer(m.env, u), g = await gastFreigabe(m.env, u, tok, MIT);
  m.an();
  const k = await ruf(m.env, u, 'POST', '/geteilt/erfassen', { freigabe: g.id, art: 'kosten', gruppe: 'variabel', bezeichnung: 'Diesel', betrag: 50 }, g.gast);
  assert.equal(k.status, 200); assert.equal(k.json.mail, undefined);
  assert.equal(m.stoerungen().length, 0);
});

test('Geht die Mail schief, ist die Störung trotzdem gespeichert; ohne Mail-Dienst genauso', async () => {
  const m = mitMail(true), u = uhr(), tok = await besitzer(m.env, u), g = await gastFreigabe(m.env, u, tok, MIT);
  m.an();
  const r = await melden(m.env, u, g);
  assert.equal(r.status, 200, JSON.stringify(r.json)); assert.equal(r.json.mail, false);
  const alle = (await ruf(m.env, u, 'GET', '/abgleich/aenderungen?seit=0', undefined, tok)).json.eintraege;
  assert.ok(alle.some((e) => e.id === r.json.id && e.tabelle === 'vorgaenge'));
  const env = umgebung(), u2 = uhr(), tok2 = await besitzer(env, u2), g2 = await gastFreigabe(env, u2, tok2, MIT);
  const r2 = await melden(env, u2, g2);
  assert.equal(r2.status, 200); assert.equal(r2.json.mail, false);
});

test('Bremse: höchstens 5 Mails je Freigabe und Stunde, die Meldungen gehen trotzdem durch; nach einer Stunde wieder', async () => {
  const m = mitMail(), u = uhr(), tok = await besitzer(m.env, u), g = await gastFreigabe(m.env, u, tok, MIT);
  m.an();
  for (let i = 0; i < 7; i++) { const r = await melden(m.env, u, g, { bezeichnung: 'Störung Nr. ' + i }); assert.equal(r.status, 200); assert.equal(r.json.mail, i < 5, 'Meldung ' + i); }
  assert.equal(m.stoerungen().length, 5);
  u.t += 61 * 60 * 1000;
  assert.equal((await melden(m.env, u, g)).json.mail, true);
  assert.equal(m.stoerungen().length, 6);
});

test('Mit „mitnutzen“ sieht der Gast frühere Störungen und Arbeiten dieses Fahrzeugs (nur Texte); mit „nur lesen“ und über den Kontroll-Code nicht', async () => {
  const env = umgebung(), u = uhr(), tok = await besitzer(env, u), g = await gastFreigabe(env, u, tok, MIT);
  const j = (await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast)).json;
  const tabellen = j.datensaetze.map((x) => x.tabelle);
  assert.ok(tabellen.includes('vorgaenge'));
  const ids = j.datensaetze.filter((x) => x.tabelle === 'vorgaenge').map((x) => x.id);
  assert.deepEqual(ids, ['vg-1'], 'nur dieses Fahrzeug');
  const verlauf = j.datensaetze.filter((x) => x.tabelle === 'verlaeufe').map(nutz).find((v) => v.objektTyp === 'vorgang');
  assert.equal(verlauf.werte.arbeit, 'Sicherung getauscht');
  assert.ok(!tabellen.includes('kosten'), 'keine Kosten');
  assert.ok(!JSON.stringify(j).includes('4321'), 'kein Betrag');
});

test('Nur ansehen: keine Vorgänge für den Gast; Kontroll-Code: auch nicht', async () => {
  const env = umgebung(), u = uhr(), tok = await besitzer(env, u), g = await gastFreigabe(env, u, tok);
  const j = (await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast)).json;
  assert.ok(!j.datensaetze.some((x) => x.tabelle === 'vorgaenge'));
  const k = await ruf(env, u, 'POST', '/kontrolle/erstellen', { fahrzeugId: 'fz-1', stunden: 2 }, tok);
  assert.equal(k.status, 200, JSON.stringify(k.json));
  const l = await ruf(env, u, 'GET', '/kontrolle/lesen?code=' + k.json.code);
  assert.equal(l.status, 200, JSON.stringify(l.json));
  assert.ok(!l.json.datensaetze.some((x) => x.tabelle === 'vorgaenge'));
});

test('Dienst 13f-3: Version, Gesundheit, Anleitung, keine neue SQL-Zeile', async () => {
  const d = await laden();
  assert.equal(d.VERSION, '13h');
  const g = (await ruf(umgebung(), uhr(), 'GET', '/gesundheit')).json;
  assert.equal(g.version, '13h'); assert.equal(g.stoerungsmail, true);
  assert.ok(!fs.existsSync(path.join(__dirname, '..', 'server', '13f-3.sql')), 'keine neue SQL-Datei');
  assert.ok(fs.readFileSync(path.join(__dirname, '..', 'server', 'EINRICHTUNG.md'), 'utf8').includes('Update auf 13f-3'));
  assert.deepEqual(Object.keys(d.STOERUNG_AUSWIRKUNG_TEXT), d.GAST_AUSWIRKUNGEN);
});
