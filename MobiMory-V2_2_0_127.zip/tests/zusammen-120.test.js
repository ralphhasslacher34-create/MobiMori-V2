'use strict';
/* 2.0.120: Weg, Fahrtwerte und Kilometer zweier Geräte werden zusammengeführt. */
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/karte.js');
require('../js/routen.js');
require('../js/fahrt.js');
const MM = global.MM;

test('Weg: Punkte beider Geräte werden nach Zeit gemischt, gleiche Sekunde nur einmal', () => {
  const a = { punkte: [[48.0, 9.0, 100, 0], [48.001, 9.0, 160, 0]] };
  const b = { punkte: [[48.0005, 9.0, 130, 0], [48.001, 9.0, 160, 0]] };
  const m = MM.Karte.wegZusammen(a, b);
  const sek = m.punkte.map((p) => p[2]);
  assert.deepEqual(sek, sek.slice().sort((x, y) => x - y));
  assert.equal(new Set(sek).size, sek.length);
});

test('Kilometer: je Minute der größere Wert, Summe stimmt', () => {
  const a = { km: 0, mi: { 10: 0.5, 11: 0.4 }, ab: 0 };
  const b = { km: 0, mi: { 10: 0.3, 11: 0.6, 12: 0.2 }, ab: 0 };
  const m = MM.Routen.spurZusammen(a, b);
  assert.equal(m.mi[10], 0.5); assert.equal(m.mi[11], 0.6); assert.equal(m.mi[12], 0.2);
  assert.ok(Math.abs(m.km - 1.3) < 1e-9);
});

test('Kilometer: nach „übernehmen“ zählt nichts vor der Reset-Marke', () => {
  const a = { km: 0, mi: { 10: 0.5 }, ab: 11 * 60000 };
  const b = { km: 0, mi: { 10: 0.9, 12: 0.1 }, ab: 0 };
  const m = MM.Routen.spurZusammen(a, b);
  assert.equal(m.mi[10], undefined); assert.ok(Math.abs(m.km - 0.1) < 1e-9);
});
