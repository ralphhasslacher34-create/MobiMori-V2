'use strict';
/* 2.0.120 (Dienst 13h): Alarm-Nachrichten an die angemeldeten Geräte. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');

const APP = 'https://app.example.org';
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function uhr() { const u = { t: Date.UTC(2026, 10, 10, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
const PW = 'Sehr-sicheres-Passwort-1';

async function ruf(env, u, methode, weg, body, token) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, u.jetzt);
  return { status: r.status, json: await r.json() };
}

async function vapidSchluessel() {
  const k = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
  const jwk = await crypto.subtle.exportKey('jwk', k.privateKey);
  const roh = new Uint8Array(await crypto.subtle.exportKey('raw', k.publicKey));
  return { privat: JSON.stringify(jwk), oeffentlich: Buffer.from(roh).toString('base64url') };
}

async function zweiGeraete(env, u) {
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email: 'wache@example.org', passwort: PW });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'wache@example.org', code: a.json.entwicklungsCode });
  const z = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'wache@example.org', passwort: PW, geraet: 'Tablet' });
  return [b.json.token, z.json.token];
}

test('Alarm: Push geht nur an die anderen Geräte, Text ist allgemein, Mail wird versucht', async () => {
  const v = await vapidSchluessel();
  const gesendet = [];
  const env = { DB: neueDatenbank(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1', VAPID_PRIVAT: v.privat, VAPID_OEFFENTLICH: v.oeffentlich };
  const u = uhr();
  const [t1, t2] = await zweiGeraete(env, u);
  const echt = global.fetch;
  global.fetch = async (url, opt) => { gesendet.push({ url, opt }); return { status: 201, ok: true }; };
  try {
    assert.equal((await ruf(env, u, 'POST', '/push/anmelden', { geraet: 'geraetA1', art: 'web', ziel: 'https://fcm.googleapis.com/fcm/send/AAA' }, t1)).status, 200);
    assert.equal((await ruf(env, u, 'POST', '/push/anmelden', { geraet: 'geraetB2', art: 'web', ziel: 'https://updates.push.services.mozilla.com/wpush/v2/BBB' }, t2)).status, 200);
    const r = await ruf(env, u, 'POST', '/alarm/senden', { geraet: 'geraetA1' }, t1);
    assert.equal(r.status, 200); assert.equal(r.json.push, 1); assert.equal(r.json.fehler, 0);
    assert.equal(gesendet.length, 1);
    assert.equal(gesendet[0].url, 'https://updates.push.services.mozilla.com/wpush/v2/BBB');
    assert.match(gesendet[0].opt.headers.Authorization, /^vapid t=[\w-]+\.[\w-]+\.[\w-]+, k=/);
    assert.equal(gesendet[0].opt.body, undefined);
  } finally { global.fetch = echt; }
});

test('Anmelden: nur https-Adressen bekannter Push-Dienste, fremde und Innenadressen werden abgelehnt', async () => {
  const env = { DB: neueDatenbank(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' };
  const u = uhr();
  const [t1] = await zweiGeraete(env, u);
  for (const ziel of ['http://fcm.googleapis.com/x', 'https://evil.example.com/x', 'https://127.0.0.1/x', 'https://fcm.googleapis.com.evil.com/x', 'https://user@fcm.googleapis.com/x']) {
    const r = await ruf(env, u, 'POST', '/push/anmelden', { geraet: 'geraetA1', art: 'web', ziel }, t1);
    assert.equal(r.status, 400, ziel);
  }
  assert.equal((await ruf(env, u, 'POST', '/push/anmelden', { geraet: 'geraetA1', art: 'web', ziel: 'https://fcm.googleapis.com/fcm/send/AAA' })).status, 401);
});

test('Gelöschte Push-Adresse (410) wird entfernt; abmelden entfernt ebenfalls', async () => {
  const v = await vapidSchluessel();
  const env = { DB: neueDatenbank(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1', VAPID_PRIVAT: v.privat, VAPID_OEFFENTLICH: v.oeffentlich };
  const u = uhr();
  const [t1, t2] = await zweiGeraete(env, u);
  const echt = global.fetch;
  global.fetch = async () => ({ status: 410, ok: false });
  try {
    await ruf(env, u, 'POST', '/push/anmelden', { geraet: 'geraetB2', art: 'web', ziel: 'https://fcm.googleapis.com/fcm/send/BBB' }, t2);
    const r = await ruf(env, u, 'POST', '/alarm/senden', { geraet: 'geraetA1' }, t1);
    assert.equal(r.json.push, 0); assert.equal(r.json.fehler, 1);
    const rest = await env.DB.prepare('SELECT COUNT(*) AS n FROM push_ziel').first();
    assert.equal(rest.n, 0);
  } finally { global.fetch = echt; }
});

test('Schema und Einrichtungsdatei: eine Zeile je Befehl, im Gesamt-Schema enthalten', () => {
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13h.sql'), 'utf8').trim().split('\n');
  const schema = fs.readFileSync(path.join(__dirname, '..', 'server', 'schema.sql'), 'utf8');
  for (const z of sql) assert.ok(schema.includes(z));
});
