'use strict';
/* Baut eine „Seite“ im Format der Texterkennung aus Textzeilen (nur erfundene Daten). Jede Zeile: Text oder { text, x } (x = Einzug in Punkten). */
module.exports = function seite(zeilen, opt) {
  opt = opt || {};
  const MM = globalThis.MM, hoehe = 40, schritt = opt.schritt || 70, breitePro = 22;
  const liste = zeilen.map((z, i) => {
    const text = typeof z === 'string' ? z : z.text, x0 = typeof z === 'string' ? 100 : (z.x || 100), y0 = (typeof z === 'string' ? 0 : (z.y || 0)) + 100 + i * schritt;
    let x = x0;
    const ws = text.split(' ').filter(Boolean).map(t => { const b = { x0: x, y0: y0, x1: x + t.length * breitePro, y1: y0 + hoehe }; x = b.x1 + 14; return { t, konf: opt.konf || 90, b }; });
    return MM.Erfassung.seiteVonWoertern(ws);
  });
  return { breite: 2400, hoehe: 1800, zeilen: liste };
};
