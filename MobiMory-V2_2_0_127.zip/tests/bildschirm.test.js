'use strict';
/* 2.0.101: Bildschirm bleibt an, solange das Cockpit aktiv ist (Wake Lock des Browsers). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/texte.js');
require('../js/bildschirm.js');
const MM = globalThis.MM;
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const warte = () => new Promise(r => setImmediate(r));

/* Nachgebaute Umgebung: Browser mit Wake Lock und sichtbarem oder verstecktem Dokument */
function umgebung(opt) {
  const o = opt || {};
  const doc = { visibilityState: o.versteckt ? 'hidden' : 'visible', _h: {}, addEventListener(n, f) { (this._h[n] = this._h[n] || []).push(f); } };
  const sperren = [];
  const nav = o.ohne ? {} : { wakeLock: { request: async (art) => {
    if (o.ablehnen) { const e = new Error('nein'); e.name = 'NotAllowedError'; throw e; }
    const s = { art, released: false, _h: {}, addEventListener(n, f) { (this._h[n] = this._h[n] || []).push(f); },
      async release() { if (this.released) return; this.released = true; (this._h.release || []).forEach(f => f()); } };
    sperren.push(s); return s;
  } } };
  return { doc, nav, sperren, sichtbar(v) { doc.visibilityState = v ? 'visible' : 'hidden'; (doc._h.visibilitychange || []).forEach(f => f()); },
    vomBrowserFrei() { const s = sperren[sperren.length - 1]; return s.release(); } };
}
function bauen(u) { return MM.Bildschirm.erzeugen({ navigator: u.nav, document: u.doc }); }

test('Cockpit aktiv: der Bildschirm wird mit „screen“ wachgehalten', async () => {
  const u = umgebung(), b = bauen(u);
  assert.equal(b.moeglich(), true); assert.equal(b.status(), 'aus');
  b.an(); await warte();
  assert.equal(u.sperren.length, 1); assert.equal(u.sperren[0].art, 'screen'); assert.equal(b.status(), 'wach');
});

test('Mehrfaches Anschalten (jeder Seitenaufbau) fordert nur eine Sperre an', async () => {
  const u = umgebung(), b = bauen(u);
  b.an(); b.an(); await warte(); b.an(); await warte();
  assert.equal(u.sperren.length, 1);
});

test('Cockpit verlassen: die Sperre wird freigegeben', async () => {
  const u = umgebung(), b = bauen(u);
  b.an(); await warte(); b.aus(); await warte();
  assert.equal(u.sperren[0].released, true); assert.equal(b.status(), 'aus'); assert.equal(b.gewuenscht(), false);
});

test('App im Hintergrund: der Browser gibt frei, beim Zurückkommen wird neu gesetzt', async () => {
  const u = umgebung(), b = bauen(u);
  b.an(); await warte();
  u.sichtbar(false); await u.vomBrowserFrei(); await warte();
  assert.equal(b.status(), 'wartet', 'gewünscht, aber gerade frei');
  u.sichtbar(true); await warte();
  assert.equal(u.sperren.length, 2); assert.equal(b.status(), 'wach'); assert.equal(u.sperren[1].released, false);
});

test('Im Hintergrund wird nichts angefordert, erst beim Sichtbarwerden', async () => {
  const u = umgebung({ versteckt: true }), b = bauen(u);
  b.an(); await warte();
  assert.equal(u.sperren.length, 0); assert.equal(b.status(), 'wartet');
  u.sichtbar(true); await warte();
  assert.equal(u.sperren.length, 1); assert.equal(b.status(), 'wach');
});

test('Nach dem Verlassen des Cockpits wird beim Zurückkommen in die App nichts mehr gesetzt', async () => {
  const u = umgebung(), b = bauen(u);
  b.an(); await warte(); b.aus(); await warte();
  u.sichtbar(false); u.sichtbar(true); await warte();
  assert.equal(u.sperren.length, 1); assert.equal(b.status(), 'aus');
});

test('Wird das Cockpit verlassen, bevor der Browser antwortet, wird die neue Sperre sofort abgegeben', async () => {
  const u = umgebung(), b = bauen(u);
  b.an(); b.aus(); await warte(); await warte();
  assert.equal(u.sperren.length, 1); assert.equal(u.sperren[0].released, true); assert.equal(b.status(), 'aus');
});

test('Aus und gleich wieder an, bevor der Browser antwortet: am Ende ist genau eine Sperre aktiv', async () => {
  const u = umgebung(), b = bauen(u);
  b.an(); b.aus(); b.an(); await warte(); await warte(); await warte();
  assert.equal(b.status(), 'wach');
  assert.equal(u.sperren.filter(s => !s.released).length, 1);
});

test('Browser lehnt ab oder kennt keine Bildschirm-Sperre: kein Fehler, nur der Status', async () => {
  const a = umgebung({ ablehnen: true }), ba = bauen(a);
  assert.doesNotThrow(() => ba.an()); await warte();
  assert.equal(ba.status(), 'abgelehnt');
  const k = umgebung({ ohne: true }), bk = bauen(k);
  assert.equal(bk.moeglich(), false);
  assert.doesNotThrow(() => bk.an()); assert.equal(bk.status(), 'nicht-moeglich');
  assert.doesNotThrow(() => bk.aus());
  const leer = MM.Bildschirm.erzeugen({}); assert.doesNotThrow(() => { leer.an(); leer.aus(); });
});

test('Die App ruft das Wachhalten im Cockpit auf und gibt es auf anderen Seiten frei', () => {
  const a = lesen('js/ansicht.js');
  assert.match(a, /function cockpitVollbild[\s\S]{0,1500}bildschirmAn\(\);/, 'Cockpit-Vollbild');
  assert.match(a, /function cockpitFormularMit[\s\S]{0,200}bildschirmAn\(\);/, 'Formulare des Cockpits');
  assert.match(a, /bildschirmGebraucht = false;/);
  assert.match(a, /if \(!bildschirmGebraucht\) MM\.Bildschirm\.aus\(\);/);
});

test('Der Hinweis zur Aufzeichnung steht im Cockpit, bei der Aktivität und als Text für Homepage und Store', () => {
  const T = MM.Texte.AUFZEICHNUNG;
  ['kurz', 'cockpit', 'wachhalten', 'ohneWachhalten', 'lang', 'werbung', 'store'].forEach(k => assert.ok(T[k] && T[k].length > 20, k));
  assert.match(T.cockpit, /nur bei offener App/);
  assert.match(T.lang, /Android/);
  const a = lesen('js/ansicht.js');
  assert.match(a, /aufzeichnungHinweis\(\),/, 'Seite 1 des Cockpits');
  assert.match(a, /MM\.Texte\.AUFZEICHNUNG\.kurz/, 'Block der Aktivität');
  assert.match(lesen('index.html'), /js\/bildschirm\.js/);
  assert.match(lesen('sw.js'), /js\/bildschirm\.js/);
});
