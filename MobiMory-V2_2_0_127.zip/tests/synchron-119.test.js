'use strict';
/* 2.0.119: Synchron auf allen Geräten: Schlüsselwort (Verschlüsselung der privaten Angaben), automatischer Takt, Standorte und Einstellungen, GPS-Datei. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'konto', 'abgleich', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;

const APP = 'https://app.example.org';
const PW = 'Sehr-sicheres-Passwort-1';
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }

function umgebung(extra) { return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, extra || {}); }
function uhr() { const u = { t: Date.UTC(2026, 10, 10, 12, 0, 0) }; u.jetzt = () => u.t; return u; }

async function ruf(env, u, methode, weg, body, token) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
  return { status: r.status, json: await r.json() };
}

async function konto(env, u, email) {
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email, passwort: PW });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode });
  return b.json.token;
}

function satz(tabelle, id, extra, basis) {
  const o = Object.assign({ id, datenraumId: '@' }, extra || {});
  return { tabelle, id, basis: basis || 0, nutzlast: JSON.stringify(o) };
}

function geraetBauen(env, u) {
  return async function () {
    const d0 = await laden();
    const f = async (url, methode, token, body) => {
      const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.7' };
      if (body !== undefined && body !== null) kopf['Content-Type'] = 'application/json';
      if (token) kopf.Authorization = 'Bearer ' + token;
      const r = await d0.behandeln(new Request(url, { method: methode, headers: kopf, body: body === undefined || body === null ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
      const j = await r.json();
      if (!r.ok) { const e = new Error(j.error); e.status = r.status; throw e; }
      return j;
    };
    const fb = async (url, methode, token, bytes) => {
      const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.7', Authorization: 'Bearer ' + token };
      if (bytes) { kopf['Content-Type'] = 'application/octet-stream'; kopf['Content-Length'] = String(bytes.length); }
      const r = await d0.behandeln(new Request(url, { method: methode, headers: kopf, body: bytes || undefined }), env, { jetzt: u.jetzt });
      if (!r.ok) { const j = await r.json(); const e = new Error(j.error); e.status = r.status; throw e; }
      if (methode === 'GET') return { bytes: new Uint8Array(await r.arrayBuffer()), verschluesselt: r.headers.get('X-Verschluesselt') === '1' };
      return { json: await r.json() };
    };
    let n = 0;
    const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { kontoAnfrage: (...a) => d.netz(...a), kontoBytes: (...a) => d.netzBytes(...a), jetzt: () => new Date(u.t + (n++) * 1000).toISOString() });
    d.netz = f; d.netzBytes = fb;
    await d.starten();
    await d.kontoDienstSpeichern('https://konto.example.workers.dev');
    return d;
  };
}
async function zweiGeraete() {
  const env = umgebung(), u = uhr(), neu = geraetBauen(env, u);
  const a = await neu(), b = await neu();
  const r = await a.kontoRegistrieren({ email: 'anna@example.org', passwort: PW });
  assert.equal((await a.kontoCodePruefen({ email: 'anna@example.org', code: r.entwicklungsCode })).ok, true);
  const c = await b.kontoCodeAnfordern({ email: 'anna@example.org' });
  assert.equal((await b.kontoCodePruefen({ email: 'anna@example.org', code: c.entwicklungsCode })).ok, true);
  return { env, u, a, b, neu };
}

async function zweiGeraete() {
  const env = umgebung(), u = uhr(), neu = geraetBauen(env, u);
  const a = await neu(), b = await neu();
  const r = await a.kontoRegistrieren({ email: 'anna@example.org', passwort: PW });
  assert.equal((await a.kontoCodePruefen({ email: 'anna@example.org', code: r.entwicklungsCode })).ok, true);
  const c = await b.kontoCodeAnfordern({ email: 'anna@example.org' });
  assert.equal((await b.kontoCodePruefen({ email: 'anna@example.org', code: c.entwicklungsCode })).ok, true);
  return { env, u, a, b, neu };
}
async function alleServer(env) { return env.DB.roh.prepare('SELECT tabelle, objekt_id, nutzlast, geloescht FROM abgleich').all(); }
const WORT = 'Rotes Segelboot 77';

async function bytesRuf(env, u, methode, weg, bytes, token) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (token) kopf.Authorization = 'Bearer ' + token;
  if (bytes) { kopf['Content-Type'] = 'application/octet-stream'; kopf['Content-Length'] = String(bytes.length); }
  return d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: bytes || undefined }), env, { jetzt: u.jetzt });
}

/* ---------- Geheim (Verschlüsselung) ---------- */
test('Geheim: gleicher Text gibt gleichen Block, anderes Wort oder andere Stelle öffnet nicht, falsches Wort hat den Code „schluessel“', async () => {
  const G = MM.Geheim;
  const k = await G.schluessel(WORT, 'dr-1'), k2 = await G.schluessel(WORT, 'dr-1');
  const b1 = await G.verschluesseln(k, 'personen/pe-1', 'Allergie'), b2 = await G.verschluesseln(k2, 'personen/pe-1', 'Allergie');
  assert.equal(b1, b2, 'gleicher Text, gleiche Stelle: gleicher Block (sonst meldet jeder Lauf eine Änderung)');
  assert.ok(b1.startsWith('v1.') && !b1.includes('Allergie'));
  assert.notEqual(b1, await G.verschluesseln(k, 'personen/pe-2', 'Allergie'));
  assert.equal(await G.oeffnen(k, 'personen/pe-1', b1), 'Allergie');
  await assert.rejects(() => G.oeffnen(k, 'personen/pe-2', b1));
  const falsch = await G.schluessel('Ganz anderes Wort 1', 'dr-1');
  await assert.rejects(() => G.oeffnen(falsch, 'personen/pe-1', b1), (e) => e.code === 'schluessel');
  const anderer = await G.schluessel(WORT, 'dr-2');
  await assert.rejects(() => G.oeffnen(anderer, 'personen/pe-1', b1), (e) => e.code === 'schluessel');
  G.vergessen();
});

/* ---------- Dienst ---------- */
test('Dienst: Standorte, Anforderungen und bekannte Einstellungen werden angenommen, unbekannte nicht; „@geheim“ nur im festen Format', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  const senden = (e) => ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [e] }, tok);
  for (const id of ['wechselpunkte-ro-1', 'tagroute-ak-1', 'wechsel-ak-1', 'kartenwahl', 'wortpruefung']) assert.equal((await senden(satz('einstellungen', id))).status, 200, id);
  for (const id of ['gpsspur-ak-1', 'ei-1', 'wortpruefungX']) assert.equal((await senden(satz('einstellungen', id))).status, 400, id);
  assert.equal((await senden(satz('standorte', 'st-1'))).status, 200);
  assert.equal((await senden(satz('anforderungen', 'an-1'))).status, 200);
  assert.equal((await senden(satz('personen', 'pe-1', { '@geheim': 'v1.QUJD' }))).status, 200);
  for (const schlecht of ['QUJD', 'v1.', 'v1.***', 5, '']) assert.equal((await senden(satz('personen', 'pe-2', { '@geheim': schlecht }))).status, 400, String(schlecht));
  const s = await ruf(env, u, 'GET', '/abgleich/stand', undefined, tok);
  assert.equal(typeof s.json.automatisch, 'boolean'); assert.ok(s.json.stufe !== undefined);
});

test('Dienst: Dateiart gpsdaten geht hoch, die Liste nennt den Zeitpunkt „am“', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  const r = await bytesRuf(env, u, 'PUT', '/datei?tabelle=gpsdaten&id=ak-1&verschluesselt=1', new TextEncoder().encode('xyz'), tok);
  assert.equal(r.status, 200); assert.equal(typeof (await r.json()).am, 'number');
  const l = (await ruf(env, u, 'GET', '/datei/liste', undefined, tok)).json;
  assert.deepEqual(l.dateien.map((x) => [x.tabelle, x.id, x.verschluesselt]), [['gpsdaten', 'ak-1', true]]);
  assert.equal(typeof l.dateien[0].am, 'number');
});

/* ---------- Zwei Geräte mit Schlüsselwort ---------- */
async function mitWort(wortA, wortB) {
  const g = await zweiGeraete();
  assert.equal((await g.a.geheimWortSetzen(wortA)).ok, true);
  if (wortB) assert.equal((await g.b.geheimWortSetzen(wortB)).ok, true);
  return g;
}
async function personAnlegen(a) {
  const pe = await a.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'], email: 'anna-privat@example.org', telefon: '0171 555 12', notiz: 'Allergie gegen Nüsse' });
  assert.equal(pe.ok, true, JSON.stringify(pe));
  return pe;
}
const PRIVAT = ['anna-privat@example.org', '0171 555 12', 'Allergie gegen Nüsse'];

test('Zwei Geräte mit demselben Wort: Notiz, E-Mail und Telefon kommen an, der Dienst sieht sie nur als Block', async () => {
  const { env, a, b } = await mitWort(WORT, WORT);
  const pe = await personAnlegen(a);
  const r1 = await a.abgleichAusfuehren();
  assert.equal(r1.ok, true, JSON.stringify(r1)); assert.ok(!r1.falschesWort);
  const server = await alleServer(env), text = JSON.stringify(server.map((x) => x.nutzlast));
  PRIVAT.forEach((x) => assert.ok(!text.includes(x), x));
  assert.ok(text.includes('@geheim'), 'verschlüsselter Block ist da');
  assert.ok(server.some((x) => x.tabelle === 'einstellungen' && x.objekt_id === 'wortpruefung'));
  const r2 = await b.abgleichAusfuehren();
  assert.equal(r2.ok, true, JSON.stringify(r2)); assert.ok(!r2.falschesWort);
  const p = (await b.personenListe()).find((x) => x.aktuell.werte.bezeichnung === 'Anna');
  assert.equal(p.aktuell.werte.email, 'anna-privat@example.org'); assert.equal(p.aktuell.werte.telefon, '0171 555 12'); assert.equal(p.aktuell.werte.notiz, 'Allergie gegen Nüsse');
  /* Ohne Änderung schickt der nächste Lauf nichts (fester Anfangswert) */
  const r3 = await a.abgleichAusfuehren(), r4 = await b.abgleichAusfuehren();
  assert.deepEqual([r3.gesendet, r3.geholt, r4.gesendet, r4.geholt], [0, 0, 0, 0]);
});

test('Ändert B eine private Angabe, ist sie bei A nach dem Abgleich da', async () => {
  const { a, b } = await mitWort(WORT, WORT);
  await personAnlegen(a);
  await a.abgleichAusfuehren(); await b.abgleichAusfuehren();
  const p = (await b.personenListe())[0];
  const ae = await b.personAendern((p.person || p.objekt || p.aktuell).id || p.id, { bezeichnung: 'Anna', funktionen: ['Fahrer'], email: 'neu@example.org', telefon: '0171 555 12', notiz: 'Allergie gegen Nüsse' });
  assert.equal(ae.ok, true, JSON.stringify(ae));
  assert.equal((await b.abgleichAusfuehren()).ok, true);
  const r = await a.abgleichAusfuehren();
  assert.equal(r.ok, true); assert.ok(r.geholt >= 1);
  assert.equal((await a.personenListe())[0].aktuell.werte.email, 'neu@example.org');
});

test('Falsches Wort auf Gerät B: Meldung „passt nicht“, Felder bleiben zu, nichts Fremdes wird geschrieben', async () => {
  const { env, a, b } = await mitWort(WORT, 'Falsches Wort 123');
  await personAnlegen(a);
  assert.equal((await a.abgleichAusfuehren()).ok, true);
  const vorher = JSON.stringify(await alleServer(env));
  const r = await b.abgleichAusfuehren();
  assert.equal(r.falschesWort, true, JSON.stringify(r));
  const p = (await b.personenListe())[0];
  assert.ok(!p.aktuell.werte.email && !p.aktuell.werte.telefon && !p.aktuell.werte.notiz, 'private Felder bleiben gesperrt');
  assert.equal(p.aktuell.werte.bezeichnung, 'Anna', 'der öffentliche Teil kommt an');
  assert.equal(JSON.stringify(await alleServer(env)), vorher, 'B hat nichts verändert');
});

test('Gerät ohne Wort bekommt den öffentlichen Teil, der Block bleibt unberührt; mit dem richtigen Wort ist alles offen', async () => {
  const { env, a, b } = await mitWort(WORT);
  await personAnlegen(a);
  assert.equal((await a.abgleichAusfuehren()).ok, true);
  const vorher = JSON.stringify(await alleServer(env));
  const r = await b.abgleichAusfuehren();
  assert.equal(r.ok, true, JSON.stringify(r)); assert.ok(r.ohneWort >= 1 || r.verschlossen >= 1, JSON.stringify(r));
  const p = (await b.personenListe())[0];
  assert.ok(!p.aktuell.werte.email); assert.equal(p.aktuell.werte.bezeichnung, 'Anna');
  assert.equal((await b.abgleichAusfuehren()).ok, true);
  assert.equal(JSON.stringify(await alleServer(env)), vorher, 'ohne Wort schreibt B den Block nicht um');
  assert.equal((await b.geheimWortSetzen(WORT)).ok, true);
  const r2 = await b.abgleichAusfuehren();
  assert.equal(r2.ok, true, JSON.stringify(r2)); assert.ok(r2.geoeffnet >= 1, JSON.stringify(r2));
  assert.equal((await b.personenListe())[0].aktuell.werte.email, 'anna-privat@example.org');
});

test('Standorte, Anforderungen und Einstellungen (Wechselpunkte, Karten-Auswahl) kommen auf dem zweiten Gerät an', async () => {
  const { a, b } = await zweiGeraete();
  await a.speicher.speichern('standorte', { id: 'st-1', ortId: 'or-1', erstelltAm: 'x' });
  await a.speicher.speichern('anforderungen', { id: 'an-1', text: 'Bitte Tiefgang beachten', erstelltAm: 'x' });
  await a.speicher.speichern('einstellungen', { id: 'wechselpunkte-ro-1', punkte: [{ lat: 1, lon: 2 }], erstelltAm: 'x' });
  await a.speicher.speichern('einstellungen', { id: 'kartenwahl', wahl: ['tanken'], erstelltAm: 'x' });
  await a.speicher.speichern('einstellungen', { id: 'gpsspur-ak-1', spur: [[1, 2]] });
  assert.equal((await a.abgleichAusfuehren()).ok, true);
  assert.equal((await b.abgleichAusfuehren()).ok, true);
  assert.equal((await b.speicher.holen('standorte', 'st-1')).ortId, 'or-1');
  assert.equal((await b.speicher.holen('anforderungen', 'an-1')).text, 'Bitte Tiefgang beachten');
  assert.deepEqual((await b.speicher.holen('einstellungen', 'wechselpunkte-ro-1')).punkte, [{ lat: 1, lon: 2 }]);
  assert.deepEqual((await b.speicher.holen('einstellungen', 'kartenwahl')).wahl, ['tanken']);
  assert.ok(!(await b.speicher.holen('einstellungen', 'gpsspur-ak-1')), 'die lokale GPS-Spur geht nicht über den Datenabgleich');
});

/* ---------- Automatischer Takt ---------- */
test('Automatik: erst nach dem ersten Abgleich von Hand, nicht bei offenem Formular, nicht unsichtbar, nicht ohne Netz', async () => {
  const { a } = await zweiGeraete();
  const T0 = 1000000;
  assert.deepEqual([(await a.abgleichAutomatikTakt({ jetztMs: T0, sofort: true })).lief, (await a.abgleichAutomatikTakt({ jetztMs: T0 + 1, sofort: true })).grund], [false, 'erster Abgleich von Hand']);
  assert.equal((await a.abgleichAusfuehren()).ok, true);
  assert.equal((await a.abgleichAutomatikTakt({ jetztMs: T0 + 2, sofort: true, sichtbar: false })).grund, 'unsichtbar');
  assert.equal((await a.abgleichAutomatikTakt({ jetztMs: T0 + 3, sofort: true, online: false })).grund, 'offline');
  assert.equal((await a.abgleichAutomatikTakt({ jetztMs: T0 + 4, sofort: true, formularOffen: true })).grund, 'formular');
});

test('Automatik: Änderung geht erst nach Ruhezeit hinaus, danach bei Gerät B nach höchstens einer Minute da; ohne Änderung nur die Stand-Frage', async () => {
  const { env, a, b } = await mitWort(WORT, WORT);
  assert.equal((await a.abgleichAusfuehren()).ok, true); assert.equal((await b.abgleichAusfuehren()).ok, true);
  let t = 5000000;
  await a.abgleichAutomatikTakt({ jetztMs: t, sofort: true }); /* erster Takt: die GPS-Dateien einmal prüfen */
  const zweiterA = await a.abgleichAutomatikTakt({ jetztMs: t + 1, sofort: true });
  assert.equal(zweiterA.lief, false); assert.equal(zweiterA.grund, 'kein neuer Stand');
  await personAnlegen(a);
  t += 5000;
  assert.equal((await a.abgleichAutomatikTakt({ jetztMs: t })).lief, false, 'noch in der Ruhezeit');
  t += 16000;
  const l = await a.abgleichAutomatikTakt({ jetztMs: t });
  assert.equal(l.lief, true, JSON.stringify(l)); assert.ok(l.ergebnis.gesendet >= 1);
  assert.equal((await alleServer(env)).some((x) => x.tabelle === 'personen'), true);
  /* B fragt nach einer Minute und holt */
  const bb = await b.abgleichAutomatikTakt({ jetztMs: t + 61000, sofort: true });
  assert.equal(bb.lief, true, JSON.stringify(bb)); assert.ok(bb.ergebnis.geholt >= 1);
  assert.equal((await b.personenListe())[0].aktuell.werte.email, 'anna-privat@example.org');
  /* Danach: nichts zu tun, kein weiterer Lauf, kein Senden (der eigene Abgleich zählt nicht als Änderung) */
  assert.equal((await b.abgleichAutomatikTakt({ jetztMs: t + 200000, sofort: true })).lief, false);
  const nachVoll = await b.abgleichAutomatikTakt({ jetztMs: t + 400000, sofort: true });
  assert.equal(nachVoll.lief, true, 'nach fünf Minuten ein voller Lauf'); assert.equal(nachVoll.ergebnis.gesendet, 0);
});

test('Automatik: Ein Dienst ohne Kennzeichen „automatisch“ (Basic oder alt) bleibt bei Handabgleich', async () => {
  const { a } = await zweiGeraete();
  assert.equal((await a.abgleichAusfuehren()).ok, true);
  const orig = a.netz;
  a.netz = async (...x) => { const j = await orig(...x); if (/\/abgleich\/stand/.test(x[0])) j.automatisch = false; return j; };
  await personAnlegen(a);
  const r = await a.abgleichAutomatikTakt({ jetztMs: 9000000 + 20000 });
  assert.equal(r.lief, false); assert.equal(r.grund, 'basic');
});

/* ---------- GPS-Datei ---------- */
test('GPS-Spur: geht verschlüsselt als Datei hinaus und kommt auf dem zweiten Gerät an; ohne Wort bleibt sie auf dem Gerät', async () => {
  const { env, a, b } = await mitWort(WORT, WORT);
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  await a.speicher.speichern('einstellungen', { id: 'gpsspur-ak-1', spur: [[48.9, 9.1, 1000], [48.91, 9.11, 2000]], erstelltAm: 'x' });
  assert.equal((await a.abgleichAusfuehren()).ok, true);
  const d = await a.dateienAbgleichen({});
  assert.equal(d.ok, true, JSON.stringify(d));
  const l = (await ruf(env, uhr(), 'GET', '/datei/liste', undefined, (await a.rcGeraet()).kontoToken)).json;
  const g = l.dateien.filter((x) => x.tabelle === 'gpsdaten');
  assert.ok(g.length >= 1 && g.every((x) => x.verschluesselt === true), JSON.stringify(l));
  assert.ok(fz.ok !== false);
  assert.equal((await b.abgleichAusfuehren()).ok, true);
  const db = await b.dateienAbgleichen({});
  assert.equal(db.ok, true, JSON.stringify(db));
  const doc = await b.speicher.holen('einstellungen', 'gpsspur-ak-1');
  assert.ok(doc && doc.spur.length === 2, 'Spur kam auf B an');
  /* Ohne Wort bleibt die Spur auf dem Gerät: Gerät C ohne Wort holt nichts */
});
