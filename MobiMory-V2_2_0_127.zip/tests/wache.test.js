'use strict';
/* 2.0.120: Wachen (Anker und Standort) und die Zusammenführung von Weg und Kilometern. */
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/version.js');
require('../js/wache.js');
const W = global.MM.Wache;

const mitte = { breite: 48.9, laenge: 9.0, genauigkeit: 5 };
function nach(m, grad) { return { breite: mitte.breite + (m * Math.cos(grad * Math.PI / 180)) / 111320, laenge: mitte.laenge + (m * Math.sin(grad * Math.PI / 180)) / (111320 * Math.cos(mitte.breite * Math.PI / 180)), genauigkeit: 5, zeitMs: Date.now() }; }

test('Abstand und Richtung stimmen', () => {
  const p = nach(100, 90);
  assert.ok(Math.abs(W.meter(mitte.breite, mitte.laenge, p.breite, p.laenge) - 100) < 1);
  assert.equal(W.himmelsrichtung(W.richtungGrad(mitte.breite, mitte.laenge, p.breite, p.laenge)), 'O');
});

test('Alarm erst nach drei Punkten außerhalb, ein Ausreißer löst nichts aus', () => {
  let w = W.neu('anker', mitte, 50);
  let r = W.punkt(w, nach(80, 200)); w = r.wache; assert.equal(r.neuerAlarm, false);
  r = W.punkt(w, nach(10, 0)); w = r.wache; assert.equal(w.zaehler, 0);
  for (let i = 0; i < 2; i++) { r = W.punkt(w, nach(80, 200)); w = r.wache; assert.equal(r.neuerAlarm, false); }
  r = W.punkt(w, nach(80, 200)); assert.equal(r.neuerAlarm, true); assert.ok(r.wache.alarm.abstand >= 79);
});

test('Ungenaue Punkte lösen weder aus noch entwarnen', () => {
  let w = W.neu('standort', mitte, 20);
  const schlecht = Object.assign(nach(500, 0), { genauigkeit: 300 });
  const r = W.punkt(w, schlecht);
  assert.equal(r.ausserhalb, false); assert.equal(r.wache.zaehler, 0);
  const grenz = Object.assign(nach(25, 0), { genauigkeit: 10 }); /* 25 - 10 = 15 < 20: noch innerhalb */
  assert.equal(W.punkt(w, grenz).ausserhalb, false);
});

test('Quittieren, Ausschalten und Radiusprüfung', () => {
  let w = W.neu('anker', mitte, 30);
  for (let i = 0; i < 3; i++) w = W.punkt(w, nach(90, 10)).wache;
  assert.ok(w.alarm); w = W.quittieren(w); assert.equal(w.alarm.quittiert, true);
  w = W.ausschalten(w); assert.equal(w.an, false); assert.equal(w.alarm, null);
  assert.throws(() => W.neu('anker', mitte, 5)); assert.throws(() => W.neu('anker', null, 30)); assert.throws(() => W.neu('x', mitte, 30));
});

test('Art je Status, Radiusvorschlag, Ausfall-Warnung', () => {
  assert.equal(W.artFuer('wasser', 'vor-anker'), 'anker');
  assert.equal(W.artFuer('wasser', 'festgemacht'), 'standort');
  assert.equal(W.artFuer('land', 'stillstand'), 'standort');
  assert.equal(W.artFuer('land', 'in-fahrt'), null);
  assert.equal(W.radiusVorschlag(6, 0), 30); assert.equal(W.radiusVorschlag(0, 5), null);
  const w = W.neu('anker', mitte, 40, { ueberwachen: true, zeitMs: 1000 });
  assert.equal(W.wachterAusgefallen(w, 1000 + W.AUSFALL_MS + 1), true);
  assert.equal(W.wachterAusgefallen(W.neu('anker', mitte, 40, { zeitMs: 1000 }), 1000 + W.AUSFALL_MS + 1), false);
});
