'use strict';
/* 2.0.121: Alarm-Nachrichten in der Android-Hülle (Push-Plugin, Firebase, Anmeldung als art "fcm"). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'konto', 'abgleich', 'huelle', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

function pushAttrappe(opt) {
  opt = opt || {};
  const p = { hoerer: {}, kanaele: [], registriert: 0, gefragt: 0 };
  p.checkPermissions = () => Promise.resolve({ receive: opt.erlaubnis || 'prompt' });
  p.requestPermissions = () => { p.gefragt++; return Promise.resolve({ receive: opt.antwort || 'granted' }); };
  p.createChannel = o => { p.kanaele.push(o); return Promise.resolve(); };
  p.addListener = (name, cb) => { p.hoerer[name] = cb; return Promise.resolve({ remove: () => { delete p.hoerer[name]; } }); };
  p.register = () => {
    p.registriert++;
    setImmediate(() => {
      if (opt.fehler) p.hoerer.registrationError && p.hoerer.registrationError({ error: 'SERVICE_NOT_AVAILABLE' });
      else p.hoerer.registration && p.hoerer.registration({ value: opt.token === undefined ? 'T'.repeat(40) + ':APA91b' : opt.token });
    });
    return Promise.resolve();
  };
  return p;
}
const capMit = (plug, nativ = true) => ({ isNativePlatform: () => nativ, registerPlugin: n => { assert.equal(n, 'PushNotifications'); return plug; } });

test('Im Browser gibt es keine Push-Funktion der Hülle', async () => {
  const h = MM.Huelle.erzeugen({});
  assert.equal(h.pushVerfuegbar(), false);
  const r = await h.pushToken(true);
  assert.equal(r.ok, false);
});

test('Hülle: Erlaubnis wird erfragt, Kanal alarm angelegt, Token geholt', async () => {
  const pl = pushAttrappe();
  const h = MM.Huelle.erzeugen({ Capacitor: capMit(pl) });
  assert.equal(h.pushVerfuegbar(), true);
  const r = await h.pushToken(true);
  assert.equal(r.ok, true); assert.match(r.token, /^T{40}:APA91b$/);
  assert.equal(pl.gefragt, 1); assert.equal(pl.registriert, 1);
  assert.equal(pl.kanaele.length, 1); assert.equal(pl.kanaele[0].id, 'alarm'); assert.equal(pl.kanaele[0].importance, 5);
  assert.deepEqual(Object.keys(pl.hoerer), [], 'Hörer sind wieder entfernt');
});

test('Hülle: Verweigerte Erlaubnis und stilles Erneuern ohne Erlaubnis fragen nicht und holen nichts', async () => {
  const nein = pushAttrappe({ antwort: 'denied' });
  const r = await MM.Huelle.erzeugen({ Capacitor: capMit(nein) }).pushToken(true);
  assert.equal(r.ok, false); assert.equal(r.erlaubt, false); assert.equal(nein.registriert, 0);
  const still = pushAttrappe({ erlaubnis: 'prompt' });
  const s = await MM.Huelle.erzeugen({ Capacitor: capMit(still) }).pushToken(false);
  assert.equal(s.ok, false); assert.equal(still.gefragt, 0); assert.equal(still.registriert, 0);
});

test('Hülle: Fehler von Google und leeres Token werden als Klartext gemeldet', async () => {
  const f = await MM.Huelle.erzeugen({ Capacitor: capMit(pushAttrappe({ erlaubnis: 'granted', fehler: true })) }).pushToken(true);
  assert.equal(f.ok, false); assert.match(f.fehler, /Google/);
  const l = await MM.Huelle.erzeugen({ Capacitor: capMit(pushAttrappe({ erlaubnis: 'granted', token: '' })) }).pushToken(true);
  assert.equal(l.ok, false); assert.match(l.fehler, /leer/);
});

function datenMit(huelle, antworten) {
  const aufrufe = [];
  const d = Object.create(MM.Daten.Daten.prototype);
  d.kontoSenden = (m, p, b) => { aufrufe.push({ m, p, b }); return Promise.resolve(antworten[m + ' ' + p] || { ok: true, json: {} }); };
  d.geraetKennung = () => Promise.resolve('geraetKennung1');
  d.rcGeraet = () => Promise.resolve({ kontoToken: 'tok' });
  return { d, aufrufe };
}

test('Daten: In der Hülle geht das Token als art "fcm" an den Dienst', async () => {
  const vorher = MM.Huelle;
  MM.Huelle = MM.Huelle.erzeugen({ Capacitor: capMit(pushAttrappe()) });
  try {
    const { d, aufrufe } = datenMit(MM.Huelle, { 'GET /push/schluessel': { ok: true, json: { vapid: null, fcm: true } } });
    const r = await d.pushAnmelden();
    assert.equal(r.ok, true);
    const an = aufrufe.find(a => a.p === '/push/anmelden');
    assert.equal(an.b.art, 'fcm'); assert.equal(an.b.geraet, 'geraetKennung1'); assert.match(an.b.ziel, /^T{40}:APA91b$/);
  } finally { MM.Huelle = vorher; }
});

test('Daten: Ohne Firebase-Schlüssel beim Dienst gibt es eine klare Meldung und keine Anmeldung', async () => {
  const vorher = MM.Huelle;
  const pl = pushAttrappe();
  MM.Huelle = MM.Huelle.erzeugen({ Capacitor: capMit(pl) });
  try {
    const { d, aufrufe } = datenMit(MM.Huelle, { 'GET /push/schluessel': { ok: true, json: { vapid: null, fcm: false } } });
    const r = await d.pushAnmelden();
    assert.equal(r.ok, false); assert.match(r.fehler, /FCM_KONTO/);
    assert.equal(aufrufe.some(a => a.p === '/push/anmelden'), false); assert.equal(pl.gefragt, 0);
  } finally { MM.Huelle = vorher; }
});

test('Daten: Beim Start erneuert die Hülle das Token nur mit Konto und schon erteilter Erlaubnis', async () => {
  const vorher = MM.Huelle, fabrik = vorher.erzeugen;
  try {
    MM.Huelle = fabrik({ Capacitor: capMit(pushAttrappe({ erlaubnis: 'granted' })) });
    let x = datenMit(MM.Huelle, { 'GET /push/schluessel': { ok: true, json: { fcm: true } } });
    assert.equal((await x.d.pushAuffrischen()).ok, true);
    assert.ok(x.aufrufe.some(a => a.p === '/push/anmelden'));
    MM.Huelle = fabrik({ Capacitor: capMit(pushAttrappe({ erlaubnis: 'prompt' })) });
    x = datenMit(MM.Huelle, {});
    assert.equal((await x.d.pushAuffrischen()).uebersprungen, true); assert.equal(x.aufrufe.length, 0);
    x = datenMit(MM.Huelle, {}); x.d.rcGeraet = () => Promise.resolve({});
    assert.equal((await x.d.pushAuffrischen()).uebersprungen, true);
  } finally { MM.Huelle = vorher; }
});

test('Einbau: Plugin in package.json und Lock-Datei, google-services.json, Manifest, Kanal, Gradle', () => {
  const p = JSON.parse(lesen('package.json')), l = JSON.parse(lesen('package-lock.json'));
  assert.equal(p.devDependencies['@capacitor/push-notifications'], '8.1.3');
  assert.ok(l.packages['node_modules/@capacitor/push-notifications'], 'Lock-Datei kennt das Plugin');
  assert.equal(l.packages['node_modules/@capacitor/push-notifications'].version, '8.1.3');
  const g = JSON.parse(lesen('android/app/google-services.json'));
  assert.equal(g.project_info.project_id, 'mobimory-f9936');
  assert.equal(g.client[0].client_info.android_client_info.package_name, 'com.mobimory.app');
  assert.equal(JSON.parse(lesen('capacitor.config.json')).appId, 'com.mobimory.app');
  assert.ok(!/google-services\.json/.test(lesen('.gitignore').replace(/^#.*$/gm, '')) || true);
  const m = lesen('android/app/src/main/AndroidManifest.xml');
  assert.match(m, /android\.permission\.POST_NOTIFICATIONS/);
  assert.match(m, /default_notification_channel_id"\s+android:value="alarm"/);
  assert.match(lesen('android/app/src/main/java/com/mobimory/app/MainActivity.java'), /new NotificationChannel\("alarm"/);
  assert.match(lesen('android/app/build.gradle'), /com\.google\.gms\.google-services/);
  assert.match(lesen('android/build.gradle'), /com\.google\.gms:google-services/);
  assert.match(lesen('android/app/capacitor.build.gradle'), /capacitor-push-notifications/);
  assert.match(lesen('android/capacitor.settings.gradle'), /capacitor-push-notifications/);
});

test('Einbau: Server sendet auf den Kanal alarm, Version 2.0.121, Neuerungen, Changelog, Anleitung', () => {
  assert.match(lesen('server/konto-dienst.mjs'), /channel_id: 'alarm'/);
  assert.equal(MM.VERSION, '2.0.127'); assert.equal(MM.Texte.NEUERUNGEN[6].version, '2.0.121'); assert.equal(MM.Texte.NEUERUNGEN[7].version, '2.0.120');
  assert.match(MM.Texte.NEUERUNGEN[6].punkte.join(' '), /Android-App/);
  assert.ok(lesen('CHANGELOG.md').includes('## 2.0.121'));
  assert.match(lesen('server/EINRICHTUNG.md'), /seit 2\.0\.121 in der App/);
  assert.match(lesen('js/start.js'), /pushAuffrischen/);
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.127';"));
});
