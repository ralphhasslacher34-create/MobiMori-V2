'use strict';
/* 2.0.127: Jede Datei, die sw.js beim Update laden will, muss auch veröffentlicht werden.
   Fehlt eine, scheitert addAll im Service Worker und das Update installiert sich nie (Fehler seit 2.0.125: Ordner handbuch). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const wurzel = path.join(__dirname, '..');
const lesen = (p) => fs.readFileSync(path.join(wurzel, p), 'utf8');

function swDateien() {
  const m = lesen('sw.js').match(/var DATEIEN = \[([\s\S]*?)\];/);
  return [...m[1].matchAll(/'([^']+)'/g)].map((x) => x[1]).filter((f) => f !== './');
}
function kopierte(workflow, ziel) {
  const zeile = lesen(workflow).split('\n').find((z) => /\bcp -r\b/.test(z) && z.includes(ziel));
  assert.ok(zeile, workflow + ': Kopierzeile nach ' + ziel + ' nicht gefunden');
  return zeile.trim().split(/\s+/).slice(2, -1);
}

for (const [workflow, ziel] of [['.github/workflows/veroeffentlichen.yml', '_site/'], ['.github/workflows/android-apk.yml', 'www/']]) {
  test('Alle Dateien aus sw.js werden veröffentlicht: ' + workflow, () => {
    const kopiert = kopierte(workflow, ziel);
    const fehlt = swDateien().filter((f) => !kopiert.includes(f.split('/')[0]));
    assert.deepEqual(fehlt, [], 'Diese Dateien stehen in sw.js, werden aber nicht veröffentlicht: ' + fehlt.join(', '));
  });
}

test('Jede Datei aus sw.js gibt es im Bau', () => {
  const fehlt = swDateien().filter((f) => !fs.existsSync(path.join(wurzel, f)));
  assert.deepEqual(fehlt, []);
});
