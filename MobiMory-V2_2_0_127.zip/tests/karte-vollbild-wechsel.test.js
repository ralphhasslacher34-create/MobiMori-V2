'use strict';
/* 2.0.109: Karte im Cockpit-Wechsel füllt den ganzen Bildschirm (Kopfzeile und Seitenpunkte weg). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

test('Wechsel: Klasse cv-karte-voll wird bei der Karte gesetzt und sonst entfernt', () => {
  const a = lesen('js/ansicht.js');
  assert.match(a, /function vollbild\(an\) \{ if \(cockpitEl\) cockpitEl\.classList\.toggle\('cv-karte-voll', !!an\); \}/);
  assert.match(a, /function verbergen\(\) \{ flaeche\.hidden = true; vollbild\(false\); \}/);
  assert.match(a, /vollbild\(ansichtId === 'karte' && !!kv\);/);
  assert.match(a, /cockpitEl = el;/);
  /* Seite wählen blendet die Fläche aus, damit auch die Klasse weg ist */
  assert.match(a, /function seiteWaehlen\(n, weich\) \{\s*\n\s*if \(wechsler\) wechsler\.verbergen\(\);/);
  /* Die Karte wird nach dem Einblenden neu vermessen */
  assert.match(a, /else kv\.groesse\(\)/);
});

test('CSS: Kopfzeile und Seitenpunkte sind im Karten-Vollbild weg', () => {
  assert.match(lesen('css/styles.css'), /\.cockpit-voll\.cv-karte-voll > \.cv-kopf, \.cockpit-voll\.cv-karte-voll > \.cv-punkte \{ display: none; \}/);
});

test('Kartenleiste im Wechsel: Logbuch, Hauptmenü, Zurück und Offline-Karte sind da', () => {
  const a = lesen('js/ansicht.js'), k = lesen('js/kartenansicht.js');
  assert.match(a, /eingebettetKnoepfe: \[/);
  assert.match(a, /text: 'Logbuch', beiTipp: logbuchOeffnen/);
  assert.match(a, /text: 'Hauptmenü', href: '#\/auswahl'/);
  assert.match(a, /text: 'Zurück', beiTipp: function \(\) \{ seiteWaehlen\(/);
  assert.match(a, /offline: '#\/aktivitaet\/' \+ enc\(id\) \+ '\/karte\/offline'/);
  assert.match(a, /reiterWahl\[id\] = 'logbuch'; zeige\(\)\.catch\(fehlerSeite\); \}\);/);
  assert.match(k, /opt\.eingebettet && opt\.eingebettetKnoepfe/);
});
