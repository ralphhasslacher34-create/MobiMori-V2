/*
 * Rudergängerwechsel bei Wasserfahrzeugen (seit 2.0.106). Reine Rechnung und Texte, kein Speichern.
 *
 * Festlegung (Nutzer, 17.11.2026):
 *  - Der Skipper bleibt verantwortlich, auch wenn jemand anderes am Ruder steht. Der Skipper ist am Anfang automatisch der erste Rudergänger.
 *  - Rudergänger kann jede Person sein, die bei der Aktivität dabei ist (nicht Tiere). Keine Befähigungsprüfung: Das ist Sache des Skippers,
 *    MobiMory prüft nichts (auch keinen Führerschein, kein Alter).
 *  - Der Rudergängerwechsel ist häufig und eine eigene Sache neben „Verantwortung wechseln“ (Skipperwechsel). Er hat seine eigenen Adressen und
 *    seine eigene Ereignisart im Logbuch („Rudergängerwechsel“, art 'ruder'), nicht die des Verantwortungswechsels (art 'wechsel').
 *  - Gespeichert wird so, dass die Zeit am Ruder je Person auswertbar ist (für das Reisebuch).
 *  - An Land gibt es keinen Rudergänger.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var ART = 'Rudergängerwechsel';
  var NAME = 'Rudergänger';

  function dokumentId(aktivitaetId) { return 'ruder-' + aktivitaetId; }
  function nurWasser(welt) { return welt === 'wasser'; }

  function sortiert(liste) {
    return (liste || []).slice().sort(function (a, b) { return a.ab < b.ab ? -1 : (a.ab > b.ab ? 1 : 0); });
  }

  /*
   * Wer steht zu einem Zeitpunkt am Ruder? start = { personId, name } (der Skipper am Anfang), wechsel = [{ personId, name, ab }].
   * Vor dem ersten Wechsel steht der Skipper vom Anfang am Ruder. Ergebnis: { personId, name, ab } (ab = null beim Anfang).
   */
  function aktuell(start, wechsel, zeitpunkt) {
    var r = start ? { personId: start.personId, name: start.name, ab: null } : null;
    sortiert(wechsel).forEach(function (w) { if (!zeitpunkt || w.ab <= zeitpunkt) r = { personId: w.personId, name: w.name, ab: w.ab }; });
    return r;
  }

  /*
   * Die Abschnitte am Ruder von „von“ bis „bis“ ("JJJJ-MM-TTTHH:MM"): [{ personId, name, von, bis, minuten }].
   * Wechsel außerhalb des Zeitraums zählen nur, soweit sie in den Zeitraum hineinreichen. Ohne Start gibt es keine Abschnitte.
   */
  function abschnitte(start, wechsel, von, bis) {
    if (!start || !von || !bis) return [];
    var a = MM.Logbuch.minutenNummer(von), b = MM.Logbuch.minutenNummer(bis);
    if (isNaN(a) || isNaN(b) || b <= a) return [];
    var punkte = [{ personId: start.personId, name: start.name, ab: von }];
    sortiert(wechsel).forEach(function (w) {
      if (w.ab <= von) punkte = [{ personId: w.personId, name: w.name, ab: von }];
      else if (w.ab < bis) punkte.push({ personId: w.personId, name: w.name, ab: w.ab });
    });
    return punkte.map(function (p, i) {
      var ende = i + 1 < punkte.length ? punkte[i + 1].ab : bis;
      return { personId: p.personId, name: p.name, von: p.ab, bis: ende, minuten: MM.Logbuch.minutenNummer(ende) - MM.Logbuch.minutenNummer(p.ab) };
    });
  }

  /* Zeit am Ruder je Person, die längste zuerst: [{ personId, name, minuten, abschnitte }] */
  function zeiten(start, wechsel, von, bis) {
    var je = {}, reihe = [];
    abschnitte(start, wechsel, von, bis).forEach(function (x) {
      if (!je[x.personId]) { je[x.personId] = { personId: x.personId, name: x.name, minuten: 0, abschnitte: 0 }; reihe.push(je[x.personId]); }
      je[x.personId].minuten += x.minuten; je[x.personId].abschnitte++;
    });
    return reihe.sort(function (x, y) { return y.minuten - x.minuten || x.name.localeCompare(y.name, 'de'); });
  }

  function dauerText(min) {
    var h = Math.floor(min / 60), m = Math.round(min - h * 60);
    if (m === 60) { h++; m = 0; }
    return h ? h + ' h ' + (m < 10 ? '0' : '') + m + ' min' : m + ' min';
  }

  /* Die Wechsel als Ereignisse für das Logbuch. Der Anfang ist kein Wechsel. */
  function wechselEreignisse(start, wechsel) {
    var liste = sortiert(wechsel), vorher = start ? start.name : '';
    return liste.map(function (w) {
      var e = {
        art: 'ruder', rudergaengerId: w.id, personId: w.personId, name: w.name, vorher: vorher, ab: w.ab, datum: w.ab.slice(0, 10), zeit: w.ab.slice(11, 16),
        nachgetragenAm: w.nachgetragenAm || null, zeitHerkunft: w.zeitHerkunft || null,
        breite: typeof w.breite === 'number' ? w.breite : null, laenge: typeof w.laenge === 'number' ? w.laenge : null, positionQuelle: w.positionQuelle || null,
        text: w.name + ' steht ab jetzt am Ruder' + (vorher ? ' (vorher ' + vorher + ')' : '') + '.'
      };
      vorher = w.name;
      return e;
    });
  }

  /*
   * Darf diese Person ab diesem Zeitpunkt ans Ruder? Es zählt nur, ob sie bei der Aktivität dabei ist (Besatzung, nicht entfernt, im Zeitraum „dabei von bis“,
   * falls angegeben). Keine Befähigungsprüfung.
   * b = Besatzungswerte der Person { entfernt, dabeiVonDatum, dabeiVonZeit, dabeiBisDatum, dabeiBisZeit }, zeitpunkt = "JJJJ-MM-TTTHH:MM"
   */
  function dabei(b, zeitpunkt) {
    if (!b || b.entfernt === 'ja') return false;
    if (b.dabeiVonDatum && zeitpunkt < b.dabeiVonDatum + 'T' + (b.dabeiVonZeit || '00:00')) return false;
    if (b.dabeiBisDatum && zeitpunkt > b.dabeiBisDatum + 'T' + (b.dabeiBisZeit || '23:59')) return false;
    return true;
  }

  MM.Rudergaenger = {
    ART: ART, NAME: NAME, dokumentId: dokumentId, nurWasser: nurWasser, aktuell: aktuell, abschnitte: abschnitte, zeiten: zeiten,
    dauerText: dauerText, wechselEreignisse: wechselEreignisse, dabei: dabei
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
