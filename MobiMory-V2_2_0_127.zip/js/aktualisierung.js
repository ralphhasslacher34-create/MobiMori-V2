/*
 * Update-Prüfung der Android-App (seit 2.0.113).
 * Beim Start fragt die App in der Hülle die Versions-Datei auf mobimory.com ab (https://mobimory.com/version.json).
 * Ist dort eine neuere Version eingetragen, erscheint der Hinweis „Neue Version verfügbar“ mit Knopf zum Herunterladen.
 * Der Download öffnet sich im Browser des Geräts, installiert wird dort vom Nutzer selbst (Android fragt nach).
 *
 * Im Browser tut dieses Modul nichts. Die Abfrage läuft über das fest eingebaute Netz-Modul von Capacitor (CapacitorHttp),
 * damit keine Browser-Sperre (CORS) im Weg steht. Der Link zur APK wird nur angenommen, wenn er auf https://mobimory.com/ zeigt.
 * Die Umgebung (window mit Capacitor und document) wird übergeben, damit sich alles testen lässt.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var VERSIONSDATEI = 'https://mobimory.com/version.json';
  var LINK_ANFANG = 'https://mobimory.com/';

  function teile(v) {
    var m = /^(\d+)\.(\d+)\.(\d+)$/.exec(String(v === null || v === undefined ? '' : v).trim());
    return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
  }
  /* -1: a ist älter als b, 0: gleich oder nicht lesbar, 1: a ist neuer. Zahlen, nicht Text (2.0.9 ist kleiner als 2.0.10). */
  function vergleichen(a, b) {
    var x = teile(a), y = teile(b);
    if (!x || !y) return 0;
    for (var i = 0; i < 3; i++) { if (x[i] < y[i]) return -1; if (x[i] > y[i]) return 1; }
    return 0;
  }

  /* Die Antwort des Netz-Moduls (data als Objekt oder als Text) in { version, apk } oder null. */
  function lesen(antwort) {
    if (!antwort || typeof antwort !== 'object') return null;
    if (antwort.status !== undefined && antwort.status !== 200) return null;
    var d = antwort.data;
    if (typeof d === 'string') { try { d = JSON.parse(d); } catch (e) { return null; } }
    if (!d || typeof d !== 'object') return null;
    if (!teile(d.version)) return null;
    var apk = typeof d.apk === 'string' ? d.apk.trim() : '';
    if (apk.indexOf(LINK_ANFANG) !== 0 || /\s/.test(apk)) return null;
    return { version: String(d.version).trim(), apk: apk };
  }

  function erzeugen(umgebung, aktuelleVersion) {
    var huelle = MM.Huelle.erzeugen(umgebung);

    function netz() {
      var cap = umgebung && umgebung.Capacitor;
      var p = cap && cap.Plugins && cap.Plugins.CapacitorHttp;
      return p && typeof p.get === 'function' ? p : null;
    }

    /* Gibt { neu, version, apk } zurück oder null (Browser, kein Netz, Datei nicht lesbar). Wirft nie. */
    function pruefen() {
      if (!huelle.istHuelle()) return Promise.resolve(null);
      var p = netz();
      if (!p) return Promise.resolve(null);
      var zusage;
      try {
        zusage = Promise.resolve(p.get({
          url: VERSIONSDATEI + '?t=' + Date.now(),
          headers: { 'Cache-Control': 'no-cache' },
          connectTimeout: 8000, readTimeout: 8000
        }));
      } catch (e) { return Promise.resolve(null); }
      return zusage.then(function (antwort) {
        var info = lesen(antwort);
        if (!info) return null;
        return { neu: vergleichen(aktuelleVersion, info.version) < 0, version: info.version, apk: info.apk };
      }, function () { return null; });
    }

    return { pruefen: pruefen };
  }

  /* Der Hinweis hängt direkt am Seitenende (body), damit ihn kein Neuaufbau der Seiten wegnimmt. Nur einer zugleich. */
  function hinweisZeigen(doc, info, herunterladen) {
    if (!doc || !doc.body || doc.querySelector('.apk-hinweis')) return null;
    var T = MM.Texte.AKTUALISIERUNG;
    var box = doc.createElement('div');
    box.className = 'apk-hinweis';
    box.setAttribute('role', 'status');
    var t = doc.createElement('span');
    t.textContent = T.hinweis.replace('{version}', info.version);
    var herunter = doc.createElement('button');
    herunter.type = 'button'; herunter.className = 'knopf'; herunter.textContent = T.herunterladen;
    herunter.addEventListener('click', function () { herunterladen(info.apk); });
    var spaeter = doc.createElement('button');
    spaeter.type = 'button'; spaeter.className = 'knopf apk-spaeter'; spaeter.textContent = T.spaeter;
    spaeter.addEventListener('click', function () { if (box.parentNode) box.parentNode.removeChild(box); });
    box.appendChild(t); box.appendChild(herunter); box.appendChild(spaeter);
    doc.body.appendChild(box);
    return box;
  }

  /* Beim Start der App: prüfen und, wenn nötig, den Hinweis zeigen. Im Browser passiert nichts. */
  function beimStart(umgebung, aktuelleVersion) {
    return erzeugen(umgebung, aktuelleVersion).pruefen().then(function (info) {
      if (info && info.neu) {
        hinweisZeigen(umgebung.document, info, function (url) {
          /* Die Hülle öffnet Adressen außerhalb der App im Browser des Geräts. */
          try { umgebung.location.href = url; } catch (e) { /* nichts zu tun */ }
        });
      }
      return info;
    }).catch(function () { return null; });
  }

  MM.Aktualisierung = { erzeugen: erzeugen, beimStart: beimStart, hinweisZeigen: hinweisZeigen, lesen: lesen, vergleichen: vergleichen, teile: teile };
  MM.Aktualisierung.VERSIONSDATEI = VERSIONSDATEI;
  MM.Aktualisierung.LINK_ANFANG = LINK_ANFANG;
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
