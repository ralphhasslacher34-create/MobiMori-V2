/*
 * Schnellstart (seit 2.0.124): der geführte Einstieg für neue Nutzer.
 *
 * Beim ersten Start fragt die App, wie es losgehen soll:
 *   - „Ich lege eine Person und Fahrzeuge an“ (Basic, ohne Anmeldung) oder
 *   - „Ich melde mich mit einem Konto an“ (Testwoche).
 * Danach drei Schritte: Person, Fahrzeug, erste Aktivität. Die Arten von Aktivitäten und die verantwortliche Person setzt die App selbst vor.
 * Am Ende steht der Neue im Cockpit der ersten Aktivität. Der Start ist überspringbar und im Hauptmenü wieder aufrufbar.
 *
 * Hier stehen nur reine Funktionen und die Texte (kein Speicher, keine Seite). Der Stand liegt in der Einstellung 'schnellstart'
 * (siehe daten.js: schnellstartLesen und schnellstartSetzen), die Seiten stehen in ansicht.js.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var DOK_ID = 'schnellstart';

  /* Stand: 'offen' (noch nichts entschieden), 'unterwegs' (gewählt, nicht fertig), 'fertig', 'uebersprungen'. */
  var STAENDE = ['offen', 'unterwegs', 'fertig', 'uebersprungen'];
  var WEGE = ['basic', 'konto'];
  var SCHRITTE = ['person', 'fahrzeug', 'aktivitaet'];

  /* Die Texte stehen hier an einer Stelle (Stil der Homepage: Erlebnis und Nutzen, nicht technisch). */
  var TEXTE = {
    menue: { titel: 'Schnellstart', text: 'Person, Fahrzeug und erste Aktivität in drei Schritten. Danach bist du im Cockpit.' },
    frage: {
      titel: 'Willkommen an Bord',
      intro: 'In wenigen Minuten bist du unterwegs: eine Person, ein Fahrzeug, deine erste Aktivität. Die Vorarbeit übernimmt MobiMory für dich.',
      frage: 'Wie möchtest du starten?',
      basic: { titel: 'Ich lege eine Person und Fahrzeuge an', text: 'Du legst sofort los, ohne Anmeldung. Alles bleibt auf deinem Gerät.' },
      konto: { titel: 'Ich melde mich mit einem Konto an', text: 'Du startest mit einer Testwoche: Online-Check, Routenplanung, Dokumente scannen und deine Daten auf mehreren Geräten.' },
      ueberspringen: 'Erst einmal umschauen',
      spaeter: 'Den Schnellstart findest du jederzeit im Hauptmenü.'
    },
    konto: {
      titel: 'Weiter mit dem Schnellstart',
      angemeldet: 'Du bist angemeldet. Hast du schon Daten in deinem Konto, hole sie weiter unten mit dem Abgleich. Sonst geht es jetzt mit deiner Person und deinem Fahrzeug weiter.',
      abgemeldet: 'Melde dich an. Gibt es noch kein Konto, entsteht beim ersten Mal eines, mit einer Testwoche. Danach geht es hier mit dem Schnellstart weiter.',
      weiter: 'Weiter: Person und Fahrzeug anlegen',
      beenden: 'Schnellstart beenden'
    },
    person: {
      titel: 'Wer fährt?',
      intro: 'Wie heißt du? Du bist bei deiner ersten Aktivität verantwortlich (Skipper oder Fahrer). Weitere Personen fügst du später hinzu.',
      name: 'Dein Name', nameHilfe: 'Zum Beispiel dein Vorname.',
      vorhanden: 'Vorhandene Person', vorhandenLeer: '– neue Person anlegen –',
      vorhandenHilfe: 'Du hast schon eine Person angelegt. Nimm sie oder lege eine neue an.',
      weiter: 'Weiter'
    },
    fahrzeug: {
      titel: 'Womit bist du unterwegs?',
      intro: 'Name und Art genügen. Maße, Kennzeichen und Papiere trägst du später ein, zum Beispiel direkt am Fahrzeug.',
      welt: 'Wo bist du unterwegs?', art: 'Art des Fahrzeugs', name: 'Name des Fahrzeugs', nameHilfe: 'Zum Beispiel „Seestern“ oder „Wohnmobil Mia“.',
      vorhanden: 'Vorhandenes Fahrzeug', vorhandenLeer: '– neues Fahrzeug anlegen –',
      vorhandenHilfe: 'Du hast schon ein Fahrzeug angelegt. Nimm es oder lege ein neues an.',
      weiter: 'Weiter',
      weitere: 'Weitere Fahrzeuge legst du später unter Stammdaten › Fahrzeuge an.'
    },
    aktivitaet: {
      titel: 'Deine erste Aktivität',
      intro: 'Was hast du vor? Die Arten von Aktivitäten hat MobiMory schon für dich angelegt. Mit „Los geht’s“ startet das Logbuch und das Cockpit öffnet sich.',
      art: 'Was machst du?', bis: 'Voraussichtlich bis (Datum)', bisHilfe: 'Vorgabe ist heute. Dauert es länger, trage das Datum ein. Du kannst es später ändern.',
      los: 'Los geht’s',
      fertig: 'Das Logbuch läuft. Du bist im Cockpit.'
    },
    knoepfe: { zurueck: 'Zurück', beenden: 'Schnellstart beenden' },
    welten: [{ wert: 'land', label: 'An Land' }, { wert: 'wasser', label: 'Auf dem Wasser' }, { wert: 'luft', label: 'In der Luft' }]
  };

  /* „Schritt 2 von 3“ und der Balken dazu (Anteil in Prozent). */
  function fortschritt(schritt) {
    var i = SCHRITTE.indexOf(schritt);
    if (i < 0) return null;
    return { nr: i + 1, von: SCHRITTE.length, text: 'Schritt ' + (i + 1) + ' von ' + SCHRITTE.length, prozent: Math.round(((i + 1) / SCHRITTE.length) * 100) };
  }

  /* Der Stand aus dem Dokument (oder ohne Dokument). */
  function stand(dok) {
    var d = dok && typeof dok === 'object' ? dok : {};
    return {
      id: DOK_ID,
      stand: STAENDE.indexOf(d.stand) >= 0 ? d.stand : 'offen',
      weg: WEGE.indexOf(d.weg) >= 0 ? d.weg : null,
      personId: d.personId || null,
      fahrzeugId: d.fahrzeugId || null,
      aktivitaetId: d.aktivitaetId || null,
      geaendert: d.geaendert || null
    };
  }

  /* Fragt die App beim Programmstart? Nur, wenn noch nie etwas entschieden wurde und es weder eine Person noch ein Fahrzeug gibt.
     Wer schon Daten hat (zum Beispiel aus einer Sicherung), wird nicht gefragt. */
  function noetig(dok, anzahlPersonen, anzahlFahrzeuge) {
    var s = stand(dok);
    if (s.stand !== 'offen' || s.weg) return false;
    return !anzahlPersonen && !anzahlFahrzeuge;
  }

  /* Welcher Schritt kommt als Nächstes? Eine Person und ein Fahrzeug aus dem Stand zählen nur, wenn es sie noch gibt. */
  function naechsterSchritt(personVorhanden, fahrzeugVorhanden) {
    if (!personVorhanden) return 'person';
    if (!fahrzeugVorhanden) return 'fahrzeug';
    return 'aktivitaet';
  }

  /* Ist der Schritt von hier aus erreichbar? person immer, fahrzeug mit Person, aktivitaet mit Person und Fahrzeug. */
  function schrittErlaubt(schritt, personVorhanden, fahrzeugVorhanden) {
    if (schritt === 'person') return true;
    if (schritt === 'fahrzeug') return !!personVorhanden;
    if (schritt === 'aktivitaet') return !!personVorhanden && !!fahrzeugVorhanden;
    return false;
  }

  /* Der Schritt davor, für „Zurück“. Vor dem ersten Schritt kommt die Frage. */
  function vorherigerSchritt(schritt) {
    var i = SCHRITTE.indexOf(schritt);
    return i > 0 ? SCHRITTE[i - 1] : null;
  }

  /* Die Arten für die Wahl im Schritt Fahrzeug: wählbar und sichtbar, in der Welt. arten kommt von MM.Fahrzeugarten.alle(). */
  function artenInWelt(arten, welt) {
    return (arten || []).filter(function (a) { return a.welt === welt; }).map(function (a) { return { wert: a.id, label: a.name }; });
  }

  /* Die Eingaben der Schritte prüfen (der Name der Person und des Fahrzeugs sind Pflicht). Gibt { ok, fehler } zurück. */
  function pruefePerson(roh) {
    roh = roh || {};
    var f = {};
    if (!roh.personId && !String(roh.bezeichnung || '').trim()) f.bezeichnung = 'Bitte deinen Namen eingeben.';
    return { ok: !Object.keys(f).length, fehler: f };
  }
  function pruefeFahrzeug(roh) {
    roh = roh || {};
    var f = {};
    if (!roh.fahrzeugId) {
      if (!roh.artId) f.artId = 'Bitte die Art des Fahrzeugs wählen.';
      if (!String(roh.bezeichnung || '').trim()) f.bezeichnung = 'Bitte einen Namen für das Fahrzeug eingeben, zum Beispiel „Seestern“.';
    }
    return { ok: !Object.keys(f).length, fehler: f };
  }

  MM.Schnellstart = {
    DOK_ID: DOK_ID, STAENDE: STAENDE, WEGE: WEGE, SCHRITTE: SCHRITTE, TEXTE: TEXTE,
    fortschritt: fortschritt, stand: stand, noetig: noetig, naechsterSchritt: naechsterSchritt, schrittErlaubt: schrittErlaubt,
    vorherigerSchritt: vorherigerSchritt, artenInWelt: artenInWelt, pruefePerson: pruefePerson, pruefeFahrzeug: pruefeFahrzeug
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
