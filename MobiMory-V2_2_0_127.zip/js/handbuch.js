/*
 * Handbuch (seit 2.0.125): die Bedienungsanleitung von MobiMory, als Seiten in der App und als PDF zum Drucken.
 *
 * Die Texte stehen NUR hier, in einer Tabelle: jeder Baustein hat die Sprachen nebeneinander (de, en). Seiten und PDF entstehen daraus.
 * Eine weitere Sprache kommt dazu, indem sie in SPRACHEN eingetragen und in jedem Baustein ergänzt wird (der Test prüft, dass keine fehlt).
 *
 * Aufbau nach Aufgaben („Ich will tanken“), nicht nach Menüpunkten. Beschrieben wird nur, was die App wirklich kann.
 * Bausteine (typ): 'p' Absatz, 'kopf' Zwischenüberschrift, 'schritte' nummerierte Schritte, 'liste' Aufzählung, 'hinweis' hervorgehobener Hinweis, 'bild' Schlüsselbild (id).
 * Schlüsselbilder liegen als handbuch/<id>.jpg (deutsch) in der App; sie entstehen per Skript aus der echten App (siehe docs/HANDBUCH-BILDER.md).
 *
 * Nur reine Funktionen und Texte: kein Speicher, keine Seite. Die Seite steht in ansicht.js (#/handbuch).
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var SPRACHEN = [{ id: 'de', name: 'Deutsch' }, { id: 'en', name: 'English' }];
  var STANDARD_SPRACHE = 'de';
  var BILDER = ['schnellstart', 'schnellstart-fahrzeug', 'einrichten-ueber', 'stammdaten', 'erfassen-wege', 'erfassen-import', 'erfassen-uebergabe', 'fahrzeug-art', 'fahrzeug-maske', 'fahrzeug-huelle', 'fahrzeug-komponente', 'personen-formular', 'personen-nachweis', 'orte-ort', 'orte-gebiet', 'listen-merkmale', 'listen-kosten', 'planen-aktivitaet', 'planen-route', 'planen-tag', 'checks-reise', 'checks-grund', 'wetter-tag', 'cockpit', 'karte', 'tanken-eingabe', 'wache', 'kasse-buch', 'stoerung-werkstatt', 'reisebuch', 'geraete-konto', 'verleih-seite'];

  var UI = {
    de: {
      titel: 'Handbuch', untertitel: 'So benutzt du MobiMory', einleitung: 'Such dir aus, was du tun willst. Jedes Kapitel führt dich Schritt für Schritt.',
      inhalt: 'Inhalt', zurueck: 'Zurück', zumInhalt: 'Zum Inhalt', weiter: 'Weiter', vorher: 'Vorheriges Kapitel', naechstes: 'Nächstes Kapitel',
      sprache: 'Sprache', pdfKnopf: 'Handbuch als PDF speichern', pdfHilfe: 'Das PDF erzeugt MobiMory selbst, auch ohne Internet. Du kannst es ausdrucken.', pdfLaeuft: 'Das PDF wird erzeugt …', pdfFertig: 'Das PDF ist gespeichert: ',
      pdfFehler: 'Das PDF konnte nicht erzeugt werden.', bildFehlt: '(Bild nicht verfügbar)', stand: 'Stand: Version ', kopf: 'Handbuch', fuss: 'MobiMory · Handbuch',
      kapitel: 'Kapitel', dateiName: 'MobiMory_Handbuch_', menueText: 'Bedienungsanleitung nach Aufgaben, auch als PDF zum Drucken', kein: 'Dieses Kapitel gibt es nicht.'
    },
    en: {
      titel: 'Manual', untertitel: 'How to use MobiMory', einleitung: 'Pick what you want to do. Each chapter leads you step by step.',
      inhalt: 'Contents', zurueck: 'Back', zumInhalt: 'To the contents', weiter: 'Next', vorher: 'Previous chapter', naechstes: 'Next chapter',
      sprache: 'Language', pdfKnopf: 'Save manual as PDF', pdfHilfe: 'MobiMory creates the PDF itself, even without internet. You can print it.', pdfLaeuft: 'Creating the PDF …', pdfFertig: 'The PDF is saved: ',
      pdfFehler: 'The PDF could not be created.', bildFehlt: '(Picture not available)', stand: 'Version ', kopf: 'Manual', fuss: 'MobiMory · Manual',
      kapitel: 'Chapter', dateiName: 'MobiMory_Manual_', menueText: 'Instructions by task, also as a PDF to print', kein: 'This chapter does not exist.'
    }
  };

  function p(de, en) { return { typ: 'p', de: de, en: en }; }
  function schritte(de, en) { return { typ: 'schritte', de: de, en: en }; }
  function liste(de, en) { return { typ: 'liste', de: de, en: en }; }
  function kopf(de, en) { return { typ: 'kopf', de: de, en: en }; }
  function hinweis(de, en) { return { typ: 'hinweis', de: de, en: en }; }
  function bild(id, de, en) { return { typ: 'bild', id: id, de: de, en: en }; }

  var KAPITEL = [
    { id: 'schnellstart', titel: { de: 'Schnellstart: mein erstes Fahrzeug und meine erste Reise', en: 'Quick start: my first vehicle and my first trip' }, bloecke: [
      p('In wenigen Minuten bist du unterwegs: eine Person, ein Fahrzeug, deine erste Aktivität. Die Vorarbeit übernimmt MobiMory für dich.',
        'In a few minutes you are on your way: one person, one vehicle, your first activity. MobiMory takes care of the groundwork.'),
      bild('schnellstart', 'Der Schnellstart beim ersten Öffnen.', 'The quick start when you first open the app.'),
      p('Beim ersten Öffnen fragt MobiMory, wie du starten möchtest:', 'When you open MobiMory for the first time, it asks how you want to start:'),
      liste(['„Ich lege eine Person und Fahrzeuge an“: Du legst sofort los, ohne Anmeldung. Alles bleibt auf deinem Gerät.',
        '„Ich melde mich mit einem Konto an“: Du startest mit einer Testwoche (Online-Check, Routenplanung, Dokumente scannen und deine Daten auf mehreren Geräten).',
        '„Erst einmal umschauen“: Du überspringst den Schnellstart. Du findest ihn jederzeit im Hauptmenü.'],
        ['“I create a person and vehicles”: You start right away, without signing in. Everything stays on your device.',
          '“I sign in with an account”: You start with a trial week (online check, route planning, scanning documents and your data on several devices).',
          '“Just look around first”: You skip the quick start. You can find it any time in the main menu.']),
      p('Danach folgen drei Schritte:', 'Then three steps follow:'),
      schritte(['Wer fährt? Gib deinen Namen ein. Du bist bei deiner ersten Aktivität verantwortlich (Skipper oder Fahrer).',
        'Womit bist du unterwegs? Wähle, wo du unterwegs bist (an Land, auf dem Wasser, in der Luft), die Art des Fahrzeugs und gib ihm einen Namen. Maße, Kennzeichen und Papiere trägst du später ein.',
        'Deine erste Aktivität: Wähle, was du machst, und bis wann. Tippe auf „Los geht’s“. Das Logbuch startet und das Cockpit öffnet sich.'],
        ['Who is driving? Enter your name. You are responsible (skipper or driver) for your first activity.',
          'What are you travelling with? Choose where you travel (on land, on the water, in the air), the type of vehicle, and give it a name. You enter dimensions, registration and papers later.',
          'Your first activity: Choose what you are doing, and until when. Tap “Let’s go”. The logbook starts and the cockpit opens.']),
      bild('schnellstart-fahrzeug', 'Schritt 2: Womit bist du unterwegs?', 'Step 2: What are you travelling with?'),
      hinweis('Hast du schon Daten (zum Beispiel aus einer Sicherung), fragt MobiMory beim Start nicht. Den Schnellstart findest du dann im Hauptmenü.',
        'If you already have data (for example from a backup), MobiMory does not ask at the start. You can then find the quick start in the main menu.')
    ] },

    { id: 'einrichten', titel: { de: 'Auf dem Gerät einrichten: Browser, Android, iPad', en: 'Setting up on your device: browser, Android, iPad' }, bloecke: [
      p('MobiMory läuft im Browser (PC, Tablet, Handy) und als Android-App. Die Daten bleiben auf deinem Gerät, solange du kein Konto benutzt.',
        'MobiMory runs in the browser (PC, tablet, phone) and as an Android app. Your data stays on your device as long as you do not use an account.'),
      bild('einrichten-ueber', 'Hauptmenü › Einstellungen › Über MobiMory: hier steht das Handbuch.', 'Main menu › Settings › About MobiMory: the manual is here.'),
      kopf('Im Browser (PC, Tablet, Handy)', 'In the browser (PC, tablet, phone)'),
      schritte(['Öffne die Adresse von MobiMory im Browser.',
        'Wähle im Browser-Menü „Zum Startbildschirm hinzufügen“ (die Bezeichnung hängt vom Browser ab). Dann startet MobiMory wie eine App und arbeitet auch ohne Internet.'],
        ['Open the MobiMory address in your browser.',
          'In the browser menu choose “Add to home screen” (the wording depends on the browser). MobiMory then starts like an app and also works without internet.']),
      kopf('Auf Android (App)', 'On Android (app)'),
      schritte(['Lade auf mobimory.com/download.html die Datei MobiMory.apk und tippe sie an.',
        'Android fragt einmal, ob Installationen aus dieser Quelle erlaubt sind: erlauben und installieren.',
        'Beim ersten Öffnen fragt Android nach dem Standort (genau, bei Nutzung der App) und nach Benachrichtigungen: beides erlauben.'],
        ['On mobimory.com/download.html download the file MobiMory.apk and tap it.',
          'Android asks once whether installations from this source are allowed: allow it and install.',
          'When you first open the app, Android asks for the location (precise, while using the app) and for notifications: allow both.']),
      liste(['In der Android-App zählen Kilometer und GPS auch im Hintergrund weiter. Solange das Cockpit offen ist, steht oben die Meldung „MobiMory zeichnet auf“.',
        'Beendet dein Gerät die App im Hintergrund, stelle in den Android-Einstellungen der App den Akku auf „Nicht eingeschränkt“.',
        'Die App hat einen eigenen Speicher, getrennt vom Browser. Daten aus dem Browser kommen über eine Sicherung oder dein Konto.',
        'Gibt es eine neue Version, zeigt die App „Neue Version verfügbar“. Tippe auf „Herunterladen“.'],
        ['In the Android app, kilometres and GPS keep counting in the background. As long as the cockpit is open, the message “MobiMory is recording” shows at the top.',
          'If your device stops the app in the background, set the battery for the app to “Unrestricted” in the Android settings.',
          'The app has its own storage, separate from the browser. Data from the browser comes over a backup or your account.',
          'When a new version exists, the app shows “New version available”. Tap “Download”.']),
      kopf('Auf dem iPad und iPhone', 'On the iPad and iPhone'),
      p('Eine Apple-App gibt es noch nicht. Auf dem iPad und iPhone benutzt du MobiMory im Browser Safari.',
        'There is no Apple app yet. On the iPad and iPhone you use MobiMory in the Safari browser.'),
      schritte(['Öffne MobiMory in Safari.',
        'Tippe auf „Teilen“ und wähle „Zum Home-Bildschirm“. Starte MobiMory künftig über das Symbol auf dem Home-Bildschirm.',
        'Für Alarm-Nachrichten: Öffne in MobiMory die Seite „Wache“, tippe auf „Nachrichten auf diesem Gerät erlauben“ und antworte auf die Frage von iOS mit „Erlauben“. Das geht nur, wenn MobiMory vom Home-Bildschirm aus gestartet wurde.'],
        ['Open MobiMory in Safari.',
          'Tap “Share” and choose “Add to Home Screen”. From then on, start MobiMory with the icon on the home screen.',
          'For alarm messages: In MobiMory open the “Watch” page, tap “Allow messages on this device” and answer the iOS question with “Allow”. This only works if MobiMory was started from the home screen.']),
      hinweis('Im Browser läuft die Aufzeichnung nur bei offener App. Im Cockpit hält MobiMory den Bildschirm an, wo der Browser das erlaubt. Wechselst du in eine andere App oder sperrst du den Bildschirm, wird in dieser Zeit nichts aufgezeichnet.',
        'In the browser, recording only runs while the app is open. In the cockpit MobiMory keeps the screen on, where the browser allows it. If you switch to another app or lock the screen, nothing is recorded during that time.')
    ] },

    { id: 'stammdaten', titel: { de: 'Meine Stammdaten: was es gibt und wo es steht', en: 'My master data: what there is and where to find it' }, bloecke: [
      p('Stammdaten sind alles, was du einmal einträgst und immer wieder brauchst: dein Fahrzeug, deine Besatzung, deine Orte. Planung, Checks, Logbuch und Kosten greifen darauf zu. Du musst nichts doppelt eintippen.',
        'Master data is everything you enter once and need again and again: your vehicle, your crew, your places. Planning, checks, logbook and costs use it. You never have to type anything twice.'),
      bild('stammdaten', 'Hauptmenü › Stammdaten: alle Stammdaten auf einen Blick.', 'Main menu › Master data: all master data at a glance.'),
      p('Du findest sie im Hauptmenü unter „Stammdaten“. Dort gibt es:', 'You find it in the main menu under “Master data”. There you find:'),
      liste(['Fahrzeuge und Fahrzeugarten: was du fährst, mit allem, was daran hängt (Kapitel 5)',
        'Personen und Tiere, dazu die Nachweisarten: wer mitfährt und welche Papiere er hat (Kapitel 6)',
        'Orte und Gebiete: wo du hinfährst und welche Regeln dort gelten (Kapitel 7)',
        'Adressen: Werkstätten, Lieferanten und Händler (Kapitel 7)',
        'Arten von Aktivitäten und Arten von Ereignissen, Merkmale und Einheiten, Kostenarten und Zahlungsmittel: die Auswahllisten (Kapitel 8)'],
        ['Vehicles and vehicle types: what you drive, with everything attached to it (chapter 5)',
          'People and animals, plus the types of proof: who travels with you and which papers they have (chapter 6)',
          'Places and areas: where you go and which rules apply there (chapter 7)',
          'Addresses: workshops, suppliers and dealers (chapter 7)',
          'Types of activities and types of events, characteristics and units, cost types and means of payment: the selection lists (chapter 8)']),
      hinweis('Du musst nicht alles auf einmal eintragen. Mit Namen und Art läuft MobiMory schon. Alles andere ergänzt du, wenn du es brauchst. Wie du Daten in MobiMory bekommst, steht in Kapitel 4.',
        'You do not have to enter everything at once. With a name and a type MobiMory already works. You add the rest when you need it. How to get data into MobiMory is described in chapter 4.')
    ] },

    { id: 'erfassen', titel: { de: 'Ich bringe meine Daten in MobiMory: fünf Wege', en: 'I get my data into MobiMory: five ways' }, bloecke: [
      p('Personen und Fahrzeuge kommen auf fünf Wegen in MobiMory. Such dir den, der zu deiner Lage passt. Du kannst die Wege mischen.',
        'People and vehicles get into MobiMory in five ways. Pick the one that suits your situation. You can mix them.'),
      kopf('Weg 1: von Hand', 'Way 1: by hand'),
      p('Du legst Person oder Fahrzeug selbst an. Das ist der Weg für ein einzelnes Fahrzeug. Name und Art genügen, alles andere kommt später. Bei einem Fahrzeug siehst du dabei auch die Checkliste „Welche Komponenten hat das Fahrzeug?“ (freiwillig). Dort hakst du an, was an Bord ist.',
        'You create the person or vehicle yourself. This is the way for a single vehicle. Name and type are enough, everything else can follow. For a vehicle you also see the checklist “Which components does the vehicle have?” (optional). There you tick what is on board.'),
      schritte(['Hauptmenü › Stammdaten › Fahrzeuge, dann „Fahrzeug anlegen“. Für Personen: Stammdaten › Personen › „Person anlegen“.',
        'Wähle bei einem Fahrzeug die Art und gib einen Namen ein. Bei einer Person gib den Namen und die Funktion ein (Skipper, Fahrer, Crew, Beifahrer, Gast).',
        'Speichern. Jede spätere Änderung bleibt im Änderungsverlauf des Fahrzeugs.'],
        ['Main menu › Master data › Vehicles, then “Add vehicle”. For people: Master data › People › “Add person”.',
          'For a vehicle choose the type and enter a name. For a person enter the name and the role (skipper, driver, crew, passenger, guest).',
          'Save. Every later change stays in the vehicle’s change history.']),
      bild('erfassen-wege', 'Stammdaten › Fahrzeuge: Fahrzeug anlegen, Import und Export, Übergabedatei einlesen.', 'Master data › Vehicles: add vehicle, import and export, read handover file.'),
      kopf('Weg 2: Schnellstart', 'Way 2: quick start'),
      p('Beim ersten Öffnen legst du in drei Schritten eine Person, ein Fahrzeug und deine erste Aktivität an (Kapitel 1). Du findest den Schnellstart danach im Hauptmenü.',
        'When you first open the app you create a person, a vehicle and your first activity in three steps (chapter 1). Afterwards you find the quick start in the main menu.'),
      kopf('Weg 3: Dokument erfassen (fotografieren oder scannen)', 'Way 3: capture document (photograph or scan)'),
      p('Du fotografierst einen Ausweis, Führerschein, Sportbootführerschein, ein Funkzeugnis, das Bodensee-Schifferpatent, den Fachkundenachweis Sprengstoffrecht oder eine Zulassungsbescheinigung Teil I. Du kannst auch ein Foto oder einen Scan aus deinem Gerät wählen. MobiMory liest die Angaben und schlägt sie dir vor.',
        'You photograph an ID card, driving licence, sports boat licence, a radio certificate, the Bodensee skipper licence, the explosives expert certificate or a registration certificate part I. You can also choose a photo or a scan from your device. MobiMory reads the details and suggests them to you.'),
      schritte(['Hauptmenü › Funktionen › „Dokument erfassen“. Dasselbe Scannen gibt es beim Anlegen von Fahrzeug, Person und Komponenten und bei „Rechnung scannen“.',
        'Lege das Dokument flach auf einen einfarbigen Untergrund, ohne Spiegelung, und richte es im Zielrahmen aus. Die Kamera sagt dir, wenn es zu hell, zu weit weg oder zu nah ist. Bei Heften erst die Seite mit deinen Angaben, bei Bedarf danach eine weitere Seite.',
        'Prüfe die gelesenen Angaben. Jede Angabe kannst du einzeln ändern, ohne neu zu scannen. Gespeichert wird erst, wenn du unten bestätigst.'],
        ['Main menu › Functions › “Capture document”. The same scanning is available when you add a vehicle, a person or components and under “Scan invoice”.',
          'Place the document flat on a plain surface, without reflections, and align it in the frame. The camera tells you if it is too bright, too far or too close. For booklets, first the page with your details, then another page if needed.',
          'Check the details that were read. You can change each detail individually without scanning again. Nothing is saved until you confirm at the bottom.']),
      hinweis('Das Lesen ist eine Hilfe und keine rechtsgültige Aussage: Prüfe jede Angabe, bevor du speicherst. Den Lesedienst (Google, Rechenzentrum in der EU) gibt es nur mit einem Konto ab der Stufe Mittel. Ohne deine Zustimmung wird kein Foto gesendet. Im Monat sind es 10 Scans in der Testwoche, 50 bei Mittel und 100 bei Voll.',
        'The reading is an aid and not a legally binding statement: check every detail before you save. The reading service (Google, data centre in the EU) is only available with an account of level Medium or higher. No photo is sent without your consent. Per month that is 10 scans in the trial week, 50 with Medium and 100 with Full.'),
      kopf('Weg 4: Excel oder CSV einlesen', 'Way 4: import Excel or CSV'),
      p('Hast du deine Fahrzeuge schon in einer Tabelle? Dann übernimm sie auf einmal. Jede Zeile wird ein Fahrzeug. Es wird bis zu 1.000 Zeilen pro Datei gelesen.',
        'Do you already have your vehicles in a spreadsheet? Then take them over in one go. Each row becomes a vehicle. Up to 1,000 rows per file are read.'),
      schritte(['Stammdaten › Fahrzeuge › „Import (Excel oder CSV)“. Wähle die Datei (Excel .xlsx oder CSV).',
        'Wähle die Fahrzeugart. Stehen verschiedene Arten in der Tabelle, wähle „steht in einer Spalte“ und ordne die Spalte „Fahrzeugart“ zu.',
        'MobiMory ordnet die Spalten nach ihren Überschriften zu und versteht deutsche Zahlen und Datumsformate. Prüfe die Zuordnung und ändere, was nicht stimmt. Spalten, die du nicht brauchst, lässt du auf „nicht übernehmen“.',
        'Sieh dir die Vorschau an und übernimm. Vorhandene Fahrzeuge werden nie überschrieben.'],
        ['Master data › Vehicles › “Import (Excel or CSV)”. Choose the file (Excel .xlsx or CSV).',
          'Choose the vehicle type. If the table contains different types, choose “is in a column” and assign the column “vehicle type”.',
          'MobiMory assigns the columns by their headings and understands German number and date formats. Check the assignment and change what is wrong. Columns you do not need stay on “do not import”.',
          'Look at the preview and import. Existing vehicles are never overwritten.']),
      bild('erfassen-import', 'Der Import: Datei wählen, Spalten zuordnen, Vorschau.', 'The import: choose the file, assign columns, preview.'),
      kopf('Weg 5: Übergabedatei einlesen', 'Way 5: read a handover file'),
      p('Hast du ein Fahrzeug gekauft oder geschenkt bekommen und vom bisherigen Besitzer eine Übergabedatei erhalten? Dann liest du sie ein und wirst Besitzer des Fahrzeugs, mit seiner technischen Historie. Ist die Datei verschlüsselt, gibt dir der bisherige Besitzer das Schlüsselwort.',
        'Did you buy a vehicle or get it as a gift, and did you receive a handover file from the previous owner? Then you read it in and become the owner of the vehicle, with its technical history. If the file is encrypted, the previous owner gives you the keyword.'),
      schritte(['Stammdaten › Fahrzeuge › „Übergabedatei einlesen“. Wähle die Datei und gib bei Bedarf das Schlüsselwort ein.',
        'Du siehst zuerst, was in der Datei steht. Es wird noch nichts verändert. Deine vorhandenen Fahrzeuge und Daten bleiben unberührt.',
        'Bestätige. Das Fahrzeug wird als neues Fahrzeug angelegt. Vorhandenes wird nicht verändert oder überschrieben.'],
        ['Master data › Vehicles › “Read handover file”. Choose the file and enter the keyword if needed.',
          'First you see what is in the file. Nothing is changed yet. Your existing vehicles and data stay untouched.',
          'Confirm. The vehicle is created as a new vehicle. Existing data is not changed or overwritten.']),
      bild('erfassen-uebergabe', 'Die Übergabedatei einlesen.', 'Reading a handover file.'),
      kopf('Gibt es das schon?', 'Does it exist already?'),
      p('Bei Import, Übergabe und Anlegen prüft MobiMory, ob es das Fahrzeug schon gibt: nach Kennzeichen, Registriernummer, Fahrgestellnummer (FIN) oder Rumpfnummer (HIN). Beim Anlegen und bei der Übergabe fragt es nach und legt nichts an, solange du nicht trotzdem bestätigst. Meist ist es besser, das vorhandene Fahrzeug zu öffnen. Beim Import überspringt es Fahrzeuge, die es schon gibt (Status „Gibt es schon“). Die Gegenrichtung gibt es auch: Unter „Fahrzeug abgeben“ erstellst du eine Übergabedatei für den neuen Besitzer.',
        'For import, handover and adding, MobiMory checks whether the vehicle already exists: by registration, registry number, chassis number (VIN) or hull number (HIN). When adding and at handover it asks and creates nothing unless you confirm anyway. It is usually better to open the existing vehicle. With the import it skips vehicles that already exist (status “Gibt es schon”). The opposite direction exists too: under “Hand over vehicle” you create a handover file for the new owner.')
    ] },

    { id: 'fahrzeug', titel: { de: 'Ich pflege mein Fahrzeug: Hülle, Komponenten und alles, was daran hängt', en: 'I maintain my vehicle: shell, components and everything attached' }, bloecke: [
      p('Ein Fahrzeug ist in MobiMory wie eine Zwiebel aufgebaut: erst die Art, dann die Äußere Hülle mit den Angaben zum Fahrzeug, dann die Hauptkomponenten, darunter beliebig tief die Teile. An jedem Teil hängen Fristen, Dokumente und mehr.',
        'In MobiMory a vehicle is built like an onion: first the type, then the outer shell with the details of the vehicle, then the main components, and below them parts to any depth. Deadlines, documents and more are attached to every part.'),
      kopf('Die Art bestimmt die Felder', 'The type determines the fields'),
      p('Wähle bei „Fahrzeug anlegen“ die Art. Es gibt 19 Fahrzeugarten:', 'Choose the type under “Add vehicle”. There are 19 vehicle types:'),
      liste(['An Land (8): Auto, Motorrad, Transporter, Lkw, Wohnmobil, Wohnwagen, Anhänger, Bootstrailer',
        'Auf dem Wasser (10): Motorboot, Segelboot Monohull, Segelboot Katamaran, Segelboot Jolle oder Kleinboot, Schlauchboot oder RIB, Jetski, Hausboot, Beiboot oder Dinghy, Paddel- oder Ruderboot, Sonstiges Wasserfahrzeug',
        'In der Luft (1): Flugzeug'],
        ['On land (8): car, motorcycle, van, truck, motorhome, caravan, trailer, boat trailer',
          'On the water (10): motorboat, sailing boat monohull, sailing boat catamaran, sailing boat dinghy or small boat, inflatable or RIB, jet ski, houseboat, tender or dinghy, paddle or rowing boat, other watercraft',
          'In the air (1): aeroplane']),
      bild('fahrzeug-art', 'Fahrzeug anlegen: die Art wählen.', 'Add vehicle: choose the type.'),
      p('Die Art entscheidet, welche Angaben MobiMory fragt. Ein Boot hat Registriernummer, Rumpfnummer (HIN), Heimathafen, Baumaterial, Tiefgang und Durchfahrtshöhe. Ein Wohnmobil hat Kennzeichen, Fahrgestellnummer (FIN), Achsen, Mautklasse, Höhe und Anhängelast. Eigene Arten und Untergruppen legst du unter Stammdaten › Fahrzeugarten an.',
        'The type decides which details MobiMory asks for. A boat has registry number, hull number (HIN), home port, building material, draught and clearance height. A motorhome has registration, chassis number (VIN), axles, toll class, height and towing capacity. You create your own types and subgroups under Master data › Vehicle types.'),
      kopf('Die Äußere Hülle: Angaben zum Fahrzeug', 'The outer shell: details of the vehicle'),
      p('Öffne das Fahrzeug und tippe auf „Angaben ändern“. Die Felder stehen in Gruppen:', 'Open the vehicle and tap “Change details”. The fields are in groups:'),
      liste(['Fahrzeug: Marke, Modell, Typ, Baujahr, Erstzulassung, Kennzeichen oder Registriernummer, FIN oder HIN, Personen und Plätze',
        'Maße: Länge, Breite, Höhe oder Tiefgang, bei Booten die Durchfahrtshöhe',
        'Gewichte: Leergewicht, zulässiges Gesamtgewicht (bei Wohnmobil auch Anhänge- und Stützlast, bei Booten die Verdrängung)',
        'Kraftstoff und Geschwindigkeit: Kraftstoff, Höchst- und Reisegeschwindigkeit. Die Reisegeschwindigkeit nutzt MobiMory für die Ankunftszeit.',
        'Einordnung und Eignung: Antrieb, Zustand, Auslegung, Eignung und Ausstattung',
        'Achsen und Maut (nur bei Straßenfahrzeugen wie dem Wohnmobil): Achsen, Mautklasse',
        'Versicherung: Versicherung, Versicherungsnummer, Telefon für Schadenmeldungen'],
        ['Vehicle: make, model, type, year, first registration, registration or registry number, VIN or HIN, persons and seats',
          'Dimensions: length, width, height or draught, for boats the clearance height',
          'Weights: unladen weight, permitted total weight (for motorhomes also towing and nose weight, for boats the displacement)',
          'Fuel and speed: fuel, top and cruising speed. MobiMory uses the cruising speed for the arrival time.',
          'Classification and suitability: drive, condition, design, suitability and equipment',
          'Axles and toll (road vehicles only, such as the motorhome): axles, toll class',
          'Insurance: insurer, policy number, telephone for damage reports']),
      bild('fahrzeug-maske', 'Angaben ändern: die Felder in Gruppen.', 'Change details: the fields in groups.'),
      p('Die Größenklasse rechnet MobiMory aus der Länge: Klein (bis 6 m), Mittel (6 bis 9 m), Groß (9 bis 15 m), Sehr groß (ab 15 m). Du trägst sie nicht ein.',
        'MobiMory works out the size class from the length: Small (up to 6 m), Medium (6 to 9 m), Large (9 to 15 m), Very large (from 15 m). You do not enter it.'),
      kopf('Die Hauptkomponenten und die Teile darunter', 'The main components and the parts below them'),
      p('Auf der Fahrzeugseite steht der Block „Hauptkomponenten“. Tippe auf „Hauptkomponente hinzufügen“. Die Arten sind Motor, Getriebe, Tank, Heizung, Klima, Stromversorgung, Wasserversorgung und Sonstiges. Unter jeder Komponente legst du Teile an, beliebig tief (zum Beispiel Motor › Anlasser › Kabel).',
        'The vehicle page has the block “Main components”. Tap “Add main component”. The types are engine, gearbox, tank, heating, air conditioning, power supply, water supply and other. Below each component you add parts, to any depth (for example engine › starter › cable).'),
      liste(['Teil: Hersteller, Modell, Seriennummer, Kurzname (bis 8 Zeichen), Baujahr, Anzahl',
        'Einbau: eingebaut am, Einbauort, ausgebaut am. So bleibt der Ausbau nachvollziehbar.',
        'Technische Merkmale: Werte wie Leistung oder Spannung, ausgewählt aus der Merkmale-Liste (Kapitel 8)',
        'Eignung geprüft und „Liefert Strom als“: für Verbraucher und Stromversorgung'],
        ['Part: manufacturer, model, serial number, short name (up to 8 characters), year, quantity',
          'Installation: installed on, location, removed on. This keeps removals traceable.',
          'Technical characteristics: values such as power or voltage, chosen from the characteristics list (chapter 8)',
          'Suitability checked and “Supplies power as”: for consumers and power supply']),
      bild('fahrzeug-huelle', 'Die Fahrzeugseite: Hülle, Hauptkomponenten, Fristen und mehr.', 'The vehicle page: shell, main components, deadlines and more.'),
      bild('fahrzeug-komponente', 'Eine Komponente mit ihren Angaben.', 'A component with its details.'),
      hinweis('Beim Anlegen eines Fahrzeugs hilft die Checkliste „Welche Komponenten hat das Fahrzeug?“. Fehlt dort etwas, legst du es unter Stammdaten › Merkmale und Einheiten › Komponentenliste selbst an.',
        'When you add a vehicle, the checklist “Which components does the vehicle have?” helps you. If something is missing there, you add it yourself under Master data › Characteristics and units › Component list.'),
      kopf('Was am Fahrzeug und an den Komponenten hängt', 'What is attached to the vehicle and its components'),
      p('Auf der Fahrzeugseite stehen untereinander diese Blöcke. Fristen, Dokumente und Zähler hängen auch an einzelnen Komponenten.',
        'These blocks are listed one below the other on the vehicle page. Deadlines, documents and counters can also be attached to single components.'),
      liste(['Fristen: Wartung oder Prüfung, fällig nach Zeit (Monate oder Jahre) oder nach Strecke oder Betriebsstunden. Du legst fest, wie früh MobiMory vorwarnt und was bei Überfälligkeit passiert: nur warnen, eingeschränkt oder Sperre. Überfällige Fristen stehen ganz oben. Beispiele: Ölwechsel, Feuerlöscher, Hauptuntersuchung.',
        'Dokumente: Bedienungsanleitung, Ersatzteilliste, Wartungsanleitung, Reparaturbuch, Kaufbeleg oder Rechnung, Garantie, Foto oder Sonstiges, als Datei vom Gerät oder als Link.',
        'Nachweise: Papiere des Fahrzeugs, zum Beispiel Zulassungsbescheinigung oder Hauptuntersuchung, mit „gültig bis“ (siehe Kapitel 6).',
        'Anforderungen: Du legst fest, welche Nachweise ein Verantwortlicher für dieses Fahrzeug braucht, zum Beispiel einen Führerschein. Es genügt jeweils eine der gewählten Arten. Bei mehreren Anforderungen müssen alle erfüllt sein. Bei der Planung prüft MobiMory das für dich.',
        'Verbrauch und Versorgung: Tanks und Verbraucher, und was woher versorgt wird.',
        'Zusammengehörige Fahrzeuge: Zugfahrzeug und Anhänger, Boot und Trailer.',
        'Heimatstandort: wo das Fahrzeug normalerweise steht. Er bestimmt das Heimatland für den Grundcheck. Du wählst ihn aus deinen Orten mit Standort. Der frühere Stand bleibt im Verlauf.',
        'Zähler (Strecke und Betriebsstunden), Kosten, Werkstatt und Grundcheck: dazu gibt es eigene Kapitel. Das Kapitel zu den Zählern folgt später.'],
        ['Deadlines: maintenance or inspection, due after a time (months or years) or after distance or operating hours. You decide how early MobiMory warns and what happens when overdue: warn only, restricted or block. Overdue deadlines are shown at the top. Examples: oil change, fire extinguisher, technical inspection.',
          'Documents: operating manual, spare parts list, maintenance manual, repair book, purchase receipt or invoice, warranty, photo or other, as a file from the device or as a link.',
          'Proofs: papers of the vehicle, for example registration certificate or technical inspection, with “valid until” (see chapter 6).',
          'Requirements: you decide which proofs a responsible person needs for this vehicle, for example a driving licence. One of the chosen types is enough each time. With several requirements all must be met. MobiMory checks this for you during planning.',
          'Consumption and supply: tanks and consumers, and what is supplied from where.',
          'Related vehicles: towing vehicle and trailer, boat and trailer.',
          'Home location: where the vehicle normally stays. It determines the home country for the basic check. You choose it from your places with a location. The earlier setting stays in the history.',
          'Counters (distance and operating hours), costs, workshop and basic check: these have their own chapters. The chapter on counters follows later.']),
      p('Verkauft, verschenkt oder verschrottet? Unter „Fahrzeug abgeben“ verschwindet das Fahrzeug aus den Auswahllisten, bleibt bei dir aber lesbar. Nichts wird gelöscht.',
        'Sold, given away or scrapped? Under “Hand over vehicle” the vehicle disappears from the selection lists but stays readable for you. Nothing is deleted.')
    ] },

    { id: 'personen', titel: { de: 'Ich lege Personen, Tiere und ihre Nachweise an', en: 'I add people, animals and their proofs' }, bloecke: [
      p('Wer mitfährt, legst du unter Stammdaten › Personen an, Tiere unter Stammdaten › Tiere. Personen und Tiere gibt es nur einmal. Du wählst sie bei jeder Aktivität aus.',
        'Who travels with you is added under Master data › People, animals under Master data › Animals. People and animals exist only once. You choose them for each activity.'),
      kopf('Die Person', 'The person'),
      liste(['Name',
        'Funktionen: Skipper, Fahrer, Crew, Beifahrer, Gast (mehrere sind möglich)',
        'E-Mail, Telefon, Notiz'],
        ['Name',
          'Roles: skipper, driver, crew, passenger, guest (several are possible)',
          'E-mail, telephone, note']),
      bild('personen-formular', 'Die Person mit ihren Angaben und Nachweisen.', 'A person with their details and proofs.'),
      p('Ausweisnummer, Geburtsdatum und Wohnort stehen nicht an der Person. Sie gehören zu den Nachweisen und bleiben nur auf deinem Gerät.',
        'ID number, date of birth and place of residence are not stored with the person. They belong to the proofs and stay on your device only.'),
      kopf('Das Tier', 'The animal'),
      p('Ein Tier hat einen Namen, eine Tierart (Hund, Katze, Frettchen, Vogel, Pferd, Kleintier, Sonstiges), eine Chipnummer und eine Notiz. Tiere können Nachweise haben, zum Beispiel den EU-Heimtierausweis oder die Tollwutimpfung. Ein Tier kann nie Rudergänger sein.',
        'An animal has a name, a species (dog, cat, ferret, bird, horse, small animal, other), a chip number and a note. Animals can have proofs, for example the EU pet passport or the rabies vaccination. An animal can never be the helmsperson.'),
      kopf('Nachweise', 'Proofs'),
      p('Ein Nachweis ist ein Papier mit Fristen: Führerschein, Ausweis, Funkzeugnis, Heimtierausweis, Zulassungsbescheinigung. Er gehört zu einer Person, einem Tier oder einem Fahrzeug. Du öffnest die Person und tippst auf „Nachweis hinzufügen“.',
        'A proof is a paper with deadlines: driving licence, ID, radio certificate, pet passport, registration certificate. It belongs to a person, an animal or a vehicle. You open the person and tap “Add proof”.'),
      liste(['Art des Nachweises (aus der Liste der Nachweisarten)', 'Nummer und Aussteller', 'Ausgestellt am und gültig bis', 'Klassen oder Stufen (zum Beispiel die Führerscheinklassen)', 'Scan oder Foto (freiwillig): bleibt nur auf deinem Gerät, oder mit Schlüsselwort verschlüsselt auf deinem Konto'],
        ['Type of proof (from the list of proof types)', 'Number and issuer', 'Issued on and valid until', 'Classes or levels (for example the driving licence classes)', 'Scan or photo (optional): stays on your device only, or encrypted with the keyword on your account']),
      bild('personen-nachweis', 'Ein Nachweis mit „gültig bis“ und Status.', 'A proof with “valid until” and status.'),
      p('MobiMory warnt dich 30 Tage vor dem Ablauf. Ein Nachweis mit Scan oder Foto zählt, wenn die Planung prüft, ob ein Verantwortlicher alle Anforderungen des Fahrzeugs erfüllt.',
        'MobiMory warns you 30 days before expiry. A proof with a scan or photo counts when planning checks whether a responsible person meets all requirements of the vehicle.'),
      p('Unter Stammdaten › Nachweisarten stehen die Arten. Dort übernimmst du Vorschläge (zum Beispiel Führerschein, Personalausweis, Reisepass, Sportbootführerschein, Funkzeugnisse SRC, LRC und UBI, Bodensee-Schifferpatent, EU-Heimtierausweis, Tollwutimpfung, Zulassungsbescheinigung Teil I und II, Hauptuntersuchung, Internationaler Bootsschein) oder legst eigene an.',
        'Under Master data › Proof types you find the types. There you take over suggestions (for example driving licence, ID card, passport, sports boat licence, radio certificates SRC, LRC and UBI, Bodensee skipper licence, EU pet passport, rabies vaccination, registration certificate part I and II, technical inspection, international boat certificate) or add your own.')
    ] },

    { id: 'orte', titel: { de: 'Ich lege Orte, Gebiete und Adressen an', en: 'I add places, areas and addresses' }, bloecke: [
      p('Orte sind das, wohin du fährst und wo du stehst. Route, Wetter, Karte, Wache und Grundcheck nutzen sie. Ohne Position (Breite und Länge) kann MobiMory einen Ort nicht berechnen. Die Ortssuche trägt sie für dich ein.',
        'Places are where you go and where you stay. Route, weather, map, watch and basic check use them. Without a position (latitude and longitude) MobiMory cannot calculate with a place. The place search fills it in for you.'),
      kopf('Ort', 'Place'),
      liste(['Art: Heimatort, Stellplatz, Campingplatz, Hafen oder Marina, Ankerplatz oder Boje, Parkplatz oder Garage, Sonstiger Ort',
        'Land, Revier (Binnenwasserstraße), Adresse, Breite und Länge',
        'Ausstattung: zum Beispiel Strom, Frischwasser, Entsorgung, WLAN, Dusche, WC, Treibstoff, Gas, Slip oder Kran, Hunde erlaubt',
        'Ansprechpartner, Telefon, Notiz'],
        ['Type: home place, pitch, campsite, harbour or marina, anchorage or buoy, car park or garage, other place',
          'Country, waterway (inland), address, latitude and longitude',
          'Facilities: for example electricity, fresh water, disposal, Wi-Fi, shower, toilet, fuel, gas, slip or crane, dogs allowed',
          'Contact person, telephone, note']),
      bild('orte-ort', 'Ein Ort mit Position, Ausstattung und Standorten.', 'A place with position, facilities and locations.'),
      kopf('Standort: der Platz in einem Ort', 'Location: the spot within a place'),
      p('In einem Ort kannst du Standorte anlegen: den Liegeplatz im Hafen, den Stellplatz auf dem Campingplatz, die Garage. Ein Standort hat eine Art, eine eigene Position und die Platzmaße (Länge, Breite, Tiefe am Platz, Höhe der Durchfahrt oder Halle). Einen Standort wählst du als Heimatstandort deines Fahrzeugs.',
        'In a place you can add locations: the berth in the harbour, the pitch on the campsite, the garage. A location has a type, its own position and the dimensions of the spot (length, width, depth at the berth, height of the passage or hall). You choose a location as the home location of your vehicle.'),
      kopf('Gebiete und ihre Regeln', 'Areas and their rules'),
      p('Gebiete sind Länder, Regionen, Kreise, Reviere (Binnenwasserstraßen) und einzelne Orte. An ein Gebiet hängst du Regeln. Der Grundcheck und der Reisecheck prüfen sie für dich.',
        'Areas are countries, regions, districts, waterways (inland) and single places. You attach rules to an area. The basic check and the trip check test them for you.'),
      liste(['Befähigung: ein Nachweis der Person muss vorhanden sein, zum Beispiel ein Funkzeugnis',
        'Pflichtausrüstung: etwas muss am Fahrzeug sein, zum Beispiel eine Rettungsweste'],
        ['Qualification: a proof of the person must exist, for example a radio certificate',
          'Mandatory equipment: something must be on the vehicle, for example a life jacket']),
      bild('orte-gebiet', 'Ein Gebiet mit seinen Regeln.', 'An area with its rules.'),
      kopf('Adressen', 'Addresses'),
      p('Unter Stammdaten › Adressen stehen Werkstätten, Lieferanten und Händler. Du wählst sie bei einer Störung in der Werkstatt, bei Kosten und für Schadensberichte.',
        'Under Master data › Addresses you find workshops, suppliers and dealers. You choose them for a fault in the workshop, for costs and for damage reports.')
    ] },

    { id: 'listen', titel: { de: 'Ich pflege die Auswahllisten', en: 'I maintain the selection lists' }, bloecke: [
      p('Überall, wo du etwas aus einer Liste wählst, kannst du die Liste selbst ändern. Die Vorlage von MobiMory ist nur der Anfang. Eigene Einträge legst du an, auch mitten im Formular.',
        'Wherever you choose something from a list you can change the list itself. MobiMory’s template is just the start. You add your own entries, even in the middle of a form.'),
      liste(['Arten von Aktivitäten: Urlaub, Törn, Ausfahrt und mehr',
        'Arten von Ereignissen: was du im Logbuch und im Cockpit festhältst, zum Beispiel Abfahrt und Ankunft',
        'Fahrzeugarten und Nachweisarten',
        'Merkmale und Einheiten: die Merkmale der Komponenten, die Einheiten (damit „kn“ und „Knoten“ nicht durcheinandergehen), die Stoffe (Treibstoff, Gas, Strom), die Spannungen und die Komponentenliste für die Checkliste beim Anlegen eines Fahrzeugs',
        'Kostenarten und Zahlungsmittel: nur Bezeichnungen wie „Girokarte“ oder „Kreditkarte“, nie Karten- oder Kontonummern. „Bar“ gehört zur Kasse und bleibt immer da.'],
        ['Types of activities: holiday, trip, outing and more',
          'Types of events: what you record in the logbook and the cockpit, for example departure and arrival',
          'Vehicle types and proof types',
          'Characteristics and units: the characteristics of components, the units (so that “kn” and “knots” do not get mixed up), the substances (fuel, gas, electricity), the voltages and the component list for the checklist when adding a vehicle',
          'Cost types and means of payment: names only, such as “debit card” or “credit card”, never card or account numbers. “Cash” belongs to the cash book and always stays.']),
      bild('listen-merkmale', 'Merkmale und Einheiten, Stoffe und Komponentenliste.', 'Characteristics and units, substances and component list.'),
      bild('listen-kosten', 'Kostenarten und Zahlungsmittel.', 'Cost types and means of payment.'),
      hinweis('Gelöscht wird nichts, was schon benutzt ist. Du blendest es aus: Es erscheint dann nicht mehr zur Auswahl, bleibt aber überall dort, wo es schon steht. Nur eigene, noch unbenutzte Einträge kannst du löschen.',
        'Nothing that is already in use is deleted. You hide it: it then no longer appears for selection but stays everywhere it already is. You can only delete your own entries that are not yet used.')
    ] },

    { id: 'planen', titel: { de: 'Ich will eine Route planen: Aktivität, Route, Tag', en: 'I want to plan a route: activity, route, day' }, bloecke: [
      p('Du planst von außen nach innen: zuerst die Aktivität (die ganze Reise), dann die Route, dann die einzelnen Tage.',
        'You plan from the outside in: first the activity (the whole trip), then the route, then the single days.'),
      kopf('1. Die Aktivität', '1. The activity'),
      bild('planen-aktivitaet', 'Die Aktivität planen: Art, Fahrzeug und Zeitraum.', 'Planning the activity: type, vehicle and period.'),
      schritte(['Öffne Funktionen › Aktivitäten und tippe auf „Aktivität planen“.', 'Wähle die Art (zum Beispiel Urlaub oder Törn), das Fahrzeug, von und bis wann, und die verantwortliche Person.',
        'Trage Start, Ziel und Zwischenziele ein. Die Zwischenziele sind eine nummerierte Liste. Mit „Hoch“ und „Runter“ änderst du die Reihenfolge. Es sind so viele Zwischenziele möglich, wie die Aktivität Tage hat, höchstens 25. Jedes braucht einen Ort mit Position.'],
        ['Open Functions › Activities and tap “Plan activity”.', 'Choose the type (for example holiday or cruise), the vehicle, from and until when, and the responsible person.',
          'Enter start, destination and stopovers. The stopovers are a numbered list. Use “Up” and “Down” to change the order. As many stopovers are possible as the activity has days, at most 25. Each needs a place with a position.']),
      kopf('2. Die Route', '2. The route'),
      bild('planen-route', 'Die Seite „Route und Wetter“ der Aktivität.', 'The “Route and weather” page of the activity.'),
      p('Bei der Aktivität öffnest du „Route und Wetter“. Dort liest du eine Routendatei (GPX) ein, zum Beispiel aus deiner Navigations-App. Du siehst den Fahrplan und kannst das Wetter holen.',
        'At the activity you open “Route and weather”. There you load a route file (GPX), for example from your navigation app. You see the schedule and can fetch the weather.'),
      kopf('3. Der Tag', '3. The day'),
      bild('planen-tag', 'Der Tag mit Start, Ziel und Ankunftszeit.', 'The day with start, destination and arrival time.'),
      p('Jede Aktivität besteht aus Tagen. Jeder Tag hat einen Start und ein Ziel. Tag 2 startet am Ziel von Tag 1, du kannst es ändern. Trage bei jedem Tag die Uhrzeit des Beginns ein.',
        'Each activity consists of days. Each day has a start and a destination. Day 2 starts at the destination of day 1; you can change it. Enter the start time for every day.'),
      p('Bei Straßenfahrzeugen plant MobiMory einen Tag für sich:', 'For road vehicles MobiMory plans one day at a time:'),
      schritte(['Öffne die Seite des Tages und tippe auf „Tag planen“. Du kannst vorher bis zu 10 Zwischenziele für diesen Tag wählen.',
        'MobiMory plant vom Start zum Ziel des Tages, mit den Maßen und Gewichten deines Fahrzeugs. Du siehst Länge, Fahrzeit und Warnungen.',
        'Die Tagesroute kannst du als GPX-Datei sichern.'],
        ['Open the page of the day and tap “Plan day”. Beforehand you can choose up to 10 stopovers for this day.',
          'MobiMory plans from the start to the destination of the day, using your vehicle’s dimensions and weights. You see length, travel time and warnings.',
          'You can save the day route as a GPX file.']),
      hinweis('Jede geplante Tagesroute zählt als 1 Route in deinem Konto: fünf Tage sind fünf Routen. Die Routenplanung läuft über dein MobiMory-Konto (ab Stufe Mittel). Für Wasserfahrzeuge plant MobiMory keine Route; du kannst das Ziel in einer Navigations-App öffnen.',
        'Each planned day route counts as 1 route in your account: five days are five routes. Route planning runs over your MobiMory account (from the Medium level). For watercraft MobiMory does not plan a route; you can open the destination in a navigation app.'),
      kopf('Voraussichtliche Ankunft (ETA)', 'Estimated arrival (ETA)'),
      p('Die ETA steht beim Tag und nach dem Ablegen. Bei Straßenfahrzeugen rechnet sie mit der Länge der geplanten Tagesroute und der Reisegeschwindigkeit deines Fahrzeugs. Ist der Tag noch nicht geplant, steht dort „unklar“ und der Hinweis, den Tag zu planen. Strömung, Schleusen, Pausen und Tide sind nicht enthalten. Das ist eine Hilfestellung und keine rechtliche Aussage.',
        'The ETA shows at the day and after casting off. For road vehicles it uses the length of the planned day route and your vehicle’s cruising speed. If the day is not planned yet, it shows “unclear” and the hint to plan the day. Current, locks, breaks and tide are not included. This is an aid and not a legal statement.')
    ] },

    { id: 'checks', titel: { de: 'Ich prüfe, ob alles stimmt: Reisecheck und Grundcheck', en: 'I check that everything is in order: trip check and basic check' }, bloecke: [
      p('Reisecheck: Er sagt dir, was für diese Reise nötig ist (Papiere, Ausrüstung, Regeln der Länder und Gebiete) und ob es bei dir erfüllt ist. Du findest ihn unter Funktionen › Reisecheck. Für einen einzelnen Tag gibt es den Check am Tag.',
        'Trip check: It tells you what is needed for this trip (papers, equipment, rules of the countries and areas) and whether you meet it. You find it under Functions › Trip check. For a single day there is the check at the day.'),
      bild('checks-reise', 'Der Reisecheck.', 'The trip check.'),
      p('Grundcheck: Er prüft ein Fahrzeug an seinem Heimatort. Er fragt: Was braucht dieses Fahrzeug im Heimatland an Papieren und Grundausrüstung? Du brauchst dafür keine Aktivität. Du öffnest ihn am Fahrzeug.',
        'Basic check: It checks a vehicle at its home location. It asks: What papers and basic equipment does this vehicle need in its home country? You do not need an activity for it. You open it at the vehicle.'),
      bild('checks-grund', 'Der Grundcheck eines Fahrzeugs.', 'The basic check of a vehicle.'),
      liste(['Jeder Punkt zeigt Quelle und Stand. Es steht dort: vorhanden, zu wenig, fehlt oder unklar.', 'Fehlt etwas, führt ein Link direkt zur Ausrüstung des Fahrzeugs oder zu den Nachweisen.',
        'Heißt ein Punkt bei dir anders (zum Beispiel „Persönliche Schwimmhilfe“ statt „Rettungsweste“), wählst du bei diesem Punkt „Habe ich unter anderem Namen“. MobiMory setzt nie von selbst etwas gleich.',
        'Der Online-Check läuft über dein Konto und zählt zum Kontingent (Mittel 3, Voll 10 in 12 Monaten, egal ob Reisecheck, Tagcheck oder Grundcheck). Schlägt eine Recherche fehl, wird nicht gezählt.',
        'Nach einem Reisecheck merkt sich MobiMory die Ergebnisse als Regeln bei den Orten und Gebieten, mit Datum. Reist du wieder dorthin, siehst du zuerst diesen Überblick mit dem Hinweis, dass die Daten veraltet sein können.'],
        ['Each item shows its source and date. It says: present, too few, missing or unclear.', 'If something is missing, a link leads directly to the vehicle’s equipment or to the proofs.',
          'If an item has a different name for you (for example “personal flotation aid” instead of “life jacket”), choose “I have it under another name” at that item. MobiMory never treats things as equal by itself.',
          'The online check runs over your account and counts towards the quota (Medium 3, Full 10 in 12 months, whether trip check, day check or basic check). If a search fails, it is not counted.',
          'After a trip check, MobiMory remembers the results as rules at the places and areas, with a date. If you travel there again, you first see this overview with the note that the data may be out of date.']),
      hinweis('Die Checks sind eine Hilfe für die Planung und keine rechtsgültige Aussage. Die letzte Verantwortung hat der Skipper bzw. Fahrer. Zum Check gehen keine Namen und keine Nummern ins Netz.',
        'The checks are an aid for planning and not a legally binding statement. The final responsibility lies with the skipper or driver. No names and no numbers go online for the check.')
    ] },

    { id: 'wetter', titel: { de: 'Ich will das Wetter wissen: Vorhersage, Wellen, Tide', en: 'I want to know the weather: forecast, waves, tide' }, bloecke: [
      p('Das Wetter holt MobiMory für die Punkte zwischen Start und Ziel eines Tages, passend zur Ankunftszeit an jedem Punkt. Die Quelle ist Open-Meteo.',
        'MobiMory fetches the weather for the points between the start and the destination of a day, matching the arrival time at each point. The source is Open-Meteo.'),
      bild('wetter-tag', 'Der Tag: Wetter online holen und Orte oder Wetter von Hand ändern.', 'The day: fetch weather online and change places or weather by hand.'),
      schritte(['Öffne die Seite des Tages. Der Tag braucht Start, Ziel mit Position, die Uhrzeit des Beginns und eine Geschwindigkeit.', 'Tippe auf „Wetter online holen“. Später heißt der Knopf „Wetter neu holen“.',
        'Du siehst je Punkt Himmel, Temperatur, Wind, Böen und Regen. Bei Wasserfahrzeugen kommen Wellen, Wasserstand sowie Hoch- und Niedrigwasser dazu.'],
        ['Open the page of the day. The day needs a start, a destination with position, the start time and a speed.', 'Tap “Fetch weather online”. Later the button reads “Fetch weather again”.',
          'For each point you see sky, temperature, wind, gusts and rain. For watercraft, waves, water level and high and low water are added.']),
      liste(['Eine Prognose gibt es nur für die nächsten 15 Tage. Für einen Tag, der mehr als einen Tag zurückliegt, holt MobiMory kein Wetter.',
        'Der geholte Stand bleibt im Gerät und ist auch ohne Netz zu sehen. Zum Holen braucht das Gerät Netz.', 'Du kannst das Wetter eines Tages auch von Hand eintragen.',
        'Im Cockpit schreibt „Wetter jetzt“ das Wetter an deinem Standort als Eintrag ins Logbuch. Wie oft das Wetter im Cockpit automatisch geholt wird, stellst du unter Einstellungen › Anzeige ein.'],
        ['A forecast is only available for the next 15 days. For a day that is more than one day in the past, MobiMory does not fetch weather.',
          'The fetched state stays on the device and can be seen without network. Fetching needs network.', 'You can also enter the weather of a day by hand.',
          'In the cockpit, “Weather now” writes the weather at your position as an entry in the logbook. How often the weather is fetched automatically in the cockpit, you set under Settings › Display.']),
      hinweis('Das sind Prognosen und Modellwerte, keine Garantie und keine amtlichen Gezeitentafeln.', 'These are forecasts and model values, no guarantee and no official tide tables.')
    ] },

    { id: 'unterwegs', titel: { de: 'Ich will unterwegs etwas festhalten: Cockpit und Logbuch', en: 'I want to record things on the way: cockpit and logbook' }, bloecke: [
      p('Das Cockpit ist dein Schnellzugriff unterwegs. Du öffnest es bei der Aktivität. Jeder Eintrag bekommt Datum, Uhrzeit und, wenn das Gerät eine Position hat, den Ort. Daraus wächst dein Logbuch.',
        'The cockpit is your quick access on the way. You open it at the activity. Every entry gets date, time and, if the device has a position, the place. Your logbook grows from this.'),
      bild('cockpit', 'Das Cockpit, Seite 1: Position, Ankunftszeit und Rest.', 'The cockpit, page 1: position, arrival time and remaining distance.'),
      p('Das Cockpit hat drei Seiten. Du wischst nach links und rechts, die Punkte unten zeigen, wo du bist.', 'The cockpit has three pages. You swipe left and right; the dots below show where you are.'),
      liste(['Seite 1: Info mit Position und Ankunftszeit', 'Seite 2: die Knöpfe', 'Seite 3: Motoren, Zähler und Tagesabschluss'], ['Page 1: info with position and arrival time', 'Page 2: the buttons', 'Page 3: engines, counters and end-of-day closing']),
      p('Die wichtigsten Knöpfe:', 'The most important buttons:'),
      liste(['Abfahrt und Ankunft (bei Wasserfahrzeugen „Ablegen“ und „Anlegen“)', 'Notiz und Foto', 'Wetter jetzt', 'Ver- und Entsorgung (zum Beispiel Tanken)',
        'Wechsel: Skipper und Rudergänger (die Verantwortung wechselt, zum Beispiel beim Törn)', 'Kurswechsel festhalten (nur Wasserfahrzeuge): Grund wählen, Notiz schreiben, MobiMory trägt Zeit und Position ein',
        'Wache und Karte'],
        ['Departure and arrival (for watercraft “Cast off” and “Moor”)', 'Note and photo', 'Weather now', 'Supply and disposal (for example refuelling)',
          'Change: skipper and helmsman (responsibility changes, for example on a cruise)', 'Record course change (watercraft only): choose a reason, write a note, MobiMory enters time and position',
          'Watch and map']),
      liste(['Schaltest du einen Motor oder Verbraucher ein oder aus, schreibt MobiMory dazu einen Eintrag ins Logbuch.',
        'Am Ende des Tages machst du den Tagesabschluss mit dem tatsächlichen Ziel und einer Notiz.',
        'Etwas vergessen? Trage es im Logbuch nach. Es steht dann als „nachgetragen“ da. Änderst du die Position eines Eintrags, schreibst du dazu, warum; der Verlauf hält es fest.',
        'Das Cockpit kann von selbst zwischen den Seiten, der Karte und den letzten Ereignissen wechseln. Das schont den Bildschirm. Du stellst es unten auf Seite 3 unter „Ansichten-Wechsel“ ein.'],
        ['If you switch an engine or consumer on or off, MobiMory writes an entry in the logbook.',
          'At the end of the day you do the end-of-day closing with the actual destination and a note.',
          'Forgot something? Add it later in the logbook. It then shows as “added later”. If you change the position of an entry, you write why; the history records it.',
          'The cockpit can switch by itself between the pages, the map and the latest events. This saves the screen. You set it on page 3 under “View switching”.']),
      hinweis('Kilometer und GPS werden nur gezählt, solange MobiMory offen ist. Nur die Android-App zeichnet auch im Hintergrund auf.',
        'Kilometres and GPS are only counted while MobiMory is open. Only the Android app also records in the background.')
    ] },

    { id: 'karte', titel: { de: 'Ich will die Karte nutzen', en: 'I want to use the map' }, bloecke: [
      p('Die Karte öffnest du im Cockpit mit „Karte“ oder bei der Aktivität. Sie füllt den ganzen Bildschirm.', 'You open the map in the cockpit with “Map” or at the activity. It fills the whole screen.'),
      bild('karte', 'Die Karte: Route, gefahrener Weg und deine Position.', 'The map: route, travelled path and your position.'),
      liste(['Du siehst die Route, die Wetterpunkte, den gefahrenen Weg und deine Position. Auf der Karte siehst du auch, wo du auf der Route liegst und ob du früher oder später bist als geplant.',
        'Bei Wasserfahrzeugen zeigt die blaue Linie den Soll-Kurs, die orange den gefahrenen Weg. Die Wechselpunkte stehen als Nummern darauf.',
        'Mit „Folgen“ bleibt die Karte bei dir. Mit „Alles zeigen“ siehst du die ganze Route.',
        'Einträge mit Position erscheinen mit eigenem Zeichen, zum Beispiel „!“ für eine Störung. Unter „Ereignisse“ wählst du, welche Arten du sehen willst, für alle Aktivitäten und bei jeder Aktivität extra.',
        'Für einen einzelnen Tag gibt es die Karte des Tages mit Tagesroute, Start, Ziel und Warnstellen.',
        'Wasserfahrzeuge können auf Wunsch Seezeichen (Tonnen, Leuchtfeuer, Häfen) von OpenSeaMap zeigen.'],
        ['You see the route, the weather points, the travelled path and your position. On the map you also see where you are on the route and whether you are earlier or later than planned.',
          'For watercraft the blue line shows the planned course, the orange one the travelled path. The waypoints are shown on it as numbers.',
          'With “Follow” the map stays with you. With “Show all” you see the whole route.',
          'Entries with a position appear with their own symbol, for example “!” for a fault. Under “Events” you choose which kinds you want to see, for all activities and separately for each activity.',
          'For a single day there is the day map with day route, start, destination and warning spots.',
          'Watercraft can show seamarks (buoys, lights, harbours) from OpenSeaMap on request.']),
      kopf('Karte ohne Internet', 'Map without internet'),
      p('Tippe vor der Fahrt auf „Offline-Karte holen“. MobiMory lädt dann die Kartenbilder für deine Route aufs Gerät, bei Wasserfahrzeugen mit den Seezeichen. Ohne Internet und ohne geholte Karte zeigt die Karte „Kein Internet“.',
        'Before the trip tap “Fetch offline map”. MobiMory then loads the map images for your route onto the device, for watercraft with the seamarks. Without internet and without a fetched map, the map shows “No internet”.'),
      hinweis('Die Seezeichen sind nur eine Information und keine amtliche Karte. Es gibt keine Wassertiefen. Für die Navigation bleiben deine Navigations-App und die amtliche Seekarte zuständig.',
        'The seamarks are information only and not an official chart. There are no water depths. For navigation your navigation app and the official nautical chart remain responsible.')
    ] },

    { id: 'tanken', titel: { de: 'Ich will tanken', en: 'I want to refuel' }, bloecke: [
      p('Tanken trägst du im Cockpit über den Knopf „Ver- und Entsorgung“ ein. Den Knopf gibt es, sobald du die Vorschläge für Fahrzeugarten übernommen hast.', 'You enter refuelling in the cockpit with the button “Supply and disposal”. The button is there as soon as you have taken over the suggestions for vehicle types.'),
      bild('tanken-eingabe', 'Ver- und Entsorgung: Treibstoff tanken.', 'Supply and disposal: refuelling.'),
      schritte(['Einmalig: Stammdaten › Arten von Ereignissen › „Vorschläge für Fahrzeugarten übernehmen“. Dann gibt es „Ver- und Entsorgung“ und „Tanken“ als Ereignisse.',
        'Tippe im Cockpit auf „Ver- und Entsorgung“. Liegt der Knopf nicht zwischen den Cockpit-Knöpfen, findest du ihn unter „Sonstige Ereignisse“. Mit „Knöpfe ändern“ legst du ihn als eigenen Knopf ab.',
        'Wähle bei „Was?“: Treibstoff tanken, Gasflasche tauschen, Frischwasser auffüllen, Grauwasser, Schwarzwasser oder Chemietoilette entleeren. MobiMory zeigt nur, was dein Fahrzeug als Tank hat.',
        'Trage die Angaben ein, nach denen MobiMory fragt, zum Beispiel die Menge und den Preis.'],
        ['Once only: Master data › Types of events › “Take over suggestions for vehicle types”. Then “Supply and disposal” and “Refuelling” exist as events.',
          'In the cockpit tap “Supply and disposal”. If the button is not among the cockpit buttons, you find it under “Other events”. With “Change buttons” you put it on its own button.',
          'Under “What?” choose: refuel, change gas bottle, fill fresh water, empty grey water, black water or chemical toilet. MobiMory only shows what your vehicle has as a tank.',
          'Enter the details MobiMory asks for, for example the quantity and the price.']),
      p('Nach dem Tanken rechnet MobiMory alles, was sich rechnen lässt: Liter je Betriebsstunde, je Kilometer, je Seemeile und je Tag. Die Betriebsstunden und Kilometer kommen aus den Zählern. Der Literpreis steht mit drei Stellen hinter dem Komma.',
        'After refuelling, MobiMory calculates everything that can be calculated: litres per operating hour, per kilometre, per nautical mile and per day. The operating hours and kilometres come from the counters. The price per litre is shown with three decimal places.'),
      p('Den Verbrauch siehst du unter Einstellungen › Anzeige in der Einheit, die du wählst.', 'You see the consumption under Settings › Display in the unit you choose.')
    ] },

    { id: 'wache', titel: { de: 'Ich will sicher ankern: Wache und Standortwache', en: 'I want to anchor safely: watch and location watch' }, bloecke: [
      p('Die Wache ist deine Alarmanlage. Du öffnest sie im Cockpit mit dem Knopf „Wache“.', 'The watch is your alarm system. You open it in the cockpit with the button “Watch”.'),
      bild('wache', 'Die Wache: Radius wählen und „Wache starten“ tippen.', 'The watch: choose a radius and tap “Start watch”.'),
      schritte(['Wähle den Radius.', 'Stelle ein, ob Alarmton und Vibration an diesem Gerät kommen sollen und ob MobiMory warnen soll, wenn sich dieses Gerät 15 Minuten lang nicht mehr meldet.', 'Tippe auf „Wache starten“.'],
        ['Choose the radius.', 'Set whether alarm sound and vibration should come on this device, and whether MobiMory should warn if this device does not report for 15 minutes.', 'Tap “Start watch”.']),
      liste(['Ankerwache: Vor Anker merkt sich MobiMory die Position. Treibt das Fahrzeug über den gewählten Radius hinaus, schlägt die App Alarm mit Ton, Abstand, Richtung und einer Zeichnung des Versatzes.',
        'Standortwache: Bei Stillstand oder festgemacht überwacht sie jedes Fahrzeug, auch an Land.', 'Die Wache braucht kein Internet.',
        '„Ton aus“ stellt den Alarmton ab.'],
        ['Anchor watch: At anchor MobiMory remembers the position. If the vehicle drifts beyond the chosen radius, the app sounds the alarm with sound, distance, direction and a drawing of the offset.',
          'Location watch: At standstill or when moored it watches any vehicle, also on land.', 'The watch does not need internet.',
          '“Sound off” turns off the alarm sound.']),
      kopf('Alarm auf deinen anderen Geräten', 'Alarm on your other devices'),
      schritte(['Melde dich auf den Geräten mit demselben Konto an.', 'Öffne auf jedem Gerät die Seite „Wache“ und tippe auf „Nachrichten auf diesem Gerät erlauben“. Beantworte die Frage des Geräts mit „Zulassen“.',
        'Mit „Test-Nachricht an meine anderen Geräte“ prüfst du, ob es klappt.'],
        ['Sign in on the devices with the same account.', 'On each device open the “Watch” page and tap “Allow messages on this device”. Answer the device’s question with “Allow”.',
          'With “Test message to my other devices” you check that it works.']),
      p('Löst die Wache aus, bekommen deine anderen Geräte eine Nachricht, und eine E-Mail geht an dein Konto. Das ist nur eine Zusatzwarnung und braucht Internet.',
        'If the watch triggers, your other devices get a message and an email goes to your account. This is only an additional warning and needs internet.'),
      hinweis('Im Browser muss der Bildschirm an bleiben. Sicherer ist die Android-App. Verlass dich nicht allein auf die App: Sie ist eine Hilfe, keine Garantie.',
        'In the browser the screen must stay on. The Android app is safer. Do not rely on the app alone: it is an aid, not a guarantee.')
    ] },

    { id: 'kasse', titel: { de: 'Ich will meine Reisekasse und Kosten führen', en: 'I want to keep my travel cash and costs' }, bloecke: [
      p('Jede Aktivität kann ihre Reisekasse haben: Bargeld und Fremdwährung der Reise.', 'Every activity can have its own travel cash box: cash and foreign currency of the trip.'),
      bild('kasse-buch', 'Die Reisekasse einer Aktivität.', 'The travel cash box of an activity.'),
      liste(['Du öffnest die Reisekasse bei der Aktivität. Dort legst du Kassen an und trägst Ausgaben ein.', 'Mit dem Kassensturz vergleichst du, was in der Kasse sein soll, mit dem, was wirklich drin ist.',
        'Im Kassenbuch (Funktionen › Kassenbuch) siehst du die Kassen aller Aktivitäten. Jede Zeile führt zur Reisekasse.',
        'Kosten (Funktionen › Kosten) zeigen Fixkosten, variable Kosten, Instandhaltung und Wertverlust über alle Fahrzeuge.',
        'An einem Posten kannst du ein Foto und Belege anhängen. Falsch eingegeben? Auf der Seite des Postens: Korrigieren, Ausblenden oder Löschen. Löschen fragt vorher nach.'],
        ['You open the travel cash box at the activity. There you create cash boxes and enter expenses.', 'With the cash check you compare what should be in the box with what is really in it.',
          'In the cash book (Functions › Cash book) you see the cash boxes of all activities. Each line leads to the travel cash box.',
          'Costs (Functions › Costs) show fixed costs, variable costs, maintenance and loss of value across all vehicles.',
          'You can attach a photo and receipts to an item. Entered wrongly? On the item’s page: Correct, Hide or Delete. Delete asks first.']),
      p('Kosten werden einem Tag zugeordnet. Die Summe der Reise ist die Summe aller Tage, dazu kommen Posten ohne Tag.', 'Costs are assigned to a day. The sum of the trip is the sum of all days, plus items without a day.')
    ] },

    { id: 'stoerung', titel: { de: 'Ich melde eine Störung: Werkstatt und Schadensbericht', en: 'I report a fault: workshop and damage report' }, bloecke: [
      p('In der Werkstatt (Funktionen › Werkstatt) meldest du Störungen, planst Arbeiten und hakst sie ab.', 'In the workshop (Functions › Workshop) you report faults, plan work and complete it.'),
      bild('stoerung-werkstatt', 'Die Werkstatt.', 'The workshop.'),
      schritte(['Öffne das Fahrzeug oder die betroffene Komponente und tippe auf „Störung melden“.', 'Beschreibe, was nicht geht, und ob das Fahrzeug nutzbar bleibt.',
        'Plane die Arbeit und trage sie als erledigt ein, wenn sie fertig ist.'],
        ['Open the vehicle or the affected component and tap “Report fault”.', 'Describe what does not work and whether the vehicle remains usable.', 'Plan the work and mark it as done when it is finished.']),
      kopf('Schadensbericht für die Versicherung', 'Damage report for the insurance'),
      p('Unter Funktionen › Schadensbericht hältst du einen Schaden fest, mit Fotos und Belegen. Beim Speichern legt MobiMory automatisch eine Störung in der Werkstatt dazu. Den Bericht gibst du als Seite oder als PDF aus, zum Drucken oder Mailen.',
        'Under Functions › Damage report you record damage, with photos and receipts. When you save, MobiMory automatically adds a fault in the workshop. You output the report as a page or as a PDF, to print or email.')
    ] },

    { id: 'reisebuch', titel: { de: 'Ich mache aus der Reise ein Buch: Reisebuch und PDF', en: 'I turn the trip into a book: travel book and PDF' }, bloecke: [
      p('Aus deiner Reise wird ein Buch: Reise, Tag für Tag, Ereignisse, besuchte Orte und deine Fotos. Du liest es in MobiMory, druckst es aus oder speicherst es als PDF. MobiMory ändert dabei nichts an deinen Daten.',
        'Your trip becomes a book: trip, day by day, events, visited places and your photos. You read it in MobiMory, print it or save it as a PDF. MobiMory does not change your data in the process.'),
      bild('reisebuch', 'Das Reisebuch: wähle, was ins Buch kommt.', 'The travel book: choose what goes into the book.'),
      schritte(['Öffne Funktionen › Reisebuch und wähle die Reise.', 'Wähle eine fertige Zusammenstellung oder stelle selbst zusammen, was ins Buch soll. Eigene Auswahlen kannst du mit Namen speichern.', 'Lies das Buch, drucke es oder tippe auf „PDF erzeugen“.'],
        ['Open Functions › Travel book and choose the trip.', 'Choose a ready-made selection or put together yourself what should go into the book. You can save your own selections with a name.', 'Read the book, print it or tap “Create PDF”.']),
      liste(['Reisetagebuch: Bilder und die Texte aus dem Tagesabschluss.', 'Vollständiges Logbuch: jeder Schritt der Reise, jeder Eintrag mit Datum, Uhrzeit, Position und Herkunft, dazu Motorlaufzeiten, Wetter und Störungen.',
        'Nur Zahlen der Reise und Tagesabschlüsse ohne Bilder gibt es auch.', 'Karten (Übersichtskarte und Karte je Tag) werden als Bild bei der Reise gespeichert und sehen später auch ohne Internet gleich aus.'],
        ['Travel diary: pictures and the texts from the end-of-day closing.', 'Complete logbook: every step of the trip, every entry with date, time, position and origin, plus engine running times, weather and faults.',
          'There are also “Trip figures only” and “End-of-day closings without pictures”.', 'Maps (overview map and map per day) are saved as a picture with the trip and later look the same even without internet.']),
      hinweis('Kosten stehen nur im Buch, wenn du es willst. Fotos stehen nur im Buch, wenn sie auf diesem Gerät liegen; im PDF sind sie verkleinert.',
        'Costs are only in the book if you want them. Photos are only in the book if they are on this device; in the PDF they are reduced in size.')
    ] },

    { id: 'geraete', titel: { de: 'Ich nutze mehrere Geräte: Konto, Abgleich, Schlüsselwort', en: 'I use several devices: account, sync, keyword' }, bloecke: [
      p('Mit einem Konto hast du deine Daten auf allen deinen Geräten. Das Konto findest du unter Einstellungen › Deine Daten › Konto.', 'With an account you have your data on all your devices. You find the account under Settings › Your data › Account.'),
      bild('geraete-konto', 'Das Konto mit dem Abgleich.', 'The account with the sync.'),
      schritte(['Melde dich auf dem ersten Gerät an. Gibt es noch kein Konto, entsteht beim ersten Mal eines, mit einer Testwoche.', 'Melde dich auf dem zweiten Gerät mit demselben Konto an.',
        'Tippe auf dem neuen Gerät einmal auf „Jetzt abgleichen“. Das holt deine Daten.'],
        ['Sign in on the first device. If there is no account yet, one is created the first time, with a trial week.', 'Sign in on the second device with the same account.',
          'On the new device tap “Sync now” once. This fetches your data.']),
      liste(['In der Testwoche und mit den Stufen Mittel und Voll gleicht MobiMory von allein ab, solange die App offen ist: kurz nach einer Änderung, sonst fragt sie jede Minute nach Neuem.',
        'Mit Basic gleichst du nur von Hand ab. Ohne Netz arbeitest du wie bisher.', 'Läuft die Aufzeichnung auf zwei Geräten, werden Weg und Kilometer zusammengeführt statt überschrieben.'],
        ['In the trial week and with the Medium and Full levels MobiMory syncs by itself while the app is open: shortly after a change, otherwise it asks every minute for news.',
          'With Basic you only sync by hand. Without network you work as before.', 'If recording runs on two devices, path and kilometres are merged instead of overwritten.']),
      kopf('Das Schlüsselwort', 'The keyword'),
      p('Alles Private geht nur verschlüsselt zum Dienst, und der Dienst kann es nicht lesen: Notizen, Telefonnummern, E-Mail- und Postadressen, Nummern der Nachweise, Namen im Reisecheck, Scans und die GPS-Spur. Den Schlüssel dafür bildet dein Schlüsselwort. Du gibst es einmal je Gerät ein, es bleibt auf dem Gerät gespeichert. Auf dem zweiten Gerät brauchst du dasselbe Wort.',
        'Everything private goes to the service only encrypted, and the service cannot read it: notes, phone numbers, email and postal addresses, proof numbers, names in the trip check, scans and the GPS track. Your keyword forms the key for this. You enter it once per device, it stays saved on the device. On the second device you need the same word.'),
      hinweis('Vergisst du das Schlüsselwort und hast kein Gerät mehr mit gespeichertem Wort, sind diese Angaben nicht mehr zu öffnen. Schreib es dir auf.',
        'If you forget the keyword and no longer have a device with the word saved, this information can no longer be opened. Write it down.'),
      kopf('Sicherung', 'Backup'),
      p('Unter Einstellungen › Deine Daten › Sicherung erstellst du eine Sicherung deiner Daten, zum Beispiel als Datei. Mach das regelmäßig; MobiMory erinnert dich daran. Eine Sicherung beim Dienst wird mit deinem Schlüsselwort verschlüsselt.',
        'Under Settings › Your data › Backup you create a backup of your data, for example as a file. Do this regularly; MobiMory reminds you. A backup at the service is encrypted with your keyword.')
    ] },

    { id: 'verleih', titel: { de: 'Ich verleihe oder gebe ein Fahrzeug ab', en: 'I lend or hand over a vehicle' }, bloecke: [
      kopf('Verleihen (Funktionen › Verleih)', 'Lending (Functions › Lending)'),
      bild('verleih-seite', 'Der Verleih (er braucht ein Konto).', 'Lending (it needs an account).'),
      liste(['Du gibst ein Fahrzeug für eine andere Person frei: nur zum Lesen, für höchstens 12 Monate. Die Person bekommt einen Code, meldet sich mit ihrer E-Mail-Adresse an und trägt den Code ein.',
        'Sie sieht das Fahrzeug, die Fristen und Zähler, die Dokumente und das letzte Prüfergebnis. Kosten, Notizen, Nachweise, Aktivitäten und Ereignisse sieht sie nicht.',
        'Leihst du ein Fahrzeug, machst du die Reise wie jede andere, mit Logbuch und Reisebuch. Endet die Leihe, bleibt alles lesbar, du kannst aber nichts Neues anlegen.',
        'Mit den Kontrollpapieren (Funktionen › Kontrollpapiere) erzeugst du einen Kontroll-Code. Wer ihn hat, kann Papiere und das Prüfergebnis ohne Konto lesen, zum Beispiel bei einer Kontrolle.'],
        ['You share a vehicle with another person: read-only, for at most 12 months. The person gets a code, signs in with their email address and enters the code.',
          'They see the vehicle, the deadlines and counters, the documents and the last check result. They do not see costs, notes, proofs, activities and events.',
          'If you borrow a vehicle, you make the trip like any other, with logbook and travel book. When the loan ends, everything stays readable, but you cannot add anything new.',
          'With the control papers (Functions › Control papers) you create a control code. Whoever has it can read papers and the check result without an account, for example at a control.']),
      kopf('Abgeben (Funktionen › Fahrzeug abgeben)', 'Handing over (Functions › Hand over vehicle)'),
      schritte(['Wähle das Fahrzeug und den Grund: verkauft, verschenkt oder verschrottet, mit Datum.', 'Das Fahrzeug verschwindet aus den Auswahllisten, bleibt bei dir aber lesbar, unter „Abgegebene Fahrzeuge“. Du kannst es jederzeit wieder aktiv setzen.',
        'Für den neuen Besitzer erzeugst du die Übergabedatei und, wenn du willst, ein PDF der Technik-Akte.'],
        ['Choose the vehicle and the reason: sold, given away or scrapped, with date.', 'The vehicle disappears from the selection lists but stays readable for you, under “Handed-over vehicles”. You can reactivate it at any time.',
          'For the new owner you create the handover file and, if you want, a PDF of the technical file.']),
      hinweis('Die Übergabedatei enthält die technische Geschichte (Komponenten, Zähler, Fristen, Störungen, Dokumente). Aktivitäten, Logbuch, Kosten, Reisekasse und Personen gehören nicht dazu.',
        'The handover file contains the technical history (components, counters, deadlines, faults, documents). Activities, logbook, costs, travel cash and people are not part of it.')
    ] }
  ];

  function sprache(s) { return UI[s] ? s : STANDARD_SPRACHE; }
  function ui(s) { return UI[sprache(s)]; }
  function inhaltsliste(s) {
    s = sprache(s);
    return KAPITEL.map(function (k, i) { return { id: k.id, nr: i + 1, titel: k.titel[s] }; });
  }
  /* Ein Kapitel in einer Sprache: { id, nr, titel, bloecke: [{ typ, text | punkte, bild?: id }], vorher, naechstes } oder null. */
  function kapitel(id, s) {
    s = sprache(s);
    var i = -1; KAPITEL.forEach(function (k, n) { if (k.id === id) i = n; });
    if (i < 0) return null;
    var k = KAPITEL[i];
    return { id: k.id, nr: i + 1, titel: k.titel[s],
      bloecke: k.bloecke.map(function (b) {
        var o = { typ: b.typ };
        if (b.typ === 'schritte' || b.typ === 'liste') o.punkte = b[s]; else o.text = b[s];
        if (b.typ === 'bild') o.bild = b.id;
        return o;
      }),
      vorher: i > 0 ? { id: KAPITEL[i - 1].id, titel: KAPITEL[i - 1].titel[s] } : null,
      naechstes: i < KAPITEL.length - 1 ? { id: KAPITEL[i + 1].id, titel: KAPITEL[i + 1].titel[s] } : null };
  }

  function dateiName(s, version) { return ui(s).dateiName + String(version || '').replace(/[^0-9A-Za-z.]+/g, '_') + '.pdf'; }

  /*
   * Das PDF des ganzen Handbuchs (MM.Pdf, ohne Netz). bilder: { <bildId>: Uint8Array mit JPEG } (fehlt eines, steht ein Hinweis).
   * ctx: { version, datum }. Gibt { bytes, name, bilder, ohneBild } zurück.
   */
  function pdf(s, bilder, ctx) {
    s = sprache(s); bilder = bilder || {}; ctx = ctx || {};
    var u = UI[s], eingefuegt = 0, ohne = 0;
    var d = MM.Pdf.neu({ fuss: u.fuss + (ctx.version ? ' · ' + ctx.version : ''), titel: 'MobiMory ' + u.titel, datum: ctx.datum });
    d.titelseite({ kopf: 'MobiMory', titel: u.titel, untertitel: u.untertitel, zeilen: ctx.version ? [[u.stand.replace(/ $/, ''), ctx.version]] : [], fuss: MM.Texte ? MM.Texte.COPYRIGHT : '' });
    d.titel(u.titel, u.untertitel);
    d.absatz(u.einleitung, { grau: true });
    d.abschnitt(u.inhalt);
    inhaltsliste(s).forEach(function (k) { d.absatz(k.nr + '. ' + k.titel); });
    KAPITEL.forEach(function (_, i) {
      var k = kapitel(KAPITEL[i].id, s);
      d.abschnitt(k.nr + '. ' + k.titel);
      k.bloecke.forEach(function (b) {
        if (b.typ === 'p') d.absatz(b.text);
        else if (b.typ === 'kopf') d.absatz(b.text, { fett: true, groesse: 11 });
        else if (b.typ === 'hinweis') d.absatz(b.text, { fett: true });
        else if (b.typ === 'liste') b.punkte.forEach(function (t) { d.absatz('• ' + t); });
        else if (b.typ === 'schritte') b.punkte.forEach(function (t, n) { d.absatz((n + 1) + '. ' + t); });
        else if (b.typ === 'bild') {
          var by = bilder[b.bild];
          if (by && d.bild(by, { maxH: 260, unterschrift: b.text })) eingefuegt++;
          else { ohne++; d.absatz(u.bildFehlt, { grau: true, groesse: 8 }); }
        }
      });
    });
    return { bytes: d.bytes(), name: dateiName(s, ctx.version), bilder: eingefuegt, ohneBild: ohne };
  }

  MM.Handbuch = { SPRACHEN: SPRACHEN, STANDARD_SPRACHE: STANDARD_SPRACHE, BILDER: BILDER, KAPITEL: KAPITEL, UI: UI, sprache: sprache, ui: ui, inhaltsliste: inhaltsliste, kapitel: kapitel, dateiName: dateiName, pdf: pdf };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
