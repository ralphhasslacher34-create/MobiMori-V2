/*
 * Ereignisse auf der Karte (seit 2.0.108): welche Ereignisarten erscheinen auf der Karte, und wie sehen sie aus.
 *
 * Regeln (von Ralph am 17.11.2026 festgelegt):
 *  - Alle Ereignisse mit Position können auf der Route markiert werden.
 *  - Die Auswahl hat zwei Stufen: eine generelle Vorauswahl des Nutzers und eine eigene Auswahl je Aktivität, die sie ergänzt oder
 *    verkleinert. Gibt es für die Aktivität keine eigene Auswahl, gilt die generelle.
 *  - Gespeichert wird, was der Nutzer ABGEWÄHLT hat („aus“). Neue Ereignisarten erscheinen so von selbst.
 *  - Seezeichen (nur Wasserfahrzeuge) gehören zur selben Auswahl.
 *  - Zum Start ist alles an, außer „Geschwindigkeit“: Diese Einträge kommen im Rhythmus und würden die Karte bei langen Reisen füllen.
 *
 * Hier steht nur die Beschreibung und die Rechnung, kein Speichern und kein Zeichnen.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var DOK_GENERELL = 'kartenwahl';
  function dokJeAktivitaet(aktivitaetId) { return 'kartenwahl-' + aktivitaetId; }
  var STANDARD_AUS = ['geschwindigkeit'];

  /* Der Schlüssel einer Ereignisart: Groß- und Kleinschreibung und Randleerzeichen sind egal. */
  function schluessel(artName) { return String(artName == null ? '' : artName).trim().toLowerCase(); }

  /* Bekannte Arten: Symbol (ein Zeichen) und Farbklasse (css/styles.css, .kv-art-…). Alles andere bekommt den Punkt. */
  var BEKANNT = [
    { schluessel: 'wetter', farbe: '#7a3db8', symbol: 'W', klasse: 'kv-wetterjetzt' },
    { schluessel: 'störung', farbe: '#c0262d', symbol: '!', klasse: 'kv-art-stoerung' },
    { schluessel: 'ein und aus', farbe: '#495057', symbol: 'M', klasse: 'kv-art-motor' },
    { schluessel: 'abfahrt', farbe: '#1f8a3b', symbol: 'A', klasse: 'kv-art-fahrt' },
    { schluessel: 'ankunft', farbe: '#1f8a3b', symbol: 'E', klasse: 'kv-art-fahrt' },
    { schluessel: 'ablegen', farbe: '#1f8a3b', symbol: 'A', klasse: 'kv-art-fahrt' },
    { schluessel: 'anlegen', farbe: '#1f8a3b', symbol: 'E', klasse: 'kv-art-fahrt' },
    { schluessel: 'skipperwechsel', farbe: '#0b7285', symbol: 'SW', klasse: 'kv-art-wechsel' },
    { schluessel: 'fahrerwechsel', farbe: '#0b7285', symbol: 'FW', klasse: 'kv-art-wechsel' },
    { schluessel: 'wechsel des verantwortlichen', farbe: '#0b7285', symbol: 'SW', klasse: 'kv-art-wechsel' },
    { schluessel: 'rudergängerwechsel', farbe: '#0b7285', symbol: 'RW', klasse: 'kv-art-wechsel' },
    { schluessel: 'kurswechsel', farbe: '#b8620b', symbol: 'KW', klasse: 'kv-art-kurs' },
    { schluessel: 'notiz', farbe: '#5f6b76', symbol: 'N', klasse: 'kv-art-notiz' },
    { schluessel: 'geschwindigkeit', farbe: '#5f6b76', symbol: 'G', klasse: 'kv-eintrag' }
  ];
  function bekannt(artName) {
    var s = schluessel(artName);
    for (var i = 0; i < BEKANNT.length; i++) if (BEKANNT[i].schluessel === s) return BEKANNT[i];
    return null;
  }
  /* { symbol, klasse, farbe } für eine Ereignisart (die Farbe für das Kartenbild). */
  function aussehen(artName) {
    var b = bekannt(artName);
    return b ? { symbol: b.symbol, klasse: b.klasse, farbe: b.farbe } : { symbol: '•', klasse: 'kv-art-sonst', farbe: '#5f6b76' };
  }

  /* Name der Kartenart eines Wechsels (seit 2.0.115): art 'wechsel' = Skipperwechsel (Wasser) bzw. Fahrerwechsel (Land), art 'ruder' = Rudergängerwechsel. */
  function wechselName(art, welt) {
    if (art === 'ruder') return 'Rudergängerwechsel';
    return welt === 'wasser' ? 'Skipperwechsel' : (welt === 'land' ? 'Fahrerwechsel' : 'Wechsel des Verantwortlichen');
  }

  /* Aus einem gespeicherten Dokument (oder nichts) eine Wahl machen: { aus: [Schlüssel], seezeichen: true | false | null }. null = nicht festgelegt. */
  function lesen(dok) {
    if (!dok || typeof dok !== 'object') return null;
    var aus = [];
    (Array.isArray(dok.aus) ? dok.aus : []).forEach(function (a) { var s = schluessel(a); if (s && aus.indexOf(s) < 0) aus.push(s); });
    return { aus: aus, seezeichen: dok.seezeichen === true ? true : (dok.seezeichen === false ? false : null) };
  }
  /* Die Wahl, die zum Start gilt. */
  function standard() { return { aus: STANDARD_AUS.slice(), seezeichen: true }; }

  /* Die wirksame Wahl: die der Aktivität, sonst die generelle, sonst der Standard. Fehlt bei der Aktivität die Angabe zu den Seezeichen, gilt die generelle. */
  function wirksam(generell, jeAktivitaet) {
    var g = generell ? { aus: generell.aus.slice(), seezeichen: generell.seezeichen === null ? true : generell.seezeichen } : standard();
    if (!jeAktivitaet) return g;
    return { aus: jeAktivitaet.aus.slice(), seezeichen: jeAktivitaet.seezeichen === null ? g.seezeichen : jeAktivitaet.seezeichen };
  }

  function sichtbar(artName, wahl) { return !wahl || wahl.aus.indexOf(schluessel(artName)) < 0; }

  /* Die Ereignisse, die auf der Karte erscheinen sollen (die Reihenfolge bleibt). */
  function filtern(ereignisse, wahl) {
    return (ereignisse || []).filter(function (e) { return sichtbar(e.artName, wahl); });
  }

  /* Die Arten, die zur Auswahl stehen: alle, die in dieser Aktivität mit Position vorkommen, dazu die abgewählten (damit man sie wieder anschalten kann).
   * Ergebnis: [{ schluessel, name, anzahl, an }], sortiert nach Name. */
  function artenListe(ereignisse, wahl) {
    var karte = {}, liste = [];
    (ereignisse || []).forEach(function (e) {
      var s = schluessel(e.artName);
      if (!s) return;
      if (!karte[s]) { karte[s] = { schluessel: s, name: e.artName, anzahl: 0, an: true }; liste.push(karte[s]); }
      karte[s].anzahl++;
    });
    ((wahl && wahl.aus) || []).forEach(function (s) {
      if (!karte[s]) {
        var b = bekannt(s);
        karte[s] = { schluessel: s, name: b ? s.charAt(0).toUpperCase() + s.slice(1) : s, anzahl: 0, an: false };
        liste.push(karte[s]);
      }
    });
    liste.forEach(function (x) { x.an = !wahl || wahl.aus.indexOf(x.schluessel) < 0; });
    return liste.sort(function (a, b) { return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : (a.name.toLowerCase() > b.name.toLowerCase() ? 1 : 0); });
  }

  /* Eine Art an- oder abschalten. Ergebnis: eine neue Wahl. */
  function umschalten(wahl, artName, an) {
    var s = schluessel(artName), aus = wahl.aus.filter(function (x) { return x !== s; });
    if (!an) aus.push(s);
    return { aus: aus, seezeichen: wahl.seezeichen };
  }

  /* Was gespeichert wird. */
  function dokument(id, wahl, aktivitaetId, jetzt) {
    var d = { id: id, aus: wahl.aus.slice(), seezeichen: wahl.seezeichen === null ? null : !!wahl.seezeichen, geaendertAm: jetzt };
    if (aktivitaetId) d.aktivitaetId = aktivitaetId;
    return d;
  }

  MM.KartenEreignisse = {
    wechselName: wechselName, DOK_GENERELL: DOK_GENERELL, dokJeAktivitaet: dokJeAktivitaet, STANDARD_AUS: STANDARD_AUS, BEKANNT: BEKANNT,
    schluessel: schluessel, aussehen: aussehen, lesen: lesen, standard: standard, wirksam: wirksam, sichtbar: sichtbar, filtern: filtern,
    artenListe: artenListe, umschalten: umschalten, dokument: dokument
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
