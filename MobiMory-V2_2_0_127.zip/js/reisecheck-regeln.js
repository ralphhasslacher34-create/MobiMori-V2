/*
 * Reisecheck und Regeln (seit 2.0.101): Die Ergebnisse eines Reisechecks werden als Regeln in den betroffenen Orten und Gebieten gespeichert,
 * jeweils mit dem Datum des Reisechecks. Bei einer erneuten Reise in dasselbe Gebiet zeigt die App zuerst einen Überblick aus diesen Regeln,
 * mit dem Hinweis „Stand: Datum, die Daten können veraltet sein“. Ein neuer Online-Check ist dann nicht zwingend nötig.
 *
 * Festlegungen:
 *  - Gespeichert wird, was gilt (die Anforderung, ihr Bereich, die Kategorie, die Erklärung, Quellen), nie, wie es bei dieser Besatzung steht.
 *    Status („Erfüllt“, „Fehlt“), Beleg, Namen und Nummern der Reise bleiben im Check selbst.
 *  - Eine Anforderung kommt in den Ort oder das Gebiet, dessen Name zum „Bereich“ der Anforderung passt (der genaueste Treffer je Kette).
 *    Passt keiner, gilt sie für die Reise insgesamt und kommt in die Länder der Reise.
 *  - Dieselbe Anforderung wird in einem Gebiet nur einmal geführt. Ein neuer Check schreibt sie mit dem neuen Datum fort,
 *    Regeln aus früheren Checks, die der neue Check nicht mehr nennt, bleiben mit ihrem alten Datum stehen.
 *  - Die Regeln liegen in der Tabelle „regeln“ mit art = 'reisecheck'. Die Prüfung der Befähigung und der Pflichtausrüstung nimmt sie nicht mit.
 *
 * Hier steht nur Rechnung und Beschreibung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var ART = 'reisecheck';
  var MAX_QUELLEN = 3;
  var MAX_BEZEICHNUNG = 120;
  var EBENEN_TIEFE = { land: 1, region: 2, revier: 2, kreis: 3, ort: 4 };
  var STAND_HINWEIS = 'die Daten können veraltet sein';

  function text(x) { return x === null || x === undefined ? '' : String(x).trim(); }
  function normal(s) { return text(s).replace(/\s+/g, ' ').toLowerCase(); }
  function kurz(s, n) { s = text(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; }

  function ist(werte) { return !!werte && werte.art === ART; } /* dieselbe Rechnung wie MM.Orte.istReisecheckRegel */

  /* Datum des Checks als JJJJ-MM-TT (aus der Zeit, zu der der Check gesendet wurde). */
  function datumVon(zeit) { var m = /^(\d{4}-\d{2}-\d{2})/.exec(text(zeit)); return m ? m[1] : null; }

  /* Woran dieselbe Anforderung wiedererkannt wird: der Text, wer betroffen ist und die Verkehrsart. */
  function schluessel(w) { return normal(w.anforderung).slice(0, 240) + '|' + normal(w.subjektArt) + '|' + normal(w.verkehr); }

  /* Die Werte einer Regel aus einer Anforderung des Checks. a = Anforderung im eigenen Format (MM.Reisecheck.antwortPruefen). */
  function regelWerte(a, datum, checkId) {
    var quellen = (a.quellen || []).slice(0, MAX_QUELLEN).map(function (q) { return { titel: q.titel, url: q.url, herausgeber: q.herausgeber || '', amtlich: !!q.amtlich }; });
    return {
      bezeichnung: kurz(a.anforderung, MAX_BEZEICHNUNG), art: ART,
      pflichtAusruestung: null, menge: null, bezug: null, eignung: null, fahrzeugArten: [], ausruestung: null, artIds: [], gilt: 'ja', herkunft: 'reisecheck',
      anforderung: text(a.anforderung), bereich: text(a.bereich), kategorie: text(a.kategorie) || 'Hinweis', subjektArt: text(a.subjektArt) || 'Reise',
      verkehr: text(a.verkehr), erklaerung: text(a.erklaerung), quellen: quellen, pruefDatum: datum, checkId: checkId || null
    };
  }

  /* Passt der Bereich der Anforderung zum Namen eines Ortes oder Gebiets? Der Name muss im Bereich vorkommen (oder umgekehrt, ab 4 Zeichen). */
  function passt(bereich, name) {
    var b = normal(bereich), n = normal(name);
    if (b.length < 3 || n.length < 3) return false;
    return b.indexOf(n) >= 0 || (b.length >= 4 && n.indexOf(b) >= 0);
  }

  /*
   * Wohin gehört welche Anforderung?
   *  p.anforderungen  die Anforderungen des Checks
   *  p.ketten         [[{ id, name, ebene }]] die Gebiete der Reise von oben nach unten (MM.Gebiete.kettenAusOrten)
   *  p.orte           [{ id, name }] die Orte der Reise
   * Ergebnis: { ziele: [{ typ: 'gebiet'|'ort', id, name, anforderungen: [Anforderung] }], ohneZiel: n, grund }
   *  grund 'kein-gebiet': Weder ein Gebiet noch ein Ort mit Gebiet ist da, es kann nichts gespeichert werden.
   */
  function zuordnen(p) {
    var ketten = (p.ketten || []).filter(function (k) { return k && k.length; });
    var orte = p.orte || [];
    var ziele = [], index = {};
    function ziel(typ, id, name) {
      var k = typ + ':' + id;
      if (!index[k]) { index[k] = { typ: typ, id: id, name: name, anforderungen: [] }; ziele.push(index[k]); }
      return index[k];
    }
    /* Die Länder der Reise (oberstes Glied jeder Kette; ein eigenes Gebiet ohne Ebene steht für sich). */
    var laender = [];
    ketten.forEach(function (k) { var o = k[0]; if (o && !laender.some(function (l) { return l.id === o.id; })) laender.push(o); });
    var gebieteAlle = [];
    ketten.forEach(function (k) { k.forEach(function (g) { if (g.ebene !== 'ort' && !gebieteAlle.some(function (x) { return x.id === g.id; })) gebieteAlle.push(g); }); });
    if (!laender.length && !orte.length) return { ziele: [], ohneZiel: (p.anforderungen || []).length, grund: 'kein-gebiet' };

    var ohneZiel = 0;
    (p.anforderungen || []).forEach(function (a) {
      var treffer = null;
      /* 1. Ein Ort der Reise, dessen Name zum Bereich passt */
      orte.some(function (o) { if (passt(a.bereich, o.name)) { treffer = { typ: 'ort', id: o.id, name: o.name }; return true; } return false; });
      /* 2. Das genaueste Gebiet der Reise, dessen Name zum Bereich passt */
      if (!treffer) {
        var beste = null;
        gebieteAlle.forEach(function (g) {
          if (!passt(a.bereich, g.name)) return;
          if (!beste || (EBENEN_TIEFE[g.ebene] || 0) > (EBENEN_TIEFE[beste.ebene] || 0)) beste = g;
        });
        if (beste) treffer = { typ: 'gebiet', id: beste.id, name: beste.name };
      }
      if (treffer) { ziel(treffer.typ, treffer.id, treffer.name).anforderungen.push(a); return; }
      /* 3. Sonst gilt sie für die Reise insgesamt: in die Länder der Reise */
      if (!laender.length) { ohneZiel++; return; }
      laender.forEach(function (l) { ziel('gebiet', l.id, l.name).anforderungen.push(a); });
    });
    return { ziele: ziele, ohneZiel: ohneZiel, grund: ziele.length || !ohneZiel ? null : 'kein-gebiet' };
  }

  /*
   * Fortschreiben: Was kommt neu dazu, was wird mit neuem Datum aktualisiert?
   *  p.vorhanden  [{ id, nr, werte }] die Regeln mit art 'reisecheck', die dieses Gebiet schon hat
   *  p.neu        [Werte] die Regeln aus dem neuen Check (regelWerte)
   * Ergebnis: { anlegen: [Werte], aendern: [{ id, werte }], gleich: n }
   * Eine Regel mit demselben Schlüssel wird nur geändert, wenn der neue Check später ist als der gespeicherte Stand.
   */
  function fortschreiben(p) {
    var nachKey = {};
    (p.vorhanden || []).forEach(function (v) { if (ist(v.werte)) nachKey[schluessel(v.werte)] = v; });
    var res = { anlegen: [], aendern: [], gleich: 0 }, gesehen = {};
    (p.neu || []).forEach(function (w) {
      var k = schluessel(w);
      if (gesehen[k]) return; gesehen[k] = true;
      var da = nachKey[k];
      if (!da) { res.anlegen.push(w); return; }
      if ((da.werte.pruefDatum || '') > (w.pruefDatum || '')) { res.gleich++; return; }
      /* Der Nutzer kann eine Regel abgeschaltet haben („gilt“ = nein): Das bleibt so. */
      var aktualisiert = Object.assign({}, w, { gilt: da.werte.gilt === 'nein' ? 'nein' : 'ja' });
      /* Derselbe Stand von demselben Tag: nichts zu tun, auch wenn der Check selbst ein anderer ist (anderer Verweis). */
      if (JSON.stringify(Object.assign({}, aktualisiert, { checkId: null })) === JSON.stringify(Object.assign({}, da.werte, { checkId: null }))) { res.gleich++; return; }
      res.aendern.push({ id: da.id, werte: aktualisiert });
    });
    return res;
  }

  function rangKategorie(k) { var i = MM.Reisecheck ? MM.Reisecheck.KATEGORIEN.indexOf(k) : -1; return i < 0 ? 99 : i; }

  /*
   * Der Überblick aus den gespeicherten Regeln für eine Reise.
   *  p.gruppen  [{ name, ebene, regeln: [Werte] }] die Orte und Gebiete der Reise mit ihren Reisecheck-Regeln
   * Ergebnis: { gruppen: [{ name, ebene, stand, standText, eintraege: [Werte] }], anzahl, stand, standText }
   * Leere Gruppen fallen weg. „stand“ ist das jüngste Datum, „standText“ der Satz dazu (Datum formatiert über p.datumText).
   */
  function ueberblick(p) {
    var fmt = typeof p.datumText === 'function' ? p.datumText : function (d) { return d; };
    function satz(d) { return 'Stand: ' + fmt(d) + ', ' + STAND_HINWEIS + '.'; }
    var gruppen = [], anzahl = 0, gesamt = null;
    (p.gruppen || []).forEach(function (g) {
      var e = (g.regeln || []).filter(function (w) { return ist(w) && w.gilt !== 'nein'; }).slice().sort(function (a, b) {
        return rangKategorie(a.kategorie) - rangKategorie(b.kategorie) || normal(a.anforderung).localeCompare(normal(b.anforderung), 'de');
      });
      if (!e.length) return;
      var stand = e.reduce(function (m, w) { return w.pruefDatum && (!m || w.pruefDatum > m) ? w.pruefDatum : m; }, null);
      gruppen.push({ name: g.name, ebene: g.ebene || null, stand: stand, standText: stand ? satz(stand) : 'Stand unbekannt, ' + STAND_HINWEIS + '.', eintraege: e });
      anzahl += e.length;
      if (stand && (!gesamt || stand > gesamt)) gesamt = stand;
    });
    return { gruppen: gruppen, anzahl: anzahl, stand: gesamt, standText: gesamt ? satz(gesamt) : null };
  }

  MM.ReisecheckRegeln = {
    ART: ART, STAND_HINWEIS: STAND_HINWEIS, ist: ist, datumVon: datumVon, schluessel: schluessel, regelWerte: regelWerte, passt: passt,
    zuordnen: zuordnen, fortschreiben: fortschreiben, ueberblick: ueberblick
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
