/*
 * Schlüsselwort für private Angaben beim Abgleich (seit 2.0.119): reine Rechnung auf Texten, kein Netz, kein Speicher.
 *
 * Alles Empfindliche (Notizen, Telefon, E-Mail, Adressen, Nachweis-Nummern, Namen im Reisecheck) geht zum Dienst nur als Block, den der Dienst nicht lesen kann.
 * Aus Schlüsselwort und Kennung des Datenraums entsteht auf jedem Gerät derselbe Schlüssel (PBKDF2, 200.000 Runden). Er steckt nur im Arbeitsspeicher.
 *
 * Der Block ist deterministisch: Derselbe Inhalt ergibt auf jedem Gerät denselben Text. Der Startwert (12 Byte) wird aus Inhalt und Kennung des Datensatzes
 * berechnet (HMAC-SHA256), die Verschlüsselung ist AES-GCM mit der Kennung als zusätzlich geprüfte Angabe. Dadurch erkennt der Abgleich Änderungen am
 * Abdruck des Textes, ohne die Daten zu öffnen, und ein Block lässt sich nicht in einen anderen Datensatz kopieren.
 * Preis: Wer den Dienst liest, sieht, ob zwei Blöcke gleich sind, nie was drin steht.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var RUNDEN = 200000;
  var PRAEFIX = 'v1.';
  var MAX_MERKER = 50000;
  var cache = { schluessel: null, wert: null };

  function fehler(code, text) { var e = new Error(text); e.code = code; return e; }
  function bytes(t) { return new TextEncoder().encode(t); }
  function zusammen(teile) {
    var n = 0; teile.forEach(function (t) { n += t.length; });
    var r = new Uint8Array(n), p = 0;
    teile.forEach(function (t) { r.set(t, p); p += t.length; });
    return r;
  }
  function zuBase64(u8) {
    var s = '';
    for (var i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192));
    return global.btoa(s);
  }
  function ausBase64(t) {
    var b = global.atob(t), r = new Uint8Array(b.length);
    for (var i = 0; i < b.length; i++) r[i] = b.charCodeAt(i);
    return r;
  }

  /* Der Schlüssel zu Wort und Datenraum (nur im Arbeitsspeicher, höchstens einer). Ergebnis: { aes, hmac, merker } */
  function schluessel(wort, datenraum) {
    var k = String(datenraum) + '|' + String(wort);
    if (cache.schluessel === k && cache.wert) return cache.wert;
    var s = global.crypto.subtle;
    var p = s.importKey('raw', bytes(wort), 'PBKDF2', false, ['deriveBits']).then(function (basis) {
      return s.deriveBits({ name: 'PBKDF2', salt: bytes('mobimory-geheim-v1|' + datenraum), iterations: RUNDEN, hash: 'SHA-256' }, basis, 512);
    }).then(function (bits) {
      var u = new Uint8Array(bits);
      return Promise.all([s.importKey('raw', u.slice(0, 32), 'AES-GCM', false, ['encrypt', 'decrypt']), s.importKey('raw', u.slice(32), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])]);
    }).then(function (r) { return { aes: r[0], hmac: r[1], merker: {}, zahl: 0 }; });
    cache.schluessel = k; cache.wert = p;
    p.catch(function () { if (cache.wert === p) { cache.schluessel = null; cache.wert = null; } });
    return p;
  }

  function vergessen() { cache.schluessel = null; cache.wert = null; }

  /* Text -> Block. aad: Kennung des Datensatzes (Tabelle/Id). Gleiche Eingabe ergibt denselben Block. */
  function verschluesseln(key, aad, text) {
    var m = aad + '\u0000' + text;
    if (key.merker[m]) return Promise.resolve(key.merker[m]);
    var s = global.crypto.subtle, a = bytes(aad), klar = bytes(text);
    return s.sign('HMAC', key.hmac, zusammen([a, new Uint8Array([0]), klar])).then(function (mac) {
      var iv = new Uint8Array(mac).slice(0, 12);
      return s.encrypt({ name: 'AES-GCM', iv: iv, additionalData: a }, key.aes, klar).then(function (c) {
        var block = PRAEFIX + zuBase64(zusammen([iv, new Uint8Array(c)]));
        if (key.zahl >= MAX_MERKER) { key.merker = {}; key.zahl = 0; }
        key.merker[m] = block; key.zahl++;
        return block;
      });
    });
  }

  /* Block -> Text. Falsches Wort oder veränderter Block: Fehler mit code „schluessel“. */
  function oeffnen(key, aad, block) {
    var s = global.crypto.subtle;
    if (typeof block !== 'string' || block.indexOf(PRAEFIX) !== 0) return Promise.reject(fehler('format', 'Das ist kein gültiger Block.'));
    var u;
    try { u = ausBase64(block.slice(PRAEFIX.length)); } catch (e) { return Promise.reject(fehler('format', 'Das ist kein gültiger Block.')); }
    if (u.length < 12 + 16) return Promise.reject(fehler('format', 'Das ist kein gültiger Block.'));
    return s.decrypt({ name: 'AES-GCM', iv: u.slice(0, 12), additionalData: bytes(aad) }, key.aes, u.slice(12)).then(function (klar) {
      return new TextDecoder().decode(new Uint8Array(klar));
    }, function () { throw fehler('schluessel', 'Das Schlüsselwort passt nicht.'); });
  }

  MM.Geheim = { RUNDEN: RUNDEN, PRAEFIX: PRAEFIX, MIN_LAENGE: 8, schluessel: schluessel, vergessen: vergessen, verschluesseln: verschluesseln, oeffnen: oeffnen };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
