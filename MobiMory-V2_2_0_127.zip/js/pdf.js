/*
 * PDF schreiben (seit 2.0.37): nur Rechnung auf Texten und Bytes, kein Fremdprogramm.
 *
 * Gebraucht für die Technik-Akte beim Abgeben eines Fahrzeugs. Das PDF hat nur Text und Linien,
 * Seitenformat A4, die eingebauten Schriften Helvetica und Helvetica-Bold (kein Einbetten nötig,
 * jeder PDF-Betrachter kennt sie). Umlaute und das Euro-Zeichen stehen in der Windows-Zeichentabelle (WinAnsi).
 *
 * Benutzung:
 *   var d = MM.Pdf.neu({ fuss: 'MobiMory 2.0.37' });
 *   d.titel('Technik-Akte'); d.abschnitt('Fahrzeug'); d.zeile('Bezeichnung', 'Fahrzeug A');
 *   d.tabelle([{ titel: 'Datum', breite: 70 }, { titel: 'Was', breite: 0 }], [['01.02.2026', 'HU bestanden']]);
 *   var bytes = d.bytes();   // Uint8Array
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var SEITE_B = 595, SEITE_H = 842;

  /* Zeichenbreiten der Standardschriften (Tausendstel der Schriftgröße) für die Zeichen 32 bis 126. */
  var BREITE_NORMAL = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278,
    556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
    1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
    667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
    333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556,
    556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584];
  var BREITE_FETT = [278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278,
    556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 333, 333, 584, 584, 584, 611,
    975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778,
    667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556,
    333, 556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611,
    611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500, 389, 280, 389, 584];

  /* Zeichen außerhalb von 32 bis 126, soweit die Windows-Zeichentabelle sie kennt: Unicode, Code in der Tabelle, Breite normal, Breite fett. */
  var SONDER = {
    '€': [0x80, 556, 556], '‚': [0x82, 222, 278], '„': [0x84, 333, 500], '…': [0x85, 1000, 1000], '‘': [0x91, 222, 278],
    '’': [0x92, 222, 278], '“': [0x93, 333, 500], '”': [0x94, 333, 500], '•': [0x95, 350, 350], '–': [0x96, 556, 556],
    '—': [0x97, 1000, 1000], '™': [0x99, 1000, 1000], '‹': [0x8B, 333, 333], '›': [0x9B, 333, 333],
    'ä': [0xE4, 556, 556], 'ö': [0xF6, 556, 611], 'ü': [0xFC, 556, 611], 'Ä': [0xC4, 667, 722], 'Ö': [0xD6, 778, 778],
    'Ü': [0xDC, 722, 722], 'ß': [0xDF, 611, 611], '°': [0xB0, 400, 400], '±': [0xB1, 584, 584], '²': [0xB2, 333, 333],
    '³': [0xB3, 333, 333], 'µ': [0xB5, 556, 611], '·': [0xB7, 278, 278], '§': [0xA7, 556, 556], '©': [0xA9, 737, 737],
    '«': [0xAB, 556, 556], '»': [0xBB, 556, 556], '\u00A0': [0xA0, 278, 278]
  };
  /* Buchstaben mit Akzent haben die Breite des Grundbuchstabens. */
  var GRUND = { 'àáâãåāă': 'a', 'èéêëēĕ': 'e', 'ìíîïī': 'i', 'òóôõøō': 'o', 'ùúûū': 'u', 'ç': 'c', 'ñ': 'n', 'ýÿ': 'y',
    'ÀÁÂÃÅ': 'A', 'ÈÉÊË': 'E', 'ÌÍÎÏ': 'I', 'ÒÓÔÕØ': 'O', 'ÙÚÛ': 'U', 'Ç': 'C', 'Ñ': 'N', 'Ý': 'Y' };
  var LATIN1 = {};
  Object.keys(GRUND).forEach(function (k) { k.split('').forEach(function (c) { LATIN1[c] = GRUND[k]; }); });

  /* Ein Zeichen: { code (Byte), b (Breite) }. Unbekanntes wird ein Fragezeichen. */
  function zeichen(c, fett) {
    if (c === '\u2192') c = '>'; /* Pfeil: die Schrift kennt ihn nicht (seit 2.0.85 als „>“ statt „?“) */
    var i = fett ? 2 : 1;
    var cp = c.charCodeAt(0);
    if (cp >= 32 && cp <= 126) return { code: cp, b: (fett ? BREITE_FETT : BREITE_NORMAL)[cp - 32] };
    if (SONDER[c]) return { code: SONDER[c][0], b: SONDER[c][i] };
    if (LATIN1[c]) { var g = LATIN1[c].charCodeAt(0); return { code: c.charCodeAt(0) <= 255 ? cp : 63, b: (fett ? BREITE_FETT : BREITE_NORMAL)[g - 32] }; }
    return { code: 63, b: (fett ? BREITE_FETT : BREITE_NORMAL)[63 - 32] };
  }

  /* Breite eines Textes in Punkt. */
  function breite(text, groesse, fett) {
    var s = 0, t = String(text == null ? '' : text);
    for (var i = 0; i < t.length; i++) { s += zeichen(t.charAt(i), fett).b; }
    return s * groesse / 1000;
  }

  /* Text für den Inhaltsstrom: Klammern und Schrägstrich geschützt, Zeichen als Bytes der Windows-Tabelle. */
  function kodiert(text) {
    var t = String(text == null ? '' : text).replace(/[\r\n\t]+/g, ' '), res = '';
    for (var i = 0; i < t.length; i++) {
      var z = zeichen(t.charAt(i), false).code;
      if (z === 40 || z === 41 || z === 92) res += '\\' + String.fromCharCode(z);
      else if (z < 32 || z > 126) res += '\\' + ('00' + z.toString(8)).slice(-3);
      else res += String.fromCharCode(z);
    }
    return res;
  }

  /* Text in Zeilen umbrechen. Zu lange Wörter werden zeichenweise getrennt. */
  function umbrechen(text, maxBreite, groesse, fett) {
    var absaetze = String(text == null ? '' : text).split(/\r?\n/), zeilen = [];
    absaetze.forEach(function (ab) {
      var woerter = ab.split(/\s+/).filter(function (w) { return w !== ''; });
      if (!woerter.length) { zeilen.push(''); return; }
      var akt = '';
      woerter.forEach(function (w) {
        var test = akt ? akt + ' ' + w : w;
        if (breite(test, groesse, fett) <= maxBreite) { akt = test; return; }
        if (akt) { zeilen.push(akt); akt = ''; }
        if (breite(w, groesse, fett) <= maxBreite) { akt = w; return; }
        var stueck = '';
        for (var i = 0; i < w.length; i++) {
          if (breite(stueck + w.charAt(i), groesse, fett) > maxBreite && stueck) { zeilen.push(stueck); stueck = ''; }
          stueck += w.charAt(i);
        }
        akt = stueck;
      });
      if (akt) zeilen.push(akt);
    });
    return zeilen;
  }

  function zahl(n) { return (Math.round(n * 100) / 100).toString(); }

  /* JPEG lesen (seit 2.0.81, für das Reisebuch): Breite, Höhe und Zahl der Farbanteile aus dem Kopf. null, wenn es kein lesbares JPEG ist.
     Eingebettet wird das JPEG unverändert (DCTDecode), mit Grau (1) oder Farbe (3); CMYK (4) und andere Formate nimmt das PDF nicht. */
  function jpegInfo(b) {
    if (!b || b.length < 12 || b[0] !== 0xFF || b[1] !== 0xD8) return null;
    var i = 2;
    while (i + 9 < b.length) {
      if (b[i] !== 0xFF) { i++; continue; }
      var m = b[i + 1];
      if (m === 0xFF) { i++; continue; }
      if (m === 0x01 || (m >= 0xD0 && m <= 0xD8)) { i += 2; continue; }
      if (m === 0xD9 || m === 0xDA) return null;
      if (m === 0xC0 || m === 0xC1 || m === 0xC2) {
        var info = { hoehe: b[i + 5] * 256 + b[i + 6], breite: b[i + 7] * 256 + b[i + 8], komponenten: b[i + 9] };
        return info.breite > 0 && info.hoehe > 0 && (info.komponenten === 1 || info.komponenten === 3) ? info : null;
      }
      i += 2 + b[i + 2] * 256 + b[i + 3];
    }
    return null;
  }

  /* Bytes als Zeichenkette mit einem Zeichen je Byte (so schreibt dieses Modul die Datei). */
  function binaer(b) {
    var s = '', n = 8192;
    for (var i = 0; i < b.length; i += n) s += String.fromCharCode.apply(null, b.subarray(i, i + n));
    return s;
  }

  function neu(opt) {
    opt = opt || {};
    var rand = { l: 50, r: 50, o: 56, u: 56 };
    var nutzB = SEITE_B - rand.l - rand.r;
    var seiten = [], strom = null, y = 0, bilder = [], seitenBilder = [];
    var fuss = opt.fuss || '';

    function neueSeite() { strom = []; seiten.push(strom); y = SEITE_H - rand.o; }
    neueSeite();

    function platz(h) { if (y - h < rand.u) neueSeite(); }

    function text(x, yy, t, groesse, fett, grau) {
      strom.push((grau ? '0.35 g ' : '0 g ') + 'BT /' + (fett ? 'F2' : 'F1') + ' ' + zahl(groesse) + ' Tf ' + zahl(x) + ' ' + zahl(yy) + ' Td (' + kodiert(t) + ') Tj ET');
    }
    function linie(x1, y1, x2, y2, grau) {
      strom.push((grau === undefined ? 0.6 : grau) + ' G 0.5 w ' + zahl(x1) + ' ' + zahl(y1) + ' m ' + zahl(x2) + ' ' + zahl(y2) + ' l S');
    }
    function flaeche(x, yy, w, h, grau) {
      strom.push(grau + ' g ' + zahl(x) + ' ' + zahl(yy) + ' ' + zahl(w) + ' ' + zahl(h) + ' re f');
    }

    var d = {
      /* Eine eigene Titelseite (seit 2.0.85). Muss als Erstes aufgerufen werden, danach beginnt eine neue Seite.
         o: { kopf (kleine Zeile oben), titel, untertitel, zeilen: [[Name, Wert]], fuss } */
      titelseite: function (o) {
        o = o || {};
        function mitte(t, g, fett, grau, yy) { text(rand.l + Math.max(0, (nutzB - breite(t, g, fett)) / 2), yy, t, g, fett, grau); }
        var yy = SEITE_H * 0.64;
        flaeche(rand.l, yy + 70, nutzB, 3, 0.25);
        if (o.kopf) { mitte(String(o.kopf).toUpperCase(), 11, true, true, yy + 40); }
        umbrechen(o.titel || '', nutzB, 30, true).forEach(function (z) { mitte(z, 30, true, false, yy); yy -= 38; });
        if (o.untertitel) { yy -= 4; mitte(o.untertitel, 13, false, true, yy); yy -= 24; }
        flaeche(rand.l, yy - 6, nutzB, 1, 0.6);
        yy -= 34;
        (o.zeilen || []).forEach(function (z) {
          umbrechen(String(z[0]) + ': ' + String(z[1]), nutzB, 11, false).forEach(function (t) { mitte(t, 11, false, false, yy); yy -= 16; });
        });
        if (o.fuss) mitte(o.fuss, 9, false, true, rand.u + 20);
        neueSeite();
        return d;
      },
      /* Große Überschrift der ersten Seite. */
      titel: function (t, untertitel) {
        platz(50);
        text(rand.l, y - 20, t, 20, true);
        y -= 28;
        if (untertitel) { text(rand.l, y - 10, untertitel, 10, false, true); y -= 16; }
        linie(rand.l, y - 4, SEITE_B - rand.r, y - 4, 0.3);
        y -= 16;
        return d;
      },
      abschnitt: function (t) {
        platz(40);
        y -= 10;
        text(rand.l, y - 11, t, 12, true);
        y -= 20;
        return d;
      },
      /* Absatz mit Umbruch. opt: { groesse, fett, grau } */
      absatz: function (t, o) {
        o = o || {};
        var g = o.groesse || 10, zh = g * 1.35;
        umbrechen(t, nutzB, g, !!o.fett).forEach(function (z) {
          platz(zh);
          if (z) text(rand.l, y - g, z, g, !!o.fett, !!o.grau);
          y -= zh;
        });
        y -= 3;
        return d;
      },
      /* Zeile „Name: Wert“ mit fester Spalte für den Namen. */
      zeile: function (name, wert) {
        var g = 10, zh = 13.5, nb = 130;
        var zeilen = umbrechen(wert === null || wert === undefined || wert === '' ? '–' : wert, nutzB - nb, g, false);
        /* Ein langer Name bricht um und läuft nicht in den Wert (seit 2.0.85). */
        var namen = umbrechen(String(name), nb - 8, g, true);
        var n = Math.max(zeilen.length, namen.length);
        for (var i = 0; i < n; i++) {
          platz(zh);
          if (namen[i]) text(rand.l, y - g, namen[i], g, true);
          if (zeilen[i]) text(rand.l + nb, y - g, zeilen[i], g, false);
          y -= zh;
        }
        return d;
      },
      abstand: function (pt) { y -= pt; if (y < rand.u) neueSeite(); return d; },
      /*
       * Tabelle. spalten: [{ titel, breite }], breite 0 = Rest. zeilen: Listen von Texten.
       * Die Kopfzeile wiederholt sich auf jeder Seite.
       */
      tabelle: function (spalten, zeilen) {
        var g = 9, zh = 11.5, pad = 3;
        var fest = 0, rest = 0;
        spalten.forEach(function (s) { if (s.breite) fest += s.breite; else rest++; });
        var restB = rest ? Math.max(40, (nutzB - fest) / rest) : 0;
        var bs = spalten.map(function (s) { return s.breite || restB; });
        var summe = 0; bs.forEach(function (b) { summe += b; });
        if (summe > nutzB) { var f = nutzB / summe; bs = bs.map(function (b) { return b * f; }); }

        function kopfzeile() {
          platz(zh + 2 * pad + 6);
          flaeche(rand.l, y - zh - 2 * pad + 1, nutzB, zh + 2 * pad - 1, 0.9);
          var x = rand.l;
          spalten.forEach(function (s, i) { text(x + pad, y - pad - g + 1, s.titel, g, true); x += bs[i]; });
          y -= zh + 2 * pad;
          linie(rand.l, y + 1, rand.l + nutzB, y + 1, 0.4);
        }
        kopfzeile();
        zeilen.forEach(function (z) {
          var zellen = spalten.map(function (s, i) { return umbrechen(z[i], bs[i] - 2 * pad, g, false); });
          var n = 1; zellen.forEach(function (c) { if (c.length > n) n = c.length; });
          var hoehe = n * zh + 2 * pad;
          if (y - hoehe < rand.u) { neueSeite(); kopfzeile(); }
          var x = rand.l;
          zellen.forEach(function (c, i) {
            c.forEach(function (t, k) { if (t) text(x + pad, y - pad - g + 1 - k * zh, t, g, false); });
            x += bs[i];
          });
          y -= hoehe;
          linie(rand.l, y + 1, rand.l + nutzB, y + 1, 0.8);
        });
        y -= 6;
        return d;
      },
      /* Ein JPEG-Bild einfügen (seit 2.0.81), verkleinert auf die Breite der Seite und höchstens opt.maxH Punkt hoch, mit Unterschrift.
         Gibt false zurück, wenn die Bytes kein lesbares JPEG sind (dann wird nichts eingefügt). */
      bild: function (bytes, o) {
        o = o || {};
        var info = jpegInfo(bytes);
        if (!info) return false;
        var maxH = o.maxH || 230, f = Math.min(nutzB / info.breite, maxH / info.hoehe, 1);
        var w = info.breite * f, hh = info.hoehe * f, un = o.unterschrift ? 14 : 0;
        platz(hh + 6 + un);
        bilder.push({ bytes: bytes, info: info });
        var nr = bilder.length, sx = seiten.length - 1;
        (seitenBilder[sx] = seitenBilder[sx] || []).push(nr);
        strom.push('q ' + zahl(w) + ' 0 0 ' + zahl(hh) + ' ' + zahl(rand.l) + ' ' + zahl(y - hh) + ' cm /Im' + nr + ' Do Q');
        y -= hh + 4;
        if (o.unterschrift) { text(rand.l, y - 8, o.unterschrift, 8, false, true); y -= 14; }
        y -= 2;
        return true;
      },
      bilderAnzahl: function () { return bilder.length; },
      seitenAnzahl: function () { return seiten.length; },
      /* Fertige PDF-Datei als Bytes. */
      bytes: function () {
        var n = seiten.length;
        /* Fußzeile mit Seitenzahl auf jede Seite */
        var ströme = seiten.map(function (s, i) {
          var teil = s.slice();
          var alt = strom; strom = teil;
          linie(rand.l, rand.u - 14, SEITE_B - rand.r, rand.u - 14, 0.7);
          text(rand.l, rand.u - 28, fuss, 8, false, true);
          var st = 'Seite ' + (i + 1) + ' von ' + n;
          text(SEITE_B - rand.r - breite(st, 8, false), rand.u - 28, st, 8, false, true);
          strom = alt;
          return teil.join('\n');
        });

        /* Objekte: 1 Katalog, 2 Seitenbaum, 3 Schrift normal, 4 Schrift fett, 5 Info, danach je Seite Seite + Inhalt */
        var objekte = [];
        function titelHex(t) {
          var h = 'FEFF';
          for (var i = 0; i < t.length; i++) { h += ('0000' + t.charCodeAt(i).toString(16)).slice(-4).toUpperCase(); }
          return '<' + h + '>';
        }
        var kids = [];
        for (var i = 0; i < n; i++) kids.push((6 + 2 * i) + ' 0 R');
        objekte[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        objekte[2] = '<< /Type /Pages /Kids [' + kids.join(' ') + '] /Count ' + n + ' >>';
        objekte[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        objekte[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        objekte[5] = '<< /Title ' + titelHex(opt.titel || 'Dokument') + ' /Producer ' + titelHex('MobiMory') + (opt.datum ? ' /CreationDate (D:' + String(opt.datum).replace(/[^0-9]/g, '').slice(0, 14) + ')' : '') + ' >>';
        for (var k = 0; k < n; k++) {
          var inhalt = ströme[k];
          var xo = (seitenBilder[k] || []).map(function (nr) { return '/Im' + nr + ' ' + (6 + 2 * n + nr - 1) + ' 0 R'; }).join(' ');
          objekte[6 + 2 * k] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + SEITE_B + ' ' + SEITE_H + '] /Resources << /Font << /F1 3 0 R /F2 4 0 R >>' + (xo ? ' /XObject << ' + xo + ' >>' : '') + ' >> /Contents ' + (7 + 2 * k) + ' 0 R >>';
          objekte[7 + 2 * k] = '<< /Length ' + inhalt.length + ' >>\nstream\n' + inhalt + '\nendstream';
        }
        bilder.forEach(function (bi, j) {
          objekte[6 + 2 * n + j] = '<< /Type /XObject /Subtype /Image /Width ' + bi.info.breite + ' /Height ' + bi.info.hoehe + ' /ColorSpace ' + (bi.info.komponenten === 1 ? '/DeviceGray' : '/DeviceRGB') +
            ' /BitsPerComponent 8 /Filter /DCTDecode /Length ' + bi.bytes.length + ' >>\nstream\n' + binaer(bi.bytes) + '\nendstream';
        });
        var out = '%PDF-1.4\n%\u00E2\u00E3\u00CF\u00D3\n';
        var pos = [];
        for (var o = 1; o < objekte.length; o++) {
          pos[o] = out.length;
          out += o + ' 0 obj\n' + objekte[o] + '\nendobj\n';
        }
        var xref = out.length;
        out += 'xref\n0 ' + objekte.length + '\n0000000000 65535 f \n';
        for (var p = 1; p < objekte.length; p++) { out += ('0000000000' + pos[p]).slice(-10) + ' 00000 n \n'; }
        out += 'trailer\n<< /Size ' + objekte.length + ' /Root 1 0 R /Info 5 0 R >>\nstartxref\n' + xref + '\n%%EOF\n';
        var bytes = new Uint8Array(out.length);
        for (var b = 0; b < out.length; b++) bytes[b] = out.charCodeAt(b) & 255;
        return bytes;
      }
    };
    return d;
  }

  MM.Pdf = { neu: neu, breite: breite, umbrechen: umbrechen, kodiert: kodiert, jpegInfo: jpegInfo };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
