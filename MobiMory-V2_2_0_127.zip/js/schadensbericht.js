/*
 * Schadensbericht (Bau C, seit 2.0.91): ein eigenes Formular am Fahrzeug, aus einer Störung (Werkstatt) oder von Hand.
 * Reine Rechnung und Texte, kein Netz, kein Speicher. Das Speichern steht in daten.js, die Seiten in ansicht.js.
 *
 * Festlegung (Nutzer, 15.11.2026):
 *  - MobiMory füllt vor, was es weiß: Fahrzeug, Kennzeichen, Versicherung und Versicherungsnummer (Fahrzeugangaben, seit 2.0.91),
 *    Ort und Zeit aus dem Logbuch (nur wenn die Störung dort entstand).
 *  - Der Nutzer ergänzt Hergang, Beteiligte, Zeugen und Fotos.
 *  - Ausgabe als Seite plus PDF zum Drucken oder Mailen (wie das Reisebuch).
 *  - Belege (Fotos, Kostenvoranschlag, Gutachten, Rechnungen) kommen aus der Dokumentenliste am Werkstatt-Vorgang, ohne Dopplung.
 *  - Der Europäische Unfallbericht wird nicht nachgebaut: Es ist ein eigenes Formular. Die Versicherer nehmen ihre eigenen Online-Formulare,
 *    der Bericht sammelt alles, damit man es dort abtippen kann.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var MAX_BILDER_PDF = 30;
  var MAX_HERGANG_STOERUNG = 200;

  var ARTEN = [
    { wert: 'haftpflicht', label: 'Haftpflicht (Unfall mit einem anderen)' },
    { wert: 'kasko', label: 'Kasko (Schaden am eigenen Fahrzeug)' },
    { wert: 'glas', label: 'Glasschaden' },
    { wert: 'diebstahl', label: 'Diebstahl' },
    { wert: 'sturmhagel', label: 'Sturm oder Hagel' },
    { wert: 'wild', label: 'Wildschaden' },
    { wert: 'panne', label: 'Panne' }
  ];
  var VERLETZTE = [
    { wert: 'nein', label: 'Nein, niemand verletzt' },
    { wert: 'ja', label: 'Ja, jemand wurde verletzt' }
  ];
  var LANG = 2000, KURZ = 200;

  function text(x) { return x === null || x === undefined ? '' : String(x).trim(); }
  function datum(d) { return d && MM.Hilfen && MM.Hilfen.datum ? MM.Hilfen.datum(d) : text(d); }
  function labelVon(liste, wert) { for (var i = 0; i < liste.length; i++) { if (liste[i].wert === wert) return liste[i].label; } return null; }
  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }

  /* Felder, die der Nutzer eingibt. Die Gruppen ordnen das Formular. */
  function felder() {
    return [
      { key: 'schadenart', label: 'Art des Schadens', typ: 'auswahl', optionen: ARTEN, gruppe: 'ereignis' },
      { key: 'schaden', label: 'Was ist beschädigt?', typ: 'mehrzeilig', gruppe: 'ereignis', hilfe: 'Zum Beispiel „Stoßstange hinten links eingedrückt, Rücklicht gebrochen“' },
      { key: 'datum', label: 'Datum des Ereignisses', typ: 'datum', gruppe: 'ereignis' },
      { key: 'zeit', label: 'Uhrzeit', typ: 'zeit', gruppe: 'ereignis', hilfe: 'Freiwillig.' },
      { key: 'ort', label: 'Ort', typ: 'text', gruppe: 'ereignis', hilfe: 'Straße und Ort oder eine Beschreibung der Stelle' },
      { key: 'fahrer', label: 'Wer fuhr zum Zeitpunkt?', typ: 'text', gruppe: 'ereignis', hilfe: 'Name des Fahrers. Bei Diebstahl oder Parkschaden kann es leer bleiben.' },
      { key: 'hergang', label: 'Hergang', typ: 'mehrzeilig', gruppe: 'ereignis', hilfe: 'Was ist passiert? Kurz und sachlich, in der Reihenfolge, wie es geschah.' },
      { key: 'versicherung', label: 'Deine Versicherung', typ: 'text', gruppe: 'versicherung', hilfe: 'Kommt aus den Fahrzeugangaben, wenn du sie dort einträgst. Freiwillig.' },
      { key: 'schadennummer', label: 'Versicherungs- oder Schadennummer', typ: 'text', gruppe: 'versicherung', hilfe: 'Kommt aus den Fahrzeugangaben, wenn du sie dort einträgst. Freiwillig.' },
      { key: 'gegnerName', label: 'Name', typ: 'text', gruppe: 'gegner' },
      { key: 'gegnerAnschrift', label: 'Anschrift', typ: 'text', gruppe: 'gegner' },
      { key: 'gegnerKennzeichen', label: 'Kennzeichen', typ: 'text', gruppe: 'gegner' },
      { key: 'gegnerVersicherung', label: 'Versicherung', typ: 'text', gruppe: 'gegner' },
      { key: 'zeugen', label: 'Zeugen', typ: 'mehrzeilig', gruppe: 'weitere', hilfe: 'Name und Anschrift oder Telefon, je Zeuge eine Zeile. Freiwillig.' },
      { key: 'polizei', label: 'Polizei-Aktenzeichen', typ: 'text', gruppe: 'weitere', hilfe: 'Freiwillig. Auch die Dienststelle, wenn du sie kennst.' },
      { key: 'verletzte', label: 'Wurde jemand verletzt?', typ: 'auswahl', optionen: VERLETZTE, gruppe: 'weitere', darstellung: 'wahl' },
      { key: 'verletzteText', label: 'Wer wurde verletzt, und wie?', typ: 'mehrzeilig', gruppe: 'weitere', hilfe: 'Freiwillig.' }
    ].map(kopie);
  }

  function leer(w) {
    var k = {};
    felder().forEach(function (f) { k[f.key] = ''; });
    return Object.assign(k, w || {});
  }

  /* Prüft die Eingaben. heute: 'JJJJ-MM-TT'. Ergebnis { werte, fehler, ok }. */
  function pruefen(roh, heute) {
    roh = roh || {};
    var w = {}, f = {};
    felder().forEach(function (fd) {
      var v = text(roh[fd.key]);
      var max = fd.typ === 'mehrzeilig' ? LANG : KURZ;
      if (fd.typ === 'mehrzeilig') v = String(roh[fd.key] == null ? '' : roh[fd.key]).replace(/\r\n?/g, '\n').trim();
      if (v.length > max) f[fd.key] = 'Bitte höchstens ' + max + ' Zeichen.';
      w[fd.key] = v;
    });
    if (!labelVon(ARTEN, w.schadenart) && !f.schadenart) f.schadenart = 'Bitte die Art des Schadens wählen.';
    if (!w.datum) f.datum = 'Bitte das Datum des Ereignisses eintragen.';
    else if (!/^\d{4}-\d{2}-\d{2}$/.test(w.datum) || isNaN(Date.parse(w.datum))) f.datum = 'Das Datum ist nicht lesbar.';
    else if (heute && w.datum > heute) f.datum = 'Das Datum liegt in der Zukunft.';
    if (w.zeit && !/^([01]\d|2[0-3]):[0-5]\d$/.test(w.zeit)) f.zeit = 'Die Uhrzeit ist nicht lesbar.';
    if (!w.hergang && !f.hergang) f.hergang = 'Bitte kurz beschreiben, was passiert ist.';
    if (w.verletzte && !labelVon(VERLETZTE, w.verletzte)) f.verletzte = 'Bitte „Nein“ oder „Ja“ wählen.';
    if (w.verletzte !== 'ja') w.verletzteText = '';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  }

  /* Was MobiMory vorab weiß: aus dem Ereignis „Störung“ im Logbuch (Datum, Zeit, Ort) oder dem Tag, an dem der Vorgang eingetragen wurde. */
  function vorschlag(ereignis, vorgangWerte) {
    var w = leer();
    if (ereignis && ereignis.datum) {
      w.datum = ereignis.datum;
      w.zeit = ereignis.zeit || '';
      if (ereignis.ortName) w.ort = ereignis.ortName;
      else if (typeof ereignis.breite === 'number' && typeof ereignis.laenge === 'number') w.ort = 'Position ' + ereignis.breite.toFixed(5).replace('.', ',') + ' / ' + ereignis.laenge.toFixed(5).replace('.', ',');
    } else if (vorgangWerte && vorgangWerte.gemeldetAm) {
      w.datum = vorgangWerte.gemeldetAm;
    }
    return w;
  }

  /* Die Störung, die zu einem Bericht automatisch entsteht (seit 2.0.93): Bezeichnung aus Schadenart und Datum, Beschreibung = Hergang, gekürzt.
     „Fahrzeug bleibt nutzbar“, damit ein Bericht allein kein Fahrzeug sperrt. Das Datum hat der Bericht schon geprüft (nicht in der Zukunft). */
  function stoerungAus(werte) {
    var w = werte || {};
    var l = labelVon(ARTEN, w.schadenart) || 'Schaden';
    var kurz = l.replace(/\s*\(.*$/, '');
    var h = text(w.hergang).replace(/\s+/g, ' ');
    if (h.length > MAX_HERGANG_STOERUNG) h = h.slice(0, MAX_HERGANG_STOERUNG - 1).replace(/\s+\S*$/, '') + '…';
    return { bezeichnung: 'Schaden: ' + kurz + (w.datum ? ', ' + datum(w.datum) : ''), beschreibung: h, auswirkung: 'keine', gemeldetAm: w.datum || '' };
  }

  /*
   * Der Bericht als Text. roh: { werte, fahrzeug: { name, artName, kennzeichen }, vorgang: { name } | null, belege: [{ id, bezeichnung, art, istBild }], erstelltAm }
   * Ergebnis: { titel, untertitel, abschnitte: [{ titel, zeilen: [[Name, Wert]] }], belege, bildIds }
   */
  function bauen(roh) {
    var w = leer(roh && roh.werte), fz = (roh && roh.fahrzeug) || {};
    var art = labelVon(ARTEN, w.schadenart) || '';
    function zeilen(paare) { return paare.filter(function (p) { return text(p[1]) !== ''; }); }
    var abschnitte = [];
    abschnitte.push({ titel: 'Fahrzeug', zeilen: zeilen([['Fahrzeug', fz.name], ['Art', fz.artName], ['Kennzeichen', fz.kennzeichen]]) });
    abschnitte.push({ titel: 'Ereignis', zeilen: zeilen([['Art des Schadens', art], ['Was ist beschädigt', w.schaden], ['Datum', w.datum ? datum(w.datum) : ''], ['Uhrzeit', w.zeit ? w.zeit + ' Uhr' : ''],
      ['Ort', w.ort], ['Fahrer zum Zeitpunkt', w.fahrer], ['Hergang', w.hergang]]) });
    var vz = zeilen([['Versicherung', w.versicherung], ['Versicherungs- oder Schadennummer', w.schadennummer], ['Telefon für Schadenmeldungen', fz.schadenTelefon]]);
    if (vz.length) abschnitte.push({ titel: 'Meine Versicherung', zeilen: vz });
    var gz = zeilen([['Name', w.gegnerName], ['Anschrift', w.gegnerAnschrift], ['Kennzeichen', w.gegnerKennzeichen], ['Versicherung', w.gegnerVersicherung]]);
    if (gz.length) abschnitte.push({ titel: 'Unfallgegner', zeilen: gz });
    var weitere = zeilen([['Zeugen', w.zeugen], ['Polizei-Aktenzeichen', w.polizei], ['Verletzte', w.verletzte ? (w.verletzte === 'ja' ? 'Ja' : 'Nein') : ''],
      ['Wer wurde verletzt', w.verletzteText]]);
    if (weitere.length) abschnitte.push({ titel: 'Zeugen, Polizei, Verletzte', zeilen: weitere });
    var belege = ((roh && roh.belege) || []).map(function (b) { return { id: b.id, bezeichnung: text(b.bezeichnung) || 'Beleg', art: text(b.art), istBild: !!b.istBild }; });
    return {
      titel: 'Schadensbericht' + (fz.name ? ': ' + fz.name : ''), untertitel: [art, w.datum ? datum(w.datum) : ''].filter(Boolean).join(', '),
      vorgangName: roh && roh.vorgang ? text(roh.vorgang.name) : '', abschnitte: abschnitte, belege: belege,
      bildIds: belege.filter(function (b) { return b.istBild; }).map(function (b) { return b.id; })
    };
  }

  function dateiName(buch, endung) {
    var n = text(buch && buch.titel).replace(/^Schadensbericht:?\s*/, '').replace(/[^A-Za-z0-9ÄÖÜäöüß_-]+/g, '_').replace(/^_+|_+$/g, '') || 'Fahrzeug';
    return 'Schadensbericht_' + n + (endung || '.pdf');
  }

  /* Das PDF. bilder: { <Dokument-ID>: Uint8Array mit JPEG }. ctx: { datum }. Ergebnis { bytes, bilder, ohneBild, zuViele }. */
  function pdf(buch, bilder, ctx) {
    ctx = ctx || {};
    bilder = bilder || {};
    var d = MM.Pdf.neu({ fuss: 'MobiMory · ' + buch.titel, titel: buch.titel, datum: ctx.datum });
    var eingefuegt = 0, ohne = 0, zuViele = 0;
    d.titel(buch.titel, buch.untertitel || '');
    buch.abschnitte.forEach(function (a) {
      if (!a.zeilen.length) return;
      d.abschnitt(a.titel);
      a.zeilen.forEach(function (z) { d.zeile(z[0], z[1]); });
    });
    if (buch.belege.length) {
      d.abschnitt('Belege und Fotos');
      buch.belege.forEach(function (b) {
        d.absatz(b.bezeichnung + (b.art ? ' (' + b.art + ')' : ''), { groesse: 10 });
        if (!b.istBild) return;
        if (eingefuegt >= MAX_BILDER_PDF) { zuViele++; return; }
        var x = bilder[b.id];
        if (x && d.bild(x, { maxH: 230, unterschrift: b.bezeichnung })) eingefuegt++;
        else { ohne++; d.absatz('(Das Foto liegt nicht auf diesem Gerät oder ist kein JPEG.)', { grau: true, groesse: 8 }); }
      });
    }
    if (zuViele) d.absatz('Aus Platzgründen sind nicht alle Fotos im PDF (' + zuViele + ' weitere). Die Seite in MobiMory zeigt alle.', { grau: true, groesse: 8 });
    d.absatz('Erstellt mit MobiMory' + (ctx.datum ? ' am ' + datum(String(ctx.datum).slice(0, 10)) : '') + '. Eigenes Formular, kein Europäischer Unfallbericht.', { grau: true, groesse: 8 });
    return { bytes: d.bytes(), bilder: eingefuegt, ohneBild: ohne, zuViele: zuViele };
  }

  MM.Schadensbericht = {
    ARTEN: ARTEN, VERLETZTE: VERLETZTE, MAX_BILDER_PDF: MAX_BILDER_PDF, felder: felder, leer: leer, pruefen: pruefen, vorschlag: vorschlag, stoerungAus: stoerungAus, bauen: bauen, dateiName: dateiName, pdf: pdf, labelVon: labelVon,
    TEXT_EINLEITUNG: 'Hier sammelst du alles zu einem Schaden: Fahrzeug, Ereignis, Beteiligte, Zeugen und Fotos. Daraus entsteht eine Seite und ein PDF zum Drucken oder Mailen. Die meisten Versicherer haben ein eigenes Online-Formular: Dort tippst du die Angaben aus diesem Bericht ab.',
    TEXT_BELEGE: 'Zu jedem Bericht legt MobiMory selbst eine Störung in der Werkstatt an (das Fahrzeug bleibt dabei nutzbar). Fotos und Belege wie Kostenvoranschlag, Gutachten und Rechnungen liegen als Dokumente an dieser Störung und stehen im Bericht, ohne dass du sie zweimal einträgst.',
    TEXT_FOTOS: 'Auf der Seite des Berichts nimmst du Fotos auf („Foto aufnehmen“) oder holst sie aus einer Datei („Aus Datei“).',
    TEXT_KEIN_EU: 'Das ist ein eigenes Formular von MobiMory. Es ersetzt nicht den Europäischen Unfallbericht mit Skizze und den Unterschriften beider Seiten.'
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
