package com.mobimory.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    /* Kanal für Alarm-Nachrichten (seit 2.0.121). Der Server schickt channel_id "alarm"; der Kanal muss auf dem Gerät schon da sein,
       sonst nimmt Android einen leisen Standardkanal. Die Seite legt ihn zusätzlich über das Push-Plugin an (gleiche Kennung). */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel("alarm") == null) {
                NotificationChannel k = new NotificationChannel("alarm", "Alarm", NotificationManager.IMPORTANCE_HIGH);
                k.setDescription("Alarm einer Wache (Anker oder Standort)");
                k.enableVibration(true);
                k.setVibrationPattern(new long[] { 0, 600, 300, 600, 300, 600 });
                Uri ton = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (ton == null) ton = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                k.setSound(ton, new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                k.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
                nm.createNotificationChannel(k);
            }
        }
    }
}
