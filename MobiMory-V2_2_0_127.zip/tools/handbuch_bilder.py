"""Erzeugt die Schlüsselbilder des Handbuchs aus der echten App (Playwright), mit Beispieldaten.
Aufruf: python3 handbuch_bilder.py <App-Ordner> <Ausgabe-Ordner>
Die App wird lokal ausgeliefert, die Karten-Kacheln werden durch eine neutrale Kachel ersetzt (kein Netz nötig)."""
import sys, os, io, subprocess, time, json
from playwright.sync_api import sync_playwright
from PIL import Image

app, aus = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
os.makedirs(aus, exist_ok=True)
PORT = 8766
srv = subprocess.Popen([sys.executable, '-m', 'http.server', str(PORT), '-d', app, '--bind', '127.0.0.1'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.0)
URL = f'http://127.0.0.1:{PORT}/index.html'

kachel = io.BytesIO()
t = Image.new('RGB', (256, 256), (206, 224, 232))
for i in range(0, 256, 64):
    for j in range(256):
        t.putpixel((i, j), (190, 210, 220)); t.putpixel((j, i), (190, 210, 220))
t.save(kachel, 'PNG'); KACHEL = kachel.getvalue()

SEED = """
async () => {
  const sp = await new MM.Speicher.IdbSpeicher().oeffnen();
  const d = new MM.Daten.Daten(sp); await d.starten();
  const ok = (r, w) => { if (!r || r.ok === false) throw new Error(w + ': ' + JSON.stringify(r)); return r; };
  await d.aktivitaetsartenAusVorschlaegen();
  const mia = ok(await d.personAnlegen({ bezeichnung: 'Mia Beispiel', funktionen: ['Skipper', 'Fahrer'], email: 'mia@example.org', telefon: '0171 5550123', notiz: 'Hauptverantwortliche' }), 'mia').id;
  ok(await d.personAnlegen({ bezeichnung: 'Tom Beispiel', funktionen: ['Crew'] }), 'tom');
  ok(await d.tierAnlegen({ bezeichnung: 'Bello', tierart: 'Hund' }), 'bello');
  const sbf = ok(await d.nachweisartAnlegen({ bezeichnung: 'Sportbootführerschein', gehoertZu: 'person', hatAblauf: 'nein' }), 'sbf').id;
  const fs = ok(await d.nachweisartAnlegen({ bezeichnung: 'Führerschein', gehoertZu: 'person', hatAblauf: 'ja' }), 'fs').id;
  const funk = ok(await d.nachweisartAnlegen({ bezeichnung: 'Funkzeugnis SRC', gehoertZu: 'person', hatAblauf: 'nein' }), 'funk').id;
  const nwFs = ok(await d.nachweisAnlegen('person', mia, fs, { nummer: 'B123456789', aussteller: 'Landratsamt Beispielstadt', ausgestelltAm: '2016-05-01', gueltigBis: '2036-05-01', klassen: 'B, BE' }), 'nwfs').id;
  ok(await d.nachweisAnlegen('person', mia, sbf, { nummer: 'SBF-4711', aussteller: 'DMYV' }), 'nwsbf');
  const fz = ok(await d.fahrzeugAnlegen('motorboot', { bezeichnung: 'Seestern', marke: 'Nordwerft', modell: 'Trawler 33', baujahr: '2004', registriernummer: 'KI-1234', heimathafen: 'Kiel', laenge: '10,2', breite: '3,4', tiefgang: '0,9', leergewicht: '5200', kraftstoff: 'Diesel', reisegeschwindigkeit: '12', hoechstgeschwindigkeit: '25', versicherung: 'Beispiel Versicherung' }), 'fz').id;
  const motor = ok(await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Motor Steuerbord', hersteller: 'Volvo Penta', modell: 'D3', seriennummer: 'D3-001', kurzname: 'STB', baujahr: '2004', eingebautAm: '2004-05-01', einbauort: 'Maschinenraum' }), 'motor').id;
  const pumpe = ok(await d.komponenteAnlegen(fz, motor, null, { bezeichnung: 'Wasserpumpe', hersteller: 'Beispiel', anzahl: '1' }), 'pumpe').id;
  ok(await d.komponenteAnlegen(fz, null, 'tank', { bezeichnung: 'Dieseltank', stoff: 'Diesel', merkmale: [{ name: 'Tankinhalt', wert: '400', einheit: 'l' }] }), 'tank');
  ok(await d.komponenteAnlegen(fz, null, 'strom', { bezeichnung: 'Bordbatterie' }), 'batt');
  ok(await d.fristAnlegen(fz, motor, { bezeichnung: 'Ölwechsel', kategorie: 'wartung', kalenderWert: '12', kalenderEinheit: 'monate', vorwarnTage: '30', zuletztAm: '2026-03-15' }), 'oel');
  ok(await d.fristAnlegen(fz, null, { bezeichnung: 'Feuerlöscher', kategorie: 'pruefung', kalenderWert: '24', kalenderEinheit: 'monate', vorwarnTage: '30', zuletztAm: '2025-01-10' }), 'fl');
  ok(await d.dokumentAnlegen(fz, null, { art: 'bedienung', quelle: 'link', link: 'https://example.org/anleitung', bezeichnung: 'Bedienungsanleitung Motor' }), 'dok');
  const ort = async (n, b, l, extra) => ok(await d.ortAnlegen(Object.assign({ bezeichnung: n, positionBreite: String(b), positionLaenge: String(l) }, extra || {})), 'ort ' + n).id;
  const kiel = await ort('Kiel', 54.32, 10.14, { ortart: 'hafen', land: 'DE', adresse: 'Kiellinie 1, 24105 Kiel', ausstattung: ['strom', 'wasser', 'dusche', 'treibstoff'], ansprechpartner: 'Hafenmeister', telefon: '0431 123456' });
  const eck = await ort('Eckernförde', 54.47, 9.84, { ortart: 'hafen' });
  const fl = await ort('Flensburg', 54.79, 9.44, { ortart: 'hafen' });
  const so = ok(await d.standortAnlegen(kiel, { bezeichnung: 'Steg 4, Platz 12', standortart: 'Liegeplatz', laenge: '12', breite: '4', tiefgang: '2' }), 'so').id;
  await d.fahrzeugStandortSetzen(fz, so);
  ok(await d.adresseAnlegen({ bezeichnung: 'Marine Service Nord', art: 'werkstatt', telefon: '040 123456', ansprechpartner: 'Herr Kuhn', plz: '23570', ort: 'Travemünde' }), 'adr');
  const g = ok(await d.gebietAnlegen({ bezeichnung: 'Dänemark' }), 'gebiet').id;
  ok(await d.regelAnlegen(g, { bezeichnung: 'Funkzeugnis SRC', fahrzeugArten: ['motorboot'], artIds: [funk] }), 'regel1');
  ok(await d.regelAnlegen(g, { bezeichnung: 'Schwimmhilfen', art: 'ausruestung', pflichtAusruestung: 'Persönliche Schwimmhilfe', fahrzeugArten: ['motorboot'], menge: '1', bezug: 'person' }), 'regel2');
  const gebietGespeichert = g;
  const plan = ok(await d.aktivitaetAnlegen({ bezeichnung: 'Ostseetörn', artId: (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id, fahrzeugId: fz, vonDatum: '2026-12-05', vonZeit: '08:00', bisDatum: '2026-12-07', bisZeit: '18:00', verantwortlichId: mia, startOrtId: kiel, zielOrtId: fl, zwischenzielIds: [eck] }), 'plan').id;
  const tag = ok(await d.abschnittAnlegen(plan, { datum: '2026-12-05', beginnZeit: '08:00', endeZeit: '18:00', von: 'Kiel', nach: 'Flensburg', startOrtId: kiel, zielOrtId: fl, notiz: 'Erster Tag' }), 'tag').id;
  await d.ereignisartenVorauswahlUebernehmen();
  const r = await d.logbuchSofortStarten({ fahrzeugId: fz, verantwortlichId: mia, artId: '' });
  if (!r.ok) throw new Error(JSON.stringify(r));
  const gpx = '<gpx><rte><rtept lat="54.32" lon="10.14"><n>Kiel</n></rtept><rtept lat="54.40" lon="10.00"/><rtept lat="54.47" lon="9.84"><n>Eckernförde</n></rtept><rtept lat="54.62" lon="9.70"/><rtept lat="54.79" lon="9.44"><n>Flensburg</n></rtept></rte></gpx>';
  const imp = await d.routeImportieren(r.id, gpx, 'ostsee.gpx');
  if (imp && imp.id) await d.routeAendern(imp.id, { bezeichnung: 'Kiel – Flensburg', geschwindigkeit: '6', einheit: 'kn' });
  try { await d.ereignisSchnell(r.id, 'Notiz', { text: 'Ablegen in Kiel, Wind 3 Bft aus West' }); } catch (e) {}
  return { tag, akt: r.id, plan, fz, mia, kiel, g, ort: kiel, nwFs, motor, pumpe };
}
"""

def shot(page, name):
    png = page.screenshot(type='png')
    Image.open(io.BytesIO(png)).convert('RGB').save(os.path.join(aus, name + '.jpg'), 'JPEG', quality=82)
    print('Bild', name)

with sync_playwright() as pw:
    br = pw.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
    ctx = br.new_context(viewport={'width': 900, 'height': 680}, locale='de-DE', timezone_id='Europe/Berlin',
                         geolocation={'latitude': 54.40, 'longitude': 10.00}, permissions=['geolocation'], service_workers='block')
    ctx.route('**/*tile.openstreetmap.org/**', lambda r: r.fulfill(status=200, content_type='image/png', body=KACHEL))
    ctx.route('**/*openseamap.org/**', lambda r: r.fulfill(status=200, content_type='image/png', body=KACHEL))
    page = ctx.new_page()
    fehler = []
    page.on('pageerror', lambda e: fehler.append(str(e)))
    page.goto(URL + '#/schnellstart'); page.wait_for_timeout(1500)
    shot(page, 'schnellstart')
    page.goto(URL + '#/schnellstart/person'); page.reload(); page.wait_for_timeout(1000)
    try:
        page.fill('input[type=text]', 'Mia Beispiel'); page.click('button[type=submit], .knopf:not(.leise)'); page.wait_for_timeout(1200)
    except Exception as e:
        print('Schnellstart Person:', str(e)[:80])
    page.goto(URL + '#/schnellstart/fahrzeug'); page.reload(); page.wait_for_timeout(1200)
    shot(page, 'schnellstart-fahrzeug')
    ids = page.evaluate(SEED)
    print(json.dumps(ids))
    page.reload(); page.wait_for_timeout(800)
    I = ids
    LISTE = [
        ('einrichten-ueber', '#/einstellungen/ueber', None),
        ('stammdaten', '#/stammdaten', None),
        ('erfassen-wege', '#/fahrzeuge', 'Import und Export'),
        ('erfassen-import', '#/einstellungen/import', None),
        ('erfassen-uebergabe', '#/einstellungen/uebernehmen', None),
        ('fahrzeug-art', '#/neu', None),
        ('fahrzeug-maske', f"#/fahrzeug/{I['fz']}/aendern", 'Marke'),
        ('fahrzeug-huelle', f"#/fahrzeug/{I['fz']}", 'Äußere Hülle'),
        ('fahrzeug-komponente', f"#/komponente/{I['motor']}", None),
        ('personen-formular', f"#/person/{I['mia']}", None),
        ('personen-nachweis', f"#/nachweis/{I['nwFs']}", None),
        ('orte-ort', f"#/ort/{I['kiel']}", 'Standorte'),
        ('orte-gebiet', f"#/gebiet/{I['g']}", 'Regeln dieses Gebiets'),
        ('listen-merkmale', '#/merkmale', None),
        ('listen-kosten', '#/kosten/listen', None),
        ('planen-aktivitaet', f"#/aktivitaet/{I['plan']}", None),
        ('planen-route', f"#/aktivitaet/{I['plan']}/route", None),
        ('planen-tag', f"#/tagesabschnitt/{I['tag']}", 'Voraussichtliche Ankunft'),
        ('checks-reise', f"#/reisecheck/{I['plan']}", None),
        ('checks-grund', f"#/fahrzeug/{I['fz']}/grundcheck", None),
        ('wetter-tag', f"#/tagesabschnitt/{I['tag']}", 'Etappe:'),
        ('tanken-eingabe', f"#/aktivitaet/{I['akt']}/cockpit/ereignis", 'KLICK:Ver- und Entsorgung'),
        ('kasse-buch', f"#/aktivitaet/{I['akt']}/reisekasse", None),
        ('stoerung-werkstatt', '#/werkstatt', None),
        ('geraete-konto', '#/konto', None),
        ('verleih-seite', '#/verleih', None),
        ('cockpit', f"#/aktivitaet/{I['akt']}", None),
        ('karte', f"#/aktivitaet/{I['akt']}/karte", None),
        ('wache', f"#/aktivitaet/{I['akt']}/wache", None),
        ('reisebuch', f"#/reisebuch/{I['akt']}", None),
    ]
    for hh in filter(None, os.environ.get('TEXTE', '').split(',')):
        page.goto(URL + hh.format(**I)); page.reload(); page.wait_for_timeout(1500)
        print('##', hh, page.evaluate("() => Array.from(document.querySelectorAll('h1,h2,h3,button,a.knopf,summary')).map(e => e.textContent.trim().slice(0, 50)).filter(Boolean).join(' | ')")[:1400])
    if os.environ.get('AUSWERTEN'):
        print('## AUSWERTEN', page.evaluate(os.environ['AUSWERTEN']))
    nur = os.environ.get('NUR')
    for name, h, scroll in LISTE:
        if nur and name not in nur.split(','): continue
        page.goto(URL + h); page.reload(); page.wait_for_timeout(2200 if name in ('karte', 'cockpit', 'wache') else 1400)
        if scroll and scroll.startswith('KLICK:'):
            try:
                page.get_by_text(scroll[6:], exact=True).first.click(); page.wait_for_timeout(700)
            except Exception as e:
                print('Klick fehlgeschlagen:', name, str(e)[:80])
        elif scroll:
            ok = page.evaluate("(t) => { const e = Array.from(document.querySelectorAll('h1,h2,h3,h4,summary,label,legend')).find(x => x.textContent.trim().startsWith(t)); if (e) { e.scrollIntoView(); return true; } return false; }", scroll)
            if not ok: print('Abschnitt nicht gefunden:', name, scroll)
            page.wait_for_timeout(300)
        else:
            page.evaluate("() => window.scrollTo(0, 0)")
        shot(page, name)
    print('Seitenfehler:', fehler)
    br.close()
srv.terminate()
