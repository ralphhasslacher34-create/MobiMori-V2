# Homepage-Text: neue Funktionen 2.0.115 bis 2.0.117

Für mobimory.com, zum Einfügen in die Seite. Entwurf, bitte vor dem Veröffentlichen prüfen (besonders Aussagen zu Versicherung und Haftung). Jeder Block steht einmal als Text und einmal als fertiger HTML-Schnipsel.

---

## Überschrift

**Wer fährt, wer steuert, wer hat was geändert: lückenlos dokumentiert.**

## Einleitung (2 Sätze)

MobiMory hält fest, wer wann die Verantwortung hatte, wann der Kurs gewechselt wurde und wer wann warum etwas korrigiert hat. Alles bleibt nachvollziehbar, auch Monate später und auch für die Versicherung.

---

## Die Verkaufsargumente

### 1. Wechsel der Verantwortung (seit 2.0.115)
Skipper und Rudergänger wechseln mit einem Tipp. MobiMory speichert Zeit und Position des Wechsels. Der Skipper bleibt verantwortlich, am Ruder kann jeder an Bord stehen, nur kein Tier. An Land heißt es Fahrerwechsel. Alles steht im Logbuch und im Reisebuch.

### 2. Kurswechsel mit Grund (seit 2.0.116, Wasserfahrzeuge)
Ein Tipp im Cockpit: „Kurswechsel festhalten“. Du wählst den Grund (geplant, Plan geändert, Hindernis, Wetter, Strömung/Wind, falscher Kurs, sonstiges). MobiMory trägt Zeit, Position und den Kurs über Grund vom GPS ein. Auf der Karte erscheint das Zeichen „KW“.

### 3. Wechselpunkte aus deiner Routen-Datei (seit 2.0.116)
Lies die geplante Route aus deiner Navigations-App ein (GPX, zum Beispiel NavShip). Jeder Routenpunkt wird ein Wechselpunkt mit Soll-Kurs und Entfernung. Im Cockpit meldet MobiMory den nächsten Wechselpunkt, ab zwei Seemeilen hervorgehoben. Ohne Netz, ohne Zusatzkosten.

### 4. Wechselpunkte von Hand (neu in 2.0.117)
Keine Datei zur Hand? Trage Wechselpunkte selbst ein: Breite und Länge tippen oder mit einem Tipp die aktuelle Position nehmen. Auch zu einer aufgezeichneten Spur lassen sich so Wechselpunkte setzen.

### 5. Änderungen nur mit Begründung (neu in 2.0.117)
Wer die Position eines Eintrags nachträglich ändert, muss sagen, warum. Der Verlauf hält fest: wer (der Verantwortliche), wann, warum, alte und neue Position. Nichts wird überschrieben, der frühere Stand bleibt sichtbar. Das steht auch im Reisebuch.

### 6. Deine Geräte im Griff (neu in 2.0.117)
Im Konto siehst du alle angemeldeten Geräte und meldest jedes andere mit einem Tipp ab. Ist die erlaubte Zahl erreicht, bietet MobiMory beim Anmelden an, das älteste Gerät abzumelden.

---

## Kurzfassung für eine Kachel (je ein Satz)

- **Verantwortung:** Wechsel von Skipper und Rudergänger mit Zeit und Position festhalten.
- **Kurswechsel:** Ein Tipp, ein Grund, Kurs über Grund vom GPS, Zeichen „KW“ auf der Karte.
- **Wechselpunkte:** Aus deiner GPX-Datei oder von Hand, mit Soll-Kurs und Meldung im Cockpit.
- **Nachvollziehbar:** Jede Änderung der Position mit Wer, Wann und Warum im Verlauf.
- **Geräte:** Alle angemeldeten Geräte sehen und abmelden.

---

## HTML-Schnipsel (zum Einfügen)

```html
<section class="neu-funktionen" id="neu">
  <h2>Wer fährt, wer steuert, wer hat was geändert: lückenlos dokumentiert</h2>
  <p>MobiMory hält fest, wer wann die Verantwortung hatte, wann der Kurs gewechselt wurde und wer wann warum etwas korrigiert hat. Alles bleibt nachvollziehbar, auch Monate später und auch für die Versicherung.</p>
  <ul>
    <li><strong>Wechsel der Verantwortung</strong>: Skipper und Rudergänger wechseln mit einem Tipp, mit Zeit und Position. An Land: Fahrerwechsel.</li>
    <li><strong>Kurswechsel mit Grund</strong>: Ein Tipp im Cockpit, Grund wählen, Zeit, Position und Kurs über Grund vom GPS werden eingetragen. Auf der Karte erscheint „KW“.</li>
    <li><strong>Wechselpunkte aus deiner Routen-Datei</strong>: GPX aus deiner Navi-App einlesen, jeder Routenpunkt wird ein Wechselpunkt mit Soll-Kurs und Entfernung. Das Cockpit meldet den nächsten.</li>
    <li><strong>Wechselpunkte von Hand</strong>: Breite und Länge eintippen oder die aktuelle Position nehmen.</li>
    <li><strong>Änderungen nur mit Begründung</strong>: Wer die Position nachträglich ändert, muss sagen, warum. Der Verlauf zeigt wer, wann, warum, alt und neu.</li>
    <li><strong>Deine Geräte im Griff</strong>: Alle angemeldeten Geräte ansehen und mit einem Tipp abmelden.</li>
  </ul>
</section>
```
