# Android-App (Hülle) – so kommt die APK zu dir und zu den Nutzern

Die Web-App bleibt, wie sie ist (Browser, Desktop-PC). Die Android-App ist ein zusätzlicher Weg: dieselbe App in einer Hülle, die im Hintergrund weiter aufzeichnen darf. Apple kommt später.

Seit 2.0.113 gibt es zwei Arten von APK:

| Art | Wann | Wo liegt sie |
|---|---|---|
| **Test-APK** | solange die Geheimnisse (unten) in GitHub **fehlen** | Actions › Lauf › Artifacts › **MobiMori-APK** |
| **Echte APK** (signiert) | sobald die zwei Geheimnisse in GitHub **stehen** | Actions › Lauf › Artifacts › **MobiMory-Download** |

## Einmalig: Release-Schlüssel in GitHub eintragen

Der Schlüssel unterschreibt die App. **Geht er verloren, kann keine App mehr über die alte aktualisiert werden.** Deshalb: die Datei `mobimory-release.jks` an **zwei** sicheren Orten aufheben (zum Beispiel Cloud-Speicher und USB-Stick) und nie ins Repository hochladen.

1. GitHub › Repository **MobiMori-V2** › **Settings** › **Secrets and variables** › **Actions** › **New repository secret**.
2. Erstes Geheimnis: Name `MM_KEYSTORE_PASSWORD`, Wert = das Kennwort aus der Datei `GITHUB-GEHEIMNISSE.txt`.
3. Zweites Geheimnis: Name `MM_KEYSTORE_BASE64`, Wert = die lange Zeile aus derselben Datei.
4. Den neuen Ablauf ersetzen: GitHub › **.github/workflows** öffnen › **Add file › Upload files** › die Datei `android-apk.yml` hochladen (gleicher Name ersetzt die alte) › **Commit**.
5. Danach läuft der nächste Bau mit dem Schlüssel.

## Jede neue Version: APK und Homepage

1. Die neue ZIP wie bisher bei GitHub hochladen (Upload files).
2. **Actions** › oberster Lauf **Android-APK bauen** › grüner Haken = fertig (5 bis 10 Minuten). Roter Kreis: den Lauf öffnen und die rote Meldung an Claude schicken.
3. Beim fertigen Lauf unten bei **Artifacts** auf **MobiMory-Download** tippen. Das lädt eine ZIP. Darin liegen `MobiMory.apk`, `version.json` und `download.html`.
4. ZIP auf dem Tablet entpacken.
5. Cloudflare › **Workers & Pages** › Dienst der Homepage (**noisy-union-4869**, mobimory.com) › neue Bereitstellung. Hochladen: die drei Dateien aus Schritt 3 **und die `index.html` der Homepage**. Immer alle Dateien zusammen hochladen, sonst kann die Startseite fehlen.
6. Prüfen: `https://mobimory.com/version.json` zeigt die neue Version, `https://mobimory.com/download.html` lädt die APK.
7. Auf dem Tablet startet die App (Version davor) beim nächsten Öffnen mit dem Hinweis **Neue Version verfügbar**.

Die Datei darf höchstens 25 MiB groß sein (Grenze bei Cloudflare). Der Bau zeigt eine Warnung, wenn die APK größer ist.

## Auf dem Tablet installieren (erstes Mal)

1. Auf `mobimory.com/download.html` die APK laden, die Datei antippen.
2. Android fragt, ob Installationen aus dieser Quelle erlaubt sind („Unbekannte Quellen“): einmal erlauben.
3. Installieren, dann öffnen. Beim ersten Mal fragt Android nach **Standort** (genau, bei Nutzung der App) und nach **Benachrichtigungen**: beides erlauben.
4. Läuft die Aufzeichnung, steht oben die Benachrichtigung „MobiMory zeichnet auf“.

**Wechsel von der Test-APK auf die echte APK (einmalig):** Die Signatur ist eine andere, Android lässt kein Update darüber zu. Vorher in der App eine Sicherung machen, dann die Test-App löschen und die echte APK installieren, danach die Sicherung zurückspielen. Ab dann gehen Updates direkt über die alte App.

## Wichtig

- Die App in der Hülle hat einen eigenen Speicher, getrennt vom Browser. Daten aus der Web-App kommen über die Sicherung (Datei) oder das Konto.
- Eine neue Version der Web-App kommt nur mit einer neuen APK aufs Tablet.
- Die Update-Prüfung gibt es nur in der Android-App. Sie fragt beim Start `mobimory.com/version.json` ab und öffnet für den Download den Browser des Geräts. Ein stilles Update im Hintergrund geht nur über den Play Store (kommt später, braucht ein Entwicklerkonto).
- Manche Hersteller beenden Dienste im Hintergrund trotz Dauerdienst. Dann in den Android-Einstellungen der App den Akku auf „Nicht eingeschränkt“ stellen.
