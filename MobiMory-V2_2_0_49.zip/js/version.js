/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.49';
  MM.STUFE = 'Korrektur: weiteren Tank anlegen, ohne das Formular zu verlieren; Foto mit zwei klaren Knöpfen';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
