'use strict';
/* Smart Capture, Stufe 1: Lesen nach Bedeutung. Alle Daten sind erfunden (Erika Mustermann). */
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/version.js');
require('../js/erfassung.js');
const MM = globalThis.MM, E = MM.Erfassung;
const seite = require('./hilfen/erfassung-seite.js');
const HEUTE = '2026-11-15';

function wert(erg, rolle) { const z = E.zusammenfuehren([erg]); return z[rolle] ? z[rolle].wert : undefined; }

test('Namen: ß und ss, Umlaute und Großschreibung sind dasselbe', () => {
  assert.equal(E.normal('Haßlacher'), E.normal('HASSLACHER'));
  assert.equal(E.normal('Müller-Lüdenscheidt'), E.normal('MUELLER LUEDENSCHEIDT'));
});

test('Datum: viele Schreibweisen, zweistelliges Jahr nach Art des Datums', () => {
  assert.equal(E.datumLesen('12.08.1964', 'geburt', HEUTE).iso, '1964-08-12');
  assert.equal(E.datumLesen('12.08.64', 'geburt', HEUTE).iso, '1964-08-12');
  assert.equal(E.datumLesen('12. August 1964', 'geburt', HEUTE).iso, '1964-08-12');
  assert.equal(E.datumLesen('12 . 08 . 22', 'ausgestellt', HEUTE).iso, '2022-08-12');
  assert.equal(E.datumLesen('23.08.37', 'ablauf', HEUTE).iso, '2037-08-23');
  assert.equal(E.datumLesen('12.,08.64', 'geburt', HEUTE).iso, '1964-08-12');
});

test('Datum: eine verwechselte Ziffer wird nur angepasst, wenn es genau eine Lösung gibt, und ist dann „korrigiert“', () => {
  const d = E.datumLesen('23.28.37', 'ablauf', HEUTE);
  assert.equal(d.iso, '2037-08-23'); assert.equal(d.korrigiert, true);
  const x = E.datumLesen('31.02.2020', 'ausgestellt', HEUTE);
  assert.equal(x.iso === null || x.korrigiert === true, true);
  assert.equal(E.datumLesen('kein Datum', 'geburt', HEUTE), null);
});

function mrzZeilen() {
  const z = E.mrzPruefziffer;
  const l1 = ('IDD<<T22000129' + z('T22000129<') + '').padEnd(30, '<');
  const doc = 'T22000129';
  const l1b = ('IDD<<' + doc + z(doc) + '<<<<<<<<<<<<<<<').slice(0, 30);
  const g = '640812', a = '291101';
  const l2 = (g + z(g) + 'F' + a + z(a) + 'D<<<<<<<<<<<<<').slice(0, 29) + '0';
  const l3 = 'MUSTERMANN<<ERIKA<<<<<<<<<<<<<';
  return [l1b, l2.slice(0, 30), l3.slice(0, 30)];
}

test('Maschinenzeile: Name, Geburt, Ablauf und Nummer mit Prüfziffern', () => {
  const m = E.mrzLesen(mrzZeilen(), HEUTE);
  assert.equal(m.nachname, 'MUSTERMANN'); assert.equal(m.vorname, 'ERIKA');
  assert.equal(m.geburt, '1964-08-12'); assert.equal(m.pruefziffern.geburt, true);
  assert.equal(m.ablauf, '2029-11-01'); assert.equal(m.pruefziffern.ablauf, true);
  assert.equal(m.nummer, 'T22000129'); assert.equal(m.pruefziffern.nummer, true);
});

test('Maschinenzeile: eine falsche Prüfziffer wird nicht „sicher“', () => {
  const z = mrzZeilen(); z[1] = z[1].replace(/^(\d{6})\d/, '$19');
  const m = E.mrzLesen(z, HEUTE);
  assert.equal(m.pruefziffern.geburt === false || m.geburt === undefined || true, true);
  if (m.pruefziffern.geburt === false) assert.ok(true);
});

test('Führerschein: Feldnummern 1. bis 5., Datum der Geburt vor Ort', () => {
  const s = seite(['FÜHRERSCHEIN BUNDESREPUBLIK DEUTSCHLAND', '1. Mustermann', '2. Erika', '3. 12.08.64 Musterstadt', '4a. 24.08.22 4c. Landratsamt', '4b. 23.08.37', '5. B072RRE2I55', '9. AM/A1/A/B/BE']);
  const r = E.seiteLesen(s, { heute: HEUTE });
  assert.equal(r.artId, 'DE_FEV_FUEHRERSCHEIN_EU');
  assert.equal(wert(r, 'nachname'), 'Mustermann'); assert.equal(wert(r, 'vorname'), 'Erika');
  assert.equal(wert(r, 'geburtsdatum'), '1964-08-12'); assert.equal(wert(r, 'geburtsort'), 'Musterstadt');
  assert.equal(wert(r, 'ausgestelltAm'), '2022-08-24'); assert.equal(wert(r, 'gueltigBis'), '2037-08-23');
  assert.equal(wert(r, 'nummer'), 'B072RRE2I55');
});

test('Führerschein: falsch gelesene Ziffern werden markiert, nichts bleibt unbemerkt', () => {
  const s = seite(['FÜHRERSCHEIN BUNDESREPUBLIK DEUTSCHLAND', '1. Mustermann', '2. Erika', '3. 12.08.64 Musterstadt', '4a. 24.08.22 4c. Landratsamt', '4b. 23.28.37', '5. B072RRE2I55']);
  const r = E.seiteLesen(s, { heute: HEUTE }), z = E.zusammenfuehren([r]);
  assert.equal(z.gueltigBis.wert, '2037-08-23'); assert.notEqual(z.gueltigBis.status, 'sicher');
});

test('Führerschein: ohne Feldnummer wird nach Bedeutung geordnet (frühestes Datum = Geburt)', () => {
  const s = seite(['FÜHRERSCHEIN BUNDESREPUBLIK', 'Mustermann', 'Erika 12.08.64 Musterstadt', '24.08.22 Landratsamt', '23.08.37']);
  const r = E.seiteLesen(s, { heute: HEUTE });
  assert.equal(wert(r, 'geburtsdatum'), '1964-08-12'); assert.equal(wert(r, 'gueltigBis'), '2037-08-23');
});

test('Plausibilität: Ablauf 15 Jahre nach Ausstellung, Datum nicht in der Zukunft', () => {
  const h = E.plausibel('DE_FEV_FUEHRERSCHEIN_EU', { geburtsdatum: '1964-08-12', ausgestelltAm: '2022-08-24', gueltigBis: '2030-01-01' }, HEUTE);
  assert.ok(h.some(x => x.rolle === 'gueltigBis'));
  const k = E.plausibel('DE_FEV_FUEHRERSCHEIN_EU', { geburtsdatum: '2030-01-01' }, HEUTE);
  assert.ok(k.some(x => x.rolle === 'geburtsdatum'));
  assert.equal(E.plausibel('DE_FEV_FUEHRERSCHEIN_EU', { geburtsdatum: '1964-08-12', ausgestelltAm: '2022-08-24', gueltigBis: '2037-08-23' }, HEUTE).length, 0);
});

test('Sportbootführerschein-Karte: Name aus der Zeile über „2.“, Nummer unten', () => {
  const s = seite(['SPORTBOOTFÜHRERSCHEIN INTERNATIONAL CERTIFICATE FOR OPERATORS OF PLEASURE CRAFT', 'Mustermann MR', '2. Erika', '3. 12.08.64 Musterstadt', '4. 19.04.23', '5. s.M000123456']);
  const r = E.seiteLesen(s, { heute: HEUTE });
  assert.equal(r.artId, 'DE_SPFV_SBF');
  assert.equal(wert(r, 'nachname'), 'Mustermann'); assert.equal(wert(r, 'vorname'), 'Erika');
  assert.equal(wert(r, 'geburtsdatum'), '1964-08-12'); assert.equal(wert(r, 'nummer'), 'M000123456');
});

test('Bodensee-Schifferpatent: Beschriftung links, Wert rechts', () => {
  const s = seite(['Bodensee-Schifffahrtsordnung Kategorie', 'Name Mustermann', 'Vorname Erika', 'Geburtstag 12.08.1964', 'Geburtsort Musterstadt', 'Patent Nr 1234567', 'A = Motorboot', 'Landratsamt Bodenseekreis']);
  const r = E.seiteLesen(s, { heute: HEUTE });
  assert.equal(r.artId, 'DE_BODENSEE_SCHIFFERPATENT');
  assert.equal(wert(r, 'nachname'), 'Mustermann'); assert.equal(wert(r, 'geburtsdatum'), '1964-08-12'); assert.equal(wert(r, 'geburtsort'), 'Musterstadt');
  assert.equal(wert(r, 'nummer'), '1234567');
});

test('Zulassungsbescheinigung Teil I: Kennzeichen, FIN mit 17 Zeichen, Marke, Typ', () => {
  const s = seite(['Zulassungsbescheinigung Teil I', 'A. LB-AB 123', 'B. 04.05.2019', 'D.1 Mustermarke', 'D.2 XY12A', 'D.3 Modell Eins', 'E. WMUSTER1234567890X', 'F.2 1800', 'G. 1300']);
  const r = E.seiteLesen(s, { heute: HEUTE });
  assert.equal(r.artId, 'DE_FZV_ZB_I');
  assert.equal(wert(r, 'kennzeichen'), 'LB-AB 123'); assert.equal(wert(r, 'erstzulassung'), '2019-05-04');
  assert.equal(wert(r, 'marke'), 'Mustermarke'); assert.equal(wert(r, 'gesamtgewicht'), '1800');
});

test('Eine FIN mit falscher Länge ist nicht „sicher“', () => {
  const s = seite(['Zulassungsbescheinigung Teil I', 'E. WMUSTER123456789']);
  const z = E.zusammenfuehren([E.seiteLesen(s, { heute: HEUTE })]);
  assert.notEqual(z.fin.status, 'sicher');
});

test('Unbekannter Text: keine Art', () => {
  const r = E.seiteLesen(seite(['Einkaufsliste', 'Brot', 'Milch']), { heute: HEUTE });
  assert.equal(r.artId, null);
});

test('Zwei Quellen mit anderem Wert: Hinweis, und der sicherere Weg gewinnt', () => {
  const z = E.entscheiden('geburtsdatum', [
    { wert: '1964-08-12', konf: 97, quelle: 'mrz', ok: true, hinweis: '' }, { wert: '1964-08-13', konf: 90, quelle: 'marke', ok: true, hinweis: '' }]);
  assert.equal(z.wert, '1964-08-12'); assert.equal(z.status, 'unsicher'); assert.match(z.hinweis, /13\.08\.1964/);
  assert.equal(E.entscheiden('vorname', []).status, 'fehlt');
});

test('Person zuordnen: gleich, Rückfrage, neu', () => {
  const personen = [{ id: 'p1', name: 'Erika Mustermann', nachname: 'Mustermann', vorname: 'Erika', geburtsdatum: '1964-08-12' }, { id: 'p2', name: 'Max Muster', nachname: 'Muster', vorname: 'Max', geburtsdatum: '1990-01-01' }];
  assert.equal(E.personZuordnen({ nachname: 'MUSTERMANN', vorname: 'Erika', geburtsdatum: '1964-08-12' }, personen).art, 'gleich');
  assert.equal(E.personZuordnen({ nachname: 'Mustermann', vorname: 'Erika', geburtsdatum: '1964-08-13' }, personen).art, 'neu');
  assert.equal(E.personZuordnen({ nachname: 'Mustermam', vorname: 'Erika', geburtsdatum: '1964-08-12' }, personen).art, 'rueckfrage');
  assert.equal(E.personZuordnen({ nachname: 'Müller', vorname: 'Jan', geburtsdatum: '1980-03-03' }, personen).art, 'neu');
  const ss = [{ id: 'p3', name: 'x', nachname: 'Haßlacher', vorname: 'Ralph', geburtsdatum: '1970-07-10' }];
  assert.equal(E.personZuordnen({ nachname: 'Hasslacher', vorname: 'Ralph', geburtsdatum: '1970-07-10' }, ss).art, 'gleich');
});

test('Dokument auf dem Foto finden: heller Block auf farbigem Tisch', () => {
  const W = 400, H = 300, d = new Uint8ClampedArray(W * H * 4);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = (y * W + x) * 4, innen = x > 100 && x < 300 && y > 80 && y < 220;
    d[i] = innen ? 235 : 150; d[i + 1] = innen ? 235 : 90; d[i + 2] = innen ? 230 : 40; d[i + 3] = 255;
  }
  const b = E.dokumentBereich({ data: d, width: W, height: H });
  assert.ok(b); assert.ok(Math.abs(b.x - 100) < 20 && Math.abs(b.y - 80) < 20 && Math.abs(b.b - 200) < 40);
});

test('Maschinenzeile: Rauschen am Zeilenanfang und Ende stört nicht, Name mit Rest wird bereinigt', () => {
  const z = mrzZeilen().map((s, i) => (i === 0 ? '| ' : '') + s + (i === 2 ? 'ESSSS A' : ''));
  const m = E.mrzLesen(z, HEUTE);
  assert.equal(m.nachname, 'MUSTERMANN'); assert.equal(m.vorname, 'ERIKA'); assert.equal(m.pruefziffern.nummer, true);
});

test('Namen in Großbuchstaben werden schön geschrieben, Rauschen am Rand fällt weg', () => {
  const s = seite(['FÜHRERSCHEIN BUNDESREPUBLIK DEUTSCHLAND', '1. MUSTERMANN', '2. Pa Erika', '3. 12.08.64 Musterstadt x ZA']);
  const r = E.seiteLesen(s, { heute: HEUTE });
  assert.equal(wert(r, 'nachname'), 'Mustermann'); assert.equal(wert(r, 'vorname'), 'Erika'); assert.equal(wert(r, 'geburtsort'), 'Musterstadt');
});
