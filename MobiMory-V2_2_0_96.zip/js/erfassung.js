/*
 * Smart Capture (Schritt 14), Stufe 1: Lesen der Nachweise und Fahrzeugpapiere. NUR RECHNUNG, kein Bildschirm, keine Kamera.
 *
 * Was hier steht:
 *  - Bild: das Dokument auf dem Foto finden (der Tisch ist warm und kräftig gefärbt, Papier und Karten sind es nicht), grau und kontrastreich machen
 *  - Text: Namen vergleichen (ß = ss, Umlaute), Daten lesen (10.07.70, 10.07.1970, „10. Juli 1970“), Maschinenzeile des Personalausweises mit Prüfziffern
 *  - Erkennung der Dokumentart und das Lesen der Angaben NACH BEDEUTUNG: Feldnummer („3.“), Beschriftung („Geburtsort“) oder Muster (Datum, Nummer),
 *    nie nach fester Stelle auf dem Foto
 *  - Zusammenführen mehrerer Seiten, Plausibilitätsprüfung, Zuordnung zu einer vorhandenen Person
 *
 * Die Texterkennung selbst (Tesseract) liegt in js/erfassung-motor.js. Hier kommt nur ihr Ergebnis an, als „Seite“:
 *   { breite, hoehe, zeilen: [ { text, konf, b: {x0,y0,x1,y1}, woerter: [ { t, konf, b } ] } ] }
 *
 * Reine Haftungsaussage: Das Lesen ist eine Hilfestellung. Jede Angabe wird vom Nutzer bestätigt, nichts davon ist eine rechtsgültige Aussage.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* ---------- Text ---------- */
  var UMLAUTE = { 'ä': 'ae', 'ö': 'oe', 'ü': 'ue', 'Ä': 'ae', 'Ö': 'oe', 'Ü': 'ue', 'ß': 'ss', 'é': 'e', 'è': 'e', 'ê': 'e', 'á': 'a', 'à': 'a', 'â': 'a', 'ó': 'o', 'ô': 'o', 'ú': 'u', 'í': 'i', 'ç': 'c', 'ñ': 'n', 'š': 's', 'ž': 'z', 'č': 'c' };
  /* Vergleichsform: klein, ß = ss, Umlaut = ae/oe/ue, nur Buchstaben und Ziffern. So sind „Haßlacher“ und „HASSLACHER“ dasselbe. */
  function normal(s) {
    var t = String(s === null || s === undefined ? '' : s), r = '', i, c;
    for (i = 0; i < t.length; i++) { c = t.charAt(i); r += UMLAUTE[c] !== undefined ? UMLAUTE[c] : c; }
    return r.toLowerCase().replace(/[^a-z0-9]/g, '');
  }
  function leer(s) { return !String(s === null || s === undefined ? '' : s).trim(); }
  function saeubern(s) { return String(s === null || s === undefined ? '' : s).replace(/[|\\_*“”"‚‘’`~^]+/g, ' ').replace(/\s+/g, ' ').trim(); }
  function abstand(a, b) {
    var m = a.length, n = b.length, i, j, d = [], t, k;
    if (!m) return n; if (!n) return m;
    for (i = 0; i <= m; i++) { d[i] = [i]; }
    for (j = 1; j <= n; j++) d[0][j] = j;
    for (i = 1; i <= m; i++) for (j = 1; j <= n; j++) {
      t = a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1;
      k = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + t);
      d[i][j] = k;
    }
    return d[m][n];
  }

  /* ---------- Datum ---------- */
  var MONATE = { januar: 1, jaenner: 1, februar: 2, maerz: 3, april: 4, mai: 5, juni: 6, juli: 7, august: 8, september: 9, oktober: 10, november: 11, dezember: 12,
    jan: 1, feb: 2, mar: 3, mrz: 3, apr: 4, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, okt: 10, nov: 11, dez: 12 };
  /* Verwechslungen der Texterkennung bei Ziffern: Welche Ziffer wird oft für welche gelesen? */
  var VERWECHSLUNG = { '0': '86925', '1': '74', '2': '70', '3': '85', '4': '1', '5': '63', '6': '580', '7': '12', '8': '03692', '9': '80' };

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function tageImMonat(j, m) { return new Date(Date.UTC(j, m, 0)).getUTCDate(); }
  function gueltigesDatum(j, m, t) { return j >= 1000 && j <= 2999 && m >= 1 && m <= 12 && t >= 1 && t <= tageImMonat(j, m); }
  function iso(j, m, t) { return j + '-' + pad(m) + '-' + pad(t); }
  /* Zweistelliges Jahr: wann liegt das Datum? vergangen (Geburt, Ausstellung) oder künftig (Ablauf). */
  function jahrVon2(yy, art, heute) {
    var jetzt = heute ? parseInt(String(heute).slice(0, 4), 10) : new Date().getFullYear();
    if (art === 'ablauf') { return yy + 2000 > jetzt + 60 ? 1900 + yy : 2000 + yy; }
    return 2000 + yy > jetzt ? 1900 + yy : 2000 + yy;
  }

  /* Liest EIN Datum aus einem Text. Gibt { iso, korrigiert } oder null. art: 'geburt' | 'ausgestellt' | 'ablauf' (bestimmt das Jahrhundert bei zweistelligem Jahr).
     Ist das Datum so nicht gültig (zum Beispiel „23.28.37“), wird versucht, eine einzelne verwechselte Ziffer zu finden; ist genau ein Ergebnis möglich, kommt es als „korrigiert“ zurück. */
  function datumLesen(text, art, heute) {
    var t = String(text === null || text === undefined ? '' : text), m, tag, mon, jahr, i, q, rest;
    t = t.replace(/,/g, '.').replace(/\s*\.\s*/g, '.').replace(/\.{2,}/g, '.').replace(/(\d)\s+(?=\d)/g, '$1');
    /* „10.Juli 1970“ */
    m = /(\d{1,2})\.?\s*([A-Za-zÄÖÜäöüß]{3,9})\.?\s*(\d{4})/.exec(t);
    if (m) {
      mon = MONATE[normal(m[2])];
      if (mon && gueltigesDatum(parseInt(m[3], 10), mon, parseInt(m[1], 10))) return { iso: iso(parseInt(m[3], 10), mon, parseInt(m[1], 10)), korrigiert: false };
    }
    m = /(\d{1,2})\.(\d{1,2})\.(\d{4}|\d{2})(?!\d)/.exec(t);
    if (!m) return null;
    tag = parseInt(m[1], 10); mon = parseInt(m[2], 10); jahr = m[3].length === 2 ? jahrVon2(parseInt(m[3], 10), art, heute) : parseInt(m[3], 10);
    if (gueltigesDatum(jahr, mon, tag)) return { iso: iso(jahr, mon, tag), korrigiert: false };
    /* Eine Ziffer verwechselt? Nur gültige Ergebnisse zählen, und nur, wenn es genau eins gibt. */
    var gefunden = [], teile = [m[1], m[2], m[3]];
    for (q = 0; q < 3; q++) {
      for (i = 0; i < teile[q].length; i++) {
        var alt = teile[q].charAt(i), kand = VERWECHSLUNG[alt] || '', k;
        for (k = 0; k < kand.length; k++) {
          var neu = teile.slice(); neu[q] = teile[q].substr(0, i) + kand.charAt(k) + teile[q].substr(i + 1);
          var tt = parseInt(neu[0], 10), mm = parseInt(neu[1], 10), jj = neu[2].length === 2 ? jahrVon2(parseInt(neu[2], 10), art, heute) : parseInt(neu[2], 10);
          if (gueltigesDatum(jj, mm, tt) && gefunden.indexOf(iso(jj, mm, tt)) < 0) gefunden.push(iso(jj, mm, tt));
        }
      }
    }
    rest = gefunden.length === 1 ? gefunden[0] : null;
    return rest ? { iso: rest, korrigiert: true } : { iso: null, korrigiert: false, roh: m[0] };
  }

  /* Alle Daten in einem Text (in der Reihenfolge, wie sie dort stehen), mit der Stelle im Text. */
  function datenInText(text, art, heute) {
    var t = String(text || ''), erg = [], re = /(\d{1,2})\s*[.,]\s*(\d{1,2})\s*[.,]\s*(\d{4}|\d{2})(?!\d)/g, m, d;
    while ((m = re.exec(t))) {
      d = datumLesen(m[0], art, heute);
      erg.push({ roh: m[0], iso: d ? d.iso : null, korrigiert: d ? d.korrigiert : false, pos: m.index });
    }
    var re2 = /(\d{1,2})\.?\s*(Januar|Februar|März|Maerz|April|Mai|Juni|Juli|August|September|Oktober|November|Dezember)\s*(\d{4})/gi;
    while ((m = re2.exec(t))) {
      d = datumLesen(m[0], art, heute);
      if (d) erg.push({ roh: m[0], iso: d.iso, korrigiert: false, pos: m.index });
    }
    erg.sort(function (a, b) { return a.pos - b.pos; });
    return erg;
  }

  function datumAnzeige(isoText) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(isoText || '');
    return m ? m[3] + '.' + m[2] + '.' + m[1] : (isoText || '');
  }

  /* ---------- Maschinenzeile (MRZ) des Personalausweises, Format TD1, drei Zeilen zu 30 Zeichen ---------- */
  var MRZ_WERT = {};
  (function () { var i; for (i = 0; i < 10; i++) MRZ_WERT[String(i)] = i; for (i = 0; i < 26; i++) MRZ_WERT[String.fromCharCode(65 + i)] = 10 + i; MRZ_WERT['<'] = 0; })();
  function mrzPruefziffer(s) {
    var gew = [7, 3, 1], sum = 0, i, w;
    for (i = 0; i < s.length; i++) { w = MRZ_WERT[s.charAt(i)]; if (w === undefined) return -1; sum += w * gew[i % 3]; }
    return sum % 10;
  }
  /* Zeichen, die für „<“ gelesen werden */
  function mrzZeile(z) {
    return String(z || '').toUpperCase().replace(/^[\s|\[\](){}«‹'‘’"“”.,;:!-]+/, '').replace(/\s+/g, '').replace(/[«‹(\[{|]/g, '<').replace(/[^A-Z0-9<]/g, '<');
  }
  function mrzZiffern(s) { return s.replace(/O/g, '0').replace(/[IL]/g, '1').replace(/S/g, '5').replace(/B/g, '8').replace(/Z/g, '2').replace(/G/g, '6'); }
  /* Liest die Maschinenzeile aus den Textzeilen einer Seite. Gibt null, wenn keine da ist. */
  function mrzLesen(texte, heute) {
    var z = (texte || []).map(mrzZeile).filter(function (s) { return s.length >= 12 && (s.match(/</g) || []).length >= 3; });
    var l1 = null, l2 = null, l3 = null, i, erg = { pruefziffern: {}, gelesen: false };
    for (i = 0; i < z.length; i++) {
      if (!l1 && /^I[D<A-Z]/.test(z[i]) && /<</.test(z[i].slice(2, 8))) { l1 = z[i]; continue; }
      if (l1 && !l2 && /^\d{6,7}/.test(mrzZiffern(z[i].slice(0, 7)).replace(/</g, '0')) && /\d{6}\d?[MF<X]\d{6}/.test(mrzZiffern(z[i]).replace(/</g, '<'))) { l2 = z[i]; continue; }
      if (l1 && l2 && !l3 && /^[A-Z<]+<<[A-Z<]/.test(z[i])) { l3 = z[i]; continue; }
    }
    if (!l1 && !l2 && !l3) return null;
    if (l1) {
      var num = l1.slice(5, 14), cd = l1.charAt(14);
      erg.land = l1.slice(2, 5).replace(/</g, '');
      erg.nummer = num.replace(/</g, '');
      erg.pruefziffern.nummer = /\d/.test(cd) && mrzPruefziffer(num) === parseInt(cd, 10);
      erg.gelesen = true;
    }
    if (l2) {
      var s = mrzZiffern(l2).replace(/[^0-9MFX<]/g, function (c) { return c; });
      var m = /(\d{6})(\d)[MFX<](\d{6})(\d)/.exec(s);
      if (m) {
        erg.geburt = jahrVon2(parseInt(m[1].slice(0, 2), 10), 'geburt', heute) + '-' + m[1].slice(2, 4) + '-' + m[1].slice(4, 6);
        erg.ablauf = jahrVon2(parseInt(m[3].slice(0, 2), 10), 'ablauf', heute) + '-' + m[3].slice(2, 4) + '-' + m[3].slice(4, 6);
        erg.pruefziffern.geburt = mrzPruefziffer(m[1]) === parseInt(m[2], 10);
        erg.pruefziffern.ablauf = mrzPruefziffer(m[3]) === parseInt(m[4], 10);
        if (!gueltigesDatum(parseInt(erg.geburt.slice(0, 4), 10), parseInt(m[1].slice(2, 4), 10), parseInt(m[1].slice(4, 6), 10))) { erg.geburt = null; erg.pruefziffern.geburt = false; }
        if (!gueltigesDatum(parseInt(erg.ablauf.slice(0, 4), 10), parseInt(m[3].slice(2, 4), 10), parseInt(m[3].slice(4, 6), 10))) { erg.ablauf = null; erg.pruefziffern.ablauf = false; }
        erg.gelesen = true;
      }
    }
    if (l3) {
      var teile = l3.split(/<<+/), nach = teile[0] || '', vor = (teile[1] || '').replace(/<+$/, '');
      /* Hinter dem Namen steht oft Rauschen („RALPH<<<<<<<CECSSS“): nur der Teil bis zur ersten langen Reihe von „<“ zählt */
      vor = vor.split(/<{3,}/)[0];
      erg.nachname = nach.replace(/</g, ' ').trim();
      erg.vorname = vor.replace(/</g, ' ').trim();
      if (erg.nachname) erg.gelesen = true;
    }
    return erg.gelesen ? erg : null;
  }

  /* ---------- Bild: das Dokument auf dem Foto finden ---------- */
  function rgbHSV(r, g, b) {
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
    if (d) { if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
    return { h: h, s: mx ? d / mx : 0, v: mx / 255 };
  }
  function median(a) { var b = a.slice().sort(function (p, q) { return p - q; }); return b[b.length >> 1]; }

  /*
   * bild = { data: RGBA-Bytes, width, height }. Sucht den größten Bereich, der nicht wie der Tisch aussieht (die Tischfarbe wird am Bildrand gemessen).
   * Gibt { x, y, b, h } in Bildpunkten, oder null, wenn nichts Brauchbares gefunden wurde (dann gilt das ganze Bild).
   */
  function dokumentBereich(bild) {
    var W = bild.width, H = bild.height, sc = Math.max(1, Math.floor(Math.max(W, H) / 320)), w = Math.floor(W / sc), h = Math.floor(H / sc);
    if (w < 8 || h < 8) return null;
    var hs = [], x, y, k, i, ra = [], c;
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
      i = ((y * sc) * W + (x * sc)) * 4;
      c = rgbHSV(bild.data[i], bild.data[i + 1], bild.data[i + 2]);
      hs.push(c);
      if (y < 3 || y > h - 4 || x < 3 || x > w - 4) ra.push(c);
    }
    var mh = median(ra.map(function (e) { return e.h; })), ms = median(ra.map(function (e) { return e.s; })), mv = median(ra.map(function (e) { return e.v; }));
    var m = new Uint8Array(w * h), dh;
    for (k = 0; k < w * h; k++) {
      c = hs[k]; dh = Math.abs(c.h - mh); if (dh > 180) dh = 360 - dh;
      m[k] = (dh < 22 && Math.abs(c.s - ms) < 0.22 && Math.abs(c.v - mv) < 0.32) ? 0 : 1;
    }
    var er = new Uint8Array(w * h), di = new Uint8Array(w * h), a, dy, dx;
    for (y = 1; y < h - 1; y++) for (x = 1; x < w - 1; x++) {
      a = 1;
      for (dy = -1; dy <= 1 && a; dy++) for (dx = -1; dx <= 1; dx++) if (!m[(y + dy) * w + x + dx]) { a = 0; break; }
      er[y * w + x] = a;
    }
    for (y = 1; y < h - 1; y++) for (x = 1; x < w - 1; x++) {
      a = 0;
      for (dy = -1; dy <= 1 && !a; dy++) for (dx = -1; dx <= 1; dx++) if (er[(y + dy) * w + x + dx]) { a = 1; break; }
      di[y * w + x] = a;
    }
    var lab = new Int32Array(w * h), best = null, n = 0, s, st, cnt, x0, y0, x1, y1, p, px, py, nb, q, j;
    for (s = 0; s < w * h; s++) {
      if (!di[s] || lab[s]) continue;
      n++; st = [s]; lab[s] = n; cnt = 0; x0 = w; y0 = h; x1 = 0; y1 = 0;
      while (st.length) {
        p = st.pop(); cnt++; px = p % w; py = (p / w) | 0;
        if (px < x0) x0 = px; if (px > x1) x1 = px; if (py < y0) y0 = py; if (py > y1) y1 = py;
        nb = [p - 1, p + 1, p - w, p + w];
        for (j = 0; j < 4; j++) {
          q = nb[j];
          if (q < 0 || q >= w * h) continue;
          if ((j === 0 && px === 0) || (j === 1 && px === w - 1)) continue;
          if (di[q] && !lab[q]) { lab[q] = n; st.push(q); }
        }
      }
      if (!best || cnt > best.cnt) best = { cnt: cnt, x0: x0, y0: y0, x1: x1, y1: y1 };
    }
    if (!best) return null;
    var rx = Math.max(0, (best.x0 - 2) * sc), ry = Math.max(0, (best.y0 - 2) * sc);
    var rb = Math.min(W, (best.x1 + 3) * sc) - rx, rh = Math.min(H, (best.y1 + 3) * sc) - ry;
    var anteil = (rb * rh) / (W * H);
    /* Zu klein (Rauschen) oder fast das ganze Bild (kein Tisch zu sehen): dann lieber das ganze Bild nehmen */
    if (anteil < 0.06 || anteil > 0.94) return null;
    return { x: Math.round(rx), y: Math.round(ry), b: Math.round(rb), h: Math.round(rh), anteil: anteil };
  }

  /* Grau und kontrastreich (die hellsten und dunkelsten 1 Prozent werden abgeschnitten). Ändert die Bytes im Bild. */
  function grauNormal(bild) {
    var d = bild.data, n = bild.width * bild.height, i, g, hist = new Array(256), lo = 0, hi = 255, summe, grenze;
    for (i = 0; i < 256; i++) hist[i] = 0;
    for (i = 0; i < n; i++) { g = Math.round(0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2]); hist[g]++; d[i * 4] = g; }
    grenze = n * 0.01; summe = 0;
    for (lo = 0; lo < 255; lo++) { summe += hist[lo]; if (summe > grenze) break; }
    summe = 0;
    for (hi = 255; hi > 0; hi--) { summe += hist[hi]; if (summe > grenze) break; }
    if (hi - lo < 20) { lo = 0; hi = 255; }
    var f = 255 / (hi - lo), v;
    for (i = 0; i < n; i++) {
      v = (d[i * 4] - lo) * f; v = v < 0 ? 0 : (v > 255 ? 255 : Math.round(v));
      d[i * 4] = v; d[i * 4 + 1] = v; d[i * 4 + 2] = v; d[i * 4 + 3] = 255;
    }
    return bild;
  }

  /* ---------- Seiten aus dem Ergebnis der Texterkennung ---------- */
  function wortBox(b) { return { x0: b.x0, y0: b.y0, x1: b.x1, y1: b.y1 }; }
  /* data = Ergebnis von Tesseract mit „blocks“. versatz: bei einer Hälfte des Fotos die Verschiebung zurück ins ganze Bild. */
  function seiteAusTesseract(data, breite, hoehe, versatz) {
    var zeilen = [], dx = (versatz && versatz.x) || 0, dy = (versatz && versatz.y) || 0, bl, p, l, w, ws;
    var blocks = (data && data.blocks) || [];
    for (bl = 0; bl < blocks.length; bl++) {
      for (p = 0; p < (blocks[bl].paragraphs || []).length; p++) {
        for (l = 0; l < blocks[bl].paragraphs[p].lines.length; l++) {
          var z = blocks[bl].paragraphs[p].lines[l];
          ws = [];
          for (w = 0; w < (z.words || []).length; w++) {
            var wo = z.words[w];
            if (leer(wo.text)) continue;
            ws.push({ t: String(wo.text).trim(), konf: Math.round(wo.confidence), b: { x0: wo.bbox.x0 + dx, y0: wo.bbox.y0 + dy, x1: wo.bbox.x1 + dx, y1: wo.bbox.y1 + dy } });
          }
          if (!ws.length) continue;
          zeilen.push(zeileAus(ws));
        }
      }
    }
    return { breite: breite || 0, hoehe: hoehe || 0, zeilen: zeilen };
  }
  function zeileAus(ws) {
    var x0 = 1e9, y0 = 1e9, x1 = 0, y1 = 0, s = 0, i;
    ws.forEach(function (w) { if (w.b.x0 < x0) x0 = w.b.x0; if (w.b.y0 < y0) y0 = w.b.y0; if (w.b.x1 > x1) x1 = w.b.x1; if (w.b.y1 > y1) y1 = w.b.y1; s += w.konf; });
    return { text: ws.map(function (w) { return w.t; }).join(' '), konf: Math.round(s / ws.length), b: { x0: x0, y0: y0, x1: x1, y1: y1 }, woerter: ws };
  }
  /* Zwei Seiten (zum Beispiel beide Hälften eines Heftes) zu einer: gleiche Zeilen nicht doppelt */
  function seitenVereinen(a, b) {
    var zeilen = a.zeilen.slice();
    b.zeilen.forEach(function (z) {
      var dopp = zeilen.some(function (y) { return normal(y.text) === normal(z.text) || (ueberlappt(y.b, z.b) > 0.6 && normal(y.text).indexOf(normal(z.text)) >= 0); });
      if (!dopp) zeilen.push(z);
    });
    return { breite: Math.max(a.breite, b.breite), hoehe: Math.max(a.hoehe, b.hoehe), zeilen: zeilen };
  }
  function ueberlappt(a, b) {
    var x = Math.max(0, Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0)), y = Math.max(0, Math.min(a.y1, b.y1) - Math.max(a.y0, b.y0));
    var fl = Math.min((a.x1 - a.x0) * (a.y1 - a.y0), (b.x1 - b.x0) * (b.y1 - b.y0));
    return fl > 0 ? (x * y) / fl : 0;
  }
  function seitenText(seite) { return seite.zeilen.map(function (z) { return z.text; }).join('\n'); }
  function nachOben(seite) { return seite.zeilen.slice().sort(function (a, b) { return (a.b.y0 + a.b.y1) / 2 - (b.b.y0 + b.b.y1) / 2 || a.b.x0 - b.b.x0; }); }
  function hoeheVon(z) { return Math.max(1, z.b.y1 - z.b.y0); }
  function zeilenHoeheMedian(seite) { return median(seite.zeilen.map(hoeheVon).concat([20])); }
  /* Mitte einer Zeile senkrecht */
  function mitteY(z) { return (z.b.y0 + z.b.y1) / 2; }

  /* ---------- Bausteine zum Lesen nach Bedeutung ---------- */
  function kandidat(wert, konf, quelle, ok, hinweis) { return { wert: wert, konf: Math.max(0, Math.min(100, Math.round(konf))), quelle: quelle, ok: ok !== false, hinweis: hinweis || '' }; }

  /* Wörter einer Zeile ab einer Stelle im Zeilentext, bis eine große Lücke kommt (dann steht rechts etwas anderes) */
  function woerterAb(zeile, ab, lueckenFaktor) {
    var pos = 0, i, w, startIdx = -1, erg = [], zeichenBreite, vorher = null;
    var ws = zeile.woerter, text = '';
    for (i = 0; i < ws.length; i++) {
      ws[i]._von = text.length; text += (i ? ' ' : '') + ws[i].t; if (i) ws[i]._von = text.length - ws[i].t.length; ws[i]._bis = text.length;
    }
    zeichenBreite = (zeile.b.x1 - zeile.b.x0) / Math.max(1, text.length);
    for (i = 0; i < ws.length; i++) { if (ws[i]._bis > ab) { startIdx = i; break; } }
    if (startIdx < 0) return { text: '', konf: 0 };
    var summe = 0;
    for (i = startIdx; i < ws.length; i++) {
      w = ws[i];
      if (vorher && (w.b.x0 - vorher.b.x1) > zeichenBreite * (lueckenFaktor || 3.2)) break;
      erg.push(w); summe += w.konf; vorher = w;
    }
    /* beginnt das erste Wort schon vor „ab“ (Marke klebt am Wert), nur den Rest nehmen */
    var t = erg.map(function (e) { return e.t; }).join(' ');
    if (erg.length && erg[0]._von < ab) t = t.slice(ab - erg[0]._von);
    return { text: t, konf: erg.length ? summe / erg.length : 0, wortbox: erg.length ? { x0: erg[0].b.x0, x1: erg[erg.length - 1].b.x1, y0: zeile.b.y0, y1: zeile.b.y1 } : null };
  }

  function zeileText(z) { return z.woerter.map(function (w) { return w.t; }).join(' '); }

  /* Rechts neben einer Beschriftung (gleiche Zeile). labelRe wird auf den Zeilentext angewendet. */
  function wertRechts(seite, labelRe, opt) {
    var i, z, m, r;
    opt = opt || {};
    for (i = 0; i < seite.zeilen.length; i++) {
      z = seite.zeilen[i]; m = labelRe.exec(zeileText(z));
      if (!m) continue;
      r = woerterAb(z, m.index + m[0].length, opt.lueckenFaktor);
      var t = saeubern(r.text).replace(/^[:.,;\-–\s]+/, '');
      if (t.length >= (opt.min || 2)) return { text: t, konf: Math.min(z.konf, r.konf), zeile: z };
    }
    return null;
  }
  /* Unter einer Beschriftung: die nächste Zeile darunter, die ähnlich weit links beginnt */
  function wertUnter(seite, labelRe, opt) {
    var i, j, z, d, hz, y, kand, best, sorted = nachOben(seite);
    opt = opt || {};
    for (i = 0; i < sorted.length; i++) {
      z = sorted[i];
      if (!labelRe.test(zeileText(z))) continue;
      hz = hoeheVon(z); best = null;
      for (j = i + 1; j < sorted.length; j++) {
        d = sorted[j];
        if (mitteY(d) - z.b.y1 > hz * (opt.maxAbstand || 3.2)) break;
        if (mitteY(d) <= mitteY(z)) continue;
        if (d.b.x0 > z.b.x1 || d.b.x1 < z.b.x0) continue;
        if (opt.nur && !opt.nur.test(zeileText(d))) continue;
        if (opt.nicht && opt.nicht.test(zeileText(d))) continue;
        if (saeubern(zeileText(d)).length < (opt.min || 2)) continue;
        best = d; break;
      }
      if (best) return { text: saeubern(zeileText(best)), konf: best.konf, zeile: best };
    }
    return null;
  }
  /* Über einer Beschriftung (Formular mit Strich: der Wert steht auf dem Strich darüber) */
  function wertUeber(seite, labelRe, opt) {
    var i, j, z, d, hz, sorted = nachOben(seite);
    opt = opt || {};
    for (i = 0; i < sorted.length; i++) {
      z = sorted[i];
      if (!labelRe.test(zeileText(z))) continue;
      hz = hoeheVon(z);
      for (j = i - 1; j >= 0; j--) {
        d = sorted[j];
        if (z.b.y0 - mitteY(d) > hz * (opt.maxAbstand || 3.4)) break;
        if (d.b.x1 < z.b.x0 - (z.b.x1 - z.b.x0) || d.b.x0 > z.b.x1 + (z.b.x1 - z.b.x0)) continue;
        if (opt.nur && !opt.nur.test(zeileText(d))) continue;
        if (opt.nicht && opt.nicht.test(zeileText(d))) continue;
        if (saeubern(zeileText(d)).length < (opt.min || 2)) continue;
        return { text: saeubern(zeileText(d)), konf: d.konf, zeile: d };
      }
    }
    return null;
  }

  /* Nummerierte Felder nach dem EU-Muster („1. Name“, „4a. Datum“, „D.1 Marke“): Feldnummer, dann der Wert bis zur nächsten Feldnummer.
     codes: erlaubte Feldnummern (Text). Gibt { code: { text, konf } }. */
  function marken(seite, codes, opt) {
    opt = opt || {};
    var erg = {}, sorted = nachOben(seite), li, z, t, re, m, treffer, k, last, sub, zusatz;
    var erlaubt = {}; codes.forEach(function (c) { erlaubt[c.toLowerCase()] = c; });
    var codeMuster = opt.codeMuster || '\\d{1,2}[abc]?';
    for (li = 0; li < sorted.length; li++) {
      z = sorted[li]; t = zeileText(z); treffer = [];
      re = new RegExp('(^|\\s)(' + codeMuster + ')' + (opt.codeOhnePunkt ? '(?:\\s?[.,:]\\s?|\\s+)' : '\\s?[.,:]\\s?'), 'gi');
      while ((m = re.exec(t))) {
        var code = m[2].toLowerCase();
        if (!erlaubt[code]) { re.lastIndex = m.index + m[1].length + 1; continue; }
        /* „3.10.07.70“: gehört das „3.“ wirklich dazu? Ja, solange 3 erlaubt ist. */
        treffer.push({ code: erlaubt[code], start: m.index + m[1].length, ende: m.index + m[0].length });
        re.lastIndex = m.index + m[0].length;
      }
      for (k = 0; k < treffer.length; k++) {
        var bis = k + 1 < treffer.length ? treffer[k + 1].start : t.length;
        var teil = woerterAb(z, treffer[k].ende, opt.lueckenFaktor || 4.5);
        var txt = t.slice(treffer[k].ende, bis);
        if (k + 1 >= treffer.length) txt = teil.text; else if (txt.length > teil.text.length && teil.text.length) txt = txt.slice(0, teil.text.length + 0);
        txt = saeubern(k + 1 < treffer.length ? t.slice(treffer[k].ende, bis) : teil.text);
        if (opt.mehrzeilig && opt.mehrzeilig.indexOf(treffer[k].code) >= 0 && k + 1 >= treffer.length) {
          var nxt = sorted[li + 1];
          if (nxt && mitteY(nxt) - z.b.y1 < hoeheVon(z) * 1.6 && nxt.b.x0 >= z.b.x0 - 5 && !/(^|\s)\d{1,2}[abc]?\s?[.,:]/.test(zeileText(nxt))) {
            zusatz = saeubern(zeileText(nxt)).replace(/[.\s]+$/, '');
            if (zusatz.length >= 3) txt = (txt + ' ' + zusatz).trim();
          }
        }
        if (txt && (!erg[treffer[k].code] || erg[treffer[k].code].text.length < txt.length)) erg[treffer[k].code] = { text: txt, konf: Math.min(z.konf, teil.konf || z.konf) };
      }
    }
    return erg;
  }

  /* ---------- Dokumentarten: Erkennung und Lesen ---------- */
  function kleinText(seite) { return normalText(seitenText(seite)); }
  function normalText(s) {
    var t = String(s || ''), r = '', i, c;
    for (i = 0; i < t.length; i++) { c = t.charAt(i); r += UMLAUTE[c] !== undefined ? UMLAUTE[c] : c; }
    return r.toLowerCase();
  }

  function ziffernAnteil(s) { var d = String(s).replace(/[^0-9]/g, '').length; return d / Math.max(1, String(s).length); }
  function nurName(s) {
    /* Name: Buchstaben, Bindestrich, Leerzeichen, Punkt; Rauschen am Ende („Ralph.“, „Ralph En“) abschneiden */
    var t = saeubern(s).replace(/[0-9]+/g, ' ').replace(/[^A-Za-zÄÖÜäöüß\-' .]/g, ' ').replace(/\s+/g, ' ').trim();
    t = t.replace(/[.\-' ]+$/, '').replace(/^[^A-Za-zÄÖÜäöüß]+/, '');
    /* Kurze Reste (1 bis 2 Buchstaben, Rauschen vom Rand) fallen weg, solange noch ein richtiges Wort übrig bleibt */
    var teile = t.split(' '), lang = teile.filter(function (x) { return x.replace(/[^A-Za-zÄÖÜäöüß]/g, '').length >= 3; });
    if (lang.length && lang.length < teile.length) t = lang.join(' ');
    return t;
  }
  function ersteGrossgeschrieben(s) {
    return String(s).replace(/(^|[\s\-'])([A-Za-zÄÖÜäöüß])([A-Za-zÄÖÜäöüß]*)/g, function (all, pre, a, rest) { return pre + a.toUpperCase() + rest.toLowerCase(); });
  }
  function nameZeigen(s) {
    var t = nurName(s);
    return /[a-zäöü]/.test(t) ? t : ersteGrossgeschrieben(t);
  }

  /* Datum aus einem Text als Kandidat */
  function datumKandidat(text, konf, quelle, art, heute, hinweis) {
    var d = datumLesen(text, art, heute);
    if (!d) return null;
    if (!d.iso) return kandidat(d.roh || text, Math.min(konf, 40), quelle, false, 'Kein gültiges Datum gelesen.');
    return kandidat(d.iso, d.korrigiert ? Math.min(konf, 55) : konf, quelle, true, d.korrigiert ? 'Eine Ziffer war nicht sicher gelesen und wurde angepasst. Bitte prüfen.' : (hinweis || ''));
  }

  /* Welche Angaben jeder Dokumentart. rolle = Name der Angabe in MobiMory, papier = Nummer oder Beschriftung auf dem Papier (wie in nachweis-vorschlaege.js).
     person: Angabe gehört zur Identität der Person (Name, Vorname, Geburtsdatum, Geburtsort). */
  function A(rolle, label, typ, papier, person) { return { rolle: rolle, label: label, typ: typ || 'text', papier: papier || '', person: !!person }; }
  var PERSON = [A('nachname', 'Name', 'text', '', true), A('vorname', 'Vorname', 'text', '', true), A('geburtsdatum', 'Geburtsdatum', 'datum', '', true), A('geburtsort', 'Geburtsort', 'text', '', true)];

  function einsKandidat(map, rolle, k) { if (!k) return; (map[rolle] = map[rolle] || []).push(k); }

  var ARTEN = {};

  /* ----- Personalausweis ----- */
  ARTEN.DE_PAUSWG_PERSONALAUSWEIS = {
    name: 'Personalausweis', gehoertZu: 'person', seitenFuerScan: 2,
    erkennung: [[/personalausweis/, 6], [/identity card/, 3], [/carte d.?identit/, 3], [/idd<</, 6], [/given names/, 2], [/vornamen/, 1], [/staatsangeh/, 1], [/geburtsort/, 1], [/place of birth/, 1], [/bundesrepublik deutschland/, 1]],
    angaben: PERSON.concat([A('nummer', 'Ausweisnummer', 'text'), A('aussteller', 'Behörde', 'text'), A('gueltigBis', 'Gültig bis', 'datum')]),
    lesen: function (seite, ctx) {
      var k = {}, texte = seite.zeilen.map(function (z) { return zeileText(z); }), mrz = mrzLesen(texte, ctx.heute), t;
      if (mrz) {
        if (mrz.nachname) einsKandidat(k, 'nachname', kandidat(ersteGrossgeschrieben(mrz.nachname), 80, 'mrz', true, 'Aus der Maschinenzeile (dort steht ß als „SS“).'));
        if (mrz.vorname) einsKandidat(k, 'vorname', kandidat(ersteGrossgeschrieben(mrz.vorname), 80, 'mrz', true, 'Aus der Maschinenzeile.'));
        if (mrz.geburt) einsKandidat(k, 'geburtsdatum', kandidat(mrz.geburt, mrz.pruefziffern.geburt ? 97 : 45, 'mrz', !!mrz.pruefziffern.geburt, mrz.pruefziffern.geburt ? 'Prüfziffer der Maschinenzeile stimmt.' : 'Prüfziffer der Maschinenzeile stimmt nicht.'));
        if (mrz.ablauf) einsKandidat(k, 'gueltigBis', kandidat(mrz.ablauf, mrz.pruefziffern.ablauf ? 97 : 45, 'mrz', !!mrz.pruefziffern.ablauf, mrz.pruefziffern.ablauf ? 'Prüfziffer der Maschinenzeile stimmt.' : 'Prüfziffer der Maschinenzeile stimmt nicht.'));
        if (mrz.nummer && mrz.nummer.length === 9) einsKandidat(k, 'nummer', kandidat(mrz.nummer, mrz.pruefziffern.nummer ? 97 : 40, 'mrz', !!mrz.pruefziffern.nummer, mrz.pruefziffern.nummer ? 'Prüfziffer der Maschinenzeile stimmt.' : 'Prüfziffer der Maschinenzeile stimmt nicht.'));
      }
      /* Vorderseite: Wert unter der Beschriftung (Vornamen, Geburtsort), der Nachname steht über „Vornamen“ */
      t = wertUnter(seite, /vornamen|given\s*names|pr[eé]noms/i, { nicht: /geburt|birth|naissance/i });
      if (t && nurName(t.text).length >= 2) einsKandidat(k, 'vorname', kandidat(nameZeigen(t.text), t.konf, 'beschriftung'));
      t = wertUeber(seite, /vornamen|given\s*names|pr[eé]noms/i, { nicht: /bundesrepublik|identity|republic|republique|name\/|surname|nom\b/i, nur: /[A-ZÄÖÜß]{3,}/ });
      if (t && nurName(t.text).length >= 3) einsKandidat(k, 'nachname', kandidat(nameZeigen(t.text), t.konf, 'beschriftung'));
      t = wertUnter(seite, /geburtsort|place\s*of\s*birth|lieu\s*de\s*naissance/i, { min: 3, nicht: /geburtsort|place\s*of\s*birth|lieu\s*de|naissance|staatsangeh|nationality|datum|date/i });
      if (t && /[A-Za-zÄÖÜäöüß]{4}/.test(nurName(t.text))) einsKandidat(k, 'geburtsort', kandidat(nameZeigen(t.text), t.konf, 'beschriftung'));
      var daten = [];
      seite.zeilen.forEach(function (z) { datenInText(zeileText(z), 'geburt', ctx.heute).forEach(function (d) { if (d.iso && /\d{4}$/.test(d.roh.replace(/\s/g, ''))) daten.push({ d: d, z: z }); }); });
      if (daten.length) {
        daten.sort(function (a, b) { return a.d.iso < b.d.iso ? -1 : 1; });
        einsKandidat(k, 'geburtsdatum', kandidat(daten[0].d.iso, daten[0].z.konf, 'muster', true, 'Das früheste Datum auf der Seite.'));
        if (daten.length > 1) einsKandidat(k, 'gueltigBis', kandidat(daten[daten.length - 1].d.iso, daten[daten.length - 1].z.konf, 'muster', true, 'Das späteste Datum auf der Seite.'));
      }
      return k;
    },
    pruefen: function (w, ctx) {
      var h = [];
      if (w.geburtsdatum && w.gueltigBis && w.gueltigBis <= w.geburtsdatum) h.push({ rolle: 'gueltigBis', text: 'Das Ablaufdatum liegt vor dem Geburtsdatum.' });
      return h;
    }
  };

  /* ----- Führerschein (EU-Karte), Vorderseite nach Anlage 8 FeV ----- */
  ARTEN.DE_FEV_FUEHRERSCHEIN_EU = {
    name: 'Führerschein', gehoertZu: 'person',
    erkennung: [[/(^|[^a-z])fuehrerschein/, 5], [/driving licen[cs]e|permis de conduire/, 3], [/(^|\W)am\/a1\/a(\/|\W)/, 3], [/\b4a\b.*\b4b\b/, 1], [/landratsamt|stadt|kreis|regierungspr/, 1]],
    angaben: [A('nachname', 'Name', 'text', '1', true), A('vorname', 'Vorname', 'text', '2', true), A('geburtsdatum', 'Geburtsdatum', 'datum', '3', true), A('geburtsort', 'Geburtsort', 'text', '3', true),
      A('ausgestelltAm', 'Ausstellungsdatum', 'datum', '4a'), A('gueltigBis', 'Ablaufdatum des Dokuments', 'datum', '4b'), A('aussteller', 'Ausstellungsbehörde', 'text', '4c'),
      A('nummer', 'Führerscheinnummer', 'text', '5'), A('klassen', 'Fahrerlaubnisklassen', 'text', '9')],
    lesen: function (seite, ctx) {
      var k = {}, m = marken(seite, ['1', '2', '3', '4', '4a', '4b', '4c', '5', '7', '9'], { mehrzeilig: ['4c'], lueckenFaktor: 5 }), c, d, hinweisDatum;
      var vierA = m['4a'] || null, vierB = m['4b'] || null, vier = m['4'] || null;
      if (vier && !vierA) vierA = vier; else if (vier && !vierB) vierB = vier;
      if (m['1']) einsKandidat(k, 'nachname', kandidat(nameZeigen(m['1'].text), m['1'].konf, 'marke'));
      if (m['2']) einsKandidat(k, 'vorname', kandidat(nameZeigen(m['2'].text), m['2'].konf, 'marke'));
      if (m['3']) {
        d = datumKandidat(m['3'].text, m['3'].konf, 'marke', 'geburt', ctx.heute);
        if (d) einsKandidat(k, 'geburtsdatum', d);
        var ort = nurName(m['3'].text.replace(/\d{1,2}\s*[.,]\s*\d{1,2}\s*[.,]\s*\d{2,4}/, ' '));
        if (ort.length >= 3) einsKandidat(k, 'geburtsort', kandidat(nameZeigen(ort), m['3'].konf, 'marke'));
      }
      if (vierA) { d = datumKandidat(vierA.text, vierA.konf, 'marke', 'ausgestellt', ctx.heute); if (d) einsKandidat(k, 'ausgestelltAm', d); }
      if (vierB) { d = datumKandidat(vierB.text, vierB.konf, 'marke', 'ablauf', ctx.heute); if (d) einsKandidat(k, 'gueltigBis', d); }
      if (m['4c']) einsKandidat(k, 'aussteller', kandidat(saeubern(m['4c'].text), m['4c'].konf, 'marke'));
      if (m['5']) {
        var nr = m['5'].text.replace(/\s+/g, '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
        if (nr.length >= 8) einsKandidat(k, 'nummer', kandidat(nr, m['5'].konf, 'marke', /^[A-Z0-9]{9,12}$/.test(nr), /^[A-Z0-9]{9,12}$/.test(nr) ? '' : 'Das sieht nicht wie eine Führerscheinnummer aus.'));
      }
      if (m['9']) {
        var kl = m['9'].text.replace(/\s+/g, '').toUpperCase();
        if (/^[A-Z0-9]{1,3}(\/[A-Z0-9]{1,3})+$/.test(kl) || kl.length >= 2) einsKandidat(k, 'klassen', kandidat(kl, m['9'].konf, 'marke'));
      } else {
        var z9 = null; seite.zeilen.forEach(function (z) { if (!z9 && /AM\s*\/\s*A1\s*\/\s*A/.test(zeileText(z))) z9 = z; });
        if (z9) { var mm = /(AM\s*\/[A-Z0-9\/\s]+)/.exec(zeileText(z9)); if (mm) einsKandidat(k, 'klassen', kandidat(mm[1].replace(/\s+/g, ''), z9.konf, 'muster')); }
      }
      /* Nach Bedeutung, wenn eine Feldnummer nicht gelesen wurde: alle Daten der Seite sortieren. Das früheste ist die Geburt,
         das nächste die Ausstellung, das späteste der Ablauf. */
      var roh = [];
      nachOben(seite).forEach(function (z) { datenInText(zeileText(z), 'ausgestellt', ctx.heute).forEach(function (x) { roh.push({ text: x.roh, konf: z.konf }); }); });
      function alsDatum(i, art) { var dd = roh[i] ? datumLesen(roh[i].text, art, ctx.heute) : null; return dd && dd.iso ? { iso: dd.iso, konf: roh[i].konf } : null; }
      if (roh.length >= 3) {
        var g0 = alsDatum(0, 'geburt'), a1 = alsDatum(1, 'ausgestellt'), b2 = alsDatum(roh.length - 1, 'ablauf');
        if (!k.geburtsdatum && g0) einsKandidat(k, 'geburtsdatum', kandidat(g0.iso, g0.konf, 'muster', true, 'Das erste Datum auf der Karte.'));
        if (!k.ausgestelltAm && a1) einsKandidat(k, 'ausgestelltAm', kandidat(a1.iso, a1.konf, 'muster', true, 'Das zweite Datum auf der Karte.'));
        if (!k.gueltigBis && b2) einsKandidat(k, 'gueltigBis', kandidat(b2.iso, b2.konf, 'muster', true, 'Das letzte Datum auf der Karte.'));
      } else if (roh.length && !k.geburtsdatum) {
        var g1 = alsDatum(0, 'geburt'); if (g1) einsKandidat(k, 'geburtsdatum', kandidat(g1.iso, g1.konf, 'muster', true, 'Das erste Datum auf der Karte.'));
      }
      return k;
    },
    pruefen: function (w, ctx) {
      var h = [];
      if (w.ausgestelltAm && w.gueltigBis) {
        var a = parseInt(w.ausgestelltAm.slice(0, 4), 10), b = parseInt(w.gueltigBis.slice(0, 4), 10);
        if (w.gueltigBis <= w.ausgestelltAm) h.push({ rolle: 'gueltigBis', text: 'Das Ablaufdatum liegt nicht nach dem Ausstellungsdatum.' });
        else if (b - a !== 15 && b - a !== 14) h.push({ rolle: 'gueltigBis', text: 'Bei Karten-Führerscheinen liegt das Ablaufdatum 15 Jahre nach der Ausstellung. Bitte prüfen.', hell: true });
      }
      return h;
    }
  };

  /* ----- Sportbootführerschein im Kartenformat (International Certificate for Operators of Pleasure Craft) ----- */
  ARTEN.DE_SPFV_SBF = {
    name: 'Sportbootführerschein', gehoertZu: 'person',
    erkennung: [[/sportbootfuehrerschein/, 6], [/pleasure craft/, 4], [/certificat international de conducteur|certificado internacional/, 3], [/(^|\W)iwm(\W|$)|(^|\W)cwm(\W|$)/, 2]],
    angaben: [A('nachname', 'Name', 'text', '1', true), A('vorname', 'Vorname', 'text', '2', true), A('geburtsdatum', 'Geburtsdatum', 'datum', '3', true), A('geburtsort', 'Geburtsort', 'text', '3', true),
      A('ausgestelltAm', 'Datum der Ausfertigung', 'datum', '4'), A('nummer', 'Zertifikatsnummer', 'text', '5'), A('klassen', 'Geltungsbereich (Binnen, See)', 'text', '10'),
      A('aussteller', 'Ausgestellt durch', 'text', '13')],
    lesen: function (seite, ctx) {
      var k = {}, m = marken(seite, ['1', '2', '3', '4', '5', '6', '10', '11', '13', '14', '15'], { lueckenFaktor: 5, codeMuster: '\\d{1,2}' }), d;
      if (m['1']) einsKandidat(k, 'nachname', kandidat(nameZeigen(m['1'].text), m['1'].konf, 'marke'));
      if (!m['1']) {
        var so = nachOben(seite), ix;
        for (ix = 0; ix < so.length; ix++) { if (/(^|\s)2\s?[.,:]/.test(zeileText(so[ix]))) break; }
        if (ix > 0 && ix < so.length) { var vz = so[ix - 1], w1 = nameZeigen(zeileText(vz).replace(/^\s*1\s?[.,:]?\s*/, '').split(/\s+/)[0] || ''); if (w1.length >= 3) einsKandidat(k, 'nachname', kandidat(w1, Math.min(vz.konf, 60), 'beschriftung', true, 'Nummer „1.“ nicht gelesen, Zeile über „2.“ genommen.')); }
      }
      if (m['2']) einsKandidat(k, 'vorname', kandidat(nameZeigen(m['2'].text), m['2'].konf, 'marke'));
      if (m['3']) {
        d = datumKandidat(m['3'].text, m['3'].konf, 'marke', 'geburt', ctx.heute); if (d) einsKandidat(k, 'geburtsdatum', d);
        var ort = nurName(m['3'].text.replace(/\d{1,2}\s*[.,]\s*\d{1,2}\s*[.,]\s*\d{2,4}/, ' '));
        if (ort.length >= 3) einsKandidat(k, 'geburtsort', kandidat(nameZeigen(ort), m['3'].konf, 'marke'));
      }
      if (m['4']) { d = datumKandidat(m['4'].text, m['4'].konf, 'marke', 'ausgestellt', ctx.heute); if (d) einsKandidat(k, 'ausgestelltAm', d); }
      if (m['10']) {
        /* „IWM 31.05.86 CWM 19.11.92“: Binnen und See, jeweils mit Datum der Erteilung */
        var t10 = saeubern(m['10'].text);
        if (/[A-Z]{2,3}/.test(t10)) einsKandidat(k, 'klassen', kandidat(t10, m['10'].konf, 'marke'));
      }
      if (m['13']) einsKandidat(k, 'aussteller', kandidat(saeubern(m['13'].text), m['13'].konf, 'marke'));
      /* Die Nummer steht unten mit „s.“ davor: „s.M000472641“ */
      var nummer = null;
      seite.zeilen.forEach(function (z) {
        var mm = /(?:^|\s)[sS5]\s?[.,]\s?([A-Z]\s?[0-9O]{6,10})/.exec(zeileText(z));
        if (mm && !nummer) nummer = { t: mm[1].replace(/\s/g, '').replace(/O/g, '0'), konf: z.konf };
      });
      if (!nummer) seite.zeilen.forEach(function (z) {
        var mm = /\b(M[0-9O]{8,10})\b/.exec(zeileText(z));
        if (mm && !nummer) nummer = { t: mm[1].replace(/O/g, '0'), konf: z.konf };
      });
      if (nummer) einsKandidat(k, 'nummer', kandidat(nummer.t, nummer.konf, 'muster', /^[A-Z]\d{8,9}$/.test(nummer.t), /^[A-Z]\d{8,9}$/.test(nummer.t) ? '' : 'Die Nummer sieht ungewöhnlich aus.'));
      return k;
    },
    pruefen: function () { return []; }
  };

  /* ----- UKW-Sprechfunkzeugnis für den Binnenschifffahrtsfunk (UBI) ----- */
  ARTEN.DE_UBI = {
    name: 'Funkzeugnis UBI', gehoertZu: 'person',
    erkennung: [[/ukw-sprechfunkzeugnis/, 6], [/binnenschifffahrtsfunk|binnenschiffahrtsfunk/, 4], [/radiotelephone operator/, 3], [/\(ubi\)/, 3], [/besondere vermerke/, 3], [/deutscher segler|motoryachtverband/, 2]],
    angaben: PERSON.concat([A('nummer', 'Nummer', 'text', 'Nr.'), A('aussteller', 'Ausgestellt durch', 'text', '')]),
    lesen: function (seite, ctx) {
      var k = {}, t, d;
      seite.zeilen.forEach(function (z) {
        var mm = /\bNr\.?\s*[:.]?\s*(\d{3,8})\s*[-–—]?\s*([A-Z])?\b/.exec(zeileText(z));
        if (mm && !k.nummer) einsKandidat(k, 'nummer', kandidat(mm[1] + (mm[2] ? '-' + mm[2] : ''), z.konf, 'muster'));
      });
      t = wertUeber(seite, /^\s*Name\s*$|^\s*Name\b(?!\w)/i, { nur: /[A-Za-zÄÖÜäöüß]{3,}/, nicht: /surname|inhabers|signature|unterschrift/i });
      if (t) einsKandidat(k, 'nachname', kandidat(nameZeigen(t.text), t.konf, 'beschriftung'));
      t = wertUeber(seite, /^\s*Vornamen\b/i, { nur: /[A-Za-zÄÖÜäöüß]{2,}/ });
      if (t) einsKandidat(k, 'vorname', kandidat(nameZeigen(t.text), t.konf, 'beschriftung'));
      t = wertUeber(seite, /^\s*Geburtsdatum\b/i, { maxAbstand: 4 });
      if (t) { d = datumKandidat(t.text, t.konf, 'beschriftung', 'geburt', ctx.heute); if (d) einsKandidat(k, 'geburtsdatum', d); }
      t = wertUeber(seite, /^\s*Geburtsort\b/i, { nur: /[A-Za-zÄÖÜäöüß]{3,}/ });
      if (t) einsKandidat(k, 'geburtsort', kandidat(nameZeigen(t.text), t.konf, 'beschriftung'));
      t = wertUeber(seite, /Ort\s+und\s+Datum\s+der\s+Ausstellung/i, { nur: /[A-Za-zÄÖÜäöüß]{3,}/, maxAbstand: 4 });
      if (t) {
        var dd = datenInText(t.text, 'ausgestellt', ctx.heute);
        if (dd.length && dd[0].iso) einsKandidat(k, 'ausgestelltAm', kandidat(dd[0].iso, t.konf, 'beschriftung'));
      }
      return k;
    },
    pruefen: function () { return []; }
  };
  ARTEN.DE_UBI.angaben = ARTEN.DE_UBI.angaben.concat([A('ausgestelltAm', 'Ausstellungsdatum', 'datum', '')]);

  /* ----- Fachkundenachweis nach dem Sprengstoffrecht (Signalmittel), Heft des DMYV ----- */
  ARTEN.DE_SPRENGG_FACHKUNDE = {
    name: 'Fachkundenachweis Sprengstoffrecht (Signalmittel)', gehoertZu: 'person',
    erkennung: [[/fachkundenachweis/, 5], [/sprengstoffrecht|sprengstoff/, 4], [/(^|\W)spreng(g|v)(\W|$)/, 4], [/signalmittel/, 3], [/befaehigungsnachweis/, 2]],
    angaben: PERSON.concat([A('nummer', 'Nummer', 'text', 'Nr.'), A('aussteller', 'Ausgestellt durch', 'text', ''), A('ausgestelltAm', 'Ausstellungsdatum', 'datum', '')]),
    lesen: function (seite, ctx) {
      var k = {}, t, d, mm;
      seite.zeilen.forEach(function (z) {
        mm = /\bNr\.?\s*[:.]?\s*(\d{3,8})\b/.exec(zeileText(z));
        if (mm && !k.nummer && !/Befähigungs|Nummer des/i.test(zeileText(z))) einsKandidat(k, 'nummer', kandidat(mm[1], z.konf, 'muster'));
      });
      /* Innenseite: Ort und Datum der Ausstellung, zum Beispiel „Duisburg, 25.04.2023“ */
      seite.zeilen.forEach(function (z) {
        var s = zeileText(z);
        mm = /([A-ZÄÖÜ][a-zäöüß]+)\s*,\s*(\d{1,2}\s*[.,]\s*\d{1,2}\s*[.,]\s*\d{4})/.exec(s);
        if (mm && !k.ausgestelltAm) { d = datumKandidat(mm[2], z.konf, 'muster', 'ausgestellt', ctx.heute); if (d) einsKandidat(k, 'ausgestelltAm', d); }
      });
      t = wertUeber(seite, /Vor-?\s*und\s*Zuname/i, { nur: /[A-Za-zÄÖÜäöüß]{3,}/ });
      if (t) {
        var teile = nurName(t.text).split(/\s+/).filter(function (x) { return x.length > 1; });
        if (teile.length >= 2) {
          einsKandidat(k, 'vorname', kandidat(nameZeigen(teile[0]), t.konf, 'beschriftung'));
          einsKandidat(k, 'nachname', kandidat(nameZeigen(teile.slice(1).join(' ')), t.konf, 'beschriftung'));
        }
      }
      t = wertUeber(seite, /Geburtsland\s+und\s*-?\s*ort/i, { nur: /[A-Za-zÄÖÜäöüß]{3,}/ });
      if (t) {
        var o = nurName(t.text).replace(/^.*\//, '').trim();
        if (o.length >= 3) einsKandidat(k, 'geburtsort', kandidat(nameZeigen(o), t.konf, 'beschriftung'));
      }
      t = wertUeber(seite, /^\s*Geburtsdatum\b/i, { maxAbstand: 4 });
      if (t) { d = datumKandidat(t.text, t.konf, 'beschriftung', 'geburt', ctx.heute); if (d) einsKandidat(k, 'geburtsdatum', d); }
      seite.zeilen.forEach(function (z) {
        mm = /\b(M[0-9O]{8,10})\b/.exec(zeileText(z));
        if (mm && !k.nummer) einsKandidat(k, 'nummer', kandidat(mm[1].replace(/O/g, '0'), z.konf, 'muster', true, 'Nummer des Befähigungsnachweises (SBF).'));
      });
      t = wertRechts(seite, /^\s*DMY[VY]\s*-?\s*/i, { min: 2 });
      var aus = null; seite.zeilen.forEach(function (z) { if (!aus && /DMY[VY]\s*-?\s*Zentrale/i.test(zeileText(z))) aus = z; });
      if (aus) einsKandidat(k, 'aussteller', kandidat('DMYV-Zentrale', aus.konf, 'muster'));
      return k;
    },
    pruefen: function () { return []; }
  };

  /* ----- Bodensee-Schifferpatent ----- */
  ARTEN.DE_BODENSEE_SCHIFFERPATENT = {
    name: 'Bodensee-Schifferpatent', gehoertZu: 'person',
    erkennung: [[/schifferpatent/, 6], [/bodensee/, 3], [/bodenseekreis/, 2], [/bodensee-schifffahrtsordnung|schifffahrtsordnung/, 3], [/patent nr/, 4], [/kategorie/, 1]],
    angaben: PERSON.concat([A('nummer', 'Patent-Nummer', 'text', 'Patent Nr.'), A('klassen', 'Kategorie', 'text', 'Kategorie'), A('aussteller', 'Ausgestellt durch', 'text', ''), A('ausgestelltAm', 'Ausstellungsdatum', 'datum', ''), A('gueltigBis', 'Gültig bis', 'datum', '')]),
    lesen: function (seite, ctx) {
      var k = {}, t, d;
      t = wertRechts(seite, /(^|\s)Name\s+(?=[A-ZÄÖÜ])/, { min: 3 });
      if (!t) { var nz = null; seite.zeilen.forEach(function (z) { var m = /^\s*Name\s+(\S+)/.exec(zeileText(z)); if (m && !nz) nz = { text: m[1], konf: z.konf }; }); t = nz; }
      if (t) einsKandidat(k, 'nachname', kandidat(nameZeigen(t.text), t.konf, 'beschriftung'));
      t = wertRechts(seite, /Vorname[n]?\s+/i, { min: 2 });
      if (t) einsKandidat(k, 'vorname', kandidat(nameZeigen(t.text), t.konf, 'beschriftung'));
      t = wertRechts(seite, /Geburtstag\s+/i, { min: 6 });
      if (t) { d = datumKandidat(t.text, t.konf, 'beschriftung', 'geburt', ctx.heute); if (d) einsKandidat(k, 'geburtsdatum', d); }
      t = wertRechts(seite, /Geburtsort\s+/i, { min: 3 });
      if (t) einsKandidat(k, 'geburtsort', kandidat(nameZeigen(t.text), t.konf, 'beschriftung'));
      seite.zeilen.forEach(function (z) {
        var s = zeileText(z), mm = /\b(\d{6,8})\b/.exec(s);
        if (mm && !k.nummer && (/Patent\s*Nr/i.test(s) || (z.woerter.length === 1 && /^\d{6,8}$/.test(z.woerter[0].t)))) einsKandidat(k, 'nummer', kandidat(mm[1], z.konf, 'muster', true, 'Patent-Nummer.'));
      });
      seite.zeilen.forEach(function (z) {
        var mm = /^\s*([A-C])\s*[=:-]\s*([A-Za-zÄÖÜäöüß]+)/.exec(zeileText(z));
        if (mm && !k.klassen) einsKandidat(k, 'klassen', kandidat(mm[1] + ' = ' + mm[2], z.konf, 'muster'));
        var m2 = /([A-ZÄÖÜ][a-zäöüß]+(?:\s?[a-zäöüß]+)?)\s*,\s*den\b/.exec(zeileText(z));
        if (m2 && !k.ausgestelltAm) {
          /* das Datum steht in der Zeile darüber oder rechts */
          var cand = null;
          seite.zeilen.forEach(function (y) {
            if (y === z) return;
            var dd = datenInText(zeileText(y), 'ausgestellt', ctx.heute);
            if (dd.length && dd[0].iso && Math.abs(mitteY(y) - mitteY(z)) < hoeheVon(z) * 3.5 && !cand) cand = { iso: dd[0].iso, konf: y.konf };
          });
          if (cand) einsKandidat(k, cand.iso > ctx.heute ? 'gueltigBis' : 'ausgestelltAm', kandidat(cand.iso, cand.konf, 'muster', true, 'Datum bei „' + m2[1] + ', den“.'));
        }
        if (/Landratsamt\s+\w+/i.test(zeileText(z)) && !k.aussteller) einsKandidat(k, 'aussteller', kandidat(saeubern(/Landratsamt\s+[A-Za-zÄÖÜäöüß]+/i.exec(zeileText(z))[0]), z.konf, 'muster'));
      });
      return k;
    },
    pruefen: function () { return []; }
  };

  /* ----- Zulassungsbescheinigung Teil I (Fahrzeugschein), nach Anlage 6 FZV ----- */
  var ZB_CODES = ['A', 'B', 'C.1.1', 'C.1.2', 'C.1.3', 'D.1', 'D.2', 'D.3', 'E', 'F.1', 'F.2', 'G', 'H', 'I', 'J', 'K', 'L', 'O.1', 'O.2', 'P.1', 'P.2', 'P.3', 'P.4', 'Q', 'R', 'S.1', 'S.2', 'T', 'U.1', 'U.2', 'V.7', 'V.9', '14.1', '15.1', '18', '19', '20', '22'];
  ARTEN.DE_FZV_ZB_I = {
    name: 'Zulassungsbescheinigung Teil I', gehoertZu: 'fahrzeug',
    erkennung: [[/zulassungsbescheinigung/, 6], [/fahrzeug-?identifizierungsnummer|fahrzeugidentifizierungsnummer/, 3], [/(^|\W)amtliches kennzeichen/, 3], [/handelsbezeichnung/, 2], [/datum der erstzulassung/, 2], [/\bd\.1\b.*\bd\.2\b/, 2]],
    angaben: [A('kennzeichen', 'Amtliches Kennzeichen', 'text', 'A'), A('erstzulassung', 'Datum der Erstzulassung', 'datum', 'B'), A('marke', 'Marke', 'text', 'D.1'), A('typ', 'Typ, Variante, Version', 'text', 'D.2'),
      A('modell', 'Handelsbezeichnung', 'text', 'D.3'), A('fin', 'Fahrzeug-Identifizierungsnummer (FIN)', 'text', 'E'), A('gesamtgewicht', 'Im Zulassungsstaat zulässige Gesamtmasse (kg)', 'zahl', 'F.2'),
      A('leergewicht', 'Leermasse (kg)', 'zahl', 'G'), A('plaetze', 'Sitzplätze', 'zahl', 'S.1'), A('hoechstgeschwindigkeit', 'Höchstgeschwindigkeit (km/h)', 'zahl', 'T'),
      A('laenge', 'Länge (mm)', 'zahl', '18'), A('breite', 'Breite (mm)', 'zahl', '19'), A('hoehe', 'Höhe (mm)', 'zahl', '20'), A('achsen', 'Anzahl der Achsen', 'zahl', 'L'),
      A('nummer', 'Druckstücknummer', 'text', ''), A('aussteller', 'Zulassungsbehörde', 'text', '')],
    lesen: function (seite, ctx) {
      var k = {}, m = marken(seite, ZB_CODES, { codeMuster: '[A-Z]\\.\\d(?:\\.\\d)?|[A-Z]|\\d{2}(?:\\.\\d)?', lueckenFaktor: 5, codeOhnePunkt: true }), d;
      function ziffern(t) { var n = String(t).replace(/[^0-9]/g, ''); return n; }
      if (m['A']) { var kz = saeubern(m['A'].text).toUpperCase().replace(/[^A-ZÄÖÜ0-9\- ]/g, ''); if (kz.length >= 4) einsKandidat(k, 'kennzeichen', kandidat(kz, m['A'].konf, 'marke', /^[A-ZÄÖÜ]{1,3}[- ]?[A-Z]{1,2}[- ]?\d{1,4}[EH]?$/.test(kz), 'Bitte das Kennzeichen prüfen.')); }
      if (m['B']) { d = datumKandidat(m['B'].text, m['B'].konf, 'marke', 'ausgestellt', ctx.heute); if (d) einsKandidat(k, 'erstzulassung', d); }
      if (m['D.1']) einsKandidat(k, 'marke', kandidat(saeubern(m['D.1'].text), m['D.1'].konf, 'marke'));
      if (m['D.2']) einsKandidat(k, 'typ', kandidat(saeubern(m['D.2'].text), m['D.2'].konf, 'marke'));
      if (m['D.3']) einsKandidat(k, 'modell', kandidat(saeubern(m['D.3'].text), m['D.3'].konf, 'marke'));
      if (m['E']) {
        var fin = m['E'].text.replace(/[^A-Za-z0-9]/g, '').toUpperCase().replace(/O/g, '0').replace(/Q/g, '0').replace(/I/g, '1');
        if (fin.length >= 10) einsKandidat(k, 'fin', kandidat(fin, m['E'].konf, 'marke', fin.length === 17, fin.length === 17 ? '' : 'Die FIN hat 17 Zeichen, hier sind es ' + fin.length + '.'));
      }
      [['F.2', 'gesamtgewicht'], ['G', 'leergewicht'], ['S.1', 'plaetze'], ['T', 'hoechstgeschwindigkeit'], ['L', 'achsen'], ['18', 'laenge'], ['19', 'breite'], ['20', 'hoehe']].forEach(function (p) {
        if (m[p[0]] && ziffern(m[p[0]].text)) einsKandidat(k, p[1], kandidat(ziffern(m[p[0]].text), m[p[0]].konf, 'marke'));
      });
      /* FIN nach Bedeutung: 17 Zeichen ohne I, O, Q */
      if (!k.fin) seite.zeilen.forEach(function (z) {
        var mm = /\b([A-HJ-NPR-Z0-9]{17})\b/.exec(zeileText(z).replace(/\s/g, ' '));
        if (mm && !k.fin && /\d/.test(mm[1]) && /[A-Z]/.test(mm[1])) einsKandidat(k, 'fin', kandidat(mm[1], z.konf, 'muster'));
      });
      return k;
    },
    pruefen: function (w) {
      var h = [];
      if (w.erstzulassung && w.erstzulassung > new Date().toISOString().slice(0, 10)) h.push({ rolle: 'erstzulassung', text: 'Die Erstzulassung liegt in der Zukunft.' });
      if (w.leergewicht && w.gesamtgewicht && parseInt(w.leergewicht, 10) > parseInt(w.gesamtgewicht, 10)) h.push({ rolle: 'leergewicht', text: 'Die Leermasse ist größer als die zulässige Gesamtmasse.' });
      return h;
    }
  };

  /* ----- Internationaler Bootsschein: nur die Art wird erkannt, die Angaben trägt der Nutzer ein (Muster liegt noch nicht vor) ----- */
  ARTEN.DE_IBS = {
    name: 'Internationaler Bootsschein', gehoertZu: 'fahrzeug',
    erkennung: [[/bootsschein/, 6], [/international certificate of pleasure craft|certificate for pleasure craft/, 3], [/dmyv|deutscher motoryachtverband|deutscher segler/, 1]],
    angaben: [A('nummer', 'Bootsscheinnummer (mit Kennbuchstabe M, S oder A)', 'text', ''), A('aussteller', 'Ausgebende Organisation (DMYV, DSV, ADAC)', 'text', '')],
    lesen: function (seite) {
      var k = {};
      seite.zeilen.forEach(function (z) {
        var mm = /\b([MSA]\s?-?\s?\d{4,8})\b/.exec(zeileText(z));
        if (mm && !k.nummer && /(bootsschein|nr|nummer)/i.test(zeileText(z))) einsKandidat(k, 'nummer', kandidat(mm[1].replace(/\s/g, ''), z.konf, 'muster', true, 'Das Muster liegt noch nicht vor. Bitte prüfen.'));
      });
      return k;
    },
    pruefen: function () { return []; }
  };

  /* ---------- Art erkennen ---------- */
  /* Gibt die Arten nach Trefferpunkten, beste zuerst: [{ artId, punkte }]. Mindestens 4 Punkte, sonst keine. */
  function artErkennen(seite, extraText) {
    var text = kleinText(seite) + '\n' + (extraText || '');
    var erg = [];
    Object.keys(ARTEN).forEach(function (id) {
      var p = 0;
      ARTEN[id].erkennung.forEach(function (e) { if (e[0].test(text)) p += e[1]; });
      /* Die Maschinenzeile des Ausweises erkennt man auch, wenn nichts Lesbares dabei ist */
      if (id === 'DE_PAUSWG_PERSONALAUSWEIS' && mrzLesen(seite.zeilen.map(function (z) { return zeileText(z); }))) p += 6;
      if (p >= 4) erg.push({ artId: id, punkte: p });
    });
    erg.sort(function (a, b) { return b.punkte - a.punkte; });
    return erg;
  }

  /* ---------- Lesen einer Seite ---------- */
  /* Gibt { artId, felder: { rolle: [Kandidat] }, punkte } oder, wenn die Art nicht erkannt wurde, { artId: null, ... } */
  function seiteLesen(seite, opt) {
    opt = opt || {};
    var treffer = artErkennen(seite, opt.extraText), artId = opt.artId || (treffer[0] && treffer[0].artId) || null;
    if (!artId || !ARTEN[artId]) return { artId: null, felder: {}, treffer: treffer };
    var felder = ARTEN[artId].lesen(seite, { heute: opt.heute || new Date().toISOString().slice(0, 10) });
    return { artId: artId, felder: felder, treffer: treffer, zeilen: seite.zeilen.length };
  }

  /* ---------- Entscheiden und Zusammenführen ---------- */
  var QUELLE_GEWICHT = { mrz: 100, marke: 82, beschriftung: 72, muster: 55, rest: 30, hand: 120, lernen: 90 };
  function kandWert(k, rolle) { return rolle && /datum|gueltigBis|ausgestelltAm|erstzulassung/.test(rolle) ? k.wert : normal(k.wert); }
  function punkte(k) { return (QUELLE_GEWICHT[k.quelle] || 40) + k.konf * 0.4 + (k.ok === false ? -60 : 10); }

  /* Fasst die Kandidaten einer Angabe (von allen Seiten) zu einer Entscheidung zusammen:
     { wert, status: 'sicher' | 'unsicher' | 'fehlt', hinweis, quelle } */
  function entscheiden(rolle, kandidaten) {
    if (!kandidaten || !kandidaten.length) return { wert: '', status: 'fehlt', hinweis: 'Nicht gelesen. Bitte eintragen.', quelle: '' };
    var sorted = kandidaten.slice().sort(function (a, b) { return punkte(b) - punkte(a); }), best = sorted[0], i, gegen = null, hinweise = [];
    for (i = 1; i < sorted.length; i++) {
      if (kandWert(sorted[i], rolle) !== kandWert(best, rolle) && sorted[i].ok !== false) {
        /* Ein anderer Wert: bei Namen reicht ein kleiner Abstand (ß/ss, ein falscher Buchstabe), ein ganz anderer Wert ist ein Widerspruch */
        var nah = /nachname|vorname|geburtsort/.test(rolle) && abstand(normal(sorted[i].wert), normal(best.wert)) <= 2;
        gegen = { k: sorted[i], nah: nah };
        break;
      }
    }
    var status = (best.ok !== false && best.konf >= 60) ? 'sicher' : 'unsicher';
    if (best.hinweis) hinweise.push(best.hinweis);
    if (gegen) {
      if (!gegen.nah) { status = 'unsicher'; }
      hinweise.push('Eine andere Stelle auf dem Dokument ergibt „' + (/datum|gueltigBis|ausgestelltAm|erstzulassung/.test(rolle) ? datumAnzeige(gegen.k.wert) : gegen.k.wert) + '“.');
    }
    return { wert: best.wert, status: status, hinweis: hinweise.join(' '), quelle: best.quelle, konf: best.konf };
  }

  /* Mehrere Seitenergebnisse (alle von einer Art) zu einem Entwurf: { rolle: Entscheidung }. */
  function zusammenfuehren(ergebnisse) {
    var alle = {}, erg = {};
    ergebnisse.forEach(function (e) { Object.keys(e.felder || {}).forEach(function (r) { alle[r] = (alle[r] || []).concat(e.felder[r]); }); });
    Object.keys(alle).forEach(function (r) { erg[r] = entscheiden(r, alle[r]); });
    return erg;
  }

  /* Namen aus der Maschinenzeile haben ß als „SS“. Stimmen sie in der Vergleichsform mit dem gedruckten Namen überein, gilt der gedruckte. */
  function bevorzugeGedruckt(entwurf) { return entwurf; }

  /* ---------- Plausibilität ---------- */
  /* werte: { rolle: Text } (Daten als JJJJ-MM-TT). Gibt [{ rolle, text, hell }]; „hell“ = nur ein Hinweis, kein Fehler. */
  function plausibel(artId, werte, heute) {
    var h = [], a = ARTEN[artId], t = heute || new Date().toISOString().slice(0, 10), j = parseInt(t.slice(0, 4), 10);
    if (!a) return h;
    a.angaben.forEach(function (an) {
      var v = werte[an.rolle];
      if (leer(v)) return;
      if (an.typ === 'datum' && !/^\d{4}-\d{2}-\d{2}$/.test(String(v))) h.push({ rolle: an.rolle, text: 'Das ist kein gültiges Datum. Bitte als Tag.Monat.Jahr eintragen.' });
    });
    if (werte.geburtsdatum && /^\d{4}-\d{2}-\d{2}$/.test(werte.geburtsdatum)) {
      var alter = j - parseInt(werte.geburtsdatum.slice(0, 4), 10);
      if (werte.geburtsdatum > t) h.push({ rolle: 'geburtsdatum', text: 'Das Geburtsdatum liegt in der Zukunft.' });
      else if (alter > 120) h.push({ rolle: 'geburtsdatum', text: 'Das Geburtsdatum liegt mehr als 120 Jahre zurück.' });
    }
    if (werte.ausgestelltAm && /^\d{4}-\d{2}-\d{2}$/.test(werte.ausgestelltAm) && werte.ausgestelltAm > t) h.push({ rolle: 'ausgestelltAm', text: 'Das Ausstellungsdatum liegt in der Zukunft.' });
    if (werte.geburtsdatum && werte.ausgestelltAm && werte.ausgestelltAm < werte.geburtsdatum) h.push({ rolle: 'ausgestelltAm', text: 'Das Dokument wurde vor der Geburt ausgestellt.' });
    ['nachname', 'vorname'].forEach(function (r) {
      if (werte[r] && /\d/.test(werte[r])) h.push({ rolle: r, text: 'In einem Namen stehen keine Ziffern.' });
      if (werte[r] && normal(werte[r]).length < 2) h.push({ rolle: r, text: 'Der Name ist sehr kurz.' });
    });
    if (a.pruefen) a.pruefen(werte, { heute: t }).forEach(function (x) { h.push(x); });
    return h;
  }

  /* ---------- Zuordnung zu einer vorhandenen Person ---------- */
  /*
   * ident = { nachname, vorname, geburtsdatum } aus dem neuen Dokument.
   * personen = [{ id, name, nachname, vorname, geburtsdatum }] (die Angaben stammen aus den Nachweisen der Person).
   * Ergebnis: { art: 'gleich' | 'rueckfrage' | 'neu', person, kandidaten }
   *  gleich:     Name und Geburtsdatum stimmen überein (ß = ss, Groß/Klein egal), nur eine Person kommt in Frage
   *  rueckfrage: Geburtsdatum gleich, Name ähnlich (bis zu 2 Zeichen Unterschied), oder Name gleich und Geburtsdatum unbekannt, oder mehrere Treffer
   *  neu:        niemand passt
   */
  function personZuordnen(ident, personen) {
    var nn = normal(ident.nachname), vn = normal((ident.vorname || '').split(/\s+/)[0]), gd = ident.geburtsdatum || '';
    var gleich = [], aehnlich = [];
    (personen || []).forEach(function (p) {
      var pn = normal(p.nachname || ''), pv = normal((p.vorname || '').split(/\s+/)[0]), pg = p.geburtsdatum || '';
      /* Bei Personen ohne Nachweise mit Namensfeldern steht nur der volle Name da: „Vorname Nachname“ */
      if (!pn && p.name) { var tt = String(p.name).trim().split(/\s+/); pn = normal(tt.slice(1).join('')); pv = normal(tt[0]); if (!pn) { pn = normal(tt[0]); pv = ''; } }
      var nameGleich = pn && nn && pn === nn && (!vn || !pv || pv === vn);
      var nameNah = pn && nn && pn.length >= 5 && abstand(pn, nn) <= 2 && (!vn || !pv || abstand(pv, vn) <= 1);
      if (gd && pg) {
        if (pg === gd && nameGleich) gleich.push(p);
        else if (pg === gd && nameNah) aehnlich.push(p);
      } else if (nameGleich) aehnlich.push(p);
    });
    if (gleich.length === 1 && !aehnlich.length) return { art: 'gleich', person: gleich[0], kandidaten: gleich };
    if (gleich.length || aehnlich.length) return { art: 'rueckfrage', person: (gleich[0] || aehnlich[0]), kandidaten: gleich.concat(aehnlich) };
    return { art: 'neu', person: null, kandidaten: [] };
  }

  /* Welche Angaben zur Identität stehen in einem Nachweis? Sucht nach Bedeutung (Beschriftung des Feldes), nicht nach dem Schlüssel,
     so passt es zu allen Arten, auch zu eigenen und zu früher übernommenen. felder = Felder der Art, werte = die Angaben. */
  function identitaetAus(felder, werte) {
    var r = {};
    (felder || []).forEach(function (f) {
      var l = normal(f.label), v = werte ? werte[f.key] : null;
      if (v === null || v === undefined || v === '') return;
      var hatDatum = /geburtsdatum|geburtstag/.test(l), hatOrt = /geburtsort/.test(l);
      if (hatDatum && hatOrt) {
        var dd = datenInText(String(v), 'geburt'); var d1 = dd[0] && dd[0].iso;
        var d2 = datumLesen(String(v), 'geburt');
        r.geburtsdatum = r.geburtsdatum || (d2 && d2.iso) || d1 || '';
        r.geburtsort = r.geburtsort || nurName(String(v).replace(/\d{1,2}\s*[.,]\s*\d{1,2}\s*[.,]\s*\d{2,4}/g, ' '));
      } else if (hatDatum) { r.geburtsdatum = r.geburtsdatum || (/^\d{4}-\d{2}-\d{2}$/.test(v) ? v : ((datumLesen(String(v), 'geburt') || {}).iso || '')); }
      else if (hatOrt) { r.geburtsort = r.geburtsort || String(v); }
      else if (l === 'name' || l === 'nachname' || l === 'familienname') r.nachname = r.nachname || String(v);
      else if (l === 'vorname' || l === 'vornamen') r.vorname = r.vorname || String(v);
    });
    return r;
  }

  /* Welches Feld der Art nimmt diese Angabe auf? Zuerst der Schlüssel, dann die Nummer auf dem Papier, dann die Beschriftung. Gibt das Feld oder null. */
  function feldFuerAngabe(artFelder, angabe) {
    var i, f, l = normal(angabe.label);
    for (i = 0; i < artFelder.length; i++) { if (artFelder[i].key === angabe.rolle) return artFelder[i]; }
    for (i = 0; i < artFelder.length; i++) {
      f = artFelder[i];
      if (angabe.papier && f.papier && String(f.papier) === String(angabe.papier) && angabe.rolle !== 'geburtsort' && angabe.rolle !== 'geburtsdatum' && !angabe.person) return f;
    }
    for (i = 0; i < artFelder.length; i++) {
      f = artFelder[i]; var fl = normal(f.label);
      if (fl === l) return f;
      if (angabe.rolle === 'nachname' && (fl === 'name' || fl === 'nachname' || fl === 'familienname')) return f;
      if (angabe.rolle === 'vorname' && (fl === 'vorname' || fl === 'vornamen')) return f;
      if (angabe.rolle === 'geburtsdatum' && /geburtsdatum|geburtstag/.test(fl)) return f;
      if (angabe.rolle === 'geburtsort' && /geburtsort/.test(fl)) return f;
    }
    return null;
  }

  /* Was ein Nachweis aus dem Entwurf aufnimmt: { artFeldKey: Wert } und die Angaben, für die die Art noch ein Feld braucht. */
  function aufFelderAbbilden(artId, artFelder, werte) {
    var a = ARTEN[artId], aus = {}, fehlend = [], kombi = {};
    if (!a) return { werte: aus, fehlend: fehlend };
    a.angaben.forEach(function (an) {
      var v = werte[an.rolle];
      if (leer(v)) return;
      var f = feldFuerAngabe(artFelder, an);
      if (!f) { if (an.person || an.rolle === 'nummer' || an.rolle === 'aussteller' || an.rolle === 'ausgestelltAm' || an.rolle === 'gueltigBis' || an.rolle === 'klassen' || a.gehoertZu === 'person') fehlend.push(an); return; }
      var fl = normal(f.label), istKombi = /geburtsdatum|geburtstag/.test(fl) && /geburtsort/.test(fl);
      if (istKombi) { kombi[f.key] = kombi[f.key] || {}; kombi[f.key][an.rolle] = v; return; }
      aus[f.key] = v;
    });
    Object.keys(kombi).forEach(function (key) {
      var k = kombi[key];
      aus[key] = [k.geburtsdatum ? datumAnzeige(k.geburtsdatum) : '', k.geburtsort || ''].join(' ').trim();
    });
    return { werte: aus, fehlend: fehlend };
  }

  MM.Erfassung = {
    ARTEN: ARTEN,
    normal: normal, abstand: abstand, saeubern: saeubern,
    datumLesen: datumLesen, datenInText: datenInText, datumAnzeige: datumAnzeige, gueltigesDatum: gueltigesDatum,
    mrzLesen: mrzLesen, mrzPruefziffer: mrzPruefziffer,
    dokumentBereich: dokumentBereich, grauNormal: grauNormal,
    seiteAusTesseract: seiteAusTesseract, seitenVereinen: seitenVereinen, seitenText: seitenText, seiteVonWoertern: zeileAus,
    marken: marken, wertRechts: wertRechts, wertUnter: wertUnter, wertUeber: wertUeber,
    artErkennen: artErkennen, seiteLesen: seiteLesen, entscheiden: entscheiden, zusammenfuehren: zusammenfuehren,
    plausibel: plausibel, personZuordnen: personZuordnen, identitaetAus: identitaetAus,
    feldFuerAngabe: feldFuerAngabe, aufFelderAbbilden: aufFelderAbbilden,
    artName: function (id) { return ARTEN[id] ? ARTEN[id].name : ''; },
    artIds: function () { return Object.keys(ARTEN); }
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
