/*
 * Smart Capture: Texterkennung auf dem Gerät (Tesseract.js, mitgeliefert unter lib/tesseract, kein Internet nötig).
 * Dieses Modul ist die Brücke zwischen Bild und js/erfassung.js. Es läuft nur im Browser und wird nicht in Node getestet.
 *
 * Ein Arbeiter (Worker) wird einmal gestartet und für alle Seiten und Felder weiterverwendet (nicht je Feld neu).
 * Die Seitenaufteilung wird NICHT über den Modus des Arbeiters gesteuert (Tesseract.js 5 ignoriert ihn beim Start), sondern über das Zuschneiden des Bildes.
 *
 * Wichtig für den Datenschutz: Das Foto verlässt das Gerät nicht. Es wird nur in diesem Modul im Arbeitsspeicher bearbeitet.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  var doc = global.document;

  var ORDNER = 'lib/tesseract/';
  var DATEIEN = ['tesseract.min.js', 'worker.min.js', 'tesseract-core-simd-lstm.wasm.js', 'tesseract-core-lstm.wasm.js', 'deu.traineddata.gz'];
  var SPEICHER = 'mobimory-erkennung';   /* eigener Zwischenspeicher, bleibt bei App-Updates erhalten wie der Kartenspeicher */
  var arbeiter = null, wirdGeladen = null;

  function abs(datei) { return new global.URL(ORDNER + datei, global.location.href).href; }

  function skriptLaden() {
    if (global.Tesseract) return Promise.resolve();
    return new Promise(function (ok, fehl) {
      var s = doc.createElement('script');
      s.src = abs('tesseract.min.js'); s.onload = function () { ok(); }; s.onerror = function () { fehl(new Error('Die Texterkennung konnte nicht geladen werden.')); };
      doc.head.appendChild(s);
    });
  }

  /* Legt die Dateien der Erkennung einmal in den Speicher des Geräts, damit sie auch ohne Netz da sind. Gibt true, wenn alles bereit ist. */
  function bereitmachen(fortschritt) {
    if (!global.caches) return Promise.resolve(false);
    return global.caches.open(SPEICHER).then(function (c) {
      var i = 0;
      function weiter() {
        if (i >= DATEIEN.length) return Promise.resolve(true);
        var d = DATEIEN[i++], url = abs(d);
        return c.match(url).then(function (t) {
          if (t) return null;
          if (fortschritt) fortschritt('Erkennung wird einmalig auf das Gerät geladen (' + i + ' von ' + DATEIEN.length + ') …');
          return global.fetch(url).then(function (r) { if (!r.ok) throw new Error('Datei fehlt: ' + d); return c.put(url, r); });
        }).then(weiter);
      }
      return weiter();
    }).catch(function () { return false; });
  }

  function starten(fortschritt) {
    if (arbeiter) return Promise.resolve(arbeiter);
    if (wirdGeladen) return wirdGeladen;
    wirdGeladen = bereitmachen(fortschritt).then(skriptLaden).then(function () {
      if (fortschritt) fortschritt('Erkennung wird gestartet …');
      var basis = new global.URL(ORDNER, global.location.href).href;
      return global.Tesseract.createWorker('deu', 1, { workerPath: abs('worker.min.js'), corePath: basis, langPath: basis, gzip: true, cacheMethod: 'none', workerBlobURL: false });
    }).then(function (w) { arbeiter = w; return w; }, function (e) { wirdGeladen = null; throw e; });
    return wirdGeladen;
  }

  function beenden() { var w = arbeiter; arbeiter = null; wirdGeladen = null; return w ? w.terminate() : Promise.resolve(); }

  /* ---------- Bild ---------- */
  function leinwand(b, h) { var c = doc.createElement('canvas'); c.width = Math.max(1, Math.round(b)); c.height = Math.max(1, Math.round(h)); return c; }

  /* Bild aus Datei oder Blob, richtig gedreht laut Kamera-Angabe */
  function bildLaden(blob) {
    if (global.createImageBitmap) {
      return global.createImageBitmap(blob, { imageOrientation: 'from-image' }).catch(function () { return global.createImageBitmap(blob); });
    }
    return new Promise(function (ok, fehl) {
      var u = global.URL.createObjectURL(blob), i = new global.Image();
      i.onload = function () { ok(i); }; i.onerror = function () { fehl(new Error('Das Bild konnte nicht gelesen werden.')); }; i.src = u;
    });
  }

  function zeichnen(quelle, sx, sy, sb, sh, zielBreite, zielHoehe, drehung) {
    var c, x;
    if (drehung === 90 || drehung === 270) c = leinwand(zielHoehe, zielBreite); else c = leinwand(zielBreite, zielHoehe);
    x = c.getContext('2d');
    x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high';
    x.translate(c.width / 2, c.height / 2); x.rotate((drehung || 0) * Math.PI / 180);
    x.drawImage(quelle, sx, sy, sb, sh, -zielBreite / 2, -zielHoehe / 2, zielBreite, zielHoehe);
    return c;
  }
  function begrenzt(b, h, maximal) { var f = Math.min(1, maximal / Math.max(b, h)); return { b: Math.round(b * f), h: Math.round(h * f) }; }

  /* Das Dokument auf dem Foto: Ausschnitt (in Bildpunkten) oder das ganze Bild */
  function ausschnittFinden(quelle) {
    var k = begrenzt(quelle.width, quelle.height, 900), c = leinwand(k.b, k.h), x = c.getContext('2d'), d, r, f;
    x.drawImage(quelle, 0, 0, k.b, k.h);
    d = x.getImageData(0, 0, k.b, k.h);
    r = MM.Erfassung.dokumentBereich({ data: d.data, width: k.b, height: k.h });
    f = quelle.width / k.b;
    if (!r) return { x: 0, y: 0, b: quelle.width, h: quelle.height, ganz: true };
    return { x: Math.round(r.x * f), y: Math.round(r.y * f), b: Math.round(r.b * f), h: Math.round(r.h * f), ganz: false };
  }

  /* Grau und kontrastreich, bereit für die Erkennung */
  function aufbereiten(c) {
    var x = c.getContext('2d'), d = x.getImageData(0, 0, c.width, c.height);
    MM.Erfassung.grauNormal({ data: d.data, width: c.width, height: c.height });
    x.putImageData(d, 0, 0);
    return c;
  }

  function erkennen(w, c) {
    return w.recognize(c, {}, { blocks: true, text: true }).then(function (r) { return r.data; });
  }

  /* Wie gut ist die Lage? Viele lange, sicher gelesene Wörter in waagrechter Schrift. */
  function lageWert(data) {
    var ws = [], i, bl, p, l, k;
    (data.blocks || []).forEach(function (b) { (b.paragraphs || []).forEach(function (pa) { (pa.lines || []).forEach(function (z) { (z.words || []).forEach(function (wo) { ws.push(wo); }); }); }); });
    var lang = ws.filter(function (wo) { return String(wo.text).length >= 3; });
    var waag = lang.length ? lang.filter(function (wo) { return (wo.bbox.x1 - wo.bbox.x0) > (wo.bbox.y1 - wo.bbox.y0); }).length / lang.length : 0;
    var s = 0;
    lang.forEach(function (wo) { if (wo.confidence > 55 && /[A-Za-zÄÖÜäöüß]{4,}/.test(wo.text)) s += wo.text.length * wo.confidence / 100; });
    return s * waag * waag;
  }

  /*
   * Liest ein Foto oder einen Scan. Gibt { seite, bildDatei (zugeschnitten, gedreht), drehung, ausschnitt }.
   * Die Lage (0, 90, 180, 270 Grad) wird an einem kleinen Bild gesucht, die Erkennung selbst läuft dann einmal groß.
   * fortschritt(text) meldet den Stand in einfachen Worten.
   */
  function lesen(blob, fortschritt) {
    var meld = fortschritt || function () {}, w, bild, auss, drehungen = [0, 90, 270, 180], beste = null, scores = [];
    meld('Bild wird geöffnet …');
    return bildLaden(blob).then(function (b) {
      bild = b; auss = ausschnittFinden(bild);
      return starten(meld);
    }).then(function (arb) {
      w = arb;
      var i = 0;
      function probe() {
        if (i >= drehungen.length) return Promise.resolve();
        var dr = drehungen[i++], k = begrenzt(auss.b, auss.h, 1300);
        meld('Lage wird gesucht (' + i + ' von ' + drehungen.length + ') …');
        var c = aufbereiten(zeichnen(bild, auss.x, auss.y, auss.b, auss.h, k.b, k.h, dr));
        return erkennen(w, c).then(function (d) {
          var s = lageWert(d);
          scores.push(dr + ':' + Math.round(s)); if (!beste || s > beste.s) beste = { dr: dr, s: s };
          if (s > 120) return null;
          return probe();
        });
      }
      return probe();
    }).then(function () {
      /* Nichts Brauchbares gefunden (kleine Schrift, zum Beispiel Rückseite des Ausweises): die Lagen noch einmal in voller Größe prüfen */
      if (beste && beste.s >= 5) return null;
      meld('Lage wird genauer geprüft …');
      var kk = begrenzt(auss.b, auss.h, 2400), liste = [0, 90, 270], j = 0, bestes = null;
      function genau() {
        if (j >= liste.length) { if (bestes && bestes.s > 0) beste = { dr: bestes.dr, s: bestes.s }; return Promise.resolve(); }
        var dr = liste[j++], c = aufbereiten(zeichnen(bild, auss.x, auss.y, auss.b, auss.h, kk.b, kk.h, dr));
        return erkennen(w, c).then(function (d) {
          var sum = 0;
          (d.blocks || []).forEach(function (bl) { (bl.paragraphs || []).forEach(function (pa) { (pa.lines || []).forEach(function (z) { (z.words || []).forEach(function (wo) {
            var t = String(wo.text);
            if (t.length >= 4 && wo.confidence > 40) sum += t.length * wo.confidence / 100;
            if (/<</.test(t)) sum += 30;
          }); }); }); });
          scores.push('g' + dr + ':' + Math.round(sum));
          if (!bestes || sum > bestes.s) bestes = { dr: dr, s: sum };
          return genau();
        });
      }
      return genau();
    }).then(function () {
      var dr = beste ? beste.dr : 0, k = begrenzt(auss.b, auss.h, 2400);
      meld('Text wird gelesen …');
      var gross = zeichnen(bild, auss.x, auss.y, auss.b, auss.h, k.b, k.h, dr);
      var farbe = leinwand(gross.width, gross.height); farbe.getContext('2d').drawImage(gross, 0, 0);
      var grau = aufbereiten(gross);
      return erkennen(w, grau).then(function (d) {
        var seite = MM.Erfassung.seiteAusTesseract(d, grau.width, grau.height);
        /* Hefte und aufgeschlagene Seiten: beide Hälften noch einmal einzeln, die Spalten stören sonst die Zeilen */
        var breit = grau.width > grau.height * 1.25, wert = seite.zeilen.length;
        if (wert < 3 || breit) {
          meld('Beide Seiten werden einzeln gelesen …');
          var teile = breit ? [[0, 0, grau.width / 2, grau.height], [grau.width / 2, 0, grau.width / 2, grau.height]] : [[0, 0, grau.width, grau.height / 2], [0, grau.height / 2, grau.width, grau.height / 2]];
          var gesamt = seite, j = 0;
          function teil() {
            if (j >= teile.length) return Promise.resolve(gesamt);
            var t = teile[j++], k2 = begrenzt(t[2], t[3], 2400), cc = leinwand(k2.b, k2.h);
            cc.getContext('2d').drawImage(farbe, t[0], t[1], t[2], t[3], 0, 0, k2.b, k2.h);
            aufbereiten(cc);
            return erkennen(w, cc).then(function (dd) {
              var f = t[2] / k2.b, sp = MM.Erfassung.seiteAusTesseract(dd, grau.width, grau.height);
              sp.zeilen = sp.zeilen.map(function (z) {
                var ws = z.woerter.map(function (wo) { return { t: wo.t, konf: wo.konf, b: { x0: wo.b.x0 * f + t[0], y0: wo.b.y0 * f + t[1], x1: wo.b.x1 * f + t[0], y1: wo.b.y1 * f + t[1] } }; });
                return MM.Erfassung.seiteVonWoertern(ws);
              });
              gesamt = MM.Erfassung.seitenVereinen(gesamt, sp);
              return teil();
            });
          }
          return teil();
        }
        return seite;
      }).then(function (seite) {
        return new Promise(function (ok) { farbe.toBlob(function (bl) { ok({ seite: seite, bild: bl, breite: farbe.width, hoehe: farbe.height, drehung: dr, ausschnitt: auss, lage: scores.join(' ') }); }, 'image/jpeg', 0.9); });
      });
    });
  }

  /* Ein Rechteck (Bruchteile 0 bis 1 des gelesenen Bildes) noch einmal lesen, für das Anlernen und für „dieses Feld neu lesen“. Gibt den Text. */
  function rechteckLesen(bildBlob, box) {
    return Promise.all([bildLaden(bildBlob), starten()]).then(function (r) {
      var bild = r[0], w = r[1], sx = box.x0 * bild.width, sy = box.y0 * bild.height, sb = (box.x1 - box.x0) * bild.width, sh = (box.y1 - box.y0) * bild.height;
      var f = Math.min(3, Math.max(1, 900 / Math.max(sb, 1))), c = aufbereiten(zeichnen(bild, sx, sy, sb, sh, Math.max(8, sb * f), Math.max(8, sh * f), 0));
      return w.recognize(c).then(function (x) { return String(x.data.text || '').replace(/\s+/g, ' ').trim(); });
    });
  }

  /* Maschinenzeile des Personalausweises noch einmal nur mit erlaubten Zeichen lesen (A–Z, 0–9, <). Gibt Textzeilen. */
  function mrzLesen(bildBlob, bereichUnten) {
    var box = bereichUnten || { x0: 0, y0: 0.55, x1: 1, y1: 1 };
    return Promise.all([bildLaden(bildBlob), starten()]).then(function (r) {
      var bild = r[0], w = r[1], sx = box.x0 * bild.width, sy = box.y0 * bild.height, sb = (box.x1 - box.x0) * bild.width, sh = (box.y1 - box.y0) * bild.height;
      var f = Math.min(3, Math.max(1, 2400 / Math.max(sb, 1))), c = aufbereiten(zeichnen(bild, sx, sy, sb, sh, sb * f, sh * f, 0));
      return w.setParameters({ tessedit_char_whitelist: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<' }).then(function () {
        return w.recognize(c);
      }).then(function (x) {
        return w.setParameters({ tessedit_char_whitelist: '' }).then(function () { return String(x.data.text || '').split('\n').filter(function (z) { return z.trim(); }); });
      });
    });
  }

  MM.ErfassungMotor = { bereitmachen: bereitmachen, starten: starten, beenden: beenden, lesen: lesen, rechteckLesen: rechteckLesen, mrzLesen: mrzLesen, DATEIEN: DATEIEN };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
