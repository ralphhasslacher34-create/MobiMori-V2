/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.47';
  MM.STUFE = 'Ereignis-Knöpfe als Baukasten: jede Art kann eine Aktion auslösen (Textfeld, Foto mit Kamera, Navigations-App)';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
