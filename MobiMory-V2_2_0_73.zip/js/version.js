/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.73';
  MM.STUFE = 'Konto: Menü-Umbau, Verleih und Kontrollpapiere, Rollen';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
