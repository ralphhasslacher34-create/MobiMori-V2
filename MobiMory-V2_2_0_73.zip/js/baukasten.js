/* Gerüst des Ereignis-Baukastens (seit 2.0.50). Nur Regeln, kein Speicher und kein Netz.
 * Gesamtbild Ereignis-Baukasten: Jeder Knopf folgt demselben Muster.
 *   1. Festhalten  Ort und Zeit, immer (macht der Knopf selbst, hier nichts einzustellen)
 *   2. Fragen      nur, was die App nicht wissen kann (Text, Foto, Betrag, Ziel; seit 2.0.51 auch Tank, Menge, Literpreis, Voll getankt)
 *   3. Wirkungen   was die App danach selbst tut (Kostenposten anlegen, Navigations-App öffnen; seit 2.0.51 auch Füllstand, Verbrauch, Reichweite)
 * Welche Fragen und Wirkungen es gibt, steht nur in den Listen FRAGEN und WIRKUNGEN unten. Eine neue kommt als eine weitere Zeile
 * dazu (oder mit MM.Baukasten.frageRegistrieren / wirkungRegistrieren), der Aufbau ändert sich nicht. Tanken (seit 2.0.51), Störung und
 * Aufenthalte (spätere Stufen) sind nur Zusammenstellungen aus diesen Bausteinen (Vorlage: VORLAGEN).
 *
 * Die Zusammenstellung einer Ereignisart liegt in den Feldern „fragen“ und „wirkungen“ (Listen von Kennungen).
 * Die Aktionen aus 2.0.47 (js/aktionen.js: Text, Foto, Navigation) gehen darin auf: Eine Art, die nur das alte Feld „aktion“ hat,
 * bekommt ihre Zusammenstellung daraus (Text = Frage Text, Foto = Frage Foto, Navigation = Frage Ziel + Wirkung Navigation).
 * Nichts wird umgeschrieben, solange der Nutzer die Art nicht ändert.
 *
 * Eintrag Frage:   { id, name, hilfe, typ }   typ: 'auswahl' (aus einer Liste), 'zahl', 'janein'; ohne typ: Text, Foto, Betrag, Ziel wie bisher
 * Eintrag Wirkung: { id, name, hilfe, braucht: [Fragen, ohne die sie nichts tut], brauchtEine: [eine davon genügt], brauchtWirkung: [Wirkungen, auf denen sie aufbaut],
 *                  nichtMit: [Wirkungen, die nicht zugleich gewählt sein sollen] }
 * Seit 2.0.52: Frage „Verbraucher“ (Auswahl) und Wirkungen „Verbraucher einschalten“ und „Verbraucher ausschalten“: Ein und Aus für jeden Verbraucher.
 * „Heizung an“ und „Heizung aus“ baut sich der Nutzer als zwei Ereignisarten daraus (Vorlagen heizungAn, heizungAus), ohne eigenen Code für die Heizung. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var FRAGEN = [
    { id: 'text', name: 'Text', hilfe: 'Ein Textfeld. Der Text kommt zum Eintrag.' },
    { id: 'foto', name: 'Foto', hilfe: 'Foto aufnehmen oder ein vorhandenes Bild wählen. Das Foto kommt zum Eintrag.' },
    { id: 'vorgang', name: 'Was?', typ: 'auswahl', hilfe: 'Auswahl aus einer Liste: zum Beispiel tanken, Gasflasche tauschen, Frischwasser auffüllen, Grauwasser entleeren. Angeboten wird nur, was das Fahrzeug als Komponenten hat. Die Liste ist eine Vorlage und lässt sich erweitern.' },
    { id: 'tank', name: 'Tank', typ: 'auswahl', hilfe: 'Auswahl aus einer Liste: die Tanks des Fahrzeugs. Der gewählte Tank kommt zum Eintrag.' },
    { id: 'stoff', name: 'Kraftstoffart', typ: 'auswahl', hilfe: 'Auswahl aus der Stoffliste, mit dem Stoff des gewählten Tanks vorbelegt. Wählst du etwas anderes, gibt es nur einen Hinweis, keine Sperre.' },
    { id: 'menge', name: 'Menge', typ: 'zahl', hilfe: 'Eine Zahl: die Menge in Litern, bei Stoffen mit Dichte (zum Beispiel Gas) wahlweise in kg. Beim Entleeren freiwillig. Sie kommt zum Eintrag.' },
    { id: 'betrag', name: 'Betrag', hilfe: 'Ein Betrag in Euro. Er kommt zum Eintrag.' },
    { id: 'literpreis', name: 'Literpreis', typ: 'zahl', hilfe: 'Eine Zahl: der Preis je Liter in Euro. Mit der Menge rechnet die App den Betrag, wenn du keinen Betrag einträgst.' },
    { id: 'voll', name: 'Voll getankt?', typ: 'janein', hilfe: 'Ja oder Nein. Bei Ja ist der Tank danach voll.' },
    { id: 'ziel', name: 'Ziel', hilfe: 'Ein Ziel (Ort, Adresse oder Koordinaten), mit dem Ziel des Tages vorbelegt, wenn es eines gibt.' },
    { id: 'zielOrt', name: 'Ziel (Ort aus der Liste)', typ: 'auswahl', hilfe: 'Auswahl aus der Ortsliste (nur Orte mit Position, kein freier Text). Fehlt der Ort, legst du ihn direkt im Feld neu an (Name und Position). Mit dem Ziel rechnet die App die ETA. Die Frage „Ziel“ (Text für die Navigation) bleibt davon getrennt.' },
    { id: 'einschraenkung', name: 'Einschränkung', typ: 'auswahl', hilfe: 'Auswahl: Fahrzeug bleibt nutzbar, nur bedingt einsatzfähig oder nicht einsatzfähig. Ohne Angabe gilt „bleibt nutzbar“.' },
    { id: 'frist', name: 'Reparieren bis', typ: 'datum', hilfe: 'Ein Datum, bis wann die Störung behoben sein soll. Freiwillig.' },
    { id: 'verbraucher', name: 'Verbraucher', typ: 'auswahl', hilfe: 'Auswahl aus einer Liste: die Verbraucher des Fahrzeugs (zum Beispiel Heizung, Kühlschrank, Motor). Der gewählte Verbraucher kommt zum Eintrag.' },
    { id: 'ort', name: 'Ort', typ: 'auswahl', hilfe: 'Auswahl: der Ort ist schon da und wird bestätigt (die App schlägt ihn an der Position vor), oder du legst einen neuen an.' },
    { id: 'ausstattung', name: 'Ausstattung', hilfe: 'Was es am Ort gibt (Strom, Wasser, Entsorgung …). Es gilt auch für den Ort selbst, damit du es beim nächsten Mal siehst. Freiwillig.' },
    { id: 'besuchKosten', name: 'Kosten (Liegeplatz, Strom, Wasser, Gebühr)', hilfe: 'Eine oder mehrere Zeilen mit Art und Betrag. Jede wird ein Kostenposten. Freiwillig.' }
  ];

  var WIRKUNGEN = [
    { id: 'kosten', name: 'Kostenposten anlegen', braucht: ['betrag'],
      hilfe: 'Aus dem Betrag legt die App einen Posten bei den variablen Kosten an, am Fahrzeug und an der Reise, mit dem Namen der Art und dem Datum des Eintrags.' },
    { id: 'navi', name: 'Navigations-App öffnen', braucht: ['ziel'],
      hilfe: 'Die App übergibt nur das Ziel. Das Gerät entscheidet, welche Navigations-App öffnet.' },
    { id: 'kostenTreibstoff', name: 'Kostenposten Treibstoff und Energie', braucht: [], brauchtEine: ['betrag', 'literpreis'],
      hilfe: 'Legt einen Posten bei den variablen Kosten an, Kostenart „Treibstoff und Energie“, am Fahrzeug und an der Reise. Betrag oder Literpreis (mit der Menge) genügt.' },
    { id: 'fuellstand', name: 'Füllstand setzen', braucht: ['tank', 'menge', 'voll'],
      hilfe: 'Voll getankt: der Tank ist voll (Tankinhalt nötig). Nicht voll: letzter Stand plus Menge, mit Hinweis, dass der Stand nur gerechnet ist. Den Stand gibst du einmal beim Tank an.' },
    { id: 'verbrauch', name: 'Verbrauch rechnen', braucht: ['tank', 'menge', 'voll'], brauchtWirkung: ['fuellstand'],
      hilfe: 'Rechnet beim Volltanken die verbrauchten Liter seit dem letzten genauen Stand, je Verbraucher aus Füllstand oder Betriebsstunden (so, wie beim Verbraucher eingestellt). Bei mehreren Verbrauchern am Tank gibt es nur die Summe.' },
    { id: 'reichweite', name: 'Reichweite rechnen', braucht: ['tank', 'menge', 'voll'], brauchtWirkung: ['fuellstand', 'verbrauch'],
      hilfe: 'Füllstand geteilt durch den Verbrauch, in Betriebsstunden oder Tagen.' },
    { id: 'vorgang', name: 'Vorgang in der Werkstatt anlegen', braucht: ['text'],
      hilfe: 'Legt eine Störung in der Werkstatt an, mit dem Text als Beschreibung und der Einschränkung. Das Fahrzeug zeigt dann, wie weit es eingeschränkt ist. Pro Eintrag nur einmal.' },
    { id: 'vorgangFrist', name: 'Frist für die Reparatur setzen', braucht: ['frist'], brauchtWirkung: ['vorgang'],
      hilfe: 'Das Datum „Reparieren bis“ kommt zum Vorgang. Ist es vorbei und der Vorgang noch offen, weist die App darauf hin.' },
    { id: 'besuch', name: 'Besuch anlegen', braucht: ['ort'],
      hilfe: 'Hält den Aufenthalt fest: Besuch im Ortsverlauf, Plan gegen Ist, Ausstattung am Ort und die Kosten als Posten an Reise und Ort (mit Reisekasse). Dazu rechnet die App die Dauer von der Ankunft bis zur nächsten Abfahrt, sobald es sie gibt. Eigene Seite nach dem Antippen, dieselbe wie bei der Frage nach einer Ankunft. Die Motorstopp-Frage bei Wasserfahrzeugen kommt weiter bei den Ereignissen Ankunft, Anlegen und Anker werfen.' },
    { id: 'verbraucherEin', name: 'Verbraucher einschalten', braucht: ['verbraucher'], nichtMit: ['verbraucherAus'],
      hilfe: 'Der gewählte Verbraucher läuft ab jetzt (oder ab der Zeit des Eintrags). Die App merkt sich den Start und zählt die Betriebsstunden, sobald er ausgeschaltet wird. Läuft er schon, sagt die App es.' },
    { id: 'verbraucherAus', name: 'Verbraucher ausschalten', braucht: ['verbraucher'], nichtMit: ['verbraucherEin'],
      hilfe: 'Der gewählte Verbraucher ist aus. Die App rechnet die Dauer des Laufs und zählt sie zu den Betriebsstunden. Läuft er nicht, sagt die App es.' }
  ];

  /* Fertige Zusammenstellungen. Nur ein Anfang (Vorlage): Der Nutzer stellt sie bei der Art ein und kann sie ändern. Nichts wird erzwungen. */
  var VORLAGEN = [
    { id: 'heizungAn', name: 'Verbraucher einschalten (zum Beispiel Heizung an)', fragen: ['verbraucher'], wirkungen: ['verbraucherEin'] },
    { id: 'heizungAus', name: 'Verbraucher ausschalten (zum Beispiel Heizung aus)', fragen: ['verbraucher'], wirkungen: ['verbraucherAus'] },
    { id: 'aufenthalt', name: 'Aufenthalt (zum Beispiel Ankunft, Anlegen, Anker werfen)', fragen: ['ort', 'ausstattung', 'besuchKosten'], wirkungen: ['besuch'] },
    { id: 'stoerung', name: 'Störung', fragen: ['text', 'foto', 'einschraenkung', 'frist'], wirkungen: ['vorgang', 'vorgangFrist'] },
    { id: 'ablegen', name: 'Ablegen (Text und Foto freiwillig, Ziel aus der Ortsliste)', fragen: ['text', 'foto', 'zielOrt'], wirkungen: [] },
    { id: 'tanken', name: 'Tanken', fragen: ['tank', 'stoff', 'menge', 'betrag', 'literpreis', 'voll'], wirkungen: ['kostenTreibstoff', 'fuellstand', 'verbrauch', 'reichweite'] },
    { id: 'versorgung', name: 'Ver- und Entsorgung (tanken, Gasflasche, Wasser auffüllen, entleeren)', fragen: ['vorgang', 'tank', 'stoff', 'menge', 'betrag', 'literpreis', 'voll'], wirkungen: ['kostenTreibstoff', 'fuellstand', 'verbrauch', 'reichweite'] }
  ];

  function kopie(o) {
    var k = Object.assign({}, o);
    ['braucht', 'brauchtEine', 'brauchtWirkung', 'nichtMit'].forEach(function (f) { if (o[f]) k[f] = o[f].slice(); });
    return k;
  }
  function liste(reg) { return reg.map(kopie); }
  function finde(reg, id) {
    var s = String(id === undefined || id === null ? '' : id);
    var x = reg.filter(function (a) { return a.id === s; })[0];
    return x ? kopie(x) : null;
  }
  function registrieren(reg, a) {
    if (!a || !a.id || !a.name || finde(reg, a.id)) return false;
    var neu = { id: String(a.id), name: String(a.name), hilfe: a.hilfe || '' };
    if (a.typ) neu.typ = String(a.typ);
    ['braucht', 'brauchtEine', 'brauchtWirkung', 'nichtMit'].forEach(function (f) { if (a[f]) neu[f] = a[f].map(String); });
    reg.push(neu);
    return true;
  }

  function fragen() { return liste(FRAGEN); }
  function wirkungen() { return liste(WIRKUNGEN); }
  function frage(id) { return finde(FRAGEN, id); }
  function wirkung(id) { return finde(WIRKUNGEN, id); }
  function frageRegistrieren(a) { return registrieren(FRAGEN, a); }
  function wirkungRegistrieren(a) { return registrieren(WIRKUNGEN, a); }
  function vorlagen() { return VORLAGEN.map(function (v) { return { id: v.id, name: v.name, fragen: v.fragen.slice(), wirkungen: v.wirkungen.slice() }; }); }
  function vorlage(id) { return vorlagen().filter(function (v) { return v.id === String(id); })[0] || null; }

  /* Nur bekannte Kennungen, ohne Doppelte, in der Reihenfolge der Liste (nicht der Eingabe). */
  function normalListe(reg, roh) {
    var gewaehlt = Array.isArray(roh) ? roh.map(String) : [];
    return reg.filter(function (a) { return gewaehlt.indexOf(a.id) >= 0; }).map(function (a) { return a.id; });
  }
  function fragenNormal(roh) { return normalListe(FRAGEN, roh); }
  function wirkungenNormal(roh) { return normalListe(WIRKUNGEN, roh); }

  /* Die Zusammenstellung einer Ereignisart: { fragen: [...], wirkungen: [...] }.
   * Hat die Art eines der Felder „fragen“ oder „wirkungen“, gilt das. Sonst kommt sie aus dem alten Feld „aktion“ (2.0.47). */
  function zusammenstellung(werte) {
    var w = werte || {};
    if (w.fragen !== undefined || w.wirkungen !== undefined) return { fragen: fragenNormal(w.fragen), wirkungen: wirkungenNormal(w.wirkungen) };
    var a = MM.Aktionen ? MM.Aktionen.art(w.aktion) : null;
    return a ? { fragen: fragenNormal(a.fragen), wirkungen: wirkungenNormal(a.wirkungen) } : { fragen: [], wirkungen: [] };
  }
  function leer(z) { return !z || (!z.fragen.length && !z.wirkungen.length); }
  /* Löst der Knopf nach Wo und Wann noch etwas aus? Nur dann kommt die Seite nach dem Antippen. */
  function hatAblauf(werte) { return !leer(zusammenstellung(werte)); }
  function gleich(a, b) { return JSON.stringify(a.fragen) === JSON.stringify(b.fragen) && JSON.stringify(a.wirkungen) === JSON.stringify(b.wirkungen); }

  /* Eine Wirkung braucht ihre Fragen. Gibt für jede fehlende Frage eine Meldung zurück (leere Liste = in Ordnung). */
  function fehlendeFragen(z) {
    var meldungen = [];
    if (!z) return meldungen;
    z.wirkungen.forEach(function (wid) {
      var w = wirkung(wid);
      (w && w.braucht || []).forEach(function (fid) {
        if (z.fragen.indexOf(fid) < 0) {
          var f = frage(fid);
          meldungen.push('„' + w.name + '“ braucht die Frage „' + (f ? f.name : fid) + '“. Bitte ankreuzen.');
        }
      });
      /* Eine von mehreren Fragen genügt (zum Beispiel Betrag oder Literpreis). */
      if (w && w.brauchtEine && w.brauchtEine.length && !w.brauchtEine.some(function (fid) { return z.fragen.indexOf(fid) >= 0; })) {
        meldungen.push('„' + w.name + '“ braucht eine dieser Fragen: ' + w.brauchtEine.map(function (fid) { var f = frage(fid); return '„' + (f ? f.name : fid) + '“'; }).join(' oder ') + '. Bitte ankreuzen.');
      }
      (w && w.nichtMit || []).forEach(function (wid) {
        if (z.wirkungen.indexOf(wid) >= 0 && wid > w.id) {
          var y = wirkung(wid);
          meldungen.push('„' + w.name + '“ und „' + (y ? y.name : wid) + '“ passen nicht zusammen. Bitte nur eine ankreuzen.');
        }
      });
      (w && w.brauchtWirkung || []).forEach(function (wid) {
        if (z.wirkungen.indexOf(wid) < 0) {
          var x = wirkung(wid);
          meldungen.push('„' + w.name + '“ braucht die Wirkung „' + (x ? x.name : wid) + '“. Bitte ankreuzen.');
        }
      });
    });
    if (z && z.fragen.indexOf('ziel') >= 0 && z.fragen.indexOf('zielOrt') >= 0) meldungen.push('„Ziel“ (Text für die Navigation) und „Ziel (Ort aus der Liste)“ passen nicht zusammen. Bitte nur eines ankreuzen.');
    /* „Besuch anlegen“ hat eine eigene Seite (die des Ortes) und seine eigenen Fragen. */
    var besuchFragen = ['ort', 'ausstattung', 'besuchKosten'];
    if (z && z.wirkungen.indexOf('besuch') >= 0) {
      if (z.wirkungen.length > 1) meldungen.push('„Besuch anlegen“ hat eine eigene Seite und passt nicht mit anderen Wirkungen zusammen. Bitte nur diese eine ankreuzen.');
      if (z.fragen.some(function (fid) { return besuchFragen.indexOf(fid) < 0; })) meldungen.push('„Besuch anlegen“ stellt seine eigenen Fragen (Ort, Ausstattung, Kosten). Bitte keine anderen Fragen ankreuzen.');
    } else if (z && z.fragen.some(function (fid) { return besuchFragen.indexOf(fid) >= 0; })) {
      meldungen.push('Die Fragen Ort, Ausstattung und Kosten gehören zur Wirkung „Besuch anlegen“. Bitte diese ankreuzen.');
    }
    return meldungen;
  }

  /* Das Muster in Worten, für Listen und Seiten. Ohne Fragen und Wirkungen: ''. */
  function ablaufText(z) {
    if (leer(z)) return '';
    var teile = ['Festhalten: Ort und Zeit'];
    if (z.fragen.length) teile.push('Fragen: ' + z.fragen.map(function (i) { var f = frage(i); return f ? f.name : i; }).join(', '));
    if (z.wirkungen.length) teile.push('Wirkungen: ' + z.wirkungen.map(function (i) { var w = wirkung(i); return w ? w.name : i; }).join(', '));
    return teile.join(' → ');
  }

  MM.Baukasten = {
    fragen: fragen, wirkungen: wirkungen, frage: frage, wirkung: wirkung,
    frageRegistrieren: frageRegistrieren, wirkungRegistrieren: wirkungRegistrieren, vorlagen: vorlagen, vorlage: vorlage,
    fragenNormal: fragenNormal, wirkungenNormal: wirkungenNormal,
    zusammenstellung: zusammenstellung, hatAblauf: hatAblauf, leer: leer, gleich: gleich,
    fehlendeFragen: fehlendeFragen, ablaufText: ablaufText
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
