CREATE TABLE IF NOT EXISTS rolle (email TEXT PRIMARY KEY, name TEXT NOT NULL, funktion TEXT NOT NULL CHECK (funktion IN ('admin', 'entwickler')));
