INSERT OR REPLACE INTO rolle (email, name, funktion) VALUES ('ralphhasslacher34@gmail.com', 'Ralph Hasslacher', 'admin');
