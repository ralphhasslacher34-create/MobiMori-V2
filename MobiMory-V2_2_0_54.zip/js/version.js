/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.54';
  MM.STUFE = 'Kleinere Schalter für Motor und Verbraucher, Tank-Fehlermeldung am Feld';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
