'use strict';
/* 2.0.101: Reisecheck-Ergebnisse werden als Regeln in Orten und Gebieten gespeichert (mit Datum), bei einer erneuten Reise gibt es zuerst einen Überblick. */
const test = require('node:test');
const assert = require('node:assert/strict');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status', 'motoren',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'reisecheck', 'reisecheck-regeln', 'daten']
  .forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const R = MM.ReisecheckRegeln;

/* ---------- reine Rechnung ---------- */
const A = (o) => Object.assign({ id: 'r1', bereich: 'Kroatien', kategorie: 'Pflicht', subjektArt: 'Person', verkehr: 'Wasser', anforderung: 'Sportbootführerschein mitführen', status: 'Fehlt',
  beleg: 'GEHEIM-BELEG', erklaerung: 'Gilt für Yachten über 5 PS', quellen: [{ titel: 'Amt', url: 'https://amt.example/x', herausgeber: 'Amt', amtlich: true, stand: '' }] }, o || {});
const DE = { id: 'g-de', name: 'Deutschland', ebene: 'land' }, HR = { id: 'g-hr', name: 'Kroatien', ebene: 'land' }, ZADAR = { id: 'g-zd', name: 'Zadarska županija', ebene: 'region' };

test('Regelwerte: nur was gilt, nie Status, Beleg oder Personenbezug; mit Datum des Checks und Verweis auf den Check', () => {
  const w = R.regelWerte(A(), '2026-11-12', 'rc1');
  assert.equal(w.art, 'reisecheck'); assert.equal(w.herkunft, 'reisecheck'); assert.equal(w.gilt, 'ja');
  assert.equal(w.pruefDatum, '2026-11-12'); assert.equal(w.checkId, 'rc1');
  assert.equal(w.anforderung, 'Sportbootführerschein mitführen'); assert.equal(w.kategorie, 'Pflicht'); assert.equal(w.bereich, 'Kroatien');
  assert.deepEqual(w.artIds, []); assert.deepEqual(w.fahrzeugArten, []);
  const s = JSON.stringify(w);
  assert.ok(!s.includes('GEHEIM-BELEG')); assert.ok(!('status' in w)); assert.ok(!('beleg' in w));
  assert.equal(w.quellen.length, 1); assert.equal(w.quellen[0].url, 'https://amt.example/x');
  assert.ok(R.regelWerte(A({ anforderung: 'x'.repeat(500) }), '2026-11-12').bezeichnung.length <= 120);
  assert.equal(R.regelWerte(A({ quellen: [1, 2, 3, 4, 5].map(i => ({ titel: 't' + i, url: 'https://q.example/' + i })) }), '2026-11-12').quellen.length, 3);
});

test('Datum des Checks: JJJJ-MM-TT aus Zeitangaben, sonst null', () => {
  assert.equal(R.datumVon('2026-11-05T11:00:00Z'), '2026-11-05'); assert.equal(R.datumVon('2026-11-05'), '2026-11-05');
  assert.equal(R.datumVon(''), null); assert.equal(R.datumVon(null), null); assert.equal(R.datumVon('gestern'), null);
});

test('Zuordnung: der Bereich bestimmt das genaueste passende Gebiet, ein Ortsname schlägt das Gebiet, Unpassendes geht in die Länder der Reise', () => {
  const ketten = [[DE], [HR, ZADAR]];
  const z = R.zuordnen({ anforderungen: [
    A({ id: 'a', bereich: 'Kroatien: Vignette und Lizenz' }),
    A({ id: 'b', bereich: 'Zadarska županija, Küstengewässer', anforderung: 'Kurtaxe' }),
    A({ id: 'c', bereich: 'Hafen Biograd', anforderung: 'Liegeplatz anmelden' }),
    A({ id: 'd', bereich: 'Einreise', anforderung: 'Ausweis mitführen' })
  ], ketten, orte: [{ id: 'o1', name: 'Biograd' }] });
  const von = (typ, id) => (z.ziele.filter(t => t.typ === typ && t.id === id)[0] || { anforderungen: [] }).anforderungen.map(a => a.id).sort().join('');
  assert.equal(von('gebiet', 'g-hr'), 'ad', 'a (Land) und d (Reise insgesamt)');
  assert.equal(von('gebiet', 'g-zd'), 'b', 'die Region ist genauer als das Land');
  assert.equal(von('ort', 'o1'), 'c');
  assert.equal(von('gebiet', 'g-de'), 'd', 'Reise insgesamt kommt in jedes Land der Reise');
  assert.equal(z.grund, null);
});

test('Zuordnung: ohne Gebiet und ohne Ort mit Land kann nichts gespeichert werden', () => {
  const z = R.zuordnen({ anforderungen: [A()], ketten: [], orte: [] });
  assert.equal(z.ziele.length, 0); assert.equal(z.grund, 'kein-gebiet'); assert.equal(z.ohneZiel, 1);
  assert.equal(R.zuordnen({ anforderungen: [], ketten: [], orte: [] }).ziele.length, 0);
});

test('Passt: kurze Namen und leere Bereiche passen nie, Groß- und Kleinschreibung zählt nicht', () => {
  assert.equal(R.passt('KROATIEN, Adria', 'Kroatien'), true);
  assert.equal(R.passt('', 'Kroatien'), false); assert.equal(R.passt('Italien', 'IT'), false); assert.equal(R.passt('Einreise', 'Kroatien'), false);
});

test('Fortschreiben: neu anlegen, mit späterem Datum aktualisieren, bei gleichem oder älterem Stand nichts tun, „abgeschaltet“ bleibt', () => {
  const alt = R.regelWerte(A(), '2026-05-01', 'rc0');
  const vorhanden = [{ id: 'rg1', nr: 1, werte: alt }];
  const neu = R.regelWerte(A({ erklaerung: 'Neue Erklärung' }), '2026-11-12', 'rc1');
  const andere = R.regelWerte(A({ anforderung: 'Funkzeugnis' }), '2026-11-12', 'rc1');
  let f = R.fortschreiben({ vorhanden, neu: [neu, andere, neu] });
  assert.equal(f.anlegen.length, 1); assert.equal(f.anlegen[0].anforderung, 'Funkzeugnis');
  assert.equal(f.aendern.length, 1); assert.equal(f.aendern[0].id, 'rg1'); assert.equal(f.aendern[0].werte.pruefDatum, '2026-11-12'); assert.equal(f.aendern[0].werte.erklaerung, 'Neue Erklärung');
  /* gleicher Inhalt, gleiches Datum: nichts */
  f = R.fortschreiben({ vorhanden, neu: [R.regelWerte(A(), '2026-05-01', 'rc0')] }); assert.equal(f.aendern.length, 0); assert.equal(f.gleich, 1);
  /* älterer Check überschreibt keinen jüngeren Stand */
  const jung = [{ id: 'rg1', nr: 2, werte: neu }];
  f = R.fortschreiben({ vorhanden: jung, neu: [R.regelWerte(A({ erklaerung: 'noch älter' }), '2026-01-01', 'rc-1')] }); assert.equal(f.aendern.length, 0);
  /* vom Nutzer abgeschaltet bleibt abgeschaltet */
  const aus = [{ id: 'rg1', nr: 2, werte: Object.assign({}, alt, { gilt: 'nein' }) }];
  f = R.fortschreiben({ vorhanden: aus, neu: [neu] }); assert.equal(f.aendern[0].werte.gilt, 'nein'); assert.equal(f.aendern[0].werte.pruefDatum, '2026-11-12');
});

test('Überblick: sortiert nach Kategorie, nennt je Gruppe und insgesamt „Stand: Datum, die Daten können veraltet sein“, abgeschaltete und fremde Regeln fallen weg', () => {
  const w = (o, d) => R.regelWerte(A(o), d, 'x');
  const u = R.ueberblick({ datumText: d => d.split('-').reverse().join('.'), gruppen: [
    { name: 'Kroatien', ebene: 'land', regeln: [w({ kategorie: 'Hinweis', anforderung: 'B Hinweis' }, '2026-03-01'), w({ kategorie: 'Pflicht', anforderung: 'A Pflicht' }, '2026-11-12'),
      Object.assign(w({ anforderung: 'weg' }, '2026-11-12'), { gilt: 'nein' }), { art: 'befaehigung', bezeichnung: 'Fremd', gilt: 'ja' }] },
    { name: 'Leer', ebene: 'land', regeln: [] }
  ] });
  assert.equal(u.gruppen.length, 1); assert.equal(u.anzahl, 2);
  assert.deepEqual(u.gruppen[0].eintraege.map(e => e.anforderung), ['A Pflicht', 'B Hinweis']);
  assert.equal(u.gruppen[0].standText, 'Stand: 12.11.2026, die Daten können veraltet sein.');
  assert.equal(u.standText, 'Stand: 12.11.2026, die Daten können veraltet sein.');
  assert.equal(R.ueberblick({ gruppen: [] }).anzahl, 0); assert.equal(R.ueberblick({ gruppen: [] }).standText, null);
});

/* ---------- Datenfluss ---------- */
const JETZT = new Date(2026, 10, 12, 12, 0, 0).toISOString();
const URL_DIENST = 'https://dienst.example.dev';
const ANF = (id, o) => Object.assign({ id, area: 'Kroatien', category: 'Pflicht', subjectKey: 'P1', subjectType: 'Person', trafficMode: 'Wasser', requirement: 'Sportbootführerschein mitführen',
  proofKey: 'SBF', status: 'Fehlt', evidence: 'GEHEIM-BELEG', explanation: 'Gilt für Yachten', confidence: 'hoch', conflict: false, sources: [{ title: 'Amt', url: 'https://amt.example/x', publisher: 'Amt', official: true, updated: '' }] }, o || {});
function antwort(anf, datum) {
  return { ok: true, model: 'm1', requestId: 'q1', researchedAt: (datum || '2026-11-12') + 'T11:00:00Z', result: { summary: 'Fertig', researchStatus: 'vollständig', warnings: [], route: { routingStatus: 'plausibel', summary: '', assumptions: [], routeWarnings: [] }, requirements: anf } };
}
const HR_TREFFER = { osm_type: 'node', osm_id: 4, name: 'Biograd na Moru', lat: '43.9387', lon: '15.4443', address: { town: 'Biograd na Moru', county: 'Zadarska županija', country: 'Kroatien', country_code: 'hr' } };
const DE_TREFFER = { osm_type: 'node', osm_id: 3, name: 'Sersheim', lat: '48.9561', lon: '9.0546', address: { village: 'Sersheim', county: 'Landkreis Ludwigsburg', state: 'Baden-Württemberg', country: 'Deutschland', country_code: 'de' } };

async function neu(opt) {
  const o = opt || {}; let t = 0; const st = { antwort: o.antwort || antwort([ANF('r1'), ANF('r2', { requirement: 'Vignette kaufen', area: 'Reise', category: 'Wichtig' })]) };
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), {
    jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(),
    holeJson: async () => ({ ok: true, configured: true, model: 'm1' }),
    sendeJson: async () => st.antwort
  });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Seeschwalbe', marke: 'Bavaria', laenge: '9,5' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const start = await d.ortAusTreffer(MM.Ortssuche.kandidaten([DE_TREFFER])[0]);
  const ziel = await d.ortAusTreffer(MM.Ortssuche.kandidaten([HR_TREFFER])[0]);
  assert.equal(start.ok, true); assert.equal(ziel.ok, true);
  const arten = await d.aktivitaetsartenListe();
  const artId = arten.find(a => a.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const akt = await d.aktivitaetAnlegen({ bezeichnung: 'Törn 1', artId, fahrzeugId: boot, vonDatum: '2026-12-01', bisDatum: '2026-12-10', verantwortlichId: anna, startOrtId: start.id, zielOrtId: ziel.id });
  assert.equal(akt.ok, true, JSON.stringify(akt));
  await d.reisecheckEinrichten({ dienstUrl: URL_DIENST, passwort: 'geheim1234' });
  await d.reisecheckZustimmen();
  return { d, st, id: akt.id, boot, anna, artId, start: start.id, ziel: ziel.id };
}
async function alleRegeln(d) {
  const gebiete = await d.gebieteListe(); const namen = {}; gebiete.forEach(g => { namen[g.objekt.id] = g.aktuell.werte.bezeichnung; });
  const rec = await d.speicher.alle('regeln'); const ver = await d.speicher.alle('verlaeufe');
  return rec.map(r => { const l = ver.filter(v => v.objektId === r.id).sort((a, b) => a.nr - b.nr); return { id: r.id, gebiet: namen[r.gebietId], nr: l.length, werte: l[l.length - 1].werte }; });
}

test('Nach einem Check stehen die Anforderungen als Regeln in den Gebieten, mit dem Datum des Checks', async () => {
  const c = await neu();
  const r = await c.d.reisecheckStarten(c.id);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(r.regeln.ok, true); assert.equal(r.regeln.neu, 3, 'eine für Kroatien, eine „Reise“ in beide Länder');
  const reg = await alleRegeln(c.d);
  assert.equal(reg.length, 3);
  const hr = reg.filter(x => x.gebiet === 'Kroatien').map(x => x.werte.anforderung).sort();
  assert.deepEqual(hr, ['Sportbootführerschein mitführen', 'Vignette kaufen']);
  assert.deepEqual(reg.filter(x => x.gebiet === 'Deutschland').map(x => x.werte.anforderung), ['Vignette kaufen']);
  reg.forEach(x => { assert.equal(x.werte.art, 'reisecheck'); assert.equal(x.werte.pruefDatum, '2026-11-12'); assert.equal(x.werte.gilt, 'ja'); assert.ok(x.werte.checkId); });
  const s = JSON.stringify(reg); assert.ok(!s.includes('GEHEIM-BELEG'), 'kein Beleg'); assert.ok(!s.includes('Fehlt'), 'kein Status');
});

test('Gespeicherter Check vom Dienst: das Datum der Regel ist der Stand des Dienstes, nicht heute', async () => {
  const c = await neu();
  const rec = { id: 'rc-x', erstelltAm: JETZT, gespeichert: true, gespeichertStand: '2026-03-02T08:00:00.000Z', dienst: { recherchiertAm: '2026-11-12T11:00:00Z' }, ergebnis: { anforderungen: [{ bereich: 'Kroatien', kategorie: 'Pflicht', subjektArt: 'Person', verkehr: 'Wasser', anforderung: 'Funkzeugnis', erklaerung: '', quellen: [] }] } };
  const sr = await c.d.reisecheckRegelnSpeichern(c.id, null, rec);
  assert.equal(sr.neu, 1);
  assert.equal((await alleRegeln(c.d))[0].werte.pruefDatum, '2026-03-02');
});

test('Ein zweiter Check schreibt dieselben Regeln mit neuem Datum fort (keine Doppelten), Neues kommt dazu, Altes bleibt mit altem Datum', async () => {
  const c = await neu();
  await c.d.reisecheckStarten(c.id);
  c.st.antwort = antwort([ANF('r1', { explanation: 'Neue Erklärung' }), ANF('r3', { requirement: 'Funkzeugnis (SRC)' })], '2027-04-01');
  const r2 = await c.d.reisecheckStarten(c.id);
  assert.equal(r2.regeln.neu, 1); assert.equal(r2.regeln.aktualisiert, 1);
  const reg = await alleRegeln(c.d);
  assert.equal(reg.length, 4);
  const sbf = reg.find(x => x.werte.anforderung === 'Sportbootführerschein mitführen');
  assert.equal(sbf.nr, 2, 'zweiter Stand im Verlauf'); assert.equal(sbf.werte.pruefDatum, '2027-04-01'); assert.equal(sbf.werte.erklaerung, 'Neue Erklärung');
  const vignette = reg.filter(x => x.werte.anforderung === 'Vignette kaufen');
  assert.ok(vignette.every(x => x.werte.pruefDatum === '2026-11-12'), 'vom neuen Check nicht mehr genannt: alter Stand bleibt');
});

test('Gleicher Check noch einmal holen ändert nichts (kein neuer Verlaufseintrag)', async () => {
  const c = await neu();
  await c.d.reisecheckStarten(c.id);
  const vorher = (await c.d.speicher.alle('verlaeufe')).length;
  const r = await c.d.reisecheckStarten(c.id);
  assert.equal(r.regeln.neu, 0); assert.equal(r.regeln.aktualisiert, 0); assert.ok(r.regeln.gleich >= 3);
  assert.equal((await c.d.speicher.alle('verlaeufe')).length, vorher + 0);
});

test('Ein Ort im Bereich der Anforderung bekommt sein eigenes Gebiet (Ebene „ort“) mit der Regel', async () => {
  const c = await neu({ antwort: antwort([ANF('r1', { area: 'Biograd na Moru Hafen', requirement: 'Liegeplatz vorab anmelden' })]) });
  const r = await c.d.reisecheckStarten(c.id);
  assert.equal(r.regeln.neu, 1); assert.equal(r.regeln.ziele[0].typ, 'ort');
  const og = (await c.d.gebieteListe()).filter(g => g.aktuell.werte.ebene === 'ort');
  assert.equal(og.length, 1); assert.equal(og[0].aktuell.werte.ortId, c.ziel);
  const o = await c.d.ortLaden(c.ziel);
  assert.equal(o.eigeneRegeln.length, 1); assert.equal(o.eigeneRegeln[0].aktuell.werte.pruefDatum, '2026-11-12');
});

test('Ohne Gebiet bei den Orten wird nichts gespeichert, der Check selbst gelingt trotzdem', async () => {
  const c = await neu();
  const roh = await c.d.ortAnlegen({ bezeichnung: 'Irgendwo' });
  const akt = await c.d.aktivitaetAnlegen({ bezeichnung: 'Törn 2', artId: c.artId, fahrzeugId: c.boot, vonDatum: '2027-01-01', bisDatum: '2027-01-05', verantwortlichId: c.anna, startOrtId: roh.id, zielOrtId: roh.id });
  assert.equal(akt.ok, true, JSON.stringify(akt));
  const vor = (await alleRegeln(c.d)).length;
  const r = await c.d.reisecheckStarten(akt.id);
  assert.equal(r.ok, true); assert.equal(r.regeln.grund, 'kein-gebiet'); assert.equal(r.regeln.neu, 0);
  assert.equal((await alleRegeln(c.d)).length, vor);
});

test('Überblick bei erneuter Reise: aus den gespeicherten Regeln, mit Stand, ohne neuen Check', async () => {
  const c = await neu();
  assert.equal((await c.d.reisecheckRegelnUeberblick(c.id, null)).anzahl, 0, 'vor dem ersten Check nichts');
  await c.d.reisecheckStarten(c.id);
  /* Eine zweite Reise ins selbe Gebiet, ohne eigenen Check */
  const akt2 = await c.d.aktivitaetAnlegen({ bezeichnung: 'Törn 2', artId: c.artId, fahrzeugId: c.boot, vonDatum: '2027-06-01', bisDatum: '2027-06-10', verantwortlichId: c.anna, startOrtId: c.start, zielOrtId: c.ziel });
  const u = await c.d.reisecheckRegelnUeberblick(akt2.id, null);
  assert.equal(u.anzahl, 3); assert.equal(u.standText, 'Stand: ' + MM.Hilfen.datum('2026-11-12') + ', die Daten können veraltet sein.');
  assert.deepEqual(u.gruppen.map(g => g.name).sort(), ['Deutschland', 'Kroatien']);
  const an = await c.d.reisecheckAnsicht(akt2.id, null);
  assert.equal(an.checks.length, 0); assert.equal(an.regeln.anzahl, 3, 'die Seite zeigt den Überblick, obwohl diese Reise noch keinen Check hat');
});

test('Die Prüfung der Befähigung und Pflichtausrüstung nimmt Reisecheck-Regeln nicht mit', async () => {
  const c = await neu();
  const sbf = (await c.d.nachweisartAnlegen({ bezeichnung: 'Sportbootführerschein', gehoertZu: 'person', hatAblauf: 'nein' })).id;
  await c.d.reisecheckStarten(c.id);
  const g = (await c.d.gebieteListe()).find(x => x.aktuell.werte.bezeichnung === 'Kroatien').objekt.id;
  assert.equal((await c.d.gebietLaden(g)).regeln.length, 2, 'die Regeln aus dem Check stehen beim Gebiet');
  /* Nur Reisecheck-Regeln da: für die Prüfung gibt es noch keine Regel für die Befähigung, auch keine Pflichtausrüstung */
  let p = (await c.d.aktivitaetPruefung(c.id)).befaehigung;
  assert.ok(p.gebietInfo, 'das Gebiet wird geprüft');
  assert.match(p.gebietHinweis || '', /noch keine Regel für die Befähigung/);
  assert.equal(p.gebietInfo.regelnGesamt, 0, 'zählt nicht als Regel der Befähigung');
  assert.equal(p.gebietInfo.greifen.length + p.gebietInfo.nichtGreifen.length, 0);
  /* Eine echte Befähigungsregel daneben zählt, die Reisecheck-Regeln weiterhin nicht */
  const e = await c.d.regelAnlegen(g, { bezeichnung: 'SBF Binnen', art: 'befaehigung', artIds: [sbf], fahrzeugArten: [] });
  assert.equal(e.ok, true, JSON.stringify(e));
  p = (await c.d.aktivitaetPruefung(c.id)).befaehigung;
  assert.equal(p.gebietInfo.regelnGesamt, 1, 'nur die echte Regel zählt');
});

test('Eine Regel aus einem Reisecheck lässt sich abschalten, nicht ändern; abgeschaltet fehlt sie im Überblick', async () => {
  const c = await neu();
  await c.d.reisecheckStarten(c.id);
  const reg = await alleRegeln(c.d);
  const sbf = reg.find(x => x.werte.anforderung === 'Sportbootführerschein mitführen');
  const ae = await c.d.regelAendern(sbf.id, { bezeichnung: 'x', art: 'befaehigung', artIds: [] });
  assert.equal(ae.ok, false); assert.match(ae.fehler.allgemein, /Reisecheck/);
  const aus = await c.d.reisecheckRegelSchalten(sbf.id, 'nein'); assert.equal(aus.ok, true); assert.equal(aus.geaendert, true);
  const u = await c.d.reisecheckRegelnUeberblick(c.id, null);
  assert.equal(u.anzahl, 2);
  /* ein neuer Check schaltet sie nicht wieder ein */
  c.st.antwort = antwort([ANF('r1')], '2027-04-01'); await c.d.reisecheckStarten(c.id);
  assert.equal((await c.d.reisecheckRegelnUeberblick(c.id, null)).anzahl, 2);
  const an = await c.d.reisecheckRegelSchalten(sbf.id, 'ja'); assert.equal(an.ok, true);
  assert.equal((await c.d.reisecheckRegelnUeberblick(c.id, null)).anzahl, 3);
  assert.equal((await c.d.reisecheckRegelSchalten('gibt-es-nicht', 'ja')).ok, false);
});

test('Die Oberfläche zeigt Überblick und Regeln aus Checks (Verdrahtung)', () => {
  const fs = require('node:fs'), path = require('node:path');
  const a = fs.readFileSync(path.join(__dirname, '../js/ansicht.js'), 'utf8');
  assert.match(a, /regelnUeberblickBlock\(an\.regeln, an\.checks\.length > 0\)/);
  assert.match(a, /Überblick aus gespeicherten Regeln/); assert.match(a, /Ein neuer Online-Check ist nicht zwingend nötig/);
  assert.match(a, /MM\.Orte\.istReisecheckRegel\(rw\)/);
  assert.match(fs.readFileSync(path.join(__dirname, '../index.html'), 'utf8'), /js\/reisecheck-regeln\.js/);
  assert.match(fs.readFileSync(path.join(__dirname, '../sw.js'), 'utf8'), /js\/reisecheck-regeln\.js/);
});
