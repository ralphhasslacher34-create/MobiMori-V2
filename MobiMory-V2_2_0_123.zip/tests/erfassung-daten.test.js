'use strict';
/* Smart Capture: Speichern von Person, Fahrzeug und Nachweis. Erfundene Daten (Erika Mustermann). */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'logbuch', 'rudergaenger', 'status', 'reiseorte', 'kosten', 'reisekasse', 'erfassung', 'daten']
  .forEach(m => require('../js/' + m + '.js'));
const MM = globalThis.MM;

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 15, 12, 0, t++)).toISOString() });
  await d.starten();
  return d;
}
const scan = () => ({ name: 'scan.jpg', type: 'image/jpeg', size: 2048, bytes: new Uint8Array([1, 2, 3]) });
const FS = { nachname: 'Mustermann', vorname: 'Erika', geburtsdatum: '1964-08-12', geburtsort: 'Musterstadt', ausgestelltAm: '2022-08-24', gueltigBis: '2037-08-23', aussteller: 'Landratsamt Musterkreis', nummer: 'B072RRE2I55', klassen: 'AM/B' };

test('Erstes Dokument legt die Person an, Art wird übernommen, Scan hängt am Nachweis', async () => {
  const d = await neu();
  const r = await d.erfassungSpeichern({ vorschlagId: 'DE_FEV_FUEHRERSCHEIN_EU', werte: FS, datei: scan() });
  assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.neu, true); assert.equal(r.besitzerTyp, 'person');
  const personen = await d.personenListe();
  assert.equal(personen.length, 1); assert.equal(personen[0].aktuell.werte.bezeichnung, 'Erika Mustermann');
  const n = await d.nachweisLaden(r.nachweisId);
  assert.equal(n.datei.name, 'scan.jpg');
  assert.equal(n.aktuell.werte.nummer, 'B072RRE2I55'); assert.equal(n.aktuell.werte.gueltigBis, '2037-08-23');
  const z1 = n.felder.find(f => f.label === 'Name'), z3 = n.felder.find(f => /Geburtsdatum/.test(f.label));
  assert.equal(n.aktuell.werte[z1.key], 'Mustermann'); assert.match(n.aktuell.werte[z3.key], /12\.08\.1964 Musterstadt/);
});

test('Weiterer Nachweis: Person wird an Name und Geburtsdatum erkannt, auch bei ß/ss und Großschreibung', async () => {
  const d = await neu();
  await d.erfassungSpeichern({ vorschlagId: 'DE_FEV_FUEHRERSCHEIN_EU', werte: Object.assign({}, FS, { nachname: 'Haßlacher' }), datei: scan() });
  const personen = await d.erfassungPersonen();
  assert.equal(personen[0].nachname, 'Haßlacher'); assert.equal(personen[0].geburtsdatum, '1964-08-12');
  const z = MM.Erfassung.personZuordnen({ nachname: 'HASSLACHER', vorname: 'ERIKA', geburtsdatum: '1964-08-12' }, personen);
  assert.equal(z.art, 'gleich');
  const r = await d.erfassungSpeichern({ vorschlagId: 'DE_PAUSWG_PERSONALAUSWEIS', werte: { nachname: 'Hasslacher', vorname: 'Erika', geburtsdatum: '1964-08-12', geburtsort: 'Musterstadt', gueltigBis: '2029-11-01', nummer: 'T22000129' }, datei: scan(), personId: z.person.id });
  assert.equal(r.ok, true); assert.equal(r.neu, false);
  assert.equal((await d.personenListe()).length, 1);
  assert.equal((await d.nachweiseListe('person', z.person.id)).length, 2);
});

test('Eine schon übernommene Art ohne Namensfelder bekommt sie beim Speichern ergänzt', async () => {
  const d = await neu();
  const a = await d.nachweisartAusVorschlag('DE_UBI');
  const alt = await d.nachweisartLaden(a.id);
  await d.nachweisartAendern(a.id, { bezeichnung: alt.werte.bezeichnung, hatAblauf: alt.werte.hatAblauf, felder: [] });
  const r = await d.erfassungSpeichern({ vorschlagId: 'DE_UBI', werte: { nachname: 'Mustermann', vorname: 'Erika', geburtsdatum: '1964-08-12', geburtsort: 'Musterstadt', nummer: '123456-Z' }, datei: scan() });
  assert.equal(r.ok, true, JSON.stringify(r));
  const n = await d.nachweisLaden(r.nachweisId);
  assert.ok(n.felder.some(f => f.label === 'Name') && n.felder.some(f => /Geburtsdatum/.test(f.label)));
  const p = (await d.erfassungPersonen())[0];
  assert.equal(p.nachname, 'Mustermann'); assert.equal(p.geburtsdatum, '1964-08-12');
});

test('Neue Arten: Bodensee-Schifferpatent und Fachkundenachweis Sprengstoffrecht', async () => {
  const d = await neu();
  const r1 = await d.erfassungSpeichern({ vorschlagId: 'DE_BODENSEE_SCHIFFERPATENT', werte: { nachname: 'Mustermann', vorname: 'Erika', geburtsdatum: '1964-08-12', geburtsort: 'Musterstadt', nummer: '1234567', klassen: 'A = Motorboot', gueltigBis: '2045-11-26' }, datei: scan() });
  assert.equal(r1.ok, true, JSON.stringify(r1));
  const r2 = await d.erfassungSpeichern({ vorschlagId: 'DE_SPRENGG_FACHKUNDE', werte: { nachname: 'Mustermann', vorname: 'Erika', geburtsdatum: '1964-08-12', nummer: 'M000123456', aussteller: 'DMYV-Zentrale' }, datei: scan(), personId: r1.besitzerId });
  assert.equal(r2.ok, true, JSON.stringify(r2));
  assert.equal((await d.nachweiseListe('person', r1.besitzerId)).length, 2);
});

test('Zulassungsbescheinigung legt das Fahrzeug an, gleiche Kennung fragt nach', async () => {
  const d = await neu();
  const w = { kennzeichen: 'LB-AB 123', erstzulassung: '2019-05-04', marke: 'Mustermarke', modell: 'Eins', fin: 'WMUSTER1234567890X', gesamtgewicht: '1800', leergewicht: '1300', laenge: '4500' };
  const r = await d.erfassungSpeichern({ vorschlagId: 'DE_FZV_ZB_I', werte: w, datei: scan(), fahrzeugArt: 'auto' });
  assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.besitzerTyp, 'fahrzeug');
  const f = (await d.fahrzeugListe())[0];
  assert.equal(f.aktuell.werte.bezeichnung, 'Mustermarke Eins'); assert.equal(f.aktuell.werte.kennzeichen, 'LB-AB 123');
  assert.equal(f.aktuell.werte.laenge, 4.5); assert.equal(f.aktuell.werte.gesamtgewicht, 1800);
  const doppelt = await d.erfassungSpeichern({ vorschlagId: 'DE_FZV_ZB_I', werte: w, datei: scan(), fahrzeugArt: 'auto' });
  assert.equal(doppelt.ok, false); assert.ok(doppelt.doppelt && doppelt.doppelt.length === 1);
  const dran = await d.erfassungSpeichern({ vorschlagId: 'DE_FZV_ZB_I', werte: w, datei: scan(), fahrzeugId: f.fahrzeug.id });
  assert.equal(dran.ok, true); assert.equal((await d.fahrzeugListe()).length, 1);
});

test('Vorlage: nur die Stelle wird gemerkt, nie ein persönlicher Wert', async () => {
  const d = await neu();
  await d.erfassungVorlageMerken('DE_FEV_FUEHRERSCHEIN_EU', 'nummer', { x0: 0.3, y0: 0.6, x1: 0.7, y1: 0.7 });
  await d.erfassungVorlageMerken('DE_FEV_FUEHRERSCHEIN_EU', 'nummer', { x0: -1, y0: 0.6, x1: 2, y1: 0.7 });
  const v = await d.erfassungVorlagen();
  assert.deepEqual(Object.keys(v['DE_FEV_FUEHRERSCHEIN_EU'].felder), ['nummer']);
  assert.equal(v['DE_FEV_FUEHRERSCHEIN_EU'].felder.nummer.x0, 0); assert.equal(v['DE_FEV_FUEHRERSCHEIN_EU'].felder.nummer.x1, 1);
  assert.equal(v['DE_FEV_FUEHRERSCHEIN_EU'].gelernt, 2);
  assert.equal(JSON.stringify(v).includes('Mustermann'), false);
});

test('Unbekannte Art: nichts wird angelegt', async () => {
  const d = await neu();
  const r = await d.erfassungSpeichern({ vorschlagId: 'GIBT_ES_NICHT', werte: { nachname: 'X' }, datei: scan() });
  assert.equal(r.ok, false); assert.equal((await d.personenListe()).length, 0);
});

test('Einbau: Module in index.html und Service Worker, Kachel, Route, Lizenzdateien, Tesseract-Dateien', () => {
  const fs = require('node:fs'), path = require('node:path'), l = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
  ['js/erfassung.js', 'js/erfassung-motor.js', 'js/erfassung-ansicht.js'].forEach(f => { assert.ok(l('index.html').includes(f), f); assert.ok(l('sw.js').includes("'" + f + "'"), f); });
  assert.ok(l('index.html').indexOf('js/daten.js') < l('index.html').indexOf('js/erfassung.js') && l('index.html').indexOf('js/erfassung-ansicht.js') < l('index.html').indexOf('js/ansicht.js'));
  const a = l('js/ansicht.js');
  assert.ok(a.includes("'#/erfassung'") && a.includes("teile[0] === 'erfassung'") && a.includes('MM.AnsichtKit'));
  ['tesseract.min.js', 'worker.min.js', 'tesseract-core-simd-lstm.wasm.js', 'tesseract-core-lstm.wasm.js', 'deu.traineddata.gz', 'HERKUNFT.txt', 'LICENSE-tesseract.js.txt'].forEach(f => assert.ok(fs.existsSync(path.join(__dirname, '..', 'lib/tesseract', f)), f));
  MM.ErfassungMotor = undefined;
  assert.ok(l('js/erfassung-motor.js').includes("ORDNER = 'lib/tesseract/'"));
  assert.ok(l('CHANGELOG.md').includes('Smart Capture') && l('docs/SCHRITTE.md').includes('gebaut (2.0.96'));
  /* Nichts verlässt das Gerät: keine fremde Adresse in der Erkennung */
  ['js/erfassung.js', 'js/erfassung-motor.js', 'js/erfassung-ansicht.js'].forEach(f => assert.equal(/https?:\/\//.test(l(f).replace(/\/\*[\s\S]*?\*\//g, '')), false, f));
});

test('Dokument erfassen ist seit 2.0.101 für alle erreichbar: Kachel unter Funktionen, keine Entwickler-Sperre', () => {
  const fs = require('node:fs'), path = require('node:path');
  const a = fs.readFileSync(path.join(__dirname, '..', 'js', 'ansicht.js'), 'utf8');
  const f = a.slice(a.indexOf('function seiteFunktionen'), a.indexOf('function seiteFunktionen') + 3000);
  assert.match(f, /kachel\('Dokument erfassen'[^)]*'#\/erfassung\/neu'\)/);
  assert.ok(!/teile\[0\] === 'erfassung'\) p = nurEntwickler\(/.test(a));
  assert.ok(!/nur für Entwickler sichtbar/.test(a));
  const e = fs.readFileSync(path.join(__dirname, '..', 'js', 'erfassung-ansicht.js'), 'utf8');
  assert.ok(!e.includes("'#/nur-entwickler'"));
});

/* ---------- 2.0.99: Motoren als Komponenten, Kraftstoff, Textrahmen ---------- */
test('2.0.99: Zulassungsbescheinigung I legt das Fahrzeug neu an und gleich die Motoren als Komponenten mit Leistung, Hubraum, Kraftstoff', async () => {
  const d = await neu();
  const w = { kennzeichen: 'XX-AB 123', fin: 'WVWZZZ1JZXW000001', marke: 'VW', modell: 'Golf', hubraum: '1598', leistung: '74', kraftstoff: 'Benzin' };
  const r = await d.erfassungSpeichern({ vorschlagId: 'DE_FZV_ZB_I', werte: w, datei: scan(), fahrzeugArt: 'auto', bezeichnung: 'Golf', motoren: 1 });
  assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.besitzerTyp, 'fahrzeug'); assert.equal(r.motoren, 1);
  const k = await d.komponentenListe(r.besitzerId);
  const motor = k.filter(x => x.aktuell && x.aktuell.werte && /^Motor/.test(x.aktuell.werte.bezeichnung || ''));
  assert.equal(motor.length, 1, JSON.stringify(k.map(x => x.aktuell && x.aktuell.werte)));
});

test('2.0.99: Zwei Motoren heißen „Motor 1“ und „Motor 2“, ohne Wunsch (0) entsteht keiner', async () => {
  const d = await neu();
  const w = { kennzeichen: 'XX-AB 124', fin: 'WVWZZZ1JZXW000002', marke: 'VW', modell: 'Bus', hubraum: '1968', leistung: '110', kraftstoff: 'Diesel' };
  const r = await d.erfassungSpeichern({ vorschlagId: 'DE_FZV_ZB_I', werte: w, datei: scan(), fahrzeugArt: 'wohnmobil', bezeichnung: 'Bus', motoren: 2 });
  assert.equal(r.motoren, 2);
  const w0 = Object.assign({}, w, { kennzeichen: 'XX-AB 125', fin: 'WVWZZZ1JZXW000003' });
  const r0 = await d.erfassungSpeichern({ vorschlagId: 'DE_FZV_ZB_I', werte: w0, datei: scan(), fahrzeugArt: 'wohnmobil', bezeichnung: 'Bus 2', motoren: 0 });
  assert.equal(r0.ok, true); assert.ok(!r0.motoren);
});

test('2.0.99: Kraftstoff und Zahlen aus dem Papier, Textrahmen und gelernte Stellen am Rahmen', () => {
  const E = MM.Erfassung;
  assert.equal(E.kraftstoffWahl('Diesel'), 'Diesel'); assert.equal(E.kraftstoffWahl('Super E10'), 'Benzin'); assert.equal(E.kraftstoffWahl('xyz'), '');
  assert.equal(E.zahlText('74,0 kW'), '74.0');
  const w = (t, x0, y0) => ({ text: t, b: { x0, y0, x1: x0 + 50, y1: y0 + 20 } });
  const seite = { breite: 1000, hoehe: 1000, zeilen: [{ woerter: [w('a', 100, 200), w('b', 200, 200), w('c', 300, 200), w('d', 100, 400), w('e', 200, 400), w('f', 800, 600)] }] };
  const r = E.textRahmen(seite);
  assert.deepEqual([r.x0, r.y0], [0.1, 0.2]);
  const box = { x0: 0.15, y0: 0.3, x1: 0.5, y1: 0.5 };
  const rel = E.boxRelativ(box, r), zurueck = E.boxAbsolut(rel, r);
  ['x0', 'y0', 'x1', 'y1'].forEach(k => assert.ok(Math.abs(zurueck[k] - box[k]) < 1e-9));
  assert.equal(E.textRahmen({ breite: 100, hoehe: 100, zeilen: [] }), null);
});

test('2.0.99: Ansicht – Kamera auf der Weiteren Seite, alle Seiten sichtbar, Seitenwahl beim Markieren, Fahrzeug nur neu, Motoranzahl', () => {
  const fs = require('node:fs'), a = fs.readFileSync(require('node:path').join(__dirname, '..', 'js', 'erfassung-ansicht.js'), 'utf8');
  assert.match(a, /Mit der Kamera aufnehmen/); assert.match(a, /sitzung\.fotos/); assert.match(a, /Seite wählen/);
  assert.match(a, /er-motoren/); assert.match(a, /opt\.motoren/); assert.ok(!/fahrzeugWahlHand/.test(a));
});

test('2.0.100: Bootsschein legt das Boot mit allen Maßen und zwei Motoren an, die Leistung wird aufgeteilt, Nummern je Motor', async () => {
  const d = await neu();
  const w = { bootsname: 'Karoshi', heimathafen: 'Beinheim', marke: 'Birchwood', baujahr: '1978', typ: '33 AK', hin: 'DB5886', baumaterial: 'GFK', laenge: '10.3', breite: '3.5', tiefgang: '0.9', durchfahrtshoehe: '3.5', verdraengung: '7',
    motorAnzahl: '2', motorFabrikat: 'Ford Lehmann', motorNummer: '068432, 078456', motorBaujahr: '1978', leistung: '220.6', einbauart: 'Inb. W-Getr', nummer: '113164-A', aussteller: 'ADAC', ausgestelltAm: '2026-03-02', gueltigBis: '2028-03-01' };
  const r = await d.erfassungSpeichern({ vorschlagId: 'DE_IBS', werte: w, datei: scan(), fahrzeugArt: 'boot', motoren: 2 });
  assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.motoren, 2); assert.equal(r.motorenGeteilt, true);
  const f = await d.fahrzeugLaden(r.besitzerId), v = f.aktuell.werte;
  assert.equal(v.bezeichnung, 'Karoshi'); assert.equal(v.heimathafen, 'Beinheim'); assert.equal(v.marke, 'Birchwood'); assert.equal(v.baujahr, 1978);
  assert.equal(v.laenge, 10.3); assert.equal(v.breite, 3.5); assert.equal(v.tiefgang, 0.9); assert.equal(v.durchfahrtshoehe, 3.5); assert.equal(v.verdraengung, 7);
  assert.equal(v.registriernummer, '113164-A'); assert.equal(v.hin, 'DB5886'); assert.equal(v.baumaterial, 'GFK');
  const k = (await d.komponentenListe(r.besitzerId)).filter(x => /^Motor/.test(x.aktuell.werte.bezeichnung));
  assert.equal(k.length, 2);
  const m1 = k.find(x => x.aktuell.werte.bezeichnung === 'Motor 1').aktuell.werte, m2 = k.find(x => x.aktuell.werte.bezeichnung === 'Motor 2').aktuell.werte;
  assert.equal(m1.seriennummer, '068432'); assert.equal(m2.seriennummer, '078456'); assert.equal(m1.hersteller, 'Ford Lehmann'); assert.equal(m1.baujahr, 1978);
  assert.ok(JSON.stringify(m1.merkmale).includes('110.3'), JSON.stringify(m1.merkmale));
});

test('2.0.100: Bootsschein aus den Zeilen des Fotos gelesen (Muster des ADAC-Scheins)', () => {
  const E = MM.Erfassung, seite = require('./hilfen/erfassung-seite.js');
  const s = seite(['Beschreibung des Fahrzeugs Description of craft', 'Bootsname: KAROSHI', 'Heimathafen: BEINHEIM', 'Hersteller: BIRCHWOOD Jahr: 1978', 'Höhe über Wasserlinie: 3,50 m Tiefgang: 0,90 m', 'Länge ü.A.: 10,30 m Breite: 3,50 m',
    'Fahrzeugtyp: 33 AK Verdrängung: 7,000 t', 'Bau-Nr.: DB5886 Baumaterial: GFK', 'Anzahl/Fabrikat: 2 FORD LEHMANN Baujahr: 1978', 'Motor-Nr.: 068432', 'Serial no./No. de matricule: 078456', 'kW: 220,60 Inb. W-Getr.', '113164-A',
    'Nummer des Bootsscheins', 'Ausgestellt am: 02.03.2026 Gültig bis: 01.03.2028', 'ADAC Sportschifffahrt']);
  const r = E.seiteLesen(s, { heute: '2026-11-16' }), z = E.zusammenfuehren([r]);
  assert.equal(r.artId, 'DE_IBS');
  const soll = { bootsname: 'Karoshi', heimathafen: 'Beinheim', marke: 'Birchwood', baujahr: '1978', laenge: '10.3', breite: '3.5', tiefgang: '0.9', durchfahrtshoehe: '3.5', verdraengung: '7', hin: 'DB5886', motorAnzahl: '2', motorFabrikat: 'Ford Lehmann', motorNummer: '068432, 078456', leistung: '220.6', nummer: '113164-A', aussteller: 'ADAC', ausgestelltAm: '2026-03-02', gueltigBis: '2028-03-01' };
  Object.keys(soll).forEach(k => assert.equal(z[k] && z[k].wert, soll[k], k));
});

test('2.0.100: Rechnung wird zum Kostenposten, die Datei hängt als Beleg daran', async () => {
  const d = await neu();
  const fz = await d.fahrzeugAnlegen('auto', { bezeichnung: 'Golf', kennzeichen: 'XX-AB 123' });
  assert.equal(fz.ok, true, JSON.stringify(fz));
  const r = await d.erfassungRechnungSpeichern({ fahrzeugId: fz.id, werte: { lieferant: 'Autohaus Muster', rechnungsnummer: 'R-2026-17', datum: '2026-11-10', betrag: '123.45' }, datei: scan() });
  assert.equal(r.ok, true, JSON.stringify(r)); assert.ok(r.kostenId); assert.ok(r.dokumentId, JSON.stringify(r));
  const k = await d.kostenLaden(r.kostenId);
  assert.equal(k.aktuell.werte.betrag, 123.45); assert.equal(k.aktuell.werte.datum, '2026-11-10'); assert.match(k.aktuell.werte.bezeichnung, /Autohaus Muster/);
});

test('2.0.100: unbekanntes Dokument: eigene Art wird gemerkt, erkannt und beim Speichern als Nachweisart angelegt', async () => {
  const d = await neu();
  const def = { id: 'EIGEN_TESTSCHEIN', name: 'Testschein', gehoertZu: 'person', welt: '', angaben: [{ rolle: 'nachname', label: 'Name', typ: 'text' }, { rolle: 'vorname', label: 'Vorname', typ: 'text' }, { rolle: 'beruf', label: 'Beruf', typ: 'text' }], schluessel: ['testschein nr'] };
  assert.equal((await d.erfassungEigeneArtMerken(def)).ok, true);
  const liste = await d.erfassungEigeneArten();
  assert.equal(liste.length, 1); assert.ok(MM.Erfassung.ARTEN.EIGEN_TESTSCHEIN);
  assert.equal(MM.Erfassung.ARTEN.EIGEN_TESTSCHEIN.name, 'Testschein');
  assert.equal((await d.erfassungEigeneArtMerken({ id: 'KEIN_EIGEN', name: 'x' })).ok, false);
  delete MM.Erfassung.ARTEN.EIGEN_TESTSCHEIN;
});

test('2.0.100: Rechnung aus den Zeilen gelesen (Betrag, Datum, Nummer, Lieferant)', () => {
  const E = MM.Erfassung, seite = require('./hilfen/erfassung-seite.js');
  const s = seite(['Autohaus Muster GmbH', 'Musterstraße 1', 'Rechnung', 'Rechnungsnummer: R-2026-17', 'Datum: 10.11.2026', 'Zwischensumme 103,74', 'Gesamtbetrag 123,45 EUR']);
  const r = E.seiteLesen(s, { heute: '2026-11-16', artId: 'DE_RECHNUNG' }), z = E.zusammenfuehren([r]);
  assert.equal(z.betrag && z.betrag.wert, '123,45'.replace(',', '.') === '123.45' ? z.betrag.wert : null);
  assert.ok(z.betrag && /123[.,]45/.test(z.betrag.wert), JSON.stringify(z));
  assert.ok(z.rechnungsnummer && /R-2026-17/.test(z.rechnungsnummer.wert), JSON.stringify(z));
  assert.ok(z.lieferant && /Autohaus Muster/.test(z.lieferant.wert), JSON.stringify(z));
});

test('2.0.100: Scan-Einstiege in der Ansicht (Fahrzeug anlegen, Person, Rechnung), seit 2.0.101 für alle', () => {
  const fs = require('node:fs'), path = require('node:path');
  const a = fs.readFileSync(path.join(__dirname, '..', 'js', 'ansicht.js'), 'utf8');
  assert.match(a, /function scanBereich\(cfg\)/); assert.ok(!/scanRolle \|\|/.test(a));
  assert.match(a, /scanBereich\(\{ gehoertZu: 'fahrzeug'/); assert.match(a, /scanBereich\(\{ gehoertZu: 'person', artId: 'DE_PAUSWG_PERSONALAUSWEIS'/);
  assert.match(a, /scanBereich\(\{ gehoertZu: 'kosten'/); assert.match(a, /dateiText: 'Datei wählen \(Foto oder PDF\)'/);
});
