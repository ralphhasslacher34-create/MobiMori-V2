'use strict';
/* 2.0.123: Zwischenziele in fester Reihenfolge, Grenze nach Tagen (höchstens 25), bis zu 10 je Tag, Dienst bis 25. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = t;
const dienstTest = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche',
  'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'kartenereignisse', 'etappen', 'konto', 'daten'].forEach((m) => require('../js/' + m + '.js'));
const MM = globalThis.MM;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const JETZT = new Date(2026, 10, 15, 12, 0, 0).toISOString();

/* ---------- Rechnung: Tage, Grenze, Meldung ---------- */
test('Tage von Datum bis Datum zählen beide Tage; die Grenze ist die Zahl der Tage, höchstens 25', () => {
  const R = MM.Routen;
  assert.equal(R.tageSpanne('2027-05-01', '2027-05-01'), 1);
  assert.equal(R.tageSpanne('2027-05-01', '2027-05-21'), 21);
  assert.equal(R.tageSpanne('2027-05-21', '2027-05-01'), null);
  assert.equal(R.tageSpanne('', '2027-05-01'), null);
  assert.equal(R.maxZwischenziele('2027-05-01', '2027-05-10'), 10);
  assert.equal(R.maxZwischenziele('2027-05-01', '2027-05-21'), 21);
  assert.equal(R.maxZwischenziele('2027-05-01', '2027-12-31'), 25);
  assert.equal(R.maxZwischenziele('', ''), 25);
  assert.equal(R.MAX_ZWISCHENZIELE, 25); assert.equal(R.MAX_ZWISCHENZIELE_TAG, 10);
  assert.equal(R.zwischenzielGrenzeText(10, '2027-05-01', '2027-05-10'), null);
  assert.match(R.zwischenzielGrenzeText(11, '2027-05-01', '2027-05-10'), /höchstens 10 Zwischenziele.*10 Tage.*höchstens 25/);
  assert.match(R.zwischenzielGrenzeText(2, '2027-05-01', '2027-05-01'), /höchstens 1 Zwischenziel möglich.*1 Tag\)/);
});

test('Planungsanfrage: bis 25 Zwischenziele, mit eigener Grenze auch weniger', () => {
  const R = MM.Routen, s = { breite: 48.9, laenge: 9.1 }, z = { breite: 47.5, laenge: 8.2 }, via = (n) => Array.from({ length: n }, (_, i) => ({ breite: 40 + i / 10, laenge: 9 + i / 10 }));
  assert.equal(R.planungAnfrage(s, z, via(25), {}).ok, true);
  assert.equal(R.planungAnfrage(s, z, via(26), {}).ok, false);
  assert.equal(R.planungAnfrage(s, z, via(10), {}, 10).ok, true);
  assert.equal(R.planungAnfrage(s, z, via(11), {}, 10).ok, false);
  assert.match(R.planungAnfrage(s, z, via(11), {}, 10).fehler[0], /höchstens 10 Zwischenziele/);
  /* die Reihenfolge geht genau so in die Anfrage */
  assert.deepEqual(R.planungAnfrage(s, z, via(3), {}).anfrage.via.map((p) => p.breite), [40, 40.1, 40.2]);
  /* eine zu große Grenze von außen wird auf 25 gekappt */
  assert.equal(R.planungAnfrage(s, z, via(26), {}, 99).ok, false);
});

/* ---------- Aktivität: Reihenfolge und Grenze ---------- */
async function neu(kontoFn, bisDatum) {
  let n = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (n++) * 1000).toISOString() });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  if (kontoFn) { d.kontoAnfrageFn = kontoFn; await d.rcSchreiben({ kontoToken: 'tok', kontoEmail: 'a@example.org' }); }
  const fz = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Fahrzeug', hoehe: '3,1', breite: '2,3', laenge: '7,4', gesamtgewicht: '4500', achsen: '2' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'] })).id;
  const artId = (await d.aktivitaetsartenListe()).find((a) => a.aktuell.werte.bezeichnung === 'Urlaub').objekt.id;
  const orte = {};
  async function ort(name, b, l) { const r = await d.ortAnlegen({ bezeichnung: name, positionBreite: b === null ? '' : String(b), positionLaenge: l === null ? '' : String(l) }); assert.equal(r.ok, true, JSON.stringify(r)); orte[name] = r.id; return r.id; }
  /* Reihenfolge der Orte-Liste: Anfang, Bozen, Venedig, Florenz, Pisa, Parma, Mailand, Como, Ende */
  await ort('Anfang', 49.0, 9.0); await ort('Bozen', 46.5, 11.35); await ort('Venedig', 45.44, 12.33); await ort('Florenz', 43.77, 11.25); await ort('Pisa', 43.72, 10.4);
  await ort('Parma', 44.8, 10.33); await ort('Mailand', 45.46, 9.19); await ort('Como', 45.81, 9.08); await ort('Ende', 49.0, 9.0); await ort('Ohne', null, null);
  const basis = (extra) => Object.assign({ bezeichnung: 'Rundreise', artId, fahrzeugId: fz, vonDatum: '2027-09-01', vonZeit: '08:00', bisDatum: bisDatum || '2027-09-10', verantwortlichId: anna, startOrtId: orte.Anfang, zielOrtId: orte.Ende }, extra || {});
  return { d, fz, anna, artId, orte, basis };
}
const antwort = (body) => ({ ok: true, route: { punkte: [{ breite: body.von.breite, laenge: body.von.laenge }, { breite: 46, laenge: 10 }, { breite: body.nach.breite, laenge: body.nach.laenge }], laengeKm: 1900, dauerMin: 1500, warnungen: [] }, kontingent: { genutzt: 1, grenze: 10, stufe: 'test' } });

test('Zwischenziele bleiben in der Reihenfolge, in der sie gewählt wurden (nicht in der der Orte-Liste), ohne Doppelte und Unbekannte', async () => {
  const c = await neu();
  const o = c.orte, wunsch = [o.Mailand, o.Bozen, o.Pisa, o.Venedig, o.Bozen, 'unbekannt'];
  const r = await c.d.aktivitaetAnlegen(c.basis({ zwischenzielIds: wunsch }));
  assert.equal(r.ok, true, JSON.stringify(r));
  const a = await c.d.aktivitaetLaden(r.id);
  assert.deepEqual(a.aktuell.werte.zwischenzielIds, [o.Mailand, o.Bozen, o.Pisa, o.Venedig]);
  assert.deepEqual(a.zwischenziele.map((z) => z.name), ['Mailand', 'Bozen', 'Pisa', 'Venedig']);
  /* Umstellen und Speichern: die neue Reihenfolge gilt, der Verlauf zeigt die Änderung */
  const neuListe = [o.Venedig, o.Pisa, o.Bozen, o.Mailand];
  const g = await c.d.aktivitaetAendern(r.id, c.basis({ zwischenzielIds: neuListe }));
  assert.equal(g.ok, true, JSON.stringify(g)); assert.equal(g.geaendert, true);
  assert.deepEqual((await c.d.aktivitaetLaden(r.id)).aktuell.werte.zwischenzielIds, neuListe);
  /* gleiche Reihenfolge noch einmal: keine Änderung */
  assert.equal((await c.d.aktivitaetAendern(r.id, c.basis({ zwischenzielIds: neuListe }))).geaendert, false);
});

test('Grenze: so viele Zwischenziele wie Tage (Datumsspanne), höchstens 25; die Meldung nennt die Zahl', async () => {
  const c = await neu(null, '2027-09-03'); /* 3 Tage */
  const o = c.orte, vier = [o.Bozen, o.Venedig, o.Florenz, o.Pisa], drei = vier.slice(0, 3);
  const zuViel = await c.d.aktivitaetAnlegen(c.basis({ bisDatum: '2027-09-03', zwischenzielIds: vier }));
  assert.equal(zuViel.ok, false); assert.match(zuViel.fehler.zwischenzielIds, /höchstens 3 Zwischenziele.*3 Tage/);
  const passt = await c.d.aktivitaetAnlegen(c.basis({ bisDatum: '2027-09-03', zwischenzielIds: drei }));
  assert.equal(passt.ok, true, JSON.stringify(passt));
  /* längerer Zeitraum: 4 gehen */
  assert.equal((await c.d.aktivitaetAendern(passt.id, c.basis({ bisDatum: '2027-09-04', zwischenzielIds: vier }))).ok, true);
  /* Zeitraum wieder kürzer: das Speichern verlangt, Zwischenziele herauszunehmen */
  assert.equal((await c.d.aktivitaetAendern(passt.id, c.basis({ bisDatum: '2027-09-03', zwischenzielIds: vier }))).ok, false);
});

test('Grenze 25: die lange Reise mit mehr als 25 Tagen stößt an die 25', async () => {
  const c = await neu();
  const o = c.orte, namen = ['Bozen', 'Venedig', 'Florenz', 'Pisa', 'Parma', 'Mailand', 'Como'];
  /* 26 verschiedene Orte brauchen 26 Einträge: weitere Orte anlegen */
  const ids = namen.map((n) => o[n]);
  for (let i = 0; i < 19; i++) ids.push((await c.d.ortAnlegen({ bezeichnung: 'Ort ' + i, positionBreite: String(44 + i / 10), positionLaenge: String(9 + i / 10) })).id);
  assert.equal(ids.length, 26);
  const lang = { bisDatum: '2027-12-31' };
  const z26 = await c.d.aktivitaetAnlegen(c.basis(Object.assign({ zwischenzielIds: ids }, lang)));
  assert.equal(z26.ok, false); assert.match(z26.fehler.zwischenzielIds, /höchstens 25 Zwischenziele/);
  const z25 = await c.d.aktivitaetAnlegen(c.basis(Object.assign({ zwischenzielIds: ids.slice(0, 25) }, lang)));
  assert.equal(z25.ok, true, JSON.stringify(z25));
});

test('Rundreise von Sersheim: Start gleich Ziel, 7 Zwischenziele in fester Reihenfolge gehen genau so an die Planung', async () => {
  const aufrufe = [];
  const c = await neu(async (url, methode, token, body) => { aufrufe.push(body); return antwort(body); });
  const o = c.orte, reihe = [o.Bozen, o.Venedig, o.Florenz, o.Pisa, o.Parma, o.Mailand, o.Como];
  const r = await c.d.aktivitaetAnlegen(c.basis({ zielOrtId: o.Anfang, zwischenzielIds: reihe }));
  assert.equal(r.ok, true, JSON.stringify(r));
  const pl = await c.d.routePlanen(r.id);
  assert.equal(pl.ok, true, JSON.stringify(pl));
  assert.equal(aufrufe.length, 1);
  assert.deepEqual(aufrufe[0].via.map((p) => p.breite), [46.5, 45.44, 43.77, 43.72, 44.8, 45.46, 45.81]);
  assert.deepEqual(aufrufe[0].von, aufrufe[0].nach);
  /* umgestellt: die neue Reihenfolge geht an den Dienst */
  const rev = reihe.slice().reverse();
  assert.equal((await c.d.aktivitaetAendern(r.id, c.basis({ zielOrtId: o.Anfang, zwischenzielIds: rev }))).ok, true);
  assert.equal((await c.d.routePlanen(r.id)).ok, true);
  assert.deepEqual(aufrufe[1].via.map((p) => p.breite), [45.81, 45.46, 44.8, 43.72, 43.77, 45.44, 46.5]);
});

test('Planung der Aktivität prüft die Grenze nach Tagen: eine ältere Aktivität mit zu vielen Zwischenzielen wird nicht geplant, nichts geht zum Dienst', async () => {
  const aufrufe = [];
  const c = await neu(async (url, methode, token, body) => { aufrufe.push(body); return antwort(body); });
  const o = c.orte;
  const r = await c.d.aktivitaetAnlegen(c.basis({ bisDatum: '2027-09-10', zwischenzielIds: [o.Bozen, o.Venedig, o.Florenz] }));
  assert.equal(r.ok, true);
  const ra = await c.d.routeAnsicht(r.id);
  assert.equal(ra.planung.maxVia, 10); assert.deepEqual(ra.planung.fehler, []);
  /* Direkt in den Speicher geschrieben (wie eine ältere Aktivität): 3 Zwischenziele bei einem Tag */
  const eintrag = (await c.d.speicher.alle('verlaeufe')).filter((v) => v.objektTyp === 'aktivitaet' && v.objektId === r.id).sort((a, b) => b.nr - a.nr)[0];
  eintrag.werte.bisDatum = eintrag.werte.vonDatum; await c.d.speicher.speichern('verlaeufe', eintrag);
  const eng = await c.d.routeAnsicht(r.id);
  assert.equal(eng.planung.maxVia, 1); assert.match(eng.planung.fehler.join(' '), /höchstens 1 Zwischenziel möglich.*1 Tag/);
  const p = await c.d.routePlanen(r.id);
  assert.equal(p.ok, false); assert.equal(aufrufe.length, 0);
});

/* ---------- Je Tag: bis 10 Zwischenziele ---------- */
async function mitTagen(kontoFn) {
  const c = await neu(kontoFn, '2027-09-03');
  const r = await c.d.aktivitaetAnlegen(c.basis({ bisDatum: '2027-09-03', zwischenzielIds: [] }));
  assert.equal(r.ok, true, JSON.stringify(r));
  await c.d.tagesabschnitteVorbereiten(r.id);
  const lb = await c.d.logbuchLaden(r.id), tage = lb.abschnitte.map((x) => x.objekt.id);
  const wv = (datum, extra) => Object.assign({ datum, beginnZeit: '08:00', endeZeit: '12:00' }, extra || {});
  assert.equal((await c.d.abschnittAendern(tage[0], wv('2027-09-01', { startOrtId: c.orte.Anfang, zielOrtId: c.orte.Ende }))).ok, true);
  return Object.assign(c, { akt: r.id, tage });
}

test('Je Tag: bis zu 10 Zwischenziele in fester Reihenfolge; sie gehen genau so an den Dienst, eine Planung zählt 1 Route', async () => {
  const aufrufe = [];
  const c = await mitTagen(async (url, methode, token, body) => { aufrufe.push(body); return antwort(body); });
  const o = c.orte, tag = c.tage[0];
  const v = await c.d.tagRouteAnsicht(tag);
  assert.equal(v.planung.maxVia, 10); assert.deepEqual(v.planung.via, []);
  /* Zur Wahl: Orte mit Position (nicht „Ohne“), die des Reiseplans zuerst */
  assert.ok(v.planung.viaOptionen.some((x) => x.wert === o.Bozen)); assert.ok(!v.planung.viaOptionen.some((x) => x.wert === o.Ohne));
  const wahl = [o.Mailand, o.Bozen, o.Pisa];
  const s = await c.d.tagViaSetzen(tag, wahl);
  assert.equal(s.ok, true, JSON.stringify(s)); assert.equal(s.anzahl, 3);
  assert.deepEqual((await c.d.tagRouteAnsicht(tag)).planung.via.map((x) => x.name), ['Mailand', 'Bozen', 'Pisa']);
  const p = await c.d.tagRoutePlanen(tag);
  assert.equal(p.ok, true, JSON.stringify(p)); assert.equal(aufrufe.length, 1);
  assert.deepEqual(aufrufe[0].via.map((x) => x.breite), [45.46, 46.5, 43.72]);
  const nach = await c.d.tagRouteAnsicht(tag);
  assert.equal(nach.route.veraltet, false); assert.deepEqual(nach.route.viaNamen, ['Mailand', 'Bozen', 'Pisa']);
  /* die Wahl bleibt nach der Planung im selben Dokument */
  assert.deepEqual((await c.d.einstellungLesen('tagroute-' + tag)).viaOrtIds, wahl);
  /* Reihenfolge ändern: die Route gilt als veraltet, bis neu geplant wird */
  assert.equal((await c.d.tagViaSetzen(tag, [o.Pisa, o.Bozen, o.Mailand])).ok, true);
  assert.equal((await c.d.tagRouteAnsicht(tag)).route.veraltet, true);
  assert.equal((await c.d.tagRoutePlanen(tag)).ok, true);
  assert.deepEqual(aufrufe[1].via.map((x) => x.breite), [43.72, 46.5, 45.46]);
  assert.equal((await c.d.tagRouteAnsicht(tag)).route.veraltet, false);
  /* Alle Zwischenziele entfernen: wieder nur Start und Ziel */
  assert.equal((await c.d.tagViaSetzen(tag, [])).ok, true);
  assert.equal((await c.d.tagRoutePlanen(tag)).ok, true); assert.deepEqual(aufrufe[2].via, []);
});

test('Je Tag: höchstens 10, nur Orte mit Position, Doppelte entfallen, nichts wird halb gespeichert', async () => {
  const c = await mitTagen(async (url, methode, token, body) => antwort(body));
  const tag = c.tage[0], o = c.orte;
  const viele = [];
  for (let i = 0; i < 11; i++) viele.push((await c.d.ortAnlegen({ bezeichnung: 'Halt ' + i, positionBreite: String(44 + i / 10), positionLaenge: String(9 + i / 10) })).id);
  const elf = await c.d.tagViaSetzen(tag, viele);
  assert.equal(elf.ok, false); assert.match(elf.fehler.allgemein, /höchstens 10 Zwischenziele/);
  assert.equal(await c.d.einstellungLesen('tagroute-' + tag), null);
  const zehn = await c.d.tagViaSetzen(tag, viele.slice(0, 10));
  assert.equal(zehn.ok, true, JSON.stringify(zehn)); assert.equal(zehn.anzahl, 10);
  const ohnePos = await c.d.tagViaSetzen(tag, [o.Ohne]);
  assert.equal(ohnePos.ok, false); assert.match(ohnePos.fehler.allgemein, /Position/);
  assert.equal((await c.d.einstellungLesen('tagroute-' + tag)).viaOrtIds.length, 10, 'der alte Stand bleibt');
  const doppelt = await c.d.tagViaSetzen(tag, [o.Bozen, o.Bozen, o.Pisa]);
  assert.equal(doppelt.ok, true); assert.equal(doppelt.anzahl, 2);
  assert.equal((await c.d.tagViaSetzen('gibt-es-nicht', [o.Bozen])).ok, false);
});

test('Je Tag: Start gleich Ziel geht mit Zwischenziel (Rundfahrt), ohne nicht; die Karte des Tages zeigt die Zwischenziele mit Nummer', async () => {
  const aufrufe = [];
  const c = await mitTagen(async (url, methode, token, body) => { aufrufe.push(body); return antwort(body); });
  const tag = c.tage[0], o = c.orte;
  assert.equal((await c.d.abschnittAendern(tag, { datum: '2027-09-01', beginnZeit: '08:00', endeZeit: '12:00', startOrtId: o.Anfang, zielOrtId: o.Anfang })).ok, true);
  const ohne = await c.d.tagRouteAnsicht(tag);
  assert.match(ohne.planung.fehler.join(' '), /derselbe Ort/);
  assert.equal((await c.d.tagRoutePlanen(tag)).ok, false); assert.equal(aufrufe.length, 0);
  assert.equal((await c.d.tagViaSetzen(tag, [o.Bozen, o.Como])).ok, true);
  assert.deepEqual((await c.d.tagRouteAnsicht(tag)).planung.fehler, []);
  assert.equal((await c.d.tagRoutePlanen(tag)).ok, true);
  const kd = await c.d.tagKartenDaten(tag);
  assert.equal(kd.ok, true);
  const zw = kd.planOrte.filter((p) => p.rolle === 'zwischen');
  assert.deepEqual(zw.map((p) => [p.nr, p.name]), [[1, 'Bozen'], [2, 'Como']]);
  assert.deepEqual(kd.planOrte.map((p) => p.rolle), ['start', 'ziel', 'zwischen', 'zwischen']);
});

test('Karte der Aktivität: Zwischenziele tragen ihre Nummer in der Reihenfolge der Fahrt', async () => {
  const c = await neu();
  const o = c.orte, r = await c.d.aktivitaetAnlegen(c.basis({ zwischenzielIds: [o.Como, o.Bozen, o.Ohne] }));
  assert.equal(r.ok, true, JSON.stringify(r));
  const kd = await c.d.kartenDaten(r.id, 0);
  assert.deepEqual(kd.planOrte.filter((p) => p.rolle === 'zwischen').map((p) => [p.nr, p.name]), [[1, 'Como'], [2, 'Bozen']]);
});

/* ---------- Dienst ---------- */
dienstTest('Dienst: bis 25 Zwischenziele gehen in dieser Reihenfolge an HERE, 26 werden mit 400 abgelehnt und nicht gezählt', async () => {
  const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
  const { neuerR2 } = require('./hilfen/r2-attrappe.js');
  const APP = 'https://app.example.org';
  const dienst = await import('../server/konto-dienst.mjs');
  assert.equal(dienst.VERSION, '13h');
  const env = { DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1', HERE_SCHLUESSEL: 'here-schluessel-1' };
  const u = { t: Date.UTC(2026, 10, 15, 12, 0, 0) }; u.jetzt = () => u.t;
  const aufrufe = [];
  const holen = async (url) => { aufrufe.push(url); return new Response(JSON.stringify({ routes: [{ id: 'x', sections: [{ id: 's', polyline: 'BFoz5xJ67i1B1B7PzIhaxL7Y', summary: { length: 12345, duration: 1500 } }] }] }), { status: 200 }); };
  async function ruf(methode, weg, body, token) {
    const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
    if (body !== undefined) kopf['Content-Type'] = 'application/json';
    if (token) kopf.Authorization = 'Bearer ' + token;
    const r = await dienst.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt, fetch: holen });
    return { status: r.status, json: await r.json() };
  }
  u.t += 13 * 60 * 1000;
  const a = await ruf('POST', '/konto/code-anfordern', { email: 'a@example.org' });
  const b = await ruf('POST', '/konto/code-pruefen', { email: 'a@example.org', code: a.json.entwicklungsCode, geraet: 'Test #01234567' });
  assert.equal(b.status, 200, JSON.stringify(b.json));
  const n = env.DB.roh.prepare('SELECT id FROM nutzer WHERE email = ?').get('a@example.org');
  env.DB.roh.prepare('INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) VALUES (?, ?, ?, ?)').run(n.id, 'mittel', null, 1);
  const via = (k) => Array.from({ length: k }, (_, i) => ({ breite: 40 + i / 100, laenge: 9 + i / 100 }));
  const basis = { von: { breite: 48.9, laenge: 9.1 }, nach: { breite: 48.9, laenge: 9.1 }, fahrzeug: { hoehe: 3.1, breite: 2.3, laenge: 7.4, gesamtgewicht: 4500, achsen: 2 } };
  const ok = await ruf('POST', '/route/planen', Object.assign({ via: via(25) }, basis), b.json.token);
  assert.equal(ok.status, 200, JSON.stringify(ok.json));
  assert.equal(aufrufe.length, 1);
  const q = new URL(aufrufe[0]).searchParams.getAll('via');
  assert.equal(q.length, 25); assert.equal(q[0], '40,9'); assert.equal(q[24], '40.24,9.24');
  assert.ok(aufrufe[0].length < 3000, 'Länge der Anfrage ' + aufrufe[0].length);
  const zuviel = await ruf('POST', '/route/planen', Object.assign({ via: via(26) }, basis), b.json.token);
  assert.equal(zuviel.status, 400); assert.equal(zuviel.json.feld, 'via'); assert.match(zuviel.json.error, /höchstens 25/);
  assert.equal(aufrufe.length, 1, 'bei 26 wird HERE nicht gefragt');
});

/* ---------- Einbau ---------- */
test('Einbau: Version 2.0.123 überall, Neuerungen, Changelog, Anleitung; Oberfläche und Stil', () => {
  assert.equal(MM.VERSION, '2.0.123'); assert.equal(MM.Texte.NEUERUNGEN[0].version, '2.0.123');
  assert.match(MM.Texte.NEUERUNGEN[0].punkte.join(' '), /Hoch.*Runter/); assert.match(MM.Texte.NEUERUNGEN[0].punkte.join(' '), /Route des Tages/);
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.123';"));
  assert.equal(JSON.parse(lesen('package.json')).version, '2.0.123');
  const l = JSON.parse(lesen('package-lock.json')); assert.equal(l.version, '2.0.123'); assert.equal(l.packages[''].version, '2.0.123');
  assert.ok(lesen('README.md').includes('Version 2.0.123'));
  assert.ok(lesen('CHANGELOG.md').startsWith('# Änderungen\n\n## 2.0.123'));
  assert.match(lesen('server/EINRICHTUNG.md'), /Update 2\.0\.123: bis zu 25 Zwischenziele/);
  const a = lesen('js/ansicht.js');
  ['reihenfolgeElement', "f.typ === 'reihenfolge'", "typ: 'reihenfolge'", 'Zwischenziele speichern', 'tagViaSetzen', "'data-rf': 'hoch-'", "'data-rf': 'runter-'"].forEach((s) => assert.ok(a.includes(s), s));
  assert.ok(lesen('css/styles.css').includes('.reihenfolge-liste'));
  assert.ok(lesen('js/kartenansicht.js').includes('o.nr'));
  assert.ok(!/Peilung/.test(['ansicht', 'daten', 'logbuch', 'texte'].map((m) => lesen('js/' + m + '.js')).join('\n') + lesen('css/styles.css')), 'das Wort Peilung steht nirgends');
});
