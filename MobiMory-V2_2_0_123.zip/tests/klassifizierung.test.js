'use strict';
/* 2.0.103: Klassifizierung der Fahrzeuge (Einordnung, neue Arten, Größenklasse, Eignungsliste, Zugfahrzeuge und Boote)
   und die beiden Änderungen an der Cockpit-Anzeige. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte',
  'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM, F = MM.Fahrzeugarten;
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

async function neu(speicher) {
  let t = 0;
  const d = new MM.Daten.Daten(speicher || new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 17, 9, 0, t++)).toISOString() });
  await d.starten();
  return d;
}
const keys = id => F.felder(id).map(f => f.key);

/* ---------- Größenklasse ---------- */
test('Größenklasse: Klein bis 6 m, Mittel bis 9 m, Groß bis unter 15 m, Sehr groß ab 15 m, gerechnet aus der Länge', () => {
  const g = (l, art) => { const k = F.groessenklasse(art || 'motorboot', l); return k && k.name; };
  assert.equal(g(4.2), 'Klein'); assert.equal(g(6), 'Klein'); assert.equal(g(6.01), 'Mittel');
  assert.equal(g(9), 'Mittel'); assert.equal(g(9.01), 'Groß'); assert.equal(g(14.99), 'Groß');
  assert.equal(g(15), 'Sehr groß'); assert.equal(g(32), 'Sehr groß');
  assert.equal(g('10,5'), 'Groß', 'Text mit Komma');
});

test('Größenklasse: nur für Wasserfahrzeuge mit Länge, nicht für das Beiboot', () => {
  assert.equal(F.groessenklasse('motorboot', null), null);
  assert.equal(F.groessenklasse('motorboot', ''), null);
  assert.equal(F.groessenklasse('motorboot', 0), null);
  assert.equal(F.groessenklasse('beiboot', 3), null, 'Beiboote gehören nicht zu den Größenklassen');
  assert.equal(F.groessenklasse('wohnmobil', 7), null, 'an Land gibt es keine Größenklasse');
  assert.equal(F.groessenklasse('gibt-es-nicht', 7), null);
  assert.equal(F.groessenklasse('segelboot-monohull', 10).name, 'Groß', 'auch Untergruppen');
});

/* ---------- Arten und Felder ---------- */
test('Neue Arten: Land und Wasser sind da, alte Arten bleiben gültig', () => {
  ['transporter', 'lkw', 'anhaenger', 'bootstrailer', 'zeltanhaenger', 'motorboot', 'schlauchboot', 'jetski', 'hausboot', 'beiboot', 'paddelboot', 'wasser-sonstiges']
    .forEach(id => assert.ok(F.art(id), id));
  ['auto', 'motorrad', 'wohnmobil', 'wohnwagen', 'oldtimer', 'boot', 'sportboot', 'wasserskiboot', 'wohnboot', 'motorschiff', 'segelboot', 'flugzeug']
    .forEach(id => assert.ok(F.art(id), 'alt: ' + id));
  assert.equal(F.art('anhaenger').welt, 'land'); assert.equal(F.art('beiboot').welt, 'wasser');
});

test('Einordnung: Antrieb, Zustand, Auslegung und Eignung bei Land und Wasser, bei der Luft nur der Antrieb', () => {
  ['auto', 'wohnmobil', 'transporter', 'lkw', 'motorrad', 'motorboot', 'beiboot', 'segelboot'].forEach(id =>
    ['antrieb', 'zustand', 'auslegung', 'eignung'].forEach(k => assert.ok(keys(id).includes(k), id + ' ' + k)));
  assert.ok(keys('flugzeug').includes('antrieb'));
  ['zustand', 'auslegung', 'eignung', 'aufbau'].forEach(k => assert.ok(!keys('flugzeug').includes(k), 'Luft ' + k));
});

test('Aufbau gibt es bei Wohnmobil und Auto mit eigenen Auswahlen, sonst nicht', () => {
  const opt = (art) => F.felder(art).find(f => f.key === 'aufbau').optionen;
  assert.ok(opt('wohnmobil').includes('Alkoven') && opt('wohnmobil').includes('Vollintegriert'));
  assert.ok(opt('auto').includes('Kombi') && !opt('auto').includes('Alkoven'));
  assert.ok(!keys('motorboot').includes('aufbau'));
});

test('Zuglast und Stützlast bei Zugfahrzeugen; Anhänger kennen ihre Zugfahrzeuge, nur der Bootstrailer seine Boote', () => {
  ['auto', 'wohnmobil', 'transporter', 'lkw'].forEach(id => ['zuglast', 'stuetzlast'].forEach(k => assert.ok(keys(id).includes(k), id + ' ' + k)));
  ['wohnwagen', 'anhaenger', 'bootstrailer', 'zeltanhaenger'].forEach(id => {
    assert.ok(keys(id).includes('zugfahrzeuge'), id); assert.ok(keys(id).includes('stuetzlast'), id); assert.ok(!keys(id).includes('zuglast'), id + ' zieht nichts');
  });
  assert.ok(keys('bootstrailer').includes('bootsliste'));
  assert.ok(!keys('anhaenger').includes('bootsliste') && !keys('zeltanhaenger').includes('bootsliste') && !keys('wohnwagen').includes('bootsliste'));
  assert.ok(!keys('auto').includes('zugfahrzeuge'));
});

test('Eigene Arten erben die neuen Felder von der Obergruppe', async () => {
  const d = await neu();
  const r = await d.fahrzeugartAnlegen({ name: 'Trimaran', eltern: 'segelboot' });
  assert.deepEqual(keys(r.id), keys('boot'));
  assert.ok(keys(r.id).includes('eignung'));
});

test('Vorbelegung nach Art: Anhänger ohne Antrieb, Eignung nach der Bootsart, nur Punkte, die es für die Art gibt', () => {
  assert.equal(F.vorgabe('bootstrailer').antrieb, 'ohne');
  assert.equal(F.vorgabe('paddelboot').antrieb, 'ohne');
  assert.equal(F.vorgabe('auto').antrieb, undefined);
  assert.deepEqual(F.vorgabe('wohnmobil').eignung, ['uebernachten', 'kochen', 'bad_wc']);
  assert.deepEqual(F.vorgabe('segelboot-katamaran').eignung, ['segeln'], 'Untergruppe nimmt die Vorgabe der Obergruppe');
  assert.deepEqual(F.vorgabe('wasserskiboot').eignung, ['wasserski']);
  assert.deepEqual(F.vorgabe('lkw').eignung, undefined);
  assert.deepEqual(F.vorgabe('bootstrailer').eignung, ['transport']);
});

/* ---------- Eignungsliste ---------- */
test('Eignungsliste: Land, Wasser und Anhänger bekommen jeweils die passenden Punkte', () => {
  const w = a => F.eignungListe(a).map(e => e.wert);
  assert.ok(w('auto').includes('anhaenger_ziehen') && w('auto').includes('gelaende') && !w('auto').includes('segeln'));
  assert.ok(!w('wohnwagen').includes('anhaenger_ziehen'), 'ein Anhänger zieht keinen Anhänger');
  assert.ok(w('wohnwagen').includes('uebernachten'));
  assert.ok(w('segelboot').includes('segeln') && w('segelboot').includes('wasserski') && w('segelboot').includes('beiboot_mitfuehren') && !w('segelboot').includes('gelaende'));
  assert.ok(w('bootstrailer').includes('transport'));
  assert.deepEqual(F.eignungListe('flugzeug'), []);
  assert.ok(F.eignungListe('auto').every(e => e.vorgegeben && !e.eigen));
});

test('Eigener Punkt: Merkzettel, nicht für Aktivitäten, taucht in der Liste der Art auf und übersteht Speichern und Neustart', async () => {
  const sp = new MM.Speicher.MemorySpeicher();
  const d = await neu(sp);
  const r = await d.eignungAnlegen('  Hundetauglich ');
  assert.ok(r.ok, JSON.stringify(r)); assert.equal(r.vorgabe, false);
  const e = F.eignungListe('auto').find(x => x.wert === r.id);
  assert.equal(e.label, 'Hundetauglich'); assert.equal(e.eigen, true); assert.equal(e.vorgegeben, false);
  assert.equal(F.eignungFuerAktivitaeten(r.id), false);
  assert.equal(F.eignungFuerAktivitaeten('segeln'), true);
  assert.ok(F.felder('motorboot').find(f => f.key === 'eignung').optionen.some(o => o.wert === r.id), 'auch bei der Art Wasser');
  const d2 = await neu(sp);
  assert.ok(F.eignungListe('auto').some(x => x.wert === r.id && x.label === 'Hundetauglich'), 'nach dem Neustart noch da');
  assert.equal(F.eignungFuerAktivitaeten(r.id), false);
  void d2;
});

test('Punkt eines Entwicklers oder Admins ist sofort ein Punkt der MobiMory-Liste und für Aktivitäten verwendbar', async () => {
  const d = await neu();
  await d.rcSchreiben({ kontoToken: 'test', kontoEmail: 'a@b.c', rolle: 'entwickler' });
  const r = await d.eignungAnlegen('Hundetauglich');
  assert.ok(r.ok); assert.equal(r.vorgabe, true);
  const e = F.eignungListe('auto').find(x => x.wert === r.id);
  assert.equal(e.vorgegeben, true); assert.equal(e.eigen, false);
  assert.equal(F.eignungFuerAktivitaeten(r.id), true);
  assert.ok(F.eignungListe('auto').findIndex(x => x.wert === r.id) < F.eignungListe('auto').length, 'steht in der Liste');
  const o = F.felder('auto').find(f => f.key === 'eignung').optionen.find(x => x.wert === r.id);
  assert.equal(o.label, 'Hundetauglich', 'ohne den Zusatz „eigener Punkt“');
});

test('Eigener Punkt: leer, zu lang und doppelt werden abgelehnt (auch gegen die Vorgaben, ohne auf Groß und Klein zu achten)', async () => {
  const d = await neu();
  assert.ok((await d.eignungAnlegen('   ')).fehler.name.includes('Namen'));
  assert.ok((await d.eignungAnlegen('x'.repeat(61))).fehler.name.includes('60'));
  assert.ok((await d.eignungAnlegen('angeln')).fehler.name.includes('schon'));
  assert.ok((await d.eignungAnlegen('Hundetauglich')).ok);
  assert.ok((await d.eignungAnlegen('HUNDETAUGLICH')).fehler.name.includes('schon'));
});

test('Das Dokument der Arten bleibt ohne eigene Punkte unverändert (nichts Neues in alten Sicherungen)', async () => {
  const d = await neu();
  assert.equal(Object.prototype.hasOwnProperty.call(F.dokument(), 'eignung'), false);
  await d.eignungAnlegen('Hundetauglich');
  assert.equal(F.dokument().eignung.length, 1);
});

/* ---------- Anlegen und Prüfen ---------- */
test('Fahrzeug mit Einordnung anlegen und ändern; die Eignung bleibt in der Reihenfolge der Liste', async () => {
  const d = await neu();
  const r = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'WoMo', antrieb: 'mit', zustand: 'gebraucht', auslegung: 'beides', aufbau: 'Teilintegriert',
    eignung: ['kochen', 'uebernachten', 'gibt-es-nicht'], zuglast: '1500', stuetzlast: '75' });
  assert.ok(r.ok, JSON.stringify(r));
  const w = (await d.fahrzeugLaden(r.id)).aktuell.werte;
  assert.equal(w.antrieb, 'mit'); assert.equal(w.zustand, 'gebraucht'); assert.equal(w.auslegung, 'beides'); assert.equal(w.aufbau, 'Teilintegriert');
  assert.deepEqual(w.eignung, ['uebernachten', 'kochen'], 'Unbekanntes fällt weg, Reihenfolge nach der Liste');
  assert.equal(w.zuglast, 1500); assert.equal(w.stuetzlast, 75);
  const a = await d.fahrzeugAendern(r.id, { bezeichnung: 'WoMo', antrieb: 'mit', eignung: ['uebernachten', 'kochen', 'bad_wc'] });
  assert.ok(a.ok && a.geaendert);
  const v = (await d.fahrzeugLaden(r.id)).verlauf[0].aenderungen.find(x => x.key === 'eignung');
  assert.equal(MM.Hilfen.wert(v.feld, v.neu), 'Übernachten, Kochen, Bad und WC');
});

test('Ungültige Auswahl bei Antrieb, Zustand und Auslegung wird abgelehnt', async () => {
  const d = await neu();
  const r = await d.fahrzeugAnlegen('auto', { bezeichnung: 'A', antrieb: 'halb', zustand: 'kaputt', auslegung: 'viel' });
  assert.equal(r.ok, false);
  ['antrieb', 'zustand', 'auslegung'].forEach(k => assert.ok(r.fehler[k], k));
});

test('Anhänger ziehen geht nur mit Antrieb', async () => {
  const d = await neu();
  const schlecht = await d.fahrzeugAnlegen('auto', { bezeichnung: 'A', antrieb: 'ohne', eignung: ['anhaenger_ziehen'] });
  assert.equal(schlecht.ok, false); assert.ok(schlecht.fehler.eignung.includes('mit Antrieb'));
  assert.ok((await d.fahrzeugAnlegen('auto', { bezeichnung: 'B', antrieb: 'mit', eignung: ['anhaenger_ziehen'] })).ok);
  assert.ok((await d.fahrzeugAnlegen('auto', { bezeichnung: 'C', eignung: ['anhaenger_ziehen'] })).ok, 'ohne Angabe zum Antrieb gilt nichts dagegen');
});

test('Zugfahrzeuge: nur eigene Landfahrzeuge, kein Anhänger, nicht abgegeben; Boote nur Wasserfahrzeuge', async () => {
  const d = await neu();
  const auto = (await d.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' })).id;
  const lkw = (await d.fahrzeugAnlegen('lkw', { bezeichnung: 'Lkw' })).id;
  const boot = (await d.fahrzeugAnlegen('motorboot', { bezeichnung: 'Boot' })).id;
  const beiboot = (await d.fahrzeugAnlegen('beiboot', { bezeichnung: 'Dinghy' })).id;
  const wagen = (await d.fahrzeugAnlegen('wohnwagen', { bezeichnung: 'Wagen' })).id;
  const trailer = await d.fahrzeugAnlegen('bootstrailer', { bezeichnung: 'Trailer', zugfahrzeuge: [auto, lkw, auto, ' '], bootsliste: [boot, beiboot] });
  assert.ok(trailer.ok, JSON.stringify(trailer));
  const w = (await d.fahrzeugLaden(trailer.id)).aktuell.werte;
  assert.deepEqual(w.zugfahrzeuge, [auto, lkw], 'Doppelte und Leere fallen weg');
  assert.deepEqual(w.bootsliste, [boot, beiboot]);
  /* falsche Welt oder Anhänger als Zugfahrzeug */
  assert.ok((await d.fahrzeugAnlegen('anhaenger', { bezeichnung: 'X', zugfahrzeuge: [boot] })).fehler.zugfahrzeuge.includes('Landfahrzeuge'));
  assert.ok((await d.fahrzeugAnlegen('anhaenger', { bezeichnung: 'X', zugfahrzeuge: [wagen] })).fehler.zugfahrzeuge.includes('Landfahrzeuge'), 'ein Anhänger zieht keinen Anhänger');
  assert.ok((await d.fahrzeugAnlegen('bootstrailer', { bezeichnung: 'X', bootsliste: [auto] })).fehler.bootsliste.includes('kein Boot'));
  assert.ok((await d.fahrzeugAnlegen('anhaenger', { bezeichnung: 'X', zugfahrzeuge: ['fz-gibt-es-nicht'] })).fehler.zugfahrzeuge.includes('nicht gefunden'));
  /* nicht zu sich selbst */
  assert.ok((await d.fahrzeugAendern(trailer.id, { bezeichnung: 'Trailer', zugfahrzeuge: [trailer.id] })).fehler.zugfahrzeuge.includes('sich selbst'));
  /* abgegeben */
  await d.fahrzeugAbgeben(lkw, { datum: '2026-11-10', grund: 'verkauft' });
  assert.ok((await d.fahrzeugAnlegen('anhaenger', { bezeichnung: 'X', zugfahrzeuge: [lkw] })).fehler.zugfahrzeuge.includes('abgegeben'));
  /* ein schon eingetragenes, später abgegebenes Fahrzeug stört das Speichern nicht (geprüft wird nur, was neu ist) */
  assert.ok((await d.fahrzeugAendern(trailer.id, { bezeichnung: 'Trailer 2', zugfahrzeuge: [auto, lkw], bootsliste: [boot, beiboot] })).ok);
});

test('Auswahl für die Listen: ohne das Fahrzeug selbst, Zugfahrzeuge nur Land ohne Anhänger, Boote nur Wasser', async () => {
  const d = await neu();
  const auto = (await d.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' })).id;
  const wagen = (await d.fahrzeugAnlegen('wohnwagen', { bezeichnung: 'Wagen' })).id;
  const boot = (await d.fahrzeugAnlegen('motorboot', { bezeichnung: 'Boot' })).id;
  const a = await d.fahrzeugListenAuswahl(wagen);
  assert.deepEqual(a.zugfahrzeuge.map(x => x.wert), [auto]);
  assert.deepEqual(a.bootsliste.map(x => x.wert), [boot]);
  assert.ok(a.zugfahrzeuge[0].label.includes('Auto') && a.zugfahrzeuge[0].label.includes('(Auto)'));
});

test('Im Verlauf stehen bei den Listen die Namen der Fahrzeuge, nicht ihre Kennungen', async () => {
  const d = await neu();
  const auto = (await d.fahrzeugAnlegen('auto', { bezeichnung: 'Familienkutsche' })).id;
  const t = (await d.fahrzeugAnlegen('anhaenger', { bezeichnung: 'Hänger' })).id;
  await d.fahrzeugAendern(t, { bezeichnung: 'Hänger', zugfahrzeuge: [auto] });
  const u = (await d.fahrzeugLaden(t)).verlauf[0].aenderungen.find(x => x.key === 'zugfahrzeuge');
  assert.equal(MM.Hilfen.wert(u.feld, u.neu), 'Familienkutsche');
  assert.equal(MM.Hilfen.wert(u.feld, u.alt), null);
});

test('Namen aller Fahrzeuge, abgegebene gekennzeichnet', async () => {
  const d = await neu();
  const a = (await d.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' })).id;
  const b = (await d.fahrzeugAnlegen('lkw', { bezeichnung: 'Lkw' })).id;
  await d.fahrzeugAbgeben(b, { datum: '2026-11-10', grund: 'verkauft' });
  const m = await d.fahrzeugNamen();
  assert.deepEqual(m[a], { name: 'Auto', abgegeben: false });
  assert.deepEqual(m[b], { name: 'Lkw', abgegeben: true });
});

test('Listen von Fahrzeugen und die Eignung stehen nicht in Import und Export; Hilfen.wert zeigt keine Kennungen', async () => {
  const d = await neu();
  const ziele = (await d.importZielfelder('bootstrailer')).map(z => z.key);
  assert.ok(!ziele.includes('zugfahrzeuge') && !ziele.includes('bootsliste') && !ziele.includes('eignung'));
  assert.ok(ziele.includes('antrieb') && ziele.includes('zustand'));
  assert.equal(MM.Hilfen.wert(F.felder('anhaenger').find(f => f.key === 'zugfahrzeuge'), ['fz-1']), null);
});

test('Bei der Übergabe an einen anderen Datenraum fallen Zugfahrzeuge und Boote weg wie „Gehört zu“', () => {
  const daten = lesen('js/daten.js');
  assert.ok(/delete w\.hauptfahrzeugId; delete w\.zugfahrzeuge; delete w\.bootsliste;/.test(daten));
  assert.equal((daten.match(/delete w\.zugfahrzeuge/g) || []).length, 2, 'bei der Übergabedatei und bei geliehenen Fahrzeugen');
});

/* ---------- Cockpit ---------- */
test('Cockpit: der Fahrzeugname steht nicht noch einmal daneben, wenn er schon im Titel steht', () => {
  const n = MM.Hilfen.nameSchonDrin;
  assert.equal(n('Arbeit Man TGS 18460 17.11.2026', 'Man TGS 18460'), true);
  assert.equal(n('Arbeit MAN  TGS 18460 17.11.2026', 'man tgs 18460'), true, 'Groß und Klein, doppelte Leerzeichen');
  assert.equal(n('Urlaub am Meer', 'Man TGS 18460'), false, 'ein selbst gewählter Name zeigt das Fahrzeug weiter');
  assert.equal(n('Urlaub am Meer', ''), false); assert.equal(n('Urlaub', null), false); assert.equal(n(null, 'X'), false);
  const a = lesen('js/ansicht.js');
  assert.ok(a.includes("MM.Hilfen.nameSchonDrin(w.bezeichnung, a.fahrzeug.name) ? null : h('span', { class: 'frist-info', text: a.fahrzeug.name })"));
});

test('Cockpit: die Motorstunden stehen ohne Klammer mit Quelle und Datum, „kein Stand“ bleibt', () => {
  const a = lesen('js/ansicht.js');
  const start = a.indexOf('  function zaehlerKurz(');
  const f = a.slice(start, a.indexOf('\n  }\n', start));
  assert.ok(!/quelleText|datum\(/.test(f), 'keine Quelle und kein Datum mehr im Cockpit');
  assert.ok(f.includes("'kein Stand'") && f.includes("'noch kein Stand'"));
  assert.ok(f.includes('zahlMit(x.wert, x.einheit)'));
  /* Quelle und Datum bleiben auf der Seite der Motoren */
  assert.ok(a.includes("MM.Motoren.quelleText(strecke.stand.quelle, true)"));
});

/* ---------- Formular ---------- */
test('Formular: Mehrfachwahl wird als Liste gelesen, Vorbelegung nach der Art, eigener Punkt ergänzen', () => {
  const a = lesen('js/ansicht.js');
  assert.ok(a.includes("if (el.type === 'checkbox') { haken[el.name]"));
  assert.ok(a.includes('function vorbelegen(artId)') && a.includes('vorbelegen(a.id);'));
  assert.ok(a.includes('function eignungErgaenzen()') && a.includes('daten.eignungAnlegen(eingabe.value)'));
  assert.ok(a.includes("if (f.typ === 'fahrzeuge') f = Object.assign({}, f, { optionen: listenAuswahl[f.key] || [] });"));
  assert.ok(a.includes("var gk = MM.Fahrzeugarten.groessenklasse(a.id, w.laenge);"));
});
