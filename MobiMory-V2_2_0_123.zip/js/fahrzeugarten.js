/*
 * Fahrzeugarten und ihre Felder.
 *
 * Die Felder sind hier als DATEN beschrieben, nicht in der Oberfläche
 * festverdrahtet. So kann später eine vom Nutzer zusammengestellte
 * Fahrzeugart (zum Beispiel ein Monowheel) auf demselben Weg entstehen:
 * Sie ist dann nur eine weitere Liste von Feldern.
 *
 * Schale 1 = Fahrzeugliste (Bezeichnung, Art, Kennung)
 * Schale 2 = Äußere Hülle (alle Felder unten)
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var KRAFTSTOFFE = ['Benzin', 'Diesel', 'Autogas (LPG)', 'Erdgas (CNG)',
    'Elektro', 'Hybrid', 'Wasserstoff', 'Sonstiger'];

  var GRUPPEN = [
    { id: 'fahrzeug', titel: 'Fahrzeug' },
    { id: 'einordnung', titel: 'Einordnung und Eignung' },
    { id: 'masse', titel: 'Maße' },
    { id: 'gewichte', titel: 'Gewichte' },
    { id: 'antrieb', titel: 'Kraftstoff und Geschwindigkeit' },
    { id: 'strasse', titel: 'Achsen und Maut' },
    { id: 'zuordnung', titel: 'Zugfahrzeuge und Ladung' },
    { id: 'versicherung', titel: 'Versicherung' }
  ];

  /*
   * Einordnung (seit 2.0.103): Antrieb, Zustand, Auslegung und Eignung gelten für fast jede Art; die Größenklasse wird aus der Länge gerechnet
   * und nicht gespeichert. Die Eignung ist eine offene Liste: vorgegebene MobiMory-Punkte (für Aktivitäten verwendbar) und eigene Punkte des
   * Nutzers (nur Merkzettel beim Fahrzeug). Legt ein Entwickler oder Admin einen Punkt an, ist er sofort ein vorgegebener Punkt.
   */
  var AUFBAU_WOHNMOBIL = ['Alkoven', 'Teilintegriert', 'Vollintegriert', 'Kastenwagen / Van', 'Sonstiger'];
  var AUFBAU_PKW = ['Limousine', 'Kombi', 'SUV / Geländewagen', 'Kleinwagen', 'Cabrio / Coupé', 'Van / Bus', 'Sonstiger'];

  /* welten: wo der Punkt angeboten wird. kurz: Beschriftung bei der Vorbelegung. */
  var EIGNUNG = [
    { wert: 'anhaenger_ziehen', label: 'Anhänger ziehen', welten: ['land'], nurMitAntrieb: true },
    { wert: 'traeger', label: 'Dach- oder Heckträger', welten: ['land'] },
    { wert: 'gelaende', label: 'Geländetauglich', welten: ['land'] },
    { wert: 'winter', label: 'Wintertauglich', welten: ['land'] },
    { wert: 'uebernachten', label: 'Übernachten', welten: ['land', 'wasser'] },
    { wert: 'kochen', label: 'Kochen', welten: ['land', 'wasser'] },
    { wert: 'bad_wc', label: 'Bad und WC', welten: ['land', 'wasser'] },
    { wert: 'beiboot_mitfuehren', label: 'Beiboot mitführen', welten: ['wasser'] },
    { wert: 'transport', label: 'Boot oder Fahrzeug transportieren', welten: ['land'] },
    { wert: 'wasserski', label: 'Wasserski oder Wakeboard', welten: ['wasser'] },
    { wert: 'angeln', label: 'Angeln', welten: ['wasser'] },
    { wert: 'tauchen', label: 'Tauchen', welten: ['wasser'] },
    { wert: 'segeln', label: 'Segeln', welten: ['wasser'] },
    { wert: 'anlanden', label: 'Anlanden und Übersetzen', welten: ['wasser'] }
  ];

  /* Vorbelegung nach Art (der Nutzer korrigiert): nur dort, wo die Art die Eignung eindeutig nahelegt. */
  var EIGNUNG_VORSCHLAG = {
    wohnmobil: ['uebernachten', 'kochen', 'bad_wc'],
    wohnwagen: ['uebernachten', 'kochen'],
    bootstrailer: ['transport'],
    wasserskiboot: ['wasserski'],
    wohnboot: ['uebernachten', 'kochen', 'bad_wc'],
    hausboot: ['uebernachten', 'kochen', 'bad_wc'],
    segelboot: ['segeln'], 'segelboot-monohull': ['segeln'], 'segelboot-katamaran': ['segeln'], 'segelboot-jolle': ['segeln'],
    beiboot: ['anlanden']
  };

  /* Größenklasse nach der Länge in Metern: Klein bis 6, Mittel über 6 bis 9, Groß über 9 bis unter 15, Sehr groß ab 15. */
  var GROESSENKLASSEN = [
    { id: 'klein', name: 'Klein', bis: 6, text: 'bis 6 m' },
    { id: 'mittel', name: 'Mittel', bis: 9, text: '6 bis 9 m' },
    { id: 'gross', name: 'Groß', bis: 15, ausschluss: true, text: '9 bis 15 m' },
    { id: 'sehrgross', name: 'Sehr groß', bis: Infinity, text: 'ab 15 m' }
  ];
  function groessenklasse(artId, laenge) {
    var a = art(artId), n = typeof laenge === 'number' ? laenge : Number(String(laenge == null ? '' : laenge).replace(',', '.'));
    if (!a || a.welt !== 'wasser' || vorfahren(artId).indexOf('beiboot') >= 0) return null;
    if (laenge === null || laenge === undefined || laenge === '' || !isFinite(n) || n <= 0) return null;
    for (var i = 0; i < GROESSENKLASSEN.length; i++) {
      var k = GROESSENKLASSEN[i];
      if (n < k.bis || (!k.ausschluss && n === k.bis)) return { id: k.id, name: k.name, text: k.text };
    }
    return null;
  }

  var FELDER = {
    marke: { label: 'Marke', typ: 'text', gruppe: 'fahrzeug' },
    modell: { label: 'Modell', typ: 'text', gruppe: 'fahrzeug' },
    typ: { label: 'Typ', typ: 'text', gruppe: 'fahrzeug' },
    baujahr: { label: 'Baujahr', typ: 'ganzzahl', gruppe: 'fahrzeug', min: 1800 },
    erstzulassung: { label: 'Erstzulassung', typ: 'datum', gruppe: 'fahrzeug' },
    kennzeichen: { label: 'Kennzeichen', typ: 'text', gruppe: 'fahrzeug' },
    registriernummer: { label: 'Registriernummer', typ: 'text', gruppe: 'fahrzeug' },
    fin: { label: 'FIN (Fahrgestellnummer)', typ: 'text', gruppe: 'fahrzeug' },
    hin: { label: 'HIN (Rumpfnummer)', typ: 'text', gruppe: 'fahrzeug' },
    heimathafen: { label: 'Heimathafen', typ: 'text', gruppe: 'fahrzeug' },
    baumaterial: { label: 'Baumaterial', typ: 'text', gruppe: 'fahrzeug', hilfe: 'Zum Beispiel GFK, Stahl, Holz oder Aluminium' },
    plaetze: { label: 'Personen / Plätze', typ: 'ganzzahl', gruppe: 'fahrzeug', min: 1, max: 999,
      hilfe: 'Für wie viele Personen das Fahrzeug zugelassen ist. Der Grundcheck rechnet damit Ausrüstung „je Person“, zum Beispiel Warnwesten oder Rettungswesten.' },

    laenge: { label: 'Länge', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    breite: { label: 'Breite', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    hoehe: { label: 'Höhe', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    tiefgang: { label: 'Tiefgang', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    durchfahrtshoehe: { label: 'Durchfahrtshöhe', typ: 'zahl', einheit: 'm', gruppe: 'masse',
      hilfe: 'Höhe über dem Wasser, wichtig für Brücken' },

    leergewicht: { label: 'Leergewicht', typ: 'zahl', einheit: 'kg', gruppe: 'gewichte' },
    gesamtgewicht: { label: 'Zulässiges Gesamtgewicht', typ: 'zahl', einheit: 'kg', gruppe: 'gewichte' },
    verdraengung: { label: 'Verdrängung', typ: 'zahl', einheit: 't', gruppe: 'gewichte', hilfe: 'Das Gewicht des Wassers, das das Boot verdrängt (steht im Bootsschein)' },

    kraftstoff: { label: 'Kraftstoff', typ: 'auswahl', optionen: KRAFTSTOFFE, gruppe: 'antrieb' },
    hoechstgeschwindigkeit: { label: 'Höchstgeschwindigkeit', typ: 'zahl', einheit: 'km/h', gruppe: 'antrieb' },
    reisegeschwindigkeit: { label: 'Reisegeschwindigkeit', typ: 'zahl', einheit: 'km/h', gruppe: 'antrieb',
      hilfe: 'Deine übliche Geschwindigkeit unterwegs' },

    achsen: { label: 'Achsen', typ: 'ganzzahl', gruppe: 'strasse', min: 1, max: 10 },
    mautklasse: { label: 'Mautklasse', typ: 'text', gruppe: 'strasse' },

    versicherung: { label: 'Versicherung', typ: 'text', gruppe: 'versicherung', hilfe: 'Name der Versicherung, zum Beispiel für den Schadensbericht. Freiwillig.' },
    versicherungsnummer: { label: 'Versicherungsnummer', typ: 'text', gruppe: 'versicherung', hilfe: 'Versicherungsschein- oder Vertragsnummer. Freiwillig.' },
    schadenTelefon: { label: 'Telefon für Schadenmeldungen', typ: 'text', gruppe: 'versicherung', hilfe: 'Notruf oder Schadenhotline der Versicherung. Freiwillig.' },

    antrieb: { label: 'Antrieb', typ: 'auswahl', gruppe: 'einordnung', optionen: [{ wert: 'mit', label: 'Mit Antrieb' }, { wert: 'ohne', label: 'Ohne Antrieb' }],
      hilfe: 'Ein Anhänger oder Wohnwagen hat keinen eigenen Antrieb.' },
    zustand: { label: 'Zustand', typ: 'auswahl', gruppe: 'einordnung', optionen: [{ wert: 'neu', label: 'Neufahrzeug' }, { wert: 'gebraucht', label: 'Gebrauchtfahrzeug' }, { wert: 'oldtimer', label: 'Oldtimer' }] },
    aufbau: { label: 'Aufbau', typ: 'auswahl', gruppe: 'einordnung', optionen: AUFBAU_PKW, hilfe: 'Freiwillig.' },
    auslegung: { label: 'Auslegung', typ: 'auswahl', gruppe: 'einordnung', optionen: [{ wert: 'personen', label: 'Personentransport' }, { wert: 'lasten', label: 'Lastentransport' }, { wert: 'beides', label: 'Personen und Lasten' }] },
    eignung: { label: 'Eignung und Ausstattung', typ: 'mehrfach', gruppe: 'einordnung', optionen: [],
      hilfe: 'Hake an, wofür das Fahrzeug geeignet oder ausgestattet ist. Die Vorgaben sind nach der Art vorbelegt, du kannst sie ändern.' },

    zuglast: { label: 'Zulässige Anhängelast', typ: 'zahl', einheit: 'kg', gruppe: 'gewichte', hilfe: 'Wie viel das Fahrzeug ziehen darf (gebremst).' },
    stuetzlast: { label: 'Zulässige Stützlast', typ: 'zahl', einheit: 'kg', gruppe: 'gewichte', hilfe: 'Wie viel Last die Deichsel auf die Anhängerkupplung bringen darf.' },

    zugfahrzeuge: { label: 'Zugfahrzeuge', typ: 'fahrzeuge', gruppe: 'zuordnung', hilfe: 'Mit welchen deiner Fahrzeuge dieser Anhänger gezogen werden kann.' },
    bootsliste: { label: 'Boote auf diesem Trailer', typ: 'fahrzeuge', gruppe: 'zuordnung', hilfe: 'Welche deiner Boote und Beiboote auf diesen Trailer passen. Beides kann je Trailer anders sein.' }
  };

  var VERS = ['versicherung', 'versicherungsnummer', 'schadenTelefon'];

  var EINORD = ['antrieb', 'zustand', 'auslegung', 'eignung'];
  var ZIEHEN = ['zuglast', 'stuetzlast'];

  var LAND = ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin', 'plaetze',
    'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
    'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit', 'achsen', 'mautklasse'].concat(EINORD, ZIEHEN, VERS);
  var LAND_PKW = LAND.concat([{ key: 'aufbau', optionen: AUFBAU_PKW }]);
  var LAND_WOHNMOBIL = LAND.concat([{ key: 'aufbau', optionen: AUFBAU_WOHNMOBIL }]);

  /* Anhänger ohne eigenen Antrieb: Zugfahrzeuge als Liste, dazu die Stützlast. Der Bootstrailer kennt außerdem seine Boote. */
  var ANHAENGER = ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin',
    'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
    'hoechstgeschwindigkeit', 'achsen', 'mautklasse', 'stuetzlast'].concat(EINORD, ['zugfahrzeuge'], VERS);

  var BOOT = ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'registriernummer', 'hin', 'heimathafen', 'baumaterial', 'plaetze',
    'laenge', 'breite', 'tiefgang', 'durchfahrtshoehe', 'leergewicht', 'gesamtgewicht', 'verdraengung',
    'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit'].concat(EINORD, VERS);

  /*
   * Der Baum der Fahrzeugarten (seit 2.0.15).
   *  - GRUPPEN_KNOTEN sind nur Ordnung (Land, Wasser, Luft), kein Fahrzeug hat so eine Art.
   *  - Jede Art hat ein „eltern“. Die Wurzel heißt 'alle'.
   *  - Gespeichert wird an einem Fahrzeug weiter nur die Art-Kennung. Alte Fahrzeuge
   *    (zum Beispiel 'boot') bleiben unverändert gültig und stehen im Baum an ihrer Stelle.
   */
  var WURZEL = 'alle';
  var GRUPPEN_KNOTEN = [
    { id: 'land', name: 'Landfahrzeug', welt: 'land', eltern: WURZEL, felder: [], gruppe: true },
    { id: 'wasser', name: 'Wasserfahrzeug', welt: 'wasser', eltern: WURZEL, felder: [], gruppe: true },
    { id: 'luft', name: 'Luftfahrzeug', welt: 'luft', eltern: WURZEL, felder: [], gruppe: true }
  ];

  var ARTEN = [
    { id: 'auto', name: 'Auto', welt: 'land', eltern: 'land', kennung: 'kennzeichen', felder: LAND_PKW },
    { id: 'motorrad', name: 'Motorrad', welt: 'land', eltern: 'land', kennung: 'kennzeichen',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin', 'plaetze',
        'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
        'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit'].concat(EINORD, VERS) },
    { id: 'transporter', name: 'Transporter', welt: 'land', eltern: 'land', kennung: 'kennzeichen', felder: LAND },
    { id: 'lkw', name: 'Lkw', welt: 'land', eltern: 'land', kennung: 'kennzeichen', felder: LAND },
    { id: 'wohnmobil', name: 'Wohnmobil', welt: 'land', eltern: 'land', kennung: 'kennzeichen', felder: LAND_WOHNMOBIL },
    { id: 'wohnwagen', name: 'Wohnwagen', welt: 'land', eltern: 'land', kennung: 'kennzeichen', vorgabe: { antrieb: 'ohne' }, felder: ANHAENGER },
    { id: 'anhaenger', name: 'Anhänger', welt: 'land', eltern: 'land', kennung: 'kennzeichen', vorgabe: { antrieb: 'ohne' }, felder: ANHAENGER },
    { id: 'bootstrailer', name: 'Bootstrailer', welt: 'land', eltern: 'land', kennung: 'kennzeichen', vorgabe: { antrieb: 'ohne' }, felder: ANHAENGER.concat(['bootsliste']) },
    { id: 'zeltanhaenger', name: 'Zeltanhänger', welt: 'land', eltern: 'land', kennung: 'kennzeichen', vorgabe: { antrieb: 'ohne' }, felder: ANHAENGER },
    { id: 'oldtimer', name: 'Oldtimer', welt: 'land', eltern: 'land', kennung: 'kennzeichen', felder: LAND_PKW },
    { id: 'boot', name: 'Boot', welt: 'wasser', eltern: 'wasser', kennung: 'registriernummer', felder: BOOT },
    { id: 'motorboot', name: 'Motorboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'schlauchboot', name: 'Schlauchboot oder RIB', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'jetski', name: 'Jetski', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'hausboot', name: 'Hausboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'beiboot', name: 'Beiboot oder Dinghy', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'paddelboot', name: 'Paddel- oder Ruderboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', vorgabe: { antrieb: 'ohne' }, felder: BOOT },
    { id: 'wasser-sonstiges', name: 'Sonstiges Wasserfahrzeug', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'sportboot', name: 'Sportboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'wasserskiboot', name: 'Wasserskiboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'wohnboot', name: 'Motorboot zum Übernachten', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'motorschiff', name: 'Motorschiff', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot', name: 'Segelboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot-monohull', name: 'Segelboot Monohull', welt: 'wasser', eltern: 'segelboot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot-katamaran', name: 'Segelboot Katamaran', welt: 'wasser', eltern: 'segelboot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot-jolle', name: 'Segelboot Jolle oder Kleinboot', welt: 'wasser', eltern: 'segelboot', kennung: 'registriernummer', felder: BOOT },
    { id: 'flugzeug', name: 'Flugzeug', welt: 'luft', eltern: 'luft', kennung: 'registriernummer',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'registriernummer', 'plaetze',
        'laenge', { key: 'breite', label: 'Spannweite' }, 'hoehe', 'leergewicht',
        { key: 'gesamtgewicht', label: 'Höchstzulässiges Abfluggewicht' },
        'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit', 'antrieb'].concat(VERS) }
  ];

  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }

  /*
   * Eigene Arten und Änderungen des Nutzers (seit 2.0.16).
   *  eigene:        [{ id, name, eltern }]  vom Nutzer angelegte Arten oder Untergruppen
   *  ueberschreibung: { artId: { name?, ausgeblendet?, geloescht? } }  gilt für mitgelieferte und eigene Arten
   * Die Gruppen Land, Wasser und Luft sind fest. Eine eigene Art übernimmt Felder und Kennung der Obergruppe.
   * Gelöscht heißt: unsichtbar und nicht mehr wählbar. Das geht nur, wenn kein Fahrzeug die Art
   * (oder eine Untergruppe davon) hat. Ausblenden geht immer, bestehende Fahrzeuge bleiben unverändert.
   */
  var eigene = [];
  var ueber = {};
  var cache = null;
  /* Eigene Punkte der Eignungsliste (seit 2.0.103): [{ id, name, vorgabe }]. vorgabe = von einem Entwickler oder Admin angelegt, gilt wie ein MobiMory-Punkt. */
  var eignungEigene = [];

  function konfigurieren(dok) {
    eignungEigene = dok && Array.isArray(dok.eignung) ? dok.eignung.filter(function (e) { return e && e.id && e.name; }).map(function (e) { return { id: e.id, name: e.name, vorgabe: !!e.vorgabe }; }) : [];
    eigene = dok && Array.isArray(dok.eigene) ? dok.eigene.map(function (e) { return { id: e.id, name: e.name, eltern: e.eltern }; }) : [];
    ueber = {};
    var u = dok && dok.ueberschreibung && typeof dok.ueberschreibung === 'object' ? dok.ueberschreibung : {};
    Object.keys(u).forEach(function (k) { ueber[k] = kopie(u[k]); });
    cache = null;
  }
  function dokument() {
    var d = { id: 'fahrzeugarten', eigene: eigene.map(function (e) { return { id: e.id, name: e.name, eltern: e.eltern }; }), ueberschreibung: JSON.parse(JSON.stringify(ueber)) };
    if (eignungEigene.length) d.eignung = eignungEigene.map(function (e) { return { id: e.id, name: e.name, vorgabe: !!e.vorgabe }; });
    return d;
  }

  /* Alle Knoten (ohne Gelöschte) in einer Karte. Wird bei jeder Änderung neu aufgebaut. */
  function stand() {
    if (cache) return cache;
    var karte = {}, reihenfolge = [];
    function aufnehmen(k) { karte[k.id] = k; reihenfolge.push(k.id); }
    GRUPPEN_KNOTEN.concat(ARTEN).forEach(function (a) {
      var k = kopie(a), o = ueber[a.id] || {};
      if (o.name) k.name = o.name;
      k.ausgeblendet = !!o.ausgeblendet; k.geloescht = !!o.geloescht;
      aufnehmen(k);
    });
    eigene.forEach(function (e) {
      var o = ueber[e.id] || {};
      aufnehmen({ id: e.id, name: o.name || e.name, eltern: e.eltern, eigen: true, ausgeblendet: !!o.ausgeblendet, geloescht: !!o.geloescht });
    });
    /* Felder, Kennung und Welt der eigenen Arten kommen von der Obergruppe. */
    var STANDARD = { land: 'auto', wasser: 'boot', luft: 'flugzeug' };
    function erben(k, tiefe) {
      if (k.felder || tiefe > 20) return;
      var eltern = karte[k.eltern];
      if (eltern && !eltern.felder) erben(eltern, tiefe + 1);
      k.welt = eltern ? eltern.welt : 'land';
      var quelle = eltern && eltern.felder && eltern.felder.length ? eltern : karte[STANDARD[k.welt]] || karte.auto;
      k.felder = quelle.felder; k.kennung = quelle.kennung;
    }
    reihenfolge.forEach(function (id) { erben(karte[id], 0); });
    /* Unter einer gelöschten Art ist alles gelöscht. */
    function geloeschtOben(k, tiefe) { return k.geloescht || (tiefe < 20 && karte[k.eltern] && geloeschtOben(karte[k.eltern], tiefe + 1)); }
    var lebend = {}, ids = [];
    reihenfolge.forEach(function (id) { if (!geloeschtOben(karte[id], 0)) { lebend[id] = karte[id]; ids.push(id); } });
    cache = { karte: lebend, ids: ids };
    return cache;
  }

  function art(id) { var k = stand().karte[id]; return k || null; }

  function knoten(id) { return id === WURZEL ? { id: WURZEL, name: 'Alle Fahrzeuge', eltern: null, gruppe: true } : art(id); }

  /* Die Kennung selbst und alle Obergruppen bis zur Wurzel, zuerst die Art selbst. */
  function vorfahren(id) {
    var liste = [], k = knoten(id), schutz = 0;
    while (k && schutz++ < 20) { liste.push(k.id); k = k.eltern ? knoten(k.eltern) : null; }
    return liste;
  }

  function kinder(id) {
    var st = stand();
    return st.ids.map(function (i) { return st.karte[i]; }).filter(function (a) { return a.eltern === id; });
  }

  /* Ist die Art selbst und alles darüber eingeblendet? Nur dann ist sie für neue Fahrzeuge wählbar. */
  function sichtbar(id) {
    return vorfahren(id).every(function (i) { var k = knoten(i); return !k || !k.ausgeblendet; });
  }

  /* Der Baum von oben nach unten, mit Tiefe (Wurzel = 0). Ausgeblendete Arten fehlen samt allem darunter,
     außer mitAusgeblendeten ist gesetzt. */
  function baum(mitAusgeblendeten) {
    var ergebnis = [];
    function gehe(id, tiefe) {
      var k = knoten(id);
      ergebnis.push({ id: k.id, name: k.name, welt: k.welt || null, tiefe: tiefe, gruppe: !!k.gruppe || kinder(k.id).length > 0, waehlbar: !k.gruppe });
      kinder(id).forEach(function (c) { if (mitAusgeblendeten || !c.ausgeblendet) gehe(c.id, tiefe + 1); });
    }
    gehe(WURZEL, 0);
    return ergebnis;
  }

  /* Alle Nachkommen (ohne die Art selbst). */
  function nachkommen(id) {
    var ergebnis = [];
    kinder(id).forEach(function (c) { ergebnis.push(c.id); nachkommen(c.id).forEach(function (n) { ergebnis.push(n); }); });
    return ergebnis;
  }

  /* ---------- Verwalten: anlegen, umbenennen, ausblenden, löschen, bereinigen ---------- */
  function ist(k) { return !!(k && !k.gruppe); }
  function nameFrei(name, elternId, ausser) {
    var n = name.toLowerCase();
    return !kinder(elternId).some(function (c) { return c.id !== ausser && c.name.toLowerCase() === n; });
  }
  function sauber(name) { return String(name == null ? '' : name).replace(/\s+/g, ' ').trim(); }
  function weltKnoten(k) { return !!(k && k.gruppe && k.eltern === WURZEL && !k.eigen); }

  function anlegen(id, name, elternId) {
    var n = sauber(name), fehler = {};
    if (!n) fehler.name = 'Bitte einen Namen eingeben, zum Beispiel „Trimaran“.';
    var eltern = art(elternId);
    if (!eltern) fehler.eltern = 'Bitte wählen, unter welcher Gruppe die Art stehen soll.';
    else if (n && !nameFrei(n, elternId)) fehler.name = 'Unter dieser Gruppe gibt es schon eine Art mit diesem Namen.';
    if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
    eigene.push({ id: id, name: n, eltern: elternId });
    cache = null;
    return { ok: true, id: id };
  }

  function aendern(id, name, ausgeblendet) {
    var k = art(id);
    if (!k || weltKnoten(k)) return { ok: false, fehler: { allgemein: 'Diese Art lässt sich nicht ändern.' } };
    var n = sauber(name);
    if (!n) return { ok: false, fehler: { name: 'Bitte einen Namen eingeben.' } };
    if (!nameFrei(n, k.eltern, id)) return { ok: false, fehler: { name: 'Unter dieser Gruppe gibt es schon eine Art mit diesem Namen.' } };
    var o = ueber[id] = ueber[id] || {};
    var geaendert = false;
    if (n !== k.name) { o.name = n; geaendert = true; }
    var aus = ausgeblendet === true || ausgeblendet === 'ja';
    if (aus !== !!k.ausgeblendet) { o.ausgeblendet = aus; geaendert = true; }
    cache = null;
    return { ok: true, id: id, geaendert: geaendert };
  }

  /* benutzt = Liste der Fahrzeugarten, die ein Fahrzeug hat. */
  function benutztIn(id, benutzt) {
    var gruppe = [id].concat(nachkommen(id));
    return (benutzt || []).some(function (b) { return gruppe.indexOf(b) >= 0; });
  }

  function loeschen(id, benutzt) {
    var k = art(id);
    if (!k || weltKnoten(k)) return { ok: false, fehler: { allgemein: 'Diese Art lässt sich nicht löschen.' } };
    if (benutztIn(id, benutzt)) return { ok: false, fehler: { allgemein: '„' + k.name + '“ wird von einem Fahrzeug benutzt (oder eine Untergruppe davon). Benutzte Arten lassen sich nur ausblenden.' } };
    var namen = [k.name].concat(nachkommen(id).map(function (i) { return art(i).name; }));
    [id].concat(nachkommen(id)).forEach(function (i) { (ueber[i] = ueber[i] || {}).geloescht = true; });
    cache = null;
    return { ok: true, namen: namen };
  }

  /* Was würde „Ungebrauchtes löschen“ treffen? Alles, was weder benutzt ist noch eine benutzte Untergruppe hat. Die Gruppen Land, Wasser, Luft bleiben. */
  function ungebraucht(benutzt) {
    var gebraucht = {};
    (benutzt || []).forEach(function (b) { vorfahren(b).forEach(function (i) { gebraucht[i] = true; }); });
    return baum(true).filter(function (k) { return k.tiefe > 0 && !gebraucht[k.id] && !weltKnoten(art(k.id)); }).map(function (k) { return k.id; });
  }

  function bereinigen(benutzt) {
    var ids = ungebraucht(benutzt), namen = ids.map(function (i) { return art(i).name; });
    ids.forEach(function (i) { (ueber[i] = ueber[i] || {}).geloescht = true; });
    cache = null;
    return { ok: true, anzahl: ids.length, namen: namen };
  }

  /* Gelöschte mitgelieferte Arten wieder holen. Eigene gelöschte Arten kommen nicht zurück. */
  function wiederherstellbar() {
    return ARTEN.filter(function (a) { return ueber[a.id] && ueber[a.id].geloescht; }).map(function (a) { return a.id; });
  }
  function wiederherstellen() {
    var ids = wiederherstellbar();
    ids.forEach(function (i) { delete ueber[i].geloescht; });
    cache = null;
    return { ok: true, anzahl: ids.length };
  }

  /* Die Verwaltungsansicht: alle Arten, auch ausgeblendete, mit Tiefe und Zustand. */
  function verwaltung() {
    return baum(true).filter(function (k) { return k.tiefe > 0; }).map(function (k) {
      var a = art(k.id);
      return { id: k.id, name: k.name, tiefe: k.tiefe - 1, welt: a.welt, eigen: !!a.eigen, fest: weltKnoten(a), ausgeblendet: !!a.ausgeblendet,
        verdeckt: !a.ausgeblendet && !sichtbar(k.id), waehlbar: !a.gruppe, eltern: a.eltern };
    });
  }

  function felder(artId) {
    var a = art(artId);
    if (!a) return [];
    return a.felder.map(function (eintrag) {
      var key = typeof eintrag === 'string' ? eintrag : eintrag.key;
      var f = kopie(FELDER[key]);
      if (typeof eintrag !== 'string') { for (var p in eintrag) { f[p] = eintrag[p]; } }
      f.key = key;
      if (key === 'eignung') f.optionen = eignungOptionen(a);
      return f;
    });
  }

  /* ---------- Eignungsliste (seit 2.0.103) ---------- */
  function hatFeld(a, key) {
    return (a.felder || []).some(function (e) { return (typeof e === 'string' ? e : e.key) === key; });
  }
  /* Ein Anhänger (hat die Liste der Zugfahrzeuge) kann keinen Anhänger ziehen. */
  function istAnhaenger(artId) { var a = art(artId); return !!a && hatFeld(a, 'zugfahrzeuge'); }

  /* Die Punkte für eine Art: erst die Vorgaben der Welt, dann die von Entwicklern angelegten, dann die eigenen des Nutzers. */
  function eignungListe(artId) {
    var a = art(artId);
    if (!a) return [];
    var anhaenger = hatFeld(a, 'zugfahrzeuge');
    var liste = EIGNUNG.filter(function (e) { return e.welten.indexOf(a.welt) >= 0 && !(anhaenger && e.nurMitAntrieb); })
      .map(function (e) { return { wert: e.wert, label: e.label, vorgegeben: true, eigen: false }; });
    eignungEigene.filter(function (e) { return e.vorgabe; }).forEach(function (e) { liste.push({ wert: e.id, label: e.name, vorgegeben: true, eigen: false, entwickler: true }); });
    eignungEigene.filter(function (e) { return !e.vorgabe; }).forEach(function (e) { liste.push({ wert: e.id, label: e.name, vorgegeben: false, eigen: true }); });
    return liste;
  }
  function eignungOptionen(a) {
    return eignungListe(a.id).map(function (e) { return { wert: e.wert, label: e.label + (e.eigen ? ' (eigener Punkt)' : '') }; });
  }
  /* Die Vorbelegung für ein neues Fahrzeug dieser Art, nur mit Punkten, die es für die Art gibt. */
  function eignungVorschlag(artId) {
    var erlaubt = eignungListe(artId).map(function (e) { return e.wert; });
    var a = art(artId), ids = [];
    vorfahren(artId).forEach(function (i) { if (!ids.length && EIGNUNG_VORSCHLAG[i]) ids = EIGNUNG_VORSCHLAG[i]; });
    return ids.filter(function (i) { return erlaubt.indexOf(i) >= 0; });
  }
  /* Ein Punkt ist für Aktivitäten verwendbar, wenn er vorgegeben ist (von MobiMory oder von einem Entwickler). Eigene Punkte sind nur Merkzettel. */
  function eignungFuerAktivitaeten(wert) {
    if (EIGNUNG.some(function (e) { return e.wert === wert; })) return true;
    return eignungEigene.some(function (e) { return e.id === wert && e.vorgabe; });
  }
  function eignungAnlegen(id, name, vorgabe) {
    var n = sauber(name), fehler = {};
    if (!n) fehler.name = 'Bitte einen Namen eingeben, zum Beispiel „Hundetauglich“.';
    else if (n.length > 60) fehler.name = 'Bitte höchstens 60 Zeichen eingeben.';
    else {
      var klein = n.toLowerCase();
      var vorhanden = EIGNUNG.map(function (e) { return e.label; }).concat(eignungEigene.map(function (e) { return e.name; }));
      if (vorhanden.some(function (v) { return v.toLowerCase() === klein; })) fehler.name = 'Diesen Punkt gibt es schon.';
    }
    if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
    eignungEigene.push({ id: id, name: n, vorgabe: !!vorgabe });
    return { ok: true, id: id, vorgabe: !!vorgabe };
  }

  function gruppen(artId) {
    var alle = felder(artId);
    return GRUPPEN.map(function (g) {
      return { id: g.id, titel: g.titel, felder: alle.filter(function (f) { return f.gruppe === g.id; }) };
    }).filter(function (g) { return g.felder.length > 0; });
  }

  MM.Fahrzeugarten = {
    WURZEL: WURZEL,
    /* Alle Arten, die ein Fahrzeug haben kann, in der Reihenfolge des Baums. Ausgeblendete nur auf Wunsch. */
    alle: function (mitAusgeblendeten) { return baum(mitAusgeblendeten).filter(function (k) { return k.waehlbar; }).map(function (k) { return art(k.id); }); },
    baum: baum,
    knoten: knoten,
    vorfahren: vorfahren,
    kinder: kinder,
    nachkommen: nachkommen,
    sichtbar: sichtbar,
    /* Gilt die Art 'id' als Fall von 'gruppeId'? (Art selbst oder eine ihrer Obergruppen) */
    gehoertZu: function (id, gruppeId) { return vorfahren(id).indexOf(gruppeId) >= 0; },
    art: art,
    /* Wie art(), aber nie leer: fehlt die Art (zum Beispiel nach Übergabe oder Freigabe), kommt ein Platzhalter. */
    artSicher: function (id) { return art(id) || { id: id, name: 'Art unbekannt', welt: 'land', unbekannt: true }; },
    felder: felder,
    gruppen: gruppen,
    groessenklasse: groessenklasse, GROESSENKLASSEN: GROESSENKLASSEN,
    eignungListe: eignungListe, eignungVorschlag: eignungVorschlag, eignungAnlegen: eignungAnlegen, eignungFuerAktivitaeten: eignungFuerAktivitaeten,
    istAnhaenger: istAnhaenger,
    /* Was für diese Art vorbelegt wird, wenn ein neues Fahrzeug angelegt wird (zum Beispiel Antrieb „ohne“ beim Anhänger). */
    vorgabe: function (artId) { var a = art(artId); var v = a && a.vorgabe ? kopie(a.vorgabe) : {}; var e = eignungVorschlag(artId); if (e.length && hatFeld(a, 'eignung')) v.eignung = e; return v; },
    kennungFeld: function (artId) { var a = art(artId); return a ? a.kennung : null; },
    konfigurieren: konfigurieren, dokument: dokument,
    anlegen: anlegen, aendern: aendern, loeschen: loeschen, ungebraucht: ungebraucht, bereinigen: bereinigen,
    wiederherstellbar: wiederherstellbar, wiederherstellen: wiederherstellen, benutztIn: benutztIn, verwaltung: verwaltung
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
