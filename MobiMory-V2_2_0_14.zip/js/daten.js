/*
 * Daten: die EINE Tür zu allen Fahrzeugdaten.
 *
 * Regeln aus den V2-Festlegungen, die hier gelten:
 *  - Eine Quelle: alle Teile der App fragen nur hier nach.
 *  - Handeingabe hat Vorrang. Es wird nichts überschrieben: Jede Änderung
 *    ist ein neuer Eintrag "Korrektur zu ...", der alte bleibt sichtbar.
 *  - Nichts wird gelöscht.
 *  - Jeder Eintrag nennt seine Herkunft (hier: "hand").
 *
 * Aufbau der gespeicherten Daten:
 *  datenraum   { id, name, erstelltAm }
 *  fahrzeug    { id, datenraumId, art, erstelltAm }
 *  eintrag     { id, fahrzeugId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  komponente  { id, fahrzeugId, parentId, art, erstelltAm }
 *              parentId = null: Hauptkomponente (dann gilt "art"), sonst gehört
 *              sie zu einer anderen Komponente ("gehört zu").
 *  komponenteneintrag { id, komponenteId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  zaehler     { id, fahrzeugId, komponenteId|null, art, erstelltAm }      (Name im Verlauf)
 *  zaehlerstand { id, zaehlerId, nr, wert, datum, notiz, quelle, erstelltAm }
 *  frist       { id, fahrzeugId, komponenteId|null, erstelltAm }            (Angaben im Verlauf)
 *  verlauf     { id, objektTyp, objektId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  durchfuehrung { id, fristId, datum, zaehlerstand, notiz, art, quelle, erstelltAm }
 *  dokument    { id, fahrzeugId, komponenteId|null, erstelltAm }            (Angaben im Verlauf)
 *  datei       { id, dokumentId, name, mime, groesse, inhalt, erstelltAm }  (inhalt = die Datei selbst)
 *  person      { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  tier        { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  nachweisart { id, datenraumId, erstelltAm }                              (Angaben im Verlauf; offene Liste)
 *  nachweis    { id, datenraumId, artId, besitzerTyp, besitzerId, erstelltAm }  (Angaben im Verlauf)
 *  nachweisdatei { id, nachweisId, name, mime, groesse, inhalt, erstelltAm } (Scan oder Foto, bleibt lokal)
 *  aktivitaet  { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  aktivitaetsart { id, datenraumId, erstelltAm }                           (offene Liste, Angaben im Verlauf)
 *  besatzung   { id, aktivitaetId, personId, erstelltAm }                   (Rolle und "dabei von bis" im Verlauf)
 *  verantwortung { id, aktivitaetId, personId, ab, erstelltAm }             (Wechsel der Verantwortlichen, nur anhängen)
 *  anforderung { id, datenraumId, fahrzeugId, erstelltAm }                  (welche Nachweise Skipper und Fahrer brauchen)
 *  tagesabschnitt { id, datenraumId, aktivitaetId, herkunft, erstelltAm }   (Angaben im Verlauf; herkunft: vorbereitet oder hand)
 *  tagespruefung { id, datenraumId, aktivitaetId, abschnittId, stand, erstelltAm } (festgehaltene Prüfung zum Tagesbeginn, nur anhängen)
 *  ereignis    { id, datenraumId, aktivitaetId, abschnittId, erstelltAm }   (Angaben im Verlauf; Foto in ereignisdatei)
 *  ereignisart { id, datenraumId, erstelltAm }                              (offene Liste, Angaben im Verlauf)
 *  ereignisdatei { id, ereignisId, name, mime, groesse, inhalt, erstelltAm } (Foto, bleibt lokal)
 *  einstellung { id, ... }                                                  (zum Beispiel id "sicherung": letzteSicherung, erinnerungTage)
 *
 * "werte" enthält Bezeichnung und alle Felder. Der aktuelle Stand ist der
 * Eintrag mit der höchsten Nummer.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  function neueId(praefix) {
    var c = global.crypto;
    if (c && typeof c.randomUUID === 'function') return praefix + '-' + c.randomUUID();
    return praefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function Daten(speicher, optionen) {
    this.speicher = speicher;
    this.jetzt = (optionen && optionen.jetzt) || function () { return new Date().toISOString(); };
    this.datenraumId = null;
  }

  /* Beim ersten Start entsteht der eigene Datenraum auf diesem Gerät. */
  Daten.prototype.starten = function () {
    var self = this;
    return this.speicher.alle('datenraeume').then(function (liste) {
      if (liste.length) { self.datenraumId = liste[0].id; return liste[0]; }
      var dr = { id: neueId('dr'), name: 'Mein Datenraum', erstelltAm: self.jetzt() };
      return self.speicher.speichern('datenraeume', dr).then(function () {
        self.datenraumId = dr.id;
        return dr;
      });
    });
  };

  /* ---------- Prüfen und in saubere Werte umwandeln ---------- */
  function optWert(o) { return typeof o === 'string' ? o : o.wert; }

  function pruefeWerte(felder, roh, jahr, optionen) {
    var ohneBez = !!(optionen && optionen.ohneBezeichnung);
    var werte = {};
    var fehler = {};
    roh = roh || {};

    if (!ohneBez) {
      var bez = String(roh.bezeichnung == null ? '' : roh.bezeichnung).trim();
      if (!bez) fehler.bezeichnung = (optionen && optionen.bezeichnungFehler) || 'Bitte eine Bezeichnung eingeben, zum Beispiel „Fahrzeug A“.';
      werte.bezeichnung = bez;
    }

    felder.forEach(function (f) {
      if (f.typ === 'mehrfach') {
        var gewaehlt = Array.isArray(roh[f.key]) ? roh[f.key] : [];
        werte[f.key] = f.optionen.filter(function (o) { return gewaehlt.indexOf(optWert(o)) >= 0; }).map(optWert);
        return;
      }
      if (f.typ === 'liste') {
        var zeilen = Array.isArray(roh[f.key]) ? roh[f.key] : [];
        var sauber = [];
        zeilen.forEach(function (z) {
          var n = String(z && z.name != null ? z.name : '').trim();
          var w = String(z && z.wert != null ? z.wert : '').trim();
          if (!n && !w) return;
          if (!n || !w) fehler[f.key] = 'Bitte bei jedem Merkmal Name und Wert eingeben.';
          sauber.push({ name: n, wert: w });
        });
        werte[f.key] = sauber;
        return;
      }

      var v = roh[f.key];
      v = (v === undefined || v === null) ? '' : v;
      if (typeof v === 'string') v = v.trim();

      if (f.typ === 'text') { werte[f.key] = v === '' ? null : String(v); return; }

      if (f.typ === 'auswahl') {
        if (v === '') { werte[f.key] = null; return; }
        if (!f.optionen.some(function (o) { return optWert(o) === v; })) { fehler[f.key] = 'Bitte eine Möglichkeit aus der Liste wählen.'; }
        werte[f.key] = v;
        return;
      }

      if (f.typ === 'zeit') {
        if (v === '') { werte[f.key] = null; return; }
        if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(v)) { fehler[f.key] = 'Bitte eine Uhrzeit eingeben, zum Beispiel 14:30.'; werte[f.key] = null; } else { werte[f.key] = v; }
        return;
      }
      if (f.typ === 'datum') {
        if (v === '') { werte[f.key] = null; return; }
        var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
        var d = m ? new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])) : null;
        if (!d || d.getUTCFullYear() !== +m[1] || d.getUTCMonth() !== +m[2] - 1 || d.getUTCDate() !== +m[3]) {
          fehler[f.key] = 'Bitte ein gültiges Datum eingeben.';
          werte[f.key] = null;
        } else { werte[f.key] = v; }
        return;
      }

      /* zahl und ganzzahl: Komma oder Punkt als Dezimalzeichen erlaubt */
      if (v === '') { werte[f.key] = null; return; }
      var text = String(v).replace(/\s/g, '').replace(',', '.');
      var n = /^-?\d+(\.\d+)?$/.test(text) ? Number(text) : NaN;
      if (isNaN(n)) {
        fehler[f.key] = f.typ === 'ganzzahl' ? 'Bitte eine ganze Zahl eingeben.' : 'Bitte eine Zahl eingeben, zum Beispiel 2,5.';
        werte[f.key] = null;
        return;
      }
      if (f.typ === 'ganzzahl' && Math.floor(n) !== n) { fehler[f.key] = 'Bitte eine ganze Zahl eingeben.'; werte[f.key] = null; return; }
      if (n < 0) { fehler[f.key] = 'Die Zahl darf nicht negativ sein.'; werte[f.key] = null; return; }
      if (f.key === 'baujahr' && (n < f.min || n > jahr + 1)) {
        fehler[f.key] = 'Bitte ein Baujahr zwischen ' + f.min + ' und ' + (jahr + 1) + ' eingeben.';
        werte[f.key] = null; return;
      }
      if (f.min !== undefined && f.key !== 'baujahr' && n < f.min) { fehler[f.key] = 'Der Wert muss mindestens ' + f.min + ' sein.'; werte[f.key] = null; return; }
      if (f.max !== undefined && n > f.max) { fehler[f.key] = 'Der Wert darf höchstens ' + f.max + ' sein.'; werte[f.key] = null; return; }
      werte[f.key] = n;
    });

    return { werte: werte, fehler: fehler, ok: Object.keys(fehler).length === 0 };
  }

  Daten.prototype.pruefen = function (artId, roh) {
    return pruefeWerte(MM.Fahrzeugarten.felder(artId), roh, new Date(this.jetzt()).getFullYear());
  };

  Daten.prototype.pruefenKomponente = function (roh) {
    var p = pruefeWerte(MM.Komponenten.felder(), roh, new Date(this.jetzt()).getFullYear());
    var w = p.werte;
    if (w.eingebautAm && w.ausgebautAm && w.ausgebautAm < w.eingebautAm && !p.fehler.ausgebautAm) {
      p.fehler.ausgebautAm = 'Der Ausbau kann nicht vor dem Einbau liegen.';
      p.ok = false;
    }
    return p;
  };

  /* ---------- Unterschiede zwischen zwei Ständen ---------- */
  function gleich(a, b) {
    if (a === b) return true;
    if (a && b && typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) return JSON.stringify(a) === JSON.stringify(b);
    var la = Array.isArray(a) ? a : (a === null || a === undefined ? [] : null);
    var lb = Array.isArray(b) ? b : (b === null || b === undefined ? [] : null);
    if (la && lb) return JSON.stringify(la) === JSON.stringify(lb);
    return false;
  }

  function unterschiedeFelder(felder, alt, neu) {
    var liste = [{ key: 'bezeichnung', label: 'Bezeichnung' }].concat(felder);
    var res = [];
    liste.forEach(function (f) {
      var a = alt[f.key] === undefined ? null : alt[f.key];
      var n = neu[f.key] === undefined ? null : neu[f.key];
      if (!gleich(a, n)) res.push({ key: f.key, label: f.label, feld: f, alt: a, neu: n });
    });
    return res;
  }

  Daten.prototype.unterschiede = function (artId, alt, neu) {
    return unterschiedeFelder(MM.Fahrzeugarten.felder(artId), alt, neu);
  };

  function neuester(eintraege) {
    return eintraege.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
  }
  function nachNr(a, b) { return a.nr - b.nr; }

  /* ---------- Fahrzeuge ---------- */
  Daten.prototype.fahrzeugAnlegen = function (artId, roh) {
    if (!MM.Fahrzeugarten.art(artId)) {
      return Promise.resolve({ ok: false, fehler: { art: 'Bitte zuerst die Fahrzeugart wählen.' } });
    }
    var p = this.pruefen(artId, roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var jetzt = this.jetzt();
    var fahrzeug = { id: neueId('fz'), datenraumId: this.datenraumId, art: artId, erstelltAm: jetzt };
    var eintrag = { id: neueId('en'), fahrzeugId: fahrzeug.id, nr: 1, werte: p.werte,
      quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
    return this.speicher.mehrereSpeichern([
      { tabelle: 'fahrzeuge', objekt: fahrzeug },
      { tabelle: 'eintraege', objekt: eintrag }
    ]).then(function () { return { ok: true, id: fahrzeug.id }; });
  };

  /* Änderung = neuer Eintrag. Der alte bleibt unverändert erhalten. */
  Daten.prototype.fahrzeugAendern = function (fahrzeugId, roh) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      var p = self.pruefen(f.fahrzeug.art, roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var diff = self.unterschiede(f.fahrzeug.art, f.aktuell.werte, p.werte);
      if (!diff.length) return { ok: true, id: fahrzeugId, geaendert: false };
      var eintrag = { id: neueId('en'), fahrzeugId: fahrzeugId, nr: f.aktuell.nr + 1, werte: p.werte,
        quelle: 'hand', korrekturZu: f.aktuell.id, erstelltAm: self.jetzt() };
      return self.speicher.speichern('eintraege', eintrag)
        .then(function () { return { ok: true, id: fahrzeugId, geaendert: true }; });
    });
  };

  /* Alle Fahrzeuge des Datenraums, jeweils mit aktuellem Stand (Schale 1). */
  Daten.prototype.fahrzeugListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('fahrzeuge'), this.speicher.alle('eintraege')]).then(function (r) {
      var nachFahrzeug = {};
      r[1].forEach(function (e) { (nachFahrzeug[e.fahrzeugId] = nachFahrzeug[e.fahrzeugId] || []).push(e); });
      var liste = r[0].filter(function (f) { return f.datenraumId === self.datenraumId; })
        .map(function (f) { return { fahrzeug: f, aktuell: neuester(nachFahrzeug[f.id] || []) }; })
        .filter(function (x) { return x.aktuell; });
      liste.sort(function (a, b) {
        return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return liste;
    });
  };

  /* Ein Fahrzeug mit aktuellem Stand und dem ganzen Verlauf (neueste zuerst). */
  Daten.prototype.fahrzeugLaden = function (id) {
    var self = this;
    return Promise.all([this.speicher.holen('fahrzeuge', id), this.speicher.wo('eintraege', 'fahrzeugId', id)])
      .then(function (r) {
        var fahrzeug = r[0];
        if (!fahrzeug || !r[1].length) return null;
        var eintraege = r[1].slice().sort(nachNr);
        var verlauf = eintraege.map(function (e, i) {
          var vorher = i > 0 ? eintraege[i - 1] : null;
          return { eintrag: e, vorher: vorher,
            aenderungen: vorher ? self.unterschiede(fahrzeug.art, vorher.werte, e.werte) : [] };
        }).reverse();
        return { fahrzeug: fahrzeug, aktuell: eintraege[eintraege.length - 1], verlauf: verlauf };
      });
  };

  /* ---------- Komponenten (Schale 3 und tiefer) ---------- */

  /* Alle Komponenten eines Fahrzeugs mit aktuellem Stand, unsortiert. */
  Daten.prototype.komponentenListe = function (fahrzeugId) {
    return Promise.all([this.speicher.wo('komponenten', 'fahrzeugId', fahrzeugId), this.speicher.alle('komponenteneintraege')])
      .then(function (r) {
        var nach = {};
        r[1].forEach(function (e) { (nach[e.komponenteId] = nach[e.komponenteId] || []).push(e); });
        return r[0].map(function (k) {
          var eintraege = (nach[k.id] || []).slice().sort(nachNr);
          return { komponente: k, eintraege: eintraege, aktuell: eintraege[eintraege.length - 1] || null };
        }).filter(function (x) { return x.aktuell; });
      });
  };

  /* Reihenfolge: Hauptkomponenten nach Art, sonst nach Bezeichnung. */
  Daten.prototype.sortiereKomponenten = function (liste) {
    return liste.slice().sort(function (a, b) {
      var ia = MM.Komponenten.artIndex(a.komponente.art), ib = MM.Komponenten.artIndex(b.komponente.art);
      if (!a.komponente.parentId && !b.komponente.parentId && ia !== ib) return ia - ib;
      return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
  };

  /*
   * Neue Komponente. parentId = null: Hauptkomponente (art ist dann Pflicht),
   * sonst gehört sie zu der genannten Komponente (Art entfällt).
   */
  Daten.prototype.komponenteAnlegen = function (fahrzeugId, parentId, artId, roh) {
    var self = this;
    var p = this.pruefenKomponente(roh);
    var fehler = p.fehler;
    if (!parentId && !MM.Komponenten.art(artId)) fehler.art = 'Bitte zuerst die Art der Hauptkomponente wählen.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    return Promise.all([
      this.speicher.holen('fahrzeuge', fahrzeugId),
      parentId ? this.speicher.holen('komponenten', parentId) : Promise.resolve(null)
    ]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (parentId && (!r[1] || r[1].fahrzeugId !== fahrzeugId)) {
        return { ok: false, fehler: { allgemein: 'Die übergeordnete Komponente wurde nicht gefunden.' } };
      }
      var jetzt = self.jetzt();
      var k = { id: neueId('ko'), fahrzeugId: fahrzeugId, parentId: parentId || null,
        art: parentId ? null : artId, erstelltAm: jetzt };
      var e = { id: neueId('ke'), komponenteId: k.id, nr: 1, werte: p.werte,
        quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'komponenten', objekt: k },
        { tabelle: 'komponenteneintraege', objekt: e }
      ]).then(function () { return { ok: true, id: k.id }; });
    });
  };

  /* Änderung = neuer Eintrag, wie beim Fahrzeug. */
  Daten.prototype.komponenteAendern = function (komponenteId, roh) {
    var self = this;
    return this.komponenteLaden(komponenteId).then(function (c) {
      if (!c) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      var p = self.pruefenKomponente(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var diff = unterschiedeFelder(MM.Komponenten.felder(), c.aktuell.werte, p.werte);
      if (!diff.length) return { ok: true, id: komponenteId, geaendert: false };
      var e = { id: neueId('ke'), komponenteId: komponenteId, nr: c.aktuell.nr + 1, werte: p.werte,
        quelle: 'hand', korrekturZu: c.aktuell.id, erstelltAm: self.jetzt() };
      return self.speicher.speichern('komponenteneintraege', e)
        .then(function () { return { ok: true, id: komponenteId, geaendert: true }; });
    });
  };

  /*
   * Eine Komponente mit Stand, Verlauf, dem Weg von der Hauptkomponente bis
   * zu ihr (weg), den Teilen direkt darunter (kinder) und dem Fahrzeug.
   * tiefe: 3 = Hauptkomponente (Schale 3), 4 = Teil darunter, usw.
   */
  Daten.prototype.komponenteLaden = function (id) {
    var self = this;
    return this.speicher.holen('komponenten', id).then(function (k) {
      if (!k) return null;
      return Promise.all([self.komponentenListe(k.fahrzeugId), self.fahrzeugLaden(k.fahrzeugId)]).then(function (r) {
        var alle = r[0], fz = r[1];
        var nachId = {};
        alle.forEach(function (x) { nachId[x.komponente.id] = x; });
        var ich = nachId[id];
        if (!ich || !fz) return null;

        var weg = [];
        var p = ich.komponente.parentId;
        while (p && nachId[p]) { weg.unshift(nachId[p]); p = nachId[p].komponente.parentId; }

        function anzahlKinder(x) {
          return alle.filter(function (y) { return y.komponente.parentId === x.komponente.id; }).length;
        }
        var kinder = self.sortiereKomponenten(alle.filter(function (x) { return x.komponente.parentId === id; }))
          .map(function (x) { return { komponente: x.komponente, aktuell: x.aktuell, anzahlKinder: anzahlKinder(x) }; });

        var felder = MM.Komponenten.felder();
        var verlauf = ich.eintraege.map(function (e, i) {
          var vorher = i > 0 ? ich.eintraege[i - 1] : null;
          return { eintrag: e, vorher: vorher, aenderungen: vorher ? unterschiedeFelder(felder, vorher.werte, e.werte) : [] };
        }).reverse();

        return { komponente: ich.komponente, aktuell: ich.aktuell, verlauf: verlauf, weg: weg, kinder: kinder,
          fahrzeug: fz.fahrzeug, fahrzeugAktuell: fz.aktuell, tiefe: weg.length + 3 };
      });
    });
  };

  /* ---------- Hilfen für Zähler und Fristen ---------- */
  Daten.prototype.heute = function () {
    var d = new Date(this.jetzt());
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
  };

  function jahrVon(self) { return new Date(self.jetzt()).getFullYear(); }

  /* Prüft, ob Fahrzeug (und Komponente) existieren und zusammengehören. Gibt null oder einen Fehler zurück. */
  Daten.prototype.pruefeObjekt = function (fahrzeugId, komponenteId) {
    return Promise.all([
      this.speicher.holen('fahrzeuge', fahrzeugId),
      komponenteId ? this.speicher.holen('komponenten', komponenteId) : Promise.resolve(null)
    ]).then(function (r) {
      if (!r[0]) return { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' };
      if (komponenteId && (!r[1] || r[1].fahrzeugId !== fahrzeugId)) return { allgemein: 'Diese Komponente wurde nicht gefunden.' };
      return null;
    });
  };

  /* Verlauf der Angaben zu einem Objekt (Zähler, Frist): neueste zuerst, mit Unterschieden. */
  function verlaufAus(eintraege, felder) {
    var auf = eintraege.slice().sort(nachNr);
    return auf.map(function (e, i) {
      var vorher = i > 0 ? auf[i - 1] : null;
      return { eintrag: e, vorher: vorher, aenderungen: vorher ? unterschiedeFelder(felder, vorher.werte, e.werte) : [] };
    }).reverse();
  }
  function neuerVerlaufEintrag(typ, objektId, nr, werte, korrekturZu, jetzt) {
    return { id: neueId('vl'), objektTyp: typ, objektId: objektId, nr: nr, werte: werte,
      quelle: 'hand', korrekturZu: korrekturZu, erstelltAm: jetzt };
  }

  /* ---------- Zähler und Zählerstände ---------- */
  /*
   * Ein Zähler zählt Strecke (km) oder Betriebsstunden (h) und hängt am
   * Fahrzeug oder an einer einzelnen Komponente (zum Beispiel pro Motor).
   * Der Stand ist ein Verlauf von Einträgen. Der aktuelle Stand ist der
   * neueste Eintrag, ein Handeintrag hat Vorrang.
   */
  Daten.prototype.zaehlerAnlegen = function (fahrzeugId, komponenteId, art, roh) {
    var self = this;
    var p = pruefeWerte([], roh, jahrVon(this));
    var fehler = p.fehler;
    if (!MM.Fristen.zaehlerArt(art)) fehler.art = 'Bitte wählen, ob der Zähler Strecke oder Betriebsstunden zählt.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      var jetzt = self.jetzt();
      var z = { id: neueId('za'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, art: art, erstelltAm: jetzt };
      var e = neuerVerlaufEintrag('zaehler', z.id, 1, p.werte, null, jetzt);
      return self.speicher.mehrereSpeichern([{ tabelle: 'zaehler', objekt: z }, { tabelle: 'verlaeufe', objekt: e }])
        .then(function () { return { ok: true, id: z.id }; });
    });
  };

  Daten.prototype.zaehlerAendern = function (zaehlerId, roh) {
    var self = this;
    return this.zaehlerLaden(zaehlerId).then(function (z) {
      if (!z) return { ok: false, fehler: { allgemein: 'Dieser Zähler wurde nicht gefunden.' } };
      var p = pruefeWerte([], roh, jahrVon(self));
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (!unterschiedeFelder([], z.aktuell.werte, p.werte).length) return { ok: true, id: zaehlerId, geaendert: false };
      var e = neuerVerlaufEintrag('zaehler', zaehlerId, z.aktuell.nr + 1, p.werte, z.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: zaehlerId, geaendert: true }; });
    });
  };

  var FELDER_STAND = [
    { key: 'wert', label: 'Zählerstand', typ: 'zahl' },
    { key: 'datum', label: 'Abgelesen am', typ: 'datum' },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  Daten.prototype.zaehlerStandEintragen = function (zaehlerId, roh) {
    var self = this;
    var p = pruefeWerte(FELDER_STAND, roh, jahrVon(this), { ohneBezeichnung: true });
    var fehler = p.fehler, w = p.werte, heute = this.heute();
    if (w.wert === null && !fehler.wert) fehler.wert = 'Bitte den Zählerstand eingeben.';
    if (!w.datum && !fehler.datum) w.datum = heute;
    if (w.datum && w.datum > heute && !fehler.datum) fehler.datum = 'Das Datum liegt in der Zukunft.';
    return this.speicher.holen('zaehler', zaehlerId).then(function (z) {
      if (!z) return { ok: false, fehler: { allgemein: 'Dieser Zähler wurde nicht gefunden.' } };
      return self.speicher.wo('zaehlerstaende', 'zaehlerId', zaehlerId).then(function (staende) {
        var letzter = staende.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
        if (letzter && w.wert !== null && w.wert < letzter.wert && !fehler.wert) {
          var einheit = MM.Fristen.zaehlerArt(z.art).einheit;
          fehler.wert = 'Der Stand ist niedriger als der letzte Eintrag (' + MM.Hilfen.zahl(letzter.wert) + ' ' + einheit +
            ' vom ' + MM.Hilfen.datum(letzter.datum) + '). Zählerstände steigen. Wurde der Zähler getauscht, lege einen neuen Zähler an.';
        }
        if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
        var e = { id: neueId('zs'), zaehlerId: zaehlerId, nr: letzter ? letzter.nr + 1 : 1, wert: w.wert, datum: w.datum,
          notiz: w.notiz, quelle: 'hand', erstelltAm: self.jetzt() };
        return self.speicher.speichern('zaehlerstaende', e).then(function () { return { ok: true, id: e.id }; });
      });
    });
  };

  /* Alle Zähler eines Fahrzeugs mit Name, aktuellem Stand und Besitzer (Fahrzeug oder Komponente). */
  Daten.prototype.zaehlerListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([
      this.speicher.wo('zaehler', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.speicher.alle('zaehlerstaende'),
      this.komponentenListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'zaehler') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var sta = {}; r[2].forEach(function (e) { (sta[e.zaehlerId] = sta[e.zaehlerId] || []).push(e); });
      var kn = {}; r[3].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      return r[0].map(function (z) {
        var namen = (ver[z.id] || []).slice().sort(nachNr);
        var aktuell = namen[namen.length - 1];
        if (!aktuell) return null;
        var liste = (sta[z.id] || []).slice().sort(nachNr);
        var letzter = liste[liste.length - 1] || null;
        var art = MM.Fristen.zaehlerArt(z.art);
        var besitzer = z.komponenteId ? (kn[z.komponenteId] || 'Komponente') : 'Fahrzeug';
        return { zaehler: z, bezeichnung: aktuell.werte.bezeichnung, einheit: art.einheit, art: z.art,
          stand: letzter ? { wert: letzter.wert, datum: letzter.datum } : null,
          komponenteId: z.komponenteId, besitzer: besitzer,
          label: aktuell.werte.bezeichnung + ' (' + besitzer + ')' };
      }).filter(Boolean).sort(function (a, b) { return a.label.localeCompare(b.label, 'de', { numeric: true }); });
    });
  };

  Daten.prototype.zaehlerLaden = function (id) {
    var self = this;
    return this.speicher.holen('zaehler', id).then(function (z) {
      if (!z) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('zaehlerstaende', 'zaehlerId', id),
        self.fahrzeugLaden(z.fahrzeugId),
        self.komponentenListe(z.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[2]) return null;
        var staende = r[1].slice().sort(nachNr).reverse();
        var komp = z.komponenteId ? r[3].filter(function (k) { return k.komponente.id === z.komponenteId; })[0] : null;
        var art = MM.Fristen.zaehlerArt(z.art);
        return { zaehler: z, aktuell: eintraege[eintraege.length - 1], bezeichnung: eintraege[eintraege.length - 1].werte.bezeichnung,
          verlauf: verlaufAus(eintraege, []), staende: staende, stand: staende[0] || null, art: art, einheit: art.einheit,
          fahrzeug: r[2].fahrzeug, fahrzeugAktuell: r[2].aktuell, komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /* ---------- Fristen ---------- */
  Daten.prototype.pruefenFrist = function (roh, mitAusgang) {
    var p = pruefeWerte(MM.Fristen.felder(mitAusgang), roh, jahrVon(this));
    var w = p.werte, f = p.fehler;
    if (!w.kategorie && !f.kategorie) f.kategorie = 'Bitte die Art der Frist wählen.';
    if (w.kalenderWert) { if (!w.kalenderEinheit) w.kalenderEinheit = 'monate'; } else { w.kalenderEinheit = null; }
    if (!w.wirkung) w.wirkung = 'warnen';
    if (w.vorwarnTage === null || w.vorwarnTage === undefined) w.vorwarnTage = 0;
    var hatZ = !!w.zaehlerId, hatW = w.zaehlerWert !== null && w.zaehlerWert !== undefined;
    if (hatZ && !hatW && !f.zaehlerWert) f.zaehlerWert = 'Bitte angeben, nach wie viel Strecke oder Stunden die Frist fällig wird.';
    if (!hatZ && hatW && !f.zaehlerId) f.zaehlerId = 'Bitte einen Zähler wählen oder die Zählergrenze leer lassen.';
    if (hatW && w.zaehlerWert <= 0 && !f.zaehlerWert) f.zaehlerWert = 'Die Grenze muss größer als null sein.';
    if (!w.kalenderWert && !(hatZ && hatW) && !f.kalenderWert && !f.zaehlerWert && !f.zaehlerId) {
      f.kalenderWert = 'Bitte mindestens eine Grenze angeben: Zeit oder Zähler.';
    }
    if (!hatZ) { w.zaehlerId = null; w.zaehlerWert = null; w.vorwarnZaehler = null; }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Letzte Erledigung: das späteste Datum, bei gleichem Datum die zuletzt eingetragene. */
  function letzteDurchfuehrung(liste) {
    return liste.reduce(function (a, b) {
      if (!a) return b;
      if (b.datum !== a.datum) return b.datum > a.datum ? b : a;
      return b.erstelltAm >= a.erstelltAm ? b : a;
    }, null);
  }

  function statusZu(self, frist, werte, durchfuehrungen, zaehlerInfo) {
    var letzte = letzteDurchfuehrung(durchfuehrungen);
    if (!letzte) return { status: 'unbekannt', kalender: null, zaehler: null, grund: 'Es gibt noch keine Erledigung als Ausgangswert.' };
    var res = MM.Fristen.berechne({ werte: werte, letzte: letzte, stand: zaehlerInfo ? zaehlerInfo.stand : null, heute: self.heute() });
    res.letzte = letzte;
    return res;
  }

  Daten.prototype.fristAnlegen = function (fahrzeugId, komponenteId, roh) {
    var self = this;
    var p = this.pruefenFrist(roh, true);
    var w = p.werte, fehler = p.fehler, heute = this.heute();
    var zuletztAm = w.zuletztAm, zuletztStand = w.zuletztStand;
    delete w.zuletztAm; delete w.zuletztStand;
    if (zuletztAm && zuletztAm > heute && !fehler.zuletztAm) fehler.zuletztAm = 'Das Datum liegt in der Zukunft.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return self.zaehlerListe(fahrzeugId).then(function (liste) {
        var z = w.zaehlerId ? liste.filter(function (x) { return x.zaehler.id === w.zaehlerId; })[0] : null;
        if (w.zaehlerId && !z) return { ok: false, fehler: { zaehlerId: 'Dieser Zähler gehört nicht zu diesem Fahrzeug.' } };
        var basisDatum = zuletztAm || heute;
        var basisStand = zuletztStand;
        if (basisStand === null && !zuletztAm && z && z.stand) basisStand = z.stand.wert;
        var e2 = {};
        if (z && basisStand === null) e2.zuletztStand = 'Bitte den Zählerstand angeben, bei dem die Frist zuletzt erledigt wurde, oder trage zuerst einen aktuellen Zählerstand ein.';
        if (z && basisStand !== null && z.stand && basisStand > z.stand.wert) {
          e2.zuletztStand = 'Dieser Stand ist höher als der aktuelle Zählerstand (' + MM.Hilfen.zahl(z.stand.wert) + ' ' + z.einheit + '). Trage zuerst den aktuellen Zählerstand ein.';
        }
        if (Object.keys(e2).length) return { ok: false, fehler: e2 };

        var jetzt = self.jetzt();
        var fr = { id: neueId('fr'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, erstelltAm: jetzt };
        var ve = neuerVerlaufEintrag('frist', fr.id, 1, w, null, jetzt);
        var du = { id: neueId('du'), fristId: fr.id, datum: basisDatum, zaehlerstand: z ? basisStand : null,
          notiz: 'Ausgangswert bei Anlage der Frist', art: 'ausgangswert', quelle: 'hand', erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'fristen', objekt: fr }, { tabelle: 'verlaeufe', objekt: ve }, { tabelle: 'durchfuehrungen', objekt: du }
        ]).then(function () { return { ok: true, id: fr.id }; });
      });
    });
  };

  Daten.prototype.fristAendern = function (fristId, roh) {
    var self = this;
    return this.fristLaden(fristId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Diese Frist wurde nicht gefunden.' } };
      var p = self.pruefenFrist(roh, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.zaehlerListe(f.frist.fahrzeugId).then(function (liste) {
        if (p.werte.zaehlerId && !liste.some(function (x) { return x.zaehler.id === p.werte.zaehlerId; })) {
          return { ok: false, fehler: { zaehlerId: 'Dieser Zähler gehört nicht zu diesem Fahrzeug.' } };
        }
        if (!unterschiedeFelder(MM.Fristen.felder(false), f.aktuell.werte, p.werte).length) return { ok: true, id: fristId, geaendert: false };
        var e = neuerVerlaufEintrag('frist', fristId, f.aktuell.nr + 1, p.werte, f.aktuell.id, self.jetzt());
        return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: fristId, geaendert: true }; });
      });
    });
  };

  var FELDER_ERLEDIGT = [
    { key: 'datum', label: 'Erledigt am', typ: 'datum' },
    { key: 'zaehlerstand', label: 'Zählerstand dabei', typ: 'zahl', min: 0 },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  /* Eine Erledigung (Prüfung, Kontrolle, Arbeit). Sie setzt die Rechnung der Frist neu an. */
  Daten.prototype.durchfuehrungAnlegen = function (fristId, roh) {
    var self = this;
    var p = pruefeWerte(FELDER_ERLEDIGT, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, fehler = p.fehler, heute = this.heute();
    if (!w.datum && !fehler.datum) w.datum = heute;
    if (w.datum && w.datum > heute && !fehler.datum) fehler.datum = 'Das Datum liegt in der Zukunft.';
    return this.fristLaden(fristId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Diese Frist wurde nicht gefunden.' } };
      var z = f.zaehler;
      var neuerStand = null;
      if (z && !fehler.zaehlerstand) {
        if (w.zaehlerstand === null) {
          if (w.datum === heute && z.stand) w.zaehlerstand = z.stand.wert;
          else fehler.zaehlerstand = 'Bitte den Zählerstand angeben, bei dem die Frist erledigt wurde.';
        } else if (f.letzte && f.letzte.zaehlerstand !== null && f.letzte.zaehlerstand !== undefined && w.zaehlerstand < f.letzte.zaehlerstand) {
          fehler.zaehlerstand = 'Der Stand ist niedriger als bei der letzten Erledigung (' + MM.Hilfen.zahl(f.letzte.zaehlerstand) + ' ' + z.einheit + ').';
        }
        if (!fehler.zaehlerstand && w.zaehlerstand !== null && (!z.stand || w.zaehlerstand > z.stand.wert)) neuerStand = w.zaehlerstand;
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };

      var jetzt = self.jetzt();
      var du = { id: neueId('du'), fristId: fristId, datum: w.datum, zaehlerstand: w.zaehlerstand, notiz: w.notiz,
        art: 'erledigt', quelle: 'hand', erstelltAm: jetzt };
      var liste = [{ tabelle: 'durchfuehrungen', objekt: du }];
      if (neuerStand === null) return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: du.id }; });
      /* Ist der Stand höher als der bisher bekannte, wird er auch im Zähler eingetragen (eine Quelle). */
      return self.speicher.wo('zaehlerstaende', 'zaehlerId', z.zaehler.id).then(function (staende) {
        var nr = staende.reduce(function (m, e) { return Math.max(m, e.nr); }, 0) + 1;
        liste.push({ tabelle: 'zaehlerstaende', objekt: { id: neueId('zs'), zaehlerId: z.zaehler.id, nr: nr, wert: neuerStand,
          datum: w.datum, notiz: 'Bei Erledigung: ' + f.aktuell.werte.bezeichnung, quelle: 'hand', erstelltAm: jetzt } });
        return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: du.id }; });
      });
    });
  };

  /* Alle Fristen eines Fahrzeugs mit gerechnetem Stand. Sortiert: überfällig zuerst. */
  Daten.prototype.fristenListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([
      this.speicher.wo('fristen', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.speicher.alle('durchfuehrungen'),
      this.zaehlerListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'frist') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var du = {}; r[2].forEach(function (e) { (du[e.fristId] = du[e.fristId] || []).push(e); });
      var zl = {}; r[3].forEach(function (z) { zl[z.zaehler.id] = z; });
      var res = r[0].map(function (fr) {
        var eintraege = (ver[fr.id] || []).slice().sort(nachNr);
        var aktuell = eintraege[eintraege.length - 1];
        if (!aktuell) return null;
        var z = aktuell.werte.zaehlerId ? zl[aktuell.werte.zaehlerId] || null : null;
        return { frist: fr, aktuell: aktuell, zaehler: z, status: statusZu(self, fr, aktuell.werte, du[fr.id] || [], z) };
      }).filter(Boolean);
      res.sort(function (a, b) {
        var d = MM.Fristen.rang(b.status.status) - MM.Fristen.rang(a.status.status);
        return d || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true });
      });
      return res;
    });
  };

  Daten.prototype.fristLaden = function (id) {
    var self = this;
    return this.speicher.holen('fristen', id).then(function (fr) {
      if (!fr) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('durchfuehrungen', 'fristId', id),
        self.zaehlerListe(fr.fahrzeugId),
        self.fahrzeugLaden(fr.fahrzeugId),
        self.komponentenListe(fr.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[3]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        var zl = r[2];
        var z = aktuell.werte.zaehlerId ? zl.filter(function (x) { return x.zaehler.id === aktuell.werte.zaehlerId; })[0] || null : null;
        var du = r[1].slice().sort(function (a, b) { return a.datum !== b.datum ? (a.datum < b.datum ? 1 : -1) : (a.erstelltAm < b.erstelltAm ? 1 : -1); });
        var verlauf = verlaufAus(eintraege, MM.Fristen.felder(false));
        /* Zähler im Verlauf mit Namen statt Kennung zeigen */
        var namen = {}; zl.forEach(function (x) { namen[x.zaehler.id] = x.label; });
        verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'zaehlerId') { u.alt = u.alt ? (namen[u.alt] || 'unbekannter Zähler') : null; u.neu = u.neu ? (namen[u.neu] || 'unbekannter Zähler') : null; }
          });
        });
        var komp = fr.komponenteId ? r[4].filter(function (k) { return k.komponente.id === fr.komponenteId; })[0] : null;
        return { frist: fr, aktuell: aktuell, verlauf: verlauf, durchfuehrungen: du, letzte: letzteDurchfuehrung(r[1]),
          zaehler: z, zaehlerListe: zl, status: statusZu(self, fr, aktuell.werte, r[1], z),
          fahrzeug: r[3].fahrzeug, fahrzeugAktuell: r[3].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /* Pro Fahrzeug: wie viele Fristen sind überfällig oder bald fällig? */
  Daten.prototype.fristenUebersicht = function () {
    var self = this;
    return this.fahrzeugListe().then(function (liste) {
      return Promise.all(liste.map(function (x) { return self.fristenListe(x.fahrzeug.id); })).then(function (alle) {
        var res = {};
        liste.forEach(function (x, i) {
          var z = { ueberfaellig: 0, bald: 0, unbekannt: 0 };
          alle[i].forEach(function (f) { if (z[f.status.status] !== undefined) z[f.status.status]++; });
          res[x.fahrzeug.id] = z;
        });
        return res;
      });
    });
  };

  /* ---------- Dokumente ---------- */
  /*
   * Ein Dokument ist eine Datei vom Gerät oder ein Link. Die Datei liegt in
   * einer eigenen Ablage, getrennt vom Eintrag. Das Dokument selbst bleibt
   * unverändert: Wer eine andere Datei will, legt ein neues Dokument an.
   */
  Daten.prototype.pruefenDokument = function (roh, quelle) {
    var p = pruefeWerte(MM.Dokumente.felder(quelle), roh, jahrVon(this));
    var w = p.werte, f = p.fehler;
    if (!w.art && !f.art) f.art = 'Bitte die Art des Dokuments wählen.';
    if (quelle === 'link') {
      if (!String(roh.link == null ? '' : roh.link).trim()) f.link = 'Bitte den Link eingeben.';
      else {
        var l = MM.Dokumente.normalisiereLink(roh.link);
        if (!l) { if (!f.link) f.link = 'Das ist kein gültiger Link. Er soll mit http oder https beginnen, zum Beispiel https://www.beispiel.de/anleitung.pdf'; }
        else w.link = l;
      }
    } else { w.link = null; }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  function istQuotaFehler(err) {
    return !!err && (err.name === 'QuotaExceededError' || /quota/i.test(String(err.message || '')));
  }

  Daten.prototype.dokumentAnlegen = function (fahrzeugId, komponenteId, roh) {
    var self = this;
    roh = roh || {};
    var quelle = roh.quelle, datei = roh.datei, fehler = {};
    if (quelle !== 'datei' && quelle !== 'link') fehler.quelle = 'Bitte wählen, ob du eine Datei oder einen Link ablegen möchtest.';
    if (quelle === 'datei' && !(datei && typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Bitte eine Datei auswählen.';
    var rohW = Object.assign({}, roh);
    if (quelle === 'datei' && !String(rohW.bezeichnung == null ? '' : rohW.bezeichnung).trim() && datei && datei.name) {
      rohW.bezeichnung = String(datei.name).replace(/\.[^.]+$/, '');
    }
    var p = this.pruefenDokument(rohW, quelle);
    Object.keys(p.fehler).forEach(function (k) { fehler[k] = p.fehler[k]; });
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      var jetzt = self.jetzt();
      var w = p.werte;
      w.quelle = quelle;
      w.dateiName = quelle === 'datei' ? String(datei.name || 'Datei') : null;
      w.dateiTyp = quelle === 'datei' ? String(datei.type || '') : null;
      w.dateiGroesse = quelle === 'datei' ? datei.size : null;
      var d = { id: neueId('do'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, erstelltAm: jetzt };
      var liste = [
        { tabelle: 'dokumente', objekt: d },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('dokument', d.id, 1, w, null, jetzt) }
      ];
      if (quelle === 'datei') {
        liste.push({ tabelle: 'dateien', objekt: { id: neueId('da'), dokumentId: d.id, name: w.dateiName, mime: w.dateiTyp,
          groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      }
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: d.id }; })
        .catch(function (err) {
          if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei. Gib Platz frei oder wähle eine kleinere Datei.' } };
          throw err;
        });
    });
  };

  Daten.prototype.dokumentAendern = function (dokumentId, roh) {
    var self = this;
    return this.dokumentLaden(dokumentId).then(function (d) {
      if (!d) return { ok: false, fehler: { allgemein: 'Dieses Dokument wurde nicht gefunden.' } };
      var quelle = d.aktuell.werte.quelle;
      var p = self.pruefenDokument(roh, quelle);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, d.aktuell.werte, p.werte);
      if (!unterschiedeFelder(MM.Dokumente.felder(quelle), d.aktuell.werte, neu).length) return { ok: true, id: dokumentId, geaendert: false };
      var e = neuerVerlaufEintrag('dokument', dokumentId, d.aktuell.nr + 1, neu, d.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: dokumentId, geaendert: true }; });
    });
  };

  Daten.prototype.dokumentLaden = function (id) {
    var self = this;
    return this.speicher.holen('dokumente', id).then(function (d) {
      if (!d) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('dateien', 'dokumentId', id),
        self.fahrzeugLaden(d.fahrzeugId),
        self.komponentenListe(d.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[2]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        var komp = d.komponenteId ? r[3].filter(function (k) { return k.komponente.id === d.komponenteId; })[0] : null;
        var datei = r[1][0] ? { id: r[1][0].id, name: r[1][0].name, mime: r[1][0].mime, groesse: r[1][0].groesse } : null;
        return { dokument: d, aktuell: aktuell, verlauf: verlaufAus(eintraege, MM.Dokumente.felder(aktuell.werte.quelle)), datei: datei,
          fahrzeug: r[2].fahrzeug, fahrzeugAktuell: r[2].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /* Die Datei selbst (mit Inhalt), zum Öffnen oder Speichern. */
  Daten.prototype.dateiHolen = function (dokumentId) {
    return this.speicher.wo('dateien', 'dokumentId', dokumentId).then(function (l) { return l[0] || null; });
  };

  /* Alle Dokumente eines Fahrzeugs und seiner Komponenten. Zuerst das Fahrzeug, dann die Komponenten nach Name. */
  Daten.prototype.dokumenteListe = function (fahrzeugId) {
    return Promise.all([
      this.speicher.wo('dokumente', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.komponentenListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'dokument') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var kn = {}; r[2].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      var res = r[0].map(function (d) {
        var l = (ver[d.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1];
        if (!a) return null;
        return { dokument: d, aktuell: a, komponenteId: d.komponenteId, besitzer: d.komponenteId ? (kn[d.komponenteId] || 'Komponente') : null };
      }).filter(Boolean);
      res.sort(function (a, b) {
        if (!a.besitzer !== !b.besitzer) return a.besitzer ? 1 : -1;
        var o = (a.besitzer || '').localeCompare(b.besitzer || '', 'de', { numeric: true, sensitivity: 'base' });
        if (o) return o;
        var art = MM.Dokumente.artIndex(a.aktuell.werte.art) - MM.Dokumente.artIndex(b.aktuell.werte.art);
        return art || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return res;
    });
  };

  /* Scans und Fotos von Nachweisen: bleiben immer nur auf diesem Gerät. */
  Daten.prototype.scansBelegung = function () {
    return this.speicher.alle('nachweisdateien').then(function (l) {
      return { anzahl: l.length, bytes: l.reduce(function (s, x) { return s + (x.groesse || 0); }, 0) };
    });
  };

  /* Wie viel Platz belegen die Dateien auf diesem Gerät? */
  Daten.prototype.dateienBelegung = function () {
    return this.speicher.alle('dateien').then(function (l) {
      return { anzahl: l.length, bytes: l.reduce(function (s, x) { return s + (x.groesse || 0); }, 0) };
    });
  };

  /* ---------- Personen und Tiere ---------- */
  function tabelleVon(typ) { return typ === 'person' ? 'personen' : (typ === 'tier' ? 'tiere' : 'fahrzeuge'); }
  function trimmed(v) { return String(v == null ? '' : v).trim(); }

  Daten.prototype.pruefenPerson = function (roh) {
    var p = pruefeWerte(MM.Personen.personFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen eingeben.' });
    var w = p.werte, f = p.fehler;
    if (w.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(w.email)) f.email = 'Das ist keine gültige E-Mail-Adresse.';
    if (w.telefon && !/^[0-9+\-\/() ]{5,}$/.test(w.telefon)) f.telefon = 'Bitte nur Ziffern, Leerzeichen und + - / ( ) eingeben.';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.pruefenTier = function (roh) {
    var p = pruefeWerte(MM.Personen.tierFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen eingeben.' });
    var w = p.werte, f = p.fehler;
    if (!w.tierart && !f.tierart) f.tierart = 'Bitte die Tierart wählen.';
    if (w.chipnummer) {
      var c = w.chipnummer.replace(/[\s-]/g, '');
      if (!/^\d{9,15}$/.test(c)) f.chipnummer = 'Die Chipnummer besteht aus Ziffern, meist 15.'; else w.chipnummer = c;
    }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Gemeinsame Bausteine für Dinge mit Verlauf: Person, Tier. */
  Daten.prototype.mitVerlaufAnlegen = function (tabelle, typ, praefix, werte, extra) {
    var jetzt = this.jetzt();
    var o = { id: neueId(praefix), datenraumId: this.datenraumId, erstelltAm: jetzt };
    if (extra) { for (var k in extra) { o[k] = extra[k]; } }
    return this.speicher.mehrereSpeichern([
      { tabelle: tabelle, objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag(typ, o.id, 1, werte, null, jetzt) }
    ]).then(function () { return { ok: true, id: o.id }; });
  };

  Daten.prototype.mitVerlaufLaden = function (tabelle, id, felder) {
    var self = this;
    return Promise.all([this.speicher.holen(tabelle, id), this.speicher.wo('verlaeufe', 'objektId', id)]).then(function (r) {
      if (!r[0] || !r[1].length) return null;
      var eintraege = r[1].slice().sort(nachNr);
      return { objekt: r[0], aktuell: eintraege[eintraege.length - 1], verlauf: verlaufAus(eintraege, felder || []) };
    });
  };

  Daten.prototype.mitVerlaufAendern = function (typ, id, geladen, neu, felder) {
    if (!unterschiedeFelder(felder, geladen.aktuell.werte, neu).length) return Promise.resolve({ ok: true, id: id, geaendert: false });
    var e = neuerVerlaufEintrag(typ, id, geladen.aktuell.nr + 1, neu, geladen.aktuell.id, this.jetzt());
    return this.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: id, geaendert: true }; });
  };

  Daten.prototype.personAnlegen = function (roh) {
    var p = this.pruefenPerson(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.mitVerlaufAnlegen('personen', 'person', 'pe', p.werte);
  };
  Daten.prototype.personAendern = function (id, roh) {
    var self = this;
    return this.personLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Person wurde nicht gefunden.' } };
      var p = self.pruefenPerson(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('person', id, x, p.werte, MM.Personen.personFelder());
    });
  };
  Daten.prototype.personLaden = function (id) { return this.mitVerlaufLaden('personen', id, MM.Personen.personFelder()); };
  Daten.prototype.personenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('personen'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'person');
    });
  };

  Daten.prototype.tierAnlegen = function (roh) {
    var p = this.pruefenTier(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.mitVerlaufAnlegen('tiere', 'tier', 'ti', p.werte);
  };
  Daten.prototype.tierAendern = function (id, roh) {
    var self = this;
    return this.tierLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Tier wurde nicht gefunden.' } };
      var p = self.pruefenTier(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('tier', id, x, p.werte, MM.Personen.tierFelder());
    });
  };
  Daten.prototype.tierLaden = function (id) { return this.mitVerlaufLaden('tiere', id, MM.Personen.tierFelder()); };
  Daten.prototype.tiereListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('tiere'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'tier');
    });
  };

  /* Objekte mit aktuellem Stand, nach Namen sortiert. */
  function sammle(self, objekte, verlaeufe, typ) {
    var ver = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === typ) (ver[e.objektId] = ver[e.objektId] || []).push(e); });
    var liste = objekte.filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
      var l = (ver[o.id] || []).slice().sort(nachNr);
      return { objekt: o, aktuell: l[l.length - 1] || null };
    }).filter(function (x) { return x.aktuell; });
    liste.sort(function (a, b) { return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' }); });
    return liste;
  }

  /* ---------- Nachweisarten (offene Liste) ---------- */
  var ART_FELDER = [
    { key: 'bezeichnung', label: 'Name der Art' },
    { key: 'hatAblauf', label: 'Mit Ablaufdatum', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN },
    { key: 'land', label: 'Land', typ: 'text' },
    { key: 'beschreibung', label: 'Beschreibung', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN },
    { key: 'felder', label: 'Weitere Angaben', typ: 'zeilen' }
  ];

  Daten.prototype.pruefenNachweisart = function (roh, neu) {
    roh = roh || {};
    var f = {}, w = {};
    var bez = trimmed(roh.bezeichnung);
    if (!bez) f.bezeichnung = 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segelschein“.';
    w.bezeichnung = bez;
    if (neu) {
      if (!MM.Nachweise.BESITZER.some(function (b) { return b.wert === roh.gehoertZu; })) f.gehoertZu = 'Bitte wählen, wofür der Nachweis gilt: Person, Tier oder Fahrzeug.';
      else w.gehoertZu = roh.gehoertZu;
    }
    w.hatAblauf = roh.hatAblauf === 'ja' ? 'ja' : 'nein';
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    w.land = trimmed(roh.land) || null;
    w.beschreibung = trimmed(roh.beschreibung) || null;

    var zeilen = Array.isArray(roh.felder) ? roh.felder : [];
    var belegt = {}, hoechste = 0;
    zeilen.forEach(function (z) { var m = /^z(\d+)$/.exec(z && z.key || ''); if (m) { belegt[z.key] = true; hoechste = Math.max(hoechste, +m[1]); } });
    var sauber = [], benutzt = {};
    zeilen.forEach(function (z) {
      var label = trimmed(z && z.label), papier = trimmed(z && z.papier);
      if (!label && !papier) return;
      if (!label) { f.felder = 'Bitte bei jeder weiteren Angabe eine Beschriftung eingeben.'; return; }
      var typ = MM.Nachweise.FELDTYPEN.some(function (t) { return t.wert === z.typ; }) ? z.typ : 'text';
      var key = z.key && /^z\d+$/.test(z.key) && !benutzt[z.key] ? z.key : null;
      if (!key) { hoechste++; key = 'z' + hoechste; }
      benutzt[key] = true;
      sauber.push({ key: key, label: label, typ: typ, papier: papier });
    });
    w.felder = sauber;
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.nachweisartAnlegen = function (roh) {
    var p = this.pruefenNachweisart(roh, true);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var w = p.werte;
    w.gemeinsam = {}; w.ohne = []; w.herkunft = 'eigen'; w.vorschlagId = null;
    w.quelleTitel = null; w.quelleUrl = null; w.pruefstatus = null; w.geprueftAm = null;
    return this.mitVerlaufAnlegen('nachweisarten', 'nachweisart', 'na', w);
  };

  /* Übernimmt einen Vorschlag als eigene Art. Danach ist sie frei änderbar. */
  Daten.prototype.nachweisartAusVorschlag = function (vorschlagId) {
    var self = this;
    var v = MM.NachweisVorschlaege.finde(vorschlagId);
    if (!v) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diesen Vorschlag gibt es nicht.' } });
    return this.nachweisartenListe().then(function (liste) {
      var vorhanden = liste.filter(function (x) { return x.aktuell.werte.vorschlagId === vorschlagId; })[0];
      if (vorhanden) return { ok: false, vorhanden: true, id: vorhanden.objekt.id, fehler: { allgemein: 'Diese Art ist schon übernommen.' } };
      return self.mitVerlaufAnlegen('nachweisarten', 'nachweisart', 'na', {
        bezeichnung: v.name, gehoertZu: v.gehoertZu, hatAblauf: v.hatAblauf ? 'ja' : 'nein', ausgeblendet: 'nein',
        land: v.land, beschreibung: v.hinweis || null, gemeinsam: v.gemeinsam, ohne: v.ohne, felder: v.felder,
        herkunft: 'vorschlag', vorschlagId: v.id, quelleTitel: v.quelle ? v.quelle.titel : null, quelleUrl: v.quelle ? v.quelle.url : null,
        pruefstatus: v.pruefstatus, geprueftAm: v.geprueftAm
      });
    });
  };

  Daten.prototype.nachweisartAendern = function (id, roh) {
    var self = this;
    return this.nachweisartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var p = self.pruefenNachweisart(roh, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, x.aktuell.werte, p.werte);
      return self.mitVerlaufAendern('nachweisart', id, x, neu, ART_FELDER);
    });
  };

  Daten.prototype.nachweisartLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('nachweisarten', id, ART_FELDER).then(function (x) {
      if (!x) return null;
      return self.speicher.alle('nachweise').then(function (n) {
        x.anzahlNachweise = n.filter(function (k) { return k.artId === id; }).length;
        x.art = x.objekt; x.werte = x.aktuell.werte;
        return x;
      });
    });
  };

  /* Alle Arten, nach Besitzer (Person, Tier, Fahrzeug) und Name geordnet. */
  Daten.prototype.nachweisartenListe = function (gehoertZu) {
    var self = this;
    return Promise.all([this.speicher.alle('nachweisarten'), this.speicher.alle('verlaeufe'), this.speicher.alle('nachweise')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'nachweisart');
      var anzahl = {}; r[2].forEach(function (n) { anzahl[n.artId] = (anzahl[n.artId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlNachweise = anzahl[x.objekt.id] || 0; });
      if (gehoertZu) liste = liste.filter(function (x) { return x.aktuell.werte.gehoertZu === gehoertZu; });
      var reihenfolge = { person: 0, tier: 1, fahrzeug: 2 };
      liste.sort(function (a, b) {
        var o = reihenfolge[a.aktuell.werte.gehoertZu] - reihenfolge[b.aktuell.werte.gehoertZu];
        return o || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return liste;
    });
  };

  /* ---------- Nachweise ---------- */
  Daten.prototype.besitzerLaden = function (typ, id) {
    if (typ === 'fahrzeug') return this.fahrzeugLaden(id).then(function (f) { return f ? { name: f.aktuell.werte.bezeichnung, id: id } : null; });
    return this.mitVerlaufLaden(tabelleVon(typ), id, []).then(function (x) { return x ? { name: x.aktuell.werte.bezeichnung, id: id } : null; });
  };

  function artStatus(art, werte, heute) { return MM.Nachweise.status(art, werte, heute); }

  Daten.prototype.nachweisAnlegen = function (besitzerTyp, besitzerId, artId, roh) {
    var self = this;
    roh = roh || {};
    return Promise.all([this.nachweisartLaden(artId), this.besitzerLaden(besitzerTyp, besitzerId)]).then(function (r) {
      var art = r[0], besitzer = r[1];
      if (!art) return { ok: false, fehler: { artId: 'Bitte zuerst die Art des Nachweises wählen.' } };
      if (!besitzer) return { ok: false, fehler: { allgemein: 'Dazu wurde nichts gefunden.' } };
      var aw = art.aktuell.werte;
      if (aw.gehoertZu !== besitzerTyp) return { ok: false, fehler: { artId: 'Diese Art gilt nicht hierfür.' } };
      if (aw.ausgeblendet === 'ja') return { ok: false, fehler: { artId: 'Diese Art ist ausgeblendet.' } };

      var felder = MM.Nachweise.felderFuer(aw);
      var p = pruefeWerte(felder, roh, jahrVon(self), { ohneBezeichnung: true });
      var fehler = p.fehler, w = p.werte;
      if (w.ausgestelltAm && w.gueltigBis && w.gueltigBis < w.ausgestelltAm && !fehler.gueltigBis) fehler.gueltigBis = 'Das Ablaufdatum liegt vor dem Ausstellungsdatum.';
      var datei = roh.datei;
      if (datei && !(typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Diese Datei ist leer.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };

      var jetzt = self.jetzt();
      var n = { id: neueId('nw'), datenraumId: self.datenraumId, artId: artId, besitzerTyp: besitzerTyp, besitzerId: besitzerId, erstelltAm: jetzt };
      w.dateiName = datei ? String(datei.name || 'Datei') : null;
      w.dateiTyp = datei ? String(datei.type || '') : null;
      w.dateiGroesse = datei ? datei.size : null;
      var liste = [{ tabelle: 'nachweise', objekt: n }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('nachweis', n.id, 1, w, null, jetzt) }];
      if (datei) liste.push({ tabelle: 'nachweisdateien', objekt: { id: neueId('nd'), nachweisId: n.id, name: w.dateiName, mime: w.dateiTyp, groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: n.id }; }).catch(function (err) {
        if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei.' } };
        throw err;
      });
    });
  };

  Daten.prototype.nachweisAendern = function (id, roh) {
    var self = this;
    return this.nachweisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Nachweis wurde nicht gefunden.' } };
      var p = pruefeWerte(x.felder, roh || {}, jahrVon(self), { ohneBezeichnung: true });
      var fehler = p.fehler, w = p.werte;
      if (w.ausgestelltAm && w.gueltigBis && w.gueltigBis < w.ausgestelltAm && !fehler.gueltigBis) fehler.gueltigBis = 'Das Ablaufdatum liegt vor dem Ausstellungsdatum.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var neu = Object.assign({}, x.aktuell.werte, w);
      return self.mitVerlaufAendern('nachweis', id, { aktuell: x.aktuell }, neu, x.felder);
    });
  };

  Daten.prototype.nachweisLaden = function (id) {
    var self = this;
    return this.speicher.holen('nachweise', id).then(function (n) {
      if (!n) return null;
      return Promise.all([self.nachweisartLaden(n.artId), self.mitVerlaufLaden('nachweise', id, []), self.speicher.wo('nachweisdateien', 'nachweisId', id), self.besitzerLaden(n.besitzerTyp, n.besitzerId)]).then(function (r) {
        var art = r[0], x = r[1];
        if (!art || !x) return null;
        var felder = MM.Nachweise.felderFuer(art.aktuell.werte);
        var eintraege = x.verlauf.map(function (v) { return v.eintrag; });
        var verlauf = verlaufAus(eintraege, felder);
        var d = r[2][0] ? { id: r[2][0].id, name: r[2][0].name, mime: r[2][0].mime, groesse: r[2][0].groesse } : null;
        return { nachweis: n, aktuell: x.aktuell, verlauf: verlauf, art: art, felder: felder, datei: d, besitzer: r[3],
          status: artStatus(art.aktuell.werte, x.aktuell.werte, self.heute()) };
      });
    });
  };

  Daten.prototype.nachweisDateiHolen = function (nachweisId) {
    return this.speicher.wo('nachweisdateien', 'nachweisId', nachweisId).then(function (l) { return l[0] || null; });
  };

  /* Nachweise eines Besitzers, mit Status. Abgelaufene zuerst. */
  Daten.prototype.nachweiseListe = function (besitzerTyp, besitzerId) {
    var self = this;
    return Promise.all([this.speicher.wo('nachweise', 'besitzerId', besitzerId), this.speicher.alle('verlaeufe'), this.nachweisartenListe()]).then(function (r) {
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a; });
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'nachweis') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var heute = self.heute();
      var liste = r[0].filter(function (n) { return n.besitzerTyp === besitzerTyp; }).map(function (n) {
        var l = (ver[n.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1], art = arten[n.artId];
        if (!a || !art) return null;
        return { nachweis: n, aktuell: a, art: art, status: artStatus(art.aktuell.werte, a.werte, heute) };
      }).filter(Boolean);
      liste.sort(function (a, b) {
        var d = MM.Nachweise.rang(b.status.status) - MM.Nachweise.rang(a.status.status);
        return d || a.art.aktuell.werte.bezeichnung.localeCompare(b.art.aktuell.werte.bezeichnung, 'de', { numeric: true });
      });
      return liste;
    });
  };

  /* Pro Besitzer: wie viele Nachweise sind abgelaufen oder laufen bald ab? */
  Daten.prototype.nachweisUebersicht = function () {
    var self = this;
    return Promise.all([this.speicher.alle('nachweise'), this.speicher.alle('verlaeufe'), this.nachweisartenListe()]).then(function (r) {
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a; });
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'nachweis') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var heute = self.heute(), res = {};
      r[0].forEach(function (n) {
        var l = (ver[n.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1], art = arten[n.artId];
        if (!a || !art) return;
        var s = artStatus(art.aktuell.werte, a.werte, heute).status;
        var z = res[n.besitzerId] = res[n.besitzerId] || { abgelaufen: 0, bald: 0, unbekannt: 0 };
        if (z[s] !== undefined) z[s]++;
      });
      return res;
    });
  };

  /* ---------- Aktivitäten: gemeinsame Hilfen ---------- */
  Daten.prototype.jetztLokal = function () {
    var d = new Date(this.jetzt());
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()) + 'T' + z(d.getHours()) + ':' + z(d.getMinutes());
  };

  /* ---------- Aktivitätsarten (offene Liste) ---------- */
  var AKTART_FELDER = [
    { key: 'bezeichnung', label: 'Name der Art' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  Daten.prototype.aktivitaetsartenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('aktivitaetsarten'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'aktivitaetsart');
    });
  };

  Daten.prototype.aktivitaetsartAnlegen = function (roh) {
    var self = this;
    var bez = trimmed(roh && roh.bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segeln“.' } });
    return this.aktivitaetsartenListe().then(function (liste) {
      if (liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === bez.toLowerCase(); })) {
        return { ok: false, fehler: { bezeichnung: 'Diese Art gibt es schon.' } };
      }
      return self.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: bez, ausgeblendet: 'nein' });
    });
  };

  /* Legt die Vorschläge an, die es noch nicht gibt. Gibt die Anzahl der neuen zurück. */
  Daten.prototype.aktivitaetsartenAusVorschlaegen = function () {
    var self = this;
    return this.aktivitaetsartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Aktivitaeten.VORSCHLAEGE_ARTEN.filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
      return neu.reduce(function (kette, n) {
        return kette.then(function () { return self.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: n, ausgeblendet: 'nein' }); });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  Daten.prototype.aktivitaetsartLaden = function (id) { return this.mitVerlaufLaden('aktivitaetsarten', id, AKTART_FELDER); };

  Daten.prototype.aktivitaetsartAendern = function (id, roh) {
    var self = this;
    return this.aktivitaetsartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var bez = trimmed(roh && roh.bezeichnung);
      if (!bez) return { ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben.' } };
      var neu = { bezeichnung: bez, ausgeblendet: roh.ausgeblendet === 'ja' ? 'ja' : 'nein' };
      return self.mitVerlaufAendern('aktivitaetsart', id, x, neu, AKTART_FELDER);
    });
  };

  /* ---------- Anforderungen an Skipper und Fahrer (je Fahrzeug) ---------- */
  var ANF_FELDER = [
    { key: 'bezeichnung', label: 'Bezeichnung' },
    { key: 'artIds', label: 'Akzeptierte Nachweisarten', typ: 'mehrfach' },
    { key: 'gilt', label: 'Gilt', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  Daten.prototype.pruefenAnforderung = function (roh, personenArten) {
    roh = roh || {};
    var f = {}, w = {};
    w.bezeichnung = trimmed(roh.bezeichnung);
    if (!w.bezeichnung) f.bezeichnung = 'Bitte eine Bezeichnung eingeben, zum Beispiel „Führerschein Klasse B“.';
    var gew = Array.isArray(roh.artIds) ? roh.artIds : [];
    w.artIds = personenArten.filter(function (a) { return gew.indexOf(a) >= 0; });
    if (!w.artIds.length) f.artIds = 'Bitte mindestens eine Art von Nachweis wählen, die genügt.';
    w.gilt = roh.gilt === 'nein' ? 'nein' : 'ja';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  function personenArtIds(self) {
    return self.nachweisartenListe('person').then(function (l) { return l.map(function (x) { return x.objekt.id; }); });
  }

  Daten.prototype.anforderungAnlegen = function (fahrzeugId, roh) {
    var self = this;
    return Promise.all([this.pruefeObjekt(fahrzeugId, null), personenArtIds(this)]).then(function (r) {
      if (r[0]) return { ok: false, fehler: r[0] };
      var p = self.pruefenAnforderung(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAnlegen('anforderungen', 'anforderung', 'an', p.werte, { fahrzeugId: fahrzeugId });
    });
  };

  Daten.prototype.anforderungLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('anforderungen', id, ANF_FELDER).then(function (x) {
      if (!x) return null;
      return self.nachweisartenListe('person').then(function (arten) {
        var namen = {}; arten.forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artIds') {
              u.feld = { typ: 'text' };
              u.alt = (u.alt || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null;
              u.neu = (u.neu || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null;
            }
          });
        });
        x.arten = arten; x.namen = namen;
        return x;
      });
    });
  };

  Daten.prototype.anforderungAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.anforderungLaden(id), personenArtIds(this)]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Anforderung wurde nicht gefunden.' } };
      var p = self.pruefenAnforderung(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('anforderung', id, x, p.werte, ANF_FELDER);
    });
  };

  /* Anforderungen eines Fahrzeugs; nurGueltige blendet abgeschaltete aus. */
  Daten.prototype.anforderungenListe = function (fahrzeugId, nurGueltige) {
    var self = this;
    return Promise.all([this.speicher.wo('anforderungen', 'fahrzeugId', fahrzeugId), this.speicher.alle('verlaeufe'), this.nachweisartenListe('person')]).then(function (r) {
      var namen = {}; r[2].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      var liste = sammle(self, r[0], r[1], 'anforderung').map(function (x) {
        x.artNamen = x.aktuell.werte.artIds.map(function (i) { return namen[i] || 'unbekannte Art'; });
        return x;
      });
      return nurGueltige ? liste.filter(function (x) { return x.aktuell.werte.gilt !== 'nein'; }) : liste;
    });
  };

  /* ---------- Orte, Standorte, Gebiete und Regeln ---------- */
  var AUSGEBLENDET = { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN };
  var ORT_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.ortFelder(), [AUSGEBLENDET]);
  var STANDORT_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.standortFelder(), [AUSGEBLENDET]);
  var GEBIET_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.gebietFelder(), [AUSGEBLENDET]);
  var REGEL_FELDER = [
    { key: 'bezeichnung', label: 'Bezeichnung' },
    { key: 'art', label: 'Art der Regel', typ: 'auswahl', optionen: MM.Orte.REGELARTEN },
    { key: 'pflichtAusruestung', label: 'Pflichtausrüstung', typ: 'text' },
    { key: 'menge', label: 'Menge', typ: 'ganzzahl' },
    { key: 'bezug', label: 'Bezugsgröße', typ: 'auswahl', optionen: MM.Orte.BEZUGSGROESSEN },
    { key: 'eignung', label: 'Gefordert (Eignung)', typ: 'text' },
    { key: 'fahrzeugArten', label: 'Gilt für Fahrzeugarten', typ: 'mehrfach' },
    { key: 'ausruestung', label: 'Nur mit Ausrüstung', typ: 'text' },
    { key: 'artIds', label: 'Genügt einer dieser Nachweise', typ: 'mehrfach' },
    { key: 'gilt', label: 'Gilt', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  function gleicherName(liste, name, ausser) {
    var n = name.toLowerCase();
    return liste.some(function (x) { return x.objekt.id !== ausser && x.aktuell.werte.bezeichnung.toLowerCase() === n; });
  }

  /* Gemeinsame Prüfung für Ort, Standort und Gebiet: Name, freie Felder, „ausgeblendet“. */
  function pruefeBenannt(self, felder, roh, text) {
    var p = pruefeWerte(felder, roh, jahrVon(self), { bezeichnungFehler: text });
    p.werte.ausgeblendet = roh && roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    p.werte.herkunft = 'eigen';
    return p;
  }

  Daten.prototype.pruefenOrt = function (roh) {
    var p = pruefeBenannt(this, MM.Orte.ortFelder(), roh, 'Bitte einen Namen für den Ort eingeben, zum Beispiel „Hafen Biograd“.');
    if (p.werte.telefon && !/^[0-9+\-\/() ]{5,}$/.test(p.werte.telefon)) { p.fehler.telefon = 'Bitte nur Ziffern, Leerzeichen und + - / ( ) eingeben.'; p.ok = false; }
    return p;
  };
  Daten.prototype.pruefenStandort = function (roh) {
    return pruefeBenannt(this, MM.Orte.standortFelder(), roh, 'Bitte einen Namen für den Standort eingeben, zum Beispiel „Liegeplatz 12“.');
  };
  Daten.prototype.pruefenGebiet = function (roh) {
    return pruefeBenannt(this, MM.Orte.gebietFelder(), roh, 'Bitte einen Namen für das Gebiet eingeben, zum Beispiel „Kroatien, Adria“.');
  };

  /* ----- Orte ----- */
  Daten.prototype.orteListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('orte'), this.speicher.alle('verlaeufe'), this.speicher.alle('standorte')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'ort');
      var anzahl = {}; r[2].forEach(function (s) { anzahl[s.ortId] = (anzahl[s.ortId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlStandorte = anzahl[x.objekt.id] || 0; });
      return liste;
    });
  };

  Daten.prototype.ortAnlegen = function (roh) {
    var self = this;
    var p = this.pruefenOrt(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.orteListe().then(function (liste) {
      if (gleicherName(liste, p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Diesen Ort gibt es schon.' } };
      return self.mitVerlaufAnlegen('orte', 'ort', 'or', p.werte);
    });
  };

  Daten.prototype.ortAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', id, ORT_FELDER), this.orteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var p = self.pruefenOrt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(r[1], p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Diesen Ort gibt es schon.' } };
      return self.mitVerlaufAendern('ort', id, x, p.werte, ORT_FELDER);
    });
  };

  /* Ein Ort mit seinen Standorten. */
  Daten.prototype.ortLaden = function (id) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', id, ORT_FELDER), this.standorteListe(id)]).then(function (r) {
      if (!r[0]) return null;
      r[0].standorte = r[1];
      return r[0];
    });
  };

  /* ----- Standorte ----- */
  Daten.prototype.standorteListe = function (ortId) {
    var self = this;
    return Promise.all([this.speicher.alle('standorte'), this.speicher.alle('verlaeufe')]).then(function (r) {
      var rec = ortId ? r[0].filter(function (s) { return s.ortId === ortId; }) : r[0];
      return sammle(self, rec, r[1], 'standort');
    });
  };

  Daten.prototype.standortAnlegen = function (ortId, roh) {
    var self = this;
    return Promise.all([this.speicher.holen('orte', ortId), this.standorteListe(ortId)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var p = self.pruefenStandort(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(r[1], p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Diesen Standort gibt es an diesem Ort schon.' } };
      return self.mitVerlaufAnlegen('standorte', 'standort', 'so', p.werte, { ortId: ortId });
    });
  };

  Daten.prototype.standortLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('standorte', id, STANDORT_FELDER).then(function (x) {
      if (!x) return null;
      return self.mitVerlaufLaden('orte', x.objekt.ortId, ORT_FELDER).then(function (o) {
        x.ort = o ? { id: x.objekt.ortId, name: o.aktuell.werte.bezeichnung } : { id: x.objekt.ortId, name: 'unbekannt' };
        return x;
      });
    });
  };

  Daten.prototype.standortAendern = function (id, roh) {
    var self = this;
    return this.standortLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Standort wurde nicht gefunden.' } };
      var p = self.pruefenStandort(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.standorteListe(x.objekt.ortId).then(function (liste) {
        if (gleicherName(liste, p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Diesen Standort gibt es an diesem Ort schon.' } };
        return self.mitVerlaufAendern('standort', id, x, p.werte, STANDORT_FELDER);
      });
    });
  };

  /* ----- Heimatstandort eines Fahrzeugs (mit Verlauf, nichts wird überschrieben) ----- */
  Daten.prototype.fahrzeugStandortSetzen = function (fahrzeugId, standortId) {
    var self = this;
    standortId = standortId || null;
    return Promise.all([this.pruefeObjekt(fahrzeugId, null), standortId ? this.speicher.holen('standorte', standortId) : Promise.resolve(true),
      this.speicher.wo('verlaeufe', 'objektId', fahrzeugId)]).then(function (r) {
      if (r[0]) return { ok: false, fehler: r[0] };
      if (!r[1]) return { ok: false, fehler: { standortId: 'Dieser Standort wurde nicht gefunden.' } };
      var alt = r[2].filter(function (e) { return e.objektTyp === 'fahrzeugstandort'; }).sort(nachNr);
      var letzter = alt[alt.length - 1] || null;
      var bisher = letzter ? letzter.werte.standortId : null;
      if (bisher === standortId) return { ok: true, id: fahrzeugId, geaendert: false };
      var e = neuerVerlaufEintrag('fahrzeugstandort', fahrzeugId, letzter ? letzter.nr + 1 : 1, { standortId: standortId }, letzter ? letzter.id : null, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: fahrzeugId, geaendert: true }; });
    });
  };

  /* Heimatstandort eines Fahrzeugs: { standort: {id, name, ortId, ortName} | null, verlauf: [{ ... }] } */
  Daten.prototype.fahrzeugStandort = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.speicher.wo('verlaeufe', 'objektId', fahrzeugId), this.standorteListe(), this.orteListe()]).then(function (r) {
      var alt = r[0].filter(function (e) { return e.objektTyp === 'fahrzeugstandort'; }).sort(nachNr);
      var namen = {};
      r[1].forEach(function (s) {
        var o = r[2].filter(function (x) { return x.objekt.id === s.objekt.ortId; })[0];
        namen[s.objekt.id] = { id: s.objekt.id, name: s.aktuell.werte.bezeichnung, ortId: s.objekt.ortId, ortName: o ? o.aktuell.werte.bezeichnung : 'unbekannt' };
      });
      function text(id) { return id ? (namen[id] ? namen[id].ortName + ', ' + namen[id].name : 'unbekannt') : 'keiner'; }
      var verlauf = alt.map(function (e, i) { return { eintrag: e, alt: i ? text(alt[i - 1].werte.standortId) : null, neu: text(e.werte.standortId) }; }).reverse();
      var letzter = alt[alt.length - 1];
      return { standort: letzter && letzter.werte.standortId && namen[letzter.werte.standortId] ? namen[letzter.werte.standortId] : null, verlauf: verlauf };
    });
  };

  /* ----- Gebiete ----- */
  Daten.prototype.gebieteListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('gebiete'), this.speicher.alle('verlaeufe'), this.speicher.alle('regeln')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'gebiet');
      var anzahl = {}; r[2].forEach(function (g) { anzahl[g.gebietId] = (anzahl[g.gebietId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlRegeln = anzahl[x.objekt.id] || 0; });
      return liste;
    });
  };

  Daten.prototype.gebietAnlegen = function (roh) {
    var self = this;
    var p = this.pruefenGebiet(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.gebieteListe().then(function (liste) {
      if (gleicherName(liste, p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Dieses Gebiet gibt es schon.' } };
      return self.mitVerlaufAnlegen('gebiete', 'gebiet', 'ge', p.werte);
    });
  };

  Daten.prototype.gebietAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('gebiete', id, GEBIET_FELDER), this.gebieteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Gebiet wurde nicht gefunden.' } };
      var p = self.pruefenGebiet(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(r[1], p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Dieses Gebiet gibt es schon.' } };
      return self.mitVerlaufAendern('gebiet', id, x, p.werte, GEBIET_FELDER);
    });
  };

  /* Ein Gebiet mit seinen Regeln. */
  Daten.prototype.gebietLaden = function (id) {
    return Promise.all([this.mitVerlaufLaden('gebiete', id, GEBIET_FELDER), this.regelnListe(id)]).then(function (r) {
      if (!r[0]) return null;
      r[0].regeln = r[1];
      return r[0];
    });
  };

  /* ----- Regeln: WENN Gebiet, Fahrzeugart und Ausrüstung passen, DANN genügt einer der Nachweise ----- */
  function fahrzeugArtIds() { return MM.Fahrzeugarten.alle().map(function (a) { return a.id; }); }

  Daten.prototype.pruefenRegel = function (roh, personenArten) {
    roh = roh || {};
    var f = {}, w = {};
    w.bezeichnung = trimmed(roh.bezeichnung);
    if (!w.bezeichnung) f.bezeichnung = 'Bitte eine Bezeichnung eingeben, zum Beispiel „Funkzeugnis auf See“.';
    var fa = Array.isArray(roh.fahrzeugArten) ? roh.fahrzeugArten : [];
    w.fahrzeugArten = fahrzeugArtIds().filter(function (a) { return fa.indexOf(a) >= 0; });
    w.art = MM.Orte.regelArt(roh);
    if (w.art === 'ausruestung') {
      /* Pflichtausrüstung: Was muss am Fahrzeug eingetragen sein? Eine Bedingung „Ausrüstung“ und Nachweise gibt es hier nicht. */
      w.pflichtAusruestung = trimmed(roh.pflichtAusruestung) || null;
      if (!w.pflichtAusruestung) f.pflichtAusruestung = 'Bitte eintragen, was am Fahrzeug sein muss, zum Beispiel „Rettungsweste“.';
      w.ausruestung = null;
      w.artIds = [];
      /* Menge (ganze Zahl ab 1, leer = 1), Bezugsgröße und freiwillig die geforderte Eignung */
      var mt = String(roh.menge === undefined || roh.menge === null ? '' : roh.menge).trim();
      if (mt === '') { w.menge = 1; }
      else if (!/^\d+$/.test(mt) || Number(mt) < 1) { w.menge = 1; f.menge = 'Bitte eine ganze Zahl ab 1 eingeben, zum Beispiel 6.'; }
      else { w.menge = Number(mt); }
      w.bezug = MM.Orte.bezugsgroesse(roh);
      w.eignung = trimmed(roh.eignung) || null;
    } else {
      w.pflichtAusruestung = null;
      w.menge = null; w.bezug = null; w.eignung = null;
      w.ausruestung = trimmed(roh.ausruestung) || null;
      var gew = Array.isArray(roh.artIds) ? roh.artIds : [];
      w.artIds = personenArten.filter(function (a) { return gew.indexOf(a) >= 0; });
      if (!w.artIds.length) f.artIds = 'Bitte mindestens eine Art von Nachweis wählen, die genügt.';
    }
    w.gilt = roh.gilt === 'nein' ? 'nein' : 'ja';
    w.herkunft = 'eigen';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.regelAnlegen = function (gebietId, roh) {
    var self = this;
    return Promise.all([this.speicher.holen('gebiete', gebietId), personenArtIds(this)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieses Gebiet wurde nicht gefunden.' } };
      var p = self.pruefenRegel(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAnlegen('regeln', 'regel', 'rg', p.werte, { gebietId: gebietId });
    });
  };

  Daten.prototype.regelAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.regelLaden(id), personenArtIds(this)]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Regel wurde nicht gefunden.' } };
      if (!x.aktuell.werte.art) x.aktuell.werte = Object.assign({ art: 'befaehigung' }, x.aktuell.werte);
      if (x.aktuell.werte.art === 'ausruestung') x.aktuell.werte = Object.assign({ menge: 1, bezug: 'fahrzeug', eignung: null }, x.aktuell.werte);
      else x.aktuell.werte = Object.assign({ menge: null, bezug: null, eignung: null }, x.aktuell.werte);
      var p = self.pruefenRegel(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('regel', id, x, p.werte, REGEL_FELDER);
    });
  };

  Daten.prototype.regelLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('regeln', id, REGEL_FELDER).then(function (x) {
      if (!x) return null;
      return Promise.all([self.nachweisartenListe('person'), self.mitVerlaufLaden('gebiete', x.objekt.gebietId, GEBIET_FELDER)]).then(function (r) {
        var namen = {}; r[0].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        function arten(l) { return (l || []).map(function (a) { var z = MM.Fahrzeugarten.art(a); return z ? z.name : a; }).join(', ') || null; }
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artIds') { u.feld = { typ: 'text' }; u.alt = (u.alt || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null; u.neu = (u.neu || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null; }
            if (u.key === 'fahrzeugArten') { u.feld = { typ: 'text' }; u.alt = arten(u.alt); u.neu = arten(u.neu); }
            if (u.key === 'bezug') { u.feld = { typ: 'text' }; u.alt = u.alt ? (u.alt === 'person' ? 'je Person an Bord' : 'je Fahrzeug') : null; u.neu = u.neu ? (u.neu === 'person' ? 'je Person an Bord' : 'je Fahrzeug') : null; }
            if (u.key === 'art') { u.feld = { typ: 'text' }; u.alt = u.alt ? (u.alt === 'ausruestung' ? 'Pflichtausrüstung' : 'Befähigung') : 'Befähigung'; u.neu = u.neu === 'ausruestung' ? 'Pflichtausrüstung' : 'Befähigung'; }
          });
        });
        x.arten = r[0]; x.namen = namen;
        x.gebiet = { id: x.objekt.gebietId, name: r[1] ? r[1].aktuell.werte.bezeichnung : 'unbekannt' };
        return x;
      });
    });
  };

  /* Regeln eines Gebiets (oder aller), mit Namen der Nachweisarten. */
  Daten.prototype.regelnListe = function (gebietId) {
    var self = this;
    return Promise.all([this.speicher.alle('regeln'), this.speicher.alle('verlaeufe'), this.nachweisartenListe('person')]).then(function (r) {
      var rec = gebietId ? r[0].filter(function (g) { return g.gebietId === gebietId; }) : r[0];
      var namen = {}; r[2].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      return sammle(self, rec, r[1], 'regel').map(function (x) {
        x.artNamen = x.aktuell.werte.artIds.map(function (i) { return namen[i] || 'unbekannte Art'; });
        x.fahrzeugArtNamen = (x.aktuell.werte.fahrzeugArten || []).map(function (a) { var z = MM.Fahrzeugarten.art(a); return z ? z.name : a; });
        return x;
      });
    });
  };

  /* ---------- Aktivitäten ---------- */
  var AKT_FELDER = [
    { key: 'bezeichnung', label: 'Name' },
    { key: 'artId', label: 'Art', typ: 'text' },
    { key: 'fahrzeugId', label: 'Fahrzeug', typ: 'text' },
    { key: 'vonDatum', label: 'Von (Datum)', typ: 'datum' },
    { key: 'vonZeit', label: 'Von (Uhrzeit)', typ: 'zeit' },
    { key: 'bisDatum', label: 'Bis (Datum)', typ: 'datum' },
    { key: 'bisZeit', label: 'Bis (Uhrzeit)', typ: 'zeit' },
    { key: 'gebiet', label: 'Gebiet (Text)', typ: 'text' },
    { key: 'gebietId', label: 'Gebiet', typ: 'text' },
    { key: 'geplanteStrecke', label: 'Geplante Strecke', typ: 'zahl' },
    { key: 'geplanteStunden', label: 'Geplante Betriebsstunden', typ: 'zahl' },
    { key: 'tierIds', label: 'Tiere', typ: 'mehrfach' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'status', label: 'Status', typ: 'text' },
    { key: 'stornoGrund', label: 'Grund der Stornierung', typ: 'text' },
    { key: 'sperreUebergangenAm', label: 'Sperre übergangen am', typ: 'text' }
  ];

  Daten.prototype.aktivitaetKontext = function () {
    return Promise.all([this.aktivitaetsartenListe(), this.fahrzeugListe(), this.tiereListe(), this.personenListe(), this.gebieteListe()]).then(function (r) {
      return { arten: r[0], fahrzeuge: r[1], tiere: r[2], personen: r[3], gebiete: r[4] };
    });
  };

  Daten.prototype.pruefenAktivitaet = function (roh, ctx, neu) {
    roh = roh || {};
    var gewaehlteArt = roh.artId;
    var felder = [
      { key: 'artId', typ: 'auswahl', optionen: ctx.arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || a.objekt.id === gewaehlteArt; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; }) },
      { key: 'fahrzeugId', typ: 'auswahl', optionen: ctx.fahrzeuge.map(function (x) { return { wert: x.fahrzeug.id, label: x.aktuell.werte.bezeichnung }; }) },
      { key: 'vonDatum', typ: 'datum' }, { key: 'vonZeit', typ: 'zeit' }, { key: 'bisDatum', typ: 'datum' }, { key: 'bisZeit', typ: 'zeit' },
      { key: 'gebiet', typ: 'text' },
      { key: 'gebietId', typ: 'auswahl', optionen: (ctx.gebiete || []).filter(function (g) { return g.aktuell.werte.ausgeblendet !== 'ja' || g.objekt.id === roh.gebietId; })
        .map(function (g) { return { wert: g.objekt.id, label: g.aktuell.werte.bezeichnung }; }) },
      { key: 'geplanteStrecke', typ: 'zahl', min: 0 }, { key: 'geplanteStunden', typ: 'zahl', min: 0 },
      { key: 'tierIds', typ: 'mehrfach', optionen: ctx.tiere.map(function (t) { return { wert: t.objekt.id, label: t.aktuell.werte.bezeichnung }; }) },
      { key: 'notiz', typ: 'text' }
    ];
    var p = pruefeWerte(felder, roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen für die Aktivität eingeben, zum Beispiel „Sommertörn Kroatien“.' });
    var w = p.werte, f = p.fehler;
    if (!w.artId && !f.artId) f.artId = ctx.arten.length ? 'Bitte die Art der Aktivität wählen.' : 'Es gibt noch keine Art. Übernimm zuerst die Vorschläge oder lege eine Art an.';
    if (!w.fahrzeugId && !f.fahrzeugId) f.fahrzeugId = ctx.fahrzeuge.length ? 'Bitte das Fahrzeug wählen.' : 'Es gibt noch kein Fahrzeug. Lege zuerst ein Fahrzeug an.';
    if (!w.vonDatum && !f.vonDatum) f.vonDatum = 'Bitte das Datum angeben, an dem es losgeht.';
    if (!w.bisDatum && !f.bisDatum) f.bisDatum = 'Bitte das Datum angeben, an dem es endet.';
    if (w.vonDatum && w.bisDatum && !f.bisDatum) {
      if (w.bisDatum < w.vonDatum) f.bisDatum = 'Das Ende liegt vor dem Beginn.';
      else if (w.bisDatum === w.vonDatum && w.vonZeit && w.bisZeit && w.bisZeit < w.vonZeit && !f.bisZeit) f.bisZeit = 'Die Uhrzeit des Endes liegt vor der des Beginns.';
    }
    if (neu) {
      var pid = roh.verantwortlichId;
      if (!ctx.personen.some(function (x) { return x.objekt.id === pid; })) {
        f.verantwortlichId = ctx.personen.length ? 'Bitte wählen, wer verantwortlich ist.' : 'Es gibt noch keine Person. Lege zuerst die Besatzung an.';
      }
    }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.aktivitaetAnlegen = function (roh) {
    var self = this;
    return this.aktivitaetKontext().then(function (ctx) {
      var p = self.pruefenAktivitaet(roh, ctx, true);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var w = p.werte, jetzt = self.jetzt();
      w.status = 'geplant'; w.stornoGrund = null; w.stornoAm = null; w.sperreUebergangenAm = null;
      var a = { id: neueId('ak'), datenraumId: self.datenraumId, erstelltAm: jetzt };
      var b = { id: neueId('be'), aktivitaetId: a.id, personId: roh.verantwortlichId, erstelltAm: jetzt };
      var v = { id: neueId('ve'), aktivitaetId: a.id, personId: roh.verantwortlichId, ab: MM.Aktivitaeten.von(w), erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'aktivitaeten', objekt: a },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('aktivitaet', a.id, 1, w, null, jetzt) },
        { tabelle: 'besatzung', objekt: b },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besatzung', b.id, 1, { rolle: 'verantwortlich', dabeiVonDatum: null, dabeiVonZeit: null, dabeiBisDatum: null, dabeiBisZeit: null, entfernt: 'nein' }, null, jetzt) },
        { tabelle: 'verantwortung', objekt: v }
      ]).then(function () { return { ok: true, id: a.id }; });
    });
  };

  Daten.prototype.aktivitaetAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(id), this.aktivitaetKontext()]).then(function (r) {
      var x = r[0], ctx = r[1];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (x.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenAktivitaet(roh, ctx, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var alt = x.aktuell.werte;
      var neu = Object.assign({}, alt, p.werte);
      var zeitraumGeaendert = ['fahrzeugId', 'vonDatum', 'vonZeit', 'bisDatum', 'bisZeit', 'geplanteStrecke', 'geplanteStunden'].some(function (k) { return !gleich(alt[k], neu[k]); });
      if (zeitraumGeaendert) neu.sperreUebergangenAm = null;
      return self.mitVerlaufAendern('aktivitaet', id, { aktuell: x.aktuell }, neu, AKT_FELDER);
    });
  };

  function aktivitaetNeuerStand(self, id, aenderung) {
    return self.mitVerlaufLaden('aktivitaeten', id, []).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var neu = aenderung(Object.assign({}, x.aktuell.werte));
      if (neu.fehler) return { ok: false, fehler: neu.fehler };
      return self.mitVerlaufAendern('aktivitaet', id, { aktuell: x.aktuell }, neu.werte, AKT_FELDER);
    });
  }

  /* Stornieren: Nichts wird gelöscht, der Status heißt "storniert". */
  Daten.prototype.aktivitaetStornieren = function (id, grund) {
    var self = this;
    return aktivitaetNeuerStand(this, id, function (w) {
      if (w.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist schon storniert.' } };
      w.status = 'storniert'; w.stornoGrund = trimmed(grund) || null; w.stornoAm = self.jetzt();
      return { werte: w };
    });
  };
  Daten.prototype.aktivitaetWiederherstellen = function (id) {
    return aktivitaetNeuerStand(this, id, function (w) {
      if (w.status !== 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist nicht storniert.' } };
      w.status = 'geplant'; w.stornoGrund = null; w.stornoAm = null;
      return { werte: w };
    });
  };
  /* Eine Sperre durch eine Frist ausdrücklich übergehen. Zeit wird festgehalten. */
  Daten.prototype.aktivitaetSperreUebergehen = function (id) {
    var self = this;
    return aktivitaetNeuerStand(this, id, function (w) { w.sperreUebergangenAm = self.jetzt(); return { werte: w }; });
  };

  /* ---------- Besatzung und Verantwortung ---------- */
  var BES_FELDER = [
    { key: 'rolle', label: 'Rolle', typ: 'text' },
    { key: 'dabeiVonDatum', label: 'Dabei von (Datum)', typ: 'datum' }, { key: 'dabeiVonZeit', label: 'Dabei von (Uhrzeit)', typ: 'zeit' },
    { key: 'dabeiBisDatum', label: 'Dabei bis (Datum)', typ: 'datum' }, { key: 'dabeiBisZeit', label: 'Dabei bis (Uhrzeit)', typ: 'zeit' },
    { key: 'entfernt', label: 'Nicht mehr dabei', typ: 'text' }
  ];

  Daten.prototype.pruefenBesatzung = function (roh) {
    roh = roh || {};
    var felder = [{ key: 'dabeiVonDatum', typ: 'datum' }, { key: 'dabeiVonZeit', typ: 'zeit' }, { key: 'dabeiBisDatum', typ: 'datum' }, { key: 'dabeiBisZeit', typ: 'zeit' }];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    var rolle = roh.rolle;
    if (rolle !== 'stellvertreter' && rolle !== 'crew' && rolle !== 'verantwortlich') f.rolle = 'Bitte wählen: Stellvertreter oder Crew.';
    else w.rolle = rolle;
    if (w.dabeiVonDatum && w.dabeiBisDatum && w.dabeiBisDatum < w.dabeiVonDatum && !f.dabeiBisDatum) f.dabeiBisDatum = 'Das Ende liegt vor dem Beginn.';
    w.entfernt = roh.entfernt === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Wer hängt gerade an der Verantwortung (letzter Eintrag der Verantwortung)? */
  function letzteVerantwortung(eintraege) {
    return eintraege.slice().sort(function (a, b) { return a.ab < b.ab ? -1 : (a.ab > b.ab ? 1 : 0); }).pop() || null;
  }

  Daten.prototype.besatzungHinzufuegen = function (aktivitaetId, personId, roh) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.personLaden(personId)]).then(function (r) {
      var a = r[0], person = r[1];
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (!person) return { ok: false, fehler: { personId: 'Bitte eine Person wählen.' } };
      var p = self.pruefenBesatzung(roh);
      if (p.werte.rolle === 'verantwortlich') p.fehler.rolle = 'Die verantwortliche Person wird über „Verantwortung wechseln“ bestimmt.';
      if (Object.keys(p.fehler).length) return { ok: false, fehler: p.fehler };
      var vorhanden = a.besatzung.concat(a.entfernte).filter(function (b) { return b.besatzung.personId === personId; })[0];
      if (vorhanden && vorhanden.aktuell.werte.entfernt !== 'ja') return { ok: false, fehler: { personId: 'Diese Person ist schon dabei.' } };
      if (vorhanden) {
        /* Wieder aufnehmen: neuer Eintrag, die frühere Zeit bleibt sichtbar */
        return self.mitVerlaufAendern('besatzung', vorhanden.besatzung.id, { aktuell: vorhanden.aktuell }, p.werte, BES_FELDER)
          .then(function (res) { res.id = vorhanden.besatzung.id; return res; });
      }
      var jetzt = self.jetzt();
      var b = { id: neueId('be'), aktivitaetId: aktivitaetId, personId: personId, erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'besatzung', objekt: b }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besatzung', b.id, 1, p.werte, null, jetzt) }
      ]).then(function () { return { ok: true, id: b.id }; });
    });
  };

  Daten.prototype.besatzungAendern = function (besatzungId, roh) {
    var self = this;
    return this.speicher.holen('besatzung', besatzungId).then(function (b) {
      if (!b) return { ok: false, fehler: { allgemein: 'Dieser Eintrag wurde nicht gefunden.' } };
      return Promise.all([self.mitVerlaufLaden('besatzung', besatzungId, BES_FELDER), self.speicher.wo('verantwortung', 'aktivitaetId', b.aktivitaetId)]).then(function (r) {
        var x = r[0], letzte = letzteVerantwortung(r[1]);
        var p = self.pruefenBesatzung(roh);
        var gleichBleibt = x.aktuell.werte.rolle === 'verantwortlich' && roh.rolle === 'verantwortlich';
        if (p.werte.rolle === 'verantwortlich' && !gleichBleibt) p.fehler.rolle = 'Die verantwortliche Person wird über „Verantwortung wechseln“ bestimmt.';
        if (Object.keys(p.fehler).length) return { ok: false, fehler: p.fehler };
        var istLetzter = letzte && letzte.personId === b.personId;
        if (istLetzter && (p.werte.entfernt === 'ja' || p.werte.rolle === 'crew')) {
          return { ok: false, fehler: { allgemein: 'Diese Person ist zuletzt als verantwortlich eingetragen. Wechsle zuerst die Verantwortung auf eine andere Person.' } };
        }
        return self.mitVerlaufAendern('besatzung', besatzungId, x, p.werte, BES_FELDER).then(function (res) { res.id = besatzungId; return res; });
      });
    });
  };

  /* Verantwortung ab einem Zeitpunkt auf eine andere Person übertragen. Nur Skipper/Fahrer und Stellvertreter. */
  Daten.prototype.verantwortungWechseln = function (aktivitaetId, personId, roh) {
    var self = this;
    roh = roh || {};
    var p = pruefeWerte([{ key: 'abDatum', typ: 'datum' }, { key: 'abZeit', typ: 'zeit' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var f = p.fehler, w = p.werte;
    if (!w.abDatum && !f.abDatum) f.abDatum = 'Bitte das Datum des Wechsels angeben.';
    if (!w.abZeit && !f.abZeit) f.abZeit = 'Bitte die Uhrzeit des Wechsels angeben.';
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var dabei = a.besatzung.filter(function (b) { return b.besatzung.personId === personId && (b.aktuell.werte.rolle === 'verantwortlich' || b.aktuell.werte.rolle === 'stellvertreter'); })[0];
      if (!dabei) return { ok: false, fehler: { personId: 'Verantwortlich kann nur sein, wer als ' + MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt) + ' oder Stellvertreter dabei ist.' } };
      var ab = w.abDatum + 'T' + w.abZeit;
      var letzte = letzteVerantwortung(a.verantwortung);
      if (letzte && ab <= letzte.ab) return { ok: false, fehler: { abDatum: 'Der Wechsel muss nach dem letzten Wechsel liegen (' + letzte.ab.replace('T', ', ') + ' Uhr).' } };
      if (letzte && letzte.personId === personId) return { ok: false, fehler: { personId: 'Diese Person ist schon verantwortlich.' } };
      if (a.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      /* Beim Wechsel prüft die App die Befähigung der übernehmenden Person und hält das Ergebnis mit „geprüft am“ fest.
         Sie weist nur hin und sperrt den Wechsel nicht. Liegt der Zeitpunkt mehr als 5 Minuten vor jetzt, ist es ein Nachtrag. */
      return self.aktivitaetPruefung(aktivitaetId).then(function (pr) {
        var pruefung = MM.Logbuch.wechselPruefungFestgehalten(pr, personId);
        var nachgetragen = MM.Logbuch.zeitpunktArt(w.abDatum, w.abZeit, self.jetztLokal()) === 'nachtrag';
        var jetzt = self.jetzt();
        var v = { id: neueId('ve'), aktivitaetId: aktivitaetId, personId: personId, ab: ab, erstelltAm: jetzt };
        if (pruefung) v.pruefung = pruefung;
        if (nachgetragen) v.nachgetragenAm = jetzt;
        return self.speicher.speichern('verantwortung', v).then(function () { return { ok: true, id: aktivitaetId, verantwortungId: v.id, pruefung: pruefung || null, nachgetragen: nachgetragen }; });
      });
    });
  };

  /* ---------- Aktivität laden, listen, prüfen ---------- */
  Daten.prototype.aktivitaetLaden = function (id) {
    var self = this;
    return this.speicher.holen('aktivitaeten', id).then(function (a) {
      if (!a) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id), self.speicher.wo('besatzung', 'aktivitaetId', id), self.speicher.alle('verlaeufe'),
        self.speicher.wo('verantwortung', 'aktivitaetId', id), self.personenListe(), self.tiereListe(), self.aktivitaetsartenListe(), self.fahrzeugListe(), self.gebieteListe()
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length) return null;
        var aktuell = eintraege[eintraege.length - 1], w = aktuell.werte;
        var personen = {}; r[4].forEach(function (p) { personen[p.objekt.id] = p.aktuell.werte.bezeichnung; });
        var tiere = {}; r[5].forEach(function (t) { tiere[t.objekt.id] = t.aktuell.werte.bezeichnung; });
        var arten = {}; r[6].forEach(function (x) { arten[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var gebiete = {}; r[8].forEach(function (x) { gebiete[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var fz = r[7].filter(function (x) { return x.fahrzeug.id === w.fahrzeugId; })[0] || null;
        var welt = fz ? MM.Fahrzeugarten.art(fz.fahrzeug.art).welt : 'land';

        var verl = {}; r[2].forEach(function (e) { if (e.objektTyp === 'besatzung') (verl[e.objektId] = verl[e.objektId] || []).push(e); });
        var alleB = r[1].map(function (b) {
          var l = (verl[b.id] || []).slice().sort(nachNr);
          var ak = l[l.length - 1];
          return ak ? { besatzung: b, aktuell: ak, person: { id: b.personId, name: personen[b.personId] || 'unbekannt' }, rolleText: MM.Aktivitaeten.rolleLabel(ak.werte.rolle, welt) } : null;
        }).filter(Boolean);
        var reihenfolge = { verantwortlich: 0, stellvertreter: 1, crew: 2 };
        alleB.sort(function (x, y) { return reihenfolge[x.aktuell.werte.rolle] - reihenfolge[y.aktuell.werte.rolle] || x.person.name.localeCompare(y.person.name, 'de'); });
        var aktiv = alleB.filter(function (b) { return b.aktuell.werte.entfernt !== 'ja'; });
        var entfernt = alleB.filter(function (b) { return b.aktuell.werte.entfernt === 'ja'; });

        /* Korrekturen der Wechsel (Verlauf der Verantwortung): der neueste Stand gilt, der ursprüngliche Zeitpunkt bleibt sichtbar. */
        var vv = {}; r[2].forEach(function (e) { if (e.objektTyp === 'verantwortung') (vv[e.objektId] = vv[e.objektId] || []).push(e); });
        var ver = r[3].map(function (v) {
          var l = (vv[v.id] || []).slice().sort(nachNr), k = l[l.length - 1];
          return { id: v.id, personId: v.personId, name: personen[v.personId] || 'unbekannt',
            ab: k ? k.werte.abDatum + 'T' + k.werte.abZeit : v.ab, abUrspruenglich: v.ab, erstelltAm: v.erstelltAm,
            notiz: k ? (k.werte.notiz || null) : null, ausgeblendet: k ? (k.werte.ausgeblendet || 'nein') : 'nein', geaendert: !!k,
            nachgetragenAm: v.nachgetragenAm || null, pruefung: v.pruefung || null };
        }).sort(function (x, y) { return x.ab < y.ab ? -1 : (x.ab > y.ab ? 1 : 0); });
        var jetzt = self.jetztLokal();
        var gerade = MM.Aktivitaeten.verantwortlicher(ver, jetzt);

        var verlauf = verlaufAus(eintraege, AKT_FELDER);
        verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            function wandeln(m, wert) { return wert ? m[wert] || 'unbekannt' : null; }
            if (u.key === 'artId') { u.feld = { typ: 'text' }; u.alt = wandeln(arten, u.alt); u.neu = wandeln(arten, u.neu); }
            if (u.key === 'fahrzeugId') { u.feld = { typ: 'text' }; u.alt = u.alt ? self.fahrzeugName(r[7], u.alt) : null; u.neu = u.neu ? self.fahrzeugName(r[7], u.neu) : null; }
            if (u.key === 'tierIds') { u.feld = { typ: 'text' }; u.alt = (u.alt || []).map(function (i) { return tiere[i] || 'unbekannt'; }).join(', ') || null; u.neu = (u.neu || []).map(function (i) { return tiere[i] || 'unbekannt'; }).join(', ') || null; }
            if (u.key === 'gebietId') { u.feld = { typ: 'text' }; u.alt = wandeln(gebiete, u.alt); u.neu = wandeln(gebiete, u.neu); }
            if (u.key === 'sperreUebergangenAm' || u.key === 'status') { u.feld = { typ: 'text' }; }
          });
        });
        return { aktivitaet: a, aktuell: aktuell, verlauf: verlauf, gebiet: w.gebietId ? { id: w.gebietId, name: gebiete[w.gebietId] || 'unbekannt' } : null, art: w.artId ? { id: w.artId, name: arten[w.artId] || 'unbekannt' } : null,
          fahrzeug: fz ? { id: fz.fahrzeug.id, name: fz.aktuell.werte.bezeichnung, artId: fz.fahrzeug.art, welt: welt } : { id: w.fahrzeugId, name: 'unbekannt', artId: null, welt: 'land' },
          besatzung: aktiv, entfernte: entfernt, verantwortung: ver, verantwortlichJetzt: gerade,
          tiere: (w.tierIds || []).map(function (i) { return { id: i, name: tiere[i] || 'unbekannt' }; }), status: MM.Aktivitaeten.status(w, jetzt) };
      });
    });
  };

  Daten.prototype.fahrzeugName = function (liste, id) {
    var f = liste.filter(function (x) { return x.fahrzeug.id === id; })[0];
    return f ? f.aktuell.werte.bezeichnung : 'unbekannt';
  };

  /* Alle Aktivitäten, mit Status und Überschneidungen am selben Fahrzeug. */
  Daten.prototype.aktivitaetenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('aktivitaeten'), this.speicher.alle('verlaeufe'), this.aktivitaetsartenListe(), this.fahrzeugListe()]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'aktivitaet');
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      var fz = {}; r[3].forEach(function (f) { fz[f.fahrzeug.id] = f; });
      var jetzt = self.jetztLokal();
      liste.forEach(function (x) {
        var w = x.aktuell.werte;
        x.artName = arten[w.artId] || '';
        x.fahrzeugName = fz[w.fahrzeugId] ? fz[w.fahrzeugId].aktuell.werte.bezeichnung : 'unbekannt';
        x.status = MM.Aktivitaeten.status(w, jetzt);
        x.konflikte = [];
      });
      liste.forEach(function (x) {
        if (x.status === 'storniert') return;
        liste.forEach(function (y) {
          if (y !== x && y.status !== 'storniert' && y.aktuell.werte.fahrzeugId === x.aktuell.werte.fahrzeugId && MM.Aktivitaeten.ueberschneiden(x.aktuell.werte, y.aktuell.werte)) x.konflikte.push(y.objekt.id);
        });
      });
      var rang = { laeuft: 0, geplant: 1, vorbei: 2, storniert: 3 };
      liste.sort(function (a, b) {
        var d = rang[a.status] - rang[b.status];
        if (d) return d;
        var va = MM.Aktivitaeten.von(a.aktuell.werte), vb = MM.Aktivitaeten.von(b.aktuell.werte);
        return a.status === 'vorbei' ? (va < vb ? 1 : -1) : (va < vb ? -1 : (va > vb ? 1 : 0));
      });
      return liste;
    });
  };

  /*
   * Prüfung bei der Planung: Befähigung von Skipper/Fahrer und Stellvertretern,
   * Fristen bis zum Ende des Zeitraums, Überschneidungen am Fahrzeug.
   * Nur mit den Daten, die die App kennt. Keine rechtliche Aussage.
   */
  Daten.prototype.aktivitaetPruefung = function (id) {
    var self = this;
    return this.aktivitaetLaden(id).then(function (a) {
      if (!a) return null;
      var w = a.aktuell.werte;
      var pruefpersonen = a.besatzung.filter(function (b) { return b.aktuell.werte.rolle === 'verantwortlich' || b.aktuell.werte.rolle === 'stellvertreter'; });
      return Promise.all([
        self.anforderungenListe(w.fahrzeugId, true),
        Promise.all(pruefpersonen.map(function (b) { return self.nachweiseListe('person', b.person.id); })),
        self.fristenListe(w.fahrzeugId),
        self.aktivitaetenListe(),
        w.gebietId ? self.regelnListe(w.gebietId) : Promise.resolve([]),
        self.komponentenListe(w.fahrzeugId)
      ]).then(function (r) {
        var anf = r[0].map(function (x) { return { bezeichnung: x.aktuell.werte.bezeichnung, artIds: x.aktuell.werte.artIds }; });
        /* Regeln des gewählten Gebiets: Sie gelten zusätzlich zu den Anforderungen am Fahrzeug. */
        var gebietInfo = null, ausruestungErgebnis = null;
        if (w.gebietId && a.gebiet) {
          var komp = r[5].filter(function (k) { return !k.aktuell.werte.ausgebautAm; }).map(function (k) { return k.aktuell.werte.bezeichnung; });
          var ausw = MM.Orte.regelnAuswerten({
            regeln: r[4].map(function (x) { return Object.assign({ id: x.objekt.id }, x.aktuell.werte); }),
            fahrzeugArt: a.fahrzeug.artId, komponentenNamen: komp });
          var befGreifen = ausw.greifen.filter(function (g) { return MM.Orte.regelArt(g) === 'befaehigung'; });
          var ausGreifen = ausw.greifen.filter(function (g) { return MM.Orte.regelArt(g) === 'ausruestung'; });
          befGreifen.forEach(function (g) { anf.push({ bezeichnung: 'Gebiet ' + a.gebiet.name + ': ' + g.bezeichnung, artIds: g.artIds }); });
          var befNicht = ausw.nichtGreifen.filter(function (n) { return MM.Orte.regelArt(n.regel) === 'befaehigung'; });
          gebietInfo = { id: a.gebiet.id, name: a.gebiet.name,
            regelnGesamt: r[4].filter(function (x) { return MM.Orte.regelArt(x.aktuell.werte) === 'befaehigung' && x.aktuell.werte.gilt !== 'nein'; }).length,
            greifen: befGreifen.map(function (g) { return g.bezeichnung; }),
            nichtGreifen: befNicht.map(function (n) { return { bezeichnung: n.regel.bezeichnung, grund: n.grund }; }) };
          /* Pflichtausrüstung: gesucht wird in den Namen der eingebauten Komponenten. Nicht eingetragen heißt „unklar“, nicht „fehlt“. */
          var kompDetail = r[5].filter(function (k) { return !k.aktuell.werte.ausgebautAm; })
            .map(function (k) { return { name: k.aktuell.werte.bezeichnung, anzahl: k.aktuell.werte.anzahl, geprueft: k.aktuell.werte.eignungGeprueft }; });
          var pflicht = ausGreifen.map(function (g) {
            var e = MM.Orte.ausruestungPruefen({ regel: g, komponenten: kompDetail, personen: a.besatzung.length });
            return { bezeichnung: g.bezeichnung, pflicht: g.pflichtAusruestung, status: e.status, soll: e.soll, ist: e.ist, istGeprueft: e.istGeprueft,
              menge: e.menge, bezug: e.bezug, eignung: e.eignung, text: e.text };
          });
          ausruestungErgebnis = { liste: pflicht, ergebnis: !pflicht.length ? null : (pflicht.every(function (x) { return x.status === 'eingetragen'; }) ? 'erlaubt' : 'unklar') };
        }
        var personen = pruefpersonen.map(function (b, i) {
          var nachweise = r[1][i].map(function (n) { return { artId: n.nachweis.artId, artName: n.art.aktuell.werte.bezeichnung, hatAblauf: MM.Nachweise.hatAblauf(n.art.aktuell.werte), werte: n.aktuell.werte }; });
          var res = MM.Aktivitaeten.pruefeBefaehigung({ anforderungen: anf, nachweise: nachweise, endDatum: w.bisDatum });
          return { person: b.person, rolle: b.aktuell.werte.rolle, rolleText: b.rolleText, ergebnis: res.ergebnis, gruende: res.gruende };
        });
        var ergebnis = MM.Aktivitaeten.gesamtErgebnis(personen.map(function (x) { return x.ergebnis; }));
        var gebiet = gebietInfo ? gebietInfo.name : (trimmed(w.gebiet) || null);
        var gebietHinweis = null;
        if (gebietInfo) {
          /* Kennt die App für dieses Gebiet und dieses Fahrzeug keine Regel, bleibt sie vorsichtig: höchstens „unklar“. */
          if (!gebietInfo.greifen.length) {
            gebietHinweis = gebietInfo.regelnGesamt
              ? 'Für das Gebiet „' + gebietInfo.name + '“ trifft keine Regel auf dieses Fahrzeug zu. Die Prüfung gilt nur für die Anforderungen am Fahrzeug.'
              : 'Für das Gebiet „' + gebietInfo.name + '“ gibt es noch keine Regel für die Befähigung. Die Prüfung gilt nur für die Anforderungen am Fahrzeug.';
            if (ergebnis === 'erlaubt') ergebnis = 'unklar';
          }
        } else if (gebiet) {
          gebietHinweis = 'Das Gebiet „' + gebiet + '“ ist nur als Text eingetragen und wird nicht geprüft. Wähle ein Gebiet aus der Liste, damit seine Regeln gelten.';
          if (ergebnis === 'erlaubt') ergebnis = 'unklar';
        }
        var fristEingabe = r[2].map(function (x) { return { bezeichnung: x.aktuell.werte.bezeichnung, werte: x.aktuell.werte, letzte: x.status.letzte, zaehler: x.zaehler }; });
        var fristen = MM.Aktivitaeten.fristenImZeitraum({ fristen: fristEingabe, heute: self.heute(), endDatum: w.bisDatum, geplanteStrecke: w.geplanteStrecke, geplanteStunden: w.geplanteStunden });
        var konflikte = r[3].filter(function (x) { return a.aktivitaet.id !== x.objekt.id && a.aktuell.werte.status !== 'storniert' && x.status !== 'storniert' && x.aktuell.werte.fahrzeugId === w.fahrzeugId && MM.Aktivitaeten.ueberschneiden(w, x.aktuell.werte); })
          .map(function (x) { return { id: x.objekt.id, name: x.aktuell.werte.bezeichnung, vonDatum: x.aktuell.werte.vonDatum, bisDatum: x.aktuell.werte.bisDatum }; });
        return { geprueftAm: self.jetztLokal(), anforderungen: anf.length,
          befaehigung: { ergebnis: ergebnis, personen: personen, gebiet: gebiet, gebietHinweis: gebietHinweis, gebietInfo: gebietInfo },
          ausruestung: ausruestungErgebnis,
          fristen: { liste: fristen, zusammenfassung: MM.Aktivitaeten.fristenZusammenfassung(fristen) }, belegung: { konflikte: konflikte } };
      });
    });
  };

  /* ---------- Logbuch-Kern: Ereignisarten (offene Liste) ---------- */
  Daten.prototype.ereignisartenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('ereignisarten'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'ereignisart');
    });
  };

  Daten.prototype.ereignisartAnlegen = function (roh) {
    var self = this;
    var bez = trimmed(roh && roh.bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segel gesetzt“.' } });
    return this.ereignisartenListe().then(function (liste) {
      if (liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === bez.toLowerCase(); })) {
        return { ok: false, fehler: { bezeichnung: 'Diese Art gibt es schon.' } };
      }
      return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: bez, ausgeblendet: 'nein' });
    });
  };

  /* Legt die Vorschläge an, die es noch nicht gibt. Gibt die Anzahl der neuen zurück. */
  Daten.prototype.ereignisartenAusVorschlaegen = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Logbuch.VORSCHLAEGE_EREIGNISARTEN.filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
      return neu.reduce(function (kette, n) {
        return kette.then(function () { return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: n, ausgeblendet: 'nein' }); });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  Daten.prototype.ereignisartLaden = function (id) { return this.mitVerlaufLaden('ereignisarten', id, AKTART_FELDER); };

  Daten.prototype.ereignisartAendern = function (id, roh) {
    var self = this;
    return this.ereignisartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var bez = trimmed(roh && roh.bezeichnung);
      if (!bez) return { ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben.' } };
      var neu = { bezeichnung: bez, ausgeblendet: roh.ausgeblendet === 'ja' ? 'ja' : 'nein' };
      return self.mitVerlaufAendern('ereignisart', id, x, neu, AKTART_FELDER);
    });
  };

  /* ---------- Logbuch-Kern: Tagesabschnitte, Ereignisse, Prüfung zum Tagesbeginn ---------- */
  var ABSCHNITT_FELDER = [
    { key: 'datum', label: 'Datum', typ: 'datum' },
    { key: 'beginnZeit', label: 'Beginn (Uhrzeit)', typ: 'zeit' },
    { key: 'endeZeit', label: 'Ende (Uhrzeit)', typ: 'zeit' },
    { key: 'von', label: 'Von', typ: 'text' },
    { key: 'nach', label: 'Nach', typ: 'text' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'zielTatsaechlich', label: 'Tatsächliches Ziel', typ: 'text' },
    { key: 'abschlussNotiz', label: 'Notiz zum Tagesabschluss', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];
  var EREIGNIS_FELDER = [
    { key: 'artId', label: 'Art', typ: 'text' },
    { key: 'datum', label: 'Datum', typ: 'datum' },
    { key: 'zeit', label: 'Uhrzeit', typ: 'zeit' },
    { key: 'text', label: 'Text', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];
  var WECHSEL_FELDER = [
    { key: 'abDatum', label: 'Datum des Wechsels', typ: 'datum' },
    { key: 'abZeit', label: 'Uhrzeit des Wechsels', typ: 'zeit' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  /* Neuester Stand je Objekt aus dem Verlauf. Kein Datenraum-Filter, kein Sortieren nach Name. */
  function neuesteStaende(objekte, verlaeufe, typ) {
    var ver = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === typ) (ver[e.objektId] = ver[e.objektId] || []).push(e); });
    return objekte.map(function (o) {
      var l = (ver[o.id] || []).slice().sort(nachNr);
      return { objekt: o, aktuell: l[l.length - 1] || null, eintraege: l };
    }).filter(function (x) { return x.aktuell; });
  }

  /* Nur Aktivitäten, die nicht storniert sind, nehmen neue Einträge an (wie bei „Angaben ändern“). */
  function logbuchAktivitaet(self, aktivitaetId, schreibend) {
    return self.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (schreibend && a.aktuell.werte.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      return { a: a };
    });
  }

  function ausserhalbVon(a, datum) { return datum < a.aktuell.werte.vonDatum || datum > a.aktuell.werte.bisDatum; }

  /*
   * Das Logbuch einer Aktivität: alle Tagesabschnitte mit ihren Ereignissen (handeingetragene und
   * automatische Wechsel des Verantwortlichen), der festgehaltenen Prüfung und dem Verantwortlichen
   * zum Tagesbeginn. Es wird nichts geschrieben.
   */
  Daten.prototype.logbuchLaden = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.speicher.wo('tagesabschnitte', 'aktivitaetId', aktivitaetId),
      this.speicher.wo('ereignisse', 'aktivitaetId', aktivitaetId), this.speicher.alle('verlaeufe'),
      this.speicher.wo('tagespruefungen', 'aktivitaetId', aktivitaetId), this.ereignisartenListe()]).then(function (r) {
      var a = r[0];
      if (!a) return null;
      var arten = {}; r[5].forEach(function (x) { arten[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      var abschnitte = MM.Logbuch.abschnitteSortieren(neuesteStaende(r[1], r[3], 'tagesabschnitt'));
      var sichtbar = abschnitte.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; });
      var ziele = sichtbar.length ? sichtbar : abschnitte;

      var proAbschnitt = {};
      abschnitte.forEach(function (x) { proAbschnitt[x.objekt.id] = []; });
      neuesteStaende(r[2], r[3], 'ereignis').forEach(function (e) {
        var w = e.aktuell.werte;
        if (!proAbschnitt[e.objekt.abschnittId]) return;
        proAbschnitt[e.objekt.abschnittId].push({ art: 'ereignis', id: e.objekt.id, artName: arten[w.artId] || 'unbekannt', datum: w.datum, zeit: w.zeit,
          zeitpunkt: MM.Logbuch.ereignisZeit(w), text: w.text || null, ausgeblendet: w.ausgeblendet === 'ja',
          nachgetragen: w.nachgetragen === 'ja', nachgetragenAm: w.nachgetragenAm || null, hatFoto: !!w.dateiName, geaendert: e.eintraege.length > 1 });
      });
      MM.Logbuch.wechselEreignisse(a.verantwortung).forEach(function (wz) {
        var ziel = MM.Logbuch.abschnittFuer(ziele, wz.datum);
        if (!ziel) return;
        proAbschnitt[ziel.objekt.id].push({ art: 'wechsel', id: wz.verantwortungId, artName: MM.Logbuch.WECHSEL_ART, datum: wz.datum, zeit: wz.zeit,
          zeitpunkt: wz.ab, text: wz.text, notiz: wz.notiz, ausgeblendet: wz.ausgeblendet, nachgetragen: !!wz.nachgetragenAm, nachgetragenAm: wz.nachgetragenAm, pruefung: wz.pruefung, hatFoto: false, geaendert: wz.geaendert });
      });

      var pruefungen = {};
      r[4].slice().sort(function (x, y) { return x.erstelltAm < y.erstelltAm ? 1 : (x.erstelltAm > y.erstelltAm ? -1 : 0); })
        .forEach(function (p) { (pruefungen[p.abschnittId] = pruefungen[p.abschnittId] || []).push(p); });

      var liste = abschnitte.map(function (x) {
        var w = x.aktuell.werte;
        var tb = w.datum + 'T' + (w.beginnZeit || '00:00');
        var v = MM.Aktivitaeten.verantwortlicher(a.verantwortung, tb);
        var ereignisse = MM.Logbuch.ereignisseSortieren(proAbschnitt[x.objekt.id]);
        var verlauf = verlaufAus(x.eintraege, ABSCHNITT_FELDER);
        return { objekt: x.objekt, aktuell: x.aktuell, verlauf: verlauf, ausgeblendet: w.ausgeblendet === 'ja', ausserhalb: ausserhalbVon(a, w.datum),
          tagesbeginn: tb, verantwortlicher: v ? { personId: v.personId, name: v.name } : null,
          ereignisse: ereignisse, anzahlEreignisse: ereignisse.filter(function (e) { return !e.ausgeblendet; }).length,
          pruefungen: pruefungen[x.objekt.id] || [], pruefung: (pruefungen[x.objekt.id] || [])[0] || null };
      });
      var fehlend = MM.Logbuch.fehlendeTage(a.aktuell.werte, abschnitte.map(function (x) { return x.aktuell.werte.datum; }));
      return { aktivitaet: a, abschnitte: liste, fehlend: fehlend.neu.length, zuLang: fehlend.zuLang };
    });
  };

  /* Ein Abschnitt mit allem, was dazugehört (aus derselben Quelle wie das Logbuch). */
  Daten.prototype.abschnittLaden = function (id) {
    var self = this;
    return this.speicher.holen('tagesabschnitte', id).then(function (o) {
      if (!o) return null;
      return self.logbuchLaden(o.aktivitaetId).then(function (l) {
        if (!l) return null;
        var x = l.abschnitte.filter(function (y) { return y.objekt.id === id; })[0];
        return x ? { abschnitt: x, aktivitaet: l.aktivitaet } : null;
      });
    });
  };

  /* Prüft die Angaben eines Abschnitts. */
  Daten.prototype.pruefenAbschnitt = function (roh) {
    roh = roh || {};
    var felder = [{ key: 'datum', typ: 'datum' }, { key: 'beginnZeit', typ: 'zeit' }, { key: 'endeZeit', typ: 'zeit' },
      { key: 'von', typ: 'text' }, { key: 'nach', typ: 'text' }, { key: 'notiz', typ: 'text' }];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    if (!w.datum && !f.datum) f.datum = 'Bitte das Datum des Tages angeben.';
    if (w.beginnZeit && w.endeZeit && w.endeZeit < w.beginnZeit && !f.endeZeit) f.endeZeit = 'Die Uhrzeit des Endes liegt vor der des Beginns.';
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Die App bereitet die Tage aus dem Zeitraum der Aktivität vor. Bestehende Abschnitte bleiben unberührt. */
  Daten.prototype.tagesabschnitteVorbereiten = function (aktivitaetId) {
    var self = this;
    return logbuchAktivitaet(this, aktivitaetId, true).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      return self.speicher.wo('tagesabschnitte', 'aktivitaetId', aktivitaetId).then(function (vorhanden) {
        return self.speicher.alle('verlaeufe').then(function (vl) {
          var daten = neuesteStaende(vorhanden, vl, 'tagesabschnitt').map(function (x) { return x.aktuell.werte.datum; });
          var f = MM.Logbuch.fehlendeTage(k.a.aktuell.werte, daten);
          if (f.zuLang) return { ok: false, fehler: { allgemein: 'Der Zeitraum ist länger als ' + MM.Logbuch.MAX_TAGE + ' Tage. Lege die Tage von Hand an.' } };
          var jetzt = self.jetzt(), liste = [];
          f.neu.forEach(function (w) {
            var o = { id: neueId('tg'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, herkunft: 'vorbereitet', erstelltAm: jetzt };
            liste.push({ tabelle: 'tagesabschnitte', objekt: o });
            liste.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('tagesabschnitt', o.id, 1, w, null, jetzt) });
          });
          if (!liste.length) return { ok: true, anzahl: 0 };
          return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, anzahl: f.neu.length }; });
        });
      });
    });
  };

  /* Einen Tag von Hand ergänzen. */
  Daten.prototype.abschnittAnlegen = function (aktivitaetId, roh) {
    var self = this;
    return logbuchAktivitaet(this, aktivitaetId, true).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      var p = self.pruefenAbschnitt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      p.werte.ausgeblendet = 'nein';
      return self.mitVerlaufAnlegen('tagesabschnitte', 'tagesabschnitt', 'tg', p.werte, { aktivitaetId: aktivitaetId, herkunft: 'hand' });
    });
  };

  Daten.prototype.abschnittAendern = function (id, roh) {
    var self = this;
    return this.abschnittLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenAbschnitt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      /* Die Angaben des Tagesabschlusses stehen nicht im Formular „Tag ändern“ und bleiben unberührt. */
      var neu = Object.assign({}, x.abschnitt.aktuell.werte, p.werte);
      return self.mitVerlaufAendern('tagesabschnitt', id, { aktuell: x.abschnitt.aktuell }, neu, ABSCHNITT_FELDER);
    });
  };

  /* Die Prüfung der Aktivität zum Tagesbeginn festhalten (nur anhängen, nichts wird überschrieben). */
  Daten.prototype.tagesPruefungFesthalten = function (abschnittId) {
    var self = this;
    return this.abschnittLaden(abschnittId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      return self.aktivitaetPruefung(x.aktivitaet.aktivitaet.id).then(function (pr) {
        var stand = MM.Logbuch.pruefungFestgehalten(pr, x.abschnitt.verantwortlicher, x.abschnitt.tagesbeginn);
        var rec = { id: neueId('tp'), datenraumId: self.datenraumId, aktivitaetId: x.aktivitaet.aktivitaet.id, abschnittId: abschnittId, stand: stand, erstelltAm: self.jetzt() };
        return self.speicher.speichern('tagespruefungen', rec).then(function () { return { ok: true, id: rec.id }; });
      });
    });
  };

  /* ---------- Ereignisse ---------- */
  /* nachtragen = true: Der Zeitpunkt ist der echte, vergangene Zeitpunkt; das Ereignis steht dann als „nachgetragen am …“ da. */
  Daten.prototype.pruefenEreignis = function (roh, arten, nachtragen, bisherigeArt) {
    roh = roh || {};
    var felder = [
      { key: 'artId', typ: 'auswahl', optionen: arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || a.objekt.id === bisherigeArt; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; }) },
      { key: 'datum', typ: 'datum' }, { key: 'zeit', typ: 'zeit' }, { key: 'text', typ: 'text' }
    ];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    if (!w.artId && !f.artId) f.artId = arten.length ? 'Bitte die Art des Ereignisses wählen.' : 'Es gibt noch keine Art. Übernimm zuerst die Vorschläge oder lege eine Art an.';
    if (!w.datum && !f.datum) f.datum = 'Bitte das Datum angeben.';
    if (!w.zeit && !f.zeit) f.zeit = 'Bitte die Uhrzeit angeben.';
    if (nachtragen && w.datum && w.zeit && !f.datum && !f.zeit && w.datum + 'T' + w.zeit > this.jetztLokal()) {
      f.zeit = 'Ein Nachtrag liegt in der Vergangenheit. Der Zeitpunkt darf nicht nach jetzt liegen.';
    }
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.ereignisAnlegen = function (abschnittId, roh, optionen) {
    var self = this;
    var nachtragen = !!(optionen && optionen.nachtragen);
    roh = roh || {};
    return Promise.all([this.abschnittLaden(abschnittId), this.ereignisartenListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenEreignis(roh, r[1], nachtragen, null);
      var fehler = p.fehler, w = p.werte;
      /* Weicht die Zeit um mehr als 5 Minuten von jetzt ab (in der Vergangenheit), ist es automatisch ein Nachtrag (wie in V1). */
      if (!nachtragen && !Object.keys(fehler).length && MM.Logbuch.zeitpunktArt(w.datum, w.zeit, self.jetztLokal()) === 'nachtrag') nachtragen = true;
      var datei = roh.datei;
      if (datei && !(typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Diese Datei ist leer.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var jetzt = self.jetzt();
      w.ausgeblendet = 'nein';
      w.nachgetragen = nachtragen ? 'ja' : 'nein';
      w.nachgetragenAm = nachtragen ? jetzt : null;
      w.dateiName = datei ? String(datei.name || 'Foto') : null;
      w.dateiTyp = datei ? String(datei.type || '') : null;
      w.dateiGroesse = datei ? datei.size : null;
      var e = { id: neueId('ev'), datenraumId: self.datenraumId, aktivitaetId: x.aktivitaet.aktivitaet.id, abschnittId: abschnittId, erstelltAm: jetzt };
      var liste = [{ tabelle: 'ereignisse', objekt: e }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ereignis', e.id, 1, w, null, jetzt) }];
      if (datei) liste.push({ tabelle: 'ereignisdateien', objekt: { id: neueId('ed'), ereignisId: e.id, name: w.dateiName, mime: w.dateiTyp, groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: e.id }; }).catch(function (err) {
        if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei.' } };
        throw err;
      });
    });
  };

  Daten.prototype.ereignisLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('ereignisse', id, EREIGNIS_FELDER).then(function (x) {
      if (!x) return null;
      return Promise.all([self.ereignisartenListe(), self.abschnittLaden(x.objekt.abschnittId), self.speicher.wo('ereignisdateien', 'ereignisId', id)]).then(function (r) {
        var arten = {}; r[0].forEach(function (a) { arten[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artId') { u.feld = { typ: 'text' }; u.alt = u.alt ? arten[u.alt] || 'unbekannt' : null; u.neu = u.neu ? arten[u.neu] || 'unbekannt' : null; }
          });
        });
        var w = x.aktuell.werte, d = r[2][0];
        return { ereignis: x.objekt, aktuell: x.aktuell, verlauf: x.verlauf, art: w.artId ? { id: w.artId, name: arten[w.artId] || 'unbekannt' } : null, arten: r[0],
          abschnitt: r[1] ? r[1].abschnitt : null, aktivitaet: r[1] ? r[1].aktivitaet : null,
          datei: d ? { id: d.id, name: d.name, mime: d.mime, groesse: d.groesse } : null };
      });
    });
  };

  Daten.prototype.ereignisDateiHolen = function (ereignisId) {
    return this.speicher.wo('ereignisdateien', 'ereignisId', ereignisId).then(function (l) { return l[0] || null; });
  };

  Daten.prototype.ereignisAendern = function (id, roh) {
    var self = this;
    return this.ereignisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      if (x.aktivitaet && x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var alt = x.aktuell.werte;
      var p = self.pruefenEreignis(roh, x.arten, alt.nachgetragen === 'ja', alt.artId);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, alt, p.werte);
      return self.mitVerlaufAendern('ereignis', id, { aktuell: x.aktuell }, neu, EREIGNIS_FELDER);
    });
  };

  /* ---------- 2.0.14: Cockpit (schnelles Eintragen) und Tagesabschluss ---------- */
  /* Der heutige Tag: der sichtbare Tag von heute wird geöffnet, gibt es keinen, legt die App ihn von selbst an
     (ohne vorheriges „Tage vorbereiten“). Nur wenn der heutige Tag im Zeitraum der Aktivität liegt und sie nicht storniert ist. */
  Daten.prototype.heutigerTag = function (aktivitaetId) {
    var self = this;
    return this.logbuchLaden(aktivitaetId).then(function (lb) {
      if (!lb) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var a = lb.aktivitaet, heute = self.heute();
      var c = MM.Logbuch.cockpitMoeglich(a.aktuell.werte, heute);
      if (!c.moeglich) {
        var text = { storniert: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.',
          geplant: 'Die Aktivität beginnt erst am ' + MM.Hilfen.datum(a.aktuell.werte.vonDatum) + '. Das Cockpit trägt nur ein, wenn heute im Zeitraum liegt.',
          vorbei: 'Die Aktivität war bis ' + MM.Hilfen.datum(a.aktuell.werte.bisDatum) + '. Das Cockpit trägt nur ein, wenn heute im Zeitraum liegt. Im Logbuch kannst du Tage ergänzen und nachtragen.' }[c.grund];
        return { ok: false, fehler: { allgemein: text } };
      }
      var vorhanden = MM.Logbuch.heutigerAbschnitt(lb.abschnitte, heute);
      if (vorhanden) return { ok: true, abschnittId: vorhanden.objekt.id, neu: false };
      var werte = MM.Logbuch.fehlendeTage(a.aktuell.werte, []).neu.filter(function (x) { return x.datum === heute; })[0]
        || { datum: heute, beginnZeit: null, endeZeit: null, von: null, nach: null, notiz: null, ausgeblendet: 'nein' };
      return self.mitVerlaufAnlegen('tagesabschnitte', 'tagesabschnitt', 'tg', werte, { aktivitaetId: aktivitaetId, herkunft: 'vorbereitet' })
        .then(function (r) { return { ok: true, abschnittId: r.id, neu: true }; });
    });
  };

  /* Ein Tipp auf Abfahrt, Ankunft oder Notiz: Ereignis mit der Uhrzeit „jetzt“, ohne Formular.
     art: 'Abfahrt', 'Ankunft' oder 'Notiz' (Name der Art). Fehlen die Vorschläge der Arten, werden sie angelegt. */
  Daten.prototype.ereignisSchnell = function (aktivitaetId, artName, roh) {
    var self = this;
    roh = roh || {};
    return this.heutigerTag(aktivitaetId).then(function (t) {
      if (!t.ok) return t;
      return self.ereignisartenAusVorschlaegen().then(function () { return self.ereignisartenListe(); }).then(function (arten) {
        /* Ist die Art schon gewählt (artId), wird nicht nach dem Namen gesucht. */
        var art = roh.artId ? { objekt: { id: roh.artId }, aktuell: { werte: { ausgeblendet: 'nein' } } }
          : arten.filter(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === String(artName).toLowerCase(); })[0];
        if (!art) return { ok: false, fehler: { allgemein: 'Die Art „' + artName + '“ gibt es nicht.' } };
        if (art.aktuell.werte.ausgeblendet === 'ja') return { ok: false, fehler: { allgemein: 'Die Art „' + artName + '“ ist ausgeblendet. Blende sie unter „Arten von Ereignissen“ wieder ein.' } };
        /* Leere Zeit heißt „jetzt“ und wird erst beim Speichern genommen, nicht beim Öffnen der Seite. */
        var jetzt = self.jetztLokal();
        var werte = { artId: roh.artId || art.objekt.id, datum: roh.datum || jetzt.slice(0, 10), zeit: roh.zeit || jetzt.slice(11, 16), text: roh.text || '', datei: roh.datei || null };
        if (!roh.datum && roh.zeit) werte.datum = jetzt.slice(0, 10);
        return self.ereignisAnlegen(t.abschnittId, werte, {}).then(function (r) {
          if (r.ok) { r.zeit = werte.zeit; r.datum = werte.datum; r.abschnittId = t.abschnittId; }
          return r;
        });
      });
    });
  };

  /* Tagesabschluss (wie in V1): tatsächliches Ziel und Notiz, als neue Felder am Tagesabschnitt.
     Der Zählerstand am Ende gehört zu Schritt 6 und ist nicht dabei. */
  Daten.prototype.tagesabschlussSpeichern = function (abschnittId, roh) {
    var self = this;
    roh = roh || {};
    return this.abschnittLaden(abschnittId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = pruefeWerte([{ key: 'zielTatsaechlich', typ: 'text' }, { key: 'abschlussNotiz', typ: 'text' }], roh, jahrVon(self), { ohneBezeichnung: true });
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, x.abschnitt.aktuell.werte, { zielTatsaechlich: p.werte.zielTatsaechlich || null, abschlussNotiz: p.werte.abschlussNotiz || null });
      return self.mitVerlaufAendern('tagesabschnitt', abschnittId, { aktuell: x.abschnitt.aktuell }, neu, ABSCHNITT_FELDER);
    });
  };

  /* ---------- Wechsel des Verantwortlichen als Ereignis ---------- */
  /* Der Wechsel selbst bleibt in der Tabelle „verantwortung“. Korrekturen stehen im Verlauf und gelten ab sofort überall. */
  Daten.prototype.wechselLaden = function (verantwortungId) {
    var self = this;
    return this.speicher.holen('verantwortung', verantwortungId).then(function (rec) {
      if (!rec) return null;
      return Promise.all([self.aktivitaetLaden(rec.aktivitaetId), self.speicher.wo('verlaeufe', 'objektId', verantwortungId)]).then(function (r) {
        var a = r[0];
        if (!a) return null;
        var wz = MM.Logbuch.wechselEreignisse(a.verantwortung).filter(function (x) { return x.verantwortungId === verantwortungId; })[0];
        if (!wz) return null;
        var eintraege = r[1].filter(function (e) { return e.objektTyp === 'verantwortung'; }).sort(nachNr);
        var basis = { id: 'basis', objektTyp: 'verantwortung', objektId: verantwortungId, nr: 0, quelle: 'hand', korrekturZu: null, erstelltAm: rec.erstelltAm,
          werte: { abDatum: rec.ab.slice(0, 10), abZeit: rec.ab.slice(11, 16), notiz: null, ausgeblendet: 'nein' } };
        return { wechsel: wz, aktivitaet: a, eintraege: eintraege, verlauf: verlaufAus([basis].concat(eintraege), WECHSEL_FELDER) };
      });
    });
  };

  Daten.prototype.wechselAendern = function (verantwortungId, roh) {
    var self = this;
    roh = roh || {};
    var p = pruefeWerte([{ key: 'abDatum', typ: 'datum' }, { key: 'abZeit', typ: 'zeit' }, { key: 'notiz', typ: 'text' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var f = p.fehler, w = p.werte;
    if (!w.abDatum && !f.abDatum) f.abDatum = 'Bitte das Datum des Wechsels angeben.';
    if (!w.abZeit && !f.abZeit) f.abZeit = 'Bitte die Uhrzeit des Wechsels angeben.';
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return this.wechselLaden(verantwortungId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Wechsel wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var ab = w.abDatum + 'T' + w.abZeit;
      var liste = x.aktivitaet.verantwortung;
      var i = liste.map(function (v) { return v.id; }).indexOf(verantwortungId);
      var davor = liste[i - 1], danach = liste[i + 1];
      if (davor && ab <= davor.ab) return { ok: false, fehler: { abDatum: 'Der Wechsel muss nach dem vorherigen Wechsel liegen (' + davor.ab.replace('T', ', ') + ' Uhr).' } };
      if (danach && ab >= danach.ab) return { ok: false, fehler: { abDatum: 'Der Wechsel muss vor dem nächsten Wechsel liegen (' + danach.ab.replace('T', ', ') + ' Uhr).' } };
      var jetztStand = x.verlauf[0].eintrag.werte;
      if (!unterschiedeFelder(WECHSEL_FELDER, jetztStand, w).length) return { ok: true, id: verantwortungId, geaendert: false };
      var letzte = x.eintraege[x.eintraege.length - 1];
      var e = neuerVerlaufEintrag('verantwortung', verantwortungId, letzte ? letzte.nr + 1 : 1, w, letzte ? letzte.id : null, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: verantwortungId, geaendert: true }; });
    });
  };

  /* ---------- Sicherung ---------- */
  var DATEI_TABELLEN = ['dateien', 'nachweisdateien', 'ereignisdateien'];
  var ZAEHL_TABELLEN = [['fahrzeuge', 'Fahrzeuge'], ['komponenten', 'Komponenten'], ['fristen', 'Fristen'], ['zaehler', 'Zähler'], ['personen', 'Personen'],
    ['tiere', 'Tiere'], ['nachweise', 'Nachweise'], ['aktivitaeten', 'Aktivitäten'], ['dokumente', 'Dokumente'],
    ['orte', 'Orte'], ['standorte', 'Standorte'], ['gebiete', 'Gebiete'], ['regeln', 'Regeln'],
    ['tagesabschnitte', 'Tagesabschnitte'], ['ereignisse', 'Ereignisse']];

  function lokalesDatum(iso) {
    var d = new Date(iso);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
  }

  Daten.prototype.einstellungLesen = function (id) { return this.speicher.holen('einstellungen', id); };
  Daten.prototype.einstellungSchreiben = function (obj) { return this.speicher.speichern('einstellungen', obj); };

  /* Wann wurde zuletzt gesichert, und wie oft soll erinnert werden? (0 = nie erinnern) */
  Daten.prototype.sicherungInfo = function () {
    return Promise.all([this.einstellungLesen('sicherung'), this.speicher.alle('fahrzeuge'), this.speicher.alle('personen'), this.speicher.alle('tiere')]).then(function (r) {
      var e = r[0] || {};
      return { letzte: e.letzteSicherung || null, erinnerungTage: e.erinnerungTage === undefined ? 30 : e.erinnerungTage, hatDaten: (r[1].length + r[2].length + r[3].length) > 0 };
    });
  };

  Daten.prototype.sicherungEinstellen = function (aenderung) {
    var self = this;
    return this.einstellungLesen('sicherung').then(function (alt) {
      return self.einstellungSchreiben(Object.assign({ id: 'sicherung', letzteSicherung: null, erinnerungTage: 30 }, alt || {}, aenderung));
    });
  };

  /* Soll die App an die Sicherung erinnern? Nur, wenn es Daten gibt und die Erinnerung nicht aus ist. */
  Daten.prototype.sicherungErinnerung = function () {
    var self = this;
    return this.sicherungInfo().then(function (i) {
      if (!i.hatDaten || !i.erinnerungTage) return { faellig: false };
      if (!i.letzte) return { faellig: true, grund: 'nie' };
      var tage = MM.Fristen.tageZwischen(lokalesDatum(i.letzte), self.heute());
      return tage >= i.erinnerungTage ? { faellig: true, grund: 'alt', tage: tage } : { faellig: false, tage: tage };
    });
  };

  /* Zahlen der Daten auf diesem Gerät, in derselben Form wie in einer Sicherung. */
  Daten.prototype.sicherungZahlen = function () {
    return this.speicher.alleTabellen().then(function (t) {
      var z = {};
      ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
      var dl = []; DATEI_TABELLEN.forEach(function (n) { dl = dl.concat(t[n] || []); });
      z.dateien = dl.length;
      z.dateiBytes = dl.reduce(function (s, d) { return s + (d.groesse || 0); }, 0);
      return z;
    });
  };

  /* Erzeugt die Sicherung. Gibt Bytes, Dateinamen und Zahlen zurück. */
  Daten.prototype.sicherungErzeugen = function (optionen) {
    var self = this;
    optionen = optionen || {};
    var mitDateien = !!optionen.mitDateien;
    return this.speicher.alleTabellen().then(function (alle) {
      var tabellen = {}, dateien = [], leer = 0;
      var kette = Promise.resolve();
      MM.Speicher.TABELLEN.forEach(function (name) {
        var liste = alle[name] || [];
        if (DATEI_TABELLEN.indexOf(name) >= 0) {
          if (!mitDateien) return;
          tabellen[name] = [];
          liste.forEach(function (rec) {
            kette = kette.then(function () {
              var kopie = Object.assign({}, rec);
              if (rec.inhalt && typeof rec.inhalt.arrayBuffer === 'function') {
                return rec.inhalt.arrayBuffer().then(function (buf) { kopie.inhalt = { $datei: dateien.length }; dateien.push(new Uint8Array(buf)); tabellen[name].push(kopie); });
              }
              leer++; kopie.inhalt = null; tabellen[name].push(kopie);
            });
          });
          return;
        }
        tabellen[name] = liste;
      });
      return kette.then(function () {
        var zaehlung = {}; Object.keys(tabellen).forEach(function (n) { zaehlung[n] = tabellen[n].length; });
        var kopf = { format: MM.Sicherung.FORMAT, app: MM.VERSION, dbVersion: MM.Speicher.DB_VERSION, erstelltAm: self.jetzt(), mitDateien: mitDateien, tabellen: tabellen, zaehlung: zaehlung };
        return MM.Sicherung.bauen(kopf, dateien, optionen.schluessel || '').then(function (bytes) {
          var z = {}; ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (tabellen[x[0]] || []).length; });
          var d = new Date(kopf.erstelltAm);
          function p(n) { return (n < 10 ? '0' : '') + n; }
          var name = 'MobiMory-Sicherung_' + d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '_' + p(d.getHours()) + '-' + p(d.getMinutes()) + '.mmsicherung';
          return { bytes: bytes, name: name, groesse: bytes.length, zahlen: z, dateien: dateien.length, ohneInhalt: leer, mitDateien: mitDateien, verschluesselt: !!optionen.schluessel, erstelltAm: kopf.erstelltAm };
        });
      });
    });
  };

  /* Prüft den Inhalt einer entpackten Sicherung. Wirft Fehler mit code und verständlichem Text. */
  function sicherungPruefen(gelesen) {
    function f(code, text) { var e = new Error(text); e.code = code; return e; }
    var k = gelesen.kopf;
    if (!k || typeof k !== 'object' || !k.tabellen || typeof k.tabellen !== 'object') throw f('beschaedigt', 'Die Datei ist beschädigt.');
    if (k.format !== MM.Sicherung.FORMAT) {
      throw f(k.format > MM.Sicherung.FORMAT ? 'neuer' : 'format', k.format > MM.Sicherung.FORMAT ? 'Diese Sicherung stammt aus einer neueren Version von MobiMory. Bitte zuerst die App aktualisieren.' : 'Das ist keine MobiMory-Sicherung.');
    }
    if (typeof k.dbVersion !== 'number' || k.dbVersion > MM.Speicher.DB_VERSION) throw f('neuer', 'Diese Sicherung stammt aus einer neueren Version von MobiMory (' + (k.app || '?') + '). Bitte zuerst die App aktualisieren.');
    var benutzt = {};
    Object.keys(k.tabellen).forEach(function (n) {
      if (MM.Speicher.TABELLEN.indexOf(n) < 0) throw f('beschaedigt', 'Die Sicherung enthält etwas Unbekanntes (' + n + ').');
      var liste = k.tabellen[n];
      if (!Array.isArray(liste)) throw f('beschaedigt', 'Die Datei ist beschädigt.');
      if (k.zaehlung && k.zaehlung[n] !== undefined && k.zaehlung[n] !== liste.length) throw f('beschaedigt', 'Die Datei ist beschädigt: Die Anzahl der Einträge stimmt nicht.');
      liste.forEach(function (o) {
        if (!o || typeof o !== 'object' || typeof o.id !== 'string' || !o.id) throw f('beschaedigt', 'Die Datei ist beschädigt: Ein Eintrag ist unvollständig.');
        if (DATEI_TABELLEN.indexOf(n) >= 0 && o.inhalt !== null && o.inhalt !== undefined) {
          var i = o.inhalt && o.inhalt.$datei;
          if (typeof i !== 'number' || i < 0 || i >= gelesen.dateien.length || benutzt[i]) throw f('beschaedigt', 'Die Datei ist beschädigt: Eine Datei fehlt.');
          benutzt[i] = true;
        }
      });
    });
    return true;
  }

  /* Entpackt und prüft eine Sicherung. Noch nichts wird verändert. */
  Daten.prototype.sicherungLesen = function (bytes, schluessel) {
    return MM.Sicherung.auspacken(bytes, schluessel || '').then(function (g) { sicherungPruefen(g); return g; });
  };

  /* Was steht in der Sicherung, und was ist jetzt auf dem Gerät? */
  Daten.prototype.sicherungVorschau = function (gelesen) {
    return this.sicherungZahlen().then(function (jetzt) {
      var t = gelesen.kopf.tabellen, z = {};
      ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
      var bytes = gelesen.dateien.reduce(function (s, d) { return s + d.length; }, 0);
      return { erstelltAm: gelesen.kopf.erstelltAm, app: gelesen.kopf.app, mitDateien: !!gelesen.kopf.mitDateien, dateien: gelesen.dateien.length, dateiBytes: bytes, zahlen: z, jetzt: jetzt };
    });
  };

  /*
   * Ersetzt ALLE Daten auf dem Gerät durch die der Sicherung, in einem Schritt.
   * Schlägt etwas fehl, bleibt der bisherige Stand unverändert.
   */
  Daten.prototype.sicherungEinspielen = function (gelesen) {
    var self = this;
    try { sicherungPruefen(gelesen); } catch (e) { return Promise.reject(e); }
    var t = gelesen.kopf.tabellen, karte = {};
    MM.Speicher.TABELLEN.forEach(function (n) {
      var liste = t[n] || [];
      karte[n] = liste.map(function (o) {
        if (DATEI_TABELLEN.indexOf(n) >= 0) {
          var kopie = Object.assign({}, o);
          kopie.inhalt = (o.inhalt && typeof o.inhalt.$datei === 'number') ? new Blob([gelesen.dateien[o.inhalt.$datei]], { type: o.mime || '' }) : null;
          return kopie;
        }
        return o;
      });
    });
    var einst = (karte.einstellungen || []).filter(function (e) { return e.id === 'sicherung'; })[0] || {};
    karte.einstellungen = (karte.einstellungen || []).filter(function (e) { return e.id !== 'sicherung'; })
      .concat([{ id: 'sicherung', letzteSicherung: gelesen.kopf.erstelltAm, erinnerungTage: einst.erinnerungTage === undefined ? 30 : einst.erinnerungTage }]);
    return this.speicher.ersetzenAlles(karte).then(function () { return self.starten(); });
  };

  /* Nur für Tests auf dem eigenen Gerät. */
  Daten.prototype.allesLoeschen = function () {
    var self = this;
    return this.speicher.allesLoeschen().then(function () { return self.starten(); });
  };

  MM.Daten = { Daten: Daten };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
