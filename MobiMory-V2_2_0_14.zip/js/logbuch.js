/*
 * Logbuch-Kern: Regeln und Rechnung (Tagesabschnitte, Ereignisse, Prüfung zum Tagesbeginn).
 *
 * Aus den V2-Festlegungen und der Übergabe für 2.0.13:
 *  - Tagesabschnitte sind ein Zusatzbaustein an der Aktivität, kein eigener Bereich.
 *  - Die App bereitet die Tage aus dem Zeitraum der Aktivität vor. Jeder Abschnitt ist von Hand
 *    änderbar, ergänzbar und ausblendbar.
 *  - Die Prüfung zum Tagesbeginn ist die vorhandene Rechnung der Aktivität (aktivitaetPruefung).
 *    Sie wird hier nur je Tag festgehalten, mit „geprüft am“ und dem Verantwortlichen dieses Tages.
 *  - Ereignisarten sind eine offene Liste mit Vorschlägen.
 *  - Ein Wechsel des Verantwortlichen erscheint automatisch als Ereignis. Er bleibt die eine Quelle
 *    in der Tabelle „verantwortung“; eine Korrektur der Uhrzeit bleibt im Verlauf.
 *  - Nachtragen: ein Ereignis mit dem echten Zeitpunkt, markiert als „nachgetragen am …“.
 *  - Nichts wird gelöscht. Änderung = neuer Stand im Verlauf, Ausblenden statt Löschen.
 *  - Ab 2.0.14: Cockpit (schnelles Eintragen unterwegs) und klassisches Logbuch zeigen dieselben Einträge.
 *    Weicht eine Uhrzeit um mehr als 5 Minuten von „jetzt“ ab, ist das Ereignis ein Nachtrag.
 *    Beim Wechsel des Verantwortlichen wird die Befähigung der übernehmenden Person geprüft und
 *    festgehalten; die App weist nur hin und sperrt nichts.
 *
 * Hier steht nur Rechnung und Beschreibung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var VORSCHLAEGE_EREIGNISARTEN = ['Abfahrt', 'Ankunft', 'Wechsel des Verantwortlichen', 'Störung', 'Notiz'];
  var WECHSEL_ART = 'Wechsel des Verantwortlichen';
  var MAX_TAGE = 366;
  var WOCHENTAGE = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];

  /* "2026-12-01" -> Zahl der Tage seit 1970 (ohne Zeitzonen-Probleme). */
  function tagNummer(datum) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(datum || '');
    if (!m) return NaN;
    return Math.round(Date.UTC(+m[1], +m[2] - 1, +m[3]) / 86400000);
  }
  function tagText(nr) {
    var d = new Date(nr * 86400000);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getUTCFullYear() + '-' + z(d.getUTCMonth() + 1) + '-' + z(d.getUTCDate());
  }

  /* Alle Tage von bis (einschließlich). zuLang = mehr als MAX_TAGE Tage; dann kommt keine Liste. */
  function tageImZeitraum(vonDatum, bisDatum) {
    var a = tagNummer(vonDatum), b = tagNummer(bisDatum);
    if (isNaN(a) || isNaN(b) || b < a) return { tage: [], zuLang: false };
    if (b - a + 1 > MAX_TAGE) return { tage: [], zuLang: true };
    var res = [];
    for (var i = a; i <= b; i++) res.push(tagText(i));
    return { tage: res, zuLang: false };
  }

  function wochentag(datum) {
    var n = tagNummer(datum);
    return isNaN(n) ? '' : WOCHENTAGE[new Date(n * 86400000).getUTCDay()];
  }

  /*
   * Welche Tagesabschnitte fehlen noch? Gibt für jeden fehlenden Tag die Werte eines neuen
   * Abschnitts zurück. Am ersten Tag steht die Uhrzeit des Beginns, am letzten die des Endes
   * (nur wenn sie bei der Aktivität eingetragen sind). Tage, für die es schon einen Abschnitt
   * gibt (auch einen ausgeblendeten), werden nicht noch einmal vorbereitet.
   */
  function fehlendeTage(aktivitaet, vorhandeneDaten) {
    var z = tageImZeitraum(aktivitaet.vonDatum, aktivitaet.bisDatum);
    if (z.zuLang) return { zuLang: true, neu: [] };
    var da = {};
    (vorhandeneDaten || []).forEach(function (d) { da[d] = true; });
    var neu = [];
    z.tage.forEach(function (d, i) {
      if (da[d]) return;
      neu.push({
        datum: d,
        beginnZeit: i === 0 ? (aktivitaet.vonZeit || null) : null,
        endeZeit: i === z.tage.length - 1 ? (aktivitaet.bisZeit || null) : null,
        von: null, nach: null, notiz: null, ausgeblendet: 'nein'
      });
    });
    return { zuLang: false, neu: neu };
  }

  function zeitSchluessel(datum, zeit) { return (datum || '') + 'T' + (zeit || '00:00'); }

  /* Abschnitte nach Datum, dann nach Beginn. x.aktuell.werte hat datum und beginnZeit. */
  function abschnitteSortieren(liste) {
    return liste.slice().sort(function (a, b) {
      var ka = zeitSchluessel(a.aktuell.werte.datum, a.aktuell.werte.beginnZeit);
      var kb = zeitSchluessel(b.aktuell.werte.datum, b.aktuell.werte.beginnZeit);
      return ka < kb ? -1 : (ka > kb ? 1 : 0);
    });
  }

  /*
   * In welchen Abschnitt gehört ein Zeitpunkt (nur für automatische Ereignisse)?
   * Der Abschnitt mit demselben Datum, sonst der letzte davor, sonst der erste. Ohne Abschnitte: null.
   */
  function abschnittFuer(abschnitte, datum) {
    var sortiert = abschnitteSortieren(abschnitte);
    if (!sortiert.length) return null;
    var gleich = sortiert.filter(function (x) { return x.aktuell.werte.datum === datum; })[0];
    if (gleich) return gleich;
    var davor = sortiert.filter(function (x) { return x.aktuell.werte.datum < datum; });
    return davor.length ? davor[davor.length - 1] : sortiert[0];
  }

  /*
   * Aus den Einträgen der Verantwortung die Wechsel machen. Der erste Eintrag ist der Beginn
   * und kein Wechsel. Jeder weitere ist ein Wechsel mit Zeitpunkt („ab“, "JJJJ-MM-TTTHH:MM").
   * eintraege: [{ id, personId, name, ab, notiz, ausgeblendet, geaendert }] nach Zeit sortiert.
   */
  function wechselEreignisse(eintraege) {
    var liste = eintraege.slice().sort(function (a, b) { return a.ab < b.ab ? -1 : (a.ab > b.ab ? 1 : 0); });
    return liste.slice(1).map(function (v, i) {
      return {
        art: 'wechsel', verantwortungId: v.id, personId: v.personId, name: v.name,
        vorher: liste[i].name, ab: v.ab, datum: v.ab.slice(0, 10), zeit: v.ab.slice(11, 16),
        notiz: v.notiz || null, ausgeblendet: v.ausgeblendet === 'ja', geaendert: !!v.geaendert,
        nachgetragenAm: v.nachgetragenAm || null, pruefung: v.pruefung || null,
        text: v.name + ' ist ab jetzt verantwortlich' + (liste[i].name ? ' (vorher ' + liste[i].name + ')' : '') + '.'
      };
    });
  }


  /* ---------- 2.0.14: Nachtrag erkennen, Cockpit, Prüfung beim Wechsel, Tagesabschluss ---------- */

  /* Ab so vielen Minuten Abstand zu „jetzt“ gilt ein Ereignis als nachgetragen (wie in V1). */
  var NACHTRAG_MINUTEN = 5;

  /* \"JJJJ-MM-TTTHH:MM\" -> Minuten seit 1970 (ohne Zeitzonen-Probleme). NaN, wenn die Form nicht stimmt. */
  function minutenNummer(zeitpunkt) {
    var m = /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2})$/.exec(zeitpunkt || '');
    if (!m) return NaN;
    return tagNummer(m[1]) * 1440 + (+m[2]) * 60 + (+m[3]);
  }

  /*
   * Wie liegt ein eingegebener Zeitpunkt zu „jetzt“?
   *  'jetzt'     höchstens 5 Minuten Abstand (vorher oder nachher)
   *  'nachtrag'  mehr als 5 Minuten in der Vergangenheit
   *  'zukunft'   mehr als 5 Minuten in der Zukunft
   *  'unklar'    Datum oder Uhrzeit fehlt oder ist ungültig
   */
  function zeitpunktArt(datum, zeit, jetzt) {
    var a = minutenNummer((datum || '') + 'T' + (zeit || '')), b = minutenNummer(jetzt);
    if (isNaN(a) || isNaN(b)) return 'unklar';
    var d = b - a;
    if (d > NACHTRAG_MINUTEN) return 'nachtrag';
    if (d < -NACHTRAG_MINUTEN) return 'zukunft';
    return 'jetzt';
  }

  /*
   * Darf das Cockpit heute etwas eintragen? Ja, wenn die Aktivität nicht storniert ist und der
   * heutige Tag (nach Datum) im Zeitraum der Aktivität liegt. Sonst bleibt das Cockpit stumm und
   * verweist auf das Logbuch (Tag ergänzen, Nachtragen).
   * Rückgabe: { moeglich, grund }  grund: 'storniert' | 'geplant' | 'vorbei' | null
   */
  function cockpitMoeglich(aktivitaetWerte, heute) {
    if (aktivitaetWerte.status === 'storniert') return { moeglich: false, grund: 'storniert' };
    if (heute < aktivitaetWerte.vonDatum) return { moeglich: false, grund: 'geplant' };
    if (heute > aktivitaetWerte.bisDatum) return { moeglich: false, grund: 'vorbei' };
    return { moeglich: true, grund: null };
  }

  /* Welche Arten nutzen die großen Knöpfe? */
  var SCHNELL_ART = { abfahrt: 'Abfahrt', ankunft: 'Ankunft', notiz: 'Notiz' };

  /*
   * Die Prüfung der Befähigung der übernehmenden Person beim Wechsel (aus dem Ergebnis von
   * aktivitaetPruefung). Die App weist nur hin und sperrt nichts. „Nicht erlaubt“ steht nur da,
   * wo die App es sicher weiß (ein Nachweis, der vor dem Ende des Zeitraums abläuft); ein
   * Gebiet, das nicht oder nur als Text eingetragen ist, ergibt höchstens „unklar“.
   * Namen und Texte werden mitgespeichert, spätere Änderungen verändern den damaligen Stand nicht.
   */
  function wechselPruefungFestgehalten(pr, personId) {
    if (!pr) return null;
    var b = pr.befaehigung;
    var meine = b.personen.filter(function (p) { return p.person.id === personId; })[0];
    if (!meine) return null;
    var ergebnis = meine.ergebnis;
    if (b.gebietHinweis && ergebnis === 'erlaubt') ergebnis = 'unklar';
    return {
      geprueftAm: pr.geprueftAm,
      name: meine.person.name, rolleText: meine.rolleText, ergebnis: ergebnis,
      gruende: meine.gruende.map(function (g) { return { ergebnis: g.ergebnis, text: g.text }; }),
      gebietHinweis: b.gebietHinweis || null
    };
  }

  /* Ein Satz zur festgehaltenen Prüfung beim Wechsel. */
  function wechselPruefungKurz(p) {
    if (!p) return null;
    return 'Befähigung von ' + p.name + ': ' + MM.Aktivitaeten.ERGEBNIS[p.ergebnis] + ' (geprüft am ' + p.geprueftAm.slice(8, 10) + '.' + p.geprueftAm.slice(5, 7) + '.' + p.geprueftAm.slice(0, 4) + ', ' + p.geprueftAm.slice(11, 16) + ' Uhr)';
  }

  /* Tagesabschluss: tatsächliches Ziel und Notiz. Gibt es etwas davon? */
  function hatAbschluss(w) { return !!((w.zielTatsaechlich || '') || (w.abschlussNotiz || '')); }


  /* Der sichtbare Tag von heute (der erste, falls es mehrere am selben Datum gibt). abschnitte: wie in logbuchLaden. */
  function heutigerAbschnitt(abschnitte, heute) {
    return abschnitte.filter(function (x) { return !x.ausgeblendet && x.aktuell.werte.datum === heute; })[0] || null;
  }

  /* Die letzten n sichtbaren Ereignisse über alle Tage, das neueste zuerst (für das Cockpit). */
  function letzteEreignisse(abschnitte, n) {
    var alle = [];
    abschnitte.forEach(function (x) {
      if (x.ausgeblendet) return;
      x.ereignisse.forEach(function (e) { if (!e.ausgeblendet) alle.push(Object.assign({ tagId: x.objekt.id, tagDatum: x.aktuell.werte.datum }, e)); });
    });
    alle.sort(function (a, b) { return a.zeitpunkt < b.zeitpunkt ? 1 : (a.zeitpunkt > b.zeitpunkt ? -1 : 0); });
    return alle.slice(0, n);
  }

  /* Zeitpunkt eines Ereignisses zum Sortieren. */
  function ereignisZeit(werte) { return zeitSchluessel(werte.datum, werte.zeit); }

  /* Handeingetragene und automatische Ereignisse in eine Reihenfolge bringen. */
  function ereignisseSortieren(liste) {
    return liste.slice().sort(function (a, b) { return a.zeitpunkt < b.zeitpunkt ? -1 : (a.zeitpunkt > b.zeitpunkt ? 1 : 0); });
  }

  /*
   * Die Prüfung der Aktivität (Ergebnis von aktivitaetPruefung) in eine feste Form bringen,
   * die gespeichert wird. Namen und Texte werden mitgespeichert, weil spätere Änderungen an
   * Personen oder Fahrzeugen den damaligen Stand nicht verändern sollen.
   *  pr            Ergebnis von aktivitaetPruefung
   *  verantwortlich { personId, name } der Verantwortliche zum Tagesbeginn
   *  tagesbeginn   "JJJJ-MM-TTTHH:MM"
   */
  function pruefungFestgehalten(pr, verantwortlich, tagesbeginn) {
    var b = pr.befaehigung;
    var meine = verantwortlich ? b.personen.filter(function (p) { return p.person.id === verantwortlich.personId; })[0] : null;
    var fr = pr.fristen;
    return {
      geprueftAm: pr.geprueftAm,
      tagesbeginn: tagesbeginn,
      verantwortlich: verantwortlich ? { personId: verantwortlich.personId, name: verantwortlich.name, ergebnis: meine ? meine.ergebnis : null } : null,
      befaehigung: {
        ergebnis: b.ergebnis, gebiet: b.gebiet || null, gebietHinweis: b.gebietHinweis || null,
        personen: b.personen.map(function (p) {
          return { name: p.person.name, rolleText: p.rolleText, ergebnis: p.ergebnis,
            gruende: p.gruende.map(function (g) { return { ergebnis: g.ergebnis, text: g.text }; }) };
        })
      },
      ausruestung: pr.ausruestung && pr.ausruestung.liste.length ? {
        ergebnis: pr.ausruestung.ergebnis,
        liste: pr.ausruestung.liste.map(function (x) { return { bezeichnung: x.bezeichnung, status: x.status, text: x.text }; })
      } : null,
      fristen: {
        betroffen: fr.zusammenfassung.betroffen, sperre: fr.zusammenfassung.sperre, eingeschraenkt: fr.zusammenfassung.eingeschraenkt,
        liste: fr.liste.filter(function (f) { return f.status !== 'ok'; }).map(function (f) {
          return { bezeichnung: f.bezeichnung, status: f.status, wirkung: f.wirkung || null, text: f.text };
        }),
        gesamt: fr.liste.length
      }
    };
  }

  /* Ein Satz zur festgehaltenen Prüfung, zum Beispiel für die Tagesliste. */
  function pruefungKurz(p) {
    if (!p) return null;
    var e = MM.Aktivitaeten.ERGEBNIS;
    var teile = ['Befähigung: ' + e[p.befaehigung.ergebnis]];
    if (p.ausruestung) teile.push('Ausrüstung: ' + e[p.ausruestung.ergebnis]);
    teile.push(p.fristen.betroffen ? 'Fristen: ' + p.fristen.betroffen + ' betroffen' : 'Fristen: keine betroffen');
    return teile.join(', ');
  }

  MM.Logbuch = {
    VORSCHLAEGE_EREIGNISARTEN: VORSCHLAEGE_EREIGNISARTEN, WECHSEL_ART: WECHSEL_ART, MAX_TAGE: MAX_TAGE,
    tageImZeitraum: tageImZeitraum, wochentag: wochentag, fehlendeTage: fehlendeTage,
    abschnitteSortieren: abschnitteSortieren, abschnittFuer: abschnittFuer,
    wechselEreignisse: wechselEreignisse, ereignisZeit: ereignisZeit, ereignisseSortieren: ereignisseSortieren,
    pruefungFestgehalten: pruefungFestgehalten, pruefungKurz: pruefungKurz,
    NACHTRAG_MINUTEN: NACHTRAG_MINUTEN, SCHNELL_ART: SCHNELL_ART, minutenNummer: minutenNummer, zeitpunktArt: zeitpunktArt,
    cockpitMoeglich: cockpitMoeglich, wechselPruefungFestgehalten: wechselPruefungFestgehalten, wechselPruefungKurz: wechselPruefungKurz, hatAbschluss: hatAbschluss,
    heutigerAbschnitt: heutigerAbschnitt, letzteEreignisse: letzteEreignisse
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
