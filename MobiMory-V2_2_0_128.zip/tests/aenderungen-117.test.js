'use strict';
/* 2.0.117: Wechselpunkte von Hand, Änderung der Position mit Warum und Wer, Geräteverwaltung im Konto. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = t;
const testDienst = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status',
  'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'kartenereignisse', 'konto', 'texte', 'daten'].forEach(m => require('../js/' + m + '.js'));
const MM = globalThis.MM;
const lesen = p => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

const NAVSHIP = `<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<gpx version="1.1" creator="NavShip - CproSoft GmbH"><rte><name>Main Route</name>
<rtept lat="43.8625602722168" lon="8.054025650024414"><name>Point-1</name></rtept>
<rtept lat="44.33528137207031" lon="8.956028938293457"><name>Point-2</name></rtept>
<rtept lat="44.33528137207031" lon="8.956028938293457"><name>Point-3</name></rtept>
<rtept lat="42.7376708984375" lon="9.211250305175781"><name>Point-6</name></rtept>
</rte></gpx>`;
const SPUR = `<?xml version="1.0" encoding="UTF-8" ?><gpx xmlns="http://www.topografix.com/GPX/1/1" version="1.1" creator="Navionics Boating App"><trk><name>Spur</name><trkseg>
<trkpt lat="44.16" lon="8.50"><time>2026-11-03T09:00:00Z</time></trkpt><trkpt lat="44.20" lon="8.60"><time>2026-11-03T09:30:00Z</time></trkpt><trkpt lat="44.30" lon="8.90"><time>2026-11-03T10:30:00Z</time></trkpt></trkseg></trk></gpx>`;

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 3, 12, 0, 0).getTime() };
  let n = 0;
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (n++)).toISOString() });
}
async function mitFahrzeug(art) {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen(art || 'motorboot', { bezeichnung: 'Fahrzeug' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Sommertörn', artId: toern, fahrzeugId: fz, vonDatum: '2026-11-03', vonZeit: '09:00', bisDatum: '2026-11-05', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok);
  await d.heutigerTag(r.id);
  return { d, id: r.id };
}
const GPS = { breite: 43.80123, laenge: 15.95432, genauigkeit: 6.4 };

/* ---------- 3.1 Wechselpunkte von Hand ---------- */
test('Handpunkt: Prüfung von Name, Breite und Länge', () => {
  const R = MM.Routen;
  assert.deepEqual(R.handPunktPruefen({ name: ' Kap  Mele ', breite: '43,9', laenge: '8,5' }).werte, { name: 'Kap Mele', breite: 43.9, laenge: 8.5 });
  assert.ok(R.handPunktPruefen({ name: '', breite: '', laenge: '8,5' }).fehler.breite);
  assert.ok(R.handPunktPruefen({ breite: '43,9', laenge: '' }).fehler.laenge);
  assert.ok(R.handPunktPruefen({ breite: '95', laenge: '8' }).fehler.breite);
  assert.ok(R.handPunktPruefen({ name: 'x'.repeat(41), breite: '43', laenge: '8' }).fehler.name);
  assert.deepEqual(R.handPunktPruefen({ breite: '43,9 S', laenge: '8,5 W' }).werte, { name: '', breite: -43.9, laenge: -8.5 });
});

test('Wechselpunkte: Handpunkt kommt nach dem nächsten Routenpunkt, bei Gleichstand nach dem Punkt aus der Datei, wird nie zusammengelegt', () => {
  const R = MM.Routen;
  const punkte = [{ breite: 43.0, laenge: 8.0, km: 0, name: 'A' }, { breite: 44.0, laenge: 9.0, km: 100, name: 'B' }, { breite: 45.0, laenge: 9.0, km: 200, name: 'C' }];
  const hand = [{ id: 'h1', name: 'Mitte', breite: 43.5, laenge: 8.4 }, { id: 'h2', name: '', breite: 44.0, laenge: 9.0 }, { id: 'h3', name: 'Doppelt', breite: 44.0, laenge: 9.0 }];
  const w = R.wechselpunkte(punkte, 'route', {}, hand);
  assert.equal(w.moeglich, true); assert.equal(w.handErlaubt, true);
  assert.deepEqual(w.liste.map(x => x.name), ['A', 'Mitte', 'B', 'Punkt 4', 'Doppelt', 'C'], 'Handpunkt auf der Stelle von B bleibt eigen');
  assert.deepEqual(w.liste.map(x => x.hand), [false, true, false, true, true, false]);
  assert.equal(w.liste[1].kursHin, R.peilung(43, 8, 43.5, 8.4)); assert.equal(w.liste[1].kursWeiter, R.peilung(43.5, 8.4, 44, 9));
  assert.equal(w.liste[0].nr, 1); assert.equal(w.liste[5].nr, 6);
});

test('Wechselpunkte: Spur braucht mindestens zwei Handpunkte; unbekannte Art erlaubt keine', () => {
  const R = MM.Routen;
  const spur = [{ breite: 44.1, laenge: 8.5, km: 0 }, { breite: 44.3, laenge: 8.9, km: 30 }];
  const ohne = R.wechselpunkte(spur, 'spur', {}, []);
  assert.equal(ohne.moeglich, false); assert.equal(ohne.handErlaubt, true); assert.match(ohne.grund, /von Hand/);
  const eins = R.wechselpunkte(spur, 'spur', {}, [{ id: 'a', name: '', breite: 44.1, laenge: 8.5 }]);
  assert.equal(eins.moeglich, false); assert.match(eins.grund, /mindestens zwei/); assert.equal(eins.hand.length, 1);
  const zwei = R.wechselpunkte(spur, 'spur', {}, [{ id: 'a', name: 'Start', breite: 44.1, laenge: 8.5 }, { id: 'b', name: 'Ziel', breite: 44.3, laenge: 8.9 }]);
  assert.equal(zwei.moeglich, true); assert.deepEqual(zwei.liste.map(x => x.name), ['Start', 'Ziel']);
  const unbekannt = R.wechselpunkte(spur, null, {}, [{ id: 'a', name: '', breite: 44.1, laenge: 8.5 }]);
  assert.equal(unbekannt.moeglich, false); assert.equal(unbekannt.handErlaubt, false);
});

test('Handpunkte: anlegen, umbenennen, löschen; Namen der Dateipunkte bleiben dabei', async () => {
  const c = await mitFahrzeug();
  assert.ok((await c.d.routeImportieren(c.id, NAVSHIP, 'navship.gpx')).ok);
  const neu = await c.d.wechselpunktHandNeu(c.id, { name: 'Kap Mele', breite: '44,10', laenge: '8,50' });
  assert.ok(neu.ok, JSON.stringify(neu)); assert.ok(neu.id);
  let ra = await c.d.routeAnsicht(c.id);
  assert.deepEqual(ra.route.wechselpunkte.liste.map(x => x.name), ['Point-1', 'Kap Mele', 'Point-2', 'Point-6']);
  /* Dateipunkt umbenennen darf den Handpunkt nicht verlieren */
  const w2 = ra.route.wechselpunkte.liste[2];
  assert.ok((await c.d.wechselpunktBenennen(c.id, w2.index, 'Hafen')).ok);
  ra = await c.d.routeAnsicht(c.id);
  assert.deepEqual(ra.route.wechselpunkte.liste.map(x => x.name), ['Point-1', 'Kap Mele', 'Hafen', 'Point-6']);
  /* Handpunkt umbenennen: leer = Punkt <Nummer> */
  assert.ok((await c.d.wechselpunktHandBenennen(c.id, neu.id, '')).ok);
  assert.equal((await c.d.routeAnsicht(c.id)).route.wechselpunkte.liste[1].name, 'Punkt 2');
  assert.ok((await c.d.wechselpunktHandBenennen(c.id, neu.id, 'x'.repeat(41))).fehler.name);
  assert.ok((await c.d.wechselpunktHandBenennen(c.id, 'gibtsnicht', 'x')).fehler.allgemein);
  /* Karte zeigt ihn auch */
  const kd = await c.d.kartenDaten(c.id, 0);
  assert.equal(kd.route.wechselpunkte.length, 4);
  /* löschen */
  assert.ok((await c.d.wechselpunktHandLoeschen(c.id, neu.id)).ok);
  ra = await c.d.routeAnsicht(c.id);
  assert.deepEqual(ra.route.wechselpunkte.liste.map(x => x.name), ['Point-1', 'Hafen', 'Point-6']);
  assert.ok((await c.d.wechselpunktHandLoeschen(c.id, neu.id)).fehler.allgemein);
  /* Fehler beim Eintragen: nichts wird gespeichert */
  const schlecht = await c.d.wechselpunktHandNeu(c.id, { breite: 'abc', laenge: '' });
  assert.equal(schlecht.ok, false); assert.ok(schlecht.fehler.breite); assert.ok(schlecht.fehler.laenge);
  assert.equal((await c.d.routeAnsicht(c.id)).route.wechselpunkte.hand.length, 0);
});

test('Handpunkte bei einer Spur: zwei Punkte machen die Wechselpunkte möglich; an Land nicht', async () => {
  const c = await mitFahrzeug();
  assert.ok((await c.d.routeImportieren(c.id, SPUR, 'archiv.gpx')).ok);
  assert.equal((await c.d.routeAnsicht(c.id)).route.wechselpunkte.moeglich, false);
  assert.ok((await c.d.wechselpunktHandNeu(c.id, { name: 'Start', breite: '44,16', laenge: '8,50' })).ok);
  assert.equal((await c.d.routeAnsicht(c.id)).route.wechselpunkte.moeglich, false);
  assert.ok((await c.d.wechselpunktHandNeu(c.id, { name: 'Ziel', breite: '44,30', laenge: '8,90' })).ok);
  const ra = await c.d.routeAnsicht(c.id);
  assert.equal(ra.route.wechselpunkte.moeglich, true); assert.deepEqual(ra.route.wechselpunkte.liste.map(x => x.name), ['Start', 'Ziel']);
  assert.equal(ra.route.wechselpunkte.liste[1].kursHin, MM.Routen.peilung(44.16, 8.5, 44.3, 8.9));
  const land = await mitFahrzeug('wohnmobil');
  assert.ok((await land.d.routeImportieren(land.id, NAVSHIP, 'navship.gpx')).ok);
  assert.ok((await land.d.wechselpunktHandNeu(land.id, { breite: '44', laenge: '8' })).fehler.allgemein);
});

test('Handpunkte: höchstens 50', async () => {
  const c = await mitFahrzeug();
  assert.ok((await c.d.routeImportieren(c.id, NAVSHIP, 'navship.gpx')).ok);
  for (let i = 0; i < 50; i++) assert.ok((await c.d.wechselpunktHandNeu(c.id, { breite: '44,1', laenge: '8,' + (10 + i) })).ok);
  assert.match((await c.d.wechselpunktHandNeu(c.id, { breite: '44,1', laenge: '8,99' })).fehler.allgemein, /höchstens 50/);
});

/* ---------- 3.2 Position ändern: Warum und Wer ---------- */
async function kurswechselId(c) {
  assert.ok((await c.d.kurswechsel(c.id, { grund: 'Wetter', position: GPS, kurs: 90, geschwindigkeit: 3 })).ok);
  return (await c.d.logbuchLaden(c.id)).abschnitte[0].ereignisse.filter(x => x.artName === 'Kurswechsel')[0].id;
}
test('Position eines Kurswechsels ändern: Warum ist Pflicht, der Verlauf hält Wer, Wann, Warum, alt und neu fest', async () => {
  const c = await mitFahrzeug();
  const id = await kurswechselId(c);
  const w = (await c.d.ereignisLaden(id)).aktuell.werte;
  const basis = { artId: w.artId, datum: w.datum, zeit: w.zeit, text: w.text, breite: '43,81000', laenge: '15,96000', ausgeblendet: 'nein' };
  const ohne = await c.d.ereignisAendern(id, basis);
  assert.equal(ohne.ok, false); assert.match(ohne.fehler.positionWarum, /warum/i);
  assert.equal((await c.d.ereignisAendern(id, Object.assign({}, basis, { positionWarum: '   ' }))).ok, false);
  assert.ok((await c.d.ereignisAendern(id, Object.assign({}, basis, { positionWarum: 'x'.repeat(301) }))).fehler.positionWarum);
  const x0 = await c.d.ereignisLaden(id);
  assert.equal(x0.verlauf.length, 1, 'bis hierher wurde nichts gespeichert');
  const ok = await c.d.ereignisAendern(id, Object.assign({}, basis, { positionWarum: ' GPS war am Steg ungenau ' }));
  assert.ok(ok.ok); assert.equal(ok.geaendert, true);
  const x = await c.d.ereignisLaden(id);
  assert.equal(x.verlauf.length, 2);
  const pa = x.verlauf[0].eintrag.positionAenderung;
  assert.equal(pa.warum, 'GPS war am Steg ungenau'); assert.equal(pa.wer, 'Anna'); assert.ok(pa.werPersonId); assert.match(pa.am, /^2026-11-03T/);
  assert.deepEqual(pa.alt, { breite: 43.80123, laenge: 15.95432, quelle: 'gps' });
  assert.deepEqual(pa.neu, { breite: 43.81, laenge: 15.96, quelle: 'hand' });
  assert.equal(x.verlauf[1].eintrag.positionAenderung, undefined, 'der erste Eintrag hat keine Änderung der Position');
  const satz = MM.Logbuch.positionAenderungText(pa, am => am.slice(0, 10));
  assert.match(satz, /von Anna/); assert.match(satz, /Grund: GPS war am Steg ungenau/); assert.match(satz, /43,80123° N/); assert.match(satz, /43,81000° N/);
});

test('Nur die Position verlangt einen Grund: Text ändern geht ohne, gleiche Zahlen auch', async () => {
  const c = await mitFahrzeug();
  const id = await kurswechselId(c);
  const w = (await c.d.ereignisLaden(id)).aktuell.werte;
  const basis = { artId: w.artId, datum: w.datum, zeit: w.zeit, text: 'neuer Text', breite: '43,80123', laenge: '15,95432', gpsBreite: 43.80123, gpsLaenge: 15.95432, ausgeblendet: 'nein' };
  const r = await c.d.ereignisAendern(id, basis);
  assert.ok(r.ok, JSON.stringify(r)); assert.equal(r.geaendert, true);
  const x = await c.d.ereignisLaden(id);
  assert.equal(x.verlauf[0].eintrag.positionAenderung, undefined);
  assert.equal(x.aktuell.werte.positionQuelle, 'gps');
});

test('Position entfernen verlangt ebenfalls einen Grund und steht im Verlauf als „keine Position“', async () => {
  const c = await mitFahrzeug();
  const id = await kurswechselId(c);
  const w = (await c.d.ereignisLaden(id)).aktuell.werte;
  const basis = { artId: w.artId, datum: w.datum, zeit: w.zeit, text: w.text, breite: '', laenge: '', ausgeblendet: 'nein' };
  assert.ok((await c.d.ereignisAendern(id, basis)).fehler.positionWarum);
  assert.ok((await c.d.ereignisAendern(id, Object.assign({}, basis, { positionWarum: 'Position war falsch' }))).ok);
  const pa = (await c.d.ereignisLaden(id)).verlauf[0].eintrag.positionAenderung;
  assert.equal(pa.neu.breite, null);
  assert.match(MM.Logbuch.positionAenderungText(pa, am => am), /→ keine Position\./);
});

test('Reisebuch: die Änderung der Position steht mit Wer, Wann und Warum bei der Herkunft', async () => {
  const c = await mitFahrzeug();
  const id = await kurswechselId(c);
  const w = (await c.d.ereignisLaden(id)).aktuell.werte;
  assert.ok((await c.d.ereignisAendern(id, { artId: w.artId, datum: w.datum, zeit: w.zeit, text: w.text, breite: '43,81', laenge: '15,96', ausgeblendet: 'nein', positionWarum: 'Tippfehler' })).ok);
  const lb = await c.d.logbuchLaden(c.id);
  const e = lb.abschnitte[0].ereignisse.filter(x => x.id === id)[0];
  assert.equal(e.positionAenderungen.length, 1); assert.equal(e.positionAenderungen[0].warum, 'Tippfehler');
  const src = lesen('js/reisebuch.js');
  assert.match(src, /positionAenderungen/); assert.match(src, /positionAenderungText/);
  assert.match(lesen('js/daten.js'), /positionAenderungen: e\.positionAenderungen \|\| \[\]/);
});

/* ---------- 3.3 Geräteverwaltung ---------- */
const APP = 'https://app.example.org';
const TAG = 24 * 60 * 60 * 1000;
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung() { return { DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }; }
function uhr() { const u = { t: Date.UTC(2026, 10, 19, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
async function ruf(env, u, methode, weg, body, token) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
  return { status: r.status, json: await r.json() };
}
async function anmelden(env, u, email, geraet, extra) {
  u.t += 13 * 60 * 1000;
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email });
  return ruf(env, u, 'POST', '/konto/code-pruefen', Object.assign({ email, code: a.json.entwicklungsCode, geraet }, extra || {}));
}

testDienst('Geräteliste: eigene Sitzungen mit Name und Zeit, das eigene Gerät ist markiert, fremde Konten bleiben außen vor', async () => {
  const env = umgebung(), u = uhr();
  const a1 = await anmelden(env, u, 'a@example.org', 'MobiMory 2.0.117 #aaaaaaa1'), a2 = await anmelden(env, u, 'a@example.org', 'MobiMory 2.0.117 #aaaaaaa2');
  const b1 = await anmelden(env, u, 'b@example.org', 'MobiMory 2.0.117 #bbbbbbb1');
  assert.equal((await ruf(env, u, 'GET', '/konto/geraete')).status, 401);
  const l = await ruf(env, u, 'GET', '/konto/geraete', undefined, a2.json.token);
  assert.equal(l.status, 200); assert.equal(l.json.geraete.length, 2);
  assert.deepEqual(l.json.geraete.map(g => g.name), ['MobiMory 2.0.117 #aaaaaaa1', 'MobiMory 2.0.117 #aaaaaaa2']);
  assert.deepEqual(l.json.geraete.map(g => g.eigenes), [false, true]);
  assert.match(l.json.geraete[0].kennung, /^[a-f0-9]{16}$/); assert.ok(l.json.geraete[0].laeuftAb > l.json.geraete[0].erstelltAm);
  assert.ok(!JSON.stringify(l.json).includes(a1.json.token), 'der Schlüssel selbst kommt nie zurück');
  /* ein fremdes Gerät abmelden */
  const fremd = l.json.geraete[0].kennung;
  assert.equal((await ruf(env, u, 'POST', '/konto/geraet-abmelden', { kennung: fremd }, b1.json.token)).status, 404, 'ein anderes Konto kann es nicht beenden');
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, a1.json.token)).status, 200);
  assert.equal((await ruf(env, u, 'POST', '/konto/geraet-abmelden', { kennung: fremd }, a2.json.token)).status, 200);
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, a1.json.token)).status, 401);
  assert.equal((await ruf(env, u, 'POST', '/konto/geraet-abmelden', { kennung: fremd }, a2.json.token)).status, 404, 'zweites Mal: nicht mehr angemeldet');
  /* das eigene Gerät und Unsinn */
  const eigene = (await ruf(env, u, 'GET', '/konto/geraete', undefined, a2.json.token)).json.geraete[0].kennung;
  const e = await ruf(env, u, 'POST', '/konto/geraet-abmelden', { kennung: eigene }, a2.json.token);
  assert.equal(e.status, 400); assert.match(e.json.error, /Abmelden/);
  assert.equal((await ruf(env, u, 'POST', '/konto/geraet-abmelden', { kennung: 'x' }, a2.json.token)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/konto/geraet-abmelden', {}, a2.json.token)).status, 400);
});

testDienst('Geräte-Grenze: die Meldung nennt das älteste Gerät, der Code bleibt gültig, mit „ältestes abmelden“ klappt es beim zweiten Mal', async () => {
  const env = umgebung(), u = uhr();
  const mail = 'voll@example.org';
  const toks = [];
  for (let i = 0; i < 4; i++) toks.push((await anmelden(env, u, mail, 'MobiMory 2.0.117 #2000000' + i)).json.token);
  /* fünftes Gerät: mit Code, ohne Wunsch */
  u.t += 13 * 60 * 1000;
  const code = (await ruf(env, u, 'POST', '/konto/code-anfordern', { email: mail })).json.entwicklungsCode;
  const voll = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: mail, code, geraet: 'MobiMory 2.0.117 #20000009' });
  assert.equal(voll.status, 403); assert.equal(voll.json.geraeteVoll, true); assert.equal(voll.json.geraeteGrenze, 4);
  assert.equal(voll.json.aeltestes.name, 'MobiMory 2.0.117 #20000000'); assert.ok(voll.json.aeltestes.erstelltAm);
  /* derselbe Code gilt noch, mit dem Wunsch geht es */
  const ja = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: mail, code, geraet: 'MobiMory 2.0.117 #20000009', aeltestesAbmelden: true });
  assert.equal(ja.status, 200, JSON.stringify(ja.json));
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, toks[0])).status, 401, 'das älteste Gerät ist abgemeldet');
  for (const k of [1, 2, 3]) assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, toks[k])).status, 200);
  const l = await ruf(env, u, 'GET', '/konto/geraete', undefined, ja.json.token);
  assert.equal(l.json.geraete.length, 4);
  /* dasselbe Gerät noch einmal anmelden braucht keinen Platz und kein Abmelden */
  const nochmal = await anmelden(env, u, mail, 'MobiMory 2.0.118 #20000009');
  assert.equal(nochmal.status, 200, JSON.stringify(nochmal.json));
  assert.equal((await ruf(env, u, 'GET', '/konto/geraete', undefined, nochmal.json.token)).json.geraete.length, 4);
  /* der Wunsch ohne volle Grenze meldet niemanden ab */
  const env2 = umgebung(), u2 = uhr();
  const t1 = await anmelden(env2, u2, 'leer@example.org', 'MobiMory 2.0.117 #30000001');
  const t2 = await anmelden(env2, u2, 'leer@example.org', 'MobiMory 2.0.117 #30000002', { aeltestesAbmelden: true });
  assert.equal(t2.status, 200); assert.equal((await ruf(env2, u2, 'GET', '/konto/ich', undefined, t1.json.token)).status, 200);
});

testDienst('Geräte-Grenze: nicht mehr angemeldete (abgelaufene) Sitzungen zählen nicht und werden nicht angezeigt', async () => {
  const env = umgebung(), u = uhr();
  for (let i = 0; i < 4; i++) await anmelden(env, u, 'alt@example.org', 'MobiMory 2.0.117 #4000000' + i);
  u.t += 100 * TAG;
  const neu = await anmelden(env, u, 'alt@example.org', 'MobiMory 2.0.117 #40000009');
  assert.equal(neu.status, 200);
  assert.equal((await ruf(env, u, 'GET', '/konto/geraete', undefined, neu.json.token)).json.geraete.length, 1);
});

/* ---------- App-Seite der Geräteverwaltung ---------- */
test('App: Geräteliste und Abmelden gehen über den Dienst; ein älterer Dienst ohne die Wege wird in einfachen Worten erklärt', async () => {
  const aufrufe = [];
  let antwort;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { kontoAnfrage: async (url, methode, token, body) => {
    aufrufe.push([methode, url.replace(/^https?:\/\/[^/]+/, ''), token, body]);
    return antwort(url);
  } });
  await d.starten();
  await d.rcSchreiben({ kontoToken: 'tok-123', kontoEmail: 'a@example.org' });
  antwort = () => ({ ok: true, geraete: [{ kennung: 'abcdef0123456789', name: 'MobiMory 2.0.117 #12345678', erstelltAm: 1, laeuftAb: 2, eigenes: true }, { kennung: '0123456789abcdef', name: 'Tablet', erstelltAm: 3, laeuftAb: 4 }] });
  const l = await d.kontoGeraete();
  assert.ok(l.ok); assert.deepEqual(l.geraete.map(g => g.eigenes), [true, false]); assert.equal(aufrufe[0][0], 'GET'); assert.match(aufrufe[0][1], /^\/konto\/geraete/); assert.equal(aufrufe[0][2], 'tok-123');
  antwort = () => ({ ok: true });
  assert.ok((await d.kontoGeraetAbmelden('0123456789abcdef')).ok);
  assert.deepEqual(aufrufe[1].slice(0, 1).concat(aufrufe[1][3]), ['POST', { kennung: '0123456789abcdef' }]);
  antwort = () => { const e = new Error('Diese Adresse gibt es beim Dienst nicht.'); e.status = 404; throw e; };
  const alt = await d.kontoGeraete();
  assert.equal(alt.ok, false); assert.match(alt.fehler, /kennt die Geräteliste noch nicht/);
  /* Anmelden mit dem Wunsch „ältestes abmelden“ reicht ihn an den Dienst weiter, ohne Wunsch geht er nicht mit */
  aufrufe.length = 0;
  antwort = () => { const e = new Error('Mit der Stufe Basic sind höchstens 2 Geräte erlaubt.'); e.status = 403; e.geraeteVoll = true; e.aeltestes = { name: 'Altes', erstelltAm: 5 }; throw e; };
  const voll = await d.kontoCodePruefen({ email: 'a@example.org', code: '123456' });
  assert.equal(voll.ok, false); assert.equal(voll.geraeteVoll, true); assert.equal(voll.aeltestes.name, 'Altes');
  assert.equal(aufrufe[0][3].aeltestesAbmelden, undefined);
  await d.kontoCodePruefen({ email: 'a@example.org', code: '123456', aeltestesAbmelden: true });
  assert.equal(aufrufe[1][3].aeltestesAbmelden, true);
});

test('Einbau: Texte, Oberfläche, Version 2.0.117', () => {
  assert.equal(MM.VERSION, '2.0.128');
  assert.equal(MM.Texte.NEUERUNGEN[11].version, '2.0.117'); assert.equal(MM.Texte.NEUERUNGEN[12].version, '2.0.116');
  const n = MM.Texte.NEUERUNGEN[11].punkte.join(' ');
  assert.match(n, /Wechselpunkte von Hand/); assert.match(n, /warum/); assert.match(n, /Geräte im Konto/);
  const a = lesen('js/ansicht.js');
  assert.match(a, /function geraeteKasten\(/); assert.match(a, /geraeteKasten\(\),/); assert.match(a, /Deine angemeldeten Geräte/);
  assert.match(a, /Ältestes Gerät abmelden und hier anmelden/); assert.match(a, /Wechselpunkt von Hand hinzufügen/); assert.match(a, /Aktuelle Position nehmen/);
  assert.match(a, /Warum wird die Position geändert\?/); assert.match(a, /function positionAenderungBlock\(/); assert.match(a, /Änderungen der Position/);
  const s = lesen('server/konto-dienst.mjs');
  assert.match(s, /'GET \/konto\/geraete': geraeteListe/); assert.match(s, /'POST \/konto\/geraet-abmelden': geraetAbmelden/);
  assert.ok(lesen('server/EINRICHTUNG.md').includes('## Update 2.0.117: Geräteverwaltung'));
  assert.ok(lesen('CHANGELOG.md').includes('## 2.0.117'));
  assert.ok(fs.existsSync(path.join(__dirname, '..', 'docs', 'Homepage-Text_2.0.115-2.0.117.md')));
  assert.ok(!/peilung/i.test(a + lesen('js/daten.js') + lesen('js/texte.js') + lesen('js/logbuch.js')), 'das Wort Peilung bleibt aus Ansicht, Daten, Texten und Logbuch draußen');
});
