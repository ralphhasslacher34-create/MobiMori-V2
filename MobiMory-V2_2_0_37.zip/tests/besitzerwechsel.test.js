'use strict';
/* 2.0.37: Fahrzeugart ändern, Fahrzeug abgeben, Übergabedatei, Fahrzeug übernehmen, Technik-Akte. */
const test = require('node:test');
const assert = require('node:assert/strict');

['version', 'texte', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren',
  'personen', 'orte', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'austausch', 'pdf', 'daten']
  .forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;

/* feste Uhr: 4. November 2026, 12:00 Ortszeit, von Hand stellbar */
function neuesGeraet() {
  const uhr = { ms: new Date(2026, 10, 4, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (jahr, monat, tag, std, min) => { uhr.ms = new Date(jahr, monat - 1, tag, std || 12, min || 0, 0).getTime(); };
  return d;
}
async function neu() {
  const d = neuesGeraet();
  await d.starten();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Seestern', marke: 'Bavaria', tiefgang: '1,2' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil', kennzeichen: 'LB-XY 123' })).id;
  return { d, boot, wm };
}
const datei = (inhalt, name, typ) => { const b = new Blob([inhalt], { type: typ || 'application/pdf' }); Object.defineProperty(b, 'name', { value: name || 'a.pdf' }); return b; };
const fehlerVon = r => r.fehler || {};

/* ================= Fahrzeugart ändern ================= */
test('Fahrzeugart ändern: neuer Eintrag mit Art, Wechsel im Verlauf, Angaben der alten Art bleiben', async () => {
  const { d, boot } = await neu();
  const roh = Object.assign({}, (await d.fahrzeugLaden(boot)).aktuell.werte);
  const r = await d.fahrzeugAendern(boot, roh, 'wohnmobil');
  assert.ok(r.ok); assert.equal(r.geaendert, true); assert.equal(r.artGeaendert, true);
  const f = await d.fahrzeugLaden(boot);
  assert.equal(f.fahrzeug.art, 'wohnmobil');
  assert.equal(f.aktuell.art, 'wohnmobil'); assert.equal(f.aktuell.artVorher, 'boot'); assert.equal(f.aktuell.nr, 2);
  assert.deepEqual(f.fahrzeug.artWechsel.map(x => [x.von, x.nach, x.eintragNr]), [['boot', 'wohnmobil', 2]]);
  assert.equal(f.aktuell.werte.tiefgang, 1.2, 'Tiefgang bleibt gespeichert, auch wenn es ihn beim Wohnmobil nicht gibt');
  assert.equal(f.aktuell.werte.marke, 'Bavaria', 'gemeinsame Angaben bleiben sichtbar');
  const wechsel = f.verlauf[0].aenderungen.find(u => u.key === 'art');
  assert.deepEqual([wechsel.label, wechsel.alt, wechsel.neu], ['Fahrzeugart', 'Boot', 'Wohnmobil']);
  assert.deepEqual(f.verlauf[1].aenderungen, [], 'der erste Eintrag ist unverändert');
  assert.equal((await d.speicher.wo('eintraege', 'fahrzeugId', boot)).length, 2, 'der alte Eintrag bleibt erhalten');
});

test('Fahrzeugart ändern und zurück: die ausgeblendeten Angaben sind wieder da', async () => {
  const { d, boot } = await neu();
  await d.fahrzeugAendern(boot, (await d.fahrzeugLaden(boot)).aktuell.werte, 'wohnmobil');
  /* Das Formular schickt die Werte mit, die es kennt: hier ändert der Nutzer nebenbei das Kennzeichen */
  const mitte = Object.assign({}, (await d.fahrzeugLaden(boot)).aktuell.werte, { kennzeichen: 'LB-AB 1' });
  await d.fahrzeugAendern(boot, mitte);
  const zurueck = await d.fahrzeugAendern(boot, (await d.fahrzeugLaden(boot)).aktuell.werte, 'boot');
  assert.ok(zurueck.ok && zurueck.artGeaendert);
  const f = await d.fahrzeugLaden(boot);
  assert.equal(f.fahrzeug.art, 'boot'); assert.equal(f.aktuell.werte.tiefgang, 1.2);
  assert.equal(f.fahrzeug.artWechsel.length, 2);
  /* Verlauf: jeder Eintrag wird mit der Art seiner Zeit verglichen */
  assert.equal(f.verlauf.length, 4);
  assert.ok(f.verlauf[0].aenderungen.some(u => u.key === 'art' && u.alt === 'Wohnmobil' && u.neu === 'Boot'));
  assert.ok(f.verlauf[1].aenderungen.some(u => u.key === 'kennzeichen'), 'Änderung zwischen den Wechseln');
});

test('Fahrzeugart ändern: gleiche Art ohne Änderung ist keine Änderung, falsche Art wird abgelehnt', async () => {
  const { d, boot } = await neu();
  const werte = (await d.fahrzeugLaden(boot)).aktuell.werte;
  assert.equal((await d.fahrzeugAendern(boot, werte)).geaendert, false);
  assert.equal((await d.fahrzeugAendern(boot, werte, 'boot')).geaendert, false);
  assert.ok(fehlerVon(await d.fahrzeugAendern(boot, werte, 'wasser')).art, 'eine Gruppe ist keine Fahrzeugart');
  assert.ok(fehlerVon(await d.fahrzeugAendern(boot, werte, 'gibt-es-nicht')).art);
  assert.equal((await d.fahrzeugLaden(boot)).fahrzeug.art, 'boot');
  assert.equal((await d.speicher.wo('eintraege', 'fahrzeugId', boot)).length, 1);
});

test('Fahrzeugart ändern: die neue Art gilt überall, zum Beispiel in der Fahrzeugliste und beim Status', async () => {
  const { d, boot } = await neu();
  await d.fahrzeugAendern(boot, (await d.fahrzeugLaden(boot)).aktuell.werte, 'wohnmobil');
  const liste = await d.fahrzeugListe();
  assert.equal(liste.find(x => x.fahrzeug.id === boot).fahrzeug.art, 'wohnmobil');
  assert.equal((await d.fahrzeugStatus(boot)).welt, 'land');
  assert.ok((await d.fahrzeugartenBenutzt()).includes('wohnmobil'));
});

test('Warnung vor dem Wechsel: entfallende Angaben, Land/Wasser, nichts wird verändert', async () => {
  const { d, boot } = await neu();
  const v = await d.artWechselVorschau(boot, 'wohnmobil');
  assert.ok(v.ok); assert.equal(v.weltWechsel, true);
  assert.deepEqual([v.alt.name, v.neu.name], ['Boot', 'Wohnmobil']);
  assert.ok(v.entfallen.some(x => x.label === 'Tiefgang' && /1,2/.test(x.wert)));
  assert.ok(v.neuFelder.length > 0);
  const innerhalb = await d.artWechselVorschau(boot, 'sportboot');
  assert.equal(innerhalb.weltWechsel, false);
  assert.deepEqual(innerhalb.entfallen, []);
  assert.ok(fehlerVon(await d.artWechselVorschau(boot, 'wasser')).art);
  assert.equal((await d.fahrzeugLaden(boot)).fahrzeug.art, 'boot', 'die Vorschau ändert nichts');
});

async function mitLogbuch() {
  const c = await neu();
  const { d, boot } = c;
  await d.aktivitaetsartenAusVorschlaegen();
  await d.ereignisartenVorauswahlUebernehmen();
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const a = await d.aktivitaetAnlegen({ bezeichnung: 'Sommertörn', artId: toern, fahrzeugId: boot, vonDatum: '2026-11-03', vonZeit: '09:00', bisDatum: '2026-11-05', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(a.ok);
  const t = await d.heutigerTag(a.id);
  const anker = (await d.ereignisartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Anker werfen').objekt.id;
  const e = await d.ereignisAnlegen(t.abschnittId, { artId: anker, datum: '2026-11-04', zeit: '10:00', text: 'vor Anker' }, { nachtragen: true });
  assert.ok(e.ok);
  c.aktivitaet = a.id; c.anna = anna;
  return c;
}

test('Ereignisse, die nicht mehr zur Fahrzeugart passen, bleiben erhalten und sind markiert; beim Zurückwechseln nicht mehr', async () => {
  const { d, boot, aktivitaet } = await mitLogbuch();
  const ereignisse = async () => (await d.logbuchLaden(aktivitaet)).abschnitte.flatMap(t => t.ereignisse);
  assert.equal((await ereignisse())[0].fremdeArt, false);
  const v = await d.artWechselVorschau(boot, 'wohnmobil');
  assert.equal(v.ereignisse, 1, 'die Warnung nennt das betroffene Ereignis');
  assert.equal((await d.artWechselVorschau(boot, 'sportboot')).ereignisse, 0);
  await d.fahrzeugAendern(boot, (await d.fahrzeugLaden(boot)).aktuell.werte, 'wohnmobil');
  const nachher = await ereignisse();
  assert.equal(nachher.length, 1, 'nichts verschwindet');
  assert.equal(nachher[0].fremdeArt, true); assert.equal(nachher[0].artName, 'Anker werfen');
  await d.fahrzeugAendern(boot, (await d.fahrzeugLaden(boot)).aktuell.werte, 'boot');
  assert.equal((await ereignisse())[0].fremdeArt, false);
});

/* ================= Fahrzeug abgeben ================= */
test('Abgeben: Pflichtangaben werden geprüft', async () => {
  const { d, wm } = await neu();
  assert.ok(fehlerVon(await d.fahrzeugAbgeben(wm, { grund: 'verkauft' })).datum);
  assert.ok(fehlerVon(await d.fahrzeugAbgeben(wm, { datum: '2026-11-05', grund: 'verkauft' })).datum, 'nicht in der Zukunft');
  assert.ok(fehlerVon(await d.fahrzeugAbgeben(wm, { datum: '2026-02-30', grund: 'verkauft' })).datum, 'kein echtes Datum');
  assert.ok(fehlerVon(await d.fahrzeugAbgeben(wm, { datum: '2026-11-01' })).grund);
  assert.ok(fehlerVon(await d.fahrzeugAbgeben(wm, { datum: '2026-11-01', grund: 'geklaut' })).grund);
  assert.ok(fehlerVon(await d.fahrzeugAbgeben(wm, { datum: '2026-11-01', grund: 'verkauft', notiz: 'x'.repeat(501) })).notiz);
  assert.ok(fehlerVon(await d.fahrzeugAbgeben('gibt-es-nicht', { datum: '2026-11-01', grund: 'verkauft' })).allgemein);
  assert.equal((await d.speicher.holen('fahrzeuge', wm)).abgabe, undefined, 'nichts gespeichert');
});

test('Abgeben: weg aus allen Auswahllisten, aber lesbar, nichts gelöscht, wieder aktiv setzbar', async () => {
  const c = await mitLogbuch();
  const { d, boot, wm } = c;
  const r = await d.fahrzeugAbgeben(boot, { datum: '2026-11-01', grund: 'verkauft', notiz: 'an Herrn Meier' });
  assert.ok(r.ok);
  assert.deepEqual((await d.fahrzeugListe()).map(x => x.fahrzeug.id), [wm]);
  assert.equal((await d.fahrzeugListe({ alle: true })).length, 2);
  const abg = await d.fahrzeugeAbgegeben();
  assert.deepEqual(abg.map(x => x.fahrzeug.id), [boot]);
  assert.equal(abg[0].fahrzeug.abgabe.grund, 'verkauft'); assert.equal(abg[0].fahrzeug.abgabe.notiz, 'an Herrn Meier');
  assert.deepEqual((await d.aktivitaetKontext()).fahrzeuge.map(x => x.fahrzeug.id), [wm], 'nicht mehr zum Planen wählbar');
  assert.ok((await d.fahrzeugLaden(boot)), 'bleibt lesbar');
  const akt = (await d.aktivitaetenListe())[0];
  assert.equal(akt.fahrzeugName, 'Seestern', 'die Aktivität kennt ihr Fahrzeug weiterhin');
  assert.ok((await d.logbuchLaden(c.aktivitaet)), 'das Logbuch bleibt');
  assert.ok((await d.fahrzeugStatus(boot)).ok, 'der Status des abgegebenen Fahrzeugs lässt sich noch lesen');
  assert.ok(fehlerVon(await d.fahrzeugAendern(boot, { bezeichnung: 'Neu' })).allgemein, 'abgegeben: keine Änderung mehr');
  assert.ok(fehlerVon(await d.fahrzeugAbgeben(boot, { datum: '2026-11-01', grund: 'verkauft' })).allgemein, 'nicht zweimal');
  assert.deepEqual((await d.fristenUebersicht()), { [wm]: { ueberfaellig: 0, bald: 0, unbekannt: 0 } });
  assert.ok((await d.fahrzeugartenBenutzt()).includes('boot'), 'die Art bleibt „benutzt“');

  const w = await d.fahrzeugWiederAktiv(boot);
  assert.ok(w.ok && w.geaendert);
  assert.equal((await d.fahrzeugListe()).length, 2);
  const fz = await d.speicher.holen('fahrzeuge', boot);
  assert.equal(fz.abgabe, undefined); assert.equal(fz.abgabeVerlauf.length, 1); assert.equal(fz.abgabeVerlauf[0].datum, '2026-11-01');
  assert.equal((await d.fahrzeugWiederAktiv(boot)).geaendert, false);
});

test('Abgeben: die Kosten des abgegebenen Fahrzeugs bleiben in deiner Übersicht', async () => {
  const { d, boot, wm } = await neu();
  await d.fahrzeugAbgeben(boot, { datum: '2026-11-01', grund: 'verschenkt' });
  const u = await d.kostenUebersicht(2026);
  assert.deepEqual(u.map(x => x.fahrzeug.id).sort(), [boot, wm].sort());
});

/* ================= Übergabedatei ================= */
async function vollesFahrzeug() {
  const c = await mitLogbuch();
  const { d, boot } = c;
  const motor = (await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor', hersteller: 'Volvo Penta', modell: 'D3' })).id;
  const pumpe = (await d.komponenteAnlegen(boot, motor, null, { bezeichnung: 'Wasserpumpe' })).id;
  const z = (await d.zaehlerAnlegen(boot, motor, 'stunden', { bezeichnung: 'Betriebsstunden' })).id;
  assert.ok((await d.zaehlerStandEintragen(z, { wert: '1000', datum: '2026-06-01' })).ok);
  assert.ok((await d.zaehlerStandEintragen(z, { wert: '1250', datum: '2026-10-01' })).ok);
  const hu = (await d.fristAnlegen(boot, null, { bezeichnung: 'HU', kategorie: 'pruefung', kalenderWert: '24', kalenderEinheit: 'monate', vorwarnTage: '30', zuletztAm: '2026-05-10' })).id;
  const oel = (await d.fristAnlegen(boot, motor, { bezeichnung: 'Ölwechsel', kategorie: 'wartung', kalenderWert: '12', kalenderEinheit: 'monate', vorwarnTage: '30', zuletztAm: '2026-01-15' })).id;
  const adr = (await d.adresseAnlegen({ bezeichnung: 'Marine Service Nord', art: 'werkstatt', telefon: '040 123', ansprechpartner: 'Herr Kuhn', plz: '23570', ort: 'Travemünde', notiz: 'privat: mein Cousin' })).id;
  const alt = (await d.vorgangAnlegen(boot, null, 'stoerung', { bezeichnung: 'Lenzpumpe defekt', auswirkung: 'keine', gemeldetAm: '2026-02-01' })).id;
  await d.vorgangErledigen(alt, { datum: '2026-02-10', notiz: 'Pumpe getauscht' });
  const neuer = (await d.vorgangAnlegen(boot, motor, 'arbeit', { bezeichnung: 'Impeller wechseln', ausfuehrung: 'werkstatt', adresseId: adr, gemeldetAm: '2026-08-01' })).id;
  await d.vorgangErledigen(neuer, { datum: '2026-08-20', notiz: 'erledigt' });
  const offen = (await d.vorgangAnlegen(boot, null, 'stoerung', { bezeichnung: 'Kühlschrank kühlt schlecht', auswirkung: 'keine', gemeldetAm: '2025-07-01' })).id;
  const link = await d.dokumentAnlegen(boot, motor, { quelle: 'link', link: 'https://www.beispiel.de/d3.pdf', art: 'bedienung', bezeichnung: 'Anleitung Motor' });
  const datei1 = await d.dokumentAnlegen(boot, motor, { quelle: 'datei', datei: datei('HANDBUCH-INHALT', 'handbuch.pdf'), art: 'bedienung', bezeichnung: 'Handbuch D3' });
  assert.ok(link.ok && datei1.ok);
  Object.assign(c, { motor, pumpe, z, hu, oel, adr, alt, neuer, offen, dateiDok: datei1.id });
  return c;
}

test('Übergabedatei: gibt es nur für abgegebene Fahrzeuge', async () => {
  const { d, boot } = await vollesFahrzeug();
  assert.ok(fehlerVon(await d.uebergabeErzeugen(boot)).allgemein);
  assert.ok(fehlerVon(await d.akteErzeugen(boot)).allgemein);
});

test('Übergabedatei: enthält die technische Historie und nichts Privates', async () => {
  const c = await vollesFahrzeug();
  const { d, boot } = c;
  await d.fahrzeugAbgeben(boot, { datum: '2026-11-01', grund: 'verkauft', notiz: 'an Herrn Meier' });
  const r = await d.uebergabeErzeugen(boot);
  assert.ok(r.ok); assert.match(r.name, /^MobiMory-Uebergabe_Seestern_2026-11-01\.mmuebergabe$/);
  assert.deepEqual(r.zahlen, { komponenten: 2, zaehler: 1, fristen: 2, vorgaenge: 3, dokumente: 2 });
  assert.equal(r.dateien, 1);
  const g = await d.uebergabeLesen(r.bytes);
  const t = g.kopf.tabellen;
  assert.deepEqual(Object.keys(t).sort(), ['adressen', 'komponenten', 'komponenteneintraege', 'dateien', 'dokumente', 'durchfuehrungen', 'eintraege', 'fahrzeuge', 'fristen', 'vorgaenge', 'verlaeufe', 'zaehler', 'zaehlerstaende'].sort());
  const text = JSON.stringify(t);
  ['Sommertörn', 'Anna', 'Anker werfen', 'an Herrn Meier', 'Herr Kuhn', '040 123', 'mein Cousin'].forEach(s => assert.ok(!text.includes(s), s + ' darf nicht in der Übergabe stehen'));
  assert.ok(text.includes('Marine Service Nord') && text.includes('Travemünde'), 'Name und Ort der Werkstatt gehen mit');
  assert.equal(t.fahrzeuge[0].abgabe, undefined, 'die Abgabe mit Notiz geht nicht mit');
  assert.equal(g.kopf.fahrzeug.abgabeDatum, '2026-11-01'); assert.equal(g.kopf.fahrzeug.grund, 'verkauft');
  assert.equal(g.kopf.uebergabe, true);
});

test('Übergabedatei: ohne Dateien, und mit Schlüsselwort', async () => {
  const { d, boot } = await vollesFahrzeug();
  await d.fahrzeugAbgeben(boot, { datum: '2026-11-01', grund: 'verschenkt' });
  const ohne = await d.uebergabeErzeugen(boot, { mitDateien: false });
  assert.equal(ohne.dateien, 0); assert.equal(ohne.zahlen.dokumente, 2);
  const g = await d.uebergabeLesen(ohne.bytes);
  assert.deepEqual(g.kopf.tabellen.dateien, []);
  const geheim = await d.uebergabeErzeugen(boot, { schluessel: 'Seeadler' });
  assert.equal(geheim.verschluesselt, true);
  await assert.rejects(d.uebergabeLesen(geheim.bytes), e => e.code === 'schluessel_noetig');
  await assert.rejects(d.uebergabeLesen(geheim.bytes, 'falsch'), e => e.code === 'schluessel');
  assert.ok(await d.uebergabeLesen(geheim.bytes, 'Seeadler'));
});

test('Eine Übergabedatei lässt sich nie als Sicherung einspielen, und umgekehrt', async () => {
  const { d, boot } = await vollesFahrzeug();
  await d.fahrzeugAbgeben(boot, { datum: '2026-11-01', grund: 'verkauft' });
  const u = await d.uebergabeErzeugen(boot);
  await assert.rejects(d.sicherungLesen(u.bytes), e => e.code === 'uebergabe' && /Übergabedatei/.test(e.message));
  const s = await d.sicherungErzeugen({});
  await assert.rejects(d.uebergabeLesen(s.bytes), e => e.code === 'keine-uebergabe');
  await assert.rejects(d.uebergabeLesen(new Uint8Array([1, 2, 3])));
});

test('Übernehmen auf einem anderen Gerät: neues Fahrzeug mit der ganzen technischen Historie, Vorhandenes bleibt unberührt', async () => {
  const c = await vollesFahrzeug();
  const { d, boot } = c;
  await d.fahrzeugAbgeben(boot, { datum: '2026-11-01', grund: 'verkauft' });
  const u = await d.uebergabeErzeugen(boot);

  const neuD = neuesGeraet(); await neuD.starten();
  const eigenes = (await neuD.fahrzeugAnlegen('auto', { bezeichnung: 'Mein Auto' })).id;
  const g = await neuD.uebergabeLesen(u.bytes);
  const v = await neuD.uebergabeVorschau(g);
  assert.deepEqual([v.bezeichnung, v.artName, v.abgabeDatum, v.grund], ['Seestern', 'Boot', '2026-11-01', 'verkauft']);
  assert.deepEqual(v.zahlen, { komponenten: 2, zaehler: 1, fristen: 2, vorgaenge: 3, dokumente: 2 });
  assert.equal(v.schonUebernommen, null); assert.equal(v.artFehlt, false); assert.equal(v.dateien, 1);

  const r = await neuD.uebergabeEinspielen(g);
  assert.ok(r.ok);
  assert.notEqual(r.id, boot, 'alle Kennungen sind neu');
  const f = await neuD.fahrzeugLaden(r.id);
  assert.equal(f.aktuell.werte.bezeichnung, 'Seestern'); assert.equal(f.fahrzeug.art, 'boot'); assert.equal(f.aktuell.werte.tiefgang, 1.2);
  assert.equal(f.fahrzeug.abgabe, undefined, 'aktiv beim neuen Besitzer');
  assert.equal(f.fahrzeug.uebernommen.abgabeDatum, '2026-11-01'); assert.equal(f.fahrzeug.uebernommen.grund, 'verkauft');
  assert.deepEqual((await neuD.fahrzeugListe()).map(x => x.aktuell.werte.bezeichnung), ['Mein Auto', 'Seestern']);
  assert.equal((await neuD.fahrzeugLaden(eigenes)).aktuell.werte.bezeichnung, 'Mein Auto');

  const komp = await neuD.komponentenListe(r.id);
  assert.equal(komp.length, 2);
  const motor = komp.find(x => x.aktuell.werte.bezeichnung === 'Motor'), pumpe = komp.find(x => x.aktuell.werte.bezeichnung === 'Wasserpumpe');
  assert.equal(pumpe.komponente.parentId, motor.komponente.id, 'die Verschachtelung bleibt');
  assert.equal(motor.komponente.fahrzeugId, r.id);
  const zaehler = await neuD.zaehlerListe(r.id);
  assert.equal(zaehler.length, 1); assert.equal(zaehler[0].stand.wert, 1250); assert.equal(zaehler[0].komponenteId, motor.komponente.id);
  const fristen = await neuD.fristenListe(r.id);
  assert.deepEqual(fristen.map(x => x.aktuell.werte.bezeichnung).sort(), ['HU', 'Ölwechsel']);
  const hu = fristen.find(x => x.aktuell.werte.bezeichnung === 'HU');
  assert.equal(hu.status.letzte.datum, '2026-05-10', 'die letzte Erledigung kommt mit');
  const vorg = await neuD.vorgaengeListe(r.id);
  assert.equal(vorg.length, 3);
  assert.deepEqual(vorg.map(x => x.aktuell.werte.status).sort(), ['erledigt', 'erledigt', 'offen']);
  const mitAdresse = vorg.find(x => x.aktuell.werte.bezeichnung === 'Impeller wechseln');
  const adressen = await neuD.adressenListe();
  assert.equal(adressen.length, 1); assert.equal(mitAdresse.aktuell.werte.adresseId, adressen[0].objekt.id);
  assert.equal(adressen[0].aktuell.werte.bezeichnung, 'Marine Service Nord'); assert.ok(!adressen[0].aktuell.werte.telefon);
  const dok = await neuD.dokumenteListe(r.id);
  assert.equal(dok.length, 2);
  const mitDatei = dok.find(x => x.aktuell.werte.bezeichnung === 'Handbuch D3');
  assert.equal(await (await neuD.dateiHolen(mitDatei.dokument.id)).inhalt.text(), 'HANDBUCH-INHALT');
  /* nichts Privates, nichts Fremdes */
  assert.equal((await neuD.aktivitaetenListe()).length, 0);
  assert.equal((await neuD.personenListe()).length, 0);
  assert.equal((await neuD.speicher.alle('ereignisse')).length, 0);
  assert.equal((await neuD.speicher.alle('kosten')).length, 0);
});

test('Übernehmen: dieselbe Übergabe zweimal fragt nach; auf demselben Gerät kollidiert nichts; Werkstätten werden wiederverwendet', async () => {
  const { d, boot } = await vollesFahrzeug();
  await d.fahrzeugAbgeben(boot, { datum: '2026-11-01', grund: 'verkauft' });
  const g = await d.uebergabeLesen((await d.uebergabeErzeugen(boot)).bytes);
  const eins = await d.uebergabeEinspielen(g);
  assert.ok(eins.ok);
  const zwei = await d.uebergabeEinspielen(g);
  assert.equal(zwei.ok, false); assert.equal(zwei.schonDa, true);
  assert.equal((await d.uebergabeVorschau(g)).schonUebernommen.id, eins.id);
  const drei = await d.uebergabeEinspielen(g, { nochmal: true });
  assert.ok(drei.ok); assert.notEqual(drei.id, eins.id);
  assert.equal((await d.fahrzeugListe()).filter(x => x.aktuell.werte.bezeichnung === 'Seestern').length, 2, 'das aktive Original steht nicht mehr drin, die zwei Kopien schon');
  assert.equal((await d.adressenListe()).length, 1, 'die Werkstatt gab es schon');
  assert.equal((await d.komponentenListe(eins.id)).length, 2);
  assert.equal((await d.komponentenListe(boot)).length, 2, 'das Original ist unverändert');
  const ids = (await d.speicher.alle('komponenten')).map(x => x.id);
  assert.equal(new Set(ids).size, ids.length);
});

test('Übernehmen: fehlende Fahrzeugart wird durch die nächste vorhandene ersetzt, sonst Abbruch', async () => {
  const { d, boot } = await vollesFahrzeug();
  await d.fahrzeugAendern(boot, (await d.fahrzeugLaden(boot)).aktuell.werte, 'sportboot');
  await d.fahrzeugAbgeben(boot, { datum: '2026-11-01', grund: 'verkauft' });
  const g = await d.uebergabeLesen((await d.uebergabeErzeugen(boot)).bytes);
  assert.deepEqual(g.kopf.fahrzeug.artPfad.slice(0, 3), ['sportboot', 'boot', 'wasser']);
  g.kopf.fahrzeug.art = 'meine-eigene-art'; g.kopf.fahrzeug.artName = 'Meine Art'; g.kopf.fahrzeug.artPfad = ['segelboot', 'boot', 'wasser'];
  g.kopf.tabellen.eintraege.forEach(e => { if (e.art === 'sportboot') e.art = 'meine-eigene-art'; if (e.artVorher === 'sportboot') e.artVorher = 'meine-eigene-art'; });
  g.kopf.tabellen.fahrzeuge[0].art = 'meine-eigene-art';
  const v = await d.uebergabeVorschau(g);
  assert.equal(v.art.angepasst, true); assert.equal(v.art.id, 'segelboot');
  const r = await d.uebergabeEinspielen(g);
  assert.ok(r.ok); assert.equal(r.artAngepasst, 'Segelboot');
  const f = await d.fahrzeugLaden(r.id);
  assert.equal(f.fahrzeug.art, 'segelboot');
  assert.ok(f.verlauf.every(x => x.aenderungen.every(u => u.neu !== 'meine-eigene-art')), 'der Verlauf rechnet mit vorhandenen Arten');

  g.kopf.fahrzeug.artPfad = ['gibt-es-nicht'];
  const v2 = await d.uebergabeVorschau(g);
  assert.equal(v2.artFehlt, true);
  const r2 = await d.uebergabeEinspielen(g, { nochmal: true });
  assert.equal(r2.ok, false); assert.match(r2.fehler.allgemein, /Meine Art/);
});

test('Übernehmen ist alles oder nichts: eine beschädigte Datei legt nichts an', async () => {
  const { d, boot } = await vollesFahrzeug();
  await d.fahrzeugAbgeben(boot, { datum: '2026-11-01', grund: 'verkauft' });
  const g = await d.uebergabeLesen((await d.uebergabeErzeugen(boot)).bytes);
  const vorher = (await d.speicher.alle('fahrzeuge')).length;
  g.kopf.tabellen.fahrzeuge.push(Object.assign({}, g.kopf.tabellen.fahrzeuge[0], { id: 'fz-zweites' }));
  await assert.rejects(d.uebergabeEinspielen(g));
  assert.equal((await d.speicher.alle('fahrzeuge')).length, vorher);
});

/* ================= Technik-Akte ================= */
test('Zeitraum der Akte: letzte HU bis Abgabe, höchstens 24 Monate', () => {
  const Z = MM.Daten.akteZeitraum;
  assert.deepEqual(Z('2026-11-01', '2026-05-10', '2020-01-01'), { von: '2026-05-10', bis: '2026-11-01', art: 'hu', huDatum: '2026-05-10' });
  assert.equal(Z('2026-11-01', '2024-11-01', null).art, 'hu', 'genau 24 Monate sind noch erlaubt');
  assert.deepEqual(Z('2026-11-01', '2024-10-31', null), { von: '2024-11-01', bis: '2026-11-01', art: 'hu-alt', huDatum: '2024-10-31' });
  assert.deepEqual(Z('2026-11-01', null, '2026-03-01'), { von: '2026-03-01', bis: '2026-11-01', art: 'angelegt', huDatum: null });
  assert.deepEqual(Z('2026-11-01', null, '2020-01-01'), { von: '2024-11-01', bis: '2026-11-01', art: 'ohne-hu-grenze', huDatum: null });
  assert.equal(MM.Daten.monateZurueck('2026-03-31', 1), '2026-02-28');
  assert.equal(MM.Daten.monateZurueck('2024-03-31', 1), '2024-02-29');
  assert.equal(MM.Daten.monateZurueck('2026-01-15', 24), '2024-01-15');
  assert.equal(MM.Daten.monateZurueck('2026-02-28', 14), '2024-12-28');
});

test('Technik-Akte: nur der Zeitraum ab der letzten HU, dazu alles Offene, Zählerstand bei der Abgabe', async () => {
  const { d, boot } = await vollesFahrzeug();
  await d.fahrzeugAbgeben(boot, { datum: '2026-10-30', grund: 'verkauft' });
  const a = await d.akteDaten(boot);
  assert.ok(a.ok);
  assert.deepEqual([a.zeitraum.art, a.zeitraum.von, a.zeitraum.bis, a.zeitraum.huDatum], ['hu', '2026-05-10', '2026-10-30', '2026-05-10']);
  assert.equal(a.huFrist, 'HU'); assert.equal(a.huUeberfaellig, false);
  assert.deepEqual(a.vorgaenge.map(v => v.bezeichnung), ['Kühlschrank kühlt schlecht', 'Impeller wechseln'], 'der alte erledigte Vorgang fehlt, der alte offene ist dabei');
  assert.equal(a.staende.length, 1); assert.equal(a.staende[0].wert, 1250); assert.equal(a.staende[0].datum, '2026-10-01');
  assert.deepEqual(a.erledigt.map(e => e.name), ['HU'], 'im Zeitraum erledigt: die HU selbst, nicht der Ölwechsel vom Januar');
  assert.deepEqual(a.fristen.map(x => x.name).sort(), ['HU', 'Ölwechsel']);
  assert.deepEqual(a.komponenten.map(k => k.aktuell.werte.bezeichnung), ['Motor']);
});

test('Technik-Akte: Zählerstand gilt zum Tag der Abgabe, nicht der spätere', async () => {
  const { d, boot } = await vollesFahrzeug();
  await d.fahrzeugAbgeben(boot, { datum: '2026-09-01', grund: 'verkauft' });
  const a = await d.akteDaten(boot);
  assert.equal(a.staende[0].wert, 1000); assert.equal(a.staende[0].datum, '2026-06-01');
});

test('Technik-Akte: keine HU erfasst, oder HU länger als 24 Monate her', async () => {
  const { d, wm } = await neu();
  await d.fahrzeugAbgeben(wm, { datum: '2026-11-01', grund: 'verschenkt' });
  const a = await d.akteDaten(wm);
  assert.equal(a.zeitraum.art, 'angelegt'); assert.equal(a.zeitraum.von, '2026-11-04'.slice(0, 8) + '04');

  const c = await neu();
  c.d.stelle(2026, 11, 4);
  await c.d.fristAnlegen(c.wm, null, { bezeichnung: 'Hauptuntersuchung', kategorie: 'pruefung', kalenderWert: '24', kalenderEinheit: 'monate', vorwarnTage: '30', zuletztAm: '2023-09-01' });
  await c.d.fahrzeugAbgeben(c.wm, { datum: '2026-11-01', grund: 'verkauft' });
  const b = await c.d.akteDaten(c.wm);
  assert.deepEqual([b.zeitraum.art, b.zeitraum.von], ['hu-alt', '2024-11-01']);
  assert.equal(b.huUeberfaellig, true);
});

test('Technik-Akte als PDF: gültige Datei mit dem richtigen Inhalt', async () => {
  const { d, boot } = await vollesFahrzeug();
  await d.fahrzeugAbgeben(boot, { datum: '2026-10-30', grund: 'verkauft' });
  const r = await d.akteErzeugen(boot);
  assert.ok(r.ok); assert.equal(r.mime, 'application/pdf'); assert.match(r.name, /^Technik-Akte_Seestern_2026-10-30\.pdf$/);
  const text = Buffer.from(r.bytes).toString('latin1');
  assert.ok(text.startsWith('%PDF-1.4'));
  assert.ok(text.includes('Technik-Akte') && text.includes('Seestern'));
  assert.ok(text.includes('Impeller wechseln') && text.includes('Kühlschrank'.replace('ü', '\\374')), 'Vorgänge im Zeitraum und offene');
  assert.ok(!text.includes('Lenzpumpe'), 'ältere erledigte Vorgänge nicht');
  assert.ok(text.includes('10.05.2026'), 'letzte HU');
  assert.ok(text.includes('30.10.2026'));
  assert.ok(!text.includes('Sommert'), 'keine Aktivitäten');
  assert.ok(r.seiten >= 1);
});
