# Android-App (Hülle) – so kommt die APK aufs Tablet

Die Web-App bleibt, wie sie ist (Browser, Desktop-PC). Die Android-App ist ein zusätzlicher Weg: dieselbe App in einer Hülle, die im Hintergrund weiter aufzeichnen darf. Apple kommt später.

## APK holen (einmal pro Version, ca. 5 bis 10 Minuten)

1. Die Dateien wie bisher bei GitHub hochladen (Repository MobiMori-V2). Der Ordner `android` und die Datei `package-lock.json` gehören dazu.
2. Auf GitHub oben auf **Actions** tippen. Der oberste Lauf heißt **Android-APK bauen**. Ein grüner Haken heißt: fertig. Ein roter Kreis heißt Fehler: den Lauf öffnen und die rote Meldung an Claude schicken.
3. Den fertigen Lauf öffnen, ganz unten bei **Artifacts** auf **MobiMory-APK** tippen. Das lädt eine ZIP-Datei. Darin liegt `app-debug.apk`.
4. Wer den Lauf nicht von selbst bekommt: **Actions → Android-APK bauen → Run workflow**.

## Auf dem Tablet installieren

1. ZIP auf dem Tablet entpacken, `app-debug.apk` antippen.
2. Android fragt, ob Installationen aus dieser Quelle erlaubt sind („Unbekannte Quellen“): einmal erlauben.
3. Installieren, dann öffnen. Beim ersten Mal fragt Android nach **Standort** (genau, bei Nutzung der App) und nach **Benachrichtigungen**: beides erlauben.
4. Läuft die Aufzeichnung, steht oben die Benachrichtigung „MobiMory zeichnet auf“.

## Wichtig

- Die App in der Hülle hat einen eigenen Speicher, getrennt vom Browser. Daten aus der Web-App kommen über die Sicherung (Datei) oder das Konto.
- Eine neue Version der Web-App kommt nur mit einer neuen APK aufs Tablet.
- Manche Hersteller beenden Dienste im Hintergrund trotz Dauerdienst. Dann in den Android-Einstellungen der App den Akku auf „Nicht eingeschränkt“ stellen.
