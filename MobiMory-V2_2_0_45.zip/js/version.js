/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.45';
  MM.STUFE = 'Komponenten löschen, ausblenden, verschieben; Merkmale mit Einheit; zusammengehörige Fahrzeuge';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
