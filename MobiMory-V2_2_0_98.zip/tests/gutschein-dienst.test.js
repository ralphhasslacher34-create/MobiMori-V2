'use strict';
/* 2.0.83 (Dienst 13f-8, Bau 2): Gutscheincodes beim Bezahlen. Rabatt 1 bis 25 % nur für Neukunden, 100 % als Geschenk ohne Zahlung, Ablauf, Grenzen,
   nur Admins legen an, Rabatt auf dem Beleg. Dienst mit nachgebauter Datenbank, PayPal und Mail sind Platzhalter. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

const APP = 'https://app.example.org';
const DIENST = 'https://konto.example.workers.dev';
const TAG = 24 * 60 * 60 * 1000;
const ADMIN = 'admin-passwort-' + 'x'.repeat(20);
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) {
  return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1',
    RECHERCHE_URL: 'https://recherche.example.org', RECHERCHE_TOKEN: 'geheim-token-1',
    PAYPAL_CLIENT_ID: 'client-id-123', PAYPAL_SECRET: 'secret-456',
    UEBERWEISUNG_INHABER: 'Ralph Hasslacher', UEBERWEISUNG_IBAN: 'DE02 1203 0000 0000 2020 51', FREISCHALT_TOKEN: ADMIN,
    BELEG_ANSCHRIFT: 'Ralph Hasslacher\nMusterstraße 1\n74372 Sersheim' }, extra || {});
}
function uhr() { const u = { t: Date.UTC(2026, 10, 12, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
/* Mail-Platzhalter: wird erst nach dem Anmelden eingehängt (im Test-Dienst kommt der Anmelde-Code sonst nicht in der Antwort). */
function mail(env) { const post = { gesendet: [], fehler: false }; env.ABSENDER = 'konto@example.org'; env.EMAIL = { send: async (m) => { if (post.fehler) throw new Error('kaputt'); post.gesendet.push(m); } }; return post; }

/* PayPal-Platzhalter. modus: ok, betrag (falscher Betrag), offen (Zahlung nicht fertig), schon (zweiter Abschluss), nichts (kein Link in der Antwort). */
function paypal() {
  const p = { aufrufe: [], modus: 'ok', n: 0, bestellt: null };
  p.fetch = async (url, o) => {
    p.aufrufe.push({ url, methode: o.method, kopf: o.headers, body: o.body });
    if (/\/v1\/oauth2\/token$/.test(url)) return new Response(JSON.stringify({ access_token: 'zugang' }), { status: 200 });
    if (/\/v2\/checkout\/orders$/.test(url) && o.method === 'POST') {
      p.bestellt = JSON.parse(o.body); p.n += 1; p.orderId = 'ORDER' + p.n;
      if (p.modus === 'nichts') return new Response(JSON.stringify({ id: p.orderId, links: [] }), { status: 200 });
      return new Response(JSON.stringify({ id: p.orderId, status: 'PAYER_ACTION_REQUIRED', links: [{ rel: 'self', href: 'https://api-m.sandbox.paypal.com/v2/checkout/orders/' + p.orderId }, { rel: 'payer-action', href: 'https://www.sandbox.paypal.com/checkoutnow?token=' + p.orderId }] }), { status: 200 });
    }
    const betrag = p.modus === 'betrag' ? '1.00' : p.bestellt.purchase_units[0].amount.value;
    const fertig = { id: p.orderId, status: 'COMPLETED', purchase_units: [{ payments: { captures: [{ id: 'CAP' + p.n, status: p.modus === 'offen' ? 'PENDING' : 'COMPLETED', amount: { currency_code: 'EUR', value: betrag } }] } }] };
    if (/\/capture$/.test(url)) {
      p.abschluesse = (p.abschluesse || 0) + 1;
      if (p.modus === 'schon' && p.abschluesse > 1) return new Response(JSON.stringify({ name: 'UNPROCESSABLE_ENTITY', details: [{ issue: 'ORDER_ALREADY_CAPTURED' }] }), { status: 422 });
      return new Response(JSON.stringify(fertig), { status: 201 });
    }
    return new Response(JSON.stringify(fertig), { status: 200 });
  };
  return p;
}
function recherche() {
  const r = { aufrufe: [], modus: 'ok' };
  r.fetch = async (url, opt) => {
    r.aufrufe.push({ url });
    if (r.modus === 'fehler') return new Response(JSON.stringify({ error: 'KI nicht erreichbar' }), { status: 500 });
    return new Response(JSON.stringify({ ok: true, requirements: [{ id: 'a' }], model: 'm' }), { status: 200 });
  };
  return r;
}

async function roh(env, u, methode, weg, body, token, optionen, kopfExtra) {
  const d = await laden();
  const kopf = Object.assign({ Origin: APP, 'CF-Connecting-IP': '203.0.113.5' }, kopfExtra || {});
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  return d.behandeln(new Request(DIENST + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }),
    env, Object.assign({ jetzt: u.jetzt }, optionen || {}));
}
async function ruf(env, u, methode, weg, body, token, optionen, kopfExtra) { const r = await roh(env, u, methode, weg, body, token, optionen, kopfExtra); return { status: r.status, json: await r.json() }; }
async function anmelden(env, u, email, geraet) {
  u.t += 13 * 60 * 1000;
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email });
  return ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode, geraet });
}
async function konto(env, u, email) { const r = await anmelden(env, u, email, 'Test #' + '0123456789abcdef'.slice(0, 8)); assert.equal(r.status, 200, JSON.stringify(r.json)); return r.json.token; }
function nutzerId(env, email) { return env.DB.roh.prepare('SELECT id FROM nutzer WHERE email = ?').get(email).id; }
function stufeSetzen(env, email, stufe, bis) {
  env.DB.roh.prepare('INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) VALUES (?, ?, ?, ?)').run(nutzerId(env, email), stufe, bis === undefined ? null : bis, 1);
}
function stufeLesen(env, email) { return env.DB.roh.prepare('SELECT stufe, gueltig_bis FROM stufe_konto WHERE nutzer_id = ?').get(nutzerId(env, email)); }
function plusJahr(ms) { const d = new Date(ms); d.setUTCFullYear(d.getUTCFullYear() + 1); return d.getTime(); }
async function bezahlen(env, u, tok, produkt, pp) { return ruf(env, u, 'POST', '/bezahlen/starten', { produkt, weg: 'paypal' }, tok, { fetch: pp.fetch }); }
async function zurueck(env, u, pp, bid) { const r = await roh(env, u, 'GET', '/bezahlen/paypal/zurueck?b=' + bid + '&token=' + pp.orderId, undefined, undefined, { fetch: pp.fetch }); return { status: r.status, text: await r.text() }; }
function offeneId(env) { return env.DB.roh.prepare('SELECT id FROM bestellung ORDER BY erstellt_am DESC').get().id; }


/* ---- Hilfen für Codes ---- */
function adminSein(env, email, funktion) { env.DB.roh.prepare('INSERT OR REPLACE INTO rolle (email, name, funktion) VALUES (?, ?, ?)').run(email, 'Test', funktion || 'admin'); }
async function anlegen(env, u, tok, body) { return ruf(env, u, 'POST', '/gutschein/anlegen', Object.assign({ laeuftAb: '2027-06-30' }, body), tok); }
const normal = (c) => c.replace(/-/g, '');
async function neuerAdmin(env, u) { const t = await konto(env, u, 'chef@example.org'); adminSein(env, 'chef@example.org'); return t; }
function monateDazu(ms, n) { const d = new Date(ms), tag = d.getUTCDate(); d.setUTCDate(1); d.setUTCMonth(d.getUTCMonth() + n); const max = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate(); d.setUTCDate(Math.min(tag, max)); return d.getTime(); }
const proben = (env, sql, ...w) => env.DB.roh.prepare(sql).all(...w);

test('Dienst 13f-8: Version, sechs SQL-Zeilen auch im Schema, Gesundheit, Anleitung', async () => {
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13f-8.sql'), 'utf8').trim().split('\n');
  assert.equal(sql.length, 6);
  assert.match(sql[0], /^CREATE TABLE IF NOT EXISTS gutschein /); assert.match(sql[1], /^CREATE TABLE IF NOT EXISTS gutschein_einloesung /);
  sql.slice(2).forEach((z) => assert.match(z, /^ALTER TABLE (bestellung|beleg) ADD COLUMN (gutschein TEXT|liste_cent INTEGER);$/));
  const schema = fs.readFileSync(path.join(__dirname, '..', 'server', 'schema.sql'), 'utf8');
  sql.forEach((z) => assert.ok(schema.includes(z)));
  const d = await laden();
  assert.equal(d.VERSION, '13g');
  const env = umgebung();
  const g = await (await d.behandeln(new Request(DIENST + '/gesundheit', { headers: { Origin: APP } }), env, { jetzt: () => Date.UTC(2026, 10, 15) })).json();
  assert.equal(g.version, '13g'); assert.equal(g.bezahlung.gutscheine, true);
  const anl = fs.readFileSync(path.join(__dirname, '..', 'server', 'EINRICHTUNG.md'), 'utf8');
  assert.ok(anl.includes('Update auf 13f-8')); assert.ok(anl.includes('13f-8.sql')); assert.ok(anl.includes('Update auf 13f-9'));
});

test('Anlegen: nur Admins; Entwickler, normale Konten und Anonyme werden abgewiesen', async () => {
  const env = umgebung(), u = uhr();
  const k = await konto(env, u, 'kunde@example.org');
  assert.equal((await anlegen(env, u, undefined, { prozent: 10 })).status, 401);
  assert.equal((await anlegen(env, u, k, { prozent: 10 })).status, 403);
  adminSein(env, 'kunde@example.org', 'entwickler');
  assert.equal((await anlegen(env, u, k, { prozent: 10 })).status, 403, 'ein Entwickler darf nicht anlegen');
  assert.equal((await ruf(env, u, 'GET', '/gutschein/liste', undefined, k)).status, 403);
  assert.equal((await ruf(env, u, 'POST', '/gutschein/loeschen', { code: 'ABCD2345' }, k)).status, 403);
  adminSein(env, 'kunde@example.org', 'admin');
  assert.equal((await anlegen(env, u, k, { prozent: 10 })).status, 200);
});

test('Mail beim Anlegen (13f-9): persönlicher Code geht an die Person, Code für viele an den Verteiler, Adresse wird nicht gespeichert, ohne Mail-Versand bleibt der Code trotzdem', async () => {
  const env = umgebung(), u = uhr();
  const tok = await neuerAdmin(env, u); const post = mail(env);
  /* ohne Empfänger: keine Mail, keine Angabe „mail“ */
  const o = await anlegen(env, u, tok, { prozent: 10 });
  assert.equal(o.status, 200); assert.equal(o.json.mail, undefined); assert.equal(post.gesendet.length, 0);
  /* Geschenkcode (persönlich) */
  const g = await anlegen(env, u, tok, { prozent: 100, stufe: 'voll', monate: 3, empfaenger: ' Tanja@Example.org ', notiz: 'für Tanja' });
  assert.equal(g.status, 200); assert.equal(g.json.mail, true); assert.equal(post.gesendet.length, 1);
  const m = post.gesendet[0];
  assert.equal(m.to, 'tanja@example.org'); assert.match(m.subject, /Dein Gutscheincode/);
  assert.ok(m.text.includes(g.json.code), 'der Code steht in der Mail'); assert.match(m.text, /Voll für 3 Monate, ohne Bezahlen/); assert.match(m.text, /gilt bis 30\.06\.2027/);
  assert.match(m.text, /Konto › Deine Stufe › Gutscheincode/); assert.match(m.text, /kann einmal eingelöst werden/); assert.match(m.text, /Code einlösen/);
  assert.ok(!/für Tanja/.test(m.text), 'die Notiz steht nicht in der Mail');
  /* Rabattcode für viele: Mail an den Verteiler mit der Zahl der Einlösungen */
  const v = await anlegen(env, u, tok, { prozent: '12,5', grenze: 50, code: 'youtube', empfaenger: 'verteiler@example.org' });
  assert.equal(v.status, 200); assert.equal(v.json.mail, true);
  const m2 = post.gesendet[1];
  assert.equal(m2.to, 'verteiler@example.org'); assert.match(m2.subject, /zum Weitergeben/); assert.match(m2.text, /YOUTUBE/); assert.match(m2.text, /12,5 % Rabatt auf den ersten Kauf von Mittel oder Voll/);
  assert.match(m2.text, /50-mal eingelöst/); assert.match(m2.text, /Konto › Deine Stufe › Gutscheincode/);
  /* persönlicher Rabattcode (Grenze 1) */
  const p1 = await anlegen(env, u, tok, { prozent: 20, empfaenger: 'neu@example.org' });
  assert.equal(p1.json.mail, true); assert.match(post.gesendet[2].subject, /Dein Gutscheincode/); assert.match(post.gesendet[2].text, /20 % Rabatt/);
  /* die Adresse steht nirgends in der Datenbank */
  const alle = JSON.stringify(proben(env, 'SELECT * FROM gutschein'));
  assert.ok(!/example\.org/.test(alle.replace(/chef@example\.org/g, '')), 'keine Empfänger-Adresse gespeichert');
  /* Versand kaputt: Code ist trotzdem angelegt, mail ist false */
  post.fehler = true;
  const k = await anlegen(env, u, tok, { prozent: 15, empfaenger: 'jemand@example.org' });
  assert.equal(k.status, 200); assert.equal(k.json.mail, false);
  assert.equal(proben(env, 'SELECT code FROM gutschein WHERE code = ?', normal(k.json.code)).length, 1);
  /* Mail-Versand nicht eingerichtet (Entwicklung): mail false */
  const env2 = umgebung(), u2 = uhr(); const tok2 = await neuerAdmin(env2, u2);
  const e2 = await anlegen(env2, u2, tok2, { prozent: 15, empfaenger: 'jemand@example.org' });
  assert.equal(e2.status, 200); assert.equal(e2.json.mail, false);
  /* ungültige Adresse: Fehler am Feld, nichts angelegt */
  const vorher = proben(env, 'SELECT code FROM gutschein').length;
  const f = await anlegen(env, u, tok, { prozent: 15, empfaenger: 'keine-adresse' });
  assert.equal(f.status, 400); assert.equal(f.json.feld, 'empfaenger'); assert.equal(proben(env, 'SELECT code FROM gutschein').length, vorher);
  /* leeres Feld zählt als „kein Empfänger“ */
  const l = await anlegen(env, u, tok, { prozent: 15, empfaenger: '   ' }); assert.equal(l.status, 200); assert.equal(l.json.mail, undefined);
});

test('Anlegen: Rabatt nur über 0 bis 25 % oder genau 100 %, dazwischen lehnt der Dienst ab; Dezimalstellen gehen', async () => {
  const env = umgebung(), u = uhr(), a = await neuerAdmin(env, u);
  for (const p of [0, -5, 25.01, 26, 30, 50, 99.99, 100.5, 150, '', 'viel', null]) {
    const r = await anlegen(env, u, a, { prozent: p });
    assert.equal(r.status, 400, 'Prozent ' + p); assert.equal(r.json.feld, 'prozent');
  }
  for (const p of [1, 12.5, '12,5', 25, 0.5]) assert.equal((await anlegen(env, u, a, { prozent: p })).status, 200, 'Prozent ' + p);
  assert.equal((await anlegen(env, u, a, { prozent: 100, stufe: 'voll', monate: 2 })).status, 200);
  assert.equal(proben(env, 'SELECT prozent FROM gutschein WHERE prozent = 12.5').length, 2);
});

test('Anlegen: Ablaufdatum Pflicht und in der Zukunft, Obergrenze, 100 % nur mit Stufe und 1 bis 12 Monaten, immer Grenze 1 und zufälliger Code', async () => {
  const env = umgebung(), u = uhr(), a = await neuerAdmin(env, u);
  assert.equal((await ruf(env, u, 'POST', '/gutschein/anlegen', { prozent: 10 }, a)).json.feld, 'laeuftAb');
  assert.equal((await anlegen(env, u, a, { prozent: 10, laeuftAb: '2026-11-11' })).json.feld, 'laeuftAb');
  assert.equal((await anlegen(env, u, a, { prozent: 10, laeuftAb: '2026-13-40' })).json.feld, 'laeuftAb');
  assert.equal((await anlegen(env, u, a, { prozent: 10, laeuftAb: '2040-01-01' })).json.feld, 'laeuftAb', 'höchstens fünf Jahre');
  assert.equal((await anlegen(env, u, a, { prozent: 10, grenze: 0 })).json.feld, 'grenze');
  assert.equal((await anlegen(env, u, a, { prozent: 10, grenze: 1.5 })).json.feld, 'grenze');
  assert.equal((await anlegen(env, u, a, { prozent: 100 })).json.feld, 'stufe');
  assert.equal((await anlegen(env, u, a, { prozent: 100, stufe: 'basic', monate: 3 })).json.feld, 'stufe');
  assert.equal((await anlegen(env, u, a, { prozent: 100, stufe: 'mittel', monate: 0 })).json.feld, 'monate');
  assert.equal((await anlegen(env, u, a, { prozent: 100, stufe: 'mittel', monate: 13 })).json.feld, 'monate');
  assert.equal((await anlegen(env, u, a, { prozent: 10, code: 'ab' })).json.feld, 'code');
  /* 100 %: eigener Code und höhere Grenze werden ignoriert */
  const r = await anlegen(env, u, a, { prozent: 100, stufe: 'voll', monate: 12, grenze: 50, code: 'GRATIS2026' });
  assert.equal(r.status, 200); assert.match(r.json.code, /^[2-9A-HJKMNP-Z]{4}-[2-9A-HJKMNP-Z]{4}$/);
  const z = proben(env, 'SELECT * FROM gutschein WHERE code = ?', normal(r.json.code))[0];
  assert.equal(z.grenze, 1); assert.equal(z.stufe, 'voll'); assert.equal(z.monate, 12); assert.equal(z.erstellt_von, 'chef@example.org');
  assert.equal(proben(env, "SELECT * FROM gutschein WHERE code = 'GRATIS2026'").length, 0);
  /* Rabatt: eigener Code, Grenze, doppelt geht nicht */
  const e = await anlegen(env, u, a, { prozent: 15, code: 'youtube-15', grenze: 500, notiz: 'Kanal XY' });
  assert.equal(e.status, 200); assert.equal(e.json.code, 'YOUTUBE15');
  assert.equal((await anlegen(env, u, a, { prozent: 15, code: 'YouTube 15' })).json.feld, 'code');
  const l = await ruf(env, u, 'GET', '/gutschein/liste', undefined, a);
  const y = l.json.codes.find((c) => c.code === 'YOUTUBE15');
  assert.equal(y.prozent, 15); assert.equal(y.grenze, 500); assert.equal(y.eingeloest, 0); assert.equal(y.laeuftAb, '2027-06-30'); assert.equal(y.notiz, 'Kanal XY'); assert.equal(y.abgelaufen, false);
});

test('Rabatt mit PayPal: Neukunde zahlt den Preis nach Abzug, Beleg weist den Rabatt als eigene Zeile aus, Einlösung wird gezählt', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  const a = await neuerAdmin(env, u);
  const c = (await anlegen(env, u, a, { prozent: 20, code: 'WILLKOMMEN', grenze: 100 })).json.code;
  const tok = await konto(env, u, 'kunde@example.org'); const post = mail(env);
  /* Vorschau */
  const v = await ruf(env, u, 'POST', '/gutschein/pruefen', { code: 'willkommen' }, tok);
  assert.equal(v.status, 200, JSON.stringify(v.json)); assert.equal(v.json.art, 'rabatt'); assert.equal(v.json.prozent, 20);
  assert.equal(v.json.preise.mittel.betrag, '47,90 €'); assert.equal(v.json.preise.mittel.preis, '59,88 €'); assert.equal(v.json.preise.mittel.rabatt, '−11,98 €');
  assert.equal(v.json.preise.voll.betrag, '95,90 €'); assert.ok(!v.json.preise.recherche5);
  assert.equal(proben(env, 'SELECT * FROM gutschein_einloesung').length, 0, 'prüfen zählt nicht');
  /* Bestellen */
  const s = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal', code: 'WILLKOMMEN' }, tok, { fetch: pp.fetch });
  assert.equal(s.status, 200, JSON.stringify(s.json)); assert.equal(s.json.betrag, '47,90 €'); assert.equal(s.json.rabatt.rabatt, '−11,98 €');
  assert.equal(JSON.parse(pp.aufrufe.find((x) => /\/orders$/.test(x.url)).body).purchase_units[0].amount.value, '47.90');
  const bid = offeneId(env);
  const be = env.DB.roh.prepare('SELECT * FROM bestellung WHERE id = ?').get(bid);
  assert.equal(be.cent, 4790); assert.equal(be.liste_cent, 5988); assert.equal(be.gutschein, 'WILLKOMMEN');
  assert.equal(proben(env, 'SELECT * FROM gutschein_einloesung').length, 0, 'noch nicht bezahlt, noch nicht eingelöst');
  /* Rückkehr */
  const z = await zurueck(env, u, pp, bid);
  assert.match(z.text, /Danke/);
  const bel = env.DB.roh.prepare('SELECT * FROM beleg').get();
  assert.equal(bel.cent, 4790); assert.equal(bel.liste_cent, 5988); assert.equal(bel.gutschein, 'WILLKOMMEN');
  assert.equal(stufeLesen(env, 'kunde@example.org').stufe, 'mittel'); assert.equal(stufeLesen(env, 'kunde@example.org').gueltig_bis, plusJahr(u.t));
  const m = post.gesendet[0];
  assert.ok(m.text.includes('Preis: 59,88 €')); assert.ok(m.text.includes('Rabatt (Code WILLKOMMEN, 20 %): −11,98 €')); assert.ok(m.text.includes('Betrag: 47,90 €'));
  const g = proben(env, 'SELECT eingeloest FROM gutschein WHERE code = ?', 'WILLKOMMEN')[0];
  assert.equal(g.eingeloest, 1); assert.equal(proben(env, 'SELECT * FROM gutschein_einloesung')[0].art, 'rabatt');
  /* Der zweite Kauf (Verlängern) bekommt keinen Rabatt mehr, der Code ist für dieses Konto verbraucht */
  const w = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal', code: 'WILLKOMMEN' }, tok, { fetch: pp.fetch });
  assert.equal(w.status, 400); assert.equal(w.json.feld, 'code'); assert.match(w.json.error, /schon eingelöst/);
  const w2 = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal' }, tok, { fetch: pp.fetch });
  assert.equal(w2.json.betrag, '59,88 €', 'ohne Code der volle Preis');
});

test('Rabatt mit Überweisung: Bank-Betrag nach Abzug, Mail nennt Preis und Rabatt, Freischalten bucht den Beleg mit Rabatt', async () => {
  const env = umgebung(), u = uhr();
  const a = await neuerAdmin(env, u);
  await anlegen(env, u, a, { prozent: 12.5, code: 'HERBST', grenze: 10 });
  const tok = await konto(env, u, 'kunde@example.org'); const post = mail(env);
  const s = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'voll', weg: 'ueberweisung', code: 'HERBST' }, tok);
  assert.equal(s.status, 200, JSON.stringify(s.json));
  assert.equal(s.json.betrag, '104,89 €'); /* 11988 − 1499 (12,5 % von 119,88 = 14,985, gerundet 14,99) */
  const mt = post.gesendet[0].text;
  assert.ok(mt.includes('Betrag: 104,89 €')); assert.ok(mt.includes('Preis 119,88 €')); assert.ok(mt.includes('Rabatt mit Code HERBST: −14,99 €'));
  assert.equal(env.DB.roh.prepare('SELECT cent FROM bestellung').get().cent, 10489);
  /* Freischalt-Seite zeigt Code und Betrag */
  const lst = await ruf(env, u, 'POST', '/freischalten/liste', {}, undefined, {}, { Authorization: 'Bearer ' + ADMIN });
  assert.match(lst.json.bestellungen[0].angebot, /mit Code HERBST/); assert.equal(lst.json.bestellungen[0].betrag, '104,89 €');
  const f = await ruf(env, u, 'POST', '/freischalten/bestaetigen', { referenz: s.json.referenz }, undefined, {}, { Authorization: 'Bearer ' + ADMIN });
  assert.equal(f.status, 200, JSON.stringify(f.json));
  const bel = env.DB.roh.prepare('SELECT * FROM beleg').get();
  assert.equal(bel.cent, 10489); assert.equal(bel.liste_cent, 11988); assert.equal(bel.gutschein, 'HERBST'); assert.equal(bel.weg, 'ueberweisung');
  assert.ok(post.gesendet[post.gesendet.length - 1].text.includes('Rabatt (Code HERBST, 12,5 %): −14,99 €'));
  assert.equal(stufeLesen(env, 'kunde@example.org').stufe, 'voll');
  assert.equal(proben(env, 'SELECT eingeloest FROM gutschein')[0].eingeloest, 1);
});

test('Rabatt gilt nur für Neukunden beim ersten Kauf, nicht für Recherchen, nicht bei Mittel auf Voll, nicht nach früherer Zahlung', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  const a = await neuerAdmin(env, u);
  await anlegen(env, u, a, { prozent: 10, code: 'NEU10', grenze: 100 });
  /* Konto mit laufender Stufe Mittel (zum Beispiel von früher oder geschenkt): kein Neukunde, auch nicht für das Upgrade */
  const t1 = await konto(env, u, 'alt@example.org'); stufeSetzen(env, 'alt@example.org', 'mittel', u.t + 100 * TAG);
  const r1 = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'voll', weg: 'paypal', code: 'NEU10' }, t1, { fetch: pp.fetch });
  assert.equal(r1.status, 400); assert.match(r1.json.error, /nur für Neukunden/);
  assert.equal((await ruf(env, u, 'POST', '/gutschein/pruefen', { code: 'NEU10' }, t1)).status, 400);
  assert.equal(pp.aufrufe.length, 0, 'PayPal wird nicht gefragt');
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM bestellung').get().n, 0);
  /* Konto, dessen Stufe abgelaufen ist, war trotzdem schon Kunde */
  const t2 = await konto(env, u, 'frueher@example.org'); stufeSetzen(env, 'frueher@example.org', 'voll', u.t - 5 * TAG);
  assert.equal((await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'ueberweisung', code: 'NEU10' }, t2)).status, 400);
  /* Konto mit einem Beleg (auch nach Löschen und neu Anlegen mit derselben Adresse) */
  const t3 = await konto(env, u, 'beleg@example.org');
  env.DB.roh.prepare("INSERT INTO beleg (nummer, am, email, produkt, cent, weg, referenz) VALUES ('MM-2025-0001', 1, 'Beleg@Example.org', 'mittel', 5988, 'paypal', 'X1')").run();
  assert.equal((await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal', code: 'NEU10' }, t3, { fetch: pp.fetch })).status, 400);
  /* Neukunde mit Testwoche: Recherchen sind ausgenommen */
  const t4 = await konto(env, u, 'neu@example.org');
  const rs = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'recherche5', weg: 'paypal', code: 'NEU10' }, t4, { fetch: pp.fetch });
  assert.equal(rs.status, 400); assert.match(rs.json.error, /nicht für zusätzliche Recherchen/);
  const ok = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'voll', weg: 'paypal', code: 'NEU10' }, t4, { fetch: pp.fetch });
  assert.equal(ok.status, 200); assert.equal(ok.json.betrag, '107,89 €'); /* 11988 − 1199 */
});

test('Code prüfen: unbekannt, abgelaufen, aufgebraucht, schon eingelöst; Obergrenze bei einem Code für viele', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  const a = await neuerAdmin(env, u);
  assert.equal((await ruf(env, u, 'POST', '/gutschein/pruefen', { code: 'GIBTSNICHT' }, a)).json.error, 'Diesen Code gibt es nicht.');
  assert.equal((await ruf(env, u, 'POST', '/gutschein/pruefen', { code: '' }, a)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/gutschein/pruefen', { code: 'X' }, undefined)).status, 401);
  /* abgelaufen */
  await anlegen(env, u, a, { prozent: 10, code: 'ALT10' });
  env.DB.roh.prepare("UPDATE gutschein SET laeuft_ab = ? WHERE code = 'ALT10'").run(u.t - 1);
  const t = await konto(env, u, 'k1@example.org');
  assert.equal((await ruf(env, u, 'POST', '/gutschein/pruefen', { code: 'ALT10' }, t)).json.error, 'Dieser Code ist abgelaufen.');
  /* Obergrenze 2 */
  await anlegen(env, u, a, { prozent: 10, code: 'ZWEI', grenze: 2 });
  for (const n of [1, 2]) {
    const tk = await konto(env, u, 'neu' + n + '@example.org');
    const s = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal', code: 'ZWEI' }, tk, { fetch: pp.fetch });
    assert.equal(s.status, 200); await zurueck(env, u, pp, offeneId(env));
  }
  assert.equal(proben(env, 'SELECT eingeloest FROM gutschein WHERE code = ?', 'ZWEI')[0].eingeloest, 2);
  const t3 = await konto(env, u, 'neu3@example.org');
  assert.equal((await ruf(env, u, 'POST', '/gutschein/pruefen', { code: 'ZWEI' }, t3)).json.error, 'Dieser Code ist schon aufgebraucht.');
  assert.equal((await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal', code: 'ZWEI' }, t3, { fetch: pp.fetch })).status, 400);
  /* gelöscht */
  await ruf(env, u, 'POST', '/gutschein/loeschen', { code: 'zwei' }, a);
  assert.equal((await ruf(env, u, 'POST', '/gutschein/pruefen', { code: 'ZWEI' }, t3)).json.error, 'Diesen Code gibt es nicht.');
  assert.equal(proben(env, 'SELECT * FROM gutschein_einloesung WHERE code = ?', 'ZWEI').length, 2, 'die Einlösungen bleiben als Spur');
});

test('Zwei offene Bestellungen mit demselben Code zählen nur eine Einlösung', async () => {
  const env = umgebung(), u = uhr();
  const a = await neuerAdmin(env, u);
  await anlegen(env, u, a, { prozent: 10, code: 'DOPPELT', grenze: 5 });
  const tok = await konto(env, u, 'kunde@example.org'); mail(env);
  const s1 = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'ueberweisung', code: 'DOPPELT' }, tok);
  const s2 = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'voll', weg: 'ueberweisung', code: 'DOPPELT' }, tok);
  assert.equal(s1.status, 200); assert.equal(s2.status, 200);
  for (const s of [s1, s2]) await ruf(env, u, 'POST', '/freischalten/bestaetigen', { referenz: s.json.referenz }, undefined, {}, { Authorization: 'Bearer ' + ADMIN });
  assert.equal(proben(env, 'SELECT eingeloest FROM gutschein')[0].eingeloest, 1);
  assert.equal(proben(env, 'SELECT * FROM gutschein_einloesung').length, 1);
  assert.equal(proben(env, 'SELECT * FROM beleg').length, 2, 'beide Zahlungen sind trotzdem verbucht');
});

test('Geschenkcode 100 %: schaltet ohne Zahlung frei, PayPal wird nicht aufgerufen, kein Beleg, Mail an den Beschenkten', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  const a = await neuerAdmin(env, u);
  const code = (await anlegen(env, u, a, { prozent: 100, stufe: 'voll', monate: 3, notiz: 'für Tanja' })).json.code;
  const tok = await konto(env, u, 'tanja@example.org'); const t2 = await konto(env, u, 'anderer@example.org'); const post = mail(env);
  const v = await ruf(env, u, 'POST', '/gutschein/pruefen', { code }, tok);
  assert.equal(v.status, 200); assert.equal(v.json.art, 'frei'); assert.equal(v.json.stufe, 'voll'); assert.equal(v.json.monate, 3); assert.equal(v.json.verlaengert, false);
  assert.equal(stufeLesen(env, 'tanja@example.org'), undefined, 'prüfen ändert nichts');
  /* beim Bezahlen nicht erlaubt: dafür gibt es „einlösen“ */
  const b = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'voll', weg: 'paypal', code }, tok, { fetch: pp.fetch });
  assert.equal(b.status, 400); assert.match(b.json.error, /ohne Bezahlen frei/); assert.equal(pp.aufrufe.length, 0);
  const e = await ruf(env, u, 'POST', '/gutschein/einloesen', { code: code.toLowerCase().replace('-', ' ') }, tok);
  assert.equal(e.status, 200, JSON.stringify(e.json)); assert.equal(e.json.stufe, 'voll'); assert.equal(e.json.bis, monateDazu(u.t, 3));
  const st = stufeLesen(env, 'tanja@example.org');
  assert.equal(st.stufe, 'voll'); assert.equal(st.gueltig_bis, monateDazu(u.t, 3));
  assert.equal(pp.aufrufe.length, 0, 'PayPal nie aufgerufen, keine Gebühr');
  assert.equal(proben(env, 'SELECT * FROM beleg').length, 0); assert.equal(proben(env, 'SELECT * FROM bestellung').length, 0);
  assert.match(post.gesendet[0].text, /Dein MobiMory Voll gilt jetzt bis/); assert.equal(post.gesendet[0].to, 'tanja@example.org');
  assert.equal(proben(env, 'SELECT eingeloest FROM gutschein')[0].eingeloest, 1); assert.equal(proben(env, 'SELECT art FROM gutschein_einloesung')[0].art, 'frei');
  const s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.stufe.id, 'voll'); assert.equal(s.json.grenzen.checks, 10);
  /* nur einmal: persönlicher Code */
  assert.equal((await ruf(env, u, 'POST', '/gutschein/einloesen', { code }, tok)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/gutschein/einloesen', { code }, t2)).json.error, 'Dieser Code ist schon aufgebraucht.');
  assert.equal(stufeLesen(env, 'anderer@example.org'), undefined);
});

test('Geschenkcode: Gleiche Stufe wird angehängt (auch für Bestandskunden), Mittel wird durch Voll ab sofort ersetzt, höhere Stufe lehnt der Dienst ab', async () => {
  const env = umgebung(), u = uhr();
  const a = await neuerAdmin(env, u);
  const codeVon = async (stufe, monate) => (await anlegen(env, u, a, { prozent: 100, stufe, monate })).json.code;
  /* gleiche Stufe: Ende der Laufzeit + 6 Monate; Bestandskunde mit Beleg */
  const t1 = await konto(env, u, 'a@example.org'); const ende = u.t + 40 * TAG; stufeSetzen(env, 'a@example.org', 'mittel', ende);
  env.DB.roh.prepare("INSERT INTO beleg (nummer, am, email, produkt, cent, weg, referenz) VALUES ('MM-2026-0009', 1, 'a@example.org', 'mittel', 5988, 'paypal', 'Z9')").run();
  const c1 = await codeVon('mittel', 6);
  const v1 = await ruf(env, u, 'POST', '/gutschein/pruefen', { code: c1 }, t1);
  assert.equal(v1.json.verlaengert, true);
  const e1 = await ruf(env, u, 'POST', '/gutschein/einloesen', { code: c1 }, t1);
  assert.equal(e1.status, 200); assert.equal(stufeLesen(env, 'a@example.org').gueltig_bis, monateDazu(ende, 6));
  /* Mittel vorhanden, Code gibt Voll: Voll ab sofort, Rest von Mittel nicht angerechnet */
  const t2 = await konto(env, u, 'b@example.org'); stufeSetzen(env, 'b@example.org', 'mittel', u.t + 200 * TAG);
  const c2 = await codeVon('voll', 2);
  const v2 = await ruf(env, u, 'POST', '/gutschein/pruefen', { code: c2 }, t2);
  assert.equal(v2.json.ersetzt, 'Mittel'); assert.equal(v2.json.verlaengert, false);
  assert.equal((await ruf(env, u, 'POST', '/gutschein/einloesen', { code: c2 }, t2)).status, 200);
  const sb = stufeLesen(env, 'b@example.org'); assert.equal(sb.stufe, 'voll'); assert.equal(sb.gueltig_bis, monateDazu(u.t, 2));
  /* höhere Stufe vorhanden: Code abgelehnt und nicht verbraucht */
  const t3 = await konto(env, u, 'c@example.org'); stufeSetzen(env, 'c@example.org', 'voll', u.t + 30 * TAG);
  const c3 = await codeVon('mittel', 12);
  const x = await ruf(env, u, 'POST', '/gutschein/einloesen', { code: c3 }, t3);
  assert.equal(x.status, 400); assert.match(x.json.error, /bereits Voll/); assert.equal((await ruf(env, u, 'POST', '/gutschein/pruefen', { code: c3 }, t3)).status, 400);
  assert.equal(stufeLesen(env, 'c@example.org').stufe, 'voll');
  assert.equal(proben(env, 'SELECT eingeloest FROM gutschein WHERE code = ?', normal(c3))[0].eingeloest, 0, 'nicht verbraucht');
  /* Entwickler braucht keinen Code; abgelaufene Stufe zählt wie keine */
  const t4 = await konto(env, u, 'd@example.org'); stufeSetzen(env, 'd@example.org', 'entwickler', null);
  assert.equal((await ruf(env, u, 'POST', '/gutschein/einloesen', { code: c3 }, t4)).status, 400);
  const t5 = await konto(env, u, 'e@example.org'); stufeSetzen(env, 'e@example.org', 'voll', u.t - TAG);
  assert.equal((await ruf(env, u, 'POST', '/gutschein/einloesen', { code: c3 }, t5)).status, 200);
  assert.equal(stufeLesen(env, 'e@example.org').stufe, 'mittel'); assert.equal(stufeLesen(env, 'e@example.org').gueltig_bis, monateDazu(u.t, 12));
});

test('Geschenkcode: Ein Rabattcode löst nicht allein ein; Monatsende bleibt Monatsende', async () => {
  const env = umgebung(), u = uhr();
  const a = await neuerAdmin(env, u);
  await anlegen(env, u, a, { prozent: 10, code: 'NURRABATT' });
  const t = await konto(env, u, 'k@example.org');
  const r = await ruf(env, u, 'POST', '/gutschein/einloesen', { code: 'NURRABATT' }, t);
  assert.equal(r.status, 400); assert.match(r.json.error, /Rabattcode/);
  assert.equal(monateDazu(Date.UTC(2026, 0, 31), 1), Date.UTC(2026, 1, 28));
  u.t = Date.UTC(2026, 7, 31, 10);
  const c = (await anlegen(env, u, a, { prozent: 100, stufe: 'mittel', monate: 6 })).json.code;
  const t2 = await konto(env, u, 'l@example.org');
  const e = await ruf(env, u, 'POST', '/gutschein/einloesen', { code: c }, t2);
  assert.equal(e.json.bis, monateDazu(u.t, 6)); assert.equal(new Date(e.json.bis).getUTCDate(), 28);
});

test('Bremse: zu viele Versuche mit falschen Codes werden gebremst', async () => {
  const env = umgebung(), u = uhr();
  const t = await konto(env, u, 'raten@example.org');
  let letzter = null;
  for (let i = 0; i < 22; i++) letzter = await ruf(env, u, 'POST', '/gutschein/pruefen', { code: 'RATEN' + i + 'XX' }, t);
  assert.equal(letzter.status, 429); assert.match(letzter.json.error, /zu viele Codes/);
});

test('Ohne die SQL-Zeilen 13f-8 läuft das Bezahlen wie bisher; wer einen Code benutzt, bekommt den Hinweis', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  const a = await neuerAdmin(env, u);
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13f-8.sql'), 'utf8').trim().split('\n');
  /* alter Stand: Spalten und Tabellen entfernen */
  const roh2 = env.DB.roh;
  roh2.exec('DROP TABLE gutschein; DROP TABLE gutschein_einloesung; ALTER TABLE bestellung DROP COLUMN gutschein; ALTER TABLE bestellung DROP COLUMN liste_cent; ALTER TABLE beleg DROP COLUMN gutschein; ALTER TABLE beleg DROP COLUMN liste_cent;');
  const tok = await konto(env, u, 'kunde@example.org');
  const s = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal' }, tok, { fetch: pp.fetch });
  assert.equal(s.status, 200); assert.equal(s.json.betrag, '59,88 €');
  const z = await zurueck(env, u, pp, offeneId(env));
  assert.match(z.text, /Danke/); assert.equal(env.DB.roh.prepare('SELECT cent FROM beleg').get().cent, 5988);
  const ue = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'voll', weg: 'ueberweisung' }, tok);
  assert.equal(ue.status, 200);
  const f = await ruf(env, u, 'POST', '/freischalten/bestaetigen', { referenz: ue.json.referenz }, undefined, {}, { Authorization: 'Bearer ' + ADMIN });
  assert.equal(f.status, 200);
  const c = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal', code: 'IRGENDWAS' }, tok, { fetch: pp.fetch });
  assert.equal(c.status, 503); assert.match(c.json.error, /13f-8\.sql/);
  assert.equal((await ruf(env, u, 'POST', '/gutschein/pruefen', { code: 'IRGENDWAS' }, tok)).status, 503);
  assert.equal((await ruf(env, u, 'GET', '/gutschein/liste', undefined, a)).status, 503);
  const d = await laden();
  const g = await (await d.behandeln(new Request(DIENST + '/gesundheit', { headers: { Origin: APP } }), env, { jetzt: () => Date.UTC(2026, 10, 15) })).json();
  assert.equal(g.bezahlung.gutscheine, false); assert.ok(sql.length === 6);
});

test('Kosten-Wächter: Einnahmen zählen den gezahlten Betrag nach Rabatt, nicht den Listenpreis', async () => {
  const env = umgebung(), u = uhr(), pp = paypal();
  const a = await neuerAdmin(env, u);
  await anlegen(env, u, a, { prozent: 25, code: 'VIERTEL', grenze: 3 });
  const tok = await konto(env, u, 'kunde@example.org'); mail(env);
  await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'mittel', weg: 'paypal', code: 'VIERTEL' }, tok, { fetch: pp.fetch });
  await zurueck(env, u, pp, offeneId(env));
  const d = await laden();
  const w = await d.waechterWerte(env, env.DB, u.t);
  assert.equal(Math.round(w.einnahmenMonat * 100), Math.round(4491 / 12));
});
