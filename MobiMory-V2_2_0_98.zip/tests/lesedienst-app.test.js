'use strict';
/* 2.0.98: Smart Capture mit Lesedienst in der App. Auswertung der Google-Antwort (Drehung, Zeilen, Tabelle der Führerschein-Rückseite, ß), Zustimmung,
   Status je Stufe (ohne Konto kein Smart Capture), Senden nur nach Zustimmung, Stufen-Texte. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche',
  'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'konto', 'erfassung', 'daten'].forEach((m) => require('../js/' + m + '.js'));
const MM = globalThis.MM;
const E = MM.Erfassung, K = MM.Konto;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const JETZT = new Date(2026, 10, 16, 12, 0, 0).toISOString();

/* Ein Dokument (Bd × Hd) als Foto, im Uhrzeigersinn um 90 Grad gedreht: Punkt (x, y) im Dokument liegt im Foto bei (Hd - y, x). */
function foto(zeilen, opt) {
  const Hd = 400, Bd = 600, drehen = !opt || opt.drehen !== false, ws = [];
  zeilen.forEach((z) => z.forEach((c) => {
    const [t, x, y, w, ende] = c, h = 20;
    const ecken = [[x, y], [x + w, y], [x + w, y + h], [x, y + h]];
    const v = (drehen ? ecken.map(([a, b]) => [Hd - b, a]) : ecken).flat();
    ws.push({ t, v, k: 90, e: ende ? 1 : 0 });
  }));
  return { woerter: ws, breite: drehen ? Hd : Bd, hoehe: drehen ? Bd : Hd };
}

test('Google-Antwort: gedrehtes Foto wird aufrecht gelesen, Zeilen nach Lage, Winkel und Größe stimmen', () => {
  const a = foto([[['Name', 40, 40, 60], ['Mustermann', 120, 40, 120, true]], [['Vorname', 40, 80, 70], ['Erika', 120, 80, 60, true]]]);
  const r = E.seitenAusGoogle(a);
  assert.equal(r.winkel, 90); assert.equal(r.breite, 600); assert.equal(r.hoehe, 400);
  assert.deepEqual(r.weitere[0].zeilen.map((z) => z.text), ['Name Mustermann', 'Vorname Erika']);
  assert.deepEqual(r.seite.zeilen.map((z) => z.text), ['Name Mustermann', 'Vorname Erika'], 'die Zeilenenden von Google gelten für die erste Seite');
  const w = r.weitere[0].zeilen[0].woerter[0];
  assert.deepEqual(w.b, { x0: 40, y0: 40, x1: 100, y1: 60 }, 'die Wörter liegen wieder an ihrer Stelle im Dokument');
  const gerade = E.seitenAusGoogle(foto([[['A', 10, 10, 20, true]]], { drehen: false }));
  assert.equal(gerade.winkel, 0);
  /* schräg: kleine Abweichung bis 12 Grad wird auf gerade gestellt, größere bleibt */
  const sch = (grad) => { const rad = grad * Math.PI / 180, c = Math.cos(rad), s = Math.sin(rad), p = (x, y) => [Math.round(100 + c * x - s * y), Math.round(100 + s * x + c * y)];
    return { breite: 400, hoehe: 400, woerter: [{ t: 'Wort', k: 90, e: 1, v: [...p(0, 0), ...p(80, 0), ...p(80, 20), ...p(0, 20)] }] }; };
  assert.equal(E.seitenAusGoogle(sch(5)).winkel, 0);
  assert.ok(Math.abs(E.seitenAusGoogle(sch(30)).winkel - 30) < 1);
  assert.equal(E.seitenAusGoogle({ woerter: [], breite: 0, hoehe: 0 }).seite.zeilen.length, 0);
});

test('Führerschein-Rückseite: Tabelle Klasse, Datum, Schlüsselzahl wird aus den Reihen gelesen; Kopfzeile und Fremdzeilen zählen nicht', () => {
  const kopf = [['9', 40, 40, 20], ['10', 160, 40, 20], ['11', 280, 40, 20], ['12', 400, 40, 20, true]];
  const zeile = (y, kl, a, b, c) => [[kl, 40, y, 30], [a, 160, y, 90], [b, 280, y, 90], [c, 400, y, 40, true]].filter((x) => x[0]);
  const a = foto([kopf, zeile(80, 'AM', '01.08.2005', '*', ''), zeile(120, 'B', '01.08.2005', '31.07.2030', '78'), zeile(160, 'C1', '12.03.2010', '01.08.2027', '95'), [['Hinweis', 40, 250, 80, true]]]);
  const r = E.seitenAusGoogle(a), t = E.klassenTabelle(r.weitere[0], '2026-11-16');
  assert.deepEqual(t.zeilen.map((x) => x.klasse), ['AM', 'B', 'C1']);
  assert.deepEqual(t.zeilen[1], { klasse: 'B', von: '2005-08-01', bis: '2030-07-31', zusatz: ['78'] });
  assert.equal(t.zeilen[0].bis, '');
  assert.equal(E.klassenTabelleText(t.zeilen), 'AM: ab 01.08.2005; B: ab 01.08.2005 bis 31.07.2030, Schlüsselzahl 78; C1: ab 12.03.2010 bis 01.08.2027, Schlüsselzahl 95');
  /* ohne Daten in der Zeile keine Zeile; zweimal dieselbe Klasse zählt einmal */
  assert.equal(E.klassenTabelle(E.seitenAusGoogle(foto([[['B', 40, 40, 20], ['Auto', 100, 40, 40, true]]])).weitere[0], '2026-11-16').zeilen.length, 0);
  assert.equal(E.klassenTabelle(E.seitenAusGoogle(foto([zeile(40, 'B', '01.08.2005', '*', ''), zeile(80, 'B', '02.08.2005', '*', '')])).weitere[0], '2026-11-16').zeilen.length, 1);
  /* Die Art Führerschein liefert daraus die Angaben „Klassen“ und „Klassen mit Datum und Schlüsselzahl“ */
  const f = E.seiteLesen(r.weitere[0], { heute: '2026-11-16', artId: 'DE_FEV_FUEHRERSCHEIN_EU' }).felder;
  assert.equal(f.klassenDetails[0].quelle, 'tabelle'); assert.match(f.klassenDetails[0].wert, /^AM: ab 01\.08\.2005; B: ab/);
  assert.equal(f.klassen[0].wert, 'AM/B/C1');
  assert.ok(E.ARTEN.DE_FEV_FUEHRERSCHEIN_EU.angaben.some((x) => x.rolle === 'klassenDetails'));
  const z = E.zusammenfuehren([{ felder: f }]);
  assert.equal(z.klassenDetails.status, 'sicher'); assert.equal(z.klassenDetails.quelle, 'tabelle');
});

test('ß und B: gedrucktes „GroBmann“ wird mit der Maschinenzeile („GROSSMANN“) zu „Großmann“; ohne Übereinstimmung bleibt alles', () => {
  const k = [{ wert: 'GroBmann', quelle: 'marke', konf: 90, ok: true, hinweis: '' }, { wert: 'Grossmann', quelle: 'mrz', konf: 80, ok: true, hinweis: '' }];
  assert.equal(E.szAbgleich(k), 1); assert.equal(k[0].wert, 'Großmann'); assert.match(k[0].hinweis, /Maschinenzeile/);
  const z = E.zusammenfuehren([{ felder: { nachname: [{ wert: 'MeiBner', quelle: 'marke', konf: 90, ok: true }, { wert: 'Meissner', quelle: 'mrz', konf: 80, ok: true }] } }]);
  assert.equal(z.nachname.wert, 'Meißner'); assert.equal(z.nachname.status, 'sicher');
  const ander = [{ wert: 'Bauer', quelle: 'marke' }, { wert: 'Bauer', quelle: 'mrz' }]; assert.equal(E.szAbgleich(ander), 0); assert.equal(ander[0].wert, 'Bauer');
  const fremd = [{ wert: 'GroBmann', quelle: 'marke' }, { wert: 'Schneider', quelle: 'mrz' }]; assert.equal(E.szAbgleich(fremd), 0); assert.equal(fremd[0].wert, 'GroBmann');
  assert.equal(E.szAbgleich([{ wert: 'GroBmann', quelle: 'marke' }]), 0, 'ohne Maschinenzeile wird nichts geraten');
});

test('Rechteck: der Text in einem Bereich der Seite (für „Stelle markieren“ beim Lesedienst)', () => {
  const r = E.seitenAusGoogle(foto([[['Name', 40, 40, 60], ['Mustermann', 120, 40, 120, true]], [['Vorname', 40, 200, 70], ['Erika', 120, 200, 60, true]]]));
  const seite = r.weitere[0];
  assert.equal(E.rechteckText(seite, { x0: 0.15, y0: 0.05, x1: 0.5, y1: 0.2 }), 'Mustermann');
  assert.equal(E.rechteckText(seite, { x0: 0, y0: 0.45, x1: 0.6, y1: 0.65 }), 'Vorname Erika');
  assert.equal(E.rechteckText(seite, { x0: 0.8, y0: 0.8, x1: 1, y1: 1 }), '');
});

test('Personalausweis: die Maschinenzeile aus der Antwort des Lesedienstes wird ausgewertet (Prüfziffern, ß als SS)', () => {
  const z = (y, t) => [[t, 20, y, 560, true]];
  const a = foto([z(300, 'IDD<<T220001293<<<<<<<<<<<<<<<'), z(330, '6408125<2710314D<<<<<<<<<<<<<<<4'), z(360, 'MUSTERMANN<<ERIKA<<<<<<<<<<<<<<'), [['PERSONALAUSWEIS', 40, 40, 200, true]]], { drehen: false });
  const r = E.seitenAusGoogle(a);
  const m = E.mrzLesen(r.seite.zeilen.map((x) => x.text), '2026-11-16');
  assert.ok(m, 'Maschinenzeile gefunden'); assert.equal(m.nachname, 'MUSTERMANN'); assert.equal(m.vorname, 'ERIKA'); assert.equal(m.nummer, 'T22000129'); assert.equal(m.geburt, '1964-08-12'); assert.equal(m.pruefziffern.geburt, true);
  const f = E.seiteLesen(r.seite, { heute: '2026-11-16' });
  assert.equal(f.artId, 'DE_PAUSWG_PERSONALAUSWEIS');
});

async function neu(kontoFn, dok) {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  if (kontoFn) d.kontoAnfrageFn = kontoFn;
  if (dok !== false) await d.rcSchreiben(Object.assign({ kontoToken: 'tok', kontoEmail: 'a@example.org' }, dok || {}));
  return d;
}
const stufe = (id, name, scans, genutzt) => ({ ok: true, stufe: { id, name, bis: null }, grenzen: { geraete: 4, checks: 3, routen: 100, fahrzeuge: 3, online: true, scans }, nutzung: { geraete: 1, checks: 0, checksFrei: 3, extra: 0, routen: 0, routenFrei: 100, routenExtra: 0, scans: genutzt, scansFrei: scans === null ? null : Math.max(0, scans - genutzt) }, rolle: null });

test('Status: ohne Konto kein Smart Capture; Basic gesperrt; Testwoche mit 10 Scans; Mittel ohne Zustimmung nur Gerät; mit Zustimmung Lesedienst; Grenze erreicht nur Gerät', async () => {
  let antwort = stufe('mittel', 'Mittel', 50, 3), aufrufe = 0;
  const fn = async () => { aufrufe++; if (antwort instanceof Error) throw antwort; return antwort; };
  const ohne = await neu(fn, false);
  const s0 = await ohne.lesedienstStatus();
  assert.deepEqual([s0.modus, s0.grund], ['gesperrt', 'anmeldung']); assert.equal(aufrufe, 0, 'ohne Anmeldung wird nichts gefragt'); assert.match(s0.text, /melde dich zuerst an/i);
  const d = await neu(fn);
  antwort = stufe('basic', 'Basic', 0, 0); assert.deepEqual([(await d.lesedienstStatus()).modus, (await d.lesedienstStatus()).grund], ['gesperrt', 'stufe']);
  antwort = stufe('test', 'Testwoche', 10, 4); assert.deepEqual([(await d.lesedienstStatus()).modus, (await d.lesedienstStatus()).frei], ['geraet', 6]);
  antwort = stufe('mittel', 'Mittel', 50, 3);
  const z = await d.lesedienstStatus(); assert.deepEqual([z.modus, z.grund, z.frei, z.grenze], ['geraet', 'zustimmung', 47, 50]);
  assert.equal((await d.lesedienstZustimmung()).gilt, false);
  await d.lesedienstZustimmen();
  const g = await d.lesedienstStatus(); assert.deepEqual([g.modus, g.frei, g.grenze, g.genutzt, g.zugestimmt], ['google', 47, 50, 3, true]); assert.match(g.zugestimmtAm, /^2026-11-16/);
  antwort = stufe('mittel', 'Mittel', 50, 50);
  const l = await d.lesedienstStatus(); assert.deepEqual([l.modus, l.grund, l.frei], ['geraet', 'limit', 0]); assert.match(l.text, /50 von 50/);
  antwort = stufe('voll', 'Voll', 100, 99); assert.equal((await d.lesedienstStatus()).frei, 1);
  antwort = stufe('entwickler', 'Entwickler', null, 12);
  const e = await d.lesedienstStatus(); assert.deepEqual([e.modus, e.frei], ['google', null]);
  await d.lesedienstWiderrufen();
  assert.equal((await d.lesedienstZustimmung()).gilt, false); assert.equal((await d.lesedienstStatus()).grund, 'zustimmung');
  assert.equal((await d.lesedienstZustimmung()).verlauf.map((x) => x.aktion).join(), 'zugestimmt,widerrufen', 'der Verlauf bleibt mit Datum');
});

test('Status ohne Netz: die zuletzt bekannte Stufe gilt (nur Gerät); ohne bekannte Stufe gesperrt; abgelaufene Anmeldung gesperrt', async () => {
  let modus = 'ok';
  const fn = async () => { if (modus === 'netz') throw new Error('kein Netz'); if (modus === '401') { const e = new Error('abgelaufen'); e.status = 401; throw e; } return stufe('mittel', 'Mittel', 50, 0); };
  const d = await neu(fn);
  modus = 'netz'; assert.equal((await d.lesedienstStatus()).modus, 'gesperrt', 'noch nie geprüft');
  modus = 'ok'; await d.kontoStufe();
  modus = 'netz'; const o = await d.lesedienstStatus(); assert.deepEqual([o.modus, o.grund], ['geraet', 'offline']);
  modus = '401'; const a = await d.lesedienstStatus(); assert.deepEqual([a.modus, a.grund], ['gesperrt', 'anmeldung']);
  const b = await neu(async () => { if (modus === 'ok') return stufe('basic', 'Basic', 0, 0); throw new Error('kein Netz'); });
  modus = 'ok'; await b.kontoStufe(); modus = 'netz'; assert.equal((await b.lesedienstStatus()).grund, 'stufe', 'Basic bleibt auch ohne Netz gesperrt');
});

test('Senden: ohne Zustimmung geht nichts hinaus; mit Zustimmung POST /lesen/senden mit Bild und Zustimmung; Fehlerarten', async () => {
  const aufrufe = []; let modus = 'ok';
  const fn = async (url, methode, token, body) => {
    aufrufe.push({ url, methode, token, body });
    if (modus === '402') { const e = new Error('aufgebraucht'); e.status = 402; throw e; }
    if (modus === '401') { const e = new Error('abgelaufen'); e.status = 401; throw e; }
    if (modus === '502') { const e = new Error('Google'); e.status = 502; throw e; }
    if (modus === 'leer') return { ok: true };
    return { ok: true, woerter: [{ t: 'Name', v: [0, 0, 1, 0, 1, 1, 0, 1], k: 90, e: 1 }], breite: 10, hoehe: 10, kontingent: { genutzt: 4, grenze: 50, stufe: 'mittel', monat: '2026-11' } };
  };
  const d = await neu(fn);
  const ohne = await d.lesedienstSenden('QUJD'); assert.deepEqual([ohne.ok, ohne.art], [false, 'zustimmung']); assert.equal(aufrufe.length, 0);
  await d.lesedienstZustimmen();
  const r = await d.lesedienstSenden('QUJD');
  assert.equal(r.ok, true); assert.equal(r.antwort.kontingent.genutzt, 4);
  assert.equal(aufrufe.length, 1); assert.ok(aufrufe[0].url.endsWith('/lesen/senden')); assert.equal(aufrufe[0].methode, 'POST'); assert.equal(aufrufe[0].token, 'tok'); assert.deepEqual(aufrufe[0].body, { bild: 'QUJD', zustimmung: true });
  modus = '402'; assert.equal((await d.lesedienstSenden('QUJD')).art, 'kontingent');
  modus = '401'; assert.equal((await d.lesedienstSenden('QUJD')).art, 'anmeldung');
  modus = '502'; assert.equal((await d.lesedienstSenden('QUJD')).art, 'dienst');
  modus = 'leer'; assert.equal((await d.lesedienstSenden('QUJD')).art, 'dienst');
  /* Nichts davon landet im Geräte-Dokument außer der Zustimmung */
  const dok = await d.rcGeraet(); assert.ok(!JSON.stringify(dok).includes('QUJD'));
});

test('Konto: Scan-Grenzen je Stufe, Texte, freie Scans; Angebote nennen Smart Capture', () => {
  assert.deepEqual(['basic', 'test', 'mittel', 'voll', 'entwickler'].map((k) => K.STUFEN[k].scans), [0, 10, 50, 100, null]);
  assert.equal(K.scanFrei({ grenzen: { scans: 50 }, nutzung: { scans: 3 } }), 47); assert.equal(K.scanFrei({ grenzen: { scans: null }, nutzung: {} }), null); assert.equal(K.scanFrei({ grenzen: { scans: 0 }, nutzung: {} }), 0);
  const zeilen = (id, scans, n) => K.stufeZeilen({ stufe: { id, name: K.STUFEN[id].name }, grenzen: K.STUFEN[id], nutzung: Object.assign({ geraete: 1, checks: 0, checksFrei: 0, routen: 0 }, n) }).join('\n');
  assert.match(zeilen('mittel', 50, { scans: 3, scansFrei: 47 }), /Smart Capture: 3 von 50 Scans in diesem Monat benutzt, 47 frei/);
  assert.match(zeilen('basic', 0, {}), /Smart Capture \(Dokumente von Foto lesen\): In dieser Stufe nicht dabei/);
  assert.match(zeilen('entwickler', null, { scans: 2 }), /Smart Capture: 2 Scans in diesem Monat, ohne Grenze/);
  assert.match(K.angebote({ stufe: { id: 'basic' }, grenzen: K.STUFEN.basic })[0].text, /50 Scans im Monat für Smart Capture/);
  assert.match(K.TEXT_LESEDIENST_ZUSTIMMUNG, /weder bei Google noch bei MobiMory gespeichert/); assert.match(K.TEXT_LESEDIENST_ZUSTIMMUNG, /widerrufen/); assert.match(K.TEXT_LESEN_HINWEIS, /nicht gespeichert/);
});

test('Ansicht: Sperre ohne Konto, Hinweis vor jedem Foto mit Abbrechen, Rückfall aufs Gerät, keine gelernten Stellen beim Lesedienst', () => {
  const a = lesen('js/erfassung-ansicht.js'), m = lesen('js/erfassung-motor.js');
  assert.match(a, /lesedienstStatus\(\)/); assert.match(a, /seiteGesperrt/); assert.match(a, /vorLesenFragen/); assert.match(a, /text: 'Abbrechen'/); assert.match(a, /Stattdessen auf dem Gerät lesen/);
  assert.match(a, /if \(!erg\.artId \|\| r\.quelle === 'google'\) return Promise\.resolve\(\)/);
  assert.match(a, /Foto wurde nicht gesendet/);
  assert.match(m, /lesenGoogle: lesenGoogle/); assert.match(m, /2200/);
  /* der Zugangsschlüssel steht nirgends in der App */
  ['js/erfassung-ansicht.js', 'js/erfassung-motor.js', 'js/daten.js', 'js/konto.js', 'index.html', 'sw.js'].forEach((f) => assert.ok(!/GOOGLE_VISION_KEY|AIza[0-9A-Za-z_-]{20}|googleapis\.com/.test(lesen(f)), f));
});
