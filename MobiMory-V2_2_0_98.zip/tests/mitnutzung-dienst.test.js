'use strict';
/* 2.0.75 (Bau 1, Dienst 13f-2): Mitnutzung. Rechte je Freigabe, Erfassen durch den Gast (Kilometer, Fahrzeugkosten, Störung) im Fahrzeug des Besitzers, Kontroll-Code durch den Gast, ausgenommene Dokumente. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

const APP = 'https://app.example.org';
const PW = 'Sehr-sicheres-Passwort-1';
const TAG = 24 * 60 * 60 * 1000;
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) { return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, extra || {}); }
function uhr() { const u = { t: Date.UTC(2026, 10, 11, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
const text = (s) => new TextEncoder().encode(s);

async function roh(env, u, methode, weg, body, token, ip) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': ip || '203.0.113.5' };
  if (body !== undefined && !(body instanceof Uint8Array)) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  const bytes = body instanceof Uint8Array;
  if (bytes) kopf['Content-Length'] = String(body.length);
  return d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : (bytes ? body : JSON.stringify(body)) }), env, { jetzt: u.jetzt });
}
async function ruf(env, u, methode, weg, body, token, ip) { const r = await roh(env, u, methode, weg, body, token, ip); return { status: r.status, json: await r.json() }; }
async function konto(env, u, email) {
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email, passwort: PW });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode });
  return b.json.token;
}
/* Ein Datensatz in der Form des Abgleichs. */
function satz(tabelle, o) { return { tabelle, id: o.id, basis: 0, nutzlast: JSON.stringify(o) }; }
async function senden(env, u, tok, liste) {
  const r = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: liste }, tok);
  assert.equal(r.status, 200, JSON.stringify(r.json));
  return r.json;
}

/* Besitzer mit zwei Fahrzeugen: F1 mit Angaben, Frist, Zähler, Dokument samt Datei, Kosten, Nachweis, Ereignis; F2 mit einem Dokument. */
async function besitzer(env, u) {
  const tok = await konto(env, u, 'besitzer@example.org');
  await senden(env, u, tok, [
    satz('fahrzeuge', { id: 'fz-1', datenraumId: '@', art: 'wohnmobil', erstelltAm: 1 }),
    satz('eintraege', { id: 'en-1', fahrzeugId: 'fz-1', nr: 1, werte: { bezeichnung: 'Alter Name' }, erstelltAm: 1 }),
    satz('eintraege', { id: 'en-2', fahrzeugId: 'fz-1', nr: 2, werte: { bezeichnung: 'Mein Wohnmobil', kennzeichen: 'LB-AB 123' }, erstelltAm: 2 }),
    satz('fristen', { id: 'fr-1', fahrzeugId: 'fz-1', komponenteId: null, erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-fr-1', objektTyp: 'frist', objektId: 'fr-1', nr: 1, werte: { bezeichnung: 'Hauptuntersuchung', kalenderWert: 2, kalenderEinheit: 'jahre' }, erstelltAm: 1 }),
    satz('durchfuehrungen', { id: 'du-1', fristId: 'fr-1', datum: '2025-03-01', zaehlerstand: null, art: 'erledigt', erstelltAm: 1 }),
    satz('zaehler', { id: 'za-1', fahrzeugId: 'fz-1', komponenteId: null, art: 'strecke', erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-za-1', objektTyp: 'zaehler', objektId: 'za-1', nr: 1, werte: { bezeichnung: 'Kilometerstand' }, erstelltAm: 1 }),
    satz('zaehlerstaende', { id: 'zs-1', zaehlerId: 'za-1', nr: 1, wert: 51000, datum: '2026-10-01', erstelltAm: 1 }),
    satz('dokumente', { id: 'do-1', fahrzeugId: 'fz-1', komponenteId: null, vorgangId: null, erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-do-1', objektTyp: 'dokument', objektId: 'do-1', nr: 1, werte: { bezeichnung: 'Fahrzeugschein' }, erstelltAm: 1 }),
    satz('dateien', { id: 'da-1', dokumentId: 'do-1', name: 'schein.pdf', mime: 'application/pdf', groesse: 11, erstelltAm: 1 }),
    satz('dokumente', { id: 'do-2', fahrzeugId: 'fz-2', komponenteId: null, vorgangId: null, erstelltAm: 1 }),
    satz('dateien', { id: 'da-2', dokumentId: 'do-2', name: 'anderes.pdf', mime: 'application/pdf', groesse: 7, erstelltAm: 1 }),
    satz('kosten', { id: 'ko-1', datenraumId: '@', fahrzeugId: 'fz-1', erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-ko-1', objektTyp: 'kosten', objektId: 'ko-1', nr: 1, werte: { betrag: 99 }, erstelltAm: 1 }),
    satz('nachweise', { id: 'na-1', datenraumId: '@', artId: 'x', besitzerTyp: 'person', besitzerId: 'pe-1', erstelltAm: 1 }),
    satz('fahrzeuge', { id: 'fz-2', datenraumId: '@', art: 'boot', erstelltAm: 1 }),
    satz('aktivitaeten', { id: 'ak-1', datenraumId: '@', erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-ak-1', objektTyp: 'aktivitaet', objektId: 'ak-1', nr: 1, werte: { fahrzeugId: 'fz-1', vonDatum: '2026-11-01' }, erstelltAm: 1 }),
    satz('tagespruefungen', { id: 'tp-1', datenraumId: '@', aktivitaetId: 'ak-1', abschnittId: 'ab-1', stand: { geprueftAm: '2026-11-01T08:00', tagesbeginn: '2026-11-01', ergebnis: 'ok', fristen: { betroffen: 0, sperre: 0, eingeschraenkt: 0 } }, erstelltAm: 5 }),
    satz('tagespruefungen', { id: 'tp-0', datenraumId: '@', aktivitaetId: 'ak-1', abschnittId: 'ab-0', stand: { geprueftAm: '2026-10-01T08:00', tagesbeginn: '2026-10-01', ergebnis: 'sperre', fristen: { betroffen: 1, sperre: 1, eingeschraenkt: 0 } }, erstelltAm: 3 }),
    satz('ereignisse', { id: 'er-1', datenraumId: '@', aktivitaetId: 'ak-1', abschnittId: 'ab-1', erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-er-1', objektTyp: 'ereignis', objektId: 'er-1', nr: 1, werte: { text: 'Standort geheim', breite: 48.1, laenge: 9.1 }, erstelltAm: 1 })
  ]);
  const me = await ruf(env, u, 'GET', '/konto/ich', undefined, tok);
  const dr = me.json.datenraum.id;
  assert.equal((await roh(env, u, 'PUT', '/datei?tabelle=dateien&id=da-1', text('Inhalt-Pdf-1'.slice(0, 11)), tok)).status, 200);
  assert.equal((await roh(env, u, 'PUT', '/datei?tabelle=dateien&id=da-2', text('anderes!'.slice(0, 7)), tok)).status, 200);
  assert.equal((await roh(env, u, 'PUT', '/datei?tabelle=nachweisdateien&id=nd-1&verschluesselt=1', text('geheim'), tok)).status, 200);
  return { tok, dr };
}
async function einladen(env, u, tok, extra) {
  return ruf(env, u, 'POST', '/freigabe/einladen', Object.assign({ fahrzeugId: 'fz-1', email: 'gast@example.org', bis: '2027-03-31', nachweisArt: 'Führerschein', nachweisBis: '', bestaetigt: true }, extra || {}), tok);
}
/* Gast eingeladen und angenommen. */
async function freigabe(env, u, b, extra) {
  const gast = await konto(env, u, 'gast@example.org');
  const e = await einladen(env, u, b.tok, extra);
  assert.equal(e.status, 200, JSON.stringify(e.json));
  const a = await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, gast);
  assert.equal(a.status, 200, JSON.stringify(a.json));
  return { gast, id: e.json.id, code: e.json.entwicklungsCode };
}
const tabellenVon = (j) => j.datensaetze.map((x) => x.tabelle);

const MIT = { rechte: 'mitnutzen', gastName: 'Anna' };
async function erfassen(env, u, gast, freigabeId, b) { return ruf(env, u, 'POST', '/geteilt/erfassen', Object.assign({ freigabe: freigabeId }, b), gast); }
async function aenderungen(env, u, tok) { return (await ruf(env, u, 'GET', '/abgleich/aenderungen?seit=0', undefined, tok)).json.eintraege; }
const nutz = (e) => JSON.parse(e.nutzlast);

test('Rechte: Einladung ohne Angabe heißt „lesen“; Mitnutzung braucht einen Namen; falsche Rechte werden abgelehnt', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  const lesen = await freigabe(env, u, b);
  const l = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, b.tok)).json;
  assert.equal(l.gegeben[0].rechte, 'lesen');
  const gast = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, lesen.gast)).json;
  assert.equal(gast.erhalten[0].rechte, 'lesen');
  const ohneName = await einladen(env, u, b.tok, { email: 'kind@example.org', rechte: 'mitnutzen' });
  assert.equal(ohneName.status, 400); assert.equal(ohneName.json.feld, 'gastName');
  const falsch = await einladen(env, u, b.tok, { email: 'kind@example.org', rechte: 'alles' });
  assert.equal(falsch.status, 400); assert.equal(falsch.json.feld, 'rechte');
  const zuLang = await einladen(env, u, b.tok, { email: 'kind@example.org', rechte: 'mitnutzen', gastName: 'x'.repeat(41) });
  assert.equal(zuLang.status, 400);
  const ok = await einladen(env, u, b.tok, Object.assign({ email: 'kind@example.org' }, MIT));
  assert.equal(ok.status, 200, JSON.stringify(ok.json));
  const l2 = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, b.tok)).json;
  const kind = l2.gegeben.find((x) => x.email === 'kind@example.org');
  assert.equal(kind.rechte, 'mitnutzen'); assert.equal(kind.gastName, 'Anna');
});

test('Nur lesen: Der Gast kann nichts erfassen und keinen Kontroll-Code erzeugen', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b);
  const r = await erfassen(env, u, g.gast, g.id, { art: 'kosten', gruppe: 'variabel', bezeichnung: 'Diesel', betrag: 50 });
  assert.equal(r.status, 403);
  assert.equal((await ruf(env, u, 'POST', '/geteilt/kontrolle', { freigabe: g.id }, g.gast)).status, 403);
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast)).json.eigene, undefined);
});

test('Kilometer: Der Gast trägt einen Stand ein, er erscheint mit Namen beim Besitzer; niedrigerer Stand, fremder Zähler, Zukunft werden abgelehnt', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b, MIT);
  await senden(env, u, b.tok, [satz('zaehler', { id: 'za-2', fahrzeugId: 'fz-2', komponenteId: null, art: 'strecke', erstelltAm: 1 })]);
  const ok = await erfassen(env, u, g.gast, g.id, { art: 'kilometer', zaehlerId: 'za-1', wert: 51800, datum: '2026-11-11' });
  assert.equal(ok.status, 200, JSON.stringify(ok.json));
  const neu = (await aenderungen(env, u, b.tok)).find((e) => e.id === ok.json.id);
  assert.equal(neu.tabelle, 'zaehlerstaende');
  const o = nutz(neu);
  assert.equal(o.zaehlerId, 'za-1'); assert.equal(o.wert, 51800); assert.equal(o.nr, 2, 'nach dem bisherigen Stand Nr. 1'); assert.equal(o.gast.name, 'Anna'); assert.equal(o.gast.freigabe, g.id);
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'kilometer', zaehlerId: 'za-1', wert: 51000, datum: '2026-11-11' })).status, 400, 'niedriger als 51800');
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'kilometer', zaehlerId: 'za-2', wert: 5, datum: '2026-11-11' })).status, 404, 'Zähler eines anderen Fahrzeugs');
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'kilometer', zaehlerId: 'za-1', wert: 52000, datum: '2026-12-31' })).status, 400, 'Datum in der Zukunft');
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'kilometer', zaehlerId: 'za-1', wert: 'abc' })).status, 400);
  const zwei = await erfassen(env, u, g.gast, g.id, { art: 'kilometer', zaehlerId: 'za-1', wert: 52000 });
  assert.equal(zwei.status, 200);
  assert.equal(nutz((await aenderungen(env, u, b.tok)).find((e) => e.id === zwei.json.id)).nr, 3);
});

test('Kosten: variabel und Instandhaltung ja, Fixkosten und Reisekasse nein; Eintrag mit Namen im Fahrzeug des Besitzers', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b, MIT);
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'kosten', gruppe: 'fix', bezeichnung: 'Versicherung', betrag: 500 })).status, 403);
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'kosten', gruppe: 'reisekasse', bezeichnung: 'Eis', betrag: 3 })).status, 400);
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'kosten', gruppe: 'variabel', bezeichnung: 'Diesel', betrag: 0 })).status, 400);
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'kosten', gruppe: 'variabel', bezeichnung: '', betrag: 5 })).status, 400);
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'kosten', gruppe: 'variabel', kostenart: 'teile', bezeichnung: 'Diesel', betrag: 5 })).status, 400, 'Art passt nicht zur Gruppe');
  const ok = await erfassen(env, u, g.gast, g.id, { art: 'kosten', gruppe: 'variabel', kostenart: 'treibstoff', bezeichnung: 'Diesel Schweden', betrag: '82,50', datum: '2026-11-10', ortText: 'Malmö' });
  assert.equal(ok.status, 200, JSON.stringify(ok.json));
  const inst = await erfassen(env, u, g.gast, g.id, { art: 'kosten', gruppe: 'instandhaltung', kostenart: 'teile', bezeichnung: 'Glühlampe', betrag: 7.9 });
  assert.equal(inst.status, 200);
  const alle = await aenderungen(env, u, b.tok);
  const ko = nutz(alle.find((e) => e.tabelle === 'kosten' && e.id === ok.json.id));
  assert.equal(ko.fahrzeugId, 'fz-1'); assert.equal(ko.datenraumId, '@'); assert.equal(ko.gast.name, 'Anna');
  const vl = alle.map(nutz).find((x) => x.objektTyp === 'kosten' && x.objektId === ok.json.id);
  assert.equal(vl.nr, 1); assert.equal(vl.werte.betrag, 82.5); assert.equal(vl.werte.gruppe, 'variabel'); assert.equal(vl.werte.rhythmus, 'einmalig'); assert.equal(vl.werte.ortText, 'Malmö'); assert.equal(vl.gast.name, 'Anna');
  assert.ok(!('notiz' in vl.werte), 'nichts, was nur auf dem Gerät bleibt');
});

test('Störung: Der Gast meldet sie, sie liegt als offener Vorgang beim Besitzer; die Einschränkung wird geprüft', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b, MIT);
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'stoerung', bezeichnung: 'Kühlschrank geht nicht', auswirkung: 'schlimm' })).status, 400);
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'stoerung', bezeichnung: '', auswirkung: 'keine' })).status, 400);
  const ok = await erfassen(env, u, g.gast, g.id, { art: 'stoerung', bezeichnung: 'Kühlschrank geht nicht', beschreibung: 'Seit Malmö aus', auswirkung: 'bedingt' });
  assert.equal(ok.status, 200, JSON.stringify(ok.json));
  const alle = await aenderungen(env, u, b.tok);
  const vg = nutz(alle.find((e) => e.tabelle === 'vorgaenge' && e.id === ok.json.id));
  assert.equal(vg.fahrzeugId, 'fz-1'); assert.equal(vg.gast.name, 'Anna');
  const vl = alle.map(nutz).find((x) => x.objektTyp === 'vorgang' && x.objektId === ok.json.id);
  assert.equal(vl.werte.art, 'stoerung'); assert.equal(vl.werte.status, 'offen'); assert.equal(vl.werte.auswirkung, 'bedingt'); assert.equal(vl.werte.gemeldetAm, '2026-11-11');
});

test('Der Gast sieht seine eigenen Einträge, aber nie die Kosten des Besitzers; unbekannte Art wird abgelehnt', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b, MIT);
  await erfassen(env, u, g.gast, g.id, { art: 'kilometer', zaehlerId: 'za-1', wert: 52000 });
  await erfassen(env, u, g.gast, g.id, { art: 'kosten', gruppe: 'variabel', bezeichnung: 'Maut', betrag: 12 });
  await erfassen(env, u, g.gast, g.id, { art: 'stoerung', bezeichnung: 'Licht', auswirkung: 'keine' });
  assert.equal((await erfassen(env, u, g.gast, g.id, { art: 'verkaufen' })).status, 400);
  const r = (await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast)).json;
  assert.equal(r.rechte, 'mitnutzen');
  assert.deepEqual(r.eigene.map((x) => x.art).sort(), ['kilometer', 'kosten', 'stoerung']);
  const kosten = r.eigene.find((x) => x.art === 'kosten'); assert.equal(kosten.betrag, 12); assert.equal(kosten.titel, 'Maut');
  assert.ok(!JSON.stringify(r.datensaetze).includes('"betrag":99'), 'Kosten des Besitzers bleiben verborgen');
  assert.ok(!tabellenVon(r).includes('kosten'));
  /* Ein zweiter Gast sieht die Einträge des ersten nicht. */
  const zweiter = await konto(env, u, 'kind2@example.org');
  const e = await einladen(env, u, b.tok, { email: 'kind2@example.org', rechte: 'mitnutzen', gastName: 'Ben' });
  await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, zweiter);
  const r2 = (await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + e.json.id, undefined, zweiter)).json;
  assert.deepEqual(r2.eigene, []);
  assert.equal((await erfassen(env, u, zweiter, g.id, { art: 'kosten', gruppe: 'variabel', bezeichnung: 'x', betrag: 1 })).status, 403, 'fremde Freigabe');
});

test('Rechte enden mit der Freigabe: Widerruf, Ablauf, noch nicht begonnen', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b, MIT);
  const eingabe = { art: 'kosten', gruppe: 'variabel', bezeichnung: 'Diesel', betrag: 10 };
  assert.equal((await erfassen(env, u, g.gast, g.id, eingabe)).status, 200);
  assert.equal((await ruf(env, u, 'POST', '/freigabe/widerrufen', { id: g.id }, b.tok)).status, 200);
  assert.equal((await erfassen(env, u, g.gast, g.id, eingabe)).status, 403);
  assert.equal((await ruf(env, u, 'POST', '/geteilt/kontrolle', { freigabe: g.id }, g.gast)).status, 403);
  const env2 = umgebung(), u2 = uhr(), b2 = await besitzer(env2, u2), g2 = await freigabe(env2, u2, b2, Object.assign({ ab: '2026-11-20', bis: '2026-12-31' }, MIT));
  assert.equal((await erfassen(env2, u2, g2.gast, g2.id, eingabe)).status, 403, 'beginnt erst später');
  u2.t = Date.UTC(2026, 10, 25, 12);
  assert.equal((await erfassen(env2, u2, g2.gast, g2.id, eingabe)).status, 200);
  u2.t = Date.UTC(2027, 0, 2, 12);
  assert.equal((await erfassen(env2, u2, g2.gast, g2.id, eingabe)).status, 403, 'abgelaufen');
});

test('Dokumente ausnehmen: Dokument, Verlauf und Datei gehen nicht an den Gast; der Besitzer und andere Dokumente bleiben', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  await senden(env, u, b.tok, [
    satz('dokumente', { id: 'do-3', fahrzeugId: 'fz-1', komponenteId: null, vorgangId: null, erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-do-3', objektTyp: 'dokument', objektId: 'do-3', nr: 1, werte: { bezeichnung: 'Kaufvertrag' }, erstelltAm: 1 }),
    satz('dateien', { id: 'da-3', dokumentId: 'do-3', name: 'kauf.pdf', mime: 'application/pdf', groesse: 6, erstelltAm: 1 })
  ]);
  assert.equal((await roh(env, u, 'PUT', '/datei?tabelle=dateien&id=da-3', text('Kaufv.'), b.tok)).status, 200);
  const g = await freigabe(env, u, b, Object.assign({ ausnahmen: ['do-3'] }, MIT));
  const r = (await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast)).json;
  const text2 = JSON.stringify(r.datensaetze);
  assert.ok(!text2.includes('do-3') && !text2.includes('Kaufvertrag') && !text2.includes('da-3'), 'nichts vom Kaufvertrag');
  assert.ok(text2.includes('do-1') && text2.includes('Fahrzeugschein') && text2.includes('da-1'), 'der Fahrzeugschein bleibt');
  assert.equal((await roh(env, u, 'GET', '/geteilt/datei?freigabe=' + g.id + '&id=da-3', undefined, g.gast)).status, 404);
  assert.equal((await roh(env, u, 'GET', '/geteilt/datei?freigabe=' + g.id + '&id=da-1', undefined, g.gast)).status, 200);
  const l = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, b.tok)).json;
  assert.equal(l.gegeben.find((x) => x.id === g.id).ausnahmen, 1);
  assert.equal((await einladen(env, u, b.tok, { email: 'x@example.org', ausnahmen: 'do-3' })).status, 400);
  /* Ohne Ausnahmen sieht der Gast alles wie bisher. */
  const k = await konto(env, u, 'frei@example.org'), e = await einladen(env, u, b.tok, { email: 'frei@example.org' });
  await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, k);
  assert.ok(JSON.stringify((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + e.json.id, undefined, k)).json.datensaetze).includes('Kaufvertrag'));
});

test('Kontroll-Code durch den Gast: nur mit Mitnutzung, gilt nur für das Fahrzeug und nie länger als die Freigabe', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b, Object.assign({ bis: '2026-11-12' }, MIT));
  assert.equal((await ruf(env, u, 'POST', '/geteilt/kontrolle', { freigabe: g.id, stunden: 0 }, g.gast)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/geteilt/kontrolle', { freigabe: g.id, stunden: 500 }, g.gast)).status, 400);
  const k = await ruf(env, u, 'POST', '/geteilt/kontrolle', { freigabe: g.id, stunden: 168 }, g.gast);
  assert.equal(k.status, 200, JSON.stringify(k.json));
  assert.match(k.json.code, /^[2-9A-HJKMNP-Z]{8}$/);
  assert.equal(k.json.laeuftAb, Date.UTC(2026, 10, 12, 23, 59, 59, 999), 'endet mit der Freigabe');
  const lesen = await ruf(env, u, 'GET', '/kontrolle/lesen?code=' + k.json.code);
  assert.equal(lesen.status, 200); assert.equal(lesen.json.fahrzeugId, 'fz-1');
  assert.ok(!tabellenVon(lesen.json).includes('kosten'));
  const kl = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, b.tok)).json.kontrollen;
  assert.equal(kl.length, 1, 'der Besitzer sieht den Code in seiner Liste und kann ihn widerrufen');
  assert.equal((await ruf(env, u, 'POST', '/kontrolle/widerrufen', { id: kl[0].id }, b.tok)).status, 200);
  assert.equal((await ruf(env, u, 'GET', '/kontrolle/lesen?code=' + k.json.code)).status, 404);
});

test('Ohne die SQL-Zeilen 13f-2 geht alles wie bisher; Einladung mit Rechten sagt es in einfachen Worten', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  const raw = env.DB.roh;
  raw.exec('ALTER TABLE freigabe RENAME TO freigabe_neu'); /* nur um die Spalten zu entfernen: neu anlegen ohne 13f-2 */
  raw.exec('CREATE TABLE freigabe AS SELECT id, datenraum_id, fahrzeug_id, email, code_hash, gast_nutzer_id, erstellt_am, ab_am, laeuft_ab, einladung_bis, angenommen_am, widerrufen_am, nachweis_art, nachweis_bis, bestaetigt_am FROM freigabe_neu');
  raw.exec('DROP TABLE freigabe_neu');
  assert.equal((await ruf(env, u, 'GET', '/gesundheit')).json.mitnutzung, false);
  const e = await einladen(env, u, b.tok, MIT);
  assert.equal(e.status, 503); assert.match(e.json.error, /SQL-Zeile/);
  const l = await ruf(env, u, 'GET', '/freigabe/liste', undefined, b.tok);
  assert.equal(l.status, 200); assert.equal(l.json.verleih.mitnutzung, false);
});

test('Dienst 13f-2: Version, drei SQL-Zeilen auch im Schema, Gesundheit, Anleitung, Kostenarten stimmen mit der App überein', async () => {
  const d = await laden();
  assert.equal(d.VERSION, '13g');
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13f-2.sql'), 'utf8').trim().split('\n');
  assert.equal(sql.length, 3);
  const schema = fs.readFileSync(path.join(__dirname, '..', 'server', 'schema.sql'), 'utf8');
  sql.forEach((z) => assert.ok(schema.includes(z), z));
  assert.ok(fs.readFileSync(path.join(__dirname, '..', 'server', 'EINRICHTUNG.md'), 'utf8').includes('Update auf 13f-2'));
  assert.equal((await ruf(umgebung(), uhr(), 'GET', '/gesundheit')).json.mitnutzung, true);
  require('../js/kosten.js');
  const MM = globalThis.MM;
  ['variabel', 'instandhaltung'].forEach((g) => assert.deepEqual(d.GAST_KOSTENARTEN[g], MM.Kosten.KOSTENARTEN.filter((a) => a.gruppe === g).map((a) => a.wert), g));
  require('../js/werkstatt.js');
  assert.deepEqual(d.GAST_AUSWIRKUNGEN, MM.Werkstatt.AUSWIRKUNGEN.map((a) => a.wert));
});
