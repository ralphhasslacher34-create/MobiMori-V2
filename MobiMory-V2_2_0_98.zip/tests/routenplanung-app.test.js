'use strict';
/* 2.0.90: Routenplanung in der App. Anfrage, Warnungen, Navigations-Link, Planung speichern (Dienst nachgebaut), Wasserfahrzeug, Anzeige, Konto-Texte. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche',
  'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'konto', 'daten'].forEach((m) => require('../js/' + m + '.js'));
const MM = globalThis.MM;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const JETZT = new Date(2026, 10, 15, 12, 0, 0).toISOString();

test('Anfrage: Position von Start und Ziel ist Pflicht, fehlende Maße werden genannt, Achsen gehen mit', () => {
  const R = MM.Routen, s = { breite: 48.9, laenge: 9.1, name: 'A' }, z = { breite: 47.5, laenge: 8.2, name: 'B' };
  const q = R.planungAnfrage(s, z, [{ breite: 48.1, laenge: 8.7 }], { hoehe: 3.1, breite: 2.3, laenge: 7.4, gesamtgewicht: 4500, achsen: 2 });
  assert.equal(q.ok, true); assert.deepEqual(q.fehlend, []);
  assert.deepEqual(q.anfrage, { von: { breite: 48.9, laenge: 9.1 }, nach: { breite: 47.5, laenge: 8.2 }, via: [{ breite: 48.1, laenge: 8.7 }], fahrzeug: { hoehe: 3.1, breite: 2.3, laenge: 7.4, gesamtgewicht: 4500, achsen: 2 } });
  const teil = R.planungAnfrage(s, z, [], { hoehe: '3,1', gesamtgewicht: null });
  assert.equal(teil.ok, true); assert.deepEqual(teil.fehlend, ['Breite', 'Länge', 'Zulässiges Gesamtgewicht']); assert.deepEqual(teil.anfrage.fahrzeug, { hoehe: 3.1 });
  const ohne = R.planungAnfrage({ name: 'A', breite: null, laenge: null }, z, [{ name: 'X' }], {});
  assert.equal(ohne.ok, false); assert.equal(ohne.fehler.length, 2); assert.match(ohne.fehler[0], /Startort braucht eine Position/);
  assert.equal(R.planungAnfrage(s, z, [1, 2, 3, 4, 5, 6].map(() => s), {}).ok, false);
});

test('Warnungen: Text für Beschränkung, gesperrte Straße und Unbekanntes; Navigations-Link nur mit gültiger Position', () => {
  const R = MM.Routen;
  assert.match(R.planungWarnungText({ code: 'violatedVehicleRestriction', stufe: 'kritisch', grund: 'Route violates vehicle restriction' }), /^Achtung: Auf der Strecke gibt es eine Beschränkung.*Brücke, die niedriger ist als dein Fahrzeug/);
  assert.match(R.planungWarnungText({ code: 'violatedBlockedRoad', stufe: 'hinweis' }), /^Hinweis: Ein Teil der Strecke ist gesperrt/);
  assert.match(R.planungWarnungText({ code: 'x', stufe: 'hinweis', titel: 'Etwas anderes' }), /Etwas anderes/);
  assert.equal(R.navigationsLink(54.3, 10.1, 'Kiel'), 'geo:54.3,10.1?q=54.3,10.1(Kiel)');
  assert.equal(R.navigationsLink(null, 10, 'x'), null); assert.equal(R.navigationsLink(91, 10, 'x'), null);
  assert.match(R.PLAN_HINWEIS, /Straßendaten/);
});

async function neu(kontoFn) {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  if (kontoFn) { d.kontoAnfrageFn = kontoFn; await d.rcSchreiben({ kontoToken: 'tok', kontoEmail: 'a@example.org' }); }
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const art = arten[0].objekt.id;
  async function ort(name, b, l) { const r = await d.ortAnlegen({ bezeichnung: name, positionBreite: b === null ? '' : String(b), positionLaenge: l === null ? '' : String(l) }); assert.equal(r.ok, true, JSON.stringify(r)); return r.id; }
  return { d, anna, art, ort };
}

test('Planung: Wohnmobil mit Maßen und Orten: Anfrage geht an den Dienst, Route wird gespeichert, Warnungen und Maße bleiben, Kontingent kommt zurück', async () => {
  const aufrufe = [];
  const c = await neu(async (url, methode, token, body) => {
    aufrufe.push({ url, methode, token, body });
    return { ok: true, route: { punkte: [{ breite: 48.9, laenge: 9.1 }, { breite: 48.5, laenge: 8.9 }, { breite: 47.5, laenge: 8.2 }], laengeKm: 210.4, dauerMin: 190,
      warnungen: [{ code: 'violatedVehicleRestriction', stufe: 'kritisch', titel: 'Violated vehicle restriction.', grund: 'Route violates vehicle restriction', ort: { breite: 48.5, laenge: 8.9 } }] },
      kontingent: { genutzt: 1, grenze: 10, stufe: 'test' } };
  });
  const fz = (await c.d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil', hoehe: '3,1', breite: '2,3', laenge: '7,4', gesamtgewicht: '4500', achsen: '2' }));
  assert.equal(fz.ok, true, JSON.stringify(fz));
  const start = await c.ort('Stuttgart', 48.9, 9.1), ziel = await c.ort('Zürich', 47.5, 8.2);
  const a = await c.d.aktivitaetAnlegen({ bezeichnung: 'Fahrt', artId: c.art, fahrzeugId: fz.id, vonDatum: '2026-11-20', vonZeit: '08:00', bisDatum: '2026-11-20', verantwortlichId: c.anna, startOrtId: start, zielOrtId: ziel });
  assert.equal(a.ok, true, JSON.stringify(a));
  const vor = await c.d.routeAnsicht(a.id);
  assert.equal(vor.planung.moeglich, true); assert.deepEqual(vor.planung.fehlend, []); assert.equal(vor.planung.fehler.length, 0);
  const r = await c.d.routePlanen(a.id);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(aufrufe.length, 1); assert.equal(aufrufe[0].url.endsWith('/route/planen'), true); assert.equal(aufrufe[0].methode, 'POST'); assert.equal(aufrufe[0].token, 'tok');
  assert.deepEqual(aufrufe[0].body.fahrzeug, { hoehe: 3.1, breite: 2.3, laenge: 7.4, gesamtgewicht: 4500, achsen: 2 });
  assert.deepEqual(aufrufe[0].body.von, { breite: 48.9, laenge: 9.1 });
  assert.equal(r.name, 'Stuttgart – Zürich'); assert.equal(r.laengeKm, 210.4); assert.equal(r.dauerMin, 190); assert.equal(r.warnungen.length, 1); assert.equal(r.kontingent.genutzt, 1);
  const n = await c.d.routeAnsicht(a.id);
  assert.equal(n.route.geplant.warnungen[0].code, 'violatedVehicleRestriction'); assert.deepEqual(n.route.geplant.fehlend, []); assert.equal(n.route.geplant.dauerMin, 190);
  assert.equal(n.route.punkte.length, 3); assert.equal(n.route.werte.bezeichnung, 'Stuttgart – Zürich');
  const gpx = await c.d.routeGpx(n.route.id);
  assert.equal(gpx.ok, true); assert.match(gpx.text, /<rtept lat="48.9" lon="9.1"><name>Stuttgart<\/name>/); assert.match(gpx.text, /<name>Zürich<\/name>/);
  /* eine eingelesene Route hat keine Planung */
  const e = await c.d.routeImportieren(a.id, '<gpx><rte><rtept lat="48" lon="8"/><rtept lat="48.2" lon="8"/></rte></gpx>', 'x.gpx');
  assert.equal(e.ok, true); assert.equal((await c.d.routeAnsicht(a.id)).route.geplant, null);
});

test('Planung: fehlende Maße werden gemeldet und gespeichert, Fehler des Dienstes kommen in einfachen Worten, ohne Position oder Anmeldung wird nichts gesendet', async () => {
  let aufrufe = 0, antwort = async () => { throw Object.assign(new Error('Dein Kontingent ist aufgebraucht: 10 von 10 geplanten Routen.'), { status: 402 }); };
  const c = await neu(async (...x) => { aufrufe++; return antwort(...x); });
  const fz = await c.d.fahrzeugAnlegen('auto', { bezeichnung: 'Auto', hoehe: '1,6' });
  const start = await c.ort('Berlin', 52.5, 13.4), ziel = await c.ort('Hamburg', 53.5, 10);
  const ohnePos = await c.ort('Irgendwo', null, null);
  const mk = (extra) => c.d.aktivitaetAnlegen(Object.assign({ bezeichnung: 'Fahrt', artId: c.art, fahrzeugId: fz.id, vonDatum: '2026-11-20', vonZeit: '08:00', bisDatum: '2026-11-20', verantwortlichId: c.anna }, extra));
  const a = await mk({ startOrtId: start, zielOrtId: ziel });
  const voll = await c.d.routePlanen(a.id);
  assert.equal(voll.ok, false); assert.equal(voll.art, 'kontingent'); assert.match(voll.fehler.allgemein, /aufgebraucht/); assert.equal(aufrufe, 1);
  antwort = async () => ({ ok: true, route: { punkte: [{ breite: 52.5, laenge: 13.4 }, { breite: 53.5, laenge: 10 }], laengeKm: 290, dauerMin: 180, warnungen: [] }, kontingent: { genutzt: 2, grenze: 10, stufe: 'test' } });
  const ok = await c.d.routePlanen(a.id);
  assert.equal(ok.ok, true); assert.deepEqual(ok.fehlend, ['Breite', 'Länge', 'Zulässiges Gesamtgewicht']);
  assert.deepEqual((await c.d.routeAnsicht(a.id)).route.geplant.fehlend, ['Breite', 'Länge', 'Zulässiges Gesamtgewicht']);
  const b = await mk({ startOrtId: start, zielOrtId: ohnePos });
  aufrufe = 0;
  const kein = await c.d.routePlanen(b.id);
  assert.equal(kein.ok, false); assert.match(kein.fehler.allgemein || kein.fehler.datei || Object.values(kein.fehler)[0], /Zielort braucht eine Position/); assert.equal(aufrufe, 0);
  const o = await neu(); /* nicht angemeldet */
  const f2 = await o.d.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' }); const s2 = await o.ort('A', 1, 1), z2 = await o.ort('B', 2, 2);
  const a2 = await o.d.aktivitaetAnlegen({ bezeichnung: 'Fahrt', artId: o.art, fahrzeugId: f2.id, vonDatum: '2026-11-20', vonZeit: '08:00', bisDatum: '2026-11-20', verantwortlichId: o.anna, startOrtId: s2, zielOrtId: z2 });
  const x = await o.d.routePlanen(a2.id);
  assert.equal(x.ok, false); assert.equal(x.art, 'anmeldung'); assert.match(x.fehler.allgemein, /Melde dich zuerst an/);
});

test('Wasserfahrzeug: keine Berechnung, aber der Link für die Navigations-App mit dem Ziel; Planen wird abgelehnt', async () => {
  let aufrufe = 0;
  const c = await neu(async () => { aufrufe++; return {}; });
  const boot = await c.d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' });
  const start = await c.ort('Kiel', 54.3, 10.1), ziel = await c.ort('Laboe', 54.4, 10.2);
  const a = await c.d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: c.art, fahrzeugId: boot.id, vonDatum: '2026-11-20', vonZeit: '08:00', bisDatum: '2026-11-20', verantwortlichId: c.anna, startOrtId: start, zielOrtId: ziel });
  const v = await c.d.routeAnsicht(a.id);
  assert.equal(v.planung.moeglich, false); assert.equal(v.planung.welt, 'wasser'); assert.equal(v.planung.navi.link, 'geo:54.4,10.2?q=54.4,10.2(Laboe)'); assert.match(v.planung.grund, /Navigations-App/);
  const r = await c.d.routePlanen(a.id);
  assert.equal(r.ok, false); assert.equal(aufrufe, 0);
});

test('Einbau: Seite „Route planen“ mit Warnungen, Hinweis zu den Straßendaten, Konto-Texte, Version 2.0.94, Dokumente', () => {
  const a = lesen('js/ansicht.js');
  ['aria-label\': \'Route planen\'', 'daten.routePlanen(id)', 'Route planen (zählt 1 Route)', 'Warnungen der Planung', 'MM.Routen.PLAN_HINWEIS', 'Navigations-App öffnen', 'gehen dafür an den Konto-Dienst und an den Routen-Dienst HERE'].forEach((s) => assert.ok(a.includes(s), s));
  assert.equal(MM.VERSION, '2.0.98'); assert.ok(MM.STUFE.includes('Planung'));
  assert.equal(MM.Texte.NEUERUNGEN[10].version, '2.0.88'); assert.match(MM.Texte.NEUERUNGEN[10].punkte.join(' '), /Route planen/);
  assert.ok(lesen('CHANGELOG.md').includes('## 2.0.88\n- **Bau: Routenplanung**'));
  assert.ok(lesen('docs/SCHRITTE.md').includes('| 13f-13 |'));
  assert.ok(lesen('server/EINRICHTUNG.md').startsWith('# Konto-Dienst: Einrichtung und Updates (Stand 2.0.98, Schritt 13g)'));
  const K = MM.Konto;
  assert.equal(K.PRODUKTE.route100.cent, 999); assert.equal(K.PRODUKTE.route100.anzahl, 100);
  assert.deepEqual([K.STUFEN.basic.routen, K.STUFEN.test.routen, K.STUFEN.mittel.routen, K.STUFEN.voll.routen, K.STUFEN.entwickler.routen], [0, 10, 100, 1000, null]);
  const s = { ok: true, stufe: { id: 'mittel', name: 'Mittel', bis: null }, grenzen: { geraete: 4, checks: 3, routen: 100, fahrzeuge: 3, online: true }, nutzung: { geraete: 1, checks: 0, checksFrei: 3, extra: 0, routen: 12, routenFrei: 88, routenExtra: 100 } };
  const z = K.stufeZeilen(s, (x) => x);
  assert.ok(z.some((x) => /Routenplanung: 12 von 100 Routen/.test(x) && /88 frei/.test(x))); assert.ok(z.some((x) => /Zusätzliche Routen: 100 übrig/.test(x)));
  assert.ok(K.angebote(s).some((x) => x.id === 'route100' && x.preis === '9,99 €'));
  assert.ok(!K.angebote({ stufe: { id: 'basic' }, grenzen: { online: false } }).some((x) => x.id === 'route100'));
});

test('Karte: Warnstellen der geplanten Route kommen mit Position in die Kartendaten (2.0.90), eine eingelesene Route hat keine', async () => {
  const c = await neu(async () => ({ ok: true, route: { punkte: [{ breite: 52.5, laenge: 13.4 }, { breite: 53.5, laenge: 10 }], laengeKm: 290, dauerMin: 180,
    warnungen: [{ code: 'violatedVehicleRestriction', stufe: 'kritisch', titel: 'x', grund: '', ort: { breite: 53, laenge: 11 } }, { code: 'violatedBlockedRoad', stufe: 'hinweis', titel: 'y', grund: '', ort: null }] }, kontingent: { genutzt: 1, grenze: 10, stufe: 'test' } }));
  const fz = await c.d.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  const start = await c.ort('Berlin', 52.5, 13.4), ziel = await c.ort('Hamburg', 53.5, 10);
  const a = await c.d.aktivitaetAnlegen({ bezeichnung: 'Fahrt', artId: c.art, fahrzeugId: fz.id, vonDatum: '2026-11-20', vonZeit: '08:00', bisDatum: '2026-11-20', verantwortlichId: c.anna, startOrtId: start, zielOrtId: ziel });
  assert.equal((await c.d.routePlanen(a.id)).ok, true);
  const kd = await c.d.kartenDaten(a.id);
  assert.equal(kd.ok, true); assert.deepEqual(kd.route.warnstellen.map((w) => w.ort), [{ breite: 53, laenge: 11 }], 'nur Warnungen mit Position');
  await c.d.routeImportieren(a.id, '<gpx><rte><rtept lat="48" lon="8"/><rtept lat="48.2" lon="8"/></rte></gpx>', 'x.gpx');
  assert.deepEqual((await c.d.kartenDaten(a.id)).route.warnstellen, []);
  const k = lesen('js/kartenansicht.js');
  assert.ok(k.includes("'kv-warnung', '!'") && k.includes('MM.Routen.planungWarnungText(w)')); assert.ok(lesen('css/styles.css').includes('.kv-warnung'));
});
