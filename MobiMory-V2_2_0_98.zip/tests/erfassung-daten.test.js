'use strict';
/* Smart Capture: Speichern von Person, Fahrzeug und Nachweis. Erfundene Daten (Erika Mustermann). */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'logbuch', 'status', 'reiseorte', 'erfassung', 'daten']
  .forEach(m => require('../js/' + m + '.js'));
const MM = globalThis.MM;

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 15, 12, 0, t++)).toISOString() });
  await d.starten();
  return d;
}
const scan = () => ({ name: 'scan.jpg', type: 'image/jpeg', size: 2048, bytes: new Uint8Array([1, 2, 3]) });
const FS = { nachname: 'Mustermann', vorname: 'Erika', geburtsdatum: '1964-08-12', geburtsort: 'Musterstadt', ausgestelltAm: '2022-08-24', gueltigBis: '2037-08-23', aussteller: 'Landratsamt Musterkreis', nummer: 'B072RRE2I55', klassen: 'AM/B' };

test('Erstes Dokument legt die Person an, Art wird übernommen, Scan hängt am Nachweis', async () => {
  const d = await neu();
  const r = await d.erfassungSpeichern({ vorschlagId: 'DE_FEV_FUEHRERSCHEIN_EU', werte: FS, datei: scan() });
  assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.neu, true); assert.equal(r.besitzerTyp, 'person');
  const personen = await d.personenListe();
  assert.equal(personen.length, 1); assert.equal(personen[0].aktuell.werte.bezeichnung, 'Erika Mustermann');
  const n = await d.nachweisLaden(r.nachweisId);
  assert.equal(n.datei.name, 'scan.jpg');
  assert.equal(n.aktuell.werte.nummer, 'B072RRE2I55'); assert.equal(n.aktuell.werte.gueltigBis, '2037-08-23');
  const z1 = n.felder.find(f => f.label === 'Name'), z3 = n.felder.find(f => /Geburtsdatum/.test(f.label));
  assert.equal(n.aktuell.werte[z1.key], 'Mustermann'); assert.match(n.aktuell.werte[z3.key], /12\.08\.1964 Musterstadt/);
});

test('Weiterer Nachweis: Person wird an Name und Geburtsdatum erkannt, auch bei ß/ss und Großschreibung', async () => {
  const d = await neu();
  await d.erfassungSpeichern({ vorschlagId: 'DE_FEV_FUEHRERSCHEIN_EU', werte: Object.assign({}, FS, { nachname: 'Haßlacher' }), datei: scan() });
  const personen = await d.erfassungPersonen();
  assert.equal(personen[0].nachname, 'Haßlacher'); assert.equal(personen[0].geburtsdatum, '1964-08-12');
  const z = MM.Erfassung.personZuordnen({ nachname: 'HASSLACHER', vorname: 'ERIKA', geburtsdatum: '1964-08-12' }, personen);
  assert.equal(z.art, 'gleich');
  const r = await d.erfassungSpeichern({ vorschlagId: 'DE_PAUSWG_PERSONALAUSWEIS', werte: { nachname: 'Hasslacher', vorname: 'Erika', geburtsdatum: '1964-08-12', geburtsort: 'Musterstadt', gueltigBis: '2029-11-01', nummer: 'T22000129' }, datei: scan(), personId: z.person.id });
  assert.equal(r.ok, true); assert.equal(r.neu, false);
  assert.equal((await d.personenListe()).length, 1);
  assert.equal((await d.nachweiseListe('person', z.person.id)).length, 2);
});

test('Eine schon übernommene Art ohne Namensfelder bekommt sie beim Speichern ergänzt', async () => {
  const d = await neu();
  const a = await d.nachweisartAusVorschlag('DE_UBI');
  const alt = await d.nachweisartLaden(a.id);
  await d.nachweisartAendern(a.id, { bezeichnung: alt.werte.bezeichnung, hatAblauf: alt.werte.hatAblauf, felder: [] });
  const r = await d.erfassungSpeichern({ vorschlagId: 'DE_UBI', werte: { nachname: 'Mustermann', vorname: 'Erika', geburtsdatum: '1964-08-12', geburtsort: 'Musterstadt', nummer: '123456-Z' }, datei: scan() });
  assert.equal(r.ok, true, JSON.stringify(r));
  const n = await d.nachweisLaden(r.nachweisId);
  assert.ok(n.felder.some(f => f.label === 'Name') && n.felder.some(f => /Geburtsdatum/.test(f.label)));
  const p = (await d.erfassungPersonen())[0];
  assert.equal(p.nachname, 'Mustermann'); assert.equal(p.geburtsdatum, '1964-08-12');
});

test('Neue Arten: Bodensee-Schifferpatent und Fachkundenachweis Sprengstoffrecht', async () => {
  const d = await neu();
  const r1 = await d.erfassungSpeichern({ vorschlagId: 'DE_BODENSEE_SCHIFFERPATENT', werte: { nachname: 'Mustermann', vorname: 'Erika', geburtsdatum: '1964-08-12', geburtsort: 'Musterstadt', nummer: '1234567', klassen: 'A = Motorboot', gueltigBis: '2045-11-26' }, datei: scan() });
  assert.equal(r1.ok, true, JSON.stringify(r1));
  const r2 = await d.erfassungSpeichern({ vorschlagId: 'DE_SPRENGG_FACHKUNDE', werte: { nachname: 'Mustermann', vorname: 'Erika', geburtsdatum: '1964-08-12', nummer: 'M000123456', aussteller: 'DMYV-Zentrale' }, datei: scan(), personId: r1.besitzerId });
  assert.equal(r2.ok, true, JSON.stringify(r2));
  assert.equal((await d.nachweiseListe('person', r1.besitzerId)).length, 2);
});

test('Zulassungsbescheinigung legt das Fahrzeug an, gleiche Kennung fragt nach', async () => {
  const d = await neu();
  const w = { kennzeichen: 'LB-AB 123', erstzulassung: '2019-05-04', marke: 'Mustermarke', modell: 'Eins', fin: 'WMUSTER1234567890X', gesamtgewicht: '1800', leergewicht: '1300', laenge: '4500' };
  const r = await d.erfassungSpeichern({ vorschlagId: 'DE_FZV_ZB_I', werte: w, datei: scan(), fahrzeugArt: 'auto' });
  assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.besitzerTyp, 'fahrzeug');
  const f = (await d.fahrzeugListe())[0];
  assert.equal(f.aktuell.werte.bezeichnung, 'Mustermarke Eins'); assert.equal(f.aktuell.werte.kennzeichen, 'LB-AB 123');
  assert.equal(f.aktuell.werte.laenge, 4.5); assert.equal(f.aktuell.werte.gesamtgewicht, 1800);
  const doppelt = await d.erfassungSpeichern({ vorschlagId: 'DE_FZV_ZB_I', werte: w, datei: scan(), fahrzeugArt: 'auto' });
  assert.equal(doppelt.ok, false); assert.ok(doppelt.doppelt && doppelt.doppelt.length === 1);
  const dran = await d.erfassungSpeichern({ vorschlagId: 'DE_FZV_ZB_I', werte: w, datei: scan(), fahrzeugId: f.fahrzeug.id });
  assert.equal(dran.ok, true); assert.equal((await d.fahrzeugListe()).length, 1);
});

test('Vorlage: nur die Stelle wird gemerkt, nie ein persönlicher Wert', async () => {
  const d = await neu();
  await d.erfassungVorlageMerken('DE_FEV_FUEHRERSCHEIN_EU', 'nummer', { x0: 0.3, y0: 0.6, x1: 0.7, y1: 0.7 });
  await d.erfassungVorlageMerken('DE_FEV_FUEHRERSCHEIN_EU', 'nummer', { x0: -1, y0: 0.6, x1: 2, y1: 0.7 });
  const v = await d.erfassungVorlagen();
  assert.deepEqual(Object.keys(v['DE_FEV_FUEHRERSCHEIN_EU'].felder), ['nummer']);
  assert.equal(v['DE_FEV_FUEHRERSCHEIN_EU'].felder.nummer.x0, 0); assert.equal(v['DE_FEV_FUEHRERSCHEIN_EU'].felder.nummer.x1, 1);
  assert.equal(v['DE_FEV_FUEHRERSCHEIN_EU'].gelernt, 2);
  assert.equal(JSON.stringify(v).includes('Mustermann'), false);
});

test('Unbekannte Art: nichts wird angelegt', async () => {
  const d = await neu();
  const r = await d.erfassungSpeichern({ vorschlagId: 'GIBT_ES_NICHT', werte: { nachname: 'X' }, datei: scan() });
  assert.equal(r.ok, false); assert.equal((await d.personenListe()).length, 0);
});

test('Einbau: Module in index.html und Service Worker, Kachel, Route, Lizenzdateien, Tesseract-Dateien', () => {
  const fs = require('node:fs'), path = require('node:path'), l = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
  ['js/erfassung.js', 'js/erfassung-motor.js', 'js/erfassung-ansicht.js'].forEach(f => { assert.ok(l('index.html').includes(f), f); assert.ok(l('sw.js').includes("'" + f + "'"), f); });
  assert.ok(l('index.html').indexOf('js/daten.js') < l('index.html').indexOf('js/erfassung.js') && l('index.html').indexOf('js/erfassung-ansicht.js') < l('index.html').indexOf('js/ansicht.js'));
  const a = l('js/ansicht.js');
  assert.ok(a.includes("'#/erfassung'") && a.includes("teile[0] === 'erfassung'") && a.includes('MM.AnsichtKit'));
  ['tesseract.min.js', 'worker.min.js', 'tesseract-core-simd-lstm.wasm.js', 'tesseract-core-lstm.wasm.js', 'deu.traineddata.gz', 'HERKUNFT.txt', 'LICENSE-tesseract.js.txt'].forEach(f => assert.ok(fs.existsSync(path.join(__dirname, '..', 'lib/tesseract', f)), f));
  MM.ErfassungMotor = undefined;
  assert.ok(l('js/erfassung-motor.js').includes("ORDNER = 'lib/tesseract/'"));
  assert.ok(l('CHANGELOG.md').includes('Smart Capture') && l('docs/SCHRITTE.md').includes('gebaut (2.0.96'));
  /* Nichts verlässt das Gerät: keine fremde Adresse in der Erkennung */
  ['js/erfassung.js', 'js/erfassung-motor.js', 'js/erfassung-ansicht.js'].forEach(f => assert.equal(/https?:\/\//.test(l(f).replace(/\/\*[\s\S]*?\*\//g, '')), false, f));
});

test('Dokument erfassen ist nur für Entwickler erreichbar, nicht unter Funktionen', () => {
  const fs = require('node:fs'), path = require('node:path');
  const a = fs.readFileSync(path.join(__dirname, '..', 'js', 'ansicht.js'), 'utf8');
  assert.ok(!/seiteFunktionen[\s\S]{0,6000}kachel\('Dokument erfassen'/.test(a.slice(a.indexOf('function seiteFunktionen'), a.indexOf('function seiteFunktionen') + 6000)));
  assert.match(a, /kachel\('Dokument erfassen', 'In Erprobung[^']*', '#\/erfassung'\)/);
  assert.match(a, /teile\[0\] === 'erfassung'\) p = nurEntwickler\(/);
});
