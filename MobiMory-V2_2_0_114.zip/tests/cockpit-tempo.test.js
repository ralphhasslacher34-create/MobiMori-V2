'use strict';
/* 2.0.44: Aufbau von Cockpit, Tagesabschluss und Tag-Auswahl im Quelltext (es gibt keinen echten Browser im Test). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const ansicht = lesen('js/ansicht.js');
function funktion(name) {
  const start = ansicht.indexOf('  function ' + name + '(');
  assert.ok(start >= 0, 'Funktion fehlt: ' + name);
  return ansicht.slice(start, ansicht.indexOf('\n  }\n', start));
}

test('GPS-Punkte laufen auch in die Geschwindigkeit, mit der Geschwindigkeit des Geräts', () => {
  /* seit 2.0.112 laufen Browser und Dauerdienst der Android-Hülle über dieselbe Stelle */
  assert.match(ansicht, /geschwindigkeit: typeof geschwindigkeit === 'number'/);
  assert.match(ansicht, /p\.coords\.speed\)/);
  assert.match(ansicht, /gpsSpurPunkt\(\);\s*gpsFahrtPunkt\(\);/);
});
test('Das Wechselfeld wird nicht bei jedem GPS-Punkt neu gebaut', () => {
  assert.ok(!funktion('gpsZeichnen').includes("h('button'"));
  assert.match(funktion('gpsZeichnen'), /tempoAktualisieren\(\)/);
  assert.match(funktion('positionZeile'), /tempoKnopfBauen\(\)/);
});
test('Die Wetter-Meldung verschwindet von selbst', () => {
  const f = funktion('cockpitVollbild');
  assert.match(f, /meldungKurz/); assert.match(ansicht, /MELDUNG_KURZ_MS = 6000, MELDUNG_MAX_MS = 60000/); assert.match(f, /setTimeout\(meldungWeg, meldungFrist\)/);
  assert.match(f, /kurz \? MELDUNG_KURZ_MS : MELDUNG_MAX_MS/, 'jede Meldung hat eine Frist (seit 2.0.114), nicht nur die Wetter-Meldung');
  assert.match(f, /visibilitychange/);
  assert.match(f, /fahrtAutoPlanen\(/);
});
test('Der Tagesabschluss schreibt die Geschwindigkeit', () => {
  assert.match(funktion('abschlussFormular'), /daten\.fahrtTagAbschliessen\(/);
});
test('Zusammenfassung und Logbuch zeigen bei der Auswahl nur den gewählten Tag', () => {
  assert.match(funktion('zusammenfassungBlock'), /tagWaehler\(aktId, wahl\)/);
  assert.match(funktion('logbuchPanel'), /tagWaehler\(id, wahl\)/);
  assert.match(ansicht, /pageYOffset/);
});
test('Neue Module sind in index.html und sw.js eingetragen', () => {
  ['js/fahrt.js', 'js/tagwahl.js'].forEach(m => { assert.ok(lesen('index.html').includes(m)); assert.ok(lesen('sw.js').includes(m)); });
});
