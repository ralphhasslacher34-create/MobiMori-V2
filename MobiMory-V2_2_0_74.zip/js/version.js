/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.74';
  MM.STUFE = 'Konto: Verleih mit Gästen nach Stufe, Nachweis des Halters, Prüfung von Zeitraum und Fristen';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
