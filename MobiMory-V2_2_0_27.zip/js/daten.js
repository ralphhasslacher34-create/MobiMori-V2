/*
 * Daten: die EINE Tür zu allen Fahrzeugdaten.
 *
 * Regeln aus den V2-Festlegungen, die hier gelten:
 *  - Eine Quelle: alle Teile der App fragen nur hier nach.
 *  - Handeingabe hat Vorrang. Es wird nichts überschrieben: Jede Änderung
 *    ist ein neuer Eintrag "Korrektur zu ...", der alte bleibt sichtbar.
 *  - Nichts wird gelöscht.
 *  - Jeder Eintrag nennt seine Herkunft (hier: "hand").
 *
 * Aufbau der gespeicherten Daten:
 *  datenraum   { id, name, erstelltAm }
 *  fahrzeug    { id, datenraumId, art, erstelltAm }
 *  eintrag     { id, fahrzeugId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  komponente  { id, fahrzeugId, parentId, art, erstelltAm }
 *              parentId = null: Hauptkomponente (dann gilt "art"), sonst gehört
 *              sie zu einer anderen Komponente ("gehört zu").
 *  komponenteneintrag { id, komponenteId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  zaehler     { id, fahrzeugId, komponenteId|null, art, erstelltAm }      (Name im Verlauf)
 *  zaehlerstand { id, zaehlerId, nr, wert, datum, notiz, quelle, erstelltAm }
 *  frist       { id, fahrzeugId, komponenteId|null, erstelltAm }            (Angaben im Verlauf)
 *  verlauf     { id, objektTyp, objektId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  durchfuehrung { id, fristId, datum, zaehlerstand, notiz, art, quelle, erstelltAm }
 *  dokument    { id, fahrzeugId, komponenteId|null, vorgangId|null, erstelltAm }  (Angaben im Verlauf; vorgangId seit 2.0.26: hängt am Werkstatt-Vorgang)
 *  datei       { id, dokumentId, name, mime, groesse, inhalt, erstelltAm }  (inhalt = die Datei selbst)
 *  person      { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  tier        { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  nachweisart { id, datenraumId, erstelltAm }                              (Angaben im Verlauf; offene Liste)
 *  nachweis    { id, datenraumId, artId, besitzerTyp, besitzerId, erstelltAm }  (Angaben im Verlauf)
 *  nachweisdatei { id, nachweisId, name, mime, groesse, inhalt, erstelltAm } (Scan oder Foto, bleibt lokal)
 *  aktivitaet  { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  aktivitaetsart { id, datenraumId, erstelltAm }                           (offene Liste, Angaben im Verlauf)
 *  besatzung   { id, aktivitaetId, personId, erstelltAm }                   (Rolle und "dabei von bis" im Verlauf)
 *  verantwortung { id, aktivitaetId, personId, ab, erstelltAm }             (Wechsel der Verantwortlichen, nur anhängen)
 *  anforderung { id, datenraumId, fahrzeugId, erstelltAm }                  (welche Nachweise Skipper und Fahrer brauchen)
 *  tagesabschnitt { id, datenraumId, aktivitaetId, herkunft, erstelltAm }   (Angaben im Verlauf; herkunft: vorbereitet oder hand)
 *  tagespruefung { id, datenraumId, aktivitaetId, abschnittId, stand, erstelltAm } (festgehaltene Prüfung zum Tagesbeginn, nur anhängen)
 *  ereignis    { id, datenraumId, aktivitaetId, abschnittId, erstelltAm }   (Angaben im Verlauf; Foto in ereignisdatei)
 *  ereignisart { id, datenraumId, erstelltAm }                              (offene Liste, Angaben im Verlauf)
 *  ereignisdatei { id, ereignisId, name, mime, groesse, inhalt, erstelltAm } (Foto, bleibt lokal)
 *  kosten      { id, datenraumId, fahrzeugId, erstelltAm }                  (Angaben im Verlauf: Gruppe, Betrag, Rhythmus, Datum, Verweise auf Komponente, Aktivität, Vorgang; seit 2.0.27)
 *  kostenstamm { id 'ks-<fahrzeugId>', datenraumId, fahrzeugId, erstelltAm } (Wert, Wertverlust, Vergleichspreis im Verlauf; seit 2.0.27)
 *  einstellung { id, ... }                                                  (zum Beispiel id "sicherung": letzteSicherung, erinnerungTage)
 *
 * "werte" enthält Bezeichnung und alle Felder. Der aktuelle Stand ist der
 * Eintrag mit der höchsten Nummer.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  function neueId(praefix) {
    var c = global.crypto;
    if (c && typeof c.randomUUID === 'function') return praefix + '-' + c.randomUUID();
    return praefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function Daten(speicher, optionen) {
    this.speicher = speicher;
    this.jetzt = (optionen && optionen.jetzt) || function () { return new Date().toISOString(); };
    this.datenraumId = null;
  }

  /* Beim ersten Start entsteht der eigene Datenraum auf diesem Gerät. */
  Daten.prototype.starten = function () {
    var self = this;
    return this.speicher.alle('datenraeume').then(function (liste) {
      if (liste.length) { self.datenraumId = liste[0].id; return liste[0]; }
      var dr = { id: neueId('dr'), name: 'Mein Datenraum', erstelltAm: self.jetzt() };
      return self.speicher.speichern('datenraeume', dr).then(function () {
        self.datenraumId = dr.id;
        return dr;
      });
    }).then(function (dr) {
      /* Eigene Fahrzeugarten und Änderungen am Baum laden (seit 2.0.16). Ohne Angabe gilt der mitgelieferte Baum. */
      return self.speicher.holen('einstellungen', 'fahrzeugarten').then(function (dok) {
        MM.Fahrzeugarten.konfigurieren(dok);
        return dr;
      });
    });
  };

  /* ---------- Prüfen und in saubere Werte umwandeln ---------- */
  function optWert(o) { return typeof o === 'string' ? o : o.wert; }

  function pruefeWerte(felder, roh, jahr, optionen) {
    var ohneBez = !!(optionen && optionen.ohneBezeichnung);
    var werte = {};
    var fehler = {};
    roh = roh || {};

    if (!ohneBez) {
      var bez = String(roh.bezeichnung == null ? '' : roh.bezeichnung).trim();
      if (!bez) fehler.bezeichnung = (optionen && optionen.bezeichnungFehler) || 'Bitte eine Bezeichnung eingeben, zum Beispiel „Fahrzeug A“.';
      werte.bezeichnung = bez;
    }

    felder.forEach(function (f) {
      if (f.typ === 'mehrfach') {
        var gewaehlt = Array.isArray(roh[f.key]) ? roh[f.key] : [];
        werte[f.key] = f.optionen.filter(function (o) { return gewaehlt.indexOf(optWert(o)) >= 0; }).map(optWert);
        return;
      }
      if (f.typ === 'liste') {
        var zeilen = Array.isArray(roh[f.key]) ? roh[f.key] : [];
        var sauber = [];
        zeilen.forEach(function (z) {
          var n = String(z && z.name != null ? z.name : '').trim();
          var w = String(z && z.wert != null ? z.wert : '').trim();
          if (!n && !w) return;
          if (!n || !w) fehler[f.key] = 'Bitte bei jedem Merkmal Name und Wert eingeben.';
          sauber.push({ name: n, wert: w });
        });
        werte[f.key] = sauber;
        return;
      }

      var v = roh[f.key];
      v = (v === undefined || v === null) ? '' : v;
      if (typeof v === 'string') v = v.trim();

      if (f.typ === 'text') {
        if (f.maxLaenge && String(v).length > f.maxLaenge) fehler[f.key] = 'Bitte höchstens ' + f.maxLaenge + ' Zeichen eingeben.';
        werte[f.key] = v === '' ? null : String(v);
        return;
      }

      if (f.typ === 'auswahl') {
        if (v === '') { werte[f.key] = null; return; }
        if (!f.optionen.some(function (o) { return optWert(o) === v; })) { fehler[f.key] = 'Bitte eine Möglichkeit aus der Liste wählen.'; }
        werte[f.key] = v;
        return;
      }

      if (f.typ === 'zeit') {
        if (v === '') { werte[f.key] = null; return; }
        if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(v)) { fehler[f.key] = 'Bitte eine Uhrzeit eingeben, zum Beispiel 14:30.'; werte[f.key] = null; } else { werte[f.key] = v; }
        return;
      }
      if (f.typ === 'datum') {
        if (v === '') { werte[f.key] = null; return; }
        var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
        var d = m ? new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])) : null;
        if (!d || d.getUTCFullYear() !== +m[1] || d.getUTCMonth() !== +m[2] - 1 || d.getUTCDate() !== +m[3]) {
          fehler[f.key] = 'Bitte ein gültiges Datum eingeben.';
          werte[f.key] = null;
        } else { werte[f.key] = v; }
        return;
      }

      /* zahl und ganzzahl: Komma oder Punkt als Dezimalzeichen erlaubt */
      if (v === '') { werte[f.key] = null; return; }
      var text = String(v).replace(/\s/g, '').replace(',', '.');
      var n = /^-?\d+(\.\d+)?$/.test(text) ? Number(text) : NaN;
      if (isNaN(n)) {
        fehler[f.key] = f.typ === 'ganzzahl' ? 'Bitte eine ganze Zahl eingeben.' : 'Bitte eine Zahl eingeben, zum Beispiel 2,5.';
        werte[f.key] = null;
        return;
      }
      if (f.typ === 'ganzzahl' && Math.floor(n) !== n) { fehler[f.key] = 'Bitte eine ganze Zahl eingeben.'; werte[f.key] = null; return; }
      if (n < 0) { fehler[f.key] = 'Die Zahl darf nicht negativ sein.'; werte[f.key] = null; return; }
      if (f.key === 'baujahr' && (n < f.min || n > jahr + 1)) {
        fehler[f.key] = 'Bitte ein Baujahr zwischen ' + f.min + ' und ' + (jahr + 1) + ' eingeben.';
        werte[f.key] = null; return;
      }
      if (f.min !== undefined && f.key !== 'baujahr' && n < f.min) { fehler[f.key] = 'Der Wert muss mindestens ' + f.min + ' sein.'; werte[f.key] = null; return; }
      if (f.max !== undefined && n > f.max) { fehler[f.key] = 'Der Wert darf höchstens ' + f.max + ' sein.'; werte[f.key] = null; return; }
      werte[f.key] = n;
    });

    return { werte: werte, fehler: fehler, ok: Object.keys(fehler).length === 0 };
  }

  Daten.prototype.pruefen = function (artId, roh) {
    return pruefeWerte(MM.Fahrzeugarten.felder(artId), roh, new Date(this.jetzt()).getFullYear());
  };

  Daten.prototype.pruefenKomponente = function (roh) {
    var p = pruefeWerte(MM.Komponenten.felder(), roh, new Date(this.jetzt()).getFullYear());
    var w = p.werte;
    if (w.eingebautAm && w.ausgebautAm && w.ausgebautAm < w.eingebautAm && !p.fehler.ausgebautAm) {
      p.fehler.ausgebautAm = 'Der Ausbau kann nicht vor dem Einbau liegen.';
      p.ok = false;
    }
    return p;
  };

  /* ---------- Unterschiede zwischen zwei Ständen ---------- */
  function gleich(a, b) {
    if (a === b) return true;
    if (a && b && typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) return JSON.stringify(a) === JSON.stringify(b);
    var la = Array.isArray(a) ? a : (a === null || a === undefined ? [] : null);
    var lb = Array.isArray(b) ? b : (b === null || b === undefined ? [] : null);
    if (la && lb) return JSON.stringify(la) === JSON.stringify(lb);
    return false;
  }

  function unterschiedeFelder(felder, alt, neu) {
    var liste = [{ key: 'bezeichnung', label: 'Bezeichnung' }].concat(felder);
    var res = [];
    liste.forEach(function (f) {
      var a = alt[f.key] === undefined ? null : alt[f.key];
      var n = neu[f.key] === undefined ? null : neu[f.key];
      if (!gleich(a, n)) res.push({ key: f.key, label: f.label, feld: f, alt: a, neu: n });
    });
    return res;
  }

  Daten.prototype.unterschiede = function (artId, alt, neu) {
    return unterschiedeFelder(MM.Fahrzeugarten.felder(artId), alt, neu);
  };

  function neuester(eintraege) {
    return eintraege.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
  }
  function nachNr(a, b) { return a.nr - b.nr; }

  /* ---------- Fahrzeuge ---------- */
  Daten.prototype.fahrzeugAnlegen = function (artId, roh) {
    var gewaehlt = MM.Fahrzeugarten.art(artId);
    if (!gewaehlt || gewaehlt.gruppe) {
      return Promise.resolve({ ok: false, fehler: { art: 'Bitte zuerst die Fahrzeugart wählen.' } });
    }
    if (!MM.Fahrzeugarten.sichtbar(artId)) {
      return Promise.resolve({ ok: false, fehler: { art: 'Diese Fahrzeugart ist ausgeblendet. Blende sie unter „Fahrzeugarten verwalten“ wieder ein.' } });
    }
    var p = this.pruefen(artId, roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var jetzt = this.jetzt();
    var fahrzeug = { id: neueId('fz'), datenraumId: this.datenraumId, art: artId, erstelltAm: jetzt };
    var eintrag = { id: neueId('en'), fahrzeugId: fahrzeug.id, nr: 1, werte: p.werte,
      quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
    return this.speicher.mehrereSpeichern([
      { tabelle: 'fahrzeuge', objekt: fahrzeug },
      { tabelle: 'eintraege', objekt: eintrag }
    ]).then(function () { return { ok: true, id: fahrzeug.id }; });
  };

  /* Änderung = neuer Eintrag. Der alte bleibt unverändert erhalten. */
  Daten.prototype.fahrzeugAendern = function (fahrzeugId, roh) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      var p = self.pruefen(f.fahrzeug.art, roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var diff = self.unterschiede(f.fahrzeug.art, f.aktuell.werte, p.werte);
      if (!diff.length) return { ok: true, id: fahrzeugId, geaendert: false };
      var eintrag = { id: neueId('en'), fahrzeugId: fahrzeugId, nr: f.aktuell.nr + 1, werte: p.werte,
        quelle: 'hand', korrekturZu: f.aktuell.id, erstelltAm: self.jetzt() };
      return self.speicher.speichern('eintraege', eintrag)
        .then(function () { return { ok: true, id: fahrzeugId, geaendert: true }; });
    });
  };

  /* Alle Fahrzeuge des Datenraums, jeweils mit aktuellem Stand (Schale 1). */
  Daten.prototype.fahrzeugListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('fahrzeuge'), this.speicher.alle('eintraege')]).then(function (r) {
      var nachFahrzeug = {};
      r[1].forEach(function (e) { (nachFahrzeug[e.fahrzeugId] = nachFahrzeug[e.fahrzeugId] || []).push(e); });
      var liste = r[0].filter(function (f) { return f.datenraumId === self.datenraumId; })
        .map(function (f) { return { fahrzeug: f, aktuell: neuester(nachFahrzeug[f.id] || []) }; })
        .filter(function (x) { return x.aktuell; });
      liste.sort(function (a, b) {
        return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return liste;
    });
  };

  /* Ein Fahrzeug mit aktuellem Stand und dem ganzen Verlauf (neueste zuerst). */
  Daten.prototype.fahrzeugLaden = function (id) {
    var self = this;
    return Promise.all([this.speicher.holen('fahrzeuge', id), this.speicher.wo('eintraege', 'fahrzeugId', id)])
      .then(function (r) {
        var fahrzeug = r[0];
        if (!fahrzeug || !r[1].length) return null;
        var eintraege = r[1].slice().sort(nachNr);
        var verlauf = eintraege.map(function (e, i) {
          var vorher = i > 0 ? eintraege[i - 1] : null;
          return { eintrag: e, vorher: vorher,
            aenderungen: vorher ? self.unterschiede(fahrzeug.art, vorher.werte, e.werte) : [] };
        }).reverse();
        return { fahrzeug: fahrzeug, aktuell: eintraege[eintraege.length - 1], verlauf: verlauf };
      });
  };

  /* ---------- Komponenten (Schale 3 und tiefer) ---------- */

  /* Alle Komponenten eines Fahrzeugs mit aktuellem Stand, unsortiert. */
  Daten.prototype.komponentenListe = function (fahrzeugId) {
    return Promise.all([this.speicher.wo('komponenten', 'fahrzeugId', fahrzeugId), this.speicher.alle('komponenteneintraege')])
      .then(function (r) {
        var nach = {};
        r[1].forEach(function (e) { (nach[e.komponenteId] = nach[e.komponenteId] || []).push(e); });
        return r[0].map(function (k) {
          var eintraege = (nach[k.id] || []).slice().sort(nachNr);
          return { komponente: k, eintraege: eintraege, aktuell: eintraege[eintraege.length - 1] || null };
        }).filter(function (x) { return x.aktuell; });
      });
  };

  /* Reihenfolge: Hauptkomponenten nach Art, sonst nach Bezeichnung. */
  Daten.prototype.sortiereKomponenten = function (liste) {
    return liste.slice().sort(function (a, b) {
      var ia = MM.Komponenten.artIndex(a.komponente.art), ib = MM.Komponenten.artIndex(b.komponente.art);
      if (!a.komponente.parentId && !b.komponente.parentId && ia !== ib) return ia - ib;
      return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
  };

  /*
   * Neue Komponente. parentId = null: Hauptkomponente (art ist dann Pflicht),
   * sonst gehört sie zu der genannten Komponente (Art entfällt).
   */
  Daten.prototype.komponenteAnlegen = function (fahrzeugId, parentId, artId, roh) {
    var self = this;
    var p = this.pruefenKomponente(roh);
    var fehler = p.fehler;
    if (!parentId && !MM.Komponenten.art(artId)) fehler.art = 'Bitte zuerst die Art der Hauptkomponente wählen.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    return Promise.all([
      this.speicher.holen('fahrzeuge', fahrzeugId),
      parentId ? this.speicher.holen('komponenten', parentId) : Promise.resolve(null)
    ]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (parentId && (!r[1] || r[1].fahrzeugId !== fahrzeugId)) {
        return { ok: false, fehler: { allgemein: 'Die übergeordnete Komponente wurde nicht gefunden.' } };
      }
      if (!parentId && artId === 'motor') {
        return self.kurznameKollision(fahrzeugId, null, p.werte).then(function (f) {
          if (f) return { ok: false, fehler: f };
          return komponenteSpeichern();
        });
      }
      return komponenteSpeichern();
    });

    function komponenteSpeichern() {
      var jetzt = self.jetzt();
      var k = { id: neueId('ko'), fahrzeugId: fahrzeugId, parentId: parentId || null,
        art: parentId ? null : artId, erstelltAm: jetzt };
      var e = { id: neueId('ke'), komponenteId: k.id, nr: 1, werte: p.werte,
        quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'komponenten', objekt: k },
        { tabelle: 'komponenteneintraege', objekt: e }
      ]).then(function () { return { ok: true, id: k.id }; });
    }
  };

  /*
   * Zwei Motoren eines Fahrzeugs sollen nicht denselben Kurznamen haben, sonst sind ihre Schalter nicht zu
   * unterscheiden. Geprüft wird nur, wenn der Nutzer einen Kurznamen selbst einträgt (ohne Eintrag gilt der Vorschlag).
   * Gibt null oder { kurzname: Text } zurück.
   */
  Daten.prototype.kurznameKollision = function (fahrzeugId, eigeneId, werte) {
    var kurz = werte && werte.kurzname ? String(werte.kurzname).trim().toUpperCase() : '';
    if (!kurz) return Promise.resolve(null);
    return this.komponentenListe(fahrzeugId).then(function (liste) {
      var anderer = liste.filter(function (k) {
        return MM.Komponenten.istMotor(k.komponente) && k.komponente.id !== eigeneId &&
          MM.Komponenten.kurzAnzeige(k.aktuell.werte).toUpperCase() === kurz;
      })[0];
      return anderer ? { kurzname: 'Der Motor „' + anderer.aktuell.werte.bezeichnung + '“ hat schon den Kurznamen ' + kurz + '. Bitte einen anderen wählen.' } : null;
    });
  };

  /* Änderung = neuer Eintrag, wie beim Fahrzeug. */
  Daten.prototype.komponenteAendern = function (komponenteId, roh) {
    var self = this;
    return this.komponenteLaden(komponenteId).then(function (c) {
      if (!c) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      var p = self.pruefenKomponente(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var diff = unterschiedeFelder(MM.Komponenten.felder(), c.aktuell.werte, p.werte);
      if (!diff.length) return { ok: true, id: komponenteId, geaendert: false };
      var pruefung = MM.Komponenten.istMotor(c.komponente) ? self.kurznameKollision(c.fahrzeug.id, komponenteId, p.werte) : Promise.resolve(null);
      return pruefung.then(function (f) {
        if (f) return { ok: false, fehler: f };
        var e = { id: neueId('ke'), komponenteId: komponenteId, nr: c.aktuell.nr + 1, werte: p.werte,
          quelle: 'hand', korrekturZu: c.aktuell.id, erstelltAm: self.jetzt() };
        return self.speicher.speichern('komponenteneintraege', e)
          .then(function () { return { ok: true, id: komponenteId, geaendert: true }; });
      });
    });
  };

  /*
   * Eine Komponente mit Stand, Verlauf, dem Weg von der Hauptkomponente bis
   * zu ihr (weg), den Teilen direkt darunter (kinder) und dem Fahrzeug.
   * tiefe: 3 = Hauptkomponente (Schale 3), 4 = Teil darunter, usw.
   */
  Daten.prototype.komponenteLaden = function (id) {
    var self = this;
    return this.speicher.holen('komponenten', id).then(function (k) {
      if (!k) return null;
      return Promise.all([self.komponentenListe(k.fahrzeugId), self.fahrzeugLaden(k.fahrzeugId)]).then(function (r) {
        var alle = r[0], fz = r[1];
        var nachId = {};
        alle.forEach(function (x) { nachId[x.komponente.id] = x; });
        var ich = nachId[id];
        if (!ich || !fz) return null;

        var weg = [];
        var p = ich.komponente.parentId;
        while (p && nachId[p]) { weg.unshift(nachId[p]); p = nachId[p].komponente.parentId; }

        function anzahlKinder(x) {
          return alle.filter(function (y) { return y.komponente.parentId === x.komponente.id; }).length;
        }
        var kinder = self.sortiereKomponenten(alle.filter(function (x) { return x.komponente.parentId === id; }))
          .map(function (x) { return { komponente: x.komponente, aktuell: x.aktuell, anzahlKinder: anzahlKinder(x) }; });

        var felder = MM.Komponenten.felder();
        var verlauf = ich.eintraege.map(function (e, i) {
          var vorher = i > 0 ? ich.eintraege[i - 1] : null;
          return { eintrag: e, vorher: vorher, aenderungen: vorher ? unterschiedeFelder(felder, vorher.werte, e.werte) : [] };
        }).reverse();

        return { komponente: ich.komponente, aktuell: ich.aktuell, verlauf: verlauf, weg: weg, kinder: kinder,
          fahrzeug: fz.fahrzeug, fahrzeugAktuell: fz.aktuell, tiefe: weg.length + 3 };
      });
    });
  };

  /* ---------- Hilfen für Zähler und Fristen ---------- */
  Daten.prototype.heute = function () {
    var d = new Date(this.jetzt());
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
  };

  function jahrVon(self) { return new Date(self.jetzt()).getFullYear(); }

  /* Prüft, ob Fahrzeug (und Komponente) existieren und zusammengehören. Gibt null oder einen Fehler zurück. */
  Daten.prototype.pruefeObjekt = function (fahrzeugId, komponenteId) {
    return Promise.all([
      this.speicher.holen('fahrzeuge', fahrzeugId),
      komponenteId ? this.speicher.holen('komponenten', komponenteId) : Promise.resolve(null)
    ]).then(function (r) {
      if (!r[0]) return { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' };
      if (komponenteId && (!r[1] || r[1].fahrzeugId !== fahrzeugId)) return { allgemein: 'Diese Komponente wurde nicht gefunden.' };
      return null;
    });
  };

  /* Verlauf der Angaben zu einem Objekt (Zähler, Frist): neueste zuerst, mit Unterschieden. */
  function verlaufAus(eintraege, felder) {
    var auf = eintraege.slice().sort(nachNr);
    return auf.map(function (e, i) {
      var vorher = i > 0 ? auf[i - 1] : null;
      return { eintrag: e, vorher: vorher, aenderungen: vorher ? unterschiedeFelder(felder, vorher.werte, e.werte) : [] };
    }).reverse();
  }
  function neuerVerlaufEintrag(typ, objektId, nr, werte, korrekturZu, jetzt) {
    return { id: neueId('vl'), objektTyp: typ, objektId: objektId, nr: nr, werte: werte,
      quelle: 'hand', korrekturZu: korrekturZu, erstelltAm: jetzt };
  }

  /* ---------- Zähler und Zählerstände ---------- */
  /*
   * Ein Zähler zählt Strecke (km) oder Betriebsstunden (h) und hängt am
   * Fahrzeug oder an einer einzelnen Komponente (zum Beispiel pro Motor).
   * Der Stand ist ein Verlauf von Einträgen. Der aktuelle Stand ist der
   * neueste Eintrag, ein Handeintrag hat Vorrang.
   */
  Daten.prototype.zaehlerAnlegen = function (fahrzeugId, komponenteId, art, roh) {
    var self = this;
    var p = pruefeWerte([], roh, jahrVon(this));
    var fehler = p.fehler;
    if (!MM.Fristen.zaehlerArt(art)) fehler.art = 'Bitte wählen, ob der Zähler Strecke oder Betriebsstunden zählt.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      var jetzt = self.jetzt();
      var z = { id: neueId('za'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, art: art, erstelltAm: jetzt };
      var e = neuerVerlaufEintrag('zaehler', z.id, 1, p.werte, null, jetzt);
      return self.speicher.mehrereSpeichern([{ tabelle: 'zaehler', objekt: z }, { tabelle: 'verlaeufe', objekt: e }])
        .then(function () { return { ok: true, id: z.id }; });
    });
  };

  Daten.prototype.zaehlerAendern = function (zaehlerId, roh) {
    var self = this;
    return this.zaehlerLaden(zaehlerId).then(function (z) {
      if (!z) return { ok: false, fehler: { allgemein: 'Dieser Zähler wurde nicht gefunden.' } };
      var p = pruefeWerte([], roh, jahrVon(self));
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (!unterschiedeFelder([], z.aktuell.werte, p.werte).length) return { ok: true, id: zaehlerId, geaendert: false };
      var e = neuerVerlaufEintrag('zaehler', zaehlerId, z.aktuell.nr + 1, p.werte, z.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: zaehlerId, geaendert: true }; });
    });
  };

  var FELDER_STAND = [
    { key: 'wert', label: 'Zählerstand', typ: 'zahl' },
    { key: 'datum', label: 'Abgelesen am', typ: 'datum' },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  Daten.prototype.zaehlerStandEintragen = function (zaehlerId, roh) {
    var self = this;
    var p = pruefeWerte(FELDER_STAND, roh, jahrVon(this), { ohneBezeichnung: true });
    var fehler = p.fehler, w = p.werte, heute = this.heute();
    if (w.wert === null && !fehler.wert) fehler.wert = 'Bitte den Zählerstand eingeben.';
    if (!w.datum && !fehler.datum) w.datum = heute;
    if (w.datum && w.datum > heute && !fehler.datum) fehler.datum = 'Das Datum liegt in der Zukunft.';
    return this.speicher.holen('zaehler', zaehlerId).then(function (z) {
      if (!z) return { ok: false, fehler: { allgemein: 'Dieser Zähler wurde nicht gefunden.' } };
      return self.speicher.wo('zaehlerstaende', 'zaehlerId', zaehlerId).then(function (staende) {
        var letzter = staende.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
        if (letzter && w.wert !== null && w.wert < letzter.wert && !fehler.wert) {
          var einheit = MM.Fristen.zaehlerArt(z.art).einheit;
          fehler.wert = 'Der Stand ist niedriger als der letzte Eintrag (' + MM.Hilfen.zahl(letzter.wert) + ' ' + einheit +
            ' vom ' + MM.Hilfen.datum(letzter.datum) + '). Zählerstände steigen. Wurde der Zähler getauscht, lege einen neuen Zähler an.';
        }
        if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
        var e = { id: neueId('zs'), zaehlerId: zaehlerId, nr: letzter ? letzter.nr + 1 : 1, wert: w.wert, datum: w.datum,
          notiz: w.notiz, quelle: 'hand', erstelltAm: self.jetzt() };
        return self.speicher.speichern('zaehlerstaende', e).then(function () { return { ok: true, id: e.id }; });
      });
    });
  };

  /* Alle Zähler eines Fahrzeugs mit Name, aktuellem Stand und Besitzer (Fahrzeug oder Komponente). */
  Daten.prototype.zaehlerListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([
      this.speicher.wo('zaehler', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.speicher.alle('zaehlerstaende'),
      this.komponentenListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'zaehler') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var sta = {}; r[2].forEach(function (e) { (sta[e.zaehlerId] = sta[e.zaehlerId] || []).push(e); });
      var kn = {}; r[3].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      return r[0].map(function (z) {
        var namen = (ver[z.id] || []).slice().sort(nachNr);
        var aktuell = namen[namen.length - 1];
        if (!aktuell) return null;
        var liste = (sta[z.id] || []).slice().sort(nachNr);
        var letzter = liste[liste.length - 1] || null;
        var art = MM.Fristen.zaehlerArt(z.art);
        var besitzer = z.komponenteId ? (kn[z.komponenteId] || 'Komponente') : 'Fahrzeug';
        return { zaehler: z, bezeichnung: aktuell.werte.bezeichnung, einheit: art.einheit, art: z.art,
          stand: letzter ? { wert: letzter.wert, datum: letzter.datum, quelle: letzter.quelle || 'hand' } : null,
          komponenteId: z.komponenteId, besitzer: besitzer,
          label: aktuell.werte.bezeichnung + ' (' + besitzer + ')' };
      }).filter(Boolean).sort(function (a, b) { return a.label.localeCompare(b.label, 'de', { numeric: true }); });
    });
  };

  Daten.prototype.zaehlerLaden = function (id) {
    var self = this;
    return this.speicher.holen('zaehler', id).then(function (z) {
      if (!z) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('zaehlerstaende', 'zaehlerId', id),
        self.fahrzeugLaden(z.fahrzeugId),
        self.komponentenListe(z.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[2]) return null;
        var staende = r[1].slice().sort(nachNr).reverse();
        var komp = z.komponenteId ? r[3].filter(function (k) { return k.komponente.id === z.komponenteId; })[0] : null;
        var art = MM.Fristen.zaehlerArt(z.art);
        return { zaehler: z, aktuell: eintraege[eintraege.length - 1], bezeichnung: eintraege[eintraege.length - 1].werte.bezeichnung,
          verlauf: verlaufAus(eintraege, []), staende: staende, stand: staende[0] || null, art: art, einheit: art.einheit,
          fahrzeug: r[2].fahrzeug, fahrzeugAktuell: r[2].aktuell, komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /*
   * Der Kilometer-Zähler eines Fahrzeugs (seit 2.0.20): der Zähler der Art Strecke, der am Fahrzeug selbst hängt.
   * Gibt es mehrere, gilt der mit dem jüngsten Stand (bei gleichem Datum der höhere). Null, wenn es keinen gibt.
   * Die Kilometer trägt der Nutzer von Hand ein; GPS wäre später nur eine weitere Quelle, nie Voraussetzung.
   */
  Daten.prototype.streckenZaehler = function (fahrzeugId) {
    return this.zaehlerListe(fahrzeugId).then(function (liste) {
      var meine = liste.filter(function (x) { return x.art === 'strecke' && !x.komponenteId; });
      if (!meine.length) return null;
      meine.sort(function (a, b) {
        var da = a.stand ? a.stand.datum : '', db = b.stand ? b.stand.datum : '';
        if (da !== db) return da < db ? 1 : -1;
        return (b.stand ? b.stand.wert : -1) - (a.stand ? a.stand.wert : -1);
      });
      var z = meine[0];
      return { id: z.zaehler.id, bezeichnung: z.bezeichnung, einheit: z.einheit, stand: z.stand };
    });
  };

  /* ---------- Motoren: Schalter Start und Stopp, Betriebsstunden (seit 2.0.19) ---------- */
  /*
   * Jeder Motor (Hauptkomponente der Art Motor) hat einen eigenen Schalter und einen eigenen Zähler
   * „Betriebsstunden“. Die Läufe (Start, Stopp) liegen als ein Dokument „motorlaeufe“ in „einstellungen“
   * (keine Umstellung des Speichers, in der Sicherung enthalten). Beim Stopp entsteht ein neuer
   * Zählerstand (Quelle „schalter“): letzter Stand plus Laufzeit. Nichts wird überschrieben:
   * Eine Korrektur der Stoppzeit ist ein weiterer Zählerstand (Quelle „korrektur“), der alte bleibt im Verlauf.
   */
  var MOTORLAEUFE = 'motorlaeufe';
  function laufDokument(self) {
    return self.speicher.holen('einstellungen', MOTORLAEUFE).then(function (d) { return d || { id: MOTORLAEUFE, laeufe: [] }; });
  }
  function motorFehler(text, feld) { var f = {}; f[feld || 'allgemein'] = text; return { ok: false, fehler: f }; }
  function neuesterStand(staende) { return staende.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null); }
  function zeitMs(iso) { return new Date(iso).getTime(); }

  /* Der Betriebsstunden-Zähler eines Motors. Gibt es keinen, entsteht er hier („Betriebsstunden“). */
  Daten.prototype.motorZaehler = function (fahrzeugId, komponenteId) {
    var self = this;
    return this.zaehlerListe(fahrzeugId).then(function (liste) {
      var z = liste.filter(function (x) { return x.komponenteId === komponenteId && x.art === 'stunden'; })[0];
      if (z) return { ok: true, id: z.zaehler.id };
      return self.zaehlerAnlegen(fahrzeugId, komponenteId, 'stunden', { bezeichnung: 'Betriebsstunden' });
    });
  };

  /*
   * Die Motoren eines Fahrzeugs in der Reihenfolge der Komponenten: Name, Kurzname (und was auf dem Knopf steht),
   * läuft oder nicht (seit wann), Zähler mit Stand und die letzten fünf Läufe. Ein ausgebauter Motor fehlt,
   * außer er läuft noch.
   */
  Daten.prototype.motorenListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.komponentenListe(fahrzeugId), this.zaehlerListe(fahrzeugId), laufDokument(this)]).then(function (r) {
      var heute = self.heute();
      var motoren = self.sortiereKomponenten(r[0].filter(function (k) { return MM.Komponenten.istMotor(k.komponente); }));
      return Promise.all(motoren.map(function (k) {
        var w = k.aktuell.werte, id = k.komponente.id;
        var meine = r[2].laeufe.filter(function (l) { return l.komponenteId === id; }).sort(function (a, b) { return zeitMs(b.start) - zeitMs(a.start); });
        var offen = meine.filter(function (l) { return !l.stopp; })[0] || null;
        if (w.ausgebautAm && w.ausgebautAm <= heute && !offen) return null;
        var z = r[1].filter(function (x) { return x.komponenteId === id && x.art === 'stunden'; })[0] || null;
        var zu = z ? self.speicher.wo('zaehlerstaende', 'zaehlerId', z.zaehler.id) : Promise.resolve([]);
        return zu.then(function (staende) {
          var neuester = neuesterStand(staende);
          var zu_ = meine.filter(function (l) { return l.stopp; });
          return {
            komponenteId: id, name: w.bezeichnung, kurzname: w.kurzname || null, kurz: MM.Komponenten.kurzAnzeige(w),
            laeuft: !!offen, seit: offen ? offen.start : null, laufId: offen ? offen.id : null,
            frageEreignisId: offen && offen.frage ? offen.frage.ereignisId : null, frageStufe: offen && offen.frage ? offen.frage.stufe : null,
            zaehler: z ? { id: z.zaehler.id, stand: z.stand, einheit: z.einheit } : null,
            laeufe: zu_.slice(0, 5).map(function (l, i) {
              return { id: l.id, start: l.start, stopp: l.stopp, stunden: l.stunden, standNachher: l.standNachher,
                korrigiert: !!(l.korrekturen && l.korrekturen.length),
                korrigierbar: i === 0 && !offen && !!neuester && neuester.id === l.standId };
            })
          };
        });
      })).then(function (liste) { return liste.filter(Boolean); });
    });
  };

  Daten.prototype.motorStart = function (komponenteId) {
    var self = this;
    return this.komponenteLaden(komponenteId).then(function (c) {
      if (!c || !MM.Komponenten.istMotor(c.komponente)) return motorFehler('Dieser Motor wurde nicht gefunden.');
      var w = c.aktuell.werte;
      if (w.ausgebautAm && w.ausgebautAm <= self.heute()) return motorFehler('Dieser Motor ist ausgebaut.');
      return laufDokument(self).then(function (dok) {
        if (dok.laeufe.some(function (l) { return l.komponenteId === komponenteId && !l.stopp; })) return motorFehler('Dieser Motor läuft schon.');
        return self.motorZaehler(c.fahrzeug.id, komponenteId).then(function (zr) {
          if (!zr.ok) return motorFehler('Der Zähler für die Betriebsstunden konnte nicht angelegt werden.');
          var lauf = { id: neueId('ml'), fahrzeugId: c.fahrzeug.id, komponenteId: komponenteId, zaehlerId: zr.id, start: self.jetzt(),
            stopp: null, standVorher: null, standNachher: null, standId: null, stunden: null };
          dok.laeufe.push(lauf);
          return self.speicher.speichern('einstellungen', dok).then(function () { return { ok: true, id: lauf.id, start: lauf.start, name: w.bezeichnung }; });
        });
      });
    });
  };

  /*
   * Motor stoppen. Ohne optionen: jetzt. Mit optionen.zeitpunkt (ISO): zu diesem Zeitpunkt, zum Beispiel die Zeit der
   * Ankunft (Motorstopp-Frage, seit 2.0.22). Der Zeitpunkt darf nicht vor dem Start und nicht nach jetzt liegen.
   * optionen.ereignisId: das Ereignis am Ziel, von dem die Stoppzeit stammt (kommt in die Notiz und an den Lauf).
   */
  Daten.prototype.motorStopp = function (komponenteId, optionen) {
    var self = this;
    optionen = optionen || {};
    return laufDokument(this).then(function (dok) {
      var lauf = dok.laeufe.filter(function (l) { return l.komponenteId === komponenteId && !l.stopp; })[0];
      if (!lauf) return motorFehler('Dieser Motor läuft nicht.');
      var jetzt = self.jetzt();
      var stoppZeit = jetzt, vomZiel = false;
      if (optionen.zeitpunkt) {
        if (isNaN(zeitMs(optionen.zeitpunkt))) return motorFehler('Die Stoppzeit ist keine gültige Zeit.', 'zeit');
        if (zeitMs(optionen.zeitpunkt) < zeitMs(lauf.start)) return motorFehler('Der Stopp kann nicht vor dem Start liegen (Start: ' + MM.Hilfen.zeitpunkt(lauf.start) + ').', 'zeit');
        if (zeitMs(optionen.zeitpunkt) > zeitMs(jetzt)) return motorFehler('Die Zeit liegt in der Zukunft.', 'zeit');
        stoppZeit = optionen.zeitpunkt; vomZiel = true;
      }
      var stunden = MM.Motoren.laufStunden(lauf.start, stoppZeit);
      if (stunden === null) return motorFehler('Der Start liegt nach der jetzigen Uhrzeit des Geräts. Bitte die Uhr des Geräts prüfen.');
      return self.speicher.holen('zaehler', lauf.zaehlerId).then(function (z) {
        return z ? { ok: true, id: z.id } : self.motorZaehler(lauf.fahrzeugId, komponenteId);
      }).then(function (zr) {
        if (!zr.ok) return motorFehler('Der Zähler für die Betriebsstunden wurde nicht gefunden.');
        return self.speicher.wo('zaehlerstaende', 'zaehlerId', zr.id).then(function (staende) {
          var letzter = neuesterStand(staende);
          var basis = letzter ? letzter.wert : 0;
          var neu = MM.Motoren.runde(basis + stunden);
          var stand = { id: neueId('zs'), zaehlerId: zr.id, nr: letzter ? letzter.nr + 1 : 1, wert: neu, datum: vomZiel ? MM.Motoren.ortsdatum(stoppZeit) : self.heute(),
            notiz: 'Motorlauf ' + MM.Hilfen.zeitpunkt(lauf.start) + ' bis ' + MM.Hilfen.zeitpunkt(stoppZeit) + ' (' + MM.Motoren.stundenText(stunden) + ')' + (vomZiel ? ', Stoppzeit von der Ankunft übernommen' : ''),
            quelle: 'schalter', laufId: lauf.id, erstelltAm: jetzt };
          lauf.stopp = stoppZeit; lauf.zaehlerId = zr.id; lauf.standVorher = basis; lauf.standNachher = neu; lauf.standId = stand.id; lauf.stunden = stunden;
          if (vomZiel) lauf.stoppVonEreignis = optionen.ereignisId || true;
          return self.speicher.mehrereSpeichern([{ tabelle: 'zaehlerstaende', objekt: stand }, { tabelle: 'einstellungen', objekt: dok }])
            .then(function () { return { ok: true, id: lauf.id, stunden: stunden, stand: neu, ohneStartstand: !letzter, stopp: stoppZeit, vomZiel: vomZiel }; });
        });
      });
    });
  };

  /*
   * Der Nutzer sagt bei der Motorstopp-Frage „Läuft weiter“. stufe 'jetzt': die Frage nach der Ankunft ist beantwortet,
   * der Vorschlag nach der Wartezeit kommt später noch. stufe 'vorschlag': für dieses Ereignis kommt nichts mehr.
   */
  Daten.prototype.motorStoppFrageVerneinen = function (laufId, ereignisId, stufe) {
    var self = this;
    if (stufe !== 'jetzt' && stufe !== 'vorschlag') return Promise.resolve(motorFehler('Unbekannte Stufe der Frage.'));
    return laufDokument(this).then(function (dok) {
      var lauf = dok.laeufe.filter(function (l) { return l.id === laufId; })[0];
      if (!lauf) return motorFehler('Dieser Lauf wurde nicht gefunden.');
      if (lauf.stopp) return { ok: true, id: laufId, geaendert: false };
      var alt = lauf.frage && lauf.frage.ereignisId === ereignisId ? lauf.frage.stufe : null;
      if (alt === 'vorschlag' || alt === stufe) return { ok: true, id: laufId, geaendert: false };
      lauf.frage = { ereignisId: ereignisId, stufe: stufe };
      return self.speicher.speichern('einstellungen', dok).then(function () { return { ok: true, id: laufId, geaendert: true }; });
    });
  };

  /*
   * Stoppzeit eines beendeten Laufs korrigieren (zum Beispiel, wenn das Stoppen vergessen wurde).
   * roh: { datum, zeit } in Ortszeit. Nur der letzte Lauf eines Motors, und nur solange der Zählerstand danach nicht
   * weiterverändert wurde (sonst bleibt nur, den richtigen Stand von Hand einzutragen).
   */
  Daten.prototype.motorLaufKorrigieren = function (laufId, roh) {
    var self = this; roh = roh || {};
    return laufDokument(this).then(function (dok) {
      var lauf = dok.laeufe.filter(function (l) { return l.id === laufId; })[0];
      if (!lauf) return motorFehler('Dieser Lauf wurde nicht gefunden.');
      if (!lauf.stopp) return motorFehler('Dieser Motor läuft noch. Erst stoppen, dann die Zeit korrigieren.');
      var neuStopp = MM.Motoren.zeitpunktAusOrtszeit(roh.datum, roh.zeit);
      if (!neuStopp) return motorFehler('Bitte Datum und Uhrzeit angeben, zum Beispiel 14:30.', 'zeit');
      if (zeitMs(neuStopp) < zeitMs(lauf.start)) return motorFehler('Der Stopp kann nicht vor dem Start liegen (Start: ' + MM.Hilfen.zeitpunkt(lauf.start) + ').', 'zeit');
      var jetzt = self.jetzt();
      if (zeitMs(neuStopp) > zeitMs(jetzt)) return motorFehler('Die Zeit liegt in der Zukunft.', 'zeit');
      if (dok.laeufe.some(function (l) { return l.komponenteId === lauf.komponenteId && l.id !== lauf.id && zeitMs(l.start) >= zeitMs(lauf.start); })) {
        return motorFehler('Nur der letzte Lauf dieses Motors lässt sich korrigieren. Trage den richtigen Zählerstand von Hand ein.');
      }
      return self.speicher.wo('zaehlerstaende', 'zaehlerId', lauf.zaehlerId).then(function (staende) {
        var letzter = neuesterStand(staende);
        if (!letzter || letzter.id !== lauf.standId) {
          return motorFehler('Seit diesem Lauf wurde der Zählerstand geändert. Die Zeit lässt sich nicht mehr korrigieren. Trage den richtigen Zählerstand von Hand ein.');
        }
        if (MM.Motoren.ortsdatum(neuStopp) === MM.Motoren.ortsdatum(lauf.stopp) && MM.Motoren.ortszeit(neuStopp) === MM.Motoren.ortszeit(lauf.stopp)) {
          return { ok: true, id: lauf.id, geaendert: false };
        }
        var stunden = MM.Motoren.laufStunden(lauf.start, neuStopp);
        var neu = MM.Motoren.runde((lauf.standVorher || 0) + stunden);
        var stand = { id: neueId('zs'), zaehlerId: lauf.zaehlerId, nr: letzter.nr + 1, wert: neu, datum: MM.Motoren.ortsdatum(neuStopp),
          notiz: 'Korrektur: Motor gestoppt ' + MM.Hilfen.zeitpunkt(neuStopp) + ' statt ' + MM.Hilfen.zeitpunkt(lauf.stopp) + ' (' + MM.Motoren.stundenText(stunden) + ' Laufzeit)',
          quelle: 'korrektur', laufId: lauf.id, erstelltAm: jetzt };
        lauf.korrekturen = (lauf.korrekturen || []).concat([{ stoppAlt: lauf.stopp, standAlt: lauf.standNachher, korrigiertAm: jetzt }]);
        lauf.stopp = neuStopp; lauf.stunden = stunden; lauf.standNachher = neu; lauf.standId = stand.id;
        return self.speicher.mehrereSpeichern([{ tabelle: 'zaehlerstaende', objekt: stand }, { tabelle: 'einstellungen', objekt: dok }])
          .then(function () { return { ok: true, id: lauf.id, geaendert: true, stunden: stunden, stand: neu }; });
      });
    });
  };

  /* ---------- Fristen ---------- */
  Daten.prototype.pruefenFrist = function (roh, mitAusgang) {
    var p = pruefeWerte(MM.Fristen.felder(mitAusgang), roh, jahrVon(this));
    var w = p.werte, f = p.fehler;
    if (!w.kategorie && !f.kategorie) f.kategorie = 'Bitte die Art der Frist wählen.';
    if (w.kalenderWert) { if (!w.kalenderEinheit) w.kalenderEinheit = 'monate'; } else { w.kalenderEinheit = null; }
    if (!w.wirkung) w.wirkung = 'warnen';
    if (w.vorwarnTage === null || w.vorwarnTage === undefined) w.vorwarnTage = 0;
    var hatZ = !!w.zaehlerId, hatW = w.zaehlerWert !== null && w.zaehlerWert !== undefined;
    if (hatZ && !hatW && !f.zaehlerWert) f.zaehlerWert = 'Bitte angeben, nach wie viel Strecke oder Stunden die Frist fällig wird.';
    if (!hatZ && hatW && !f.zaehlerId) f.zaehlerId = 'Bitte einen Zähler wählen oder die Zählergrenze leer lassen.';
    if (hatW && w.zaehlerWert <= 0 && !f.zaehlerWert) f.zaehlerWert = 'Die Grenze muss größer als null sein.';
    if (!w.kalenderWert && !(hatZ && hatW) && !f.kalenderWert && !f.zaehlerWert && !f.zaehlerId) {
      f.kalenderWert = 'Bitte mindestens eine Grenze angeben: Zeit oder Zähler.';
    }
    if (!hatZ) { w.zaehlerId = null; w.zaehlerWert = null; w.vorwarnZaehler = null; }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Letzte Erledigung: das späteste Datum, bei gleichem Datum die zuletzt eingetragene. */
  function letzteDurchfuehrung(liste) {
    return liste.reduce(function (a, b) {
      if (!a) return b;
      if (b.datum !== a.datum) return b.datum > a.datum ? b : a;
      return b.erstelltAm >= a.erstelltAm ? b : a;
    }, null);
  }

  function statusZu(self, frist, werte, durchfuehrungen, zaehlerInfo) {
    var letzte = letzteDurchfuehrung(durchfuehrungen);
    if (!letzte) return { status: 'unbekannt', kalender: null, zaehler: null, grund: 'Es gibt noch keine Erledigung als Ausgangswert.' };
    var res = MM.Fristen.berechne({ werte: werte, letzte: letzte, stand: zaehlerInfo ? zaehlerInfo.stand : null, heute: self.heute() });
    res.letzte = letzte;
    return res;
  }

  Daten.prototype.fristAnlegen = function (fahrzeugId, komponenteId, roh) {
    var self = this;
    var p = this.pruefenFrist(roh, true);
    var w = p.werte, fehler = p.fehler, heute = this.heute();
    var zuletztAm = w.zuletztAm, zuletztStand = w.zuletztStand;
    delete w.zuletztAm; delete w.zuletztStand;
    if (zuletztAm && zuletztAm > heute && !fehler.zuletztAm) fehler.zuletztAm = 'Das Datum liegt in der Zukunft.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return self.zaehlerListe(fahrzeugId).then(function (liste) {
        var z = w.zaehlerId ? liste.filter(function (x) { return x.zaehler.id === w.zaehlerId; })[0] : null;
        if (w.zaehlerId && !z) return { ok: false, fehler: { zaehlerId: 'Dieser Zähler gehört nicht zu diesem Fahrzeug.' } };
        var basisDatum = zuletztAm || heute;
        var basisStand = zuletztStand;
        if (basisStand === null && !zuletztAm && z && z.stand) basisStand = z.stand.wert;
        var e2 = {};
        if (z && basisStand === null) e2.zuletztStand = 'Bitte den Zählerstand angeben, bei dem die Frist zuletzt erledigt wurde, oder trage zuerst einen aktuellen Zählerstand ein.';
        if (z && basisStand !== null && z.stand && basisStand > z.stand.wert) {
          e2.zuletztStand = 'Dieser Stand ist höher als der aktuelle Zählerstand (' + MM.Hilfen.zahl(z.stand.wert) + ' ' + z.einheit + '). Trage zuerst den aktuellen Zählerstand ein.';
        }
        if (Object.keys(e2).length) return { ok: false, fehler: e2 };

        var jetzt = self.jetzt();
        var fr = { id: neueId('fr'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, erstelltAm: jetzt };
        var ve = neuerVerlaufEintrag('frist', fr.id, 1, w, null, jetzt);
        var du = { id: neueId('du'), fristId: fr.id, datum: basisDatum, zaehlerstand: z ? basisStand : null,
          notiz: 'Ausgangswert bei Anlage der Frist', art: 'ausgangswert', quelle: 'hand', erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'fristen', objekt: fr }, { tabelle: 'verlaeufe', objekt: ve }, { tabelle: 'durchfuehrungen', objekt: du }
        ]).then(function () { return { ok: true, id: fr.id }; });
      });
    });
  };

  Daten.prototype.fristAendern = function (fristId, roh) {
    var self = this;
    return this.fristLaden(fristId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Diese Frist wurde nicht gefunden.' } };
      var p = self.pruefenFrist(roh, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.zaehlerListe(f.frist.fahrzeugId).then(function (liste) {
        if (p.werte.zaehlerId && !liste.some(function (x) { return x.zaehler.id === p.werte.zaehlerId; })) {
          return { ok: false, fehler: { zaehlerId: 'Dieser Zähler gehört nicht zu diesem Fahrzeug.' } };
        }
        if (!unterschiedeFelder(MM.Fristen.felder(false), f.aktuell.werte, p.werte).length) return { ok: true, id: fristId, geaendert: false };
        var e = neuerVerlaufEintrag('frist', fristId, f.aktuell.nr + 1, p.werte, f.aktuell.id, self.jetzt());
        return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: fristId, geaendert: true }; });
      });
    });
  };

  var FELDER_ERLEDIGT = [
    { key: 'datum', label: 'Erledigt am', typ: 'datum' },
    { key: 'zaehlerstand', label: 'Zählerstand dabei', typ: 'zahl', min: 0 },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  /* Eine Erledigung (Prüfung, Kontrolle, Arbeit). Sie setzt die Rechnung der Frist neu an. */
  Daten.prototype.durchfuehrungAnlegen = function (fristId, roh) {
    var self = this;
    var p = pruefeWerte(FELDER_ERLEDIGT, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, fehler = p.fehler, heute = this.heute();
    if (!w.datum && !fehler.datum) w.datum = heute;
    if (w.datum && w.datum > heute && !fehler.datum) fehler.datum = 'Das Datum liegt in der Zukunft.';
    return this.fristLaden(fristId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Diese Frist wurde nicht gefunden.' } };
      var z = f.zaehler;
      var neuerStand = null;
      if (z && !fehler.zaehlerstand) {
        if (w.zaehlerstand === null) {
          if (w.datum === heute && z.stand) w.zaehlerstand = z.stand.wert;
          else fehler.zaehlerstand = 'Bitte den Zählerstand angeben, bei dem die Frist erledigt wurde.';
        } else if (f.letzte && f.letzte.zaehlerstand !== null && f.letzte.zaehlerstand !== undefined && w.zaehlerstand < f.letzte.zaehlerstand) {
          fehler.zaehlerstand = 'Der Stand ist niedriger als bei der letzten Erledigung (' + MM.Hilfen.zahl(f.letzte.zaehlerstand) + ' ' + z.einheit + ').';
        }
        if (!fehler.zaehlerstand && w.zaehlerstand !== null && (!z.stand || w.zaehlerstand > z.stand.wert)) neuerStand = w.zaehlerstand;
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };

      var jetzt = self.jetzt();
      var du = { id: neueId('du'), fristId: fristId, datum: w.datum, zaehlerstand: w.zaehlerstand, notiz: w.notiz,
        art: 'erledigt', quelle: 'hand', erstelltAm: jetzt };
      var liste = [{ tabelle: 'durchfuehrungen', objekt: du }];
      if (neuerStand === null) return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: du.id }; });
      /* Ist der Stand höher als der bisher bekannte, wird er auch im Zähler eingetragen (eine Quelle). */
      return self.speicher.wo('zaehlerstaende', 'zaehlerId', z.zaehler.id).then(function (staende) {
        var nr = staende.reduce(function (m, e) { return Math.max(m, e.nr); }, 0) + 1;
        liste.push({ tabelle: 'zaehlerstaende', objekt: { id: neueId('zs'), zaehlerId: z.zaehler.id, nr: nr, wert: neuerStand,
          datum: w.datum, notiz: 'Bei Erledigung: ' + f.aktuell.werte.bezeichnung, quelle: 'hand', erstelltAm: jetzt } });
        return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: du.id }; });
      });
    });
  };

  /* Alle Fristen eines Fahrzeugs mit gerechnetem Stand. Sortiert: überfällig zuerst. */
  Daten.prototype.fristenListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([
      this.speicher.wo('fristen', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.speicher.alle('durchfuehrungen'),
      this.zaehlerListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'frist') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var du = {}; r[2].forEach(function (e) { (du[e.fristId] = du[e.fristId] || []).push(e); });
      var zl = {}; r[3].forEach(function (z) { zl[z.zaehler.id] = z; });
      var res = r[0].map(function (fr) {
        var eintraege = (ver[fr.id] || []).slice().sort(nachNr);
        var aktuell = eintraege[eintraege.length - 1];
        if (!aktuell) return null;
        var z = aktuell.werte.zaehlerId ? zl[aktuell.werte.zaehlerId] || null : null;
        return { frist: fr, aktuell: aktuell, zaehler: z, status: statusZu(self, fr, aktuell.werte, du[fr.id] || [], z) };
      }).filter(Boolean);
      res.sort(function (a, b) {
        var d = MM.Fristen.rang(b.status.status) - MM.Fristen.rang(a.status.status);
        return d || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true });
      });
      return res;
    });
  };

  Daten.prototype.fristLaden = function (id) {
    var self = this;
    return this.speicher.holen('fristen', id).then(function (fr) {
      if (!fr) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('durchfuehrungen', 'fristId', id),
        self.zaehlerListe(fr.fahrzeugId),
        self.fahrzeugLaden(fr.fahrzeugId),
        self.komponentenListe(fr.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[3]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        var zl = r[2];
        var z = aktuell.werte.zaehlerId ? zl.filter(function (x) { return x.zaehler.id === aktuell.werte.zaehlerId; })[0] || null : null;
        var du = r[1].slice().sort(function (a, b) { return a.datum !== b.datum ? (a.datum < b.datum ? 1 : -1) : (a.erstelltAm < b.erstelltAm ? 1 : -1); });
        var verlauf = verlaufAus(eintraege, MM.Fristen.felder(false));
        /* Zähler im Verlauf mit Namen statt Kennung zeigen */
        var namen = {}; zl.forEach(function (x) { namen[x.zaehler.id] = x.label; });
        verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'zaehlerId') { u.alt = u.alt ? (namen[u.alt] || 'unbekannter Zähler') : null; u.neu = u.neu ? (namen[u.neu] || 'unbekannter Zähler') : null; }
          });
        });
        var komp = fr.komponenteId ? r[4].filter(function (k) { return k.komponente.id === fr.komponenteId; })[0] : null;
        return { frist: fr, aktuell: aktuell, verlauf: verlauf, durchfuehrungen: du, letzte: letzteDurchfuehrung(r[1]),
          zaehler: z, zaehlerListe: zl, status: statusZu(self, fr, aktuell.werte, r[1], z),
          fahrzeug: r[3].fahrzeug, fahrzeugAktuell: r[3].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /* Pro Fahrzeug: wie viele Fristen sind überfällig oder bald fällig? */
  Daten.prototype.fristenUebersicht = function () {
    var self = this;
    return this.fahrzeugListe().then(function (liste) {
      return Promise.all(liste.map(function (x) { return self.fristenListe(x.fahrzeug.id); })).then(function (alle) {
        var res = {};
        liste.forEach(function (x, i) {
          var z = { ueberfaellig: 0, bald: 0, unbekannt: 0 };
          alle[i].forEach(function (f) { if (z[f.status.status] !== undefined) z[f.status.status]++; });
          res[x.fahrzeug.id] = z;
        });
        return res;
      });
    });
  };

  /* ---------- Werkstatt: Vorgänge (Störungen und Arbeiten, seit 2.0.24) ---------- */
  /*
   * Ein Vorgang ist eine Störung oder eine Arbeit am Fahrzeug oder an einer Komponente.
   * Er ist offen oder erledigt, nichts wird gelöscht. Jede Änderung ist ein neuer Eintrag im
   * Verlauf. Aus einer Störung wird eine Arbeit (selbst oder durch eine Werkstatt).
   * Offene Vorgänge mit Einschränkung bremsen das Fahrzeug: Für versprochene Aktivitäten
   * kommt dann eine Warnung, und der Nutzer entscheidet pro Aktivität: trotzdem nutzen
   * oder absagen (Absagen läuft über das vorhandene Stornieren der Aktivität).
   */
  Daten.prototype.pruefenVorgang = function (roh, art) {
    var p = pruefeWerte(MM.Werkstatt.felder(art), roh, jahrVon(this), {
      bezeichnungFehler: 'Bitte kurz sagen, worum es geht, zum Beispiel „Motor springt schlecht an“ oder „Ölwechsel“.' });
    var w = p.werte, f = p.fehler, heute = this.heute();
    if (!w.auswirkung && !f.auswirkung) {
      if (art === 'stoerung') f.auswirkung = 'Bitte wählen, wie weit die Störung das Fahrzeug einschränkt.';
      else w.auswirkung = 'keine';
    }
    if (!w.gemeldetAm && !f.gemeldetAm) w.gemeldetAm = heute;
    if (w.gemeldetAm && w.gemeldetAm > heute && !f.gemeldetAm) f.gemeldetAm = 'Das Datum liegt in der Zukunft.';
    if (art === 'arbeit') {
      if (!w.ausfuehrung && !f.ausfuehrung) f.ausfuehrung = 'Bitte wählen, ob du die Arbeit selbst erledigst oder eine Werkstatt sie macht.';
    } else { w.ausfuehrung = null; w.arbeit = null; }
    /* Verweis auf die Adressliste (seit 2.0.25), nur bei einer Arbeit. Ob es die Adresse gibt, prüft pruefeAdresseDesVorgangs. */
    var aid = roh && typeof roh.adresseId === 'string' ? roh.adresseId.trim() : '';
    w.adresseId = (art === 'arbeit' && aid) ? aid : null;
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Prüft die gewählte Adresse eines Vorgangs. behalte = die Adresse, die schon am Vorgang hängt: sie bleibt erlaubt, auch wenn sie inzwischen ausgeblendet ist. */
  function pruefeAdresseDesVorgangs(self, adresseId, behalte) {
    if (!adresseId) return Promise.resolve(null);
    return self.mitVerlaufLaden('adressen', adresseId, adresseFelder()).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { adresseId: 'Diese Adresse gibt es nicht.' };
      if (x.aktuell.werte.ausgeblendet === 'ja' && adresseId !== behalte) return { adresseId: 'Diese Adresse ist ausgeblendet. Blende sie in der Adressliste wieder ein, wenn du sie brauchst.' };
      return null;
    });
  }

  Daten.prototype.vorgangAnlegen = function (fahrzeugId, komponenteId, art, roh) {
    var self = this;
    if (art !== 'stoerung' && art !== 'arbeit') return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Art von Vorgang gibt es nicht.' } });
    var p = this.pruefenVorgang(roh, art);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return pruefeAdresseDesVorgangs(self, p.werte.adresseId, null).then(function (af) {
        if (af) return { ok: false, fehler: af };
        var w = p.werte;
        w.art = art; w.status = 'offen'; w.erledigtAm = null; w.erledigtNotiz = null;
        var jetzt = self.jetzt();
        var v = { id: neueId('vg'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'vorgaenge', objekt: v }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('vorgang', v.id, 1, w, null, jetzt) }
        ]).then(function () { return { ok: true, id: v.id }; });
      });
    });
  };

  /* Ein Vorgang in einem neuen Stand. Die Änderung bekommt die Werte, gibt neue Werte oder einen Fehler zurück. */
  function vorgangNeuerStand(self, id, aenderung) {
    return self.vorgangLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
      var neu = aenderung(Object.assign({}, x.aktuell.werte), x);
      if (neu.fehler) return { ok: false, fehler: neu.fehler };
      return self.mitVerlaufAendern('vorgang', id, { aktuell: x.aktuell }, neu.werte, MM.Werkstatt.felderAlle());
    });
  }

  Daten.prototype.vorgangAendern = function (id, roh) {
    var self = this;
    var aid = roh && typeof roh.adresseId === 'string' ? roh.adresseId.trim() : '';
    return this.vorgangLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
      var aw = x.aktuell.werte;
      return pruefeAdresseDesVorgangs(self, aw.art === 'arbeit' ? aid : '', aw.adresseId || null);
    }).then(function (af) {
      if (af && af.ok === false) return af;
      if (af) return { ok: false, fehler: af };
      return vorgangNeuerStand(self, id, function (alt) {
        if (alt.status === 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist erledigt. Öffne ihn zuerst wieder, wenn du etwas ändern willst.' } };
        var p = self.pruefenVorgang(roh, alt.art);
        if (!p.ok) return { fehler: p.fehler };
        return { werte: Object.assign(alt, p.werte) };
      });
    });
  };

  /* Aus einer offenen Störung eine Arbeit machen: selbst erledigen oder durch eine Werkstatt. */
  Daten.prototype.vorgangZuArbeit = function (id, roh) {
    var self = this;
    var p = pruefeWerte(MM.Werkstatt.felder('arbeit').filter(function (x) { return x.key === 'ausfuehrung' || x.key === 'arbeit'; }), roh, jahrVon(this), { ohneBezeichnung: true });
    if (!p.werte.ausfuehrung && !p.fehler.ausfuehrung) p.fehler.ausfuehrung = 'Bitte wählen, ob du die Arbeit selbst erledigst oder eine Werkstatt sie macht.';
    if (Object.keys(p.fehler).length) return Promise.resolve({ ok: false, fehler: p.fehler });
    var aid = roh && typeof roh.adresseId === 'string' ? roh.adresseId.trim() : '';
    return pruefeAdresseDesVorgangs(this, aid, null).then(function (af) {
      if (af) return { ok: false, fehler: af };
      return vorgangNeuerStand(self, id, function (alt) {
        if (alt.status === 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist erledigt.' } };
        if (alt.art !== 'stoerung') return { fehler: { allgemein: 'Das ist schon eine Arbeit.' } };
        alt.art = 'arbeit'; alt.ausfuehrung = p.werte.ausfuehrung; alt.arbeit = p.werte.arbeit; alt.adresseId = aid || null;
        return { werte: alt };
      });
    });
  };

  Daten.prototype.vorgangErledigen = function (id, roh) {
    var self = this;
    var p = pruefeWerte([{ key: 'datum', label: 'Erledigt am', typ: 'datum' }, { key: 'notiz', label: 'Notiz', typ: 'text' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var heute = this.heute();
    if (!p.werte.datum && !p.fehler.datum) p.werte.datum = heute;
    if (p.werte.datum && p.werte.datum > heute && !p.fehler.datum) p.fehler.datum = 'Das Datum liegt in der Zukunft.';
    if (Object.keys(p.fehler).length) return Promise.resolve({ ok: false, fehler: p.fehler });
    return vorgangNeuerStand(this, id, function (alt) {
      if (alt.status === 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist schon erledigt.' } };
      if (alt.gemeldetAm && p.werte.datum < alt.gemeldetAm) return { fehler: { datum: 'Das Datum liegt vor dem Tag, an dem der Vorgang eingetragen wurde (' + MM.Hilfen.datum(alt.gemeldetAm) + ').' } };
      alt.status = 'erledigt'; alt.erledigtAm = p.werte.datum; alt.erledigtNotiz = p.werte.notiz;
      return { werte: alt };
    });
  };

  Daten.prototype.vorgangWiederOeffnen = function (id) {
    return vorgangNeuerStand(this, id, function (alt) {
      if (alt.status !== 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist nicht erledigt.' } };
      alt.status = 'offen'; alt.erledigtAm = null; alt.erledigtNotiz = null;
      return { werte: alt };
    });
  };

  function vorgangEintrag(v, eintraege, namen) {
    var l = eintraege.slice().sort(nachNr);
    var a = l[l.length - 1];
    if (!a) return null;
    return { vorgang: v, aktuell: a, komponenteId: v.komponenteId, besitzer: v.komponenteId ? (namen[v.komponenteId] || 'Komponente') : null };
  }
  function vorgangSortieren(res) {
    res.sort(function (a, b) {
      var d = MM.Werkstatt.rang(b.aktuell.werte) - MM.Werkstatt.rang(a.aktuell.werte);
      if (d) return d;
      var wa = a.aktuell.werte, wb = b.aktuell.werte;
      var da = wa.status === 'erledigt' ? (wa.erledigtAm || '') : (wa.gemeldetAm || ''), db = wb.status === 'erledigt' ? (wb.erledigtAm || '') : (wb.gemeldetAm || '');
      if (da !== db) return da < db ? 1 : -1;
      return wa.bezeichnung.localeCompare(wb.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
    return res;
  }

  /* Alle Vorgänge eines Fahrzeugs und seiner Komponenten. Was das Fahrzeug am meisten bremst, steht oben, Erledigtes unten. */
  Daten.prototype.vorgaengeListe = function (fahrzeugId) {
    return Promise.all([this.speicher.wo('vorgaenge', 'fahrzeugId', fahrzeugId), this.speicher.alle('verlaeufe'), this.komponentenListe(fahrzeugId)]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'vorgang') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var kn = {}; r[2].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      return vorgangSortieren(r[0].map(function (v) { return vorgangEintrag(v, ver[v.id] || [], kn); }).filter(Boolean));
    });
  };

  /* Pro Fahrzeug: wie viele Vorgänge sind offen, wie viele bremsen das Fahrzeug? */
  Daten.prototype.vorgaengeUebersicht = function () {
    var self = this;
    return this.fahrzeugListe().then(function (liste) {
      return Promise.all(liste.map(function (x) { return self.vorgaengeListe(x.fahrzeug.id); })).then(function (alle) {
        var res = {};
        liste.forEach(function (x, i) {
          var z = { offen: 0, nicht: 0, bedingt: 0 };
          alle[i].forEach(function (v) {
            var w = v.aktuell.werte;
            if (w.status !== 'offen') return;
            z.offen++;
            if (MM.Werkstatt.bremst(w)) z[w.auswirkung]++;
          });
          res[x.fahrzeug.id] = z;
        });
        return res;
      });
    });
  };

  /* Entscheidungen „trotzdem nutzen“: neueste je Vorgang und Aktivität. */
  function neuesteEntscheidungen(liste) {
    var res = {};
    liste.forEach(function (e) {
      var k = e.vorgangId + '|' + e.aktivitaetId;
      if (!res[k] || e.nr > res[k].nr) res[k] = e;
    });
    return res;
  }

  Daten.prototype.vorgangLaden = function (id) {
    var self = this;
    return this.speicher.holen('vorgaenge', id).then(function (v) {
      if (!v) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.fahrzeugLaden(v.fahrzeugId),
        self.komponentenListe(v.fahrzeugId),
        self.speicher.wo('vorgangsentscheidungen', 'vorgangId', id),
        self.adressenListe()
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[1]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        /* Im Verlauf steht bei der Adresse ihr Name, nicht ihre Kennung. */
        var adressOpt = r[4].map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; });
        var felder = MM.Werkstatt.felderAlle().map(function (f) { return f.key === 'adresseId' ? Object.assign({}, f, { optionen: adressOpt }) : f; });
        var adresse = aktuell.werte.adresseId ? (r[4].filter(function (a) { return a.objekt.id === aktuell.werte.adresseId; })[0] || null) : null;
        var komp = v.komponenteId ? r[2].filter(function (k) { return k.komponente.id === v.komponenteId; })[0] : null;
        var neueste = neuesteEntscheidungen(r[3]), entscheidungen = {};
        Object.keys(neueste).forEach(function (k) { var e = neueste[k]; entscheidungen[e.aktivitaetId] = { entscheidung: e.entscheidung, am: e.erstelltAm }; });
        return { vorgang: v, aktuell: aktuell, verlauf: verlaufAus(eintraege, felder), adresse: adresse,
          fahrzeug: r[1].fahrzeug, fahrzeugAktuell: r[1].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null,
          entscheidungen: entscheidungen };
      });
    });
  };

  /*
   * Warnung für ein Fahrzeug: Bremsen offene Vorgänge das Fahrzeug, und ist es für die nächste Zeit
   * versprochen (Aktivität läuft oder ist geplant, nicht storniert)? Gibt immer ein Ergebnis zurück:
   * stufe 'nicht', 'bedingt' oder 'ok', die bremsenden Vorgänge und die betroffenen Aktivitäten.
   * Eine Aktivität gilt als entschieden („trotzdem nutzen“), wenn das für jeden bremsenden Vorgang bestätigt ist.
   */
  Daten.prototype.vorgangWarnung = function (fahrzeugId) {
    return Promise.all([this.vorgaengeListe(fahrzeugId), this.aktivitaetenListe(), this.speicher.alle('vorgangsentscheidungen')]).then(function (r) {
      var bremsend = r[0].filter(function (x) { return MM.Werkstatt.bremst(x.aktuell.werte); });
      var stufe = MM.Werkstatt.einsatz(r[0].map(function (x) { return x.aktuell.werte; }));
      var neueste = neuesteEntscheidungen(r[2]);
      var aktivitaeten = stufe === 'ok' ? [] : r[1].filter(function (a) {
        return a.aktuell.werte.fahrzeugId === fahrzeugId && (a.status === 'laeuft' || a.status === 'geplant');
      }).map(function (a) {
        var entschieden = bremsend.every(function (b) { var e = neueste[b.vorgang.id + '|' + a.objekt.id]; return e && e.entscheidung === 'trotzdem'; });
        return { aktivitaet: a, trotzdem: entschieden };
      });
      return { stufe: stufe, vorgaenge: bremsend, aktivitaeten: aktivitaeten };
    });
  };

  /* Entscheidung zu einer Aktivität: 'trotzdem' (trotzdem nutzen) oder 'offen' (zurückgenommen). Nichts wird gelöscht. */
  Daten.prototype.vorgangEntscheiden = function (vorgangId, aktivitaetId, entscheidung) {
    var self = this;
    if (entscheidung !== 'trotzdem' && entscheidung !== 'offen') return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Entscheidung gibt es nicht.' } });
    return Promise.all([this.speicher.holen('vorgaenge', vorgangId), this.speicher.holen('aktivitaeten', aktivitaetId), this.speicher.wo('vorgangsentscheidungen', 'vorgangId', vorgangId)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
      if (!r[1]) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var nr = r[2].filter(function (e) { return e.aktivitaetId === aktivitaetId; }).reduce(function (m, e) { return Math.max(m, e.nr); }, 0) + 1;
      var e = { id: neueId('vt'), vorgangId: vorgangId, aktivitaetId: aktivitaetId, nr: nr, entscheidung: entscheidung, erstelltAm: self.jetzt() };
      return self.speicher.speichern('vorgangsentscheidungen', e).then(function () { return { ok: true, id: e.id }; });
    });
  };

  /* ---------- Werkstatt: Adressen (Werkstätten, Lieferanten, Händler, seit 2.0.25) ---------- */
  /*
   * Eine einzige, zentrale Liste im Datenraum des Nutzers, nicht pro Fahrzeug. Jede Änderung ist ein neuer
   * Eintrag im Verlauf. Eine Adresse, auf die ein Vorgang verweist, wird nie gelöscht: Es gibt kein Löschen,
   * nur Ausblenden (wie bei Orten und Gebieten). Der Vorgang verweist mit adresseId auf sie.
   */
  function adresseFelder() { return MM.Werkstatt.adressFelder().concat([{ key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }]); }

  Daten.prototype.pruefenAdresse = function (roh) {
    var p = pruefeWerte(MM.Werkstatt.adressFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen eingeben, zum Beispiel „Autohaus Müller“.' });
    var w = p.werte, f = p.fehler;
    if (!w.art && !f.art) f.art = 'Bitte wählen, ob es eine Werkstatt, ein Lieferant oder ein Händler ist.';
    if (w.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(w.email)) f.email = 'Das ist keine gültige E-Mail-Adresse.';
    if (w.telefon && !/^[0-9+\-\/() ]{5,}$/.test(w.telefon)) f.telefon = 'Bitte nur Ziffern, Leerzeichen und + - / ( ) eingeben.';
    w.ausgeblendet = roh && roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Welche Vorgänge verweisen (im aktuellen Stand) auf welche Adresse? { adresseId: [{ vorgang, aktuell }] } */
  function vorgaengeNachAdresse(vorgaenge, verlaeufe) {
    var neu = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === 'vorgang' && (!neu[e.objektId] || e.nr > neu[e.objektId].nr)) neu[e.objektId] = e; });
    var res = {};
    vorgaenge.forEach(function (v) {
      var a = neu[v.id];
      if (a && a.werte.adresseId) (res[a.werte.adresseId] = res[a.werte.adresseId] || []).push({ vorgang: v, aktuell: a });
    });
    return res;
  }

  /* Alle Adressen, nach Namen sortiert, mit der Zahl der Vorgänge, die darauf verweisen. */
  Daten.prototype.adressenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('adressen'), this.speicher.alle('verlaeufe'), this.speicher.alle('vorgaenge')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'adresse');
      var karte = vorgaengeNachAdresse(r[2], r[1]);
      liste.forEach(function (x) { x.anzahlVorgaenge = (karte[x.objekt.id] || []).length; });
      return liste;
    });
  };

  function gleicheAdresse(liste, name, art, ausser) {
    var n = name.toLowerCase();
    return liste.some(function (x) { return x.objekt.id !== ausser && x.aktuell.werte.art === art && x.aktuell.werte.bezeichnung.toLowerCase() === n; });
  }

  Daten.prototype.adresseAnlegen = function (roh) {
    var self = this;
    var p = this.pruefenAdresse(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    p.werte.ausgeblendet = 'nein';
    return this.adressenListe().then(function (liste) {
      if (gleicheAdresse(liste, p.werte.bezeichnung, p.werte.art)) return { ok: false, fehler: { bezeichnung: 'Diese Adresse gibt es schon.' } };
      return self.mitVerlaufAnlegen('adressen', 'adresse', 'ad', p.werte);
    });
  };

  Daten.prototype.adresseAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('adressen', id, adresseFelder()), this.adressenListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Adresse wurde nicht gefunden.' } };
      var p = self.pruefenAdresse(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicheAdresse(r[1], p.werte.bezeichnung, p.werte.art, id)) return { ok: false, fehler: { bezeichnung: 'Diese Adresse gibt es schon.' } };
      return self.mitVerlaufAendern('adresse', id, x, p.werte, adresseFelder());
    });
  };

  /* Eine Adresse mit Verlauf und den Vorgängen, die darauf verweisen (mit Fahrzeug, offene zuerst). */
  Daten.prototype.adresseLaden = function (id) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('adressen', id, adresseFelder()), this.speicher.alle('vorgaenge'), this.speicher.alle('verlaeufe'), this.fahrzeugListe()]).then(function (r) {
      var x = r[0];
      if (!x || x.objekt.datenraumId !== self.datenraumId) return null;
      var fz = {}; r[3].forEach(function (f) { fz[f.fahrzeug.id] = f.aktuell.werte.bezeichnung; });
      x.vorgaenge = (vorgaengeNachAdresse(r[1], r[2])[id] || []).map(function (m) {
        var w = m.aktuell.werte;
        return { id: m.vorgang.id, bezeichnung: w.bezeichnung, art: w.art, status: w.status, fahrzeugName: fz[m.vorgang.fahrzeugId] || 'Fahrzeug' };
      }).sort(function (a, b) {
        if (a.status !== b.status) return a.status === 'offen' ? -1 : 1;
        return a.bezeichnung.localeCompare(b.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return x;
    });
  };

  /* ---------- Kosten (seit 2.0.27) ---------- */
  /*
   * Eine einzige Kosten-Liste für alle Fahrzeuge (Tabelle „kosten“, Index fahrzeugId). Ein Posten gehört zu einem
   * Fahrzeug und hat die Gruppe Fixkosten, variable Kosten oder Instandhaltung. Die Gruppe lässt sich nachträglich
   * nicht ändern. Verweise (in den Werten, damit sie im Verlauf stehen): komponenteId, aktivitaetId (nur variable
   * Kosten), vorgangId (nur Instandhaltung, nur beim Anlegen). Jede Änderung ist ein neuer Eintrag im Verlauf, nichts
   * wird gelöscht: Ein Posten lässt sich ausblenden und wieder einblenden, ausgeblendete rechnen nicht mit.
   * Die Kostenstammdaten (Tabelle „kostenstamm“, eine Zeile je Fahrzeug, Verlauf) halten Wert, Wertverlust und den
   * Vergleichspreis. Der Wertverlust ist keine Eingabe, sondern wird in der Auswertung gerechnet.
   */
  function trimmed2(v) { return typeof v === 'string' ? v.trim() : ''; }

  /* Geldbeträge: Der Punkt als Tausendertrennzeichen („2.400“, „1.234,50“) gilt als Tausenderpunkt, nicht als Komma:
     „2.400“ sind 2400 Euro und nicht 2,4. Alles andere (Komma oder Punkt als Dezimalzeichen, „12,5“ und „12.5“) bleibt, wie es ist. */
  function geldRoh(v) {
    if (typeof v !== 'string') return v;
    var t = v.replace(/\s/g, '').replace(/€/g, '');
    return /^\d{1,3}(\.\d{3})+(,\d+)?$/.test(t) ? t.replace(/\./g, '') : t;
  }

  Daten.prototype.pruefenKosten = function (roh, gruppe) {
    roh = Object.assign({}, roh || {});
    roh.betrag = geldRoh(roh.betrag);
    var g = MM.Kosten.GRUPPEN.some(function (x) { return x.wert === gruppe; }) ? gruppe : null;
    if (!g) return { werte: {}, fehler: { gruppe: 'Bitte wählen: Fixkosten, variable Kosten oder Instandhaltung.' }, ok: false };
    var p = pruefeWerte(MM.Kosten.felder(g), roh, jahrVon(this), {
      bezeichnungFehler: 'Bitte kurz sagen, wofür der Betrag ist, zum Beispiel „Liegeplatz Heimathafen“ oder „Zündkerzen“.' });
    var w = p.werte, f = p.fehler;
    w.gruppe = g;
    if (w.betrag === null && !f.betrag) f.betrag = 'Bitte einen Betrag eingeben.';
    else if (w.betrag !== null && !f.betrag) {
      if (!(w.betrag > 0)) f.betrag = 'Der Betrag muss größer als 0 sein.';
      else if (w.betrag > 10000000) f.betrag = 'Der Betrag ist zu groß.';
      else w.betrag = MM.Kosten.runde(w.betrag);
    }
    if (!w.datum && !f.datum) w.datum = this.heute();
    if (g === 'fix') {
      if (!w.rhythmus && !f.rhythmus) f.rhythmus = 'Bitte wählen, wie oft der Betrag fällig wird.';
      if (w.rhythmus === 'einmalig') w.bis = null;
      if (w.bis && w.datum && w.bis < w.datum && !f.bis) f.bis = 'Das Ende kann nicht vor dem Beginn liegen.';
    } else { w.rhythmus = 'einmalig'; w.bis = null; }
    if (!w.grundlage && !f.grundlage) w.grundlage = 'eingegeben';
    w.komponenteId = trimmed2(roh.komponenteId) || null;
    var aid = trimmed2(roh.aktivitaetId);
    if (aid && g !== 'variabel') f.aktivitaetId = 'Eine Aktivität kann nur bei variablen Kosten gewählt werden.';
    w.aktivitaetId = g === 'variabel' && aid ? aid : null;
    w.vorgangId = null;
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Prüft, ob es die verknüpften Dinge gibt und ob sie zum Fahrzeug gehören. Gibt null oder die Fehler zurück. */
  function pruefeKostenVerweise(self, fahrzeugId, w, vorgangId) {
    return Promise.all([
      w.komponenteId ? self.speicher.holen('komponenten', w.komponenteId) : Promise.resolve(null),
      w.aktivitaetId ? self.aktivitaetLaden(w.aktivitaetId) : Promise.resolve(null),
      vorgangId ? self.speicher.holen('vorgaenge', vorgangId) : Promise.resolve(null)
    ]).then(function (r) {
      var fehler = {};
      if (w.komponenteId && (!r[0] || r[0].fahrzeugId !== fahrzeugId)) fehler.komponenteId = 'Diese Komponente gibt es an diesem Fahrzeug nicht.';
      if (w.aktivitaetId && (!r[1] || r[1].fahrzeug.id !== fahrzeugId)) fehler.aktivitaetId = 'Diese Aktivität gibt es für dieses Fahrzeug nicht.';
      if (vorgangId && (!r[2] || r[2].fahrzeugId !== fahrzeugId)) fehler.vorgangId = 'Diesen Vorgang gibt es an diesem Fahrzeug nicht.';
      return { fehler: Object.keys(fehler).length ? fehler : null, vorgang: r[2] };
    });
  }

  /* Neuer Posten. roh.gruppe ist Pflicht, roh.vorgangId (freiwillig) hängt den Betrag an einen Vorgang der Werkstatt. */
  Daten.prototype.kostenAnlegen = function (fahrzeugId, roh) {
    var self = this;
    roh = roh || {};
    var p = this.pruefenKosten(roh, roh.gruppe);
    var vid = trimmed2(roh.vorgangId);
    if (vid && p.werte.gruppe && p.werte.gruppe !== 'instandhaltung') p.fehler.gruppe = 'Ein Betrag an einem Vorgang gehört zur Instandhaltung.';
    if (Object.keys(p.fehler).length) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.pruefeObjekt(fahrzeugId, null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return pruefeKostenVerweise(self, fahrzeugId, p.werte, vid || null).then(function (v) {
        if (v.fehler) return { ok: false, fehler: v.fehler };
        var w = p.werte;
        w.vorgangId = vid || null;
        if (v.vorgang && !w.komponenteId) w.komponenteId = v.vorgang.komponenteId || null;
        return self.mitVerlaufAnlegen('kosten', 'kosten', 'ko', w, { fahrzeugId: fahrzeugId });
      });
    });
  };

  Daten.prototype.kostenAendern = function (id, roh) {
    var self = this;
    roh = roh || {};
    return this.mitVerlaufLaden('kosten', id, MM.Kosten.felderAlle()).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieser Posten wurde nicht gefunden.' } };
      var alt = x.aktuell.werte;
      var p = self.pruefenKosten(roh, alt.gruppe);
      if (!Object.prototype.hasOwnProperty.call(roh, 'ausgeblendet')) p.werte.ausgeblendet = alt.ausgeblendet || 'nein';
      if (Object.keys(p.fehler).length) return { ok: false, fehler: p.fehler };
      return pruefeKostenVerweise(self, x.objekt.fahrzeugId, p.werte, null).then(function (v) {
        if (v.fehler) return { ok: false, fehler: v.fehler };
        p.werte.vorgangId = alt.vorgangId || null;
        return self.mitVerlaufAendern('kosten', id, x, p.werte, MM.Kosten.felderAlle());
      });
    });
  };

  /* Ausblenden (der Posten rechnet nicht mehr mit) oder wieder einblenden. Nichts wird gelöscht. */
  Daten.prototype.kostenAusblenden = function (id, ausblenden) {
    var self = this;
    return this.mitVerlaufLaden('kosten', id, MM.Kosten.felderAlle()).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieser Posten wurde nicht gefunden.' } };
      var w = Object.assign({}, x.aktuell.werte, { ausgeblendet: ausblenden ? 'ja' : 'nein' });
      return self.mitVerlaufAendern('kosten', id, x, w, MM.Kosten.felderAlle());
    });
  };

  /* Namen für die Verweise der Posten eines Fahrzeugs: { komponenten, aktivitaeten, vorgaenge } (Kennung -> Name). */
  function kostenNamen(self, fahrzeugId) {
    return Promise.all([self.komponentenListe(fahrzeugId), self.aktivitaetenListe(), self.vorgaengeListe(fahrzeugId)]).then(function (r) {
      var k = {}, a = {}, v = {};
      r[0].forEach(function (x) { k[x.komponente.id] = x.aktuell.werte.bezeichnung; });
      r[1].forEach(function (x) { a[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      r[2].forEach(function (x) { v[x.vorgang.id] = x.aktuell.werte.bezeichnung; });
      return { komponenten: k, aktivitaeten: a, vorgaenge: v };
    });
  }

  function kostenSortieren(liste) {
    liste.sort(function (a, b) {
      var da = a.aktuell.werte.datum || '', db = b.aktuell.werte.datum || '';
      if (da !== db) return da < db ? 1 : -1;
      return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
    return liste;
  }

  /* Alle Posten eines Fahrzeugs (auch ausgeblendete), neueste zuerst, mit den Namen der Verweise. */
  Daten.prototype.kostenListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.speicher.wo('kosten', 'fahrzeugId', fahrzeugId), this.speicher.alle('verlaeufe'), kostenNamen(this, fahrzeugId)]).then(function (r) {
      var ver = {};
      r[1].forEach(function (e) { if (e.objektTyp === 'kosten') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var n = r[2];
      var liste = r[0].filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
        var l = (ver[o.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1];
        if (!a) return null;
        var w = a.werte;
        return { objekt: o, aktuell: a, komponenteName: w.komponenteId ? (n.komponenten[w.komponenteId] || 'Komponente') : null,
          aktivitaetName: w.aktivitaetId ? (n.aktivitaeten[w.aktivitaetId] || 'Aktivität') : null,
          vorgangName: w.vorgangId ? (n.vorgaenge[w.vorgangId] || 'Vorgang') : null };
      }).filter(Boolean);
      return kostenSortieren(liste);
    });
  };

  /* Ein Posten mit Verlauf (die Verweise im Verlauf mit Namen) und den verknüpften Dingen. */
  Daten.prototype.kostenLaden = function (id) {
    var self = this;
    return this.speicher.holen('kosten', id).then(function (o) {
      if (!o || o.datenraumId !== self.datenraumId) return null;
      return Promise.all([self.speicher.wo('verlaeufe', 'objektId', id), self.fahrzeugLaden(o.fahrzeugId), kostenNamen(self, o.fahrzeugId)]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[1]) return null;
        var n = r[2], aktuell = eintraege[eintraege.length - 1];
        function opt(karte) { return Object.keys(karte).map(function (k) { return { wert: k, label: karte[k] }; }); }
        var felder = MM.Kosten.felderAlle().map(function (f) {
          if (f.key === 'komponenteId') return Object.assign({}, f, { optionen: opt(n.komponenten) });
          if (f.key === 'aktivitaetId') return Object.assign({}, f, { optionen: opt(n.aktivitaeten) });
          if (f.key === 'vorgangId') return Object.assign({}, f, { optionen: opt(n.vorgaenge) });
          return f;
        });
        var w = aktuell.werte;
        return { objekt: o, aktuell: aktuell, verlauf: verlaufAus(eintraege, felder), fahrzeug: r[1].fahrzeug, fahrzeugAktuell: r[1].aktuell,
          komponenteName: w.komponenteId ? (n.komponenten[w.komponenteId] || 'Komponente') : null,
          aktivitaetName: w.aktivitaetId ? (n.aktivitaeten[w.aktivitaetId] || 'Aktivität') : null,
          vorgangName: w.vorgangId ? (n.vorgaenge[w.vorgangId] || 'Vorgang') : null };
      });
    });
  };

  /* ---------- Kostenstammdaten eines Fahrzeugs: Wert, Wertverlust, Vergleichspreis ---------- */
  function kostenstammId(fahrzeugId) { return 'ks-' + fahrzeugId; }

  Daten.prototype.kostenstammLaden = function (fahrzeugId) {
    return this.mitVerlaufLaden('kostenstamm', kostenstammId(fahrzeugId), MM.Kosten.stammFelder());
  };

  Daten.prototype.pruefenKostenstamm = function (roh) {
    roh = Object.assign({}, roh || {});
    roh.fahrzeugwert = geldRoh(roh.fahrzeugwert); roh.vergleichPreisTag = geldRoh(roh.vergleichPreisTag);
    var p = pruefeWerte(MM.Kosten.stammFelder(), roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler, heute = this.heute();
    if (w.fahrzeugwert !== null && !f.fahrzeugwert) {
      if (!(w.fahrzeugwert > 0)) f.fahrzeugwert = 'Der Wert muss größer als 0 sein.';
      else if (w.fahrzeugwert > 1000000000) f.fahrzeugwert = 'Der Wert ist zu groß.';
      else w.fahrzeugwert = MM.Kosten.runde(w.fahrzeugwert);
    }
    if (w.fahrzeugwert && !w.wertDatum && !f.wertDatum) w.wertDatum = heute;
    if (w.wertDatum && w.wertDatum > heute && !f.wertDatum) f.wertDatum = 'Das Datum liegt in der Zukunft.';
    if (w.wertverlustProzent !== null && !f.wertverlustProzent && !w.fahrzeugwert && !f.fahrzeugwert) f.fahrzeugwert = 'Für einen Wertverlust braucht die App den Wert des Fahrzeugs.';
    if (w.vergleichPreisTag !== null && !f.vergleichPreisTag) {
      if (!(w.vergleichPreisTag > 0)) f.vergleichPreisTag = 'Der Preis muss größer als 0 sein.';
      else if (w.vergleichPreisTag > 1000000) f.vergleichPreisTag = 'Der Preis ist zu groß.';
      else w.vergleichPreisTag = MM.Kosten.runde(w.vergleichPreisTag);
    }
    if (w.vergleichPreisTag === null) { w.vergleichGrundlage = null; }
    else if (!w.vergleichGrundlage && !f.vergleichGrundlage) w.vergleichGrundlage = 'geschaetzt';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.kostenstammSetzen = function (fahrzeugId, roh) {
    var self = this;
    var p = this.pruefenKostenstamm(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.pruefeObjekt(fahrzeugId, null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return self.kostenstammLaden(fahrzeugId).then(function (x) {
        if (x) return self.mitVerlaufAendern('kostenstamm', kostenstammId(fahrzeugId), x, p.werte, MM.Kosten.stammFelder());
        var jetzt = self.jetzt();
        var o = { id: kostenstammId(fahrzeugId), datenraumId: self.datenraumId, fahrzeugId: fahrzeugId, erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'kostenstamm', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kostenstamm', o.id, 1, p.werte, null, jetzt) }
        ]).then(function () { return { ok: true, id: o.id, geaendert: true }; });
      });
    });
  };

  /* „Der Wert stimmt noch“: der Stand des Werts wird auf heute gesetzt, der Wert bleibt. */
  Daten.prototype.kostenstammWertBestaetigen = function (fahrzeugId) {
    var self = this;
    return this.kostenstammLaden(fahrzeugId).then(function (x) {
      if (!x || !(Number(x.aktuell.werte.fahrzeugwert) > 0)) return { ok: false, fehler: { allgemein: 'Es ist noch kein Wert eingetragen.' } };
      var w = Object.assign({}, x.aktuell.werte, { wertDatum: self.heute() });
      return self.mitVerlaufAendern('kostenstamm', kostenstammId(fahrzeugId), x, w, MM.Kosten.stammFelder());
    });
  };

  /* ---------- Kosten: Auswertung ---------- */
  function jahrGueltig(jahr, standard) {
    var j = Number(jahr);
    return isFinite(j) && Math.floor(j) === j && j >= 1900 && j <= 2200 ? j : standard;
  }

  /*
   * Die Auswertung eines Fahrzeugs für ein Jahr (ohne Angabe: dieses Jahr). Rechnung steht in MM.Kosten.auswertung.
   * Dazu die Posten, nach Gruppen geordnet: posten.<gruppe> = die Posten, die im Jahr etwas zählen (mit imJahr),
   * andere = sichtbare Posten ohne Anteil in diesem Jahr, ausgeblendet = ausgeblendete Posten.
   */
  Daten.prototype.kostenAuswertung = function (fahrzeugId, jahr) {
    var self = this;
    var heute = this.heute();
    var j = jahrGueltig(jahr, +heute.slice(0, 4));
    return Promise.all([this.fahrzeugLaden(fahrzeugId), this.kostenListe(fahrzeugId), this.kostenstammLaden(fahrzeugId),
      this.aktivitaetenListe(), this.zaehlerListe(fahrzeugId), this.speicher.alle('zaehlerstaende')]).then(function (r) {
      if (!r[0]) return null;
      var liste = r[1], stamm = r[2];
      var sichtbar = liste.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; });
      var aktivitaeten = r[3].filter(function (a) { return a.aktuell.werte.fahrzeugId === fahrzeugId && a.status !== 'storniert'; })
        .map(function (a) { return { vonDatum: a.aktuell.werte.vonDatum, bisDatum: a.aktuell.werte.bisDatum }; });
      var km = r[4].filter(function (z) { return z.art === 'strecke' && !z.komponenteId; });
      var zaehler = km.length ? km[0] : null;
      var staende = zaehler ? r[5].filter(function (s) { return s.zaehlerId === zaehler.zaehler.id; }).map(function (s) { return { datum: s.datum, wert: s.wert }; }) : [];
      var a = MM.Kosten.auswertung({ jahr: j, heute: heute, eintraege: sichtbar.map(function (x) { return { werte: x.aktuell.werte }; }),
        stamm: stamm ? stamm.aktuell.werte : null, aktivitaeten: aktivitaeten, staende: staende });
      var posten = { fix: [], variabel: [], instandhaltung: [] }, andere = [];
      sichtbar.forEach(function (x) {
        var y = Object.assign({}, x, { imJahr: MM.Kosten.imJahr(x.aktuell.werte, j, heute) });
        if (y.imJahr.summe > 0 && posten[x.aktuell.werte.gruppe]) posten[x.aktuell.werte.gruppe].push(y); else andere.push(y);
      });
      a.ok = true;
      a.fahrzeug = r[0].fahrzeug; a.fahrzeugAktuell = r[0].aktuell;
      a.stamm = stamm; a.posten = posten; a.andere = andere;
      a.ausgeblendet = liste.filter(function (x) { return x.aktuell.werte.ausgeblendet === 'ja'; });
      a.kmZaehler = zaehler ? zaehler.bezeichnung : null;
      a.heute = heute;
      return a;
    });
  };

  /* Pro Fahrzeug die Auswertung des Jahres, für die Kostenstartseite. */
  Daten.prototype.kostenUebersicht = function (jahr) {
    var self = this;
    return this.fahrzeugListe().then(function (liste) {
      return Promise.all(liste.map(function (x) { return self.kostenAuswertung(x.fahrzeug.id, jahr); })).then(function (alle) {
        return liste.map(function (x, i) { return { fahrzeug: x.fahrzeug, aktuell: x.aktuell, auswertung: alle[i] }; });
      });
    });
  };

  /* ---------- Dokumente ---------- */
  /*
   * Ein Dokument ist eine Datei vom Gerät oder ein Link. Die Datei liegt in
   * einer eigenen Ablage, getrennt vom Eintrag. Das Dokument selbst bleibt
   * unverändert: Wer eine andere Datei will, legt ein neues Dokument an.
   */
  Daten.prototype.pruefenDokument = function (roh, quelle) {
    var p = pruefeWerte(MM.Dokumente.felder(quelle), roh, jahrVon(this));
    var w = p.werte, f = p.fehler;
    if (!w.art && !f.art) f.art = 'Bitte die Art des Dokuments wählen.';
    if (quelle === 'link') {
      if (!String(roh.link == null ? '' : roh.link).trim()) f.link = 'Bitte den Link eingeben.';
      else {
        var l = MM.Dokumente.normalisiereLink(roh.link);
        if (!l) { if (!f.link) f.link = 'Das ist kein gültiger Link. Er soll mit http oder https beginnen, zum Beispiel https://www.beispiel.de/anleitung.pdf'; }
        else w.link = l;
      }
    } else { w.link = null; }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  function istQuotaFehler(err) {
    return !!err && (err.name === 'QuotaExceededError' || /quota/i.test(String(err.message || '')));
  }

  /* vorgangId (seit 2.0.26, freiwillig): Das Dokument hängt an diesem Werkstatt-Vorgang (Bild, Beleg, Reparaturbuch-Seite). Fahrzeug und Komponente
     sind dann die des Vorgangs. */
  Daten.prototype.dokumentAnlegen = function (fahrzeugId, komponenteId, roh, vorgangId) {
    var self = this;
    roh = roh || {};
    var quelle = roh.quelle, datei = roh.datei, fehler = {};
    if (quelle !== 'datei' && quelle !== 'link') fehler.quelle = 'Bitte wählen, ob du eine Datei oder einen Link ablegen möchtest.';
    if (quelle === 'datei' && !(datei && typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Bitte eine Datei auswählen.';
    var rohW = Object.assign({}, roh);
    if (quelle === 'datei' && !String(rohW.bezeichnung == null ? '' : rohW.bezeichnung).trim() && datei && datei.name) {
      rohW.bezeichnung = String(datei.name).replace(/\.[^.]+$/, '');
    }
    var p = this.pruefenDokument(rohW, quelle);
    Object.keys(p.fehler).forEach(function (k) { fehler[k] = p.fehler[k]; });
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    var vorgangPruefung = vorgangId ? this.speicher.holen('vorgaenge', vorgangId) : Promise.resolve(null);
    return vorgangPruefung.then(function (vg) {
      if (vorgangId) {
        if (!vg || vg.fahrzeugId !== fahrzeugId) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
        komponenteId = vg.komponenteId || null;
      }
      return self.pruefeObjekt(fahrzeugId, komponenteId || null);
    }).then(function (f) {
      if (f && f.ok === false) return f;
      if (f) return { ok: false, fehler: f };
      var jetzt = self.jetzt();
      var w = p.werte;
      w.quelle = quelle;
      w.dateiName = quelle === 'datei' ? String(datei.name || 'Datei') : null;
      w.dateiTyp = quelle === 'datei' ? String(datei.type || '') : null;
      w.dateiGroesse = quelle === 'datei' ? datei.size : null;
      var d = { id: neueId('do'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, vorgangId: vorgangId || null, erstelltAm: jetzt };
      var liste = [
        { tabelle: 'dokumente', objekt: d },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('dokument', d.id, 1, w, null, jetzt) }
      ];
      if (quelle === 'datei') {
        liste.push({ tabelle: 'dateien', objekt: { id: neueId('da'), dokumentId: d.id, name: w.dateiName, mime: w.dateiTyp,
          groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      }
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: d.id }; })
        .catch(function (err) {
          if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei. Gib Platz frei oder wähle eine kleinere Datei.' } };
          throw err;
        });
    });
  };

  Daten.prototype.dokumentAendern = function (dokumentId, roh) {
    var self = this;
    return this.dokumentLaden(dokumentId).then(function (d) {
      if (!d) return { ok: false, fehler: { allgemein: 'Dieses Dokument wurde nicht gefunden.' } };
      var quelle = d.aktuell.werte.quelle;
      var p = self.pruefenDokument(roh, quelle);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, d.aktuell.werte, p.werte);
      if (!unterschiedeFelder(MM.Dokumente.felder(quelle), d.aktuell.werte, neu).length) return { ok: true, id: dokumentId, geaendert: false };
      var e = neuerVerlaufEintrag('dokument', dokumentId, d.aktuell.nr + 1, neu, d.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: dokumentId, geaendert: true }; });
    });
  };

  Daten.prototype.dokumentLaden = function (id) {
    var self = this;
    return this.speicher.holen('dokumente', id).then(function (d) {
      if (!d) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('dateien', 'dokumentId', id),
        self.fahrzeugLaden(d.fahrzeugId),
        self.komponentenListe(d.fahrzeugId),
        d.vorgangId ? self.vorgangLaden(d.vorgangId) : Promise.resolve(null)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[2]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        var komp = d.komponenteId ? r[3].filter(function (k) { return k.komponente.id === d.komponenteId; })[0] : null;
        var datei = r[1][0] ? { id: r[1][0].id, name: r[1][0].name, mime: r[1][0].mime, groesse: r[1][0].groesse } : null;
        return { dokument: d, aktuell: aktuell, verlauf: verlaufAus(eintraege, MM.Dokumente.felder(aktuell.werte.quelle)), datei: datei,
          fahrzeug: r[2].fahrzeug, fahrzeugAktuell: r[2].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null,
          vorgang: r[4] ? r[4].vorgang : null, vorgangAktuell: r[4] ? r[4].aktuell : null };
      });
    });
  };

  /* Die Datei selbst (mit Inhalt), zum Öffnen oder Speichern. */
  Daten.prototype.dateiHolen = function (dokumentId) {
    return this.speicher.wo('dateien', 'dokumentId', dokumentId).then(function (l) { return l[0] || null; });
  };

  /* Alle Dokumente eines Fahrzeugs und seiner Komponenten. Zuerst das Fahrzeug, dann die Komponenten nach Name. */
  Daten.prototype.dokumenteListe = function (fahrzeugId) {
    return Promise.all([
      this.speicher.wo('dokumente', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.komponentenListe(fahrzeugId),
      this.vorgaengeListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'dokument') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var kn = {}; r[2].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      var vn = {}; r[3].forEach(function (v) { vn[v.vorgang.id] = v.aktuell.werte.bezeichnung; });
      var res = r[0].map(function (d) {
        var l = (ver[d.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1];
        if (!a) return null;
        return { dokument: d, aktuell: a, komponenteId: d.komponenteId, besitzer: d.komponenteId ? (kn[d.komponenteId] || 'Komponente') : null,
          vorgangId: d.vorgangId || null, vorgangName: d.vorgangId ? (vn[d.vorgangId] || 'Vorgang') : null };
      }).filter(Boolean);
      res.sort(function (a, b) {
        if (!a.besitzer !== !b.besitzer) return a.besitzer ? 1 : -1;
        var o = (a.besitzer || '').localeCompare(b.besitzer || '', 'de', { numeric: true, sensitivity: 'base' });
        if (o) return o;
        var art = MM.Dokumente.artIndex(a.aktuell.werte.art) - MM.Dokumente.artIndex(b.aktuell.werte.art);
        return art || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return res;
    });
  };

  /* Die Dokumente und Bilder, die an einem Werkstatt-Vorgang hängen (seit 2.0.26), in der Reihenfolge der Liste. */
  Daten.prototype.dokumenteFuerVorgang = function (vorgangId) {
    var self = this;
    return this.speicher.holen('vorgaenge', vorgangId).then(function (v) {
      if (!v) return [];
      return self.dokumenteListe(v.fahrzeugId).then(function (l) { return l.filter(function (x) { return x.vorgangId === vorgangId; }); });
    });
  };

  /* Scans und Fotos von Nachweisen: bleiben immer nur auf diesem Gerät. */
  Daten.prototype.scansBelegung = function () {
    return this.speicher.alle('nachweisdateien').then(function (l) {
      return { anzahl: l.length, bytes: l.reduce(function (s, x) { return s + (x.groesse || 0); }, 0) };
    });
  };

  /* Wie viel Platz belegen die Dateien auf diesem Gerät? */
  Daten.prototype.dateienBelegung = function () {
    return this.speicher.alle('dateien').then(function (l) {
      return { anzahl: l.length, bytes: l.reduce(function (s, x) { return s + (x.groesse || 0); }, 0) };
    });
  };

  /* ---------- Personen und Tiere ---------- */
  function tabelleVon(typ) { return typ === 'person' ? 'personen' : (typ === 'tier' ? 'tiere' : 'fahrzeuge'); }
  function trimmed(v) { return String(v == null ? '' : v).trim(); }

  Daten.prototype.pruefenPerson = function (roh) {
    var p = pruefeWerte(MM.Personen.personFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen eingeben.' });
    var w = p.werte, f = p.fehler;
    if (w.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(w.email)) f.email = 'Das ist keine gültige E-Mail-Adresse.';
    if (w.telefon && !/^[0-9+\-\/() ]{5,}$/.test(w.telefon)) f.telefon = 'Bitte nur Ziffern, Leerzeichen und + - / ( ) eingeben.';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.pruefenTier = function (roh) {
    var p = pruefeWerte(MM.Personen.tierFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen eingeben.' });
    var w = p.werte, f = p.fehler;
    if (!w.tierart && !f.tierart) f.tierart = 'Bitte die Tierart wählen.';
    if (w.chipnummer) {
      var c = w.chipnummer.replace(/[\s-]/g, '');
      if (!/^\d{9,15}$/.test(c)) f.chipnummer = 'Die Chipnummer besteht aus Ziffern, meist 15.'; else w.chipnummer = c;
    }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Gemeinsame Bausteine für Dinge mit Verlauf: Person, Tier. */
  Daten.prototype.mitVerlaufAnlegen = function (tabelle, typ, praefix, werte, extra) {
    var jetzt = this.jetzt();
    var o = { id: neueId(praefix), datenraumId: this.datenraumId, erstelltAm: jetzt };
    if (extra) { for (var k in extra) { o[k] = extra[k]; } }
    return this.speicher.mehrereSpeichern([
      { tabelle: tabelle, objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag(typ, o.id, 1, werte, null, jetzt) }
    ]).then(function () { return { ok: true, id: o.id }; });
  };

  Daten.prototype.mitVerlaufLaden = function (tabelle, id, felder) {
    var self = this;
    return Promise.all([this.speicher.holen(tabelle, id), this.speicher.wo('verlaeufe', 'objektId', id)]).then(function (r) {
      if (!r[0] || !r[1].length) return null;
      var eintraege = r[1].slice().sort(nachNr);
      return { objekt: r[0], aktuell: eintraege[eintraege.length - 1], verlauf: verlaufAus(eintraege, felder || []) };
    });
  };

  Daten.prototype.mitVerlaufAendern = function (typ, id, geladen, neu, felder) {
    if (!unterschiedeFelder(felder, geladen.aktuell.werte, neu).length) return Promise.resolve({ ok: true, id: id, geaendert: false });
    var e = neuerVerlaufEintrag(typ, id, geladen.aktuell.nr + 1, neu, geladen.aktuell.id, this.jetzt());
    return this.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: id, geaendert: true }; });
  };

  Daten.prototype.personAnlegen = function (roh) {
    var p = this.pruefenPerson(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.mitVerlaufAnlegen('personen', 'person', 'pe', p.werte);
  };
  Daten.prototype.personAendern = function (id, roh) {
    var self = this;
    return this.personLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Person wurde nicht gefunden.' } };
      var p = self.pruefenPerson(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('person', id, x, p.werte, MM.Personen.personFelder());
    });
  };
  Daten.prototype.personLaden = function (id) { return this.mitVerlaufLaden('personen', id, MM.Personen.personFelder()); };
  Daten.prototype.personenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('personen'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'person');
    });
  };

  Daten.prototype.tierAnlegen = function (roh) {
    var p = this.pruefenTier(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.mitVerlaufAnlegen('tiere', 'tier', 'ti', p.werte);
  };
  Daten.prototype.tierAendern = function (id, roh) {
    var self = this;
    return this.tierLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Tier wurde nicht gefunden.' } };
      var p = self.pruefenTier(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('tier', id, x, p.werte, MM.Personen.tierFelder());
    });
  };
  Daten.prototype.tierLaden = function (id) { return this.mitVerlaufLaden('tiere', id, MM.Personen.tierFelder()); };
  Daten.prototype.tiereListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('tiere'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'tier');
    });
  };

  /* Objekte mit aktuellem Stand, nach Namen sortiert. */
  function sammle(self, objekte, verlaeufe, typ) {
    var ver = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === typ) (ver[e.objektId] = ver[e.objektId] || []).push(e); });
    var liste = objekte.filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
      var l = (ver[o.id] || []).slice().sort(nachNr);
      return { objekt: o, aktuell: l[l.length - 1] || null };
    }).filter(function (x) { return x.aktuell; });
    liste.sort(function (a, b) { return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' }); });
    return liste;
  }

  /* ---------- Nachweisarten (offene Liste) ---------- */
  var ART_FELDER = [
    { key: 'bezeichnung', label: 'Name der Art' },
    { key: 'hatAblauf', label: 'Mit Ablaufdatum', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN },
    { key: 'land', label: 'Land', typ: 'text' },
    { key: 'beschreibung', label: 'Beschreibung', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN },
    { key: 'felder', label: 'Weitere Angaben', typ: 'zeilen' }
  ];

  Daten.prototype.pruefenNachweisart = function (roh, neu) {
    roh = roh || {};
    var f = {}, w = {};
    var bez = trimmed(roh.bezeichnung);
    if (!bez) f.bezeichnung = 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segelschein“.';
    w.bezeichnung = bez;
    if (neu) {
      if (!MM.Nachweise.BESITZER.some(function (b) { return b.wert === roh.gehoertZu; })) f.gehoertZu = 'Bitte wählen, wofür der Nachweis gilt: Person, Tier oder Fahrzeug.';
      else w.gehoertZu = roh.gehoertZu;
    }
    w.hatAblauf = roh.hatAblauf === 'ja' ? 'ja' : 'nein';
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    w.land = trimmed(roh.land) || null;
    w.beschreibung = trimmed(roh.beschreibung) || null;

    var zeilen = Array.isArray(roh.felder) ? roh.felder : [];
    var belegt = {}, hoechste = 0;
    zeilen.forEach(function (z) { var m = /^z(\d+)$/.exec(z && z.key || ''); if (m) { belegt[z.key] = true; hoechste = Math.max(hoechste, +m[1]); } });
    var sauber = [], benutzt = {};
    zeilen.forEach(function (z) {
      var label = trimmed(z && z.label), papier = trimmed(z && z.papier);
      if (!label && !papier) return;
      if (!label) { f.felder = 'Bitte bei jeder weiteren Angabe eine Beschriftung eingeben.'; return; }
      var typ = MM.Nachweise.FELDTYPEN.some(function (t) { return t.wert === z.typ; }) ? z.typ : 'text';
      var key = z.key && /^z\d+$/.test(z.key) && !benutzt[z.key] ? z.key : null;
      if (!key) { hoechste++; key = 'z' + hoechste; }
      benutzt[key] = true;
      sauber.push({ key: key, label: label, typ: typ, papier: papier });
    });
    w.felder = sauber;
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.nachweisartAnlegen = function (roh) {
    var p = this.pruefenNachweisart(roh, true);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var w = p.werte;
    w.gemeinsam = {}; w.ohne = []; w.herkunft = 'eigen'; w.vorschlagId = null;
    w.quelleTitel = null; w.quelleUrl = null; w.pruefstatus = null; w.geprueftAm = null;
    return this.mitVerlaufAnlegen('nachweisarten', 'nachweisart', 'na', w);
  };

  /* Übernimmt einen Vorschlag als eigene Art. Danach ist sie frei änderbar. */
  Daten.prototype.nachweisartAusVorschlag = function (vorschlagId) {
    var self = this;
    var v = MM.NachweisVorschlaege.finde(vorschlagId);
    if (!v) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diesen Vorschlag gibt es nicht.' } });
    return this.nachweisartenListe().then(function (liste) {
      var vorhanden = liste.filter(function (x) { return x.aktuell.werte.vorschlagId === vorschlagId; })[0];
      if (vorhanden) return { ok: false, vorhanden: true, id: vorhanden.objekt.id, fehler: { allgemein: 'Diese Art ist schon übernommen.' } };
      return self.mitVerlaufAnlegen('nachweisarten', 'nachweisart', 'na', {
        bezeichnung: v.name, gehoertZu: v.gehoertZu, hatAblauf: v.hatAblauf ? 'ja' : 'nein', ausgeblendet: 'nein',
        land: v.land, beschreibung: v.hinweis || null, gemeinsam: v.gemeinsam, ohne: v.ohne, felder: v.felder,
        herkunft: 'vorschlag', vorschlagId: v.id, quelleTitel: v.quelle ? v.quelle.titel : null, quelleUrl: v.quelle ? v.quelle.url : null,
        pruefstatus: v.pruefstatus, geprueftAm: v.geprueftAm
      });
    });
  };

  Daten.prototype.nachweisartAendern = function (id, roh) {
    var self = this;
    return this.nachweisartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var p = self.pruefenNachweisart(roh, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, x.aktuell.werte, p.werte);
      return self.mitVerlaufAendern('nachweisart', id, x, neu, ART_FELDER);
    });
  };

  Daten.prototype.nachweisartLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('nachweisarten', id, ART_FELDER).then(function (x) {
      if (!x) return null;
      return self.speicher.alle('nachweise').then(function (n) {
        x.anzahlNachweise = n.filter(function (k) { return k.artId === id; }).length;
        x.art = x.objekt; x.werte = x.aktuell.werte;
        return x;
      });
    });
  };

  /* Alle Arten, nach Besitzer (Person, Tier, Fahrzeug) und Name geordnet. */
  Daten.prototype.nachweisartenListe = function (gehoertZu) {
    var self = this;
    return Promise.all([this.speicher.alle('nachweisarten'), this.speicher.alle('verlaeufe'), this.speicher.alle('nachweise')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'nachweisart');
      var anzahl = {}; r[2].forEach(function (n) { anzahl[n.artId] = (anzahl[n.artId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlNachweise = anzahl[x.objekt.id] || 0; });
      if (gehoertZu) liste = liste.filter(function (x) { return x.aktuell.werte.gehoertZu === gehoertZu; });
      var reihenfolge = { person: 0, tier: 1, fahrzeug: 2 };
      liste.sort(function (a, b) {
        var o = reihenfolge[a.aktuell.werte.gehoertZu] - reihenfolge[b.aktuell.werte.gehoertZu];
        return o || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return liste;
    });
  };

  /* ---------- Nachweise ---------- */
  Daten.prototype.besitzerLaden = function (typ, id) {
    if (typ === 'fahrzeug') return this.fahrzeugLaden(id).then(function (f) { return f ? { name: f.aktuell.werte.bezeichnung, id: id } : null; });
    return this.mitVerlaufLaden(tabelleVon(typ), id, []).then(function (x) { return x ? { name: x.aktuell.werte.bezeichnung, id: id } : null; });
  };

  function artStatus(art, werte, heute) { return MM.Nachweise.status(art, werte, heute); }

  Daten.prototype.nachweisAnlegen = function (besitzerTyp, besitzerId, artId, roh) {
    var self = this;
    roh = roh || {};
    return Promise.all([this.nachweisartLaden(artId), this.besitzerLaden(besitzerTyp, besitzerId)]).then(function (r) {
      var art = r[0], besitzer = r[1];
      if (!art) return { ok: false, fehler: { artId: 'Bitte zuerst die Art des Nachweises wählen.' } };
      if (!besitzer) return { ok: false, fehler: { allgemein: 'Dazu wurde nichts gefunden.' } };
      var aw = art.aktuell.werte;
      if (aw.gehoertZu !== besitzerTyp) return { ok: false, fehler: { artId: 'Diese Art gilt nicht hierfür.' } };
      if (aw.ausgeblendet === 'ja') return { ok: false, fehler: { artId: 'Diese Art ist ausgeblendet.' } };

      var felder = MM.Nachweise.felderFuer(aw);
      var p = pruefeWerte(felder, roh, jahrVon(self), { ohneBezeichnung: true });
      var fehler = p.fehler, w = p.werte;
      if (w.ausgestelltAm && w.gueltigBis && w.gueltigBis < w.ausgestelltAm && !fehler.gueltigBis) fehler.gueltigBis = 'Das Ablaufdatum liegt vor dem Ausstellungsdatum.';
      var datei = roh.datei;
      if (datei && !(typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Diese Datei ist leer.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };

      var jetzt = self.jetzt();
      var n = { id: neueId('nw'), datenraumId: self.datenraumId, artId: artId, besitzerTyp: besitzerTyp, besitzerId: besitzerId, erstelltAm: jetzt };
      w.dateiName = datei ? String(datei.name || 'Datei') : null;
      w.dateiTyp = datei ? String(datei.type || '') : null;
      w.dateiGroesse = datei ? datei.size : null;
      var liste = [{ tabelle: 'nachweise', objekt: n }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('nachweis', n.id, 1, w, null, jetzt) }];
      if (datei) liste.push({ tabelle: 'nachweisdateien', objekt: { id: neueId('nd'), nachweisId: n.id, name: w.dateiName, mime: w.dateiTyp, groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: n.id }; }).catch(function (err) {
        if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei.' } };
        throw err;
      });
    });
  };

  Daten.prototype.nachweisAendern = function (id, roh) {
    var self = this;
    return this.nachweisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Nachweis wurde nicht gefunden.' } };
      var p = pruefeWerte(x.felder, roh || {}, jahrVon(self), { ohneBezeichnung: true });
      var fehler = p.fehler, w = p.werte;
      if (w.ausgestelltAm && w.gueltigBis && w.gueltigBis < w.ausgestelltAm && !fehler.gueltigBis) fehler.gueltigBis = 'Das Ablaufdatum liegt vor dem Ausstellungsdatum.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var neu = Object.assign({}, x.aktuell.werte, w);
      return self.mitVerlaufAendern('nachweis', id, { aktuell: x.aktuell }, neu, x.felder);
    });
  };

  Daten.prototype.nachweisLaden = function (id) {
    var self = this;
    return this.speicher.holen('nachweise', id).then(function (n) {
      if (!n) return null;
      return Promise.all([self.nachweisartLaden(n.artId), self.mitVerlaufLaden('nachweise', id, []), self.speicher.wo('nachweisdateien', 'nachweisId', id), self.besitzerLaden(n.besitzerTyp, n.besitzerId)]).then(function (r) {
        var art = r[0], x = r[1];
        if (!art || !x) return null;
        var felder = MM.Nachweise.felderFuer(art.aktuell.werte);
        var eintraege = x.verlauf.map(function (v) { return v.eintrag; });
        var verlauf = verlaufAus(eintraege, felder);
        var d = r[2][0] ? { id: r[2][0].id, name: r[2][0].name, mime: r[2][0].mime, groesse: r[2][0].groesse } : null;
        return { nachweis: n, aktuell: x.aktuell, verlauf: verlauf, art: art, felder: felder, datei: d, besitzer: r[3],
          status: artStatus(art.aktuell.werte, x.aktuell.werte, self.heute()) };
      });
    });
  };

  Daten.prototype.nachweisDateiHolen = function (nachweisId) {
    return this.speicher.wo('nachweisdateien', 'nachweisId', nachweisId).then(function (l) { return l[0] || null; });
  };

  /* Nachweise eines Besitzers, mit Status. Abgelaufene zuerst. */
  Daten.prototype.nachweiseListe = function (besitzerTyp, besitzerId) {
    var self = this;
    return Promise.all([this.speicher.wo('nachweise', 'besitzerId', besitzerId), this.speicher.alle('verlaeufe'), this.nachweisartenListe()]).then(function (r) {
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a; });
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'nachweis') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var heute = self.heute();
      var liste = r[0].filter(function (n) { return n.besitzerTyp === besitzerTyp; }).map(function (n) {
        var l = (ver[n.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1], art = arten[n.artId];
        if (!a || !art) return null;
        return { nachweis: n, aktuell: a, art: art, status: artStatus(art.aktuell.werte, a.werte, heute) };
      }).filter(Boolean);
      liste.sort(function (a, b) {
        var d = MM.Nachweise.rang(b.status.status) - MM.Nachweise.rang(a.status.status);
        return d || a.art.aktuell.werte.bezeichnung.localeCompare(b.art.aktuell.werte.bezeichnung, 'de', { numeric: true });
      });
      return liste;
    });
  };

  /* Pro Besitzer: wie viele Nachweise sind abgelaufen oder laufen bald ab? */
  Daten.prototype.nachweisUebersicht = function () {
    var self = this;
    return Promise.all([this.speicher.alle('nachweise'), this.speicher.alle('verlaeufe'), this.nachweisartenListe()]).then(function (r) {
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a; });
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'nachweis') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var heute = self.heute(), res = {};
      r[0].forEach(function (n) {
        var l = (ver[n.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1], art = arten[n.artId];
        if (!a || !art) return;
        var s = artStatus(art.aktuell.werte, a.werte, heute).status;
        var z = res[n.besitzerId] = res[n.besitzerId] || { abgelaufen: 0, bald: 0, unbekannt: 0 };
        if (z[s] !== undefined) z[s]++;
      });
      return res;
    });
  };

  /* ---------- Aktivitäten: gemeinsame Hilfen ---------- */
  Daten.prototype.jetztLokal = function () {
    var d = new Date(this.jetzt());
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()) + 'T' + z(d.getHours()) + ':' + z(d.getMinutes());
  };

  /* ---------- Aktivitätsarten (offene Liste) ---------- */
  var AKTART_FELDER = [
    { key: 'bezeichnung', label: 'Name der Art' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  /* Seit 2.0.17 gilt jede Aktivitätsart für Fahrzeugarten (Baum, wie bei den Ereignisarten).
     Fehlt die Angabe (ältere Arten), gilt sie für alle. */
  var AKTIVITAETSART_FELDER = AKTART_FELDER.concat([{ key: 'zuordnung', label: 'Gilt für Fahrzeugarten', typ: 'text' }]);

  Daten.prototype.aktivitaetsartenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('aktivitaetsarten'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'aktivitaetsart');
    });
  };

  Daten.prototype.aktivitaetsartAnlegen = function (roh) {
    var self = this;
    var bez = trimmed(roh && roh.bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segeln“.' } });
    return this.aktivitaetsartenListe().then(function (liste) {
      if (liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === bez.toLowerCase(); })) {
        return { ok: false, fehler: { bezeichnung: 'Diese Art gibt es schon.' } };
      }
      return self.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: bez, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungNormal(roh.zuordnung) });
    });
  };

  /* Legt die Vorschläge an, die es noch nicht gibt. Gibt die Anzahl der neuen zurück. */
  Daten.prototype.aktivitaetsartenAusVorschlaegen = function () {
    var self = this;
    return this.aktivitaetsartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Aktivitaeten.VORSCHLAEGE_ARTEN.filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
      return neu.reduce(function (kette, n) {
        var gilt = MM.Aktivitaeten.zuordnungVorschlag(n);
        var zuordnung = gilt ? MM.Logbuch.zuordnungFuerKnoten(gilt) : MM.Logbuch.zuordnungNormal();
        return kette.then(function () { return self.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: n, ausgeblendet: 'nein', zuordnung: zuordnung }); });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  /* Setzt die Starthilfe-Zuordnung bei den vorgeschlagenen Arten, die noch keine Zuordnung haben (ältere Arten).
     Was der Nutzer schon eingestellt hat, bleibt unberührt. */
  Daten.prototype.aktivitaetsartenVorauswahlUebernehmen = function () {
    var self = this;
    return this.aktivitaetsartenListe().then(function (liste) {
      var offen = liste.filter(function (x) { return x.aktuell.werte.zuordnung === undefined && MM.Aktivitaeten.zuordnungVorschlag(x.aktuell.werte.bezeichnung); });
      return offen.reduce(function (kette, x) {
        return kette.then(function () {
          return self.aktivitaetsartAendern(x.objekt.id, { bezeichnung: x.aktuell.werte.bezeichnung, ausgeblendet: x.aktuell.werte.ausgeblendet,
            zuordnung: MM.Logbuch.zuordnungFuerKnoten(MM.Aktivitaeten.zuordnungVorschlag(x.aktuell.werte.bezeichnung)) });
        });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: offen.length, namen: offen.map(function (x) { return x.aktuell.werte.bezeichnung; }) }; });
    });
  };

  /* Die Aktivitätsarten, die zu einer Fahrzeugart passen (ohne ausgeblendete). Eine Art, die schon an einer
     Aktivität hängt, bleibt auswählbar (behalteIds). Ohne Fahrzeugart: alle nicht ausgeblendeten. */
  Daten.prototype.aktivitaetsartenFuerFahrzeugart = function (artId, behalteIds) {
    var behalte = behalteIds || [];
    return this.aktivitaetsartenListe().then(function (liste) {
      return liste.filter(function (x) {
        if (behalte.indexOf(x.objekt.id) >= 0) return true;
        if (x.aktuell.werte.ausgeblendet === 'ja') return false;
        return !artId || MM.Logbuch.ereignisartGilt(x.aktuell.werte.zuordnung, artId);
      });
    });
  };

  Daten.prototype.aktivitaetsartLaden = function (id) { return this.mitVerlaufLaden('aktivitaetsarten', id, AKTIVITAETSART_FELDER); };

  Daten.prototype.aktivitaetsartAendern = function (id, roh) {
    var self = this;
    return this.aktivitaetsartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var bez = trimmed(roh && roh.bezeichnung);
      if (!bez) return { ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben.' } };
      var neu = { bezeichnung: bez, ausgeblendet: roh.ausgeblendet === 'ja' ? 'ja' : 'nein' };
      /* Ohne Angabe bleibt die Zuordnung, wie sie ist (bei alten Arten: gilt für alle). */
      if (roh.zuordnung !== undefined) neu.zuordnung = MM.Logbuch.zuordnungNormal(roh.zuordnung);
      else if (x.aktuell.werte.zuordnung !== undefined) neu.zuordnung = x.aktuell.werte.zuordnung;
      return self.mitVerlaufAendern('aktivitaetsart', id, x, neu, AKTIVITAETSART_FELDER);
    });
  };

  /* ---------- Anforderungen an Skipper und Fahrer (je Fahrzeug) ---------- */
  var ANF_FELDER = [
    { key: 'bezeichnung', label: 'Bezeichnung' },
    { key: 'artIds', label: 'Akzeptierte Nachweisarten', typ: 'mehrfach' },
    { key: 'gilt', label: 'Gilt', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  Daten.prototype.pruefenAnforderung = function (roh, personenArten) {
    roh = roh || {};
    var f = {}, w = {};
    w.bezeichnung = trimmed(roh.bezeichnung);
    if (!w.bezeichnung) f.bezeichnung = 'Bitte eine Bezeichnung eingeben, zum Beispiel „Führerschein Klasse B“.';
    var gew = Array.isArray(roh.artIds) ? roh.artIds : [];
    w.artIds = personenArten.filter(function (a) { return gew.indexOf(a) >= 0; });
    if (!w.artIds.length) f.artIds = 'Bitte mindestens eine Art von Nachweis wählen, die genügt.';
    w.gilt = roh.gilt === 'nein' ? 'nein' : 'ja';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  function personenArtIds(self) {
    return self.nachweisartenListe('person').then(function (l) { return l.map(function (x) { return x.objekt.id; }); });
  }

  Daten.prototype.anforderungAnlegen = function (fahrzeugId, roh) {
    var self = this;
    return Promise.all([this.pruefeObjekt(fahrzeugId, null), personenArtIds(this)]).then(function (r) {
      if (r[0]) return { ok: false, fehler: r[0] };
      var p = self.pruefenAnforderung(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAnlegen('anforderungen', 'anforderung', 'an', p.werte, { fahrzeugId: fahrzeugId });
    });
  };

  Daten.prototype.anforderungLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('anforderungen', id, ANF_FELDER).then(function (x) {
      if (!x) return null;
      return self.nachweisartenListe('person').then(function (arten) {
        var namen = {}; arten.forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artIds') {
              u.feld = { typ: 'text' };
              u.alt = (u.alt || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null;
              u.neu = (u.neu || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null;
            }
          });
        });
        x.arten = arten; x.namen = namen;
        return x;
      });
    });
  };

  Daten.prototype.anforderungAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.anforderungLaden(id), personenArtIds(this)]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Anforderung wurde nicht gefunden.' } };
      var p = self.pruefenAnforderung(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('anforderung', id, x, p.werte, ANF_FELDER);
    });
  };

  /* Anforderungen eines Fahrzeugs; nurGueltige blendet abgeschaltete aus. */
  Daten.prototype.anforderungenListe = function (fahrzeugId, nurGueltige) {
    var self = this;
    return Promise.all([this.speicher.wo('anforderungen', 'fahrzeugId', fahrzeugId), this.speicher.alle('verlaeufe'), this.nachweisartenListe('person')]).then(function (r) {
      var namen = {}; r[2].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      var liste = sammle(self, r[0], r[1], 'anforderung').map(function (x) {
        x.artNamen = x.aktuell.werte.artIds.map(function (i) { return namen[i] || 'unbekannte Art'; });
        return x;
      });
      return nurGueltige ? liste.filter(function (x) { return x.aktuell.werte.gilt !== 'nein'; }) : liste;
    });
  };

  /* ---------- Orte, Standorte, Gebiete und Regeln ---------- */
  var AUSGEBLENDET = { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN };
  var ORT_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.ortFelder(), [AUSGEBLENDET]);
  var STANDORT_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.standortFelder(), [AUSGEBLENDET]);
  var GEBIET_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.gebietFelder(), [AUSGEBLENDET]);
  var REGEL_FELDER = [
    { key: 'bezeichnung', label: 'Bezeichnung' },
    { key: 'art', label: 'Art der Regel', typ: 'auswahl', optionen: MM.Orte.REGELARTEN },
    { key: 'pflichtAusruestung', label: 'Pflichtausrüstung', typ: 'text' },
    { key: 'menge', label: 'Menge', typ: 'ganzzahl' },
    { key: 'bezug', label: 'Bezugsgröße', typ: 'auswahl', optionen: MM.Orte.BEZUGSGROESSEN },
    { key: 'eignung', label: 'Gefordert (Eignung)', typ: 'text' },
    { key: 'fahrzeugArten', label: 'Gilt für Fahrzeugarten', typ: 'mehrfach' },
    { key: 'ausruestung', label: 'Nur mit Ausrüstung', typ: 'text' },
    { key: 'artIds', label: 'Genügt einer dieser Nachweise', typ: 'mehrfach' },
    { key: 'gilt', label: 'Gilt', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  function gleicherName(liste, name, ausser) {
    var n = name.toLowerCase();
    return liste.some(function (x) { return x.objekt.id !== ausser && x.aktuell.werte.bezeichnung.toLowerCase() === n; });
  }

  /* Gemeinsame Prüfung für Ort, Standort und Gebiet: Name, freie Felder, „ausgeblendet“. */
  function pruefeBenannt(self, felder, roh, text) {
    var p = pruefeWerte(felder, roh, jahrVon(self), { bezeichnungFehler: text });
    p.werte.ausgeblendet = roh && roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    p.werte.herkunft = 'eigen';
    return p;
  }

  Daten.prototype.pruefenOrt = function (roh) {
    var p = pruefeBenannt(this, MM.Orte.ortFelder(), roh, 'Bitte einen Namen für den Ort eingeben, zum Beispiel „Hafen Biograd“.');
    if (p.werte.telefon && !/^[0-9+\-\/() ]{5,}$/.test(p.werte.telefon)) { p.fehler.telefon = 'Bitte nur Ziffern, Leerzeichen und + - / ( ) eingeben.'; p.ok = false; }
    return p;
  };
  Daten.prototype.pruefenStandort = function (roh) {
    return pruefeBenannt(this, MM.Orte.standortFelder(), roh, 'Bitte einen Namen für den Standort eingeben, zum Beispiel „Liegeplatz 12“.');
  };
  Daten.prototype.pruefenGebiet = function (roh) {
    return pruefeBenannt(this, MM.Orte.gebietFelder(), roh, 'Bitte einen Namen für das Gebiet eingeben, zum Beispiel „Kroatien, Adria“.');
  };

  /* ----- Orte ----- */
  Daten.prototype.orteListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('orte'), this.speicher.alle('verlaeufe'), this.speicher.alle('standorte')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'ort');
      var anzahl = {}; r[2].forEach(function (s) { anzahl[s.ortId] = (anzahl[s.ortId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlStandorte = anzahl[x.objekt.id] || 0; });
      return liste;
    });
  };

  Daten.prototype.ortAnlegen = function (roh) {
    var self = this;
    var p = this.pruefenOrt(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.orteListe().then(function (liste) {
      if (gleicherName(liste, p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Diesen Ort gibt es schon.' } };
      return self.mitVerlaufAnlegen('orte', 'ort', 'or', p.werte);
    });
  };

  Daten.prototype.ortAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', id, ORT_FELDER), this.orteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var p = self.pruefenOrt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(r[1], p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Diesen Ort gibt es schon.' } };
      return self.mitVerlaufAendern('ort', id, x, p.werte, ORT_FELDER);
    });
  };

  /* Ein Ort mit seinen Standorten. */
  Daten.prototype.ortLaden = function (id) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', id, ORT_FELDER), this.standorteListe(id)]).then(function (r) {
      if (!r[0]) return null;
      r[0].standorte = r[1];
      return r[0];
    });
  };

  /* ----- Standorte ----- */
  Daten.prototype.standorteListe = function (ortId) {
    var self = this;
    return Promise.all([this.speicher.alle('standorte'), this.speicher.alle('verlaeufe')]).then(function (r) {
      var rec = ortId ? r[0].filter(function (s) { return s.ortId === ortId; }) : r[0];
      return sammle(self, rec, r[1], 'standort');
    });
  };

  Daten.prototype.standortAnlegen = function (ortId, roh) {
    var self = this;
    return Promise.all([this.speicher.holen('orte', ortId), this.standorteListe(ortId)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var p = self.pruefenStandort(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(r[1], p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Diesen Standort gibt es an diesem Ort schon.' } };
      return self.mitVerlaufAnlegen('standorte', 'standort', 'so', p.werte, { ortId: ortId });
    });
  };

  Daten.prototype.standortLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('standorte', id, STANDORT_FELDER).then(function (x) {
      if (!x) return null;
      return self.mitVerlaufLaden('orte', x.objekt.ortId, ORT_FELDER).then(function (o) {
        x.ort = o ? { id: x.objekt.ortId, name: o.aktuell.werte.bezeichnung } : { id: x.objekt.ortId, name: 'unbekannt' };
        return x;
      });
    });
  };

  Daten.prototype.standortAendern = function (id, roh) {
    var self = this;
    return this.standortLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Standort wurde nicht gefunden.' } };
      var p = self.pruefenStandort(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.standorteListe(x.objekt.ortId).then(function (liste) {
        if (gleicherName(liste, p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Diesen Standort gibt es an diesem Ort schon.' } };
        return self.mitVerlaufAendern('standort', id, x, p.werte, STANDORT_FELDER);
      });
    });
  };

  /* ----- Heimatstandort eines Fahrzeugs (mit Verlauf, nichts wird überschrieben) ----- */
  Daten.prototype.fahrzeugStandortSetzen = function (fahrzeugId, standortId) {
    var self = this;
    standortId = standortId || null;
    return Promise.all([this.pruefeObjekt(fahrzeugId, null), standortId ? this.speicher.holen('standorte', standortId) : Promise.resolve(true),
      this.speicher.wo('verlaeufe', 'objektId', fahrzeugId)]).then(function (r) {
      if (r[0]) return { ok: false, fehler: r[0] };
      if (!r[1]) return { ok: false, fehler: { standortId: 'Dieser Standort wurde nicht gefunden.' } };
      var alt = r[2].filter(function (e) { return e.objektTyp === 'fahrzeugstandort'; }).sort(nachNr);
      var letzter = alt[alt.length - 1] || null;
      var bisher = letzter ? letzter.werte.standortId : null;
      if (bisher === standortId) return { ok: true, id: fahrzeugId, geaendert: false };
      var e = neuerVerlaufEintrag('fahrzeugstandort', fahrzeugId, letzter ? letzter.nr + 1 : 1, { standortId: standortId }, letzter ? letzter.id : null, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: fahrzeugId, geaendert: true }; });
    });
  };

  /* Heimatstandort eines Fahrzeugs: { standort: {id, name, ortId, ortName} | null, verlauf: [{ ... }] } */
  Daten.prototype.fahrzeugStandort = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.speicher.wo('verlaeufe', 'objektId', fahrzeugId), this.standorteListe(), this.orteListe()]).then(function (r) {
      var alt = r[0].filter(function (e) { return e.objektTyp === 'fahrzeugstandort'; }).sort(nachNr);
      var namen = {};
      r[1].forEach(function (s) {
        var o = r[2].filter(function (x) { return x.objekt.id === s.objekt.ortId; })[0];
        namen[s.objekt.id] = { id: s.objekt.id, name: s.aktuell.werte.bezeichnung, ortId: s.objekt.ortId, ortName: o ? o.aktuell.werte.bezeichnung : 'unbekannt' };
      });
      function text(id) { return id ? (namen[id] ? namen[id].ortName + ', ' + namen[id].name : 'unbekannt') : 'keiner'; }
      var verlauf = alt.map(function (e, i) { return { eintrag: e, alt: i ? text(alt[i - 1].werte.standortId) : null, neu: text(e.werte.standortId) }; }).reverse();
      var letzter = alt[alt.length - 1];
      return { standort: letzter && letzter.werte.standortId && namen[letzter.werte.standortId] ? namen[letzter.werte.standortId] : null, verlauf: verlauf };
    });
  };

  /* ----- Gebiete ----- */
  Daten.prototype.gebieteListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('gebiete'), this.speicher.alle('verlaeufe'), this.speicher.alle('regeln')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'gebiet');
      var anzahl = {}; r[2].forEach(function (g) { anzahl[g.gebietId] = (anzahl[g.gebietId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlRegeln = anzahl[x.objekt.id] || 0; });
      return liste;
    });
  };

  Daten.prototype.gebietAnlegen = function (roh) {
    var self = this;
    var p = this.pruefenGebiet(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.gebieteListe().then(function (liste) {
      if (gleicherName(liste, p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Dieses Gebiet gibt es schon.' } };
      return self.mitVerlaufAnlegen('gebiete', 'gebiet', 'ge', p.werte);
    });
  };

  Daten.prototype.gebietAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('gebiete', id, GEBIET_FELDER), this.gebieteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Gebiet wurde nicht gefunden.' } };
      var p = self.pruefenGebiet(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(r[1], p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Dieses Gebiet gibt es schon.' } };
      return self.mitVerlaufAendern('gebiet', id, x, p.werte, GEBIET_FELDER);
    });
  };

  /* Ein Gebiet mit seinen Regeln. */
  Daten.prototype.gebietLaden = function (id) {
    return Promise.all([this.mitVerlaufLaden('gebiete', id, GEBIET_FELDER), this.regelnListe(id)]).then(function (r) {
      if (!r[0]) return null;
      r[0].regeln = r[1];
      return r[0];
    });
  };

  /* ----- Regeln: WENN Gebiet, Fahrzeugart und Ausrüstung passen, DANN genügt einer der Nachweise ----- */
  function fahrzeugArtIds() { return MM.Fahrzeugarten.alle(true).map(function (a) { return a.id; }); }

  Daten.prototype.pruefenRegel = function (roh, personenArten) {
    roh = roh || {};
    var f = {}, w = {};
    w.bezeichnung = trimmed(roh.bezeichnung);
    if (!w.bezeichnung) f.bezeichnung = 'Bitte eine Bezeichnung eingeben, zum Beispiel „Funkzeugnis auf See“.';
    var fa = Array.isArray(roh.fahrzeugArten) ? roh.fahrzeugArten : [];
    w.fahrzeugArten = fahrzeugArtIds().filter(function (a) { return fa.indexOf(a) >= 0; });
    w.art = MM.Orte.regelArt(roh);
    if (w.art === 'ausruestung') {
      /* Pflichtausrüstung: Was muss am Fahrzeug eingetragen sein? Eine Bedingung „Ausrüstung“ und Nachweise gibt es hier nicht. */
      w.pflichtAusruestung = trimmed(roh.pflichtAusruestung) || null;
      if (!w.pflichtAusruestung) f.pflichtAusruestung = 'Bitte eintragen, was am Fahrzeug sein muss, zum Beispiel „Rettungsweste“.';
      w.ausruestung = null;
      w.artIds = [];
      /* Menge (ganze Zahl ab 1, leer = 1), Bezugsgröße und freiwillig die geforderte Eignung */
      var mt = String(roh.menge === undefined || roh.menge === null ? '' : roh.menge).trim();
      if (mt === '') { w.menge = 1; }
      else if (!/^\d+$/.test(mt) || Number(mt) < 1) { w.menge = 1; f.menge = 'Bitte eine ganze Zahl ab 1 eingeben, zum Beispiel 6.'; }
      else { w.menge = Number(mt); }
      w.bezug = MM.Orte.bezugsgroesse(roh);
      w.eignung = trimmed(roh.eignung) || null;
    } else {
      w.pflichtAusruestung = null;
      w.menge = null; w.bezug = null; w.eignung = null;
      w.ausruestung = trimmed(roh.ausruestung) || null;
      var gew = Array.isArray(roh.artIds) ? roh.artIds : [];
      w.artIds = personenArten.filter(function (a) { return gew.indexOf(a) >= 0; });
      if (!w.artIds.length) f.artIds = 'Bitte mindestens eine Art von Nachweis wählen, die genügt.';
    }
    w.gilt = roh.gilt === 'nein' ? 'nein' : 'ja';
    w.herkunft = 'eigen';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.regelAnlegen = function (gebietId, roh) {
    var self = this;
    return Promise.all([this.speicher.holen('gebiete', gebietId), personenArtIds(this)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieses Gebiet wurde nicht gefunden.' } };
      var p = self.pruefenRegel(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAnlegen('regeln', 'regel', 'rg', p.werte, { gebietId: gebietId });
    });
  };

  Daten.prototype.regelAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.regelLaden(id), personenArtIds(this)]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Regel wurde nicht gefunden.' } };
      if (!x.aktuell.werte.art) x.aktuell.werte = Object.assign({ art: 'befaehigung' }, x.aktuell.werte);
      if (x.aktuell.werte.art === 'ausruestung') x.aktuell.werte = Object.assign({ menge: 1, bezug: 'fahrzeug', eignung: null }, x.aktuell.werte);
      else x.aktuell.werte = Object.assign({ menge: null, bezug: null, eignung: null }, x.aktuell.werte);
      var p = self.pruefenRegel(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('regel', id, x, p.werte, REGEL_FELDER);
    });
  };

  Daten.prototype.regelLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('regeln', id, REGEL_FELDER).then(function (x) {
      if (!x) return null;
      return Promise.all([self.nachweisartenListe('person'), self.mitVerlaufLaden('gebiete', x.objekt.gebietId, GEBIET_FELDER)]).then(function (r) {
        var namen = {}; r[0].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        function arten(l) { return (l || []).map(function (a) { var z = MM.Fahrzeugarten.art(a); return z ? z.name : a; }).join(', ') || null; }
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artIds') { u.feld = { typ: 'text' }; u.alt = (u.alt || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null; u.neu = (u.neu || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null; }
            if (u.key === 'fahrzeugArten') { u.feld = { typ: 'text' }; u.alt = arten(u.alt); u.neu = arten(u.neu); }
            if (u.key === 'bezug') { u.feld = { typ: 'text' }; u.alt = u.alt ? (u.alt === 'person' ? 'je Person an Bord' : 'je Fahrzeug') : null; u.neu = u.neu ? (u.neu === 'person' ? 'je Person an Bord' : 'je Fahrzeug') : null; }
            if (u.key === 'art') { u.feld = { typ: 'text' }; u.alt = u.alt ? (u.alt === 'ausruestung' ? 'Pflichtausrüstung' : 'Befähigung') : 'Befähigung'; u.neu = u.neu === 'ausruestung' ? 'Pflichtausrüstung' : 'Befähigung'; }
          });
        });
        x.arten = r[0]; x.namen = namen;
        x.gebiet = { id: x.objekt.gebietId, name: r[1] ? r[1].aktuell.werte.bezeichnung : 'unbekannt' };
        return x;
      });
    });
  };

  /* Regeln eines Gebiets (oder aller), mit Namen der Nachweisarten. */
  Daten.prototype.regelnListe = function (gebietId) {
    var self = this;
    return Promise.all([this.speicher.alle('regeln'), this.speicher.alle('verlaeufe'), this.nachweisartenListe('person')]).then(function (r) {
      var rec = gebietId ? r[0].filter(function (g) { return g.gebietId === gebietId; }) : r[0];
      var namen = {}; r[2].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      return sammle(self, rec, r[1], 'regel').map(function (x) {
        x.artNamen = x.aktuell.werte.artIds.map(function (i) { return namen[i] || 'unbekannte Art'; });
        x.fahrzeugArtNamen = (x.aktuell.werte.fahrzeugArten || []).map(function (a) { var z = MM.Fahrzeugarten.art(a); return z ? z.name : a; });
        return x;
      });
    });
  };

  /* ---------- Aktivitäten ---------- */
  var AKT_FELDER = [
    { key: 'bezeichnung', label: 'Name' },
    { key: 'artId', label: 'Art', typ: 'text' },
    { key: 'fahrzeugId', label: 'Fahrzeug', typ: 'text' },
    { key: 'vonDatum', label: 'Von (Datum)', typ: 'datum' },
    { key: 'vonZeit', label: 'Von (Uhrzeit)', typ: 'zeit' },
    { key: 'bisDatum', label: 'Bis (Datum)', typ: 'datum' },
    { key: 'bisZeit', label: 'Bis (Uhrzeit)', typ: 'zeit' },
    { key: 'gebiet', label: 'Gebiet (Text)', typ: 'text' },
    { key: 'gebietId', label: 'Gebiet', typ: 'text' },
    { key: 'geplanteStrecke', label: 'Geplante Strecke', typ: 'zahl' },
    { key: 'geplanteStunden', label: 'Geplante Betriebsstunden', typ: 'zahl' },
    { key: 'tierIds', label: 'Tiere', typ: 'mehrfach' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'status', label: 'Status', typ: 'text' },
    { key: 'stornoGrund', label: 'Grund der Stornierung', typ: 'text' },
    { key: 'sperreUebergangenAm', label: 'Sperre übergangen am', typ: 'text' }
  ];

  Daten.prototype.aktivitaetKontext = function () {
    return Promise.all([this.aktivitaetsartenListe(), this.fahrzeugListe(), this.tiereListe(), this.personenListe(), this.gebieteListe()]).then(function (r) {
      return { arten: r[0], fahrzeuge: r[1], tiere: r[2], personen: r[3], gebiete: r[4] };
    });
  };

  Daten.prototype.pruefenAktivitaet = function (roh, ctx, neu) {
    roh = roh || {};
    var gewaehlteArt = roh.artId;
    var felder = [
      { key: 'artId', typ: 'auswahl', optionen: ctx.arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || a.objekt.id === gewaehlteArt; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; }) },
      { key: 'fahrzeugId', typ: 'auswahl', optionen: ctx.fahrzeuge.map(function (x) { return { wert: x.fahrzeug.id, label: x.aktuell.werte.bezeichnung }; }) },
      { key: 'vonDatum', typ: 'datum' }, { key: 'vonZeit', typ: 'zeit' }, { key: 'bisDatum', typ: 'datum' }, { key: 'bisZeit', typ: 'zeit' },
      { key: 'gebiet', typ: 'text' },
      { key: 'gebietId', typ: 'auswahl', optionen: (ctx.gebiete || []).filter(function (g) { return g.aktuell.werte.ausgeblendet !== 'ja' || g.objekt.id === roh.gebietId; })
        .map(function (g) { return { wert: g.objekt.id, label: g.aktuell.werte.bezeichnung }; }) },
      { key: 'geplanteStrecke', typ: 'zahl', min: 0 }, { key: 'geplanteStunden', typ: 'zahl', min: 0 },
      { key: 'tierIds', typ: 'mehrfach', optionen: ctx.tiere.map(function (t) { return { wert: t.objekt.id, label: t.aktuell.werte.bezeichnung }; }) },
      { key: 'notiz', typ: 'text' }
    ];
    var p = pruefeWerte(felder, roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen für die Aktivität eingeben, zum Beispiel „Sommertörn Kroatien“.' });
    var w = p.werte, f = p.fehler;
    if (!w.artId && !f.artId) f.artId = ctx.arten.length ? 'Bitte die Art der Aktivität wählen.' : 'Es gibt noch keine Art. Übernimm zuerst die Vorschläge oder lege eine Art an.';
    if (!w.fahrzeugId && !f.fahrzeugId) f.fahrzeugId = ctx.fahrzeuge.length ? 'Bitte das Fahrzeug wählen.' : 'Es gibt noch kein Fahrzeug. Lege zuerst ein Fahrzeug an.';
    if (!w.vonDatum && !f.vonDatum) f.vonDatum = 'Bitte das Datum angeben, an dem es losgeht.';
    if (!w.bisDatum && !f.bisDatum) f.bisDatum = 'Bitte das Datum angeben, an dem es endet.';
    if (w.vonDatum && w.bisDatum && !f.bisDatum) {
      if (w.bisDatum < w.vonDatum) f.bisDatum = 'Das Ende liegt vor dem Beginn.';
      else if (w.bisDatum === w.vonDatum && w.vonZeit && w.bisZeit && w.bisZeit < w.vonZeit && !f.bisZeit) f.bisZeit = 'Die Uhrzeit des Endes liegt vor der des Beginns.';
    }
    if (neu) {
      var pid = roh.verantwortlichId;
      if (!ctx.personen.some(function (x) { return x.objekt.id === pid; })) {
        f.verantwortlichId = ctx.personen.length ? 'Bitte wählen, wer verantwortlich ist.' : 'Es gibt noch keine Person. Lege zuerst die Besatzung an.';
      }
    }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.aktivitaetAnlegen = function (roh) {
    var self = this;
    return this.aktivitaetKontext().then(function (ctx) {
      var p = self.pruefenAktivitaet(roh, ctx, true);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var w = p.werte, jetzt = self.jetzt();
      w.status = 'geplant'; w.stornoGrund = null; w.stornoAm = null; w.sperreUebergangenAm = null;
      var a = { id: neueId('ak'), datenraumId: self.datenraumId, erstelltAm: jetzt };
      var b = { id: neueId('be'), aktivitaetId: a.id, personId: roh.verantwortlichId, erstelltAm: jetzt };
      var v = { id: neueId('ve'), aktivitaetId: a.id, personId: roh.verantwortlichId, ab: MM.Aktivitaeten.von(w), erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'aktivitaeten', objekt: a },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('aktivitaet', a.id, 1, w, null, jetzt) },
        { tabelle: 'besatzung', objekt: b },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besatzung', b.id, 1, { rolle: 'verantwortlich', dabeiVonDatum: null, dabeiVonZeit: null, dabeiBisDatum: null, dabeiBisZeit: null, entfernt: 'nein' }, null, jetzt) },
        { tabelle: 'verantwortung', objekt: v }
      ]).then(function () { return { ok: true, id: a.id }; });
    });
  };

  Daten.prototype.aktivitaetAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(id), this.aktivitaetKontext()]).then(function (r) {
      var x = r[0], ctx = r[1];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (x.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenAktivitaet(roh, ctx, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var alt = x.aktuell.werte;
      var neu = Object.assign({}, alt, p.werte);
      var zeitraumGeaendert = ['fahrzeugId', 'vonDatum', 'vonZeit', 'bisDatum', 'bisZeit', 'geplanteStrecke', 'geplanteStunden'].some(function (k) { return !gleich(alt[k], neu[k]); });
      if (zeitraumGeaendert) neu.sperreUebergangenAm = null;
      return self.mitVerlaufAendern('aktivitaet', id, { aktuell: x.aktuell }, neu, AKT_FELDER);
    });
  };

  function aktivitaetNeuerStand(self, id, aenderung) {
    return self.mitVerlaufLaden('aktivitaeten', id, []).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var neu = aenderung(Object.assign({}, x.aktuell.werte));
      if (neu.fehler) return { ok: false, fehler: neu.fehler };
      return self.mitVerlaufAendern('aktivitaet', id, { aktuell: x.aktuell }, neu.werte, AKT_FELDER);
    });
  }

  /* Stornieren: Nichts wird gelöscht, der Status heißt "storniert". */
  Daten.prototype.aktivitaetStornieren = function (id, grund) {
    var self = this;
    return aktivitaetNeuerStand(this, id, function (w) {
      if (w.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist schon storniert.' } };
      w.status = 'storniert'; w.stornoGrund = trimmed(grund) || null; w.stornoAm = self.jetzt();
      return { werte: w };
    });
  };
  Daten.prototype.aktivitaetWiederherstellen = function (id) {
    return aktivitaetNeuerStand(this, id, function (w) {
      if (w.status !== 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist nicht storniert.' } };
      w.status = 'geplant'; w.stornoGrund = null; w.stornoAm = null;
      return { werte: w };
    });
  };
  /* Eine Sperre durch eine Frist ausdrücklich übergehen. Zeit wird festgehalten. */
  Daten.prototype.aktivitaetSperreUebergehen = function (id) {
    var self = this;
    return aktivitaetNeuerStand(this, id, function (w) { w.sperreUebergangenAm = self.jetzt(); return { werte: w }; });
  };

  /* ---------- Besatzung und Verantwortung ---------- */
  var BES_FELDER = [
    { key: 'rolle', label: 'Rolle', typ: 'text' },
    { key: 'dabeiVonDatum', label: 'Dabei von (Datum)', typ: 'datum' }, { key: 'dabeiVonZeit', label: 'Dabei von (Uhrzeit)', typ: 'zeit' },
    { key: 'dabeiBisDatum', label: 'Dabei bis (Datum)', typ: 'datum' }, { key: 'dabeiBisZeit', label: 'Dabei bis (Uhrzeit)', typ: 'zeit' },
    { key: 'entfernt', label: 'Nicht mehr dabei', typ: 'text' }
  ];

  Daten.prototype.pruefenBesatzung = function (roh) {
    roh = roh || {};
    var felder = [{ key: 'dabeiVonDatum', typ: 'datum' }, { key: 'dabeiVonZeit', typ: 'zeit' }, { key: 'dabeiBisDatum', typ: 'datum' }, { key: 'dabeiBisZeit', typ: 'zeit' }];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    var rolle = roh.rolle;
    if (rolle !== 'stellvertreter' && rolle !== 'crew' && rolle !== 'verantwortlich') f.rolle = 'Bitte wählen: Stellvertreter oder Crew.';
    else w.rolle = rolle;
    if (w.dabeiVonDatum && w.dabeiBisDatum && w.dabeiBisDatum < w.dabeiVonDatum && !f.dabeiBisDatum) f.dabeiBisDatum = 'Das Ende liegt vor dem Beginn.';
    w.entfernt = roh.entfernt === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Wer hängt gerade an der Verantwortung (letzter Eintrag der Verantwortung)? */
  function letzteVerantwortung(eintraege) {
    return eintraege.slice().sort(function (a, b) { return a.ab < b.ab ? -1 : (a.ab > b.ab ? 1 : 0); }).pop() || null;
  }

  Daten.prototype.besatzungHinzufuegen = function (aktivitaetId, personId, roh) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.personLaden(personId)]).then(function (r) {
      var a = r[0], person = r[1];
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (!person) return { ok: false, fehler: { personId: 'Bitte eine Person wählen.' } };
      var p = self.pruefenBesatzung(roh);
      if (p.werte.rolle === 'verantwortlich') p.fehler.rolle = 'Die verantwortliche Person wird über „Verantwortung wechseln“ bestimmt.';
      if (Object.keys(p.fehler).length) return { ok: false, fehler: p.fehler };
      var vorhanden = a.besatzung.concat(a.entfernte).filter(function (b) { return b.besatzung.personId === personId; })[0];
      if (vorhanden && vorhanden.aktuell.werte.entfernt !== 'ja') return { ok: false, fehler: { personId: 'Diese Person ist schon dabei.' } };
      if (vorhanden) {
        /* Wieder aufnehmen: neuer Eintrag, die frühere Zeit bleibt sichtbar */
        return self.mitVerlaufAendern('besatzung', vorhanden.besatzung.id, { aktuell: vorhanden.aktuell }, p.werte, BES_FELDER)
          .then(function (res) { res.id = vorhanden.besatzung.id; return res; });
      }
      var jetzt = self.jetzt();
      var b = { id: neueId('be'), aktivitaetId: aktivitaetId, personId: personId, erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'besatzung', objekt: b }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besatzung', b.id, 1, p.werte, null, jetzt) }
      ]).then(function () { return { ok: true, id: b.id }; });
    });
  };

  Daten.prototype.besatzungAendern = function (besatzungId, roh) {
    var self = this;
    return this.speicher.holen('besatzung', besatzungId).then(function (b) {
      if (!b) return { ok: false, fehler: { allgemein: 'Dieser Eintrag wurde nicht gefunden.' } };
      return Promise.all([self.mitVerlaufLaden('besatzung', besatzungId, BES_FELDER), self.speicher.wo('verantwortung', 'aktivitaetId', b.aktivitaetId)]).then(function (r) {
        var x = r[0], letzte = letzteVerantwortung(r[1]);
        var p = self.pruefenBesatzung(roh);
        var gleichBleibt = x.aktuell.werte.rolle === 'verantwortlich' && roh.rolle === 'verantwortlich';
        if (p.werte.rolle === 'verantwortlich' && !gleichBleibt) p.fehler.rolle = 'Die verantwortliche Person wird über „Verantwortung wechseln“ bestimmt.';
        if (Object.keys(p.fehler).length) return { ok: false, fehler: p.fehler };
        var istLetzter = letzte && letzte.personId === b.personId;
        if (istLetzter && (p.werte.entfernt === 'ja' || p.werte.rolle === 'crew')) {
          return { ok: false, fehler: { allgemein: 'Diese Person ist zuletzt als verantwortlich eingetragen. Wechsle zuerst die Verantwortung auf eine andere Person.' } };
        }
        return self.mitVerlaufAendern('besatzung', besatzungId, x, p.werte, BES_FELDER).then(function (res) { res.id = besatzungId; return res; });
      });
    });
  };

  /* Verantwortung ab einem Zeitpunkt auf eine andere Person übertragen. Nur Skipper/Fahrer und Stellvertreter. */
  Daten.prototype.verantwortungWechseln = function (aktivitaetId, personId, roh) {
    var self = this;
    roh = roh || {};
    var p = pruefeWerte([{ key: 'abDatum', typ: 'datum' }, { key: 'abZeit', typ: 'zeit' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var f = p.fehler, w = p.werte;
    if (!w.abDatum && !f.abDatum) f.abDatum = 'Bitte das Datum des Wechsels angeben.';
    if (!w.abZeit && !f.abZeit) f.abZeit = 'Bitte die Uhrzeit des Wechsels angeben.';
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var dabei = a.besatzung.filter(function (b) { return b.besatzung.personId === personId && (b.aktuell.werte.rolle === 'verantwortlich' || b.aktuell.werte.rolle === 'stellvertreter'); })[0];
      if (!dabei) return { ok: false, fehler: { personId: 'Verantwortlich kann nur sein, wer als ' + MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt) + ' oder Stellvertreter dabei ist.' } };
      var ab = w.abDatum + 'T' + w.abZeit;
      var letzte = letzteVerantwortung(a.verantwortung);
      if (letzte && ab <= letzte.ab) return { ok: false, fehler: { abDatum: 'Der Wechsel muss nach dem letzten Wechsel liegen (' + letzte.ab.replace('T', ', ') + ' Uhr).' } };
      if (letzte && letzte.personId === personId) return { ok: false, fehler: { personId: 'Diese Person ist schon verantwortlich.' } };
      if (a.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      /* Beim Wechsel prüft die App die Befähigung der übernehmenden Person und hält das Ergebnis mit „geprüft am“ fest.
         Sie weist nur hin und sperrt den Wechsel nicht. Liegt der Zeitpunkt mehr als 5 Minuten vor jetzt, ist es ein Nachtrag. */
      return self.aktivitaetPruefung(aktivitaetId).then(function (pr) {
        var pruefung = MM.Logbuch.wechselPruefungFestgehalten(pr, personId);
        var nachgetragen = MM.Logbuch.zeitpunktArt(w.abDatum, w.abZeit, self.jetztLokal()) === 'nachtrag';
        var jetzt = self.jetzt();
        var v = { id: neueId('ve'), aktivitaetId: aktivitaetId, personId: personId, ab: ab, erstelltAm: jetzt };
        if (pruefung) v.pruefung = pruefung;
        if (nachgetragen) v.nachgetragenAm = jetzt;
        return self.speicher.speichern('verantwortung', v).then(function () { return { ok: true, id: aktivitaetId, verantwortungId: v.id, pruefung: pruefung || null, nachgetragen: nachgetragen }; });
      });
    });
  };

  /* ---------- Aktivität laden, listen, prüfen ---------- */
  Daten.prototype.aktivitaetLaden = function (id) {
    var self = this;
    return this.speicher.holen('aktivitaeten', id).then(function (a) {
      if (!a) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id), self.speicher.wo('besatzung', 'aktivitaetId', id), self.speicher.alle('verlaeufe'),
        self.speicher.wo('verantwortung', 'aktivitaetId', id), self.personenListe(), self.tiereListe(), self.aktivitaetsartenListe(), self.fahrzeugListe(), self.gebieteListe()
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length) return null;
        var aktuell = eintraege[eintraege.length - 1], w = aktuell.werte;
        var personen = {}; r[4].forEach(function (p) { personen[p.objekt.id] = p.aktuell.werte.bezeichnung; });
        var tiere = {}; r[5].forEach(function (t) { tiere[t.objekt.id] = t.aktuell.werte.bezeichnung; });
        var arten = {}; r[6].forEach(function (x) { arten[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var gebiete = {}; r[8].forEach(function (x) { gebiete[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var fz = r[7].filter(function (x) { return x.fahrzeug.id === w.fahrzeugId; })[0] || null;
        var welt = fz ? MM.Fahrzeugarten.art(fz.fahrzeug.art).welt : 'land';

        var verl = {}; r[2].forEach(function (e) { if (e.objektTyp === 'besatzung') (verl[e.objektId] = verl[e.objektId] || []).push(e); });
        var alleB = r[1].map(function (b) {
          var l = (verl[b.id] || []).slice().sort(nachNr);
          var ak = l[l.length - 1];
          return ak ? { besatzung: b, aktuell: ak, person: { id: b.personId, name: personen[b.personId] || 'unbekannt' }, rolleText: MM.Aktivitaeten.rolleLabel(ak.werte.rolle, welt) } : null;
        }).filter(Boolean);
        var reihenfolge = { verantwortlich: 0, stellvertreter: 1, crew: 2 };
        alleB.sort(function (x, y) { return reihenfolge[x.aktuell.werte.rolle] - reihenfolge[y.aktuell.werte.rolle] || x.person.name.localeCompare(y.person.name, 'de'); });
        var aktiv = alleB.filter(function (b) { return b.aktuell.werte.entfernt !== 'ja'; });
        var entfernt = alleB.filter(function (b) { return b.aktuell.werte.entfernt === 'ja'; });

        /* Korrekturen der Wechsel (Verlauf der Verantwortung): der neueste Stand gilt, der ursprüngliche Zeitpunkt bleibt sichtbar. */
        var vv = {}; r[2].forEach(function (e) { if (e.objektTyp === 'verantwortung') (vv[e.objektId] = vv[e.objektId] || []).push(e); });
        var ver = r[3].map(function (v) {
          var l = (vv[v.id] || []).slice().sort(nachNr), k = l[l.length - 1];
          return { id: v.id, personId: v.personId, name: personen[v.personId] || 'unbekannt',
            ab: k ? k.werte.abDatum + 'T' + k.werte.abZeit : v.ab, abUrspruenglich: v.ab, erstelltAm: v.erstelltAm,
            notiz: k ? (k.werte.notiz || null) : null, ausgeblendet: k ? (k.werte.ausgeblendet || 'nein') : 'nein', geaendert: !!k,
            nachgetragenAm: v.nachgetragenAm || null, pruefung: v.pruefung || null };
        }).sort(function (x, y) { return x.ab < y.ab ? -1 : (x.ab > y.ab ? 1 : 0); });
        var jetzt = self.jetztLokal();
        var gerade = MM.Aktivitaeten.verantwortlicher(ver, jetzt);

        var verlauf = verlaufAus(eintraege, AKT_FELDER);
        verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            function wandeln(m, wert) { return wert ? m[wert] || 'unbekannt' : null; }
            if (u.key === 'artId') { u.feld = { typ: 'text' }; u.alt = wandeln(arten, u.alt); u.neu = wandeln(arten, u.neu); }
            if (u.key === 'fahrzeugId') { u.feld = { typ: 'text' }; u.alt = u.alt ? self.fahrzeugName(r[7], u.alt) : null; u.neu = u.neu ? self.fahrzeugName(r[7], u.neu) : null; }
            if (u.key === 'tierIds') { u.feld = { typ: 'text' }; u.alt = (u.alt || []).map(function (i) { return tiere[i] || 'unbekannt'; }).join(', ') || null; u.neu = (u.neu || []).map(function (i) { return tiere[i] || 'unbekannt'; }).join(', ') || null; }
            if (u.key === 'gebietId') { u.feld = { typ: 'text' }; u.alt = wandeln(gebiete, u.alt); u.neu = wandeln(gebiete, u.neu); }
            if (u.key === 'sperreUebergangenAm' || u.key === 'status') { u.feld = { typ: 'text' }; }
          });
        });
        return { aktivitaet: a, aktuell: aktuell, verlauf: verlauf, gebiet: w.gebietId ? { id: w.gebietId, name: gebiete[w.gebietId] || 'unbekannt' } : null, art: w.artId ? { id: w.artId, name: arten[w.artId] || 'unbekannt' } : null,
          fahrzeug: fz ? { id: fz.fahrzeug.id, name: fz.aktuell.werte.bezeichnung, artId: fz.fahrzeug.art, welt: welt } : { id: w.fahrzeugId, name: 'unbekannt', artId: null, welt: 'land' },
          besatzung: aktiv, entfernte: entfernt, verantwortung: ver, verantwortlichJetzt: gerade,
          tiere: (w.tierIds || []).map(function (i) { return { id: i, name: tiere[i] || 'unbekannt' }; }), status: MM.Aktivitaeten.status(w, jetzt) };
      });
    });
  };

  Daten.prototype.fahrzeugName = function (liste, id) {
    var f = liste.filter(function (x) { return x.fahrzeug.id === id; })[0];
    return f ? f.aktuell.werte.bezeichnung : 'unbekannt';
  };

  /* Alle Aktivitäten, mit Status und Überschneidungen am selben Fahrzeug. */
  Daten.prototype.aktivitaetenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('aktivitaeten'), this.speicher.alle('verlaeufe'), this.aktivitaetsartenListe(), this.fahrzeugListe()]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'aktivitaet');
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      var fz = {}; r[3].forEach(function (f) { fz[f.fahrzeug.id] = f; });
      var jetzt = self.jetztLokal();
      liste.forEach(function (x) {
        var w = x.aktuell.werte;
        x.artName = arten[w.artId] || '';
        x.fahrzeugName = fz[w.fahrzeugId] ? fz[w.fahrzeugId].aktuell.werte.bezeichnung : 'unbekannt';
        x.status = MM.Aktivitaeten.status(w, jetzt);
        x.konflikte = [];
      });
      liste.forEach(function (x) {
        if (x.status === 'storniert') return;
        liste.forEach(function (y) {
          if (y !== x && y.status !== 'storniert' && y.aktuell.werte.fahrzeugId === x.aktuell.werte.fahrzeugId && MM.Aktivitaeten.ueberschneiden(x.aktuell.werte, y.aktuell.werte)) x.konflikte.push(y.objekt.id);
        });
      });
      var rang = { laeuft: 0, geplant: 1, vorbei: 2, storniert: 3 };
      liste.sort(function (a, b) {
        var d = rang[a.status] - rang[b.status];
        if (d) return d;
        var va = MM.Aktivitaeten.von(a.aktuell.werte), vb = MM.Aktivitaeten.von(b.aktuell.werte);
        return a.status === 'vorbei' ? (va < vb ? 1 : -1) : (va < vb ? -1 : (va > vb ? 1 : 0));
      });
      return liste;
    });
  };

  /*
   * Prüfung bei der Planung: Befähigung von Skipper/Fahrer und Stellvertretern,
   * Fristen bis zum Ende des Zeitraums, Überschneidungen am Fahrzeug.
   * Nur mit den Daten, die die App kennt. Keine rechtliche Aussage.
   */
  Daten.prototype.aktivitaetPruefung = function (id) {
    var self = this;
    return this.aktivitaetLaden(id).then(function (a) {
      if (!a) return null;
      var w = a.aktuell.werte;
      var pruefpersonen = a.besatzung.filter(function (b) { return b.aktuell.werte.rolle === 'verantwortlich' || b.aktuell.werte.rolle === 'stellvertreter'; });
      return Promise.all([
        self.anforderungenListe(w.fahrzeugId, true),
        Promise.all(pruefpersonen.map(function (b) { return self.nachweiseListe('person', b.person.id); })),
        self.fristenListe(w.fahrzeugId),
        self.aktivitaetenListe(),
        w.gebietId ? self.regelnListe(w.gebietId) : Promise.resolve([]),
        self.komponentenListe(w.fahrzeugId)
      ]).then(function (r) {
        var anf = r[0].map(function (x) { return { bezeichnung: x.aktuell.werte.bezeichnung, artIds: x.aktuell.werte.artIds }; });
        /* Regeln des gewählten Gebiets: Sie gelten zusätzlich zu den Anforderungen am Fahrzeug. */
        var gebietInfo = null, ausruestungErgebnis = null;
        if (w.gebietId && a.gebiet) {
          var komp = r[5].filter(function (k) { return !k.aktuell.werte.ausgebautAm; }).map(function (k) { return k.aktuell.werte.bezeichnung; });
          var ausw = MM.Orte.regelnAuswerten({
            regeln: r[4].map(function (x) { return Object.assign({ id: x.objekt.id }, x.aktuell.werte); }),
            fahrzeugArt: a.fahrzeug.artId, komponentenNamen: komp });
          var befGreifen = ausw.greifen.filter(function (g) { return MM.Orte.regelArt(g) === 'befaehigung'; });
          var ausGreifen = ausw.greifen.filter(function (g) { return MM.Orte.regelArt(g) === 'ausruestung'; });
          befGreifen.forEach(function (g) { anf.push({ bezeichnung: 'Gebiet ' + a.gebiet.name + ': ' + g.bezeichnung, artIds: g.artIds }); });
          var befNicht = ausw.nichtGreifen.filter(function (n) { return MM.Orte.regelArt(n.regel) === 'befaehigung'; });
          gebietInfo = { id: a.gebiet.id, name: a.gebiet.name,
            regelnGesamt: r[4].filter(function (x) { return MM.Orte.regelArt(x.aktuell.werte) === 'befaehigung' && x.aktuell.werte.gilt !== 'nein'; }).length,
            greifen: befGreifen.map(function (g) { return g.bezeichnung; }),
            nichtGreifen: befNicht.map(function (n) { return { bezeichnung: n.regel.bezeichnung, grund: n.grund }; }) };
          /* Pflichtausrüstung: gesucht wird in den Namen der eingebauten Komponenten. Nicht eingetragen heißt „unklar“, nicht „fehlt“. */
          var kompDetail = r[5].filter(function (k) { return !k.aktuell.werte.ausgebautAm; })
            .map(function (k) { return { name: k.aktuell.werte.bezeichnung, anzahl: k.aktuell.werte.anzahl, geprueft: k.aktuell.werte.eignungGeprueft }; });
          var pflicht = ausGreifen.map(function (g) {
            var e = MM.Orte.ausruestungPruefen({ regel: g, komponenten: kompDetail, personen: a.besatzung.length });
            return { bezeichnung: g.bezeichnung, pflicht: g.pflichtAusruestung, status: e.status, soll: e.soll, ist: e.ist, istGeprueft: e.istGeprueft,
              menge: e.menge, bezug: e.bezug, eignung: e.eignung, text: e.text };
          });
          ausruestungErgebnis = { liste: pflicht, ergebnis: !pflicht.length ? null : (pflicht.every(function (x) { return x.status === 'eingetragen'; }) ? 'erlaubt' : 'unklar') };
        }
        var personen = pruefpersonen.map(function (b, i) {
          var nachweise = r[1][i].map(function (n) { return { artId: n.nachweis.artId, artName: n.art.aktuell.werte.bezeichnung, hatAblauf: MM.Nachweise.hatAblauf(n.art.aktuell.werte), werte: n.aktuell.werte }; });
          var res = MM.Aktivitaeten.pruefeBefaehigung({ anforderungen: anf, nachweise: nachweise, endDatum: w.bisDatum });
          return { person: b.person, rolle: b.aktuell.werte.rolle, rolleText: b.rolleText, ergebnis: res.ergebnis, gruende: res.gruende };
        });
        var ergebnis = MM.Aktivitaeten.gesamtErgebnis(personen.map(function (x) { return x.ergebnis; }));
        var gebiet = gebietInfo ? gebietInfo.name : (trimmed(w.gebiet) || null);
        var gebietHinweis = null;
        if (gebietInfo) {
          /* Kennt die App für dieses Gebiet und dieses Fahrzeug keine Regel, bleibt sie vorsichtig: höchstens „unklar“. */
          if (!gebietInfo.greifen.length) {
            gebietHinweis = gebietInfo.regelnGesamt
              ? 'Für das Gebiet „' + gebietInfo.name + '“ trifft keine Regel auf dieses Fahrzeug zu. Die Prüfung gilt nur für die Anforderungen am Fahrzeug.'
              : 'Für das Gebiet „' + gebietInfo.name + '“ gibt es noch keine Regel für die Befähigung. Die Prüfung gilt nur für die Anforderungen am Fahrzeug.';
            if (ergebnis === 'erlaubt') ergebnis = 'unklar';
          }
        } else if (gebiet) {
          gebietHinweis = 'Das Gebiet „' + gebiet + '“ ist nur als Text eingetragen und wird nicht geprüft. Wähle ein Gebiet aus der Liste, damit seine Regeln gelten.';
          if (ergebnis === 'erlaubt') ergebnis = 'unklar';
        }
        var fristEingabe = r[2].map(function (x) { return { bezeichnung: x.aktuell.werte.bezeichnung, werte: x.aktuell.werte, letzte: x.status.letzte, zaehler: x.zaehler }; });
        var fristen = MM.Aktivitaeten.fristenImZeitraum({ fristen: fristEingabe, heute: self.heute(), endDatum: w.bisDatum, geplanteStrecke: w.geplanteStrecke, geplanteStunden: w.geplanteStunden });
        var konflikte = r[3].filter(function (x) { return a.aktivitaet.id !== x.objekt.id && a.aktuell.werte.status !== 'storniert' && x.status !== 'storniert' && x.aktuell.werte.fahrzeugId === w.fahrzeugId && MM.Aktivitaeten.ueberschneiden(w, x.aktuell.werte); })
          .map(function (x) { return { id: x.objekt.id, name: x.aktuell.werte.bezeichnung, vonDatum: x.aktuell.werte.vonDatum, bisDatum: x.aktuell.werte.bisDatum }; });
        return { geprueftAm: self.jetztLokal(), anforderungen: anf.length,
          befaehigung: { ergebnis: ergebnis, personen: personen, gebiet: gebiet, gebietHinweis: gebietHinweis, gebietInfo: gebietInfo },
          ausruestung: ausruestungErgebnis,
          fristen: { liste: fristen, zusammenfassung: MM.Aktivitaeten.fristenZusammenfassung(fristen) }, belegung: { konflikte: konflikte } };
      });
    });
  };

  /* ---------- Fahrzeugarten verwalten (seit 2.0.16) ----------
   * Eigene Arten und Änderungen liegen als ein Dokument in „einstellungen“ (Kennung „fahrzeugarten“),
   * dadurch keine Umstellung des Speichers. Die Regeln selbst stehen in js/fahrzeugarten.js. */
  function fahrzeugartenSpeichern(self) {
    return self.speicher.speichern('einstellungen', MM.Fahrzeugarten.dokument());
  }
  /* Die Arten, die ein Fahrzeug hat (eine Art je Fahrzeug, auch doppelt). */
  Daten.prototype.fahrzeugartenBenutzt = function () {
    return this.speicher.alle('fahrzeuge').then(function (liste) { return liste.map(function (f) { return f.art; }); });
  };

  /* Die Ansicht: alle Arten mit Zustand und Zahl der Fahrzeuge (mit Untergruppen), dazu was „Ungebrauchtes löschen“ träfe. */
  Daten.prototype.fahrzeugartenVerwaltung = function () {
    return this.fahrzeugartenBenutzt().then(function (benutzt) {
      var F = MM.Fahrzeugarten, zahl = {};
      benutzt.forEach(function (b) { F.vorfahren(b).forEach(function (i) { zahl[i] = (zahl[i] || 0) + 1; }); });
      var arten = F.verwaltung().map(function (k) { k.fahrzeuge = zahl[k.id] || 0; return k; });
      var weg = F.ungebraucht(benutzt);
      return { arten: arten, ungebraucht: weg.map(function (i) { return { id: i, name: F.art(i).name }; }), wiederherstellbar: F.wiederherstellbar().length };
    });
  };

  Daten.prototype.fahrzeugartAnlegen = function (roh) {
    var self = this;
    roh = roh || {};
    var r = MM.Fahrzeugarten.anlegen(neueId('fa'), roh.name, roh.eltern);
    if (!r.ok) return Promise.resolve(r);
    return fahrzeugartenSpeichern(self).then(function () { return r; });
  };

  Daten.prototype.fahrzeugartAendern = function (id, roh) {
    var self = this;
    roh = roh || {};
    var r = MM.Fahrzeugarten.aendern(id, roh.name, roh.ausgeblendet);
    if (!r.ok || !r.geaendert) return Promise.resolve(r);
    return fahrzeugartenSpeichern(self).then(function () { return r; });
  };

  Daten.prototype.fahrzeugartLoeschen = function (id) {
    var self = this;
    return this.fahrzeugartenBenutzt().then(function (benutzt) {
      var r = MM.Fahrzeugarten.loeschen(id, benutzt);
      if (!r.ok) return r;
      return fahrzeugartenSpeichern(self).then(function () { return r; });
    });
  };

  /* Löscht alles Ungebrauchte (keine Gruppen Land, Wasser, Luft). Benutzte Arten bleiben. */
  Daten.prototype.fahrzeugartenBereinigen = function () {
    var self = this;
    return this.fahrzeugartenBenutzt().then(function (benutzt) {
      var r = MM.Fahrzeugarten.bereinigen(benutzt);
      if (!r.anzahl) return r;
      return fahrzeugartenSpeichern(self).then(function () { return r; });
    });
  };

  Daten.prototype.fahrzeugartenWiederherstellen = function () {
    var self = this;
    var r = MM.Fahrzeugarten.wiederherstellen();
    if (!r.anzahl) return Promise.resolve(r);
    return fahrzeugartenSpeichern(self).then(function () { return r; });
  };

  /* ---------- Logbuch-Kern: Ereignisarten (offene Liste) ---------- */
  /* Seit 2.0.15 gilt jede Ereignisart für Fahrzeugarten (Baum). Fehlt die Angabe (ältere Arten), gilt sie für alle. */
  var EREIGNISART_FELDER = AKTART_FELDER.concat([{ key: 'zuordnung', label: 'Gilt für Fahrzeugarten', typ: 'text' },
    { key: 'giltImStatus', label: 'Möglich im Status', typ: 'text' }, { key: 'danachStatus', label: 'Danach Status', typ: 'text' }]);

  Daten.prototype.ereignisartenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('ereignisarten'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'ereignisart');
    });
  };

  Daten.prototype.ereignisartAnlegen = function (roh) {
    var self = this;
    var bez = trimmed(roh && roh.bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segel gesetzt“.' } });
    return this.ereignisartenListe().then(function (liste) {
      if (liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === bez.toLowerCase(); })) {
        return { ok: false, fehler: { bezeichnung: 'Diese Art gibt es schon.' } };
      }
      /* Status-Regel (seit 2.0.23): beides leer = Starthilfe nach dem Namen. */
      var sr = MM.Status.regelNormal(roh);
      if (!sr.ok) return { ok: false, fehler: sr.fehler };
      return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: bez, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungNormal(roh.zuordnung),
        giltImStatus: sr.werte.giltImStatus, danachStatus: sr.werte.danachStatus });
    });
  };

  /* Legt die Vorschläge an, die es noch nicht gibt. Gibt die Anzahl der neuen zurück. */
  Daten.prototype.ereignisartenAusVorschlaegen = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Logbuch.VORSCHLAEGE_EREIGNISARTEN.filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
      return neu.reduce(function (kette, n) {
        return kette.then(function () { return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: n, ausgeblendet: 'nein' }); });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  /* Die Vorschläge mit Zuordnung zu Fahrzeugarten (Anlegen, Segel setzen, ...). Gibt die Anzahl der neuen zurück. */
  Daten.prototype.ereignisartenVorauswahlUebernehmen = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Logbuch.ZUSATZ_VORSCHLAEGE.filter(function (v) { return vorhanden.indexOf(v.bezeichnung.toLowerCase()) < 0; });
      return neu.reduce(function (kette, v) {
        return kette.then(function () {
          return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: v.bezeichnung, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(v.gilt) });
        });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  /* Die Ereignisarten, die zu einer Fahrzeugart passen (ohne ausgeblendete). Eine Art, die schon an einem
     Eintrag hängt, bleibt auswählbar (behalteIds), auch wenn sie nicht mehr zur Fahrzeugart passt. */
  Daten.prototype.ereignisartenFuerFahrzeugart = function (artId, behalteIds) {
    var behalte = behalteIds || [];
    return this.ereignisartenListe().then(function (liste) {
      return liste.filter(function (x) {
        if (behalte.indexOf(x.objekt.id) >= 0) return true;
        if (x.aktuell.werte.ausgeblendet === 'ja') return false;
        return !artId || MM.Logbuch.ereignisartGilt(x.aktuell.werte.zuordnung, artId);
      });
    });
  };

  Daten.prototype.ereignisartLaden = function (id) { return this.mitVerlaufLaden('ereignisarten', id, EREIGNISART_FELDER); };

  Daten.prototype.ereignisartAendern = function (id, roh) {
    var self = this;
    return this.ereignisartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var bez = trimmed(roh && roh.bezeichnung);
      if (!bez) return { ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben.' } };
      var neu = { bezeichnung: bez, ausgeblendet: roh.ausgeblendet === 'ja' ? 'ja' : 'nein' };
      /* Ohne Angabe bleibt die Zuordnung, wie sie ist (bei alten Arten: gilt für alle). */
      if (roh.zuordnung !== undefined) neu.zuordnung = MM.Logbuch.zuordnungNormal(roh.zuordnung);
      else if (x.aktuell.werte.zuordnung !== undefined) neu.zuordnung = x.aktuell.werte.zuordnung;
      /* Status-Regel (seit 2.0.23): ohne Angabe bleibt sie, wie sie ist. */
      if (roh.giltImStatus !== undefined || roh.danachStatus !== undefined) {
        var sr = MM.Status.regelNormal(roh);
        if (!sr.ok) return { ok: false, fehler: sr.fehler };
        neu.giltImStatus = sr.werte.giltImStatus; neu.danachStatus = sr.werte.danachStatus;
      } else {
        if (x.aktuell.werte.giltImStatus !== undefined) neu.giltImStatus = x.aktuell.werte.giltImStatus;
        if (x.aktuell.werte.danachStatus !== undefined) neu.danachStatus = x.aktuell.werte.danachStatus;
      }
      return self.mitVerlaufAendern('ereignisart', id, x, neu, EREIGNISART_FELDER);
    });
  };

  /* ---------- Logbuch ohne Planung starten (seit 2.0.15) ----------
   * Legt sofort eine Aktivität an: Beginn jetzt, Ende standardmäßig heute, Fahrzeug und verantwortliche Person Pflicht,
   * Stellvertreter und Crew freiwillig. Die Art wählt der Nutzer (seit 2.0.17) aus den Arten, die zum Fahrzeug passen;
   * ohne Angabe gilt „Ausfahrt“.
   * Die Aktivität läuft dann wie jede andere, mit derselben Prüfung. Nichts wird nebenbei gebaut.
   *  roh = { fahrzeugId, artId?, verantwortlichId, stellvertreterIds: [], crewIds: [], bisDatum? }  */
  Daten.prototype.logbuchSofortStarten = function (roh) {
    var self = this;
    roh = roh || {};
    return this.aktivitaetsartenAusVorschlaegen().then(function () { return self.aktivitaetKontext(); }).then(function (ctx) {
      var fz = ctx.fahrzeuge.filter(function (x) { return x.fahrzeug.id === roh.fahrzeugId; })[0];
      var fehler = {};
      if (!fz) fehler.fahrzeugId = ctx.fahrzeuge.length ? 'Bitte das Fahrzeug wählen.' : 'Es gibt noch kein Fahrzeug. Lege zuerst ein Fahrzeug an.';
      var welt = fz ? MM.Fahrzeugarten.art(fz.fahrzeug.art).welt : null;
      var verantwortlich = MM.Aktivitaeten.verantwortlichenName(welt);
      if (!ctx.personen.some(function (x) { return x.objekt.id === roh.verantwortlichId; })) {
        fehler.verantwortlichId = ctx.personen.length ? 'Bitte wählen, wer ' + (welt ? verantwortlich : 'verantwortlich') + ' ist.' : 'Es gibt noch keine Person. Lege zuerst die Besatzung an.';
      }
      var stell = (roh.stellvertreterIds || []).filter(function (i) { return i && i !== roh.verantwortlichId; });
      var crew = (roh.crewIds || []).filter(function (i) { return i && i !== roh.verantwortlichId && stell.indexOf(i) < 0; });
      var bekannt = ctx.personen.map(function (x) { return x.objekt.id; });
      if (stell.concat(crew).some(function (i) { return bekannt.indexOf(i) < 0; })) fehler.crewIds = 'Eine gewählte Person gibt es nicht (mehr).';
      var gewaehlt = roh.artId
        ? ctx.arten.filter(function (a) { return a.objekt.id === roh.artId; })[0]
        : ctx.arten.filter(function (a) { return a.aktuell.werte.bezeichnung.toLowerCase() === 'ausfahrt' && a.aktuell.werte.ausgeblendet !== 'ja'; })[0];
      if (roh.artId && !gewaehlt) fehler.artId = 'Bitte eine Art wählen.';
      else if (gewaehlt && gewaehlt.aktuell.werte.ausgeblendet === 'ja') fehler.artId = 'Die Art „' + gewaehlt.aktuell.werte.bezeichnung + '“ ist ausgeblendet. Wähle eine andere Art.';
      else if (!gewaehlt && !Object.keys(fehler).length) fehler.allgemein = 'Die Art „Ausfahrt“ ist ausgeblendet oder fehlt. Blende sie unter „Arten von Aktivitäten“ wieder ein oder wähle eine andere Art.';
      else if (gewaehlt && fz && !MM.Logbuch.ereignisartGilt(gewaehlt.aktuell.werte.zuordnung, fz.fahrzeug.art)) {
        fehler.artId = 'Die Art „' + gewaehlt.aktuell.werte.bezeichnung + '“ gilt nicht für dieses Fahrzeug. Wähle eine passende Art.';
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var jetzt = self.jetztLokal(), tag = jetzt.slice(0, 10), zeit = jetzt.slice(11, 16);
      var a = {
        bezeichnung: gewaehlt.aktuell.werte.bezeichnung + ' ' + fz.aktuell.werte.bezeichnung + ' ' + tag.slice(8, 10) + '.' + tag.slice(5, 7) + '.' + tag.slice(0, 4),
        artId: gewaehlt.objekt.id, fahrzeugId: roh.fahrzeugId,
        vonDatum: tag, vonZeit: zeit, bisDatum: roh.bisDatum || tag, bisZeit: '',
        verantwortlichId: roh.verantwortlichId, tierIds: [], notiz: 'Ohne Planung gestartet'
      };
      return self.aktivitaetAnlegen(a).then(function (res) {
        if (!res.ok) return res;
        var kette = Promise.resolve();
        stell.forEach(function (pid) { kette = kette.then(function () { return self.besatzungHinzufuegen(res.id, pid, { rolle: 'stellvertreter' }); }); });
        crew.forEach(function (pid) { kette = kette.then(function () { return self.besatzungHinzufuegen(res.id, pid, { rolle: 'crew' }); }); });
        return kette.then(function () { return { ok: true, id: res.id }; });
      });
    });
  };

  /* ---------- Logbuch-Kern: Tagesabschnitte, Ereignisse, Prüfung zum Tagesbeginn ---------- */
  var ABSCHNITT_FELDER = [
    { key: 'datum', label: 'Datum', typ: 'datum' },
    { key: 'beginnZeit', label: 'Beginn (Uhrzeit)', typ: 'zeit' },
    { key: 'endeZeit', label: 'Ende (Uhrzeit)', typ: 'zeit' },
    { key: 'von', label: 'Von', typ: 'text' },
    { key: 'nach', label: 'Nach', typ: 'text' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'zielTatsaechlich', label: 'Tatsächliches Ziel', typ: 'text' },
    { key: 'abschlussNotiz', label: 'Notiz zum Tagesabschluss', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];
  var EREIGNIS_FELDER = [
    { key: 'artId', label: 'Art', typ: 'text' },
    { key: 'datum', label: 'Datum', typ: 'datum' },
    { key: 'zeit', label: 'Uhrzeit', typ: 'zeit' },
    { key: 'text', label: 'Text', typ: 'text' },
    { key: 'breite', label: 'Breite', typ: 'text' },
    { key: 'laenge', label: 'Länge', typ: 'text' },
    { key: 'positionQuelle', label: 'Herkunft der Position', typ: 'text' },
    { key: 'ortName', label: 'Ortsname', typ: 'text' },
    { key: 'ortNameQuelle', label: 'Herkunft des Ortsnamens', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];
  var WECHSEL_FELDER = [
    { key: 'abDatum', label: 'Datum des Wechsels', typ: 'datum' },
    { key: 'abZeit', label: 'Uhrzeit des Wechsels', typ: 'zeit' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  /* Neuester Stand je Objekt aus dem Verlauf. Kein Datenraum-Filter, kein Sortieren nach Name. */
  function neuesteStaende(objekte, verlaeufe, typ) {
    var ver = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === typ) (ver[e.objektId] = ver[e.objektId] || []).push(e); });
    return objekte.map(function (o) {
      var l = (ver[o.id] || []).slice().sort(nachNr);
      return { objekt: o, aktuell: l[l.length - 1] || null, eintraege: l };
    }).filter(function (x) { return x.aktuell; });
  }

  /* Nur Aktivitäten, die nicht storniert sind, nehmen neue Einträge an (wie bei „Angaben ändern“). */
  function logbuchAktivitaet(self, aktivitaetId, schreibend) {
    return self.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (schreibend && a.aktuell.werte.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      return { a: a };
    });
  }

  function ausserhalbVon(a, datum) { return datum < a.aktuell.werte.vonDatum || datum > a.aktuell.werte.bisDatum; }

  /*
   * Das Logbuch einer Aktivität: alle Tagesabschnitte mit ihren Ereignissen (handeingetragene und
   * automatische Wechsel des Verantwortlichen), der festgehaltenen Prüfung und dem Verantwortlichen
   * zum Tagesbeginn. Es wird nichts geschrieben.
   */
  Daten.prototype.logbuchLaden = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.speicher.wo('tagesabschnitte', 'aktivitaetId', aktivitaetId),
      this.speicher.wo('ereignisse', 'aktivitaetId', aktivitaetId), this.speicher.alle('verlaeufe'),
      this.speicher.wo('tagespruefungen', 'aktivitaetId', aktivitaetId), this.ereignisartenListe()]).then(function (r) {
      var a = r[0];
      if (!a) return null;
      var arten = {}; r[5].forEach(function (x) { arten[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      var abschnitte = MM.Logbuch.abschnitteSortieren(neuesteStaende(r[1], r[3], 'tagesabschnitt'));
      var sichtbar = abschnitte.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; });
      var ziele = sichtbar.length ? sichtbar : abschnitte;

      var proAbschnitt = {};
      abschnitte.forEach(function (x) { proAbschnitt[x.objekt.id] = []; });
      neuesteStaende(r[2], r[3], 'ereignis').forEach(function (e) {
        var w = e.aktuell.werte;
        if (!proAbschnitt[e.objekt.abschnittId]) return;
        proAbschnitt[e.objekt.abschnittId].push({ art: 'ereignis', id: e.objekt.id, artName: arten[w.artId] || 'unbekannt', datum: w.datum, zeit: w.zeit,
          zeitpunkt: MM.Logbuch.ereignisZeit(w), text: w.text || null, ausgeblendet: w.ausgeblendet === 'ja',
          nachgetragen: w.nachgetragen === 'ja', nachgetragenAm: w.nachgetragenAm || null, erstelltAm: e.objekt.erstelltAm || null, hatFoto: !!w.dateiName, geaendert: e.eintraege.length > 1,
          ortName: w.ortName || null, ortNameQuelle: w.ortNameQuelle || null, breite: typeof w.breite === 'number' ? w.breite : null, laenge: typeof w.laenge === 'number' ? w.laenge : null, positionQuelle: w.positionQuelle || null });
      });
      MM.Logbuch.wechselEreignisse(a.verantwortung).forEach(function (wz) {
        var ziel = MM.Logbuch.abschnittFuer(ziele, wz.datum);
        if (!ziel) return;
        proAbschnitt[ziel.objekt.id].push({ art: 'wechsel', id: wz.verantwortungId, artName: MM.Logbuch.WECHSEL_ART, datum: wz.datum, zeit: wz.zeit,
          zeitpunkt: wz.ab, text: wz.text, notiz: wz.notiz, ausgeblendet: wz.ausgeblendet, nachgetragen: !!wz.nachgetragenAm, nachgetragenAm: wz.nachgetragenAm, pruefung: wz.pruefung, hatFoto: false, geaendert: wz.geaendert });
      });

      var pruefungen = {};
      r[4].slice().sort(function (x, y) { return x.erstelltAm < y.erstelltAm ? 1 : (x.erstelltAm > y.erstelltAm ? -1 : 0); })
        .forEach(function (p) { (pruefungen[p.abschnittId] = pruefungen[p.abschnittId] || []).push(p); });

      var liste = abschnitte.map(function (x) {
        var w = x.aktuell.werte;
        var tb = w.datum + 'T' + (w.beginnZeit || '00:00');
        var v = MM.Aktivitaeten.verantwortlicher(a.verantwortung, tb);
        var ereignisse = MM.Logbuch.ereignisseSortieren(proAbschnitt[x.objekt.id]);
        var verlauf = verlaufAus(x.eintraege, ABSCHNITT_FELDER);
        return { objekt: x.objekt, aktuell: x.aktuell, verlauf: verlauf, ausgeblendet: w.ausgeblendet === 'ja', ausserhalb: ausserhalbVon(a, w.datum),
          tagesbeginn: tb, verantwortlicher: v ? { personId: v.personId, name: v.name } : null,
          ereignisse: ereignisse, anzahlEreignisse: ereignisse.filter(function (e) { return !e.ausgeblendet; }).length,
          pruefungen: pruefungen[x.objekt.id] || [], pruefung: (pruefungen[x.objekt.id] || [])[0] || null };
      });
      var fehlend = MM.Logbuch.fehlendeTage(a.aktuell.werte, abschnitte.map(function (x) { return x.aktuell.werte.datum; }));
      return { aktivitaet: a, abschnitte: liste, fehlend: fehlend.neu.length, zuLang: fehlend.zuLang };
    });
  };

  /* Ein Abschnitt mit allem, was dazugehört (aus derselben Quelle wie das Logbuch). */
  Daten.prototype.abschnittLaden = function (id) {
    var self = this;
    return this.speicher.holen('tagesabschnitte', id).then(function (o) {
      if (!o) return null;
      return self.logbuchLaden(o.aktivitaetId).then(function (l) {
        if (!l) return null;
        var x = l.abschnitte.filter(function (y) { return y.objekt.id === id; })[0];
        return x ? { abschnitt: x, aktivitaet: l.aktivitaet } : null;
      });
    });
  };

  /* Prüft die Angaben eines Abschnitts. */
  Daten.prototype.pruefenAbschnitt = function (roh) {
    roh = roh || {};
    var felder = [{ key: 'datum', typ: 'datum' }, { key: 'beginnZeit', typ: 'zeit' }, { key: 'endeZeit', typ: 'zeit' },
      { key: 'von', typ: 'text' }, { key: 'nach', typ: 'text' }, { key: 'notiz', typ: 'text' }];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    if (!w.datum && !f.datum) f.datum = 'Bitte das Datum des Tages angeben.';
    if (w.beginnZeit && w.endeZeit && w.endeZeit < w.beginnZeit && !f.endeZeit) f.endeZeit = 'Die Uhrzeit des Endes liegt vor der des Beginns.';
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Die App bereitet die Tage aus dem Zeitraum der Aktivität vor. Bestehende Abschnitte bleiben unberührt. */
  Daten.prototype.tagesabschnitteVorbereiten = function (aktivitaetId) {
    var self = this;
    return logbuchAktivitaet(this, aktivitaetId, true).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      return self.speicher.wo('tagesabschnitte', 'aktivitaetId', aktivitaetId).then(function (vorhanden) {
        return self.speicher.alle('verlaeufe').then(function (vl) {
          var daten = neuesteStaende(vorhanden, vl, 'tagesabschnitt').map(function (x) { return x.aktuell.werte.datum; });
          var f = MM.Logbuch.fehlendeTage(k.a.aktuell.werte, daten);
          if (f.zuLang) return { ok: false, fehler: { allgemein: 'Der Zeitraum ist länger als ' + MM.Logbuch.MAX_TAGE + ' Tage. Lege die Tage von Hand an.' } };
          var jetzt = self.jetzt(), liste = [];
          f.neu.forEach(function (w) {
            var o = { id: neueId('tg'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, herkunft: 'vorbereitet', erstelltAm: jetzt };
            liste.push({ tabelle: 'tagesabschnitte', objekt: o });
            liste.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('tagesabschnitt', o.id, 1, w, null, jetzt) });
          });
          if (!liste.length) return { ok: true, anzahl: 0 };
          return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, anzahl: f.neu.length }; });
        });
      });
    });
  };

  /* Einen Tag von Hand ergänzen. */
  Daten.prototype.abschnittAnlegen = function (aktivitaetId, roh) {
    var self = this;
    return logbuchAktivitaet(this, aktivitaetId, true).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      var p = self.pruefenAbschnitt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      p.werte.ausgeblendet = 'nein';
      return self.mitVerlaufAnlegen('tagesabschnitte', 'tagesabschnitt', 'tg', p.werte, { aktivitaetId: aktivitaetId, herkunft: 'hand' });
    });
  };

  Daten.prototype.abschnittAendern = function (id, roh) {
    var self = this;
    return this.abschnittLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenAbschnitt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      /* Die Angaben des Tagesabschlusses stehen nicht im Formular „Tag ändern“ und bleiben unberührt. */
      var neu = Object.assign({}, x.abschnitt.aktuell.werte, p.werte);
      return self.mitVerlaufAendern('tagesabschnitt', id, { aktuell: x.abschnitt.aktuell }, neu, ABSCHNITT_FELDER);
    });
  };

  /* Die Prüfung der Aktivität zum Tagesbeginn festhalten (nur anhängen, nichts wird überschrieben). */
  Daten.prototype.tagesPruefungFesthalten = function (abschnittId) {
    var self = this;
    return this.abschnittLaden(abschnittId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      return self.aktivitaetPruefung(x.aktivitaet.aktivitaet.id).then(function (pr) {
        var stand = MM.Logbuch.pruefungFestgehalten(pr, x.abschnitt.verantwortlicher, x.abschnitt.tagesbeginn);
        var rec = { id: neueId('tp'), datenraumId: self.datenraumId, aktivitaetId: x.aktivitaet.aktivitaet.id, abschnittId: abschnittId, stand: stand, erstelltAm: self.jetzt() };
        return self.speicher.speichern('tagespruefungen', rec).then(function () { return { ok: true, id: rec.id }; });
      });
    });
  };

  /* ---------- Ereignisse ---------- */
  /* nachtragen = true: Der Zeitpunkt ist der echte, vergangene Zeitpunkt; das Ereignis steht dann als „nachgetragen am …“ da. */
  Daten.prototype.pruefenEreignis = function (roh, arten, nachtragen, bisherigeArt) {
    roh = roh || {};
    var felder = [
      { key: 'artId', typ: 'auswahl', optionen: arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || a.objekt.id === bisherigeArt; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; }) },
      { key: 'datum', typ: 'datum' }, { key: 'zeit', typ: 'zeit' }, { key: 'text', typ: 'text' }
    ];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    if (!w.artId && !f.artId) f.artId = arten.length ? 'Bitte die Art des Ereignisses wählen.' : 'Es gibt noch keine Art. Übernimm zuerst die Vorschläge oder lege eine Art an.';
    if (!w.datum && !f.datum) f.datum = 'Bitte das Datum angeben.';
    if (!w.zeit && !f.zeit) f.zeit = 'Bitte die Uhrzeit angeben.';
    if (nachtragen && w.datum && w.zeit && !f.datum && !f.zeit && w.datum + 'T' + w.zeit > this.jetztLokal()) {
      f.zeit = 'Ein Nachtrag liegt in der Vergangenheit. Der Zeitpunkt darf nicht nach jetzt liegen.';
    }
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    /* Position und Ortsname (seit 2.0.21): nur wenn die Eingaben sie überhaupt nennen, sonst bleibt ein bestehender Stand unverändert. */
    if (roh.breite !== undefined || roh.laenge !== undefined || roh.ortName !== undefined) {
      var pos = MM.Logbuch.positionPruefen(roh);
      Object.keys(pos.werte).forEach(function (k) { w[k] = pos.werte[k]; });
      Object.keys(pos.fehler).forEach(function (k) { f[k] = pos.fehler[k]; });
    }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* ---------- Position: Gerät und gelernte Ortsnamen (seit 2.0.21) ---------- */
  var POSITIONSNAMEN_DOK = 'positionsnamen';

  /* Die Kennung dieses Geräts. Sie entsteht beim ersten Bedarf und gehört zum Gerät (nicht in die Sicherung). */
  Daten.prototype.geraetKennung = function () {
    var self = this;
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      if (dok && dok.geraetId) return dok.geraetId;
      var id = neueId('ge');
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, geraetId: id })).then(function () { return id; });
    });
  };

  /* Alle gelernten Ortsnamen, nach Name sortiert: [{ name, breite, laenge, n, zuletzt }] */
  Daten.prototype.positionsnamenListe = function () {
    return this.speicher.holen('einstellungen', POSITIONSNAMEN_DOK).then(function (dok) {
      return ((dok && dok.punkte) || []).slice().sort(function (a, b) { return a.name.localeCompare(b.name, 'de'); });
    });
  };

  /* Zu dieser Position: der Name eines bekannten Ortes im Umfeld, oder null. { name, abstand } */
  Daten.prototype.ortNameVorschlag = function (breite, laenge) {
    if (typeof breite !== 'number' || typeof laenge !== 'number') return Promise.resolve(null);
    return this.speicher.holen('einstellungen', POSITIONSNAMEN_DOK).then(function (dok) {
      return MM.Logbuch.ortSuchen(dok && dok.punkte, breite, laenge);
    });
  };

  /* Nach dem Speichern: Hat der Nutzer zur Position einen Namen eingegeben oder bestätigt, merkt sich die App ihn. */
  Daten.prototype.ortLernenNachSpeichern = function (w) {
    var self = this;
    if (!w || typeof w.breite !== 'number' || typeof w.laenge !== 'number' || !w.ortName || w.ortNameQuelle !== 'hand') return Promise.resolve(false);
    return this.speicher.holen('einstellungen', POSITIONSNAMEN_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', MM.Logbuch.ortLernen(dok, w.ortName, w.breite, w.laenge, self.jetzt()));
    }).then(function () { return true; });
  };

  Daten.prototype.ereignisAnlegen = function (abschnittId, roh, optionen) {
    var self = this;
    var nachtragen = !!(optionen && optionen.nachtragen);
    roh = roh || {};
    return Promise.all([this.abschnittLaden(abschnittId), this.ereignisartenListe(), this.geraetKennung()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenEreignis(roh, r[1], nachtragen, null);
      var fehler = p.fehler, w = p.werte;
      /* Störung im Logbuch (seit 2.0.26): Das Ereignis „Störung“ legt den Werkstatt-Vorgang an, es gibt nur eine Störung.
         Ohne Angabe gilt „Fahrzeug bleibt nutzbar“ (vorbelegt, Festlegung des Nutzers vom 04.11.2026); der Nutzer ändert es beim Vorgang.
         Die Störung hängt am Fahrzeug der Aktivität. Auch ein Nachtrag legt den Vorgang an, mit dem Datum des Ereignisses. */
      var gewaehlteArt = r[1].filter(function (a) { return a.objekt.id === w.artId; })[0];
      var stoerung = !!gewaehlteArt && MM.Logbuch.istStoerungArt(gewaehlteArt.aktuell.werte.bezeichnung);
      var vorgangWerte = null;
      if (stoerung && !fehler.artId) {
        var au = roh.auswirkung === undefined || roh.auswirkung === null ? '' : String(roh.auswirkung).trim();
        if (!au) au = 'keine';
        if (!MM.Werkstatt.AUSWIRKUNGEN.some(function (o) { return o.wert === au; })) fehler.auswirkung = 'Bitte wählen, wie weit die Störung das Fahrzeug einschränkt.';
        else if (w.datum && w.zeit) {
          var vw = MM.Werkstatt.ausEreignis(w.text, w.datum, w.zeit, self.heute());
          var vp = self.pruefenVorgang({ bezeichnung: vw.bezeichnung, beschreibung: vw.beschreibung, auswirkung: au, gemeldetAm: vw.gemeldetAm }, 'stoerung');
          if (!vp.ok) fehler.allgemein = 'Die Störung konnte nicht als Vorgang in der Werkstatt angelegt werden: ' + Object.keys(vp.fehler).map(function (k) { return vp.fehler[k]; }).join(' ');
          else vorgangWerte = vp.werte;
        }
      }
      /* Schnelles Eintragen (Cockpit): Kennt die App den Ort im Umfeld, steht ihr Name als Vorschlag dabei. Gelernt wird er erst, wenn der Nutzer ihn bestätigt. */
      var vorschlag = optionen && optionen.ortVorschlag && !fehler.breite && !fehler.laenge && typeof w.breite === 'number' && !w.ortName
        ? self.ortNameVorschlag(w.breite, w.laenge) : Promise.resolve(null);
      return vorschlag.then(function (v) {
      if (v) { w.ortName = v.name; w.ortNameQuelle = 'vorschlag'; }
      /* Weicht die Zeit um mehr als 5 Minuten von jetzt ab (in der Vergangenheit), ist es automatisch ein Nachtrag (wie in V1). */
      if (!nachtragen && !Object.keys(fehler).length && MM.Logbuch.zeitpunktArt(w.datum, w.zeit, self.jetztLokal()) === 'nachtrag') nachtragen = true;
      var datei = roh.datei;
      if (datei && !(typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Diese Datei ist leer.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      /* Status des Fahrzeugs (seit 2.0.23): Ein Ereignis „jetzt“ wird nur gespeichert, wenn es im aktuellen Status möglich ist.
         Das Nachtragen mit früherer Uhrzeit wird nie gesperrt, damit Vergessenes nachgetragen werden kann. */
      var artGewaehlt = nachtragen ? null : r[1].filter(function (a) { return a.objekt.id === w.artId; })[0];
      var statusPruefung = artGewaehlt ? self.fahrzeugStatus(x.aktivitaet.aktuell.werte.fahrzeugId) : Promise.resolve(null);
      return statusPruefung.then(function (st) {
      if (st && st.ok) {
        var pr = st.pruefe(artGewaehlt.aktuell.werte.bezeichnung);
        if (!pr.erlaubt) return { ok: false, gesperrt: true, grund: pr.grund, status: pr.statusName,
          fehler: { allgemein: '„' + artGewaehlt.aktuell.werte.bezeichnung + '“ geht jetzt nicht, das Fahrzeug hat den Status „' + pr.statusName + '“ (' + pr.grund + '). Hast du etwas vergessen? Dann trage es mit der echten Uhrzeit nach.' } };
      }
      var jetzt = self.jetzt();
      w.ausgeblendet = 'nein';
      w.nachgetragen = nachtragen ? 'ja' : 'nein';
      w.nachgetragenAm = nachtragen ? jetzt : null;
      w.dateiName = datei ? String(datei.name || 'Foto') : null;
      w.dateiTyp = datei ? String(datei.type || '') : null;
      w.dateiGroesse = datei ? datei.size : null;
      w.geraetId = r[2];
      var e = { id: neueId('ev'), datenraumId: self.datenraumId, aktivitaetId: x.aktivitaet.aktivitaet.id, abschnittId: abschnittId, erstelltAm: jetzt };
      var liste = [{ tabelle: 'ereignisse', objekt: e }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ereignis', e.id, 1, w, null, jetzt) }];
      var vorgangId = null;
      if (vorgangWerte) {
        /* Ereignis, Vorgang und beider Verlauf werden zusammen gespeichert: ganz oder gar nicht. */
        vorgangWerte.art = 'stoerung'; vorgangWerte.status = 'offen'; vorgangWerte.erledigtAm = null; vorgangWerte.erledigtNotiz = null;
        var vg = { id: neueId('vg'), fahrzeugId: x.aktivitaet.aktuell.werte.fahrzeugId, komponenteId: null, erstelltAm: jetzt, ereignisId: e.id };
        vorgangId = vg.id; e.vorgangId = vg.id;
        liste.push({ tabelle: 'vorgaenge', objekt: vg }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('vorgang', vg.id, 1, vorgangWerte, null, jetzt) });
      }
      if (datei) liste.push({ tabelle: 'ereignisdateien', objekt: { id: neueId('ed'), ereignisId: e.id, name: w.dateiName, mime: w.dateiTyp, groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      return self.speicher.mehrereSpeichern(liste).then(function () { return self.ortLernenNachSpeichern(w); }).then(function () {
        return { ok: true, id: e.id, vorgangId: vorgangId, breite: w.breite === undefined ? null : w.breite, laenge: w.laenge === undefined ? null : w.laenge, ortName: w.ortName || null, ortNameQuelle: w.ortNameQuelle || null };
      }).catch(function (err) {
        if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei.' } };
        throw err;
      });
      });
      });
    });
  };

  /* ---------- Status des Fahrzeugs (seit 2.0.23) ----------
   * Der Status gehört zum Fahrzeug und wird aus allen sichtbaren Ereignissen seiner Aktivitäten nach Uhrzeit gerechnet,
   * nichts wird dafür gemerkt. Die Regeln stehen in js/status.js, die Regel einer Art hängt an der Art (nicht am Namen).
   * Ergebnis: { ok, fahrzeugId, welt, hatStatus, stand (MM.Status.rechnen), regeln: [{ name, artId, regel }], pruefe(artName) } */
  Daten.prototype.fahrzeugStatus = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.fahrzeugListe(), this.aktivitaetenListe(), this.ereignisartenListe()]).then(function (r) {
      var fz = r[0].filter(function (f) { return f.fahrzeug.id === fahrzeugId; })[0];
      if (!fz) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      var welt = MM.Fahrzeugarten.art(fz.fahrzeug.art).welt;
      var arten = {}, regeln = [];
      r[2].forEach(function (a) {
        var w = a.aktuell.werte;
        arten[String(w.bezeichnung || '').trim().toLowerCase()] = w;
        if (w.ausgeblendet === 'ja') return;
        if (!MM.Logbuch.ereignisartGilt(w.zuordnung, fz.fahrzeug.art)) return;
        regeln.push({ name: w.bezeichnung, artId: a.objekt.id, regel: MM.Status.regelFuer(w, welt) });
      });
      var meine = r[1].filter(function (a) { return a.aktuell.werte.fahrzeugId === fahrzeugId && a.aktuell.werte.status !== 'storniert' && a.status !== 'storniert'; });
      return Promise.all(meine.map(function (a) { return self.logbuchLaden(a.objekt.id); })).then(function (lbs) {
        var ereignisse = [];
        lbs.forEach(function (lb) {
          if (!lb) return;
          lb.abschnitte.forEach(function (x) {
            if (x.ausgeblendet) return;
            x.ereignisse.forEach(function (e) { if (e.art === 'ereignis' && !e.ausgeblendet) ereignisse.push({ id: e.id, artName: e.artName, zeitpunkt: e.zeitpunkt, erstelltAm: e.erstelltAm || null }); });
          });
        });
        var stand = MM.Status.rechnen(ereignisse, arten, welt, self.jetztLokal());
        function regelVonName(n) {
          var w = arten[String(n || '').trim().toLowerCase()];
          return MM.Status.regelFuer(w || { bezeichnung: n }, welt);
        }
        return { ok: true, fahrzeugId: fahrzeugId, welt: welt, hatStatus: MM.Status.hatStatus(welt), stand: stand, regeln: regeln,
          pruefe: function (artName) { return MM.Status.pruefen(regelVonName(artName), stand, regeln); } };
      });
    });
  };

  Daten.prototype.ereignisLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('ereignisse', id, EREIGNIS_FELDER).then(function (x) {
      if (!x) return null;
      return Promise.all([self.ereignisartenListe(), self.abschnittLaden(x.objekt.abschnittId), self.speicher.wo('ereignisdateien', 'ereignisId', id)]).then(function (r) {
        var arten = {}; r[0].forEach(function (a) { arten[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artId') { u.feld = { typ: 'text' }; u.alt = u.alt ? arten[u.alt] || 'unbekannt' : null; u.neu = u.neu ? arten[u.neu] || 'unbekannt' : null; }
            /* Herkunft in Worten (seit 2.0.21) */
            var herkunft = { gps: 'GPS', hand: u.key === 'ortNameQuelle' ? 'von dir eingegeben oder bestätigt' : 'von Hand', vorschlag: 'Vorschlag der App' };
            if (u.key === 'positionQuelle' || u.key === 'ortNameQuelle') { u.alt = u.alt ? herkunft[u.alt] || u.alt : null; u.neu = u.neu ? herkunft[u.neu] || u.neu : null; }
          });
        });
        var w = x.aktuell.werte, d = r[2][0];
        return { ereignis: x.objekt, aktuell: x.aktuell, verlauf: x.verlauf, art: w.artId ? { id: w.artId, name: arten[w.artId] || 'unbekannt' } : null, arten: r[0],
          abschnitt: r[1] ? r[1].abschnitt : null, aktivitaet: r[1] ? r[1].aktivitaet : null,
          datei: d ? { id: d.id, name: d.name, mime: d.mime, groesse: d.groesse } : null };
      });
    });
  };

  Daten.prototype.ereignisDateiHolen = function (ereignisId) {
    return this.speicher.wo('ereignisdateien', 'ereignisId', ereignisId).then(function (l) { return l[0] || null; });
  };

  Daten.prototype.ereignisAendern = function (id, roh) {
    var self = this;
    return this.ereignisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      if (x.aktivitaet && x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var alt = x.aktuell.werte;
      var p = self.pruefenEreignis(roh, x.arten, alt.nachgetragen === 'ja', alt.artId);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      /* Störung (seit 2.0.26): Nur ein neues Ereignis „Störung“ legt den Vorgang in der Werkstatt an. Eine Art nachträglich auf „Störung“ zu stellen, würde die Werkstatt auslassen. */
      if (p.werte.artId !== alt.artId && !(x.ereignis && x.ereignis.vorgangId)) {
        var neueArt = x.arten.filter(function (a) { return a.objekt.id === p.werte.artId; })[0];
        if (neueArt && MM.Logbuch.istStoerungArt(neueArt.aktuell.werte.bezeichnung)) {
          return { ok: false, fehler: { artId: 'Eine Störung meldest du mit „Ereignis eintragen“ oder „Nachtragen“, damit sie auch in der Werkstatt steht. Ändere hier nicht die Art.' } };
        }
      }
      var neu = Object.assign({}, alt, p.werte);
      return self.mitVerlaufAendern('ereignis', id, { aktuell: x.aktuell }, neu, EREIGNIS_FELDER).then(function (r) {
        var anders = alt.ortName !== neu.ortName || alt.ortNameQuelle !== neu.ortNameQuelle || alt.breite !== neu.breite || alt.laenge !== neu.laenge;
        if (r && r.ok && anders) return self.ortLernenNachSpeichern(neu).then(function () { return r; });
        return r;
      });
    });
  };

  /* ---------- 2.0.14: Cockpit (schnelles Eintragen) und Tagesabschluss ---------- */
  /* Der heutige Tag: der sichtbare Tag von heute wird geöffnet, gibt es keinen, legt die App ihn von selbst an
     (ohne vorheriges „Tage vorbereiten“). Nur wenn der heutige Tag im Zeitraum der Aktivität liegt und sie nicht storniert ist. */
  Daten.prototype.heutigerTag = function (aktivitaetId) {
    var self = this;
    return this.logbuchLaden(aktivitaetId).then(function (lb) {
      if (!lb) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var a = lb.aktivitaet, heute = self.heute();
      var c = MM.Logbuch.cockpitMoeglich(a.aktuell.werte, heute);
      if (!c.moeglich) {
        var text = { storniert: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.',
          geplant: 'Die Aktivität beginnt erst am ' + MM.Hilfen.datum(a.aktuell.werte.vonDatum) + '. Das Cockpit trägt nur ein, wenn heute im Zeitraum liegt.',
          vorbei: 'Die Aktivität war bis ' + MM.Hilfen.datum(a.aktuell.werte.bisDatum) + '. Das Cockpit trägt nur ein, wenn heute im Zeitraum liegt. Im Logbuch kannst du Tage ergänzen und nachtragen.' }[c.grund];
        return { ok: false, fehler: { allgemein: text } };
      }
      var vorhanden = MM.Logbuch.heutigerAbschnitt(lb.abschnitte, heute);
      if (vorhanden) return { ok: true, abschnittId: vorhanden.objekt.id, neu: false };
      var werte = MM.Logbuch.fehlendeTage(a.aktuell.werte, []).neu.filter(function (x) { return x.datum === heute; })[0]
        || { datum: heute, beginnZeit: null, endeZeit: null, von: null, nach: null, notiz: null, ausgeblendet: 'nein' };
      return self.mitVerlaufAnlegen('tagesabschnitte', 'tagesabschnitt', 'tg', werte, { aktivitaetId: aktivitaetId, herkunft: 'vorbereitet' })
        .then(function (r) { return { ok: true, abschnittId: r.id, neu: true }; });
    });
  };

  /* Ein Tipp auf Abfahrt, Ankunft oder Notiz: Ereignis mit der Uhrzeit „jetzt“, ohne Formular.
     art: 'Abfahrt', 'Ankunft' oder 'Notiz' (Name der Art). Fehlen die Vorschläge der Arten, werden sie angelegt. */
  Daten.prototype.ereignisSchnell = function (aktivitaetId, artName, roh) {
    var self = this;
    roh = roh || {};
    return this.heutigerTag(aktivitaetId).then(function (t) {
      if (!t.ok) return t;
      return self.ereignisartenAusVorschlaegen().then(function () { return self.ereignisartenListe(); }).then(function (arten) {
        /* Ist die Art schon gewählt (artId), wird nicht nach dem Namen gesucht. */
        var art = roh.artId ? { objekt: { id: roh.artId }, aktuell: { werte: { ausgeblendet: 'nein' } } }
          : arten.filter(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === String(artName).toLowerCase(); })[0];
        if (!art) return { ok: false, fehler: { allgemein: 'Die Art „' + artName + '“ gibt es nicht.' } };
        if (art.aktuell.werte.ausgeblendet === 'ja') return { ok: false, fehler: { allgemein: 'Die Art „' + artName + '“ ist ausgeblendet. Blende sie unter „Arten von Ereignissen“ wieder ein.' } };
        /* Leere Zeit heißt „jetzt“ und wird erst beim Speichern genommen, nicht beim Öffnen der Seite. */
        var jetzt = self.jetztLokal();
        var werte = { artId: roh.artId || art.objekt.id, datum: roh.datum || jetzt.slice(0, 10), zeit: roh.zeit || jetzt.slice(11, 16), text: roh.text || '', datei: roh.datei || null };
        if (!roh.datum && roh.zeit) werte.datum = jetzt.slice(0, 10);
        /* Position (seit 2.0.21): vom GPS des Geräts, nur wenn der Aufrufer eine frische mitgibt und die Uhrzeit „jetzt“ ist (beim Nachtragen gibt es keine GPS-Position). */
        var pos = roh.position;
        var mitPosition = pos && !roh.zeit && typeof pos.breite === 'number' && typeof pos.laenge === 'number';
        if (mitPosition) {
          werte.breite = pos.breite; werte.laenge = pos.laenge;
          werte.gpsBreite = pos.breite; werte.gpsLaenge = pos.laenge; werte.gpsGenauigkeit = pos.genauigkeit;
        }
        if (roh.ortName !== undefined) werte.ortName = roh.ortName;
        if (roh.auswirkung !== undefined) werte.auswirkung = roh.auswirkung;
        /* Ohne Namen vom Nutzer schlägt die App einen bekannten Ort im Umfeld vor. Hat der Nutzer das Feld bewusst geleert (ortName ''), bleibt es leer. */
        var vorschlagen = mitPosition && roh.ortName === undefined;
        return self.ereignisAnlegen(t.abschnittId, werte, { ortVorschlag: vorschlagen }).then(function (r) {
          if (r.ok) { r.zeit = werte.zeit; r.datum = werte.datum; r.abschnittId = t.abschnittId; }
          return r;
        });
      });
    });
  };

  /* ---------- Schnellknöpfe im Cockpit (seit 2.0.18) ----------
   * Die Belegung liegt als ein Dokument „schnellknoepfe“ in „einstellungen“ (keine Umstellung des Speichers, in der
   * Sicherung enthalten). Die Regeln stehen in js/logbuch.js. */
  /*
   * knoepfeAlle: alle Knöpfe, die für die Fahrzeugart belegt sind (bis 15).
   * knoepfe:     die Knöpfe, die dieses Gerät zeigt (die ersten „geraetMax“, seit 2.0.20).
   * sonstige:    alles, was nicht auf einem gezeigten Knopf liegt (auch die Knöpfe, die dieses Gerät nicht mehr zeigt).
   */
  Daten.prototype.schnellknoepfeFuerFahrzeugart = function (artId) {
    var self = this;
    return this.ereignisartenAusVorschlaegen().then(function () {
      return Promise.all([self.ereignisartenListe(), self.speicher.holen('einstellungen', 'schnellknoepfe'), self.geraetEinstellungen()]);
    }).then(function (r) {
      var angebot = MM.Logbuch.schnellAngebot(r[0], artId);
      var belegung = MM.Logbuch.schnellBelegung(r[1], artId);
      var alle = MM.Logbuch.schnellKnoepfe(belegung, angebot);
      var knoepfe = MM.Logbuch.schnellAufGeraet(alle, r[2].knoepfe);
      return { artId: artId, angebot: angebot, knoepfe: knoepfe, knoepfeAlle: alle, sonstige: MM.Logbuch.schnellSonstige(knoepfe, angebot),
        eigene: belegung.eigene, von: belegung.von, standard: belegung.keys === null, max: MM.Logbuch.MAX_SCHNELL,
        geraetMax: r[2].knoepfe, geraetGesetzt: r[2].knoepfeGesetzt, versteckt: alle.length - knoepfe.length };
    });
  };

  /* slots: Liste von Schlüsseln in der Reihenfolge der Knöpfe, leere Felder dürfen vorkommen. Die Fehler heißen s1 bis s15. */
  Daten.prototype.schnellknoepfeSetzen = function (artId, slots) {
    var self = this;
    if (!MM.Fahrzeugarten.knoten(artId)) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Fahrzeugart gibt es nicht.' } });
    slots = (slots || []).slice(0, MM.Logbuch.MAX_SCHNELL);
    return this.schnellknoepfeFuerFahrzeugart(artId).then(function (info) {
      var gueltig = {}, fehler = {}, an = {}, keys = [];
      info.angebot.alle.forEach(function (x) { gueltig[x.key] = x.name; });
      slots.forEach(function (k, i) {
        if (!k) return;
        var feld = 's' + (i + 1);
        if (!gueltig[k]) fehler[feld] = 'Das gibt es für diese Fahrzeugart nicht (mehr). Wähle etwas anderes.';
        else if (an[k]) fehler[feld] = '„' + gueltig[k] + '“ liegt schon auf Knopf ' + an[k] + '.';
        else { an[k] = i + 1; keys.push(k); }
      });
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      return self.speicher.holen('einstellungen', 'schnellknoepfe').then(function (dok) {
        return self.speicher.speichern('einstellungen', MM.Logbuch.schnellDokumentSetzen(dok, artId, keys));
      }).then(function () { return { ok: true, id: artId, anzahl: keys.length }; });
    });
  };

  /* Die Art hat dann keine eigene Liste mehr und übernimmt die der Obergruppe (oder den Standard). */
  Daten.prototype.schnellknoepfeZuruecksetzen = function (artId) {
    var self = this;
    return this.speicher.holen('einstellungen', 'schnellknoepfe').then(function (dok) {
      if (!dok || !dok.belegung || !Array.isArray(dok.belegung[artId])) return { ok: true, id: artId, geaendert: false };
      return self.speicher.speichern('einstellungen', MM.Logbuch.schnellDokumentZuruecksetzen(dok, artId)).then(function () { return { ok: true, id: artId, geaendert: true }; });
    });
  };

  /* ---------- Hat die Fahrzeugart einen Motor? (seit 2.0.20) ----------
   * Die Einstellung des Nutzers liegt als ein Dokument „fahrzeugart-motor“ in „einstellungen“ (keine Umstellung des
   * Speichers, in der Sicherung enthalten). Die Regeln stehen in js/motoren.js. Es ist nur ein Hinweis, keine Sperre. */
  var MOTOR_DOK = 'fahrzeugart-motor';

  Daten.prototype.fahrzeugartMotor = function (artId) {
    return this.speicher.holen('einstellungen', MOTOR_DOK).then(function (dok) {
      var r = MM.Motoren.motorArt(dok, artId);
      r.artId = artId;
      return r;
    });
  };

  /* wert: 'ja' oder 'nein' */
  Daten.prototype.fahrzeugartMotorSetzen = function (artId, wert) {
    var self = this;
    if (wert !== 'ja' && wert !== 'nein') return Promise.resolve({ ok: false, fehler: { allgemein: 'Bitte „Hat einen Motor“ oder „Hat keinen Motor“ wählen.' } });
    if (!MM.Fahrzeugarten.knoten(artId)) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Fahrzeugart gibt es nicht.' } });
    return this.speicher.holen('einstellungen', MOTOR_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', MM.Motoren.motorDokumentSetzen(dok, artId, wert));
    }).then(function () { return { ok: true, id: artId, wert: wert }; });
  };

  /* Die Art hat dann keine eigene Einstellung mehr und übernimmt die der Obergruppe (oder die Voreinstellung). */
  Daten.prototype.fahrzeugartMotorZuruecksetzen = function (artId) {
    var self = this;
    return this.speicher.holen('einstellungen', MOTOR_DOK).then(function (dok) {
      if (!dok || !dok.werte || (dok.werte[artId] !== 'ja' && dok.werte[artId] !== 'nein')) return { ok: true, id: artId, geaendert: false };
      return self.speicher.speichern('einstellungen', MM.Motoren.motorDokumentSetzen(dok, artId, null)).then(function () { return { ok: true, id: artId, geaendert: true }; });
    });
  };

  /* ---------- Einstellungen dieses Geräts (seit 2.0.20) ----------
   * Was nur für das einzelne Gerät gilt (zum Beispiel wie viele Knöpfe das Cockpit zeigt), liegt als ein Dokument
   * „geraet“ in „einstellungen“. Es wird nicht in die Sicherung geschrieben und beim Einspielen einer Sicherung
   * nicht überschrieben: Ein Tablet bleibt ein Tablet, auch wenn die Daten vom Handy stammen. */
  var GERAET_DOK = 'geraet';

  Daten.prototype.geraetEinstellungen = function () {
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      var n = MM.Logbuch.geraetKnoepfeGueltig(dok && dok.knoepfe);
      return { knoepfe: n === null ? MM.Logbuch.SCHNELL_GERAET_STANDARD : n, knoepfeGesetzt: n !== null };
    });
  };

  /* Wartezeit der Motorstopp-Frage in Minuten auf diesem Gerät: { wartezeit, gesetzt } (Vorgabe MM.Motoren.WARTEZEIT_STANDARD). */
  Daten.prototype.geraetWartezeit = function () {
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      var wz = MM.Motoren.wartezeitGueltig(dok && dok.motorFrageMinuten);
      return { wartezeit: wz === null ? MM.Motoren.WARTEZEIT_STANDARD : wz, gesetzt: wz !== null };
    });
  };

  /* Wartezeit der Motorstopp-Frage in Minuten (1 bis 1440), nur für dieses Gerät (seit 2.0.22). */
  Daten.prototype.geraetWartezeitSetzen = function (wert) {
    var self = this;
    var n = MM.Motoren.wartezeitGueltig(wert);
    if (n === null) return Promise.resolve({ ok: false, fehler: { wartezeit: 'Bitte eine ganze Zahl von ' + MM.Motoren.WARTEZEIT_MIN + ' bis ' + MM.Motoren.WARTEZEIT_MAX + ' Minuten eintragen.' } });
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, motorFrageMinuten: n }));
    }).then(function () { return { ok: true, wartezeit: n }; });
  };

  /* Höchstzahl der Knöpfe im Cockpit auf diesem Gerät: ganze Zahl von 0 bis 15. */
  Daten.prototype.geraetKnoepfeSetzen = function (wert) {
    var self = this;
    var n = MM.Logbuch.geraetKnoepfeGueltig(wert);
    if (n === null) return Promise.resolve({ ok: false, fehler: { geraet: 'Bitte eine Zahl von 0 bis ' + MM.Logbuch.MAX_SCHNELL + ' wählen.' } });
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, knoepfe: n }));
    }).then(function () { return { ok: true, knoepfe: n }; });
  };

  /* Tagesabschluss (wie in V1): tatsächliches Ziel und Notiz, als neue Felder am Tagesabschnitt.
     Der Zählerstand am Ende gehört zu Schritt 6 und ist nicht dabei. */
  Daten.prototype.tagesabschlussSpeichern = function (abschnittId, roh) {
    var self = this;
    roh = roh || {};
    return this.abschnittLaden(abschnittId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = pruefeWerte([{ key: 'zielTatsaechlich', typ: 'text' }, { key: 'abschlussNotiz', typ: 'text' }], roh, jahrVon(self), { ohneBezeichnung: true });
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, x.abschnitt.aktuell.werte, { zielTatsaechlich: p.werte.zielTatsaechlich || null, abschlussNotiz: p.werte.abschlussNotiz || null });
      return self.mitVerlaufAendern('tagesabschnitt', abschnittId, { aktuell: x.abschnitt.aktuell }, neu, ABSCHNITT_FELDER);
    });
  };

  /* ---------- Wechsel des Verantwortlichen als Ereignis ---------- */
  /* Der Wechsel selbst bleibt in der Tabelle „verantwortung“. Korrekturen stehen im Verlauf und gelten ab sofort überall. */
  Daten.prototype.wechselLaden = function (verantwortungId) {
    var self = this;
    return this.speicher.holen('verantwortung', verantwortungId).then(function (rec) {
      if (!rec) return null;
      return Promise.all([self.aktivitaetLaden(rec.aktivitaetId), self.speicher.wo('verlaeufe', 'objektId', verantwortungId)]).then(function (r) {
        var a = r[0];
        if (!a) return null;
        var wz = MM.Logbuch.wechselEreignisse(a.verantwortung).filter(function (x) { return x.verantwortungId === verantwortungId; })[0];
        if (!wz) return null;
        var eintraege = r[1].filter(function (e) { return e.objektTyp === 'verantwortung'; }).sort(nachNr);
        var basis = { id: 'basis', objektTyp: 'verantwortung', objektId: verantwortungId, nr: 0, quelle: 'hand', korrekturZu: null, erstelltAm: rec.erstelltAm,
          werte: { abDatum: rec.ab.slice(0, 10), abZeit: rec.ab.slice(11, 16), notiz: null, ausgeblendet: 'nein' } };
        return { wechsel: wz, aktivitaet: a, eintraege: eintraege, verlauf: verlaufAus([basis].concat(eintraege), WECHSEL_FELDER) };
      });
    });
  };

  Daten.prototype.wechselAendern = function (verantwortungId, roh) {
    var self = this;
    roh = roh || {};
    var p = pruefeWerte([{ key: 'abDatum', typ: 'datum' }, { key: 'abZeit', typ: 'zeit' }, { key: 'notiz', typ: 'text' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var f = p.fehler, w = p.werte;
    if (!w.abDatum && !f.abDatum) f.abDatum = 'Bitte das Datum des Wechsels angeben.';
    if (!w.abZeit && !f.abZeit) f.abZeit = 'Bitte die Uhrzeit des Wechsels angeben.';
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return this.wechselLaden(verantwortungId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Wechsel wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var ab = w.abDatum + 'T' + w.abZeit;
      var liste = x.aktivitaet.verantwortung;
      var i = liste.map(function (v) { return v.id; }).indexOf(verantwortungId);
      var davor = liste[i - 1], danach = liste[i + 1];
      if (davor && ab <= davor.ab) return { ok: false, fehler: { abDatum: 'Der Wechsel muss nach dem vorherigen Wechsel liegen (' + davor.ab.replace('T', ', ') + ' Uhr).' } };
      if (danach && ab >= danach.ab) return { ok: false, fehler: { abDatum: 'Der Wechsel muss vor dem nächsten Wechsel liegen (' + danach.ab.replace('T', ', ') + ' Uhr).' } };
      var jetztStand = x.verlauf[0].eintrag.werte;
      if (!unterschiedeFelder(WECHSEL_FELDER, jetztStand, w).length) return { ok: true, id: verantwortungId, geaendert: false };
      var letzte = x.eintraege[x.eintraege.length - 1];
      var e = neuerVerlaufEintrag('verantwortung', verantwortungId, letzte ? letzte.nr + 1 : 1, w, letzte ? letzte.id : null, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: verantwortungId, geaendert: true }; });
    });
  };

  /* ---------- Sicherung ---------- */
  var DATEI_TABELLEN = ['dateien', 'nachweisdateien', 'ereignisdateien'];
  var ZAEHL_TABELLEN = [['fahrzeuge', 'Fahrzeuge'], ['komponenten', 'Komponenten'], ['fristen', 'Fristen'], ['zaehler', 'Zähler'], ['personen', 'Personen'],
    ['tiere', 'Tiere'], ['nachweise', 'Nachweise'], ['aktivitaeten', 'Aktivitäten'], ['dokumente', 'Dokumente'],
    ['orte', 'Orte'], ['standorte', 'Standorte'], ['gebiete', 'Gebiete'], ['regeln', 'Regeln'],
    ['tagesabschnitte', 'Tagesabschnitte'], ['ereignisse', 'Ereignisse'], ['vorgaenge', 'Vorgänge'], ['adressen', 'Adressen'], ['kosten', 'Kostenposten']];

  function lokalesDatum(iso) {
    var d = new Date(iso);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
  }

  Daten.prototype.einstellungLesen = function (id) { return this.speicher.holen('einstellungen', id); };
  Daten.prototype.einstellungSchreiben = function (obj) { return this.speicher.speichern('einstellungen', obj); };

  /* Wann wurde zuletzt gesichert, und wie oft soll erinnert werden? (0 = nie erinnern) */
  Daten.prototype.sicherungInfo = function () {
    return Promise.all([this.einstellungLesen('sicherung'), this.speicher.alle('fahrzeuge'), this.speicher.alle('personen'), this.speicher.alle('tiere')]).then(function (r) {
      var e = r[0] || {};
      return { letzte: e.letzteSicherung || null, erinnerungTage: e.erinnerungTage === undefined ? 30 : e.erinnerungTage, hatDaten: (r[1].length + r[2].length + r[3].length) > 0 };
    });
  };

  Daten.prototype.sicherungEinstellen = function (aenderung) {
    var self = this;
    return this.einstellungLesen('sicherung').then(function (alt) {
      return self.einstellungSchreiben(Object.assign({ id: 'sicherung', letzteSicherung: null, erinnerungTage: 30 }, alt || {}, aenderung));
    });
  };

  /* Soll die App an die Sicherung erinnern? Nur, wenn es Daten gibt und die Erinnerung nicht aus ist. */
  Daten.prototype.sicherungErinnerung = function () {
    var self = this;
    return this.sicherungInfo().then(function (i) {
      if (!i.hatDaten || !i.erinnerungTage) return { faellig: false };
      if (!i.letzte) return { faellig: true, grund: 'nie' };
      var tage = MM.Fristen.tageZwischen(lokalesDatum(i.letzte), self.heute());
      return tage >= i.erinnerungTage ? { faellig: true, grund: 'alt', tage: tage } : { faellig: false, tage: tage };
    });
  };

  /* Zahlen der Daten auf diesem Gerät, in derselben Form wie in einer Sicherung. */
  Daten.prototype.sicherungZahlen = function () {
    return this.speicher.alleTabellen().then(function (t) {
      var z = {};
      ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
      var dl = []; DATEI_TABELLEN.forEach(function (n) { dl = dl.concat(t[n] || []); });
      z.dateien = dl.length;
      z.dateiBytes = dl.reduce(function (s, d) { return s + (d.groesse || 0); }, 0);
      return z;
    });
  };

  /* Erzeugt die Sicherung. Gibt Bytes, Dateinamen und Zahlen zurück. */
  Daten.prototype.sicherungErzeugen = function (optionen) {
    var self = this;
    optionen = optionen || {};
    var mitDateien = !!optionen.mitDateien;
    return this.speicher.alleTabellen().then(function (alle) {
      var tabellen = {}, dateien = [], leer = 0;
      var kette = Promise.resolve();
      MM.Speicher.TABELLEN.forEach(function (name) {
        var liste = alle[name] || [];
        if (DATEI_TABELLEN.indexOf(name) >= 0) {
          if (!mitDateien) return;
          tabellen[name] = [];
          liste.forEach(function (rec) {
            kette = kette.then(function () {
              var kopie = Object.assign({}, rec);
              if (rec.inhalt && typeof rec.inhalt.arrayBuffer === 'function') {
                return rec.inhalt.arrayBuffer().then(function (buf) { kopie.inhalt = { $datei: dateien.length }; dateien.push(new Uint8Array(buf)); tabellen[name].push(kopie); });
              }
              leer++; kopie.inhalt = null; tabellen[name].push(kopie);
            });
          });
          return;
        }
        /* Die Einstellungen dieses Geräts (2.0.20) gehören nicht in die Sicherung. */
        tabellen[name] = name === 'einstellungen' ? liste.filter(function (e) { return e.id !== GERAET_DOK; }) : liste;
      });
      return kette.then(function () {
        var zaehlung = {}; Object.keys(tabellen).forEach(function (n) { zaehlung[n] = tabellen[n].length; });
        var kopf = { format: MM.Sicherung.FORMAT, app: MM.VERSION, dbVersion: MM.Speicher.DB_VERSION, erstelltAm: self.jetzt(), mitDateien: mitDateien, tabellen: tabellen, zaehlung: zaehlung };
        return MM.Sicherung.bauen(kopf, dateien, optionen.schluessel || '').then(function (bytes) {
          var z = {}; ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (tabellen[x[0]] || []).length; });
          var d = new Date(kopf.erstelltAm);
          function p(n) { return (n < 10 ? '0' : '') + n; }
          var name = 'MobiMory-Sicherung_' + d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '_' + p(d.getHours()) + '-' + p(d.getMinutes()) + '.mmsicherung';
          return { bytes: bytes, name: name, groesse: bytes.length, zahlen: z, dateien: dateien.length, ohneInhalt: leer, mitDateien: mitDateien, verschluesselt: !!optionen.schluessel, erstelltAm: kopf.erstelltAm };
        });
      });
    });
  };

  /* Prüft den Inhalt einer entpackten Sicherung. Wirft Fehler mit code und verständlichem Text. */
  function sicherungPruefen(gelesen) {
    function f(code, text) { var e = new Error(text); e.code = code; return e; }
    var k = gelesen.kopf;
    if (!k || typeof k !== 'object' || !k.tabellen || typeof k.tabellen !== 'object') throw f('beschaedigt', 'Die Datei ist beschädigt.');
    if (k.format !== MM.Sicherung.FORMAT) {
      throw f(k.format > MM.Sicherung.FORMAT ? 'neuer' : 'format', k.format > MM.Sicherung.FORMAT ? 'Diese Sicherung stammt aus einer neueren Version von MobiMory. Bitte zuerst die App aktualisieren.' : 'Das ist keine MobiMory-Sicherung.');
    }
    if (typeof k.dbVersion !== 'number' || k.dbVersion > MM.Speicher.DB_VERSION) throw f('neuer', 'Diese Sicherung stammt aus einer neueren Version von MobiMory (' + (k.app || '?') + '). Bitte zuerst die App aktualisieren.');
    var benutzt = {};
    Object.keys(k.tabellen).forEach(function (n) {
      if (MM.Speicher.TABELLEN.indexOf(n) < 0) throw f('beschaedigt', 'Die Sicherung enthält etwas Unbekanntes (' + n + ').');
      var liste = k.tabellen[n];
      if (!Array.isArray(liste)) throw f('beschaedigt', 'Die Datei ist beschädigt.');
      if (k.zaehlung && k.zaehlung[n] !== undefined && k.zaehlung[n] !== liste.length) throw f('beschaedigt', 'Die Datei ist beschädigt: Die Anzahl der Einträge stimmt nicht.');
      liste.forEach(function (o) {
        if (!o || typeof o !== 'object' || typeof o.id !== 'string' || !o.id) throw f('beschaedigt', 'Die Datei ist beschädigt: Ein Eintrag ist unvollständig.');
        if (DATEI_TABELLEN.indexOf(n) >= 0 && o.inhalt !== null && o.inhalt !== undefined) {
          var i = o.inhalt && o.inhalt.$datei;
          if (typeof i !== 'number' || i < 0 || i >= gelesen.dateien.length || benutzt[i]) throw f('beschaedigt', 'Die Datei ist beschädigt: Eine Datei fehlt.');
          benutzt[i] = true;
        }
      });
    });
    return true;
  }

  /* Entpackt und prüft eine Sicherung. Noch nichts wird verändert. */
  Daten.prototype.sicherungLesen = function (bytes, schluessel) {
    return MM.Sicherung.auspacken(bytes, schluessel || '').then(function (g) { sicherungPruefen(g); return g; });
  };

  /* Was steht in der Sicherung, und was ist jetzt auf dem Gerät? */
  Daten.prototype.sicherungVorschau = function (gelesen) {
    return this.sicherungZahlen().then(function (jetzt) {
      var t = gelesen.kopf.tabellen, z = {};
      ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
      var bytes = gelesen.dateien.reduce(function (s, d) { return s + d.length; }, 0);
      return { erstelltAm: gelesen.kopf.erstelltAm, app: gelesen.kopf.app, mitDateien: !!gelesen.kopf.mitDateien, dateien: gelesen.dateien.length, dateiBytes: bytes, zahlen: z, jetzt: jetzt };
    });
  };

  /*
   * Ersetzt ALLE Daten auf dem Gerät durch die der Sicherung, in einem Schritt.
   * Schlägt etwas fehl, bleibt der bisherige Stand unverändert.
   */
  Daten.prototype.sicherungEinspielen = function (gelesen) {
    var self = this;
    try { sicherungPruefen(gelesen); } catch (e) { return Promise.reject(e); }
    var t = gelesen.kopf.tabellen, karte = {};
    MM.Speicher.TABELLEN.forEach(function (n) {
      var liste = t[n] || [];
      karte[n] = liste.map(function (o) {
        if (DATEI_TABELLEN.indexOf(n) >= 0) {
          var kopie = Object.assign({}, o);
          kopie.inhalt = (o.inhalt && typeof o.inhalt.$datei === 'number') ? new Blob([gelesen.dateien[o.inhalt.$datei]], { type: o.mime || '' }) : null;
          return kopie;
        }
        return o;
      });
    });
    var einst = (karte.einstellungen || []).filter(function (e) { return e.id === 'sicherung'; })[0] || {};
    karte.einstellungen = (karte.einstellungen || []).filter(function (e) { return e.id !== 'sicherung'; })
      .concat([{ id: 'sicherung', letzteSicherung: gelesen.kopf.erstelltAm, erinnerungTage: einst.erinnerungTage === undefined ? 30 : einst.erinnerungTage }]);
    /* Die Einstellungen dieses Geräts bleiben, wie sie sind (nicht die des Geräts, von dem die Sicherung stammt). */
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (geraet) {
      karte.einstellungen = karte.einstellungen.filter(function (e) { return e.id !== GERAET_DOK; }).concat(geraet ? [geraet] : []);
      return self.speicher.ersetzenAlles(karte);
    }).then(function () { return self.starten(); });
  };

  /* Nur für Tests auf dem eigenen Gerät. */
  Daten.prototype.allesLoeschen = function () {
    var self = this;
    return this.speicher.allesLoeschen().then(function () { return self.starten(); });
  };

  MM.Daten = { Daten: Daten };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
