/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.27';
  MM.STUFE = 'Kosten: eine Kosten-Liste, Beträge an der Werkstatt, Wertverlust, Auswertung und Vergleich';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
