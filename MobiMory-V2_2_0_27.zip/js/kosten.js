/*
 * Kosten, Schritt 8: Beschreibung und Rechnung. Hier steht kein Speichern.
 *
 * Aus den V2-Festlegungen (03./04.11.2026):
 *  - Eine einzige Kosten-Liste für alle Fahrzeuge, verknüpft mit Fahrzeug, Komponente, Aktivität und Vorgang.
 *    Ein Betrag hat genau eine Quelle: Die Beträge einer Arbeit in der Werkstatt stehen hier und nirgends sonst.
 *  - Drei Gruppen, die der Nutzer einträgt: Fixkosten, variable Kosten, Instandhaltung. Dazu kommt als vierte
 *    Gruppe der Wertverlust, den die App rechnet.
 *  - Fixkosten sind immer gleich, egal ob 0 oder 10.000 km im Jahr: Liegeplatz, Stellplatz oder Garage am Heimatort,
 *    Versicherung, Steuer, Prüfungen (HU, Gasprüfung, Feuerlöscher, Rettungsmittel).
 *  - Variable Kosten entstehen erst bei der Nutzung: Parkplätze, Garagen und Liegeplätze auf Reisen, Treibstoff.
 *  - Instandhaltung (Wartung und Reparatur) ist eine eigene Gruppe und wird im Vergleich pro Jahr gerechnet.
 *  - Wertverlust: Der Nutzer trägt den Fahrzeugwert und einen Prozentsatz pro Jahr ein, oder er lässt ihn weg.
 *    Ohne Angabe rechnet die App ohne Wertveränderung. Einmal im Jahr fragt sie, ob der Wert noch stimmt.
 *  - Grundsatz Lernen: Bei jedem Wert steht, ob er eingegeben, geschätzt oder gerechnet ist.
 *  - Vergleichswert: Was das eigene Fahrzeug pro Monat, Tag, Kilometer und Jahr kostet, gegenüber einem gemieteten
 *    oder gecharterten Fahrzeug der gleichen Klasse über den genutzten Zeitraum.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var GRUPPEN = [
    { wert: 'fix', label: 'Fixkosten', hilfe: 'Immer gleich, egal wie viel du fährst: Liegeplatz, Stellplatz oder Garage am Heimatort, Versicherung, Steuer und Prüfungen wie HU, Gasprüfung oder Feuerlöscher.' },
    { wert: 'variabel', label: 'Variable Kosten', hilfe: 'Entstehen erst bei der Nutzung: Treibstoff, Parkplätze, Häfen, Garagen und Liegeplätze auf Reisen, Maut und Gebühren.' },
    { wert: 'instandhaltung', label: 'Instandhaltung', hilfe: 'Wartung und Reparatur: Teile, Arbeit, Rechnungen von Werkstätten. Am Vorgang in der Werkstatt trägst du die Beträge ein.' }
  ];
  var WERTVERLUST = { wert: 'wertverlust', label: 'Wertverlust' };

  var KOSTENARTEN = [
    { wert: 'stellplatz', label: 'Liegeplatz, Stellplatz oder Garage (Heimat)', gruppe: 'fix' },
    { wert: 'versicherung', label: 'Versicherung', gruppe: 'fix' },
    { wert: 'steuer', label: 'Steuer und Abgaben', gruppe: 'fix' },
    { wert: 'pruefung', label: 'Prüfung (HU, Gas, Feuerlöscher, Rettungsmittel)', gruppe: 'fix' },
    { wert: 'fixsonst', label: 'Sonstige Fixkosten', gruppe: 'fix' },
    { wert: 'treibstoff', label: 'Treibstoff und Energie', gruppe: 'variabel' },
    { wert: 'unterwegs', label: 'Liegeplatz, Hafen, Parkplatz oder Garage unterwegs', gruppe: 'variabel' },
    { wert: 'gebuehren', label: 'Maut und Gebühren', gruppe: 'variabel' },
    { wert: 'varsonst', label: 'Sonstige Kosten der Nutzung', gruppe: 'variabel' },
    { wert: 'teile', label: 'Teile und Material', gruppe: 'instandhaltung' },
    { wert: 'arbeit', label: 'Arbeit', gruppe: 'instandhaltung' },
    { wert: 'fremd', label: 'Fremdwerkstatt (Rechnung)', gruppe: 'instandhaltung' },
    { wert: 'instsonst', label: 'Sonstiges zur Instandhaltung', gruppe: 'instandhaltung' }
  ];

  /* monate = in wie vielen Monaten der Betrag einmal fällig wird; 0 = einmalig */
  var RHYTHMEN = [
    { wert: 'einmalig', label: 'Einmalig', monate: 0 },
    { wert: 'monatlich', label: 'Jeden Monat', monate: 1 },
    { wert: 'vierteljaehrlich', label: 'Alle 3 Monate', monate: 3 },
    { wert: 'halbjaehrlich', label: 'Alle 6 Monate', monate: 6 },
    { wert: 'jaehrlich', label: 'Jedes Jahr', monate: 12 },
    { wert: 'zweijaehrlich', label: 'Alle 2 Jahre', monate: 24 }
  ];

  /* Was der Nutzer einträgt. „gerechnet“ und „gemischt“ entstehen nur in der Auswertung. */
  var GRUNDLAGEN = [
    { wert: 'eingegeben', label: 'Tatsächlicher Betrag (eingegeben)' },
    { wert: 'geschaetzt', label: 'Geschätzt' }
  ];
  var GRUNDLAGE_TEXT = { eingegeben: 'eingegeben', geschaetzt: 'geschätzt', gerechnet: 'gerechnet', gemischt: 'gemischt' };

  function finde(liste, wert) {
    for (var i = 0; i < liste.length; i++) { if (liste[i].wert === wert) return liste[i]; }
    return null;
  }
  function labelVon(liste, wert) { var x = finde(liste, wert); return x ? x.label : null; }
  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }
  function runde(n) { return Math.round(n * 100) / 100; }

  function kostenartenFuer(gruppe) { return KOSTENARTEN.filter(function (a) { return a.gruppe === gruppe; }); }
  function monateVon(rhythmus) { var r = finde(RHYTHMEN, rhythmus); return r ? r.monate : 0; }

  /* Felder, die der Nutzer eingibt. Die Bezeichnung kommt als Name dazu, Verweise (Komponente, Aktivität) stellt die Ansicht. */
  function felder(gruppe) {
    var f = [
      { key: 'kostenart', label: 'Art der Kosten', typ: 'auswahl', optionen: kostenartenFuer(gruppe).map(kopie), leerText: '– keine Angabe –' },
      { key: 'betrag', label: 'Betrag', typ: 'zahl', einheit: '€', hilfe: 'Der Betrag in Euro. Bei wiederkehrenden Kosten der Betrag je Zahlung.' }
    ];
    if (gruppe === 'fix') f.push({ key: 'rhythmus', label: 'Wie oft wird er fällig?', typ: 'auswahl', optionen: RHYTHMEN.map(kopie) });
    f.push({ key: 'datum', label: gruppe === 'fix' ? 'Datum' : 'Datum der Zahlung', typ: 'datum',
      hilfe: gruppe === 'fix' ? 'Bei einer Einmalzahlung der Tag der Zahlung, bei wiederkehrenden Kosten der Beginn.' : 'Auch ein Datum in der Zukunft ist möglich, zum Beispiel für geplante Kosten.' });
    if (gruppe === 'fix') f.push({ key: 'bis', label: 'Bis (freiwillig)', typ: 'datum', hilfe: 'Nur bei wiederkehrenden Kosten. Ohne Angabe läuft der Betrag weiter.' });
    f.push({ key: 'grundlage', label: 'Woher stammt der Betrag?', typ: 'auswahl', optionen: GRUNDLAGEN.map(kopie), darstellung: 'wahl' });
    f.push({ key: 'notiz', label: 'Notiz', typ: 'text' });
    return f;
  }

  /* Alle gespeicherten Felder eines Postens, für den Verlauf und den Vergleich. */
  function felderAlle() {
    return [
      { key: 'gruppe', label: 'Gruppe', typ: 'auswahl', optionen: GRUPPEN.map(kopie) },
      { key: 'kostenart', label: 'Art der Kosten', typ: 'auswahl', optionen: KOSTENARTEN.map(kopie) },
      { key: 'betrag', label: 'Betrag', typ: 'zahl', einheit: '€' },
      { key: 'rhythmus', label: 'Wie oft', typ: 'auswahl', optionen: RHYTHMEN.map(kopie) },
      { key: 'datum', label: 'Datum', typ: 'datum' },
      { key: 'bis', label: 'Bis', typ: 'datum' },
      { key: 'grundlage', label: 'Grundlage', typ: 'auswahl', optionen: GRUNDLAGEN.map(kopie) },
      { key: 'komponenteId', label: 'Komponente', typ: 'auswahl', optionen: [] },
      { key: 'aktivitaetId', label: 'Aktivität', typ: 'auswahl', optionen: [] },
      { key: 'vorgangId', label: 'Vorgang in der Werkstatt', typ: 'auswahl', optionen: [] },
      { key: 'notiz', label: 'Notiz', typ: 'text' },
      { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: [{ wert: 'ja', label: 'Ja' }, { wert: 'nein', label: 'Nein' }] }
    ].map(kopie);
  }

  /* Kostenstammdaten eines Fahrzeugs: Wert, Wertverlust und der Vergleichswert. Alles freiwillig. */
  function stammFelder() {
    return [
      { key: 'fahrzeugwert', label: 'Wert des Fahrzeugs', typ: 'zahl', einheit: '€', hilfe: 'Was das Fahrzeug heute wert ist, ungefähr genügt.' },
      { key: 'wertDatum', label: 'Stand des Werts', typ: 'datum', hilfe: 'Ohne Angabe gilt heute. Einmal im Jahr fragt die App, ob der Wert noch stimmt.' },
      { key: 'wertverlustProzent', label: 'Wertverlust pro Jahr', typ: 'zahl', einheit: '%', min: 0, max: 100,
        hilfe: 'Prozent vom Wert pro Jahr. Bei Wohnmobilen, Booten und Oldtimern ist er oft sehr klein oder null. Ohne Angabe rechnet die App ohne Wertveränderung.' },
      { key: 'vergleichBezeichnung', label: 'Womit wird verglichen?', typ: 'text', hilfe: 'Zum Beispiel „Wohnmobil für 4 Personen bei einer Mietstation“ oder „Motoryacht im Charter“' },
      { key: 'vergleichPreisTag', label: 'Was kostet es pro Tag, es zu mieten oder zu chartern?', typ: 'zahl', einheit: '€ pro Tag', hilfe: 'Ein Fahrzeug der gleichen Klasse. Damit vergleicht die App deine Kosten.' },
      { key: 'vergleichGrundlage', label: 'Woher stammt der Preis?', typ: 'auswahl', optionen: GRUNDLAGEN.map(kopie), darstellung: 'wahl' }
    ].map(kopie);
  }

  /* ---------- Rechnung ---------- */
  function monatIndex(iso) {
    var m = /^(\d{4})-(\d{2})/.exec(iso || '');
    return m ? (+m[1]) * 12 + (+m[2] - 1) : NaN;
  }
  function tagNummer(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
    return m ? Math.round(Date.UTC(+m[1], +m[2] - 1, +m[3]) / 86400000) : NaN;
  }
  function tageZwischen(von, bis) { return tagNummer(bis) - tagNummer(von); }

  /*
   * Wie viel von einem Posten fällt in das Jahr? Rechnung nach Monaten, nicht nach Zahlungstag:
   *  - einmalig: der ganze Betrag im Jahr des Datums
   *  - wiederkehrend: Betrag geteilt durch die Monate des Rhythmus, für jeden ganzen Monat, in dem der Posten gilt
   *    (vom Monat des Datums bis zum Monat von „bis“, ohne „bis“ ohne Ende)
   * bisher = bis heute (Nachschau), noch = danach (Vorschau). Gibt { summe, bisher, noch, monate }.
   */
  function imJahr(w, jahr, heute) {
    var leer = { summe: 0, bisher: 0, noch: 0, monate: 0 };
    var b = Number(w && w.betrag);
    if (!w || !isFinite(b) || b <= 0 || !w.datum) return leer;
    var r = monateVon(w.rhythmus);
    if (!r) {
      if (+w.datum.slice(0, 4) !== jahr) return leer;
      var schon = w.datum <= heute ? b : 0;
      return { summe: runde(b), bisher: runde(schon), noch: runde(b - schon), monate: 0 };
    }
    var start = monatIndex(w.datum), ende = w.bis ? monatIndex(w.bis) : Infinity, jetzt = monatIndex(heute);
    var aktiv = 0, vorbei = 0;
    for (var m = 0; m < 12; m++) {
      var mi = jahr * 12 + m;
      if (mi >= start && mi <= ende) { aktiv++; if (mi <= jetzt) vorbei++; }
    }
    var anteil = b / r;
    var summe = runde(anteil * aktiv), bisher = runde(anteil * vorbei);
    return { summe: summe, bisher: bisher, noch: runde(summe - bisher), monate: aktiv };
  }

  /* Summe der einmaligen Posten einer Liste von Werten. Wiederkehrende zählt sie nur (sie haben keine einfache Summe). */
  function summeEinmalig(liste) {
    var s = 0, wk = 0;
    (liste || []).forEach(function (w) { if (!w.rhythmus || w.rhythmus === 'einmalig') s += Number(w.betrag) || 0; else wk++; });
    return { summe: runde(s), wiederkehrend: wk };
  }

  /* Aus den Grundlagen der Posten: 'eingegeben', 'geschaetzt', 'gemischt' oder null (kein Posten). */
  function grundlageVon(liste) {
    var e = false, g = false;
    liste.forEach(function (x) { if (x === 'geschaetzt') g = true; else e = true; });
    if (e && g) return 'gemischt';
    if (g) return 'geschaetzt';
    return e ? 'eingegeben' : null;
  }

  /* Wertverlust im Jahr aus den Kostenstammdaten. Ohne Wert oder Prozentsatz: keine Wertveränderung. */
  function wertverlust(stamm, jahr, heute) {
    var leer = { summe: 0, bisher: 0, noch: 0, grundlage: null, angegeben: false };
    if (!stamm) return leer;
    var wert = Number(stamm.fahrzeugwert), p = Number(stamm.wertverlustProzent);
    if (!isFinite(wert) || wert <= 0 || stamm.wertverlustProzent === null || stamm.wertverlustProzent === undefined || !isFinite(p) || p <= 0) return leer;
    if (stamm.wertDatum && +stamm.wertDatum.slice(0, 4) > jahr) return leer;
    var summe = runde(wert * p / 100);
    var hj = +heute.slice(0, 4), anteil = jahr < hj ? 1 : (jahr > hj ? 0 : (+heute.slice(5, 7)) / 12);
    var bisher = runde(summe * anteil);
    return { summe: summe, bisher: bisher, noch: runde(summe - bisher), grundlage: 'gerechnet', angegeben: true };
  }

  /* Soll die App fragen, ob der Fahrzeugwert noch stimmt? Wert eingetragen und älter als ein Jahr. */
  function wertFrage(stamm, heute) {
    if (!stamm || !(Number(stamm.fahrzeugwert) > 0) || !stamm.wertDatum) return false;
    return tageZwischen(stamm.wertDatum, heute) > 365;
  }

  /*
   * Wie viele Tage im Jahr wurde das Fahrzeug genutzt? Gezählt werden die Tage, an denen mindestens eine
   * Aktivität läuft (jeder Tag nur einmal). genutzt = bis heute, geplant = nach heute.
   * aktivitaeten: [{ vonDatum, bisDatum }], schon ohne stornierte.
   */
  function nutzungstage(aktivitaeten, jahr, heute) {
    var anfang = tagNummer(jahr + '-01-01'), ende = tagNummer(jahr + '-12-31'), hn = tagNummer(heute);
    var tage = {};
    (aktivitaeten || []).forEach(function (a) {
      if (!a || !a.vonDatum) return;
      var von = tagNummer(a.vonDatum), bis = tagNummer(a.bisDatum || a.vonDatum);
      if (isNaN(von) || isNaN(bis)) return;
      for (var t = Math.max(von, anfang); t <= Math.min(bis, ende); t++) tage[t] = true;
    });
    var genutzt = 0, geplant = 0;
    Object.keys(tage).forEach(function (k) { if (+k <= hn) genutzt++; else geplant++; });
    return { genutzt: genutzt, geplant: geplant };
  }

  /*
   * Kilometer im Jahr aus den Ständen des Kilometer-Zählers: Stand am Ende (letzter Stand bis zum Jahresende oder heute)
   * minus Stand zum Beginn (letzter Stand vor dem 1. Januar). Gibt es keinen Stand davor, zählt der erste Stand im Jahr
   * (ohneAnfang = true). Gibt null, wenn sich nichts rechnen lässt.
   */
  function kilometerImJahr(staende, jahr, heute) {
    var jahresanfang = jahr + '-01-01', jahresende = jahr + '-12-31';
    var bisDatum = heute < jahresende ? heute : jahresende;
    var liste = (staende || []).filter(function (s) { return s && s.datum && isFinite(Number(s.wert)); })
      .sort(function (a, b) { return a.datum !== b.datum ? (a.datum < b.datum ? -1 : 1) : Number(a.wert) - Number(b.wert); });
    var davor = liste.filter(function (s) { return s.datum < jahresanfang; });
    var imJ = liste.filter(function (s) { return s.datum >= jahresanfang && s.datum <= bisDatum; });
    if (!imJ.length) return null;
    var ende = imJ[imJ.length - 1];
    var start = davor.length ? davor[davor.length - 1] : imJ[0];
    var km = Number(ende.wert) - Number(start.wert);
    if (!(km > 0)) return null;
    return { km: km, ab: start.datum, bis: ende.datum, ohneAnfang: !davor.length };
  }

  /*
   * Die ganze Auswertung eines Fahrzeugs für ein Jahr.
   *  p.eintraege   [{ werte }]  die sichtbaren Posten (nicht ausgeblendet)
   *  p.stamm       Werte der Kostenstammdaten oder null
   *  p.aktivitaeten [{ vonDatum, bisDatum }]  nicht stornierte Aktivitäten des Fahrzeugs
   *  p.staende     [{ datum, wert }]  Stände des Kilometer-Zählers
   * Pro Monat und pro Jahr rechnet die App mit der Jahressumme. Pro Tag, pro Kilometer und der Vergleich rechnen
   * mit dem, was bis heute angefallen ist, damit Kosten und genutzte Zeit zueinander passen.
   */
  function auswertung(p) {
    var jahr = p.jahr, heute = p.heute;
    var gruppen = {};
    GRUPPEN.forEach(function (g) { gruppen[g.wert] = { summe: 0, bisher: 0, noch: 0, anzahl: 0, grundlage: null }; });
    var gl = {};
    (p.eintraege || []).forEach(function (e) {
      var w = e.werte, g = gruppen[w.gruppe];
      if (!g) return;
      var x = imJahr(w, jahr, heute);
      if (x.summe <= 0) return;
      g.summe += x.summe; g.bisher += x.bisher; g.noch += x.noch; g.anzahl++;
      (gl[w.gruppe] = gl[w.gruppe] || []).push(w.grundlage);
    });
    GRUPPEN.forEach(function (gd) {
      var g = gruppen[gd.wert];
      g.summe = runde(g.summe); g.bisher = runde(g.bisher); g.noch = runde(g.noch);
      g.grundlage = grundlageVon(gl[gd.wert] || []);
    });
    var wv = wertverlust(p.stamm, jahr, heute);
    var gesamt = {
      summe: runde(gruppen.fix.summe + gruppen.variabel.summe + gruppen.instandhaltung.summe + wv.summe),
      bisher: runde(gruppen.fix.bisher + gruppen.variabel.bisher + gruppen.instandhaltung.bisher + wv.bisher),
      noch: 0
    };
    gesamt.noch = runde(gesamt.summe - gesamt.bisher);
    /* Die Gesamtsumme ist immer gerechnet: Sie entsteht aus eingegebenen und geschätzten Beträgen und dem Wertverlust. */
    var gesamtGrundlage = gesamt.summe > 0 ? 'gerechnet' : null;

    var nutzung = nutzungstage(p.aktivitaeten, jahr, heute);
    var km = kilometerImJahr(p.staende, jahr, heute);
    var preis = p.stamm && Number(p.stamm.vergleichPreisTag) > 0 ? Number(p.stamm.vergleichPreisTag) : null;
    var vergleich = null;
    if (preis) {
      var miete = runde(preis * nutzung.genutzt);
      vergleich = { preisTag: preis, bezeichnung: p.stamm.vergleichBezeichnung || null, grundlage: p.stamm.vergleichGrundlage === 'geschaetzt' ? 'geschaetzt' : 'eingegeben',
        tage: nutzung.genutzt, eigen: gesamt.bisher, miete: miete, differenz: runde(gesamt.bisher - miete),
        /* Ab wie vielen Nutzungstagen im Jahr ist das eigene Fahrzeug günstiger als Mieten (Jahressumme geteilt durch den Tagespreis) */
        guenstigerAbTage: gesamt.summe > 0 ? Math.ceil(gesamt.summe / preis) : 0 };
    }
    return {
      jahr: jahr, gruppen: gruppen, wertverlust: wv, gesamt: gesamt, gesamtGrundlage: gesamtGrundlage,
      nutzung: nutzung, km: km,
      proJahr: gesamt.summe,
      proMonat: runde(gesamt.summe / 12),
      proTag: nutzung.genutzt > 0 ? runde(gesamt.bisher / nutzung.genutzt) : null,
      proKm: km ? runde(gesamt.bisher / km.km) : null,
      vergleich: vergleich,
      wertFrage: wertFrage(p.stamm, heute)
    };
  }

  MM.Kosten = {
    GRUPPEN: GRUPPEN, WERTVERLUST: WERTVERLUST, KOSTENARTEN: KOSTENARTEN, RHYTHMEN: RHYTHMEN, GRUNDLAGEN: GRUNDLAGEN, GRUNDLAGE_TEXT: GRUNDLAGE_TEXT,
    kostenartenFuer: kostenartenFuer, monateVon: monateVon, labelVon: labelVon,
    felder: felder, felderAlle: felderAlle, stammFelder: stammFelder,
    imJahr: imJahr, summeEinmalig: summeEinmalig, grundlageVon: grundlageVon, wertverlust: wertverlust, wertFrage: wertFrage,
    nutzungstage: nutzungstage, kilometerImJahr: kilometerImJahr, auswertung: auswertung, runde: runde
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
