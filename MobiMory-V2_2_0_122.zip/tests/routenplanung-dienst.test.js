'use strict';
/* 2.0.88 (13f-10): Routenplanung im Konto-Dienst. HERE ist ein Platzhalter. Zählung getrennt von den Online-Checks, Nachkauf, kein Zählen bei Fehlern. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

const APP = 'https://app.example.org';
const PW = 'Sehr-sicheres-Passwort-1';
const TAG = 24 * 60 * 60 * 1000;
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) {
  return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1', HERE_SCHLUESSEL: 'here-schluessel-1',
    RECHERCHE_URL: 'https://recherche.example.org', RECHERCHE_TOKEN: 'geheim-token-1' }, extra || {});
}
function uhr() { const u = { t: Date.UTC(2026, 10, 15, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
const LINIE = 'BFoz5xJ67i1B1B7PzIhaxL7Y';

function here() {
  const r = { aufrufe: [], modus: 'ok' };
  r.fetch = async (url) => {
    r.aufrufe.push(url);
    if (r.modus === 'netz') throw new Error('kein Netz');
    if (r.modus === 'fehler') return new Response(JSON.stringify({ title: 'Unauthorized' }), { status: 401 });
    if (r.modus === 'keine') return new Response(JSON.stringify({ routes: [], notices: [{ code: 'noRouteFound', severity: 'critical' }] }), { status: 200 });
    const mit = r.modus === 'warnung';
    return new Response(JSON.stringify({ routes: [{ id: 'x', sections: [Object.assign({ id: 's', polyline: LINIE, summary: { length: 12345, duration: 1500 } },
      mit ? { notices: [{ title: 'Violated vehicle restriction.', code: 'violatedVehicleRestriction', severity: 'critical', details: [{ type: 'restriction', cause: 'Route violates vehicle restriction' }] }], spans: [{ offset: 0 }, { offset: 2, notices: [0] }] } : {})] }] }), { status: 200 });
  };
  return r;
}
async function roh(env, u, methode, weg, body, token, optionen) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  return d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, Object.assign({ jetzt: u.jetzt }, optionen || {}));
}
async function ruf(env, u, methode, weg, body, token, optionen) { const r = await roh(env, u, methode, weg, body, token, optionen); return { status: r.status, json: await r.json() }; }
async function konto(env, u, email) {
  u.t += 13 * 60 * 1000;
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode, geraet: 'Test #01234567' });
  assert.equal(b.status, 200, JSON.stringify(b.json)); return b.json.token;
}
function stufeSetzen(env, email, stufe) {
  const n = env.DB.roh.prepare('SELECT id FROM nutzer WHERE email = ?').get(email);
  env.DB.roh.prepare('INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) VALUES (?, ?, ?, ?)').run(n.id, stufe, null, 1);
}
const ANFRAGE = { von: { breite: 48.9, laenge: 9.1 }, nach: { breite: 47.5, laenge: 8.2 }, via: [{ breite: 48.1, laenge: 8.7 }], fahrzeug: { hoehe: 3.1, breite: 2.3, laenge: 7.4, gesamtgewicht: 4500, achsen: 2 } };

test('Dienst 13f-10: Dekodierung der HERE-Linie, SQL-Datei im Schema, Gesundheit, Anleitung', async () => {
  const d = await laden();
  assert.equal(d.VERSION, '13h');
  assert.deepEqual(d.polylineDekodieren(LINIE)[0], { breite: 50.10228, laenge: 8.69821 });
  assert.equal(d.polylineDekodieren(LINIE).length, 4);
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13f-10.sql'), 'utf8').split('\n').filter((z) => z.trim());
  assert.equal(sql.length, 3);
  const schema = fs.readFileSync(path.join(__dirname, '..', 'server', 'schema.sql'), 'utf8');
  sql.forEach((z) => assert.ok(schema.includes(z)));
  assert.ok(fs.readFileSync(path.join(__dirname, '..', 'server', 'EINRICHTUNG.md'), 'utf8').includes('Update auf 13f-10'));
  const env = umgebung(), u = uhr();
  const g = (await ruf(env, u, 'GET', '/gesundheit')).json;
  assert.equal(g.version, '13h'); assert.deepEqual(g.routen, { tabellen: true, schluessel: true });
  assert.equal((await ruf(umgebung({ HERE_SCHLUESSEL: undefined }), u, 'GET', '/gesundheit')).json.routen.schluessel, false);
});

test('Route planen: Testwoche zählt, Antwort mit Punkten, Länge, Dauer; der Aufruf an HERE trägt Maße in cm und den Schlüssel', async () => {
  const env = umgebung(), u = uhr(), h = here(), o = { fetch: h.fetch };
  const tok = await konto(env, u, 'a@example.org');
  assert.equal((await ruf(env, u, 'POST', '/route/planen', ANFRAGE, undefined, o)).status, 401);
  const r = await ruf(env, u, 'POST', '/route/planen', ANFRAGE, tok, o);
  assert.equal(r.status, 200, JSON.stringify(r.json));
  assert.equal(r.json.route.punkte.length, 4); assert.equal(r.json.route.laengeKm, 12.35); assert.equal(r.json.route.dauerMin, 25); assert.deepEqual(r.json.route.warnungen, []);
  assert.deepEqual(r.json.kontingent, { genutzt: 1, grenze: 10, stufe: 'test' });
  const url = h.aufrufe[0];
  ['transportMode=truck', 'origin=48.9,9.1', 'destination=47.5,8.2', 'via=48.1,8.7', 'vehicle[height]=310', 'vehicle[width]=230', 'vehicle[length]=740', 'vehicle[grossWeight]=4500', 'vehicle[axleCount]=2', 'apiKey=here-schluessel-1', 'spans=notices'].forEach((s) => assert.ok(url.includes(s), s));
  const s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.grenzen.routen, 10); assert.equal(s.json.nutzung.routen, 1); assert.equal(s.json.nutzung.routenFrei, 9); assert.equal(s.json.nutzung.checks, 0, 'Checks und Routen zählen getrennt');
});

test('Route planen: Warnungen aus den Hinweisen von HERE, mit Stelle', async () => {
  const env = umgebung(), u = uhr(), h = here(); h.modus = 'warnung';
  const tok = await konto(env, u, 'a@example.org');
  const r = await ruf(env, u, 'POST', '/route/planen', ANFRAGE, tok, { fetch: h.fetch });
  assert.equal(r.status, 200); assert.equal(r.json.route.warnungen.length, 1);
  const w = r.json.route.warnungen[0];
  assert.equal(w.code, 'violatedVehicleRestriction'); assert.equal(w.stufe, 'kritisch'); assert.deepEqual(w.ort, { breite: 50.10063, laenge: 8.6915 }); assert.match(w.grund, /restriction/);
});

test('Route planen: Basic darf nicht, Eingaben werden geprüft, ohne Schlüssel gibt es einen klaren Fehler, nichts wird gezählt', async () => {
  const env = umgebung(), u = uhr(), h = here(), o = { fetch: h.fetch };
  const tok = await konto(env, u, 'a@example.org');
  stufeSetzen(env, 'a@example.org', 'basic'); env.DB.roh.prepare('DELETE FROM testwoche').run();
  const b = await ruf(env, u, 'POST', '/route/planen', ANFRAGE, tok, o);
  assert.equal(b.status, 402); assert.match(b.json.error, /ab der Stufe Mittel/); assert.equal(h.aufrufe.length, 0);
  stufeSetzen(env, 'a@example.org', 'mittel');
  assert.equal((await ruf(env, u, 'POST', '/route/planen', Object.assign({}, ANFRAGE, { von: { breite: 99, laenge: 9 } }), tok, o)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/route/planen', Object.assign({}, ANFRAGE, { nach: null }), tok, o)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/route/planen', Object.assign({}, ANFRAGE, { via: [1, 2, 3, 4, 5, 6].map(() => ANFRAGE.von) }), tok, o)).status, 400);
  const ohne = await ruf(umgebung({ HERE_SCHLUESSEL: '' }), u, 'POST', '/route/planen', ANFRAGE, tok, o);
  assert.equal(ohne.status, 401); /* anderes Konto in anderer Umgebung: nur der Weg bis zur Anmeldung zählt */
  const e2 = umgebung({ HERE_SCHLUESSEL: '' }), t2 = await konto(e2, u, 'b@example.org');
  const k = await ruf(e2, u, 'POST', '/route/planen', ANFRAGE, t2, o);
  assert.equal(k.status, 503); assert.match(k.json.error, /noch nicht eingetragen/);
  assert.equal(e2.DB.roh.prepare('SELECT COUNT(*) AS n FROM route_nutzung').get().n, 0);
});

test('Route planen: Fehler und „keine Route“ zählen nicht; bei einem Fehler kommt der nachgekaufte Block zurück', async () => {
  const env = umgebung(), u = uhr(), h = here(), o = { fetch: h.fetch };
  const tok = await konto(env, u, 'a@example.org');
  for (const [modus, status] of [['netz', 502], ['fehler', 502], ['keine', 404]]) {
    h.modus = modus;
    const r = await ruf(env, u, 'POST', '/route/planen', ANFRAGE, tok, o);
    assert.equal(r.status, status, modus); assert.match(r.json.error, /nicht gezählt/);
    u.t += 3 * 60 * 1000;
  }
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM route_nutzung').get().n, 0);
  const s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.nutzung.routen, 0);
});

test('Route planen: Kontingent aufgebraucht, dann Nachkauf (100 Routen für 9,99 €) wird benutzt und zählt nicht zur Stufe', async () => {
  const env = umgebung(), u = uhr(), h = here(), o = { fetch: h.fetch };
  const tok = await konto(env, u, 'a@example.org');
  for (let i = 0; i < 10; i++) { u.t += 2 * 60 * 1000; assert.equal((await ruf(env, u, 'POST', '/route/planen', ANFRAGE, tok, o)).status, 200, 'Route ' + (i + 1)); }
  u.t += 2 * 60 * 1000;
  const voll = await ruf(env, u, 'POST', '/route/planen', ANFRAGE, tok, o);
  assert.equal(voll.status, 402); assert.match(voll.json.error, /10 von 10 geplanten Routen/); assert.match(voll.json.error, /100 zusätzliche Routen/);
  const n = env.DB.roh.prepare('SELECT id FROM nutzer WHERE email = ?').get('a@example.org');
  env.DB.roh.prepare('INSERT INTO route_extra (nutzer_id, anzahl) VALUES (?, ?)').run(n.id, 100);
  const r = await ruf(env, u, 'POST', '/route/planen', ANFRAGE, tok, o);
  assert.equal(r.status, 200); assert.equal(r.json.kontingent.extraFrei, 99);
  const s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.nutzung.routenExtra, 99); assert.equal(s.json.nutzung.routen, 10, 'die Stufe zählt nur ihre eigenen Routen');
  /* ein Jahr später ist das Kontingent wieder frei */
  u.t += 366 * TAG; stufeSetzen(env, 'a@example.org', 'mittel');
  const d2 = await ruf(env, u, 'GET', '/konto/stufe', undefined, await konto(env, u, 'a@example.org'));
  assert.equal(d2.json.grenzen.routen, 100); assert.equal(d2.json.nutzung.routen, 0);
});

test('Stufen: Mittel 100, Voll 1000, Entwickler ohne Grenze; Produkt „route100“ gibt es und kostet 9,99 €', async () => {
  const d = await laden();
  assert.deepEqual([d.STUFEN.basic.routen, d.STUFEN.test.routen, d.STUFEN.mittel.routen, d.STUFEN.voll.routen, d.STUFEN.entwickler.routen], [0, 10, 100, 1000, null]);
  assert.equal(d.PRODUKTE.route100.cent, 999); assert.equal(d.PRODUKTE.route100.anzahl, 100); assert.equal(d.PRODUKTE.route100.art, 'routen');
  assert.throws(() => d.routeAuswerten({ routes: [] }), /keine Route/);
  assert.equal(d.routeAuswerten({ routes: [{ sections: [{ polyline: LINIE, summary: { length: 1000, duration: 60 } }] }] }).laengeKm, 1);
});

test('Nachkauf per Überweisung: route100 schreibt 100 Routen gut, Beleg und Mail nennen Routen; Basic kann es nicht kaufen', async () => {
  const env = umgebung({ UEBERWEISUNG_IBAN: 'DE02120300000000202051', UEBERWEISUNG_INHABER: 'Ralph Hasslacher', FREISCHALT_TOKEN: 'f'.repeat(24) }), u = uhr();
  const tok = await konto(env, u, 'a@example.org');
  const b = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'route100', weg: 'ueberweisung' }, tok);
  assert.equal(b.status, 200, JSON.stringify(b.json));
  const best = env.DB.roh.prepare('SELECT * FROM bestellung').get();
  assert.equal(best.produkt, 'route100'); assert.equal(best.cent, 999);
  const code = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'route100', weg: 'paypal', code: 'NEU10' }, tok);
  assert.equal(code.status, 400);
  env.DB.roh.prepare('DELETE FROM testwoche').run(); stufeSetzen(env, 'a@example.org', 'basic');
  const basic = await ruf(env, u, 'POST', '/bezahlen/starten', { produkt: 'route100', weg: 'ueberweisung' }, tok);
  assert.equal(basic.status, 400); assert.match(basic.json.error, /Zusätzliche Routen/);
});
