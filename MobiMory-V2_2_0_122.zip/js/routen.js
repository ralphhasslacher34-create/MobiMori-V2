/*
 * Routen, Schritt 9: Beschreibung und Rechnung. Hier steht kein Speichern und kein Netz.
 *
 * Aus den V2-Festlegungen (03./04.11.2026):
 *  - MobiMory ist keine Navigations-App. Eine Route wird eingelesen (GPX, KML, GeoJSON). Seit 2.0.88 kann die App für Straßenfahrzeuge auch eine Route planen lassen (Konto-Dienst, HERE), siehe unten.
 *  - Aus Route, Geschwindigkeit und Abfahrtszeit rechnet die App Fahrzeit und Ankunftszeit (ETA) je Punkt.
 *  - Für ausgewählte Punkte der Route holt die App das Wetter zur Ankunftszeit an diesem Punkt
 *    (Quelle Open-Meteo, wie schon in V1). Damit lässt sich entscheiden, ob eine Stunde früher oder später starten besser ist.
 *  - Bei Wasserfahrzeugen kommen Wellen und der Wasserstand mit Hoch- und Niedrigwasser dazu (Open-Meteo Marine).
 *  - Alles, was aus dem Netz kommt, ist eine Prognose und ein Modellwert. Die App sagt das dazu und trifft keine rechtliche
 *    oder nautische Aussage. Die Verantwortung bleibt beim Skipper oder Fahrer.
 *  - Kilometer über GPS sind nie Voraussetzung: Ohne GPS bleibt die Handeingabe. Handeingabe hat Vorrang.
 *
 * Alle Zeiten ohne Zeitzone („JJJJ-MM-TTTHH:MM“) sind Ortszeit des Geräts.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var FORMATE = [
    { wert: 'gpx', label: 'GPX' },
    { wert: 'kml', label: 'KML' },
    { wert: 'geojson', label: 'GeoJSON' }
  ];
  var KN_IN_KMH = 1.852;
  var MAX_PUNKTE = 800;          /* So viele Punkte bleiben höchstens gespeichert (Form bleibt, Länge bleibt exakt). */
  var MAX_MESSPUNKTE = 12;       /* So viele Punkte der Route bekommen höchstens ein Wetter (ohne eigene Regel). */
  var MAX_MESSPUNKTE_REGEL = 24; /* Mit eigener Regel (Abstand nach km, sm oder Zeit): so viele Punkte höchstens. */
  var SM_IN_KM = 1.852;
  var WETTER_ARTEN = [{ wert: 'strecke', label: 'Nach Entfernung' }, { wert: 'zeit', label: 'Nach Fahrzeit' }];
  var MAX_DATEI_ZEICHEN = 20 * 1024 * 1024;

  var EINHEITEN = [
    { wert: 'kn', label: 'Knoten (kn)' },
    { wert: 'kmh', label: 'Kilometer pro Stunde (km/h)' }
  ];

  function runde(n, stellen) { var f = Math.pow(10, stellen); return Math.round(n * f) / f; }
  function zahl(x) { var n = typeof x === 'number' ? x : parseFloat(String(x).replace(',', '.')); return isFinite(n) ? n : null; }
  function gueltig(breite, laenge) { return typeof breite === 'number' && typeof laenge === 'number' && breite >= -90 && breite <= 90 && laenge >= -180 && laenge <= 180; }

  /* ---------- Entfernung ---------- */
  /* Luftlinie zwischen zwei Punkten in Kilometern (Haversine). */
  function entfernungKm(b1, l1, b2, l2) {
    var r = 6371.0088, rad = Math.PI / 180;
    var dB = (b2 - b1) * rad, dL = (l2 - l1) * rad;
    var a = Math.sin(dB / 2) * Math.sin(dB / 2) + Math.cos(b1 * rad) * Math.cos(b2 * rad) * Math.sin(dL / 2) * Math.sin(dL / 2);
    return 2 * r * Math.asin(Math.min(1, Math.sqrt(a)));
  }

  /* ---------- Dateien lesen ---------- */
  function entitaeten(t) {
    return String(t).replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
      .replace(/&#(\d+);/g, function (m, n) { return String.fromCharCode(parseInt(n, 10)); }).replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
  }
  function ohneKommentare(t) { return String(t).replace(/<!--[\s\S]*?-->/g, ''); }
  function attribut(attrs, name) {
    var m = new RegExp('(?:^|\\s)' + name + '\\s*=\\s*("([^"]*)"|\'([^\']*)\')', 'i').exec(attrs);
    return m ? (m[2] !== undefined ? m[2] : m[3]) : null;
  }
  function inneresTag(inhalt, tag) {
    var m = new RegExp('<' + tag + '\\b[^>]*>([\\s\\S]*?)</' + tag + '>', 'i').exec(inhalt || '');
    return m ? entitaeten(m[1]) : null;
  }
  function punkt(breite, laenge, name) {
    var p = { breite: runde(breite, 6), laenge: runde(laenge, 6) };
    if (name) p.name = String(name).slice(0, 80);
    return p;
  }

  /* Alle Elemente „tag“ mit ihren Eigenschaften: [{ attrs, inhalt }]. Selbstschließende Elemente haben keinen Inhalt. */
  function elemente(text, tag) {
    var res = [], re = new RegExp('<' + tag + '\\b([^>]*)>', 'gi'), m;
    while ((m = re.exec(text))) {
      var attrs = m[1], selbst = /\/\s*$/.test(attrs), inhalt = '';
      if (!selbst) {
        var ende = text.toLowerCase().indexOf('</' + tag.toLowerCase() + '>', re.lastIndex);
        if (ende >= 0) inhalt = text.slice(re.lastIndex, ende);
      }
      res.push({ attrs: attrs, inhalt: inhalt, start: m.index });
    }
    return res;
  }

  function gpxLesen(text) {
    var t = ohneKommentare(text), res = { name: null, route: [], spur: [], marken: [] };
    function aus(tag, ziel) {
      elemente(t, tag).forEach(function (e) {
        var b = zahl(attribut(e.attrs, 'lat')), l = zahl(attribut(e.attrs, 'lon'));
        if (gueltig(b, l)) ziel.push(punkt(b, l, inneresTag(e.inhalt, 'name')));
      });
    }
    aus('rtept', res.route); aus('trkpt', res.spur); aus('wpt', res.marken);
    var meta = /<metadata\b[^>]*>([\s\S]*?)<\/metadata>/i.exec(t);
    res.name = (meta ? inneresTag(meta[1], 'name') : null)
      || (function () { var r = elemente(t, 'rte')[0]; return r ? inneresTag(r.inhalt, 'name') : null; })()
      || (function () { var r = elemente(t, 'trk')[0]; return r ? inneresTag(r.inhalt, 'name') : null; })();
    return res;
  }

  function koordinatenListe(s) {
    var res = [];
    String(s).trim().split(/\s+/).forEach(function (tr) {
      var teile = tr.split(',');
      var l = zahl(teile[0]), b = zahl(teile[1]);
      if (gueltig(b, l)) res.push({ breite: b, laenge: l });
    });
    return res;
  }

  function kmlLesen(text) {
    var t = ohneKommentare(text), res = { name: null, route: [], spur: [], marken: [] };
    elemente(t, 'Placemark').forEach(function (pm) {
      var name = inneresTag(pm.inhalt, 'name');
      elemente(pm.inhalt, 'LineString').forEach(function (ls) {
        var c = inneresTag(ls.inhalt, 'coordinates');
        if (c) koordinatenListe(c).forEach(function (k) { res.spur.push(punkt(k.breite, k.laenge)); });
      });
      elemente(pm.inhalt, 'gx:coord').forEach(function (gc) {
        var teile = entitaeten(gc.inhalt).split(' '), l = zahl(teile[0]), b = zahl(teile[1]);
        if (gueltig(b, l)) res.spur.push(punkt(b, l));
      });
      elemente(pm.inhalt, 'Point').forEach(function (pt) {
        var c = inneresTag(pt.inhalt, 'coordinates');
        var k = c ? koordinatenListe(c)[0] : null;
        if (k) res.marken.push(punkt(k.breite, k.laenge, name));
      });
    });
    var erster = t.search(/<Placemark\b/i);
    var kopf = erster >= 0 ? t.slice(0, erster) : t;
    res.name = inneresTag(kopf, 'name');
    return res;
  }

  function geojsonLesen(text) {
    var j = JSON.parse(text), res = { name: null, route: [], spur: [], marken: [] };
    function koord(c) { var l = zahl(c && c[0]), b = zahl(c && c[1]); return gueltig(b, l) ? { breite: b, laenge: l } : null; }
    function geometrie(g, name) {
      if (!g || typeof g !== 'object') return;
      if (g.type === 'Point') { var k = koord(g.coordinates); if (k) res.marken.push(punkt(k.breite, k.laenge, name)); }
      else if (g.type === 'MultiPoint') { (g.coordinates || []).forEach(function (c) { var k2 = koord(c); if (k2) res.marken.push(punkt(k2.breite, k2.laenge, name)); }); }
      else if (g.type === 'LineString') { (g.coordinates || []).forEach(function (c) { var k3 = koord(c); if (k3) res.spur.push(punkt(k3.breite, k3.laenge)); }); }
      else if (g.type === 'MultiLineString') { (g.coordinates || []).forEach(function (zeile) { (zeile || []).forEach(function (c) { var k4 = koord(c); if (k4) res.spur.push(punkt(k4.breite, k4.laenge)); }); }); }
      else if (g.type === 'GeometryCollection') { (g.geometries || []).forEach(function (x) { geometrie(x, name); }); }
    }
    function objekt(o) {
      if (!o || typeof o !== 'object') return;
      if (o.type === 'FeatureCollection') { if (typeof o.name === 'string') res.name = res.name || o.name; (o.features || []).forEach(objekt); }
      else if (o.type === 'Feature') {
        var n = o.properties && typeof o.properties.name === 'string' ? o.properties.name : null;
        if (n && !res.name && o.geometry && /Line/.test(o.geometry.type)) res.name = n;
        geometrie(o.geometry, n);
      } else geometrie(o, null);
    }
    objekt(j);
    return res;
  }

  /* Das Format an Dateiname und Inhalt erkennen: 'gpx', 'kml', 'geojson' oder null. */
  function formatErkennen(text, dateiname) {
    var t = String(text || '').replace(/^\uFEFF/, '').trim();
    if (!t) return null;
    if (t.charAt(0) === '{') return 'geojson';
    if (/<gpx\b/i.test(t)) return 'gpx';
    if (/<kml\b/i.test(t)) return 'kml';
    var n = String(dateiname || '').toLowerCase();
    if (/\.gpx$/.test(n)) return 'gpx';
    if (/\.kml$/.test(n)) return 'kml';
    if (/\.(geojson|json)$/.test(n)) return 'geojson';
    return null;
  }

  /*
   * Eine Routendatei lesen. Ergebnis: { ok, format, name, punkte, anzahlGelesen, hinweise } oder { ok: false, fehler }.
   * Ist in der Datei eine Route (GPX rtept) oder eine Linie (Spur, KML, GeoJSON), bilden ihre Punkte den Weg; benannte
   * Wegpunkte (wpt, Point) bleiben als benannte Punkte erhalten, wenn sie auf oder an dem Weg liegen. Gibt es nur
   * Wegpunkte, bilden sie in der Reihenfolge der Datei die Route.
   */
  function lesen(text, dateiname) {
    var roh = String(text || '').replace(/^\uFEFF/, '');
    if (roh.length > MAX_DATEI_ZEICHEN) return { ok: false, fehler: 'Die Datei ist zu groß (über 20 MB).' };
    var format = formatErkennen(roh, dateiname);
    if (!format) return { ok: false, fehler: 'Dieses Format kenne ich nicht. MobiMory liest Routen als GPX, KML oder GeoJSON.' };
    var g;
    try { g = format === 'gpx' ? gpxLesen(roh) : (format === 'kml' ? kmlLesen(roh) : geojsonLesen(roh)); }
    catch (e) { return { ok: false, fehler: 'Die Datei lässt sich nicht lesen. Ist es wirklich eine ' + labelVon(format) + '-Datei?' }; }
    var hinweise = [], weg, marken = g.marken.slice(), wegart = null;
    if (g.route.length >= 2) { weg = g.route; wegart = 'route'; if (g.spur.length) hinweise.push('Die Datei enthält Route und Spur. Übernommen wurde die Route.'); }
    else if (g.spur.length >= 2) { weg = g.spur; wegart = 'spur'; }
    else if (marken.length >= 2) { weg = marken; marken = []; wegart = 'wegpunkte'; hinweise.push('Die Datei enthält nur Wegpunkte. Sie bilden in der Reihenfolge der Datei die Route.'); }
    else return { ok: false, fehler: 'In der Datei steht keine Route mit mindestens zwei Punkten.' };
    var anzahl = weg.length;
    /* Benannte Wegpunkte, die nahe am Weg liegen, werden zu benannten Punkten des Wegs (Abstand höchstens 500 m). */
    var benannt = weg.map(function (p) { return Object.assign({}, p); });
    marken.forEach(function (m) {
      var bester = -1, abstand = 0.5;
      benannt.forEach(function (p, i) { var d = entfernungKm(m.breite, m.laenge, p.breite, p.laenge); if (d <= abstand) { abstand = d; bester = i; } });
      if (bester >= 0 && m.name && !benannt[bester].name) benannt[bester].name = m.name;
    });
    var ergebnis = punkteAufbereiten(benannt);
    return { ok: true, format: format, wegart: wegart, name: g.name || null, punkte: ergebnis.punkte, laengeKm: ergebnis.laengeKm, anzahlGelesen: anzahl, hinweise: hinweise };
  }
  function labelVon(f) { for (var i = 0; i < FORMATE.length; i++) if (FORMATE[i].wert === f) return FORMATE[i].label; return f; }

  /* ---------- Länge und Vereinfachen ---------- */
  /* Fügt jedem Punkt „km“ (Strecke vom Start) hinzu und gibt die Gesamtlänge. Die Länge stammt aus allen Punkten, auch wenn danach vereinfacht wird. */
  function kumulieren(punkte) {
    var summe = 0;
    return { laengeKm: 0, punkte: punkte.map(function (p, i) {
      if (i > 0) summe += entfernungKm(punkte[i - 1].breite, punkte[i - 1].laenge, p.breite, p.laenge);
      var k = Object.assign({}, p); k.km = runde(summe, 3); return k;
    }) };
  }
  function punkteAufbereiten(punkte) {
    var k = kumulieren(punkte), laenge = k.punkte.length ? k.punkte[k.punkte.length - 1].km : 0;
    return { punkte: vereinfachen(k.punkte, MAX_PUNKTE), laengeKm: runde(laenge, 3) };
  }

  /* Douglas-Peucker: Punkte, die fast auf der Linie liegen, fallen weg. Erster, letzter und benannte Punkte bleiben. */
  function vereinfachen(punkte, maxAnzahl) {
    if (punkte.length <= maxAnzahl) return punkte.slice();
    var mitte = punkte.reduce(function (s, p) { return s + p.breite; }, 0) / punkte.length;
    var kx = 111.320 * Math.cos(mitte * Math.PI / 180), ky = 110.574; /* km je Grad */
    function xy(p) { return [p.laenge * kx, p.breite * ky]; }
    function abstandZurStrecke(p, a, b) {
      var P = xy(p), A = xy(a), B = xy(b), dx = B[0] - A[0], dy = B[1] - A[1], l2 = dx * dx + dy * dy;
      var t = l2 ? Math.max(0, Math.min(1, ((P[0] - A[0]) * dx + (P[1] - A[1]) * dy) / l2)) : 0;
      var ex = A[0] + t * dx - P[0], ey = A[1] + t * dy - P[1];
      return Math.sqrt(ex * ex + ey * ey);
    }
    function mitToleranz(eps) {
      var behalten = punkte.map(function (p, i) { return i === 0 || i === punkte.length - 1 || !!p.name; });
      var stapel = [], i, letzte = 0;
      for (i = 1; i < punkte.length; i++) { if (behalten[i]) { stapel.push([letzte, i]); letzte = i; } }
      while (stapel.length) {
        var s = stapel.pop(), von = s[0], bis = s[1], maxD = 0, idx = -1, j;
        for (j = von + 1; j < bis; j++) { var d = abstandZurStrecke(punkte[j], punkte[von], punkte[bis]); if (d > maxD) { maxD = d; idx = j; } }
        if (idx >= 0 && maxD > eps) { behalten[idx] = true; stapel.push([von, idx], [idx, bis]); }
      }
      return punkte.filter(function (p, i) { return behalten[i]; });
    }
    var eps = 0.002, res = mitToleranz(eps), versuche = 0;
    while (res.length > maxAnzahl && versuche < 40) { eps *= 1.6; res = mitToleranz(eps); versuche++; }
    return res;
  }

  /* Ein Punkt der Route bei „km“ vom Start (zwischen zwei Punkten gerade gerechnet). */
  function punktBeiKm(punkte, km) {
    if (!punkte.length) return null;
    if (km <= punkte[0].km) return { breite: punkte[0].breite, laenge: punkte[0].laenge };
    var i;
    for (i = 1; i < punkte.length; i++) {
      if (punkte[i].km >= km) {
        var a = punkte[i - 1], b = punkte[i], spanne = b.km - a.km, f = spanne > 0 ? (km - a.km) / spanne : 0;
        return { breite: a.breite + (b.breite - a.breite) * f, laenge: a.laenge + (b.laenge - a.laenge) * f };
      }
    }
    var l = punkte[punkte.length - 1];
    return { breite: l.breite, laenge: l.laenge };
  }

  /* ---------- Zeiten ---------- */
  function z2(n) { return (n < 10 ? '0' : '') + n; }
  /* „JJJJ-MM-TTTHH:MM“ -> Millisekunden (Ortszeit des Geräts) oder null */
  function zeitMs(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(String(iso || ''));
    if (!m) return null;
    return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], 0, 0).getTime();
  }
  function zeitIso(ms) {
    var d = new Date(ms);
    return d.getFullYear() + '-' + z2(d.getMonth() + 1) + '-' + z2(d.getDate()) + 'T' + z2(d.getHours()) + ':' + z2(d.getMinutes());
  }
  function geschwindigkeitKmh(wert, einheit) {
    var n = zahl(wert);
    if (n === null || n <= 0) return null;
    return einheit === 'kn' ? n * KN_IN_KMH : n;
  }
  /* Reisegeschwindigkeit vorbelegen (seit 2.0.118). Der eigene Wert der Route gewinnt immer. Ohne eigenen Wert gilt unterwegs (mit genug Fahrt) Ø Tag, dann Ø fahrend,
   * sonst die Reisegeschwindigkeit des Fahrzeugs (km/h). Ein Wert über der Höchstgeschwindigkeit des Fahrzeugs wird übersprungen.
   * Auf dem Wasser in Knoten: gerechnet aus km/h, die Fahrzeugwerte auf 0,1 gerundet, die Werte aus dem GPS auf 0,5 Knoten (km/h: ganze), damit das geholte Wetter nicht bei jeder Schwankung veraltet.
   * w: Werte der Route (geschwindigkeit, einheit), fz: Werte des Fahrzeugs, live: { unterwegs, tagKmh, fahrendKmh } oder null.
   * Ergebnis: { eigen, wert, einheit, herkunft ('eigen' | 'tag' | 'fahrend' | 'fahrzeug' | null), text } */
  function tempoVorschlag(w, fz, welt, live) {
    w = w || {}; fz = fz || {};
    var einheit = w.einheit === 'kn' || w.einheit === 'kmh' ? w.einheit : (welt === 'wasser' ? 'kn' : 'kmh');
    var n = zahl(w.geschwindigkeit);
    if (n !== null && n > 0) return { eigen: true, wert: n, einheit: einheit, herkunft: 'eigen', text: 'Von dir eingetragen.' };
    var hoechst = zahl(fz.hoechstgeschwindigkeit) !== null && fz.hoechstgeschwindigkeit > 0 ? fz.hoechstgeschwindigkeit : null;
    function brauchbar(v) { return zahl(v) !== null && v > 0 && (hoechst === null || v <= hoechst); }
    var kmh = null, herkunft = null;
    if (live && live.unterwegs && brauchbar(live.tagKmh)) { kmh = live.tagKmh; herkunft = 'tag'; }
    else if (live && live.unterwegs && brauchbar(live.fahrendKmh)) { kmh = live.fahrendKmh; herkunft = 'fahrend'; }
    else if (brauchbar(fz.reisegeschwindigkeit)) { kmh = fz.reisegeschwindigkeit; herkunft = 'fahrzeug'; }
    if (kmh === null) return { eigen: false, wert: null, einheit: einheit, herkunft: null, text: 'Am Fahrzeug ist keine Reisegeschwindigkeit eingetragen. Trage sie bei den Angaben des Fahrzeugs oder hier ein.' };
    var wert = einheit === 'kn' ? kmh / KN_IN_KMH : kmh;
    if (herkunft === 'fahrzeug') wert = Math.round(wert * 10) / 10;
    else wert = einheit === 'kn' ? Math.round(wert * 2) / 2 : Math.round(wert);
    if (!(wert > 0)) return { eigen: false, wert: null, einheit: einheit, herkunft: null, text: 'Die gemessene Geschwindigkeit ist noch zu klein. Trage die Reisegeschwindigkeit ein.' };
    var quelle = herkunft === 'tag' ? 'Ø Tag (gemessen)' : (herkunft === 'fahrend' ? 'Ø fahrend (gemessen)' : 'der Reisegeschwindigkeit des Fahrzeugs');
    return { eigen: false, wert: wert, einheit: einheit, herkunft: herkunft, text: 'Vorbelegt aus ' + quelle + '. Trage einen eigenen Wert ein, wenn du anders planst.' };
  }
  function dauerText(minuten) {
    var m = Math.round(minuten), h = Math.floor(m / 60), r = m % 60;
    if (h === 0) return r + ' min';
    return h + ' h' + (r ? ' ' + z2(r) + ' min' : '');
  }

  /*
   * Fahrplan: Fahrzeit und Ankunftszeit je Punkt.
   *  punkte: [{ km, breite, laenge, name? }], opt: { geschwindigkeit, einheit ('kn' | 'kmh'), abfahrt ('JJJJ-MM-TTTHH:MM') }
   * Ergebnis: { ok, laengeKm, dauerMin, ankunft, zeilen: [{ nr, name, km, minuten, eta }] } oder { ok: false, grund }.
   * Es wird mit gleichbleibender Geschwindigkeit gerechnet. Strömung, Wind und Schleusen kennt die App nicht.
   */
  function fahrplan(punkte, opt) {
    if (!punkte || punkte.length < 2) return { ok: false, grund: 'keine_route' };
    var v = geschwindigkeitKmh(opt && opt.geschwindigkeit, opt && opt.einheit);
    if (v === null) return { ok: false, grund: 'keine_geschwindigkeit' };
    var start = zeitMs(opt && opt.abfahrt);
    var laenge = punkte[punkte.length - 1].km;
    var zeilen = punkte.map(function (p, i) {
      var min = p.km / v * 60;
      return { nr: i + 1, name: p.name || null, breite: p.breite, laenge: p.laenge, km: p.km, minuten: Math.round(min), eta: start === null ? null : zeitIso(start + Math.round(min) * 60000) };
    });
    var dauer = Math.round(laenge / v * 60);
    return { ok: true, laengeKm: laenge, dauerMin: dauer, ankunft: start === null ? null : zeitIso(start + dauer * 60000), abfahrt: start === null ? null : zeitIso(start), zeilen: zeilen };
  }

  /*
   * Die Regel für die Wetterpunkte an der Route (wie in V1): Abstand nach Entfernung (alle x km oder x sm) oder nach Fahrzeit (alle x Stunden).
   * Regel: { art: 'strecke' | 'zeit', abstand: Zahl größer 0, einheit: 'km' | 'sm' | 'h' }.
   * Voreinstellung wie in V1: Wasserfahrzeug alle 10 sm, sonst jede Stunde.
   */
  function wetterRegelStandard(welt) {
    return welt === 'wasser' ? { art: 'strecke', abstand: 10, einheit: 'sm' } : { art: 'zeit', abstand: 1, einheit: 'h' };
  }
  /* Aus den gespeicherten Angaben der Route die gültige Regel machen. Fehlt etwas oder ist es unsinnig, gilt die Voreinstellung. */
  function wetterRegel(werte, welt) {
    var std = wetterRegelStandard(welt), w = werte || {};
    var art = w.wetterArt === 'strecke' || w.wetterArt === 'zeit' ? w.wetterArt : null;
    var abstand = zahl(w.wetterAbstand);
    if (!art || abstand === null || abstand <= 0) return std;
    var einheit = art === 'zeit' ? 'h' : (w.wetterEinheit === 'sm' ? 'sm' : 'km');
    return { art: art, abstand: abstand, einheit: einheit };
  }
  /* Der Abstand der Wetterpunkte in Kilometern. Bei Fahrzeit: Geschwindigkeit mal Stunden. Mindestens 100 m. */
  function regelSchrittKm(regel, kmh) {
    var km = regel.art === 'zeit' ? kmh * regel.abstand : regel.abstand * (regel.einheit === 'sm' ? SM_IN_KM : 1);
    return Math.max(0.1, km);
  }
  /* Der Abstand der Regel als Text, zum Beispiel „alle 10 sm“ oder „jede Stunde“. */
  function regelText(regel) {
    var n = String(Math.round(regel.abstand * 100) / 100).replace('.', ',');
    if (regel.art === 'zeit') return regel.abstand === 1 ? 'jede Stunde' : 'alle ' + n + ' Stunden';
    return 'alle ' + n + ' ' + regel.einheit;
  }

  /*
   * Die Punkte, für die Wetter geholt wird: Start, Ziel, benannte Wegpunkte, und dazwischen etwa alle zwei Fahrstunden
   * (mindestens alle Länge/11). Höchstens MAX_MESSPUNKTE. Jeder: { name, breite, laenge, km, minuten }.
   */
  function messpunkte(punkte, geschwindigkeit, einheit, regel) {
    var v = geschwindigkeitKmh(geschwindigkeit, einheit);
    if (!punkte || punkte.length < 2 || v === null) return [];
    var laenge = punkte[punkte.length - 1].km, schritt, maxAnzahl = MAX_MESSPUNKTE;
    if (regel) { schritt = regelSchrittKm(regel, v); maxAnzahl = MAX_MESSPUNKTE_REGEL; }
    else schritt = Math.max(v * 2, laenge / (MAX_MESSPUNKTE - 1));
    var wahl = [], letzteKm = -1e9, i;
    function nimm(p, km, name) { wahl.push({ name: name || null, breite: runde(p.breite, 5), laenge: runde(p.laenge, 5), km: runde(km, 2), minuten: Math.round(km / v * 60) }); letzteKm = km; }
    nimm(punkte[0], 0, punkte[0].name || 'Start');
    for (i = 1; i < punkte.length - 1; i++) {
      if (punkte[i].name && punkte[i].km - letzteKm >= schritt * 0.4) {
        /* Zwischen dem letzten Punkt und diesem benannten Punkt: bei Bedarf Zwischenpunkte einschieben. */
        zwischen(punkte, letzteKm, punkte[i].km, schritt, wahl, v);
        nimm(punkte[i], punkte[i].km, punkte[i].name);
      }
    }
    zwischen(punkte, letzteKm, laenge, schritt, wahl, v);
    wahl.push({ name: punkte[punkte.length - 1].name || 'Ziel', breite: runde(punkte[punkte.length - 1].breite, 5), laenge: runde(punkte[punkte.length - 1].laenge, 5), km: runde(laenge, 2), minuten: Math.round(laenge / v * 60) });
    /* Zu viele: erst die ohne Namen aufgeben, gleichmäßig. */
    while (wahl.length > maxAnzahl) {
      var kandidaten = [], j;
      for (j = 1; j < wahl.length - 1; j++) kandidaten.push(j);
      var ohne = kandidaten.filter(function (k) { return !wahl[k].name; });
      var weg = (ohne.length ? ohne : kandidaten)[Math.floor((ohne.length ? ohne : kandidaten).length / 2)];
      wahl.splice(weg, 1);
    }
    wahl.forEach(function (w, n) { w.nr = n + 1; });
    return wahl;
  }
  function zwischen(punkte, vonKm, bisKm, schritt, wahl, v) {
    var km = vonKm + schritt;
    while (km < bisKm - schritt * 0.4) {
      var p = punktBeiKm(punkte, km);
      wahl.push({ name: null, breite: runde(p.breite, 5), laenge: runde(p.laenge, 5), km: runde(km, 2), minuten: Math.round(km / v * 60) });
      km += schritt;
    }
  }

  /* ---------- Wetter und Tide: Abfragen und Auswertung (Open-Meteo) ---------- */
  var WETTER_VARIABLEN = 'temperature_2m,precipitation,precipitation_probability,wind_speed_10m,wind_direction_10m,wind_gusts_10m,weather_code';
  var MARINE_VARIABLEN = 'wave_height,wave_direction,wave_period,sea_level_height_msl';

  function wetterUrl(breite, laenge, windEinheit) {
    return 'https://api.open-meteo.com/v1/forecast?latitude=' + encodeURIComponent(breite) + '&longitude=' + encodeURIComponent(laenge) +
      '&hourly=' + WETTER_VARIABLEN + '&wind_speed_unit=' + (windEinheit === 'kn' ? 'kn' : 'kmh') + '&timezone=GMT&timeformat=unixtime&forecast_days=16';
  }
  function marineUrl(breite, laenge) {
    return 'https://marine-api.open-meteo.com/v1/marine?latitude=' + encodeURIComponent(breite) + '&longitude=' + encodeURIComponent(laenge) +
      '&hourly=' + MARINE_VARIABLEN + '&timezone=GMT&timeformat=unixtime&forecast_days=8';
  }

  var WETTER_CODES = { 0: 'klar', 1: 'überwiegend klar', 2: 'wolkig', 3: 'bedeckt', 45: 'Nebel', 48: 'Nebel mit Reif', 51: 'leichter Nieselregen', 53: 'Nieselregen', 55: 'starker Nieselregen',
    56: 'gefrierender Nieselregen', 57: 'starker gefrierender Nieselregen', 61: 'leichter Regen', 63: 'Regen', 65: 'starker Regen', 66: 'gefrierender Regen', 67: 'starker gefrierender Regen',
    71: 'leichter Schneefall', 73: 'Schneefall', 75: 'starker Schneefall', 77: 'Schneegriesel', 80: 'leichte Regenschauer', 81: 'Regenschauer', 82: 'heftige Regenschauer',
    85: 'leichte Schneeschauer', 86: 'starke Schneeschauer', 95: 'Gewitter', 96: 'Gewitter mit Hagel', 99: 'Gewitter mit starkem Hagel' };
  function wetterText(code) { var n = zahl(code); return n !== null && WETTER_CODES[n] ? WETTER_CODES[n] : null; }

  var WINDROSE = ['N', 'NO', 'O', 'SO', 'S', 'SW', 'W', 'NW'];
  function himmelsrichtung(grad) { var n = zahl(grad); return n === null ? null : WINDROSE[Math.round(((n % 360) + 360) % 360 / 45) % 8]; }

  /* Index der Stunde, die zur Zeit (Sekunden seit 1970) am nächsten liegt, aber höchstens 90 Minuten daneben. -1, wenn es keine gibt. */
  function naechsteStunde(zeiten, sek) {
    if (!zeiten || !zeiten.length) return -1;
    var bester = -1, abstand = 5400, i;
    for (i = 0; i < zeiten.length; i++) { var d = Math.abs(zeiten[i] - sek); if (d <= abstand) { abstand = d; bester = i; } }
    return bester;
  }
  function wert(reihe, i, stellen) { var n = reihe && reihe[i] !== undefined && reihe[i] !== null ? zahl(reihe[i]) : null; return n === null ? null : runde(n, stellen); }

  /* Das Wetter an einem Punkt zur Zeit sek aus der Antwort von Open-Meteo (forecast). null, wenn für die Zeit nichts da ist. */
  function wetterZurZeit(antwort, sek) {
    var hh = antwort && antwort.hourly;
    if (!hh || !hh.time) return null;
    var i = naechsteStunde(hh.time, sek);
    if (i < 0) return null;
    var code = wert(hh.weather_code, i, 0);
    return { temperatur: wert(hh.temperature_2m, i, 1), regenMm: wert(hh.precipitation, i, 1), regenWahrscheinlichkeit: wert(hh.precipitation_probability, i, 0),
      wind: wert(hh.wind_speed_10m, i, 0), boeen: wert(hh.wind_gusts_10m, i, 0), windRichtung: wert(hh.wind_direction_10m, i, 0), himmel: wetterText(code), code: code };
  }
  /* Wellen und Wasserstand zur Zeit sek aus der Antwort von Open-Meteo (marine). Leere Werte, wenn das Modell dort nichts liefert. */
  function meerZurZeit(antwort, sek) {
    var hh = antwort && antwort.hourly;
    if (!hh || !hh.time) return null;
    var i = naechsteStunde(hh.time, sek);
    if (i < 0) return null;
    var res = { welle: wert(hh.wave_height, i, 1), wellenRichtung: wert(hh.wave_direction, i, 0), wellenPeriode: wert(hh.wave_period, i, 0), wasserstand: wert(hh.sea_level_height_msl, i, 2) };
    var vorher = wert(hh.sea_level_height_msl, i - 1, 2), nachher = wert(hh.sea_level_height_msl, i + 1, 2);
    res.trend = res.wasserstand !== null && vorher !== null && nachher !== null ? (nachher > vorher ? 'steigend' : (nachher < vorher ? 'fallend' : 'gleich')) : null;
    if (res.welle === null && res.wasserstand === null) return null;
    return res;
  }

  /*
   * Hoch- und Niedrigwasser aus der Stundenreihe des Wasserstands (Open-Meteo marine, sea_level_height_msl).
   * Ein Punkt ist ein Hoch- oder Niedrigwasser, wenn er höher oder tiefer ist als seine Nachbarn. Die Zeit wird über eine Parabel
   * durch drei Stundenwerte verfeinert. Ergebnis: [{ art: 'hoch' | 'niedrig', sek, hoehe }] nach Zeit.
   * Gibt es keine echten Gezeiten (Schwankung unter 0,2 m in der ganzen Reihe), ist das Ergebnis leer.
   */
  function gezeiten(antwort) {
    var hh = antwort && antwort.hourly;
    if (!hh || !hh.time || !hh.sea_level_height_msl) return [];
    var t = hh.time, s = hh.sea_level_height_msl, res = [], i, min = Infinity, max = -Infinity;
    for (i = 0; i < s.length; i++) { if (typeof s[i] === 'number') { min = Math.min(min, s[i]); max = Math.max(max, s[i]); } }
    if (!(max - min >= 0.2)) return [];
    for (i = 1; i < s.length - 1; i++) {
      var a = s[i - 1], b = s[i], c = s[i + 1];
      if (typeof a !== 'number' || typeof b !== 'number' || typeof c !== 'number') continue;
      var hoch = b > a && b >= c, tief = b < a && b <= c;
      if (!hoch && !tief) continue;
      var nenner = a - 2 * b + c, versatz = nenner !== 0 ? 0.5 * (a - c) / nenner : 0;
      versatz = Math.max(-1, Math.min(1, versatz));
      var hoehe = b - 0.25 * (a - c) * versatz;
      res.push({ art: hoch ? 'hoch' : 'niedrig', sek: Math.round(t[i] + versatz * (t[i + 1] - t[i])), hoehe: runde(hoehe, 2) });
    }
    return res;
  }
  /* Das nächste Hoch- und das nächste Niedrigwasser nach der Zeit sek. */
  function naechsteGezeiten(liste, sek) {
    var h = null, n = null;
    (liste || []).forEach(function (g) { if (g.sek >= sek) { if (g.art === 'hoch' && !h) h = g; if (g.art === 'niedrig' && !n) n = g; } });
    return { hoch: h, niedrig: n };
  }

  /* Ortszeit-Text („HH:MM“, bei anderem Tag mit Tag und Monat) aus Sekunden. */
  function sekText(sek, bezugMs) {
    var d = new Date(sek * 1000), t = z2(d.getHours()) + ':' + z2(d.getMinutes());
    if (bezugMs !== undefined && bezugMs !== null) { var b = new Date(bezugMs); if (b.getDate() !== d.getDate() || b.getMonth() !== d.getMonth()) t = z2(d.getDate()) + '.' + z2(d.getMonth() + 1) + '. ' + t; }
    return t;
  }

  /* Die schwerste Stelle der Route in einer Zeile: größte Böen, größte Welle, größte Regenwahrscheinlichkeit. */
  function schwerste(zeilen) {
    var s = { boeen: null, welle: null, regen: null };
    zeilen.forEach(function (z) {
      if (z.wetter && z.wetter.boeen !== null && (s.boeen === null || z.wetter.boeen > s.boeen.wert)) s.boeen = { wert: z.wetter.boeen, nr: z.nr };
      if (z.meer && z.meer.welle !== null && (s.welle === null || z.meer.welle > s.welle.wert)) s.welle = { wert: z.meer.welle, nr: z.nr };
      if (z.wetter && z.wetter.regenWahrscheinlichkeit !== null && (s.regen === null || z.wetter.regenWahrscheinlichkeit > s.regen.wert)) s.regen = { wert: z.wetter.regenWahrscheinlichkeit, nr: z.nr };
    });
    return s;
  }

  /*
   * Die ganze Auswertung. Eingabe:
   *  messpunkte: [{ nr, name, km, minuten, breite, laenge }], abfahrtMs, versatzMin (Abfahrt früher oder später, zum Vergleichen),
   *  antworten: [{ wetter: Antwort | null, meer: Antwort | null }] in der Reihenfolge der Messpunkte, mitMeer: Wasserfahrzeug
   * Ergebnis: { zeilen: [{ nr, name, km, etaMs, wetter, meer, tide }], schwerste }
   */
  function auswerten(messpunkteListe, abfahrtMs, versatzMin, antworten, mitMeer) {
    var zeilen = messpunkteListe.map(function (m, i) {
      var etaMs = abfahrtMs + (m.minuten + (versatzMin || 0)) * 60000, sek = Math.round(etaMs / 1000);
      var a = antworten[i] || {}, tide = null;
      if (mitMeer && a.meer) { var g = gezeiten(a.meer); tide = g.length ? naechsteGezeiten(g, sek) : null; }
      return { nr: m.nr, name: m.name, km: m.km, breite: m.breite, laenge: m.laenge, etaMs: etaMs, wetter: wetterZurZeit(a.wetter, sek), meer: mitMeer ? meerZurZeit(a.meer, sek) : null, tide: tide };
    });
    return { zeilen: zeilen, schwerste: schwerste(zeilen) };
  }

  /* Die Stunden einer Antwort von Open-Meteo, die zwischen vonSek und bisSek liegen (alle Reihen gleich gekürzt). Spart Platz im Speicher. */
  function kuerzen(antwort, vonSek, bisSek) {
    var hh = antwort && antwort.hourly;
    if (!hh || !hh.time) return null;
    var idx = [], i;
    for (i = 0; i < hh.time.length; i++) { if (hh.time[i] >= vonSek && hh.time[i] <= bisSek) idx.push(i); }
    var neu = {};
    Object.keys(hh).forEach(function (k) { neu[k] = Array.isArray(hh[k]) ? idx.map(function (j) { return hh[k][j]; }) : hh[k]; });
    return { hourly: neu };
  }

  /* ---------- Ausgabe als GPX ---------- */
  function xmlText(t) { return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function gpx(name, punkte) {
    var z = ['<?xml version="1.0" encoding="UTF-8"?>', '<gpx version="1.1" creator="MobiMory" xmlns="http://www.topografix.com/GPX/1/1">', '  <metadata><name>' + xmlText(name || 'Route') + '</name></metadata>', '  <rte>', '    <name>' + xmlText(name || 'Route') + '</name>'];
    (punkte || []).forEach(function (p) {
      z.push('    <rtept lat="' + p.breite + '" lon="' + p.laenge + '">' + (p.name ? '<name>' + xmlText(p.name) + '</name>' : '') + '</rtept>');
    });
    z.push('  </rte>', '</gpx>', '');
    return z.join('\n');
  }

  /* ---------- Routenplanung (seit 2.0.88) ---------- */
  /*
   * Die Rechnung macht der Konto-Dienst mit HERE (Straßenfahrzeuge, Modus Lastwagen). Hier stehen nur die Anfrage, der Text der Warnungen und der Link für Wasserfahrzeuge.
   * Maße in Metern, Gewichte in Kilogramm, wie im Fahrzeug eingetragen. Fehlt eine Angabe, wird sie nicht geprüft; die App sagt das dazu.
   */
  var PLAN_PFLICHT = [{ key: 'hoehe', label: 'Höhe' }, { key: 'breite', label: 'Breite' }, { key: 'laenge', label: 'Länge' }, { key: 'gesamtgewicht', label: 'Zulässiges Gesamtgewicht' }];
  var PLAN_HINWEIS = 'Die Warnungen sind nur so gut wie die Straßendaten. Maße und Gewichte schützen dort, wo die Straßendaten die Beschränkung kennen. Achte unterwegs auf Schilder, Brücken und Tunnel. Die Verantwortung bleibt beim Fahrer.';
  var MAX_ZWISCHENZIELE = 5;

  function planPosition(p) { return !!p && typeof p.breite === 'number' && typeof p.laenge === 'number' && gueltig(p.breite, p.laenge); }

  /* Aus Start, Ziel, Zwischenzielen ({ breite, laenge, name }) und den Werten des Fahrzeugs die Anfrage an den Dienst: { ok, fehler[], anfrage, fehlend[] }. */
  function planungAnfrage(start, ziel, via, werte) {
    var fehler = [], w = werte || {}, fehlend = [];
    if (!planPosition(start)) fehler.push('Der Startort braucht eine Position (Ort der Aktivität ändern, dann Position eintragen).');
    if (!planPosition(ziel)) fehler.push('Der Zielort braucht eine Position (Ort der Aktivität ändern, dann Position eintragen).');
    var v = (via || []).filter(planPosition);
    if ((via || []).length !== v.length) fehler.push('Ein Zwischenziel hat keine Position.');
    if (v.length > MAX_ZWISCHENZIELE) fehler.push('Es sind höchstens ' + MAX_ZWISCHENZIELE + ' Zwischenziele möglich.');
    var fz = {};
    PLAN_PFLICHT.forEach(function (f) {
      var n = zahl(w[f.key]);
      if (n === null || n <= 0) fehlend.push(f.label); else fz[f.key] = n;
    });
    var ach = zahl(w.achsen);
    if (ach !== null && ach >= 1) fz.achsen = Math.round(ach);
    if (fehler.length) return { ok: false, fehler: fehler, anfrage: null, fehlend: fehlend };
    function pt(p) { return { breite: p.breite, laenge: p.laenge }; }
    return { ok: true, fehler: [], anfrage: { von: pt(start), nach: pt(ziel), via: v.map(pt), fahrzeug: fz }, fehlend: fehlend };
  }

  /* Text einer Warnung aus der Antwort des Dienstes: { code, stufe (kritisch oder hinweis), titel, grund, ort }. */
  function planungWarnungText(w) {
    var code = w && w.code || '';
    var kopf = w && w.stufe === 'kritisch' ? 'Achtung: ' : 'Hinweis: ';
    if (code === 'violatedVehicleRestriction') return kopf + 'Auf der Strecke gibt es eine Beschränkung, die zu deinem Fahrzeug nicht passt (zum Beispiel eine Brücke, die niedriger ist als dein Fahrzeug, oder eine Gewichtsgrenze). Prüfe die Stelle.' + (w.grund ? ' (' + w.grund + ')' : '');
    if (code === 'violatedBlockedRoad') return kopf + 'Ein Teil der Strecke ist gesperrt.';
    if (code === 'currentWeightExceedsLimit') return kopf + 'Das Gewicht des Fahrzeugs ist größer als die Grenze auf einem Abschnitt.';
    return kopf + (w && w.titel ? w.titel : 'Hinweis des Routen-Dienstes') + (w && w.grund ? ' (' + w.grund + ')' : '');
  }

  /* Wasserfahrzeuge: Die App plant nicht, sondern öffnet eine Navigations-App des Geräts mit dem Ziel (geo-Adresse). */
  function navigationsLink(breite, laenge, name) {
    if (!gueltig(breite, laenge)) return null;
    return 'geo:' + breite + ',' + laenge + '?q=' + breite + ',' + laenge + (name ? '(' + encodeURIComponent(String(name).slice(0, 60)) + ')' : '');
  }

  /* ---------- Kilometer über GPS (Spur) ---------- */
  /*
   * Aus den GPS-Positionen, die das Cockpit sieht, wird eine Strecke gezählt. Ein Punkt zählt nur,
   *  - wenn die Strecke gerade gezählt werden soll (das Fahrzeug ist „in Fahrt“); sonst merkt sich die App nur die Position,
   *  - wenn seine Genauigkeit gut genug ist (höchstens 50 m),
   *  - wenn der Abstand zum letzten Punkt höchstens 10 Minuten zurückliegt (sonst war die App im Hintergrund: Lücke, nichts wird geschätzt),
   *  - wenn er mindestens so weit vom letzten gezählten Punkt entfernt ist, wie die Ungenauigkeit beider Punkte zusammen (höchstens 100 m, mindestens 15 m),
   *  - und wenn die Geschwindigkeit dazwischen glaubhaft ist (unter 150 km/h an Land, unter 80 km/h auf dem Wasser, sonst ist es ein Sprung des GPS).
   * Stehen oder Treiben auf der Stelle zählt dadurch nicht. Das ist eine Luftlinie von Punkt zu Punkt, kein genauer Tacho.
   * spur: { km, letzter: { breite, laenge, zeitMs, genauigkeit } | null, punkte: Anzahl gezählter Punkte, verworfen: Anzahl, luecken: Anzahl }
   */
  var LUECKE_MS = 10 * 60 * 1000;
  /* Seit 2.0.120 hält die Spur zusätzlich die Kilometer je Minute (mi: { "<Minute seit 1970>": km }) und den Zeitpunkt der letzten Übernahme in den Zähler (ab, Millisekunden).
     Daraus lassen sich zwei Fassungen vom selben Weg zusammenführen (spurZusammen), ohne Kilometer doppelt zu zählen. */
  function spurNeu() { return { km: 0, letzter: null, punkte: 0, verworfen: 0, luecken: 0, mi: {}, ab: 0 }; }
  function minuteZu(mi, zeitMs, km) {
    var n = {}, k;
    for (k in mi) if (Object.prototype.hasOwnProperty.call(mi, k)) n[k] = mi[k];
    var key = String(Math.floor(zeitMs / 60000));
    n[key] = Math.round(((n[key] || 0) + km) * 10000) / 10000;
    return n;
  }
  function miSumme(mi) { var t = 0, k; for (k in (mi || {})) if (Object.prototype.hasOwnProperty.call(mi, k)) t += mi[k]; return t; }
  function spurZusammen(a, b) {
    a = a || spurNeu(); b = b || spurNeu();
    var ab = Math.max(a.ab || 0, b.ab || 0), mi = {}, rest = 0;
    [a, b].forEach(function (x) {
      var k, m = x.mi || {};
      for (k in m) {
        if (!Object.prototype.hasOwnProperty.call(m, k)) continue;
        if (ab && Number(k) * 60000 < ab) continue;
        mi[k] = Math.max(mi[k] || 0, m[k]);
      }
      /* Kilometer ohne Minutenangabe (aus einer älteren Fassung) zählen nur, wenn die Fassung nach der letzten Übernahme noch gilt */
      if ((x.ab || 0) >= ab) rest = Math.max(rest, (x.km || 0) - miSumme(x.mi));
    });
    var km = Math.round((miSumme(mi) + Math.max(0, rest)) * 1000) / 1000;
    var la = a.letzter, lb = b.letzter;
    var letzter = la && lb ? (lb.zeitMs > la.zeitMs ? lb : la) : (la || lb || null);
    return { km: km, letzter: letzter, punkte: Math.max(a.punkte || 0, b.punkte || 0), verworfen: Math.max(a.verworfen || 0, b.verworfen || 0),
      luecken: Math.max(a.luecken || 0, b.luecken || 0), mi: mi, ab: ab };
  }
  function spurPunkt(spur, fix, welt, zaehlen) {
    var s = { km: spur.km, letzter: spur.letzter, punkte: spur.punkte, verworfen: spur.verworfen, luecken: spur.luecken || 0, mi: spur.mi || {}, ab: spur.ab || 0 };
    if (!fix || !gueltig(fix.breite, fix.laenge)) return s;
    var gen = typeof fix.genauigkeit === 'number' && isFinite(fix.genauigkeit) ? fix.genauigkeit : 25;
    if (gen > 50) { s.verworfen++; return s; }
    var neuerLetzter = { breite: fix.breite, laenge: fix.laenge, zeitMs: fix.zeitMs, genauigkeit: gen };
    if (zaehlen === false || !s.letzter) { s.letzter = neuerLetzter; if (!spur.letzter && zaehlen !== false) s.punkte = 1; return s; }
    /* Vor dem Zeitpunkt der letzten Übernahme in den Zähler wird nichts mehr gezählt (sonst käme beim Zusammenführen etwas doppelt dazu). */
    if (s.ab && fix.zeitMs < s.ab) { s.letzter = neuerLetzter; return s; }
    if (fix.zeitMs - s.letzter.zeitMs > LUECKE_MS) { s.luecken++; s.letzter = neuerLetzter; return s; }
    var d = entfernungKm(s.letzter.breite, s.letzter.laenge, fix.breite, fix.laenge) * 1000;
    var schwelle = Math.max(15, Math.min(100, s.letzter.genauigkeit + gen));
    if (d < schwelle) return s;
    var stunden = (fix.zeitMs - s.letzter.zeitMs) / 3600000;
    var grenze = welt === 'wasser' ? 80 : 150;
    if (stunden > 0 && (d / 1000) / stunden > grenze) { s.verworfen++; return s; }
    s.km += d / 1000; s.punkte++;
    s.mi = minuteZu(s.mi, fix.zeitMs, d / 1000);
    s.letzter = neuerLetzter;
    return s;
  }


  /* ---------- Wechselpunkte (seit 2.0.116, Wasserfahrzeuge) ----------
   * Die Routenpunkte (GPX rtept) oder, wenn es nur die gibt, die Wegpunkte einer eingelesenen Datei sind die Wechselpunkte: Dort ändert sich der Soll-Kurs.
   * Eine aufgezeichnete Spur (Archiv-Export einer Navi-App) ist keine geplante Route und hat keine Wechselpunkte.
   * Punkte, die nacheinander (höchstens WP_GLEICH_KM auseinander) an derselben Position liegen, sind ein Wechselpunkt; der erste Name bleibt stehen.
   * Der Name ist der Name aus der Datei („Point-2“), sonst „Punkt <Nummer>“. Der Nutzer kann ihn ändern (namen: { "<Index des ersten Punkts>": "Name" }).
   * Der Soll-Kurs ist die Peilung von Wechselpunkt zu Wechselpunkt (rechtweisend, Großkreis-Anfangskurs). Hier steht nur Rechnung, kein Speichern. */
  var KM_PRO_SM = 1.852;
  var WP_GLEICH_KM = 0.03;        /* 30 m: gleiche Position */
  var WP_ERREICHT_SM = 0.1;       /* 0,1 sm (185 m): Wechselpunkt erreicht */
  var WP_NAEHERT_SM = 2;          /* ab 2 sm vor dem Wechselpunkt hebt das Cockpit die Meldung hervor */
  var WP_NAME_MAX = 40;

  /* Peilung von Punkt 1 zu Punkt 2 in ganzen Grad, 0 bis 359 (0 = Nord, 90 = Ost). */
  function peilung(b1, l1, b2, l2) {
    var rad = Math.PI / 180, dL = (l2 - l1) * rad, p1 = b1 * rad, p2 = b2 * rad;
    var y = Math.sin(dL) * Math.cos(p2), x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dL);
    return Math.round(((Math.atan2(y, x) / rad) + 360) % 360) % 360;
  }
  function gradText(g) { var n = Math.round(g) % 360; if (n < 0) n += 360; return ('00' + n).slice(-3) + '°'; }
  function smText(sm) { return (Math.round(sm * 10) / 10).toFixed(1).replace('.', ','); }

  /* Der Routenpunkt, der einer Position am nächsten liegt (Index), oder -1 ohne Punkte. */
  function naechsterPunktIndex(punkte, breite, laenge) {
    var best = -1, bd = Infinity;
    (punkte || []).forEach(function (p, i) { var d = entfernungKm(p.breite, p.laenge, breite, laenge); if (d < bd) { bd = d; best = i; } });
    return best;
  }

  /* Wechselpunkte von Hand (seit 2.0.117): „eigene“ ist eine Liste { id, name, breite, laenge, am }. Ein Handpunkt steht in der Reihenfolge nach dem nächsten Routenpunkt
   * (bei Gleichstand nach dem Punkt aus der Datei), wird nie mit anderen zusammengelegt und ist auch bei einer reinen Spur möglich (mindestens zwei Punkte).
   * Ergebnis zusätzlich: handErlaubt (Handpunkte sind für diese Datei möglich) und hand (die Handpunkte in Reihenfolge der Eingabe, zum Bearbeiten). */
  function wechselpunkte(punkte, wegart, namen, eigene, regel) {
    var dateiArt = wegart === 'route' || wegart === 'wegpunkte', handErlaubt = dateiArt || wegart === 'spur';
    var hand = [];
    if (handErlaubt) (Array.isArray(eigene) ? eigene : []).forEach(function (e) {
      if (e && typeof e.id === 'string' && typeof e.breite === 'number' && typeof e.laenge === 'number') hand.push(e);
    });
    if (!dateiArt && !(wegart === 'spur' && hand.length)) {
      return { moeglich: false, liste: [], hand: [], handErlaubt: handErlaubt, grund: wegart === 'spur'
        ? 'Diese Datei enthält nur eine aufgezeichnete Spur und keine geplante Route. Wechselpunkte aus der Datei gibt es hier nicht. Du kannst sie unten von Hand eintragen (mindestens zwei), oder du exportierst in deiner Navi-App eine geplante Route und liest sie ein.'
        : 'Für diese Route kennt die App die Wechselpunkte nicht. Lies die Routendatei noch einmal ein.' };
    }
    var liste = [], eigeneNamen = namen || {};
    if (dateiArt) (punkte || []).forEach(function (p, i) {
      var letzte = liste[liste.length - 1];
      if (letzte && entfernungKm(letzte.breite, letzte.laenge, p.breite, p.laenge) <= WP_GLEICH_KM) {
        letzte.anzahl++;
        if (!letzte.dateiName && p.name) letzte.dateiName = p.name;
        return;
      }
      liste.push({ index: i, breite: p.breite, laenge: p.laenge, km: typeof p.km === 'number' ? p.km : null, dateiName: p.name || null, anzahl: 1, hand: false, id: null });
    });
    /* Mindestabstand und Knick-Regel (seit 2.0.118): nur für die Punkte aus der Datei, die Datei selbst bleibt unverändert. */
    var r = wpRegelLesen(regel), ausgeduennt = 0;
    if (r && dateiArt) { var d = wpAusduennen(liste, r, eigeneNamen); liste = d.liste; ausgeduennt = d.entfallen; }
    hand.forEach(function (e) {
      var i = naechsterPunktIndex(punkte, e.breite, e.laenge);
      liste.push({ index: i < 0 ? 0 : i, breite: e.breite, laenge: e.laenge, km: i >= 0 && typeof punkte[i].km === 'number' ? punkte[i].km : null, dateiName: null, anzahl: 1, hand: true, id: e.id, handName: e.name || '' });
    });
    liste.forEach(function (w, k) { w.reihe = k; });
    liste.sort(function (a, b) { return a.index - b.index || (a.hand ? 1 : 0) - (b.hand ? 1 : 0) || a.reihe - b.reihe; });
    if (liste.length < 2) return { moeglich: false, liste: [], hand: hand, handErlaubt: handErlaubt, grund: wegart === 'spur' ? 'Bei einer aufgezeichneten Spur brauchst du mindestens zwei Wechselpunkte von Hand.' : 'Die Route hat nur einen Punkt. Es gibt keinen Wechselpunkt.' };
    liste.forEach(function (w, n) {
      w.nr = n + 1;
      var eigen = w.hand ? w.handName : eigeneNamen[String(w.index)];
      w.eigenerName = typeof eigen === 'string' && eigen.trim() !== '';
      w.name = w.eigenerName ? eigen.trim().slice(0, WP_NAME_MAX) : (w.dateiName || ('Punkt ' + w.nr));
      var vor = n > 0 ? liste[n - 1] : null, nach = n < liste.length - 1 ? liste[n + 1] : null;
      w.kursHin = vor ? peilung(vor.breite, vor.laenge, w.breite, w.laenge) : null;
      w.distanzHinSm = vor ? runde(entfernungKm(vor.breite, vor.laenge, w.breite, w.laenge) / KM_PRO_SM, 1) : null;
      w.kursWeiter = nach ? peilung(w.breite, w.laenge, nach.breite, nach.laenge) : null;
    });
    return { moeglich: true, liste: liste, hand: hand, handErlaubt: handErlaubt, grund: null, regel: r, ausgeduennt: ausgeduennt };
  }

  /* Mindestabstand und Knick-Regel der Wechselpunkte (seit 2.0.118). Einstellung je Route: { abstandSm, knickGrad }, ohne Wahl gilt nur das Zusammenfassen auf 30 m.
   * Ein Punkt bleibt immer: der erste, der letzte, einer mit eigenem Namen und einer, an dem die Route um mindestens knickGrad abknickt (Knick gegen den Kurs der Nachbarn in der Datei).
   * Alle anderen entfallen, wenn sie weniger als abstandSm vom zuletzt behaltenen Punkt oder vom folgenden Knickpunkt entfernt sind. */
  var WP_ABSTAND_MAX_SM = 50;
  var WP_KNICK_STANDARD = 30;
  function wpRegelLesen(regel) {
    if (!regel || typeof regel.abstandSm !== 'number' || !(regel.abstandSm > 0)) return null;
    var k = typeof regel.knickGrad === 'number' && regel.knickGrad > 0 ? regel.knickGrad : WP_KNICK_STANDARD;
    return { abstandSm: regel.abstandSm, knickGrad: k };
  }
  function wpWinkel(a, b) { var d = Math.abs(a - b) % 360; return d > 180 ? 360 - d : d; }
  function wpAusduennen(liste, r, namen) {
    var n = liste.length, minKm = r.abstandSm * KM_PRO_SM;
    if (n < 3) return { liste: liste, entfallen: 0 };
    var fest = liste.map(function (w, i) {
      if (i === 0 || i === n - 1) return 'fest';
      if (namen && typeof namen[String(w.index)] === 'string' && namen[String(w.index)].trim() !== '') return 'fest';
      var vor = liste[i - 1], nach = liste[i + 1];
      var drehung = wpWinkel(peilung(vor.breite, vor.laenge, w.breite, w.laenge), peilung(w.breite, w.laenge, nach.breite, nach.laenge));
      return drehung >= r.knickGrad ? 'fest' : '';
    });
    var behalten = [], letzte = null;
    liste.forEach(function (w, i) {
      if (fest[i] || !letzte || entfernungKm(letzte.breite, letzte.laenge, w.breite, w.laenge) >= minKm) { behalten.push(i); letzte = w; }
    });
    /* rückwärts: ein weicher Punkt kurz vor einem festen Punkt entfällt */
    var folgender = null, ergebnis = [];
    for (var k = behalten.length - 1; k >= 0; k--) {
      var i = behalten[k], w = liste[i];
      if (!fest[i] && folgender && entfernungKm(w.breite, w.laenge, folgender.breite, folgender.laenge) < minKm) continue;
      ergebnis.unshift(w); folgender = w;
    }
    return { liste: ergebnis, entfallen: n - ergebnis.length };
  }
  /* Eingabe prüfen: roh { abstandSm, knickGrad } als Text oder Zahl. Leer = keine eigene Regel. Ergebnis { werte: { abstandSm, knickGrad } } (beide null = aus) oder { fehler }. */
  function wpRegelPruefen(roh) {
    roh = roh || {};
    function zahlLesen(v) {
      var t = String(v === null || v === undefined ? '' : v).trim().replace(',', '.');
      if (t === '') return { leer: true };
      if (!/^\d+(\.\d+)?$/.test(t)) return { fehler: true };
      return { wert: parseFloat(t) };
    }
    var a = zahlLesen(roh.abstandSm), k = zahlLesen(roh.knickGrad), f = {};
    if (a.fehler) f.abstandSm = 'Bitte eine Zahl eingeben, zum Beispiel 0,5.';
    else if (!a.leer && !(a.wert > 0)) f.abstandSm = 'Der Mindestabstand muss größer als 0 sein. Leer lassen schaltet ihn aus.';
    else if (!a.leer && a.wert > WP_ABSTAND_MAX_SM) f.abstandSm = 'Der Mindestabstand darf höchstens ' + WP_ABSTAND_MAX_SM + ' sm sein.';
    if (k.fehler) f.knickGrad = 'Bitte eine Zahl eingeben, zum Beispiel 30.';
    else if (!k.leer && (k.wert < 1 || k.wert > 179)) f.knickGrad = 'Die Kursänderung muss zwischen 1 und 179 Grad liegen.';
    else if (!k.leer && a.leer && !f.abstandSm) f.abstandSm = 'Die Kursänderung gilt nur zusammen mit einem Mindestabstand. Bitte auch den Mindestabstand eingeben.';
    if (Object.keys(f).length) return { fehler: f };
    return { werte: { abstandSm: a.leer ? null : a.wert, knickGrad: a.leer || k.leer ? null : k.wert } };
  }

  /* Ein Wechselpunkt von Hand: Eingabe prüfen. roh: { name, breite, laenge } (Dezimalgrad als Text oder Zahl). Ergebnis: { werte: { name, breite, laenge } } oder { fehler }. */
  function handPunktPruefen(roh) {
    roh = roh || {};
    var fehler = {}, f = {};
    var b = MM.Logbuch.koordinateLesen(roh.breite, 'breite'), l = MM.Logbuch.koordinateLesen(roh.laenge, 'laenge');
    if (b.fehler) fehler.breite = b.fehler; else if (b.leer) fehler.breite = 'Bitte die Breite eingeben.';
    if (l.fehler) fehler.laenge = l.fehler; else if (l.leer) fehler.laenge = 'Bitte die Länge eingeben.';
    var name = String(roh.name === null || roh.name === undefined ? '' : roh.name).replace(/\s+/g, ' ').trim();
    if (name.length > WP_NAME_MAX) fehler.name = 'Der Name darf höchstens ' + WP_NAME_MAX + ' Zeichen haben.';
    if (Object.keys(fehler).length) return { fehler: fehler };
    f = { name: name, breite: b.wert, laenge: l.wert };
    return { werte: f };
  }

  /* Wie viele Wechselpunkte hat die Fahrt schon hinter sich, wenn das Fahrzeug bei „km“ der Route steht? Ergebnis: Listenindex des letzten passierten (0 = Start). */
  function wpStartIndex(liste, kmAufRoute) {
    var p = 0;
    (liste || []).forEach(function (w, i) { if (typeof w.km === 'number' && w.km <= kmAufRoute) p = i; });
    return p;
  }
  /* Die Fahrt kommt an einem Wechselpunkt an: der höchste Wechselpunkt nach „passiert“, der höchstens WP_ERREICHT_SM entfernt ist, gilt als passiert. */
  function wpPassiert(liste, passiert, breite, laenge) {
    var p = typeof passiert === 'number' ? passiert : 0, erreicht = null;
    for (var i = p + 1; i < (liste || []).length; i++) {
      if (entfernungKm(breite, laenge, liste[i].breite, liste[i].laenge) / KM_PRO_SM <= WP_ERREICHT_SM) { p = i; erreicht = liste[i]; }
    }
    return { passiert: p, erreicht: erreicht };
  }
  /* Der nächste Wechselpunkt nach „passiert“ mit Abstand (sm) und Peilung von der Position zu ihm, oder null am Ende der Route. */
  function wpNaechster(liste, passiert, breite, laenge) {
    var n = (typeof passiert === 'number' ? passiert : 0) + 1, w = liste && liste[n];
    if (!w) return null;
    return { wp: w, abstandSm: runde(entfernungKm(breite, laenge, w.breite, w.laenge) / KM_PRO_SM, 1), kursZu: peilung(breite, laenge, w.breite, w.laenge), naehert: entfernungKm(breite, laenge, w.breite, w.laenge) / KM_PRO_SM <= WP_NAEHERT_SM };
  }
  /* Die Meldung im Cockpit. info: Ergebnis von wpNaechster; kursJetzt: Kurs über Grund in Grad oder null; erreicht: gerade erreichter Wechselpunkt oder null. */
  function wpMeldung(info, kursJetzt, erreicht) {
    var z = [];
    if (erreicht) z.push('Wechselpunkt ' + erreicht.name + ' erreicht' + (erreicht.kursWeiter !== null ? ', neuer Soll-Kurs ' + gradText(erreicht.kursWeiter) : ', das war der letzte') + '.');
    if (info) {
      z.push((info.naehert ? 'Gleich Wechselpunkt ' : 'Nächster Wechselpunkt ') + info.wp.name + ' in ' + smText(info.abstandSm) + ' sm, Soll-Kurs ' + gradText(info.wp.kursHin)
        + (typeof kursJetzt === 'number' ? ', Kurs jetzt ' + gradText(kursJetzt) : '') + '.');
    }
    return z.join(' ');
  }
  /* Neuer Name für einen Wechselpunkt (Index des ersten Punkts): { namen } oder { fehler }. Leer setzt auf den Namen aus der Datei zurück. */
  function wpNamenSetzen(namen, index, name) {
    var n = Object.assign({}, namen || {}), t = String(name == null ? '' : name).trim();
    if (t.length > WP_NAME_MAX) return { fehler: 'Der Name darf höchstens ' + WP_NAME_MAX + ' Zeichen haben.' };
    if (t) n[String(index)] = t; else delete n[String(index)];
    return { namen: n };
  }

  MM.Routen = {
    FORMATE: FORMATE, EINHEITEN: EINHEITEN, KN_IN_KMH: KN_IN_KMH, MAX_PUNKTE: MAX_PUNKTE, MAX_MESSPUNKTE: MAX_MESSPUNKTE, MAX_MESSPUNKTE_REGEL: MAX_MESSPUNKTE_REGEL, WETTER_ARTEN: WETTER_ARTEN,
    wetterRegelStandard: wetterRegelStandard, wetterRegel: wetterRegel, regelSchrittKm: regelSchrittKm, regelText: regelText,
    entfernungKm: entfernungKm, lesen: lesen, formatErkennen: formatErkennen, vereinfachen: vereinfachen, punkteAufbereiten: punkteAufbereiten, punktBeiKm: punktBeiKm,
    zeitMs: zeitMs, zeitIso: zeitIso, geschwindigkeitKmh: geschwindigkeitKmh, tempoVorschlag: tempoVorschlag, dauerText: dauerText, fahrplan: fahrplan, messpunkte: messpunkte,
    wetterUrl: wetterUrl, marineUrl: marineUrl, wetterText: wetterText, himmelsrichtung: himmelsrichtung, wetterZurZeit: wetterZurZeit, meerZurZeit: meerZurZeit,
    gezeiten: gezeiten, naechsteGezeiten: naechsteGezeiten, kuerzen: kuerzen, auswerten: auswerten, schwerste: schwerste, sekText: sekText, gpx: gpx,
    spurNeu: spurNeu, spurPunkt: spurPunkt, spurZusammen: spurZusammen, zahl: zahl,
    peilung: peilung, gradText: gradText, smText: smText, wechselpunkte: wechselpunkte, wpRegelPruefen: wpRegelPruefen, WP_KNICK_STANDARD: WP_KNICK_STANDARD, WP_ABSTAND_MAX_SM: WP_ABSTAND_MAX_SM, handPunktPruefen: handPunktPruefen, naechsterPunktIndex: naechsterPunktIndex, wpStartIndex: wpStartIndex, wpPassiert: wpPassiert, wpNaechster: wpNaechster, wpMeldung: wpMeldung, wpNamenSetzen: wpNamenSetzen,
    KM_PRO_SM: KM_PRO_SM, WP_GLEICH_KM: WP_GLEICH_KM, WP_ERREICHT_SM: WP_ERREICHT_SM, WP_NAEHERT_SM: WP_NAEHERT_SM,
    planungAnfrage: planungAnfrage, planungWarnungText: planungWarnungText, navigationsLink: navigationsLink, PLAN_PFLICHT: PLAN_PFLICHT, PLAN_HINWEIS: PLAN_HINWEIS, MAX_ZWISCHENZIELE: MAX_ZWISCHENZIELE
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
