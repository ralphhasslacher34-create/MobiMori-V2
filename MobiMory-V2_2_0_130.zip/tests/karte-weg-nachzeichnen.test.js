'use strict';
/* 2.0.111: Der gefahrene Weg wächst in der Karte mit (Cockpit-Wechsel und Karte der Aktivität). Dazu Einbau der festen Signatur und der Adresse der Hülle. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/texte.js');
const MM = globalThis.MM;
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

test('Die Karte kann den gefahrenen Weg neu setzen, ohne die Daten neu zu laden', () => {
  const k = lesen('js/kartenansicht.js');
  assert.match(k, /wegNeu: function \(w\) \{ if \(!karte \|\| !w\) return; kd\.weg = w; zeichnen\(\); \}/);
});

test('Cockpit-Wechsel und Karte der Aktivität nutzen den Horcher mit Nachzeichnen, höchstens alle 15 Sekunden und nur bei neuen Punkten', () => {
  const a = lesen('js/ansicht.js');
  const f = a.slice(a.indexOf('function kartenHorcher'), a.indexOf('function gpsStoppen'));
  assert.match(f, /kv\.position\(frischePosition\(\)\)/);
  assert.match(f, /Date\.now\(\) - zuletztMs < 15000/);
  assert.match(f, /gpsWeg\.punkte\.length === zuletztN/);
  assert.match(f, /kv\.wegNeu\(gpsWeg\)/);
  assert.equal((a.match(/gpsHorcher = kartenHorcher\(kv, id\);/g) || []).length, 2, 'Wechselkarte und Karte der Aktivität');
  assert.match(a, /gpsHorcher = function \(\) \{ kv\.position\(frischePosition\(\)\); \};/, 'Karte des Tages bleibt unverändert');
});

test('Der Horcher zeichnet nach, wenn neue Punkte da sind, und nicht öfter als alle 15 Sekunden', () => {
  const a = lesen('js/ansicht.js');
  const src = a.slice(a.indexOf('function kartenHorcher'), a.indexOf('function gpsStoppen'));
  let jetzt = 100000; const D = { now: () => jetzt };
  let pos = 0; const neu = [];
  const kv = { position: () => { pos++; }, wegNeu: w => neu.push(w.punkte.length) };
  const zustand = { weg: { punkte: [1, 2] } };
  const mach = new Function('st', 'kv', 'D', 'return (function () { var gpsWeg = st.weg, gpsWegAkt = "a"; function frischePosition() { return null; } var Date = D; ' + src +
    '; return { h: kartenHorcher(kv, "a"), setze: function (w) { gpsWeg = w; } }; })()');
  const o = mach(zustand, kv, D);
  o.h(); assert.equal(neu.length, 0, 'gleiche Punktzahl wie beim Aufbau: nichts');
  o.setze({ punkte: [1, 2, 3] }); o.h(); assert.deepEqual(neu, [3], 'erster neuer Punkt: sofort');
  o.setze({ punkte: [1, 2, 3, 4] }); jetzt += 5000; o.h(); assert.deepEqual(neu, [3], 'unter 15 Sekunden: noch nicht');
  jetzt += 11000; o.h(); assert.deepEqual(neu, [3, 4], 'nach 15 Sekunden');
  jetzt += 20000; o.h(); assert.deepEqual(neu, [3, 4], 'keine neuen Punkte, keine Zeichnung');
  assert.equal(pos, 5, 'die Position wird jedes Mal aktualisiert');
});

test('Hülle: Adresse im Dienst erlaubt, feste Signatur, Versionsnummer aus der Laufnummer', () => {
  assert.match(lesen('server/wrangler-konto.jsonc'), /"ERLAUBTE_URSPRUENGE": "https:\/\/app\.mobimory\.com,https:\/\/localhost"/);
  const g = lesen('android/app/build.gradle');
  assert.match(g, /storeFile file\('debug\.keystore'\)/);
  assert.match(g, /GITHUB_RUN_NUMBER/);
  assert.ok(fs.existsSync(path.join(__dirname, '..', 'android', 'app', 'debug.keystore')));
  assert.equal(MM.VERSION, '2.0.130');
  assert.equal(MM.Texte.NEUERUNGEN[19].version, '2.0.111');
  assert.match(MM.Texte.NEUERUNGEN[19].punkte.join(' '), /gefahrenen Wegs/);
  assert.match(lesen('CHANGELOG.md'), /## 2\.0\.111\n- \*\*Fehler: gefahrener Weg/);
  /* 2.0.112: Gradle liest die Nummern als Werte (nicht als Aufruf mit .toInteger()) */
  assert.match(g, /def mmVersionCode = Integer\.parseInt\(System\.getenv\('GITHUB_RUN_NUMBER'\) \?: '1'\)/);
  assert.match(g, /versionCode mmVersionCode/); assert.doesNotMatch(g, /versionCode \(/);
});
