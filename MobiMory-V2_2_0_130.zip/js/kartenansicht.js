/*
 * Kartenansicht (seit 2.0.34, Schritt 9b): die Karte im Vollbild, gezeichnet mit Leaflet (lib/leaflet).
 *
 * Gezeigt werden: die geplante Route, Start, Ziel und Zwischenziele, die Wetterpunkte der Route (grau, wenn schon vorbei),
 * die Einträge „Wetter jetzt“ und weitere Einträge mit Position aus dem Logbuch, der tatsächlich gefahrene Weg und die aktuelle Position.
 * Die Kacheln kommen zuerst aus dem Gerät (Offline-Karte, js/kartenablage.js), sonst aus dem Netz.
 *
 * Alle Texte kommen mit textContent in die Seite, nie als HTML (außer dem festen Nachweis der Kartenquelle in der Karte selbst).
 * Die Rechnung steht in js/karte.js, das Holen der Daten in js/daten.js.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  var doc = global.document;

  function el(tag, attrs) {
    var e = doc.createElement(tag), k;
    if (attrs) {
      for (k in attrs) {
        if (!Object.prototype.hasOwnProperty.call(attrs, k) || attrs[k] === null || attrs[k] === undefined) continue;
        if (k === 'text') e.textContent = attrs[k];
        else if (k === 'class') e.className = attrs[k];
        else if (k.slice(0, 2) === 'on') e[k] = attrs[k];
        else e.setAttribute(k, attrs[k]);
      }
    }
    for (var i = 2; i < arguments.length; i++) { var c = arguments[i]; if (c === null || c === undefined || c === false) continue; e.appendChild(typeof c === 'string' ? doc.createTextNode(c) : c); }
    return e;
  }
  function zahl1(n) { return String(Math.round(n * 10) / 10).replace('.', ','); }
  function uhr(datum, zeit) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(datum || '');
    return (m ? m[3] + '.' + m[2] + '. ' : '') + (zeit ? zeit + ' Uhr' : '');
  }

  /* Die Kachelschicht: erst das Gerät, dann das Netz. zaehler wird hochgezählt (lokal, netz, fehlt). */
  function kachelSchicht(L, ablage, zaehler, beiAenderung, see) {
    var Schicht = L.GridLayer.extend({
      createTile: function (coords, fertig) {
        var img = doc.createElement('img'), url = see ? MM.Karte.seeKachelUrl(coords.z, coords.x, coords.y) : MM.Karte.kachelUrl(coords.z, coords.x, coords.y), objekt = null, erledigt = false;
        img.alt = ''; img.setAttribute('role', 'presentation'); img.referrerPolicy = 'strict-origin-when-cross-origin';
        function schluss(ok) {
          if (erledigt) return;
          erledigt = true;
          if (objekt) { try { global.URL.revokeObjectURL(objekt); } catch (e) { /* nichts zu tun */ } objekt = null; }
          if (!ok && !see) { zaehler.fehlt++; if (beiAenderung) beiAenderung(); }
          if (!ok && see) img.style.display = 'none';
          fertig(null, img);
        }
        img.onload = function () { schluss(true); };
        img.onerror = function () { schluss(false); };
        ablage.blob(url).then(function (b) {
          if (b) { if (!see) zaehler.lokal++; try { objekt = global.URL.createObjectURL(b); img.src = objekt; return; } catch (e) { /* dann aus dem Netz */ } }
          if (!see) zaehler.netz++;
          img.src = url;
        });
        return img;
      }
    });
    var q = see ? MM.Karte.SEE_QUELLE : MM.Karte.QUELLE;
    return new Schicht({ minZoom: q.minZoom, maxZoom: q.maxZoom, noWrap: true, tileSize: 256, zIndex: see ? 5 : 1,
      attribution: '<a href="' + q.nachweisLink + '" target="_blank" rel="noopener">' + q.nachweis + '</a>' });
  }

  function pin(L, klasse, text, groesse) {
    var g = groesse || 30;
    return L.divIcon({ className: 'kv-pin-huelle', iconSize: [g, g], iconAnchor: [g / 2, g / 2], popupAnchor: [0, -g / 2], html: el('span', { class: 'kv-pin ' + klasse + (String(text).length > 1 ? ' zwei' : ''), text: text }) });
  }

  /* Ein Zeichen, das neben seinem Ort steht (seit 2.0.118): Der Anker wird um dx, dy Pixel verschoben, der Ort bleibt, der Punkt steht daneben. */
  function pinVersetzt(L, klasse, text, groesse, dx, dy) {
    var g = groesse || 30;
    return L.divIcon({ className: 'kv-pin-huelle', iconSize: [g, g], iconAnchor: [g / 2 - dx, g / 2 - dy], popupAnchor: [dx, dy - g / 2], html: el('span', { class: 'kv-pin ' + klasse + (String(text).length > 1 ? ' zwei' : ''), text: text }) });
  }

  /*
   * opt: {
   *   ablage: Kartenablage,
   *   kd: Ergebnis von daten.kartenDaten,
   *   zurueck: Adresse „zurück zum Cockpit“, offline: Adresse der Seite Offline-Karte, routeSeite: Adresse der Seite Route und Wetter,
   *   beiZurueck: Funktion, beim Verlassen,
   *   wetterNeu(versatzMin): Zusage mit { zeilen, versatzMin } oder null (Wetterpunkte neu gerechnet für Verspätung),
   *   wetterJetzt(): Zusage mit { ok, text } oder { ok: false, fehler } (Knopf „Wetter jetzt“ in der Karte),
   *   neuLaden(): Zusage mit neuen Kartendaten (nach „Wetter jetzt“),
   *   gpsText(): Text zum Stand des GPS
   * }
   * Ergebnis: { element, start(), position(fix), neueDaten(kd), zerstoeren() } oder { fehler } ohne Leaflet.
   */
  function aufbauen(opt) {
    var L = global.L;
    if (!L || !L.map) return { fehler: 'Die Karte konnte nicht geladen werden (Leaflet fehlt).' };
    var kd = opt.kd, karte = null, folgen = true, letzteFix = null, ebenen = null, posMarker = null, genauigkeitKreis = null;
    var zaehler = { lokal: 0, netz: 0, fehlt: 0 }, verspaetungAngewandt = 0, letzteNeuRechnung = 0, fix = null, zuletztAngezeigt = null;
    /* Ereignisse auf der Karte (seit 2.0.108): die wirksame Wahl, bei der Tagesroute ohne eigene Auswahl alles. */
    var KE = MM.KartenEreignisse;
    var wasser = !!(kd.aktivitaet && kd.aktivitaet.welt === 'wasser');
    var wahl = kd.wahl ? { aus: kd.wahl.wirksam.aus.slice(), seezeichen: kd.wahl.wirksam.seezeichen } : KE.standard();
    var seeSchicht = null, wahlEigene = !!(kd.wahl && kd.wahl.eigene);
    /* Schalter (seit 2.0.118): Wetterpunkte und Wechselpunkte einzeln ein- und ausblenden, gilt für diese Ansicht. */
    var zeigeWetter = true, zeigeWechsel = true;

    var info = el('div', { class: 'kv-info', role: 'status', 'aria-live': 'polite' });
    var infoKopf = el('button', { class: 'kv-info-kopf', type: 'button', 'aria-expanded': 'false', 'aria-label': 'Angaben zur Karte, antippen zum Auf- und Zuklappen' });
    var infoRumpf = el('div', { class: 'kv-info-rumpf' });
    infoRumpf.hidden = true;
    infoKopf.onclick = function () {
      infoRumpf.hidden = !infoRumpf.hidden;
      infoKopf.setAttribute('aria-expanded', infoRumpf.hidden ? 'false' : 'true');
      wurzel.classList.toggle('kv-info-offen', !infoRumpf.hidden);
      global.setTimeout(function () { if (karte) karte.invalidateSize(); }, 50);
    };
    info.appendChild(infoKopf); info.appendChild(infoRumpf);
    var kartenFlaeche = el('div', { class: 'kv-karte', role: 'application', 'aria-label': 'Karte' });
    var folgenKnopf = el('button', { class: 'knopf leise klein', type: 'button', text: 'Folgen: an', 'aria-pressed': 'true' });
    var meldung = el('p', { class: 'kv-meldung', role: 'status' });
    meldung.hidden = true;
    function melden(text) { meldung.textContent = text || ''; meldung.hidden = !text; }

    var ereignisKnopf = el('button', { class: 'knopf leise klein', type: 'button', text: 'Ereignisse', 'aria-expanded': 'false' });
    var ereignisPanel = el('div', { class: 'kv-panel', role: 'region', 'aria-label': 'Ereignisse auf der Karte' });
    ereignisPanel.hidden = true;
    ereignisKnopf.onclick = function () {
      ereignisPanel.hidden = !ereignisPanel.hidden;
      ereignisKnopf.setAttribute('aria-expanded', ereignisPanel.hidden ? 'false' : 'true');
      if (!ereignisPanel.hidden) panelZeichnen();
    };
    /* Eingebettet (Cockpit-Wechsel, Vollbild seit 2.0.109): eigene Knöpfe vorn in der Leiste, zum Beispiel Logbuch, Hauptmenü, Zurück. */
    var knoepfeEingebettet = null;
    if (opt.eingebettet && opt.eingebettetKnoepfe && opt.eingebettetKnoepfe.length) {
      knoepfeEingebettet = el('span', { class: 'kv-eigene' });
      opt.eingebettetKnoepfe.forEach(function (k) {
        knoepfeEingebettet.appendChild(k.href ? el('a', { class: 'knopf leise klein', href: k.href, text: k.text })
          : el('button', { class: 'knopf leise klein', type: 'button', text: k.text, onclick: function () { if (k.beiTipp) k.beiTipp(); } }));
      });
    }
    var leiste = el('div', { class: 'kv-leiste' },
      opt.eingebettet ? null : el('a', { class: 'knopf leise klein', href: opt.zurueck, text: 'Zurück', onclick: function () { if (opt.beiZurueck) opt.beiZurueck(); } }),
      knoepfeEingebettet,
      folgenKnopf,
      el('button', { class: 'knopf leise klein', type: 'button', text: 'Alles zeigen', onclick: function () { alles(); } }),
      opt.wetterJetzt ? el('button', { class: 'knopf leise klein', type: 'button', text: 'Wetter jetzt', onclick: function (ev) {
        var b = ev.currentTarget; if (b.disabled) return;
        b.disabled = true;
        opt.wetterJetzt().then(function (r) { b.disabled = false; melden(r.ok ? r.text : ((r.fehler && r.fehler.allgemein) || 'Das hat nicht geklappt.')); if (r.ok) neueDatenHolen(); }, function () { b.disabled = false; melden('Das hat nicht geklappt.'); });
      } }) : null,
      opt.offline ? el('a', { class: 'knopf leise klein', href: opt.offline, text: 'Offline-Karte' }) : null,
      kd.nurRoute ? null : ereignisKnopf);
    var kartenRahmen = el('div', { class: 'kv-rahmen' }, kartenFlaeche, ereignisPanel);
    var wurzel = el('div', { class: 'karte-voll', role: 'main' }, leiste, meldung, kartenRahmen, info);

    function planPunkte() {
      var p = [];
      if (kd.route) kd.route.punkte.forEach(function (x) { p.push([x.breite, x.laenge]); });
      kd.planOrte.forEach(function (o) { p.push([o.breite, o.laenge]); });
      return p;
    }
    function alles() {
      if (!karte) return;
      var pts = planPunkte();
      MM.Karte.wegStuecke(kd.weg).forEach(function (s) { s.forEach(function (q) { pts.push(q); }); });
      kd.ereignisse.forEach(function (e) { pts.push([e.breite, e.laenge]); });
      if (fix) pts.push([fix.breite, fix.laenge]);
      if (!pts.length) { karte.setView([50, 10], 5); return; }
      folgen = false; folgenAnzeigen();
      karte.fitBounds(L.latLngBounds(pts), { padding: [36, 36], maxZoom: 15 });
    }
    function folgenAnzeigen() { folgenKnopf.textContent = 'Folgen: ' + (folgen ? 'an' : 'aus'); folgenKnopf.setAttribute('aria-pressed', folgen ? 'true' : 'false'); }
    folgenKnopf.onclick = function () {
      folgen = !folgen; folgenAnzeigen();
      if (folgen && fix && karte) karte.setView([fix.breite, fix.laenge], Math.max(karte.getZoom(), 13));
    };

    function popupInhalt(titel, zeilen) {
      var d = el('div', { class: 'kv-popup' }, el('strong', { text: titel }));
      zeilen.forEach(function (z) { if (z) d.appendChild(el('p', { text: z })); });
      return d;
    }

    /* Zwei Orte liegen auf dem Bildschirm übereinander, wenn sie weniger als etwa 36 Pixel auseinander sind (vor dem ersten Zoom: weniger als 60 m). */
    function nahBeieinander(b1, l1, b2, l2) {
      try {
        var p1 = karte.latLngToContainerPoint([b1, l1]), p2 = karte.latLngToContainerPoint([b2, l2]);
        return p1.distanceTo(p2) < 36;
      } catch (e) { return MM.Routen.entfernungKm(b1, l1, b2, l2) < 0.06; }
    }

    function zeichnen() {
      if (!karte) return;
      if (ebenen) ebenen.clearLayers(); else ebenen = L.layerGroup().addTo(karte);
      var pos = fix && kd.route ? MM.Karte.aufRoute(kd.route.punkte, fix.breite, fix.laenge) : null;
      /* geplante Route */
      if (kd.route && kd.route.punkte.length >= 2) {
        L.polyline(kd.route.punkte.map(function (x) { return [x.breite, x.laenge]; }), { color: '#1d5fbf', weight: 5, opacity: .75 }).addTo(ebenen);
      }
      /* gefahrener Weg */
      MM.Karte.wegStuecke(kd.weg).forEach(function (s) {
        if (s.length > 1) L.polyline(s, { color: '#e07b00', weight: 4, opacity: .95 }).addTo(ebenen);
      });
      /* Start, Ziel, Zwischenziele */
      var hatStart = false, hatZiel = false;
      kd.planOrte.forEach(function (o) {
        var s = o.rolle === 'start', z = o.rolle === 'ziel';
        if (s) hatStart = true; if (z) hatZiel = true;
        /* Seit 2.0.123 tragen Zwischenziele ihre Nummer in der Reihenfolge der Fahrt. */
        var nr = o.nr ? String(o.nr) : null;
        L.marker([o.breite, o.laenge], { icon: pin(L, s ? 'kv-start' : (z ? 'kv-ziel' : 'kv-zwischen'), s ? 'S' : (z ? 'Z' : (nr || '•')), 30), title: (nr && !s && !z ? nr + ': ' : '') + o.name, keyboard: true })
          .bindPopup(popupInhalt((s ? 'Start' : (z ? 'Ziel' : 'Zwischenziel' + (nr ? ' ' + nr : ''))) + ': ' + o.name, [])).addTo(ebenen);
      });
      if (kd.route && kd.route.punkte.length >= 2) {
        var p0 = kd.route.punkte[0], p1 = kd.route.punkte[kd.route.punkte.length - 1];
        if (!hatStart) L.marker([p0.breite, p0.laenge], { icon: pin(L, 'kv-start', 'S', 30), title: 'Start der Route' }).bindPopup(popupInhalt('Start der Route', [kd.route.name])).addTo(ebenen);
        if (!hatZiel) L.marker([p1.breite, p1.laenge], { icon: pin(L, 'kv-ziel', 'Z', 30), title: 'Ziel der Route' }).bindPopup(popupInhalt('Ziel der Route', [kd.route.name])).addTo(ebenen);
      }
      /* Wechselpunkte (seit 2.0.116): lila Nummer, Soll-Kurs beim Antippen. Die blaue Linie ist der Soll-Kurs, die orange der gefahrene Weg. */
      if (zeigeWechsel && kd.route && kd.route.wechselpunkte) {
        kd.route.wechselpunkte.forEach(function (w) {
          var zeilen = [];
          if (w.kursHin !== null) zeilen.push('Soll-Kurs hin ' + MM.Routen.gradText(w.kursHin) + ', ' + MM.Routen.smText(w.distanzHinSm) + ' sm');
          zeilen.push(w.kursWeiter !== null ? 'danach Soll-Kurs ' + MM.Routen.gradText(w.kursWeiter) : 'Ziel der Route');
          L.marker([w.breite, w.laenge], { icon: pin(L, 'kv-wp', String(w.nr), 26), title: 'Wechselpunkt ' + w.nr + ': ' + w.name, keyboard: true, zIndexOffset: 150 })
            .bindPopup(popupInhalt('Wechselpunkt ' + w.nr + ' · ' + w.name, zeilen)).addTo(ebenen);
        });
      }
      /* Warnstellen der geplanten Route (seit 2.0.89): rotes „!“, Text beim Antippen */
      if (kd.route && kd.route.warnstellen) {
        kd.route.warnstellen.forEach(function (w) {
          L.marker([w.ort.breite, w.ort.laenge], { icon: pin(L, 'kv-warnung', '!', 32), title: 'Warnung der Planung', keyboard: true, zIndexOffset: 800 })
            .bindPopup(popupInhalt('Warnung der Planung', [MM.Routen.planungWarnungText(w), MM.Routen.PLAN_HINWEIS])).addTo(ebenen);
        });
      }
      /* Wetterpunkte der Route */
      if (zeigeWetter && kd.wetter) {
        var wps = zeigeWechsel && kd.route && kd.route.wechselpunkte ? kd.route.wechselpunkte : [];
        kd.wetter.zeilen.forEach(function (z) {
          if (typeof z.breite !== 'number') return;
          var vorbei = pos && pos.abstandKm <= 3 && z.km < pos.km - 0.5;
          var zeilen = MM.Karte.wetterPunktText(z, kd.wetter.windEinheit);
          var kopf = 'Ankunft ca. ' + MM.Karte.etaText(z.etaMs) + ' Uhr' + (kd.wetter.versatzMin ? ' (' + MM.Karte.verspaetungText(kd.wetter.versatzMin) + ' eingerechnet)' : '') + ', km ' + zahl1(z.km);
          /* Liegt ein Wechselpunkt (Kurs) an derselben Stelle, bleibt er auf der Route und der Wetterpunkt steht daneben (seit 2.0.118). */
          var daneben = wps.some(function (w) { return nahBeieinander(z.breite, z.laenge, w.breite, w.laenge); });
          L.marker([z.breite, z.laenge], { icon: daneben ? pinVersetzt(L, vorbei ? 'kv-vorbei' : 'kv-wetterpunkt', String(z.nr), 30, 24, -24) : pin(L, vorbei ? 'kv-vorbei' : 'kv-wetterpunkt', String(z.nr), 30), title: 'Wetterpunkt ' + z.nr + (z.name ? ': ' + z.name : ''), keyboard: true, zIndexOffset: daneben ? 120 : 0 })
            .bindPopup(popupInhalt('Punkt ' + z.nr + (z.name ? ' · ' + z.name : '') + (vorbei ? ' (schon vorbei)' : ''), [kopf, zeilen.length ? zeilen.join(', ') : 'Dafür gibt es kein Wetter.', 'Prognose, kein Messwert.'])).addTo(ebenen);
        });
      }
      /* Einträge aus dem Logbuch mit Position (seit 2.0.108 nach der Auswahl des Nutzers, mit eigenem Zeichen je Art) */
      KE.filtern(kd.ereignisse, wahl).forEach(function (e) {
        var w = e.istWetter, a = KE.aussehen(e.artName);
        L.marker([e.breite, e.laenge], { icon: pin(L, a.klasse, a.symbol, 28), title: e.artName + ' ' + uhr(e.datum, e.zeit), keyboard: true, zIndexOffset: w ? 200 : 100 })
          .bindPopup(popupInhalt(e.artName + ' · ' + uhr(e.datum, e.zeit), [e.ortName, e.text])).addTo(ebenen);
      });
      /* aktuelle Position */
      posMarker = null; genauigkeitKreis = null;
      if (fix) {
        if (isFinite(fix.genauigkeit) && fix.genauigkeit > 0 && fix.genauigkeit < 500) genauigkeitKreis = L.circle([fix.breite, fix.laenge], { radius: fix.genauigkeit, color: '#1d5fbf', weight: 1, fillOpacity: .1, interactive: false }).addTo(ebenen);
        posMarker = L.marker([fix.breite, fix.laenge], { icon: pin(L, 'kv-position', '', 22), zIndexOffset: 1000, title: 'Du bist hier', keyboard: false, interactive: false }).addTo(ebenen);
      }
    }

    function infoZeichnen() {
      var rumpf = infoRumpf;
      rumpf.textContent = '';
      var pos = fix && kd.route ? MM.Karte.aufRoute(kd.route.punkte, fix.breite, fix.laenge) : null;
      var zeile1 = fix ? 'Position ' + MM.Logbuch.positionText(fix.breite, fix.laenge) + (isFinite(fix.genauigkeit) ? ' (GPS, ±' + Math.round(fix.genauigkeit) + ' m)' : ' (GPS)') : (opt.gpsText ? opt.gpsText() : 'Position wird gesucht …');
      rumpf.appendChild(el('p', { text: zeile1 }));
      if (pos && kd.route) {
        var t = 'Auf der Route bei km ' + zahl1(pos.km) + ' von ' + zahl1(kd.route.laengeKm) + ', ' + (pos.abstandKm < 0.05 ? 'genau auf der Route' : zahl1(pos.abstandKm) + ' km neben der Route');
        var v = MM.Karte.verspaetungMin({ position: pos, kmh: kd.route.kmh, abfahrtMs: kd.route.abfahrtMs, jetztMs: Date.now() });
        if (v !== null) t += ', ' + MM.Karte.verspaetungText(v);
        else if (pos.abstandKm > 3) t += ' (zu weit weg für einen Zeitvergleich)';
        rumpf.appendChild(el('p', { text: t }));
      } else if (!kd.route) {
        rumpf.appendChild(kd.nurRoute ? el('p', { class: 'kv-leise' }, 'Für diesen Tag ist noch keine Route geplant. ', el('a', { href: opt.routeSeite, text: 'Zum Tag' }))
          : el('p', { class: 'kv-leise' }, 'Es gibt noch keine Route. ', el('a', { href: opt.routeSeite, text: 'Route einlesen' })));
      }
      if (kd.nurRoute && kd.route) rumpf.appendChild(el('p', { text: 'Tagesroute ' + kd.route.name + ': ' + zahl1(kd.route.laengeKm) + ' km' }));
      if (kd.nurRoute && kd.veraltet) rumpf.appendChild(el('p', { class: 'kv-warn', text: 'Start oder Ziel des Tages sind seit der Planung andere. Plane den Tag neu.' }));
      var wl = MM.Karte.wegLaengeKm(kd.weg);
      if (wl > 0) rumpf.appendChild(el('p', { text: 'Gefahrener Weg: ' + zahl1(wl) + ' km (Luftlinie von Punkt zu Punkt)' }));
      if (kd.route && !kd.wetter && !kd.nurRoute) rumpf.appendChild(el('p', { class: 'kv-leise' }, 'Für die Route ist noch kein Wetter geholt. ', el('a', { href: opt.routeSeite, text: 'Wetter holen' })));
      if (kd.wetter && !kd.wetter.aktuell) rumpf.appendChild(el('p', { class: 'kv-warn', text: 'Das Wetter der Route gehört zu einer früheren Abfahrt oder Geschwindigkeit. Hole es auf der Seite Route und Wetter neu.' }));
      if (zaehler.fehlt >= 4 && zaehler.lokal === 0) rumpf.appendChild(el('p', { class: 'kv-warn', text: 'Kartenkacheln fehlen hier (kein Netz und keine Offline-Karte für dieses Gebiet). Die Linien und Punkte stimmen trotzdem.' }));
      var hatWp = !!(kd.route && kd.route.wechselpunkte && kd.route.wechselpunkte.length), hatKw = kd.ereignisse.some(function (e) { return MM.Logbuch.istKurswechselArt(e.artName); });
      rumpf.appendChild(el('p', { class: 'kv-legende' },
        el('span', { class: 'kv-pin kv-start klein', text: 'S' }), ' Start ', el('span', { class: 'kv-pin kv-ziel klein', text: 'Z' }), ' Ziel ',
        el('span', { class: 'kv-pin kv-wetterpunkt klein', text: '1' }), ' Wetterpunkt ', el('span', { class: 'kv-pin kv-wetterjetzt klein', text: 'W' }), ' Wetter jetzt ',
        el('span', { class: 'kv-pin kv-art-stoerung klein', text: '!' }), ' Störung ', el('span', { class: 'kv-pin kv-art-motor klein', text: 'M' }), ' Motor ',
        hatWp ? el('span', { class: 'kv-pin kv-wp klein', text: '1' }) : null, hatWp ? ' Wechselpunkt ' : null,
        hatKw ? el('span', { class: 'kv-pin kv-art-kurs klein zwei', text: 'KW' }) : null, hatKw ? ' Kurswechsel ' : null,
        el('span', { class: 'kv-pin kv-art-sonst klein', text: '•' }), ' anderes Ereignis ',
        el('span', { class: 'kv-linie kv-linie-plan' }), ' Soll-Kurs (geplant) ', el('span', { class: 'kv-linie kv-linie-weg' }), ' gefahren'));
      /* Die Zeile am unteren Rand: Position und gefahrener Weg in kurzer Form, antippen klappt alles auf. */
      var kurz = fix ? MM.Logbuch.positionText(fix.breite, fix.laenge) + (isFinite(fix.genauigkeit) ? ' (±' + Math.round(fix.genauigkeit) + ' m)' : '') : (opt.gpsText ? opt.gpsText() : 'Position wird gesucht …');
      if (wl > 0) kurz += ' · gefahren ' + zahl1(wl) + ' km';
      infoKopf.textContent = kurz + '  ▲';
      zuletztAngezeigt = pos;
    }

    /* Seezeichen ein- und ausschalten (nur Wasserfahrzeuge). */
    function seeAnwenden() {
      if (!karte || !wasser) return;
      if (wahl.seezeichen && !seeSchicht) seeSchicht = kachelSchicht(L, opt.ablage, zaehler, null, true).addTo(karte);
      else if (!wahl.seezeichen && seeSchicht) { karte.removeLayer(seeSchicht); seeSchicht = null; }
    }

    /* Das Feld „Ereignisse“: Haken je Art, Seezeichen, und wo die Auswahl gelten soll. */
    function panelZeichnen() {
      ereignisPanel.textContent = '';
      var hatWpPanel = !!(kd.route && kd.route.wechselpunkte && kd.route.wechselpunkte.length), hatWetterPanel = !!(kd.wetter && kd.wetter.zeilen && kd.wetter.zeilen.length);
      if (hatWpPanel || hatWetterPanel) {
        ereignisPanel.appendChild(el('h2', { text: 'Punkte der Route' }));
        function schalter(id, text, an, beiAenderung) {
          var cb = el('input', { type: 'checkbox', id: id }); cb.checked = an;
          cb.onchange = function () { beiAenderung(cb.checked); zeichnen(); infoZeichnen(); };
          return el('p', null, cb, ' ', el('label', { for: id, text: text }));
        }
        if (hatWetterPanel) ereignisPanel.appendChild(schalter('kv-zeige-wetter', 'Wetterpunkte', zeigeWetter, function (v) { zeigeWetter = v; }));
        if (hatWpPanel) ereignisPanel.appendChild(schalter('kv-zeige-wechsel', 'Wechselpunkte', zeigeWechsel, function (v) { zeigeWechsel = v; }));
        ereignisPanel.appendChild(el('p', { class: 'kv-leise', text: 'Liegen ein Wetterpunkt und ein Wechselpunkt an derselben Stelle, steht der Wetterpunkt daneben.' }));
      }
      ereignisPanel.appendChild(el('h2', { text: 'Ereignisse auf der Karte' }));
      var liste = KE.artenListe(kd.ereignisse, wahl);
      if (!liste.length) ereignisPanel.appendChild(el('p', { class: 'kv-leise', text: 'In dieser Aktivität gibt es noch keine Einträge mit Position.' }));
      var ul = el('ul', { class: 'kv-arten' });
      liste.forEach(function (x, i) {
        var id = 'kv-art-' + i, cb = el('input', { type: 'checkbox', id: id });
        cb.checked = x.an;
        cb.onchange = function () { wahl = KE.umschalten(wahl, x.name, cb.checked); zeichnen(); };
        var a = KE.aussehen(x.name);
        ul.appendChild(el('li', null, cb, ' ', el('span', { class: 'kv-pin klein ' + a.klasse, text: a.symbol }), ' ', el('label', { for: id, text: x.name + (x.anzahl ? ' (' + x.anzahl + ')' : '') })));
      });
      ereignisPanel.appendChild(ul);
      if (wasser) {
        var sid = 'kv-see', sc = el('input', { type: 'checkbox', id: sid });
        sc.checked = !!wahl.seezeichen;
        sc.onchange = function () { wahl = { aus: wahl.aus, seezeichen: sc.checked }; seeAnwenden(); };
        ereignisPanel.appendChild(el('p', null, sc, ' ', el('label', { for: sid, text: 'Seezeichen (Tonnen, Leuchtfeuer, Häfen)' })));
        ereignisPanel.appendChild(el('p', { class: 'kv-leise', text: 'Nur zur Information. Keine amtliche Karte, keine Wassertiefen. Sie ersetzen weder deine Sorgfaltspflicht noch amtliche nautische Unterlagen.' }));
      }
      if (opt.wahlSpeichern) {
        var status = el('p', { class: 'kv-leise', role: 'status', text: wahlEigene ? 'Für diese Aktivität gilt eine eigene Auswahl.' : 'Es gilt deine Vorauswahl für alle Aktivitäten.' });
        ereignisPanel.appendChild(el('p', { class: 'knopfzeile' },
          el('button', { class: 'knopf klein', type: 'button', text: 'Nur für diese Aktivität speichern', onclick: function () {
            opt.wahlSpeichern.aktivitaet(wahl).then(function () { wahlEigene = true; status.textContent = 'Gespeichert: gilt für diese Aktivität.'; }, function () { status.textContent = 'Das hat nicht geklappt.'; });
          } }),
          el('button', { class: 'knopf leise klein', type: 'button', text: 'Als Vorauswahl für alle Aktivitäten speichern', onclick: function () {
            opt.wahlSpeichern.generell(wahl).then(function () { wahlEigene = false; status.textContent = 'Gespeichert: gilt als Vorauswahl für alle Aktivitäten.'; }, function () { status.textContent = 'Das hat nicht geklappt.'; });
          } })));
        ereignisPanel.appendChild(status);
      }
      ereignisPanel.appendChild(el('p', { class: 'knopfzeile' }, el('button', { class: 'knopf leise klein', type: 'button', text: 'Schließen', onclick: function () { ereignisPanel.hidden = true; ereignisKnopf.setAttribute('aria-expanded', 'false'); } })));
    }

    /* Verspätung hat sich geändert: Die Wetterpunkte werden für die neue Ankunftszeit gerechnet (höchstens einmal pro Minute). */
    function verspaetungPruefen() {
      if (!opt.wetterNeu || !kd.route || !kd.wetter || !fix) return;
      if (Date.now() - letzteNeuRechnung < 60000) return;
      var pos = MM.Karte.aufRoute(kd.route.punkte, fix.breite, fix.laenge);
      var v = MM.Karte.verspaetungMin({ position: pos, kmh: kd.route.kmh, abfahrtMs: kd.route.abfahrtMs, jetztMs: Date.now() });
      if (v === null) return;
      v = Math.round(v / 5) * 5;
      if (Math.abs(v - verspaetungAngewandt) < 10) return;
      letzteNeuRechnung = Date.now();
      opt.wetterNeu(v).then(function (r) {
        if (!r || !r.zeilen) return;
        verspaetungAngewandt = v;
        kd.wetter.zeilen = r.zeilen; kd.wetter.versatzMin = r.versatzMin;
        zeichnen(); infoZeichnen();
      }, function () { /* die alten Werte bleiben */ });
    }

    function neueDatenHolen() { if (opt.neuLaden) opt.neuLaden().then(function (nd) { if (nd) neueDaten(nd); }); }
    function neueDaten(nd) { kd = nd; verspaetungAngewandt = nd.wetter ? (nd.wetter.versatzMin || 0) : 0; zeichnen(); infoZeichnen(); }

    return {
      element: wurzel,
      zaehler: zaehler,
      start: function () {
        karte = L.map(kartenFlaeche, { zoomControl: true, attributionControl: true, preferCanvas: false, worldCopyJump: false, maxBoundsViscosity: 1 });
        karte.setMaxBounds([[-85, -180], [85, 180]]);
        kachelSchicht(L, opt.ablage, zaehler, function () { infoZeichnen(); }).addTo(karte);
        seeAnwenden();
        karte.on('dragstart', function () { if (folgen) { folgen = false; folgenAnzeigen(); } });
        karte.on('zoomend', function () { if (zeigeWetter && zeigeWechsel && kd.wetter && kd.route && kd.route.wechselpunkte && kd.route.wechselpunkte.length) zeichnen(); });
        zeichnen(); infoZeichnen();
        if (fix) karte.setView([fix.breite, fix.laenge], 13); else alles();
        global.setTimeout(function () { if (karte) karte.invalidateSize(); }, 150);
      },
      position: function (f) {
        fix = f;
        if (!karte) return;
        if (f) {
          if (posMarker) { posMarker.setLatLng([f.breite, f.laenge]); if (genauigkeitKreis) { genauigkeitKreis.setLatLng([f.breite, f.laenge]); if (isFinite(f.genauigkeit)) genauigkeitKreis.setRadius(f.genauigkeit); } }
          else zeichnen();
          if (folgen) karte.panTo([f.breite, f.laenge], { animate: true });
        }
        infoZeichnen(); verspaetungPruefen();
      },
      neueDaten: neueDaten,
      /* Seit 2.0.111: nur den gefahrenen Weg neu setzen und zeichnen (ohne die Daten neu zu laden), damit der Strich beim Fahren mitwächst. */
      wegNeu: function (w) { if (!karte || !w) return; kd.weg = w; zeichnen(); },
      aktualisieren: neueDatenHolen,
      meldung: melden,
      alles: alles,
      /* Seit 2.0.104: nach dem Einblenden im Cockpit-Wechsel die Größe neu lesen, ohne die Karte neu zu bauen. */
      groesse: function () { if (karte) { karte.invalidateSize(); if (folgen && fix) karte.panTo([fix.breite, fix.laenge], { animate: false }); } },
      zerstoeren: function () { if (karte) { try { karte.remove(); } catch (e) { /* nichts zu tun */ } karte = null; } }
    };
  }

  /*
   * Karte für „Person über Bord“ (seit 2.0.130). opt: { ablage, beiGezogen(position) }.
   * zeichnen({ anfang, person, gesichtet, boot, weg: [[breite, laenge]], bereich: Ergebnis von MM.Seemann.suchbereich, offen })
   * So nah wie möglich, Boot und Person bleiben sichtbar. Wer selbst verschiebt, schaltet das ab („Boot und Person“ schaltet es wieder ein).
   */
  function mobKarte(opt) {
    var L = global.L, karte = null, ebenen = null, folgen = true, letzte = null, zieht = false, ausschnitt = '';
    if (!L || !L.map) return { element: el('p', { class: 'fehlerkasten', text: 'Die Karte konnte nicht geladen werden. Entfernung und Kurs oben gelten trotzdem.' }), start: function () {}, zeichnen: function () {}, zerstoeren: function () {} };
    var flaeche = el('div', { class: 'mob-karte', role: 'application', 'aria-label': 'Karte Person über Bord' });
    var knopfNah = el('button', { class: 'knopf leise klein', type: 'button', text: 'Boot und Person', onclick: function () { folgen = true; ausschnitt = ''; zeichnen(letzte); } });
    var knopfAlles = el('button', { class: 'knopf leise klein', type: 'button', text: 'Suchbereich zeigen', onclick: function () {
      if (!karte || !letzte) return;
      folgen = false;
      var b = letzte.bereich, p = [[letzte.person.breite, letzte.person.laenge]];
      if (b.art === 'faecher') [b.links, b.mitte, b.rechts].forEach(function (q) { p.push([q.breite, q.laenge]); });
      else p = L.latLng(b.mittel.breite, b.mittel.laenge).toBounds(b.radius * 2);
      karte.fitBounds(p, { padding: [24, 24], maxZoom: MM.Karte.QUELLE.maxZoom });
    } });
    var wurzel = el('div', null, flaeche, el('p', { class: 'knopfzeile' }, knopfNah, knopfAlles));
    function zeichnen(d) {
      if (d) letzte = d;
      if (!karte || !letzte || zieht) return;
      d = letzte;
      ebenen.clearLayers();
      var b = d.bereich, p = [d.person.breite, d.person.laenge];
      var stil = { color: '#c62828', weight: 2, interactive: false };
      if (b.art === 'faecher') {
        L.polygon([p, [b.links.breite, b.links.laenge], [b.mitte.breite, b.mitte.laenge], [b.rechts.breite, b.rechts.laenge]], Object.assign({ fillOpacity: .18 }, stil))
          .bindTooltip('geschätzt', { permanent: true, direction: 'bottom', offset: [0, 20] }).addTo(ebenen);
        L.polyline([p, [b.mitte.breite, b.mitte.laenge]], Object.assign({ dashArray: '8 6' }, stil)).addTo(ebenen);
      } else {
        L.circle([b.mittel.breite, b.mittel.laenge], Object.assign({ radius: b.radius, fillOpacity: .18 }, stil)).bindTooltip('geschätzt', { permanent: true, direction: 'bottom', offset: [0, 20] }).addTo(ebenen);
      }
      if (d.weg && d.weg.length > 1) L.polyline(d.weg.map(function (q) { return [q[0], q[1]]; }), { color: '#e07b00', weight: 4, interactive: false }).addTo(ebenen);
      if (d.gesichtet) L.marker([d.anfang.breite, d.anfang.laenge], { icon: pin(L, 'kv-vorbei', '1', 26), title: 'Ursprüngliche Stelle', interactive: false }).addTo(ebenen);
      var m = L.marker(p, { icon: pin(L, 'kv-warnung', 'P', 32), title: 'Person', draggable: !!(d.offen && d.gesichtet && opt.beiGezogen), zIndexOffset: 900 }).addTo(ebenen);
      m.on('dragstart', function () { zieht = true; });
      m.on('dragend', function () { zieht = false; var q = m.getLatLng(); opt.beiGezogen({ breite: q.lat, laenge: q.lng }); });
      if (d.boot) L.marker([d.boot.breite, d.boot.laenge], { icon: pin(L, 'kv-position', '', 22), title: 'Boot', zIndexOffset: 1000, interactive: false }).addTo(ebenen);
      if (folgen) {
        var punkte = [p].concat(d.boot ? [[d.boot.breite, d.boot.laenge]] : []);
        var neu = punkte.map(function (q) { return q[0].toFixed(4) + ',' + q[1].toFixed(4); }).join(';');
        if (neu !== ausschnitt) { ausschnitt = neu; karte.fitBounds(L.latLngBounds(punkte), { padding: [40, 40], maxZoom: MM.Karte.QUELLE.maxZoom, animate: false }); }
      }
    }
    return {
      element: wurzel,
      start: function () {
        karte = L.map(flaeche, { zoomControl: true, attributionControl: true });
        kachelSchicht(L, opt.ablage, { lokal: 0, netz: 0, fehlt: 0 }).addTo(karte);
        L.control.scale({ position: 'topright', imperial: false, maxWidth: 140 }).addTo(karte);
        ebenen = L.layerGroup().addTo(karte);
        karte.setView([50, 10], 5);
        karte.on('dragstart', function () { folgen = false; });
        global.setTimeout(function () { if (karte) { karte.invalidateSize(); ausschnitt = ''; zeichnen(); } }, 150);
      },
      zeichnen: zeichnen,
      zerstoeren: function () { if (karte) { try { karte.remove(); } catch (e) { /* nichts zu tun */ } karte = null; } }
    };
  }

  MM.Kartenansicht = { aufbauen: aufbauen, mobKarte: mobKarte };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
