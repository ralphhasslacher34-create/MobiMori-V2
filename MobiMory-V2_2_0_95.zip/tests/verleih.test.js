'use strict';
/* 2.0.74 (Bau B, Dienst 13f-1): Verleih. Gäste nach Stufe und Geräten, Nachweis des Halters, Prüfung von Zeitraum und Fristen, Stornieren.
   Dienst mit nachgebauter Datenbank, Regeln und Daten-Schicht der App ohne Dienst. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'personen', 'orte', 'gebiete',
  'ortssuche', 'sicherung', 'speicher', 'hilfen', 'logbuch', 'status', 'reiseorte', 'konto', 'freigaben', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const F = MM.Freigaben;

const APP = 'https://app.example.org';
const PW = 'Sehr-sicheres-Passwort-1';
const TAG = 24 * 60 * 60 * 1000;
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung() { return { DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }; }
function uhr() { const u = { t: Date.UTC(2026, 10, 11, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
async function ruf(env, u, methode, weg, body, token) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
  return { status: r.status, json: await r.json() };
}
/* Anmelden per Code mit Gerätekennung, wie es die App tut. */
async function anmelden(env, u, email, geraet) {
  u.t += 13 * 60 * 1000;
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email });
  const r = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode, geraet });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  return r.json.token;
}
function stufeSetzen(env, email, stufe) {
  const n = env.DB.roh.prepare('SELECT id FROM nutzer WHERE email = ?').get(email);
  env.DB.roh.prepare('INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) VALUES (?, ?, ?, ?)').run(n.id, stufe, null, 1);
}
const satz = (tabelle, o) => ({ tabelle, id: o.id, basis: 0, nutzlast: JSON.stringify(o) });

/* Besitzer mit n Geräten (eigene Sitzungen), einem Fahrzeug beim Dienst und der gewünschten Stufe (null = Testwoche, 'basic' = Testwoche vorbei). */
async function besitzer(env, u, mail, geraete, stufe) {
  const toks = [];
  for (let i = 0; i < geraete; i++) toks.push(await anmelden(env, u, mail, 'MobiMory 2.0.74 #2000000' + i));
  const s = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [
    satz('fahrzeuge', { id: 'fz-1', datenraumId: '@', art: 'wohnmobil', erstelltAm: 1 }),
    satz('eintraege', { id: 'en-1', fahrzeugId: 'fz-1', nr: 1, werte: { bezeichnung: 'Mein Wohnmobil' }, erstelltAm: 1 })
  ] }, toks[0]);
  assert.equal(s.status, 200, JSON.stringify(s.json));
  if (stufe === 'basic') u.t += 8 * TAG;
  else if (stufe) stufeSetzen(env, mail, stufe);
  return toks[0];
}
const BEF = { nachweisArt: 'Führerschein', nachweisBis: '', bestaetigt: true };
function einladen(env, u, tok, mail, extra) {
  return ruf(env, u, 'POST', '/freigabe/einladen', Object.assign({ fahrzeugId: 'fz-1', email: mail, bis: '2027-03-31' }, BEF, extra || {}), tok);
}

/* ---------- Gäste nach Stufe und Geräten ---------- */

test('Gäste: Basic hat keine Gäste, die Liste sagt es dem Besitzer, Testwoche und Mittel dürfen', async () => {
  const env = umgebung(), u = uhr();
  const tok = await besitzer(env, u, 'basic@example.org', 1, 'basic');
  const e = await einladen(env, u, tok, 'g1@example.org');
  assert.equal(e.status, 403); assert.match(e.json.error, /ab der Stufe Mittel/); assert.equal(e.json.stufe, 'basic');
  const l = await ruf(env, u, 'GET', '/freigabe/liste', undefined, tok);
  assert.equal(l.json.verleih.erlaubt, false); assert.equal(l.json.verleih.stufe, 'basic');
  assert.match(F.gaesteText(l.json.verleih), /ab der Stufe Mittel/);
  /* Testwoche läuft auf Mittel-Niveau */
  const env2 = umgebung(), u2 = uhr();
  const t2 = await besitzer(env2, u2, 'test@example.org', 1, null);
  assert.equal((await einladen(env2, u2, t2, 'g1@example.org')).status, 200);
  /* bezahlt: Mittel */
  const env3 = umgebung(), u3 = uhr();
  const t3 = await besitzer(env3, u3, 'mittel@example.org', 1, 'mittel');
  assert.equal((await einladen(env3, u3, t3, 'g1@example.org')).status, 200);
});

test('Gäste: Anzahl = Geräte der Stufe minus eigene Geräte (Mittel 4); ein Gast zählt einmal; Stornieren macht einen Platz frei', async () => {
  const env = umgebung(), u = uhr();
  const tok = await besitzer(env, u, 'mittel@example.org', 2, 'mittel');
  assert.equal((await einladen(env, u, tok, 'g1@example.org')).status, 200);
  const zweite = await einladen(env, u, tok, 'g2@example.org');
  assert.equal(zweite.status, 200);
  const l = await ruf(env, u, 'GET', '/freigabe/liste', undefined, tok);
  assert.deepEqual(l.json.verleih.gaeste, { grenze: 2, eigene: 2, belegt: 2, frei: 0 });
  assert.match(F.gaesteText(l.json.verleih), /2 von 2 Plätzen belegt/);
  const dritte = await einladen(env, u, tok, 'g3@example.org');
  assert.equal(dritte.status, 409); assert.match(dritte.json.error, /Die 2 Plätze für Gäste sind vergeben/);
  /* derselbe Gast noch einmal (ersetzt die alte Freigabe) braucht keinen neuen Platz */
  assert.equal((await einladen(env, u, tok, 'g1@example.org', { bis: '2027-02-28' })).status, 200);
  /* Stornieren macht Platz */
  assert.equal((await ruf(env, u, 'POST', '/freigabe/widerrufen', { id: zweite.json.id }, tok)).status, 200);
  assert.equal((await einladen(env, u, tok, 'g3@example.org')).status, 200);
});

test('Gäste: nutzt der Besitzer alle Geräte der Stufe selbst, bleibt kein Platz; Voll hat zehn Geräte, Entwickler keine Grenze', async () => {
  const env = umgebung(), u = uhr();
  const tok = await besitzer(env, u, 'voll4@example.org', 4, 'mittel');
  const e = await einladen(env, u, tok, 'g1@example.org');
  assert.equal(e.status, 409); assert.match(e.json.error, /Alle 4 Geräte der Stufe Mittel nutzt du selbst/);
  /* Voll: 10 Geräte minus 3 eigene = 7 Plätze */
  const env2 = umgebung(), u2 = uhr();
  const t2 = await besitzer(env2, u2, 'voll@example.org', 3, 'voll');
  assert.deepEqual((await ruf(env2, u2, 'GET', '/freigabe/liste', undefined, t2)).json.verleih.gaeste, { grenze: 7, eigene: 3, belegt: 0, frei: 4 + 3 });
  /* Entwickler: keine Grenze */
  const env3 = umgebung(), u3 = uhr();
  const t3 = await besitzer(env3, u3, 'entw@example.org', 3, 'entwickler');
  assert.deepEqual((await ruf(env3, u3, 'GET', '/freigabe/liste', undefined, t3)).json.verleih.gaeste, { grenze: null, eigene: 3, belegt: 0, frei: null });
  for (let i = 0; i < 6; i++) assert.equal((await einladen(env3, u3, t3, 'g' + i + '@example.org')).status, 200);
  assert.match(F.gaesteText({ erlaubt: true, gaeste: { grenze: null, belegt: 6 } }), /keine Grenze/);
});

test('Gäste: eine abgelaufene oder nie angenommene Einladung zählt nicht mehr', async () => {
  const env = umgebung(), u = uhr();
  const tok = await besitzer(env, u, 'mittel@example.org', 3, 'mittel');
  assert.equal((await einladen(env, u, tok, 'g1@example.org')).status, 200);
  assert.equal((await ruf(env, u, 'GET', '/freigabe/liste', undefined, tok)).json.verleih.gaeste.belegt, 1);
  u.t += 15 * TAG; /* die Einladung gilt 14 Tage und wurde nicht angenommen */
  const l = await ruf(env, u, 'GET', '/freigabe/liste', undefined, tok);
  assert.equal(l.status, 200);
  assert.equal(l.json.verleih.gaeste.belegt, 0);
});

/* ---------- Nachweis des Halters ---------- */

test('Nachweis: ohne Bestätigung, ohne Art und mit abgelaufenem Nachweis gibt es keinen Verleih; gespeichert wird nur Art, gültig bis und der Tag', async () => {
  const env = umgebung(), u = uhr();
  const tok = await besitzer(env, u, 'mittel@example.org', 1, 'mittel');
  let r = await einladen(env, u, tok, 'g@example.org', { bestaetigt: false });
  assert.equal(r.status, 400); assert.equal(r.json.feld, 'bestaetigt'); assert.match(r.json.error, /gesehen hast/);
  r = await einladen(env, u, tok, 'g@example.org', { bestaetigt: undefined });
  assert.equal(r.json.feld, 'bestaetigt');
  r = await einladen(env, u, tok, 'g@example.org', { nachweisArt: '  ' });
  assert.equal(r.json.feld, 'nachweisArt');
  r = await einladen(env, u, tok, 'g@example.org', { nachweisArt: 'x'.repeat(61) });
  assert.equal(r.json.feld, 'nachweisArt');
  r = await einladen(env, u, tok, 'g@example.org', { nachweisBis: '31.12.2026' });
  assert.equal(r.json.feld, 'nachweisBis');
  r = await einladen(env, u, tok, 'g@example.org', { nachweisBis: '2027-03-30' });
  assert.equal(r.status, 400); assert.equal(r.json.feld, 'nachweisBis'); assert.match(r.json.error, /läuft am 2027-03-30 ab/);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM freigabe').get().n, 0, 'nichts wurde angelegt');
  r = await einladen(env, u, tok, 'g@example.org', { nachweisBis: '2027-03-31', nachweisArt: ' Bootsführerschein ' });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  const z = env.DB.roh.prepare('SELECT nachweis_art, nachweis_bis, bestaetigt_am FROM freigabe').get();
  assert.equal(z.nachweis_art, 'Bootsführerschein'); assert.equal(z.nachweis_bis, '2027-03-31'); assert.equal(z.bestaetigt_am, u.t);
  const l = await ruf(env, u, 'GET', '/freigabe/liste', undefined, tok);
  assert.deepEqual([l.json.gegeben[0].nachweisArt, l.json.gegeben[0].nachweisBis, l.json.gegeben[0].bestaetigtAm], ['Bootsführerschein', '2027-03-31', '2026-11-11']);
});

test('Nachweis: ohne Ablaufdatum geht es auch, der Gast sieht den Nachweis nicht', async () => {
  const env = umgebung(), u = uhr();
  const tok = await besitzer(env, u, 'mittel@example.org', 1, 'mittel');
  const gast = await anmelden(env, u, 'g@example.org', 'MobiMory 2.0.74 #30000000');
  const e = await einladen(env, u, tok, 'g@example.org');
  assert.equal(e.status, 200);
  assert.equal(env.DB.roh.prepare('SELECT nachweis_bis FROM freigabe').get().nachweis_bis, null);
  assert.equal((await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, gast)).status, 200);
  const gl = await ruf(env, u, 'GET', '/freigabe/liste', undefined, gast);
  assert.equal(JSON.stringify(gl.json.erhalten).includes('Führerschein'), false);
  assert.equal(JSON.stringify(gl.json.erhalten).includes('nachweis'), false);
});

/* ---------- Server-Dateien ---------- */

test('Dienst 13f-1: Version, drei SQL-Zeilen, die auch im Schema stehen, Gesundheit meldet den Verleih, Anleitung vorhanden', async () => {
  const d = await laden();
  assert.equal(d.VERSION, '13f-11');
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13f-1.sql'), 'utf8').trim().split('\n');
  assert.equal(sql.length, 3);
  sql.forEach((z) => assert.match(z, /^ALTER TABLE freigabe ADD COLUMN (nachweis_art TEXT|nachweis_bis TEXT|bestaetigt_am INTEGER);$/));
  const schema = fs.readFileSync(path.join(__dirname, '..', 'server', 'schema.sql'), 'utf8');
  sql.forEach((z) => assert.ok(schema.includes(z), 'im Schema: ' + z));
  assert.ok(fs.readFileSync(path.join(__dirname, '..', 'server', 'EINRICHTUNG.md'), 'utf8').includes('Update auf 13f-1'));
  const env = umgebung(), u = uhr();
  const g = await ruf(env, u, 'GET', '/gesundheit');
  assert.equal(g.json.version, '13f-11'); assert.equal(g.json.verleih, true);
});

test('Dienst 13f-1: Fehlt die SQL-Zeile, sagt der Dienst es in einfachen Worten, statt abzustürzen', async () => {
  const env = umgebung(), u = uhr();
  const tok = await besitzer(env, u, 'mittel@example.org', 1, 'mittel');
  env.DB.roh.exec('ALTER TABLE freigabe DROP COLUMN nachweis_art; ALTER TABLE freigabe DROP COLUMN nachweis_bis; ALTER TABLE freigabe DROP COLUMN bestaetigt_am;');
  const e = await einladen(env, u, tok, 'g@example.org');
  assert.equal(e.status, 503); assert.match(e.json.error, /SQL-Zeile/);
  const l = await ruf(env, u, 'GET', '/freigabe/liste', undefined, tok);
  assert.equal(l.status, 200); assert.equal(l.json.verleih.spalten, false);
  assert.equal((await ruf(env, u, 'GET', '/gesundheit')).json.verleih, false);
});

/* ---------- Regeln der App ---------- */

test('Einladung prüfen: Nachweisart und Bestätigung sind Pflicht, „gültig bis“ darf nicht vor dem Ende liegen', () => {
  const heute = '2026-11-11';
  const ok = F.einladung({ fahrzeugId: 'a', email: 'g@example.org', bis: '2027-03-31', nachweisArt: ' Führerschein ', bestaetigt: true }, heute);
  assert.equal(ok.ok, true); assert.equal(ok.werte.nachweisArt, 'Führerschein'); assert.equal(ok.werte.bestaetigt, true); assert.equal('nachweisBis' in ok.werte, false);
  const ohne = F.einladung({ fahrzeugId: 'a', email: 'g@example.org', bis: '2027-03-31' }, heute);
  assert.deepEqual(Object.keys(ohne.fehler).sort(), ['bestaetigt', 'nachweisArt']);
  assert.match(ohne.fehler.bestaetigt, /Ohne diese Bestätigung gibt es keinen Verleih/);
  assert.equal(F.einladung({ fahrzeugId: 'a', email: 'g@example.org', bis: '2027-03-31', nachweisArt: 'F', bestaetigt: 'ja' }, heute).ok, false, 'nur ein echtes „ja“ zählt');
  const frueh = F.einladung({ fahrzeugId: 'a', email: 'g@example.org', bis: '2027-03-31', nachweisArt: 'F', nachweisBis: '2027-03-30', bestaetigt: true }, heute);
  assert.match(frueh.fehler.nachweisBis, /läuft am 2027-03-30 ab/);
  assert.equal(F.einladung({ fahrzeugId: 'a', email: 'g@example.org', bis: '2027-03-31', nachweisArt: 'F', nachweisBis: '2027-03-31', bestaetigt: true }, heute).ok, true);
  assert.match(F.einladung({ fahrzeugId: 'a', email: 'g@example.org', bis: '2027-03-31', nachweisArt: 'F', nachweisBis: 'morgen', bestaetigt: true }, heute).fehler.nachweisBis, /als Tag/);
});

test('Prüfung vor dem Verleih: eigene Planung zuerst, andere Verleihe, Fristen; storniert, vorbei, widerrufen und dieselbe Person zählen nicht', () => {
  const p = { ab: '2026-12-05', bis: '2026-12-20', email: 'g@example.org',
    aktivitaeten: [
      { name: 'Sommertörn', vonDatum: '2026-12-01', bisDatum: '2026-12-10', status: 'geplant' },
      { name: 'Storniert', vonDatum: '2026-12-06', bisDatum: '2026-12-07', status: 'storniert' },
      { name: 'Alt', vonDatum: '2026-12-06', bisDatum: '2026-12-07', status: 'vorbei' },
      { name: 'Später', vonDatum: '2026-12-21', bisDatum: '2026-12-22', status: 'geplant' }
    ],
    freigaben: [
      { email: 'anderer@example.org', ab: '2026-12-18', bis: '2027-01-05', status: 'aktiv' },
      { email: 'G@example.org', ab: '2026-12-06', bis: '2026-12-08', status: 'aktiv' },
      { email: 'weg@example.org', ab: '2026-12-06', bis: '2026-12-08', status: 'widerrufen' },
      { email: 'alt@example.org', ab: '2026-12-06', bis: '2026-12-08', status: 'abgelaufen' }
    ],
    fristen: [
      { bezeichnung: 'Hauptuntersuchung', status: 'faellig', text: 'Zeit: fällig am 2026-12-10, also im Zeitraum', wirkung: 'sperre' },
      { bezeichnung: 'Ölwechsel', status: 'ok', text: '' },
      { bezeichnung: 'Gasprüfung', status: 'ueberfaellig', text: 'Zeit: schon seit 2026-10-01 überfällig', wirkung: 'warnen' },
      { bezeichnung: 'Unbekannt', status: 'unbekannt', text: '' }
    ] };
  const r = F.verleihHinweise(p);
  assert.equal(r.ok, false);
  assert.deepEqual(r.liste.map((x) => x.art), ['planung', 'verliehen', 'frist', 'frist']);
  assert.match(r.liste[0].text, /„Sommertörn“.*Deine Planung hat Vorrang/);
  assert.match(r.liste[1].text, /anderer@example\.org/);
  assert.match(r.liste[2].text, /Frist wird fällig: Hauptuntersuchung.*sperrt das Fahrzeug/);
  assert.match(r.liste[3].text, /Frist überfällig: Gasprüfung/); assert.ok(!/sperrt|schränkt/.test(r.liste[3].text));
  assert.equal(F.verleihHinweise({ ab: '2026-12-05', bis: '2026-12-20', email: 'g@example.org', aktivitaeten: [], freigaben: [], fristen: [] }).ok, true);
  /* Aneinanderstoßen zählt als Überschneidung (volle Tage) */
  assert.equal(F.verleihHinweise({ ab: '2026-12-10', bis: '2026-12-20', aktivitaeten: [{ name: 'X', vonDatum: '2026-12-01', bisDatum: '2026-12-10', status: 'geplant' }] }).liste.length, 1);
  assert.equal(F.verleihHinweise({ ab: '2026-12-11', bis: '2026-12-20', aktivitaeten: [{ name: 'X', vonDatum: '2026-12-01', bisDatum: '2026-12-10', status: 'geplant' }] }).ok, true);
});

/* ---------- Daten-Schicht der App ---------- */

test('App: Prüfung vor dem Verleih liest Planung und Fristen des Fahrzeugs, warnt und sperrt nichts; Nachweisarten kommen aus den Anforderungen', async () => {
  let n = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(2026, 10, 3, 12, 0, 0).getTime() + (n++) * 1000).toISOString() });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const arten = await d.aktivitaetsartenListe();
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'] })).id;
  const a = await d.aktivitaetAnlegen({ bezeichnung: 'Sommertörn', artId: arten.find((x) => x.aktuell.werte.bezeichnung === 'Törn').objekt.id, fahrzeugId: wm, vonDatum: '2026-12-01', bisDatum: '2026-12-10', verantwortlichId: anna });
  assert.equal(a.ok, true, JSON.stringify(a));
  const fr = await d.fristAnlegen(wm, null, { kategorie: 'pruefung', bezeichnung: 'Hauptuntersuchung', kalenderWert: 2, kalenderEinheit: 'jahre', wirkung: 'sperre', vorwarnTage: 30, zuletztAm: '2024-12-10' });
  assert.equal(fr.ok, true, JSON.stringify(fr));
  const roh = { fahrzeugId: wm, email: 'g@example.org', ab: '2026-12-05', bis: '2026-12-20' };
  const h = await d.verleihPruefen(roh);
  assert.equal(h.ok, false);
  assert.deepEqual(h.liste.map((x) => x.art), ['planung', 'frist']);
  assert.match(h.liste[1].text, /Hauptuntersuchung/);
  /* anderes Fahrzeug, anderer Zeitraum: nichts zu melden */
  assert.equal((await d.verleihPruefen({ fahrzeugId: boot, email: 'g@example.org', ab: '2026-12-05', bis: '2026-12-20' })).ok, true);
  assert.equal((await d.verleihPruefen({ fahrzeugId: wm, email: 'g@example.org', ab: '2027-01-15', bis: '2027-01-20' })).liste.some((x) => x.art === 'planung'), false);
  /* Nachweisarten: ohne Anforderungen die üblichen, immer mit „Anderer Nachweis“ */
  assert.deepEqual(await d.verleihNachweisarten(wm), ['Führerschein', 'Bootsführerschein', 'Anderer Nachweis']);
});

test('App-Seite: Verleih zeigt Gäste-Zeile, Nachweis, Bestätigung, „Trotzdem verleihen“, „Absage“ und „Stornieren“; die Kontrollpapiere nicht', () => {
  const src = fs.readFileSync(path.join(__dirname, '..', 'js', 'ansicht.js'), 'utf8');
  ['Prüfen und Einladung senden', 'Trotzdem verleihen', 'Absage', 'Stornieren', 'Ich habe den Nachweis der Person gesehen.', 'MM.Freigaben.gaesteText(vl)', 'daten.verleihPruefen(w)'].forEach((x) => assert.ok(src.includes(x), x));
  assert.ok(src.includes('Die Freigabe ist storniert.'));
  const texte = fs.readFileSync(path.join(__dirname, '..', 'js', 'texte.js'), 'utf8');
  assert.ok(texte.includes('2.0.74'));
});
