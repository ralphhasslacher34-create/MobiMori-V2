/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.46';
  MM.STUFE = 'Kostenblock: abgegebene Fahrzeuge gekennzeichnet, gleiche Kennung nur nach Rückfrage, Kostenposten löschen und korrigieren';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
