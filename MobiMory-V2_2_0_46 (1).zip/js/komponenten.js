/*
 * Komponenten: Hauptkomponenten (Schale 3) und alles darunter (Schale 4 und tiefer).
 *
 * Es gibt nur EINE Liste für alle Komponenten. Jede Komponente "gehört zu"
 * einem Fahrzeug oder zu einer anderen Komponente. So lässt sich beliebig
 * tief aufschlüsseln: Motor, Einspritzung, Pumpe, ...
 *
 * Die Felder sind, wie bei den Fahrzeugarten, als Daten beschrieben.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Nur Hauptkomponenten haben eine Art. Die Reihenfolge ist die Anzeigereihenfolge. */
  var ARTEN = [
    { id: 'motor', name: 'Motor' },
    { id: 'getriebe', name: 'Getriebe' },
    { id: 'heizung', name: 'Heizung' },
    { id: 'klima', name: 'Klima' },
    { id: 'strom', name: 'Stromversorgung' },
    { id: 'wasser', name: 'Wasserversorgung' },
    { id: 'sonstiges', name: 'Sonstiges' }
  ];

  var GRUPPEN = [
    { id: 'teil', titel: 'Teil' },
    { id: 'einbau', titel: 'Einbau' },
    { id: 'merkmale', titel: 'Technische Merkmale' }
  ];

  var FELDER = [
    { key: 'hersteller', label: 'Hersteller', typ: 'text', gruppe: 'teil' },
    { key: 'modell', label: 'Modell', typ: 'text', gruppe: 'teil' },
    { key: 'seriennummer', label: 'Seriennummer', typ: 'text', gruppe: 'teil' },
    { key: 'kurzname', label: 'Kurzname', typ: 'text', gruppe: 'teil', maxLaenge: 8,
      hilfe: 'Höchstens 8 Zeichen. Steht auf kleinen Knöpfen, zum Beispiel auf dem Motorschalter im Cockpit. Die App macht aus der Bezeichnung einen Vorschlag, du kannst ihn ändern.' },
    { key: 'baujahr', label: 'Baujahr', typ: 'ganzzahl', gruppe: 'teil', min: 1800 },
    { key: 'anzahl', label: 'Anzahl', typ: 'ganzzahl', gruppe: 'teil', min: 1,
      hilfe: 'Wie viele Stück dieser Art eingebaut sind, zum Beispiel 6 Rettungswesten. Leer zählt als 1.' },
    { key: 'eignungGeprueft', label: 'Eignung geprüft', typ: 'auswahl', gruppe: 'teil', leerText: 'Nein, noch nicht geprüft',
      optionen: [{ wert: 'ja', label: 'Ja, geprüft' }],
      hilfe: 'Nur wichtig, wenn eine Regel eine bestimmte Eignung verlangt, zum Beispiel „Automatik, 150 N“.' },
    { key: 'eingebautAm', label: 'Eingebaut am', typ: 'datum', gruppe: 'einbau' },
    { key: 'einbauort', label: 'Einbauort', typ: 'text', gruppe: 'einbau', hilfe: 'Zum Beispiel Motorraum oder Heck' },
    { key: 'ausgebautAm', label: 'Ausgebaut am', typ: 'datum', gruppe: 'einbau',
      hilfe: 'Nur eintragen, wenn das Teil nicht mehr im Fahrzeug ist' },
    { key: 'merkmale', label: 'Technische Merkmale', typ: 'liste', gruppe: 'merkmale',
      hilfe: 'Jedes Merkmal hat einen Namen, einen Wert und eine Einheit, zum Beispiel „Leistung“, „110“, „kW“. Bei Verbrauch und ähnlichem kommt eine Bezugsgröße dazu, zum Beispiel „100 km“.' }
  ];

  /*
   * Vorlagen für die offenen Listen der Merkmale und der Einheiten (seit 2.0.45).
   * Die Vorlage ist nur der Anfang: Der Nutzer kann eigene Einträge anlegen und jeden Eintrag ausblenden.
   * Die App trägt nichts von selbst in eine Komponente ein. Eine Einheit steht erst dann an einem Merkmal, wenn der Nutzer sie wählt.
   * Kennung eines mitgelieferten Eintrags = sein Name (Merkmal) oder sein Zeichen (Einheit).
   */
  var MERKMAL_VORLAGE = [
    { wert: 'Leistung', einheit: 'kW', bezug: '' },
    { wert: 'Hubraum', einheit: 'cm³', bezug: '' },
    { wert: 'Drehzahl', einheit: '1/min', bezug: '' },
    { wert: 'Verbrauch', einheit: 'l', bezug: 'Betriebsstunde' },
    { wert: 'Tankinhalt', einheit: 'l', bezug: '' },
    { wert: 'Kapazität', einheit: 'Ah', bezug: '' },
    { wert: 'Spannung', einheit: 'V', bezug: '' },
    { wert: 'Stromstärke', einheit: 'A', bezug: '' },
    { wert: 'Gewicht', einheit: 'kg', bezug: '' },
    { wert: 'Länge', einheit: 'mm', bezug: '' },
    { wert: 'Durchmesser', einheit: 'mm', bezug: '' },
    { wert: 'Druck', einheit: 'bar', bezug: '' },
    { wert: 'Ölmenge', einheit: 'l', bezug: '' },
    { wert: 'Auftrieb', einheit: 'N', bezug: '' }
  ];
  var EINHEITEN_VORLAGE = ['kW', 'PS', 'l', 'ml', 'kg', 'g', 'bar', 'V', 'A', 'Ah', 'W', 'N', 'mm', 'cm', 'm', 'cm³', 'l/h', '1/min', '°C', 'Stück', 'Prozent'];
  var MAX_EINHEIT = 20, MAX_BEZUG = 40, MAX_MERKMAL = 60;

  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }

  /*
   * Kurzname: aus der Bezeichnung entsteht eine Zeichenfolge, die immer auf einen kleinen Knopf passt.
   * Bekannte Wörter haben feste Kürzel (Steuerbord = STB), Zahlen bleiben ganz, andere Wörter
   * werden auf 3 Buchstaben gekürzt. Wird es länger als 8 Zeichen, werden sie auf 2 gekürzt,
   * zuletzt wird abgeschnitten. Das Ergebnis ist ein Vorschlag, der Nutzer bestätigt oder ändert ihn.
   */
  var MAX_KURZNAME = 8;
  var KUERZEL = { motor: 'MO', backbord: 'BB', steuerbord: 'STB', links: 'LI', rechts: 'RE', mitte: 'MI', hilfsmotor: 'HIMO', aussenborder: 'AB', hauptmotor: 'HMO', generator: 'GEN' };

  function sauber(wort) {
    return String(wort).toUpperCase().replace(/Ä/g, 'A').replace(/Ö/g, 'O').replace(/Ü/g, 'U').replace(/ß/g, 'SS')
      .replace(/[^A-Z0-9]/g, '');
  }

  function kurznameVorschlag(name) {
    var woerter = String(name == null ? '' : name).split(/[\s\-_\/,.;:]+/).filter(Boolean);
    var teile = woerter.map(function (w) {
      var schluessel = w.toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
      var bekannt = KUERZEL[schluessel];
      var s = sauber(w);
      return { bekannt: bekannt || null, zahl: /^\d+$/.test(s), s: s };
    }).filter(function (t) { return t.s; });
    function bauen(laenge) {
      return teile.map(function (t) { return t.bekannt ? t.bekannt : (t.zahl ? t.s : t.s.slice(0, laenge)); }).join('');
    }
    var r = bauen(3);
    if (r.length > MAX_KURZNAME) r = bauen(2);
    if (r.length > MAX_KURZNAME) r = r.slice(0, MAX_KURZNAME);
    return r;
  }

  /* Was auf dem Knopf steht: der gespeicherte Kurzname, sonst der Vorschlag aus der Bezeichnung. */
  function kurzAnzeige(werte) {
    var k = werte && werte.kurzname ? String(werte.kurzname).trim() : '';
    return k || kurznameVorschlag(werte ? werte.bezeichnung : '');
  }

  /* Nur Hauptkomponenten der Art Motor haben einen Schalter. */
  function istMotor(komponente) { return !!komponente && !komponente.parentId && komponente.art === 'motor'; }

  function art(id) {
    for (var i = 0; i < ARTEN.length; i++) { if (ARTEN[i].id === id) return ARTEN[i]; }
    return null;
  }

  function felder() { return FELDER.map(kopie); }

  function gruppen() {
    return GRUPPEN.map(function (g) {
      return { id: g.id, titel: g.titel, felder: FELDER.filter(function (f) { return f.gruppe === g.id; }).map(kopie) };
    });
  }

  function artIndex(id) {
    for (var i = 0; i < ARTEN.length; i++) { if (ARTEN[i].id === id) return i; }
    return ARTEN.length;
  }

  /*
   * Ausgeblendete Komponenten (seit 2.0.45): Eine ausgeblendete Hauptkomponente verdeckt alles darunter.
   * liste: wie daten.komponentenListe ({ komponente, aktuell }). Ergebnis: die Liste ohne Ausgeblendete und ohne Verdeckte.
   * Ausgeblendete zählen nicht für die Ausrüstungsprüfung, den Grundcheck, den Reisecheck und den Motorschalter.
   */
  function istAusgeblendet(komponente) { return !!(komponente && komponente.ausgeblendet); }

  function verdecktIds(liste) {
    var nachId = {};
    (liste || []).forEach(function (x) { nachId[x.komponente.id] = x; });
    var verdeckt = {};
    (liste || []).forEach(function (x) {
      var k = x.komponente, schutz = 0, hoch = k;
      while (hoch && schutz++ < 50) {
        if (hoch.ausgeblendet) { verdeckt[k.id] = true; break; }
        hoch = hoch.parentId ? (nachId[hoch.parentId] ? nachId[hoch.parentId].komponente : null) : null;
      }
    });
    return verdeckt;
  }

  function aktive(liste) {
    var v = verdecktIds(liste);
    return (liste || []).filter(function (x) { return !v[x.komponente.id]; });
  }

  /* Alle Kennungen einer Komponente und alles darunter (beliebig tief). */
  function mitUnterkomponenten(liste, id) {
    var ids = [id], i = 0;
    while (i < ids.length && ids.length < 5000) {
      var aktuell = ids[i++];
      (liste || []).forEach(function (x) { if (x.komponente.parentId === aktuell && ids.indexOf(x.komponente.id) < 0) ids.push(x.komponente.id); });
    }
    return ids;
  }

  /* Ein Merkmal zum Anzeigen: „Leistung: 110 kW“ oder „Verbrauch: 8 l, bezogen auf 100 km“. Alte Zeilen ohne Einheit bleiben wie sie waren. */
  function merkmalWert(z) {
    var t = String(z.wert) + (z.einheit ? ' ' + z.einheit : '');
    return t + (z.bezug ? ', bezogen auf ' + z.bezug : '');
  }
  function merkmalText(z) { return z.name + ': ' + merkmalWert(z); }

  function gleichText(a, b) { return String(a == null ? '' : a).trim().toLowerCase() === String(b == null ? '' : b).trim().toLowerCase(); }

  /*
   * Die Listen aus Vorlage, eigenen Einträgen und Ausgeblendeten. dok: das gespeicherte Dokument (oder null).
   * Merkmale: [{ wert, label, einheit, bezug, eigen, ausgeblendet }]; Einheiten: [{ wert, label, eigen, ausgeblendet }]
   */
  function merkmaleListe(dok) {
    var versteckt = (dok && dok.ausgeblendet) || [];
    var liste = MERKMAL_VORLAGE.map(function (m) {
      return { wert: m.wert, label: m.wert, einheit: m.einheit, bezug: m.bezug, eigen: false, ausgeblendet: versteckt.indexOf(m.wert) >= 0 };
    });
    ((dok && dok.eigene) || []).forEach(function (m) {
      liste.push({ wert: m.wert, label: m.label, einheit: m.einheit || '', bezug: m.bezug || '', eigen: true, ausgeblendet: versteckt.indexOf(m.wert) >= 0 });
    });
    return liste;
  }

  function einheitenListe(dok) {
    var versteckt = (dok && dok.ausgeblendet) || [];
    var liste = EINHEITEN_VORLAGE.map(function (e) { return { wert: e, label: e, eigen: false, ausgeblendet: versteckt.indexOf(e) >= 0 }; });
    ((dok && dok.eigene) || []).forEach(function (e) { liste.push({ wert: e.wert, label: e.label, eigen: true, ausgeblendet: versteckt.indexOf(e.wert) >= 0 }); });
    return liste;
  }

  MM.Komponenten = {
    arten: function () { return ARTEN.slice(); },
    art: art,
    artIndex: artIndex,
    felder: felder,
    gruppen: gruppen,
    MAX_KURZNAME: MAX_KURZNAME,
    kurznameVorschlag: kurznameVorschlag,
    kurzAnzeige: kurzAnzeige,
    istMotor: istMotor,
    istAusgeblendet: istAusgeblendet,
    verdecktIds: verdecktIds,
    aktive: aktive,
    mitUnterkomponenten: mitUnterkomponenten,
    merkmalWert: merkmalWert,
    merkmalText: merkmalText,
    gleichText: gleichText,
    MERKMAL_VORLAGE: MERKMAL_VORLAGE,
    EINHEITEN_VORLAGE: EINHEITEN_VORLAGE,
    MAX_EINHEIT: MAX_EINHEIT,
    MAX_BEZUG: MAX_BEZUG,
    MAX_MERKMAL: MAX_MERKMAL,
    merkmaleListe: merkmaleListe,
    einheitenListe: einheitenListe
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
