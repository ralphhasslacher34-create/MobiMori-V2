/*
 * Ansicht: was der Nutzer sieht.
 *
 * Seiten (Adresse hinter dem #):
 *   #/                         Startseite
 *   #/auswahl                  Hauptmenü (Stammdaten, Funktionen, Einstellungen)
 *   #/stammdaten               Stammdaten (Fahrzeuge, Personen, Tiere, Nachweisarten, Orte, Gebiete, Adressen)
 *   #/fahrzeuge                Meine Fahrzeuge (Schale 1)
 *   #/neu-im-programm          Neu im Programm
 *   #/einstellungen            Einstellungen
 *   #/fahrzeug/<id>/komponente/neu   Hauptkomponente anlegen
 *   #/komponente/<id>          Komponente (Schale 3 und tiefer)
 *   #/komponente/<id>/neu      Teil darunter anlegen
 *   #/komponente/<id>/aendern  Komponente ändern
 *   #/frist/<id>               Frist (auch /erledigt und /aendern)
 *   #/werkstatt                Werkstatt: Fahrzeug wählen; #/fahrzeug/<id>/werkstatt alle Vorgänge des Fahrzeugs
 *   #/vorgang/<id>             Vorgang (Störung oder Arbeit; auch /aendern, /arbeit, /erledigt)
 *   #/vorgang/<id>/dokument/neu  Dokument oder Bild am Vorgang ablegen (seit 2.0.26)
 *   #/fahrzeug/<id>/stoerung/neu, /arbeit/neu und #/komponente/<id>/stoerung/neu, /arbeit/neu
 *   #/adressen (auch /neu), #/adresse/<id> (auch /aendern)   Werkstätten, Lieferanten und Händler (zentrale Liste)
 *   #/besuch/<id> (auch /aendern), #/aktivitaet/<id>/besuch/neu (?ereignis=, ?ort=, ?von=cockpit)   Besuche an Orten (seit 2.0.28)
 *   #/aktivitaet/<id>/reisekasse (?fix=aus), /kasse/neu (?art=, ?waehrung=), /kassensturz   Reisekasse, Kassen und Auswertung der Reise (seit 2.0.29)
 *   #/kosten/listen, /kosten/listen/art/neu (?gruppe=), /kosten/listen/zahlung/neu, #/kosten/<id>/dokument/neu   Arten, Zahlungsmittel, Foto am Posten (seit 2.0.29)
 *   #/kosten (?jahr=)          Kosten über alle Fahrzeuge (seit 2.0.27); #/kosten/<id> (auch /aendern)   ein Posten
 *   #/fahrzeug/<id>/kosten (?jahr=), /kosten/neu (?gruppe=, ?aktivitaet=, ?vorgang=, ?komponente=), /kostenstamm   Auswertung, Eintragen, Kostenstammdaten
 *   #/zaehler/<id>             Zähler (auch /stand und /aendern)
 *   #/fahrzeug/<id>/frist/neu, /zaehler/neu und #/komponente/<id>/frist/neu, /zaehler/neu
 *   #/dokument/<id>            Dokument (auch /aendern)
 *   #/fahrzeug/<id>/dokumente  alle Dokumente eines Fahrzeugs
 *   #/fahrzeug/<id>/dokument/neu und #/komponente/<id>/dokument/neu
 *   #/personen, #/tiere (auch /neu), #/person/<id>, #/tier/<id> (auch /aendern, /nachweis/neu)
 *   #/nachweis/<id>           Nachweis (auch /aendern); #/fahrzeug/<id>/nachweis/neu
 *   #/nachweisarten           offene Liste der Nachweisarten; /vorschlaege; #/nachweisart/<id>, /neu, /aendern
 *   #/kassenbuch                Kassenbuch: die Kassen aller Aktivitäten, jede Zeile führt zur Reisekasse der Aktivität (seit 2.0.31)
 *   #/aktivitaet/<id>/route    Route und Wetter: Routendatei einlesen, Fahrplan, Wetter, Tide (seit 2.0.33)
 *   #/funktionen, #/aktivitaeten, #/aktivitaet/<id> (auch /aendern, /stornieren, /besatzung/neu, /verantwortung)
 *   #/besatzung/<id>/aendern, #/aktivitaetsarten, #/aktivitaetsart/<id>/aendern
 *   #/aktivitaet/<id>/tag/neu, #/tagesabschnitt/<id> (auch /aendern, /ereignis/neu, /nachtragen)   Logbuch an der Aktivität
 *   #/aktivitaet/<id>/cockpit/ereignis, /notiz, /foto, /wechsel   Cockpit (schnell eintragen, nur heute)
 *   #/motoren/<fahrzeugId>     Motoren des Fahrzeugs: Schalter, Betriebsstunden, letzte Läufe (auch mit ?aktivitaet=<id>)
 *   #/lauf/<id>/korrigieren    Stoppzeit eines Motorlaufs korrigieren (mit ?fahrzeug=<id>, ?aktivitaet=<id>)
 *   #/motorfrage               Wartezeit der Motorstopp-Frage nach der Ankunft (mit ?fahrzeug=<id>, ?aktivitaet=<id>)
 *   #/aktivitaet/<id>/karte    Karte im Vollbild: Route, Wetterpunkte, gefahrener Weg, Position (seit 2.0.34)
 *   #/aktivitaet/<id>/karte/offline   Offline-Karte holen und löschen (seit 2.0.34)
 *   #/wetterrhythmus           Wie oft das Wetter im Cockpit automatisch geholt wird, nur dieses Gerät (seit 2.0.34)
 *   #/tagesabschnitt/<id>/abschluss   Tagesabschluss (tatsächliches Ziel, Notiz)
 *   #/reisecheck/<aktivitaetId>/tag/<tagId>[/<checkId>]   Reisecheck für einen Tag (Etappe, seit 2.0.43)
 *   #/ereignis/<id> (auch /aendern), #/wechsel/<id> (auch /aendern), #/ereignisarten, #/ereignisart/<id>/aendern
 *   #/fahrzeug/<id>/anforderung/neu, #/anforderung/<id>/aendern
 *   #/orte (auch /neu), #/ort/<id> (auch /aendern, /standort/neu, /regel/neu), #/standort/<id>/aendern
 *   #/gebiete (auch /neu), #/gebiet/<id> (auch /aendern, /regel/neu), #/regel/<id>/aendern
 *   #/fahrzeug/<id>/heimatstandort
 *   #/einstellungen/sichern, #/einstellungen/wiederherstellen
 *   #/einstellungen/import, #/einstellungen/export   Fahrzeuge aus Excel oder CSV übernehmen, Daten als Excel oder CSV ausgeben
 *   #/neu                      Fahrzeug anlegen
 *   #/fahrzeug/<id>            Fahrzeug mit äußerer Hülle (Schale 2)
 *   #/fahrzeug/<id>/aendern    Angaben ändern (seit 2.0.37 auch die Fahrzeugart)
 *   #/fahrzeug/<id>/abgeben, #/fahrzeug/<id>/uebergabe   Fahrzeug abgeben; Übergabedatei und Technik-Akte (PDF)
 *   #/einstellungen/uebernehmen   Fahrzeug aus einer Übergabedatei übernehmen
 *
 * Alle Texte kommen mit textContent in die Seite, nie als HTML.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  var doc = global.document;

  var daten = null;
  var wurzel = null;
  var meldung = null; /* wird einmal auf der nächsten Seite gezeigt */
  var frageTimer = null; /* Timer für die Motorstopp-Frage nach der Wartezeit (seit 2.0.22), nur solange das Cockpit offen ist */
  var motorHinweis = null; /* „Kein Motor läuft“ nach Abfahrt oder Ablegen, wird einmal im Cockpit gezeigt (seit 2.0.20) */

  /* ---------- GPS-Position dieses Geräts (seit 2.0.21) ----------
   * Das Cockpit hört auf das GPS, solange es offen ist, und merkt sich die letzte Position. Ein Eintrag bekommt sie nur, wenn sie frisch ist
   * (höchstens 2 Minuten alt). Es wird nie auf das GPS gewartet und nie nachgefragt: Ohne Position wird trotzdem sofort gespeichert. */
  var gpsFix = null, gpsWatchId = null, gpsStatus = 'unbekannt', gpsGebraucht = false, gpsSicht = null, gpsTextEl = null, gpsLetzteSuche = null, gpsName = null;

  function gpsStarten() {
    gpsGebraucht = true;
    var geo = global.navigator && global.navigator.geolocation;
    if (!geo) { gpsStatus = 'fehlt'; return; }
    if (gpsWatchId !== null) return;
    try {
      gpsWatchId = geo.watchPosition(function (p) {
        gpsFix = { breite: p.coords.latitude, laenge: p.coords.longitude, genauigkeit: p.coords.accuracy, zeitMs: Date.now(),
          geschwindigkeit: typeof p.coords.speed === 'number' && isFinite(p.coords.speed) ? p.coords.speed : null };
        gpsStatus = 'ok';
        gpsSpurPunkt();
        gpsFahrtPunkt();
        gpsWegPunkt();
        gpsZeichnen();
        if (gpsHorcher) gpsHorcher();
      }, function (err) {
        gpsStatus = err && err.code === 1 ? 'verweigert' : 'suche';
        gpsZeichnen();
        if (gpsHorcher) gpsHorcher();
      }, { enableHighAccuracy: true, maximumAge: 15000, timeout: 60000 });
    } catch (e) { gpsStatus = 'fehlt'; gpsWatchId = null; }
  }

  /* ---------- GPS-Strecke (seit 2.0.33) ----------
   * Solange das Cockpit offen ist und das Fahrzeug „in Fahrt“ ist, zählt die App die Strecke aus den GPS-Punkten (MM.Routen.spurPunkt).
   * Sie schreibt nie von allein in den Zähler: Der Nutzer tippt „GPS-Strecke übernehmen“. Ohne GPS bleibt die Handeingabe. */
  var gpsSpur = null, gpsSpurAkt = null, gpsSpurWelt = 'land', gpsInFahrt = false, gpsSpurGesichert = 0, gpsSpurUngesichert = false;

  function cockpitSpurVorbereiten(aktId, gespeichert, fzStatus, welt) {
    if (gpsSpurAkt !== aktId || !gpsSpur) { gpsSpur = gespeichert || MM.Routen.spurNeu(); gpsSpurAkt = aktId; }
    gpsSpurWelt = welt;
    gpsInFahrt = !!(fzStatus && fzStatus.ok && fzStatus.hatStatus && fzStatus.stand && fzStatus.stand.wirksam === 'in-fahrt');
  }
  function gpsSpurSichern(sofort) {
    if (!gpsSpur || !gpsSpurAkt || !gpsSpurUngesichert) return;
    if (!sofort && Date.now() - gpsSpurGesichert < 20000) return;
    gpsSpurGesichert = Date.now(); gpsSpurUngesichert = false;
    daten.gpsSpurSpeichern(gpsSpurAkt, gpsSpur).catch(function () { gpsSpurUngesichert = true; });
  }
  function gpsSpurPunkt() {
    if (!gpsSpur || !gpsSpurAkt || !gpsFix) return;
    var neu = MM.Routen.spurPunkt(gpsSpur, gpsFix, gpsSpurWelt, gpsInFahrt);
    if (neu.km !== gpsSpur.km || neu.verworfen !== gpsSpur.verworfen || neu.luecken !== gpsSpur.luecken || (gpsInFahrt && neu.punkte !== gpsSpur.punkte)) gpsSpurUngesichert = true;
    gpsSpur = neu;
    gpsSpurSichern(false);
  }

  /* ---------- Geschwindigkeit (seit 2.0.44) ----------
   * Aktuell, Ø fahrend und Ø Tag aus den GPS-Punkten (MM.Fahrt). Der Tag läuft von der ersten Bewegung bis zum Tagesabschluss.
   * Gezählt wird, wenn das Fahrzeug in Fahrt ist (hat die Fahrzeugart keinen Status, immer). Der Zustand liegt im Programm und wird
   * alle 20 Sekunden auf dem Gerät gesichert. Gespeichert im Logbuch wird beim Tagesabschluss und im Rhythmus der automatischen Einträge. */
  var gpsFahrt = null, gpsFahrtAkt = null, gpsFahrtWelt = 'land', gpsFahrtZaehlen = false, gpsFahrtGesichert = 0, gpsFahrtUngesichert = false;
  var tempoModus = 'aktuell', tempoKnopf = null, tempoNameEl = null, tempoWertEl = null, tempoTimer = null;
  var fahrtTimer = null, fahrtVersuch = { akt: null, ms: null }, fahrtErfolg = { akt: null, ms: null };

  function fahrtVorbereiten(aktId, gespeichert, fzStatus, welt) {
    if (gpsFahrtAkt !== aktId || !gpsFahrt) { gpsFahrt = gespeichert || MM.Fahrt.neu(); gpsFahrtAkt = aktId; }
    gpsFahrtWelt = welt;
    gpsFahrtZaehlen = !(fzStatus && fzStatus.ok && fzStatus.hatStatus) || gpsInFahrt;
  }
  /* Sichert den Zustand; gibt eine Zusage zurück (auch wenn nichts zu sichern war). */
  function fahrtSichern(sofort) {
    if (!gpsFahrt || !gpsFahrtAkt || !gpsFahrtUngesichert) return Promise.resolve();
    if (!sofort && Date.now() - gpsFahrtGesichert < 20000) return Promise.resolve();
    gpsFahrtGesichert = Date.now(); gpsFahrtUngesichert = false;
    return daten.gpsFahrtSpeichern(gpsFahrtAkt, gpsFahrt).catch(function () { gpsFahrtUngesichert = true; });
  }
  function gpsFahrtPunkt() {
    if (!gpsFahrt || !gpsFahrtAkt || !gpsFix) return;
    var neu = MM.Fahrt.punkt(gpsFahrt, gpsFix, gpsFahrtWelt, gpsFahrtZaehlen);
    if (neu.km !== gpsFahrt.km || neu.startMs !== gpsFahrt.startMs || neu.verworfen !== gpsFahrt.verworfen || neu.luecken !== gpsFahrt.luecken) gpsFahrtUngesichert = true;
    gpsFahrt = neu;
    fahrtSichern(false);
  }
  /* Nach dem Tagesabschluss liest das Cockpit den Zustand wieder aus dem Gerätespeicher. */
  function fahrtNeuLesen() { gpsFahrt = null; gpsFahrtAkt = null; gpsFahrtUngesichert = false; }

  /* Das Wechselfeld in der Kopfzeile: ein Tipp schaltet weiter, Aktuell → Ø fahrend → Ø Tag → Aktuell. Beim Start steht „Aktuell“. */
  function tempoAktualisieren() {
    if (!tempoKnopf) return;
    if (gpsStatus === 'verweigert' || gpsStatus === 'fehlt' || !gpsFahrt) { tempoKnopf.hidden = true; return; }
    tempoKnopf.hidden = false;
    var a = MM.Fahrt.anzeige(MM.Fahrt.werte(gpsFahrt, Date.now()), gpsFahrtWelt, tempoModus);
    tempoNameEl.textContent = a.name; tempoWertEl.textContent = a.wert;
    tempoKnopf.setAttribute('aria-label', a.name + ' ' + a.wert + ', tippen zum Wechseln');
  }
  function tempoWechseln() { tempoModus = MM.Fahrt.naechsterModus(tempoModus); tempoAktualisieren(); }
  function tempoKnopfBauen() {
    tempoNameEl = h('span', { class: 'frist-info' });
    tempoWertEl = h('strong');
    tempoKnopf = h('button', { class: 'cv-tempo', type: 'button', onclick: tempoWechseln }, tempoNameEl, tempoWertEl);
    if (tempoTimer) global.clearInterval(tempoTimer);
    /* „Aktuell“ verfällt nach 20 Sekunden ohne GPS-Punkt, darum alle 5 Sekunden neu zeichnen, solange der Knopf zu sehen ist. */
    tempoTimer = global.setInterval(function () {
      if (!tempoKnopf || !doc.body.contains(tempoKnopf)) { global.clearInterval(tempoTimer); tempoTimer = null; return; }
      tempoAktualisieren();
    }, 5000);
    return tempoKnopf;
  }

  /* Zwischenwerte im Rhythmus der automatischen Einträge (derselbe wie beim Wetter, einstellbar). Kein Netz nötig, und die Seite bleibt ruhig. */
  function fahrtAutoPlanen(aktId, seiteEl, ereignisse, rhythmus, erlaubt) {
    if (fahrtTimer) { global.clearTimeout(fahrtTimer); fahrtTimer = null; }
    if (!(rhythmus > 0) || !erlaubt) return;
    function spaeter() { if (doc.body.contains(seiteEl)) fahrtTimer = global.setTimeout(tick, 60000); }
    function tick() {
      fahrtTimer = null;
      if (!doc.body.contains(seiteEl)) return;
      var jetzt = Date.now();
      if (!gpsFahrt || gpsFahrtAkt !== aktId || gpsFahrt.abgeschlossen || MM.Fahrt.werte(gpsFahrt, jetzt).tagKmh === null) { spaeter(); return; }
      var letzte = MM.Fahrt.letzterEintragMs(ereignisse);
      if (fahrtErfolg.akt === aktId && fahrtErfolg.ms !== null && (letzte === null || fahrtErfolg.ms > letzte)) letzte = fahrtErfolg.ms;
      var versuch = fahrtVersuch.akt === aktId ? fahrtVersuch.ms : null;
      if (!MM.Fahrt.faellig(rhythmus, letzte, versuch, jetzt)) { spaeter(); return; }
      fahrtVersuch = { akt: aktId, ms: jetzt };
      gpsFahrtUngesichert = true;
      fahrtSichern(true).then(function () {
        return daten.fahrtEintragen(aktId, { fahrt: gpsFahrt, art: 'rhythmus', position: frischePosition() });
      }).then(function (r) {
        if (r.ok) fahrtErfolg = { akt: aktId, ms: Date.now() };
        spaeter();
      }, spaeter);
    }
    fahrtTimer = global.setTimeout(tick, 7000);
  }

  /* ---------- Gefahrener Weg (seit 2.0.34, Schritt 9b) ----------
   * Der Weg besteht aus den GPS-Punkten dieser Aktivität (dünn gehalten, siehe MM.Karte.wegPunkt). Er wird aufgezeichnet, solange das Cockpit
   * oder die Karte offen ist und das Fahrzeug „in Fahrt“ ist (hat die Fahrzeugart keinen Status, immer). Im Hintergrund zeichnet ein Browser nichts auf. */
  var gpsWeg = null, gpsWegAkt = null, gpsWegWelt = 'land', gpsWegAktiv = false, gpsWegGesichert = 0, gpsWegUngesichert = false, gpsHorcher = null;

  function wegVorbereiten(aktId, gespeichert, fzStatus, welt) {
    if (gpsWegAkt !== aktId || !gpsWeg) { gpsWeg = gespeichert || MM.Karte.wegNeu(); gpsWegAkt = aktId; }
    gpsWegWelt = welt;
    gpsWegAktiv = !(fzStatus && fzStatus.ok && fzStatus.hatStatus) || gpsInFahrt;
  }
  function gpsWegSichern(sofort) {
    if (!gpsWeg || !gpsWegAkt || !gpsWegUngesichert) return;
    if (!sofort && Date.now() - gpsWegGesichert < 20000) return;
    gpsWegGesichert = Date.now(); gpsWegUngesichert = false;
    daten.gpsWegSpeichern(gpsWegAkt, gpsWeg).catch(function () { gpsWegUngesichert = true; });
  }
  function gpsWegPunkt() {
    if (!gpsWeg || !gpsWegAkt || !gpsFix || !gpsWegAktiv) return;
    var neu = MM.Karte.wegPunkt(gpsWeg, gpsFix, gpsWegWelt);
    if (neu.punkte.length !== gpsWeg.punkte.length || neu.verworfen !== gpsWeg.verworfen) gpsWegUngesichert = true;
    gpsWeg = neu;
    gpsWegSichern(false);
  }

  /* ---------- Wetter im Rhythmus (seit 2.0.34) ----------
   * Solange das Cockpit (oder die Karte) offen ist und das Fahrzeug in Fahrt ist, holt die App das Wetter im eingestellten Rhythmus
   * und schreibt es als Eintrag „Wetter“ ins Logbuch. Fällig ist es, wenn der letzte Eintrag „Wetter“ länger her ist als der Rhythmus.
   * Ohne Netz oder Position wird frühestens nach 10 Minuten wieder versucht. Im Hintergrund holt ein Browser nichts. */
  var meldungKurz = false; /* seit 2.0.44: die Meldung zum Wetter im Cockpit verschwindet nach ein paar Sekunden von selbst */
  var wetterTimer = null, wetterVersuch = { akt: null, ms: null }, wetterErfolg = { akt: null, ms: null };
  function wetterAutoPlanen(aktId, seiteEl, ereignisse, rhythmus, erlaubt, beiErfolg) {
    if (wetterTimer) { global.clearTimeout(wetterTimer); wetterTimer = null; }
    if (!(rhythmus > 0) || !erlaubt) return;
    function spaeter() { if (doc.body.contains(seiteEl)) wetterTimer = global.setTimeout(tick, 60000); }
    function tick() {
      wetterTimer = null;
      if (!doc.body.contains(seiteEl)) return;
      var jetzt = Date.now(), versuch = wetterVersuch.akt === aktId ? wetterVersuch.ms : null;
      var letzte = MM.Karte.letztesWetterMs(ereignisse);
      if (wetterErfolg.akt === aktId && wetterErfolg.ms !== null && (letzte === null || wetterErfolg.ms > letzte)) letzte = wetterErfolg.ms;
      var pos = frischePosition();
      if (!pos || !MM.Karte.wetterFaellig(rhythmus, letzte, versuch, jetzt)) { spaeter(); return; }
      wetterVersuch = { akt: aktId, ms: jetzt };
      daten.wetterJetzt(aktId, pos, { automatisch: true }).then(function (r) {
        if (r.ok) wetterErfolg = { akt: aktId, ms: Date.now() };
        if (r.ok && doc.body.contains(seiteEl)) { beiErfolg(r); return; }
        spaeter();
      }, spaeter);
    }
    wetterTimer = global.setTimeout(tick, 5000);
  }

  function gpsStoppen() {
    var geo = global.navigator && global.navigator.geolocation;
    if (gpsWatchId !== null && geo) { try { geo.clearWatch(gpsWatchId); } catch (e) { /* nichts zu tun */ } }
    gpsWatchId = null;
  }

  /* Die frische GPS-Position (auf 5 Nachkommastellen, etwa ein Meter) oder null */
  function frischePosition() {
    var f = MM.Logbuch.gpsFrisch(gpsFix, Date.now());
    return f ? { breite: Number(f.breite.toFixed(5)), laenge: Number(f.laenge.toFixed(5)), genauigkeit: f.genauigkeit } : null;
  }

  function koordFeld(x) { return typeof x === 'number' ? String(x).replace('.', ',') : ''; }

  function positionZeile() {
    gpsSicht = h('p', { class: 'cv-position' });
    gpsTextEl = h('span', { class: 'cv-pos-text', role: 'status' });
    gpsSicht.appendChild(gpsTextEl);
    gpsSicht.appendChild(tempoKnopfBauen());
    gpsZeichnen(true);
    return gpsSicht;
  }

  /* sofort: beim Aufbau der Seite (das Element hängt noch nicht im Dokument), sonst nur, solange die Zeile zu sehen ist */
  function gpsZeichnen(sofort) {
    if (!gpsSicht || (!sofort && !doc.body.contains(gpsSicht))) return;
    var fix = frischePosition(), t;
    if (fix) {
      t = MM.Logbuch.positionText(fix.breite, fix.laenge) + ' (GPS' + (isFinite(fix.genauigkeit) ? ', ±' + Math.round(fix.genauigkeit) + ' m' : '') + ')' + (gpsName ? ' · ' + gpsName : '');
      if (!gpsLetzteSuche || MM.Logbuch.entfernungMeter(fix.breite, fix.laenge, gpsLetzteSuche.breite, gpsLetzteSuche.laenge) >= 25) {
        gpsLetzteSuche = { breite: fix.breite, laenge: fix.laenge };
        daten.ortNameVorschlag(fix.breite, fix.laenge).then(function (v) { gpsName = v ? v.name : null; gpsZeichnen(); });
      }
    } else if (gpsStatus === 'verweigert') t = 'GPS nicht erlaubt, Einträge ohne Position';
    else if (gpsStatus === 'fehlt') t = 'Kein GPS auf diesem Gerät, Einträge ohne Position';
    else t = 'wird gesucht …';
    /* Nur der Text wird neu gezeichnet. Das Wechselfeld bleibt stehen, damit ein Tipp nie ins Leere geht. */
    gpsTextEl.textContent = '';
    gpsTextEl.appendChild(h('span', { class: 'frist-info', text: 'Position' }));
    gpsTextEl.appendChild(h('strong', { text: t }));
    if (gpsSpur && gpsSpurAkt && (gpsInFahrt || gpsSpur.km > 0)) {
      gpsTextEl.appendChild(h('span', { class: 'frist-info', text: ' · GPS-Strecke' }));
      gpsTextEl.appendChild(h('strong', { text: MM.Hilfen.zahl(Math.round(gpsSpur.km * 10) / 10) + ' km' + (gpsInFahrt ? '' : ' (zählt nur in Fahrt)') }));
    }
    tempoAktualisieren();
  }

  /* Eine Zeile zu Ort und Position eines Ereignisses (Logbuch) */
  function ortZeile(e) {
    var teile = [];
    if (e.ortName) teile.push(e.ortName + (e.ortNameQuelle === 'vorschlag' ? ' (Vorschlag)' : ''));
    if (typeof e.breite === 'number' && typeof e.laenge === 'number') teile.push(MM.Logbuch.positionText(e.breite, e.laenge) + ' (' + (e.positionQuelle === 'gps' ? 'GPS' : 'von Hand') + ')');
    return teile.join(' · ');
  }

  /* ---------- kleine Bauhelfer ---------- */
  function anhaengen(el, kind) {
    if (kind === null || kind === undefined || kind === false) return;
    if (Array.isArray(kind)) { kind.forEach(function (k) { anhaengen(el, k); }); return; }
    if (typeof kind === 'string' || typeof kind === 'number') { el.appendChild(doc.createTextNode(String(kind))); return; }
    el.appendChild(kind);
  }
  function h(tag, attrs) {
    var el = doc.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) return;
        if (k === 'text') el.textContent = v;
        else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
        else if (k === 'value') el.value = v;
        else el.setAttribute(k, v === true ? '' : v);
      });
    }
    for (var i = 2; i < arguments.length; i++) anhaengen(el, arguments[i]);
    return el;
  }

  function kopf() {
    return h('header', { class: 'kopf' },
      h('a', { href: '#/auswahl' }, h('img', { class: 'marke', src: 'icons/icon.svg', alt: '', width: '32', height: '32' }), 'MobiMory'),
      h('span', { class: 'version', text: 'Version ' + MM.VERSION }));
  }

  function fuss() {
    return h('footer', { class: 'fuss' }, h('p', { text: MM.Texte.COPYRIGHT }));
  }

  /* Wo-bin-ich-Zeile: Liste aus [Text, Adresse]; der letzte Eintrag hat keine Adresse. */
  function krumen(liste) {
    var nav = h('nav', { class: 'krumen', 'aria-label': 'Wo du bist' });
    liste.forEach(function (k, i) {
      if (i) nav.appendChild(doc.createTextNode(' › '));
      nav.appendChild(k[1] ? h('a', { href: k[1], text: k[0] }) : doc.createTextNode(k[0]));
    });
    return nav;
  }
  var WEG_FAHRZEUGE = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Fahrzeuge', '#/fahrzeuge']];

  /* Kachelseiten (seit 2.0.31): Die Kacheln füllen den freien Platz. Wie viele Spalten und wie hoch, rechnet MM.Hilfen.kachelRaster.
     Mehr Kacheln werden kleiner, wenige bekommen eine sinnvolle Höchsthöhe. Gemessen wird nach dem Aufbau der Seite und bei jeder Drehung. */
  /* Seit 2.0.32: Text darf nie abgeschnitten werden. Titel bleiben ganze Wörter, Beschreibungen brechen nur an Silbengrenzen um. Passt ein Titel nicht in die Kachel,
     wird zuerst die Schrift etwas kleiner (Stufen 1, 0,9, 0,8), und wenn es dann immer noch nicht passt, gibt es eine Spalte weniger. Die Höhe der Kachel wächst mit dem Text. */
  var KACHEL_SCHRIFTEN = [1, 0.9, 0.8];
  function kachelUeberlaeuft(k) {
    var i, j, e, teile = k.querySelectorAll('.kachel, .kachel-titel, .kachel-text');
    for (j = 0; j < teile.length; j++) { e = teile[j]; if (e.scrollWidth > e.clientWidth + 1) return true; }
    return false;
  }
  function kachelnAnpassen(main) {
    var k = main.querySelector(':scope > .kacheln');
    if (!k || !k.children.length) return;
    k.style.gridTemplateColumns = ''; k.style.gridAutoRows = ''; k.style.removeProperty('--kachel-schrift'); k.classList.remove('umbruch-notfall');
    var rem = parseFloat(global.getComputedStyle(doc.documentElement).fontSize) || 18;
    var r = k.getBoundingClientRect(), unten = doc.documentElement.scrollHeight - (r.bottom + (global.pageYOffset || 0));
    var gap = parseFloat(global.getComputedStyle(k).rowGap) || rem * 0.85;
    var p = { breite: k.clientWidth, hoehe: (global.innerHeight || 0) - r.top - unten, anzahl: k.children.length, rem: rem, abstand: gap };
    var passt = false, x, i;
    for (;;) {
      x = MM.Hilfen.kachelRaster(p);
      k.style.gridTemplateColumns = 'repeat(' + x.spalten + ', minmax(0, 1fr))';
      k.style.gridAutoRows = 'minmax(' + x.hoehe + 'px, auto)';
      for (i = 0; i < KACHEL_SCHRIFTEN.length && !passt; i++) {
        k.style.setProperty('--kachel-schrift', String(KACHEL_SCHRIFTEN[i]));
        passt = !kachelUeberlaeuft(k);
      }
      if (passt || x.spalten <= 1) break;
      p.hoechstSpalten = x.spalten - 1;
    }
    if (!passt) k.classList.add('umbruch-notfall');
  }
  if (global.addEventListener) global.addEventListener('resize', function () {
    var m = doc.getElementById('inhalt');
    if (m && m.classList.contains('kachelseite')) kachelnAnpassen(m);
  });

  function seite(titel, inhalt, leiste) {
    doc.title = titel + ' – MobiMory';
    wurzel.textContent = '';
    var main = h('main', { class: 'inhalt', id: 'inhalt' });
    if (meldung) { main.appendChild(h('p', { class: 'meldung', role: 'status', text: meldung })); meldung = null; }
    anhaengen(main, inhalt);
    wurzel.appendChild(kopf());
    wurzel.appendChild(main);
    wurzel.appendChild(fuss());
    if (leiste) wurzel.appendChild(leiste);
    if (main.querySelector(':scope > .kacheln')) { main.classList.add('kachelseite'); kachelnAnpassen(main); }
    var h1 = main.querySelector('h1');
    if (h1) { h1.setAttribute('tabindex', '-1'); h1.focus({ preventScroll: true }); }
    global.scrollTo(0, 0);
  }

  function schild(artId, kennung) {
    var a = MM.Fahrzeugarten.art(artId);
    if (!kennung) return h('span', { class: 'schild leer', text: 'ohne Kennung' });
    return h('span', { class: 'schild welt-' + a.welt, text: kennung });
  }
  function kennungVon(artId, werte) { return werte[MM.Fahrzeugarten.kennungFeld(artId)] || ''; }

  /* ---------- Seite: Meine Fahrzeuge ---------- */
  function seiteListe() {
    return Promise.all([daten.fahrzeugListe(), daten.fristenUebersicht(), daten.nachweisUebersicht(), daten.fahrzeugeAbgegeben()]).then(function (res) {
      var liste = res[0], uebersicht = res[1], nwUebersicht = res[2], abgegeben = res[3];
      var inhalt = [krumen(WEG_FAHRZEUGE.slice(0, 2).concat([['Fahrzeuge']])), h('h1', { text: 'Meine Fahrzeuge' })];
      if (!liste.length) {
        inhalt.push(h('div', { class: 'leer-hinweis' },
          h('p', { text: 'Hier ist noch kein Fahrzeug.' }),
          h('p', { text: 'Lege dein erstes Fahrzeug an. Es genügt zuerst die Bezeichnung und die Fahrzeugart. Alles andere kannst du jederzeit nachtragen.' })));
      } else {
        inhalt.push(h('ul', { class: 'liste' }, liste.map(function (x) {
          var a = MM.Fahrzeugarten.art(x.fahrzeug.art);
          return h('li', null, h('a', { class: 'zeile welt-' + a.welt, href: '#/fahrzeug/' + encodeURIComponent(x.fahrzeug.id) },
            h('span', { class: 'zeile-text' },
              h('strong', { class: 'zeile-name', text: x.aktuell.werte.bezeichnung }),
              h('span', { class: 'zeile-art', text: a.name }),
              fristHinweis(uebersicht[x.fahrzeug.id]),
              nachweisHinweis(nwUebersicht[x.fahrzeug.id])),
            schild(a.id, kennungVon(a.id, x.aktuell.werte))));
        })));
      }
      if (abgegeben.length) {
        inhalt.push(h('details', { class: 'ausgebaut' },
          h('summary', { text: 'Abgegebene Fahrzeuge (' + abgegeben.length + ')' }),
          h('ul', { class: 'liste' }, abgegeben.map(function (x) {
            var a = MM.Fahrzeugarten.art(x.fahrzeug.art), ab = x.fahrzeug.abgabe;
            return h('li', null, h('a', { class: 'zeile welt-' + a.welt, href: '#/fahrzeug/' + encodeURIComponent(x.fahrzeug.id) },
              h('span', { class: 'zeile-text' },
                h('strong', { class: 'zeile-name', text: x.aktuell.werte.bezeichnung }),
                h('span', { class: 'zeile-art', text: a.name + ' · ' + (GRUND_WORT[ab.grund] || 'Abgegeben').toLowerCase() + ' am ' + MM.Hilfen.datum(ab.datum) })),
              schild(a.id, kennungVon(a.id, x.aktuell.werte))));
          }))));
      }
      inhalt.push(h('p', { class: 'hinweis' }, 'Schon eine Tabelle mit deinen Fahrzeugen? ', h('a', { href: '#/einstellungen/import', text: 'Aus Excel oder CSV übernehmen' })));
      inhalt.push(h('p', { class: 'hinweis' }, 'Ein Fahrzeug von einem früheren Besitzer bekommen? ', h('a', { href: '#/einstellungen/uebernehmen', text: 'Übergabedatei einlesen' })));
      seite('Meine Fahrzeuge', inhalt,
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
          h('a', { class: 'knopf', href: '#/neu', text: 'Fahrzeug anlegen' })));
    });
  }

  /* ---------- Fristen und Zähler: gemeinsame Bausteine ---------- */
  var STATUS_TEXT = { ueberfaellig: 'Überfällig', bald: 'Bald fällig', ok: 'In Ordnung', unbekannt: 'Angaben fehlen' };

  function zahlMit(n, einheit) { return MM.Hilfen.zahl(n) + (einheit ? ' ' + einheit : ''); }
  function tageText(n) { return n + (n === 1 ? ' Tag' : ' Tage'); }
  function tageDativ(n) { return n + (n === 1 ? ' Tag' : ' Tagen'); }

  function fristHinweis(u) {
    if (!u) return null;
    if (u.ueberfaellig) return h('span', { class: 'hinweis-frist status-ueberfaellig', text: u.ueberfaellig === 1 ? '1 Frist überfällig' : u.ueberfaellig + ' Fristen überfällig' });
    if (u.bald) return h('span', { class: 'hinweis-frist status-bald', text: u.bald === 1 ? '1 Frist bald fällig' : u.bald + ' Fristen bald fällig' });
    return null;
  }

  /* Die Zeilen "Zeit: ..." und "Zähler: ..." einer gerechneten Frist. */
  function fristZeilen(st, einheit) {
    var z = [];
    if (st.kalender) {
      var k = st.kalender, d = MM.Hilfen.datum(k.faelligAm);
      if (k.tage < 0) z.push({ status: k.status, text: 'Zeit: seit ' + tageDativ(-k.tage) + ' überfällig (war am ' + d + ')' });
      else if (k.tage === 0) z.push({ status: k.status, text: 'Zeit: heute fällig' });
      else z.push({ status: k.status, text: 'Zeit: fällig am ' + d + ' (in ' + tageDativ(k.tage) + ')' });
    }
    if (st.zaehler) {
      var q = st.zaehler;
      if (q.status === 'unbekannt') z.push({ status: 'unbekannt', text: 'Zähler: ' + q.grund });
      else if (q.rest < 0) z.push({ status: q.status, text: 'Zähler: um ' + zahlMit(-q.rest, einheit) + ' überschritten (fällig war bei ' + zahlMit(q.faelligBei, einheit) + ')' });
      else z.push({ status: q.status, text: 'Zähler: fällig bei ' + zahlMit(q.faelligBei, einheit) + ', noch ' + zahlMit(q.rest, einheit) });
    }
    if (!z.length && st.grund) z.push({ status: 'unbekannt', text: st.grund });
    return z;
  }

  function fristZeile(x, besitzer) {
    var st = x.status, einheit = x.zaehler ? x.zaehler.einheit : '';
    var zeilen = fristZeilen(st, einheit).sort(function (a, b) { return MM.Fristen.rang(b.status) - MM.Fristen.rang(a.status); });
    return h('li', null, h('a', { class: 'frist status-' + st.status, href: '#/frist/' + encodeURIComponent(x.frist.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: x.aktuell.werte.bezeichnung }),
        zeilen.length ? h('span', { class: 'frist-info', text: zeilen[0].text }) : null,
        besitzer ? h('span', { class: 'frist-info', text: 'an: ' + besitzer }) : null),
      h('span', { class: 'chip-status status-' + st.status, text: STATUS_TEXT[st.status] })));
  }

  /* Fristen eines Fahrzeugs oder einer Komponente. neuHash zum Beispiel '#/fahrzeug/<id>'. */
  function fristenBereich(fristen, neuHash, besitzerVon) {
    return h('section', { class: 'bereich', 'aria-label': 'Fristen' },
      h('h2', { text: 'Fristen' }),
      fristen.length ? h('ul', { class: 'fristen' }, fristen.map(function (x) { return fristZeile(x, besitzerVon ? besitzerVon(x) : null); }))
        : h('p', { class: 'leer-text', text: 'Noch keine Frist. Zum Beispiel Ölwechsel, Feuerlöscher oder Hauptuntersuchung.' }),
      h('a', { class: 'knopf leise', href: neuHash + '/frist/neu', text: 'Frist hinzufügen' }));
  }

  function zaehlerBereich(zaehler, neuHash, mitBesitzer) {
    return h('section', { class: 'bereich', 'aria-label': 'Zähler' },
      h('h2', { text: 'Zähler' }),
      zaehler.length ? h('ul', { class: 'fristen' }, zaehler.map(function (z) {
        return h('li', null, h('a', { class: 'frist zaehler-zeile', href: '#/zaehler/' + encodeURIComponent(z.zaehler.id) },
          h('span', { class: 'frist-text' },
            h('strong', { class: 'frist-name', text: z.bezeichnung }),
            mitBesitzer && z.komponenteId ? h('span', { class: 'frist-info', text: 'an: ' + z.besitzer }) : null),
          h('span', { class: 'zaehler-stand', text: z.stand ? zahlMit(z.stand.wert, z.einheit) : 'noch kein Stand' })));
      })) : h('p', { class: 'leer-text', text: 'Noch kein Zähler. Ein Zähler zählt Strecke (km) oder Betriebsstunden (h), zum Beispiel pro Motor.' }),
      h('a', { class: 'knopf leise', href: neuHash + '/zaehler/neu', text: 'Zähler hinzufügen' }));
  }


  /* ---------- Verlauf (gleich für Fahrzeuge und Komponenten) ---------- */
  function verlaufBlock(verlauf) {
    return h('details', { class: 'verlauf' },
      h('summary', { text: 'Verlauf der Eintragungen (' + verlauf.length + ')' }),
      h('ol', null, verlauf.map(function (v, i) {
        var e = v.eintrag;
        var kopfzeile = h('div', null,
          h('span', { class: 'wann', text: MM.Hilfen.zeitpunkt(e.erstelltAm) }),
          i === 0 ? h('span', { class: 'marke-aktuell', text: 'aktuell' }) : null);
        var text;
        if (!v.vorher) text = h('div', { text: 'Angelegt, per Handeingabe' });
        else text = h('div', null,
          h('span', { class: 'korrektur', text: v.art === 'verschoben' ? 'Verschoben' : (v.art === 'ausgeblendet' ? 'Ausgeblendet' : (v.art === 'eingeblendet' ? 'Wieder eingeblendet' : 'Korrektur zu Eintrag vom ' + MM.Hilfen.zeitpunkt(v.vorher.erstelltAm))) }),
          h('ul', null, v.aenderungen.map(function (u) {
            var alt = MM.Hilfen.wert(u.feld, u.alt), neu = MM.Hilfen.wert(u.feld, u.neu);
            return h('li', null, u.label + ': ',
              h('span', { class: 'alt', text: alt === null ? 'nicht angegeben' : alt }), ' → ',
              neu === null ? 'nicht angegeben' : neu);
          })));
        return h('li', { class: i === 0 ? 'aktuell' : null }, kopfzeile, text);
      })));
  }

  /* ---------- Liste von Komponenten (Hauptkomponenten oder Teile) ---------- */
  function komponentenKarte(x, anzahlKinder) {
    var w = x.aktuell.werte;
    var art = x.komponente.parentId ? null : MM.Komponenten.art(x.komponente.art);
    var zeile2 = [art ? art.name : null, [w.hersteller, w.modell].filter(Boolean).join(' '), w.anzahl > 1 ? w.anzahl + ' Stück' : null].filter(Boolean).join(', ');
    return h('li', null, h('a', { class: 'teil', href: '#/komponente/' + encodeURIComponent(x.komponente.id) },
      h('span', { class: 'teil-text' },
        h('strong', { class: 'teil-name', text: w.bezeichnung }),
        zeile2 ? h('span', { class: 'teil-info', text: zeile2 }) : null),
      anzahlKinder ? h('span', { class: 'teil-zahl', text: anzahlKinder === 1 ? '1 Teil darunter' : anzahlKinder + ' Teile darunter' }) : null));
  }

  /* Eingebaute zuerst, ausgebaute eingeklappt darunter. */
  function komponentenListeBlock(eintraege, anzahlVon) {
    var weg = eintraege.filter(function (x) { return x.komponente.ausgeblendet; });
    var drin = eintraege.filter(function (x) { return !x.komponente.ausgeblendet && !x.aktuell.werte.ausgebautAm; });
    var raus = eintraege.filter(function (x) { return !x.komponente.ausgeblendet && x.aktuell.werte.ausgebautAm; });
    return [
      drin.length ? h('ul', { class: 'teile' }, drin.map(function (x) { return komponentenKarte(x, anzahlVon(x)); })) : null,
      raus.length ? h('details', { class: 'ausgebaut' },
        h('summary', { text: 'Ausgebaut (' + raus.length + ')' }),
        h('ul', { class: 'teile' }, raus.map(function (x) { return komponentenKarte(x, anzahlVon(x)); }))) : null,
      weg.length ? h('details', { class: 'ausgebaut' },
        h('summary', { text: 'Ausgeblendet (' + weg.length + ')' }),
        h('ul', { class: 'teile' }, weg.map(function (x) { return komponentenKarte(x, anzahlVon(x)); }))) : null
    ];
  }

  /* Zusammengehörige Fahrzeuge (seit 2.0.45): am Anhänger „Gehört zu“, am Hauptfahrzeug die Liste der dazugehörigen Fahrzeuge. */
  function zusammengehoerigBlock(z) {
    if (!z || (!z.hauptfahrzeug && !z.alle.length)) return null;
    function link(x) { return h('a', { href: '#/fahrzeug/' + encodeURIComponent(x.id), text: x.name }); }
    return h('section', { class: 'block', 'aria-label': 'Zusammengehörige Fahrzeuge' },
      h('h2', { text: 'Zusammengehörige Fahrzeuge' }),
      z.hauptfahrzeug ? h('p', null, 'Gehört zu: ', link(z.hauptfahrzeug), z.hauptfahrzeug.artName ? ' (' + z.hauptfahrzeug.artName + ')' : '',
        z.kette.length > 1 ? h('span', { class: 'frist-info', text: ' – und das gehört wiederum zu ' + z.kette.slice(1).map(function (x) { return x.name; }).join(' › ') }) : null) : null,
      z.alle.length ? h('div', null, h('h3', { text: 'Dazugehörige Fahrzeuge' }),
        h('ul', { class: 'teile' }, z.alle.map(function (x) {
          return h('li', { style: x.tiefe > 1 ? 'margin-left:' + ((x.tiefe - 1) * 1.2) + 'rem' : null }, h('span', { class: 'teil' },
            h('span', { class: 'teil-text' }, h('strong', { class: 'teil-name' }, link(x)),
              h('span', { class: 'teil-info', text: [x.artName, x.tiefe > 1 ? 'gehört zu ' + x.ueber : null].filter(Boolean).join(', ') }))));
        }))) : null);
  }

  /* ---------- Seite: Fahrzeug mit Schalen ---------- */
  function komponentenName(komp, id) {
    var k = komp.filter(function (x) { return x.komponente.id === id; })[0];
    return k ? k.aktuell.werte.bezeichnung : 'Komponente';
  }

  var GRUND_WORT = { verkauft: 'Verkauft', verschenkt: 'Verschenkt', verschrottet: 'Verschrottet', sonstiges: 'Abgegeben' };
  /* Hinweis oben auf der Fahrzeugseite: abgegeben oder von einem früheren Besitzer übernommen. */
  function abgabeBanner(f) {
    var abg = f.fahrzeug.abgabe, ue = f.fahrzeug.uebernommen;
    if (abg) {
      return h('section', { class: 'block warn', role: 'status' },
        h('h2', { text: (GRUND_WORT[abg.grund] || 'Abgegeben') + ' am ' + MM.Hilfen.datum(abg.datum) }),
        h('p', { text: 'Dieses Fahrzeug ist abgegeben. Es steht nicht mehr in den Auswahllisten und lässt sich nicht mehr planen oder ändern. Du kannst alles lesen, die Übergabedatei und das PDF erzeugen oder das Fahrzeug wieder aktiv setzen.' }),
        abg.notiz ? h('p', { text: 'Notiz: ' + abg.notiz }) : null,
        h('p', { class: 'knopfzeile' },
          h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(f.fahrzeug.id) + '/uebergabe', text: 'Übergabe: Datei und PDF' })));
    }
    if (ue) {
      return h('p', { class: 'hinweis', text: 'Übernommen am ' + MM.Hilfen.datum(String(ue.am).slice(0, 10)) + ' von einem früheren Besitzer (' + (GRUND_WORT[ue.grund] || 'abgegeben').toLowerCase() + ' am ' + MM.Hilfen.datum(ue.abgabeDatum) + '). Die technische Historie davor gehört zu diesem Fahrzeug.' });
    }
    return null;
  }

  function seiteFahrzeug(id) {
    return Promise.all([daten.fahrzeugLaden(id), daten.komponentenListe(id), daten.fristenListe(id), daten.zaehlerListe(id), daten.dokumenteListe(id), daten.nachweiseListe('fahrzeug', id), daten.anforderungenListe(id), daten.fahrzeugStandort(id), daten.vorgaengeListe(id), daten.vorgangWarnung(id), daten.kostenAuswertung(id), daten.fahrzeugZuordnung(id)]).then(function (r) {
      var f = r[0], komp = r[1], fristen = r[2], zaehler = r[3], dokumente = r[4], nachweise = r[5], anforderungen = r[6], heimat = r[7], vorgaenge = r[8], vorgangWarn = r[9], kostenAuswertung = r[10], zuordnung = r[11];
      if (!f) { return seite('Nicht gefunden', [h('h1', { text: 'Fahrzeug nicht gefunden' }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]); }
      var a = MM.Fahrzeugarten.art(f.fahrzeug.art);
      var w = f.aktuell.werte;
      var abg = f.fahrzeug.abgabe || null;

      var gruppen = MM.Fahrzeugarten.gruppen(a.id).map(function (g) {
        var gefuellt = [], offen = [];
        g.felder.forEach(function (fe) {
          var t = MM.Hilfen.wert(fe, w[fe.key]);
          if (t === null) offen.push(fe.label); else gefuellt.push([h('dt', { text: fe.label }), h('dd', { text: t })]);
        });
        return h('section', { class: 'gruppe' },
          h('h3', { text: g.titel }),
          gefuellt.length ? h('dl', { class: 'daten' }, gefuellt) : null,
          offen.length ? h('p', { class: 'offen', text: 'Noch nicht angegeben: ' + offen.join(', ') }) : null);
      });

      var haupt = daten.sortiereKomponenten(komp.filter(function (x) { return !x.komponente.parentId; }));
      function kinderVon(x) { return komp.filter(function (y) { return y.komponente.parentId === x.komponente.id; }).length; }
      var s3 = h('section', { class: 'schale s3 live', 'aria-label': 'Hauptkomponenten' },
        h('div', { class: 'schale-name', text: 'Dritte Schale' }),
        h('h2', { text: 'Hauptkomponenten' }),
        haupt.length ? komponentenListeBlock(haupt, kinderVon)
          : h('p', { class: 'leer-text', text: 'Noch keine Hauptkomponente. Lege zum Beispiel Motor, Getriebe oder Heizung an. Darunter lässt sich beliebig tief aufschlüsseln.' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(id) + '/komponente/neu', text: 'Hauptkomponente hinzufügen' }));

      var s2 = h('section', { class: 'schale s2', 'aria-label': 'Äußere Hülle' },
        h('div', { class: 'schale-kopf' },
          h('div', { class: 'schale-name', text: 'Zweite Schale' }),
          h('h2', { text: 'Äußere Hülle' })),
        gruppen,
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(f.aktuell.erstelltAm) + ', per Handeingabe' }),
        s3);

      var s1 = h('div', { class: 'schale s1' },
        h('div', { class: 'schale-kopf' },
          h('div', { class: 'schale-name', text: 'Erste Schale: ' + a.name }),
          h('div', { class: 'fahrzeug-kopf' },
            h('h1', { text: w.bezeichnung }),
            schild(a.id, kennungVon(a.id, w)))),
        s2);

      var verlauf = verlaufBlock(f.verlauf);

      /* Überfällige oder bald fällige Fristen stehen ganz oben, damit man sie nicht übersieht. */
      var dringend = fristen.some(function (x) { return MM.Fristen.rang(x.status.status) >= MM.Fristen.rang('bald'); });
      var fristBlock = fristenBereich(fristen, '#/fahrzeug/' + encodeURIComponent(id), function (x) { return x.frist.komponenteId ? komponentenName(komp, x.frist.komponenteId) : null; });
      fristBlock.className += ' oben';

      var werkBlock = werkstattBereich(vorgaenge, '#/fahrzeug/' + encodeURIComponent(id), '#/fahrzeug/' + encodeURIComponent(id) + '/werkstatt', true);
      var werkDringend = vorgangWarn.stufe !== 'ok';
      if (werkDringend) werkBlock.className += ' oben';

      seite(w.bezeichnung, [
        krumen(WEG_FAHRZEUGE.concat([[w.bezeichnung]])),
        abgabeBanner(f),
        abg ? null : warnungKarte(vorgangWarn, null),
        werkDringend ? werkBlock : null,
        dringend ? fristBlock : null,
        s1,
        zusammengehoerigBlock(zuordnung),
        heimatstandortBereich(heimat, id),
        grundcheckKurzBlock(id),
        dringend ? null : fristBlock,
        werkDringend ? null : werkBlock,
        kostenAuswertung ? kostenFahrzeugBlock(kostenAuswertung, '#/fahrzeug/' + encodeURIComponent(id)) : null,
        zaehlerBereich(zaehler, '#/fahrzeug/' + encodeURIComponent(id), true),
        nachweiseBereich(nachweise, '#/fahrzeug/' + encodeURIComponent(id)),
        anforderungenBereich(anforderungen, id, MM.Fahrzeugarten.art(f.fahrzeug.art).welt),
        dokumenteBereich(dokumente.filter(function (x) { return !x.komponenteId && !x.vorgangId && !x.kostenId; }), '#/fahrzeug/' + encodeURIComponent(id),
          { anzahl: dokumente.length, href: '#/fahrzeug/' + encodeURIComponent(id) + '/dokumente' }),
        abg ? null : h('section', { class: 'block' },
          h('h2', { text: 'Fahrzeug abgeben' }),
          h('p', { text: 'Verkauft, verschenkt oder verschrottet? Dann gib das Fahrzeug hier ab. Es verschwindet aus den Auswahllisten, bleibt aber bei dir lesbar. Nichts wird gelöscht. Danach kannst du die technische Historie als Übergabedatei und als PDF weitergeben.' }),
          h('p', null, h('a', { class: 'knopf leise', href: '#/fahrzeug/' + encodeURIComponent(id) + '/abgeben', text: 'Fahrzeug abgeben' }))),
        verlauf
      ], abg
        ? h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: '#/fahrzeuge', text: 'Zur Liste' }),
          h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(id) + '/uebergabe', text: 'Übergabe' }))
        : h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/fahrzeuge', text: 'Zur Liste' }),
        h('a', { class: 'knopf leise', href: '#/aktivitaet/neu?fahrzeug=' + encodeURIComponent(id), text: 'Aktivität planen' }),
        h('a', { class: 'knopf leise', href: '#/logbuch/start?fahrzeug=' + encodeURIComponent(id), text: 'Logbuch jetzt starten' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
    });
  }

  /* ---------- Seite: anlegen / ändern ---------- */
  function optWert(o) { return typeof o === 'string' ? o : o.wert; }
  function optLabel(o) { return typeof o === 'string' ? o : o.label; }

  function feldElement(f, wert, fehler, aenderung) {
    var id = 'f-' + f.key;
    var eingabe;
    if (f.typ === 'auswahl' && f.darstellung === 'wahl') {
      return h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
        h('legend', { class: 'fest-art', text: f.label }),
        f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
        fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null,
        h('div', { class: 'artwahl' }, f.optionen.map(function (o) {
          var r = h('input', { type: 'radio', name: f.key, value: optWert(o), onchange: aenderung });
          if (wert === optWert(o)) r.checked = true;
          return h('label', null, r, h('span', { text: optLabel(o) }));
        })));
    }
    if (f.typ === 'baum') {
      var an = Array.isArray(wert) ? wert : [];
      return h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
        h('legend', { class: 'fest-art', text: f.label }),
        f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
        h('ul', { class: 'artbaum' }, f.optionen.map(function (o) {
          var c = h('input', { type: 'checkbox', name: f.key, value: o.wert, onchange: aenderung });
          if (an.indexOf(o.wert) >= 0) c.checked = true;
          return h('li', { style: 'margin-left:' + (o.tiefe * 1.4) + 'rem' }, h('label', { class: 'baumzeile' }, c, h('span', { text: o.label })));
        })),
        fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null);
    }
    if (f.typ === 'mehrfach') {
      var gew = Array.isArray(wert) ? wert : [];
      return h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
        h('legend', { class: 'fest-art', text: f.label }),
        f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
        h('div', { class: 'artwahl' }, f.optionen.map(function (o) {
          var c = h('input', { type: 'checkbox', name: f.key, value: optWert(o), onchange: aenderung });
          if (gew.indexOf(optWert(o)) >= 0) c.checked = true;
          return h('label', null, c, h('span', { text: optLabel(o) }));
        })),
        fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null);
    }
    if (f.typ === 'datei') {
      return h('div', { class: 'feld' + (fehler ? ' hat-fehler' : '') },
        h('label', { for: id, text: f.label }),
        f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
        h('div', { class: 'eingabe' }, h('input', { id: id, name: f.key, type: 'file', accept: f.accept || null, onchange: aenderung })),
        wert && wert.name ? h('p', { class: 'gewaehlt', text: 'Gewählt: ' + wert.name + (wert.size ? ' (' + MM.Hilfen.groesse(wert.size) + ')' : '') }) : null,
        fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null);
    }
    if (f.typ === 'auswahl') {
      eingabe = h('select', { id: id, name: f.key, onchange: aenderung },
        h('option', { value: '', text: f.leerText || '– bitte wählen –' }),
        f.optionen.map(function (o) { return h('option', { value: optWert(o), text: optLabel(o) }); }));
      eingabe.value = wert || '';
    } else if (f.typ === 'datum') {
      eingabe = h('input', { id: id, name: f.key, type: 'date', value: wert || '', oninput: aenderung });
    } else if (f.typ === 'zeit') {
      eingabe = h('input', { id: id, name: f.key, type: 'time', value: wert || '', oninput: aenderung });
    } else {
      eingabe = h('input', { id: id, name: f.key, type: 'text', autocomplete: 'off', autocapitalize: f.typ === 'text' ? 'sentences' : 'off',
        inputmode: f.typ === 'zahl' ? 'decimal' : (f.typ === 'ganzzahl' ? 'numeric' : null),
        value: wert === null || wert === undefined ? '' : String(wert).replace('.', f.typ === 'zahl' ? ',' : '.'),
        'aria-describedby': f.hilfe ? id + '-h' : null, 'aria-invalid': fehler ? 'true' : null, oninput: aenderung });
    }
    return h('div', { class: 'feld' + (fehler ? ' hat-fehler' : '') },
      h('label', { for: id, text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', id: id + '-h', text: f.hilfe }) : null,
      h('div', { class: 'eingabe' }, eingabe, f.einheit ? h('span', { class: 'einheit', text: f.einheit }) : null),
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null);
  }

  function seiteFormular(modus, fahrzeugId) {
    var laden = modus === 'aendern' ? daten.fahrzeugLaden(fahrzeugId) : Promise.resolve(null);
    return Promise.all([laden, daten.zuordnungAuswahl(modus === 'aendern' ? fahrzeugId : null)]).then(function (rr) {
      var vorhanden = rr[0], zuordnungOptionen = rr[1];
      if (modus === 'aendern' && !vorhanden) return seiteFahrzeug(fahrzeugId);
      var zustand = {
        art: vorhanden ? vorhanden.fahrzeug.art : null,
        alteArt: vorhanden ? vorhanden.fahrzeug.art : null,
        werte: vorhanden ? Object.assign({}, vorhanden.aktuell.werte) : {},
        fehler: {}, vorschau: null, gelesen: false, rueckfrage: null, trotzdem: false
      };
      var titel = modus === 'aendern' ? 'Angaben ändern' : 'Fahrzeug anlegen';
      var behaelter = h('div');

      function lesen() {
        /* Eingaben aus dem Formular in den Zustand übernehmen */
        var felder = behaelter.querySelectorAll('input[name], select[name]');
        Array.prototype.forEach.call(felder, function (el) {
          if (el.type === 'radio') return;
          zustand.werte[el.name] = el.value;
        });
      }

      function speichern(ev) {
        ev.preventDefault();
        lesen();
        var artWechsel = modus === 'aendern' && zustand.art && zustand.art !== zustand.alteArt;
        if (artWechsel && !zustand.gelesen) {
          zustand.fehler = { gelesen: 'Bitte zuerst die Hinweise zur neuen Fahrzeugart lesen und bestätigen.' };
          zeichne();
          var warn = behaelter.querySelector('.art-warnung');
          if (warn && warn.scrollIntoView) warn.scrollIntoView({ block: 'center' });
          return;
        }
        zustand.rueckfrage = null;
        var p = modus === 'aendern'
          ? daten.fahrzeugAendern(fahrzeugId, zustand.werte, artWechsel ? zustand.art : undefined)
          : daten.fahrzeugAnlegen(zustand.art, zustand.werte, { trotzdem: zustand.trotzdem });
        p.then(function (r) {
          /* Gleiche Kennung wie ein vorhandenes Fahrzeug (seit 2.0.46): nichts angelegt, erst fragen. */
          if (!r.ok && r.doppelt) {
            zustand.fehler = {};
            zustand.rueckfrage = { treffer: r.doppelt, text: r.fehler && r.fehler.allgemein };
            zeichne();
            var frage = behaelter.querySelector('#kennung-frage');
            if (frage) { if (frage.focus) frage.focus({ preventScroll: true }); if (frage.scrollIntoView) frage.scrollIntoView({ block: 'center' }); }
            return;
          }
          if (!r.ok) {
            zustand.fehler = r.fehler;
            zeichne();
            var ersterFehler = behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten');
            if (ersterFehler) { ersterFehler.focus ? ersterFehler.focus() : null; }
            return;
          }
          meldung = modus === 'aendern'
            ? (r.geaendert ? (r.artGeaendert ? 'Gespeichert. Die Fahrzeugart ist geändert, der frühere Stand bleibt im Verlauf sichtbar.' : 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.') : 'Es gab keine Änderung.')
            : 'Fahrzeug angelegt.';
          global.location.hash = '#/fahrzeug/' + encodeURIComponent(r.id);
        }).catch(fehlerSeite);
      }

      /* Was ändert sich, wenn die Fahrzeugart gewechselt wird? Wird gezeigt, bevor etwas gespeichert ist. */
      function artWarnung() {
        if (!zustand.art || zustand.art === zustand.alteArt) return h('p', { class: 'hilfe', text: 'Hast du die falsche Fahrzeugart gewählt? Wähle oben die richtige. Vor dem Speichern siehst du, was sich ändert. Nichts geht verloren.' });
        var v = zustand.vorschau;
        if (!v) return h('p', { class: 'hilfe', text: 'Einen Moment …' });
        var zeilen = [];
        zeilen.push(h('p', null, h('strong', { text: 'Fahrzeugart ändern: ' + v.alt.name + ' → ' + v.neu.name })));
        if (v.entfallen.length) {
          zeilen.push(h('p', { text: 'Diese Angaben gibt es bei der neuen Art nicht. Sie bleiben gespeichert und sind nur ausgeblendet. Wechselst du zurück, sind sie wieder da:' }));
          zeilen.push(h('ul', null, v.entfallen.map(function (x) { return h('li', { text: x.label + ': ' + x.wert }); })));
        }
        if (v.neuFelder.length) zeilen.push(h('p', { text: 'Neu dazu kommen: ' + v.neuFelder.join(', ') + '.' }));
        if (v.weltWechsel) zeilen.push(h('p', { text: 'Der Wechsel geht zwischen Land und Wasser. Status, Ereignisse und Cockpit-Knöpfe richten sich danach nach der neuen Art.' }));
        else zeilen.push(h('p', { text: 'Ereignisse und Cockpit-Knöpfe richten sich danach nach der neuen Art.' }));
        if (v.ereignisse) zeilen.push(h('p', { text: v.ereignisse === 1 ? '1 bereits erfasstes Ereignis im Logbuch gehört nicht mehr zur neuen Art. Es bleibt erhalten und wird markiert.' : v.ereignisse + ' bereits erfasste Ereignisse im Logbuch gehören nicht mehr zur neuen Art. Sie bleiben erhalten und werden markiert.' }));
        if (v.weltWechsel && v.anforderungen) zeilen.push(h('p', { text: 'Es gibt ' + (v.anforderungen === 1 ? '1 Anforderung' : v.anforderungen + ' Anforderungen') + ' an Skipper oder Fahrer. Bitte prüfe sie nach dem Wechsel.' }));
        zeilen.push(h('p', { class: 'hilfe', text: 'Der frühere Stand bleibt im Verlauf des Fahrzeugs sichtbar.' }));
        var ok = h('input', { type: 'checkbox', id: 'art-gelesen', onchange: function () { zustand.gelesen = ok.checked; } });
        if (zustand.gelesen) ok.checked = true;
        zeilen.push(h('div', { class: 'feld' + (zustand.fehler.gelesen ? ' hat-fehler' : '') },
          h('label', { class: 'checkzeile', for: 'art-gelesen' }, ok, h('span', { text: 'Ich habe die Hinweise gelesen und will die Fahrzeugart ändern.' })),
          zustand.fehler.gelesen ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.gelesen }) : null));
        return h('section', { class: 'art-warnung block warn', role: 'alert' }, zeilen);
      }

      /* Die Rückfrage bei gleicher Kennung (seit 2.0.46). Es ist noch nichts angelegt. */
      function rueckfrageBox() {
        var q = zustand.rueckfrage;
        if (!q) return null;
        return h('section', { class: 'block warn', role: 'alert', tabindex: '-1', id: 'kennung-frage' },
          h('p', null, h('strong', { text: 'Dieses Fahrzeug gibt es vielleicht schon.' })),
          h('p', { text: q.text }),
          h('p', { class: 'hilfe', text: 'Es wurde noch nichts angelegt. Meist ist es besser, das vorhandene Fahrzeug zu öffnen.' }),
          h('ul', null, q.treffer.map(function (t) { return h('li', null, h('a', { href: '#/fahrzeug/' + encodeURIComponent(t.id), text: '„' + t.name + '“ öffnen' })); })),
          h('p', { class: 'knopfzeile' },
            h('button', { class: 'knopf leise', type: 'button', text: 'Kennung ändern', onclick: function () {
              lesen(); zustand.rueckfrage = null; zustand.trotzdem = false; zeichne();
              var kz = behaelter.querySelector('input[name=kennzeichen], input[name=registriernummer], input[name=fin], input[name=hin]');
              if (kz && kz.focus) kz.focus();
            } }),
            h('button', { class: 'knopf gefahr', type: 'button', text: 'Trotzdem neu anlegen', onclick: function () {
              zustand.trotzdem = true;
              speichern({ preventDefault: function () {} });
            } })));
      }

      function zeichne() {
        behaelter.textContent = '';
        var teile = [];
        if (modus === 'neu' && !zustand.art) {
          teile.push(h('p', { text: 'Wähle zuerst die Fahrzeugart. Dann erscheinen die passenden Felder. Nur die Bezeichnung ist Pflicht.' }));
        }
        var fk = Object.keys(zustand.fehler);
        if (fk.length) {
          teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
            text: fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.' }));
        }
        if (zustand.rueckfrage) teile.push(rueckfrageBox());

        /* Fahrzeugart: beim Anlegen wählbar, beim Ändern seit 2.0.37 auch (mit Warnung vor dem Speichern) */
        if (modus === 'neu' || modus === 'aendern') {
          teile.push(h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
            h('legend', { class: 'fest-art', text: 'Fahrzeugart' }),
            zustand.fehler.art ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.art }) : null,
            h('div', { class: 'artwahl' }, MM.Fahrzeugarten.baum().filter(function (k) { return k.tiefe > 0; }).map(function (k, i, alleK) {
              if (!k.waehlbar) {
                var hatArten = alleK.some(function (x) { return x.waehlbar && MM.Fahrzeugarten.gehoertZu(x.id, k.id); });
                return k.tiefe === 1 && hatArten ? h('p', { class: 'hilfe artgruppe', text: k.name }) : null;
              }
              var a = MM.Fahrzeugarten.art(k.id);
              var r = h('input', { type: 'radio', name: 'art', value: a.id, onchange: function () {
                lesen(); zustand.art = a.id; zustand.fehler = {}; zustand.gelesen = false; zustand.vorschau = null;
                if (modus === 'aendern' && a.id !== zustand.alteArt) {
                  daten.artWechselVorschau(fahrzeugId, a.id).then(function (v) { if (zustand.art === a.id) { zustand.vorschau = v.ok ? v : null; zeichne(); } });
                }
                zeichne();
                var b = behaelter.querySelector('#f-bezeichnung'); if (b && modus === 'neu') b.focus({ preventScroll: true });
              } });
              if (zustand.art === a.id) r.checked = true;
              return h('label', { class: 'welt-' + a.welt }, r, h('span', { text: a.name }));
            })),
            h('p', { class: 'hilfe' }, 'Deine Art fehlt? ', h('a', { href: '#/fahrzeugarten', text: 'Fahrzeugarten verwalten' }))));
          if (modus === 'aendern') teile.push(artWarnung());
        }

        if (zustand.art) {
          teile.push(feldElement({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Wie du das Fahrzeug nennst, zum Beispiel „Fahrzeug A“' },
            zustand.werte.bezeichnung, zustand.fehler.bezeichnung));
          MM.Fahrzeugarten.gruppen(zustand.art).forEach(function (g) {
            teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
              h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }),
              g.felder.map(function (f) { return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key]); })));
          });
          /* Gehört zu (seit 2.0.45): gilt für jede Fahrzeugart. Die Auswahl zeigt nur Fahrzeuge, die keinen Kreis ergeben. */
          if (zuordnungOptionen.length || zustand.werte.hauptfahrzeugId) {
            teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
              h('legend', { class: 'fest-art', text: 'Zusammengehörig', style: 'margin-bottom:.6rem' }),
              feldElement({ key: 'hauptfahrzeugId', label: 'Gehört zu', typ: 'auswahl', leerText: '– gehört zu keinem anderen Fahrzeug –', optionen: zuordnungOptionen,
                hilfe: 'Zum Beispiel der Trailer zum Boot, das Dinghy zur Yacht oder der Motorradanhänger zum Wohnmobil. Das Fahrzeug bleibt eigenständig, du kannst es jederzeit ändern.' },
                zustand.werte.hauptfahrzeugId, zustand.fehler.hauptfahrzeugId)));
          }
        }
        anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
      }

      zeichne();
      seite(titel, [
        krumen(WEG_FAHRZEUGE.concat([[titel]])),
        h('h1', { text: titel }),
        behaelter
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: modus === 'aendern' ? '#/fahrzeug/' + encodeURIComponent(fahrzeugId) : '#/fahrzeuge', text: 'Abbrechen' }),
        h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
    });
  }

  /* ---------- Seite: Komponente (Schale 3 und tiefer) ---------- */
  function komponentenKrumen(c, mitSelbst) {
    var liste = WEG_FAHRZEUGE.slice(0, 3);
    liste.push([c.fahrzeugAktuell.werte.bezeichnung, '#/fahrzeug/' + encodeURIComponent(c.fahrzeug.id)]);
    c.weg.forEach(function (x) { liste.push([x.aktuell.werte.bezeichnung, '#/komponente/' + encodeURIComponent(x.komponente.id)]); });
    if (mitSelbst) liste.push([c.aktuell.werte.bezeichnung]);
    return liste;
  }
  function adresseUeber(c) {
    var eltern = c.weg.length ? c.weg[c.weg.length - 1] : null;
    return eltern ? '#/komponente/' + encodeURIComponent(eltern.komponente.id) : '#/fahrzeug/' + encodeURIComponent(c.fahrzeug.id);
  }

  function seiteKomponente(id) {
    return daten.komponenteLaden(id).then(function (c) {
      if (!c) {
        return seite('Nicht gefunden', [h('h1', { text: 'Komponente nicht gefunden' }),
          h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
      }
      return Promise.all([daten.fristenListe(c.fahrzeug.id), daten.zaehlerListe(c.fahrzeug.id), daten.dokumenteListe(c.fahrzeug.id), daten.vorgaengeListe(c.fahrzeug.id), daten.kostenListe(c.fahrzeug.id), daten.komponenteVerwendung(id)]).then(function (r) {
        return zeigeKomponente(id, c, r[0], r[1], r[2], r[3], r[4], r[5]);
      });
    });
  }

  function zeigeKomponente(id, c, alleFristen, alleZaehler, alleDokumente, alleVorgaenge, alleKosten, verwendung) {
      var w = c.aktuell.werte;
      var meineKosten = (alleKosten || []).filter(function (x) { return x.aktuell.werte.komponenteId === id; });
      var meineVorgaenge = (alleVorgaenge || []).filter(function (x) { return x.komponenteId === id; });
      var meineFristen = alleFristen.filter(function (x) { return x.frist.komponenteId === id; });
      var meineZaehler = alleZaehler.filter(function (z) { return z.komponenteId === id; });
      var meineDokumente = alleDokumente.filter(function (x) { return x.komponenteId === id && !x.vorgangId && !x.kostenId; });
      var art = c.komponente.parentId ? null : MM.Komponenten.art(c.komponente.art);
      var eltern = c.weg.length ? c.weg[c.weg.length - 1].aktuell.werte.bezeichnung : c.fahrzeugAktuell.werte.bezeichnung;

      var gruppen = MM.Komponenten.gruppen().map(function (g) {
        var gefuellt = [], offen = [];
        g.felder.forEach(function (fe) {
          var t = MM.Hilfen.wert(fe, w[fe.key]);
          if (t === null) { offen.push(fe.label); return; }
          if (fe.typ === 'liste') {
            w[fe.key].forEach(function (z) { gefuellt.push([h('dt', { text: z.name }), h('dd', { text: MM.Komponenten.merkmalWert(z) })]); });
          } else gefuellt.push([h('dt', { text: fe.label }), h('dd', { text: t })]);
        });
        return h('section', { class: 'gruppe' },
          h('h3', { text: g.titel }),
          gefuellt.length ? h('dl', { class: 'daten' }, gefuellt) : null,
          offen.length ? h('p', { class: 'offen', text: 'Noch nicht angegeben: ' + offen.join(', ') }) : null);
      });

      var teile = h('section', { class: 'teile-block' },
        h('h2', { text: 'Teile darunter' }),
        c.kinder.length ? komponentenListeBlock(c.kinder, function (x) { return x.anzahlKinder; })
          : h('p', { class: 'leer-text', text: 'Noch kein Teil darunter. Du kannst beliebig tief weiter aufschlüsseln.' }),
        h('a', { class: 'knopf', href: '#/komponente/' + encodeURIComponent(id) + '/neu', text: 'Teil hinzufügen' }));

      var spaeter = h('section', { class: 'schale s3', 'aria-label': 'Folgt' },
        h('p', { text: 'Nachweise zu diesem Teil folgen in einem späteren Schritt.' }));

      var karte = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Schale ' + c.tiefe + (art ? ': ' + art.name : ': Teil') }),
        h('h1', { text: w.bezeichnung }),
        h('p', { class: 'gehoert', text: 'gehört zu: ' + eltern }),
        c.komponente.ausgeblendet ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Diese Komponente ist ausgeblendet. Sie zählt nicht für die Ausrüstungsprüfung, den Grundcheck und den Motorschalter. Die Teile darunter sind mit verdeckt.' })
          : (c.weg.some(function (x) { return x.komponente.ausgeblendet; }) ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Eine Komponente darüber ist ausgeblendet und verdeckt dieses Teil. Es zählt deshalb nicht für die Prüfungen.' }) : null),
        w.ausgebautAm ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Ausgebaut am ' + MM.Hilfen.datum(w.ausgebautAm) + '. Dieses Teil ist nicht mehr im Fahrzeug.' }) : null,
        gruppen,
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(c.aktuell.erstelltAm) + ', per Handeingabe' }),
        teile,
        fristenBereich(meineFristen, '#/komponente/' + encodeURIComponent(id), null),
        werkstattBereich(meineVorgaenge, '#/komponente/' + encodeURIComponent(id), null, false),
        zaehlerBereich(meineZaehler, '#/komponente/' + encodeURIComponent(id), false),
        dokumenteBereich(meineDokumente, '#/komponente/' + encodeURIComponent(id), null),
        kostenBlock(meineKosten, '#/fahrzeug/' + encodeURIComponent(c.fahrzeug.id) + '/kosten/neu?komponente=' + encodeURIComponent(id), 'Noch kein Betrag an diesem Teil. Hier stehen Kosten, die du diesem Teil zuordnest, zum Beispiel Wartung oder ein Ersatzteil.', 'Kosten eintragen'),
        spaeter,
        komponentenVerwalten(c, verwendung));

      seite(w.bezeichnung, [krumen(komponentenKrumen(c, true)), karte, verlaufBlock(c.verlauf)],
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: adresseUeber(c), text: 'Zurück' }),
          h('a', { class: 'knopf', href: '#/komponente/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
  }

  /* Löschen, Ausblenden und Verschieben stehen auf der Seite der Komponente (seit 2.0.45). */
  function komponentenVerwalten(c, v) {
    var id = c.komponente.id, aus = !!c.komponente.ausgeblendet;
    var benutzt = v && v.benutzt;
    var knoepfe = [
      h('a', { class: 'knopf leise', href: '#/komponente/' + encodeURIComponent(id) + '/verschieben', text: 'Verschieben' }),
      h('button', { class: 'knopf leise', type: 'button', text: aus ? 'Wieder einblenden' : 'Ausblenden', onclick: function () {
        daten.komponenteAusblenden(id, !aus).then(function (r) {
          meldung = r.ok ? (aus ? 'Wieder eingeblendet.' : 'Ausgeblendet. Der Verlauf hält es fest.') : (r.fehler && r.fehler.allgemein) || 'Das hat nicht geklappt.';
          return zeige();
        }).catch(fehlerSeite);
      } })
    ];
    if (!benutzt) knoepfe.push(h('button', { class: 'knopf gefahr', type: 'button', text: 'Löschen', onclick: function () {
      var frage = 'Diese Komponente wirklich löschen?' + (v && v.anzahlUnter ? ' Dabei verschwinden auch ' + (v.anzahlUnter === 1 ? '1 Teil' : v.anzahlUnter + ' Teile') + ' darunter.' : '') + ' Das lässt sich nicht rückgängig machen.';
      if (!global.confirm(frage)) return;
      daten.komponenteLoeschen(id).then(function (r) {
        if (!r.ok) { meldung = (r.fehler && r.fehler.allgemein) || 'Das hat nicht geklappt.'; return zeige(); }
        meldung = 'Gelöscht.' + (r.anzahlUnter ? ' (mit ' + (r.anzahlUnter === 1 ? '1 Teil' : r.anzahlUnter + ' Teilen') + ' darunter)' : '');
        global.location.hash = adresseUeber(c);
      }).catch(fehlerSeite);
    } }));
    return h('section', { class: 'bereich', 'aria-label': 'Verwalten' },
      h('h2', { text: 'Verwalten' }),
      h('p', { class: 'hilfe', text: benutzt
        ? 'Diese Komponente wird benutzt (' + v.gruende.join(', ') + (v.inUnterteilen ? ', zum Teil an einem Teil darunter' : '') + '). Benutzte Komponenten werden nicht gelöscht. Du kannst sie ausblenden oder an die richtige Stelle verschieben.'
        : 'Diese Komponente wird nirgends benutzt. Du kannst sie löschen, ausblenden oder verschieben.' }),
      h('p', { class: 'knopfzeile' }, knoepfe));
  }

  /* ---------- Seite: Komponente verschieben (seit 2.0.45) ---------- */
  function seiteKomponentenVerschieben(id) {
    return Promise.all([daten.komponenteLaden(id), daten.komponenteZiele(id)]).then(function (r) {
      var c = r[0], ziele = r[1];
      if (!c) return seite('Nicht gefunden', [h('h1', { text: 'Komponente nicht gefunden' }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
      var zurueck = '#/komponente/' + encodeURIComponent(id);
      var zustand = { ziel: c.komponente.parentId || '', art: c.komponente.art || 'sonstiges', fehler: {} };
      var behaelter = h('div');
      function lesen() {
        var z = behaelter.querySelector('select[name="ziel"]'); if (z) zustand.ziel = z.value;
        var a = behaelter.querySelector('input[name="art"]:checked'); if (a) zustand.art = a.value;
      }
      function speichern(ev) {
        ev.preventDefault(); lesen();
        daten.komponenteVerschieben(id, { parentId: zustand.ziel || null, art: zustand.art }).then(function (res) {
          if (!res.ok) { zustand.fehler = res.fehler || {}; zeichne(); return; }
          meldung = res.geaendert ? 'Verschoben. Der Verlauf hält fest, von wo nach wo.' : 'Es gab keine Änderung.';
          global.location.hash = zurueck;
        }).catch(fehlerSeite);
      }
      function zeichne() {
        behaelter.textContent = '';
        var fk = Object.keys(zustand.fehler);
        var teile = [];
        if (fk.length) teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1', text: zustand.fehler.allgemein || zustand.fehler.parentId || zustand.fehler.art || zustand.fehler.kurzname || 'Bitte eine Angabe prüfen.' }));
        teile.push(h('div', { class: 'feld' },
          h('label', { for: 'f-ziel', text: 'Neuer Platz' }),
          h('p', { class: 'hilfe', text: 'Verschoben wird die Komponente mit allen Teilen darunter. Fristen, Zähler, Kosten, Dokumente und Vorgänge bleiben dran.' }),
          h('div', { class: 'eingabe' }, (function () {
            var sel = h('select', { id: 'f-ziel', name: 'ziel', onchange: function () { lesen(); zeichne(); } },
              h('option', { value: '', text: 'Direkt am Fahrzeug „' + c.fahrzeugAktuell.werte.bezeichnung + '“ (wird Hauptkomponente)' }),
              ziele.map(function (z) { return h('option', { value: z.id, text: 'Unter: ' + z.weg }); }));
            sel.value = zustand.ziel; return sel;
          })())));
        if (!zustand.ziel) {
          teile.push(h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
            h('legend', { class: 'fest-art', text: 'Art der Hauptkomponente' }),
            h('div', { class: 'artwahl' }, MM.Komponenten.arten().map(function (a) {
              var rd = h('input', { type: 'radio', name: 'art', value: a.id }); if (zustand.art === a.id) rd.checked = true;
              return h('label', null, rd, h('span', { text: a.name }));
            }))));
        }
        anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
      }
      zeichne();
      seite('Verschieben', [krumen(komponentenKrumen(c, false).concat([[c.aktuell.werte.bezeichnung, zurueck], ['Verschieben']])), h('h1', { text: c.aktuell.werte.bezeichnung + ' verschieben' }), behaelter],
        h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: zurueck, text: 'Abbrechen' }),
          h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Verschieben' })));
    });
  }

  /* ---------- Seite: Komponente anlegen / ändern ---------- */
  /*
   * Merkmale mit Liste, Einheit und Bezugsgröße (seit 2.0.45). Der Name kommt aus der Merkmal-Liste (Vorschläge) oder ist neu,
   * die Einheit kommt aus der Einheiten-Liste oder wird neu angelegt. Wählt man ein bekanntes Merkmal, steht die Einheit schon da, sie bleibt änderbar.
   * listen: { merkmale: [{ label, einheit, bezug }], einheiten: [{ label }] } (nur eingeblendete)
   */
  var EINHEIT_NEU = '__neu__';
  function merkmaleElement(f, zeilen, fehler, hinzu, weg, listen) {
    listen = listen || { merkmale: [], einheiten: [] };
    var vorschlaege = h('datalist', { id: 'merkmal-vorschlaege' }, listen.merkmale.map(function (m) { return h('option', { value: m.label }); }));
    return h('fieldset', { class: 'feld liste' + (fehler ? ' hat-fehler' : '') },
      h('legend', { class: 'feld-label', text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
      vorschlaege,
      h('div', { class: 'merkmale' }, zeilen.map(function (z, i) {
        var einheiten = listen.einheiten.map(function (e) { return e.label; });
        if (z.einheit && einheiten.indexOf(z.einheit) < 0) einheiten.push(z.einheit);
        var sel = h('select', { class: 'merkmal-einheit', 'aria-label': 'Einheit ' + (i + 1) },
          h('option', { value: '', text: '– keine Einheit –' }),
          einheiten.map(function (e) { return h('option', { value: e, text: e }); }),
          h('option', { value: EINHEIT_NEU, text: 'Neue Einheit …' }));
        sel.value = z.neueEinheit !== undefined && z.neueEinheit !== '' ? EINHEIT_NEU : (z.einheit || '');
        var neuEin = h('input', { class: 'merkmal-einheit-neu', type: 'text', autocomplete: 'off', placeholder: 'Neue Einheit', 'aria-label': 'Neue Einheit ' + (i + 1), value: z.neueEinheit || '' });
        neuEin.style.display = sel.value === EINHEIT_NEU ? '' : 'none';
        sel.addEventListener('change', function () { neuEin.style.display = sel.value === EINHEIT_NEU ? '' : 'none'; if (sel.value === EINHEIT_NEU) neuEin.focus(); });
        var bezug = h('input', { class: 'merkmal-bezug', type: 'text', autocomplete: 'off', placeholder: 'Bezugsgröße (zum Beispiel 100 km)', 'aria-label': 'Bezugsgröße ' + (i + 1), value: z.bezug || '' });
        var name = h('input', { class: 'merkmal-name', type: 'text', autocomplete: 'off', placeholder: 'Merkmal', list: 'merkmal-vorschlaege', 'aria-label': 'Merkmal ' + (i + 1), value: z.name });
        name.addEventListener('change', function () {
          var m = listen.merkmale.filter(function (x) { return MM.Komponenten.gleichText(x.label, name.value); })[0];
          if (!m || sel.value !== '' || bezug.value.trim() !== '') return;
          if (m.einheit && Array.prototype.some.call(sel.options, function (o) { return o.value === m.einheit; })) sel.value = m.einheit;
          if (m.bezug) bezug.value = m.bezug;
        });
        return h('div', { class: 'merkmal-zeile' },
          name,
          h('input', { class: 'merkmal-wert', type: 'text', autocomplete: 'off', placeholder: 'Wert', 'aria-label': 'Wert ' + (i + 1), value: z.wert }),
          sel, neuEin, bezug,
          h('button', { type: 'button', class: 'knopf leise klein', text: 'Entfernen', onclick: function () { weg(i); } }));
      })),
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null,
      h('button', { type: 'button', class: 'knopf leise', text: 'Merkmal hinzufügen', onclick: hinzu }));
  }

  /* modus: 'neu-haupt' (id = Fahrzeug), 'neu-teil' (id = übergeordnete Komponente), 'aendern' (id = Komponente) */
  function seiteKomponentenFormular(modus, id) {
    var laden;
    if (modus === 'neu-haupt') laden = daten.fahrzeugLaden(id).then(function (f) { return f ? { fz: f, c: null } : null; });
    else laden = daten.komponenteLaden(id).then(function (c) { return c ? { fz: null, c: c } : null; });

    return Promise.all([laden, daten.merkmaleListe(), daten.einheitenListe()]).then(function (rr) {
      var k = rr[0];
      var merkmalListen = { merkmale: rr[1].filter(function (x) { return !x.ausgeblendet; }), einheiten: rr[2].filter(function (x) { return !x.ausgeblendet; }) };
      if (!k) return seite('Nicht gefunden', [h('h1', { text: 'Nicht gefunden' }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
      var c = k.c;
      var fahrzeugId = k.fz ? k.fz.fahrzeug.id : c.fahrzeug.id;
      var titel = modus === 'neu-haupt' ? 'Hauptkomponente hinzufügen' : (modus === 'neu-teil' ? 'Teil hinzufügen' : 'Angaben ändern');

      var zurueck, weg;
      if (modus === 'neu-haupt') {
        zurueck = '#/fahrzeug/' + encodeURIComponent(fahrzeugId);
        weg = WEG_FAHRZEUGE.slice(0, 3).concat([[k.fz.aktuell.werte.bezeichnung, zurueck], [titel]]);
      } else if (modus === 'neu-teil') {
        zurueck = '#/komponente/' + encodeURIComponent(id);
        weg = komponentenKrumen(c, false).concat([[c.aktuell.werte.bezeichnung, zurueck], [titel]]);
      } else {
        zurueck = '#/komponente/' + encodeURIComponent(id);
        weg = komponentenKrumen(c, false).concat([[c.aktuell.werte.bezeichnung, zurueck], [titel]]);
      }

      var zustand = {
        art: modus === 'aendern' ? c.komponente.art : null,
        werte: modus === 'aendern' ? JSON.parse(JSON.stringify(c.aktuell.werte)) : { merkmale: [] },
        fehler: {}
      };
      if (!Array.isArray(zustand.werte.merkmale)) zustand.werte.merkmale = [];
      /* Vom Grundcheck (seit 2.0.40): Name und Menge sind vorbelegt, der Nutzer bestätigt. Es wird nichts von selbst gespeichert. */
      if (modus === 'neu-haupt' && hashParam('name')) {
        zustand.art = 'sonstiges';
        zustand.werte.bezeichnung = hashParam('name');
        if (/^\d+$/.test(hashParam('anzahl'))) zustand.werte.anzahl = hashParam('anzahl');
      }
      var istHaupt = modus === 'neu-haupt' || (modus === 'aendern' && !c.komponente.parentId);
      var behaelter = h('div');

      function lesen() {
        Array.prototype.forEach.call(behaelter.querySelectorAll('input[name], select[name]'), function (el) {
          if (el.type !== 'radio') zustand.werte[el.name] = el.value;
        });
        if (behaelter.querySelector('.merkmale')) {
          zustand.werte.merkmale = Array.prototype.map.call(behaelter.querySelectorAll('.merkmal-zeile'), function (z) {
            var sel = z.querySelector('.merkmal-einheit').value;
            return { name: z.querySelector('.merkmal-name').value, wert: z.querySelector('.merkmal-wert').value,
              einheit: sel === EINHEIT_NEU ? '' : sel, neueEinheit: sel === EINHEIT_NEU ? z.querySelector('.merkmal-einheit-neu').value : '',
              bezug: z.querySelector('.merkmal-bezug').value };
          });
        }
      }

      function speichern(ev) {
        ev.preventDefault();
        lesen();
        var p;
        if (modus === 'neu-haupt') p = daten.komponenteAnlegen(fahrzeugId, null, zustand.art, zustand.werte);
        else if (modus === 'neu-teil') p = daten.komponenteAnlegen(fahrzeugId, id, null, zustand.werte);
        else p = daten.komponenteAendern(id, zustand.werte);
        p.then(function (r) {
          if (!r.ok) {
            zustand.fehler = r.fehler;
            zeichne();
            var erster = behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten');
            if (erster && erster.focus) erster.focus();
            return;
          }
          if (modus === 'aendern') meldung = r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.';
          else meldung = modus === 'neu-haupt' ? 'Hauptkomponente angelegt.' : 'Teil angelegt.';
          global.location.hash = zurueck;
        }).catch(fehlerSeite);
      }

      function zeichne() {
        behaelter.textContent = '';
        var teile = [];
        if (modus === 'neu-haupt' && !zustand.art) {
          teile.push(h('p', { text: 'Wähle zuerst die Art. Dann erscheinen die Felder. Nur die Bezeichnung ist Pflicht.' }));
        }
        var fk = Object.keys(zustand.fehler);
        if (fk.length) {
          teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
            text: zustand.fehler.allgemein ? zustand.fehler.allgemein : (fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.') }));
        }

        if (modus === 'neu-haupt') {
          teile.push(h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
            h('legend', { class: 'fest-art', text: 'Art der Hauptkomponente' }),
            zustand.fehler.art ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.art }) : null,
            h('div', { class: 'artwahl' }, MM.Komponenten.arten().map(function (a) {
              var r = h('input', { type: 'radio', name: 'art', value: a.id, onchange: function () {
                lesen(); zustand.art = a.id; zustand.fehler = {};
                if (!String(zustand.werte.bezeichnung || '').trim() && a.id !== 'sonstiges') zustand.werte.bezeichnung = a.name;
                zeichne();
                var b = behaelter.querySelector('#f-bezeichnung'); if (b) b.focus({ preventScroll: true });
              } });
              if (zustand.art === a.id) r.checked = true;
              return h('label', null, r, h('span', { text: a.name }));
            }))));
        } else if (modus === 'aendern' && istHaupt) {
          teile.push(h('p', null, 'Art: ', h('span', { class: 'fest-art', text: MM.Komponenten.art(zustand.art).name }),
            h('span', { class: 'hilfe', text: ' (lässt sich nicht ändern)' })));
        } else if (modus === 'neu-teil') {
          teile.push(h('p', { class: 'gehoert', text: 'gehört zu: ' + c.aktuell.werte.bezeichnung }));
        }

        if (modus !== 'neu-haupt' || zustand.art) {
          teile.push(feldElement({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text',
            hilfe: istHaupt ? 'Zum Beispiel „Motor Backbord“. Bei zwei gleichen Teilen hilft ein Zusatz.' : 'Zum Beispiel „Einspritzpumpe“' },
            zustand.werte.bezeichnung, zustand.fehler.bezeichnung));
          MM.Komponenten.gruppen().forEach(function (g) {
            teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
              h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }),
              g.felder.map(function (f) {
                if (f.typ === 'liste') {
                  return merkmaleElement(f, zustand.werte.merkmale || [], zustand.fehler[f.key],
                    function () {
                      lesen(); zustand.werte.merkmale.push({ name: '', wert: '', einheit: '', bezug: '' }); zeichne();
                      var alle = behaelter.querySelectorAll('.merkmal-name'); if (alle.length) alle[alle.length - 1].focus();
                    },
                    function (i) { lesen(); zustand.werte.merkmale.splice(i, 1); zeichne(); }, merkmalListen);
                }
                return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key]);
              })));
          });
        }
        anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
        kurznameVorschlagAnbinden();
      }

      /* Bei einem Motor macht die App aus der Bezeichnung einen Vorschlag für den Kurznamen (zum Beispiel „Motor Steuerbord“
         wird MOSTB). Der Nutzer sieht ihn im Feld und kann ihn ändern. Einen selbst geänderten Kurznamen überschreibt die App nicht mehr. */
      function kurznameVorschlagAnbinden() {
        var motor = (modus === 'neu-haupt' && zustand.art === 'motor') || (modus === 'aendern' && istHaupt && zustand.art === 'motor');
        var bez = behaelter.querySelector('#f-bezeichnung'), kurz = behaelter.querySelector('#f-kurzname');
        if (!motor || !bez || !kurz) return;
        var vorschlag = function () { return MM.Komponenten.kurznameVorschlag(bez.value); };
        if (zustand.kurzAuto === undefined) {
          var bisher = String(zustand.werte.kurzname || '').trim();
          zustand.kurzAuto = modus === 'neu-haupt' || !bisher || bisher.toUpperCase() === MM.Komponenten.kurznameVorschlag(zustand.werte.bezeichnung);
        }
        if (zustand.kurzAuto && !kurz.value.trim()) { kurz.value = vorschlag(); zustand.werte.kurzname = kurz.value; }
        bez.addEventListener('input', function () {
          if (!zustand.kurzAuto) return;
          kurz.value = vorschlag(); zustand.werte.kurzname = kurz.value;
        });
        kurz.addEventListener('input', function () {
          var t = kurz.value.trim().toUpperCase();
          zustand.kurzAuto = t === '' || t === vorschlag();
        });
        kurz.addEventListener('change', function () { kurz.value = kurz.value.trim().toUpperCase(); });
      }

      zeichne();
      seite(titel, [krumen(weg), h('h1', { text: titel }), behaelter],
        h('div', { class: 'leiste' },
          h('a', { class: 'knopf leise', href: zurueck, text: 'Abbrechen' }),
          h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
    });
  }

  /* Zeilen-Editor für eigene Angaben einer Nachweisart: Beschriftung, Typ, Stelle auf dem Papier. */
  /* Kostenzeilen (seit 2.0.29): je Zeile eine Art und ein Betrag, jede Zeile wird ein eigener Posten. f.optionen = die Arten. */
  function kostenzeilenElement(f, zeilen, fehler, hinzu, weg) {
    var summe = 0, gueltig = false;
    zeilen.forEach(function (z) { var n = Number(String(z.betrag == null ? '' : z.betrag).replace(/\s/g, '').replace(',', '.')); if (isFinite(n) && n > 0) { summe += n; gueltig = true; } });
    return h('fieldset', { class: 'feld liste' + (fehler ? ' hat-fehler' : '') },
      h('legend', { class: 'feld-label', text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
      h('div', { class: 'zeilen-editor-kz kostenzeilen', 'data-feld': f.key }, zeilen.map(function (z, i) {
        var sel = h('select', { class: 'kz-art', 'aria-label': 'Art der Kosten ' + (i + 1) }, h('option', { value: '', text: '– Art wählen –' }),
          f.optionen.map(function (o) { return h('option', { value: o.wert, text: o.label }); }));
        sel.value = z.kostenart || '';
        return h('div', { class: 'zeile-edit kz-edit' }, sel,
          h('input', { class: 'kz-neu', type: 'text', autocomplete: 'off', placeholder: 'oder neue Art, z. B. Kurtaxe', 'aria-label': 'Neue Art ' + (i + 1), value: z.neueKostenart || '' }),
          h('input', { class: 'kz-betrag', type: 'text', inputmode: 'decimal', autocomplete: 'off', placeholder: 'Betrag', 'aria-label': 'Betrag ' + (i + 1), value: z.betrag == null ? '' : z.betrag }),
          h('button', { type: 'button', class: 'knopf leise klein', text: 'Entfernen', onclick: function () { weg(i); } }));
      })),
      gueltig ? h('p', { class: 'hilfe', text: 'Summe: ' + euro(summe) + (f.einheit && f.einheit !== '€' ? ' (in ' + f.einheit + ')' : '') }) : null,
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null,
      h('button', { type: 'button', class: 'knopf leise', text: 'Zeile hinzufügen', onclick: hinzu }));
  }

  function zeilenElement(f, zeilen, fehler, hinzu, weg) {
    return h('fieldset', { class: 'feld liste' + (fehler ? ' hat-fehler' : '') },
      h('legend', { class: 'feld-label', text: f.label }),
      f.hilfe ? h('p', { class: 'hilfe', text: f.hilfe }) : null,
      h('div', { class: 'zeilen-editor', 'data-feld': f.key }, zeilen.map(function (z, i) {
        return h('div', { class: 'zeile-edit', 'data-key': z.key || '' },
          h('input', { class: 'ze-label', type: 'text', autocomplete: 'off', placeholder: 'Beschriftung, z. B. Geburtsdatum', 'aria-label': 'Beschriftung ' + (i + 1), value: z.label }),
          (function () {
            var sel = h('select', { class: 'ze-typ', 'aria-label': 'Art der Angabe ' + (i + 1) }, MM.Nachweise.FELDTYPEN.map(function (t) { return h('option', { value: t.wert, text: t.label }); }));
            sel.value = z.typ || 'text'; return sel;
          })(),
          h('input', { class: 'ze-papier', type: 'text', autocomplete: 'off', placeholder: 'Stelle auf dem Papier (freiwillig)', 'aria-label': 'Stelle auf dem Papier ' + (i + 1), value: z.papier || '' }),
          h('button', { type: 'button', class: 'knopf leise klein', text: 'Entfernen', onclick: function () { weg(i); } }));
      })),
      fehler ? h('p', { class: 'fehler', role: 'alert', text: fehler }) : null,
      h('button', { type: 'button', class: 'knopf leise', text: 'Angabe hinzufügen', onclick: hinzu }));
  }

  /* ---------- Baum der Fahrzeugarten mit Häkchen (Ereignisarten und Aktivitätsarten, seit 2.0.17 gemeinsam) ---------- */
  /* Setzt werteStart.gilt und gibt zurück: optionen (für das Baum-Feld) und nachAenderung (für einfachFormular). */
  function zuordnungBaumTeile(werteStart) {
    werteStart.gilt = MM.Logbuch.auswahlAusZuordnung(werteStart.zuordnung);
    var vorherGilt = werteStart.gilt.slice();
    return {
      optionen: MM.Fahrzeugarten.baum().map(function (k) { return { wert: k.id, label: k.name, tiefe: k.tiefe }; }),
      nachAenderung: function (key, z) {
        if (key !== 'gilt') return;
        var jetzt = z.werte.gilt || [];
        var geaendert = jetzt.filter(function (i) { return vorherGilt.indexOf(i) < 0; }).concat(vorherGilt.filter(function (i) { return jetzt.indexOf(i) < 0; }))[0];
        if (!geaendert) return;
        z.werte.gilt = MM.Logbuch.auswahlUmschalten(vorherGilt, geaendert, jetzt.indexOf(geaendert) >= 0);
        vorherGilt = z.werte.gilt.slice();
        z.fokusWert = geaendert;
      }
    };
  }

  /* Die Aktivitätsarten (Optionen fürs Auswahlfeld), die zum gewählten Fahrzeug passen. Ohne Fahrzeug: alle nicht
     ausgeblendeten. behalteId: die Art, die schon an der Aktivität hängt, bleibt wählbar. */
  function aktivitaetsartOptionen(ctx, fahrzeugId, behalteId) {
    var fz = ctx.fahrzeuge.filter(function (x) { return x.fahrzeug.id === fahrzeugId; })[0];
    var fzArt = fz ? fz.fahrzeug.art : null;
    return ctx.arten.filter(function (x) {
      if (behalteId && x.objekt.id === behalteId) return true;
      if (x.aktuell.werte.ausgeblendet === 'ja') return false;
      return !fzArt || MM.Logbuch.ereignisartGilt(x.aktuell.werte.zuordnung, fzArt);
    }).map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });
  }
  /* Vorgabe beim Logbuch-Start: „Ausfahrt“, wenn sie zum Fahrzeug passt, sonst nichts. */
  function vorgabeAktivitaetsart(ctx, fahrzeugId) {
    var opt = aktivitaetsartOptionen(ctx, fahrzeugId, null);
    var ausfahrt = ctx.arten.filter(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === 'ausfahrt'; })[0];
    return ausfahrt && opt.some(function (o) { return o.wert === ausfahrt.objekt.id; }) ? ausfahrt.objekt.id : '';
  }

  /* ---------- Einfaches Formular (für Fristen und Zähler) ---------- */
  /*
   * opts: titel, krumen, zurueck, werte, gruppen(zustand) -> [{titel, hinweis, felder}],
   *       neuzeichnenBei [Feldnamen], nachAenderung(key, zustand), intro,
   *       speichern(werte) -> Promise({ok, fehler, ...}), meldung(r), danach(r) -> Adresse
   */
  function einfachFormular(opts) {
    var zustand = { werte: JSON.parse(JSON.stringify(opts.werte || {})), fehler: {} };
    var behaelter = h('div');

    function lesen() {
      /* Mehrfachauswahl: alle angekreuzten Werte pro Feld */
      var boxen = {};
      Array.prototype.forEach.call(behaelter.querySelectorAll('input[type="checkbox"][name]'), function (el) {
        (boxen[el.name] = boxen[el.name] || []); if (el.checked) boxen[el.name].push(el.value);
      });
      Object.keys(boxen).forEach(function (k) { zustand.werte[k] = boxen[k]; });
      /* Zeilen (eigene Angaben einer Nachweisart) */
      Array.prototype.forEach.call(behaelter.querySelectorAll('.zeilen-editor[data-feld]'), function (ed) {
        zustand.werte[ed.getAttribute('data-feld')] = Array.prototype.map.call(ed.querySelectorAll('.zeile-edit'), function (z) {
          return { key: z.getAttribute('data-key') || '', label: z.querySelector('.ze-label').value, typ: z.querySelector('.ze-typ').value, papier: z.querySelector('.ze-papier').value };
        });
      });
      Array.prototype.forEach.call(behaelter.querySelectorAll('.kostenzeilen[data-feld]'), function (ed) {
        zustand.werte[ed.getAttribute('data-feld')] = Array.prototype.map.call(ed.querySelectorAll('.kz-edit'), function (z) {
          return { kostenart: z.querySelector('.kz-art').value, neueKostenart: z.querySelector('.kz-neu').value, betrag: z.querySelector('.kz-betrag').value };
        });
      });
      Array.prototype.forEach.call(behaelter.querySelectorAll('input[name], select[name]'), function (el) {
        if (el.type === 'checkbox') return;
        if (el.type === 'radio') { if (el.checked) zustand.werte[el.name] = el.value; }
        else if (el.type === 'file') { if (el.files && el.files[0]) zustand.werte[el.name] = el.files[0]; }
        else zustand.werte[el.name] = el.value;
      });
    }
    function beiAenderung(key) {
      return function () {
        lesen();
        if (opts.nachAenderung) opts.nachAenderung(key, zustand);
        zustand.fehler = {};
        zeichne();
        var el = (zustand.fokusWert ? behaelter.querySelector('[name="' + key + '"][value="' + zustand.fokusWert + '"]') : null)
          || behaelter.querySelector('[name="' + key + '"]:checked') || behaelter.querySelector('[name="' + key + '"]');
        zustand.fokusWert = null;
        if (el && el.focus) el.focus({ preventScroll: true });
      };
    }
    function speichern(ev) {
      ev.preventDefault();
      lesen();
      opts.speichern(zustand.werte).then(function (r) {
        if (!r.ok) {
          zustand.fehler = r.fehler || {};
          zeichne();
          var erster = behaerter_erster();
          if (erster && erster.focus) erster.focus();
          return;
        }
        meldung = opts.meldung(r);
        var ziel = opts.danach(r);
        if (global.location.hash === ziel) zeige(); else global.location.hash = ziel;
      }).catch(fehlerSeite);
    }
    function behaerter_erster() { return behaelter.querySelector('.hat-fehler input, .hat-fehler select, .fehlerkasten'); }

    function zeichne() {
      behaelter.textContent = '';
      var teile = [];
      var fk = Object.keys(zustand.fehler);
      if (fk.length) {
        teile.push(h('div', { class: 'fehlerkasten', role: 'alert', tabindex: '-1',
          text: zustand.fehler.allgemein ? zustand.fehler.allgemein : (fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.') }));
      }
      opts.gruppen(zustand).forEach(function (g) {
        var felder = g.felder.map(function (f) {
          if (f.typ === 'kostenzeilen') {
            return kostenzeilenElement(f, zustand.werte[f.key] || [], zustand.fehler[f.key],
              function () { lesen(); (zustand.werte[f.key] = zustand.werte[f.key] || []).push({ kostenart: '', neueKostenart: '', betrag: '' }); zeichne();
                var alle = behaelter.querySelectorAll('.kz-art'); if (alle.length) alle[alle.length - 1].focus(); },
              function (i) { lesen(); zustand.werte[f.key].splice(i, 1); zeichne(); });
          }
          if (f.typ === 'zeilen') {
            return zeilenElement(f, zustand.werte[f.key] || [], zustand.fehler[f.key],
              function () { lesen(); (zustand.werte[f.key] = zustand.werte[f.key] || []).push({ key: '', label: '', typ: 'text', papier: '' }); zeichne();
                var alle = behaelter.querySelectorAll('.ze-label'); if (alle.length) alle[alle.length - 1].focus(); },
              function (i) { lesen(); zustand.werte[f.key].splice(i, 1); zeichne(); });
          }
          var hook = opts.neuzeichnenBei && opts.neuzeichnenBei.indexOf(f.key) >= 0 ? beiAenderung(f.key) : undefined;
          return feldElement(f, zustand.werte[f.key], zustand.fehler[f.key], hook);
        });
        teile.push(h('fieldset', { style: 'border:0;padding:0;margin:0;display:grid;gap:1.1rem' },
          g.titel ? h('legend', { class: 'fest-art', text: g.titel, style: 'margin-bottom:.6rem' }) : null,
          g.hinweis ? h('p', { class: 'hilfe', text: g.hinweis }) : null,
          felder));
      });
      anhaengen(behaelter, h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern }, teile));
    }

    zeichne();
    seite(opts.titel, [opts.krumen, h('h1', { text: opts.titel }), opts.intro || null, behaelter],
      h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: opts.zurueck, text: 'Abbrechen' }),
        h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Speichern' })));
  }

  function nichtGefunden(text) {
    return seite('Nicht gefunden', [h('h1', { text: text }), h('p', null, h('a', { href: '#/fahrzeuge', text: 'Zurück zu meinen Fahrzeugen' }))]);
  }

  function ortKrumen(fz, fzId, komp) {
    var liste = WEG_FAHRZEUGE.slice(0, 3);
    liste.push([fz.werte.bezeichnung, '#/fahrzeug/' + encodeURIComponent(fzId)]);
    if (komp) liste.push([komp.aktuell.werte.bezeichnung, '#/komponente/' + encodeURIComponent(komp.komponente.id)]);
    return liste;
  }

  /* ---------- Seite: Frist ---------- */
  function seiteFrist(id) {
    return daten.fristLaden(id).then(function (f) {
      if (!f) return nichtGefunden('Frist nicht gefunden');
      var w = f.aktuell.werte, st = f.status, einheit = f.zaehler ? f.zaehler.einheit : '';
      var besitzer = f.komponente ? f.komponenteAktuell.werte.bezeichnung : f.fahrzeugAktuell.werte.bezeichnung;
      var zurueck = f.komponente ? '#/komponente/' + encodeURIComponent(f.komponente.id) : '#/fahrzeug/' + encodeURIComponent(f.fahrzeug.id);

      var regeln = [];
      if (w.kalenderWert) regeln.push('alle ' + w.kalenderWert + ' ' + (w.kalenderEinheit === 'jahre' ? (w.kalenderWert === 1 ? 'Jahr' : 'Jahre') : (w.kalenderWert === 1 ? 'Monat' : 'Monate')));
      if (w.zaehlerId && w.zaehlerWert) regeln.push('alle ' + zahlMit(w.zaehlerWert, einheit) + (f.zaehler ? ' (Zähler: ' + f.zaehler.bezeichnung + ')' : ''));
      var regelText = regeln.join(' oder ') + (regeln.length > 1 ? ', was zuerst eintritt' : '');

      var zeilen = fristZeilen(st, einheit);
      var letzte = f.letzte;
      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: MM.Fristen.labelVon(MM.Fristen.KATEGORIEN, w.kategorie) + ' an: ' + besitzer }),
        h('h1', { text: w.bezeichnung }),
        h('p', null, h('span', { class: 'chip-status gross status-' + st.status, text: STATUS_TEXT[st.status] })),
        h('ul', { class: 'status-zeilen' }, zeilen.map(function (z) { return h('li', { class: 'status-' + z.status, text: z.text }); })),
        h('section', { class: 'gruppe' }, h('h3', { text: 'Regel' }),
          h('dl', { class: 'daten' },
            h('dt', { text: 'Fällig' }), h('dd', { text: regelText }),
            h('dt', { text: 'Wirkung' }), h('dd', { text: MM.Fristen.labelVon(MM.Fristen.WIRKUNGEN, w.wirkung) }),
            h('dt', { text: 'Vorwarnung' }), h('dd', { text: [w.kalenderWert ? tageText(w.vorwarnTage || 0) : null,
              (w.zaehlerId && w.vorwarnZaehler !== null && w.vorwarnZaehler !== undefined) ? zahlMit(w.vorwarnZaehler, einheit) : null].filter(Boolean).join(' und ') || 'keine' })),
          w.wirkung !== 'warnen' ? h('p', { class: 'hinweis', text: 'Eine Sperre oder Einschränkung wirkt später bei Verleih und Aktivitäten. Das folgt in späteren Schritten.' }) : null),
        h('section', { class: 'gruppe' }, h('h3', { text: 'Zuletzt erledigt' }),
          letzte ? h('p', { text: MM.Hilfen.datum(letzte.datum) + (letzte.zaehlerstand !== null && letzte.zaehlerstand !== undefined && f.zaehler ? ', bei ' + zahlMit(letzte.zaehlerstand, einheit) : '') +
            (letzte.art === 'ausgangswert' ? ' (Ausgangswert bei Anlage der Frist)' : '') }) : h('p', { class: 'leer-text', text: 'Noch nichts eingetragen.' })),
        h('p', null, h('a', { class: 'knopf leise', href: '#/frist/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));

      var erledigungen = h('details', { class: 'verlauf' },
        h('summary', { text: 'Erledigungen (' + f.durchfuehrungen.length + ')' }),
        h('ol', null, f.durchfuehrungen.map(function (d, i) {
          return h('li', { class: i === 0 ? 'aktuell' : null },
            h('div', null, h('span', { class: 'wann', text: MM.Hilfen.datum(d.datum) }),
              d.zaehlerstand !== null && d.zaehlerstand !== undefined ? ', bei ' + zahlMit(d.zaehlerstand, einheit) : ''),
            d.notiz ? h('div', { text: d.notiz }) : null);
        })));

      seite(w.bezeichnung, [
        krumen(ortKrumen(f.fahrzeugAktuell, f.fahrzeug.id, f.komponente ? { komponente: f.komponente, aktuell: f.komponenteAktuell } : null).concat([[w.bezeichnung]])),
        kopf, erledigungen, verlaufBlock(f.verlauf)
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/frist/' + encodeURIComponent(id) + '/erledigt', text: 'Erledigt eintragen' })));
    });
  }

  /* ---------- Formular: Frist anlegen / ändern ---------- */
  /* modus: 'neu-fz' (id = Fahrzeug), 'neu-komp' (id = Komponente), 'aendern' (id = Frist) */
  function fristFormular(modus, id) {
    var laden;
    if (modus === 'neu-fz') {
      laden = Promise.all([daten.fahrzeugLaden(id), daten.zaehlerListe(id)]).then(function (r) {
        return r[0] ? { fahrzeugId: id, komponenteId: null, fz: r[0].aktuell, komp: null, zl: r[1], zurueck: '#/fahrzeug/' + encodeURIComponent(id), werte: null } : null;
      });
    } else if (modus === 'neu-komp') {
      laden = daten.komponenteLaden(id).then(function (c) {
        if (!c) return null;
        return daten.zaehlerListe(c.fahrzeug.id).then(function (zl) {
          return { fahrzeugId: c.fahrzeug.id, komponenteId: id, fz: c.fahrzeugAktuell, komp: { komponente: c.komponente, aktuell: c.aktuell },
            zl: zl, zurueck: '#/komponente/' + encodeURIComponent(id), werte: null };
        });
      });
    } else {
      laden = daten.fristLaden(id).then(function (f) {
        if (!f) return null;
        return { fahrzeugId: f.fahrzeug.id, komponenteId: f.komponente ? f.komponente.id : null, fz: f.fahrzeugAktuell,
          komp: f.komponente ? { komponente: f.komponente, aktuell: f.komponenteAktuell } : null, zl: f.zaehlerListe,
          zurueck: '#/frist/' + encodeURIComponent(id), werte: JSON.parse(JSON.stringify(f.aktuell.werte)), name: f.aktuell.werte.bezeichnung };
      });
    }
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var neu = modus !== 'aendern';
      var titel = neu ? 'Frist hinzufügen' : 'Frist ändern';
      var start = k.werte || { kategorie: 'wartung', kalenderEinheit: 'monate', wirkung: 'warnen', vorwarnTage: '30' };
      var weg = ortKrumen(k.fz, k.fahrzeugId, k.komp);
      if (!neu) weg.push([k.name, k.zurueck]);
      weg.push([titel]);

      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: k.zurueck, werte: start, neuzeichnenBei: ['zaehlerId'],
        intro: neu ? h('p', { text: 'Eine Frist kann nach Zeit, nach Zähler oder nach beidem fällig werden. Gilt beides, entscheidet, was zuerst eintritt.' }) : null,
        gruppen: function (z) {
          var gewaehlt = k.zl.filter(function (x) { return x.zaehler.id === z.werte.zaehlerId; })[0] || null;
          var einheit = gewaehlt ? gewaehlt.einheit : '';
          function f(key, extra) {
            var def = MM.Fristen.felder(true).filter(function (x) { return x.key === key; })[0];
            return Object.assign({}, def, extra || {});
          }
          var gruppen = [
            { titel: 'Frist', felder: [
              { key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Zum Beispiel „Ölwechsel“ oder „Feuerlöscher prüfen“' },
              f('kategorie', { leerText: '– bitte wählen –' }) ] },
            { titel: 'Kalender', felder: [f('kalenderWert'), f('kalenderEinheit', { leerText: 'Monate' })] }
          ];
          var zfelder = [];
          if (k.zl.length) {
            zfelder.push(f('zaehlerId', { typ: 'auswahl', leerText: 'Kein Zähler', hilfe: 'Wähle, wenn die Frist nach Strecke oder Betriebsstunden gelten soll.',
              optionen: k.zl.map(function (x) { return { wert: x.zaehler.id, label: x.label }; }) }));
            if (gewaehlt) zfelder.push(f('zaehlerWert', { einheit: einheit }));
          }
          gruppen.push({ titel: 'Zähler', hinweis: k.zl.length ? null : 'Es gibt noch keinen Zähler. Lege zuerst einen Zähler am Fahrzeug oder an der Komponente an, wenn die Frist nach Strecke oder Betriebsstunden gelten soll.', felder: zfelder });
          var wf = [f('wirkung', { leerText: 'Nur warnen' }), f('vorwarnTage')];
          if (gewaehlt) wf.push(f('vorwarnZaehler', { einheit: einheit }));
          gruppen.push({ titel: 'Wirkung und Vorwarnung', felder: wf });
          if (neu) {
            var af = [f('zuletztAm')];
            if (gewaehlt) af.push(f('zuletztStand', { einheit: einheit }));
            gruppen.push({ titel: 'Ausgangswert', hinweis: 'Ab wann soll gerechnet werden? Ohne Angabe zählt die Frist ab heute.', felder: af });
          }
          return gruppen;
        },
        speichern: function (w) { return neu ? daten.fristAnlegen(k.fahrzeugId, k.komponenteId, w) : daten.fristAendern(id, w); },
        meldung: function (r) { return neu ? 'Frist angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/frist/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Formular: Frist erledigt eintragen ---------- */
  function erledigtFormular(id) {
    return daten.fristLaden(id).then(function (f) {
      if (!f) return nichtGefunden('Frist nicht gefunden');
      var z = f.zaehler, w = f.aktuell.werte;
      var start = { datum: daten.heute(), zaehlerstand: z && z.stand ? String(z.stand.wert) : '', notiz: '' };
      var weg = ortKrumen(f.fahrzeugAktuell, f.fahrzeug.id, f.komponente ? { komponente: f.komponente, aktuell: f.komponenteAktuell } : null);
      weg.push([w.bezeichnung, '#/frist/' + encodeURIComponent(id)]); weg.push(['Erledigt eintragen']);
      var felder = [{ key: 'datum', label: 'Erledigt am', typ: 'datum' }];
      if (z) felder.push({ key: 'zaehlerstand', label: 'Zählerstand dabei', typ: 'zahl', einheit: z.einheit,
        hilfe: z.stand ? 'Aktueller Stand: ' + zahlMit(z.stand.wert, z.einheit) + '. Ein höherer Stand wird auch im Zähler eingetragen.' : 'Der Stand, als die Frist erledigt wurde.' });
      felder.push({ key: 'notiz', label: 'Notiz', typ: 'text', hilfe: 'Zum Beispiel die Werkstatt oder was gemacht wurde' });
      einfachFormular({
        titel: 'Erledigt eintragen', krumen: krumen(weg), zurueck: '#/frist/' + encodeURIComponent(id), werte: start,
        intro: h('p', { text: w.bezeichnung + ': Danach beginnt die Rechnung der Frist von vorn. Die frühere Erledigung bleibt sichtbar.' }),
        gruppen: function () { return [{ titel: null, felder: felder }]; },
        speichern: function (v) { return daten.durchfuehrungAnlegen(id, v); },
        meldung: function () { return 'Erledigt eingetragen.'; },
        danach: function () { return '#/frist/' + encodeURIComponent(id); }
      });
    });
  }

  /* ---------- Werkstatt: Vorgänge (Störungen und Arbeiten, seit 2.0.24) ---------- */
  var VG_EINSTUFUNG = {
    nicht: ['Nicht einsatzfähig', 'status-ueberfaellig'],
    bedingt: ['Nur bedingt einsatzfähig', 'status-bald']
  };

  function vorgangChip(w) {
    if (w.status === 'erledigt') return ['Erledigt', 'status-ok'];
    if (VG_EINSTUFUNG[w.auswirkung]) return VG_EINSTUFUNG[w.auswirkung];
    return [w.art === 'arbeit' ? 'Arbeit offen' : 'Störung offen', 'status-unbekannt'];
  }

  function vorgangZeile(x, mitBesitzer) {
    var w = x.aktuell.werte, chip = vorgangChip(w);
    var info = [MM.Werkstatt.labelVon(MM.Werkstatt.ARTEN, w.art)];
    if (w.art === 'arbeit' && w.ausfuehrung) info.push(MM.Werkstatt.labelVon(MM.Werkstatt.AUSFUEHRUNGEN, w.ausfuehrung));
    info.push(w.status === 'erledigt' ? 'erledigt am ' + MM.Hilfen.datum(w.erledigtAm) : 'seit ' + MM.Hilfen.datum(w.gemeldetAm));
    return h('li', null, h('a', { class: 'frist ' + chip[1], href: '#/vorgang/' + encodeURIComponent(x.vorgang.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: w.bezeichnung }),
        h('span', { class: 'frist-info', text: info.join(', ') }),
        mitBesitzer && x.besitzer ? h('span', { class: 'frist-info', text: 'an: ' + x.besitzer }) : null),
      h('span', { class: 'chip-status ' + chip[1], text: chip[0] })));
  }

  /* Werkstatt-Block am Fahrzeug oder an einer Komponente. neuHash zum Beispiel '#/fahrzeug/<id>'. */
  function werkstattBereich(liste, neuHash, alleHash, mitBesitzer) {
    var offen = liste.filter(function (x) { return x.aktuell.werte.status === 'offen'; });
    var erledigt = liste.length - offen.length;
    return h('section', { class: 'bereich', 'aria-label': 'Werkstatt' },
      h('h2', { text: 'Werkstatt' }),
      offen.length ? h('ul', { class: 'fristen' }, offen.map(function (x) { return vorgangZeile(x, mitBesitzer); }))
        : h('p', { class: 'leer-text', text: liste.length ? 'Nichts offen.' : 'Noch kein Vorgang. Hier meldest du Störungen und planst Arbeiten.' }),
      alleHash && liste.length ? h('p', null, h('a', { href: alleHash, text: 'Alle Vorgänge' + (erledigt ? ' (davon ' + erledigt + ' erledigt)' : '') })) : null,
      h('div', { class: 'leiste-inline' },
        h('a', { class: 'knopf leise', href: neuHash + '/stoerung/neu', text: 'Störung melden' }),
        h('a', { class: 'knopf leise', href: neuHash + '/arbeit/neu', text: 'Arbeit planen' })));
  }

  /*
   * Warnkarte: Das Fahrzeug ist nicht oder nur bedingt einsatzfähig, aber für die nächste Zeit versprochen.
   * Entscheiden (trotzdem nutzen oder absagen) lässt sich beim Vorgang. vorgang = der Vorgang, bei dem diese Seite gerade ist (oder null).
   */
  function warnungKarte(w, vorgang, nachEntscheidung) {
    if (!w || w.stufe === 'ok' || !w.aktivitaeten.length) return null;
    var nicht = w.stufe === 'nicht';
    var erster = w.vorgaenge[0];
    return h('section', { class: 'bereich oben warnung ' + (nicht ? 'status-ueberfaellig' : 'status-bald'), role: 'alert', 'aria-label': 'Warnung' },
      h('h2', { text: nicht ? 'Das Fahrzeug ist nicht einsatzfähig, aber versprochen' : 'Das Fahrzeug ist nur bedingt einsatzfähig, aber versprochen' }),
      h('p', { text: 'Für die nächste Zeit ist das Fahrzeug eingeplant. Kann es trotzdem genutzt werden, oder muss abgesagt werden?' }),
      h('ul', { class: 'fristen' }, w.aktivitaeten.map(function (a) {
        var x = a.aktivitaet, wa = x.aktuell.werte;
        var entsch = vorgang ? vorgang.entscheidungen[x.objekt.id] : null;
        var meinTrotzdem = !!(entsch && entsch.entscheidung === 'trotzdem');
        var knoepfe = [];
        if (vorgang) {
          if (meinTrotzdem) {
            knoepfe.push(h('button', { class: 'knopf leise klein', type: 'button', text: 'Entscheidung zurücknehmen', onclick: function () {
              daten.vorgangEntscheiden(vorgang.vorgang.id, x.objekt.id, 'offen').then(function (r) { meldung = r.ok ? 'Die Entscheidung ist zurückgenommen.' : (r.fehler && r.fehler.allgemein); return zeige(); }).catch(fehlerSeite);
            } }));
          } else {
            knoepfe.push(h('button', { class: 'knopf klein', type: 'button', text: 'Trotzdem nutzen', onclick: function () {
              daten.vorgangEntscheiden(vorgang.vorgang.id, x.objekt.id, 'trotzdem').then(function (r) { meldung = r.ok ? 'Festgehalten: „' + wa.bezeichnung + '“ wird trotzdem genutzt.' : (r.fehler && r.fehler.allgemein); return zeige(); }).catch(fehlerSeite);
            } }));
          }
          knoepfe.push(h('a', { class: 'knopf gefahr klein', href: '#/aktivitaet/' + encodeURIComponent(x.objekt.id) + '/stornieren', text: 'Absagen' }));
        }
        return h('li', null, h('div', { class: 'frist ak' },
          h('span', { class: 'frist-text' },
            h('a', { class: 'frist-name', href: '#/aktivitaet/' + encodeURIComponent(x.objekt.id), text: wa.bezeichnung }),
            h('span', { class: 'frist-info', text: [x.artName, zeitraumText(wa)].filter(Boolean).join(', ') }),
            vorgang ? null : h('span', { class: 'frist-info', text: a.trotzdem ? 'Trotzdem nutzen ist festgehalten.' : 'Noch nicht entschieden.' }),
            vorgang && meinTrotzdem ? h('span', { class: 'frist-info', text: 'Trotzdem nutzen, festgehalten am ' + jetztText(entsch.am) }) : null,
            knoepfe.length ? h('span', { class: 'leiste-inline' }, knoepfe) : null)));
      })),
      !vorgang && erster ? h('p', null, h('a', { class: 'knopf', href: '#/vorgang/' + encodeURIComponent(erster.vorgang.id), text: 'Beim Vorgang entscheiden' })) : null,
      vorgang ? h('p', { class: 'hinweis', text: 'Absagen ist jederzeit möglich. Die App entscheidet nichts allein, und die Verantwortung bleibt beim Halter und Fahrer.' }) : null);
  }

  /* ---------- Seite: Werkstatt über alle Fahrzeuge ---------- */
  function seiteWerkstattUebersicht() {
    return Promise.all([daten.fahrzeugListe(), daten.vorgaengeUebersicht()]).then(function (r) {
      var liste = r[0], u = r[1];
      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Werkstatt']]), h('h1', { text: 'Werkstatt' }),
        h('p', { text: 'Störungen melden, Arbeiten planen und erledigen. Wähle das Fahrzeug.' })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Hier ist noch kein Fahrzeug. Lege zuerst ein Fahrzeug an.' })));
      else {
        inhalt.push(h('ul', { class: 'liste' }, liste.map(function (x) {
          var a = MM.Fahrzeugarten.art(x.fahrzeug.art), z = u[x.fahrzeug.id] || { offen: 0, nicht: 0, bedingt: 0 };
          var hinweis = z.nicht ? h('span', { class: 'hinweis-frist status-ueberfaellig', text: z.nicht === 1 ? '1 Vorgang: nicht einsatzfähig' : z.nicht + ' Vorgänge: nicht einsatzfähig' })
            : (z.bedingt ? h('span', { class: 'hinweis-frist status-bald', text: z.bedingt === 1 ? '1 Vorgang: nur bedingt einsatzfähig' : z.bedingt + ' Vorgänge: nur bedingt einsatzfähig' }) : null);
          return h('li', null, h('a', { class: 'zeile welt-' + a.welt, href: '#/fahrzeug/' + encodeURIComponent(x.fahrzeug.id) + '/werkstatt' },
            h('span', { class: 'zeile-text' },
              h('strong', { class: 'zeile-name', text: x.aktuell.werte.bezeichnung }),
              h('span', { class: 'zeile-art', text: a.name }),
              h('span', { class: 'zeile-art', text: z.offen ? (z.offen === 1 ? '1 offener Vorgang' : z.offen + ' offene Vorgänge') : 'Nichts offen' }),
              hinweis),
            schild(a.id, kennungVon(a.id, x.aktuell.werte))));
        })));
      }
      seite('Werkstatt', inhalt, h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/funktionen', text: 'Zurück' }),
        h('a', { class: 'knopf leise', href: '#/adressen', text: 'Adressen' })));
    });
  }

  /* ---------- Seite: alle Vorgänge eines Fahrzeugs ---------- */
  function seiteWerkstatt(fahrzeugId) {
    return Promise.all([daten.fahrzeugLaden(fahrzeugId), daten.vorgaengeListe(fahrzeugId), daten.vorgangWarnung(fahrzeugId)]).then(function (r) {
      var f = r[0], liste = r[1], warnung = r[2];
      if (!f) return nichtGefunden('Fahrzeug nicht gefunden');
      var fz = '#/fahrzeug/' + encodeURIComponent(fahrzeugId);
      var offen = liste.filter(function (x) { return x.aktuell.werte.status === 'offen'; });
      var erledigt = liste.filter(function (x) { return x.aktuell.werte.status === 'erledigt'; });
      seite('Werkstatt: ' + f.aktuell.werte.bezeichnung, [
        krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Werkstatt', '#/werkstatt'], [f.aktuell.werte.bezeichnung]]),
        h('h1', { text: 'Werkstatt: ' + f.aktuell.werte.bezeichnung }),
        warnungKarte(warnung, null),
        h('section', { class: 'bereich', 'aria-label': 'Offen' }, h('h2', { text: 'Offen (' + offen.length + ')' }),
          offen.length ? h('ul', { class: 'fristen' }, offen.map(function (x) { return vorgangZeile(x, true); })) : h('p', { class: 'leer-text', text: 'Nichts offen.' })),
        erledigt.length ? h('details', { class: 'ausgebaut' }, h('summary', { text: 'Erledigt (' + erledigt.length + ')' }),
          h('ul', { class: 'fristen' }, erledigt.map(function (x) { return vorgangZeile(x, true); }))) : null
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: fz, text: 'Zum Fahrzeug' }),
        h('a', { class: 'knopf leise', href: fz + '/arbeit/neu', text: 'Arbeit planen' }),
        h('a', { class: 'knopf', href: fz + '/stoerung/neu', text: 'Störung melden' })));
    });
  }

  /* ---------- Seite: ein Vorgang ---------- */
  function seiteVorgang(id) {
    return daten.vorgangLaden(id).then(function (v) {
      if (!v) return nichtGefunden('Vorgang nicht gefunden');
      return Promise.all([daten.vorgangWarnung(v.fahrzeug.id), daten.dokumenteFuerVorgang(id), daten.kostenListe(v.fahrzeug.id)]).then(function (rr) {
        var warnung = rr[0], dokumente = rr[1];
        var meineKosten = rr[2].filter(function (x) { return x.aktuell.werte.vorgangId === id; });
        var w = v.aktuell.werte, chip = vorgangChip(w);
        var besitzer = v.komponente ? v.komponenteAktuell.werte.bezeichnung : v.fahrzeugAktuell.werte.bezeichnung;
        var zurueck = '#/fahrzeug/' + encodeURIComponent(v.fahrzeug.id) + '/werkstatt';
        var u = '#/vorgang/' + encodeURIComponent(id);
        var zeilen = [[h('dt', { text: 'Eingetragen am' }), h('dd', { text: MM.Hilfen.datum(w.gemeldetAm) })],
          [h('dt', { text: 'Einschränkung' }), h('dd', { text: MM.Werkstatt.labelVon(MM.Werkstatt.AUSWIRKUNGEN, w.auswirkung) })]];
        if (w.beschreibung) zeilen.push([h('dt', { text: w.art === 'arbeit' ? 'Beschreibung' : 'Was ist los?' }), h('dd', { text: w.beschreibung })]);
        if (v.vorgang.ereignisId) zeilen.push([h('dt', { text: 'Im Logbuch' }), h('dd', null, h('a', { href: '#/ereignis/' + encodeURIComponent(v.vorgang.ereignisId), text: 'Zum Ereignis „Störung“' }))]);
        if (w.art === 'arbeit') {
          zeilen.push([h('dt', { text: 'Wer macht die Arbeit' }), h('dd', { text: MM.Werkstatt.labelVon(MM.Werkstatt.AUSFUEHRUNGEN, w.ausfuehrung) || 'Noch nicht festgelegt' })]);
          if (w.arbeit) zeilen.push([h('dt', { text: 'Was soll gemacht werden' }), h('dd', { text: w.arbeit })]);
          if (v.adresse) zeilen.push([h('dt', { text: 'Werkstatt, Lieferant oder Händler' }),
            h('dd', null, h('a', { href: '#/adresse/' + encodeURIComponent(v.adresse.objekt.id), text: v.adresse.aktuell.werte.bezeichnung }),
              ' (' + MM.Werkstatt.labelVon(MM.Werkstatt.ADRESSARTEN, v.adresse.aktuell.werte.art) + ')')]);
        }
        if (w.status === 'erledigt') {
          zeilen.push([h('dt', { text: 'Erledigt am' }), h('dd', { text: MM.Hilfen.datum(w.erledigtAm) })]);
          if (w.erledigtNotiz) zeilen.push([h('dt', { text: 'Notiz' }), h('dd', { text: w.erledigtNotiz })]);
        }
        var kopf = h('section', { class: 'schale sx' },
          h('div', { class: 'schale-name', text: MM.Werkstatt.labelVon(MM.Werkstatt.ARTEN, w.art) + ' an: ' + besitzer }),
          h('h1', { text: w.bezeichnung }),
          h('p', null, h('span', { class: 'chip-status gross ' + chip[1], text: chip[0] })),
          h('dl', { class: 'daten' }, zeilen),
          w.status === 'offen' ? h('p', { class: 'hinweis', text: w.art === 'stoerung' ? 'Wenn klar ist, wie es behoben wird, mach daraus eine Arbeit: selbst erledigen oder durch eine Werkstatt.' : 'Ist die Arbeit gemacht, trage sie als erledigt ein.' }) : null,
          h('p', null, w.status === 'offen' ? h('a', { class: 'knopf leise', href: u + '/aendern', text: 'Angaben ändern' }) : null));

        var knoepfe = [h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' })];
        if (w.status === 'offen') {
          if (w.art === 'stoerung') knoepfe.push(h('a', { class: 'knopf leise', href: u + '/arbeit', text: 'Arbeit daraus machen' }));
          knoepfe.push(h('a', { class: 'knopf', href: u + '/erledigt', text: 'Erledigt eintragen' }));
        } else {
          knoepfe.push(h('button', { class: 'knopf', type: 'button', text: 'Wieder öffnen', onclick: function () {
            daten.vorgangWiederOeffnen(id).then(function (r) { meldung = r.ok ? 'Der Vorgang ist wieder offen.' : (r.fehler && r.fehler.allgemein); return zeige(); }).catch(fehlerSeite);
          } }));
        }
        seite(w.bezeichnung, [
          krumen(ortKrumen(v.fahrzeugAktuell, v.fahrzeug.id, v.komponente ? { komponente: v.komponente, aktuell: v.komponenteAktuell } : null).concat([[w.bezeichnung]])),
          w.status === 'offen' && MM.Werkstatt.bremst(w) ? warnungKarte(warnung, v) : null,
          kopf,
          kostenBlock(meineKosten, '#/fahrzeug/' + encodeURIComponent(v.fahrzeug.id) + '/kosten/neu?gruppe=instandhaltung&vorgang=' + encodeURIComponent(id), 'Noch kein Betrag. Trage hier Teile, Arbeit oder die Rechnung der Werkstatt ein. Die Beträge gehören zur Instandhaltung des Fahrzeugs.', 'Betrag eintragen'),
          vorgangDokumenteBereich(dokumente, u), verlaufBlock(v.verlauf)
        ], h('div', { class: 'leiste' }, knoepfe));
      });
    });
  }

  /* Dokumente und Bilder am Vorgang (seit 2.0.26): Foto vom Schaden, Rechnung, Seite aus dem Reparaturbuch. Auch bei einem erledigten Vorgang. */
  function vorgangDokumenteBereich(liste, u) {
    return h('section', { class: 'bereich', 'aria-label': 'Dokumente und Bilder' },
      h('h2', { text: 'Dokumente und Bilder' }),
      liste.length ? h('ul', { class: 'fristen' }, liste.map(function (x) { return dokZeile(x, false); }))
        : h('p', { class: 'leer-text', text: 'Noch nichts abgelegt. Lege zum Beispiel ein Foto vom Schaden, die Rechnung der Werkstatt oder eine Seite aus dem Reparaturbuch ab.' }),
      h('a', { class: 'knopf leise', href: u + '/dokument/neu', text: 'Bild oder Dokument hinzufügen' }));
  }

  /* ---------- Formulare: Vorgang melden, ändern, zur Arbeit machen, erledigt ---------- */
  /* Auswahl aus der Adressliste. behalte = die Adresse, die schon am Vorgang hängt (bleibt wählbar, auch wenn ausgeblendet). */
  function adressFeld(adressen, behalte) {
    var opt = adressen.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || a.objekt.id === behalte; })
      .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung + ' (' + MM.Werkstatt.labelVon(MM.Werkstatt.ADRESSARTEN, a.aktuell.werte.art) + ')' }; });
    return { key: 'adresseId', label: 'Werkstatt, Lieferant oder Händler', typ: 'auswahl', optionen: opt, leerText: '– keine Angabe –',
      hilfe: opt.length ? 'Aus deiner Adressliste. Freiwillig.' : 'Noch keine Adresse in der Liste. Lege sie unter „Stammdaten, Adressen“ an und trage sie hier später nach.' };
  }

  /* ziel: 'fz' (id = Fahrzeug), 'komp' (id = Komponente), 'aendern' (id = Vorgang) */
  function vorgangFormular(art, ziel, id) {
    var laden;
    if (ziel === 'fz') {
      laden = daten.fahrzeugLaden(id).then(function (f) { return f ? { fahrzeugId: id, komponenteId: null, fz: f.aktuell, komp: null, zurueck: '#/fahrzeug/' + encodeURIComponent(id), werte: null } : null; });
    } else if (ziel === 'komp') {
      laden = daten.komponenteLaden(id).then(function (c) {
        return c ? { fahrzeugId: c.fahrzeug.id, komponenteId: id, fz: c.fahrzeugAktuell, komp: { komponente: c.komponente, aktuell: c.aktuell }, zurueck: '#/komponente/' + encodeURIComponent(id), werte: null } : null;
      });
    } else {
      laden = daten.vorgangLaden(id).then(function (v) {
        if (!v) return null;
        return { fahrzeugId: v.fahrzeug.id, komponenteId: v.komponente ? v.komponente.id : null, fz: v.fahrzeugAktuell,
          komp: v.komponente ? { komponente: v.komponente, aktuell: v.komponenteAktuell } : null, zurueck: '#/vorgang/' + encodeURIComponent(id),
          werte: JSON.parse(JSON.stringify(v.aktuell.werte)), name: v.aktuell.werte.bezeichnung, art: v.aktuell.werte.art, status: v.aktuell.werte.status };
      });
    }
    return Promise.all([laden, daten.adressenListe()]).then(function (rr) {
      var k = rr[0], adressen = rr[1];
      if (!k) return nichtGefunden('Nicht gefunden');
      var neu = ziel !== 'aendern';
      if (!neu) art = k.art;
      if (!neu && k.status === 'erledigt') return nichtGefunden('Dieser Vorgang ist erledigt. Öffne ihn zuerst wieder.');
      var titel = neu ? (art === 'arbeit' ? 'Arbeit planen' : 'Störung melden') : (art === 'arbeit' ? 'Arbeit ändern' : 'Störung ändern');
      var start = k.werte || { auswirkung: art === 'arbeit' ? 'keine' : '', gemeldetAm: daten.heute() };
      var weg = ortKrumen(k.fz, k.fahrzeugId, k.komp);
      if (!neu) weg.push([k.name, k.zurueck]);
      weg.push([titel]);
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: k.zurueck, werte: start,
        intro: neu ? h('p', { text: art === 'arbeit' ? 'Eine Arbeit, die gemacht werden soll, zum Beispiel ein Ölwechsel. Du legst fest, ob du sie selbst machst oder eine Werkstatt.' : 'Melde, was nicht stimmt. Ist das Fahrzeug nicht oder nur bedingt einsatzfähig, warnt die App, wenn es für die nächste Zeit eingeplant ist.' }) : null,
        gruppen: function () {
          function f(key, extra) {
            var def = MM.Werkstatt.felder(art).filter(function (x) { return x.key === key; })[0];
            return Object.assign({}, def, extra || {});
          }
          var gruppen = [{ titel: null, felder: [
            { key: 'bezeichnung', label: 'Worum geht es?', typ: 'text', hilfe: art === 'arbeit' ? 'Zum Beispiel „Ölwechsel“ oder „Zündkerzen“' : 'Zum Beispiel „Motor springt schlecht an“ oder „Bilgenpumpe tropft“' },
            f('beschreibung'),
            f('auswirkung', { leerText: '– bitte wählen –' }),
            f('gemeldetAm')] }];
          if (art === 'arbeit') gruppen.push({ titel: 'Wer macht die Arbeit?', felder: [f('ausfuehrung', { leerText: '– bitte wählen –' }), f('arbeit'), adressFeld(adressen, k.werte ? k.werte.adresseId : null)] });
          return gruppen;
        },
        speichern: function (w) { return neu ? daten.vorgangAnlegen(k.fahrzeugId, k.komponenteId, art, w) : daten.vorgangAendern(id, w); },
        meldung: function (r) { return neu ? (art === 'arbeit' ? 'Arbeit eingetragen.' : 'Störung gemeldet.') : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/vorgang/' + encodeURIComponent(r.id); }
      });
    });
  }

  function vorgangZuArbeitFormular(id) {
    return Promise.all([daten.vorgangLaden(id), daten.adressenListe()]).then(function (rr) {
      var v = rr[0], adressen = rr[1];
      if (!v) return nichtGefunden('Vorgang nicht gefunden');
      var w = v.aktuell.werte;
      if (w.status !== 'offen' || w.art !== 'stoerung') return nichtGefunden('Aus diesem Vorgang lässt sich keine Arbeit machen.');
      var weg = ortKrumen(v.fahrzeugAktuell, v.fahrzeug.id, v.komponente ? { komponente: v.komponente, aktuell: v.komponenteAktuell } : null);
      weg.push([w.bezeichnung, '#/vorgang/' + encodeURIComponent(id)]); weg.push(['Arbeit daraus machen']);
      einfachFormular({
        titel: 'Arbeit daraus machen', krumen: krumen(weg), zurueck: '#/vorgang/' + encodeURIComponent(id), werte: { ausfuehrung: '', arbeit: '', adresseId: '' },
        intro: h('p', { text: w.bezeichnung + ': Die Störung bleibt im Verlauf sichtbar. Die Einschränkung des Fahrzeugs bleibt, bis die Arbeit erledigt ist.' }),
        gruppen: function () {
          function f(key, extra) { return Object.assign({}, MM.Werkstatt.felder('arbeit').filter(function (x) { return x.key === key; })[0], extra || {}); }
          return [{ titel: null, felder: [f('ausfuehrung', { leerText: '– bitte wählen –' }), f('arbeit'), adressFeld(adressen, null)] }];
        },
        speichern: function (roh) { return daten.vorgangZuArbeit(id, roh); },
        meldung: function () { return 'Aus der Störung ist eine Arbeit geworden.'; },
        danach: function () { return '#/vorgang/' + encodeURIComponent(id); }
      });
    });
  }

  function vorgangErledigtFormular(id) {
    return daten.vorgangLaden(id).then(function (v) {
      if (!v) return nichtGefunden('Vorgang nicht gefunden');
      var w = v.aktuell.werte;
      if (w.status !== 'offen') return nichtGefunden('Dieser Vorgang ist schon erledigt.');
      var weg = ortKrumen(v.fahrzeugAktuell, v.fahrzeug.id, v.komponente ? { komponente: v.komponente, aktuell: v.komponenteAktuell } : null);
      weg.push([w.bezeichnung, '#/vorgang/' + encodeURIComponent(id)]); weg.push(['Erledigt eintragen']);
      einfachFormular({
        titel: 'Erledigt eintragen', krumen: krumen(weg), zurueck: '#/vorgang/' + encodeURIComponent(id), werte: { datum: daten.heute(), notiz: '' },
        intro: h('p', { text: w.bezeichnung + ': Danach bremst dieser Vorgang das Fahrzeug nicht mehr. Der Vorgang bleibt sichtbar, und du kannst ihn wieder öffnen.' }),
        gruppen: function () {
          return [{ titel: null, felder: [{ key: 'datum', label: 'Erledigt am', typ: 'datum' },
            { key: 'notiz', label: 'Notiz', typ: 'text', hilfe: 'Zum Beispiel was gemacht wurde oder wer es gemacht hat' }] }];
        },
        speichern: function (roh) { return daten.vorgangErledigen(id, roh); },
        meldung: function () { return 'Erledigt eingetragen.'; },
        danach: function () { return '#/vorgang/' + encodeURIComponent(id); }
      });
    });
  }

  /* ---------- Adressen: Werkstätten, Lieferanten und Händler (zentrale Liste, seit 2.0.25) ---------- */
  var KR_ADRESSEN = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten']];
  function adressArtLabel(w) { return MM.Werkstatt.labelVon(MM.Werkstatt.ADRESSARTEN, w.art) || ''; }

  function seiteAdressen() {
    return daten.adressenListe().then(function (liste) {
      var inhalt = [krumen(KR_ADRESSEN.concat([['Adressen']])), h('h1', { text: 'Adressen' }),
        h('p', { class: 'hilfe', text: 'Eine Liste für alle Fahrzeuge: Werkstätten, Lieferanten und Händler. Eine Arbeit in der Werkstatt kann darauf verweisen.' })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Noch keine Adresse. Lege zum Beispiel deine Werkstatt oder einen Lieferanten für Ersatzteile an.' })));
      else inhalt.push(h('ul', { class: 'liste' }, liste.map(function (x) {
        var w = x.aktuell.werte;
        var info = [adressArtLabel(w), [w.plz, w.ort].filter(Boolean).join(' '), x.anzahlVorgaenge ? (x.anzahlVorgaenge === 1 ? '1 Vorgang' : x.anzahlVorgaenge + ' Vorgänge') : null].filter(Boolean).join(', ');
        return h('li', null, h('a', { class: 'zeile welt-land', href: '#/adresse/' + encodeURIComponent(x.objekt.id) },
          h('span', { class: 'zeile-text' },
            h('strong', { class: 'zeile-name', text: w.bezeichnung }),
            h('span', { class: 'zeile-art', text: info })),
          w.ausgeblendet === 'ja' ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : null));
      })));
      seite('Adressen', inhalt, h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/adressen/neu', text: 'Adresse anlegen' })));
    });
  }

  function seiteAdresse(id) {
    return daten.adresseLaden(id).then(function (x) {
      if (!x) return nichtGefunden('Adresse nicht gefunden');
      var w = x.aktuell.werte;
      var dl = [];
      MM.Werkstatt.adressFelder().forEach(function (f) {
        if (f.key === 'art') return; /* steht schon über dem Namen */
        var t = MM.Hilfen.wert(f, w[f.key]);
        if (t !== null) dl.push([h('dt', { text: f.label }), h('dd', { text: t })]);
      });
      var karte = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: adressArtLabel(w) }),
        h('h1', { text: w.bezeichnung }),
        w.ausgeblendet === 'ja' ? h('p', null, h('span', { class: 'chip-status', text: 'ausgeblendet' })) : null,
        dl.length ? h('dl', { class: 'daten' }, dl) : h('p', { class: 'leer-text', text: 'Noch keine weiteren Angaben.' }),
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(x.aktuell.erstelltAm) + ', per Handeingabe' }),
        h('p', null, h('a', { class: 'knopf leise', href: '#/adresse/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
      var vorgaenge = h('section', { class: 'bereich', 'aria-label': 'Vorgänge' },
        h('h2', { text: 'Vorgänge mit dieser Adresse' }),
        x.vorgaenge.length ? h('ul', { class: 'fristen' }, x.vorgaenge.map(function (v) {
          var chip = v.status === 'erledigt' ? ['Erledigt', 'status-ok'] : ['Offen', 'status-unbekannt'];
          return h('li', null, h('a', { class: 'frist ' + chip[1], href: '#/vorgang/' + encodeURIComponent(v.id) },
            h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: v.bezeichnung }), h('span', { class: 'frist-info', text: 'an: ' + v.fahrzeugName })),
            h('span', { class: 'chip-status ' + chip[1], text: chip[0] })));
        })) : h('p', { class: 'leer-text', text: 'Noch kein Vorgang verweist auf diese Adresse. Bei einer Arbeit wählst du sie unter „Wer macht die Arbeit?“.' }));
      seite(w.bezeichnung, [
        krumen(KR_ADRESSEN.concat([['Adressen', '#/adressen'], [w.bezeichnung]])), karte, vorgaenge, x.verlauf.length > 1 ? verlaufBlock(x.verlauf) : null
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/adressen', text: 'Zur Liste' }),
        h('a', { class: 'knopf', href: '#/adresse/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
    });
  }

  function adresseFormular(modus, id) {
    var laden = modus === 'aendern' ? daten.adresseLaden(id) : Promise.resolve({ aktuell: { werte: { bezeichnung: '', art: '' } } });
    return laden.then(function (x) {
      if (!x) return nichtGefunden('Adresse nicht gefunden');
      var neu = modus === 'neu';
      var titel = neu ? 'Adresse anlegen' : 'Adresse ändern';
      var weg = KR_ADRESSEN.concat([['Adressen', '#/adressen']]);
      if (!neu) weg.push([x.aktuell.werte.bezeichnung, '#/adresse/' + encodeURIComponent(id)]);
      weg.push([titel]);
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: neu ? '#/adressen' : '#/adresse/' + encodeURIComponent(id),
        werte: JSON.parse(JSON.stringify(x.aktuell.werte)),
        intro: neu ? h('p', { text: 'Name und Art genügen. Alles andere ist freiwillig. Die Adresse gilt für alle deine Fahrzeuge.' }) : null,
        gruppen: function () {
          var f = [{ key: 'bezeichnung', label: 'Name', typ: 'text', hilfe: 'Zum Beispiel „Autohaus Müller“ oder „Bootsbedarf Nord“' }].concat(MM.Werkstatt.adressFelder());
          if (!neu) f.push({ key: 'ausgeblendet', label: 'Anzeigen?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Ja, anzeigen' }, { wert: 'ja', label: 'Nein, ausblenden' }] });
          return [{ titel: null, felder: f }];
        },
        speichern: function (w) { return neu ? daten.adresseAnlegen(w) : daten.adresseAendern(id, w); },
        meldung: function (r) { return neu ? 'Adresse angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/adresse/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Kosten (seit 2.0.27) ---------- */
  var KR_KOSTEN = [['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen']];
  var KR_STAMM = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten']];

  function euro(n) { return MM.Hilfen.euro(n); }
  function grundText(g) { return g ? ' (' + MM.Kosten.GRUNDLAGE_TEXT[g] + ')' : ''; }
  function kleinGeschrieben(t) { return t ? t.charAt(0).toLowerCase() + t.slice(1) : ''; }
  function kostenJahrWahl() {
    var j = parseInt(hashParam('jahr'), 10);
    return isFinite(j) && j >= 1900 && j <= 2200 ? j : +daten.heute().slice(0, 4);
  }
  function kostenJahrLeiste(basis, jahr) {
    return h('p', { class: 'knopfzeile' },
      h('a', { class: 'knopf leise klein', href: basis + '?jahr=' + (jahr - 1), text: '◀ ' + (jahr - 1) }),
      h('strong', { text: 'Jahr ' + jahr }),
      h('a', { class: 'knopf leise klein', href: basis + '?jahr=' + (jahr + 1), text: (jahr + 1) + ' ▶' }));
  }

  /* Betrag, Rhythmus und Datum eines Postens in einem Satz */
  function kostenPostenText(w) {
    var fremd = w.waehrung && w.betragWaehrung ? MM.Reisekasse.zahlText(w.betragWaehrung) + ' ' + w.waehrung + ' = ' : '';
    if (!w.rhythmus || w.rhythmus === 'einmalig') return fremd + euro(w.betrag) + ' am ' + MM.Hilfen.datum(w.datum);
    return euro(w.betrag) + ' ' + kleinGeschrieben(MM.Kosten.labelVon(MM.Kosten.RHYTHMEN, w.rhythmus)) + ', ab ' + MM.Hilfen.datum(w.datum) + (w.bis ? ' bis ' + MM.Hilfen.datum(w.bis) : '');
  }

  /* Eine Zeile in der Liste der Posten. Mit x.imJahr steht rechts der Anteil am Jahr, sonst der Betrag. */
  function kostenPostenZeile(x) {
    var w = x.aktuell.werte;
    var zus = [x.artName || MM.Kosten.labelVon(MM.Kosten.KOSTENARTEN, w.kostenart), x.komponenteName ? 'an: ' + x.komponenteName : null,
      x.aktivitaetName ? 'Aktivität: ' + x.aktivitaetName : null, x.ortName ? 'Ort: ' + x.ortName : (w.ortText ? 'Ort: ' + w.ortText : null), x.vorgangName ? 'Vorgang: ' + x.vorgangName : null,
      x.zahlungName ? 'bezahlt mit: ' + x.zahlungName : null].filter(Boolean).join(', ');
    return h('li', null, h('a', { class: 'frist', href: '#/kosten/' + encodeURIComponent(x.objekt.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: w.bezeichnung }),
        h('span', { class: 'frist-info', text: kostenPostenText(w) + (w.grundlage === 'geschaetzt' ? ' (geschätzt)' : (w.grundlage === 'gerechnet' ? ' (gerechnet)' : '')) }),
        zus ? h('span', { class: 'frist-info', text: zus }) : null),
      h('span', { class: 'chip-status', text: euro(x.imJahr ? x.imJahr.summe : w.betrag) })));
  }

  /* Block „Kosten“ an Vorgang, Aktivität oder Komponente: die Posten mit Betrag und der Knopf zum Eintragen. */
  function kostenBlock(alle, neuHref, leerText, knopfText) {
    var sicht = alle.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; });
    var s = MM.Kosten.summeEinmalig(sicht.map(function (x) { return x.aktuell.werte; }));
    return h('section', { class: 'bereich', 'aria-label': 'Kosten' },
      h('h2', { text: 'Kosten' + (sicht.length && !s.wiederkehrend ? ': ' + euro(s.summe) : '') }),
      sicht.length ? h('ul', { class: 'fristen' }, sicht.map(kostenPostenZeile)) : h('p', { class: 'leer-text', text: leerText }),
      sicht.length && s.wiederkehrend ? h('p', { class: 'hilfe', text: 'Wiederkehrende Kosten sind in keiner Summe eingerechnet. Die Auswertung am Fahrzeug rechnet sie pro Jahr.' }) : null,
      h('a', { class: 'knopf leise', href: neuHref, text: knopfText }));
  }

  /* Block „Kosten“ auf der Seite des Fahrzeugs: die Jahreszahlen und der Weg zur Auswertung. */
  function kostenFahrzeugBlock(a, fzHash) {
    var inhalt = [h('h2', { text: 'Kosten ' + a.jahr })];
    if (a.gesamt.summe > 0) {
      inhalt.push(h('dl', { class: 'daten' },
        h('dt', { text: 'Im Jahr' }), h('dd', { text: euro(a.gesamt.summe) }),
        h('dt', { text: 'Pro Monat' }), h('dd', { text: euro(a.proMonat) }),
        h('dt', { text: 'Fixkosten' }), h('dd', { text: euro(a.gruppen.fix.summe) }),
        h('dt', { text: 'Variable Kosten' }), h('dd', { text: euro(a.gruppen.variabel.summe) }),
        h('dt', { text: 'Instandhaltung' }), h('dd', { text: euro(a.gruppen.instandhaltung.summe) }),
        a.wertverlust.angegeben ? [h('dt', { text: 'Wertverlust' }), h('dd', { text: euro(a.wertverlust.summe) + ' (gerechnet)' })] : null));
    } else inhalt.push(h('p', { class: 'leer-text', text: 'Für ' + a.jahr + ' sind noch keine Kosten eingetragen. Trage Fixkosten, variable Kosten und Instandhaltung ein, dann rechnet die App aus, was das Fahrzeug kostet.' }));
    inhalt.push(h('div', { class: 'leiste-inline' },
      h('a', { class: 'knopf leise', href: fzHash + '/kosten', text: 'Kosten ansehen' }),
      h('a', { class: 'knopf leise', href: fzHash + '/kosten/neu', text: 'Kosten eintragen' })));
    return h('section', { class: 'bereich', 'aria-label': 'Kosten' }, inhalt);
  }

  /* ---------- Block „Orte und Kosten der Reise“ auf der Seite der Aktivität (seit 2.0.28) ---------- */
  var PLAN_ART_TEXT = { start: 'Start', zwischenziel: 'Zwischenziel', ziel: 'Ziel' };
  function reiseBlock(r, aktId, storniert) {
    var inhalt = [h('h2', { text: 'Orte und Kosten der Reise' })];
    if (r.planVorhanden) {
      inhalt.push(h('h3', { text: 'Plan gegen Ist' }),
        h('ul', { class: 'fristen' }, r.plan.map(function (x) {
          return h('li', null, h('a', { class: 'frist', href: '#/ort/' + encodeURIComponent(x.ortId) },
            h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: PLAN_ART_TEXT[x.art] + ': ' + x.name })),
            h('span', { class: 'chip-status ' + (x.besucht ? 'status-ok' : 'status-bald'), text: x.besucht ? 'besucht' : 'noch nicht besucht' })));
        })),
        r.ungeplant.length ? h('p', { class: 'hilfe', text: 'Nicht geplant, aber besucht: ' + r.ungeplant.map(function (o) { return o.name; }).join(', ') + '.' }) : null);
    }
    inhalt.push(h('h3', { text: 'Besuche (' + r.anzahlBesuche + ')' }),
      r.besuche.length ? h('ul', { class: 'fristen' }, r.besuche.map(function (b) { return besuchZeile(b, false); }))
        : h('p', { class: 'leer-text', text: 'Noch kein Ort festgehalten. Bei einer Ankunft fragt das Cockpit freiwillig nach dem Ort. Du kannst einen Besuch auch von Hand eintragen.' }));
    if (r.anzahlPosten) {
      inhalt.push(h('h3', { text: 'Was die Reise gekostet hat: ' + euro(r.summe) + grundText(r.grundlage) }),
        h('dl', { class: 'daten' }, r.nachArt.map(function (x) { return [h('dt', { text: x.label }), h('dd', { text: euro(x.summe) + (x.anzahl > 1 ? ' (' + x.anzahl + ' Posten)' : '') })]; })),
        r.orte.some(function (o) { return o.summe > 0; }) ? h('p', { class: 'hilfe', text: 'Nach Ort: ' + r.orte.filter(function (o) { return o.summe > 0; }).map(function (o) { return o.name + ' ' + euro(o.summe); }).join(', ') + (r.ohneOrt > 0 ? ', ohne Ort ' + euro(r.ohneOrt) : '') + '.' }) : null);
    } else inhalt.push(h('p', { class: 'hilfe', text: 'Hier erscheint, was die Reise gekostet hat und wie sich die Kosten aufgliedern, sobald Beträge zur Aktivität eingetragen sind.' }));
    if (!storniert) inhalt.push(h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: '#/aktivitaet/' + encodeURIComponent(aktId) + '/besuch/neu', text: 'Besuch eintragen' })));
    return h('section', { class: 'bereich', 'aria-label': 'Orte und Kosten der Reise' }, inhalt);
  }

  /* ---------- Reisekasse (seit 2.0.29): Kassen, Ausgaben der Reise und Auswertung ---------- */
  var KR_AKT = [['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten']];

  function kassenBetragText(n, code) { return code === 'EUR' ? euro(n) : MM.Reisekasse.zahlText(n) + ' ' + code; }

  /* Kurzer Block auf der Seite der Aktivität: Stand der Kassen und der Weg zur Reisekasse. */
  function reisekasseKurzBlock(r, aktId, storniert, fahrzeugId) {
    var g = r.gesamt, u = '#/aktivitaet/' + encodeURIComponent(aktId);
    var inhalt = [h('h2', { text: 'Reisekasse und Reisekosten' })];
    if (g.gesamt > 0) inhalt.push(h('p', { text: 'Bisher ' + euro(g.gesamt) + (g.fixAnteil.eingerechnet ? ' mit Fixkosten-Anteil' : '') + ', davon Reisekasse ' + euro(g.reisekasse.summe) + '.' }));
    else inhalt.push(h('p', { class: 'leer-text', text: 'Hier sammelst du Einkäufe, Essen gehen, Souvenirs und die Bargeldkasse der Reise. Am Ende siehst du, was der Urlaub wirklich gekostet hat.' }));
    (r.kassen || []).forEach(function (x) {
      inhalt.push(h('p', { class: 'hilfe', text: 'Kasse ' + x.waehrung + ': Stand ' + kassenBetragText(x.rechnung.stand, x.waehrung) }));
    });
    inhalt.push(h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: u + '/reisekasse', text: 'Reisekasse öffnen' }),
      storniert ? null : h('a', { class: 'knopf leise', href: '#/fahrzeug/' + encodeURIComponent(fahrzeugId) + '/kosten/neu?gruppe=reisekasse&aktivitaet=' + encodeURIComponent(aktId), text: 'Ausgabe eintragen' })));
    return h('section', { class: 'bereich', 'aria-label': 'Reisekasse' }, inhalt);
  }

  function kasseBlock(x, u) {
    var rc = x.rechnung, code = x.waehrung, kt = MM.Reisekasse.kursText(code, rc.kurs);
    var zeilen = [[h('dt', { text: 'Anfangsbestand' }), h('dd', { text: kassenBetragText(rc.anfang, code) })],
      [h('dt', { text: 'Einzahlungen' }), h('dd', { text: kassenBetragText(rc.einzahlungen, code) })],
      [h('dt', { text: 'Ausgaben (bar)' }), h('dd', { text: kassenBetragText(rc.ausgaben, code) + (code !== 'EUR' ? ' = ' + euro(rc.ausgabenEuro) : '') })]];
    if (rc.differenz !== 0) zeilen.push([h('dt', { text: 'Differenzen (Kassensturz)' }), h('dd', { text: (rc.differenz > 0 ? '+' : '') + kassenBetragText(rc.differenz, code) })]);
    if (kt) zeilen.push([h('dt', { text: 'Kurs (Durchschnitt)' }), h('dd', { text: kt })]);
    return h('section', { class: 'schale sx', 'aria-label': 'Kasse ' + code },
      h('div', { class: 'schale-name', text: 'Kasse ' + MM.Reisekasse.waehrungLabel(code) }),
      h('p', { class: 'kasse-stand' + (rc.stand < 0 ? ' minus' : ''), text: kassenBetragText(rc.stand, code) }),
      rc.stand < 0 ? h('p', { class: 'hilfe', text: 'Der Stand ist im Minus. Trage den Anfangsbestand oder eine Einzahlung nach, oder mache einen Kassensturz.' }) : null,
      h('dl', { class: 'daten' }, zeilen),
      x.buchungen.length ? h('ul', { class: 'fristen' }, x.buchungen.map(function (b) {
        var w = b.aktuell.werte, aus = w.ausgeblendet === 'ja';
        var t = MM.Reisekasse.buchungsartLabel(w.art) + ' ' + MM.Hilfen.datum(w.datum) + ': ' + (w.art === 'differenz' && w.betrag > 0 ? '+' : '') + kassenBetragText(w.betrag, code) + (w.euro ? ' für ' + euro(w.euro) : '') + (w.notiz ? ' (' + w.notiz + ')' : '');
        return h('li', { class: aus ? 'buchung-aus' : null }, h('span', { class: 'frist-info', text: t + (aus ? ' – ausgeblendet' : '') }), ' ',
          h('button', { class: 'knopf leise klein', type: 'button', text: aus ? 'Wieder einblenden' : 'Ausblenden', onclick: function () {
            daten.kasseBuchungAusblenden(b.objekt.id, !aus).then(function () { meldung = aus ? 'Die Buchung zählt wieder.' : 'Die Buchung zählt nicht mehr. Sie wird nicht gelöscht.'; return zeige(); }).catch(fehlerSeite);
          } }));
      })) : null,
      h('p', { class: 'knopfzeile' },
        h('a', { class: 'knopf leise', href: u + '/kasse/neu?art=einzahlung&waehrung=' + code, text: 'Einzahlung' }),
        h('a', { class: 'knopf leise', href: u + '/kassensturz?waehrung=' + code, text: 'Kassensturz' })));
  }

  function seiteReisekasse(aktId) {
    var fixEin = hashParam('fix') !== 'aus';
    return Promise.all([daten.aktivitaetLaden(aktId), daten.reiseAuswertung(aktId, { fixEin: fixEin })]).then(function (rr) {
      var a = rr[0], r = rr[1];
      if (!a || !r) return nichtGefunden('Aktivität nicht gefunden');
      var w = a.aktuell.werte, u = '#/aktivitaet/' + encodeURIComponent(aktId), g = r.gesamt, storniert = w.status === 'storniert';
      var neuAusgabe = '#/fahrzeug/' + encodeURIComponent(a.fahrzeug.id) + '/kosten/neu?gruppe=reisekasse&aktivitaet=' + encodeURIComponent(aktId);
      var teile = [krumen(KR_AKT.concat([[w.bezeichnung, u], ['Reisekasse']])), h('h1', { text: 'Reisekasse' }),
        h('p', { text: w.bezeichnung + ': Ausgaben der Reise, die nicht das Fahrzeug betreffen, und das Bargeld.' })];

      teile.push(h('h2', { text: 'Bargeld' }));
      if (!r.kassen.length) teile.push(h('p', { class: 'leer-text', text: 'Noch keine Kasse. Trage zu Reisebeginn das Bargeld ein, das du dabei hast. Wählst du bei einer Ausgabe „Bar“, zieht die App den Betrag von der Kasse ab.' }));
      r.kassen.forEach(function (x) { teile.push(kasseBlock(x, u)); });
      if (!storniert) teile.push(h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: u + '/kasse/neu?art=anfang', text: r.kassen.length ? 'Weitere Kasse (andere Währung)' : 'Kasse anlegen (Anfangsbestand)' })));

      var ausgaben = r.reisekassePosten.map(function (x) {
        var wx = x.aktuell.werte;
        return Object.assign({}, x, { artName: wx.kostenart ? (r.artNamen[wx.kostenart] || null) : null, zahlungName: wx.bezahltMit ? (r.zahlungNamen[wx.bezahltMit] || null) : null });
      }).sort(function (x, y) { return (y.aktuell.werte.datum || '') < (x.aktuell.werte.datum || '') ? -1 : 1; });
      var sichtbar = ausgaben.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; });
      teile.push(h('h2', { text: 'Ausgaben der Reisekasse' }),
        sichtbar.length ? h('ul', { class: 'fristen' }, sichtbar.map(kostenPostenZeile)) : h('p', { class: 'leer-text', text: 'Noch keine Ausgabe. Trage Einkäufe, Essen gehen, Souvenirs oder Eintritte ein, gern mit einem Foto.' }),
        storniert ? null : h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf', href: neuAusgabe, text: 'Ausgabe eintragen' })));

      teile.push(h('h2', { text: 'Was hat die Reise gekostet?' }));
      if (g.gesamt <= 0 && g.fixAnteil.summe <= 0) teile.push(h('p', { class: 'leer-text', text: 'Sobald Beträge eingetragen sind, siehst du hier Fahrzeug und Reisekasse getrennt und die Gesamtsumme.' }));
      else {
        var dl = [[h('dt', { text: 'Fahrzeug (Treibstoff, Plätze, Maut …)' }), h('dd', { text: euro(g.fahrzeug.summe) + grundText(g.fahrzeug.grundlage) })],
          [h('dt', { text: 'Reisekasse' }), h('dd', { text: euro(g.reisekasse.summe) + grundText(g.reisekasse.grundlage) })]];
        if (g.fixAnteil.summe > 0) dl.push([h('dt', { text: 'Fixkosten-Anteil (' + g.tage + ' Tage)' }), h('dd', { text: euro(g.fixAnteil.summe) + ' (gerechnet)' + (g.fixAnteil.eingerechnet ? '' : ', nicht eingerechnet') })]);
        dl.push([h('dt', { text: 'Gesamt' }), h('dd', null, h('strong', { text: euro(g.gesamt) }), ' (gerechnet)')]);
        if (g.proTag !== null) dl.push([h('dt', { text: 'Pro Tag (' + g.tage + ' Tage)' }), h('dd', { text: euro(g.proTag) })]);
        if (g.proPerson !== null) dl.push([h('dt', { text: 'Pro Person (' + g.personen + ')' }), h('dd', { text: euro(g.proPerson) })]);
        if (g.proTagPerson !== null) dl.push([h('dt', { text: 'Pro Tag und Person' }), h('dd', { text: euro(g.proTagPerson) })]);
        teile.push(h('dl', { class: 'daten' }, dl));
        if (g.fixAnteil.summe > 0) teile.push(h('p', { class: 'hilfe', text: 'Der Fixkosten-Anteil rechnet die Fixkosten des Fahrzeugs (zum Beispiel Liegeplatz, Versicherung) anteilig auf die Reisetage. So stimmt „Was hat der Urlaub wirklich gekostet?“, und die reinen Reisekosten stehen trotzdem extra da.' }),
          h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: u + '/reisekasse' + (fixEin ? '?fix=aus' : ''), text: g.fixAnteil.eingerechnet ? 'Fixkosten-Anteil ausschalten' : 'Fixkosten-Anteil einschalten' })));
        if (g.reisekasse.nachArt.length) teile.push(h('h3', { text: 'Reisekasse nach Art' }),
          h('dl', { class: 'daten' }, g.reisekasse.nachArt.map(function (x) { return [h('dt', { text: x.art ? (r.artNamen[x.art] || 'Art') : 'ohne Art' }), h('dd', { text: euro(x.summe) + (x.anzahl > 1 ? ' (' + x.anzahl + ' Posten)' : '') })]; })));
        if (g.nachZahlungsmittel.length) teile.push(h('h3', { text: 'Nach Zahlungsmittel' }),
          h('dl', { class: 'daten' }, g.nachZahlungsmittel.map(function (x) { return [h('dt', { text: x.label }), h('dd', { text: euro(x.summe) + (x.anzahl > 1 ? ' (' + x.anzahl + ' Posten)' : '') })]; })),
          h('p', { class: 'hilfe', text: 'Einzahlungen in die Kasse sind keine Ausgaben und zählen nicht mit. Differenzen aus dem Kassensturz stehen nur in der Kasse.' }));
      }
      seite('Reisekasse', teile, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: u, text: 'Zur Aktivität' })));
    });
  }

  /* Anfangsbestand oder Einzahlung. ?art=anfang|einzahlung, ?waehrung=NOK */
  function kasseBuchenFormular(aktId) {
    return Promise.all([daten.aktivitaetLaden(aktId), daten.kassenListe(aktId)]).then(function (rr) {
      var a = rr[0], kassen = rr[1];
      if (!a) return nichtGefunden('Aktivität nicht gefunden');
      var w = a.aktuell.werte, u = '#/aktivitaet/' + encodeURIComponent(aktId), zurueck = u + '/reisekasse';
      var wPar = MM.Reisekasse.waehrungNormal(hashParam('waehrung')) || 'EUR', artPar = hashParam('art');
      var start = { art: artPar === 'anfang' || artPar === 'einzahlung' ? artPar : (kassen.some(function (k) { return k.waehrung === wPar; }) ? 'einzahlung' : 'anfang'),
        waehrung: wPar, betrag: '', euro: '', datum: daten.heute(), notiz: '' };
      var wOpt = MM.Reisekasse.WAEHRUNGEN.map(function (x) { return { wert: x.wert, label: x.label }; });
      kassen.forEach(function (k) { if (!wOpt.some(function (x) { return x.wert === k.waehrung; })) wOpt.push({ wert: k.waehrung, label: k.waehrung }); });
      if (!wOpt.some(function (x) { return x.wert === wPar; })) wOpt.push({ wert: wPar, label: wPar });
      einfachFormular({
        titel: 'Geld in die Kasse', krumen: krumen(KR_AKT.concat([[w.bezeichnung, u], ['Reisekasse', zurueck], ['Geld in die Kasse']])), zurueck: zurueck, werte: start, neuzeichnenBei: ['art', 'waehrung'],
        intro: h('p', { text: 'Der Anfangsbestand ist das Bargeld, das du zu Reisebeginn hast. Geld, das du später holst oder tauschst, trägst du als Einzahlung ein. Eine Einzahlung ist keine Ausgabe: Das Geld wandert nur von der Karte oder dem Konto in die Kasse und zählt nicht doppelt in den Reisekosten. Eine Gebühr am Automaten ist dagegen eine eigene Ausgabe.' }),
        gruppen: function (z) {
          var code = MM.Reisekasse.waehrungNormal(z.werte.waehrung) || 'EUR';
          var f = [{ key: 'art', label: 'Was trägst du ein?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Reisekasse.BUCHUNGSARTEN.filter(function (x) { return x.wert !== 'differenz'; }) },
            { key: 'waehrung', label: 'Währung', typ: 'auswahl', optionen: wOpt }].concat(MM.Reisekasse.buchungsFelder(z.werte.art || 'anfang', code));
          return [{ titel: null, felder: f }];
        },
        speichern: function (x) { return daten.kasseBuchen(aktId, x); },
        meldung: function () { return 'Eingetragen.'; },
        danach: function () { return zurueck; }
      });
    });
  }

  function kassensturzFormular(aktId) {
    return Promise.all([daten.aktivitaetLaden(aktId), daten.kassenListe(aktId)]).then(function (rr) {
      var a = rr[0], kassen = rr[1];
      if (!a) return nichtGefunden('Aktivität nicht gefunden');
      var w = a.aktuell.werte, u = '#/aktivitaet/' + encodeURIComponent(aktId), zurueck = u + '/reisekasse';
      if (!kassen.length) return seite('Kassensturz', [krumen(KR_AKT.concat([[w.bezeichnung, u], ['Reisekasse', zurueck], ['Kassensturz']])), h('h1', { text: 'Kassensturz' }),
        h('p', { text: 'Es gibt noch keine Kasse. Lege sie zuerst mit dem Anfangsbestand an.' }),
        h('p', null, h('a', { class: 'knopf', href: u + '/kasse/neu?art=anfang', text: 'Kasse anlegen' }))]);
      var wPar = hashParam('waehrung'), erste = kassen.filter(function (k) { return k.waehrung === wPar; })[0] || kassen[0];
      var letzter = erste.waehrung;
      einfachFormular({
        titel: 'Kassensturz', krumen: krumen(KR_AKT.concat([[w.bezeichnung, u], ['Reisekasse', zurueck], ['Kassensturz']])), zurueck: zurueck,
        werte: { waehrung: erste.waehrung, ist: '', datum: daten.heute(), notiz: '' }, neuzeichnenBei: ['waehrung'],
        intro: h('p', { text: 'Zähle das Bargeld und trage ein, wie viel wirklich da ist. Stimmt es nicht mit dem Stand der App überein, speichert die App die Differenz als eigenen Eintrag, damit die Rechnung wieder stimmt.' }),
        gruppen: function (z) {
          var k = kassen.filter(function (x) { return x.waehrung === z.werte.waehrung; })[0] || erste;
          var f = [];
          if (kassen.length > 1) f.push({ key: 'waehrung', label: 'Welche Kasse?', typ: 'auswahl', optionen: kassen.map(function (x) { return { wert: x.waehrung, label: x.waehrung }; }) });
          f.push({ key: 'ist', label: 'Das liegt wirklich in der Kasse', typ: 'zahl', einheit: k.waehrung, hilfe: 'Nach der App sollten es ' + kassenBetragText(k.rechnung.stand, k.waehrung) + ' sein.' },
            { key: 'datum', label: 'Datum', typ: 'datum' }, { key: 'notiz', label: 'Notiz', typ: 'text' });
          return [{ titel: null, felder: f }];
        },
        speichern: function (x) { letzter = x.waehrung || erste.waehrung; return daten.kassensturz(aktId, x); },
        meldung: function (r) { return r.geaendert ? 'Gespeichert. Die Differenz von ' + (r.differenz > 0 ? '+' : '') + kassenBetragText(r.differenz, letzter) + ' steht als eigener Eintrag in der Kasse.' : 'Der Stand stimmt.'; },
        danach: function () { return zurueck; }
      });
    });
  }

  /* ---------- Kostenarten und Zahlungsmittel verwalten (seit 2.0.29) ---------- */
  /* ---------- Merkmale und Einheiten: Listen verwalten (seit 2.0.45) ---------- */
  function seiteMerkmaleListen() {
    return Promise.all([daten.merkmaleListe(), daten.einheitenListe()]).then(function (r) {
      function zeile(x, text, aus) {
        return h('li', { class: x.ausgeblendet ? 'buchung-aus' : null }, h('span', { class: 'frist-info', text: text + (x.eigen ? ' (eigene)' : '') + (x.ausgeblendet ? ' – ausgeblendet' : '') }), ' ',
          h('button', { class: 'knopf leise klein', type: 'button', text: x.ausgeblendet ? 'Wieder einblenden' : 'Ausblenden', onclick: function () {
            aus(x.wert, !x.ausgeblendet).then(function () { return zeige(); }).catch(fehlerSeite);
          } }));
      }
      seite('Merkmale und Einheiten', [
        krumen(KR_STAMM.concat([['Merkmale und Einheiten']])), h('h1', { text: 'Merkmale und Einheiten' }),
        h('p', { text: 'Die Listen sind offen: Du kannst eigene Einträge anlegen, auch mitten im Formular einer Komponente. Ausgeblendet erscheint ein Eintrag nicht mehr zur Auswahl, bleibt aber an den Komponenten, an denen er steht. Die Einheiten kommen immer aus der Liste, damit „kn“ und „Knoten“ nicht durcheinandergehen.' }),
        h('section', { class: 'bereich', 'aria-label': 'Merkmale' }, h('h2', { text: 'Merkmale' }),
          h('ul', { class: 'fristen' }, r[0].map(function (m) {
            return zeile(m, m.label + (m.einheit ? ', ' + m.einheit : '') + (m.bezug ? ', bezogen auf ' + m.bezug : ''), daten.merkmalAusblenden.bind(daten));
          })),
          h('a', { class: 'knopf leise', href: '#/merkmale/neu', text: 'Neues Merkmal' })),
        h('section', { class: 'bereich', 'aria-label': 'Einheiten' }, h('h2', { text: 'Einheiten' }),
          h('ul', { class: 'fristen' }, r[1].map(function (e) { return zeile(e, e.label, daten.einheitAusblenden.bind(daten)); })),
          h('a', { class: 'knopf leise', href: '#/merkmale/einheit/neu', text: 'Neue Einheit' }))
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' })));
    });
  }

  function merkmalNeuFormular() {
    var zurueck = '#/merkmale';
    return daten.einheitenListe().then(function (liste) {
      einfachFormular({
        titel: 'Neues Merkmal', krumen: krumen(KR_STAMM.concat([['Merkmale und Einheiten', zurueck], ['Neues Merkmal']])), zurueck: zurueck,
        werte: { name: '', einheit: '', bezug: '' },
        gruppen: function () { return [{ titel: null, felder: [
          { key: 'name', label: 'Name des Merkmals', typ: 'text', hilfe: 'Zum Beispiel „Leistung“ oder „Verbrauch“' },
          { key: 'einheit', label: 'Einheit', typ: 'auswahl', leerText: '– keine Einheit –', optionen: liste.filter(function (x) { return !x.ausgeblendet; }).map(function (x) { return { wert: x.label, label: x.label }; }), hilfe: 'Wird bei der Komponente vorgeschlagen und lässt sich dort ändern. Fehlt sie? Lege sie zuerst unter „Neue Einheit“ an.' },
          { key: 'bezug', label: 'Bezugsgröße (freiwillig)', typ: 'text', hilfe: 'Zum Beispiel „100 km“ oder „Betriebsstunde“ beim Verbrauch' }] }]; },
        speichern: function (w) { return daten.merkmalAnlegen(w.name, w.einheit, w.bezug); },
        meldung: function () { return 'Das Merkmal ist angelegt.'; }, danach: function () { return zurueck; }
      });
    });
  }

  function einheitNeuFormular() {
    var zurueck = '#/merkmale';
    einfachFormular({
      titel: 'Neue Einheit', krumen: krumen(KR_STAMM.concat([['Merkmale und Einheiten', zurueck], ['Neue Einheit']])), zurueck: zurueck,
      werte: { bezeichnung: '' },
      gruppen: function () { return [{ titel: null, felder: [{ key: 'bezeichnung', label: 'Einheit', typ: 'text', hilfe: 'Zum Beispiel „kn“ oder „m²“. Höchstens 20 Zeichen.' }] }]; },
      speichern: function (w) { return daten.einheitAnlegen(w.bezeichnung); },
      meldung: function () { return 'Die Einheit ist angelegt.'; }, danach: function () { return zurueck; }
    });
    return Promise.resolve();
  }

  function seiteKostenListen() {
    return Promise.all([daten.kostenartenListe(), daten.zahlungsmittelListe()]).then(function (r) {
      var teile = [krumen(KR_STAMM.concat([['Kostenarten und Zahlungsmittel']])), h('h1', { text: 'Kostenarten und Zahlungsmittel' }),
        h('p', { text: 'Die Listen sind offen: Du kannst eigene Arten anlegen, auch mitten im Formular. Benutzte Arten werden nur ausgeblendet, nicht gelöscht. Ausgeblendet erscheint eine Art nicht mehr zur Auswahl, bleibt aber an den Posten, an denen sie hängt.' })];
      MM.Kosten.alleGruppen().forEach(function (g) {
        var arten = r[0].filter(function (a) { return a.gruppe === g.wert; });
        teile.push(h('section', { class: 'bereich', 'aria-label': g.label }, h('h2', { text: g.label }),
          h('ul', { class: 'fristen' }, arten.map(function (a) {
            return h('li', { class: a.ausgeblendet ? 'buchung-aus' : null }, h('span', { class: 'frist-info', text: a.label + (a.eigen ? ' (eigene)' : '') + (a.ausgeblendet ? ' – ausgeblendet' : '') }), ' ',
              h('button', { class: 'knopf leise klein', type: 'button', text: a.ausgeblendet ? 'Wieder einblenden' : 'Ausblenden', onclick: function () {
                daten.kostenartAusblenden(a.wert, !a.ausgeblendet).then(function () { return zeige(); }).catch(fehlerSeite);
              } }));
          })),
          h('a', { class: 'knopf leise', href: '#/kosten/listen/art/neu?gruppe=' + g.wert, text: 'Neue Art in „' + g.label + '“' })));
      });
      teile.push(h('section', { class: 'bereich', 'aria-label': 'Zahlungsmittel' }, h('h2', { text: 'Zahlungsmittel' }),
        h('p', { class: 'hilfe', text: 'Nur Bezeichnungen, zum Beispiel „Girokarte“ oder „Kreditkarte“. Keine Karten- oder Kontonummern. „Bar“ gehört zur Kasse und bleibt immer da.' }),
        h('ul', { class: 'fristen' }, r[1].map(function (z) {
          return h('li', { class: z.ausgeblendet ? 'buchung-aus' : null }, h('span', { class: 'frist-info', text: z.label + (z.ausgeblendet ? ' – ausgeblendet' : '') }), ' ',
            z.eigen ? h('button', { class: 'knopf leise klein', type: 'button', text: z.ausgeblendet ? 'Wieder einblenden' : 'Ausblenden', onclick: function () {
              daten.zahlungsmittelAusblenden(z.wert, !z.ausgeblendet).then(function () { return zeige(); }).catch(fehlerSeite);
            } }) : null);
        })),
        h('a', { class: 'knopf leise', href: '#/kosten/listen/zahlung/neu', text: 'Neues Zahlungsmittel' })));
      seite('Kostenarten und Zahlungsmittel', teile, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' })));
    });
  }

  function kostenartNeuFormular() {
    var g = hashParam('gruppe');
    var zurueck = '#/kosten/listen';
    einfachFormular({
      titel: 'Neue Kostenart', krumen: krumen(KR_STAMM.concat([['Kostenarten und Zahlungsmittel', zurueck], ['Neue Kostenart']])), zurueck: zurueck,
      werte: { gruppe: MM.Kosten.istGruppe(g) ? g : 'variabel', bezeichnung: '' },
      gruppen: function () { return [{ titel: null, felder: [
        { key: 'gruppe', label: 'Zu welcher Gruppe gehört die Art?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Kosten.alleGruppen().map(function (x) { return { wert: x.wert, label: x.label }; }) },
        { key: 'bezeichnung', label: 'Name der Art', typ: 'text', hilfe: 'Zum Beispiel „Kurtaxe“ oder „Fährgebühr“' }] }]; },
      speichern: function (w) { return daten.kostenartAnlegen(w.gruppe, w.bezeichnung); },
      meldung: function () { return 'Die Art ist angelegt.'; }, danach: function () { return zurueck; }
    });
    return Promise.resolve();
  }

  function zahlungsmittelNeuFormular() {
    var zurueck = '#/kosten/listen';
    einfachFormular({
      titel: 'Neues Zahlungsmittel', krumen: krumen(KR_STAMM.concat([['Kostenarten und Zahlungsmittel', zurueck], ['Neues Zahlungsmittel']])), zurueck: zurueck,
      werte: { bezeichnung: '' },
      gruppen: function () { return [{ titel: null, felder: [{ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Zum Beispiel „Kreditkarte“ oder „Girokarte“. Keine Karten- oder Kontonummern.' }] }]; },
      speichern: function (w) { return daten.zahlungsmittelAnlegen(w.bezeichnung); },
      meldung: function () { return 'Das Zahlungsmittel ist angelegt.'; }, danach: function () { return zurueck; }
    });
    return Promise.resolve();
  }

  /* ---------- Besuche (seit 2.0.28): Ort festhalten, ansehen, ändern ---------- */
  var KR_BESUCH = [['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten']];

  function komma(n) { return typeof n === 'number' ? String(n).replace('.', ',') : ''; }

  /* Neuer Besuch zu einer Aktivität. ?ereignis= (die Ankunft), ?ort= (vorgewählter Ort), ?von=cockpit (danach zurück ins Cockpit) */
  function besuchFormular(aktId) {
    var ereignisId = hashParam('ereignis'), vorOrt = hashParam('ort'), vonCockpit = hashParam('von') === 'cockpit';
    return Promise.all([daten.besuchKontext(aktId, ereignisId || null), daten.kostenartenListe(), daten.zahlungsmittelListe()]).then(function (rr) {
      var k = rr[0], artenAlle = rr[1], zahlungAlle = rr[2];
      if (!k.ok) return nichtGefunden('Aktivität nicht gefunden');
      var aw = k.aktivitaet.aktuell.werte, e = k.ereignis;
      if (k.besuchVorhanden) {
        return seite('Besuch', [h('h1', { text: 'Besuch' }), h('p', { text: 'Zu dieser Ankunft gibt es schon einen Besuch.' }),
          h('p', null, h('a', { class: 'knopf', href: '#/besuch/' + encodeURIComponent(k.besuchVorhanden), text: 'Besuch ansehen' }))]);
      }
      var orteSicht = k.orte.filter(function (o) { return o.aktuell.werte.ausgeblendet !== 'ja'; });
      var start = { ortId: vorOrt || (k.vorschlag ? k.vorschlag.ortId : ''), standortId: '', neuerOrtName: '', neuerOrtArt: '',
        positionBreite: e ? komma(e.breite) : '', positionLaenge: e ? komma(e.laenge) : '', datum: e && e.datum ? e.datum : daten.heute(), zeit: e && e.zeit ? e.zeit : '',
        ausstattung: [], ausstattungSonst: '', notiz: '', zeilen: [{ kostenart: '', neueKostenart: '', betrag: '' }], grundlage: 'eingegeben', bezahltMit: '', neuesZahlungsmittel: '', waehrung: '' };
      if (!start.ortId && e && e.ortName) {
        var gleich = orteSicht.filter(function (o) { return o.aktuell.werte.bezeichnung.toLowerCase() === e.ortName.toLowerCase(); })[0];
        if (gleich) start.ortId = gleich.objekt.id; else start.neuerOrtName = e.ortName;
      }
      if (k.vorschlag && start.ortId === k.vorschlag.ortId) start.standortId = k.vorschlag.standortId || '';
      function ortWerte(oid) { var o = k.orte.filter(function (x) { return x.objekt.id === oid; })[0]; return o ? o.aktuell.werte : null; }
      function uebernehmen(z) {
        var ow = ortWerte(z.werte.ortId);
        z.werte.ausstattung = ow && ow.ausstattung ? ow.ausstattung.slice() : [];
        z.werte.ausstattungSonst = ow && ow.ausstattungSonst ? ow.ausstattungSonst : '';
      }
      if (start.ortId) { var ow0 = ortWerte(start.ortId); if (ow0) { start.ausstattung = (ow0.ausstattung || []).slice(); start.ausstattungSonst = ow0.ausstattungSonst || ''; } }
      var fzHash = '#/aktivitaet/' + encodeURIComponent(aktId);
      var zurueck = fzHash;
      var weg = KR_BESUCH.concat([[aw.bezeichnung, fzHash], ['Ort festhalten']]);
      var artOpt = MM.Orte.ORTARTEN.map(function (a) { return { wert: a.wert, label: a.label }; });
      var kostenarten = artenAlle.filter(function (a) { return a.gruppe === 'variabel' && !a.ausgeblendet; }).map(function (a) { return { wert: a.wert, label: a.label }; });
      if (vonCockpit) reiterWahl[aktId] = 'cockpit';
      einfachFormular({
        titel: 'Ort festhalten', krumen: krumen(weg), zurueck: zurueck, werte: start, neuzeichnenBei: ['ortId', 'waehrung'],
        nachAenderung: function (key, z) { if (key === 'ortId') { z.werte.standortId = ''; uebernehmen(z); } },
        intro: h('p', { text: 'Alles hier ist freiwillig. Nur der Ort wird gebraucht. Ausstattung und Kosten kannst du auch später ergänzen.' }),
        gruppen: function (z) {
          var ortId = z.werte.ortId, ow = ortId ? ortWerte(ortId) : null;
          var plan = ortId ? MM.Reiseorte.planVergleich(k.plan, ortId) : (MM.Reiseorte.planVorhanden(k.plan) ? 'nein' : null);
          var hinw = [];
          if (k.vorschlag && ortId === k.vorschlag.ortId) hinw.push('Die App erkennt den Ort an der Position der Ankunft (' + MM.Logbuch.entfernungText(k.vorschlag.abstand) + ' entfernt).');
          if (plan) hinw.push(MM.Reiseorte.planText(plan));
          var g = [{ titel: null, hinweis: hinw.join(' ') || null, felder: [
            { key: 'ortId', label: 'Ort', typ: 'auswahl', optionen: orteSicht.map(function (o) { return { wert: o.objekt.id, label: o.aktuell.werte.bezeichnung }; }), leerText: '– neuer Ort –' }] }];
          if (!ortId) {
            g.push({ titel: 'Neuer Ort', hinweis: e && typeof e.breite === 'number' ? 'Die Position der Ankunft ist eingetragen und wird für den Ort gemerkt.' : 'Ohne Position erkennt die App den Ort später nicht an der Ankunft. Du kannst sie am Ort nachtragen.', felder: [
              { key: 'neuerOrtName', label: 'Name des Ortes', typ: 'text', hilfe: 'Zum Beispiel „Stellplatz Bad Mergentheim“ oder „Hafen Rovinj“' },
              { key: 'neuerOrtArt', label: 'Art des Ortes', typ: 'auswahl', optionen: artOpt, leerText: '– keine Angabe –' },
              { key: 'positionBreite', label: 'Breite (Dezimalgrad)', typ: 'text' }, { key: 'positionLaenge', label: 'Länge (Dezimalgrad)', typ: 'text' }] });
          } else {
            var st = k.standorte.filter(function (s) { return s.objekt.ortId === ortId && s.aktuell.werte.ausgeblendet !== 'ja'; });
            if (st.length) g.push({ titel: null, felder: [{ key: 'standortId', label: 'Standort (freiwillig)', typ: 'auswahl', optionen: st.map(function (s) { return { wert: s.objekt.id, label: s.aktuell.werte.bezeichnung }; }), leerText: '– keiner –' }] });
            if (ow && typeof ow.positionBreite !== 'number' && e && typeof e.breite === 'number') g[g.length - 1].hinweis = 'Der Ort hat noch keine Position. Die der Ankunft wird für ihn gemerkt.';
          }
          g.push({ titel: 'Ausstattung', hinweis: 'Die Angaben gelten auch für den Ort selbst, damit du sie beim nächsten Mal schon siehst.', felder: [
            { key: 'ausstattung', label: 'Was gibt es dort?', typ: 'mehrfach', optionen: MM.Orte.AUSSTATTUNG.map(function (a) { return { wert: a.wert, label: a.label }; }) },
            { key: 'ausstattungSonst', label: 'Weitere Ausstattung', typ: 'text' }] });
          var pr = ortId ? k.preise[ortId] : null;
          var wc = MM.Reisekasse.waehrungNormal(z.werte.waehrung), fremd = !!wc && wc !== 'EUR';
          var zOpt = zahlungAlle.filter(function (x) { return !x.ausgeblendet; }).map(function (x) { return { wert: x.wert, label: x.label }; });
          var wOpt = MM.Reisekasse.WAEHRUNGEN.map(function (x) { return { wert: x.wert, label: x.label }; });
          g.push({ titel: 'Kosten (freiwillig)', hinweis: (pr ? 'Zuletzt bezahlt: ' + euro(pr.betrag) + (pr.datum ? ' am ' + MM.Hilfen.datum(pr.datum) : '') + grundText(pr.grundlage) + '. ' : '') + 'Jede Zeile wird ein eigener Posten in der Kosten-Liste, als variable Kosten dieser Aktivität.', felder: [
            { key: 'zeilen', label: 'Was hat es gekostet?', typ: 'kostenzeilen', optionen: kostenarten, einheit: fremd ? wc : '€',
              hilfe: 'Zum Beispiel Liegegebühr, Stromzuschlag, Wasserzuschlag, Müllentsorgung, Kurtaxe. Eine Art, die es nicht gibt, legst du in der Zeile neu an.' },
            { key: 'waehrung', label: 'Währung', typ: 'auswahl', optionen: wOpt, leerText: '– Euro –', hilfe: fremd ? 'Die Beträge oben sind in ' + wc + '. Die App rechnet sie mit dem Kurs deiner Kasse in Euro um.' : null },
            { key: 'bezahltMit', label: 'Bezahlt mit (freiwillig)', typ: 'auswahl', optionen: zOpt, leerText: '– keine Angabe –', hilfe: 'Bei „Bar“ wird der Betrag von der Kasse der Aktivität abgezogen.' },
            { key: 'neuesZahlungsmittel', label: 'Oder neues Zahlungsmittel anlegen', typ: 'text' },
            { key: 'grundlage', label: 'Woher stammen die Beträge?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Kosten.GRUNDLAGEN.map(function (x) { return { wert: x.wert, label: x.label }; }) }] });
          g.push({ titel: 'Wann und Notiz', felder: [{ key: 'datum', label: 'Datum', typ: 'datum' }, { key: 'zeit', label: 'Uhrzeit', typ: 'zeit' },
            { key: 'notiz', label: 'Notiz (nur für dich)', typ: 'text' }] });
          return g;
        },
        speichern: function (w) { return daten.besuchAnlegen(aktId, Object.assign({}, w, { ereignisId: ereignisId })); },
        meldung: function (r) { return 'Festgehalten.' + (r.geplant ? ' ' + MM.Reiseorte.planText(r.geplant) : ''); },
        danach: function (r) { return vonCockpit ? fzHash : '#/besuch/' + encodeURIComponent(r.id); }
      });
    });
  }

  function seiteBesuch(id) {
    return daten.besuchLaden(id).then(function (b) {
      if (!b) return nichtGefunden('Besuch nicht gefunden');
      var w = b.aktuell.werte, aus = w.ausgeblendet === 'ja', fzHash = '#/fahrzeug/' + encodeURIComponent(b.fahrzeug.id);
      var zeilen = [];
      if (b.ort) zeilen.push([h('dt', { text: 'Ort' }), h('dd', null, h('a', { href: '#/ort/' + encodeURIComponent(b.ort.id), text: b.ort.name }))]);
      if (b.standort) zeilen.push([h('dt', { text: 'Standort' }), h('dd', { text: b.standort.name })]);
      zeilen.push([h('dt', { text: 'Wann' }), h('dd', { text: MM.Hilfen.datum(w.datum) + (w.zeit ? ', ' + w.zeit + ' Uhr' : '') })]);
      zeilen.push([h('dt', { text: 'Aktivität' }), h('dd', null, h('a', { href: '#/aktivitaet/' + encodeURIComponent(b.aktivitaet.id), text: b.aktivitaet.name }))]);
      zeilen.push([h('dt', { text: 'Fahrzeug' }), h('dd', null, h('a', { href: fzHash, text: b.fahrzeug.name }))]);
      if (b.geplantText) zeilen.push([h('dt', { text: 'Im Plan' }), h('dd', { text: b.geplantText })]);
      var au = MM.Reiseorte.ausstattungText(w.ausstattung, w.ausstattungSonst);
      if (au) zeilen.push([h('dt', { text: 'Ausstattung beim Besuch' }), h('dd', { text: au })]);
      if (w.notiz) zeilen.push([h('dt', { text: 'Notiz' }), h('dd', { text: w.notiz })]);
      var besucht = w.status === 'besucht';
      var karte = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Besuch' }),
        h('h1', { text: b.ort ? b.ort.name : 'Nicht festgehalten' }),
        aus ? h('p', null, h('span', { class: 'chip-status', text: 'ausgeblendet, zählt nicht mit' })) : null,
        besucht ? h('dl', { class: 'daten' }, zeilen) : h('p', { class: 'leer-text', text: 'Zu dieser Ankunft wurde nichts festgehalten.' }),
        besucht ? h('p', { class: 'knopfzeile' },
          h('a', { class: 'knopf leise', href: '#/besuch/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' }),
          h('button', { class: 'knopf leise', type: 'button', text: aus ? 'Wieder einblenden' : 'Ausblenden', onclick: function () {
            daten.besuchAusblenden(id, !aus).then(function (r) { meldung = r.ok ? (aus ? 'Der Besuch zählt wieder mit.' : 'Der Besuch ist ausgeblendet. Er wird nicht gelöscht.') : (r.fehler && r.fehler.allgemein); return zeige(); }).catch(fehlerSeite);
          } })) : null);
      var kosten = besucht ? h('section', { class: 'bereich', 'aria-label': 'Kosten' },
        h('h2', { text: 'Kosten dieses Besuchs' }),
        b.kosten.length ? h('ul', { class: 'fristen' }, b.kosten.map(kostenPostenZeile)) : h('p', { class: 'leer-text', text: 'Noch kein Betrag. Du kannst ihn jederzeit nachtragen.' }),
        h('a', { class: 'knopf leise', href: fzHash + '/kosten/neu?besuch=' + encodeURIComponent(id), text: 'Betrag eintragen' })) : null;
      var ortName = b.ort ? b.ort.name : 'Besuch';
      seite(ortName, [krumen(KR_BESUCH.concat([[b.aktivitaet.name, '#/aktivitaet/' + encodeURIComponent(b.aktivitaet.id)], [ortName]])), karte, kosten,
        b.verlauf.length > 1 ? verlaufBlock(b.verlauf) : null],
        h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/aktivitaet/' + encodeURIComponent(b.aktivitaet.id), text: 'Zur Aktivität' })));
    });
  }

  function besuchAendernFormular(id) {
    return Promise.all([daten.besuchLaden(id), daten.standorteListe()]).then(function (rr) {
      var b = rr[0];
      if (!b) return nichtGefunden('Besuch nicht gefunden');
      if (b.aktuell.werte.status !== 'besucht') return nichtGefunden('Zu diesem Besuch gibt es nichts zu ändern');
      var w = b.aktuell.werte, zurueck = '#/besuch/' + encodeURIComponent(id);
      var st = rr[1].filter(function (s) { return s.objekt.ortId === w.ortId && (s.aktuell.werte.ausgeblendet !== 'ja' || s.objekt.id === w.standortId); })
        .map(function (s) { return { wert: s.objekt.id, label: s.aktuell.werte.bezeichnung }; });
      var start = JSON.parse(JSON.stringify(w)); start.standortId = start.standortId || ''; start.zeit = start.zeit || ''; start.ausstattungSonst = start.ausstattungSonst || ''; start.notiz = start.notiz || '';
      einfachFormular({
        titel: 'Besuch ändern', krumen: krumen(KR_BESUCH.concat([[b.aktivitaet.name, '#/aktivitaet/' + encodeURIComponent(b.aktivitaet.id)], [b.ort ? b.ort.name : 'Besuch', zurueck], ['Ändern']])),
        zurueck: zurueck, werte: start,
        intro: h('p', { text: 'Der Ort lässt sich hier nicht ändern. Ist er falsch, blende den Besuch aus und trage ihn neu ein. Die Ausstattung ändert nur diesen Besuch, nicht den Ort.' }),
        gruppen: function () {
          return [{ titel: null, felder: (st.length ? [{ key: 'standortId', label: 'Standort', typ: 'auswahl', optionen: st, leerText: '– keiner –' }] : []).concat([
            { key: 'datum', label: 'Datum', typ: 'datum' }, { key: 'zeit', label: 'Uhrzeit', typ: 'zeit' },
            { key: 'ausstattung', label: 'Ausstattung beim Besuch', typ: 'mehrfach', optionen: MM.Orte.AUSSTATTUNG.map(function (a) { return { wert: a.wert, label: a.label }; }) },
            { key: 'ausstattungSonst', label: 'Weitere Ausstattung', typ: 'text' }, { key: 'notiz', label: 'Notiz (nur für dich)', typ: 'text' }]) }];
        },
        speichern: function (x) { return daten.besuchAendern(id, x); },
        meldung: function (r) { return r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'; },
        danach: function () { return zurueck; }
      });
    });
  }

  /* ---------- Seite: Kosten über alle Fahrzeuge ---------- */
  function seiteKostenUebersicht() {
    var jahr = kostenJahrWahl();
    return daten.kostenUebersicht(jahr).then(function (liste) {
      var inhalt = [krumen(KR_KOSTEN.concat([['Kosten']])), h('h1', { text: 'Kosten' }),
        h('p', { text: 'Was deine Fahrzeuge kosten: Fixkosten, variable Kosten, Instandhaltung und Wertverlust. Wähle das Fahrzeug.' }),
        kostenJahrLeiste('#/kosten', jahr)];
      /* Abgegebene Fahrzeuge (seit 2.0.46) stehen getrennt und als „abgegeben“ gekennzeichnet, ihre Kosten bleiben erhalten. */
      var aktiv = liste.filter(function (x) { return !x.fahrzeug.abgabe; }), abgegeben = liste.filter(function (x) { return !!x.fahrzeug.abgabe; });
      var zeile = function (x) {
        var a = MM.Fahrzeugarten.art(x.fahrzeug.art), k = x.auswertung, ab = x.fahrzeug.abgabe;
        var text = k && k.gesamt.summe > 0 ? euro(k.gesamt.summe) + ' im Jahr, ' + euro(k.proMonat) + ' pro Monat' : 'Für ' + jahr + ' noch nichts eingetragen';
        return h('li', null, h('a', { class: 'zeile welt-' + a.welt, href: '#/fahrzeug/' + encodeURIComponent(x.fahrzeug.id) + '/kosten?jahr=' + jahr },
          h('span', { class: 'zeile-text' },
            h('strong', { class: 'zeile-name', text: x.aktuell.werte.bezeichnung }),
            h('span', { class: 'zeile-art', text: a.name + (ab ? ' · abgegeben (' + (GRUND_WORT[ab.grund] || 'Abgegeben').toLowerCase() + ' am ' + MM.Hilfen.datum(ab.datum) + ')' : '') }),
            h('span', { class: 'zeile-art', text: text })),
          schild(a.id, kennungVon(a.id, x.aktuell.werte))));
      };
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Hier ist noch kein Fahrzeug. Lege zuerst ein Fahrzeug an.' })));
      else {
        if (aktiv.length) inhalt.push(h('ul', { class: 'liste' }, aktiv.map(zeile)));
        else inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Es gibt kein aktives Fahrzeug. Die abgegebenen stehen unten.' })));
        if (abgegeben.length) inhalt.push(h('details', { class: 'ausgebaut' },
          h('summary', { text: 'Abgegebene Fahrzeuge (' + abgegeben.length + ')' }),
          h('ul', { class: 'liste' }, abgegeben.map(zeile))));
      }
      seite('Kosten', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/funktionen', text: 'Zurück' }),
        h('a', { class: 'knopf leise', href: '#/kosten/listen', text: 'Kostenarten und Zahlungsmittel' })));
    });
  }

  /* ---------- Seite: Kosten eines Fahrzeugs ---------- */
  function kostenGesamtBereich(a) {
    if (!(a.gesamt.summe > 0)) {
      return h('section', { class: 'schale sx', 'aria-label': 'Gesamtkosten' },
        h('div', { class: 'schale-name', text: 'Gesamtkosten' }),
        h('p', { class: 'leer-text', text: 'Für ' + a.jahr + ' sind noch keine Kosten eingetragen. Trage unten Fixkosten, variable Kosten und Instandhaltung ein, dann rechnet die App aus, was das Fahrzeug im Jahr, pro Monat, pro Nutzungstag und pro Kilometer kostet.' }));
    }
    var zeilen = [
      [h('dt', { text: 'Im Jahr ' + a.jahr }), h('dd', { text: euro(a.gesamt.summe) + grundText(a.gesamtGrundlage) })]
    ];
    if (a.gesamt.noch > 0) {
      zeilen.push([h('dt', { text: 'Davon bis heute' }), h('dd', { text: euro(a.gesamt.bisher) })]);
      zeilen.push([h('dt', { text: 'Davon noch zu erwarten' }), h('dd', { text: euro(a.gesamt.noch) + ' (Vorschau: geplante und wiederkehrende Beträge)' })]);
    }
    zeilen.push([h('dt', { text: 'Pro Monat' }), h('dd', { text: euro(a.proMonat) + ' (Jahressumme geteilt durch 12, gerechnet)' })]);
    zeilen.push([h('dt', { text: 'Pro Nutzungstag' }), h('dd', { text: a.proTag !== null
      ? euro(a.proTag) + ' bei ' + a.nutzung.genutzt + (a.nutzung.genutzt === 1 ? ' genutztem Tag' : ' genutzten Tagen') + ' (gerechnet)'
      : 'Noch nicht gerechnet: Für ' + a.jahr + ' gibt es keinen genutzten Tag in einer Aktivität.' })]);
    zeilen.push([h('dt', { text: 'Pro Kilometer' }), h('dd', { text: a.proKm !== null
      ? euro(a.proKm) + ' bei ' + MM.Hilfen.zahl(a.km.km) + ' km (gerechnet' + (a.km.ohneAnfang ? ', ab dem ersten Stand ' + MM.Hilfen.datum(a.km.ab) : '') + ')'
      : 'Noch nicht gerechnet: Für ' + a.jahr + ' fehlen Kilometerstände' + (a.kmZaehler ? '' : ' (es gibt keinen Zähler für Strecke am Fahrzeug)') + '.' })]);
    return h('section', { class: 'schale sx', 'aria-label': 'Gesamtkosten' },
      h('div', { class: 'schale-name', text: 'Gesamtkosten' }),
      h('dl', { class: 'daten' }, zeilen),
      h('p', { class: 'hilfe', text: 'Pro Tag und pro Kilometer rechnen mit den Kosten bis heute, damit sie zur genutzten Zeit passen. Bei jedem Wert steht, ob er eingegeben, geschätzt oder gerechnet ist.' }));
  }

  function kostenVergleichBereich(a, fzHash) {
    var v = a.vergleich;
    if (!v) {
      return h('section', { class: 'bereich', 'aria-label': 'Vergleich' },
        h('h2', { text: 'Vergleich mit Mieten oder Chartern' }),
        h('p', { class: 'leer-text', text: 'Trage in den Kostenstammdaten ein, was ein gemietetes oder gechartertes Fahrzeug der gleichen Klasse pro Tag kostet. Dann zeigt die App, wie deine Kosten dazu stehen.' }),
        h('a', { class: 'knopf leise', href: fzHash + '/kostenstamm', text: 'Vergleichspreis eintragen' }));
    }
    var zeilen = [
      [h('dt', { text: 'Preis zum Mieten' }), h('dd', { text: euro(v.preisTag) + ' pro Tag' + grundText(v.grundlage) + (v.bezeichnung ? ', ' + v.bezeichnung : '') })]
    ];
    if (v.tage > 0) {
      zeilen.push([h('dt', { text: 'Deine Kosten bis heute' }), h('dd', { text: euro(v.eigen) + ' (gerechnet)' })]);
      zeilen.push([h('dt', { text: 'Mieten für ' + v.tage + (v.tage === 1 ? ' genutzten Tag' : ' genutzte Tage') }), h('dd', { text: euro(v.miete) + ' (gerechnet)' })]);
      zeilen.push([h('dt', { text: 'Unterschied' }), h('dd', { text: v.differenz > 0 ? 'Das eigene Fahrzeug war bis heute um ' + euro(v.differenz) + ' teurer.' : (v.differenz < 0 ? 'Das eigene Fahrzeug war bis heute um ' + euro(-v.differenz) + ' günstiger.' : 'Beides kostet bis heute gleich viel.') })]);
    } else zeilen.push([h('dt', { text: 'Genutzte Tage' }), h('dd', { text: 'Noch keiner in ' + a.jahr + '. Ein Vergleich ist erst mit genutzten Tagen sinnvoll.' })]);
    if (v.guenstigerAbTage > 0) zeilen.push([h('dt', { text: 'Ab wie vielen Tagen' }), h('dd', { text: 'Ab etwa ' + v.guenstigerAbTage + ' Nutzungstagen im Jahr ist das eigene Fahrzeug günstiger als Mieten (Jahressumme geteilt durch den Tagespreis).' })]);
    return h('section', { class: 'bereich', 'aria-label': 'Vergleich' },
      h('h2', { text: 'Vergleich mit Mieten oder Chartern' }),
      h('dl', { class: 'daten' }, zeilen),
      h('p', { class: 'hilfe', text: 'Das ist nur eine Rechnung mit deinen Angaben. Sie berücksichtigt nicht, was Mieten sonst kostet oder was dir das eigene Fahrzeug sonst bringt.' }));
  }

  function kostenGruppeBereich(g, a, jahr, fzHash) {
    var gr = a.gruppen[g.wert], posten = a.posten[g.wert];
    return h('section', { class: 'bereich', 'aria-label': g.label },
      h('h2', { text: g.label + ': ' + euro(gr.summe) + grundText(gr.grundlage) }),
      h('p', { class: 'hilfe', text: g.hilfe }),
      posten.length ? h('ul', { class: 'fristen' }, posten.map(kostenPostenZeile)) : h('p', { class: 'leer-text', text: 'Für ' + jahr + ' ist nichts eingetragen.' }),
      posten.length ? h('p', { class: 'hilfe', text: 'Rechts steht der Anteil am Jahr ' + jahr + '. Wiederkehrende Beträge sind nach Monaten gerechnet. Falsch eingetragen? Tippe den Posten an, dort kannst du ihn korrigieren oder löschen.' }) : null,
      h('a', { class: 'knopf leise', href: fzHash + '/kosten/neu?gruppe=' + g.wert, text: g.label + ' eintragen' }));
  }

  function kostenWertverlustBereich(a, fzHash, fahrzeugId) {
    var s = a.stamm ? a.stamm.aktuell.werte : null, wv = a.wertverlust;
    var inhalt = [h('h2', { text: 'Wertverlust: ' + euro(wv.summe) + grundText(wv.grundlage) })];
    if (wv.angegeben) inhalt.push(h('p', { text: 'Gerechnet: ' + euro(s.fahrzeugwert) + ' Wert (Stand ' + MM.Hilfen.datum(s.wertDatum) + ') mal ' + MM.Hilfen.zahl(s.wertverlustProzent) + ' % pro Jahr.' }));
    else if (s && s.fahrzeugwert && s.wertverlustProzent > 0) inhalt.push(h('p', { text: 'Der Wert ist erst ab ' + MM.Hilfen.datum(s.wertDatum) + ' eingetragen. Für ' + a.jahr + ' rechnet die App keinen Wertverlust.' }));
    else if (s && s.fahrzeugwert) inhalt.push(h('p', { text: 'Wert ' + euro(s.fahrzeugwert) + ' (Stand ' + MM.Hilfen.datum(s.wertDatum) + '). Es ist kein Wertverlust eingetragen: Ohne Angabe rechnet die App ohne Wertveränderung.' }));
    else inhalt.push(h('p', { class: 'leer-text', text: 'Es ist kein Wert eingetragen. Ohne Angabe rechnet die App ohne Wertveränderung. Bei Wohnmobilen, Booten und Oldtimern ist der Wertverlust ab einem gewissen Alter oft sehr klein.' }));
    if (a.wertFrage) {
      inhalt.push(h('div', { class: 'warnung status-bald', role: 'status' },
        h('p', { text: 'Stimmt der Wert des Fahrzeugs noch? Er wurde zuletzt am ' + MM.Hilfen.datum(s.wertDatum) + ' eingetragen.' }),
        h('p', { class: 'knopfzeile' },
          h('button', { class: 'knopf klein', type: 'button', text: 'Ja, er stimmt noch', onclick: function () {
            daten.kostenstammWertBestaetigen(fahrzeugId).then(function (r) { meldung = r.ok ? 'Der Wert gilt mit dem heutigen Stand.' : (r.fehler && r.fehler.allgemein); return zeige(); }).catch(fehlerSeite);
          } }),
          h('a', { class: 'knopf leise klein', href: fzHash + '/kostenstamm', text: 'Nein, Wert ändern' }))));
    }
    inhalt.push(h('a', { class: 'knopf leise', href: fzHash + '/kostenstamm', text: 'Kostenstammdaten ändern' }));
    return h('section', { class: 'bereich', 'aria-label': 'Wertverlust' }, inhalt);
  }

  function seiteKostenFahrzeug(fahrzeugId) {
    var jahr = kostenJahrWahl();
    return daten.kostenAuswertung(fahrzeugId, jahr).then(function (a) {
      if (!a) return nichtGefunden('Fahrzeug nicht gefunden');
      var fzHash = '#/fahrzeug/' + encodeURIComponent(fahrzeugId), name = a.fahrzeugAktuell.werte.bezeichnung;
      seite('Kosten: ' + name, [
        krumen(KR_KOSTEN.concat([['Kosten', '#/kosten?jahr=' + a.jahr], [name]])),
        h('h1', { text: 'Kosten: ' + name }),
        kostenJahrLeiste(fzHash + '/kosten', a.jahr),
        kostenGesamtBereich(a),
        kostenVergleichBereich(a, fzHash),
        MM.Kosten.GRUPPEN.map(function (g) { return kostenGruppeBereich(g, a, a.jahr, fzHash); }),
        kostenWertverlustBereich(a, fzHash, fahrzeugId),
        a.andere.length ? h('details', { class: 'ausgebaut' }, h('summary', { text: 'Weitere Posten ohne Anteil in ' + a.jahr + ' (' + a.andere.length + ')' }),
          h('ul', { class: 'fristen' }, a.andere.map(kostenPostenZeile))) : null,
        a.ausgeblendet.length ? h('details', { class: 'ausgebaut' }, h('summary', { text: 'Ausgeblendet (' + a.ausgeblendet.length + ')' }),
          h('ul', { class: 'fristen' }, a.ausgeblendet.map(kostenPostenZeile))) : null
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/kosten?jahr=' + a.jahr, text: 'Zurück' }),
        h('a', { class: 'knopf leise', href: fzHash + '/kostenstamm', text: 'Kostenstammdaten' }),
        h('a', { class: 'knopf', href: fzHash + '/kosten/neu', text: 'Kosten eintragen' })));
    });
  }

  /* ---------- Seite: ein Posten ---------- */
  function seitePosten(id) {
    return daten.kostenLaden(id).then(function (k) {
      if (!k) return nichtGefunden('Posten nicht gefunden');
      var w = k.aktuell.werte, fzHash = '#/fahrzeug/' + encodeURIComponent(k.fahrzeug.id), fzName = k.fahrzeugAktuell.werte.bezeichnung;
      var reise = w.gruppe === 'reisekasse', gruppeLabel = MM.Kosten.labelVon(MM.Kosten.alleGruppen(), w.gruppe);
      var zeilen = [[h('dt', { text: 'Gruppe' }), h('dd', { text: gruppeLabel })]];
      if (w.kostenart) zeilen.push([h('dt', { text: 'Art der Kosten' }), h('dd', { text: k.artName || MM.Kosten.labelVon(MM.Kosten.KOSTENARTEN, w.kostenart) })]);
      zeilen.push([h('dt', { text: 'Betrag' }), h('dd', { text: kostenPostenText(w) })]);
      zeilen.push([h('dt', { text: 'Grundlage' }), h('dd', { text: w.grundlage === 'geschaetzt' ? 'Geschätzt' : (w.grundlage === 'gerechnet' ? 'Gerechnet mit dem Kurs der Kasse. Du kannst den Euro-Betrag von der Abrechnung nachtragen.' : 'Tatsächlicher Betrag (eingegeben)') })]);
      if (k.zahlungName) zeilen.push([h('dt', { text: 'Bezahlt mit' }), h('dd', { text: k.zahlungName })]);
      if (w.ortText) zeilen.push([h('dt', { text: 'Ort (Text)' }), h('dd', { text: w.ortText })]);
      zeilen.push([h('dt', { text: 'Fahrzeug' }), h('dd', null, h('a', { href: fzHash, text: fzName }))]);
      if (w.komponenteId) zeilen.push([h('dt', { text: 'Komponente' }), h('dd', null, h('a', { href: '#/komponente/' + encodeURIComponent(w.komponenteId), text: k.komponenteName }))]);
      if (w.aktivitaetId) zeilen.push([h('dt', { text: 'Aktivität' }), h('dd', null, h('a', { href: '#/aktivitaet/' + encodeURIComponent(w.aktivitaetId), text: k.aktivitaetName }))]);
      if (w.ortId) zeilen.push([h('dt', { text: 'Ort' }), h('dd', null, h('a', { href: '#/ort/' + encodeURIComponent(w.ortId), text: k.ortName }))]);
      if (w.besuchId) zeilen.push([h('dt', { text: 'Besuch' }), h('dd', null, h('a', { href: '#/besuch/' + encodeURIComponent(w.besuchId), text: 'Besuch ansehen' }))]);
      if (w.vorgangId) zeilen.push([h('dt', { text: 'Vorgang in der Werkstatt' }), h('dd', null, h('a', { href: '#/vorgang/' + encodeURIComponent(w.vorgangId), text: k.vorgangName }))]);
      if (w.notiz) zeilen.push([h('dt', { text: 'Notiz' }), h('dd', { text: w.notiz })]);
      var aus = w.ausgeblendet === 'ja';
      var karte = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Kosten: ' + gruppeLabel }),
        h('h1', { text: w.bezeichnung }),
        aus ? h('p', null, h('span', { class: 'chip-status', text: 'ausgeblendet, rechnet nicht mit' })) : null,
        h('dl', { class: 'daten' }, zeilen),
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(k.aktuell.erstelltAm) + ', per Handeingabe' }));
      /* Falsch eingegeben (seit 2.0.46): Korrigieren, Ausblenden und Löschen stehen zusammen und gut sichtbar unter dem Posten. */
      var zurueckHash = reise ? '#/aktivitaet/' + encodeURIComponent(w.aktivitaetId) + '/reisekasse' : fzHash + '/kosten';
      var verwalten = h('section', { class: 'bereich', 'aria-label': 'Falsch eingegeben' },
        h('h2', { text: 'Falsch eingegeben?' }),
        h('p', { class: 'hilfe', text: 'Korrigieren ändert die Angaben, der frühere Stand bleibt im Verlauf. Ausblenden rechnet den Posten nicht mehr mit, er bleibt aber aufgehoben. Löschen entfernt ihn endgültig.' }),
        h('p', { class: 'knopfzeile' },
          h('a', { class: 'knopf', href: '#/kosten/' + encodeURIComponent(id) + '/aendern', text: 'Korrigieren' }),
          h('button', { class: 'knopf leise', type: 'button', text: aus ? 'Wieder einblenden' : 'Ausblenden', onclick: function () {
            daten.kostenAusblenden(id, !aus).then(function (r) { meldung = r.ok ? (aus ? 'Der Posten rechnet wieder mit.' : 'Der Posten ist ausgeblendet und rechnet nicht mehr mit. Er wird nicht gelöscht.') : (r.fehler && r.fehler.allgemein); return zeige(); }).catch(fehlerSeite);
          } }),
          h('button', { class: 'knopf gefahr', type: 'button', text: 'Löschen', onclick: function () {
            var nb = k.dokumente.length;
            var frage = 'Diesen Posten wirklich löschen?\n\n' + w.bezeichnung + ': ' + kostenPostenText(w) + '\n\n'
              + (nb ? 'Dabei verschwinden auch ' + (nb === 1 ? '1 Foto oder Beleg' : nb + ' Fotos und Belege') + '. ' : '')
              + (reise ? 'Die Kasse der Reise rechnet danach ohne diesen Betrag. ' : '')
              + 'Das lässt sich nicht rückgängig machen. Soll er nur nicht mehr mitrechnen, wähle „Ausblenden“.';
            if (!global.confirm(frage)) return;
            daten.kostenLoeschen(id).then(function (r) {
              if (!r.ok) { meldung = (r.fehler && r.fehler.allgemein) || 'Das hat nicht geklappt.'; return zeige(); }
              meldung = 'Der Posten ist gelöscht.';
              global.location.hash = zurueckHash;
            }).catch(fehlerSeite);
          } })));
      var fotos = h('section', { class: 'bereich', 'aria-label': 'Fotos und Belege' },
        h('h2', { text: 'Fotos und Belege' }),
        k.dokumente.length ? h('ul', { class: 'fristen' }, k.dokumente.map(function (x) { return dokZeile(x, false); }))
          : h('p', { class: 'leer-text', text: 'Noch nichts abgelegt. Lege zum Beispiel ein Foto vom Beleg oder vom gekauften Stück ab, als Erinnerung.' }),
        h('a', { class: 'knopf leise', href: '#/kosten/' + encodeURIComponent(id) + '/dokument/neu', text: 'Foto oder Beleg hinzufügen' }));
      seite(w.bezeichnung, [
        krumen(reise ? KR_KOSTEN.concat([['Kosten', '#/kosten'], [k.aktivitaetName || 'Aktivität', '#/aktivitaet/' + encodeURIComponent(w.aktivitaetId)], [w.bezeichnung]])
          : KR_KOSTEN.concat([['Kosten', '#/kosten'], [fzName, fzHash + '/kosten'], [w.bezeichnung]])),
        karte, verwalten, fotos, k.verlauf.length > 1 ? verlaufBlock(k.verlauf) : null
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: zurueckHash, text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/kosten/' + encodeURIComponent(id) + '/aendern', text: 'Korrigieren' })));
    });
  }

  /* ---------- Formular: Posten eintragen oder ändern ---------- */
  /* modus 'neu' (id = Fahrzeug; vorbelegt über ?gruppe=, ?aktivitaet=, ?vorgang=, ?komponente=) oder 'aendern' (id = Posten) */
  function kostenFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = neu ? daten.fahrzeugLaden(id).then(function (f) { return f ? { fahrzeugId: id, fz: f.aktuell, posten: null } : null; })
      : daten.kostenLaden(id).then(function (k) { return k ? { fahrzeugId: k.fahrzeug.id, fz: k.fahrzeugAktuell, posten: k } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var vorGruppe = neu ? hashParam('gruppe') : '', vorAkt = neu ? hashParam('aktivitaet') : '', vorVorgang = neu ? hashParam('vorgang') : '', vorKomp = neu ? hashParam('komponente') : '';
      var vorBesuch = neu ? hashParam('besuch') : '', vorOrt = neu ? hashParam('ort') : '';
      var vorTag = neu ? hashParam('tag') : '', tagAkt = neu ? vorAkt : (k.posten.aktuell.werte.aktivitaetId || '');
      return Promise.all([daten.komponentenListe(k.fahrzeugId), daten.aktivitaetenListe(), vorVorgang ? daten.vorgangLaden(vorVorgang) : Promise.resolve(null),
        daten.orteListe(), vorBesuch ? daten.besuchLaden(vorBesuch) : Promise.resolve(null), daten.kostenartenListe(), daten.zahlungsmittelListe(),
        tagAkt ? daten.logbuchLaden(tagAkt) : Promise.resolve(null)]).then(function (rr) {
        var komp = rr[0], aktivitaeten = rr[1], vg = rr[2], orteAlle = rr[3], bs = rr[4], artenAlle = rr[5], zahlungAlle = rr[6];
        /* Tage der Reise (seit 2.0.43): nur für die Aktivität, mit der das Formular geöffnet wurde. */
        var tagListe = rr[7] ? rr[7].abschnitte.filter(function (t) { return !t.ausgeblendet || t.objekt.id === (neu ? vorTag : k.posten.aktuell.werte.abschnittId); }) : [];
        if (vorVorgang && (!vg || vg.fahrzeug.id !== k.fahrzeugId)) return nichtGefunden('Vorgang nicht gefunden');
        if (vorBesuch && (!bs || bs.fahrzeug.id !== k.fahrzeugId || bs.aktuell.werte.status !== 'besucht')) return nichtGefunden('Besuch nicht gefunden');
        if (vorVorgang) { vorGruppe = 'instandhaltung'; if (!vorKomp && vg.komponente) vorKomp = vg.komponente.id; }
        if (vorAkt && vorGruppe !== 'reisekasse') vorGruppe = 'variabel';
        if (bs) { vorGruppe = 'variabel'; vorAkt = bs.objekt.aktivitaetId; vorOrt = bs.aktuell.werte.ortId || ''; }
        var festeGruppe = !!vorGruppe && (!!vorVorgang || !!vorAkt);
        var istReise = vorGruppe === 'reisekasse' || (!neu && k.posten.aktuell.werte.gruppe === 'reisekasse');
        /* Ein Betrag aus einem Besuch behält seinen Ort, sonst kann der Ort frei gewählt werden (nur variable Kosten). */
        var ortFest = bs || (!neu && k.posten.aktuell.werte.besuchId);
        var fzHash = '#/fahrzeug/' + encodeURIComponent(k.fahrzeugId), fzName = k.fz.werte.bezeichnung;
        var aktZiel = '#/aktivitaet/' + encodeURIComponent(vorAkt) + (vorGruppe === 'reisekasse' ? '/reisekasse' : '');
        var zurueck = neu ? (vorBesuch ? '#/besuch/' + encodeURIComponent(vorBesuch) : (vorVorgang ? '#/vorgang/' + encodeURIComponent(vorVorgang) : (vorAkt ? aktZiel : fzHash + '/kosten'))) : '#/kosten/' + encodeURIComponent(id);
        var titel = neu ? 'Kosten eintragen' : 'Posten ändern';
        var weg = KR_KOSTEN.concat([['Kosten', '#/kosten'], [fzName, fzHash + '/kosten']]);
        if (!neu) weg.push([k.posten.aktuell.werte.bezeichnung, '#/kosten/' + encodeURIComponent(id)]);
        if (istReise) titel = neu ? 'Ausgabe der Reisekasse eintragen' : 'Ausgabe ändern';
        weg.push([titel]);
        var start = neu ? { gruppe: MM.Kosten.istGruppe(vorGruppe) ? vorGruppe : '', bezeichnung: '', kostenart: '', betrag: '', rhythmus: 'jaehrlich',
          datum: vg && vg.aktuell.werte.erledigtAm ? vg.aktuell.werte.erledigtAm : daten.heute(), bis: '', grundlage: 'eingegeben', komponenteId: vorKomp, aktivitaetId: vorAkt, ortId: vorOrt, notiz: '',
          bezahltMit: '', neueKostenart: '', neuesZahlungsmittel: '', waehrung: '', betragWaehrung: '', ortText: '', abschnittId: vorTag }
          : JSON.parse(JSON.stringify(k.posten.aktuell.werte));
        if (neu && vorTag) { var vt = tagListe.filter(function (t) { return t.objekt.id === vorTag; })[0]; if (vt) start.datum = vt.aktuell.werte.datum; else start.abschnittId = ''; }
        if (!neu) {
          var sw = start;
          sw.abschnittId = sw.abschnittId || '';
          sw.neueKostenart = ''; sw.neuesZahlungsmittel = ''; sw.bezahltMit = sw.bezahltMit || ''; sw.waehrung = sw.waehrung || ''; sw.ortText = sw.ortText || '';
          sw.betragWaehrung = sw.betragWaehrung || '';
          if (sw.grundlage === 'gerechnet') { sw.betrag = ''; sw.grundlage = 'eingegeben'; } /* leer lassen heißt: die App rechnet */
          if (sw.waehrung && sw.betragWaehrung !== '') sw.betragWaehrung = String(sw.betragWaehrung).replace('.', ',');
        }
        var letztesDatum = null;
        var aktOpt = aktivitaeten.filter(function (a) { return a.aktuell.werte.fahrzeugId === k.fahrzeugId && (a.status !== 'storniert' || a.objekt.id === start.aktivitaetId); })
          .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung + ' (' + zeitraumText(a.aktuell.werte) + ')' }; });
        var kompOpt = komp.map(function (c) { return { wert: c.komponente.id, label: c.aktuell.werte.bezeichnung }; });
        var ortOpt = orteAlle.filter(function (o) { return o.aktuell.werte.ausgeblendet !== 'ja' || o.objekt.id === start.ortId; })
          .map(function (o) { return { wert: o.objekt.id, label: o.aktuell.werte.bezeichnung }; });
        var bezHilfe = { reisekasse: 'Zum Beispiel „Pizza in Rovinj“ oder „Magnet als Souvenir“', fix: 'Zum Beispiel „Liegeplatz Heimathafen“ oder „Versicherung Wohnmobil“', variabel: 'Zum Beispiel „Diesel“ oder „Hafengebühr Rovinj“', instandhaltung: 'Zum Beispiel „Zündkerzen“ oder „Rechnung Autohaus Müller“' };
        var intro = null;
        if (neu && vorVorgang) intro = h('p', { text: 'Betrag zur Arbeit „' + vg.aktuell.werte.bezeichnung + '“. Er gehört zur Instandhaltung und steht nur hier in der Kosten-Liste, nirgends sonst.' });
        else if (neu && vorBesuch) intro = h('p', { text: 'Betrag zum Besuch in „' + (bs.ort ? bs.ort.name : 'unbekannt') + '“. Er gehört zu den variablen Kosten und steht nur in der Kosten-Liste.' });
        else if (neu && istReise) intro = h('p', { text: 'Eine Ausgabe der Reise, die nicht das Fahrzeug betrifft: Einkauf, Essen gehen, Souvenir, Eintritt. Name und Betrag genügen. Wählst du „Bar“, zieht die App den Betrag von der Kasse ab.' });
        else if (neu && vorAkt) intro = h('p', { text: 'Kosten zu dieser Aktivität. Sie gehören zu den variablen Kosten, weil sie erst bei der Nutzung entstehen.' });
        else if (neu) intro = h('p', { text: 'Wähle die Gruppe und trage den Betrag ein. Name und Betrag genügen, alles andere ist freiwillig. Auch geschätzte Beträge sind möglich, sie sind als geschätzt gekennzeichnet.' });
        einfachFormular({
          titel: titel, krumen: krumen(weg), zurueck: zurueck, werte: start, neuzeichnenBei: ['gruppe', 'waehrung'], intro: intro,
          gruppen: function (z) {
            var g = z.werte.gruppe;
            var wahl = null;
            if (neu && !festeGruppe) wahl = { key: 'gruppe', label: 'Gruppe', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Kosten.GRUPPEN.map(function (x) { return { wert: x.wert, label: x.label }; }),
              hilfe: g ? MM.Kosten.labelVon(MM.Kosten.GRUPPEN, g) + ': ' + MM.Kosten.GRUPPEN.filter(function (x) { return x.wert === g; })[0].hilfe : 'Fixkosten sind immer gleich, variable Kosten entstehen bei der Nutzung, Instandhaltung ist Wartung und Reparatur.' };
            if (!g) return [{ titel: null, felder: [wahl] }];
            var sichtbarArten = artenAlle.filter(function (a) { return !a.ausgeblendet || a.wert === z.werte.kostenart; }).map(function (a) { return { wert: a.wert, label: a.label, gruppe: a.gruppe }; });
            var alle = MM.Kosten.felder(g, sichtbarArten);
            var mitAkt = g === 'variabel' || g === 'reisekasse';
            var fremd = mitAkt && !!z.werte.waehrung && z.werte.waehrung !== 'EUR';
            var hauptFelder = [];
            alle.filter(function (f) { return f.key !== 'notiz'; }).forEach(function (f) {
              if (f.key === 'betrag' && fremd) {
                hauptFelder.push({ key: 'betragWaehrung', label: 'Betrag in ' + z.werte.waehrung, typ: 'zahl', einheit: z.werte.waehrung });
                hauptFelder.push(Object.assign({}, f, { label: 'Betrag in Euro (freiwillig)', hilfe: 'Leer lassen: Die App rechnet mit dem Kurs deiner Kasse und kennzeichnet den Betrag als „gerechnet“. Den Euro-Betrag von der Abrechnung kannst du jederzeit nachtragen.' }));
              } else hauptFelder.push(f);
              if (f.key === 'kostenart') hauptFelder.push({ key: 'neueKostenart', label: 'Oder neue Art anlegen (freiwillig)', typ: 'text', hilfe: 'Die neue Art steht danach in der Liste, auch bei den nächsten Posten.' });
            });
            var haupt = [{ key: 'bezeichnung', label: 'Wofür?', typ: 'text', hilfe: bezHilfe[g] }].concat(hauptFelder);
            var verweise = [];
            if (kompOpt.length && g !== 'reisekasse') verweise.push({ key: 'komponenteId', label: 'Komponente', typ: 'auswahl', optionen: kompOpt, leerText: '– keine –', hilfe: 'Zum Beispiel der Motor, wenn der Betrag zu ihm gehört.' });
            if (mitAkt && !ortFest && ortOpt.length) verweise.push({ key: 'ortId', label: 'Ort', typ: 'auswahl', optionen: ortOpt, leerText: '– keiner –', hilfe: 'Zum Beispiel der Stellplatz oder Hafen, in dem der Betrag angefallen ist. Die Orte legst du unter Stammdaten › Orte an.' });
            if (g === 'variabel') verweise.push({ key: 'aktivitaetId', label: 'Aktivität', typ: 'auswahl', optionen: aktOpt, leerText: '– keine –', hilfe: aktOpt.length ? 'Zu welcher Aktivität gehört der Betrag, zum Beispiel einem Törn oder Urlaub?' : 'Es gibt noch keine Aktivität für dieses Fahrzeug.' });
            if (mitAkt && tagListe.length && z.werte.aktivitaetId === tagAkt) verweise.push({ key: 'abschnittId', label: 'Tag der Reise', typ: 'auswahl', leerText: '– keiner (nach Datum) –',
              optionen: tagListe.map(function (t) { return { wert: t.objekt.id, label: tagText(t.aktuell.werte) }; }),
              hilfe: 'Zu welchem Tag der Reise gehört der Betrag? Ohne Angabe ordnet die App ihn dem Tag mit gleichem Datum zu, wenn es genau einen gibt, sonst steht er „ohne Tag“.' });
            var gruppenListe = [];
            if (wahl) gruppenListe.push({ titel: null, felder: [wahl] });
            gruppenListe.push({ titel: wahl ? MM.Kosten.labelVon(MM.Kosten.GRUPPEN, g) : null, felder: haupt });
            if (verweise.length) gruppenListe.push({ titel: 'Gehört zu (freiwillig)', felder: verweise });
            if (mitAkt) {
              var zOpt = zahlungAlle.filter(function (x) { return !x.ausgeblendet || x.wert === z.werte.bezahltMit; }).map(function (x) { return { wert: x.wert, label: x.label }; });
              var wOpt = MM.Reisekasse.WAEHRUNGEN.map(function (x) { return { wert: x.wert, label: x.label }; });
              if (z.werte.waehrung && !wOpt.some(function (x) { return x.wert === z.werte.waehrung; })) wOpt.push({ wert: z.werte.waehrung, label: z.werte.waehrung });
              var hinw = z.werte.bezahltMit === 'bar' && z.werte.aktivitaetId ? 'Bar: Der Betrag wird von der Kasse dieser Aktivität abgezogen.' : null;
              gruppenListe.push({ titel: 'Bezahlung und Ort (freiwillig)', hinweis: hinw, felder: [
                { key: 'bezahltMit', label: 'Bezahlt mit', typ: 'auswahl', optionen: zOpt, leerText: '– keine Angabe –' },
                { key: 'neuesZahlungsmittel', label: 'Oder neues Zahlungsmittel anlegen', typ: 'text', hilfe: 'Nur eine Bezeichnung, zum Beispiel „Kreditkarte“. Keine Karten- oder Kontonummern.' },
                { key: 'waehrung', label: 'Währung', typ: 'auswahl', optionen: wOpt, leerText: '– Euro –' },
                { key: 'ortText', label: 'Ort als Text', typ: 'text', hilfe: 'Zum Beispiel „Rovinj, Markt“. Einen Ort aus der Orte-Liste wählst du oben bei „Gehört zu“.' }] });
            }
            gruppenListe.push({ titel: null, felder: alle.filter(function (f) { return f.key === 'notiz'; }) });
            return gruppenListe;
          },
          speichern: function (w) {
            letztesDatum = w.datum || daten.heute();
            return neu ? daten.kostenAnlegen(k.fahrzeugId, Object.assign({}, w, { vorgangId: vorVorgang, besuchId: vorBesuch })) : daten.kostenAendern(id, w);
          },
          meldung: function (r) { return neu ? 'Eingetragen.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
          danach: function (r) {
            if (!neu) return '#/kosten/' + encodeURIComponent(id);
            if (vorBesuch) return '#/besuch/' + encodeURIComponent(vorBesuch);
            if (vorVorgang) return '#/vorgang/' + encodeURIComponent(vorVorgang);
            if (vorAkt) return aktZiel;
            return fzHash + '/kosten?jahr=' + (letztesDatum || daten.heute()).slice(0, 4);
          }
        });
      });
    });
  }

  /* ---------- Formular: Kostenstammdaten (Wert, Wertverlust, Vergleichspreis) ---------- */
  function kostenstammFormular(fahrzeugId) {
    return Promise.all([daten.fahrzeugLaden(fahrzeugId), daten.kostenstammLaden(fahrzeugId)]).then(function (r) {
      var f = r[0], st = r[1];
      if (!f) return nichtGefunden('Fahrzeug nicht gefunden');
      var fzHash = '#/fahrzeug/' + encodeURIComponent(fahrzeugId), name = f.aktuell.werte.bezeichnung;
      einfachFormular({
        titel: 'Kostenstammdaten', krumen: krumen(KR_KOSTEN.concat([['Kosten', '#/kosten'], [name, fzHash + '/kosten'], ['Kostenstammdaten']])), zurueck: fzHash + '/kosten',
        werte: st ? JSON.parse(JSON.stringify(st.aktuell.werte)) : { vergleichGrundlage: 'geschaetzt' },
        intro: h('p', { text: 'Alles freiwillig. Ohne Wert und Wertverlust rechnet die App ohne Wertveränderung. Der Vergleichspreis ist die Grundlage für den Vergleich mit Mieten oder Chartern.' }),
        gruppen: function () {
          var fe = MM.Kosten.stammFelder();
          function aus(keys) { return fe.filter(function (x) { return keys.indexOf(x.key) >= 0; }); }
          return [{ titel: 'Wert und Wertverlust', felder: aus(['fahrzeugwert', 'wertDatum', 'wertverlustProzent']) },
            { titel: 'Vergleich mit Mieten oder Chartern', felder: aus(['vergleichBezeichnung', 'vergleichPreisTag', 'vergleichGrundlage']) }];
        },
        speichern: function (w) { return daten.kostenstammSetzen(fahrzeugId, w); },
        meldung: function (x) { return x.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'; },
        danach: function () { return fzHash + '/kosten'; }
      });
    });
  }

  /* ---------- Seite: Zähler ---------- */
  function seiteZaehler(id) {
    return daten.zaehlerLaden(id).then(function (z) {
      if (!z) return nichtGefunden('Zähler nicht gefunden');
      var besitzer = z.komponente ? z.komponenteAktuell.werte.bezeichnung : z.fahrzeugAktuell.werte.bezeichnung;
      var zurueck = z.komponente ? '#/komponente/' + encodeURIComponent(z.komponente.id) : '#/fahrzeug/' + encodeURIComponent(z.fahrzeug.id);
      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: z.art.label + ' an: ' + besitzer }),
        h('h1', { text: z.bezeichnung }),
        h('p', { class: 'grosse-zahl', text: z.stand ? zahlMit(z.stand.wert, z.einheit) : 'Noch kein Stand' }),
        z.stand ? h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.datum(z.stand.datum) + ', ' + MM.Motoren.quelleText(z.stand.quelle, true) }) : h('p', { class: 'leer-text', text: 'Trage den ersten Zählerstand ein. Dann rechnen die Fristen damit.' }),
        h('p', null, h('a', { class: 'knopf leise', href: '#/zaehler/' + encodeURIComponent(id) + '/aendern', text: 'Name ändern' })));
      var staende = h('details', { class: 'verlauf', open: z.staende.length ? 'open' : null },
        h('summary', { text: 'Zählerstände (' + z.staende.length + ')' }),
        h('ol', null, z.staende.map(function (s, i) {
          return h('li', { class: i === 0 ? 'aktuell' : null },
            h('div', null, h('span', { class: 'wann', text: zahlMit(s.wert, z.einheit) }), ', ' + MM.Hilfen.datum(s.datum), i === 0 ? h('span', { class: 'marke-aktuell', text: 'aktuell' }) : null),
            s.notiz ? h('div', { text: s.notiz }) : null);
        })));
      seite(z.bezeichnung, [
        krumen(ortKrumen(z.fahrzeugAktuell, z.fahrzeug.id, z.komponente ? { komponente: z.komponente, aktuell: z.komponenteAktuell } : null).concat([[z.bezeichnung]])),
        kopf, staende, z.verlauf.length > 1 ? verlaufBlock(z.verlauf) : null
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/zaehler/' + encodeURIComponent(id) + '/stand', text: 'Neuen Stand eintragen' })));
    });
  }

  /* ---------- Formular: Zähler anlegen / Name ändern ---------- */
  /* modus: 'neu-fz' (id = Fahrzeug), 'neu-komp' (id = Komponente), 'aendern' (id = Zähler) */
  function zaehlerFormular(modus, id) {
    var laden;
    if (modus === 'neu-fz') laden = daten.fahrzeugLaden(id).then(function (f) { return f ? { fahrzeugId: id, komponenteId: null, fz: f.aktuell, komp: null, zurueck: '#/fahrzeug/' + encodeURIComponent(id) } : null; });
    else if (modus === 'neu-komp') laden = daten.komponenteLaden(id).then(function (c) { return c ? { fahrzeugId: c.fahrzeug.id, komponenteId: id, fz: c.fahrzeugAktuell, komp: { komponente: c.komponente, aktuell: c.aktuell }, zurueck: '#/komponente/' + encodeURIComponent(id) } : null; });
    else laden = daten.zaehlerLaden(id).then(function (z) { return z ? { fahrzeugId: z.fahrzeug.id, komponenteId: z.komponente ? z.komponente.id : null, fz: z.fahrzeugAktuell, komp: z.komponente ? { komponente: z.komponente, aktuell: z.komponenteAktuell } : null, zurueck: '#/zaehler/' + encodeURIComponent(id), z: z } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var neu = modus !== 'aendern';
      var titel = neu ? 'Zähler hinzufügen' : 'Zähler umbenennen';
      var weg = ortKrumen(k.fz, k.fahrzeugId, k.komp);
      if (!neu) weg.push([k.z.bezeichnung, k.zurueck]);
      weg.push([titel]);
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: k.zurueck,
        werte: neu ? { art: null, bezeichnung: '', startStand: '' } : { bezeichnung: k.z.bezeichnung },
        neuzeichnenBei: ['art'],
        nachAenderung: function (key, z) {
          if (key !== 'art') return;
          var a = MM.Fristen.zaehlerArt(z.werte.art);
          var istStandard = MM.Fristen.ZAEHLERARTEN.some(function (x) { return x.standard === z.werte.bezeichnung; });
          if (a && (!String(z.werte.bezeichnung || '').trim() || istStandard)) z.werte.bezeichnung = a.standard;
        },
        intro: neu ? h('p', { text: 'Ein Zähler zählt Strecke oder Betriebsstunden. Er kann am Fahrzeug oder an einer einzelnen Komponente hängen, zum Beispiel pro Motor.' }) : null,
        gruppen: function (z) {
          var g = [];
          var felder = [];
          if (neu) felder.push({ key: 'art', label: 'Was wird gezählt?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Fristen.ZAEHLERARTEN });
          var a = MM.Fristen.zaehlerArt(z.werte.art);
          if (!neu || a) {
            felder.push({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Zum Beispiel „Kilometerstand“ oder „Betriebsstunden Motor Backbord“' });
            if (neu) felder.push({ key: 'startStand', label: 'Aktueller Stand (kann leer bleiben)', typ: 'zahl', einheit: a.einheit });
          }
          g.push({ titel: null, felder: felder });
          return g;
        },
        speichern: function (w) {
          if (!neu) return daten.zaehlerAendern(id, w);
          return daten.zaehlerAnlegen(k.fahrzeugId, k.komponenteId, w.art, w).then(function (r) {
            if (!r.ok) return r;
            if (String(w.startStand || '').trim() === '') return r;
            return daten.zaehlerStandEintragen(r.id, { wert: w.startStand }).then(function (s) {
              r.standFehler = s.ok ? null : s.fehler.wert || s.fehler.datum || 'Der Stand konnte nicht eingetragen werden.';
              return r;
            });
          });
        },
        meldung: function (r) { return neu ? (r.standFehler ? 'Zähler angelegt. Der Stand fehlt noch: ' + r.standFehler : 'Zähler angelegt.') : (r.geaendert ? 'Gespeichert. Der frühere Name bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/zaehler/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Formular: neuer Zählerstand ---------- */
  function standFormular(id) {
    return daten.zaehlerLaden(id).then(function (z) {
      if (!z) return nichtGefunden('Zähler nicht gefunden');
      var weg = ortKrumen(z.fahrzeugAktuell, z.fahrzeug.id, z.komponente ? { komponente: z.komponente, aktuell: z.komponenteAktuell } : null);
      weg.push([z.bezeichnung, '#/zaehler/' + encodeURIComponent(id)]); weg.push(['Neuen Stand eintragen']);
      einfachFormular({
        titel: 'Neuen Stand eintragen', krumen: krumen(weg), zurueck: '#/zaehler/' + encodeURIComponent(id),
        werte: { wert: '', datum: daten.heute(), notiz: '' },
        intro: z.stand ? h('p', { text: 'Letzter Stand: ' + zahlMit(z.stand.wert, z.einheit) + ' am ' + MM.Hilfen.datum(z.stand.datum) + '.' }) : null,
        gruppen: function () {
          return [{ titel: null, felder: [
            { key: 'wert', label: 'Zählerstand', typ: 'zahl', einheit: z.einheit },
            { key: 'datum', label: 'Abgelesen am', typ: 'datum' },
            { key: 'notiz', label: 'Notiz', typ: 'text', hilfe: 'Zum Beispiel „nach dem Tanken“' }] }];
        },
        speichern: function (w) { return daten.zaehlerStandEintragen(id, w).then(function (r) { r.id = id; return r; }); },
        meldung: function () { return 'Zählerstand eingetragen.'; },
        danach: function () { return '#/zaehler/' + encodeURIComponent(id); }
      });
    });
  }

  /* ---------- Dokumente: gemeinsame Bausteine ---------- */
  function dokInfo(w) {
    return w.quelle === 'link' ? 'Link' : 'Datei, ' + MM.Hilfen.groesse(w.dateiGroesse);
  }

  function dokZeile(x, mitBesitzer) {
    var w = x.aktuell.werte;
    return h('li', null, h('a', { class: 'frist dok', href: '#/dokument/' + encodeURIComponent(x.dokument.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: w.bezeichnung }),
        h('span', { class: 'frist-info', text: dokInfo(w) }),
        mitBesitzer && x.besitzer ? h('span', { class: 'frist-info', text: 'an: ' + x.besitzer }) : null,
        mitBesitzer && x.vorgangName ? h('span', { class: 'frist-info', text: 'am Vorgang: ' + x.vorgangName }) : null),
      h('span', { class: 'chip-status', text: MM.Dokumente.artLabel(w.art) })));
  }

  /* Dokumente eines Fahrzeugs oder einer Komponente. gesamt: Link zur Gesamtliste (nur beim Fahrzeug). */
  function dokumenteBereich(liste, neuHash, gesamt) {
    return h('section', { class: 'bereich', 'aria-label': 'Dokumente' },
      h('h2', { text: 'Dokumente' }),
      liste.length ? h('ul', { class: 'fristen' }, liste.map(function (x) { return dokZeile(x, false); }))
        : h('p', { class: 'leer-text', text: 'Noch kein Dokument. Lege zum Beispiel eine Bedienungsanleitung oder Ersatzteilliste ab, als Datei oder als Link.' }),
      gesamt && gesamt.anzahl > liste.length ? h('p', null, h('a', { href: gesamt.href, text: 'Alle Dokumente ansehen (' + gesamt.anzahl + '), auch die der Komponenten und Vorgänge' })) : null,
      h('a', { class: 'knopf leise', href: neuHash + '/dokument/neu', text: 'Dokument hinzufügen' }));
  }

  /* Datei öffnen oder auf dem Gerät speichern. statusEl zeigt bei Bedarf einen Ersatz-Link. */
  function dateiOeffnen(lade, speichern, statusEl) {
    return lade().then(function (d) {
      if (!d) { statusEl.textContent = 'Die Datei wurde nicht gefunden.'; return; }
      var url = global.URL.createObjectURL(d.inhalt);
      statusEl.textContent = '';
      if (speichern) {
        var a = doc.createElement('a');
        a.href = url; a.download = d.name;
        doc.body.appendChild(a); a.click(); a.remove();
      } else {
        var w = global.open(url, '_blank');
        if (!w) statusEl.appendChild(h('a', { href: url, target: '_blank', rel: 'noopener', text: 'Tippe hier, um die Datei zu öffnen' }));
      }
      global.setTimeout(function () { global.URL.revokeObjectURL(url); }, 10 * 60 * 1000);
    }).catch(function (err) { statusEl.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler'); });
  }

  /* ---------- Seite: Dokument ---------- */
  function seiteDokument(id) {
    return daten.dokumentLaden(id).then(function (d) {
      if (!d) return nichtGefunden('Dokument nicht gefunden');
      var w = d.aktuell.werte;
      var besitzer = d.komponente ? d.komponenteAktuell.werte.bezeichnung : d.fahrzeugAktuell.werte.bezeichnung;
      var zurueck = d.komponente ? '#/komponente/' + encodeURIComponent(d.komponente.id) : '#/fahrzeug/' + encodeURIComponent(d.fahrzeug.id);
      var vorgangName = d.vorgangAktuell ? d.vorgangAktuell.werte.bezeichnung : null;
      if (d.vorgang) zurueck = '#/vorgang/' + encodeURIComponent(d.vorgang.id);
      var status = h('p', { class: 'oeffnen-status', role: 'status' });
      var vorschau = h('div', { class: 'vorschau' });
      var istBild = d.datei && /^image\//.test(d.datei.mime || '');
      if (istBild) {
        daten.dateiHolen(id).then(function (x) {
          if (!x) return;
          var url = global.URL.createObjectURL(x.inhalt);
          vorschau.appendChild(h('img', { src: url, alt: w.bezeichnung, class: 'vorschau-bild' }));
        });
      }
      var knoepfe = w.quelle === 'link'
        ? h('p', null, h('a', { class: 'knopf', href: w.link, target: '_blank', rel: 'noopener noreferrer', text: 'Link öffnen' }))
        : h('p', { class: 'knopfzeile' },
          h('button', { class: 'knopf', type: 'button', text: 'Öffnen', onclick: function () { dateiOeffnen(function () { return daten.dateiHolen(id); }, false, status); } }),
          h('button', { class: 'knopf leise', type: 'button', text: 'Auf dem Gerät speichern', onclick: function () { dateiOeffnen(function () { return daten.dateiHolen(id); }, true, status); } }));

      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: MM.Dokumente.artLabel(w.art) + (d.vorgang ? ' am Vorgang: ' + vorgangName : ' an: ' + besitzer) }),
        h('h1', { text: w.bezeichnung }),
        h('dl', { class: 'daten' },
          d.vorgang ? [h('dt', { text: 'Vorgang' }), h('dd', null, h('a', { href: zurueck, text: vorgangName })), h('dt', { text: 'An' }), h('dd', { text: besitzer })] : null,
          w.quelle === 'link' ? [h('dt', { text: 'Link' }), h('dd', { text: w.link })] : [
            h('dt', { text: 'Datei' }), h('dd', { text: (w.dateiName || '') + ' (' + MM.Hilfen.groesse(w.dateiGroesse) + ')' }),
            h('dt', { text: 'Gespeichert' }), h('dd', { text: 'auf diesem Gerät, auch ohne Internet' })],
          w.notiz ? [h('dt', { text: 'Notiz' }), h('dd', { text: w.notiz })] : null),
        vorschau, knoepfe, status,
        h('p', { class: 'stand', text: 'Abgelegt am ' + MM.Hilfen.zeitpunkt(d.dokument.erstelltAm) }),
        h('p', null, h('a', { class: 'knopf leise', href: '#/dokument/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));

      seite(w.bezeichnung, [
        krumen(ortKrumen(d.fahrzeugAktuell, d.fahrzeug.id, d.komponente ? { komponente: d.komponente, aktuell: d.komponenteAktuell } : null).concat(d.vorgang ? [[vorgangName, zurueck], [w.bezeichnung]] : [[w.bezeichnung]])),
        kopf, d.verlauf.length > 1 ? verlaufBlock(d.verlauf) : null
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' })));
    });
  }

  /* ---------- Seite: alle Dokumente eines Fahrzeugs ---------- */
  function seiteDokumente(fahrzeugId) {
    return Promise.all([daten.fahrzeugLaden(fahrzeugId), daten.dokumenteListe(fahrzeugId)]).then(function (r) {
      var f = r[0], liste = r[1];
      if (!f) return nichtGefunden('Fahrzeug nicht gefunden');
      var fzName = f.aktuell.werte.bezeichnung;
      var behaelter = h('div', { class: 'dok-gruppen' });
      var suche = h('input', { type: 'search', class: 'suche', placeholder: 'Suchen, zum Beispiel „Heizung“ oder „Ersatzteil“', 'aria-label': 'Dokumente suchen', autocomplete: 'off' });

      function zeichne() {
        var q = suche.value.trim().toLowerCase();
        behaelter.textContent = '';
        var treffer = liste.filter(function (x) {
          if (!q) return true;
          var w = x.aktuell.werte;
          return [w.bezeichnung, MM.Dokumente.artLabel(w.art), x.besitzer || fzName, x.vorgangName || '', w.notiz || ''].join(' ').toLowerCase().indexOf(q) >= 0;
        });
        if (!treffer.length) {
          behaelter.appendChild(h('p', { class: 'leer-text', text: liste.length ? 'Nichts gefunden.' : 'Noch kein Dokument. Du kannst es am Fahrzeug, an jeder Komponente oder an einem Vorgang in der Werkstatt ablegen.' }));
          return;
        }
        var gruppen = [], zuletzt;
        treffer.forEach(function (x) {
          var key = x.komponenteId || '';
          if (key !== zuletzt) { gruppen.push({ key: key, name: x.besitzer || fzName, eintraege: [] }); zuletzt = key; }
          gruppen[gruppen.length - 1].eintraege.push(x);
        });
        gruppen.forEach(function (g) {
          var ziel = g.key ? '#/komponente/' + encodeURIComponent(g.key) : '#/fahrzeug/' + encodeURIComponent(fahrzeugId);
          behaelter.appendChild(h('section', { class: 'bereich' },
            h('h2', null, h('a', { href: ziel, text: g.name })),
            h('ul', { class: 'fristen' }, g.eintraege.map(function (x) { return dokZeile(x, false); }))));
        });
      }
      suche.addEventListener('input', zeichne);
      zeichne();

      seite('Dokumente', [
        krumen(WEG_FAHRZEUGE.concat([[fzName, '#/fahrzeug/' + encodeURIComponent(fahrzeugId)], ['Dokumente']])),
        h('h1', { text: 'Dokumente' }),
        h('p', { class: 'gehoert', text: 'Alle Dokumente von ' + fzName + ' und seinen Komponenten (' + liste.length + ')' }),
        liste.length > 3 ? suche : null,
        behaelter
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/fahrzeug/' + encodeURIComponent(fahrzeugId), text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(fahrzeugId) + '/dokument/neu', text: 'Dokument hinzufügen' })));
    });
  }

  /* ---------- Formular: Dokument ablegen / ändern ---------- */
  /* modus: 'neu-fz' (id = Fahrzeug), 'neu-komp' (id = Komponente), 'neu-vorg' (id = Vorgang, seit 2.0.26), 'aendern' (id = Dokument) */
  function dokumentFormular(modus, id) {
    var laden;
    if (modus === 'neu-fz') laden = daten.fahrzeugLaden(id).then(function (f) { return f ? { fahrzeugId: id, komponenteId: null, fz: f.aktuell, komp: null, zurueck: '#/fahrzeug/' + encodeURIComponent(id) } : null; });
    else if (modus === 'neu-komp') laden = daten.komponenteLaden(id).then(function (c) { return c ? { fahrzeugId: c.fahrzeug.id, komponenteId: id, fz: c.fahrzeugAktuell, komp: { komponente: c.komponente, aktuell: c.aktuell }, zurueck: '#/komponente/' + encodeURIComponent(id) } : null; });
    else if (modus === 'neu-kosten') laden = daten.kostenLaden(id).then(function (kk) {
      return kk ? { fahrzeugId: kk.fahrzeug.id, komponenteId: null, kostenId: id, kostenName: kk.aktuell.werte.bezeichnung, fz: kk.fahrzeugAktuell, komp: null, zurueck: '#/kosten/' + encodeURIComponent(id) } : null;
    });
    else if (modus === 'neu-vorg') laden = daten.vorgangLaden(id).then(function (v) {
      return v ? { fahrzeugId: v.fahrzeug.id, komponenteId: v.komponente ? v.komponente.id : null, vorgangId: id, vorgangName: v.aktuell.werte.bezeichnung, fz: v.fahrzeugAktuell,
        komp: v.komponente ? { komponente: v.komponente, aktuell: v.komponenteAktuell } : null, zurueck: '#/vorgang/' + encodeURIComponent(id) } : null;
    });
    else laden = daten.dokumentLaden(id).then(function (d) { return d ? { fahrzeugId: d.fahrzeug.id, komponenteId: d.komponente ? d.komponente.id : null, fz: d.fahrzeugAktuell, komp: d.komponente ? { komponente: d.komponente, aktuell: d.komponenteAktuell } : null, zurueck: '#/dokument/' + encodeURIComponent(id), d: d } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var neu = modus !== 'aendern';
      var titel = neu ? 'Dokument hinzufügen' : 'Dokument ändern';
      var weg = ortKrumen(k.fz, k.fahrzeugId, k.komp);
      if (k.vorgangId) weg.push([k.vorgangName, k.zurueck]);
      if (k.kostenId) weg.push([k.kostenName, k.zurueck]);
      if (!neu) weg.push([k.d.aktuell.werte.bezeichnung, k.zurueck]);
      weg.push([titel]);
      var start = neu ? { quelle: 'datei', art: k.vorgangId || k.kostenId ? 'foto' : 'bedienung', bezeichnung: '', notiz: '' } : JSON.parse(JSON.stringify(k.d.aktuell.werte));
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: k.zurueck, werte: start, neuzeichnenBei: ['quelle', 'datei'],
        nachAenderung: function (key, z) {
          if (key === 'datei' && z.werte.datei && !String(z.werte.bezeichnung || '').trim()) z.werte.bezeichnung = String(z.werte.datei.name).replace(/\.[^.]+$/, '');
        },
        intro: neu && k.kostenId ? h('p', { text: 'Lege ein Foto oder einen Beleg zu diesem Posten ab, zum Beispiel die Quittung oder ein Bild vom gekauften Stück. Die Datei bleibt auf dem Gerät und ist auch ohne Internet da.' })
          : neu && k.vorgangId ? h('p', { text: 'Lege ein Bild oder einen Beleg zu diesem Vorgang ab, zum Beispiel ein Foto vom Schaden, die Rechnung der Werkstatt oder eine Seite aus dem Reparaturbuch. Die Datei bleibt auf dem Gerät und ist auch ohne Internet da. Oder speichere einen Link.' })
          : neu ? h('p', { text: 'Lege eine Datei von diesem Gerät ab, zum Beispiel ein PDF oder Foto. Sie bleibt auf dem Gerät und ist auch ohne Internet da. Oder speichere den Link zu einer Anleitung im Internet.' })
          : h('p', { text: k.d.aktuell.werte.quelle === 'datei' ? 'Die Datei selbst bleibt unverändert. Für eine andere Datei lege ein neues Dokument an.' : 'Hier kannst du Angaben und Link ändern.' }),
        gruppen: function (z) {
          var felder = [];
          if (neu) {
            felder.push({ key: 'quelle', label: 'Was möchtest du ablegen?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Dokumente.QUELLEN });
            if (z.werte.quelle === 'datei') felder.push({ key: 'datei', label: 'Datei', typ: 'datei', hilfe: 'Tippe auf „Datei auswählen“ und suche sie auf dem Gerät.' });
          }
          var quelle = neu ? z.werte.quelle : k.d.aktuell.werte.quelle;
          felder.push({ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text',
            hilfe: quelle === 'datei' && neu ? 'Zum Beispiel „Heizung Bedienungsanleitung“. Bleibt das Feld leer, nimmt die App den Dateinamen.' : 'Zum Beispiel „Heizung Bedienungsanleitung“' });
          MM.Dokumente.felder(quelle).forEach(function (f) { felder.push(f); });
          return [{ titel: null, felder: felder }];
        },
        speichern: function (w) { return neu ? daten.dokumentAnlegen(k.fahrzeugId, k.komponenteId, w, k.vorgangId || null, k.kostenId || null) : daten.dokumentAendern(id, w); },
        meldung: function (r) { return neu ? 'Dokument abgelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/dokument/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Nachweise: gemeinsame Bausteine ---------- */
  var NW_STATUS = { abgelaufen: 'Abgelaufen', bald: 'Läuft bald ab', gueltig: 'Gültig', unbefristet: 'Ohne Ablauf', unbekannt: 'Datum fehlt' };
  var NW_KLASSE = { abgelaufen: 'status-ueberfaellig', bald: 'status-bald', gueltig: 'status-ok', unbekannt: 'status-unbekannt', unbefristet: '' };

  function nachweisHinweis(u) {
    if (!u) return null;
    if (u.abgelaufen) return h('span', { class: 'hinweis-frist status-ueberfaellig', text: u.abgelaufen === 1 ? '1 Nachweis abgelaufen' : u.abgelaufen + ' Nachweise abgelaufen' });
    if (u.bald) return h('span', { class: 'hinweis-frist status-bald', text: u.bald === 1 ? '1 Nachweis läuft bald ab' : u.bald + ' Nachweise laufen bald ab' });
    return null;
  }

  function nachweisZeile(x) {
    var w = x.aktuell.werte, a = x.art.aktuell.werte, st = x.status;
    var teile = [];
    if (w.nummer) teile.push('Nr. ' + w.nummer);
    if (st.status !== 'unbefristet' && w.gueltigBis) teile.push('gültig bis ' + MM.Hilfen.datum(w.gueltigBis));
    if (w.klassen) teile.push(w.klassen);
    return h('li', null, h('a', { class: 'frist nw ' + NW_KLASSE[st.status], href: '#/nachweis/' + encodeURIComponent(x.nachweis.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: a.bezeichnung }),
        teile.length ? h('span', { class: 'frist-info', text: teile.join(', ') }) : null),
      h('span', { class: 'chip-status ' + NW_KLASSE[st.status], text: NW_STATUS[st.status] })));
  }

  function nachweiseBereich(liste, neuHash) {
    return h('section', { class: 'bereich', 'aria-label': 'Nachweise' },
      h('h2', { text: 'Nachweise' }),
      liste.length ? h('ul', { class: 'fristen' }, liste.map(nachweisZeile))
        : h('p', { class: 'leer-text', text: 'Noch kein Nachweis. Zum Beispiel Führerschein, Ausweis, Heimtierausweis oder Zulassungsbescheinigung.' }),
      h('a', { class: 'knopf leise', href: neuHash + '/nachweis/neu', text: 'Nachweis hinzufügen' }));
  }

  /* ---------- Personen und Tiere ---------- */
  var BESITZER = {
    person: {
      liste: '#/personen', einzel: '#/person/', krumen: 'Personen', schale: 'Person', titelNeu: 'Person hinzufügen', titelAendern: 'Person ändern',
      felder: function () { return MM.Personen.personFelder(); }, laden: function (id) { return daten.personLaden(id); },
      alle: function () { return daten.personenListe(); }, anlegen: function (w) { return daten.personAnlegen(w); }, aendern: function (id, w) { return daten.personAendern(id, w); },
      leer: 'Noch keine Person. Lege die Besatzung an, die du mitnimmst. Für Skipper und Fahrer zählen später die Nachweise.',
      info: function (w) { return w.funktionen && w.funktionen.length ? w.funktionen.join(', ') : 'noch keine Funktion'; },
      intro: 'Name und Funktionen genügen. Geburtsdatum und Wohnort gehören zu den Nachweisen, nicht zur Person, und bleiben auf dem Gerät.'
    },
    tier: {
      liste: '#/tiere', einzel: '#/tier/', krumen: 'Tiere', schale: 'Tier', titelNeu: 'Tier hinzufügen', titelAendern: 'Tier ändern',
      felder: function () { return MM.Personen.tierFelder(); }, laden: function (id) { return daten.tierLaden(id); },
      alle: function () { return daten.tiereListe(); }, anlegen: function (w) { return daten.tierAnlegen(w); }, aendern: function (id, w) { return daten.tierAendern(id, w); },
      leer: 'Noch kein Tier. Lege die Tiere an, die mitreisen. Heimtierausweis und Impfungen kommen als Nachweise dazu.',
      info: function (w) { return [w.tierart, w.chipnummer ? 'Chip ' + w.chipnummer : null].filter(Boolean).join(', '); },
      intro: 'Name und Tierart genügen. Heimtierausweis und Impfungen legst du danach als Nachweise an.'
    }
  };

  function seiteBesitzerListe(typ) {
    var c = BESITZER[typ];
    return Promise.all([c.alle(), daten.nachweisUebersicht()]).then(function (r) {
      var liste = r[0], u = r[1];
      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], [c.krumen]]), h('h1', { text: c.krumen })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: c.leer })));
      else inhalt.push(h('ul', { class: 'liste' }, liste.map(function (x) {
        return h('li', null, h('a', { class: 'zeile welt-' + (typ === 'person' ? 'wasser' : 'land'), href: c.einzel + encodeURIComponent(x.objekt.id) },
          h('span', { class: 'zeile-text' },
            h('strong', { class: 'zeile-name', text: x.aktuell.werte.bezeichnung }),
            h('span', { class: 'zeile-art', text: c.info(x.aktuell.werte) }),
            nachweisHinweis(u[x.objekt.id]))));
      })));
      seite(c.krumen, inhalt, h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
        h('a', { class: 'knopf', href: c.liste + '/neu', text: c.titelNeu })));
    });
  }

  function seiteBesitzer(typ, id) {
    var c = BESITZER[typ];
    return Promise.all([c.laden(id), daten.nachweiseListe(typ, id)]).then(function (r) {
      var x = r[0], nachweise = r[1];
      if (!x) return nichtGefunden(c.schale + ' nicht gefunden');
      var w = x.aktuell.werte;
      var dl = [];
      c.felder().forEach(function (f) {
        var t = MM.Hilfen.wert(f, w[f.key]);
        if (t !== null) dl.push([h('dt', { text: f.label }), h('dd', { text: t })]);
      });
      var karte = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: c.schale }),
        h('h1', { text: w.bezeichnung }),
        dl.length ? h('dl', { class: 'daten' }, dl) : h('p', { class: 'leer-text', text: 'Noch keine weiteren Angaben.' }),
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(x.aktuell.erstelltAm) + ', per Handeingabe' }),
        h('p', null, h('a', { class: 'knopf leise', href: c.einzel + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
      seite(w.bezeichnung, [
        krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], [c.krumen, c.liste], [w.bezeichnung]]),
        karte, nachweiseBereich(nachweise, c.einzel + encodeURIComponent(id)), x.verlauf.length > 1 ? verlaufBlock(x.verlauf) : null
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: c.liste, text: 'Zur Liste' }),
        h('a', { class: 'knopf', href: c.einzel + encodeURIComponent(id) + '/nachweis/neu', text: 'Nachweis hinzufügen' })));
    });
  }

  function besitzerFormular(typ, modus, id) {
    var c = BESITZER[typ];
    var laden = modus === 'aendern' ? c.laden(id) : Promise.resolve({ aktuell: { werte: { bezeichnung: '', funktionen: [] } } });
    return laden.then(function (x) {
      if (!x) return nichtGefunden(c.schale + ' nicht gefunden');
      var neu = modus === 'neu';
      var titel = neu ? c.titelNeu : c.titelAendern;
      var weg = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], [c.krumen, c.liste]];
      if (!neu) weg.push([x.aktuell.werte.bezeichnung, c.einzel + encodeURIComponent(id)]);
      weg.push([titel]);
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: neu ? c.liste : c.einzel + encodeURIComponent(id),
        werte: JSON.parse(JSON.stringify(x.aktuell.werte)),
        intro: neu ? h('p', { text: c.intro }) : null,
        gruppen: function () { return [{ titel: null, felder: [{ key: 'bezeichnung', label: 'Name', typ: 'text' }].concat(c.felder()) }]; },
        speichern: function (w) { return neu ? c.anlegen(w) : c.aendern(id, w); },
        meldung: function (r) { return neu ? c.schale + ' angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return c.einzel + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Seite: Nachweis ---------- */
  var BESITZER_HASH = { person: '#/person/', tier: '#/tier/', fahrzeug: '#/fahrzeug/' };
  function besitzerKrumen(typ, id, name) {
    if (typ === 'fahrzeug') return WEG_FAHRZEUGE.concat([[name, '#/fahrzeug/' + encodeURIComponent(id)]]);
    var c = BESITZER[typ];
    return [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], [c.krumen, c.liste], [name, c.einzel + encodeURIComponent(id)]];
  }

  function seiteNachweis(id) {
    return daten.nachweisLaden(id).then(function (n) {
      if (!n) return nichtGefunden('Nachweis nicht gefunden');
      var aw = n.art.aktuell.werte, w = n.aktuell.werte, st = n.status;
      var zurueck = BESITZER_HASH[n.nachweis.besitzerTyp] + encodeURIComponent(n.nachweis.besitzerId);
      var gefuellt = [], offen = [];
      n.felder.forEach(function (f) {
        var t = MM.Hilfen.wert(f, w[f.key]);
        if (t === null) { offen.push(f.label); return; }
        gefuellt.push([h('dt', null, f.label, f.papier ? h('span', { class: 'papier', text: ' (' + f.papier + ')' }) : null), h('dd', { text: t })]);
      });
      var status = h('p', { class: 'oeffnen-status', role: 'status' });
      var vorschau = h('div', { class: 'vorschau' });
      if (n.datei && /^image\//.test(n.datei.mime || '')) {
        daten.nachweisDateiHolen(id).then(function (x) {
          if (x) vorschau.appendChild(h('img', { src: global.URL.createObjectURL(x.inhalt), alt: 'Scan: ' + aw.bezeichnung, class: 'vorschau-bild' }));
        });
      }
      var dateiTeil = n.datei ? [
        h('section', { class: 'gruppe' }, h('h3', { text: 'Scan oder Foto' }),
          h('p', { text: n.datei.name + ' (' + MM.Hilfen.groesse(n.datei.groesse) + '). Bleibt nur auf diesem Gerät.' }),
          vorschau,
          h('p', { class: 'knopfzeile' },
            h('button', { class: 'knopf leise', type: 'button', text: 'Öffnen', onclick: function () { dateiOeffnen(function () { return daten.nachweisDateiHolen(id); }, false, status); } }),
            h('button', { class: 'knopf leise', type: 'button', text: 'Auf dem Gerät speichern', onclick: function () { dateiOeffnen(function () { return daten.nachweisDateiHolen(id); }, true, status); } })),
          status)] : null;

      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: MM.Nachweise.besitzerLabel(n.nachweis.besitzerTyp) + ': ' + n.besitzer.name }),
        h('h1', { text: aw.bezeichnung }),
        h('p', null, h('span', { class: 'chip-status gross ' + NW_KLASSE[st.status], text: NW_STATUS[st.status] }),
          st.status === 'bald' || st.status === 'gueltig' ? h('span', { class: 'frist-info', text: '  noch ' + st.tage + (st.tage === 1 ? ' Tag' : ' Tage') }) : null,
          st.status === 'abgelaufen' ? h('span', { class: 'frist-info', text: '  seit ' + (-st.tage) + (st.tage === -1 ? ' Tag' : ' Tagen') }) : null),
        gefuellt.length ? h('dl', { class: 'daten stapel' }, gefuellt) : h('p', { class: 'leer-text', text: 'Noch keine Angaben eingetragen.' }),
        offen.length ? h('p', { class: 'offen', text: 'Noch nicht angegeben: ' + offen.join(', ') }) : null,
        dateiTeil,
        h('p', { class: 'stand', text: 'Herkunft: per Handeingabe. Stand vom ' + MM.Hilfen.zeitpunkt(n.aktuell.erstelltAm) }),
        h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: '#/nachweis/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' }),
          h('a', { class: 'knopf leise', href: '#/nachweisart/' + encodeURIComponent(n.nachweis.artId), text: 'Zur Art' })));
      seite(aw.bezeichnung, [
        krumen(besitzerKrumen(n.nachweis.besitzerTyp, n.nachweis.besitzerId, n.besitzer.name).concat([[aw.bezeichnung]])),
        kopf, n.verlauf.length > 1 ? verlaufBlock(n.verlauf) : null
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/nachweis/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
    });
  }

  /* ---------- Formular: Nachweis anlegen / ändern ---------- */
  /* modus 'neu': typ = Besitzer (person, tier, fahrzeug), id = Besitzer. modus 'aendern': id = Nachweis. */
  function nachweisFormular(modus, typ, id) {
    var neu = modus === 'neu';
    var laden = neu
      ? Promise.all([daten.besitzerLaden(typ, id), daten.nachweisartenListe(typ)]).then(function (r) { return r[0] ? { besitzer: r[0], arten: r[1].filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja'; }), typ: typ, bid: id } : null; })
      : daten.nachweisLaden(id).then(function (n) { return n ? { n: n, besitzer: n.besitzer, typ: n.nachweis.besitzerTyp, bid: n.nachweis.besitzerId } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var titel = neu ? 'Nachweis hinzufügen' : 'Nachweis ändern';
      var zurueck = neu ? BESITZER_HASH[k.typ] + encodeURIComponent(k.bid) : '#/nachweis/' + encodeURIComponent(id);
      var weg = besitzerKrumen(k.typ, k.bid, k.besitzer.name);
      if (!neu) weg.push([k.n.art.aktuell.werte.bezeichnung, zurueck]);
      weg.push([titel]);

      function feldDef(f) {
        var d = { key: f.key, label: f.label, typ: f.typ };
        if (f.papier) d.hilfe = 'Steht auf dem Papier unter „' + f.papier + '“';
        return d;
      }
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: zurueck, neuzeichnenBei: neu ? ['artId'] : [],
        werte: neu ? { artId: '' } : JSON.parse(JSON.stringify(k.n.aktuell.werte)),
        intro: neu ? (k.arten.length ? h('p', { text: 'Wähle die Art des Nachweises. Dann erscheinen die passenden Angaben. Alle Angaben sind freiwillig.' })
          : h('div', { class: 'leer-hinweis' }, h('p', { text: 'Es gibt noch keine Art von Nachweis für ' + MM.Nachweise.besitzerLabel(k.typ) + '. Übernimm Vorschläge oder lege eine eigene Art an.' }),
            h('p', null, h('a', { class: 'knopf', href: '#/nachweisarten/vorschlaege', text: 'Vorschläge ansehen' })))) : null,
        gruppen: function (z) {
          var felder = [];
          var art;
          if (neu) {
            if (!k.arten.length) return [];
            felder.push({ key: 'artId', label: 'Art des Nachweises', typ: 'auswahl', leerText: '– bitte wählen –',
              optionen: k.arten.map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; }) });
            var gewaehlt = k.arten.filter(function (a) { return a.objekt.id === z.werte.artId; })[0];
            art = gewaehlt ? gewaehlt.aktuell.werte : null;
          } else {
            art = k.n.art.aktuell.werte;
          }
          if (art) {
            MM.Nachweise.felderFuer(art).forEach(function (f) { felder.push(feldDef(f)); });
            if (neu) felder.push({ key: 'datei', label: 'Scan oder Foto (freiwillig)', typ: 'datei', accept: 'image/*,application/pdf',
              hilfe: 'Zum Beispiel ein Foto des Dokuments. Es bleibt nur auf diesem Gerät.' });
          }
          return [{ titel: null, felder: felder }];
        },
        speichern: function (w) { return neu ? daten.nachweisAnlegen(k.typ, k.bid, w.artId, w) : daten.nachweisAendern(id, w); },
        meldung: function (r) { return neu ? 'Nachweis angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/nachweis/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Nachweisarten ---------- */
  var ARTEN_GRUPPEN = [['person', 'Für Personen'], ['tier', 'Für Tiere'], ['fahrzeug', 'Für Fahrzeuge']];
  var PRUEF_KLASSE = { geprueft: 'status-ok', teilweise: 'status-bald', offen: '' };

  function herkunftText(w) {
    if (w.herkunft === 'vorschlag') return 'Vorschlag, ' + (MM.NachweisVorschlaege.PRUEFSTATUS[w.pruefstatus] || '').toLowerCase();
    return 'von dir eingetragen';
  }

  function seiteNachweisarten() {
    return daten.nachweisartenListe().then(function (liste) {
      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Nachweisarten']]), h('h1', { text: 'Nachweisarten' }),
        h('p', { text: 'Die Liste ist offen. Du legst eigene Arten an oder übernimmst Vorschläge. Alles bleibt änderbar.' })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Noch keine Art. Übernimm Vorschläge für Deutschland und die EU oder lege eine eigene Art an.' })));
      ARTEN_GRUPPEN.forEach(function (g) {
        var teil = liste.filter(function (x) { return x.aktuell.werte.gehoertZu === g[0]; });
        if (!teil.length) return;
        inhalt.push(h('section', { class: 'bereich' }, h('h2', { text: g[1] }),
          h('ul', { class: 'fristen' }, teil.map(function (x) {
            var w = x.aktuell.werte;
            return h('li', null, h('a', { class: 'frist', href: '#/nachweisart/' + encodeURIComponent(x.objekt.id) },
              h('span', { class: 'frist-text' },
                h('strong', { class: 'frist-name', text: w.bezeichnung }),
                h('span', { class: 'frist-info', text: herkunftText(w) + ', ' + (x.anzahlNachweise === 1 ? '1 Nachweis' : x.anzahlNachweise + ' Nachweise') })),
              w.ausgeblendet === 'ja' ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : null));
          }))));
      });
      seite('Nachweisarten', inhalt, h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/nachweisarten/vorschlaege', text: 'Vorschläge' }),
        h('a', { class: 'knopf', href: '#/nachweisart/neu', text: 'Eigene Art anlegen' })));
    });
  }

  function seiteVorschlaege() {
    return daten.nachweisartenListe().then(function (liste) {
      var uebernommen = {};
      liste.forEach(function (x) { if (x.aktuell.werte.vorschlagId) uebernommen[x.aktuell.werte.vorschlagId] = x.objekt.id; });
      var alle = MM.NachweisVorschlaege.alle();

      function uebernehmen(ids) {
        return ids.reduce(function (kette, vid) {
          return kette.then(function () { return daten.nachweisartAusVorschlag(vid); });
        }, Promise.resolve()).then(function () {
          meldung = ids.length === 1 ? 'Art übernommen.' : ids.length + ' Arten übernommen.';
          return zeige();
        }).catch(fehlerSeite);
      }

      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Nachweisarten', '#/nachweisarten'], ['Vorschläge']]),
        h('h1', { text: 'Vorschläge' }),
        h('p', { text: 'Vorschläge für Deutschland und die EU. Du übernimmst, was du brauchst. Danach gehört die Art dir und lässt sich ändern. Jeder Vorschlag nennt seine Quelle und wie weit er geprüft ist.' })];
      ARTEN_GRUPPEN.forEach(function (g) {
        var teil = alle.filter(function (v) { return v.gehoertZu === g[0]; });
        var offen = teil.filter(function (v) { return !uebernommen[v.id]; });
        inhalt.push(h('section', { class: 'bereich' },
          h('h2', { text: g[1] }),
          offen.length > 1 ? h('p', null, h('button', { class: 'knopf leise', type: 'button', text: 'Alle ' + offen.length + ' übernehmen', onclick: function () { uebernehmen(offen.map(function (v) { return v.id; })); } })) : null,
          h('ul', { class: 'fristen' }, teil.map(function (v) {
            var da = uebernommen[v.id];
            return h('li', { class: 'vorschlag' },
              h('div', { class: 'vorschlag-kopf' },
                h('strong', { class: 'frist-name', text: v.name }),
                h('span', { class: 'chip-status ' + PRUEF_KLASSE[v.pruefstatus], text: MM.NachweisVorschlaege.PRUEFSTATUS[v.pruefstatus] })),
              h('p', { class: 'frist-info', text: v.land + (v.geprueftAm ? ', geprüft am ' + MM.Hilfen.datum(v.geprueftAm) : '') + (v.hatAblauf ? ', mit Ablaufdatum' : ', ohne Ablaufdatum') + ', ' + (v.felder.length ? v.felder.length + ' weitere Angaben' : 'nur die allgemeinen Angaben') }),
              h('details', { class: 'vorschlag-mehr' },
                h('summary', { text: 'Hinweis und Quelle' }),
                v.hinweis ? h('p', { text: v.hinweis }) : null,
                v.quelle ? h('p', null, 'Quelle: ', h('a', { href: v.quelle.url, target: '_blank', rel: 'noopener noreferrer', text: v.quelle.titel })) : h('p', { text: 'Quelle: noch keine geprüfte Quelle.' }),
                v.felder.length ? h('p', { class: 'frist-info', text: 'Angaben: ' + v.felder.map(function (f) { return f.label + (f.papier ? ' (' + f.papier + ')' : ''); }).join('; ') }) : null),
              da ? h('p', null, 'Schon übernommen. ', h('a', { href: '#/nachweisart/' + encodeURIComponent(da), text: 'Zur Art' }))
                : h('p', null, h('button', { class: 'knopf', type: 'button', text: 'Übernehmen', onclick: function () { uebernehmen([v.id]); } })));
          }))));
      });
      seite('Vorschläge', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/nachweisarten', text: 'Zurück' })));
    });
  }

  function seiteNachweisart(id) {
    return daten.nachweisartLaden(id).then(function (x) {
      if (!x) return nichtGefunden('Art nicht gefunden');
      var w = x.werte;
      var felderListe = MM.Nachweise.felderFuer(w);
      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Art von Nachweis, ' + MM.Nachweise.besitzerLabel(w.gehoertZu) }),
        h('h1', { text: w.bezeichnung }),
        w.ausgeblendet === 'ja' ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Ausgeblendet: Für neue Nachweise nicht mehr auswählbar. Vorhandene Nachweise bleiben.' }) : null,
        h('dl', { class: 'daten' },
          h('dt', { text: 'Herkunft' }), h('dd', { text: herkunftText(w) }),
          h('dt', { text: 'Ablaufdatum' }), h('dd', { text: MM.Nachweise.hatAblauf(w) ? 'ja' : 'nein' }),
          w.land ? [h('dt', { text: 'Land' }), h('dd', { text: w.land })] : null,
          h('dt', { text: 'Nachweise' }), h('dd', { text: String(x.anzahlNachweise) })),
        w.beschreibung ? h('p', { class: 'hinweis', text: w.beschreibung }) : null,
        h('section', { class: 'gruppe' }, h('h3', { text: 'Angaben je Nachweis' }),
          h('ul', { class: 'angaben' }, felderListe.map(function (f) { return h('li', { text: f.label + (f.papier ? ' (Papier: ' + f.papier + ')' : '') }); }))),
        w.herkunft === 'vorschlag' ? h('section', { class: 'gruppe' }, h('h3', { text: 'Quelle' }),
          w.quelleUrl ? h('p', null, h('a', { href: w.quelleUrl, target: '_blank', rel: 'noopener noreferrer', text: w.quelleTitel || w.quelleUrl })) : h('p', { text: 'Noch keine geprüfte Quelle.' }),
          h('p', { class: 'hinweis', text: (MM.NachweisVorschlaege.PRUEFSTATUS[w.pruefstatus] || '') + (w.geprueftAm ? ', geprüft am ' + MM.Hilfen.datum(w.geprueftAm) : '') })) : null,
        h('p', null, h('a', { class: 'knopf leise', href: '#/nachweisart/' + encodeURIComponent(id) + '/aendern', text: 'Art ändern' })));
      seite(w.bezeichnung, [
        krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Nachweisarten', '#/nachweisarten'], [w.bezeichnung]]),
        kopf, x.verlauf.length > 1 ? verlaufBlock(x.verlauf) : null
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/nachweisarten', text: 'Zur Liste' }),
        h('a', { class: 'knopf', href: '#/nachweisart/' + encodeURIComponent(id) + '/aendern', text: 'Art ändern' })));
    });
  }

  function nachweisartFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = neu ? Promise.resolve({ werte: { gehoertZu: 'person', hatAblauf: 'nein', felder: [] } }) : daten.nachweisartLaden(id);
    return laden.then(function (x) {
      if (!x) return nichtGefunden('Art nicht gefunden');
      var titel = neu ? 'Eigene Art anlegen' : 'Art ändern';
      var weg = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Nachweisarten', '#/nachweisarten']];
      if (!neu) weg.push([x.werte.bezeichnung, '#/nachweisart/' + encodeURIComponent(id)]);
      weg.push([titel]);
      var start = neu ? x.werte : { bezeichnung: x.werte.bezeichnung, hatAblauf: MM.Nachweise.hatAblauf(x.werte) ? 'ja' : 'nein', land: x.werte.land || '', beschreibung: x.werte.beschreibung || '',
        ausgeblendet: x.werte.ausgeblendet || 'nein', felder: JSON.parse(JSON.stringify(x.werte.felder || [])) };
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: neu ? '#/nachweisarten' : '#/nachweisart/' + encodeURIComponent(id), werte: start,
        intro: neu ? h('p', { text: 'Lege eine Art von Nachweis an, die es noch nicht gibt, zum Beispiel einen ausländischen Bootsführerschein. Jeder Nachweis hat immer Nummer, Aussteller, Ausstellungsdatum und Notiz. Hier legst du weitere Angaben fest.' })
          : h('p', { text: 'Du kannst die Art jederzeit ändern. Bereits eingetragene Angaben gehen dabei nicht verloren.' }),
        gruppen: function () {
          var felder = [{ key: 'bezeichnung', label: 'Name der Art', typ: 'text', hilfe: 'Zum Beispiel „Segelschein“ oder „Impfpass Pferd“' }];
          if (neu) felder.push({ key: 'gehoertZu', label: 'Wofür gilt der Nachweis?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Nachweise.BESITZER });
          felder.push({ key: 'hatAblauf', label: 'Hat der Nachweis ein Ablaufdatum?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Nachweise.JA_NEIN });
          felder.push({ key: 'land', label: 'Land', typ: 'text', hilfe: 'Freiwillig, zum Beispiel DE oder EU' });
          felder.push({ key: 'beschreibung', label: 'Beschreibung', typ: 'text', hilfe: 'Freiwillig' });
          if (!neu) felder.push({ key: 'ausgeblendet', label: 'Ausblenden?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Nein, auswählbar' }, { wert: 'ja', label: 'Ja, ausblenden' }],
            hilfe: 'Ausgeblendete Arten sind für neue Nachweise nicht mehr auswählbar. Vorhandene Nachweise bleiben.' });
          felder.push({ key: 'felder', label: 'Weitere Angaben', typ: 'zeilen', hilfe: 'Zum Beispiel „Geburtsdatum“ als Datum. Die Stelle auf dem Papier hilft später beim automatischen Einlesen.' });
          return [{ titel: null, felder: felder }];
        },
        speichern: function (w) { return neu ? daten.nachweisartAnlegen(w) : daten.nachweisartAendern(id, w); },
        meldung: function (r) { return neu ? 'Art angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/nachweisart/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Aktivitäten: gemeinsame Bausteine ---------- */
  var AK_STATUS = { laeuft: 'Läuft', geplant: 'Geplant', vorbei: 'Vorbei', storniert: 'Storniert' };
  var AK_KLASSE = { laeuft: 'status-ok', geplant: '', vorbei: '', storniert: 'status-ueberfaellig' };
  var ERG_KLASSE = { erlaubt: 'status-ok', nicht_erlaubt: 'status-ueberfaellig', unklar: 'status-bald' };
  var FRIST_ERG = { ueberfaellig: ['Überfällig', 'status-ueberfaellig'], faellig: ['Wird fällig', 'status-bald'], unbekannt: ['Angaben fehlen', 'status-unbekannt'], ok: ['In Ordnung', 'status-ok'] };

  function zeitText(datum, zeit) { return MM.Hilfen.datum(datum) + (zeit ? ', ' + zeit + ' Uhr' : ''); }
  function zeitraumText(w) { return zeitText(w.vonDatum, w.vonZeit) + ' bis ' + zeitText(w.bisDatum, w.bisZeit); }
  function jetztText(iso) { return MM.Hilfen.datum(iso.slice(0, 10)) + ', ' + iso.slice(11, 16) + ' Uhr'; }

  function seiteFunktionen() {
    seite('Funktionen', [
      krumen([['Hauptmenü', '#/auswahl'], ['Funktionen']]),
      h('h1', { text: 'Funktionen' }),
      h('div', { class: 'kacheln' },
        kachel('Aktivitäten', 'Urlaub, Törn, Ausfahrt und mehr planen', '#/aktivitaeten'),
        kachel('Reisecheck', 'Reise prüfen und Hinweise bekommen', '#/reisecheck'),
        kachel('Cockpit und Logbuch', 'Unterwegs festhalten: bei der Aktivität', '#/aktivitaeten'),
        kachel('Werkstatt', 'Störungen melden, Arbeiten planen und erledigen', '#/werkstatt'),
        kachel('Kassenbuch', 'Bargeld und Fremdwährung der Reisen, Kassensturz', '#/kassenbuch'),
        kachel('Kosten', 'Fixkosten, variable Kosten, Instandhaltung und Wertverlust', '#/kosten'))
    ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/auswahl', text: 'Zurück' })));
    return Promise.resolve();
  }

  /* ---------- Reisecheck (seit 2.0.38, Schritt 11) ---------- */
  var RC_KLASSE = { ok: 'status-ok', pruefen: 'status-bald', fehlt: 'status-ueberfaellig' };
  var RC_STATUS_KLASSE = { 'Erfüllt': 'status-ok', 'Prüfen': 'status-bald', 'Fehlt': 'status-ueberfaellig', 'Nicht relevant': '' };
  var RC_KATEGORIE_TITEL = { Pflicht: 'Pflicht', Wichtig: 'Wichtig', Empfohlen: 'Empfohlen', Hinweis: 'Hinweise' };

  function rcZeit(iso) {
    var d = new Date(iso);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return MM.Hilfen.datum(d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate())) + ', ' + z(d.getHours()) + ':' + z(d.getMinutes()) + ' Uhr';
  }
  function rcChip(gesamt) { return h('span', { class: 'chip-status ' + RC_KLASSE[gesamt], text: MM.Reisecheck.GESAMT_TEXT[gesamt] }); }
  function rcZaehlText(z) {
    var t = [];
    if (z.Fehlt) t.push(z.Fehlt + ' fehlt' + (z.Fehlt === 1 ? '' : 'en'));
    if (z['Prüfen']) t.push(z['Prüfen'] + ' zu prüfen');
    if (z['Erfüllt']) t.push(z['Erfüllt'] + ' erfüllt');
    if (z['Nicht relevant']) t.push(z['Nicht relevant'] + ' nicht relevant');
    return t.join(', ');
  }
  /* „P1“ und „A1“ stehen nur in der Anfrage. Auf dem Gerät zeigen wir die Namen. */
  function rcNamenEinsetzen(text, namen) {
    return String(text || '').replace(/\b([PA]\d{1,2})\b/g, function (m, k) { return namen && namen[k] ? namen[k] : m; });
  }

  function seiteReisecheck() {
    return Promise.all([daten.reisecheckUebersicht(), daten.reisecheckEinstellung()]).then(function (r) {
      var liste = r[0], e = r[1];
      var dienst = e.eingerichtet ? (e.zugestimmt ? 'Der Dienst ist eingerichtet und du hast zugestimmt.' : 'Der Dienst ist eingerichtet. Es fehlt noch deine Zustimmung.') : 'Der Dienst ist noch nicht eingerichtet.';
      seite('Reisecheck', [
        krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Reisecheck']]),
        h('h1', { text: 'Reisecheck' }),
        h('p', { text: 'Der Reisecheck fragt online nach, was für eine Reise nötig ist, zum Beispiel Papiere, Ausrüstung und Einreise, und vergleicht es mit deinen Nachweisen. Er ist eine Planungshilfe und keine rechtsgültige Auskunft. Die Verantwortung bleibt beim Skipper oder Fahrer.' }),
        h('section', { class: 'block' }, h('h2', { text: 'Dienst' }), h('p', { text: dienst }),
          h('p', null, h('a', { class: 'knopf leise', href: '#/reisecheck/dienst', text: e.eingerichtet ? 'Dienst ansehen' : 'Dienst einrichten' }))),
        h('section', { class: 'bereich', 'aria-label': 'Aktivitäten' }, h('h2', { text: 'Aktivität wählen' }),
          liste.length ? h('ul', { class: 'fristen' }, liste.map(function (x) {
            return h('li', null, h('a', { class: 'frist ' + (x.letzter ? RC_KLASSE[x.letzter.gesamt] : ''), href: '#/reisecheck/' + enc(x.id) },
              h('span', { class: 'frist-text' },
                h('strong', { class: 'frist-name', text: x.name }),
                h('span', { class: 'frist-info', text: x.fahrzeugName + ', ' + MM.Hilfen.datum(x.vonDatum) + ' bis ' + MM.Hilfen.datum(x.bisDatum) }),
                h('span', { class: 'frist-info', text: x.letzter ? 'Letzter Check: ' + rcZeit(x.letzter.erstelltAm) : 'Noch kein Check' })),
              x.letzter ? rcChip(x.letzter.gesamt) : null));
          })) : h('p', { class: 'leer-text', text: 'Es gibt noch keine Aktivität. Plane zuerst eine, dann kannst du sie prüfen.' }),
          h('p', null, h('a', { class: 'knopf leise', href: '#/aktivitaet/neu', text: 'Aktivität planen' })))
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/funktionen', text: 'Zurück' })));
    });
  }

  function seiteReisecheckDienst() {
    function zeige() {
      return daten.reisecheckEinstellung().then(function (e) {
        var fel = h('p', { class: 'fehler', role: 'alert' });
        var status = h('p', { class: 'hinweis', role: 'status' });
        var url = h('input', { type: 'url', id: 'rc-url', value: e.dienstUrl, autocomplete: 'off', inputmode: 'url', placeholder: 'https://…workers.dev' });
        var pw = h('input', { type: 'password', id: 'rc-pw', autocomplete: 'off', 'aria-describedby': 'rc-pw-hilfe' });
        var speichern = h('button', { class: 'knopf', type: 'button', text: 'Speichern' });
        var testen = h('button', { class: 'knopf leise', type: 'button', text: 'Verbindung testen' });
        var telPw = h('p', { class: 'fehler', role: 'alert' }), telUrl = h('p', { class: 'fehler', role: 'alert' });

        speichern.addEventListener('click', function () {
          fel.textContent = ''; telPw.textContent = ''; telUrl.textContent = ''; status.textContent = '';
          daten.reisecheckEinrichten({ dienstUrl: url.value, passwort: pw.value }).then(function (r) {
            if (!r.ok) { telUrl.textContent = r.fehler.dienstUrl || ''; telPw.textContent = r.fehler.passwort || ''; return; }
            meldungRc = r.zustimmungZurueck ? 'Gespeichert. Weil die Adresse eine andere ist, ist deine Zustimmung zurückgesetzt. Bitte stimme neu zu.' : 'Gespeichert.';
            return zeige();
          }).catch(fehlerSeite);
        });
        testen.addEventListener('click', function () {
          fel.textContent = ''; status.textContent = 'Die Verbindung wird geprüft …'; testen.disabled = true;
          daten.reisecheckVerbindung().then(function (r) {
            testen.disabled = false;
            if (r.ok) status.textContent = 'Der Dienst antwortet' + (r.modell ? ' (Modell: ' + r.modell + ')' : '') + '. Das Passwort wird erst beim ersten Check geprüft.';
            else { status.textContent = ''; fel.textContent = r.fehler; }
          }).catch(function () { testen.disabled = false; status.textContent = ''; fel.textContent = 'Der Dienst antwortet nicht.'; });
        });

        var zustimmung;
        if (e.zugestimmt) {
          zustimmung = [h('p', { class: 'meldung', text: 'Du hast am ' + rcZeit(e.zugestimmtAm) + ' zugestimmt.' }),
            h('p', null, h('button', { class: 'knopf leise', type: 'button', text: 'Zustimmung widerrufen', onclick: function () { daten.reisecheckWiderrufen().then(function () { meldungRc = 'Die Zustimmung ist widerrufen. Es gehen keine Angaben mehr hinaus.'; return zeige(); }).catch(fehlerSeite); } }))];
        } else {
          zustimmung = [e.zustimmungAlt ? h('p', { class: 'meldung', text: 'Der Text hat sich geändert. Bitte lies ihn noch einmal und stimme neu zu.' }) : null,
            h('p', null, h('button', { class: 'knopf', type: 'button', disabled: e.eingerichtet ? null : 'disabled', text: 'Ich stimme zu', onclick: function () { daten.reisecheckZustimmen().then(function (r) { meldungRc = r.ok ? 'Danke, die Zustimmung ist festgehalten.' : r.fehler.allgemein; return zeige(); }).catch(fehlerSeite); } })),
            e.eingerichtet ? null : h('p', { class: 'hinweis', text: 'Zuerst Adresse und Passwort speichern, dann kannst du zustimmen.' })];
        }
        var m = meldungRc; meldungRc = '';
        seite('Reisecheck: Dienst', [
          krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Reisecheck', '#/reisecheck'], ['Dienst']]),
          h('h1', { text: 'Dienst für den Reisecheck' }),
          m ? h('p', { class: 'meldung', role: 'status', text: m }) : null,
          h('section', { class: 'block' },
            h('h2', { text: 'Adresse und Passwort' }),
            h('p', { text: 'Die Recherche macht ein kleiner Dienst im Internet, der eine KI mit Internetsuche fragt. Hast du ihn schon für die alte Version eingerichtet, trage hier dieselbe Adresse und dasselbe Passwort ein. Beides bleibt nur auf diesem Gerät und kommt nicht in die Sicherung.' }),
            h('div', { class: 'formular' },
              h('div', { class: 'feld' }, h('label', { for: 'rc-url', text: 'Adresse des Dienstes' }), h('div', { class: 'eingabe' }, url), telUrl),
              h('div', { class: 'feld' }, h('label', { for: 'rc-pw', text: 'Passwort für den Dienst' }), h('div', { class: 'eingabe' }, pw),
                h('p', { class: 'hilfe', id: 'rc-pw-hilfe', text: e.hatPasswort ? 'Ein Passwort ist gespeichert. Lass das Feld leer, wenn es so bleiben soll.' : 'Das Passwort hast du beim Einrichten des Dienstes festgelegt.' }), telPw),
              fel, status,
              h('p', { class: 'knopfzeile' }, speichern, testen))),
          h('section', { class: 'block' },
            h('h2', { text: 'Zustimmung' }),
            h('p', { text: MM.Reisecheck.ZUSTIMMUNG_TEXT }),
            zustimmung),
          e.protokoll.length ? h('section', { class: 'bereich', 'aria-label': 'Protokoll der Zustimmungen' },
            h('h2', { text: 'Protokoll' }),
            h('ul', { class: 'status-zeilen' }, e.protokoll.slice(-6).reverse().map(function (p) {
              return h('li', { class: p.aktion === 'zugestimmt' ? 'status-ok' : 'status-bald', text: rcZeit(p.am) + ': ' + (p.aktion === 'zugestimmt' ? 'zugestimmt' : 'widerrufen') + (p.grund ? ' (' + p.grund + ')' : '') });
            }))) : null
        ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/reisecheck', text: 'Zurück' })));
      });
    }
    return zeige();
  }
  var meldungRc = '';

  function rcAnforderung(a, namen) {
    var wer = MM.Reisecheck.subjektName(namen, a.subjekt);
    return h('li', { class: 'rc-anf ' + RC_STATUS_KLASSE[a.status] },
      h('div', { class: 'rc-kopf' }, h('span', { class: 'chip-status ' + RC_STATUS_KLASSE[a.status], text: a.status }), ' ', h('strong', { text: a.bereich || a.subjektArt })),
      h('p', { class: 'rc-text', text: rcNamenEinsetzen(a.anforderung, namen) }),
      h('p', { class: 'frist-info', text: 'Betrifft: ' + wer + (a.verkehr ? ' · ' + a.verkehr : '') + ' · Sicherheit der Angabe: ' + a.vertrauen }),
      a.widerspruch ? h('p', { class: 'meldung', text: 'Die Quellen widersprechen sich. Bitte selbst nachprüfen.' }) : null,
      a.beleg ? h('p', { class: 'hinweis', text: 'Verglichen mit: ' + rcNamenEinsetzen(a.beleg, namen) }) : null,
      a.erklaerung ? h('p', { text: rcNamenEinsetzen(a.erklaerung, namen) }) : null,
      a.quellen.length ? h('ul', { class: 'rc-quellen' }, a.quellen.map(function (q) {
        return h('li', null, h('a', { href: q.url, target: '_blank', rel: 'noopener noreferrer', text: q.titel }),
          h('span', { class: 'frist-info', text: ' ' + [q.amtlich ? 'amtlich' : 'nicht als amtlich gekennzeichnet', q.herausgeber, q.stand ? 'Stand ' + q.stand : ''].filter(Boolean).join(', ') }));
      })) : h('p', { class: 'frist-info', text: 'Keine Quelle genannt. Prüfe diesen Punkt selbst.' }));
  }

  function rcErgebnis(l, zeile) {
    var c = l.check, e = c.ergebnis, a = l.auswertung, namen = c.namen;
    var teile = [
      h('section', { class: 'block' },
        h('h2', { text: 'Ergebnis vom ' + rcZeit(c.erstelltAm) }),
        h('p', null, rcChip(a.gesamt)),
        h('p', { text: rcZaehlText(a.zaehl) + '.' }),
        zeile && zeile.veraltet ? h('p', { class: 'meldung', text: 'Seit diesem Check haben sich Daten geändert, die in die Anfrage eingehen (zum Beispiel Besatzung, Nachweise, Fahrzeug oder Zeitraum). Prüfe noch einmal.' }) : null,
        e.recherche !== 'vollständig' ? h('p', { class: 'meldung', text: 'Die Recherche war ' + e.recherche + '. Das Ergebnis kann Lücken haben.' }) : null,
        e.zusammenfassung ? h('p', { text: rcNamenEinsetzen(e.zusammenfassung, namen) }) : null,
        e.warnungen.length ? h('ul', { class: 'status-zeilen' }, e.warnungen.map(function (w) { return h('li', { class: 'status-bald', text: rcNamenEinsetzen(w, namen) }); })) : null,
        c.dienst && c.dienst.modell ? h('p', { class: 'hinweis', text: 'Recherche durch: ' + c.dienst.modell }) : null)
    ];
    var r = e.route;
    if (r && (r.zusammenfassung || r.annahmen.length || r.hinweise.length)) {
      teile.push(h('section', { class: 'bereich', 'aria-label': 'Route' }, h('h2', { text: 'Route' }),
        r.zusammenfassung ? h('p', { text: rcNamenEinsetzen(r.zusammenfassung, namen) }) : null,
        r.hinweise.length ? h('ul', { class: 'status-zeilen' }, r.hinweise.map(function (x) { return h('li', { class: 'status-bald', text: x }); })) : null,
        r.annahmen.length ? h('p', { class: 'hinweis', text: 'Annahmen: ' + r.annahmen.join(' ') }) : null));
    }
    MM.Reisecheck.KATEGORIEN.forEach(function (k) {
      var liste = l.anforderungen.filter(function (x) { return x.kategorie === k; });
      if (!liste.length) return;
      teile.push(h('section', { class: 'bereich', 'aria-label': RC_KATEGORIE_TITEL[k] },
        h('h2', { text: RC_KATEGORIE_TITEL[k] + ' (' + liste.length + ')' }),
        h('ul', { class: 'rc-liste' }, liste.map(function (x) { return rcAnforderung(x, namen); }))));
    });
    teile.push(h('p', { class: 'hinweis', text: 'Planungshilfe, keine rechtsgültige Auskunft. Die Recherche kann veraltet oder falsch sein. Die Verantwortung bleibt beim Skipper oder Fahrer. Prüfe wichtige Punkte bei der zuständigen Stelle.' }));
    return teile;
  }

  /* tagId (seit 2.0.43): Reisecheck für einen Tag (Etappe) mit den zwei Orten dieses Tages, zusätzlich zum Gesamtcheck. */
  function seiteReisecheckAktivitaet(id, checkId, tagId) {
    var basis = '#/reisecheck/' + enc(id) + (tagId ? '/tag/' + enc(tagId) : '');
    return daten.reisecheckAnsicht(id, tagId || null).then(function (an) {
      if (!an) return nichtGefunden(tagId ? 'Tag nicht gefunden' : 'Aktivität nicht gefunden');
      var zeigeId = checkId || (an.checks.length ? an.checks[0].id : null);
      return (zeigeId ? daten.reisecheckLaden(zeigeId) : Promise.resolve(null)).then(function (l) {
        var e = an.einstellung, akt = an.aktivitaet;
        var bereit = e.eingerichtet && e.zugestimmt && an.anfrage && !akt.storniert;
        var fel = h('p', { class: 'fehler', role: 'alert' }), status = h('p', { class: 'hinweis', role: 'status' });
        var start = h('button', { class: 'knopf', type: 'button', disabled: bereit ? null : 'disabled', text: an.checks.length ? 'Noch einmal online prüfen' : 'Jetzt online prüfen' });
        start.addEventListener('click', function () {
          fel.textContent = ''; start.disabled = true;
          status.textContent = 'Der Dienst recherchiert im Internet. Das kann ein bis zwei Minuten dauern. Bitte die Seite offen lassen …';
          daten.reisecheckStarten(id, tagId || null).then(function (r) {
            if (r.ok) { global.location.hash = basis + '/' + enc(r.id); return; }
            status.textContent = ''; start.disabled = false; fel.textContent = r.fehler.allgemein;
          }).catch(function (err) { status.textContent = ''; start.disabled = false; fel.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler'); });
        });
        var voraussetzung = null;
        if (akt.storniert) voraussetzung = h('p', { class: 'meldung', text: 'Diese Aktivität ist storniert.' });
        else if (!e.eingerichtet) voraussetzung = h('p', { class: 'meldung' }, 'Der Dienst ist noch nicht eingerichtet. ', h('a', { href: '#/reisecheck/dienst', text: 'Dienst einrichten' }));
        else if (!e.zugestimmt) voraussetzung = h('p', { class: 'meldung' }, 'Es fehlt deine Zustimmung. ', h('a', { href: '#/reisecheck/dienst', text: 'Zustimmung ansehen' }));
        var zeile = l ? an.checks.filter(function (x) { return x.id === l.check.id; })[0] : null;
        seite('Reisecheck: ' + akt.name, [
          krumen(tagId ? [['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [akt.name, '#/aktivitaet/' + enc(id)], [MM.Hilfen.datum(akt.tagDatum), '#/tagesabschnitt/' + enc(tagId)], ['Reisecheck']]
            : [['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Reisecheck', '#/reisecheck'], [akt.name]]),
          h('h1', { text: tagId ? 'Reisecheck für den ' + MM.Hilfen.datum(akt.tagDatum) : 'Reisecheck' }),
          h('p', null, h('a', { href: '#/aktivitaet/' + enc(id), text: akt.name }), ' · ' + akt.fahrzeugName + ' · ' + (tagId ? 'Tag ' + MM.Hilfen.datum(akt.tagDatum) : MM.Hilfen.datum(akt.vonDatum) + ' bis ' + MM.Hilfen.datum(akt.bisDatum))),
          tagId ? h('p', { class: 'hilfe', text: 'Dieser Check gilt nur für diesen Tag und nimmt nur Start- und Zielort des Tages. Er ersetzt den Gesamtcheck der Reise nicht, sondern kommt dazu. Ob er im Kontingent zählt, wird mit dem Kostenmodell entschieden: Zurzeit zählt er nicht.' }) : null,
          h('section', { class: 'block' },
            h('h2', { text: 'Prüfung starten' }),
            voraussetzung,
            an.fehler.length ? [h('p', { class: 'meldung', text: 'Für den Check fehlt noch etwas:' }), h('ul', { class: 'status-zeilen' }, an.fehler.map(function (f) { return h('li', { class: 'status-bald', text: f }); })),
              h('p', null, tagId ? h('a', { class: 'knopf leise', href: '#/tagesabschnitt/' + enc(tagId) + '/aendern', text: 'Tag ergänzen' }) : h('a', { class: 'knopf leise', href: '#/aktivitaet/' + enc(id) + '/aendern', text: 'Aktivität ergänzen' }))] : null,
            an.anfrage ? h('details', { class: 'block test' }, h('summary', { text: 'Was geht an den Dienst?' }),
              h('p', { class: 'hinweis', text: 'Nur diese Angaben, ohne Namen und ohne Nummern. Die Besatzung heißt dort „P1“, „P2“ und Tiere „A1“.' }),
              h('ul', { class: 'status-zeilen' }, an.anfrage.vorschau.map(function (z) { return h('li', { text: z }); }))) : null,
            fel, status, h('p', { class: 'knopfzeile' }, start)),
          l ? rcErgebnis(l, zeile) : (checkId ? h('p', { class: 'meldung', text: 'Diesen Check gibt es nicht.' }) : h('p', { class: 'leer-text', text: tagId ? 'Für diesen Tag gibt es noch keinen Check.' : 'Für diese Aktivität gibt es noch keinen Check.' })),
          an.checks.length > 1 || (an.checks.length === 1 && checkId && l && an.checks[0].id !== l.check.id) ? h('section', { class: 'bereich', 'aria-label': 'Frühere Checks' },
            h('h2', { text: tagId ? 'Alle Checks dieses Tages' : 'Alle Checks dieser Aktivität' }),
            h('ul', { class: 'fristen' }, an.checks.map(function (x) {
              return h('li', null, h('a', { class: 'frist ' + RC_KLASSE[x.gesamt], href: basis + '/' + enc(x.id) },
                h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: rcZeit(x.erstelltAm) }), h('span', { class: 'frist-info', text: rcZaehlText(x.zaehl) + (x.veraltet ? ' · Daten seitdem geändert' : '') })),
                rcChip(x.gesamt)));
            }))) : null
        ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: tagId ? '#/tagesabschnitt/' + enc(tagId) : '#/reisecheck', text: 'Zurück' })));
      });
    });
  }

  /* ---------- Grundcheck (Schritt 11b, seit 2.0.40) ---------- */
  var GC_KLASSE = { vorhanden: 'status-ok', zu_wenig: 'status-bald', fehlt: 'status-ueberfaellig', unklar: 'status-bald' };

  /*
   * „Habe ich unter anderem Namen“ (seit 2.0.41): Der Nutzer wählt, wie dieser Punkt bei ihm heißt (zum Beispiel Rettungsweste statt
   * Persönliche Schwimmhilfe). Er bestätigt damit selbst, dass beides dasselbe ist. Die App rät nichts und setzt nichts von selbst gleich.
   * ctx: { id, land, artName, kandidaten: { ausruestung: [Namen], papier: [Namen] } }
   */
  function gcZuordnung(z, ctx) {
    var pt = z.punkt, art = pt.art, schon = z.zugeordnet || [];
    if (z.status === 'vorhanden' && !schon.length) return null;
    var eigen = MM.Orte.suchbegriff(pt.name).toLowerCase();
    var frei = (ctx.kandidaten[art] || []).filter(function (n) { return schon.indexOf(n) < 0 && n.toLowerCase() !== eigen; });
    var fel = h('p', { class: 'fehler', role: 'alert' });
    function neuZeigen(text) { meldung = text; zeige(); }
    var teile = [h('p', { class: 'hinweis', text: 'Heißt dieser Punkt bei dir anders? Wähle deine Bezeichnung aus der Liste. Damit bestätigst du selbst, dass beides dasselbe ist. ' +
      'Die App merkt sich das für ' + ctx.land + (ctx.artName ? ' und ' + ctx.artName : '') + ' und nutzt es im Grundcheck und im Reisecheck. Sie setzt nie von selbst etwas gleich.' })];
    if (schon.length) {
      teile.push(h('ul', { class: 'status-zeilen' }, schon.map(function (n) {
        var weg = h('button', { class: 'knopf leise klein', type: 'button', text: 'Aufheben' });
        weg.addEventListener('click', function () {
          weg.disabled = true; fel.textContent = '';
          daten.grundcheckZuordnungAufheben(ctx.id, { art: art, punkt: pt.name, land: ctx.land, ziel: n }).then(function (r) {
            if (r.ok) neuZeigen('Die Zuordnung zu „' + n + '“ ist aufgehoben.');
            else { weg.disabled = false; fel.textContent = r.fehler.allgemein; }
          }).catch(function (err) { weg.disabled = false; fel.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler'); });
        });
        return h('li', { class: 'status-ok' }, 'Gleichgesetzt mit „' + n + '“ ', weg);
      })));
    }
    if (frei.length) {
      var sel = h('select', { 'aria-label': 'Wie heißt „' + pt.name + '“ bei dir?' }, [h('option', { value: '', text: '– meine Bezeichnung wählen –' })].concat(frei.map(function (n) { return h('option', { value: n, text: n }); })));
      var los = h('button', { class: 'knopf klein', type: 'button', text: 'Gleichsetzen' });
      los.addEventListener('click', function () {
        fel.textContent = '';
        if (!sel.value) { fel.textContent = 'Bitte zuerst deine Bezeichnung aus der Liste wählen.'; return; }
        los.disabled = true;
        daten.grundcheckZuordnen(ctx.id, { art: art, punkt: pt.name, land: ctx.land, ziel: sel.value }).then(function (r) {
          if (r.ok) neuZeigen('„' + pt.name + '“ ist jetzt mit „' + sel.value + '“ gleichgesetzt.');
          else { los.disabled = false; fel.textContent = r.fehler.allgemein; }
        }).catch(function (err) { los.disabled = false; fel.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler'); });
      });
      teile.push(h('p', { class: 'knopfzeile' }, sel, ' ', los));
    } else if (!schon.length) {
      teile.push(h('p', { class: 'frist-info', text: art === 'papier'
        ? 'Am Fahrzeug ist noch kein Nachweis eingetragen, den du gleichsetzen könntest.'
        : 'Am Fahrzeug ist noch keine Komponente eingetragen, die du gleichsetzen könntest. Trage sie zuerst ein, dann kannst du sie hier auswählen.' }));
    }
    teile.push(fel);
    return h('details', { class: 'block test' }, [h('summary', { text: 'Habe ich unter anderem Namen' })].concat(teile));
  }

  function gcZeile(z, ctx) {
    var pt = z.punkt;
    return h('li', { class: 'rc-anf ' + GC_KLASSE[z.status] },
      h('div', { class: 'rc-kopf' }, h('span', { class: 'chip-status ' + GC_KLASSE[z.status], text: MM.Grundcheck.STATUS_TEXT[z.status] }), ' ', h('strong', { text: pt.name })),
      h('p', { class: 'rc-text', text: z.text }),
      pt.erklaerung ? h('p', { class: 'frist-info', text: pt.erklaerung }) : null,
      pt.widerspruch ? h('p', { class: 'meldung', text: 'Die Quellen widersprechen sich. Bitte selbst nachprüfen.' }) : null,
      z.link ? h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: z.link.href, text: z.link.text })) : null,
      ctx ? gcZuordnung(z, ctx) : null,
      pt.quellen.length ? h('ul', { class: 'rc-quellen' }, pt.quellen.map(function (q) {
        return h('li', null, h('a', { href: q.url, target: '_blank', rel: 'noopener noreferrer', text: q.titel }),
          h('span', { class: 'frist-info', text: ' ' + [q.amtlich ? 'amtlich' : 'nicht als amtlich gekennzeichnet', q.herausgeber, q.stand ? 'Stand ' + q.stand : ''].filter(Boolean).join(', ') }));
      })) : h('p', { class: 'frist-info', text: 'Keine Quelle genannt. Prüfe diesen Punkt selbst.' }),
      pt.stand ? h('p', { class: 'frist-info', text: 'Stand der Angabe: ' + pt.stand }) : null);
  }

  function seiteGrundcheck(id, checkId) {
    return daten.grundcheckAnsicht(id, checkId).then(function (an) {
      if (!an) return nichtGefunden('Fahrzeug nicht gefunden');
      var e = an.einstellung, fz = an.fahrzeug, g = an.gewaehlt;
      var zurueck = '#/fahrzeug/' + enc(id);
      var bereit = e.eingerichtet && e.zugestimmt && an.anfrage && !fz.abgegeben;
      var fel = h('p', { class: 'fehler', role: 'alert' }), status = h('p', { class: 'hinweis', role: 'status' });
      var start = h('button', { class: 'knopf', type: 'button', disabled: bereit ? null : 'disabled', text: an.checks.length ? 'Grundcheck wiederholen' : 'Grundcheck starten' });
      start.addEventListener('click', function () {
        fel.textContent = ''; start.disabled = true;
        status.textContent = 'Der Dienst recherchiert im Internet. Das kann ein bis zwei Minuten dauern. Bitte die Seite offen lassen …';
        daten.grundcheckStarten(id).then(function (r) {
          if (r.ok) { global.location.hash = '#/fahrzeug/' + enc(id) + '/grundcheck/' + enc(r.id); return; }
          status.textContent = ''; start.disabled = false; fel.textContent = r.fehler.allgemein;
        }).catch(function (err) { status.textContent = ''; start.disabled = false; fel.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler'); });
      });
      var voraussetzung = null;
      if (fz.abgegeben) voraussetzung = h('p', { class: 'meldung', text: 'Dieses Fahrzeug ist abgegeben.' });
      else if (!e.eingerichtet) voraussetzung = h('p', { class: 'meldung' }, 'Der Dienst ist noch nicht eingerichtet. ', h('a', { href: '#/reisecheck/dienst', text: 'Dienst einrichten' }));
      else if (!e.zugestimmt) voraussetzung = h('p', { class: 'meldung' }, 'Es fehlt deine Zustimmung. ', h('a', { href: '#/reisecheck/dienst', text: 'Zustimmung ansehen' }));
      var heimatZeile = an.heimat.land
        ? h('p', null, h('strong', { text: 'Heimatland: ' + an.heimat.land }), ' (Heimatstandort: ' + an.heimat.ortName + ', ' + an.heimat.standortName + ') ', h('a', { href: zurueck + '/heimatstandort', text: 'ändern' }))
        : h('p', { class: 'meldung' }, an.heimat.grund + ' ', h('a', { href: zurueck + '/heimatstandort', text: 'Heimatstandort wählen' }));
      var teile = [
        krumen(WEG_FAHRZEUGE.concat([[fz.name, zurueck], ['Grundcheck']])),
        h('h1', { text: 'Grundcheck' }),
        h('p', { text: fz.name + (fz.artName ? ' · ' + fz.artName : '') }),
        h('p', { class: 'hinweis', text: 'Der Grundcheck sagt, was dein Fahrzeug an seinem Heimatort an Papieren und Grundausrüstung braucht, und vergleicht es mit dem, was du eingetragen hast. Er braucht keine Aktivität und keine Besatzung. Es wird nichts gesperrt, und es ist keine rechtsgültige Aussage.' }),
        h('section', { class: 'block' },
          h('h2', { text: 'Prüfung starten' }),
          heimatZeile,
          voraussetzung,
          an.fehler.length && an.heimat.land ? [h('p', { class: 'meldung', text: 'Für den Check fehlt noch etwas:' }), h('ul', { class: 'status-zeilen' }, an.fehler.map(function (f) { return h('li', { class: 'status-bald', text: f }); }))] : null,
          an.anfrage ? h('details', { class: 'block test' }, h('summary', { text: 'Was geht an den Dienst?' }),
            h('p', { class: 'hinweis', text: 'Nur diese Angaben, ohne Namen und ohne Nummern.' }),
            h('ul', { class: 'status-zeilen' }, an.anfrage.vorschau.map(function (z) { return h('li', { text: z }); }))) : null,
          fel, status, h('p', { class: 'knopfzeile' }, start))
      ];
      if (g) {
        teile.push(h('section', { class: 'block' },
          h('h2', { text: 'Ergebnis vom ' + rcZeit(g.erstelltAm) + ' für ' + g.land }),
          h('p', { text: MM.Grundcheck.zaehlText(an.zaehl) + '.' }),
          g.landWechsel ? h('p', { class: 'meldung', text: 'Das Heimatland ist inzwischen ' + an.heimat.land + '. Dieser Check gilt für ' + g.land + '. Wiederhole den Grundcheck.' }) : null,
          g.veraltet && !g.landWechsel ? h('p', { class: 'meldung', text: 'Seit diesem Check haben sich Angaben am Fahrzeug geändert, die in die Anfrage eingehen. Der Vergleich unten gilt für den heutigen Stand der Eintragungen. Wiederhole den Grundcheck, wenn sich etwas Grundlegendes geändert hat, zum Beispiel nach einem Umzug.' }) : null,
          g.recherche !== 'vollständig' ? h('p', { class: 'meldung', text: 'Die Recherche war ' + g.recherche + '. Das Ergebnis kann Lücken haben.' }) : null,
          g.warnungen.length ? h('ul', { class: 'status-zeilen' }, g.warnungen.map(function (w) { return h('li', { class: 'status-bald', text: w }); })) : null,
          g.dienst && g.dienst.modell ? h('p', { class: 'hinweis', text: 'Recherche durch: ' + g.dienst.modell }) : null));
        if (!an.zeilen.length) teile.push(h('p', { class: 'meldung', text: 'Der Dienst hat keine Punkte im erwarteten Format geliefert. Die App rät nichts. Wiederhole den Grundcheck später noch einmal.' }));
        MM.Grundcheck.ARTEN.forEach(function (art) {
          var liste = an.zeilen.filter(function (z) { return z.punkt.art === art; });
          if (!liste.length) return;
          teile.push(h('section', { class: 'bereich', 'aria-label': MM.Grundcheck.ARTEN_TEXT[art] },
            h('h2', { text: MM.Grundcheck.ARTEN_TEXT[art] + ' (' + liste.length + ')' }),
            h('ul', { class: 'rc-liste' }, liste.map(function (z) { return gcZeile(z, { id: id, land: g.land, artName: fz.artName, kandidaten: an.kandidaten }); }))));
        });
        if (an.nichtLesbar.length) {
          teile.push(h('section', { class: 'bereich', 'aria-label': 'Weitere Hinweise' },
            h('h2', { text: 'Weitere Hinweise des Dienstes (nicht auswertbar)' }),
            h('p', { class: 'hinweis', text: 'Diese Punkte kamen nicht im festen Format an. Die App vergleicht sie nicht und rät nichts. Prüfe sie selbst.' }),
            h('ul', { class: 'rc-liste' }, an.nichtLesbar.map(function (x) {
              return h('li', { class: 'rc-anf status-bald' }, h('div', { class: 'rc-kopf' }, h('span', { class: 'chip-status status-bald', text: 'Unklar' })), h('p', { class: 'rc-text', text: x.text }),
                x.quellen.length ? h('ul', { class: 'rc-quellen' }, x.quellen.map(function (q) { return h('li', null, h('a', { href: q.url, target: '_blank', rel: 'noopener noreferrer', text: q.titel }), h('span', { class: 'frist-info', text: x.stand ? ' Stand ' + x.stand : '' })); })) : null);
            }))));
        }
        teile.push(h('p', { class: 'hinweis', text: 'Planungshilfe, keine rechtsgültige Auskunft. Die Recherche kann veraltet oder falsch sein. Die Verantwortung bleibt beim Halter und Fahrer. Prüfe wichtige Punkte bei der zuständigen Stelle.' }));
      } else if (checkId) teile.push(h('p', { class: 'meldung', text: 'Diesen Check gibt es nicht.' }));
      else teile.push(h('p', { class: 'leer-text', text: 'Für dieses Fahrzeug gibt es noch keinen Grundcheck.' }));
      if (an.checks.length > 1) {
        teile.push(h('section', { class: 'bereich', 'aria-label': 'Frühere Grundchecks' },
          h('h2', { text: 'Alle Grundchecks dieses Fahrzeugs' }),
          h('ul', { class: 'fristen' }, an.checks.map(function (x) {
            return h('li', null, h('a', { class: 'frist', href: zurueck + '/grundcheck/' + enc(x.id) },
              h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: rcZeit(x.erstelltAm) }), h('span', { class: 'frist-info', text: x.land + (x.veraltet ? ' · Daten seitdem geändert' : '') }))));
          }))));
      }
      seite('Grundcheck: ' + fz.name, teile, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' })));
    });
  }

  function grundcheckKurzBlock(id) {
    return h('section', { class: 'bereich', 'aria-label': 'Grundcheck' },
      h('h2', { text: 'Grundcheck' }),
      h('p', { class: 'leer-text', text: 'Zeigt, was dieses Fahrzeug an seinem Heimatort an Papieren und Grundausrüstung braucht, und vergleicht es mit deinen Eintragungen.' }),
      h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: '#/fahrzeug/' + enc(id) + '/grundcheck', text: 'Grundcheck öffnen' })));
  }

  function reisecheckKurzBlock(id, storniert) {
    return h('section', { class: 'bereich', 'aria-label': 'Reisecheck' },
      h('h2', { text: 'Reisecheck' }),
      h('p', { class: 'leer-text', text: 'Prüft online, was für diese Reise nötig ist, und vergleicht es mit deiner Besatzung, deinen Nachweisen und deinem Fahrzeug.' }),
      h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: '#/reisecheck/' + enc(id), text: storniert ? 'Ansehen' : 'Reisecheck öffnen' })));
  }

  /* ---------- Kassenbuch (seit 2.0.31): die Kassen aller Aktivitäten auf einen Blick ---------- */
  function seiteKassenbuch() {
    return daten.aktivitaetenListe().then(function (liste) {
      return Promise.all(liste.map(function (x) { return daten.kassenListe(x.objekt.id); })).then(function (kassen) {
        function zeile(x, i) {
          var w = x.aktuell.werte, k = kassen[i];
          return h('li', null, h('a', { class: 'frist ak ' + AK_KLASSE[x.status], href: '#/aktivitaet/' + enc(x.objekt.id) + '/reisekasse' },
            h('span', { class: 'frist-text' },
              h('strong', { class: 'frist-name', text: w.bezeichnung }),
              h('span', { class: 'frist-info', text: [x.artName, x.fahrzeugName].filter(Boolean).join(', ') }),
              h('span', { class: 'frist-info', text: zeitraumText(w) }),
              k.length ? k.map(function (e) { return h('span', { class: 'frist-info', text: 'Kasse ' + e.waehrung + ': Stand ' + kassenBetragText(e.rechnung.stand, e.waehrung) }); })
                : h('span', { class: 'frist-info', text: 'Noch keine Kasse' })),
            h('span', { class: 'chip-status ' + AK_KLASSE[x.status], text: AK_STATUS[x.status] })));
        }
        var mit = [], ohne = [];
        liste.forEach(function (x, i) { (kassen[i].length ? mit : ohne).push(zeile(x, i)); });
        var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Kassenbuch']]), h('h1', { text: 'Kassenbuch' }),
          h('p', { class: 'hilfe', text: 'Eine Kasse gehört immer zu einer Aktivität. Hier siehst du die Kassen aller Aktivitäten. Tippe auf eine Aktivität, um ihre Reisekasse zu öffnen.' })];
        if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Noch keine Aktivität, also auch noch keine Kasse. Plane zuerst eine Aktivität, zum Beispiel einen Urlaub oder einen Törn.' })));
        if (mit.length) inhalt.push(h('ul', { class: 'fristen' }, mit));
        else if (liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Noch keine Kasse angelegt. Öffne eine Aktivität unten und lege dort den Anfangsbestand fest.' })));
        if (ohne.length) inhalt.push(h('details', { class: 'ausgebaut', open: mit.length ? null : 'open' }, h('summary', { text: 'Aktivitäten ohne Kasse (' + ohne.length + ')' }), h('ul', { class: 'fristen' }, ohne)));
        seite('Kassenbuch', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/funktionen', text: 'Zurück' }),
          h('a', { class: 'knopf leise', href: '#/aktivitaeten', text: 'Zu den Aktivitäten' })));
      });
    });
  }

  function aktivitaetZeile(x) {
    var w = x.aktuell.werte;
    return h('li', null, h('a', { class: 'frist ak ' + AK_KLASSE[x.status], href: '#/aktivitaet/' + encodeURIComponent(x.objekt.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: w.bezeichnung }),
        h('span', { class: 'frist-info', text: [x.artName, x.fahrzeugName].filter(Boolean).join(', ') }),
        h('span', { class: 'frist-info', text: zeitraumText(w) }),
        x.konflikte.length ? h('span', { class: 'hinweis-frist status-bald', text: x.konflikte.length === 1 ? 'Überschneidet sich mit 1 anderen' : 'Überschneidet sich mit ' + x.konflikte.length + ' anderen' }) : null),
      h('span', { class: 'chip-status ' + AK_KLASSE[x.status], text: AK_STATUS[x.status] })));
  }

  function seiteAktivitaeten() {
    return daten.aktivitaetenListe().then(function (liste) {
      function teil(status) { return liste.filter(function (x) { return status.indexOf(x.status) >= 0; }); }
      var jetzt = teil(['laeuft', 'geplant']), vorbei = teil(['vorbei']), storno = teil(['storniert']);
      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten']]), h('h1', { text: 'Aktivitäten' })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Noch keine Aktivität. Plane zum Beispiel einen Törn oder einen Urlaub. Du brauchst dafür ein Fahrzeug und eine Person.' })));
      if (jetzt.length) inhalt.push(h('ul', { class: 'fristen' }, jetzt.map(aktivitaetZeile)));
      if (vorbei.length) inhalt.push(h('details', { class: 'ausgebaut' }, h('summary', { text: 'Vorbei (' + vorbei.length + ')' }), h('ul', { class: 'fristen' }, vorbei.map(aktivitaetZeile))));
      if (storno.length) inhalt.push(h('details', { class: 'ausgebaut' }, h('summary', { text: 'Storniert (' + storno.length + ')' }), h('ul', { class: 'fristen' }, storno.map(aktivitaetZeile))));
      inhalt.push(h('p', null, h('a', { href: '#/aktivitaetsarten', text: 'Arten von Aktivitäten verwalten' })));
      inhalt.push(h('p', null, h('a', { href: '#/ereignisarten', text: 'Arten von Ereignissen im Logbuch verwalten' })));
      seite('Aktivitäten', inhalt, h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/funktionen', text: 'Zurück' }),
        h('a', { class: 'knopf leise', href: '#/aktivitaet/neu', text: 'Aktivität planen' }),
        h('a', { class: 'knopf', href: '#/logbuch/start', text: 'Logbuch jetzt starten' })));
    });
  }

  /* ---------- Seite: Aktivität ---------- */
  function seiteAktivitaet(id) {
    return Promise.all([daten.aktivitaetLaden(id), daten.aktivitaetPruefung(id), daten.logbuchLaden(id)]).then(function (r) {
      var a = r[0], pr = r[1], lb = r[2];
      if (!a) return nichtGefunden('Aktivität nicht gefunden');
      var w = a.aktuell.werte;
      /* Läuft die Aktivität (oder wurde das Cockpit gewählt), kommt das Cockpit im Vollbild. Es gibt nur, wenn heute im Zeitraum liegt. */
      if ((reiterWahl[id] || (a.status === 'laeuft' ? 'cockpit' : 'logbuch')) === 'cockpit' && MM.Logbuch.cockpitMoeglich(w, daten.heute()).moeglich) {
        return Promise.all([daten.schnellknoepfeFuerFahrzeugart(a.fahrzeug.artId), daten.motorenListe(a.fahrzeug.id), daten.fahrzeugartMotor(a.fahrzeug.artId), daten.streckenZaehler(a.fahrzeug.id), daten.geraetWartezeit(), daten.fahrzeugStatus(a.fahrzeug.id), daten.gpsSpurLesen(id), daten.gpsWegLesen(id), daten.geraetWetterRhythmus(), daten.gpsFahrtLesen(id)])
          .then(function (x) {
            var ereignisse = [];
            lb.abschnitte.forEach(function (t) { if (!t.ausgeblendet) t.ereignisse.forEach(function (e) { if (e.art === 'ereignis' && !e.ausgeblendet) ereignisse.push(e); }); });
            cockpitSpurVorbereiten(id, x[6], x[5], a.fahrzeug.welt);
            wegVorbereiten(id, x[7], x[5], a.fahrzeug.welt);
            fahrtVorbereiten(id, x[9], x[5], a.fahrzeug.welt);
            return daten.reiseortFrage(id, ereignisse).then(function (bf) { return cockpitVollbild(a, lb, x[0], x[1], x[2].hat, x[3], x[4].wartezeit, x[5], bf, x[8].minuten); });
          });
      }
      return Promise.all([daten.kostenListe(a.fahrzeug.id), daten.reiseAuswertung(id), daten.routeAnsicht(id), daten.reiseZusammenfassung(id)]).then(function (kr) {
      var kostenAlle = kr[0], reise = kr[1], routeInfo = kr[2], zus = kr[3];
      var meineKosten = kostenAlle.filter(function (x) { return x.aktuell.werte.aktivitaetId === id && x.aktuell.werte.gruppe !== 'reisekasse'; });
      var verantwortlich = MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt);
      var storniert = w.status === 'storniert';

      /* Kopf */
      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Aktivität' + (a.art ? ': ' + a.art.name : '') }),
        h('h1', { text: w.bezeichnung }),
        h('p', null, h('span', { class: 'chip-status gross ' + AK_KLASSE[a.status], text: AK_STATUS[a.status] })),
        storniert ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Storniert am ' + jetztText(w.stornoAm.replace(/:\d\d(\.\d+)?Z?$/, '').slice(0, 16)) + (w.stornoGrund ? '. Grund: ' + w.stornoGrund : '.') }) : null,
        h('dl', { class: 'daten stapel' },
          h('dt', { text: 'Fahrzeug' }), h('dd', null, h('a', { href: '#/fahrzeug/' + encodeURIComponent(a.fahrzeug.id), text: a.fahrzeug.name })),
          h('dt', { text: 'Zeitraum' }), h('dd', { text: zeitraumText(w) }),
          a.gebiet ? [h('dt', { text: 'Gebiet' }), h('dd', null, h('a', { href: '#/gebiet/' + encodeURIComponent(a.gebiet.id), text: a.gebiet.name }))]
            : (w.gebiet ? [h('dt', { text: 'Gebiet (Text)' }), h('dd', { text: w.gebiet })] : null),
          a.ortGebiete && a.ortGebiete.ketten.length ? [h('dt', { text: 'Gebiet aus den Orten' }), h('dd', null, a.ortGebiete.ketten.map(function (k, i) {
            return [i ? h('br') : null, k.map(function (g, n) { return [n ? ' › ' : null, h('a', { href: '#/gebiet/' + encodeURIComponent(g.id), text: g.name })]; })];
          }))] : null,
          a.ortGebiete && a.ortGebiete.ohneGebiet.length ? [h('dt', { text: 'Gebiet unklar bei' }), h('dd', { text: a.ortGebiete.ohneGebiet.join(', ') + ' (Ort noch nicht geprüft)' })] : null,
          a.startOrt ? [h('dt', { text: 'Start' }), h('dd', null, h('a', { href: '#/ort/' + encodeURIComponent(a.startOrt.id), text: a.startOrt.name }))] : null,
          a.zielOrt ? [h('dt', { text: 'Ziel' }), h('dd', null, h('a', { href: '#/ort/' + encodeURIComponent(a.zielOrt.id), text: a.zielOrt.name }))] : null,
          a.zwischenziele.length ? [h('dt', { text: 'Zwischenziele' }), h('dd', null, a.zwischenziele.map(function (z, i) { return [i ? ', ' : null, h('a', { href: '#/ort/' + encodeURIComponent(z.id), text: z.name })]; }))] : null,
          w.geplanteStrecke ? [h('dt', { text: 'Geplante Strecke' }), h('dd', { text: MM.Hilfen.zahl(w.geplanteStrecke) + ' km' })] : null,
          w.geplanteStunden ? [h('dt', { text: 'Geplante Betriebsstunden' }), h('dd', { text: MM.Hilfen.zahl(w.geplanteStunden) + ' h' })] : null,
          a.tiere.length ? [h('dt', { text: 'Tiere' }), h('dd', { text: a.tiere.map(function (t) { return t.name; }).join(', ') })] : null,
          w.notiz ? [h('dt', { text: 'Notiz' }), h('dd', { text: w.notiz })] : null),
        h('p', { class: 'knopfzeile' },
          storniert ? h('button', { class: 'knopf', type: 'button', text: 'Wiederherstellen', onclick: function () { daten.aktivitaetWiederherstellen(id).then(function () { meldung = 'Die Aktivität ist wieder geplant.'; return zeige(); }).catch(fehlerSeite); } })
            : [h('a', { class: 'knopf leise', href: '#/aktivitaet/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' }),
              h('a', { class: 'knopf gefahr', href: '#/aktivitaet/' + encodeURIComponent(id) + '/stornieren', text: 'Stornieren' })]));

      /* Besatzung */
      var jetzt = a.verantwortlichJetzt;
      var besatzung = h('section', { class: 'bereich', 'aria-label': 'Besatzung' },
        h('h2', { text: 'Besatzung' }),
        h('ul', { class: 'fristen' }, a.besatzung.map(function (b) {
          var dabei = b.aktuell.werte.dabeiVonDatum || b.aktuell.werte.dabeiBisDatum
            ? 'dabei ' + (b.aktuell.werte.dabeiVonDatum ? 'von ' + zeitText(b.aktuell.werte.dabeiVonDatum, b.aktuell.werte.dabeiVonZeit) : '') + (b.aktuell.werte.dabeiBisDatum ? ' bis ' + zeitText(b.aktuell.werte.dabeiBisDatum, b.aktuell.werte.dabeiBisZeit) : '') : null;
          var gerade = jetzt && jetzt.personId === b.person.id;
          return h('li', null, h('a', { class: 'frist ' + (gerade ? 'status-ok' : ''), href: '#/besatzung/' + encodeURIComponent(b.besatzung.id) + '/aendern' },
            h('span', { class: 'frist-text' },
              h('strong', { class: 'frist-name', text: b.person.name }),
              h('span', { class: 'frist-info', text: b.rolleText + (dabei ? ', ' + dabei : '') })),
            gerade ? h('span', { class: 'chip-status status-ok', text: 'verantwortlich' }) : null));
        })),
        a.entfernte.length ? h('details', { class: 'ausgebaut' }, h('summary', { text: 'Nicht mehr dabei (' + a.entfernte.length + ')' }),
          h('ul', { class: 'fristen' }, a.entfernte.map(function (b) {
            return h('li', null, h('a', { class: 'frist', href: '#/besatzung/' + encodeURIComponent(b.besatzung.id) + '/aendern' },
              h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: b.person.name }), h('span', { class: 'frist-info', text: b.rolleText }))));
          }))) : null,
        storniert ? null : h('p', { class: 'knopfzeile' },
          h('a', { class: 'knopf leise', href: '#/aktivitaet/' + encodeURIComponent(id) + '/besatzung/neu', text: 'Person hinzufügen' }),
          h('a', { class: 'knopf leise', href: '#/aktivitaet/' + encodeURIComponent(id) + '/verantwortung', text: 'Verantwortung wechseln' })),
        h('details', { class: 'ausgebaut' }, h('summary', { text: 'Wer war wann verantwortlich (' + a.verantwortung.length + ')' }),
          h('ol', { class: 'wechsel' }, a.verantwortung.map(function (v) {
            return h('li', null, 'ab ' + jetztText(v.ab) + ': ', h('strong', { text: v.name }), v.pruefung ? h('span', { class: 'frist-info', text: ' (Befähigung beim Wechsel: ' + MM.Aktivitaeten.ERGEBNIS[v.pruefung.ergebnis] + ')' }) : null);
          }))));

      /* Prüfung */
      var b = pr.befaehigung;
      var fr = pr.fristen;
      var betroffene = fr.liste.filter(function (f) { return f.status === 'faellig' || f.status === 'ueberfaellig'; });
      var sperreStatus = null;
      if (fr.zusammenfassung.sperre) {
        sperreStatus = w.sperreUebergangenAm
          ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Die Sperre wurde ausdrücklich übergangen am ' + jetztText(w.sperreUebergangenAm.replace(/:\d\d(\.\d+)?Z?$/, '').slice(0, 16)) + '.' })
          : h('div', null,
            h('p', { class: 'fehlerkasten', text: 'Mindestens eine Frist mit Sperre wird bis zum Ende des Zeitraums fällig.' }),
            storniert ? null : h('p', null, h('button', { class: 'knopf gefahr', type: 'button', text: 'Sperre ausdrücklich übergehen',
              onclick: function () { if (global.confirm('Die Sperre wirklich übergehen? Die Zeit wird festgehalten.')) daten.aktivitaetSperreUebergehen(id).then(function () { meldung = 'Die Sperre wurde übergangen und mit der Zeit festgehalten.'; return zeige(); }).catch(fehlerSeite); } })));
      }
      var pruefung = h('section', { class: 'bereich', 'aria-label': 'Prüfung' },
        h('h2', { text: 'Prüfung' }),
        h('p', { class: 'hinweis', text: 'Geprüft am ' + jetztText(pr.geprueftAm) + ', nur mit den Daten, die die App kennt. Das ist eine Hilfestellung und keine rechtliche Aussage. Die letzte Verantwortung hat der ' + verantwortlich + '.' }),
        h('section', { class: 'gruppe' },
          h('h3', { text: 'Befähigung von ' + verantwortlich + ' und Stellvertretern' }),
          h('p', null, h('span', { class: 'chip-status gross ' + ERG_KLASSE[b.ergebnis], text: MM.Aktivitaeten.ERGEBNIS[b.ergebnis] }),
            h('span', { class: 'frist-info', text: '  gilt bis zum Ende des Zeitraums (' + MM.Hilfen.datum(w.bisDatum) + ')' })),
          b.personen.map(function (p) {
            return h('div', { class: 'pruef-person' },
              h('p', null, h('strong', { text: p.person.name }), ' (' + p.rolleText + '): ', h('span', { class: 'chip-status ' + ERG_KLASSE[p.ergebnis], text: MM.Aktivitaeten.ERGEBNIS[p.ergebnis] })),
              h('ul', { class: 'gruende' }, p.gruende.map(function (g) { return h('li', { class: ERG_KLASSE[g.ergebnis], text: g.text }); })));
          }),
          pr.anforderungen === 0 ? h('p', { class: 'hinweis' }, 'Lege am Fahrzeug fest, welche Nachweise nötig sind. ', h('a', { href: '#/fahrzeug/' + encodeURIComponent(a.fahrzeug.id) + '/anforderung/neu', text: 'Anforderung anlegen' })) : null,
          b.gebietInfo ? h('div', { class: 'pruef-person' },
            h('p', null, h('strong', { text: 'Regeln des Gebiets ' + b.gebietInfo.name })),
            h('ul', { class: 'gruende' }, b.gebietInfo.greifen.map(function (t) { return h('li', { text: 'Gilt: ' + t }); })
              .concat(b.gebietInfo.nichtGreifen.map(function (n) { return h('li', { text: 'Gilt nicht: ' + n.bezeichnung + ' (' + n.grund + ')' }); })))) : null,
          b.gebietHinweis ? h('p', { class: 'hinweis' }, b.gebietHinweis + ' ', b.gebietInfo ? h('a', { href: '#/gebiet/' + encodeURIComponent(b.gebietInfo.id), text: 'Regeln ansehen' }) : null) : null),
        pr.ausruestung && pr.ausruestung.liste.length ? h('section', { class: 'gruppe' },
          h('h3', { text: 'Pflichtausrüstung im Gebiet' }),
          h('p', null, h('span', { class: 'chip-status gross ' + ERG_KLASSE[pr.ausruestung.ergebnis], text: MM.Aktivitaeten.ERGEBNIS[pr.ausruestung.ergebnis] })),
          h('ul', { class: 'gruende' }, pr.ausruestung.liste.map(function (x) {
            return h('li', { class: x.status === 'eingetragen' ? ERG_KLASSE.erlaubt : ERG_KLASSE.unklar,
              text: x.bezeichnung + ' – ' + x.text });
          })),
          h('p', { class: 'hilfe' }, 'Die App zählt nur die eingetragenen Komponenten (Anzahl) und zeigt die Eignung nur an. Sie weiß nicht, was wirklich an Bord liegt. ', h('a', { href: '#/fahrzeug/' + encodeURIComponent(a.fahrzeug.id), text: 'Zum Fahrzeug' }))) : null,
        h('section', { class: 'gruppe' },
          h('h3', { text: 'Fristen des Fahrzeugs bis zum Ende' }),
          !fr.liste.length ? h('p', { class: 'leer-text', text: 'Am Fahrzeug gibt es keine Fristen.' })
            : (betroffene.length ? h('ul', { class: 'gruende' }, betroffene.map(function (f) {
              var e = FRIST_ERG[f.status];
              return h('li', { class: e[1] }, h('strong', { text: f.bezeichnung }), ': ' + e[0] + ' (Wirkung: ' + MM.Fristen.labelVon(MM.Fristen.WIRKUNGEN, f.wirkung) + '). ' + f.text);
            })) : h('p', { class: 'leer-text', text: 'Bis zum Ende des Zeitraums wird keine Frist fällig.' })),
          fr.liste.filter(function (f) { return f.status === 'unbekannt'; }).length ? h('p', { class: 'hinweis', text: 'Bei manchen Fristen fehlen Angaben: ' + fr.liste.filter(function (f) { return f.status === 'unbekannt'; }).map(function (f) { return f.bezeichnung; }).join(', ') + '.' }) : null,
          sperreStatus),
        (fr.gespann || []).length ? h('section', { class: 'gruppe' },
          h('h3', { text: 'Dazugehörige Fahrzeuge: Fristen bis zum Ende' }),
          h('p', { class: 'hilfe', text: 'Diese Fahrzeuge gehören zum Fahrzeug der Aktivität. Ihre Fristen werden mitgeprüft, als Hinweis. Nichts wird gesperrt.' }),
          fr.gespann.map(function (g) {
            var bet = g.liste.filter(function (f) { return f.status === 'faellig' || f.status === 'ueberfaellig'; });
            var unb = g.liste.filter(function (f) { return f.status === 'unbekannt'; });
            return h('div', { class: 'pruef-person' },
              h('p', null, h('a', { href: '#/fahrzeug/' + encodeURIComponent(g.fahrzeugId) }, h('strong', { text: g.name })), g.artName ? ' (' + g.artName + ')' : '', g.tiefe > 1 ? ' – gehört zu ' + g.ueber : ''),
              !g.liste.length ? h('p', { class: 'leer-text', text: 'Bei diesem Fahrzeug gibt es keine Fristen.' })
                : (bet.length ? h('ul', { class: 'gruende' }, bet.map(function (f) {
                  var e = FRIST_ERG[f.status];
                  return h('li', { class: e[1] }, h('strong', { text: g.name + ': ' + f.bezeichnung }), ': ' + e[0] + '. ' + f.text);
                })) : h('p', { class: 'leer-text', text: 'Bis zum Ende des Zeitraums wird keine Frist fällig.' })),
              unb.length ? h('p', { class: 'hinweis', text: 'Bei manchen Fristen fehlen Angaben: ' + unb.map(function (f) { return f.bezeichnung; }).join(', ') + '.' }) : null);
          })) : null,
        h('section', { class: 'gruppe' },
          h('h3', { text: 'Belegung des Fahrzeugs' }),
          pr.belegung.konflikte.length ? h('ul', { class: 'gruende' }, pr.belegung.konflikte.map(function (k) {
            return h('li', { class: 'status-bald' }, 'Überschneidet sich mit ', h('a', { href: '#/aktivitaet/' + encodeURIComponent(k.id), text: k.name }), ' (' + MM.Hilfen.datum(k.vonDatum) + ' bis ' + MM.Hilfen.datum(k.bisDatum) + '). Das ist nur eine Warnung.');
          })) : h('p', { class: 'leer-text', text: 'Keine Überschneidung mit anderen Aktivitäten dieses Fahrzeugs.' })));

      seite(w.bezeichnung, [
        krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [w.bezeichnung]]),
        kopf, zusammenfassungBlock(zus, id, storniert, w.vonDatum !== w.bisDatum, tagWahlFuer(id, w, lb)), logbuchBlock(a, lb, storniert, zus, tagWahlFuer(id, w, lb)), pruefung, besatzung,
        reise ? reiseBlock(reise, id, storniert) : null,
        routeKurzBlock(routeInfo, id, storniert),
        reisecheckKurzBlock(id, storniert),
        reise ? reisekasseKurzBlock(reise, id, storniert, a.fahrzeug.id) : null,
        kostenBlock(meineKosten, '#/fahrzeug/' + encodeURIComponent(a.fahrzeug.id) + '/kosten/neu?gruppe=variabel&aktivitaet=' + encodeURIComponent(id), 'Noch keine Kosten zu dieser Aktivität. Trage zum Beispiel Treibstoff, Hafengebühren oder Parkplätze ein.', 'Kosten eintragen'),
        a.verlauf.length > 1 ? verlaufBlock(a.verlauf) : null
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/aktivitaeten', text: 'Zur Liste' }),
        storniert ? null : h('a', { class: 'knopf', href: '#/aktivitaet/' + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' })));
      });
    });
  }

  /* ---------- Route und Wetter (seit 2.0.33, Schritt 9) ---------- */
  var routeVersatz = {}; /* je Aktivität: Abfahrt früher (-) oder später (+), in Minuten, nur zum Ansehen */

  function kmText(km) { return MM.Hilfen.zahl(Math.round(km * 10) / 10) + ' km'; }
  function streckeText(km, welt) { return kmText(km) + (welt === 'wasser' ? ' (' + MM.Hilfen.zahl(Math.round(km / 1.852 * 10) / 10) + ' sm)' : ''); }
  function versatzText(m) { return m === 0 ? 'geplant' : (m < 0 ? Math.abs(m / 60) + ' h früher' : m / 60 + ' h später'); }
  function windEinheitText(e) { return e === 'kn' ? 'kn' : 'km/h'; }

  /* Kurzer Block auf der Seite der Aktivität */
  function routeKurzBlock(ra, id, storniert) {
    var r = ra && ra.ok ? ra.route : null;
    var teile = [h('h2', { text: 'Route und Wetter' })];
    if (r) {
      teile.push(h('p', null, h('strong', { text: r.werte.bezeichnung }), h('span', { class: 'frist-info', text: ' ' + streckeText(r.laengeKm, ra.aktivitaet.welt) + (r.fahrplan.ok ? ', Fahrzeit ' + MM.Routen.dauerText(r.fahrplan.dauerMin) : ', noch keine Geschwindigkeit') })));
    } else teile.push(h('p', { class: 'leer-text', text: 'Noch keine Route. Lies eine Routendatei ein (GPX, KML oder GeoJSON), dann rechnet die App Fahrzeit und Ankunftszeit und holt das Wetter.' }));
    teile.push(h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: '#/aktivitaet/' + enc(id) + '/route', text: r ? 'Route und Wetter öffnen' : (storniert ? 'Ansehen' : 'Route einlesen') })));
    return h('section', { class: 'bereich', 'aria-label': 'Route und Wetter' }, teile);
  }

  function wetterKarte(z, s, abfahrtMs) {
    var e = windEinheitText(s.windEinheit), w = z.wetter, m = z.meer, zeilen = [];
    var kopfText = z.nr + ' · ' + (z.name || 'Punkt') + ' · ' + MM.Routen.sekText(z.etaMs / 1000, abfahrtMs) + ' Uhr · km ' + MM.Hilfen.zahl(z.km);
    if (w) {
      zeilen.push('Himmel: ' + (w.himmel || 'unbekannt') + (w.temperatur !== null ? ', ' + MM.Hilfen.zahl(w.temperatur) + ' °C' : ''));
      if (w.wind !== null) zeilen.push('Wind: ' + w.wind + ' ' + e + (w.windRichtung !== null ? ' aus ' + MM.Routen.himmelsrichtung(w.windRichtung) : '') + (w.boeen !== null ? ', Böen ' + w.boeen + ' ' + e : ''));
      if (w.regenMm !== null || w.regenWahrscheinlichkeit !== null) zeilen.push('Regen: ' + (w.regenMm !== null ? MM.Hilfen.zahl(w.regenMm) + ' mm' : '') + (w.regenWahrscheinlichkeit !== null ? ', Wahrscheinlichkeit ' + w.regenWahrscheinlichkeit + ' %' : ''));
    } else zeilen.push('Für diese Zeit liegen keine Wetterdaten vor.');
    if (s.mitMeer) {
      if (m) {
        if (m.welle !== null) zeilen.push('Welle: ' + MM.Hilfen.zahl(m.welle) + ' m' + (m.wellenRichtung !== null ? ' aus ' + MM.Routen.himmelsrichtung(m.wellenRichtung) : '') + (m.wellenPeriode !== null ? ', Periode ' + m.wellenPeriode + ' s' : ''));
        if (m.wasserstand !== null) zeilen.push('Wasserstand (Modell): ' + MM.Hilfen.zahl(m.wasserstand) + ' m' + (m.trend ? ', ' + m.trend : ''));
      } else zeilen.push('Wellen und Wasserstand: für diesen Punkt liefert das Modell nichts.');
      if (z.tide) {
        var g = [z.tide.hoch, z.tide.niedrig].filter(Boolean).sort(function (a, b) { return a.sek - b.sek; });
        g.forEach(function (x) { zeilen.push((x.art === 'hoch' ? 'Hochwasser ' : 'Niedrigwasser ') + MM.Routen.sekText(x.sek, abfahrtMs) + ' Uhr (' + MM.Hilfen.zahl(x.hoehe) + ' m)'); });
      }
    }
    return h('li', { class: 'rp-punkt' }, h('strong', { text: kopfText }), zeilen.map(function (t) { return h('span', { class: 'frist-info rp-zeile', text: t }); }));
  }

  function seiteRoute(id) {
    var versatz = routeVersatz[id] || 0;
    return Promise.all([daten.routeAnsicht(id), daten.wetterStand(id, versatz)]).then(function (res) {
      var ra = res[0], ws = res[1];
      if (!ra.ok) return nichtGefunden('Aktivität nicht gefunden');
      var akt = ra.aktivitaet, r = ra.route, welt = akt.welt, wasser = welt === 'wasser';
      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [akt.name, '#/aktivitaet/' + enc(id)], ['Route und Wetter']]),
        h('h1', { text: 'Route und Wetter' })];
      if (r) inhalt.push(h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf', href: '#/aktivitaet/' + enc(id) + '/karte', text: 'Karte ansehen' }), h('a', { class: 'knopf leise', href: '#/aktivitaet/' + enc(id) + '/karte/offline', text: 'Offline-Karte holen' })));
      var fehlerP = h('p', { class: 'fehler', role: 'alert' });

      /* Datei einlesen */
      var datei = h('input', { type: 'file', id: 'rt-datei', accept: '.gpx,.kml,.geojson,.json,application/gpx+xml,application/vnd.google-earth.kml+xml,application/geo+json,application/json', onchange: function () {
        var f = datei.files && datei.files[0];
        if (!f) return;
        if (f.size > 20 * 1024 * 1024) { fehlerP.textContent = 'Die Datei ist zu groß (über 20 MB).'; return; }
        var lesen = typeof f.text === 'function' ? f.text() : new Promise(function (ok, nein) { var fr = new global.FileReader(); fr.onload = function () { ok(fr.result); }; fr.onerror = nein; fr.readAsText(f); });
        lesen.then(function (text) { return daten.routeImportieren(id, text, f.name); }).then(function (x) {
          if (!x.ok) { fehlerP.textContent = (x.fehler && (x.fehler.datei || x.fehler.allgemein)) || 'Das hat nicht geklappt.'; return null; }
          routeVersatz[id] = 0;
          meldung = 'Route „' + x.name + '“ übernommen: ' + x.punkte + ' Punkte, ' + kmText(x.laengeKm) + '.' + (x.hinweise.length ? ' ' + x.hinweise.join(' ') : '') + ' Trage jetzt die Reisegeschwindigkeit ein.';
          return zeige();
        }).catch(fehlerSeite);
      } });
      var einlesen = h('section', { class: 'bereich', 'aria-label': 'Routendatei einlesen' },
        h('h2', { text: r ? 'Andere Route einlesen' : 'Route einlesen' }),
        h('p', { class: 'hilfe', text: 'MobiMory plant keine Route und navigiert nicht. Du liest eine Route ein, die du in deiner Navigations- oder Karten-App gemacht hast (Dateien .gpx, .kml oder .geojson). Eine frühere Route bleibt erhalten.' }),
        akt.storniert ? h('p', { class: 'hinweis', text: 'Die Aktivität ist storniert. Es kann keine Route eingelesen werden.' }) : h('div', { class: 'feld' }, h('label', { for: 'rt-datei', text: 'Datei auswählen' }), h('div', { class: 'eingabe' }, datei)),
        fehlerP);
      if (!r) { inhalt.push(einlesen); }
      else {
        var w = r.werte;
        /* Angaben zur Route */
        var fel = {};
        function feld(key, label, el, hilfe) { fel[key] = h('span', { class: 'fehler', role: 'alert' }); return h('div', { class: 'feld' }, h('label', { for: 'rt-' + key, text: label }), h('div', { class: 'eingabe' }, el), hilfe ? h('p', { class: 'hilfe', text: hilfe }) : null, fel[key]); }
        var iName = h('input', { type: 'text', id: 'rt-bezeichnung', value: w.bezeichnung || '' });
        var iGes = h('input', { type: 'text', id: 'rt-geschwindigkeit', inputmode: 'decimal', value: w.geschwindigkeit === null || w.geschwindigkeit === undefined ? '' : String(w.geschwindigkeit).replace('.', ',') });
        var iEinh = h('select', { id: 'rt-einheit' }, MM.Routen.EINHEITEN.map(function (o) { return h('option', { value: o.wert, text: o.label }); })); iEinh.value = w.einheit || (wasser ? 'kn' : 'kmh');
        var iDat = h('input', { type: 'date', id: 'rt-abfahrtDatum', value: w.abfahrtDatum || '' });
        var iZeit = h('input', { type: 'time', id: 'rt-abfahrtZeit', value: w.abfahrtZeit || '' });
        var iNotiz = h('input', { type: 'text', id: 'rt-notiz', value: w.notiz || '' });
        /* Abstand der Wetterpunkte: Voreinstellung oder eigene Regel (Entfernung in km oder sm, oder Fahrzeit in Stunden) */
        var std = MM.Routen.wetterRegelStandard(wasser ? 'wasser' : 'land');
        var iWArt = h('select', { id: 'rt-wetterArt' }, h('option', { value: '', text: 'Voreinstellung (' + MM.Routen.regelText(std) + ')' }),
          MM.Routen.WETTER_ARTEN.map(function (o) { return h('option', { value: o.wert, text: o.label }); }));
        iWArt.value = r.regelEigene ? w.wetterArt : '';
        var iWAbst = h('input', { type: 'text', id: 'rt-wetterAbstand', inputmode: 'decimal', value: r.regelEigene ? String(w.wetterAbstand).replace('.', ',') : '' });
        var iWEinh = h('select', { id: 'rt-wetterEinheit' });
        function einheitenFuellen() {
          var zeit = iWArt.value === 'zeit', vorher = iWEinh.value;
          while (iWEinh.firstChild) iWEinh.removeChild(iWEinh.firstChild);
          (zeit ? [{ wert: 'h', label: 'Stunden' }] : [{ wert: 'km', label: 'km' }, { wert: 'sm', label: 'sm' }]).forEach(function (o) { iWEinh.appendChild(h('option', { value: o.wert, text: o.label })); });
          iWEinh.value = zeit ? 'h' : (vorher === 'sm' ? 'sm' : (vorher === 'km' ? 'km' : (wasser ? 'sm' : 'km')));
          iWAbst.disabled = iWEinh.disabled = iWArt.value === '';
        }
        einheitenFuellen();
        if (r.regelEigene && w.wetterEinheit) iWEinh.value = w.wetterEinheit;
        iWArt.addEventListener('change', einheitenFuellen);
        var speichern = h('button', { class: 'knopf', type: 'button', text: 'Angaben speichern', onclick: function () {
          Object.keys(fel).forEach(function (k) { fel[k].textContent = ''; });
          daten.routeAendern(r.id, { bezeichnung: iName.value, geschwindigkeit: iGes.value, einheit: iEinh.value, abfahrtDatum: iDat.value, abfahrtZeit: iZeit.value,
            wetterArt: iWArt.value, wetterAbstand: iWArt.value ? iWAbst.value : '', wetterEinheit: iWArt.value ? iWEinh.value : '', notiz: iNotiz.value }).then(function (x) {
            if (!x.ok) { Object.keys(x.fehler || {}).forEach(function (k) { if (fel[k]) fel[k].textContent = x.fehler[k]; else fehlerP.textContent = x.fehler[k]; }); return null; }
            meldung = x.geaendert ? 'Gespeichert.' : 'Nichts geändert.';
            return zeige();
          }).catch(fehlerSeite);
        } });
        var kopf = h('section', { class: 'bereich', 'aria-label': 'Route' },
          h('h2', { text: r.werte.bezeichnung }),
          h('dl', { class: 'daten stapel' },
            h('dt', { text: 'Länge' }), h('dd', { text: streckeText(r.laengeKm, welt) }),
            h('dt', { text: 'Punkte' }), h('dd', { text: r.punkte.length + (r.anzahlGelesen > r.punkte.length ? ' (aus ' + r.anzahlGelesen + ' gelesenen, die Länge ist unverändert)' : '') }),
            h('dt', { text: 'Datei' }), h('dd', { text: (r.dateiName || 'unbekannt') + ' (' + r.format.toUpperCase() + ')' }),
            r.fahrplan.ok ? [h('dt', { text: 'Fahrzeit' }), h('dd', { text: MM.Routen.dauerText(r.fahrplan.dauerMin) + (r.fahrplan.ankunft ? ', Ankunft ' + MM.Routen.sekText(MM.Routen.zeitMs(r.fahrplan.ankunft) / 1000, MM.Routen.zeitMs(r.fahrplan.abfahrt)) + ' Uhr' : '') })] : null,
            akt.geplanteStrecke !== null ? [h('dt', { text: 'Geplante Strecke der Aktivität' }), h('dd', { text: kmText(akt.geplanteStrecke) })] : null),
          h('div', { class: 'formular' },
            feld('bezeichnung', 'Name der Route', iName),
            feld('geschwindigkeit', 'Reisegeschwindigkeit', iGes, 'Gleichbleibend gerechnet. Strömung, Wind, Schleusen und Pausen kennt die App nicht.'),
            feld('einheit', 'Einheit', iEinh),
            feld('abfahrtDatum', 'Abfahrt (Datum)', iDat), feld('abfahrtZeit', 'Abfahrt (Uhrzeit)', iZeit, 'Ortszeit. Ohne Datum und Uhrzeit gibt es keine Ankunftszeiten und kein Wetter.'),
            feld('wetterArt', 'Abstand der Wetterpunkte', iWArt, 'Gilt jetzt: ' + MM.Routen.regelText(r.wetterRegel) + (r.regelEigene ? '' : ' (Voreinstellung)') + '. Start, Ziel und benannte Wegpunkte bekommen immer Wetter. Die Route selbst ändert sich dadurch nicht.'),
            feld('wetterAbstand', 'Abstand', iWAbst), feld('wetterEinheit', 'Einheit des Abstands', iWEinh),
            feld('notiz', 'Notiz', iNotiz), h('p', null, speichern)),
          h('p', { class: 'knopfzeile' },
            h('button', { class: 'knopf leise', type: 'button', text: 'Als GPX-Datei sichern', onclick: function () { daten.routeGpx(r.id).then(function (g) { if (g.ok) dateiSpeichern(g.text, g.name, 'application/gpx+xml'); }).catch(fehlerSeite); } }),
            !akt.storniert && akt.geplanteStrecke !== Math.round(r.laengeKm * 10) / 10 ? h('button', { class: 'knopf leise', type: 'button', text: 'Länge als geplante Strecke übernehmen', onclick: function () {
              daten.routeAlsGeplanteStrecke(id, r.id).then(function (x) { meldung = x.ok ? 'Die geplante Strecke ist jetzt ' + kmText(x.km) + '.' : ((x.fehler && x.fehler.allgemein) || 'Das hat nicht geklappt.'); return zeige(); }).catch(fehlerSeite);
            } }) : null));
        inhalt.push(kopf);

        /* Fahrplan */
        if (r.fahrplan.ok && r.messpunkte.length) {
          var abMs = r.fahrplan.abfahrt ? MM.Routen.zeitMs(r.fahrplan.abfahrt) : null;
          inhalt.push(h('section', { class: 'bereich', 'aria-label': 'Fahrplan' }, h('h2', { text: 'Fahrplan' }),
            h('ul', { class: 'fristen' }, r.messpunkte.map(function (m) {
              return h('li', { class: 'rp-punkt' }, h('strong', { text: m.nr + ' · ' + (m.name || 'Punkt') }),
                h('span', { class: 'frist-info rp-zeile', text: 'km ' + MM.Hilfen.zahl(m.km) + ', nach ' + MM.Routen.dauerText(m.minuten) + (abMs !== null ? ', Ankunft ' + MM.Routen.sekText((abMs + m.minuten * 60000) / 1000, abMs) + ' Uhr' : '') }));
            }))));
        }

        /* Wetter */
        var abruf = h('button', { class: 'knopf', type: 'button', text: 'Wetter' + (wasser ? ' und Tide' : '') + ' abrufen', onclick: function () {
          abruf.disabled = true; abruf.textContent = 'Wird geholt …';
          daten.wetterAbrufen(id).then(function (x) {
            if (x.ok) meldung = 'Wetter für ' + x.punkte + ' Punkte geholt.' + (x.ohneWetter ? ' Für ' + x.ohneWetter + ' Punkte gab es kein Wetter.' : '') + (x.ohneMeer ? ' Wellen und Wasserstand gab es für ' + x.ohneMeer + ' Punkte nicht, dort liefert das Modell nichts.' : '');
            else meldung = (x.fehler && (x.fehler.allgemein || x.fehler.geschwindigkeit || x.fehler.abfahrtDatum)) || 'Das hat nicht geklappt.';
            return zeige();
          }).catch(fehlerSeite);
        } });
        var wb = [h('h2', { text: wasser ? 'Wetter, Wellen und Tide' : 'Wetter' }), h('p', { class: 'knopfzeile' }, abruf),
          global.navigator && global.navigator.onLine === false ? h('p', { class: 'hinweis', text: 'Dieses Gerät meldet gerade kein Netz. Das Abrufen braucht Netz, ein früher geholter Stand bleibt sichtbar.' }) : null];
        if (ws.ok) {
          var abfMs = MM.Routen.zeitMs(ws.abfahrt);
          wb.push(h('p', { class: 'hinweis', text: 'Geholt am ' + jetztText(MM.Routen.zeitIso(new Date(ws.abgerufenAm).getTime())) + ' für Abfahrt ' + jetztText(ws.abfahrt) + '. Wind in ' + windEinheitText(ws.windEinheit) + '.' }));
          if (!ws.aktuell) wb.push(h('p', { class: 'fehlerkasten', text: 'Dieser Stand gehört zu einer früheren Abfahrt, Geschwindigkeit, Route oder einem anderen Abstand der Wetterpunkte. Hole das Wetter neu, sonst stimmen die Ankunftszeiten nicht.' }));
          /* Vergleich */
          var best = null;
          ws.vergleich.forEach(function (v) { var b = v.schwerste.boeen ? v.schwerste.boeen.wert : null; if (b !== null && (best === null || b < best)) best = b; });
          wb.push(h('h3', { text: 'Abfahrt früher oder später' }),
            h('ul', { class: 'fristen' }, ws.vergleich.map(function (v) {
              var s = v.schwerste, aktiv = v.versatzMin === versatz, txt = [];
              if (s.boeen) txt.push('Böen bis ' + s.boeen.wert + ' ' + windEinheitText(ws.windEinheit) + ' (Punkt ' + s.boeen.nr + ')');
              if (s.welle) txt.push('Welle bis ' + MM.Hilfen.zahl(s.welle.wert) + ' m');
              if (s.regen) txt.push('Regen bis ' + s.regen.wert + ' %');
              return h('li', { class: 'rp-punkt' + (aktiv ? ' rp-aktiv' : '') },
                h('strong', { text: MM.Routen.sekText((abfMs + v.versatzMin * 60000) / 1000, abfMs) + ' Uhr (' + versatzText(v.versatzMin) + ')' + (s.boeen && s.boeen.wert === best ? ' · wenigste Böen' : '') }),
                h('span', { class: 'frist-info rp-zeile', text: txt.join(', ') || 'keine Werte' }),
                aktiv ? h('span', { class: 'chip-status status-ok', text: 'unten angezeigt' }) : h('button', { class: 'knopf leise klein', type: 'button', text: 'Unten anzeigen', onclick: function () { routeVersatz[id] = v.versatzMin; zeige().catch(fehlerSeite); } }));
            })));
          wb.push(h('h3', { text: 'Punkte der Route (Abfahrt ' + versatzText(versatz) + ')' }), h('ul', { class: 'fristen' }, ws.zeilen.map(function (z) { return wetterKarte(z, ws, abfMs + versatz * 60000); })));
        } else wb.push(h('p', { class: 'leer-text', text: r.fahrplan.ok && w.abfahrtDatum && w.abfahrtZeit ? 'Noch kein Wetter geholt.' : 'Für das Wetter brauche ich Reisegeschwindigkeit, Datum und Uhrzeit der Abfahrt. Trage sie oben ein und speichere.' }));
        wb.push(h('details', { class: 'ausgebaut' }, h('summary', { text: 'Was diese Zahlen bedeuten' }),
          h('ul', { class: 'gruende' },
            h('li', { text: 'Wetter, Wellen und Wasserstand sind Prognosen und Modellwerte von Open-Meteo, keine Messwerte und keine Garantie. MobiMory navigiert nicht und trifft keine Aussage, ob eine Fahrt sicher ist. Das entscheidet der ' + MM.Aktivitaeten.verantwortlichenName(welt) + '.' }),
            h('li', { text: 'Die Ankunftszeiten rechnen mit gleichbleibender Geschwindigkeit entlang der Route, ohne Strömung, Schleusen und Pausen. Alle Zeiten sind Ortszeit dieses Geräts.' }),
            wasser ? h('li', { text: 'Der Wasserstand ist ein Modellwert pro Stunde. Hoch- und Niedrigwasser sind daraus gerechnet und können um etwa eine halbe Stunde abweichen, in Häfen, Flussmündungen und Küstennähe auch mehr. Vor einer Ein- oder Ausfahrt gelten die amtlichen Gezeitentafeln. Auf Meeren ohne nennenswerte Gezeiten zeigt die App keine Hoch- und Niedrigwasser.' }) : null,
            h('li', { text: 'Eine Prognose gibt es für die nächsten 16 Tage, Wellen für 8 Tage.' }))));
        inhalt.push(h('section', { class: 'bereich', 'aria-label': 'Wetter' }, wb));
        if (ra.fruehere.length) inhalt.push(h('details', { class: 'ausgebaut' }, h('summary', { text: 'Frühere Routen (' + ra.fruehere.length + ')' }), h('ul', { class: 'fristen' }, ra.fruehere.map(function (f) {
          return h('li', { class: 'rp-punkt' }, h('strong', { text: f.name }), h('span', { class: 'frist-info rp-zeile', text: kmText(f.laengeKm) + ', ' + f.format.toUpperCase() }),
            h('button', { class: 'knopf leise klein', type: 'button', text: 'Diese Route verwenden', onclick: function () { daten.routeVerwenden(id, f.id).then(function () { routeVersatz[id] = 0; return zeige(); }).catch(fehlerSeite); } }));
        }))));
        if (!akt.storniert) inhalt.push(einlesen);
      }
      seite('Route und Wetter', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/aktivitaet/' + enc(id), text: 'Zurück zur Aktivität' })));
    });
  }

  /* ---------- Formular: Aktivität planen / ändern ---------- */
  /* modus 'neu' (id leer oder Fahrzeug) oder 'aendern' (id = Aktivität) */
  function aktivitaetFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = Promise.all([daten.aktivitaetKontext(), neu ? Promise.resolve(null) : daten.aktivitaetLaden(id)]);
    return laden.then(function (r) {
      var ctx = r[0], a = r[1];
      if (!neu && !a) return nichtGefunden('Aktivität nicht gefunden');
      var titel = neu ? 'Aktivität planen' : 'Aktivität ändern';
      var weg = [['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten']];
      if (!neu) weg.push([a.aktuell.werte.bezeichnung, '#/aktivitaet/' + encodeURIComponent(id)]);
      weg.push([titel]);
      var start = neu ? { bezeichnung: '', artId: '', fahrzeugId: id || '', verantwortlichId: '', tierIds: [], startOrtId: '', zielOrtId: '', zwischenzielIds: [] } : JSON.parse(JSON.stringify(a.aktuell.werte));
      if (!neu) { start.zwischenzielIds = start.zwischenzielIds || []; start.startOrtId = start.startOrtId || ''; start.zielOrtId = start.zielOrtId || ''; }
      /* Reiseplan (seit 2.0.28): Orte aus der Orte-Liste. Ausgeblendete bleiben nur, wenn sie schon gewählt sind. */
      var gewaehltePlan = [start.startOrtId, start.zielOrtId].concat(start.zwischenzielIds || []);
      var planOrtOpt = (ctx.orte || []).filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja' || gewaehltePlan.indexOf(x.objekt.id) >= 0; })
        .map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });
      var artOptionen = ctx.arten.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja' || (!neu && x.objekt.id === a.aktuell.werte.artId); })
        .map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });
      var fzOptionen = ctx.fahrzeuge.map(function (x) { return { wert: x.fahrzeug.id, label: x.aktuell.werte.bezeichnung }; });
      var personOptionen = ctx.personen.map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });
      var gebietOptionen = ctx.gebiete.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja' || (!neu && x.objekt.id === a.aktuell.werte.gebietId); })
        .map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });
      var tierOptionen = ctx.tiere.map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });

      var voraussetzungen = [];
      if (!artOptionen.length) voraussetzungen.push(h('p', null, 'Es gibt noch keine Art von Aktivität. ',
        h('button', { class: 'knopf', type: 'button', text: 'Vorschläge übernehmen (Urlaub, Törn, Ausfahrt, Wasserski, Segeln, Rallye)',
          onclick: function () { daten.aktivitaetsartenAusVorschlaegen().then(function () { return zeige(); }).catch(fehlerSeite); } })));
      if (!fzOptionen.length) voraussetzungen.push(h('p', null, 'Es gibt noch kein Fahrzeug. ', h('a', { class: 'knopf leise', href: '#/neu', text: 'Fahrzeug anlegen' })));
      if (neu && !personOptionen.length) voraussetzungen.push(h('p', null, 'Es gibt noch keine Person. ', h('a', { class: 'knopf leise', href: '#/personen/neu', text: 'Person anlegen' })));

      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: neu ? '#/aktivitaeten' : '#/aktivitaet/' + encodeURIComponent(id), werte: start, neuzeichnenBei: ['fahrzeugId'],
        nachAenderung: function (key, z) {
          /* Neue Aktivität: passt die gewählte Art nicht zum neuen Fahrzeug, muss sie neu gewählt werden. Beim Ändern bleibt sie. */
          if (key !== 'fahrzeugId' || !neu) return;
          var passt = aktivitaetsartOptionen(ctx, z.werte.fahrzeugId, null).some(function (o) { return o.wert === z.werte.artId; });
          if (!passt) z.werte.artId = '';
        },
        intro: voraussetzungen.length ? h('div', { class: 'leer-hinweis' }, voraussetzungen)
          : (neu ? h('p', { text: 'Nenne Name, Art, Fahrzeug, Zeitraum und wer verantwortlich ist. Alles Weitere kannst du später ergänzen. Die Besatzung fügst du danach hinzu.' }) : null),
        gruppen: function (z) {
          var fz = ctx.fahrzeuge.filter(function (x) { return x.fahrzeug.id === z.werte.fahrzeugId; })[0];
          var welt = fz ? MM.Fahrzeugarten.art(fz.fahrzeug.art).welt : 'land';
          var verantwortlich = MM.Aktivitaeten.verantwortlichenName(fz ? welt : null);
          var g = [{ titel: null, felder: [
            { key: 'bezeichnung', label: 'Name', typ: 'text', hilfe: 'Zum Beispiel „Sommertörn Kroatien“' },
            { key: 'artId', label: 'Art', typ: 'auswahl', optionen: aktivitaetsartOptionen(ctx, z.werte.fahrzeugId, neu ? null : a.aktuell.werte.artId), leerText: '– bitte wählen –',
              hilfe: fz ? 'Es stehen nur Arten zur Wahl, die zum Fahrzeug passen. Die Zuordnung änderst du unter Arten von Aktivitäten.' : 'Wähle auch das Fahrzeug: Dann stehen nur Arten zur Wahl, die zum Fahrzeug passen.' },
            { key: 'fahrzeugId', label: 'Fahrzeug', typ: 'auswahl', optionen: fzOptionen, leerText: '– bitte wählen –' }
          ] }, { titel: 'Zeitraum', felder: [
            { key: 'vonDatum', label: 'Von (Datum)', typ: 'datum' }, { key: 'vonZeit', label: 'Von (Uhrzeit)', typ: 'zeit', hilfe: 'Freiwillig. Ohne Uhrzeit gilt der Tagesbeginn.' },
            { key: 'bisDatum', label: 'Bis (Datum)', typ: 'datum' }, { key: 'bisZeit', label: 'Bis (Uhrzeit)', typ: 'zeit', hilfe: 'Freiwillig. Ohne Uhrzeit gilt das Tagesende.' }
          ] }];
          if (neu) g.push({ titel: 'Verantwortlich', felder: [{ key: 'verantwortlichId', label: verantwortlich, typ: 'auswahl', optionen: personOptionen, leerText: '– bitte wählen –',
            hilfe: 'Zu jedem Zeitpunkt ist genau eine Person verantwortlich. Stellvertreter fügst du danach hinzu.' }] });
          g.push(planOrtOpt.length ? { titel: 'Reiseplan (freiwillig)',
            hinweis: 'Start, Ziel und Zwischenziele sind Orte aus deiner Orte-Liste. Bei einer Ankunft zeigt die App, ob es dein geplantes Ziel war. Route, Fahrzeit und Ankunftszeit findest du auf der Seite „Route und Wetter“ der Aktivität.',
            felder: [{ key: 'startOrtId', label: 'Start', typ: 'auswahl', optionen: planOrtOpt, leerText: '– keiner –' },
              { key: 'zielOrtId', label: 'Ziel', typ: 'auswahl', optionen: planOrtOpt, leerText: '– keines –' },
              { key: 'zwischenzielIds', label: 'Zwischenziele', typ: 'mehrfach', optionen: planOrtOpt }] }
            : { titel: 'Reiseplan (freiwillig)', hinweis: 'Es gibt noch keinen Ort. Lege unter Stammdaten › Orte zum Beispiel deinen Heimathafen und dein Ziel an, dann kannst du hier Start, Ziel und Zwischenziele wählen.', felder: [] });
          g.push({ titel: 'Weiteres', felder: [
            { key: 'gebietId', label: 'Gebiet', typ: 'auswahl', optionen: gebietOptionen, leerText: '– keines –',
              hilfe: gebietOptionen.length ? 'Freiwillig. Die Regeln des Gebiets gelten bei der Prüfung. Gebiete und Regeln legst du unter Stammdaten › Gebiete an.' : 'Freiwillig. Es gibt noch kein Gebiet. Lege unter Stammdaten › Gebiete eines an, damit die App seine Regeln prüfen kann.' }
          ].concat(!neu && start.gebiet ? [{ key: 'gebiet', label: 'Gebiet als Text (aus einer früheren Version)', typ: 'text', hilfe: 'Der Text wird nicht geprüft. Wähle oben ein Gebiet aus der Liste und leere dieses Feld.' }] : []).concat([
            { key: 'geplanteStrecke', label: 'Geplante Strecke', typ: 'zahl', einheit: 'km', hilfe: 'Freiwillig. Damit rechnet die App Zähler-Fristen bis zum Ende.' },
            { key: 'geplanteStunden', label: 'Geplante Betriebsstunden', typ: 'zahl', einheit: 'h', hilfe: 'Freiwillig, für Fristen nach Betriebsstunden.' }
          ]).concat(tierOptionen.length ? [{ key: 'tierIds', label: 'Mitreisende Tiere', typ: 'mehrfach', optionen: tierOptionen }] : [])
            .concat([{ key: 'notiz', label: 'Notiz', typ: 'text' }]) });
          return g;
        },
        speichern: function (w) { return neu ? daten.aktivitaetAnlegen(w) : daten.aktivitaetAendern(id, w); },
        meldung: function (r) { return neu ? 'Aktivität angelegt. Die Prüfung steht unten.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/aktivitaet/' + encodeURIComponent(r.id); }
      });
    });
  }

  /* ---------- Logbuch jetzt starten, ohne Planung (seit 2.0.15) ---------- */
  function logbuchStartFormular(fzVorgabe) {
    return daten.aktivitaetKontext().then(function (ctx) {
      var fzOptionen = ctx.fahrzeuge.map(function (x) { return { wert: x.fahrzeug.id, label: x.aktuell.werte.bezeichnung }; });
      var personOptionen = ctx.personen.map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });
      var start = { fahrzeugId: fzVorgabe || (fzOptionen.length === 1 ? fzOptionen[0].wert : ''), verantwortlichId: personOptionen.length === 1 ? personOptionen[0].wert : '',
        stellvertreterIds: [], crewIds: [], bisDatum: daten.heute() };
      start.artId = start.fahrzeugId ? vorgabeAktivitaetsart(ctx, start.fahrzeugId) : '';
      var voraus = [];
      if (!fzOptionen.length) voraus.push(h('p', null, 'Es gibt noch kein Fahrzeug. ', h('a', { class: 'knopf leise', href: '#/neu', text: 'Fahrzeug anlegen' })));
      if (!personOptionen.length) voraus.push(h('p', null, 'Es gibt noch keine Person. ', h('a', { class: 'knopf leise', href: '#/personen/neu', text: 'Person anlegen' })));
      einfachFormular({
        titel: 'Logbuch jetzt starten', zurueck: '#/aktivitaeten', werte: start, neuzeichnenBei: ['fahrzeugId'],
        nachAenderung: function (key, z) {
          if (key !== 'fahrzeugId') return;
          var passt = aktivitaetsartOptionen(ctx, z.werte.fahrzeugId, null).some(function (o) { return o.wert === z.werte.artId; });
          if (!passt) z.werte.artId = vorgabeAktivitaetsart(ctx, z.werte.fahrzeugId);
        },
        krumen: krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], ['Logbuch jetzt starten']]),
        intro: voraus.length ? h('div', { class: 'leer-hinweis' }, voraus)
          : h('p', { text: 'Du fährst ohne Planung los. Beginn ist jetzt. Wähle Fahrzeug, Art der Aktivität, wer verantwortlich ist und wer dabei ist. Danach läuft das Logbuch wie bei jeder Aktivität, auch die Prüfung.' }),
        gruppen: function (z) {
          var fz = ctx.fahrzeuge.filter(function (x) { return x.fahrzeug.id === z.werte.fahrzeugId; })[0];
          var welt = fz ? MM.Fahrzeugarten.art(fz.fahrzeug.art).welt : null;
          var verantwortlich = MM.Aktivitaeten.verantwortlichenName(welt);
          var artOpt = aktivitaetsartOptionen(ctx, z.werte.fahrzeugId, null);
          var artHilfe = !z.werte.fahrzeugId ? 'Wähle zuerst das Fahrzeug. Dann stehen nur Arten zur Wahl, die zum Fahrzeug passen.'
            : (artOpt.length ? 'Es stehen nur Arten zur Wahl, die zum Fahrzeug passen. Die Zuordnung änderst du unter Arten von Aktivitäten.'
              : 'Für dieses Fahrzeug gilt noch keine Art von Aktivität. Lege sie unter Arten von Aktivitäten fest.');
          return [{ titel: null, felder: [{ key: 'fahrzeugId', label: 'Fahrzeug', typ: 'auswahl', optionen: fzOptionen, leerText: '– bitte wählen –' },
              { key: 'artId', label: 'Aktivität', typ: 'auswahl', optionen: artOpt, leerText: '– bitte wählen –', hilfe: artHilfe }] },
            { titel: 'Verantwortlich und Besatzung', felder: [{ key: 'verantwortlichId', label: verantwortlich, typ: 'auswahl', optionen: personOptionen, leerText: '– bitte wählen –' }]
              .concat(personOptionen.length > 1 ? [
                { key: 'stellvertreterIds', label: 'Stellvertreter', typ: 'mehrfach', optionen: personOptionen, hilfe: 'Freiwillig. Wer übernehmen kann, wenn die verantwortliche Person ausfällt.' },
                { key: 'crewIds', label: 'Crew', typ: 'mehrfach', optionen: personOptionen, hilfe: 'Freiwillig. Wer sonst dabei ist.' }] : []) },
            { titel: 'Ende', felder: [{ key: 'bisDatum', label: 'Voraussichtlich bis (Datum)', typ: 'datum', hilfe: 'Vorgabe ist heute. Dauert es länger, trage das Datum ein. Du kannst es später unter „Angaben ändern“ anpassen.' }] }];
        },
        speichern: function (w) { return daten.logbuchSofortStarten(w); },
        meldung: function () { return 'Das Logbuch läuft. Du bist im Cockpit.'; },
        danach: function (r) { return '#/aktivitaet/' + encodeURIComponent(r.id); }
      });
    });
  }

  function stornoFormular(id) {
    return daten.aktivitaetLaden(id).then(function (a) {
      if (!a) return nichtGefunden('Aktivität nicht gefunden');
      var w = a.aktuell.werte;
      einfachFormular({
        titel: 'Aktivität stornieren', zurueck: '#/aktivitaet/' + encodeURIComponent(id), werte: { grund: '' },
        krumen: krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [w.bezeichnung, '#/aktivitaet/' + encodeURIComponent(id)], ['Stornieren']]),
        intro: h('p', { text: 'Die Aktivität wird nicht gelöscht. Sie bekommt den Status „storniert“ und bleibt mit allem Drumherum erhalten. Du kannst sie später wiederherstellen.' }),
        gruppen: function () { return [{ titel: null, felder: [{ key: 'grund', label: 'Grund', typ: 'text', hilfe: 'Freiwillig, zum Beispiel „Wetter“ oder „Fahrzeug defekt“' }] }]; },
        speichern: function (v) { return daten.aktivitaetStornieren(id, v.grund).then(function (r) { r.id = id; return r; }); },
        meldung: function () { return 'Die Aktivität ist storniert.'; },
        danach: function () { return '#/aktivitaet/' + encodeURIComponent(id); }
      });
    });
  }

  /* ---------- Besatzung und Verantwortung ---------- */
  var ROLLEN_WAHL = [{ wert: 'stellvertreter', label: 'Stellvertreter' }, { wert: 'crew', label: 'Crew' }];

  function besatzungFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = neu ? daten.aktivitaetLaden(id) : daten.speicher.holen('besatzung', id).then(function (b) { return b ? daten.aktivitaetLaden(b.aktivitaetId).then(function (a) { return a ? { a: a, b: b } : null; }) : null; });
    return Promise.all([laden, daten.personenListe()]).then(function (r) {
      var a = neu ? r[0] : (r[0] && r[0].a), personen = r[1];
      if (!a) return nichtGefunden('Nicht gefunden');
      var aId = a.aktivitaet.id, w = a.aktuell.werte;
      var eintrag = neu ? null : a.besatzung.concat(a.entfernte).filter(function (x) { return x.besatzung.id === id; })[0];
      if (!neu && !eintrag) return nichtGefunden('Nicht gefunden');
      var titel = neu ? 'Person hinzufügen' : 'Besatzung ändern';
      var weg = [['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [w.bezeichnung, '#/aktivitaet/' + encodeURIComponent(aId)], [titel]];
      var verantwortlicheRolle = !neu && eintrag.aktuell.werte.rolle === 'verantwortlich';
      var belegt = a.besatzung.map(function (b) { return b.person.id; });
      var frei = personen.filter(function (p) { return belegt.indexOf(p.objekt.id) < 0; }).map(function (p) { return { wert: p.objekt.id, label: p.aktuell.werte.bezeichnung }; });
      var start = neu ? { personId: '', rolle: 'crew' } : JSON.parse(JSON.stringify(eintrag.aktuell.werte));
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: '#/aktivitaet/' + encodeURIComponent(aId), werte: start,
        intro: neu ? (frei.length ? h('p', { text: 'Jede Person steht nur einmal in der Besatzung. Die Crew ist beliebig austauschbar. Stellvertreter können später verantwortlich werden.' })
          : h('div', { class: 'leer-hinweis' }, h('p', { text: 'Alle Personen sind schon dabei, oder es gibt noch keine weitere Person.' }), h('p', null, h('a', { class: 'knopf', href: '#/personen/neu', text: 'Person anlegen' }))))
          : h('p', null, h('strong', { text: eintrag.person.name }), verantwortlicheRolle ? ' ist ' + MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt) + '. Die Rolle ändert sich über „Verantwortung wechseln“.' : ''),
        gruppen: function () {
          var felder = [];
          if (neu) felder.push({ key: 'personId', label: 'Person', typ: 'auswahl', optionen: frei, leerText: '– bitte wählen –' });
          if (!verantwortlicheRolle) felder.push({ key: 'rolle', label: 'Rolle', typ: 'auswahl', darstellung: 'wahl', optionen: ROLLEN_WAHL });
          felder.push({ key: 'dabeiVonDatum', label: 'Dabei von (Datum)', typ: 'datum', hilfe: 'Freiwillig, wenn die Person nicht die ganze Zeit dabei ist' });
          felder.push({ key: 'dabeiVonZeit', label: 'Dabei von (Uhrzeit)', typ: 'zeit' });
          felder.push({ key: 'dabeiBisDatum', label: 'Dabei bis (Datum)', typ: 'datum' });
          felder.push({ key: 'dabeiBisZeit', label: 'Dabei bis (Uhrzeit)', typ: 'zeit' });
          if (!neu) felder.push({ key: 'entfernt', label: 'Ist die Person dabei?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Ja, dabei' }, { wert: 'ja', label: 'Nicht mehr dabei' }] });
          return [{ titel: null, felder: felder }];
        },
        speichern: function (v) {
          if (verantwortlicheRolle) v.rolle = 'verantwortlich';
          return neu ? daten.besatzungHinzufuegen(aId, v.personId, v).then(function (r) { r.id = aId; return r; }) : daten.besatzungAendern(id, v).then(function (r) { r.id = aId; return r; });
        },
        meldung: function (r) { return neu ? 'Person hinzugefügt.' : (r.geaendert ? 'Gespeichert.' : 'Es gab keine Änderung.'); },
        danach: function () { return '#/aktivitaet/' + encodeURIComponent(aId); }
      });
    });
  }

  function verantwortungFormular(id) {
    return daten.aktivitaetLaden(id).then(function (a) {
      if (!a) return nichtGefunden('Aktivität nicht gefunden');
      var w = a.aktuell.werte;
      var verantwortlich = MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt);
      var letzte = a.verantwortung[a.verantwortung.length - 1];
      var kandidaten = a.besatzung.filter(function (b) { return (b.aktuell.werte.rolle === 'verantwortlich' || b.aktuell.werte.rolle === 'stellvertreter') && (!letzte || b.person.id !== letzte.personId); })
        .map(function (b) { return { wert: b.person.id, label: b.person.name + ' (' + b.rolleText + ')' }; });
      var jetzt = daten.jetztLokal();
      einfachFormular({
        titel: 'Verantwortung wechseln', zurueck: '#/aktivitaet/' + encodeURIComponent(id),
        werte: { personId: '', abDatum: jetzt.slice(0, 10), abZeit: jetzt.slice(11, 16) },
        krumen: krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [w.bezeichnung, '#/aktivitaet/' + encodeURIComponent(id)], ['Verantwortung wechseln']]),
        intro: kandidaten.length ? h('p', { text: 'Zu jedem Zeitpunkt ist genau eine Person verantwortlich. Der Wechsel wird mit dem Zeitpunkt festgehalten. Wechseln können nur ' + verantwortlich + ' und Stellvertreter.' })
          : h('div', { class: 'leer-hinweis' }, h('p', { text: 'Es gibt keine andere Person, die verantwortlich werden könnte. Füge zuerst einen Stellvertreter hinzu.' }),
            h('p', null, h('a', { class: 'knopf', href: '#/aktivitaet/' + encodeURIComponent(id) + '/besatzung/neu', text: 'Person hinzufügen' }))),
        gruppen: function () {
          if (!kandidaten.length) return [];
          return [{ titel: null, felder: [
            { key: 'personId', label: 'Wer ist ab dann verantwortlich?', typ: 'auswahl', optionen: kandidaten, leerText: '– bitte wählen –' },
            { key: 'abDatum', label: 'Ab (Datum)', typ: 'datum' }, { key: 'abZeit', label: 'Ab (Uhrzeit)', typ: 'zeit' }] }];
        },
        speichern: function (v) { return daten.verantwortungWechseln(id, v.personId, v); },
        meldung: function (r) { return 'Der Wechsel ist festgehalten.' + (r.pruefung ? ' ' + MM.Logbuch.wechselPruefungKurz(r.pruefung) + '. Das ist ein Hinweis, der Wechsel ist nicht gesperrt.' : ''); },
        danach: function () { return '#/aktivitaet/' + encodeURIComponent(id); }
      });
    });
  }

  /* ---------- Aktivitätsarten ---------- */
  function seiteAktivitaetsarten() {
    return daten.aktivitaetsartenListe().then(function (liste) {
      var inhalt = [krumen(KR_STAMM.concat([['Arten von Aktivitäten']])), h('h1', { text: 'Arten von Aktivitäten' }),
        h('p', { text: 'Die Liste ist offen. Bei jeder Art legst du fest, für welche Fahrzeugarten sie gilt, damit bei der Aktivität nur Arten zur Wahl stehen, die zum Fahrzeug passen. Übernimm die Vorschläge oder lege eigene Arten an.' })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Noch keine Art.' })));
      else inhalt.push(h('ul', { class: 'fristen' }, liste.map(function (x) {
        return h('li', null, h('a', { class: 'frist', href: '#/aktivitaetsart/' + encodeURIComponent(x.objekt.id) + '/aendern' },
          h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: x.aktuell.werte.bezeichnung }),
            h('span', { class: 'frist-info', text: 'Gilt für: ' + MM.Logbuch.zuordnungText(x.aktuell.werte.zuordnung) })),
          x.aktuell.werte.ausgeblendet === 'ja' ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : null));
      })));
      var fehlend = MM.Aktivitaeten.VORSCHLAEGE_ARTEN.filter(function (n) { return !liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === n.toLowerCase(); }); });
      if (fehlend.length) inhalt.push(h('p', null, h('button', { class: 'knopf leise', type: 'button', text: 'Vorschläge übernehmen (' + fehlend.length + ')',
        onclick: function () { daten.aktivitaetsartenAusVorschlaegen().then(function (r) { meldung = r.anzahl + ' Arten übernommen.'; return zeige(); }).catch(fehlerSeite); } })));
      var ohneZuordnung = liste.filter(function (x) { return x.aktuell.werte.zuordnung === undefined && MM.Aktivitaeten.zuordnungVorschlag(x.aktuell.werte.bezeichnung); });
      if (ohneZuordnung.length) inhalt.push(h('p', null, h('button', { class: 'knopf leise', type: 'button', text: 'Vorschläge für Fahrzeugarten übernehmen (' + ohneZuordnung.length + ')',
        onclick: function () { daten.aktivitaetsartenVorauswahlUebernehmen().then(function (r) { meldung = 'Zuordnung gesetzt für: ' + r.namen.join(', ') + '.'; return zeige(); }).catch(fehlerSeite); } }),
        h('span', { class: 'hilfe', text: ' Zum Beispiel Wasserski nur für Wasserskiboote. Was du selbst eingestellt hast, bleibt. Die Zuordnung änderst du danach jederzeit.' })));
      seite('Arten von Aktivitäten', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/aktivitaetsart/neu', text: 'Eigene Art anlegen' })));
    });
  }

  function aktivitaetsartFormular(modus, id) {
    var neu = modus === 'neu';
    return (neu ? Promise.resolve({ aktuell: { werte: { bezeichnung: '', ausgeblendet: 'nein' } } }) : daten.aktivitaetsartLaden(id)).then(function (x) {
      if (!x) return nichtGefunden('Art nicht gefunden');
      var titel = neu ? 'Eigene Art anlegen' : 'Art ändern';
      var werteStart = JSON.parse(JSON.stringify(x.aktuell.werte));
      var baum = zuordnungBaumTeile(werteStart);
      einfachFormular({
        titel: titel, zurueck: '#/aktivitaetsarten', werte: werteStart, neuzeichnenBei: ['gilt'],
        nachAenderung: baum.nachAenderung,
        krumen: krumen(KR_STAMM.concat([['Arten von Aktivitäten', '#/aktivitaetsarten'], [titel]])),
        gruppen: function () {
          var f = [{ key: 'bezeichnung', label: 'Name der Art', typ: 'text', hilfe: 'Zum Beispiel „Angeln“ oder „Regatta“' }];
          if (!neu) f.push({ key: 'ausgeblendet', label: 'Ausblenden?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Nein, auswählbar' }, { wert: 'ja', label: 'Ja, ausblenden' }],
            hilfe: 'Ausgeblendete Arten sind für neue Aktivitäten nicht mehr auswählbar. Vorhandene Aktivitäten bleiben.' });
          return [{ titel: null, felder: f }, { titel: 'Gilt für diese Fahrzeugarten', felder: [{ key: 'gilt', label: 'Fahrzeugarten', typ: 'baum', optionen: baum.optionen,
            hilfe: 'Ein Häkchen an einer Gruppe gilt für alles darunter. Du kannst darunter einzelne Arten abwählen oder wieder ankreuzen, auch später.' }] }];
        },
        speichern: function (v) {
          var roh2 = Object.assign({}, v, { zuordnung: MM.Logbuch.zuordnungAusAuswahl(v.gilt || [], neu ? null : x.aktuell.werte.zuordnung) });
          return neu ? daten.aktivitaetsartAnlegen(roh2) : daten.aktivitaetsartAendern(id, roh2).then(function (r) { r.id = id; return r; });
        },
        meldung: function (r) { return neu ? 'Art angelegt.' : (r.geaendert ? 'Gespeichert.' : 'Es gab keine Änderung.'); },
        danach: function () { return '#/aktivitaetsarten'; }
      });
    });
  }

  /* ---------- Logbuch: Tagesabschnitte, Ereignisse, Prüfung zum Tagesbeginn (Zusatzbaustein an der Aktivität) ---------- */
  function enc(x) { return encodeURIComponent(x); }
  function tagText(w) { var wt = MM.Logbuch.wochentag(w.datum); return (wt ? wt + ' ' : '') + MM.Hilfen.datum(w.datum); }
  function uhrzeitenText(w) {
    if (w.beginnZeit && w.endeZeit) return w.beginnZeit + ' bis ' + w.endeZeit + ' Uhr';
    if (w.beginnZeit) return 'ab ' + w.beginnZeit + ' Uhr';
    if (w.endeZeit) return 'bis ' + w.endeZeit + ' Uhr';
    return null;
  }
  function vonNachText(w, z) {
    if (z && (z.start || z.ziel)) return (z.start ? z.start.name : (w.von || '?')) + ' → ' + (z.ziel ? z.ziel.name : (w.nach || '?'));
    return w.von || w.nach ? (w.von || '?') + ' → ' + (w.nach || '?') : null;
  }
  function anzahlText(n, eins, mehr) { return n === 0 ? 'Keine ' + mehr : n + ' ' + (n === 1 ? eins : mehr); }
  function logbuchKrumen(a, mehr) {
    return [['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [a.aktuell.werte.bezeichnung, '#/aktivitaet/' + enc(a.aktivitaet.id)]].concat(mehr || []);
  }
  function tuMeldung(vorgang, text) {
    return vorgang.then(function (r) { meldung = r.ok ? text(r) : (r.fehler && r.fehler.allgemein) || 'Das hat nicht geklappt.'; return zeige(); }).catch(fehlerSeite);
  }

  /* ---------- Tag der Reise wählen (seit 2.0.44) ----------
   * Bei einer Reise über mehrere Tage steht oben ein Knopf mit dem gewählten Reisetag. Dahinter liegt ein Kalender, der am ersten Reisetag (Tag 1)
   * beginnt und am letzten (Tag X) endet, nicht beim heutigen Datum. Tage mit einem Tag im Logbuch sind hervorgehoben. Nach der Wahl schließt er sich.
   * Gezeigt wird dann nur dieser Tag, in der Zusammenfassung und im Logbuch. Während der Reise ist der heutige Reisetag vorgewählt, sonst Tag 1. */
  var tagWahl = {}; /* je Aktivität der zuletzt gewählte Tag (Kennung des Tages im Logbuch) */

  /* Die Auswahl gibt es nur bei einer Reise über mehrere Tage mit mindestens zwei sichtbaren Tagen. Ergebnis: { id, tage, w } oder null. */
  function tagWahlFuer(id, w, lb) {
    var tage = lb.abschnitte.filter(function (x) { return !x.ausgeblendet; }).map(function (x) { return { id: x.objekt.id, datum: x.aktuell.werte.datum }; });
    if (!MM.Tagwahl.mehrtaegig(w.vonDatum, w.bisDatum) || tage.length < 2) return null;
    return { id: MM.Tagwahl.standard(tage, daten.heute(), tagWahl[id] || null), tage: tage, w: w };
  }

  function tagWaehlen(aktId, tagId) {
    tagWahl[aktId] = tagId;
    var y = global.pageYOffset || 0;
    zeige().then(function () { global.scrollTo(0, y); }).catch(fehlerSeite);
  }

  function kalenderMonate(aktId, wahl) {
    return MM.Tagwahl.monate(wahl.w.vonDatum, wahl.w.bisDatum, wahl.tage, wahl.id, daten.heute()).map(function (mo) {
      return h('table', { class: 'tw-monat' },
        h('caption', { text: mo.titel }),
        h('thead', null, h('tr', null, MM.Tagwahl.WOCHENTAGE.map(function (x) { return h('th', { scope: 'col', text: x }); }))),
        h('tbody', null, mo.wochen.map(function (wo) {
          return h('tr', null, wo.map(function (z) {
            if (!z) return h('td', { class: 'tw-leer' });
            var klasse = 'tw-tag tw-' + z.art + (z.gewaehlt ? ' tw-gewaehlt' : '') + (z.heute ? ' tw-heute' : '');
            if (z.art === 'aktiv') {
              return h('td', null, h('button', { class: klasse, type: 'button', 'aria-pressed': z.gewaehlt ? 'true' : 'false', text: String(z.tag),
                'aria-label': 'Tag ' + z.nr + ', ' + MM.Hilfen.datum(z.datum) + (z.heute ? ', heute' : ''), onclick: function () { tagWaehlen(aktId, z.id); } }));
            }
            return h('td', null, h('span', { class: klasse, text: String(z.tag) }));
          }));
        })));
    });
  }

  function tagWaehler(aktId, wahl) {
    var t = wahl.tage.filter(function (x) { return x.id === wahl.id; })[0];
    var nr = MM.Tagwahl.tagNummer(wahl.w.vonDatum, wahl.w.bisDatum, t.datum), anzahl = MM.Tagwahl.reiseTage(wahl.w.vonDatum, wahl.w.bisDatum);
    var kalender = h('div', { class: 'tagwahl-kalender', role: 'group', 'aria-label': 'Reisetag wählen', hidden: true },
      kalenderMonate(aktId, wahl),
      h('p', { class: 'hilfe', text: 'Hervorgehoben sind die Tage, die es im Logbuch gibt. Ein Tipp auf einen Tag zeigt ihn und schließt den Kalender.' }));
    var knopf = h('button', { class: 'knopf leise tagwahl-knopf', type: 'button', 'aria-expanded': 'false',
      text: '📅 ' + MM.Tagwahl.knopfText(nr, anzahl, MM.Logbuch.wochentag(t.datum), MM.Hilfen.datum(t.datum)),
      onclick: function () { kalender.hidden = !kalender.hidden; knopf.setAttribute('aria-expanded', kalender.hidden ? 'false' : 'true'); } });
    return h('div', { class: 'tagwahl' }, knopf, kalender);
  }

  /* ---------- Etappen: Zusammenfassung der Reise und der einzelne Tag (seit 2.0.43) ---------- */
  function streckeTextEtappe(s) { return s ? MM.Hilfen.zahl(s.km) + ' km (' + (s.art === 'route' ? 'auf der Route' : 'Luftlinie zwischen den Orten') + ')' : 'unklar (Start- oder Zielort mit Position fehlt)'; }
  function kostenTextEtappe(k) {
    if (!k.anzahl) return 'keine Kosten eingetragen';
    return euro(k.summe) + ' (' + k.anzahl + (k.anzahl === 1 ? ' Posten' : ' Posten') + (k.nachDatum ? ', ' + k.nachDatum + ' nach Datum zugeordnet' : '') + ')';
  }
  function wetterTextEtappe(wz) {
    if (wz.quelle === 'hand') return 'von Hand: ' + wz.text;
    if (wz.quelle === 'online') return wz.text + ' (online geholt am ' + MM.Hilfen.zeitpunkt(wz.abgerufenAm) + ' Uhr' + (wz.aktuell ? '' : ', Orte, Uhrzeit oder Geschwindigkeit haben sich seitdem geändert') + ')';
    return 'unklar' + (wz.grund ? ': ' + wz.grund : '');
  }
  function ortLink(o) { return o ? h('a', { href: '#/ort/' + enc(o.id), text: o.name }) : null; }
  function startZielNodes(z) {
    if (!z.start && !z.ziel && !z.vonText && !z.nachText) return 'noch nicht gewählt';
    return [z.start ? ortLink(z.start) : (z.vonText || '?'), ' → ', z.ziel ? ortLink(z.ziel) : (z.nachText || '?')];
  }

  function etappeKarte(z, aktId, storniert) {
    var tid = enc(z.id);
    return h('article', { class: 'tag-karte' + (z.ausserhalb ? ' ausgeblendet' : '') },
      h('h3', null, h('a', { href: '#/tagesabschnitt/' + tid, text: tagText({ datum: z.datum }) })),
      h('dl', { class: 'daten stapel' },
        h('dt', { text: 'Start und Ziel' }), h('dd', null, startZielNodes(z)),
        h('dt', { text: 'Strecke' }), h('dd', { text: streckeTextEtappe(z.strecke) }),
        h('dt', { text: 'Kosten' }), h('dd', { text: kostenTextEtappe(z.kosten) }),
        h('dt', { text: 'Ereignisse' }), h('dd', { text: z.ereignisse.anzahl ? z.ereignisse.anzahl + ': ' + z.ereignisse.text : 'keine' }),
        h('dt', { text: 'Wetter' }), h('dd', { text: wetterTextEtappe(z.wetter) })),
      h('p', { class: 'knopfzeile' },
        h('a', { class: 'knopf leise klein', href: '#/tagesabschnitt/' + tid, text: 'Tag ansehen' }),
        storniert ? null : h('a', { class: 'knopf leise klein', href: '#/tagesabschnitt/' + tid + '/aendern', text: 'Tag ändern' })));
  }

  /* Oben an der Aktivität: alle Tage mit Strecke, Kosten, Ereignissen und Wetter, dazu die Gesamtsumme. */
  function zusammenfassungBlock(zus, aktId, storniert, mehrtaegig, wahl) {
    if (!zus) return null;
    if (!zus.tage.length) {
      return mehrtaegig ? h('section', { class: 'bereich', 'aria-label': 'Zusammenfassung der Reise' }, h('h2', { text: 'Zusammenfassung der Reise' }),
        h('p', { class: 'leer-text', text: 'Noch keine Tage. Im Logbuch kannst du die Tage aus dem Zeitraum vorbereiten. Jeder Tag bekommt dann Start- und Zielort, Wetter und Kosten.' })) : null;
    }
    var g = zus.gesamt, kostenTage = Math.round((zus.kostenSumme - zus.ohneTag.summe) * 100) / 100;
    var summe = [
      h('dt', { text: 'Strecke aller Tage' }), h('dd', { text: MM.Hilfen.zahl(zus.streckeSumme) + ' km' + (zus.streckeUnklar ? ' (bei ' + zus.streckeUnklar + (zus.streckeUnklar === 1 ? ' Tag unklar' : ' Tagen unklar') + ')' : '') }),
      h('dt', { text: 'Kosten der Tage' }), h('dd', { text: euro(kostenTage) }),
      zus.ohneTag.anzahl ? [h('dt', { text: 'Kosten ohne Tag' }), h('dd', { text: euro(zus.ohneTag.summe) + ' (' + zus.ohneTag.anzahl + (zus.ohneTag.anzahl === 1 ? ' Posten' : ' Posten') + ')' })] : null,
      g.fixAnteil && g.fixAnteil.eingerechnet ? [h('dt', { text: 'Fixkosten-Anteil für die Reisetage' }), h('dd', { text: euro(g.fixAnteil.summe) + ' (gerechnet)' })] : null,
      h('dt', { text: 'Gesamtsumme der Reise' }), h('dd', null, h('strong', { text: euro(g.gesamt) }))];
    return h('section', { class: 'bereich', 'aria-label': 'Zusammenfassung der Reise' },
      h('h2', { text: 'Zusammenfassung der Reise' }),
      h('p', { class: 'hilfe', text: (wahl ? 'Der gewählte Tag der Reise. ' : 'Alle Tage der Reise in einem Blick. ') + 'Jeder Tag ist eine Etappe mit eigenem Start und Ziel, eigenem Wetter und eigenen Kosten. Die Gesamtsumme ist die Summe aller Tage, dazu kommen Posten ohne Tag.' }),
      wahl ? tagWaehler(aktId, wahl) : null,
      (wahl ? zus.tage.filter(function (z) { return z.id === wahl.id; }) : zus.tage).map(function (z) { return etappeKarte(z, aktId, storniert); }),
      h('dl', { class: 'daten stapel' }, summe));
  }

  /* Auf der Seite eines Tages: Start, Ziel, Strecke, Wetter (holen oder von Hand), Kosten und Reisecheck dieses Tages. */
  function etappeBlock(z, tagId, aktId, fahrzeugId, w, storniert) {
    var fel = h('p', { class: 'fehler', role: 'alert' }), status = h('p', { class: 'hinweis', role: 'status' });
    var kostenHash = '#/fahrzeug/' + enc(fahrzeugId) + '/kosten/neu?aktivitaet=' + enc(aktId) + '&tag=' + enc(tagId);
    var holen = h('button', { class: 'knopf', type: 'button', text: z.wetter.quelle === 'online' ? 'Wetter neu holen' : 'Wetter online holen', disabled: z.wetterGrund || storniert ? 'disabled' : null });
    holen.addEventListener('click', function () {
      fel.textContent = ''; holen.disabled = true; status.textContent = 'Die App holt das Wetter für die Punkte dieses Tages …';
      daten.etappeWetterAbrufen(tagId).then(function (r) {
        if (r.ok) { meldung = 'Das Wetter ist geholt (' + r.punkte + (r.punkte === 1 ? ' Punkt' : ' Punkte') + (r.ohneWetter ? ', bei ' + r.ohneWetter + ' ohne Wert' : '') + ').'; return zeige(); }
        status.textContent = ''; holen.disabled = false; fel.textContent = r.fehler.allgemein;
      }).catch(function (err) { status.textContent = ''; holen.disabled = false; fel.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler'); });
    });
    var handWeg = z.wetter.quelle === 'hand' && !storniert ? h('button', { class: 'knopf leise', type: 'button', text: 'Wetter von Hand entfernen', onclick: function () {
      daten.abschnittAendern(tagId, Object.assign({}, w, { wetterHand: '' })).then(function (r) { if (r.ok) { meldung = 'Das Wetter von Hand ist entfernt.'; return zeige(); } fel.textContent = (r.fehler && (r.fehler.allgemein || r.fehler.wetterHand)) || 'Das hat nicht geklappt.'; }).catch(fehlerSeite);
    } }) : null;
    return h('section', { class: 'bereich', 'aria-label': 'Etappe' },
      h('h2', { text: 'Etappe: Start, Ziel, Wetter und Kosten' }),
      h('dl', { class: 'daten stapel' },
        h('dt', { text: 'Start und Ziel' }), h('dd', null, startZielNodes(z)),
        h('dt', { text: 'Strecke' }), h('dd', { text: streckeTextEtappe(z.strecke) }),
        h('dt', { text: 'Wetter' }), h('dd', { text: wetterTextEtappe(z.wetter) }),
        h('dt', { text: 'Kosten' }), h('dd', { text: kostenTextEtappe(z.kosten) })),
      z.wetter.quelle === 'unklar' && z.wetterGrund ? h('p', { class: 'hinweis', text: 'Das Wetter lässt sich noch nicht holen. ' + z.wetterGrund }) : null,
      fel, status,
      storniert ? null : h('p', { class: 'knopfzeile' }, holen, ' ', handWeg,
        h('a', { class: 'knopf leise', href: '#/tagesabschnitt/' + enc(tagId) + '/aendern', text: 'Orte oder Wetter von Hand ändern' })),
      storniert ? null : h('p', { class: 'knopfzeile' },
        h('a', { class: 'knopf leise', href: kostenHash + '&gruppe=variabel', text: 'Kosten für diesen Tag eintragen' }),
        h('a', { class: 'knopf leise', href: kostenHash + '&gruppe=reisekasse', text: 'Ausgabe der Reisekasse eintragen' }),
        h('a', { class: 'knopf leise', href: '#/reisecheck/' + enc(aktId) + '/tag/' + enc(tagId), text: 'Reisecheck für diesen Tag' })));
  }

  /* ---------- Block auf der Seite der Aktivität: zwei Reiter, Cockpit und Logbuch (dieselben Einträge) ---------- */
  var reiterWahl = {}; /* je Aktivität der zuletzt gewählte Reiter, bleibt beim Zurückkommen erhalten */

  function pruefChip(p) {
    return p ? h('span', { class: 'chip-status ' + ERG_KLASSE[p.ergebnis], text: 'Befähigung: ' + MM.Aktivitaeten.ERGEBNIS[p.ergebnis] }) : null;
  }

  function logbuchBlock(a, lb, storniert, zus, wahl) {
    var id = a.aktivitaet.id;
    var c = MM.Logbuch.cockpitMoeglich(a.aktuell.werte, daten.heute());
    return h('section', { class: 'bereich', 'aria-label': 'Logbuch' },
      c.moeglich
        ? h('p', { class: 'knopfzeile' }, h('button', { class: 'knopf', type: 'button', text: 'Cockpit öffnen (Vollbild)',
          onclick: function () { reiterWahl[id] = 'cockpit'; zeige().catch(fehlerSeite); } }))
        : h('p', { class: 'hilfe', text: 'Das Cockpit ist nur offen, wenn die Aktivität nicht storniert ist und heute in ihrem Zeitraum liegt.' }),
      logbuchPanel(a, lb, storniert, zus, wahl));
  }

  /* ---------- Cockpit im Vollbild (seit 2.0.18): kein Menü, kein Scrollen, große Knöpfe ---------- */
  function vollbildSeite(titel, el) {
    doc.title = titel + ' – MobiMory';
    wurzel.textContent = '';
    wurzel.appendChild(el);
    global.scrollTo(0, 0);
  }

  /* ---------- Motorschalter (seit 2.0.19): je Motor ein Schalter, grau = aus, rot = läuft ---------- */
  /* Ein Tipp startet oder stoppt den Motor jetzt. Danach wird die Seite neu gezeichnet, die Meldung steht oben. */
  function motorSchalten(m) {
    var vorgang = m.laeuft ? daten.motorStopp(m.komponenteId) : daten.motorStart(m.komponenteId);
    return vorgang.then(function (r) {
      if (!r.ok) { meldung = (r.fehler && r.fehler.allgemein) || 'Das hat nicht geklappt.'; return zeige(); }
      if (m.laeuft) {
        meldung = m.name + ' gestoppt. Lief ' + (MM.Motoren.stundenText(r.stunden) || 'unter einer Minute') + ', Stand ' + zahlMit(r.stand, 'h') + '.' +
          (r.ohneStartstand ? ' Es fehlt noch ein Startstand, der Zähler zählt ab 0.' : '');
      } else {
        meldung = m.name + ' gestartet, ' + MM.Motoren.ortszeit(r.start) + ' Uhr.';
      }
      return zeige();
    }).catch(fehlerSeite);
  }

  /* Der Schalter selbst: Kurzname und „Start“ oder „Stopp“ (bei laufendem Motor mit der Startzeit). */
  function motorKnopf(m, klasse, beiTipp) {
    var sch = MM.Motoren.schalter(m);
    return h('button', { class: 'knopf motor-schalter motor-' + sch.zustand + (klasse ? ' ' + klasse : ''), type: 'button',
      'aria-label': m.name + (m.laeuft ? ': läuft, tippen zum Stoppen' : ': aus, tippen zum Starten'), onclick: beiTipp },
      h('span', { class: 'ms-name', text: sch.name }),
      h('span', { class: 'ms-aktion', text: sch.aktion + (m.laeuft && m.seit ? ' · seit ' + MM.Motoren.ortszeit(m.seit) : '') }));
  }

  /* Beide Zähler in einer Zeile (seit 2.0.20): Betriebsstunden je Motor und Kilometer, jeweils mit Quelle und Datum des Stands. */
  function zaehlerKurz(x) {
    if (x.leer) return x.art === 'strecke' ? 'kein Stand' : 'noch kein Stand';
    return zahlMit(x.wert, x.einheit) + ' (' + MM.Motoren.quelleText(x.quelle) + ', ' + MM.Hilfen.datum(x.datum).slice(0, 6) + ')';
  }
  function zaehlerZeile(eintraege) {
    if (!eintraege.length) return null;
    return h('p', { class: 'cv-zaehler', 'aria-label': 'Zählerstände' }, eintraege.map(function (x) {
      return h('span', { class: 'cv-z' }, h('span', { class: 'frist-info', text: x.name }), h('strong', { text: zaehlerKurz(x) }));
    }));
  }

  /* sk: die Schnellknöpfe der Fahrzeugart auf diesem Gerät (daten.schnellknoepfeFuerFahrzeugart), motoren: daten.motorenListe,
     hatMotor: hat die Fahrzeugart normalerweise einen Motor (daten.fahrzeugartMotor), strecke: daten.streckenZaehler,
     wartezeit: Minuten bis zum Vorschlag der Stoppzeit (daten.geraetWartezeit, seit 2.0.22),
     fzStatus: Status des Fahrzeugs und seine Regeln (daten.fahrzeugStatus, seit 2.0.23) */
  function cockpitVollbild(a, lb, sk, motoren, hatMotor, strecke, wartezeit, fzStatus, besuchFrage, wetterRhythmus) {
    motoren = motoren || [];
    var statusInfo = fzStatus && fzStatus.ok && fzStatus.hatStatus ? fzStatus : null;
    var id = a.aktivitaet.id, w = a.aktuell.werte;
    var verantwortlich = MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt);
    var heute = MM.Logbuch.heutigerAbschnitt(lb.abschnitte, daten.heute());
    var gerade = a.verantwortlichJetzt;
    var nachricht = meldung; meldung = null;
    var kurz = meldungKurz; meldungKurz = false;
    var hinweisText = motorHinweis; motorHinweis = null;
    gpsStarten();
    var arbeitet = false;
    var tasten = [];

    /* Wetter jetzt (seit 2.0.34): Wetter am aktuellen Standort holen und als Eintrag „Wetter“ ins Logbuch schreiben. Ohne Netz wird nichts gespeichert. */
    function wetterAusloesen(knopf) {
      if (arbeitet) return;
      arbeitet = true;
      tasten.forEach(function (k) { k.setAttribute('disabled', ''); });
      if (knopf) knopf.textContent = 'Wetter wird geholt …';
      reiterWahl[id] = 'cockpit';
      daten.wetterJetzt(id, frischePosition()).then(function (r) {
        if (r.ok) wetterErfolg = { akt: id, ms: Date.now() };
        meldung = r.ok ? 'Wetter gespeichert, ' + r.zeit + ' Uhr. ' + r.text.replace(/^Wetter: /, '') : ((r.fehler && r.fehler.allgemein) || 'Das hat nicht geklappt.');
        meldungKurz = !!r.ok;
        return zeige();
      }).catch(fehlerSeite);
    }

    function ereignisKnopf(x) {
      /* Ein Knopf „Karte“ (seit 2.0.35) öffnet die Karte und schreibt nichts ins Logbuch. */
      if (MM.Karte.istKartenArt(x.name)) return wegKnopf('#/aktivitaet/' + enc(id) + '/karte', x.name, '');
      /* Ein Schnellknopf „Wetter“ holt das Wetter, statt einen leeren Eintrag zu machen. */
      if (MM.Karte.istWetterArt(x.name)) {
        var wk = h('button', { class: 'knopf cv-knopf', type: 'button', text: x.name, onclick: function () { wetterAusloesen(wk); } });
        tasten.push(wk);
        return wk;
      }
      /* Status (seit 2.0.23): Passt das Ereignis nicht zum Status des Fahrzeugs, ist der Knopf grau und nennt den Grund. */
      var sperre = statusInfo ? statusInfo.pruefe(x.name) : { erlaubt: true };
      if (!sperre.erlaubt) {
        return h('button', { class: 'knopf cv-knopf cv-gesperrt', type: 'button', disabled: '', 'aria-disabled': 'true',
          'aria-label': x.name + ': gesperrt, ' + sperre.grund },
          h('span', { class: 'ms-name', text: x.name }), h('span', { class: 'ms-aktion', text: sperre.grund }));
      }
      var b = h('button', { class: 'knopf cv-knopf', type: 'button', text: x.name,
        onclick: function () {
          if (arbeitet) return;
          arbeitet = true;
          tasten.forEach(function (k) { k.setAttribute('disabled', ''); });
          reiterWahl[id] = 'cockpit';
          daten.ereignisSchnell(id, x.name, { artId: x.id, position: frischePosition() }).then(function (r) {
            meldung = r.ok ? x.name + ' gespeichert, ' + r.zeit + ' Uhr.' : (r.fehler && (r.fehler.allgemein || r.fehler.zeit || r.fehler.artId)) || 'Das hat nicht geklappt.';
            /* Nur ein Hinweis: Der Eintrag ist schon gespeichert, nichts wird gefragt oder gesperrt. */
            if (r.ok) motorHinweis = MM.Motoren.motorHinweis(hatMotor, x.name, motoren);
            if (r.ok && r.vorgangId) meldung += ' Steht auch in der Werkstatt, Einschränkung: bleibt nutzbar. Du kannst sie dort ändern.';
            return zeige();
          }).catch(fehlerSeite);
        } });
      tasten.push(b);
      return b;
    }
    function wegKnopf(hash, text, klasse) {
      return h('a', { class: 'knopf cv-knopf ' + (klasse || ''), href: hash, text: text, onclick: function () { reiterWahl[id] = 'cockpit'; } });
    }
    var knoepfe = sk.knoepfe.map(function (x) {
      return x.typ === 'ereignis' ? ereignisKnopf(x) : wegKnopf('#/aktivitaet/' + enc(id) + '/cockpit/' + x.id, x.name, x.id === 'wechsel' ? 'leise' : '');
    });
    knoepfe.push(wegKnopf('#/aktivitaet/' + enc(id) + '/cockpit/ereignis', 'Sonstige Ereignisse', 'leise cv-sonstige'));

    var letztes = MM.Logbuch.letzteEreignisse(lb.abschnitte, 1)[0];
    var wann = letztes ? (letztes.datum !== letztes.tagDatum ? MM.Hilfen.datum(letztes.datum).slice(0, 6) + ' ' : '') + (letztes.zeit ? letztes.zeit + ' Uhr' : '') : '';

    var abschluss = h('button', { class: 'knopf leise klein', type: 'button', text: 'Tagesabschluss',
      onclick: function () {
        reiterWahl[id] = 'cockpit';
        daten.heutigerTag(id).then(function (r) {
          if (!r.ok) { meldung = (r.fehler && r.fehler.allgemein) || 'Das hat nicht geklappt.'; return zeige(); }
          global.location.hash = '#/tagesabschnitt/' + enc(r.abschnittId) + '/abschluss';
        }).catch(fehlerSeite);
      } });
    var fussKnoepfe = [abschluss,
      h('a', { class: 'knopf leise klein', href: '#/schnellknoepfe/' + enc(a.fahrzeug.artId) + '?aktivitaet=' + enc(id), text: 'Knöpfe ändern' }),
      h('button', { class: 'knopf leise klein', type: 'button', text: 'Logbuch und Angaben', onclick: function () { reiterWahl[id] = 'logbuch'; zeige().catch(fehlerSeite); } })];
    if (gpsSpur && gpsSpurAkt === id && gpsSpur.km >= 0.05) {
      fussKnoepfe.push(h('button', { class: 'knopf leise klein', type: 'button', text: 'GPS-Strecke übernehmen', onclick: function () {
        if (arbeitet) return;
        arbeitet = true; reiterWahl[id] = 'cockpit';
        gpsSpurUngesichert = true; gpsSpurSichern(true);
        daten.gpsSpurSpeichern(id, gpsSpur).then(function () { return daten.gpsStreckeUebernehmen(id); }).then(function (r) {
          if (r.ok) { gpsSpur = { km: 0, letzter: gpsSpur.letzter, punkte: 0, verworfen: 0, luecken: 0 }; meldung = 'GPS-Strecke ' + MM.Hilfen.zahl(r.km) + ' km übernommen. ' + r.zaehlerName + ' steht jetzt auf ' + MM.Hilfen.zahl(r.stand) + ' ' + r.einheit + '.'; }
          else meldung = (r.fehler && r.fehler.allgemein) || 'Das hat nicht geklappt.';
          return zeige();
        }).catch(fehlerSeite);
      } }));
    }
    if (doc.fullscreenEnabled) {
      fussKnoepfe.push(h('button', { class: 'knopf leise klein', type: 'button', text: doc.fullscreenElement ? 'Vollbild beenden' : 'Ganzer Bildschirm',
        onclick: function () {
          var p = doc.fullscreenElement ? doc.exitFullscreen() : doc.documentElement.requestFullscreen();
          if (p && p.then) p.then(function () { zeige().catch(fehlerSeite); }, function () {});
        } }));
    }

    /* Untere Leiste (seit 2.0.19): bis zu zwei Motoren je ein Schalter, ab drei ein Schalter „Motoren“ mit einer Liste */
    var leisteInfo = MM.Motoren.leiste(motoren);
    var motorenHash = '#/motoren/' + enc(a.fahrzeug.id) + '?aktivitaet=' + enc(id);
    var motorLeiste = null;
    if (leisteInfo.modus === 'einzeln') {
      motorLeiste = h('div', { class: 'cv-motoren', role: 'group', 'aria-label': 'Motoren' }, motoren.map(function (m) {
        var b = motorKnopf(m, 'cv-motor', function () {
          if (arbeitet) return;
          arbeitet = true;
          tasten.forEach(function (k) { k.setAttribute('disabled', ''); });
          reiterWahl[id] = 'cockpit';
          motorSchalten(m);
        });
        tasten.push(b);
        return b;
      }));
    } else if (leisteInfo.modus === 'sammel') {
      motorLeiste = h('div', { class: 'cv-motoren', role: 'group', 'aria-label': 'Motoren' },
        h('a', { class: 'knopf motor-schalter cv-motor motor-' + (leisteInfo.laufen ? 'laeuft' : 'aus'), href: motorenHash, onclick: function () { reiterWahl[id] = 'cockpit'; },
          'aria-label': 'Motoren, ' + leisteInfo.text + ', tippen für die Liste' },
          h('span', { class: 'ms-name', text: 'Motoren' }), h('span', { class: 'ms-aktion', text: leisteInfo.text })));
    }
    fussKnoepfe.push(leisteInfo.modus === 'keine'
      ? h('a', { class: 'knopf leise klein', href: '#/fahrzeug/' + enc(a.fahrzeug.id) + '/komponente/neu', text: 'Motor eintragen', onclick: function () { reiterWahl[id] = 'cockpit'; } })
      : h('a', { class: 'knopf leise klein', href: motorenHash, text: 'Motoren', onclick: function () { reiterWahl[id] = 'cockpit'; } }));

    /* Motorstopp-Frage (seit 2.0.22): wird bei jedem Zeichnen aus den Ereignissen und den laufenden Motoren abgeleitet,
       nicht gemerkt. Auslöser ist ein Ereignis am Ziel (Ankunft, Anlegen, Anker werfen), nie die Laufzeit des Motors. */
    var ereignisListe = [];
    lb.abschnitte.forEach(function (x) {
      if (x.ausgeblendet) return;
      x.ereignisse.forEach(function (e) { if (e.art === 'ereignis' && !e.ausgeblendet) ereignisListe.push(e); });
    });
    var jetztLokal = daten.jetztLokal();
    var fragen = MM.Motoren.stoppFragen(motoren, ereignisListe, wartezeit, jetztLokal);

    function motorStoppen(f, vomZiel) {
      if (arbeitet) return;
      arbeitet = true;
      tasten.forEach(function (k) { k.setAttribute('disabled', ''); });
      reiterWahl[id] = 'cockpit';
      var optionen = vomZiel ? { zeitpunkt: MM.Motoren.zeitpunktAusOrtszeit(f.datum, f.zeit), ereignisId: f.ereignisId } : undefined;
      daten.motorStopp(f.komponenteId, optionen).then(function (r) {
        if (!r.ok) { meldung = (r.fehler && (r.fehler.allgemein || r.fehler.zeit)) || 'Das hat nicht geklappt.'; return zeige(); }
        meldung = f.name + ' gestoppt' + (r.vomZiel ? ' um ' + f.zeit + ' Uhr (' + f.ereignisName + ')' : '') + '. Lief ' + (MM.Motoren.stundenText(r.stunden) || 'unter einer Minute') + ', Stand ' + zahlMit(r.stand, 'h') + '.' +
          (r.ohneStartstand ? ' Es fehlt noch ein Startstand, der Zähler zählt ab 0.' : '');
        return zeige();
      }).catch(fehlerSeite);
    }
    function motorLaeuftWeiter(gruppe) {
      if (arbeitet) return;
      arbeitet = true;
      tasten.forEach(function (k) { k.setAttribute('disabled', ''); });
      reiterWahl[id] = 'cockpit';
      Promise.all(gruppe.map(function (f) { return daten.motorStoppFrageVerneinen(f.laufId, f.ereignisId, f.stufe); })).then(function () { return zeige(); }).catch(fehlerSeite);
    }
    function frageKarte(stufe) {
      var gruppe = fragen.filter(function (f) { return f.stufe === stufe; });
      if (!gruppe.length) return null;
      var f0 = gruppe[0], mehrere = gruppe.length > 1;
      var namen = gruppe.map(function (f) { return f.kurz; }).join(', ');
      var text = stufe === 'jetzt' ? MM.Motoren.FRAGE_TEXT
        : namen + (mehrere ? ' laufen' : ' läuft') + ' noch, ' + f0.ereignisName + ' war um ' + f0.zeit + ' Uhr (vor ' + (MM.Motoren.stundenText(f0.minuten / 60) || 'unter einer Minute') + '). Stoppzeit ' + f0.zeit + ' Uhr übernehmen?';
      var info = stufe === 'jetzt' ? f0.ereignisName + ' um ' + f0.zeit + ' Uhr' + (mehrere ? ', es laufen: ' + namen : ', es läuft: ' + namen) : null;
      var knoepfeFrage = gruppe.map(function (f) {
        var b = h('button', { class: 'knopf', type: 'button',
          text: stufe === 'jetzt' ? (mehrere ? f.kurz + ' stoppen' : 'Motor stoppen') : (mehrere ? f.kurz + ': ' : '') + 'Stopp um ' + f.zeit + ' übernehmen',
          onclick: function () { motorStoppen(f, stufe === 'vorschlag'); } });
        tasten.push(b);
        return b;
      });
      var weiter = h('button', { class: 'knopf leise', type: 'button', text: 'Läuft weiter', onclick: function () { motorLaeuftWeiter(gruppe); } });
      tasten.push(weiter);
      return h('div', { class: 'cv-frage', role: 'alert' },
        h('p', null, h('span', { text: text }), info ? h('span', { class: 'frist-info', text: ' ' + info }) : null),
        h('div', { class: 'cv-frage-knoepfe' }, knoepfeFrage, weiter));
    }
    /* Frage nach dem Ort (seit 2.0.28): nach Ankunft, Anlegen oder Anker werfen, immer freiwillig, sperrt nichts. */
    function ortKarte() {
      if (!besuchFrage) return null;
      var f = besuchFrage, zeilen = [];
      if (f.vorschlag) zeilen.push('Bekannter Ort: ' + f.vorschlag.name + ' (' + MM.Logbuch.entfernungText(f.vorschlag.abstand) + ').');
      else if (f.ortName) zeilen.push('Ortsname: ' + f.ortName + '.');
      if (f.plan.text) zeilen.push(f.plan.text);
      else if (f.plan.vorhanden && !f.vorschlag && f.plan.zielName) zeilen.push('Geplantes Ziel: ' + f.plan.zielName + '.');
      var festhalten = h('a', { class: 'knopf', href: '#/aktivitaet/' + enc(id) + '/besuch/neu?ereignis=' + enc(f.ereignisId) + '&von=cockpit' + (f.vorschlag ? '&ort=' + enc(f.vorschlag.ortId) : ''),
        text: f.vorschlag ? 'Ort bestätigen' : 'Ort festhalten', onclick: function () { reiterWahl[id] = 'cockpit'; } });
      var spaeter = h('button', { class: 'knopf leise', type: 'button', text: 'Nicht jetzt', onclick: function () {
        if (arbeitet) return;
        arbeitet = true; tasten.forEach(function (k) { k.setAttribute('disabled', ''); }); reiterWahl[id] = 'cockpit';
        daten.besuchUeberspringen(id, f.ereignisId).then(function () { return zeige(); }).catch(fehlerSeite);
      } });
      tasten.push(spaeter);
      return h('div', { class: 'cv-frage', role: 'status' },
        h('p', null, h('span', { text: f.artName + ' um ' + f.zeit + ' Uhr. Ort, Ausstattung und Kosten festhalten? Freiwillig.' }), zeilen.length ? h('span', { class: 'frist-info', text: ' ' + zeilen.join(' ') }) : null),
        h('div', { class: 'cv-frage-knoepfe' }, festhalten, spaeter));
    }
    var frageKarten = [frageKarte('jetzt'), frageKarte('vorschlag'), ortKarte()];
    /* Kommt später noch ein Vorschlag, zeichnet sich das Cockpit zu diesem Zeitpunkt neu. */
    var wartenMs = MM.Motoren.naechsteFrageInMs(motoren, ereignisListe, wartezeit, jetztLokal);
    if (wartenMs !== null) {
      frageTimer = global.setTimeout(function () { frageTimer = null; zeige().catch(fehlerSeite); }, Math.min(wartenMs, 2147000000) + 1000);
    }

    var el = h('div', { class: 'cockpit-voll', role: 'main' },
      h('div', { class: 'cv-status' },
        h('p', { class: 'cv-titel' }, h('strong', { text: w.bezeichnung }), h('span', { class: 'frist-info', text: a.fahrzeug.name })),
        h('p', null, h('span', { class: 'frist-info', text: verantwortlich + ' jetzt' }), h('strong', { text: gerade ? gerade.name : 'noch niemand' }),
          gerade ? h('span', { class: 'frist-info', text: 'seit ' + jetztText(gerade.ab) }) : null),
        h('p', null, h('span', { class: 'frist-info', text: 'Heute' }), h('strong', { text: tagText({ datum: daten.heute() }) }),
          h('span', { class: 'frist-info', text: heute ? anzahlText(heute.anzahlEreignisse, 'Ereignis', 'Ereignisse') : '' })),
        statusInfo ? h('p', { class: 'cv-fzstatus' }, h('span', { class: 'frist-info', text: 'Status' }), h('strong', { text: statusInfo.stand.name }),
          h('span', { class: 'frist-info', text: statusInfo.stand.unbekannt ? 'noch kein Ereignis mit Status' : 'seit ' + statusInfo.stand.seit.slice(11, 16) + ' Uhr (' + statusInfo.stand.durch + ')' })) : null,
        positionZeile(),
        motoren.filter(function (m) { return m.laeuft; }).map(function (m) {
          return h('p', null, h('span', { class: 'frist-info', text: 'Läuft' }), h('strong', { text: m.name }), h('span', { class: 'frist-info', text: 'seit ' + MM.Motoren.ortszeit(m.seit) + ' Uhr' }));
        }),
        zaehlerZeile(MM.Motoren.zaehlerAnzeige(motoren, strecke, a.fahrzeug.welt))),
      nachricht ? h('p', { class: 'cv-meldung', role: 'status', text: nachricht }) : null,
      hinweisText ? h('p', { class: 'cv-hinweis', role: 'status', text: hinweisText }) : null,
      frageKarten,
      h('div', { class: 'cv-raster' }, knoepfe),
      motorLeiste,
      h('div', { class: 'cv-fuss' },
        h('p', { class: 'cv-letzte', text: letztes ? 'Zuletzt: ' + wann + ' – ' + letztes.artName + (letztes.text ? ': ' + letztes.text : '') : 'Noch kein Eintrag.' }),
        h('div', { class: 'cv-fussknoepfe' }, fussKnoepfe)));
    vollbildSeite(w.bezeichnung, el);
    /* Der Wetterbericht ist nur der Stand von diesem Moment, im Logbuch steht er ohnehin. Darum verschwindet die Meldung nach ein paar Sekunden
       von selbst, oder sofort mit einem Tipp darauf. */
    var meldungEl = nachricht && kurz ? el.querySelector('.cv-meldung') : null;
    if (meldungEl) {
      var meldungWeg = function () { if (meldungEl.parentNode) meldungEl.parentNode.removeChild(meldungEl); };
      meldungEl.addEventListener('click', meldungWeg);
      meldungEl.setAttribute('title', 'Antippen schließt die Meldung');
      global.setTimeout(meldungWeg, 6000);
    }
    wetterAutoPlanen(id, el, ereignisListe, wetterRhythmus, !statusInfo || gpsInFahrt, function (r) {
      meldung = 'Wetter automatisch gespeichert, ' + r.zeit + ' Uhr. ' + r.text.replace(/^Wetter \(automatisch\): /, '');
      meldungKurz = true;
      zeige().catch(fehlerSeite);
    });
    fahrtAutoPlanen(id, el, ereignisListe, wetterRhythmus, !statusInfo || gpsInFahrt);
  }

  /* ---------- Seite: Motoren (seit 2.0.19): alle Motoren eines Fahrzeugs mit Schalter, Betriebsstunden und letzten Läufen ---------- */
  function hashParam(name) {
    var m = new RegExp(name + '=([^&]+)').exec(global.location.hash);
    return m ? decodeURIComponent(m[1]) : '';
  }

  function seiteMotoren(fahrzeugId, aktId) {
    return Promise.all([daten.fahrzeugLaden(fahrzeugId), daten.motorenListe(fahrzeugId), aktId ? daten.aktivitaetLaden(aktId) : Promise.resolve(null), daten.streckenZaehler(fahrzeugId)]).then(function (r) {
      var fz = r[0], motoren = r[1], a = r[2], strecke = r[3];
      if (!fz) return nichtGefunden('Fahrzeug nicht gefunden');
      if (a && a.fahrzeug.id !== fahrzeugId) a = null;
      var zurueck = a ? '#/aktivitaet/' + enc(aktId) : '#/fahrzeug/' + enc(fahrzeugId);
      var weg = a ? logbuchKrumen(a, [['Motoren']]) : ortKrumen(fz.aktuell, fz.fahrzeug.id, null).concat([['Motoren']]);
      var query = '?fahrzeug=' + enc(fahrzeugId) + (a ? '&aktivitaet=' + enc(aktId) : '');
      var jetzt = Date.parse(daten.jetzt());
      var doppelt = MM.Motoren.doppelteKurznamen(motoren);
      var inhalt = [krumen(weg), h('h1', { text: 'Motoren' }), h('p', { class: 'frist-info', text: fz.aktuell.werte.bezeichnung })];

      if (!motoren.length) {
        inhalt.push(h('div', { class: 'leer-hinweis' },
          h('p', { text: 'In den Komponenten dieses Fahrzeugs ist noch kein Motor eingetragen. Der Schalter kommt aus dem Motor, den du dort einträgst, und sein Name ist die Beschriftung.' }),
          h('p', null, h('a', { class: 'knopf', href: '#/fahrzeug/' + enc(fahrzeugId) + '/komponente/neu', text: 'Motor eintragen' }))));
      }
      if (doppelt.length) {
        inhalt.push(h('p', { class: 'hinweis', text: 'Mehrere Motoren haben denselben Kurznamen (' + doppelt.join(', ') + '). Gib ihnen unterschiedliche Kurznamen, sonst sind die Schalter schwer zu unterscheiden.' }));
      }

      motoren.forEach(function (m) {
        var arbeitet = false;
        var zaehlerZeilen;
        if (m.zaehler && m.zaehler.stand) {
          zaehlerZeilen = [h('p', null, h('strong', { text: 'Betriebsstunden: ' + zahlMit(m.zaehler.stand.wert, m.zaehler.einheit) }), h('span', { class: 'frist-info', text: ' (Stand vom ' + MM.Hilfen.datum(m.zaehler.stand.datum) + ')' })),
            h('p', { class: 'knopfzeile' },
              h('a', { class: 'knopf leise klein', href: '#/zaehler/' + enc(m.zaehler.id) + '/stand', text: 'Stand von Hand eintragen' }),
              h('a', { class: 'knopf leise klein', href: '#/zaehler/' + enc(m.zaehler.id), text: 'Zähler öffnen' }))];
        } else if (m.zaehler) {
          zaehlerZeilen = [h('p', { class: 'hinweis', text: 'Noch kein Zählerstand. Der Zähler zählt ab 0, bis du den echten Stand von Hand einträgst.' }),
            h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise klein', href: '#/zaehler/' + enc(m.zaehler.id) + '/stand', text: 'Stand von Hand eintragen' }))];
        } else {
          zaehlerZeilen = [h('p', { class: 'hinweis', text: 'Noch kein Zähler. Er entsteht beim ersten Start und zählt dann ab 0. Du kannst ihn auch vorher mit dem echten Stand anlegen.' }),
            h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise klein', href: '#/komponente/' + enc(m.komponenteId) + '/zaehler/neu', text: 'Zähler mit Stand anlegen' }))];
        }
        var laeufe = m.laeufe.length ? h('details', { class: 'ausgebaut' }, h('summary', { text: 'Letzte Läufe (' + m.laeufe.length + ')' }),
          h('ul', { class: 'fristen' }, m.laeufe.map(function (l) {
            return h('li', null, h('div', { class: 'frist motor-lauf' },
              h('span', { class: 'frist-text' },
                h('strong', { class: 'frist-name', text: MM.Hilfen.zeitpunkt(l.start) + ' bis ' + MM.Motoren.ortszeit(l.stopp) + ' Uhr' }),
                h('span', { class: 'frist-info', text: (MM.Motoren.stundenText(l.stunden) || 'unter einer Minute') + (l.standNachher !== null && l.standNachher !== undefined ? ', Stand danach ' + zahlMit(l.standNachher, 'h') : '') + (l.korrigiert ? ', Stoppzeit korrigiert' : '') })),
              l.korrigierbar ? h('a', { class: 'knopf leise klein', href: '#/lauf/' + enc(l.id) + '/korrigieren' + query, text: 'Stoppzeit korrigieren' }) : null));
          }))) : null;
        inhalt.push(h('article', { class: 'tag-karte motor-karte' },
          h('h2', null, h('a', { href: '#/komponente/' + enc(m.komponenteId), text: m.name })),
          h('p', { class: 'frist-info', text: 'Kurzname auf dem Schalter: ' + m.kurz + (m.kurzname ? '' : ' (Vorschlag aus dem Namen, noch nicht gespeichert)') }),
          h('p', null, m.laeuft
            ? [h('strong', { text: 'Läuft seit ' + MM.Motoren.ortszeit(m.seit) + ' Uhr' }), h('span', { class: 'frist-info', text: ' (' + MM.Motoren.dauerText(jetzt - Date.parse(m.seit)) + ')' })]
            : h('strong', { text: 'Aus' })),
          motorKnopf(m, 'gross', function (ev) {
            if (arbeitet) return;
            arbeitet = true; ev.currentTarget.setAttribute('disabled', '');
            if (a) reiterWahl[aktId] = 'cockpit';
            motorSchalten(m);
          }),
          zaehlerZeilen, laeufe));
      });

      /* Motorstopp-Frage (seit 2.0.22): Wartezeit auf diesem Gerät */
      if (motoren.length) {
        inhalt.push(h('article', { class: 'tag-karte motor-karte' }, h('h2', { text: 'Motorstopp-Frage' }),
          h('p', { class: 'frist-info', text: 'Nach Ankunft, Anlegen oder Anker werfen fragt die App, ob der Motor gestoppt wird. Läuft er danach noch, schlägt sie die Zeit der Ankunft als Stoppzeit vor.' }),
          h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise klein', href: '#/motorfrage?fahrzeug=' + enc(fahrzeugId) + (a ? '&aktivitaet=' + enc(aktId) : ''), text: 'Wartezeit einstellen' }))));
      }

      /* Kilometer (seit 2.0.20): neben den Betriebsstunden, von Hand eingetragen. Bei Landfahrzeugen immer, sonst nur mit Zähler. */
      var artKnoten = MM.Fahrzeugarten.art(fz.fahrzeug.art);
      if (strecke || (artKnoten && artKnoten.welt === 'land')) {
        var kmInhalt;
        if (strecke && strecke.stand) {
          kmInhalt = [h('p', null, h('strong', { text: 'Kilometer: ' + zahlMit(strecke.stand.wert, strecke.einheit) }),
              h('span', { class: 'frist-info', text: ' (Stand vom ' + MM.Hilfen.datum(strecke.stand.datum) + ', ' + MM.Motoren.quelleText(strecke.stand.quelle, true) + ')' })),
            h('p', { class: 'knopfzeile' },
              h('a', { class: 'knopf leise klein', href: '#/zaehler/' + enc(strecke.id) + '/stand', text: 'Stand von Hand eintragen' }),
              h('a', { class: 'knopf leise klein', href: '#/zaehler/' + enc(strecke.id), text: 'Zähler öffnen' }))];
        } else if (strecke) {
          kmInhalt = [h('p', { class: 'hinweis', text: 'Noch kein Kilometerstand. Trage den Stand von Hand ein, zum Beispiel den Tachostand.' }),
            h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise klein', href: '#/zaehler/' + enc(strecke.id) + '/stand', text: 'Stand von Hand eintragen' }))];
        } else {
          kmInhalt = [h('p', { class: 'hinweis', text: 'Noch kein Kilometer-Zähler. Lege ihn mit dem Tachostand an.' }),
            h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise klein', href: '#/fahrzeug/' + enc(fahrzeugId) + '/zaehler/neu', text: 'Zähler mit Stand anlegen' }))];
        }
        inhalt.push(h('article', { class: 'tag-karte motor-karte' }, h('h2', { text: 'Kilometer' }),
          h('p', { class: 'frist-info', text: 'Die Kilometer trägst du von Hand ein. GPS kann später eine weitere Quelle sein, ist aber nie Voraussetzung. Ein Handeintrag hat Vorrang.' }),
          kmInhalt));
      }

      seite('Motoren', inhalt, h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: zurueck, text: a ? 'Zurück zum Cockpit' : 'Zurück' }),
        motoren.length ? h('a', { class: 'knopf leise', href: '#/fahrzeug/' + enc(fahrzeugId) + '/komponente/neu', text: 'Motor eintragen' }) : null));
    });
  }

  /* ---------- Seite: Karte (seit 2.0.34, Schritt 9b) ---------- */
  var aktuelleKarte = null, kartenAblage = null;
  function ablage() { if (!kartenAblage) kartenAblage = new MM.Kartenablage(); return kartenAblage; }
  function gpsTextKurz() {
    if (gpsStatus === 'verweigert') return 'GPS nicht erlaubt. Die Karte zeigt Route und Punkte, aber nicht deine Position.';
    if (gpsStatus === 'fehlt') return 'Kein GPS auf diesem Gerät. Die Karte zeigt Route und Punkte, aber nicht deine Position.';
    return 'Position wird gesucht …';
  }

  function seiteKarte(id) {
    return daten.kartenDaten(id, 0).then(function (kd) {
      if (!kd.ok) return nichtGefunden('Aktivität nicht gefunden');
      return Promise.all([daten.fahrzeugStatus(kd.aktivitaet.fahrzeugId), daten.gpsSpurLesen(id), daten.geraetWetterRhythmus(), daten.gpsFahrtLesen(id)]).then(function (r) {
        var fzStatus = r[0], welt = kd.aktivitaet.welt;
        /* Der Weg im Speicher des Programms ist neuer als der gespeicherte. */
        if (gpsWegAkt === id && gpsWeg) kd.weg = gpsWeg;
        cockpitSpurVorbereiten(id, r[1], fzStatus, welt);
        wegVorbereiten(id, kd.weg, fzStatus, welt);
        fahrtVorbereiten(id, r[3], fzStatus, welt);
        gpsStarten();
        var kv = MM.Kartenansicht.aufbauen({
          ablage: ablage(), kd: kd,
          zurueck: '#/aktivitaet/' + enc(id), offline: '#/aktivitaet/' + enc(id) + '/karte/offline', routeSeite: '#/aktivitaet/' + enc(id) + '/route',
          beiZurueck: function () { reiterWahl[id] = 'cockpit'; },
          wetterNeu: function (v) { return daten.wetterStand(id, v).then(function (ws) { return ws.ok ? { zeilen: ws.zeilen, versatzMin: ws.versatzMin } : null; }); },
          wetterJetzt: function () {
            return daten.wetterJetzt(id, frischePosition()).then(function (x) {
              if (x.ok) { wetterErfolg = { akt: id, ms: Date.now() }; x.text = 'Wetter gespeichert, ' + x.zeit + ' Uhr. ' + x.text.replace(/^Wetter: /, ''); }
              return x;
            });
          },
          neuLaden: function () { return daten.kartenDaten(id, 0).then(function (n) { if (!n.ok) return null; if (gpsWegAkt === id && gpsWeg) n.weg = gpsWeg; return n; }); },
          gpsText: gpsTextKurz
        });
        if (kv.fehler) {
          seite('Karte', [krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [kd.aktivitaet.name, '#/aktivitaet/' + enc(id)], ['Karte']]),
            h('h1', { text: 'Karte' }), h('p', { class: 'fehlerkasten', role: 'alert', text: kv.fehler })]);
          return null;
        }
        aktuelleKarte = kv;
        gpsHorcher = function () { kv.position(frischePosition()); };
        kv.position(frischePosition());
        vollbildSeite('Karte – ' + kd.aktivitaet.name, kv.element);
        kv.start();
        var autoErlaubt = !(fzStatus && fzStatus.ok && fzStatus.hatStatus) || gpsInFahrt;
        function autoPlanen() {
          wetterAutoPlanen(id, kv.element, kd.ereignisse, r[2].minuten, autoErlaubt, function (x) {
            kv.meldung('Wetter automatisch gespeichert, ' + x.zeit + ' Uhr. ' + x.text.replace(/^Wetter \(automatisch\): /, ''));
            kv.aktualisieren();
            autoPlanen();
          });
        }
        autoPlanen();
        return null;
      });
    });
  }

  /* ---------- Seite: Offline-Karte (seit 2.0.34): Kacheln für das Gebiet der Aktivität im Gerät ablegen ---------- */
  function seiteKarteOffline(id) {
    return Promise.all([daten.kartenDaten(id, 0), daten.karteInfo(id), daten.kartePlanen(id, 'grob'), daten.kartePlanen(id, 'mittel'), daten.kartePlanen(id, 'fein')]).then(function (r) {
      var kd = r[0], info = r[1], plaene = { grob: r[2], mittel: r[3], fein: r[4] };
      if (!kd.ok) return nichtGefunden('Aktivität nicht gefunden');
      var q = MM.Karte.QUELLE, zurKarte = '#/aktivitaet/' + enc(id) + '/karte';
      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [kd.aktivitaet.name, '#/aktivitaet/' + enc(id)], ['Karte', zurKarte], ['Offline-Karte']]),
        h('h1', { text: 'Offline-Karte' }),
        h('p', { text: 'Damit die Karte unterwegs ohne Netz funktioniert, holst du sie vorher, solange du Netz hast. Geholt wird nur ein Streifen entlang deiner Route, keine Weltkarte.' })];

      inhalt.push(info
        ? h('section', { class: 'bereich', 'aria-label': 'Stand' }, h('h2', { text: 'Schon im Gerät' }),
          h('p', { text: info.anzahl + (info.anzahl === 1 ? ' Kachel' : ' Kacheln') + ', etwa ' + MM.Karte.groesseText(info.bytes) + ', zuletzt geholt am ' + MM.Hilfen.datum(String(info.geladenAm).slice(0, 10)) + '.' }),
          h('p', { class: 'knopfzeile' }, h('button', { class: 'knopf gefahr klein', type: 'button', text: 'Offline-Karte dieser Aktivität löschen', onclick: function () {
            if (!global.confirm('Die Kacheln dieser Aktivität aus dem Gerät löschen? Kacheln, die auch eine andere Aktivität braucht, bleiben.')) return;
            daten.karteFreigeben(id).then(function (x) { return ablage().loeschen(x.keys).then(function (n) { meldung = n + (n === 1 ? ' Kachel' : ' Kacheln') + ' gelöscht.'; return zeige(); }); }).catch(fehlerSeite);
          } }))) : h('p', { class: 'hinweis', text: 'Für diese Aktivität ist noch keine Offline-Karte im Gerät.' }));

      var brauchbar = ['grob', 'mittel', 'fein'].filter(function (k) { return plaene[k].ok; });
      var erste = plaene.grob;
      if (!brauchbar.length) {
        inhalt.push(h('p', { class: 'fehlerkasten', role: 'alert', text: erste.grund || 'Es kann keine Karte geholt werden.' }));
        if (!kd.route) inhalt.push(h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf', href: '#/aktivitaet/' + enc(id) + '/route', text: 'Route einlesen' })));
      } else {
        var grundlage = erste.quelle === 'route' ? 'Grundlage ist die Route „' + kd.route.name + '“.' : 'Es gibt keine Route, Grundlage sind Start, Ziel und Zwischenziele mit Position.';
        var gewaehlt = brauchbar.indexOf('mittel') >= 0 ? 'mittel' : brauchbar[brauchbar.length - 1];
        var stufenEl = h('div', { class: 'stufenwahl', role: 'radiogroup', 'aria-label': 'Genauigkeit der Karte' });
        MM.Karte.STUFEN.forEach(function (st) {
          var pl = plaene[st.wert], rid = 'ok-' + st.wert;
          var radio = h('input', { type: 'radio', name: 'ok-stufe', id: rid, value: st.wert, onchange: function () { gewaehlt = st.wert; } });
          if (!pl.ok) radio.setAttribute('disabled', '');
          if (st.wert === gewaehlt) radio.checked = true;
          stufenEl.appendChild(h('div', { class: 'feld' }, radio, ' ', h('label', { for: rid, text: st.label }),
            h('span', { class: 'frist-info', text: pl.ok ? ' – ' + pl.anzahl + ' Kacheln, etwa ' + MM.Karte.groesseText(pl.bytes) : ' – ' + (pl.grund || 'nicht möglich') })));
        });
        var fortschritt = h('p', { class: 'hinweis', role: 'status' });
        var laeuft = false, abbrechenFlag = false;
        var stopp = h('button', { class: 'knopf leise', type: 'button', text: 'Abbrechen', onclick: function () { abbrechenFlag = true; fortschritt.textContent = 'Wird abgebrochen …'; } });
        stopp.hidden = true;
        var holen = h('button', { class: 'knopf', type: 'button', text: 'Karte jetzt holen', onclick: function () {
          if (laeuft) return;
          var pl = plaene[gewaehlt];
          if (!pl || !pl.ok) return;
          laeuft = true; abbrechenFlag = false; holen.disabled = true; stopp.hidden = false;
          fortschritt.textContent = 'Es geht los …';
          ablage().holen(pl.kacheln, {
            fortschritt: function (f, g) { fortschritt.textContent = 'Kacheln geholt: ' + f + ' von ' + g; },
            abbrechen: function () { return abbrechenFlag; }
          }).then(function (res) {
            var gemerkt = res.urls.length ? daten.karteMerken(id, gewaehlt, res.urls, res.bytes) : Promise.resolve(null);
            return gemerkt.then(function () {
              var text = res.ok && !res.abgebrochen && !res.fehler ? 'Fertig: ' + res.urls.length + ' Kacheln im Gerät (' + res.neu + ' neu geholt, ' + res.schon + ' waren schon da).'
                : (res.abgebrochen ? 'Abgebrochen. ' + res.urls.length + ' Kacheln sind im Gerät.' : (res.grund || 'Das hat nicht geklappt.') + ' ' + res.urls.length + ' Kacheln sind im Gerät.');
              if (global.location.hash.indexOf('/karte/offline') < 0) return null;
              meldung = text;
              return zeige();
            });
          }).catch(fehlerSeite);
        } });
        inhalt.push(h('section', { class: 'bereich', 'aria-label': 'Karte holen' }, h('h2', { text: 'Karte holen' }), h('p', { class: 'hilfe', text: grundlage }), stufenEl,
          global.navigator && global.navigator.onLine === false ? h('p', { class: 'hinweis', text: 'Dieses Gerät meldet gerade kein Netz. Zum Holen braucht es Netz.' }) : null,
          h('p', { class: 'knopfzeile' }, holen, stopp), fortschritt));
      }
      inhalt.push(h('details', { class: 'ausgebaut' }, h('summary', { text: 'Woher die Karte kommt und was zu beachten ist' }),
        h('ul', { class: 'gruende' },
          h('li', { text: 'Kartenquelle: ' + q.name + ' (' + q.nachweis + '). Der Nachweis steht auf der Karte.' }),
          h('li', { text: 'Diese Quelle ist für Tests im kleinen Rahmen gedacht. Die App holt höchstens ' + q.maxKacheln + ' Kacheln auf einmal, nur wenn du es auslöst, mit Pausen dazwischen. Vor einer Veröffentlichung in einem App-Store wird die Quelle gewechselt.' }),
          h('li', { text: 'Die Kacheln liegen nur auf diesem Gerät und nicht in der Sicherungsdatei. Du kannst sie jederzeit neu holen.' }),
          h('li', { text: 'Je feiner die Stufe, desto mehr Platz und Zeit braucht sie. Die Größe ist vorab geschätzt.' }))));
      seite('Offline-Karte', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: zurKarte, text: 'Zurück zur Karte' })));
    });
  }

  /* ---------- Formular: Wetter im Rhythmus (seit 2.0.34), gilt nur für dieses Gerät ---------- */
  function wetterRhythmusFormular() {
    return daten.geraetWetterRhythmus().then(function (g) {
      einfachFormular({
        titel: 'Wetter im Rhythmus',
        krumen: krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen', '#/einstellungen'], ['Wetter im Rhythmus']]),
        zurueck: '#/einstellungen',
        werte: { rhythmus: String(g.minuten) },
        intro: [h('p', { text: 'Das Wetter lässt sich im Cockpit mit „Wetter jetzt“ von Hand holen. Hier stellst du ein, dass die App es zusätzlich selbst holt und als Eintrag „Wetter“ ins Logbuch schreibt, mit Datum, Uhrzeit und Position. Im selben Rhythmus speichert die App auch die Geschwindigkeitswerte (aktuell, Ø fahrend, Ø Tag) als Eintrag „Geschwindigkeit“. Das ist der eine Rhythmus für alle automatischen Einträge im Logbuch.' }),
          h('p', { class: 'hilfe', text: 'Das passiert nur, solange das Cockpit oder die Karte offen ist, das Fahrzeug in Fahrt ist und das Gerät GPS und Netz hat. Ein Browser holt im Hintergrund nichts. Beim Wetter wird ohne Netz nichts gespeichert und frühestens nach 10 Minuten neu versucht, die Geschwindigkeit braucht kein Netz. Die Einstellung gilt nur für dieses Gerät.' })],
        gruppen: function () {
          return [{ titel: null, felder: [{ key: 'rhythmus', label: 'Wie oft', typ: 'auswahl', optionen: MM.Karte.RHYTHMEN.map(function (x) { return { wert: String(x.wert), label: x.label }; }) }] }];
        },
        speichern: function (w) { return daten.geraetWetterRhythmusSetzen(w.rhythmus); },
        meldung: function (x) { return x.minuten ? 'Gespeichert. Das Wetter wird im Cockpit ' + (x.minuten === 60 ? 'jede Stunde' : 'alle ' + (x.minuten % 60 === 0 ? (x.minuten / 60) + ' Stunden' : x.minuten + ' Minuten')) + ' geholt.' : 'Gespeichert. Das Wetter wird nicht automatisch geholt, und es gibt keine Zwischenwerte der Geschwindigkeit. Der Tageswert kommt weiter beim Tagesabschluss.'; },
        danach: function () { return '#/einstellungen'; }
      });
    });
  }

  /* Block in den Einstellungen: Wetter und Karte */
  function wetterKartenBlock() {
    return h('section', { class: 'block' }, h('h2', { text: 'Wetter und Karte' }),
      h('p', { text: 'Im Cockpit holt „Wetter jetzt“ das Wetter am Standort. Es kann auch im Rhythmus automatisch geholt werden. Karten für unterwegs holst du je Aktivität unter „Karte“, „Offline-Karte“.' }),
      h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: '#/wetterrhythmus', text: 'Wetter im Rhythmus einstellen' })));
  }

  /* ---------- Formular: Wartezeit der Motorstopp-Frage (seit 2.0.22), gilt nur für dieses Gerät ---------- */
  function motorFrageFormular(fahrzeugId, aktId) {
    return daten.geraetWartezeit().then(function (g) {
      var zurueck = fahrzeugId ? '#/motoren/' + enc(fahrzeugId) + (aktId ? '?aktivitaet=' + enc(aktId) : '') : '#/einstellungen';
      einfachFormular({
        titel: 'Motorstopp-Frage',
        krumen: krumen([['Hauptmenü', '#/auswahl'], fahrzeugId ? ['Motoren', zurueck] : ['Einstellungen', zurueck], ['Motorstopp-Frage']]),
        zurueck: zurueck,
        werte: { wartezeit: String(g.wartezeit) },
        intro: [h('p', { text: 'Bei Ankunft, Anlegen oder Anker werfen fragt die App: „' + MM.Motoren.FRAGE_TEXT + '“ Läuft der Motor danach noch, schlägt sie nach der Wartezeit die Zeit der Ankunft als Stoppzeit vor, und du übernimmst sie oder sagst „Läuft weiter“.' }),
          h('p', { class: 'hilfe', text: 'Die Wartezeit gilt nur für dieses Gerät. Ausgelöst wird die Frage nie von der Laufzeit des Motors, sondern immer von einem Ereignis am Ziel. Vorgabe: ' + MM.Motoren.WARTEZEIT_STANDARD + ' Minuten.' })],
        gruppen: function () {
          return [{ titel: null, felder: [{ key: 'wartezeit', label: 'Wartezeit in Minuten (' + MM.Motoren.WARTEZEIT_MIN + ' bis ' + MM.Motoren.WARTEZEIT_MAX + ')', typ: 'ganzzahl' }] }];
        },
        speichern: function (w) { return daten.geraetWartezeitSetzen(w.wartezeit); },
        meldung: function (r) { return 'Gespeichert. Die Frage kommt nach ' + r.wartezeit + (r.wartezeit === 1 ? ' Minute' : ' Minuten') + ' mit dem Vorschlag der Stoppzeit.'; },
        danach: function () { return zurueck; }
      });
    });
  }

  /* ---------- Formular: Stoppzeit eines Motorlaufs korrigieren ---------- */
  function laufKorrigierenFormular(laufId, fahrzeugId, aktId) {
    return daten.motorenListe(fahrzeugId).then(function (motoren) {
      var m = null, l = null;
      motoren.forEach(function (x) { x.laeufe.forEach(function (y) { if (y.id === laufId) { m = x; l = y; } }); });
      if (!l) return nichtGefunden('Lauf nicht gefunden');
      var zurueck = '#/motoren/' + enc(fahrzeugId) + (aktId ? '?aktivitaet=' + enc(aktId) : '');
      einfachFormular({
        titel: 'Stoppzeit korrigieren',
        krumen: krumen([['Hauptmenü', '#/auswahl'], ['Motoren', zurueck], [m.name], ['Stoppzeit korrigieren']]),
        zurueck: zurueck,
        werte: { datum: MM.Motoren.ortsdatum(l.stopp), zeit: MM.Motoren.ortszeit(l.stopp) },
        intro: [h('p', { text: m.name + ': gestartet ' + MM.Hilfen.zeitpunkt(l.start) + ', gestoppt ' + MM.Hilfen.zeitpunkt(l.stopp) + ' (' + (MM.Motoren.stundenText(l.stunden) || 'unter einer Minute') + ').' }),
          h('p', { class: 'hilfe', text: 'Trage ein, wann der Motor wirklich gestoppt wurde. Der Zählerstand wird neu gerechnet. Der alte Stand bleibt im Verlauf des Zählers sichtbar.' })],
        gruppen: function () {
          return [{ titel: null, felder: [
            { key: 'datum', label: 'Gestoppt am', typ: 'datum' },
            { key: 'zeit', label: 'Uhrzeit', typ: 'zeit' }] }];
        },
        speichern: function (w) { return daten.motorLaufKorrigieren(laufId, w); },
        meldung: function (r) { return r.geaendert ? 'Stoppzeit korrigiert. Neuer Stand: ' + zahlMit(r.stand, 'h') + '.' : 'Es gab keine Änderung.'; },
        danach: function () { return zurueck; }
      });
    });
  }

  /* ---------- Reiter „Logbuch“: klassisch, alle Tage und Ereignisse der Reihe nach, mit Verlauf ---------- */
  function logbuchPanel(a, lb, storniert, zus, wahl) {
    var id = a.aktivitaet.id;
    var sichtbar = lb.abschnitte.filter(function (x) { return !x.ausgeblendet; });
    var versteckt = lb.abschnitte.filter(function (x) { return x.ausgeblendet; });

    function tagKarte(x) {
      var w = x.aktuell.werte, tid = enc(x.objekt.id);
      var zz = zus ? zus.tage.filter(function (t) { return t.id === x.objekt.id; })[0] : null;
      var kopfInfo = [vonNachText(w, zz), uhrzeitenText(w)].filter(Boolean).join(', ');
      var ereig = x.ereignisse.filter(function (e) { return !e.ausgeblendet; });
      var weg = x.ereignisse.filter(function (e) { return e.ausgeblendet; });
      return h('article', { class: 'tag-karte' + (x.ausgeblendet ? ' ausgeblendet' : '') },
        h('h3', null, h('a', { href: '#/tagesabschnitt/' + tid, text: tagText(w) })),
        x.ausserhalb ? h('p', { class: 'hinweis-frist status-bald', text: 'Außerhalb des Zeitraums der Aktivität' }) : null,
        kopfInfo ? h('p', { class: 'frist-info', text: kopfInfo }) : null,
        x.verantwortlicher ? h('p', { class: 'frist-info', text: MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt) + ' zum Tagesbeginn: ' + x.verantwortlicher.name }) : null,
        h('p', { class: 'frist-info', text: x.pruefung ? 'Prüfung zum Tagesbeginn: ' + MM.Logbuch.pruefungKurz(x.pruefung.stand) + ' (geprüft am ' + jetztText(x.pruefung.stand.geprueftAm) + ')' : 'Prüfung zum Tagesbeginn noch nicht festgehalten' }),
        w.notiz ? h('p', { class: 'frist-info', text: 'Notiz: ' + w.notiz }) : null,
        ereig.length ? h('ul', { class: 'fristen' }, ereig.map(function (e) { return ereignisZeile(e, w.datum); })) : h('p', { class: 'leer-text', text: 'Noch kein Ereignis.' }),
        weg.length ? h('details', { class: 'ausgebaut' }, h('summary', { text: 'Ausgeblendete Ereignisse (' + weg.length + ')' }), h('ul', { class: 'fristen' }, weg.map(function (e) { return ereignisZeile(e, w.datum); }))) : null,
        MM.Logbuch.hatAbschluss(w) ? h('p', { class: 'tag-abschluss' }, h('strong', { text: 'Tagesabschluss: ' }),
          w.zielTatsaechlich ? 'Ziel ' + w.zielTatsaechlich : null, w.zielTatsaechlich && w.abschlussNotiz ? '. ' : null, w.abschlussNotiz ? w.abschlussNotiz : null) : null,
        storniert ? null : h('p', { class: 'knopfzeile' },
          h('a', { class: 'knopf leise klein', href: '#/tagesabschnitt/' + tid + '/ereignis/neu', text: 'Ereignis' }),
          h('a', { class: 'knopf leise klein', href: '#/tagesabschnitt/' + tid + '/nachtragen', text: 'Nachtragen' }),
          h('a', { class: 'knopf leise klein', href: '#/tagesabschnitt/' + tid + '/abschluss', text: 'Tagesabschluss' }),
          h('a', { class: 'knopf leise klein', href: '#/tagesabschnitt/' + tid + '/aendern', text: 'Tag ändern' }),
          h('a', { class: 'knopf leise klein', href: '#/tagesabschnitt/' + tid, text: 'Verlauf und Prüfung' })));
    }
    return [
      h('p', { class: 'hilfe', text: (wahl ? 'Der gewählte Tag, wie in einem Logbuch auf Papier. ' : 'Alle Tage der Reihe nach, wie in einem Logbuch auf Papier. ') + 'Hier wird geändert, nachgetragen und ausgeblendet. Jede Änderung bleibt im Verlauf, nichts wird gelöscht. Es sind dieselben Einträge wie im Cockpit.' }),
      wahl ? tagWaehler(id, wahl) : null,
      sichtbar.length ? (wahl ? sichtbar.filter(function (x) { return x.objekt.id === wahl.id; }) : sichtbar).map(tagKarte) : h('p', { class: 'leer-text', text: lb.abschnitte.length ? 'Alle Tage sind ausgeblendet.' : 'Noch keine Tage im Logbuch.' }),
      versteckt.length ? h('details', { class: 'ausgebaut' }, h('summary', { text: 'Ausgeblendete Tage (' + versteckt.length + ')' }), versteckt.map(tagKarte)) : null,
      lb.zuLang ? h('p', { class: 'hinweis', text: 'Der Zeitraum ist länger als ' + MM.Logbuch.MAX_TAGE + ' Tage. Die App bereitet ihn nicht vor. Lege die Tage von Hand an.' }) : null,
      storniert ? h('p', { class: 'hinweis', text: 'Die Aktivität ist storniert. Es kommt nichts Neues ins Logbuch, bis sie wieder hergestellt ist.' })
        : h('p', { class: 'knopfzeile' },
          lb.fehlend ? h('button', { class: 'knopf', type: 'button', text: 'Tage aus dem Zeitraum vorbereiten (' + lb.fehlend + ')',
            onclick: function () { reiterWahl[id] = 'logbuch'; tuMeldung(daten.tagesabschnitteVorbereiten(id), function (r) { return r.anzahl + (r.anzahl === 1 ? ' Tag vorbereitet.' : ' Tage vorbereitet.'); }); } }) : null,
          h('a', { class: 'knopf leise', href: '#/aktivitaet/' + enc(id) + '/tag/neu', text: 'Tag ergänzen' })),
      h('p', null, h('a', { href: '#/ereignisarten', text: 'Arten von Ereignissen verwalten' }))
    ];
  }

  /* Eine festgehaltene Prüfung (so, wie sie damals war) */
  function festgehaltenAnsicht(s) {
    var E = MM.Aktivitaeten.ERGEBNIS;
    var fr = s.fristen;
    return h('div', { class: 'pruef-person' },
      h('p', null, h('strong', { text: 'Geprüft am ' + jetztText(s.geprueftAm) }),
        s.verantwortlich ? h('span', { class: 'frist-info', text: '  Verantwortlich zum Tagesbeginn: ' + s.verantwortlich.name }) : null),
      h('p', null,
        h('span', { class: 'chip-status gross ' + ERG_KLASSE[s.befaehigung.ergebnis], text: 'Befähigung: ' + E[s.befaehigung.ergebnis] }), ' ',
        s.ausruestung ? h('span', { class: 'chip-status gross ' + ERG_KLASSE[s.ausruestung.ergebnis], text: 'Ausrüstung: ' + E[s.ausruestung.ergebnis] }) : null, ' ',
        h('span', { class: 'chip-status gross ' + (fr.sperre ? 'status-ueberfaellig' : (fr.betroffen ? 'status-bald' : 'status-ok')),
          text: fr.betroffen ? 'Fristen: ' + fr.betroffen + ' betroffen' : 'Fristen: keine betroffen' })),
      h('details', { class: 'ausgebaut' }, h('summary', { text: 'Einzelheiten' }),
        s.verantwortlich && s.verantwortlich.ergebnis ? h('p', null, h('strong', { text: s.verantwortlich.name }), ' (verantwortlich zum Tagesbeginn): ',
          h('span', { class: 'chip-status ' + ERG_KLASSE[s.verantwortlich.ergebnis], text: E[s.verantwortlich.ergebnis] })) : null,
        s.befaehigung.personen.map(function (p) {
          return h('div', null,
            h('p', null, h('strong', { text: p.name }), ' (' + p.rolleText + '): ', h('span', { class: 'chip-status ' + ERG_KLASSE[p.ergebnis], text: E[p.ergebnis] })),
            h('ul', { class: 'gruende' }, p.gruende.map(function (g) { return h('li', { class: ERG_KLASSE[g.ergebnis], text: g.text }); })));
        }),
        s.befaehigung.gebietHinweis ? h('p', { class: 'hinweis', text: s.befaehigung.gebietHinweis }) : null,
        s.ausruestung ? h('div', null, h('p', null, h('strong', { text: 'Pflichtausrüstung' })),
          h('ul', { class: 'gruende' }, s.ausruestung.liste.map(function (x) { return h('li', { class: x.status === 'eingetragen' ? ERG_KLASSE.erlaubt : ERG_KLASSE.unklar, text: x.bezeichnung + ' – ' + x.text }); }))) : null,
        h('div', null, h('p', null, h('strong', { text: 'Fristen des Fahrzeugs bis zum Ende der Aktivität' })),
          fr.liste.length ? h('ul', { class: 'gruende' }, fr.liste.map(function (f) {
            var e = FRIST_ERG[f.status];
            return h('li', { class: e[1] }, h('strong', { text: f.bezeichnung }), ': ' + e[0] + (f.wirkung ? ' (Wirkung: ' + MM.Fristen.labelVon(MM.Fristen.WIRKUNGEN, f.wirkung) + ')' : '') + '. ' + f.text);
          })) : h('p', { class: 'leer-text', text: fr.gesamt ? 'Keine Frist war betroffen.' : 'Am Fahrzeug gab es keine Fristen.' }))));
  }

  function ereignisZeile(e, tagDatum) {
    var href = e.art === 'wechsel' ? '#/wechsel/' + enc(e.id) : '#/ereignis/' + enc(e.id);
    var wann = (e.datum !== tagDatum ? MM.Hilfen.datum(e.datum).slice(0, 6) + ' ' : '') + (e.zeit ? e.zeit + ' Uhr' : '');
    return h('li', null, h('a', { class: 'frist', href: href },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: wann + ' – ' + e.artName }),
        e.text ? h('span', { class: 'frist-info', text: e.text }) : null,
        e.art === 'wechsel' && e.notiz ? h('span', { class: 'frist-info', text: 'Notiz: ' + e.notiz }) : null,
        e.art === 'wechsel' && e.pruefung ? h('span', { class: 'frist-info' }, pruefChip(e.pruefung)) : null,
        ortZeile(e) ? h('span', { class: 'frist-info', text: ortZeile(e) }) : null,
        e.nachgetragen ? h('span', { class: 'hinweis-frist status-bald', text: 'Nachgetragen am ' + MM.Hilfen.zeitpunkt(e.nachgetragenAm) + ' Uhr' }) : null,
        e.fremdeArt ? h('span', { class: 'hinweis-frist status-unbekannt', text: 'Gehört nicht mehr zur Fahrzeugart' }) : null,
        e.geaendert ? h('span', { class: 'frist-info', text: 'Korrigiert. Der frühere Stand steht im Verlauf.' }) : null,
        e.hatFoto ? h('span', { class: 'frist-info', text: 'Mit Foto' }) : null),
      e.art === 'wechsel' ? h('span', { class: 'chip-status', text: 'automatisch' }) : null));
  }

  /* ---------- Seite: ein Tag im Logbuch ---------- */
  function seiteTagesabschnitt(id) {
    return daten.abschnittLaden(id).then(function (r) {
      if (!r) return nichtGefunden('Tag nicht gefunden');
      return daten.reiseZusammenfassung(r.aktivitaet.aktivitaet.id).then(function (zus) { return tagesseiteZeigen(id, r, zus); });
    });
  }
  function tagesseiteZeigen(id, r, zus) {
    {
      var x = r.abschnitt, a = r.aktivitaet, w = x.aktuell.werte;
      var zeile = zus ? zus.tage.filter(function (t) { return t.id === id; })[0] : null;
      var storniert = a.aktuell.werte.status === 'storniert';
      var verantwortlich = MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt);
      var p = x.pruefung;
      var sichtbar = x.ereignisse.filter(function (e) { return !e.ausgeblendet; });
      var versteckt = x.ereignisse.filter(function (e) { return e.ausgeblendet; });

      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Tag im Logbuch' }),
        h('h1', { text: tagText(w) }),
        x.ausgeblendet ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Dieser Tag ist ausgeblendet. Er ist nicht gelöscht.' }) : null,
        x.ausserhalb ? h('p', { class: 'hinweis', text: 'Dieser Tag liegt außerhalb des Zeitraums der Aktivität (' + zeitraumText(a.aktuell.werte) + ').' }) : null,
        h('dl', { class: 'daten stapel' },
          h('dt', { text: 'Aktivität' }), h('dd', null, h('a', { href: '#/aktivitaet/' + enc(a.aktivitaet.id), text: a.aktuell.werte.bezeichnung })),
          w.beginnZeit ? [h('dt', { text: 'Beginn' }), h('dd', { text: w.beginnZeit + ' Uhr' })] : null,
          w.endeZeit ? [h('dt', { text: 'Ende' }), h('dd', { text: w.endeZeit + ' Uhr' })] : null,
          !zeile || !zeile.start ? (w.von ? [h('dt', { text: 'Von' }), h('dd', { text: w.von })] : null) : null,
          !zeile || !zeile.ziel ? (w.nach ? [h('dt', { text: 'Nach' }), h('dd', { text: w.nach })] : null) : null,
          x.verantwortlicher ? [h('dt', { text: verantwortlich + ' zum Tagesbeginn' }), h('dd', { text: x.verantwortlicher.name + ' (ab ' + jetztText(x.tagesbeginn) + ')' })] : null,
          w.notiz ? [h('dt', { text: 'Notiz' }), h('dd', { text: w.notiz })] : null,
          w.zielTatsaechlich ? [h('dt', { text: 'Tatsächliches Ziel' }), h('dd', { text: w.zielTatsaechlich })] : null,
          w.abschlussNotiz ? [h('dt', { text: 'Notiz zum Tagesabschluss' }), h('dd', { text: w.abschlussNotiz })] : null),
        storniert ? null : h('p', { class: 'knopfzeile' },
          h('a', { class: 'knopf leise', href: '#/tagesabschnitt/' + enc(id) + '/aendern', text: 'Angaben ändern' }),
          h('a', { class: 'knopf leise', href: '#/tagesabschnitt/' + enc(id) + '/abschluss', text: MM.Logbuch.hatAbschluss(w) ? 'Tagesabschluss ändern' : 'Tagesabschluss' })));

      var pruefung = h('section', { class: 'bereich', 'aria-label': 'Prüfung zum Tagesbeginn' },
        h('h2', { text: 'Prüfung zum Tagesbeginn' }),
        h('p', { class: 'hilfe', text: 'Die App rechnet die Prüfung der Aktivität neu und hält das Ergebnis für diesen Tag fest, mit „geprüft am“ und dem ' + verantwortlich + ' dieses Tages. Spätere Änderungen verändern das Festgehaltene nicht. Das ist eine Hilfestellung und keine rechtliche Aussage. Die letzte Verantwortung hat der ' + verantwortlich + '.' }),
        p ? festgehaltenAnsicht(p.stand) : h('p', { class: 'leer-text', text: 'Für diesen Tag ist noch keine Prüfung festgehalten.' }),
        x.pruefungen.length > 1 ? h('details', { class: 'ausgebaut' }, h('summary', { text: 'Frühere Festhaltungen (' + (x.pruefungen.length - 1) + ')' }),
          x.pruefungen.slice(1).map(function (q) { return festgehaltenAnsicht(q.stand); })) : null,
        storniert ? null : h('p', { class: 'knopfzeile' }, h('button', { class: 'knopf', type: 'button', text: p ? 'Prüfung neu festhalten' : 'Prüfung jetzt festhalten',
          onclick: function () { tuMeldung(daten.tagesPruefungFesthalten(id), function () { return 'Die Prüfung ist für diesen Tag festgehalten.'; }); } })));

      var ereignisse = h('section', { class: 'bereich', 'aria-label': 'Ereignisse' },
        h('h2', { text: 'Ereignisse' }),
        sichtbar.length ? h('ul', { class: 'fristen' }, sichtbar.map(function (e) { return ereignisZeile(e, w.datum); })) : h('p', { class: 'leer-text', text: 'Noch kein Ereignis an diesem Tag.' }),
        versteckt.length ? h('details', { class: 'ausgebaut' }, h('summary', { text: 'Ausgeblendete Ereignisse (' + versteckt.length + ')' }),
          h('ul', { class: 'fristen' }, versteckt.map(function (e) { return ereignisZeile(e, w.datum); }))) : null,
        storniert ? null : [h('p', { class: 'knopfzeile' },
          h('a', { class: 'knopf', href: '#/tagesabschnitt/' + enc(id) + '/ereignis/neu', text: 'Ereignis eintragen' }),
          h('a', { class: 'knopf leise', href: '#/tagesabschnitt/' + enc(id) + '/nachtragen', text: 'Nachtragen' })),
        h('p', { class: 'hilfe', text: 'Nachtragen: Du trägst ein Ereignis später mit dem echten Zeitpunkt ein. Es steht dann als „nachgetragen am …“ da. Ein Wechsel des Verantwortlichen kommt von selbst dazu.' })],
        h('p', null, h('a', { href: '#/ereignisarten', text: 'Arten von Ereignissen verwalten' })));

      seite(tagText(w), [
        krumen(logbuchKrumen(a, [[tagText(w)]])),
        kopf, zeile ? etappeBlock(zeile, id, a.aktivitaet.id, a.fahrzeug.id, w, storniert) : null, pruefung, ereignisse, x.verlauf.length > 1 ? verlaufBlock(x.verlauf) : null
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/aktivitaet/' + enc(a.aktivitaet.id), text: 'Zur Aktivität' }),
        storniert ? null : h('a', { class: 'knopf', href: '#/tagesabschnitt/' + enc(id) + '/ereignis/neu', text: 'Ereignis eintragen' })));
    }
  }

  /* ---------- Formular: Tag ergänzen / ändern ---------- */
  /* modus 'neu': id = Aktivität. modus 'aendern': id = Tag. */
  function abschnittFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = neu ? daten.aktivitaetLaden(id).then(function (a) { return a ? { a: a } : null; })
      : daten.abschnittLaden(id).then(function (r) { return r ? { a: r.aktivitaet, x: r.abschnitt } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var titel = neu ? 'Tag ergänzen' : 'Tag ändern';
      var zurueck = neu ? '#/aktivitaet/' + enc(k.a.aktivitaet.id) : '#/tagesabschnitt/' + enc(id);
      var weg = logbuchKrumen(k.a, neu ? [] : [[tagText(k.x.aktuell.werte), zurueck]]).concat([[titel]]);
      var start = neu ? { datum: '', beginnZeit: '', endeZeit: '', von: '', nach: '', notiz: '', startOrtId: '', zielOrtId: '', wetterHand: '', ausgeblendet: 'nein' } : JSON.parse(JSON.stringify(k.x.aktuell.werte));
      start.startOrtId = start.startOrtId || ''; start.zielOrtId = start.zielOrtId || ''; start.wetterHand = start.wetterHand || '';
      return daten.etappeOrtOptionen(k.a.aktivitaet.id, [start.startOrtId, start.zielOrtId]).then(function (oo) {
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: zurueck,
        werte: start,
        intro: neu ? h('p', { text: 'Ein Tag, der nicht zum vorbereiteten Zeitraum gehört, geht auch. Er wird dann als „außerhalb des Zeitraums“ gekennzeichnet.' }) : null,
        gruppen: function () {
          var ortHilfe = !oo.optionen.length ? 'Es gibt noch keine Orte. Lege sie unter Stammdaten › Orte an.'
            : (oo.nurPlan ? 'Zur Wahl stehen die Orte der Gesamtplanung dieser Reise (Start, Zwischenziele, Ziel). Weitere Orte trägst du bei der Aktivität ein.' : 'Die Aktivität hat noch keine geplanten Orte, darum stehen alle Orte zur Wahl.');
          var f = [
            { key: 'datum', label: 'Datum', typ: 'datum' },
            { key: 'beginnZeit', label: 'Beginn (Uhrzeit)', typ: 'zeit', hilfe: 'Freiwillig. Für das Wetter des Tages nötig, denn es gilt für die Ankunftszeit an jedem Punkt.' },
            { key: 'endeZeit', label: 'Ende (Uhrzeit)', typ: 'zeit', hilfe: 'Freiwillig.' },
            { key: 'startOrtId', label: 'Startort des Tages', typ: 'auswahl', optionen: oo.optionen, leerText: '– noch nicht gewählt –', hilfe: ortHilfe },
            { key: 'zielOrtId', label: 'Zielort des Tages', typ: 'auswahl', optionen: oo.optionen, leerText: '– noch nicht gewählt –', hilfe: 'Aus derselben Liste. Das Wetter und der Reisecheck dieses Tages nehmen genau diese zwei Orte.' }];
          if (start.von || start.nach) {
            f.push({ key: 'von', label: 'Von (früher als Text eingetragen)', typ: 'text', hilfe: 'Wird nur noch angezeigt, wenn kein Startort gewählt ist.' });
            f.push({ key: 'nach', label: 'Nach (früher als Text eingetragen)', typ: 'text', hilfe: 'Wird nur noch angezeigt, wenn kein Zielort gewählt ist.' });
          }
          f.push({ key: 'wetterHand', label: 'Wetter von Hand (freiwillig)', typ: 'text', hilfe: 'Ersetzt das Wetter, das die App aus den Orten holt. Leer lassen: Dann gilt das online geholte Wetter.' });
          f.push({ key: 'notiz', label: 'Notiz', typ: 'text' });
          if (!neu) f.push({ key: 'ausgeblendet', label: 'Ausblenden?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Nein, sichtbar' }, { wert: 'ja', label: 'Ja, ausblenden' }],
            hilfe: 'Ausgeblendete Tage stehen weiter im Logbuch unter „Ausgeblendete Tage“. Es wird nichts gelöscht.' });
          return [{ titel: null, felder: f }];
        },
        speichern: function (w) { return neu ? daten.abschnittAnlegen(k.a.aktivitaet.id, w) : daten.abschnittAendern(id, w); },
        meldung: function (r) { return neu ? 'Tag ergänzt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return '#/tagesabschnitt/' + enc(r.id); }
      });
      });
    });
  }

  /* ---------- Formular: Ereignis eintragen, nachtragen, ändern ---------- */
  /* modus 'neu' und 'nachtragen': id = Tag. modus 'aendern': id = Ereignis. */
  /* Störung im Logbuch (seit 2.0.26): ist die gewählte Art die Störung? Dann fragt das Formular, wie weit das Fahrzeug eingeschränkt ist. */
  function istStoerungGewaehlt(optionen, artId) {
    var o = artId ? optionen.filter(function (x) { return x.wert === artId; })[0] : null;
    return !!o && MM.Logbuch.istStoerungArt(o.label);
  }
  function auswirkungFeld() {
    return { key: 'auswirkung', label: 'Wie weit ist das Fahrzeug eingeschränkt?', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Werkstatt.AUSWIRKUNGEN,
      hilfe: 'Vorbelegt mit „bleibt nutzbar“. Die Störung steht dann auch in der Werkstatt, und die App warnt, wenn das Fahrzeug eingeschränkt und für die nächste Zeit versprochen ist.' };
  }

  function ereignisFormular(modus, id) {
    var aendern = modus === 'aendern', nachtragen = modus === 'nachtragen';
    if (!aendern && !nachtragen) gpsStarten();
    var fix = !aendern && !nachtragen ? frischePosition() : null;
    var vorschlagLaden = fix ? daten.ortNameVorschlag(fix.breite, fix.laenge) : Promise.resolve(null);
    var laden = aendern
      ? daten.ereignisLaden(id).then(function (x) { return x && x.abschnitt ? { x: x, abschnitt: x.abschnitt, a: x.aktivitaet, arten: x.arten } : null; })
      : Promise.all([daten.abschnittLaden(id), daten.ereignisartenListe()]).then(function (r) { return r[0] ? { abschnitt: r[0].abschnitt, a: r[0].aktivitaet, arten: r[1] } : null; });
    return Promise.all([laden, vorschlagLaden]).then(function (rr) {
      var k = rr[0], vorschlag = rr[1];
      if (!k) return nichtGefunden('Nicht gefunden');
      var tagW = k.abschnitt.aktuell.werte;
      var titel = aendern ? 'Ereignis ändern' : (nachtragen ? 'Ereignis nachtragen' : 'Ereignis eintragen');
      var tagHash = '#/tagesabschnitt/' + enc(k.abschnitt.objekt.id);
      var zurueck = aendern ? '#/ereignis/' + enc(id) : tagHash;
      var weg = logbuchKrumen(k.a, [[tagText(tagW), tagHash]]);
      if (aendern) weg.push([k.x.art ? k.x.art.name : 'Ereignis', zurueck]);
      weg.push([titel]);
      var bisherige = aendern ? k.x.aktuell.werte.artId : null;
      var fzArt = k.a && k.a.fahrzeug ? k.a.fahrzeug.artId : null;
      var artOptionen = k.arten.filter(function (x) {
        if (x.objekt.id === bisherige) return true;
        if (x.aktuell.werte.ausgeblendet === 'ja') return false;
        if (MM.Karte.istKartenArt(x.aktuell.werte.bezeichnung)) return false; /* „Karte“ öffnet nur die Karte, kein Logbuch-Eintrag (seit 2.0.35) */
        return !fzArt || MM.Logbuch.ereignisartGilt(x.aktuell.werte.zuordnung, fzArt);
      }).map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });
      var jetzt = daten.jetztLokal();
      var start = aendern ? JSON.parse(JSON.stringify(k.x.aktuell.werte))
        : { artId: '', datum: nachtragen ? tagW.datum : jetzt.slice(0, 10), zeit: nachtragen ? '' : jetzt.slice(11, 16), text: '', auswirkung: 'keine' };
      /* Position (seit 2.0.21): beim Eintragen „jetzt“ die frische GPS-Position, beim Ändern der gespeicherte Stand; beim Nachtragen leer (nur von Hand) */
      var altW = aendern ? k.x.aktuell.werte : null;
      if (aendern) {
        start.breite = koordFeld(altW.breite); start.laenge = koordFeld(altW.laenge); start.ortName = altW.ortName || '';
        if (altW.positionQuelle === 'gps') { start.gpsBreite = altW.breite; start.gpsLaenge = altW.laenge; start.gpsGenauigkeit = altW.positionGenauigkeit; }
      } else {
        start.breite = fix ? koordFeld(fix.breite) : ''; start.laenge = fix ? koordFeld(fix.laenge) : ''; start.ortName = vorschlag ? vorschlag.name : '';
        if (fix) { start.gpsBreite = fix.breite; start.gpsLaenge = fix.laenge; start.gpsGenauigkeit = fix.genauigkeit; }
      }
      var intro;
      if (!artOptionen.length && k.arten.some(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; })) {
        intro = h('div', { class: 'leer-hinweis' }, h('p', null, 'Für diese Fahrzeugart gilt noch keine Art von Ereignis. ',
          h('a', { class: 'knopf leise', href: '#/ereignisarten', text: 'Arten von Ereignissen verwalten' })));
      } else if (!artOptionen.length) {
        intro = h('div', { class: 'leer-hinweis' }, h('p', null, 'Es gibt noch keine Art von Ereignis. ',
          h('button', { class: 'knopf', type: 'button', text: 'Vorschläge übernehmen (Abfahrt, Ankunft, Wechsel des Verantwortlichen, Störung, Notiz)',
            onclick: function () { daten.ereignisartenAusVorschlaegen().then(function () { return zeige(); }).catch(fehlerSeite); } })));
      } else if (nachtragen) {
        intro = h('p', { text: 'Trage das Ereignis mit dem echten Zeitpunkt ein, an dem es wirklich war. Es steht dann als „nachgetragen am …“ da. Der Zeitpunkt darf nicht nach jetzt liegen.' });
      } else if (!aendern) {
        intro = h('p', { text: 'Der Zeitpunkt ist jetzt. War das Ereignis früher, nimm auf der Tagesseite „Nachtragen“.' });
      } else if (k.x.aktuell.werte.nachgetragen === 'ja') {
        intro = h('p', { text: 'Dieses Ereignis wurde nachgetragen. Das bleibt so stehen, auch wenn du es korrigierst.' });
      } else intro = null;
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: zurueck, werte: start, intro: intro, neuzeichnenBei: aendern ? [] : ['artId'],
        gruppen: function (z) {
          if (!artOptionen.length) return [];
          var f = [
            { key: 'artId', label: 'Art', typ: 'auswahl', optionen: artOptionen, leerText: '– bitte wählen –' }];
          /* Störung (seit 2.0.26): Beim Eintragen und Nachtragen legt das Ereignis den Vorgang in der Werkstatt an. */
          if (!aendern && istStoerungGewaehlt(artOptionen, z && z.werte && z.werte.artId)) f.push(auswirkungFeld());
          f.push({ key: 'datum', label: 'Datum', typ: 'datum' },
            { key: 'zeit', label: 'Uhrzeit', typ: 'zeit' },
            { key: 'text', label: 'Text', typ: 'text', hilfe: 'Freiwillig, zum Beispiel „Leinen los“ oder „Ölstand geprüft“. Bei einer Störung wird daraus die Beschreibung in der Werkstatt.' });
          if (!aendern) f.push({ key: 'datei', label: 'Foto (freiwillig)', typ: 'datei', accept: 'image/*', hilfe: 'Zum Beispiel ein Foto von unterwegs. Es bleibt nur auf diesem Gerät.' });
          else f.push({ key: 'ausgeblendet', label: 'Ausblenden?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Nein, sichtbar' }, { wert: 'ja', label: 'Ja, ausblenden' }],
            hilfe: 'Ausgeblendete Ereignisse stehen weiter im Logbuch unter „Ausgeblendete Ereignisse“. Es wird nichts gelöscht.' });
          var hinweis = aendern ? (altW.positionQuelle === 'gps' ? 'Die Position kam vom GPS. Änderst du die Zahlen, gilt sie danach als von Hand eingetragen.' : null)
            : (nachtragen ? 'Beim Nachtragen gibt es keine GPS-Position. Trage Breite und Länge von Hand ein, wenn du sie kennst.'
              : (fix ? 'Die Position kommt vom GPS dieses Geräts' + (isFinite(fix.genauigkeit) ? ' (Genauigkeit etwa ' + Math.round(fix.genauigkeit) + ' m)' : '') + (vorschlag ? '. Die App kennt diesen Ort (' + MM.Logbuch.entfernungText(vorschlag.abstand) + ' entfernt) und schlägt den Namen vor' : '') + '. Änderst du die Zahlen, gilt sie als von Hand eingetragen.'
                : 'Gerade keine GPS-Position. Du kannst Breite und Länge von Hand eintragen oder leer lassen.'));
          return [{ titel: null, felder: f }, { titel: 'Ort und Position (freiwillig)', hinweis: hinweis, felder: [
            { key: 'breite', label: 'Breite', typ: 'text', hilfe: 'Dezimalgrad, zum Beispiel 48,8566. Süd mit Minuszeichen oder S.' },
            { key: 'laenge', label: 'Länge', typ: 'text', hilfe: 'Dezimalgrad, zum Beispiel 2,3522. West mit Minuszeichen oder W.' },
            { key: 'ortName', label: 'Ortsname', typ: 'text', hilfe: 'Zum Beispiel „Schleuse Gamsheim“ oder „vor der Hafeneinfahrt“. Mit Position merkt sich die App den Namen für diese Gegend und schlägt ihn beim nächsten Mal vor.' }] }];
        },
        speichern: function (w) { return aendern ? daten.ereignisAendern(id, w).then(function (r) { r.id = id; return r; }) : daten.ereignisAnlegen(id, w, { nachtragen: nachtragen }); },
        meldung: function (r) { return aendern ? (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.') : ((nachtragen ? 'Nachgetragen.' : 'Ereignis eingetragen.') + (r.vorgangId ? ' Die Störung steht auch in der Werkstatt.' : '')); },
        danach: function (r) { return '#/ereignis/' + enc(r.id); }
      });
    });
  }

  /* ---------- Seite: Ereignis ---------- */
  function seiteEreignis(id) {
    return Promise.all([daten.ereignisLaden(id), daten.geraetKennung()]).then(function (rr) {
      var x = rr[0], meinGeraet = rr[1];
      if (!x || !x.abschnitt) return nichtGefunden('Ereignis nicht gefunden');
      var w = x.aktuell.werte, a = x.aktivitaet, tag = x.abschnitt;
      var storniert = a.aktuell.werte.status === 'storniert';
      var tagHash = '#/tagesabschnitt/' + enc(tag.objekt.id);
      var status = h('p', { class: 'oeffnen-status', role: 'status' });
      var vorschau = h('div', { class: 'vorschau' });
      if (x.datei && /^image\//.test(x.datei.mime || '')) {
        daten.ereignisDateiHolen(id).then(function (d) {
          if (d) vorschau.appendChild(h('img', { src: global.URL.createObjectURL(d.inhalt), alt: 'Foto zum Ereignis', class: 'vorschau-bild' }));
        });
      }
      var fotoTeil = x.datei ? h('section', { class: 'gruppe' }, h('h3', { text: 'Foto' }),
        h('p', { text: x.datei.name + ' (' + MM.Hilfen.groesse(x.datei.groesse) + '). Bleibt nur auf diesem Gerät.' }), vorschau,
        h('p', { class: 'knopfzeile' },
          h('button', { class: 'knopf leise', type: 'button', text: 'Öffnen', onclick: function () { dateiOeffnen(function () { return daten.ereignisDateiHolen(id); }, false, status); } }),
          h('button', { class: 'knopf leise', type: 'button', text: 'Auf dem Gerät speichern', onclick: function () { dateiOeffnen(function () { return daten.ereignisDateiHolen(id); }, true, status); } })),
        status) : null;
      var kopf = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: 'Ereignis im Logbuch' }),
        h('h1', { text: x.art ? x.art.name : 'Ereignis' }),
        w.ausgeblendet === 'ja' ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Dieses Ereignis ist ausgeblendet. Es ist nicht gelöscht.' }) : null,
        w.nachgetragen === 'ja' ? h('p', { class: 'hinweis status-bald', text: 'Nachgetragen am ' + MM.Hilfen.zeitpunkt(w.nachgetragenAm) + ' Uhr. Der Zeitpunkt unten ist der echte.' }) : null,
        h('dl', { class: 'daten stapel' },
          h('dt', { text: 'Zeitpunkt' }), h('dd', { text: zeitText(w.datum, w.zeit) }),
          h('dt', { text: 'Tag' }), h('dd', null, h('a', { href: tagHash, text: tagText(tag.aktuell.werte) })),
          h('dt', { text: 'Aktivität' }), h('dd', null, h('a', { href: '#/aktivitaet/' + enc(a.aktivitaet.id), text: a.aktuell.werte.bezeichnung })),
          w.text ? [h('dt', { text: 'Text' }), h('dd', { text: w.text })] : null,
          x.ereignis && x.ereignis.vorgangId ? [h('dt', { text: 'Werkstatt' }), h('dd', null, h('a', { href: '#/vorgang/' + enc(x.ereignis.vorgangId), text: 'Zum Vorgang dieser Störung' }))] : null,
          w.ortName ? [h('dt', { text: 'Ort' }), h('dd', { text: w.ortName + (w.ortNameQuelle === 'vorschlag' ? ' (Vorschlag der App, noch nicht von dir bestätigt)' : '') })] : null,
          typeof w.breite === 'number' && typeof w.laenge === 'number' ? [h('dt', { text: 'Position' }),
            h('dd', { text: MM.Logbuch.positionText(w.breite, w.laenge) + ', ' + (w.positionQuelle === 'gps' ? 'per GPS' + (typeof w.positionGenauigkeit === 'number' ? ' (Genauigkeit etwa ' + w.positionGenauigkeit + ' m)' : '') : 'von Hand eingetragen') })] : null,
          w.geraetId ? [h('dt', { text: 'Gerät' }), h('dd', { text: w.geraetId === meinGeraet ? 'dieses Gerät' : 'ein anderes Gerät' })] : null),
        fotoTeil,
        h('p', { class: 'stand', text: 'Herkunft: per Handeingabe. Stand vom ' + MM.Hilfen.zeitpunkt(x.aktuell.erstelltAm) }),
        storniert ? null : h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: '#/ereignis/' + enc(id) + '/aendern', text: 'Angaben ändern' })));
      seite(x.art ? x.art.name : 'Ereignis', [
        krumen(logbuchKrumen(a, [[tagText(tag.aktuell.werte), tagHash], [x.art ? x.art.name : 'Ereignis']])),
        kopf, x.verlauf.length > 1 ? verlaufBlock(x.verlauf) : null
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: tagHash, text: 'Zum Tag' }),
        storniert ? null : h('a', { class: 'knopf', href: '#/ereignis/' + enc(id) + '/aendern', text: 'Angaben ändern' })));
    });
  }

  /* ---------- Seite und Formular: Wechsel des Verantwortlichen (automatisches Ereignis) ---------- */
  function seiteWechsel(id) {
    return daten.wechselLaden(id).then(function (x) {
      if (!x) return nichtGefunden('Wechsel nicht gefunden');
      var wz = x.wechsel, a = x.aktivitaet;
      var storniert = a.aktuell.werte.status === 'storniert';
      var eintrag = a.verantwortung.filter(function (v) { return v.id === id; })[0];
      return daten.logbuchLaden(a.aktivitaet.id).then(function (lb) {
        var tag = lb ? lb.abschnitte.filter(function (t) { return t.ereignisse.some(function (e) { return e.id === id; }); })[0] : null;
        var kopf = h('section', { class: 'schale sx' },
          h('div', { class: 'schale-name', text: 'Automatisches Ereignis im Logbuch' }),
          h('h1', { text: MM.Logbuch.WECHSEL_ART }),
          wz.ausgeblendet ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Dieses Ereignis ist im Logbuch ausgeblendet. Die Verantwortung bleibt, wie sie ist.' }) : null,
          wz.nachgetragenAm ? h('p', { class: 'hinweis status-bald', text: 'Nachgetragen am ' + MM.Hilfen.zeitpunkt(wz.nachgetragenAm) + ' Uhr. Der Zeitpunkt unten ist der echte.' }) : null,
          h('p', { text: wz.text }),
          wechselPruefungAnsicht(wz.pruefung, a.fahrzeug.welt),
          h('dl', { class: 'daten stapel' },
            h('dt', { text: 'Zeitpunkt' }), h('dd', { text: zeitText(wz.datum, wz.zeit) }),
            eintrag && eintrag.geaendert && eintrag.abUrspruenglich !== eintrag.ab ? [h('dt', { text: 'Ursprünglicher Zeitpunkt' }), h('dd', { text: jetztText(eintrag.abUrspruenglich) })] : null,
            tag ? [h('dt', { text: 'Tag' }), h('dd', null, h('a', { href: '#/tagesabschnitt/' + enc(tag.objekt.id), text: tagText(tag.aktuell.werte) }))] : null,
            h('dt', { text: 'Aktivität' }), h('dd', null, h('a', { href: '#/aktivitaet/' + enc(a.aktivitaet.id), text: a.aktuell.werte.bezeichnung })),
            wz.notiz ? [h('dt', { text: 'Notiz' }), h('dd', { text: wz.notiz })] : null),
          h('p', { class: 'hilfe', text: 'Dieses Ereignis entsteht von selbst, wenn die Verantwortung wechselt. Du kannst den Zeitpunkt korrigieren. Der frühere Zeitpunkt bleibt im Verlauf. Wer wann verantwortlich war, folgt der Korrektur.' }),
          storniert ? null : h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: '#/wechsel/' + enc(id) + '/aendern', text: 'Angaben ändern' })));
        seite(MM.Logbuch.WECHSEL_ART, [
          krumen(logbuchKrumen(a, (tag ? [[tagText(tag.aktuell.werte), '#/tagesabschnitt/' + enc(tag.objekt.id)]] : []).concat([[MM.Logbuch.WECHSEL_ART]]))),
          kopf, x.verlauf.length > 1 ? verlaufBlock(x.verlauf) : null
        ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: tag ? '#/tagesabschnitt/' + enc(tag.objekt.id) : '#/aktivitaet/' + enc(a.aktivitaet.id), text: 'Zurück' }),
          storniert ? null : h('a', { class: 'knopf', href: '#/wechsel/' + enc(id) + '/aendern', text: 'Angaben ändern' })));
      });
    });
  }

  function wechselFormular(id) {
    return daten.wechselLaden(id).then(function (x) {
      if (!x) return nichtGefunden('Wechsel nicht gefunden');
      var a = x.aktivitaet, wz = x.wechsel;
      var titel = 'Wechsel ändern';
      var zurueck = '#/wechsel/' + enc(id);
      einfachFormular({
        titel: titel, zurueck: zurueck, krumen: krumen(logbuchKrumen(a, [[MM.Logbuch.WECHSEL_ART, zurueck], [titel]])),
        werte: { abDatum: wz.datum, abZeit: wz.zeit, notiz: wz.notiz || '', ausgeblendet: wz.ausgeblendet ? 'ja' : 'nein' },
        intro: h('p', { text: 'Korrigiere, wann der Wechsel wirklich war. Er muss nach dem vorherigen und vor dem nächsten Wechsel liegen. Die Verantwortung der Aktivität folgt der Korrektur. Der frühere Zeitpunkt bleibt im Verlauf.' }),
        gruppen: function () {
          return [{ titel: null, felder: [
            { key: 'abDatum', label: 'Datum des Wechsels', typ: 'datum' }, { key: 'abZeit', label: 'Uhrzeit des Wechsels', typ: 'zeit' },
            { key: 'notiz', label: 'Notiz', typ: 'text', hilfe: 'Freiwillig.' },
            { key: 'ausgeblendet', label: 'Im Logbuch ausblenden?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Nein, sichtbar' }, { wert: 'ja', label: 'Ja, ausblenden' }],
              hilfe: 'Ausblenden löscht den Wechsel nicht. Er bleibt in der Verantwortung der Aktivität.' }] }];
        },
        speichern: function (w) { return daten.wechselAendern(id, w); },
        meldung: function (r) { return r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'; },
        danach: function () { return zurueck; }
      });
    });
  }

  /* Die beim Wechsel festgehaltene Befähigung der übernehmenden Person */
  function wechselPruefungAnsicht(p, welt) {
    if (!p) return h('p', { class: 'leer-text', text: 'Bei diesem Wechsel ist keine Prüfung festgehalten (er wurde vor Version 2.0.14 eingetragen).' });
    return h('section', { class: 'gruppe' },
      h('h3', { text: 'Prüfung beim Wechsel' }),
      h('p', null, h('strong', { text: 'Geprüft am ' + jetztText(p.geprueftAm) + ': ' }), pruefChip(p),
        h('span', { class: 'frist-info', text: '  ' + p.name + ' (' + p.rolleText + ')' })),
      p.gruende.length ? h('ul', { class: 'gruende' }, p.gruende.map(function (g) { return h('li', { class: ERG_KLASSE[g.ergebnis], text: g.text }); })) : null,
      p.gebietHinweis ? h('p', { class: 'hinweis', text: p.gebietHinweis }) : null,
      h('p', { class: 'hilfe', text: 'Die App weist nur hin und sperrt den Wechsel nicht. Das ist eine Hilfestellung und keine rechtliche Aussage. Die letzte Verantwortung hat der ' + MM.Aktivitaeten.verantwortlichenName(welt) + '.' }));
  }

  /* ---------- Cockpit-Seiten: Ereignis, Notiz, Foto (heutiger Tag, Zeit „jetzt“) ---------- */
  function cockpitKrumen(a, titel) {
    return krumen([['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], [a.aktuell.werte.bezeichnung, '#/aktivitaet/' + enc(a.aktivitaet.id)], [titel]]);
  }

  /* modus: 'ereignis', 'notiz' oder 'foto'. Leere Uhrzeit heißt „jetzt“ und gilt erst beim Speichern. */
  function cockpitFormular(modus, id) {
    return daten.aktivitaetLaden(id).then(function (a) {
      if (!a || modus !== 'ereignis') return cockpitFormularMit(modus, id, null);
      return daten.schnellknoepfeFuerFahrzeugart(a.fahrzeug ? a.fahrzeug.artId : null).then(function (sk) { return cockpitFormularMit(modus, id, sk); });
    });
  }

  /* sk: nur beim Modus „ereignis“ (Sonstige Ereignisse): was nicht auf einem Schnellknopf liegt */
  function cockpitFormularMit(modus, id, sk) {
    gpsStarten();
    var fix = frischePosition();
    return Promise.all([daten.aktivitaetLaden(id), daten.ereignisartenAusVorschlaegen().then(function () { return daten.ereignisartenListe(); }),
      fix ? daten.ortNameVorschlag(fix.breite, fix.laenge) : Promise.resolve(null)]).then(function (r) {
      var a = r[0], arten = r[1], vorschlag = r[2];
      if (!a) return nichtGefunden('Aktivität nicht gefunden');
      var titel = { ereignis: 'Sonstige Ereignisse', notiz: 'Notiz eintragen', foto: 'Foto eintragen' }[modus];
      var zurueck = '#/aktivitaet/' + enc(id);
      var fzArt = a.fahrzeug ? a.fahrzeug.artId : null;
      /* „Wetter“ und „Karte“ (seit 2.0.35) sind Aktionen und stehen als Knöpfe oben, nicht in der Auswahl. */
      function istAktion(name) { return MM.Karte.istWetterArt(name) || MM.Karte.istKartenArt(name); }
      var optionen = arten.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja' && x.aktuell.werte.bezeichnung !== MM.Logbuch.WECHSEL_ART
          && !istAktion(x.aktuell.werte.bezeichnung)
          && (!fzArt || MM.Logbuch.ereignisartGilt(x.aktuell.werte.zuordnung, fzArt)); })
        .map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; });
      /* Sonstige Ereignisse: nur, was nicht auf einem Schnellknopf liegt */
      if (sk) optionen = sk.sonstige.ereignisse.filter(function (x) { return !istAktion(x.name); }).map(function (x) { return { wert: x.id, label: x.name }; });
      var aktionen = sk ? sk.sonstige.ereignisse.filter(function (x) { return istAktion(x.name); }) : [];
      function aktionsKnopf(x) {
        if (MM.Karte.istKartenArt(x.name)) {
          return h('a', { class: 'knopf leise', href: '#/aktivitaet/' + enc(id) + '/karte', text: x.name, onclick: function () { reiterWahl[id] = 'cockpit'; } });
        }
        var wb = h('button', { class: 'knopf leise', type: 'button', text: x.name, onclick: function () {
          wb.setAttribute('disabled', '');
          wb.textContent = 'Wetter wird geholt …';
          daten.wetterJetzt(id, frischePosition()).then(function (r) {
            if (r.ok) wetterErfolg = { akt: id, ms: Date.now() };
            meldung = r.ok ? 'Wetter gespeichert, ' + r.zeit + ' Uhr. ' + r.text.replace(/^Wetter: /, '') : ((r.fehler && r.fehler.allgemein) || 'Das hat nicht geklappt.');
            meldungKurz = !!r.ok;
            reiterWahl[id] = 'cockpit';
            global.location.hash = zurueck;
          }).catch(fehlerSeite);
        } });
        return wb;
      }
      var c = MM.Logbuch.cockpitMoeglich(a.aktuell.werte, daten.heute());
      if (!c.moeglich) {
        return seite(titel, [cockpitKrumen(a, titel), h('h1', { text: titel }),
          h('p', { class: 'hinweis', text: 'Das Cockpit trägt nur ein, wenn die Aktivität nicht storniert ist und heute in ihrem Zeitraum liegt. Im Logbuch kannst du Tage ergänzen und nachtragen.' })],
          h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' })));
      }
      reiterWahl[id] = 'cockpit';
      einfachFormular({
        titel: titel, krumen: cockpitKrumen(a, titel), zurueck: zurueck,
        werte: { artId: '', text: '', datei: null, datum: '', zeit: '', ortName: vorschlag ? vorschlag.name : '', auswirkung: 'keine' },
        neuzeichnenBei: modus === 'ereignis' ? ['artId'] : [],
        intro: h('div', null,
          h('p', { text: modus === 'foto' ? 'Mach ein Foto oder wähle eines aus. Es bleibt nur auf diesem Gerät. Die Uhrzeit ist jetzt.'
            : (modus === 'ereignis' ? 'Hier stehen alle Ereignisse, die nicht auf einem Schnellknopf liegen. Die Uhrzeit ist jetzt. Ist es früher passiert, trage die echte Uhrzeit ein, dann steht es als „nachgetragen“ da.'
              : 'Die Uhrzeit ist jetzt. Ist es früher passiert, trage die echte Uhrzeit ein, dann steht es als „nachgetragen“ da.') }),
          aktionen.length ? h('p', { class: 'knopfzeile' }, aktionen.map(aktionsKnopf)) : null,
          sk && sk.sonstige.funktionen.length ? h('p', { class: 'knopfzeile' }, sk.sonstige.funktionen.map(function (f) {
            return h('a', { class: 'knopf leise', href: '#/aktivitaet/' + enc(id) + '/cockpit/' + f.id, text: f.name });
          })) : null,
          modus === 'ereignis' && sk && !optionen.length && !aktionen.length ? h('p', { class: 'hilfe', text: 'Alle Ereignisse dieser Fahrzeugart liegen schon auf Schnellknöpfen.' }) : null),
        gruppen: function (z) {
          var f = [];
          if (modus === 'ereignis') f.push({ key: 'artId', label: 'Was ist passiert?', typ: 'auswahl', darstellung: optionen.length <= 8 ? 'wahl' : undefined, optionen: optionen, leerText: '– bitte wählen –' });
          if (modus === 'ereignis' && istStoerungGewaehlt(optionen, z && z.werte && z.werte.artId)) f.push(auswirkungFeld());
          if (modus === 'foto') f.push({ key: 'datei', label: 'Foto', typ: 'datei', accept: 'image/*' });
          f.push({ key: 'text', label: modus === 'notiz' ? 'Notiz' : 'Text (freiwillig)', typ: 'text' });
          if (modus !== 'foto') f.push({ key: 'zeit', label: 'Uhrzeit (leer = jetzt)', typ: 'zeit', hilfe: 'Nur ausfüllen, wenn es früher war.' });
          f.push({ key: 'ortName', label: 'Ortsname (freiwillig)', typ: 'text',
            hilfe: (fix ? 'Position per GPS: ' + MM.Logbuch.positionText(fix.breite, fix.laenge) + '. ' + (vorschlag ? 'Die App kennt diesen Ort (' + MM.Logbuch.entfernungText(vorschlag.abstand) + ' entfernt) und schlägt den Namen vor. ' : '')
              : 'Gerade keine GPS-Position, der Eintrag wird ohne Position gespeichert. Du kannst sie später unter „Angaben ändern“ von Hand eintragen. ') +
              'Ein Name, den du hier eingibst oder bestätigst, merkt sich die App für diese Gegend. Bei früherer Uhrzeit gilt keine GPS-Position.' });
          return [{ titel: null, felder: f }];
        },
        speichern: function (v) {
          var fehler = {};
          if (modus === 'notiz' && !(v.text || '').trim()) fehler.text = 'Bitte die Notiz eintragen.';
          if (modus === 'foto' && !v.datei) fehler.datei = 'Bitte ein Foto wählen.';
          if (modus === 'ereignis' && !v.artId) fehler.artId = optionen.length ? 'Bitte wählen, was passiert ist.' : (sk ? 'Alle Ereignisse dieser Fahrzeugart liegen schon auf Schnellknöpfen.' : 'Es gibt keine Art von Ereignis. Lege eine unter „Arten von Ereignissen“ an.');
          if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
          var roh = { text: v.text, zeit: v.zeit || '', datei: v.datei || null, ortName: v.ortName || '', position: v.zeit ? null : fix };
          if (modus === 'ereignis') { roh.artId = v.artId; roh.auswirkung = v.auswirkung || ''; }
          var vorgang = daten.ereignisSchnell(id, 'Notiz', roh);
          /* Wie bei den Knöpfen: nach „Abfahrt“ oder „Ablegen“ ohne laufenden Motor nur ein Hinweis (nicht bei nachgetragener Zeit). */
          var gewaehlt = modus === 'ereignis' && !v.zeit && a.fahrzeug ? optionen.filter(function (o) { return o.wert === v.artId; })[0] : null;
          if (!gewaehlt) return vorgang;
          return vorgang.then(function (r) {
            if (!r.ok) return r;
            return Promise.all([daten.fahrzeugartMotor(fzArt), daten.motorenListe(a.fahrzeug.id)]).then(function (m) {
              motorHinweis = MM.Motoren.motorHinweis(m[0].hat, gewaehlt.label, m[1]);
              return r;
            });
          });
        },
        meldung: function (r) { return (modus === 'foto' ? 'Foto' : (modus === 'notiz' ? 'Notiz' : 'Ereignis')) + ' gespeichert, ' + r.zeit + ' Uhr.' + (r.vorgangId ? ' Die Störung steht auch in der Werkstatt.' : ''); },
        danach: function () { return zurueck; }
      });
    });
  }

  /* ---------- Cockpit: Verantwortung wechseln (große Knöpfe, ein Tipp auf den Namen) ---------- */
  function cockpitWechselSeite(id) {
    return daten.aktivitaetLaden(id).then(function (a) {
      if (!a) return nichtGefunden('Aktivität nicht gefunden');
      var w = a.aktuell.werte;
      var verantwortlich = MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt);
      var zurueck = '#/aktivitaet/' + enc(id);
      var titel = 'Verantwortung wechseln';
      var storniert = w.status === 'storniert';
      var letzte = a.verantwortung[a.verantwortung.length - 1];
      var kandidaten = a.besatzung.filter(function (b) { return (b.aktuell.werte.rolle === 'verantwortlich' || b.aktuell.werte.rolle === 'stellvertreter') && (!letzte || b.person.id !== letzte.personId); });
      var jetzt = daten.jetztLokal();
      var fehlerBox = h('div');
      var arbeitet = false;
      var datumFeld = h('input', { type: 'date', id: 'cw-datum', value: jetzt.slice(0, 10), 'aria-label': 'Datum des Wechsels' });
      var zeitFeld = h('input', { type: 'time', id: 'cw-zeit', value: jetzt.slice(11, 16), 'aria-label': 'Uhrzeit des Wechsels' });
      var knoepfe = [];

      function wechseln(person) {
        if (arbeitet) return;
        arbeitet = true;
        knoepfe.forEach(function (k) { k.setAttribute('disabled', ''); });
        var jetztNeu = daten.jetztLokal();
        /* Unverändert heißt „jetzt“ (zum Zeitpunkt des Tippens). Nur wer die Zeit ändert, trägt einen anderen Zeitpunkt ein. */
        var geaendert = datumFeld.value !== jetzt.slice(0, 10) || zeitFeld.value !== jetzt.slice(11, 16);
        var ab = geaendert ? { abDatum: datumFeld.value, abZeit: zeitFeld.value } : { abDatum: jetztNeu.slice(0, 10), abZeit: jetztNeu.slice(11, 16) };
        /* Der heutige Tag wird bei Bedarf angelegt, damit der Wechsel im Logbuch steht. Außerhalb des Zeitraums geht es ohne. */
        daten.heutigerTag(id).catch(function () { return null; }).then(function () {
          return daten.verantwortungWechseln(id, person.person.id, ab);
        }).then(function (r) {
          if (!r.ok) {
            arbeitet = false;
            knoepfe.forEach(function (k) { k.removeAttribute('disabled'); });
            var f = r.fehler || {};
            fehlerBox.textContent = '';
            fehlerBox.appendChild(h('div', { class: 'fehlerkasten', role: 'alert', text: f.allgemein || f.personId || f.abDatum || f.abZeit || 'Das hat nicht geklappt.' }));
            return null;
          }
          reiterWahl[id] = 'cockpit';
          var p = r.pruefung;
          meldung = person.person.name + ' ist ab ' + ab.abZeit + ' Uhr ' + verantwortlich + '.' + (p ? ' ' + MM.Logbuch.wechselPruefungKurz(p) + '. Das ist ein Hinweis, der Wechsel ist nicht gesperrt.' : '') + (r.nachgetragen ? ' Nachgetragen.' : '');
          if (global.location.hash === zurueck) return zeige();
          global.location.hash = zurueck;
          return null;
        }).catch(fehlerSeite);
      }

      knoepfe = kandidaten.map(function (b) {
        return h('button', { class: 'knopf cockpit-knopf', type: 'button', onclick: function () { wechseln(b); } },
          h('span', { text: b.person.name }), h('span', { class: 'cockpit-knopf-info', text: b.rolleText }));
      });
      var inhalt = [
        cockpitKrumen(a, titel), h('h1', { text: titel }),
        letzte ? h('p', null, h('span', { class: 'frist-info', text: verantwortlich + ' jetzt: ' }), h('strong', { text: a.verantwortlichJetzt ? a.verantwortlichJetzt.name : letzte.name })) : null,
        storniert ? h('p', { class: 'hinweis', text: 'Die Aktivität ist storniert. Es kommt nichts Neues ins Logbuch, bis sie wieder hergestellt ist.' }) : null,
        !storniert && !kandidaten.length ? h('div', { class: 'leer-hinweis' }, h('p', { text: 'Es gibt keine andere Person, die verantwortlich werden könnte. Füge zuerst einen Stellvertreter hinzu.' }),
          h('p', null, h('a', { class: 'knopf', href: '#/aktivitaet/' + enc(id) + '/besatzung/neu', text: 'Person hinzufügen' }))) : null,
        !storniert && kandidaten.length ? [
          h('p', { text: 'Tippe auf den Namen. Der Wechsel gilt ab jetzt (' + jetzt.slice(11, 16) + ' Uhr). Die App prüft dabei die Befähigung der übernehmenden Person und weist nur hin, sie sperrt nichts.' }),
          fehlerBox,
          h('div', { class: 'cockpit-raster' }, knoepfe),
          h('details', { class: 'ausgebaut' }, h('summary', { text: 'Wechsel vergessen? Echte Uhrzeit nachtragen' }),
            h('p', { class: 'hilfe', text: 'Ändere Datum und Uhrzeit auf den echten Zeitpunkt und tippe dann auf den Namen. Der Wechsel muss nach dem letzten Wechsel liegen und steht dann als „nachgetragen“ da.' }),
            h('div', { class: 'feld' }, h('label', { class: 'feld-label', for: 'cw-datum', text: 'Datum' }), datumFeld),
            h('div', { class: 'feld' }, h('label', { class: 'feld-label', for: 'cw-zeit', text: 'Uhrzeit' }), zeitFeld))
        ] : null
      ];
      seite(titel, inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: zurueck, text: 'Zurück' })));
    });
  }

  /* ---------- Formular: Tagesabschluss (tatsächliches Ziel und Notiz) ---------- */
  function abschlussFormular(id) {
    return daten.abschnittLaden(id).then(function (r) {
      if (!r) return nichtGefunden('Tag nicht gefunden');
      var x = r.abschnitt, a = r.aktivitaet, w = x.aktuell.werte;
      var zurueck = '#/tagesabschnitt/' + enc(id);
      var titel = 'Tagesabschluss';
      einfachFormular({
        titel: titel, zurueck: zurueck, krumen: krumen(logbuchKrumen(a, [[tagText(w), zurueck], [titel]])),
        werte: { zielTatsaechlich: w.zielTatsaechlich || '', abschlussNotiz: w.abschlussNotiz || '' },
        intro: h('div', null,
          h('p', { text: 'Am Ende des Tages: wo seid ihr wirklich angekommen, und was soll im Logbuch stehen?' }),
          w.nach ? h('p', { class: 'hilfe', text: 'Geplant war: ' + w.nach + '.' }) : null,
          h('p', { class: 'hilfe', text: 'Der Zählerstand am Ende kommt mit dem Schritt „Zähler automatisch“.' })),
        gruppen: function () {
          return [{ titel: null, felder: [
            { key: 'zielTatsaechlich', label: 'Tatsächliches Ziel', typ: 'text', hilfe: 'Zum Beispiel „Zadar, Stadthafen“.' },
            { key: 'abschlussNotiz', label: 'Notiz zum Tag', typ: 'text' }] }];
        },
        /* Seit 2.0.44: Beim Tagesabschluss kommen die Geschwindigkeitswerte des Tages als Eintrag „Geschwindigkeit“ ins Logbuch,
           der Wert dieses Tages bleibt danach stehen und die nächste Bewegung beginnt eine neue Zählung. */
        speichern: function (v) {
          gpsFahrtUngesichert = true;
          return fahrtSichern(true).then(function () { return daten.tagesabschlussSpeichern(id, v); }).then(function (res) {
            res.id = id;
            if (!res.ok) return res;
            return daten.fahrtTagAbschliessen(id, { position: frischePosition() }).then(function (g) {
              fahrtNeuLesen();
              res.geschwindigkeit = g && g.ok && g.geschrieben ? g.text : null;
              return res;
            }, function () { fahrtNeuLesen(); return res; });
          });
        },
        meldung: function (res) { return (res.geaendert ? 'Tagesabschluss gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.') + (res.geschwindigkeit ? ' Die Geschwindigkeit des Tages steht im Logbuch.' : ''); },
        danach: function () { return zurueck; }
      });
    });
  }

  /* ---------- Fahrzeugarten verwalten (seit 2.0.16) ---------- */
  var ART_WEG = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Fahrzeugarten', '#/fahrzeugarten']];

  function seiteFahrzeugarten() {
    return daten.fahrzeugartenVerwaltung().then(function (v) {
      var inhalt = [krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten'], ['Fahrzeugarten']]), h('h1', { text: 'Fahrzeugarten' }),
        h('p', { text: 'Hier baust du deinen Baum der Fahrzeugarten. Lege Untergruppen an, blende ein, was du nicht brauchst, und lösche, was nie benutzt wurde. Was ein Fahrzeug benutzt, lässt sich nur ausblenden.' })];
      inhalt.push(h('ul', { class: 'fristen artverwaltung' }, v.arten.map(function (k) {
        return h('li', { style: 'margin-left:' + (Math.max(0, k.tiefe - 1) * 1.2) + 'rem' },
          h('a', { class: 'frist' + (k.ausgeblendet || k.verdeckt ? ' ausgeblendet' : ''), href: '#/fahrzeugart/' + enc(k.id) },
            h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: k.name }),
              h('span', { class: 'frist-info', text: (k.fest ? 'Feste Gruppe' : (k.eigen ? 'Von dir angelegt' : 'Vorschlag')) + (k.waehlbar ? ' · ' + (k.fahrzeuge === 1 ? '1 Fahrzeug' : (k.fahrzeuge ? k.fahrzeuge + ' Fahrzeuge' : 'kein Fahrzeug')) : '') })),
            k.ausgeblendet ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : (k.verdeckt ? h('span', { class: 'chip-status', text: 'Gruppe darüber ausgeblendet' }) : null)));
      })));
      var knoepfe = [];
      if (v.ungebraucht.length) {
        knoepfe.push(h('button', { class: 'knopf gefahr', type: 'button', text: 'Ungebrauchtes löschen (' + v.ungebraucht.length + ')',
          onclick: function () {
            var namen = v.ungebraucht.map(function (x) { return x.name; });
            if (!global.confirm('Diese ' + namen.length + ' Arten werden gelöscht, weil kein Fahrzeug sie benutzt:\n\n' + namen.join(', ') + '\n\nDas lässt sich nicht rückgängig machen. Löschen?')) return;
            daten.fahrzeugartenBereinigen().then(function (r) { meldung = r.anzahl + ' Arten gelöscht. Benutzte Arten und die Gruppen Land, Wasser, Luft bleiben.'; return zeige(); }).catch(fehlerSeite);
          } }));
      }
      if (v.wiederherstellbar) {
        knoepfe.push(h('button', { class: 'knopf leise', type: 'button', text: 'Gelöschte Vorschläge zurückholen (' + v.wiederherstellbar + ')',
          onclick: function () { daten.fahrzeugartenWiederherstellen().then(function (r) { meldung = r.anzahl + ' Vorschläge zurückgeholt.'; return zeige(); }).catch(fehlerSeite); } }));
      }
      if (knoepfe.length) inhalt.push(h('p', { class: 'knopfzeile' }, knoepfe));
      if (!v.ungebraucht.length) inhalt.push(h('p', { class: 'hilfe', text: 'Alles im Baum wird von einem Fahrzeug benutzt oder ist eine feste Gruppe. Es gibt nichts Ungebrauchtes zu löschen.' }));
      seite('Fahrzeugarten', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/fahrzeugart/neu', text: 'Neue Art anlegen' })));
    });
  }

  function seiteFahrzeugart(id) {
    return Promise.all([daten.fahrzeugartenVerwaltung(), daten.fahrzeugartMotor(id)]).then(function (rr) {
      var v = rr[0], motor = rr[1];
      var k = v.arten.filter(function (x) { return x.id === id; })[0];
      if (!k) return nichtGefunden('Fahrzeugart nicht gefunden');
      var F = MM.Fahrzeugarten;
      var pfad = F.vorfahren(id).filter(function (i) { return i !== F.WURZEL; }).reverse().map(function (i) { return F.art(i).name; }).join(' › ');
      var unter = F.kinder(id).map(function (c) { return c.name + (c.ausgeblendet ? ' (ausgeblendet)' : ''); });
      var inhalt = [krumen(ART_WEG.concat([[k.name]])), h('h1', { text: k.name }),
        k.ausgeblendet ? h('p', { class: 'meldung ausgebaut-hinweis', text: 'Diese Art ist ausgeblendet. Neue Fahrzeuge und neue Ereignisse bieten sie nicht an. Bestehende Fahrzeuge bleiben unverändert.' }) : null,
        h('dl', { class: 'daten stapel' },
          h('dt', { text: 'Stellung im Baum' }), h('dd', { text: pfad }),
          h('dt', { text: 'Herkunft' }), h('dd', { text: k.fest ? 'Feste Gruppe, nicht änderbar' : (k.eigen ? 'Von dir angelegt' : 'Mitgelieferter Vorschlag') }),
          k.waehlbar ? [h('dt', { text: 'Fahrzeuge' }), h('dd', { text: k.fahrzeuge ? k.fahrzeuge + ' (mit Untergruppen)' : 'keines' })] : null,
          unter.length ? [h('dt', { text: 'Untergruppen' }), h('dd', { text: unter.join(', ') })] : null,
          h('dt', { text: 'Normalerweise ein Motor' }),
          h('dd', { text: (motor.hat ? 'Ja' : 'Nein') + ' (' + (motor.eigene ? 'von dir eingestellt'
            : (motor.standard ? 'Voreinstellung' + (motor.von && motor.von !== id ? ' von „' + F.art(motor.von).name + '“' : '')
              : 'übernommen von „' + F.art(motor.von).name + '“')) + ')' })),
        h('p', { class: 'hilfe', text: 'Das ist nur ein Hinweis für das Cockpit: Tippst du „Abfahrt“ oder „Ablegen“, ohne dass ein Motor läuft, speichert die App den Eintrag trotzdem und zeigt oben „Kein Motor läuft“. Es gibt keine Rückfrage und keine Sperre.' }),
        h('p', { class: 'knopfzeile' },
          h('button', { class: 'knopf' + (motor.hat ? '' : ' leise'), type: 'button', text: 'Hat einen Motor',
            onclick: function () { daten.fahrzeugartMotorSetzen(id, 'ja').then(function () { meldung = k.name + ': Hat normalerweise einen Motor.'; return zeige(); }).catch(fehlerSeite); } }),
          h('button', { class: 'knopf' + (motor.hat ? ' leise' : ''), type: 'button', text: 'Hat keinen Motor',
            onclick: function () { daten.fahrzeugartMotorSetzen(id, 'nein').then(function () { meldung = k.name + ': Hat normalerweise keinen Motor.'; return zeige(); }).catch(fehlerSeite); } }),
          motor.eigene ? h('button', { class: 'knopf leise', type: 'button', text: 'Eigene Einstellung entfernen',
            onclick: function () { daten.fahrzeugartMotorZuruecksetzen(id).then(function () { meldung = 'Die eigene Einstellung ist entfernt.'; return zeige(); }).catch(fehlerSeite); } }) : null)];
      var knoepfe = [h('a', { class: 'knopf', href: '#/fahrzeugart/neu?eltern=' + enc(id), text: 'Untergruppe anlegen' }),
        h('a', { class: 'knopf leise', href: '#/schnellknoepfe/' + enc(id), text: 'Schnellknöpfe im Cockpit' })];
      if (!k.fest) {
        knoepfe.push(h('a', { class: 'knopf leise', href: '#/fahrzeugart/' + enc(id) + '/aendern', text: k.ausgeblendet ? 'Umbenennen oder einblenden' : 'Umbenennen oder ausblenden' }));
        if (k.fahrzeuge === 0) {
          knoepfe.push(h('button', { class: 'knopf gefahr', type: 'button', text: 'Löschen',
            onclick: function () {
              var alle = [k.name].concat(F.nachkommen(id).map(function (n) { return F.art(n).name; }));
              if (!global.confirm('Gelöscht wird: ' + alle.join(', ') + '.\n\nKein Fahrzeug benutzt das. Das lässt sich nicht rückgängig machen. Löschen?')) return;
              daten.fahrzeugartLoeschen(id).then(function (r) {
                if (!r.ok) { meldung = (r.fehler && r.fehler.allgemein) || 'Das ging nicht.'; return zeige(); }
                meldung = '„' + k.name + '“ ist gelöscht.'; global.location.hash = '#/fahrzeugarten';
              }).catch(fehlerSeite);
            } }));
        } else {
          inhalt.push(h('p', { class: 'hilfe', text: 'Löschen geht nicht, weil diese Art oder eine Untergruppe von einem Fahrzeug benutzt wird. Du kannst sie ausblenden.' }));
        }
      }
      inhalt.push(h('p', { class: 'knopfzeile' }, knoepfe));
      seite(k.name, inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/fahrzeugarten', text: 'Zur Liste' })));
    });
  }

  /* ---------- Schnellknöpfe im Cockpit einstellen (seit 2.0.18) ---------- */
  function schnellknoepfeFormular(artId, aktId) {
    var F = MM.Fahrzeugarten, k = F.knoten(artId);
    if (!k) return nichtGefunden('Fahrzeugart nicht gefunden');
    return daten.schnellknoepfeFuerFahrzeugart(artId).then(function (info) {
      var titel = 'Schnellknöpfe: ' + k.name;
      var zurueck = aktId ? '#/aktivitaet/' + enc(aktId) : '#/fahrzeugart/' + enc(artId);
      var start = {}, i;
      for (i = 0; i < info.max; i++) start['s' + (i + 1)] = info.knoepfeAlle[i] ? info.knoepfeAlle[i].key : '';
      start.geraet = String(info.geraetMax);
      var optionen = info.angebot.alle.map(function (x) { return { wert: x.key, label: x.name }; });
      var woher = info.eigene ? 'Diese Art hat eine eigene Einstellung.'
        : (info.von ? 'Diese Art übernimmt die Einstellung von „' + F.knoten(info.von).name + '“. Wenn du speicherst, bekommt sie eine eigene.'
          : 'Zurzeit gilt die Standard-Belegung (Abfahrt, Ankunft, Notiz, Foto, Verantwortung wechseln). Wenn du speicherst, bekommt diese Art eine eigene.');
      var krumenWeg = aktId ? [['Hauptmenü', '#/auswahl'], ['Funktionen', '#/funktionen'], ['Aktivitäten', '#/aktivitaeten'], ['Cockpit', zurueck], [titel]]
        : ART_WEG.concat([[k.name, zurueck], [titel]]);
      einfachFormular({
        titel: titel, zurueck: zurueck, krumen: krumen(krumenWeg), werte: start,
        intro: h('div', null,
          h('p', { text: 'Lege fest, welche Knöpfe im Cockpit stehen, bis zu ' + info.max + '. Ein Tipp darauf speichert das Ereignis sofort mit der Uhrzeit von jetzt. „Wetter“ holt das Wetter und speichert es, „Karte“ öffnet die Karte und schreibt nichts ins Logbuch. Notiz, Foto und Verantwortung wechseln öffnen ihre Seite. Der Knopf „Sonstige Ereignisse“ kommt immer dazu und enthält alles, was nicht auf einem Knopf liegt.' }),
          h('p', { class: 'hilfe', text: 'Die Knöpfe stehen von links nach rechts und von oben nach unten. Wie viele Spalten es sind, richtet sich nach der Breite des Bildschirms: 2 beim Handy, 3 beim Tablet, 4 bei einem großen Bildschirm. Die Belegung gilt für ' + k.name + ' und alle Untergruppen, die nichts Eigenes eingestellt haben, auf allen Geräten.' }),
          h('p', { text: info.versteckt > 0
            ? 'Auf diesem Gerät sind zurzeit die ersten ' + info.knoepfe.length + ' von ' + info.knoepfeAlle.length + ' Knöpfen zu sehen. Die übrigen liegen unter „Sonstige Ereignisse“.'
            : (info.knoepfeAlle.length ? 'Auf diesem Gerät sind zurzeit alle ' + info.knoepfeAlle.length + ' Knöpfe zu sehen.' : 'Für diese Art ist zurzeit kein Knopf belegt.') }),
          h('p', { text: woher }),
          info.eigene ? h('p', { class: 'knopfzeile' }, h('button', { class: 'knopf leise', type: 'button', text: 'Eigene Einstellung entfernen',
            onclick: function () {
              daten.schnellknoepfeZuruecksetzen(artId).then(function () { meldung = 'Die eigene Einstellung ist entfernt.'; return zeige(); }).catch(fehlerSeite);
            } })) : null),
        gruppen: function () {
          var f = [], zahlen = [];
          for (var n = 1; n <= info.max; n++) f.push({ key: 's' + n, label: 'Knopf ' + n, typ: 'auswahl', optionen: optionen, leerText: '– leer –' });
          for (var z = 0; z <= info.max; z++) zahlen.push({ wert: String(z), label: String(z) });
          return [
            { titel: 'Auf diesem Gerät', hinweis: 'Gilt nur für dieses Gerät und für alle Fahrzeugarten, nicht für deine anderen Geräte. Das Gerät zeigt die ersten so vielen Knöpfe der Liste unten, die übrigen liegen unter „Sonstige Ereignisse“ und gehen nicht verloren. Vorgabe: ' + MM.Logbuch.SCHNELL_GERAET_STANDARD + '.',
              felder: [{ key: 'geraet', label: 'Höchstzahl Knöpfe auf diesem Gerät', typ: 'auswahl', optionen: zahlen, leerText: '– nicht ändern –' }] },
            { titel: 'Knöpfe im Cockpit', felder: f }];
        },
        speichern: function (w) {
          var slots = []; for (var n = 1; n <= info.max; n++) slots.push(w['s' + n] || '');
          var geraet = (w.geraet === '' || w.geraet === undefined || w.geraet === null) ? null : w.geraet;
          if (geraet !== null && MM.Logbuch.geraetKnoepfeGueltig(geraet) === null) return Promise.resolve({ ok: false, fehler: { geraet: 'Bitte eine Zahl von 0 bis ' + info.max + ' wählen.' } });
          /* Erst die Belegung (wird vollständig geprüft), dann die Zahl für dieses Gerät: Es wird nichts halb gespeichert. */
          return daten.schnellknoepfeSetzen(artId, slots).then(function (r) {
            if (!r.ok || geraet === null) return r;
            return daten.geraetKnoepfeSetzen(geraet).then(function (g) { return g.ok ? Object.assign({}, r, { geraet: g.knoepfe }) : g; });
          });
        },
        meldung: function (r) {
          var gezeigt = Math.min(r.anzahl, r.geraet === undefined ? info.geraetMax : r.geraet);
          return 'Gespeichert. Für diese Art sind ' + r.anzahl + (r.anzahl === 1 ? ' Knopf' : ' Knöpfe') + ' belegt, auf diesem Gerät stehen davon ' + gezeigt + ' im Cockpit, dazu „Sonstige Ereignisse“.';
        },
        danach: function () { return zurueck; }
      });
    });
  }

  function fahrzeugartFormular(modus, id, elternVorgabe) {
    var neu = modus === 'neu';
    var F = MM.Fahrzeugarten;
    var k = neu ? null : F.art(id);
    if (!neu && (!k || (k.gruppe && !k.eigen && k.eltern === F.WURZEL))) return Promise.resolve(nichtGefunden('Fahrzeugart nicht gefunden'));
    var titel = neu ? 'Neue Art anlegen' : 'Art ändern';
    var elternOptionen = F.baum(true).filter(function (x) { return x.tiefe > 0; })
      .map(function (x) { return { wert: x.id, label: new Array(x.tiefe).join('– ') + x.name }; });
    einfachFormular({
      titel: titel, zurueck: neu ? '#/fahrzeugarten' : '#/fahrzeugart/' + enc(id),
      werte: neu ? { name: '', eltern: elternVorgabe || '' } : { name: k.name, ausgeblendet: k.ausgeblendet ? 'ja' : 'nein' },
      krumen: krumen(ART_WEG.concat(neu ? [[titel]] : [[k.name, '#/fahrzeugart/' + enc(id)], [titel]])),
      intro: neu ? h('p', { text: 'Die neue Art übernimmt die Felder und die Ereignisse der Gruppe, unter der sie steht. Ereignisse kannst du danach bei den Arten von Ereignissen anpassen.' }) : null,
      gruppen: function () {
        var f = [{ key: 'name', label: 'Name', typ: 'text', hilfe: neu ? 'Zum Beispiel „Trimaran“ oder „Aufsitzrasenmäher“' : null }];
        if (neu) f.push({ key: 'eltern', label: 'Steht unter', typ: 'auswahl', optionen: elternOptionen, leerText: '– bitte wählen –' });
        else f.push({ key: 'ausgeblendet', label: 'Ausblenden?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Nein, auswählbar' }, { wert: 'ja', label: 'Ja, ausblenden' }],
          hilfe: 'Ausgeblendete Arten (und alles darunter) sind für neue Fahrzeuge nicht mehr auswählbar. Bestehende Fahrzeuge bleiben unverändert.' });
        return [{ titel: null, felder: f }];
      },
      speichern: function (v) { return neu ? daten.fahrzeugartAnlegen(v) : daten.fahrzeugartAendern(id, v).then(function (r) { r.id = id; return r; }); },
      meldung: function (r) { return neu ? 'Art angelegt.' : (r.geaendert ? 'Gespeichert.' : 'Es gab keine Änderung.'); },
      danach: function (r) { return neu ? '#/fahrzeugart/' + enc(r.id) : '#/fahrzeugart/' + enc(id); }
    });
    return Promise.resolve();
  }

  /* ---------- Ereignisarten ---------- */
  function seiteEreignisarten() {
    return daten.ereignisartenListe().then(function (liste) {
      var inhalt = [krumen(KR_STAMM.concat([['Arten von Ereignissen']])), h('h1', { text: 'Arten von Ereignissen' }),
        h('p', { text: 'Die Liste ist offen. Bei jeder Art legst du fest, für welche Fahrzeugarten sie gilt, damit Logbuch und Cockpit nur zeigen, was zum Fahrzeug passt. Übernimm die Vorschläge oder lege eigene Arten an.' })];
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: 'Noch keine Art.' })));
      else inhalt.push(h('ul', { class: 'fristen' }, liste.map(function (x) {
        return h('li', null, h('a', { class: 'frist', href: '#/ereignisart/' + enc(x.objekt.id) + '/aendern' },
          h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: x.aktuell.werte.bezeichnung }),
            h('span', { class: 'frist-info', text: 'Gilt für: ' + MM.Logbuch.zuordnungText(x.aktuell.werte.zuordnung) })),
          x.aktuell.werte.ausgeblendet === 'ja' ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : null));
      })));
      var fehlend = MM.Logbuch.VORSCHLAEGE_EREIGNISARTEN.filter(function (n) { return !liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === n.toLowerCase(); }); });
      if (fehlend.length) inhalt.push(h('p', null, h('button', { class: 'knopf leise', type: 'button', text: 'Vorschläge übernehmen (' + fehlend.length + ')',
        onclick: function () { daten.ereignisartenAusVorschlaegen().then(function (r) { meldung = r.anzahl + ' Arten übernommen.'; return zeige(); }).catch(fehlerSeite); } })));
      var fehlendZusatz = MM.Logbuch.ZUSATZ_VORSCHLAEGE.filter(function (v) { return !liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === v.bezeichnung.toLowerCase(); }); });
      if (fehlendZusatz.length) inhalt.push(h('p', null, h('button', { class: 'knopf leise', type: 'button', text: 'Vorschläge für Fahrzeugarten übernehmen (' + fehlendZusatz.length + ')',
        onclick: function () { daten.ereignisartenVorauswahlUebernehmen().then(function (r) { meldung = r.anzahl + ' Arten mit Zuordnung übernommen: ' + fehlendZusatz.map(function (v) { return v.bezeichnung; }).join(', ') + '.'; return zeige(); }).catch(fehlerSeite); } }),
        h('span', { class: 'hilfe', text: ' Zum Beispiel Anlegen, Anker werfen, Segel setzen. Die Zuordnung änderst du danach jederzeit.' })));
      seite('Arten von Ereignissen', inhalt, h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
        h('a', { class: 'knopf', href: '#/ereignisart/neu', text: 'Eigene Art anlegen' })));
    });
  }

  function ereignisartFormular(modus, id) {
    var neu = modus === 'neu';
    return (neu ? Promise.resolve({ aktuell: { werte: { bezeichnung: '', ausgeblendet: 'nein' } } }) : daten.ereignisartLaden(id)).then(function (x) {
      if (!x) return nichtGefunden('Art nicht gefunden');
      var titel = neu ? 'Eigene Art anlegen' : 'Art ändern';
      var werteStart = JSON.parse(JSON.stringify(x.aktuell.werte));
      werteStart.giltImStatus = MM.Status.listeLesen(werteStart.giltImStatus);
      werteStart.danachStatus = werteStart.danachStatus || '';
      var baum = zuordnungBaumTeile(werteStart);
      var baumOptionen = baum.optionen;
      einfachFormular({
        titel: titel, zurueck: '#/ereignisarten', werte: werteStart, neuzeichnenBei: ['gilt'],
        nachAenderung: baum.nachAenderung,
        krumen: krumen(KR_STAMM.concat([['Arten von Ereignissen', '#/ereignisarten'], [titel]])),
        gruppen: function () {
          var f = [{ key: 'bezeichnung', label: 'Name der Art', typ: 'text', hilfe: 'Zum Beispiel „Segel gesetzt“ oder „Tanken“' }];
          if (!neu) f.push({ key: 'ausgeblendet', label: 'Ausblenden?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Nein, auswählbar' }, { wert: 'ja', label: 'Ja, ausblenden' }],
            hilfe: 'Ausgeblendete Arten sind für neue Ereignisse nicht mehr auswählbar. Vorhandene Ereignisse bleiben.' });
          var statusOptionen = MM.Status.ALLE.map(function (s2) { return { wert: s2.id, label: s2.name }; });
          var standardRegel = !neu && MM.Status.STANDARD[String(x.aktuell.werte.bezeichnung || '').trim().toLowerCase()];
          var standardText = standardRegel ? ' Ohne Angabe gilt für „' + x.aktuell.werte.bezeichnung + '“: möglich im Status „' + standardRegel.gilt.map(function (g) { return MM.Status.statusName(null, g); }).join(' oder ') + '“, danach „' + MM.Status.statusName(null, standardRegel.danach) + '“.' : '';
          return [{ titel: null, felder: f }, { titel: 'Gilt für diese Fahrzeugarten', felder: [{ key: 'gilt', label: 'Fahrzeugarten', typ: 'baum', optionen: baumOptionen,
            hilfe: 'Ein Häkchen an einer Gruppe gilt für alles darunter. Du kannst darunter einzelne Arten abwählen oder wieder ankreuzen, auch später.' }] },
            { titel: 'Status des Fahrzeugs (freiwillig)', felder: [
              { key: 'giltImStatus', label: 'Möglich im Status', typ: 'mehrfach', optionen: statusOptionen,
                hilfe: 'In welchem Status des Fahrzeugs darf dieses Ereignis eingetragen werden? Sonst ist der Knopf grau.' + standardText },
              { key: 'danachStatus', label: 'Danach Status', typ: 'auswahl', darstellung: 'wahl',
                optionen: [{ wert: '', label: 'Keine eigene Regel (Starthilfe nach dem Namen, sonst ohne Wirkung)' }]
                  .concat(statusOptionen).concat([{ wert: MM.Status.KEINE, label: 'Ändert den Status nicht, ist nie gesperrt' }]),
                hilfe: 'In welchen Status bringt dieses Ereignis das Fahrzeug? Eine Regel braucht beide Angaben.' }] }];
        },
        speichern: function (v) {
          var roh2 = Object.assign({}, v, { zuordnung: MM.Logbuch.zuordnungAusAuswahl(v.gilt || [], neu ? null : x.aktuell.werte.zuordnung) });
          return neu ? daten.ereignisartAnlegen(roh2) : daten.ereignisartAendern(id, roh2).then(function (r) { r.id = id; return r; });
        },
        meldung: function (r) { return neu ? 'Art angelegt.' : (r.geaendert ? 'Gespeichert.' : 'Es gab keine Änderung.'); },
        danach: function () { return '#/ereignisarten'; }
      });
    });
  }

  /* ---------- Anforderungen am Fahrzeug ---------- */
  function anforderungenBereich(liste, fahrzeugId, welt) {
    var name = MM.Aktivitaeten.verantwortlichenName(welt);
    return h('section', { class: 'bereich', 'aria-label': 'Anforderungen' },
      h('h2', { text: 'Anforderungen an ' + name + ' und Stellvertreter' }),
      liste.length ? h('ul', { class: 'fristen' }, liste.map(function (x) {
        var w = x.aktuell.werte;
        return h('li', null, h('a', { class: 'frist', href: '#/anforderung/' + encodeURIComponent(x.objekt.id) + '/aendern' },
          h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: w.bezeichnung }), h('span', { class: 'frist-info', text: 'Genügt: ' + x.artNamen.join(' oder ') })),
          w.gilt === 'nein' ? h('span', { class: 'chip-status', text: 'abgeschaltet' }) : null));
      })) : h('p', { class: 'leer-text', text: 'Noch keine Anforderung. Lege fest, welche Nachweise nötig sind, damit die App bei der Planung prüfen kann.' }),
      h('a', { class: 'knopf leise', href: '#/fahrzeug/' + encodeURIComponent(fahrzeugId) + '/anforderung/neu', text: 'Anforderung hinzufügen' }));
  }

  /* modus 'neu' (id = Fahrzeug) oder 'aendern' (id = Anforderung) */
  function anforderungFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = neu ? daten.fahrzeugLaden(id).then(function (f) { return f ? { fz: f, start: { bezeichnung: '', artIds: [], gilt: 'ja' } } : null; })
      : daten.anforderungLaden(id).then(function (x) { return x ? daten.speicher.holen('anforderungen', id).then(function (rec) { return daten.fahrzeugLaden(rec.fahrzeugId).then(function (f) { return f ? { fz: f, x: x, start: JSON.parse(JSON.stringify(x.aktuell.werte)) } : null; }); }) : null; });
    return Promise.all([laden, daten.nachweisartenListe('person')]).then(function (r) {
      var k = r[0], arten = r[1];
      if (!k) return nichtGefunden('Nicht gefunden');
      var fz = k.fz.fahrzeug, name = k.fz.aktuell.werte.bezeichnung;
      var welt = MM.Fahrzeugarten.art(fz.art).welt;
      var verantwortlich = MM.Aktivitaeten.verantwortlichenName(welt);
      var titel = neu ? 'Anforderung hinzufügen' : 'Anforderung ändern';
      var zurueck = '#/fahrzeug/' + encodeURIComponent(fz.id);
      var weg = WEG_FAHRZEUGE.concat([[name, zurueck], [titel]]);
      var optionen = arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || (k.start.artIds || []).indexOf(a.objekt.id) >= 0; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; });
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: zurueck, werte: k.start,
        intro: optionen.length ? h('p', { text: 'Welche Nachweise braucht ein ' + verantwortlich + ' für dieses Fahrzeug? Es genügt jeweils eine der Arten, die du wählst. Legst du mehrere Anforderungen an, müssen alle erfüllt sein. Für die Verantwortlichen zählt nur ein Nachweis mit Scan oder Foto.' })
          : h('div', { class: 'leer-hinweis' }, h('p', { text: 'Es gibt noch keine Art von Nachweis für Personen. Übernimm Vorschläge oder lege eine eigene Art an.' }), h('p', null, h('a', { class: 'knopf', href: '#/nachweisarten/vorschlaege', text: 'Vorschläge ansehen' }))),
        gruppen: function () {
          if (!optionen.length) return [];
          var f = [{ key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: 'Zum Beispiel „Führerschein Klasse B“ oder „Funkzeugnis“' },
            { key: 'artIds', label: 'Genügt einer dieser Nachweise', typ: 'mehrfach', optionen: optionen }];
          if (!neu) f.push({ key: 'gilt', label: 'Gilt die Anforderung?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'ja', label: 'Ja, sie gilt' }, { wert: 'nein', label: 'Nein, abgeschaltet' }] });
          return [{ titel: null, felder: f }];
        },
        speichern: function (v) { return neu ? daten.anforderungAnlegen(id, v) : daten.anforderungAendern(id, v); },
        meldung: function (r) { return neu ? 'Anforderung angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function () { return zurueck; }
      });
    });
  }

  /* ---------- Orte, Standorte, Gebiete und Regeln ---------- */
  var KR_ORTE = [['Hauptmenü', '#/auswahl'], ['Stammdaten', '#/stammdaten']];
  var BENANNT = {
    ort: {
      liste: '#/orte', einzel: '#/ort/', krumen: 'Orte', schale: 'Ort', titelNeu: 'Ort anlegen', titelAendern: 'Ort ändern',
      felder: function () { return MM.Orte.ortFelder(); }, laden: function (id) { return daten.ortLaden(id); },
      anlegen: function (w) { return daten.ortAnlegen(w); }, aendern: function (id, w) { return daten.ortAendern(id, w); },
      namenHilfe: 'Zum Beispiel „Hafen Biograd“ oder „Zuhause“',
      intro: 'Ein Ort ist ein Platz, an dem du dein Fahrzeug hast oder hinbringst, zum Beispiel dein Heimathafen oder ein Stellplatz, Campingplatz oder Hafen auf Reisen. Mit Position und Ausstattung erkennt die App ihn bei einer Ankunft wieder. Die einzelnen Plätze darin legst du danach als Standorte an.'
    },
    gebiet: {
      liste: '#/gebiete', einzel: '#/gebiet/', krumen: 'Gebiete', schale: 'Gebiet', titelNeu: 'Gebiet anlegen', titelAendern: 'Gebiet ändern',
      felder: function () { return MM.Orte.gebietFelder(); }, laden: function (id) { return daten.gebietLaden(id); },
      anlegen: function (w) { return daten.gebietAnlegen(w); }, aendern: function (id, w) { return daten.gebietAendern(id, w); },
      namenHilfe: 'Zum Beispiel „Kroatien, Adria“ oder „Deutschland, Binnen“',
      intro: 'Ein Gebiet ist ein Land, eine Region, ein Kreis oder ein Revier, für das besondere Regeln gelten. Die meisten Gebiete entstehen von selbst aus deinen Orten. Hier legst du eigene Gebiete an, zum Beispiel „Kroatien, Adria“. Die Regeln trägst du danach selbst ein. MobiMory prüft damit bei der Planung, macht aber keine rechtsgültige Aussage.'
    }
  };

  function seiteBenanntListe(typ) {
    var c = BENANNT[typ];
    return Promise.all([typ === 'ort' ? daten.orteListe() : daten.gebieteListe(), typ === 'ort' ? daten.gelernteNamenOffen() : Promise.resolve([]),
      daten.gebieteListe(), typ === 'gebiet' ? daten.kontoWelten() : Promise.resolve([])]).then(function (rr) {
      var liste = rr[0], offeneNamen = rr[1], alleGebiete = rr[2], welten = rr[3];
      /* Gebiete (seit 2.0.39): als Baum Land > Region > Kreis oder Revier. Gezeigt wird, was zu den Fahrzeugen im Konto passt. */
      var verborgen = 0, tiefe = {};
      if (typ === 'gebiet') {
        var erlaubt = MM.Gebiete.ebenenFuerKonto(welten);
        var sicht = liste.filter(function (x) { var e = x.aktuell.werte.ebene; return !e || erlaubt.indexOf(e) >= 0; });
        verborgen = liste.length - sicht.length;
        var ids = {}; sicht.forEach(function (x) { ids[x.objekt.id] = x; });
        var kinder = {}, wurzeln = [];
        sicht.forEach(function (x) {
          var el = x.aktuell.werte.elternId;
          if (el && ids[el]) (kinder[el] = kinder[el] || []).push(x); else wurzeln.push(x);
        });
        var baum = [];
        (function gehe(l, t) { l.forEach(function (x) { tiefe[x.objekt.id] = t; baum.push(x); gehe(kinder[x.objekt.id] || [], t + 1); }); })(wurzeln, 0);
        liste = baum;
      }
      var inhalt = [krumen(KR_ORTE.concat([[c.krumen]])), h('h1', { text: c.krumen })];
      /* Gelernte Namen aus dem Logbuch (seit 2.0.21) werden auf Wunsch zu Orten mit Position (seit 2.0.28). */
      if (typ === 'ort' && offeneNamen.length) {
        inhalt.push(h('div', { class: 'leer-hinweis' },
          h('p', { text: 'Die App hat bei Ankünften ' + (offeneNamen.length === 1 ? '1 Ortsnamen' : offeneNamen.length + ' Ortsnamen') + ' gelernt, zu denen es noch keinen Ort gibt: ' + offeneNamen.slice(0, 4).map(function (x) { return x.name; }).join(', ') + (offeneNamen.length > 4 ? ' und weitere' : '') + '. Als Orte bekommen sie ihre Position, Ausstattung und Kosten.' }),
          h('p', null, h('button', { class: 'knopf', type: 'button', text: 'Als Orte übernehmen',
            onclick: function () { daten.gelernteNamenUebernehmen().then(function (r) { meldung = r.angelegt + (r.angelegt === 1 ? ' Ort angelegt.' : ' Orte angelegt.'); return zeige(); }).catch(fehlerSeite); } }))));
      }
      if (!liste.length) inhalt.push(h('div', { class: 'leer-hinweis' }, h('p', { text: typ === 'ort' ? 'Noch kein Ort. Suche zum Beispiel deinen Heimatort. Die App prüft ihn und legt das Gebiet dazu an.' : 'Noch kein Gebiet. Gebiete entstehen aus deinen Orten: Suche einen Ort, dann legt die App Land, Region und Kreis an. Eigene Gebiete wie „Kroatien, Adria“ kannst du auch von Hand anlegen.' })));
      else {
        if (typ === 'gebiet') inhalt.push(h('p', { class: 'hilfe', text: 'Die Gebiete entstehen aus deinen Orten und werden danach wiederverwendet. Gezeigt wird, was zu den Fahrzeugen in deinem Konto passt: bei Landfahrzeugen Land, Region und Kreis, bei Wasserfahrzeugen Land und Revier.' + (verborgen ? ' Ausgeblendet nach Fahrzeugart: ' + verborgen + '. Sie bleiben gespeichert.' : '') }));
        inhalt.push(h('ul', { class: 'liste' }, liste.map(function (x) {
          var w = x.aktuell.werte;
          var zahl = typ === 'ort' ? (x.anzahlStandorte === 1 ? '1 Standort' : x.anzahlStandorte + ' Standorte') : (x.anzahlRegeln === 1 ? '1 Regel' : x.anzahlRegeln + ' Regeln');
          var gebietText = null;
          if (typ === 'ort') {
            var wegO = w.gebietId ? MM.Gebiete.pfad(alleGebiete, w.gebietId) : [];
            gebietText = wegO.length ? MM.Gebiete.pfadText(wegO, ', ') : 'Gebiet unklar';
          }
          return h('li', { style: typ === 'gebiet' && tiefe[x.objekt.id] ? 'margin-left:' + (tiefe[x.objekt.id] * 1.2) + 'rem' : null }, h('a', { class: 'zeile welt-land', href: c.einzel + encodeURIComponent(x.objekt.id) },
            h('span', { class: 'zeile-text' },
              h('strong', { class: 'zeile-name', text: w.bezeichnung }),
              h('span', { class: 'zeile-art', text: [typ === 'ort' ? MM.Orte.ortartLabel(w.ortart) : (w.ebene ? MM.Gebiete.ebeneLabel(w.ebene).split(' (')[0] : 'eigenes Gebiet'), typ === 'ort' && !(w.gebietId && gebietText !== 'Gebiet unklar') ? w.land : null, gebietText, zahl, typ === 'ort' && typeof w.positionBreite === 'number' ? 'mit Position' : null].filter(Boolean).join(', ') })),
            w.ausgeblendet === 'ja' ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : null));
        })));
      }
      seite(c.krumen, inhalt, h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/stammdaten', text: 'Zurück' }),
        typ === 'ort' ? h('a', { class: 'knopf leise', href: '#/orte/neu', text: 'Ohne Prüfung anlegen' }) : null,
        h('a', { class: 'knopf', href: typ === 'ort' ? '#/orte/suchen' : c.liste + '/neu', text: typ === 'ort' ? 'Ort suchen und anlegen' : c.titelNeu })));
    });
  }

  /* Eigene Regeln eines Ortes (seit 2.0.42): Der Ort ist die unterste Ebene der Kette, aber nur, wenn er eigene Regeln hat.
     Ohne eigene Regel gelten die Regeln von Land, Region, Kreis oder Revier. */
  function regelZeile(g) {
    var rw = g.aktuell.werte;
    var wenn = [g.fahrzeugArtNamen.length ? g.fahrzeugArtNamen.join(', ') : 'jede Fahrzeugart', rw.ausruestung ? 'mit „' + rw.ausruestung + '“' : null].filter(Boolean).join(', ');
    var istAus = MM.Orte.regelArt(rw) === 'ausruestung';
    return h('li', null, h('a', { class: 'frist', href: '#/regel/' + encodeURIComponent(g.objekt.id) + '/aendern' },
      h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: rw.bezeichnung }),
        h('span', { class: 'frist-info', text: istAus ? 'Pflichtausrüstung: ' + MM.Orte.menge(rw) + ' × ' + rw.pflichtAusruestung + ' ' + (MM.Orte.bezugsgroesse(rw) === 'person' ? 'je Person an Bord' : 'je Fahrzeug') + (rw.eignung ? ', Eignung: ' + rw.eignung : '') + '. Gilt für: ' + (g.fahrzeugArtNamen.length ? g.fahrzeugArtNamen.join(', ') : 'jede Fahrzeugart') + '.'
          : 'Wenn: ' + wenn + '. Dann genügt: ' + g.artNamen.join(' oder ') + '.' })),
      rw.gilt === 'nein' ? h('span', { class: 'chip-status', text: 'abgeschaltet' }) : null));
  }

  function ortRegelnBlock(id, x) {
    var geprueft = !!(x.gebietPfad && x.gebietPfad.length);
    var regeln = x.eigeneRegeln || [];
    return h('section', { class: 'bereich', 'aria-label': 'Eigene Regeln dieses Ortes' },
      h('h2', { text: 'Eigene Regeln dieses Ortes' }),
      h('p', { class: 'hilfe', text: 'Ein Ort bekommt nur dann eigene Regeln, wenn du ihm welche anlegst. Sonst gelten die Regeln der Ebenen darüber: Land, Region und Kreis, bei Wasserfahrzeugen Land und Revier. Mit eigenen Regeln steht der Ort als unterste Ebene hinten an der Kette, zum Beispiel Deutschland › Rhein › ' + x.aktuell.werte.bezeichnung + '.' }),
      regeln.length ? h('ul', { class: 'fristen' }, regeln.map(regelZeile)) : h('p', { class: 'leer-text', text: 'Noch keine eigene Regel. Hier gelten die Regeln der Ebenen darüber.' }),
      geprueft ? h('a', { class: 'knopf leise', href: '#/ort/' + encodeURIComponent(id) + '/regel/neu', text: 'Eigene Regel für diesen Ort' })
        : h('p', { class: 'hinweis', text: 'Eine eigene Regel gibt es erst, wenn der Ort geprüft ist, denn sie hängt unter dem Land des Ortes. Prüfe den Ort zuerst über die Ortssuche („Ort prüfen“).' }));
  }

  function seiteBenannt(typ, id) {
    var c = BENANNT[typ];
    return Promise.all([c.laden(id), typ === 'ort' ? daten.ortAuswertung(id) : Promise.resolve(null)]).then(function (rr) {
      var x = rr[0], ortA = rr[1];
      if (!x) return nichtGefunden(c.schale + ' nicht gefunden');
      var w = x.aktuell.werte;
      var dl = [];
      c.felder().forEach(function (f) {
        /* Die Position steht als eine Zeile (Breite und Länge zusammen). */
        if (f.koordinate) return;
        var t = MM.Hilfen.wert(f, w[f.key]);
        if (t !== null) dl.push([h('dt', { text: f.label }), h('dd', { text: t })]);
      });
      if (typ === 'ort' && typeof w.positionBreite === 'number' && typeof w.positionLaenge === 'number') {
        dl.splice(Math.min(2, dl.length), 0, [h('dt', { text: 'Position' }), h('dd', { text: MM.Logbuch.positionText(w.positionBreite, w.positionLaenge) })]);
      }
      /* Gebiet des Ortes (seit 2.0.39): aus der Ortssuche, sonst unklar. */
      if (typ === 'ort') {
        dl.unshift([h('dt', { text: 'Gebiet' }), h('dd', { text: x.gebietPfad && x.gebietPfad.length ? MM.Gebiete.pfadText(x.gebietPfad) : 'unklar, der Ort ist noch nicht geprüft' })]);
        if (x.revier) dl.splice(1, 0, [h('dt', { text: 'Revier' }), h('dd', { text: x.revier.name })]);
      }
      if (typ === 'gebiet' && w.ebene) {
        dl.unshift([h('dt', { text: 'Ebene' }), h('dd', { text: MM.Gebiete.ebeneLabel(w.ebene) })]);
        if (x.pfad && x.pfad.length > 1) dl.splice(1, 0, [h('dt', { text: 'Gehört zu' }), h('dd', { text: MM.Gebiete.pfadText(x.pfad.slice(0, -1)) })]);
        if (x.unter && x.unter.length) dl.push([h('dt', { text: 'Darunter' }), h('dd', { text: x.unter.map(function (g) { return g.name; }).join(', ') })]);
      }
      var karte = h('section', { class: 'schale sx' },
        h('div', { class: 'schale-name', text: c.schale }),
        h('h1', { text: w.bezeichnung }),
        w.ausgeblendet === 'ja' ? h('p', null, h('span', { class: 'chip-status', text: 'ausgeblendet' })) : null,
        dl.length ? h('dl', { class: 'daten' }, dl) : h('p', { class: 'leer-text', text: 'Noch keine weiteren Angaben.' }),
        h('p', { class: 'stand', text: 'Stand vom ' + MM.Hilfen.zeitpunkt(x.aktuell.erstelltAm) + ', ' + MM.Orte.herkunftText(w) }),
        h('p', null, typ === 'gebiet' && x.ort ? h('a', { class: 'knopf leise', href: '#/ort/' + encodeURIComponent(x.ort.id), text: 'Zum Ort' })
            : h('a', { class: 'knopf leise', href: c.einzel + encodeURIComponent(id) + '/aendern', text: 'Angaben ändern' }),
          typ === 'ort' ? [' ', h('a', { class: 'knopf leise', href: '#/ort/' + encodeURIComponent(id) + '/pruefen', text: w.ortGeprueft === 'ja' ? 'Ort erneut prüfen' : 'Ort prüfen' })] : null));
      var kinder, neuHref, neuText;
      if (typ === 'gebiet' && x.ort) dl.unshift([h('dt', { text: 'Ort' }), h('dd', null, h('a', { href: '#/ort/' + encodeURIComponent(x.ort.id), text: x.ort.name }))]);
      if (typ === 'ort') {
        neuHref = '#/ort/' + encodeURIComponent(id) + '/standort/neu'; neuText = 'Standort hinzufügen';
        kinder = h('section', { class: 'bereich', 'aria-label': 'Standorte' },
          h('h2', { text: 'Standorte' }),
          x.standorte.length ? h('ul', { class: 'fristen' }, x.standorte.map(function (s) {
            var sw = s.aktuell.werte;
            return h('li', null, h('a', { class: 'frist', href: '#/standort/' + encodeURIComponent(s.objekt.id) + '/aendern' },
              h('span', { class: 'frist-text' }, h('strong', { class: 'frist-name', text: sw.bezeichnung }), sw.standortart ? h('span', { class: 'frist-info', text: sw.standortart }) : null),
              sw.ausgeblendet === 'ja' ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : null));
          })) : h('p', { class: 'leer-text', text: 'Noch kein Standort. Lege zum Beispiel einen Liegeplatz oder Stellplatz an.' }),
          h('a', { class: 'knopf leise', href: neuHref, text: neuText }));
      } else {
        neuHref = '#/gebiet/' + encodeURIComponent(id) + '/regel/neu'; neuText = 'Regel hinzufügen';
        kinder = h('section', { class: 'bereich', 'aria-label': 'Regeln' },
          h('h2', { text: 'Regeln dieses Gebiets' }),
          h('p', { class: 'hilfe', text: 'Es gibt zwei Arten von Regeln. Befähigung: Wenn Fahrzeugart und Ausrüstung passen, genügt einer der gewählten Nachweise. Pflichtausrüstung: Eine Ausrüstung muss am Fahrzeug eingetragen sein. Alle passenden Regeln müssen erfüllt sein.' }),
          x.regeln.length ? h('ul', { class: 'fristen' }, x.regeln.map(regelZeile)) : h('p', { class: 'leer-text', text: 'Noch keine Regel. Ohne Regel kann die App für dieses Gebiet nichts prüfen und sagt höchstens „unklar“.' }),
          h('a', { class: 'knopf leise', href: neuHref, text: neuText }));
      }
      seite(w.bezeichnung, [
        krumen(KR_ORTE.concat([[c.krumen, c.liste], [w.bezeichnung]])), karte, kinder, typ === 'ort' ? ortRegelnBlock(id, x) : null, typ === 'ort' && ortA ? ortBesucheBlock(ortA) : null, x.verlauf.length > 1 ? verlaufBlock(x.verlauf) : null
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: c.liste, text: 'Zur Liste' }),
        h('a', { class: 'knopf', href: neuHref, text: neuText })));
    });
  }

  /* ---------- Reiseorte (seit 2.0.28): Besuche und Kosten an einem Ort ---------- */
  function geplantChip(art) {
    return art ? h('span', { class: 'chip-status ' + (art === 'nein' ? 'status-bald' : 'status-ok'), text: MM.Reiseorte.labelVon(MM.Reiseorte.GEPLANT, art) }) : null;
  }

  /* Eine Zeile in der Liste der Besuche. Auf der Seite eines Ortes steht die Aktivität dabei, auf der Seite einer Aktivität der Ort. */
  function besuchZeile(b, aufOrtSeite) {
    var w = b.aktuell.werte;
    var info = [aufOrtSeite ? 'Aktivität: ' + b.aktivitaetName : null, b.standortName ? 'Standort: ' + b.standortName : null,
      MM.Reiseorte.ausstattungText(w.ausstattung, w.ausstattungSonst)].filter(Boolean).join('. ');
    var wann = (w.datum ? MM.Hilfen.datum(w.datum) : '') + (w.zeit ? ', ' + w.zeit + ' Uhr' : '');
    return h('li', null, h('a', { class: 'frist', href: '#/besuch/' + encodeURIComponent(b.objekt.id) },
      h('span', { class: 'frist-text' },
        h('strong', { class: 'frist-name', text: aufOrtSeite ? wann : (b.ortName || 'Ort') }),
        aufOrtSeite ? null : h('span', { class: 'frist-info', text: wann }),
        info ? h('span', { class: 'frist-info', text: info }) : null),
      w.ausgeblendet === 'ja' ? h('span', { class: 'chip-status', text: 'ausgeblendet' }) : geplantChip(w.geplant)));
  }

  function ortBesucheBlock(a) {
    var zeilen = [[h('dt', { text: 'Besuche' }), h('dd', { text: a.anzahl === 0 ? 'Noch keiner festgehalten' : a.anzahl === 1 ? '1 Besuch' : a.anzahl + ' Besuche' })]];
    if (a.letzter) zeilen.push([h('dt', { text: 'Zuletzt dort' }), h('dd', { text: MM.Hilfen.datum(a.letzter) })]);
    if (a.anzahlPosten) {
      zeilen.push([h('dt', { text: 'Insgesamt bezahlt' }), h('dd', { text: euro(a.summe) + grundText(a.grundlage) + (a.anzahlPosten > 1 ? ', ' + a.anzahlPosten + ' Posten' : '') })]);
      if (a.letzterPreis) zeilen.push([h('dt', { text: 'Zuletzt bezahlt' }), h('dd', { text: euro(a.letzterPreis.betrag) + (a.letzterPreis.datum ? ' am ' + MM.Hilfen.datum(a.letzterPreis.datum) : '') + grundText(a.letzterPreis.grundlage) })]);
      a.nachArt.forEach(function (x) { zeilen.push([h('dt', { text: x.label }), h('dd', { text: euro(x.summe) })]); });
    }
    var ein = a.besuche.filter(function (b) { return b.aktuell.werte.ausgeblendet !== 'ja'; }), aus = a.besuche.filter(function (b) { return b.aktuell.werte.ausgeblendet === 'ja'; });
    return h('section', { class: 'bereich', 'aria-label': 'Besuche und Kosten' },
      h('h2', { text: 'Besuche und Kosten' }),
      h('dl', { class: 'daten' }, zeilen),
      ein.length ? h('ul', { class: 'fristen' }, ein.map(function (b) { return besuchZeile(b, true); })) : h('p', { class: 'leer-text', text: 'Hier wird jeder Besuch festgehalten, wenn du bei einer Ankunft die Frage zum Ort beantwortest. So entsteht mit der Zeit deine Historie.' }),
      aus.length ? h('details', { class: 'ausgebaut' }, h('summary', { text: 'Ausgeblendet (' + aus.length + ')' }), h('ul', { class: 'fristen' }, aus.map(function (b) { return besuchZeile(b, true); }))) : null,
      h('p', { class: 'hilfe', text: 'Später teilbar wären nur Name, Art, Position und Ausstattung des Ortes. Deine Notizen, Kosten und Besuche bleiben nur bei dir. Veröffentlicht wird nichts.' }));
  }

  /* Wert in der Revier-Auswahl für „Neues Revier eintragen“. Kein echter Revier-Name, nur eine Marke für das Formular. */
  var REVIER_NEU = '::neues-revier::';

  function benanntFormular(typ, modus, id) {
    var c = BENANNT[typ];
    var laden = modus === 'aendern' ? c.laden(id) : Promise.resolve({ aktuell: { werte: { bezeichnung: '' } } });
    /* Das Revier (Binnenwasserstraße) gibt es nur bei Wasserfahrzeugen im Konto, und nur bei einem geprüften Ort (er hat ein Land). */
    var zusatz = typ === 'ort' ? Promise.all([daten.kontoWelten(), modus === 'aendern' ? laden : null]).then(function (r) {
      var wasser = r[0].indexOf('wasser') >= 0, land = r[1] && r[1].gebietPfad && r[1].gebietPfad[0] ? r[1].gebietPfad[0] : null;
      return (wasser && land ? daten.reviereZuLand(land.id) : Promise.resolve([])).then(function (reviere) {
        /* Auswahlliste (seit 2.0.42): Gibt es unter dem Land schon Reviere, wählt man eins aus der Liste oder trägt ein neues ein. Das Revier dieses Ortes bleibt in der Liste. */
        var aktuell = r[1] && r[1].revier ? r[1].revier.name : null;
        var liste = reviere.slice(); if (aktuell && liste.indexOf(aktuell) < 0) liste.push(aktuell);
        liste.sort(function (a, b) { return a.localeCompare(b, 'de', { sensitivity: 'base' }); });
        return { wasser: wasser, land: land, reviere: reviere, liste: liste, aktuell: aktuell, auswahl: !!(land && liste.length) };
      });
    }) : Promise.resolve(null);
    return Promise.all([laden, zusatz]).then(function (rz) {
      var x = rz[0], revierInfo = rz[1];
      if (!x) return nichtGefunden(c.schale + ' nicht gefunden');
      var neu = modus === 'neu';
      var titel = neu ? c.titelNeu : c.titelAendern;
      var weg = KR_ORTE.concat([[c.krumen, c.liste]]);
      if (!neu) weg.push([x.aktuell.werte.bezeichnung, c.einzel + encodeURIComponent(id)]);
      weg.push([titel]);
      einfachFormular({
        titel: titel, krumen: krumen(weg), zurueck: neu ? c.liste : c.einzel + encodeURIComponent(id),
        werte: Object.assign(JSON.parse(JSON.stringify(x.aktuell.werte)),
          typ === 'ort' && revierInfo && revierInfo.auswahl ? { revierWahl: revierInfo.aktuell || '', revierName: '' } : (typ === 'ort' && x.revier ? { revierName: x.revier.name } : {})),
        intro: neu ? h('p', { text: c.intro }) : null,
        neuzeichnenBei: typ === 'ort' && revierInfo && revierInfo.auswahl ? ['revierWahl'] : [],
        gruppen: function (z) {
          var f = [{ key: 'bezeichnung', label: 'Name', typ: 'text', hilfe: c.namenHilfe }];
          c.felder().forEach(function (fe) {
            if (fe.key !== 'revierName') { f.push(fe); return; }
            if (!(revierInfo && revierInfo.wasser)) return;
            if (revierInfo.auswahl) {
              /* Auswahlliste: die Reviere, die es unter dem Land schon gibt, dazu „Neues Revier“ */
              f.push({ key: 'revierWahl', label: fe.label, typ: 'auswahl', leerText: '– kein Revier –', optionen: revierInfo.liste.map(function (n) { return { wert: n, label: n }; })
                .concat([{ wert: REVIER_NEU, label: 'Neues Revier eintragen …' }]),
                hilfe: 'Nur für Wasserfahrzeuge. Die Liste zeigt die Reviere, die du in diesem Land schon eingetragen hast. Ein neues Revier legst du mit „Neues Revier eintragen“ an. Es steht dann beim nächsten Ort in der Liste.' });
              if (z.werte.revierWahl === REVIER_NEU) f.push({ key: 'revierName', label: 'Name des neuen Reviers', typ: 'text', hilfe: 'Zum Beispiel „Rhein“ oder „Neckar“. Das Revier gehört zum Land des Ortes.' });
              return;
            }
            var kopie = Object.assign({}, fe);
            if (!revierInfo.land) kopie.hilfe = 'Nur für Wasserfahrzeuge. Das Revier gehört zum Land des Ortes. Prüfe den Ort zuerst über die Ortssuche („Ort prüfen“), dann kannst du es hier eintragen.';
            else kopie.hilfe = fe.hilfe + ' Das erste Revier in diesem Land trägst du hier ein. Danach wählst du es beim nächsten Ort aus einer Liste.';
            f.push(kopie);
          });
          if (!neu) f.push({ key: 'ausgeblendet', label: 'Anzeigen?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Ja, anzeigen' }, { wert: 'ja', label: 'Nein, ausblenden' }] });
          return [{ titel: null, felder: f }];
        },
        speichern: function (w) {
          var werte = w;
          if (typ === 'ort' && revierInfo && revierInfo.auswahl) {
            /* Aus der Auswahl wird der Revier-Name, den die Datenschicht kennt. „Kein Revier“ leert das Revier. */
            werte = Object.assign({}, w);
            if (w.revierWahl === REVIER_NEU) {
              if (!String(w.revierName || '').trim()) return Promise.resolve({ ok: false, fehler: { revierName: 'Bitte den Namen des neuen Reviers eingeben oder „kein Revier“ wählen.' } });
            } else werte.revierName = w.revierWahl || '';
            delete werte.revierWahl;
          }
          return neu ? c.anlegen(werte) : c.aendern(id, werte);
        },
        meldung: function (r) { return neu ? c.schale + ' angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function (r) { return c.einzel + encodeURIComponent(r.id); }
      });
    });
  }


  /* ---------- Seite: Ortssuche (seit 2.0.39) ----------
   * modus 'neu': Ort suchen und anlegen. modus 'pruefen' (id = Ort): einen vorhandenen Ort nachträglich prüfen.
   * Gesucht wird erst auf Knopfdruck. Es geht nur der eingegebene Ortsname hinaus. */
  function seiteOrtSuche(modus, id) {
    var pruefen = modus === 'pruefen';
    return (pruefen ? daten.ortLaden(id) : Promise.resolve({ aktuell: { werte: { bezeichnung: '' } } })).then(function (x) {
      if (!x) return nichtGefunden('Ort nicht gefunden');
      var name = x.aktuell.werte.bezeichnung;
      var titel = pruefen ? 'Ort prüfen' : 'Ort suchen und anlegen';
      var zurueck = pruefen ? '#/ort/' + encodeURIComponent(id) : '#/orte';
      var weg = KR_ORTE.concat([['Orte', '#/orte']]); if (pruefen) weg.push([name, zurueck]); weg.push([titel]);
      var ergebnis = h('div', { 'aria-live': 'polite' });
      var eingabe = h('input', { id: 'ortsuche', type: 'text', autocomplete: 'off', autocapitalize: 'words', value: name });
      var knopf = h('button', { class: 'knopf', type: 'submit', text: 'Ort suchen' });

      function zeigeTreffer(liste) {
        ergebnis.textContent = '';
        anhaengen(ergebnis, [
          h('p', { class: 'hilfe', text: liste.length === 1 ? 'Ein Treffer. Wähle ihn, wenn er stimmt.' : liste.length + ' Treffer. Wähle den, den du meinst.' }),
          h('ul', { class: 'liste' }, liste.map(function (k) {
            return h('li', null, h('button', { class: 'zeile welt-land', type: 'button', style: 'width:100%;text-align:left', onclick: function () { waehlen(k); } },
              h('span', { class: 'zeile-text' },
                h('strong', { class: 'zeile-name', text: k.name }),
                h('span', { class: 'zeile-art', text: MM.Gebiete.pfadText(MM.Ortssuche.kette(k).map(function (g) { return { name: g.name }; }), ', ') + (k.gemeinde ? ' (Gemeinde ' + k.gemeinde + ')' : '') }))));
          }))]);
      }
      function waehlen(k) {
        var versprechen = pruefen ? daten.ortPruefungUebernehmen(id, k) : daten.ortAusTreffer(k);
        versprechen.then(function (r) {
          if (!r.ok) { ergebnis.textContent = ''; anhaengen(ergebnis, h('p', { class: 'fehler', role: 'alert', text: (r.fehler && r.fehler.allgemein) || 'Der Ort konnte nicht gespeichert werden.' })); return; }
          var g = r.gebiete ? (r.gebiete.neu ? r.gebiete.neu + (r.gebiete.neu === 1 ? ' neues Gebiet' : ' neue Gebiete') + ' gespeichert' : 'Gebiete schon vorhanden und wiederverwendet') : '';
          meldung = pruefen ? 'Ort geprüft. ' + g + '.' : (r.vorhanden ? 'Diesen Ort gibt es schon.' : 'Ort „' + r.name + '“ angelegt. ' + g + '.');
          global.location.hash = '#/ort/' + encodeURIComponent(r.id);
        }).catch(fehlerSeite);
      }
      function suchen(ev) {
        ev.preventDefault();
        knopf.disabled = true; ergebnis.textContent = '';
        anhaengen(ergebnis, h('p', { class: 'hilfe', text: 'Suche läuft …' }));
        daten.ortSuchen(eingabe.value).then(function (r) {
          knopf.disabled = false; ergebnis.textContent = '';
          if (!r.ok) { anhaengen(ergebnis, h('p', { class: r.grund === 'netz' ? 'hinweis' : 'fehler', role: 'alert', text: r.text })); return; }
          zeigeTreffer(r.kandidaten);
        });
      }
      var intro = pruefen
        ? 'Gib den Ort ein, so wie er im Atlas steht. Wähle den richtigen Treffer. Name, Notizen und Kosten bleiben, nur das Gebiet kommt dazu.'
        : 'Gib den Namen des Ortes ein. Die App sucht ihn und zeigt die Treffer. Gibt es den Namen mehrfach, wählst du den richtigen aus. Aus dem Treffer entstehen Ort und Gebiet.';
      seite(titel, [krumen(weg), h('h1', { text: titel }), h('p', { text: intro }),
        h('form', { class: 'formular', novalidate: 'novalidate', onsubmit: suchen },
          h('div', { class: 'feld' }, h('label', { for: 'ortsuche', text: 'Ort' }),
            h('p', { class: 'hilfe', text: 'Es geht nur dieser Ortsname an die Suche (OpenStreetMap), keine weiteren Angaben. Du brauchst dafür Netz.' }),
            h('div', { class: 'eingabe' }, eingabe)),
          h('p', null, knopf)),
        ergebnis,
        h('p', { class: 'hilfe' }, h('a', { href: pruefen ? zurueck : '#/orte/neu', text: pruefen ? 'Zurück, ohne zu prüfen' : 'Ohne Netz oder ohne Treffer: Ort ohne Prüfung anlegen' }))],
        h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: zurueck, text: 'Abbrechen' })));
    });
  }

  /* Standort: modus 'neu' (id = Ort) oder 'aendern' (id = Standort) */
  function standortFormular(modus, id) {
    var neu = modus === 'neu';
    var laden = neu ? daten.ortLaden(id).then(function (o) { return o ? { ort: { id: id, name: o.aktuell.werte.bezeichnung }, start: { bezeichnung: '' } } : null; })
      : daten.standortLaden(id).then(function (s) { return s ? { ort: s.ort, start: JSON.parse(JSON.stringify(s.aktuell.werte)) } : null; });
    return laden.then(function (k) {
      if (!k) return nichtGefunden('Nicht gefunden');
      var titel = neu ? 'Standort hinzufügen' : 'Standort ändern';
      var zurueck = '#/ort/' + encodeURIComponent(k.ort.id);
      einfachFormular({
        titel: titel, krumen: krumen(KR_ORTE.concat([['Orte', '#/orte'], [k.ort.name, zurueck], [titel]])), zurueck: zurueck, werte: k.start,
        intro: neu ? h('p', { text: 'Ein Standort ist ein einzelner Platz an diesem Ort, zum Beispiel „Liegeplatz 12“ oder „Stellplatz Nord“.' }) : null,
        gruppen: function () {
          var f = [{ key: 'bezeichnung', label: 'Name', typ: 'text', hilfe: 'Zum Beispiel „Liegeplatz 12“' }].concat(MM.Orte.standortFelder());
          if (!neu) f.push({ key: 'ausgeblendet', label: 'Anzeigen?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'nein', label: 'Ja, anzeigen' }, { wert: 'ja', label: 'Nein, ausblenden' }] });
          return [{ titel: null, felder: f }];
        },
        speichern: function (w) { return neu ? daten.standortAnlegen(id, w) : daten.standortAendern(id, w); },
        meldung: function (r) { return neu ? 'Standort angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function () { return zurueck; }
      });
    });
  }

  /* Regel: modus 'neu' (id = Gebiet, mit imOrt = true id = Ort, seit 2.0.42) oder 'aendern' (id = Regel).
     Eine Regel am Ort ist eine Regel des Ort-Gebiets: Die Seite führt zurück zum Ort. */
  function regelFormular(modus, id, imOrt) {
    var neu = modus === 'neu';
    var leer = { bezeichnung: '', art: 'befaehigung', pflichtAusruestung: '', menge: 1, bezug: 'fahrzeug', eignung: '', fahrzeugArten: [], ausruestung: '', artIds: [], gilt: 'ja' };
    var laden = neu && imOrt ? daten.ortLaden(id).then(function (o) { return o ? { gebiet: { id: null, name: o.aktuell.werte.bezeichnung }, ort: { id: id, name: o.aktuell.werte.bezeichnung }, start: leer } : null; })
      : neu ? daten.gebietLaden(id).then(function (g) { return g ? { gebiet: { id: id, name: g.aktuell.werte.bezeichnung }, ort: null, start: leer } : null; })
      : daten.regelLaden(id).then(function (x) { return x ? { gebiet: x.gebiet, ort: x.gebiet && x.gebiet.ortId ? { id: x.gebiet.ortId, name: x.gebiet.name } : null, start: Object.assign({ art: 'befaehigung', menge: 1, bezug: 'fahrzeug' }, JSON.parse(JSON.stringify(x.aktuell.werte))) } : null; });
    return Promise.all([laden, daten.nachweisartenListe('person')]).then(function (r) {
      var k = r[0], arten = r[1];
      if (!k) return nichtGefunden('Nicht gefunden');
      var titel = neu ? 'Regel hinzufügen' : 'Regel ändern';
      var zurueck = k.ort ? '#/ort/' + encodeURIComponent(k.ort.id) : '#/gebiet/' + encodeURIComponent(k.gebiet.id);
      var wo = k.ort ? 'am Ort „' + k.ort.name + '“' : 'im Gebiet „' + k.gebiet.name + '“';
      var optionen = arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || (k.start.artIds || []).indexOf(a.objekt.id) >= 0; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; });
      einfachFormular({
        titel: titel, krumen: krumen(KR_ORTE.concat([k.ort ? ['Orte', '#/orte'] : ['Gebiete', '#/gebiete'], [k.gebiet.name, zurueck], [titel]])), zurueck: zurueck, werte: k.start, neuzeichnenBei: ['art'],
        intro: h('p', { text: 'Wähle zuerst die Art der Regel. Befähigung: Wenn du ' + wo + ' unterwegs bist und Fahrzeugart und Ausrüstung passen, genügt einer der Nachweise, die du wählst. Pflichtausrüstung: Die genannte Ausrüstung muss am Fahrzeug eingetragen sein. Ohne Auswahl bei den Fahrzeugarten gilt die Regel für jedes Fahrzeug. Die Regel ist von dir eingetragen, die App prüft sie nicht auf Richtigkeit.' }),
        gruppen: function (z) {
          var aus = z.werte.art === 'ausruestung';
          if (!aus && !optionen.length) return [{ titel: null, hinweis: 'Es gibt noch keine Art von Nachweis für Personen. Übernimm Vorschläge unter Stammdaten › Nachweisarten oder lege eine eigene Art an.',
            felder: [{ key: 'art', label: 'Art der Regel', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Orte.REGELARTEN }] }];
          var f = [{ key: 'art', label: 'Art der Regel', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Orte.REGELARTEN },
            { key: 'bezeichnung', label: 'Bezeichnung', typ: 'text', hilfe: aus ? 'Zum Beispiel „Rettungswesten an Bord“' : 'Zum Beispiel „Funkzeugnis auf See“' }];
          if (aus) {
            f.push({ key: 'pflichtAusruestung', label: 'Pflichtausrüstung', typ: 'text', hilfe: 'Was muss am Fahrzeug sein, zum Beispiel „Rettungsweste“ oder „Feuerlöscher“? Die App sucht dieses Wort in den Namen der eingebauten Komponenten.' });
            f.push({ key: 'menge', label: 'Menge', typ: 'ganzzahl', hilfe: 'Wie viele müssen es sein? Bei „je Person an Bord“ gilt die Menge für jede Person.' });
            f.push({ key: 'bezug', label: 'Bezugsgröße', typ: 'auswahl', darstellung: 'wahl', optionen: MM.Orte.BEZUGSGROESSEN });
            f.push({ key: 'eignung', label: 'Gefordert (Eignung)', typ: 'text', hilfe: 'Freiwillig, zum Beispiel „Automatik, 150 N“. Ist etwas eingetragen, sagt die Prüfung „unklar“, bis bei den Komponenten der Haken „Eignung geprüft“ gesetzt ist. Die App prüft die Eignung nicht selbst.' });
          }
          f.push({ key: 'fahrzeugArten', label: 'Gilt für diese Fahrzeugarten', typ: 'mehrfach', hilfe: 'Nichts angekreuzt: gilt für jede Fahrzeugart.',
            optionen: MM.Fahrzeugarten.alle(true).map(function (a) { return { wert: a.id, label: a.name + (MM.Fahrzeugarten.sichtbar(a.id) ? '' : ' (ausgeblendet)') }; }) });
          if (!aus) {
            f.push({ key: 'ausruestung', label: 'Nur mit Ausrüstung', typ: 'text', hilfe: 'Freiwillig, zum Beispiel „Funkanlage“. Die Regel gilt, wenn am Fahrzeug eine eingebaute Komponente mit diesem Wort im Namen steht.' });
            f.push({ key: 'artIds', label: 'Genügt einer dieser Nachweise', typ: 'mehrfach', optionen: optionen });
          }
          if (!neu) f.push({ key: 'gilt', label: 'Gilt die Regel?', typ: 'auswahl', darstellung: 'wahl', optionen: [{ wert: 'ja', label: 'Ja, sie gilt' }, { wert: 'nein', label: 'Nein, abgeschaltet' }] });
          return [{ titel: null, felder: f }];
        },
        speichern: function (v) { return neu ? (imOrt ? daten.ortRegelAnlegen(id, v) : daten.regelAnlegen(id, v)) : daten.regelAendern(id, v); },
        meldung: function (r) { return neu ? 'Regel angelegt.' : (r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'); },
        danach: function () { return zurueck; }
      });
    });
  }

  /* Heimatstandort am Fahrzeug */
  function heimatstandortBereich(info, fahrzeugId) {
    var href = '#/fahrzeug/' + encodeURIComponent(fahrzeugId) + '/heimatstandort';
    return h('section', { class: 'bereich', 'aria-label': 'Heimatstandort' },
      h('h2', { text: 'Heimatstandort' }),
      info.standort ? h('p', null, h('a', { href: '#/ort/' + encodeURIComponent(info.standort.ortId), text: info.standort.ortName }), ', ' + info.standort.name)
        : h('p', { class: 'leer-text', text: 'Noch kein Heimatstandort gewählt.' }),
      h('a', { class: 'knopf leise', href: href, text: info.standort ? 'Heimatstandort ändern' : 'Heimatstandort wählen' }),
      info.verlauf.length > 1 ? h('details', { class: 'verlauf' },
        h('summary', { text: 'Verlauf des Heimatstandorts (' + info.verlauf.length + ')' }),
        h('ol', null, info.verlauf.map(function (v, i) {
          return h('li', { class: i === 0 ? 'aktuell' : null }, h('div', null, h('span', { class: 'wann', text: MM.Hilfen.zeitpunkt(v.eintrag.erstelltAm) }), i === 0 ? h('span', { class: 'marke-aktuell', text: 'aktuell' }) : null),
            h('div', { text: v.alt === null ? 'Gewählt: ' + v.neu : v.alt + ' → ' + v.neu }));
        }))) : null);
  }

  function heimatstandortFormular(fahrzeugId) {
    return Promise.all([daten.fahrzeugLaden(fahrzeugId), daten.fahrzeugStandort(fahrzeugId), daten.standorteListe(), daten.orteListe()]).then(function (r) {
      var f = r[0], info = r[1];
      if (!f) return nichtGefunden('Fahrzeug nicht gefunden');
      var orte = {}; r[3].forEach(function (o) { orte[o.objekt.id] = o.aktuell.werte.bezeichnung; });
      var aktuellId = info.standort ? info.standort.id : '';
      var optionen = r[2].filter(function (s) { return s.aktuell.werte.ausgeblendet !== 'ja' || s.objekt.id === aktuellId; })
        .map(function (s) { return { wert: s.objekt.id, label: (orte[s.objekt.ortId] || 'Ort') + ', ' + s.aktuell.werte.bezeichnung }; })
        .sort(function (a, b) { return a.label.localeCompare(b.label, 'de', { numeric: true, sensitivity: 'base' }); });
      var name = f.aktuell.werte.bezeichnung, zurueck = '#/fahrzeug/' + encodeURIComponent(fahrzeugId);
      einfachFormular({
        titel: 'Heimatstandort wählen', krumen: krumen(WEG_FAHRZEUGE.concat([[name, zurueck], ['Heimatstandort']])), zurueck: zurueck, werte: { standortId: aktuellId },
        intro: optionen.length ? h('p', { text: 'Wo steht das Fahrzeug normalerweise, zum Beispiel am Liegeplatz oder in der Garage? Die Wahl lässt sich jederzeit ändern, der frühere Stand bleibt im Verlauf.' })
          : h('div', { class: 'leer-hinweis' }, h('p', { text: 'Es gibt noch keinen Standort. Lege zuerst einen Ort mit einem Standort an.' }), h('p', null, h('a', { class: 'knopf', href: '#/orte', text: 'Zu den Orten' }))),
        gruppen: function () { return optionen.length ? [{ titel: null, felder: [{ key: 'standortId', label: 'Heimatstandort', typ: 'auswahl', optionen: optionen, leerText: '– keiner –' }] }] : []; },
        speichern: function (v) { return daten.fahrzeugStandortSetzen(fahrzeugId, v.standortId); },
        meldung: function (r) { return r.geaendert ? 'Gespeichert. Der frühere Stand bleibt im Verlauf sichtbar.' : 'Es gab keine Änderung.'; },
        danach: function () { return zurueck; }
      });
    });
  }

  /* ---------- Startseite ---------- */
  function seiteStart() {
    doc.title = 'MobiMory';
    wurzel.textContent = '';
    var saetze = MM.Texte.KERNSATZ.split('. ').map(function (t, i, a) { return i < a.length - 1 ? t + '.' : t; });
    wurzel.appendChild(h('main', { class: 'start', id: 'inhalt' },
      h('div', { class: 'start-logo' },
        h('img', { src: 'icons/icon.svg', alt: '', width: '112', height: '112' }),
        h('p', { class: 'start-name', text: 'MobiMory' }),
        h('p', { class: 'start-vtd', text: 'Vehicle, Travel and Data' })),
      h('h1', { class: 'kernsatz' }, saetze.map(function (z, i) {
        return h('span', { class: 'satz' },
          h('span', { class: 'chip', 'aria-hidden': 'true', text: 'VTD'.charAt(i) }),
          h('span', { text: z + ' ' }));
      })),
      h('p', { class: 'infotext', text: MM.Texte.INFOTEXT }),
      h('div', { class: 'start-knoepfe' },
        h('a', { class: 'knopf gross', href: '#/auswahl', text: 'Programm starten' }),
        h('a', { class: 'knopf leise gross', href: '#/neu-im-programm', text: 'Neu im Programm' })),
      h('footer', { class: 'start-fuss' },
        h('p', { text: MM.Texte.COPYRIGHT }),
        h('p', { text: 'Version ' + MM.VERSION }))));
    global.scrollTo(0, 0);
    return Promise.resolve();
  }

  /* ---------- Kacheln ---------- */
  function kachel(titel, text, href) {
    var inhalt = [h('span', { class: 'kachel-titel', text: titel }), h('span', { class: 'kachel-text', text: text })];
    if (href) return h('a', { class: 'kachel', href: href }, inhalt);
    return h('div', { class: 'kachel bald' }, inhalt, h('span', { class: 'kachel-bald', text: 'kommt' }));
  }

  /* ---------- Hauptmenü (äußerste Schale nach der Startseite) ---------- */
  function seiteHauptmenue() {
    return daten.sicherungErinnerung().then(function (e) {
      var hinweis = null;
      if (e.faellig) {
        hinweis = h('div', { class: 'erinnerung', role: 'status' },
          h('p', { text: e.grund === 'nie' ? 'Du hast noch nie eine Sicherung erstellt. Geht das Gerät kaputt, sind deine Daten weg.' : 'Die letzte Sicherung ist ' + e.tage + ' Tage her.' }),
          h('a', { class: 'knopf', href: '#/einstellungen/sichern', text: 'Jetzt sichern' }));
      }
      seite('Hauptmenü', [
        h('h1', { text: 'Hauptmenü' }),
        hinweis,
        h('div', { class: 'kacheln' },
          kachel('Stammdaten', 'Fahrzeuge, Personen, Tiere, Orte, Gebiete, Adressen und alle Arten-Listen', '#/stammdaten'),
          kachel('Funktionen', 'Aktivitäten, Werkstatt, Kassenbuch, Kosten und mehr', '#/funktionen'),
          kachel('Einstellungen', 'Deine Daten, Sicherung und Hinweise zum Programm', '#/einstellungen')),
        h('p', { class: 'zur-start' }, h('a', { href: '#/', text: 'Zur Startseite' }))
      ]);
    });
  }

  function seiteStammdaten() {
    return Promise.all([daten.fahrzeugListe(), daten.personenListe(), daten.tiereListe(), daten.nachweisartenListe(), daten.orteListe(), daten.gebieteListe(), daten.adressenListe(),
      daten.aktivitaetsartenListe(), daten.ereignisartenListe(), daten.kostenartenListe(), daten.zahlungsmittelListe()]).then(function (r) {
      function zahl(n, eins, viele, keins) { return n === 0 ? keins : (n === 1 ? '1 ' + eins : n + ' ' + viele); }
      seite('Stammdaten', [
        krumen([['Hauptmenü', '#/auswahl'], ['Stammdaten']]),
        h('h1', { text: 'Stammdaten' }),
        h('div', { class: 'kacheln' },
          kachel('Fahrzeuge', zahl(r[0].length, 'Fahrzeug', 'Fahrzeuge', 'Noch kein Fahrzeug angelegt'), '#/fahrzeuge'),
          kachel('Fahrzeugarten', 'Arten und Untergruppen selbst anlegen, ausblenden, bereinigen', '#/fahrzeugarten'),
          kachel('Personen', zahl(r[1].length, 'Person', 'Personen', 'Besatzung und Gäste'), '#/personen'),
          kachel('Tiere', zahl(r[2].length, 'Tier', 'Tiere', 'Tiere an Bord'), '#/tiere'),
          kachel('Nachweisarten', zahl(r[3].length, 'Art', 'Arten', 'Führerschein, Ausweis, Heimtierausweis und mehr'), '#/nachweisarten'),
          kachel('Orte', zahl(r[4].length, 'Ort', 'Orte', 'Heimat- und Reiseorte, Standorte und Besuche'), '#/orte'),
          kachel('Gebiete', zahl(r[5].length, 'Gebiet', 'Gebiete', 'Länder und Reviere mit ihren Regeln'), '#/gebiete'),
          kachel('Adressen', zahl(r[6].length, 'Adresse', 'Adressen', 'Werkstätten, Lieferanten und Händler'), '#/adressen'),
          kachel('Arten von Aktivitäten', zahl(r[7].length, 'Art', 'Arten', 'Urlaub, Törn, Ausfahrt und mehr'), '#/aktivitaetsarten'),
          kachel('Arten von Ereignissen', zahl(r[8].length, 'Art', 'Arten', 'Für Logbuch und Cockpit, zum Beispiel Abfahrt und Ankunft'), '#/ereignisarten'),
          kachel('Merkmale und Einheiten', 'Listen für die technischen Merkmale der Komponenten', '#/merkmale'),
          kachel('Kostenarten und Zahlungsmittel', r[9].filter(function (x) { return !x.ausgeblendet; }).length + ' Kostenarten, ' + r[10].filter(function (x) { return !x.ausgeblendet; }).length + ' Zahlungsmittel', '#/kosten/listen'))
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/auswahl', text: 'Zurück' })));
    });
  }

  /* ---------- Neu im Programm ---------- */
  function seiteNeuerungen() {
    seite('Neu im Programm', [
      h('h1', { text: 'Neu im Programm' }),
      h('div', { class: 'neuerungen' }, MM.Texte.NEUERUNGEN.map(function (v) {
        return h('section', { class: 'neuerung' },
          h('h2', { text: 'Version ' + v.version }),
          h('p', { class: 'datum', text: MM.Hilfen.datum(v.datum) }),
          h('ul', null, v.punkte.map(function (t) { return h('li', { text: t }); })));
      }))
    ], h('div', { class: 'leiste' },
      h('a', { class: 'knopf leise', href: '#/', text: 'Zur Startseite' }),
      h('a', { class: 'knopf', href: '#/auswahl', text: 'Programm starten' })));
    return Promise.resolve();
  }

  /* ---------- Einstellungen ---------- */
  /* ---------- Sicherung ---------- */
  var ERINNERUNG_WAHL = [{ wert: '0', label: 'Nie erinnern' }, { wert: '14', label: 'Nach 14 Tagen' }, { wert: '30', label: 'Nach 30 Tagen' }, { wert: '90', label: 'Nach 90 Tagen' }];

  function sicherungBlock(info) {
    var meld = h('p', { class: 'hinweis', role: 'status' });
    var sel = h('select', { id: 'erinnerung', 'aria-label': 'Erinnerung an die Sicherung', onchange: function () {
      daten.sicherungEinstellen({ erinnerungTage: parseInt(sel.value, 10) }).then(function () { meld.textContent = 'Gespeichert.'; }).catch(fehlerSeite);
    } }, ERINNERUNG_WAHL.map(function (o) { return h('option', { value: o.wert, text: o.label }); }));
    sel.value = String(info.erinnerungTage);
    return h('section', { class: 'block' },
      h('h2', { text: 'Sicherung' }),
      info.letzte ? h('p', { text: 'Letzte Sicherung: ' + MM.Hilfen.zeitpunkt(info.letzte) + ' Uhr.' })
        : h('p', { class: info.hatDaten ? 'fehler' : null, text: info.hatDaten ? 'Du hast noch nie gesichert. Geht das Gerät kaputt, sind die Daten weg.' : 'Noch nie gesichert. Es gibt auch noch nichts zu sichern.' }),
      h('p', { class: 'knopfzeile' },
        h('a', { class: 'knopf', href: '#/einstellungen/sichern', text: 'Sicherung erstellen' }),
        h('a', { class: 'knopf leise', href: '#/einstellungen/wiederherstellen', text: 'Wiederherstellen' })),
      h('div', { class: 'feld' }, h('label', { for: 'erinnerung', text: 'Erinnerung' }), h('div', { class: 'eingabe' }, sel), meld));
  }

  function zahlenListe(z) {
    var teile = [['fahrzeuge', 'Fahrzeuge'], ['komponenten', 'Komponenten'], ['fristen', 'Fristen'], ['zaehler', 'Zähler'], ['personen', 'Personen'], ['tiere', 'Tiere'], ['nachweise', 'Nachweise'], ['aktivitaeten', 'Aktivitäten'], ['dokumente', 'Dokumente'], ['tagesabschnitte', 'Tagesabschnitte'], ['ereignisse', 'Ereignisse'], ['vorgaenge', 'Vorgänge'], ['adressen', 'Adressen'], ['kosten', 'Kostenposten'], ['besuche', 'Besuche'], ['kassenbuchungen', 'Kassenbuchungen'], ['routen', 'Routen']];
    return teile.filter(function (t) { return z[t[0]]; }).map(function (t) { return z[t[0]] + ' ' + t[1]; }).join(', ') || 'noch nichts';
  }

  function dateiSpeichern(bytes, name, typ) {
    var url = global.URL.createObjectURL(new global.Blob([bytes], { type: typ || 'application/octet-stream' }));
    var a = doc.createElement('a');
    a.href = url; a.download = name;
    doc.body.appendChild(a); a.click(); a.remove();
    global.setTimeout(function () { global.URL.revokeObjectURL(url); }, 60000);
  }

  function seiteSichern() {
    return daten.sicherungZahlen().then(function (z) {
      var fel = h('p', { class: 'fehler', role: 'alert' });
      var status = h('p', { class: 'hinweis', role: 'status' });
      var cb = h('input', { type: 'checkbox', id: 'sx-dateien', checked: z.dateien ? 'checked' : null });
      var pw1 = h('input', { type: 'password', id: 'sx-pw1', autocomplete: 'new-password', 'aria-describedby': 'sx-pw-hilfe' });
      var pw2 = h('input', { type: 'password', id: 'sx-pw2', autocomplete: 'new-password' });
      var knopf = h('button', { class: 'knopf', type: 'button', text: 'Sicherung erstellen' });
      var behaelter = h('div');

      function ergebnis(s) {
        behaelter.textContent = '';
        var jetztIso = daten.jetzt();
        function markieren() { daten.sicherungEinstellen({ letzteSicherung: jetztIso }); }
        var teilen = null;
        try {
          var f = new global.File([s.bytes], s.name, { type: 'application/octet-stream' });
          if (global.navigator.canShare && global.navigator.canShare({ files: [f] })) {
            teilen = h('button', { class: 'knopf leise', type: 'button', text: 'Teilen oder in die Cloud legen', onclick: function () {
              global.navigator.share({ files: [f], title: 'MobiMory-Sicherung' }).then(markieren).catch(function () {});
            } });
          }
        } catch (e) { teilen = null; }
        behaelter.appendChild(h('section', { class: 'block' },
          h('h2', { text: 'Die Sicherung ist fertig' }),
          h('dl', { class: 'daten stapel' },
            h('dt', { text: 'Datei' }), h('dd', { text: s.name }),
            h('dt', { text: 'Größe' }), h('dd', { text: MM.Hilfen.groesse(s.groesse) }),
            h('dt', { text: 'Enthält' }), h('dd', { text: zahlenListe(s.zahlen) + (s.mitDateien ? '; dazu ' + s.dateien + (s.dateien === 1 ? ' Datei' : ' Dateien') + ' (Dokumente und Scans)' : '; ohne Dokumente und Scans') }),
            h('dt', { text: 'Schutz' }), h('dd', { text: s.verschluesselt ? 'Mit Schlüsselwort verschlüsselt' : 'Ohne Schlüsselwort, jeder kann sie lesen' })),
          h('p', { class: 'knopfzeile' },
            h('button', { class: 'knopf', type: 'button', text: 'Auf dem Gerät speichern', onclick: function () { dateiSpeichern(s.bytes, s.name); markieren(); } }),
            teilen),
          h('p', { class: 'hinweis', text: 'Lege die Datei an einen sicheren Ort, am besten nicht nur auf diesem Gerät, zum Beispiel in deiner Cloud oder per E-Mail an dich selbst. Ob die Datei gut angekommen ist, siehst du dort. Danach merkt sich die App das Datum.' }),
          s.verschluesselt ? h('p', { class: 'hinweis', text: 'Merke dir das Schlüsselwort gut. Ohne es lässt sich die Sicherung nicht mehr öffnen.' }) : null,
          h('p', null, h('a', { class: 'knopf leise', href: '#/einstellungen', text: 'Fertig' }))));
      }

      knopf.addEventListener('click', function () {
        fel.textContent = '';
        var w1 = pw1.value, w2 = pw2.value;
        if (w1 || w2) {
          if (w1.length < 8) { fel.textContent = 'Das Schlüsselwort braucht mindestens 8 Zeichen.'; pw1.focus(); return; }
          if (w1 !== w2) { fel.textContent = 'Die beiden Schlüsselwörter sind nicht gleich.'; pw2.focus(); return; }
        } else if (!global.confirm('Ohne Schlüsselwort kann jeder die Datei lesen, der sie bekommt. Darin stehen auch Ausweisdaten. Trotzdem ohne Schlüsselwort sichern?')) {
          return;
        }
        knopf.disabled = true;
        status.textContent = 'Die Sicherung wird erstellt. Das kann bei vielen Dateien etwas dauern …';
        daten.sicherungErzeugen({ mitDateien: cb.checked, schluessel: w1 }).then(function (s) { status.textContent = ''; ergebnis(s); })
          .catch(function (err) { knopf.disabled = false; status.textContent = ''; fel.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler') + '. Es wurde nichts verändert.'; });
      });

      behaelter.appendChild(h('div', { class: 'formular' },
        h('p', { text: 'Die Sicherungsdatei enthält alle deine Daten. Mit ihr bekommst du alles zurück, wenn das Gerät kaputt geht, und kannst auf ein neues Gerät umziehen.' }),
        z.dateien ? h('div', { class: 'feld' },
          h('label', { class: 'checkzeile' }, cb, h('span', { text: 'Dokumente und Scans mitsichern (' + z.dateien + (z.dateien === 1 ? ' Datei, ' : ' Dateien, ') + MM.Hilfen.groesse(z.dateiBytes) + ')' })),
          h('p', { class: 'hilfe', text: 'Ohne Dateien wird die Sicherung klein. Die Dokumente und Scans müssen dann nach einer Wiederherstellung neu abgelegt werden.' })) : null,
        h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
          h('legend', { class: 'fest-art', text: 'Schlüsselwort (empfohlen)' }),
          h('p', { class: 'hilfe', id: 'sx-pw-hilfe', text: 'Die Datei enthält Ausweisdaten und Scans. Mit einem Schlüsselwort ist sie verschlüsselt. Vergisst du es, kann niemand die Sicherung öffnen, auch ich nicht. Ohne Schlüsselwort kann sie jeder lesen.' }),
          h('label', { for: 'sx-pw1', text: 'Schlüsselwort' }), h('div', { class: 'eingabe' }, pw1),
          h('label', { for: 'sx-pw2', text: 'Schlüsselwort wiederholen' }), h('div', { class: 'eingabe' }, pw2)),
        fel, status, h('p', null, knopf)));

      seite('Sicherung erstellen', [
        krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen', '#/einstellungen'], ['Sicherung erstellen']]),
        h('h1', { text: 'Sicherung erstellen' }), behaelter
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/einstellungen', text: 'Zurück' })));
    });
  }

  function seiteWiederherstellen() {
    var behaelter = h('div');
    var zustand = { bytes: null };

    function zeigeWahl(fehlertext) {
      behaelter.textContent = '';
      var eingabe = h('input', { type: 'file', id: 'wd-datei', onchange: function () {
        var f = eingabe.files && eingabe.files[0];
        if (!f) return;
        f.arrayBuffer().then(function (buf) { zustand.bytes = new Uint8Array(buf); return versuchen(''); }).catch(function (e) { zeigeWahl('Die Datei konnte nicht gelesen werden: ' + (e && e.message ? e.message : '')); });
      } });
      behaelter.appendChild(h('div', { class: 'formular' },
        h('div', { class: 'fehlerkasten' }, 'Beim Wiederherstellen werden ALLE Daten auf diesem Gerät durch die der Sicherung ersetzt. Zusammenführen gibt es nicht.'),
        h('div', { class: 'feld' }, h('label', { for: 'wd-datei', text: 'Sicherungsdatei auswählen' }), h('div', { class: 'eingabe' }, eingabe)),
        fehlertext ? h('p', { class: 'fehler', role: 'alert', text: fehlertext }) : null,
        h('p', { class: 'hinweis', text: 'Es wird noch nichts verändert. Zuerst siehst du, was in der Sicherung steht.' })));
    }

    function zeigeSchluessel(fehlertext) {
      behaelter.textContent = '';
      var pw = h('input', { type: 'password', id: 'wd-pw', autocomplete: 'current-password' });
      behaelter.appendChild(h('div', { class: 'formular' },
        h('p', { text: 'Diese Sicherung ist verschlüsselt. Gib das Schlüsselwort ein.' }),
        h('div', { class: 'feld' }, h('label', { for: 'wd-pw', text: 'Schlüsselwort' }), h('div', { class: 'eingabe' }, pw)),
        fehlertext ? h('p', { class: 'fehler', role: 'alert', text: fehlertext }) : null,
        h('p', { class: 'knopfzeile' },
          h('button', { class: 'knopf', type: 'button', text: 'Öffnen', onclick: function () { versuchen(pw.value); } }),
          h('button', { class: 'knopf leise', type: 'button', text: 'Andere Datei', onclick: function () { zeigeWahl(); } }))));
    }

    function versuchen(wort) {
      return daten.sicherungLesen(zustand.bytes, wort).then(function (g) { return zeigeVorschau(g); }).catch(function (err) {
        if (err && err.code === 'schluessel_noetig') return zeigeSchluessel();
        if (err && err.code === 'schluessel') return zeigeSchluessel(err.message);
        zeigeWahl(err && err.message ? err.message : 'Die Datei lässt sich nicht lesen.');
      });
    }

    function zeigeVorschau(g) {
      return daten.sicherungVorschau(g).then(function (v) {
        behaelter.textContent = '';
        var teile = [['fahrzeuge', 'Fahrzeuge'], ['komponenten', 'Komponenten'], ['fristen', 'Fristen'], ['zaehler', 'Zähler'], ['personen', 'Personen'], ['tiere', 'Tiere'], ['nachweise', 'Nachweise'], ['aktivitaeten', 'Aktivitäten'], ['dokumente', 'Dokumente'], ['tagesabschnitte', 'Tagesabschnitte'], ['ereignisse', 'Ereignisse'], ['vorgaenge', 'Vorgänge'], ['adressen', 'Adressen'], ['kosten', 'Kostenposten'], ['besuche', 'Besuche'], ['kassenbuchungen', 'Kassenbuchungen'], ['routen', 'Routen']];
        var ok = h('input', { type: 'checkbox', id: 'wd-ok' });
        var los = h('button', { class: 'knopf gefahr', type: 'button', text: 'Jetzt wiederherstellen', disabled: 'disabled' });
        var fel = h('p', { class: 'fehler', role: 'alert' });
        ok.addEventListener('change', function () { if (ok.checked) los.removeAttribute('disabled'); else los.setAttribute('disabled', 'disabled'); });
        los.addEventListener('click', function () {
          los.setAttribute('disabled', 'disabled'); fel.textContent = '';
          daten.sicherungEinspielen(g).then(function () {
            meldung = 'Wiederhergestellt: Die Sicherung vom ' + MM.Hilfen.zeitpunkt(v.erstelltAm) + ' Uhr ist jetzt auf diesem Gerät.';
            if (global.location.hash === '#/auswahl') return zeige();
            global.location.hash = '#/auswahl';
          }).catch(function (err) { los.removeAttribute('disabled'); fel.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : '') + ' Es wurde nichts verändert.'; });
        });
        behaelter.appendChild(h('div', { class: 'formular' },
          h('p', null, 'Sicherung vom ', h('strong', { text: MM.Hilfen.zeitpunkt(v.erstelltAm) + ' Uhr' }), ', erstellt mit MobiMory ' + (v.app || '?') + '.'),
          h('table', { class: 'vergleich' },
            h('thead', null, h('tr', null, h('th', { text: '' }), h('th', { text: 'In der Sicherung' }), h('th', { text: 'Jetzt hier' }))),
            h('tbody', null, teile.filter(function (t) { return v.zahlen[t[0]] || v.jetzt[t[0]]; }).map(function (t) {
              return h('tr', null, h('td', { text: t[1] }), h('td', { text: String(v.zahlen[t[0]] || 0) }), h('td', { text: String(v.jetzt[t[0]] || 0) }));
            }))),
          v.mitDateien ? h('p', { text: 'Dokumente und Scans: enthalten (' + v.dateien + (v.dateien === 1 ? ' Datei, ' : ' Dateien, ') + MM.Hilfen.groesse(v.dateiBytes) + ').' })
            : h('p', { class: 'hinweis', text: 'Dokumente und Scans: nicht in der Sicherung. Sie müssen nach der Wiederherstellung neu abgelegt werden.' }),
          h('div', { class: 'fehlerkasten', text: 'Alles, was jetzt auf diesem Gerät steht, wird ersetzt. Was nach dieser Sicherung dazugekommen ist, geht verloren.' }),
          h('p', null, h('a', { href: '#/einstellungen/sichern', text: 'Zuerst den jetzigen Stand sichern' })),
          h('div', { class: 'feld' }, h('label', { class: 'checkzeile' }, ok, h('span', { text: 'Ich weiß es: Alle Daten auf diesem Gerät werden ersetzt.' }))),
          fel, h('p', null, los),
          h('p', null, h('button', { class: 'knopf leise', type: 'button', text: 'Andere Datei', onclick: function () { zeigeWahl(); } }))));
      });
    }

    zeigeWahl();
    seite('Wiederherstellen', [
      krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen', '#/einstellungen'], ['Wiederherstellen']]),
      h('h1', { text: 'Aus Sicherung wiederherstellen' }), behaelter
    ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/einstellungen', text: 'Zurück' })));
    return Promise.resolve();
  }

  function schaetzung() {
    var n = global.navigator;
    if (!n.storage || !n.storage.estimate) return Promise.resolve(null);
    return Promise.all([
      n.storage.estimate().catch(function () { return null; }),
      n.storage.persisted ? n.storage.persisted().catch(function () { return null; }) : Promise.resolve(null)
    ]).then(function (r) { return r[0] ? { usage: r[0].usage, quota: r[0].quota, dauerhaft: r[1] } : null; });
  }

  /* ---------- Fahrzeug abgeben, Übergabe, Übernehmen (seit 2.0.37) ---------- */
  function teilenKnopf(bytes, name, mime) {
    try {
      var f = new global.File([bytes], name, { type: mime });
      if (global.navigator.canShare && global.navigator.canShare({ files: [f] })) {
        return h('button', { class: 'knopf leise', type: 'button', text: 'Teilen oder in die Cloud legen', onclick: function () { global.navigator.share({ files: [f], title: name }).catch(function () {}); } });
      }
    } catch (e) { /* kein Teilen möglich */ }
    return null;
  }

  function seiteAbgeben(id) {
    return daten.fahrzeugLaden(id).then(function (f) {
      if (!f) return nichtGefunden('Fahrzeug nicht gefunden');
      if (f.fahrzeug.abgabe) { global.location.hash = '#/fahrzeug/' + encodeURIComponent(id) + '/uebergabe'; return null; }
      var w = f.aktuell.werte;
      var zustand = { datum: daten.heute(), grund: '', notiz: '', fehler: {} };
      var behaelter = h('div');
      function lesen() {
        var d = behaelter.querySelector('#ab-datum'), n = behaelter.querySelector('#ab-notiz');
        if (d) zustand.datum = d.value; if (n) zustand.notiz = n.value;
      }
      function speichern(ev) {
        ev.preventDefault(); lesen();
        daten.fahrzeugAbgeben(id, { datum: zustand.datum, grund: zustand.grund, notiz: zustand.notiz }).then(function (r) {
          if (!r.ok) { zustand.fehler = r.fehler; zeichne(); var e1 = behaelter.querySelector('.hat-fehler input, .hat-fehler textarea'); if (e1) e1.focus(); return; }
          meldung = 'Das Fahrzeug ist abgegeben. Jetzt kannst du die Übergabedatei und das PDF erzeugen.' +
            (r.zuordnungGeloest && r.zuordnungGeloest.length ? ' Hinweis: ' + r.zuordnungGeloest.join(', ') + (r.zuordnungGeloest.length === 1 ? ' gehört' : ' gehören') + ' nicht mehr zu diesem Fahrzeug. ' + (r.zuordnungGeloest.length === 1 ? 'Es bleibt' : 'Sie bleiben') + ' bestehen.' : '');
          global.location.hash = '#/fahrzeug/' + encodeURIComponent(id) + '/uebergabe';
        }).catch(fehlerSeite);
      }
      function zeichne() {
        behaelter.textContent = '';
        var fk = Object.keys(zustand.fehler);
        behaelter.appendChild(h('form', { class: 'formular', novalidate: 'novalidate', id: 'formular', onsubmit: speichern },
          fk.length ? h('div', { class: 'fehlerkasten', role: 'alert', text: fk.length === 1 ? 'Bitte eine Angabe prüfen.' : 'Bitte ' + fk.length + ' Angaben prüfen.' }) : null,
          h('div', { class: 'feld' + (zustand.fehler.datum ? ' hat-fehler' : '') },
            h('label', { for: 'ab-datum', text: 'Datum der Abgabe' }),
            h('div', { class: 'eingabe' }, h('input', { id: 'ab-datum', type: 'date', value: zustand.datum || '', max: daten.heute() })),
            zustand.fehler.datum ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.datum }) : null),
          h('fieldset', { class: 'feld' + (zustand.fehler.grund ? ' hat-fehler' : ''), style: 'border:0;padding:0;margin:0' },
            h('legend', { class: 'fest-art', text: 'Warum?' }),
            daten.abgabeGruende().map(function (g) {
              var r = h('input', { type: 'radio', name: 'ab-grund', value: g.wert, id: 'ab-g-' + g.wert, onchange: function () { lesen(); zustand.grund = g.wert; } });
              if (zustand.grund === g.wert) r.checked = true;
              return h('label', { class: 'checkzeile', for: 'ab-g-' + g.wert }, r, h('span', { text: g.label }));
            }),
            zustand.fehler.grund ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.grund }) : null),
          h('div', { class: 'feld' + (zustand.fehler.notiz ? ' hat-fehler' : '') },
            h('label', { for: 'ab-notiz', text: 'Notiz (freiwillig)' }),
            h('p', { class: 'hilfe', text: 'Zum Beispiel an wen. Die Notiz bleibt bei dir und geht nicht in die Übergabe.' }),
            h('div', { class: 'eingabe' }, h('textarea', { id: 'ab-notiz', rows: '3', maxlength: '500' }, zustand.notiz)),
            zustand.fehler.notiz ? h('p', { class: 'fehler', role: 'alert', text: zustand.fehler.notiz }) : null)));
      }
      zeichne();
      seite('Fahrzeug abgeben', [
        krumen(WEG_FAHRZEUGE.concat([[w.bezeichnung, '#/fahrzeug/' + encodeURIComponent(id)], ['Abgeben']])),
        h('h1', { text: w.bezeichnung + ' abgeben' }),
        h('section', { class: 'block' },
          h('h2', { text: 'Das passiert' }),
          h('ul', null,
            h('li', { text: 'Das Fahrzeug verschwindet aus allen Auswahllisten und lässt sich nicht mehr planen.' }),
            h('li', { text: 'Es bleibt bei dir lesbar, mit allem, was du eingetragen hast. Nichts wird gelöscht.' }),
            h('li', { text: 'Deine Aktivitäten, das Logbuch, die Kosten und die Reisekasse bleiben bei dir. Sie gehören zu deiner Besitzzeit.' }),
            h('li', { text: 'Danach kannst du die technische Historie als Übergabedatei für den neuen Besitzer und als PDF (Technik-Akte) erzeugen.' }),
            h('li', { text: 'Ein Fehler? Du kannst das Fahrzeug jederzeit wieder aktiv setzen.' }))),
        behaelter
      ], h('div', { class: 'leiste' },
        h('a', { class: 'knopf leise', href: '#/fahrzeug/' + encodeURIComponent(id), text: 'Abbrechen' }),
        h('button', { class: 'knopf', type: 'submit', form: 'formular', text: 'Fahrzeug abgeben' })));
      return null;
    });
  }

  var ZEITRAUM_TEXT = {
    'hu': function (z) { return 'Die Akte reicht von der letzten HU am ' + MM.Hilfen.datum(z.huDatum) + ' bis zur Abgabe.'; },
    'hu-alt': function (z) { return 'Die letzte HU (' + MM.Hilfen.datum(z.huDatum) + ') ist mehr als 24 Monate her. Die Akte zeigt deshalb die letzten 24 Monate bis zur Abgabe, ab ' + MM.Hilfen.datum(z.von) + '. Das steht auch im PDF.'; },
    'angelegt': function (z) { return 'Es ist keine HU erfasst. Die Akte beginnt, als du das Fahrzeug in MobiMory angelegt hast (' + MM.Hilfen.datum(z.von) + ').'; },
    'ohne-hu-grenze': function (z) { return 'Es ist keine HU erfasst. Die Akte zeigt die letzten 24 Monate bis zur Abgabe, ab ' + MM.Hilfen.datum(z.von) + '.'; }
  };

  function seiteUebergabe(id) {
    return daten.fahrzeugLaden(id).then(function (f) {
      if (!f) return nichtGefunden('Fahrzeug nicht gefunden');
      var w = f.aktuell.werte, abg = f.fahrzeug.abgabe;
      var krume = krumen(WEG_FAHRZEUGE.concat([[w.bezeichnung, '#/fahrzeug/' + encodeURIComponent(id)], ['Übergabe']]));
      var zurueck = h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/fahrzeug/' + encodeURIComponent(id), text: 'Zum Fahrzeug' }));
      if (!abg) {
        seite('Übergabe', [krume, h('h1', { text: 'Übergabe: ' + w.bezeichnung }),
          h('p', { text: 'Dieses Fahrzeug ist noch nicht abgegeben. Gib es zuerst ab. Danach kannst du hier die Übergabedatei und das PDF erzeugen.' }),
          h('p', null, h('a', { class: 'knopf', href: '#/fahrzeug/' + encodeURIComponent(id) + '/abgeben', text: 'Fahrzeug abgeben' }))], zurueck);
        return null;
      }
      return daten.akteDaten(id).then(function (akte) {
        var pdfBox = h('div'), dateiBox = h('div');

        /* PDF */
        function pdfStart() {
          pdfBox.textContent = '';
          var fel = h('p', { class: 'fehler', role: 'alert' }), status = h('p', { class: 'hinweis', role: 'status' });
          var los = h('button', { class: 'knopf', type: 'button', text: 'PDF erstellen', onclick: function () {
            fel.textContent = ''; los.disabled = true; status.textContent = 'Das PDF wird erstellt …';
            daten.akteErzeugen(id).then(function (r) {
              status.textContent = '';
              if (!r.ok) { los.disabled = false; fel.textContent = r.fehler && r.fehler.allgemein ? r.fehler.allgemein : 'Das hat nicht geklappt.'; return; }
              pdfBox.textContent = '';
              pdfBox.appendChild(h('div', null,
                h('p', null, h('strong', { text: r.name }), ' (' + r.seiten + (r.seiten === 1 ? ' Seite, ' : ' Seiten, ') + MM.Hilfen.groesse(r.groesse) + ')'),
                h('p', { class: 'knopfzeile' },
                  h('button', { class: 'knopf', type: 'button', text: 'Auf dem Gerät speichern', onclick: function () { dateiSpeichern(r.bytes, r.name, r.mime); } }),
                  teilenKnopf(r.bytes, r.name, r.mime),
                  h('button', { class: 'knopf leise', type: 'button', text: 'Neu erstellen', onclick: pdfStart }))));
            }).catch(function (e) { los.disabled = false; status.textContent = ''; fel.textContent = 'Das hat nicht geklappt: ' + (e && e.message ? e.message : 'unbekannter Fehler') + '.'; });
          } });
          pdfBox.appendChild(h('div', null, fel, status, h('p', null, los)));
        }
        pdfStart();

        /* Übergabedatei */
        function dateiStart() {
          dateiBox.textContent = '';
          var cb = h('input', { type: 'checkbox', id: 'ue-dateien', checked: 'checked' });
          var pw = h('input', { type: 'password', id: 'ue-pw', autocomplete: 'new-password' });
          var fel = h('p', { class: 'fehler', role: 'alert' }), status = h('p', { class: 'hinweis', role: 'status' });
          var los = h('button', { class: 'knopf', type: 'button', text: 'Übergabedatei erstellen', onclick: function () {
            fel.textContent = ''; los.disabled = true; status.textContent = 'Die Datei wird erstellt …';
            daten.uebergabeErzeugen(id, { mitDateien: cb.checked, schluessel: pw.value }).then(function (r) {
              status.textContent = '';
              if (!r.ok) { los.disabled = false; fel.textContent = r.fehler && r.fehler.allgemein ? r.fehler.allgemein : 'Das hat nicht geklappt.'; return; }
              dateiBox.textContent = '';
              dateiBox.appendChild(h('div', null,
                h('p', null, h('strong', { text: r.name }), ' (' + MM.Hilfen.groesse(r.groesse) + (r.verschluesselt ? ', verschlüsselt' : '') + ')'),
                h('p', { text: 'Enthält: ' + r.zahlen.komponenten + ' Komponenten, ' + r.zahlen.fristen + ' Fristen, ' + r.zahlen.zaehler + ' Zähler, ' + r.zahlen.vorgaenge + ' Vorgänge, ' + r.zahlen.dokumente + ' Dokumente' + (r.mitDateien ? ' (mit ' + r.dateien + (r.dateien === 1 ? ' Datei)' : ' Dateien)') : ' (ohne Dateien)') + '.' }),
                h('p', { class: 'knopfzeile' },
                  h('button', { class: 'knopf', type: 'button', text: 'Auf dem Gerät speichern', onclick: function () { dateiSpeichern(r.bytes, r.name, 'application/octet-stream'); } }),
                  teilenKnopf(r.bytes, r.name, 'application/octet-stream'),
                  h('button', { class: 'knopf leise', type: 'button', text: 'Neu erstellen', onclick: dateiStart }))));
            }).catch(function (e) { los.disabled = false; status.textContent = ''; fel.textContent = 'Das hat nicht geklappt: ' + (e && e.message ? e.message : 'unbekannter Fehler') + '.'; });
          } });
          dateiBox.appendChild(h('div', { class: 'formular' },
            h('label', { class: 'checkzeile', for: 'ue-dateien' }, cb, h('span', { text: 'Dokumente und Dateien (Anleitungen, Belege, Fotos) mitgeben' })),
            h('div', { class: 'feld' }, h('label', { for: 'ue-pw', text: 'Schlüsselwort (freiwillig)' }),
              h('p', { class: 'hilfe', text: 'Mit Schlüsselwort lässt sich die Datei nur mit diesem Wort öffnen. Sag es dem neuen Besitzer getrennt von der Datei.' }),
              h('div', { class: 'eingabe' }, pw)),
            fel, status, h('p', null, los)));
        }
        dateiStart();

        var wieder = h('button', { class: 'knopf leise', type: 'button', text: 'Wieder aktiv setzen', onclick: function () {
          if (!global.confirm('Das Fahrzeug wieder aktiv setzen? Es erscheint dann wieder in den Auswahllisten.')) return;
          daten.fahrzeugWiederAktiv(id).then(function () { meldung = 'Das Fahrzeug ist wieder aktiv.'; global.location.hash = '#/fahrzeug/' + encodeURIComponent(id); }).catch(fehlerSeite);
        } });

        seite('Übergabe', [krume, h('h1', { text: 'Übergabe: ' + w.bezeichnung }),
          h('p', null, (GRUND_WORT[abg.grund] || 'Abgegeben') + ' am ', h('strong', { text: MM.Hilfen.datum(abg.datum) }), '.'),
          h('section', { class: 'block' },
            h('h2', { text: 'Technik-Akte als PDF' }),
            h('p', { text: 'Zum Ausdrucken, zum Beispiel für den Kaufvertrag. Sie zeigt die technische Historie von der letzten HU bis zur Abgabe, höchstens 24 Monate: letzte HU, Zählerstände, erledigte und offene Fristen, Störungen und Arbeiten, Hauptkomponenten.' }),
            h('p', { class: 'hinweis', text: ZEITRAUM_TEXT[akte.zeitraum.art](akte.zeitraum) }),
            akte.huUeberfaellig ? h('p', { class: 'fehlerkasten', text: 'Die HU ist überfällig. Das steht deutlich im PDF.' }) : null,
            pdfBox),
          h('section', { class: 'block' },
            h('h2', { text: 'Übergabedatei für den neuen Besitzer' }),
            h('p', { text: 'Der neue Besitzer liest sie in seiner MobiMory ein und ist damit Besitzer mit der ganzen technischen Historie: Komponenten und Ausrüstung, Zähler und Zählerstände, Fristen und Prüfungen, Störungen und Arbeiten, Dokumente. Nicht dabei sind deine Aktivitäten, das Logbuch, Kosten, Reisekasse, Personen und Besatzung.' }),
            dateiBox),
          h('section', { class: 'block' },
            h('h2', { text: 'Ein Fehler?' }),
            h('p', { text: 'Das Fahrzeug lässt sich jederzeit wieder aktiv setzen. Nichts geht verloren.' }),
            h('p', null, wieder))
        ], zurueck);
        return null;
      });
    });
  }

  function seiteUebernehmen() {
    var behaelter = h('div');
    var zustand = { bytes: null };

    function zeigeWahl(fehlertext) {
      behaelter.textContent = '';
      var eingabe = h('input', { type: 'file', id: 'ub-datei', onchange: function () {
        var f = eingabe.files && eingabe.files[0];
        if (!f) return;
        f.arrayBuffer().then(function (buf) { zustand.bytes = new Uint8Array(buf); return versuchen(''); }).catch(function (e) { zeigeWahl('Die Datei konnte nicht gelesen werden: ' + (e && e.message ? e.message : '')); });
      } });
      behaelter.appendChild(h('div', { class: 'formular' },
        h('p', { text: 'Hast du ein Fahrzeug gekauft oder geschenkt bekommen und vom bisherigen Besitzer eine Übergabedatei erhalten? Lies sie hier ein. Du wirst Besitzer des Fahrzeugs, mit seiner technischen Historie.' }),
        h('div', { class: 'feld' }, h('label', { for: 'ub-datei', text: 'Übergabedatei auswählen' }), h('div', { class: 'eingabe' }, eingabe)),
        fehlertext ? h('p', { class: 'fehler', role: 'alert', text: fehlertext }) : null,
        h('p', { class: 'hinweis', text: 'Es wird noch nichts verändert. Zuerst siehst du, was in der Datei steht. Deine vorhandenen Fahrzeuge und Daten bleiben unberührt.' })));
    }

    function zeigeSchluessel(fehlertext) {
      behaelter.textContent = '';
      var pw = h('input', { type: 'password', id: 'ub-pw', autocomplete: 'current-password' });
      behaelter.appendChild(h('div', { class: 'formular' },
        h('p', { text: 'Diese Übergabedatei ist verschlüsselt. Gib das Schlüsselwort ein, das du vom bisherigen Besitzer bekommen hast.' }),
        h('div', { class: 'feld' }, h('label', { for: 'ub-pw', text: 'Schlüsselwort' }), h('div', { class: 'eingabe' }, pw)),
        fehlertext ? h('p', { class: 'fehler', role: 'alert', text: fehlertext }) : null,
        h('p', { class: 'knopfzeile' },
          h('button', { class: 'knopf', type: 'button', text: 'Öffnen', onclick: function () { versuchen(pw.value); } }),
          h('button', { class: 'knopf leise', type: 'button', text: 'Andere Datei', onclick: function () { zeigeWahl(); } }))));
    }

    function versuchen(wort) {
      return daten.uebergabeLesen(zustand.bytes, wort).then(function (g) { return zeigeVorschau(g); }).catch(function (err) {
        if (err && err.code === 'schluessel_noetig') return zeigeSchluessel();
        if (err && err.code === 'schluessel') return zeigeSchluessel(err.message);
        zeigeWahl(err && err.message ? err.message : 'Die Datei lässt sich nicht lesen.');
      });
    }

    function zeigeVorschau(g) {
      return daten.uebergabeVorschau(g).then(function (v) {
        behaelter.textContent = '';
        var fel = h('p', { class: 'fehler', role: 'alert' });
        var kennungDa = !v.schonUebernommen && v.kennungTreffer && v.kennungTreffer.length > 0;
        function uebernehmen(nochmal) {
          los.setAttribute('disabled', 'disabled'); fel.textContent = '';
          daten.uebergabeEinspielen(g, { nochmal: !!nochmal, trotzdem: kennungDa }).then(function (r) {
            if (!r.ok) { los.removeAttribute('disabled'); fel.textContent = r.fehler && r.fehler.allgemein ? r.fehler.allgemein : 'Das hat nicht geklappt.'; return; }
            meldung = 'Das Fahrzeug ist übernommen. Du bist jetzt Besitzer, mit der technischen Historie des bisherigen Besitzers.';
            global.location.hash = '#/fahrzeug/' + encodeURIComponent(r.id);
          }).catch(function (err) { los.removeAttribute('disabled'); fel.textContent = 'Das hat nicht geklappt: ' + (err && err.message ? err.message : '') + ' Es wurde nichts angelegt.'; });
        }
        var los = h('button', { class: kennungDa ? 'knopf gefahr' : 'knopf', type: 'button', text: v.schonUebernommen ? 'Trotzdem noch einmal übernehmen' : (kennungDa ? 'Trotzdem übernehmen' : 'Fahrzeug übernehmen'), onclick: function () { uebernehmen(!!v.schonUebernommen); } });
        if (v.artFehlt) los.setAttribute('disabled', 'disabled');
        var z = v.zahlen;
        behaelter.appendChild(h('div', { class: 'formular' },
          h('p', null, h('strong', { text: v.bezeichnung }), ' (' + v.artName + '), ' + (GRUND_WORT[v.grund] || 'abgegeben').toLowerCase() + ' am ' + MM.Hilfen.datum(v.abgabeDatum) + '.'),
          h('p', { class: 'hinweis', text: 'Datei erstellt am ' + MM.Hilfen.zeitpunkt(v.erstelltAm) + ' Uhr mit MobiMory ' + (v.app || '?') + '.' }),
          h('dl', { class: 'daten stapel' },
            h('dt', { text: 'Komponenten' }), h('dd', { text: String(z.komponenten) }),
            h('dt', { text: 'Zähler' }), h('dd', { text: String(z.zaehler) }),
            h('dt', { text: 'Fristen' }), h('dd', { text: String(z.fristen) }),
            h('dt', { text: 'Störungen und Arbeiten' }), h('dd', { text: String(z.vorgaenge) }),
            h('dt', { text: 'Dokumente' }), h('dd', { text: z.dokumente + (v.mitDateien ? ' (mit ' + v.dateien + (v.dateien === 1 ? ' Datei, ' : ' Dateien, ') + MM.Hilfen.groesse(v.dateiBytes) + ')' : ' (ohne Dateien)') })),
          v.schonUebernommen ? h('div', { class: 'fehlerkasten', text: 'Diese Übergabe hast du schon am ' + MM.Hilfen.zeitpunkt(v.schonUebernommen.am) + ' Uhr übernommen („' + v.schonUebernommen.bezeichnung + '“). Nochmal übernehmen legt ein zweites Fahrzeug an.' }) : null,
          kennungDa ? h('section', { class: 'block warn', role: 'alert' },
            h('p', null, h('strong', { text: 'Dieses Fahrzeug gibt es vielleicht schon.' })),
            h('p', { text: v.kennungText }),
            h('p', { class: 'hilfe', text: 'Es wurde noch nichts angelegt. Wenn du es trotzdem übernimmst, entsteht ein zweites Fahrzeug mit derselben Kennung. Meist ist es besser, das vorhandene Fahrzeug zu öffnen.' }),
            h('ul', null, v.kennungTreffer.map(function (t) { return h('li', null, h('a', { href: '#/fahrzeug/' + encodeURIComponent(t.id), text: '„' + t.name + '“ öffnen' })); }))) : null,
          v.artFehlt ? h('div', { class: 'fehlerkasten', text: 'Die Fahrzeugart „' + v.artName + '“ gibt es hier nicht. Lege sie unter „Fahrzeugarten verwalten“ an und lies die Datei danach noch einmal ein.' }) : null,
          !v.artFehlt && v.art && v.art.angepasst ? h('p', { class: 'hinweis', text: 'Die Fahrzeugart „' + v.artName + '“ gibt es hier nicht. Das Fahrzeug bekommt die nächste passende Art: „' + v.art.name + '“. Du kannst sie später ändern.' }) : null,
          h('p', { class: 'hinweis', text: 'Das Fahrzeug wird als neues Fahrzeug angelegt. Vorhandenes wird nicht verändert oder überschrieben.' }),
          fel, h('p', null, los),
          h('p', null, h('button', { class: 'knopf leise', type: 'button', text: 'Andere Datei', onclick: function () { zeigeWahl(); } }))));
      });
    }

    zeigeWahl();
    seite('Fahrzeug übernehmen', [
      krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen', '#/einstellungen'], ['Fahrzeug übernehmen']]),
      h('h1', { text: 'Fahrzeug übernehmen' }), behaelter
    ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/fahrzeuge', text: 'Zurück' })));
    return Promise.resolve();
  }

  /* ---------- Import und Export (seit 2.0.30) ---------- */
  function austauschBlock() {
    return h('section', { class: 'block' },
      h('h2', { text: 'Import und Export' }),
      h('p', { text: 'Fahrzeugdaten aus einer Excel- oder CSV-Tabelle übernehmen, damit du sie nicht von Hand eintippen musst. Oder deine Daten als Excel- oder CSV-Datei ausgeben, zum Beispiel zum Auswerten.' }),
      h('p', { class: 'knopfzeile' },
        h('a', { class: 'knopf', href: '#/einstellungen/import', text: 'Aus Excel oder CSV übernehmen' }),
        h('a', { class: 'knopf leise', href: '#/einstellungen/export', text: 'Als Excel oder CSV ausgeben' })),
      h('p', { text: 'Ein Fahrzeug von einem früheren Besitzer bekommen? Lies seine Übergabedatei ein.' }),
      h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf leise', href: '#/einstellungen/uebernehmen', text: 'Fahrzeug aus Übergabedatei übernehmen' })));
  }

  function zellText(z) { return z === null || z === undefined ? '' : String(z); }
  function kurz(s, n) { s = zellText(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; }
  var IMPORT_STATUS = { neu: ['Neu', 'status-ok'], vorhanden: ['Gibt es schon', 'status-bald'], doppelt: ['Doppelt in der Tabelle', 'status-bald'], fehler: ['Fehler', 'status-ueberfaellig'] };

  function seiteImport() {
    var behaelter = h('div');
    var z = { blaetter: null, blatt: 0, hatKopf: true, artId: '', zuordnung: [] };

    function zeilenAlle() { return z.blaetter[z.blatt].zeilen; }
    function zeilenDaten() { return z.hatKopf ? zeilenAlle().slice(1) : zeilenAlle(); }
    function spaltenZahl() { var n = 0; zeilenAlle().forEach(function (r) { n = Math.max(n, r.length); }); return n; }
    function kopfzeile() { var k = [], i, r = zeilenAlle()[0] || []; for (i = 0; i < spaltenZahl(); i++) k.push(z.hatKopf ? zellText(r[i]) : ''); return k; }
    function kopfText(i) { var t = z.hatKopf ? zellText((zeilenAlle()[0] || [])[i]).trim() : ''; return t || ('Spalte ' + MM.Austausch.spalteName(i)); }
    function beispiele(i) {
      var res = [], rows = zeilenDaten(), j;
      for (j = 0; j < rows.length && res.length < 2; j++) { var t = zellText(rows[j][i]).trim(); if (t) res.push(kurz(t, 24)); }
      return res.join(' · ');
    }
    function opt() { return { zeilen: zeilenDaten(), zuordnung: z.zuordnung, artId: z.artId, ersteNr: 1 }; }

    /* Rät die Zuordnung neu. Was der Nutzer schon gewählt hat und noch passt, bleibt. */
    function anpassen(behalten) {
      var ziele = daten.importZielfelder(z.artId || null), erlaubt = {}, n = spaltenZahl(), i, neu = [];
      ziele.forEach(function (f) { erlaubt[f.key] = true; });
      var benutzt = {};
      for (i = 0; i < n; i++) { var alt = behalten ? z.zuordnung[i] : ''; if (alt && erlaubt[alt] && !benutzt[alt]) { neu[i] = alt; benutzt[alt] = true; } else neu[i] = ''; }
      if (z.hatKopf) {
        var frei = ziele.filter(function (f) { return !benutzt[f.key]; }), vorschlag = MM.Austausch.spaltenRaten(kopfzeile(), frei);
        for (i = 0; i < n; i++) { if (!neu[i] && vorschlag[i]) neu[i] = vorschlag[i]; }
      }
      z.zuordnung = neu;
    }

    function zeigeWahl(fehlertext) {
      behaelter.textContent = '';
      var eingabe = h('input', { type: 'file', id: 'im-datei', accept: '.xlsx,.csv,.txt,.tsv,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', onchange: function () {
        var f = eingabe.files && eingabe.files[0];
        if (!f) return;
        if (f.size > 25 * 1024 * 1024) { zeigeWahl('Die Datei ist zu groß (über 25 MB). Bitte in kleinere Dateien teilen.'); return; }
        f.arrayBuffer().then(function (buf) { return MM.Austausch.dateiLesen(new Uint8Array(buf)); }).then(function (r) {
          z.blaetter = r.blaetter; z.blatt = 0; z.hatKopf = true; z.artId = ''; z.zuordnung = [];
          anpassen(false);
          zeigeZuordnung();
        }).catch(function (e) { zeigeWahl(e && e.message ? e.message : 'Die Datei konnte nicht gelesen werden.'); });
      } });
      behaelter.appendChild(h('div', { class: 'formular' },
        h('p', { text: 'Hast du deine Fahrzeugdaten schon in einer Excel- oder CSV-Tabelle? Dann übernimm sie hier. Jede Zeile der Tabelle wird ein Fahrzeug.' }),
        h('div', { class: 'feld' }, h('label', { for: 'im-datei', text: 'Datei auswählen (Excel .xlsx oder CSV)' }), h('div', { class: 'eingabe' }, eingabe)),
        fehlertext ? h('p', { class: 'fehler', role: 'alert', text: fehlertext }) : null,
        h('p', { class: 'hinweis', text: 'Es wird noch nichts übernommen. Zuerst ordnest du die Spalten zu und siehst eine Vorschau. Vorhandene Fahrzeuge werden nie überschrieben.' })));
    }

    function zeigeZuordnung(fehlertext) {
      behaelter.textContent = '';
      var ziele = daten.importZielfelder(z.artId || null), n = spaltenZahl(), teile = [];
      if (z.blaetter.length > 1) {
        var bsel = h('select', { id: 'im-blatt', onchange: function () { z.blatt = parseInt(bsel.value, 10); anpassen(false); zeigeZuordnung(); } },
          z.blaetter.map(function (b, i) { return h('option', { value: String(i), text: b.name }); }));
        bsel.value = String(z.blatt);
        teile.push(h('div', { class: 'feld' }, h('label', { for: 'im-blatt', text: 'Blatt der Excel-Datei' }), h('div', { class: 'eingabe' }, bsel)));
      }
      var kopfCb = h('input', { type: 'checkbox', id: 'im-kopf', checked: z.hatKopf ? 'checked' : null, onchange: function () { z.hatKopf = kopfCb.checked; anpassen(false); zeigeZuordnung(); } });
      teile.push(h('div', { class: 'feld' }, h('label', { class: 'checkzeile' }, kopfCb, h('span', { text: 'Die erste Zeile enthält die Überschriften' }))));
      var arten = MM.Fahrzeugarten.alle(false);
      var asel = h('select', { id: 'im-art', onchange: function () { z.artId = asel.value; anpassen(true); zeigeZuordnung(); } },
        [h('option', { value: '', text: '– steht in einer Spalte der Tabelle –' })].concat(arten.map(function (a) { return h('option', { value: a.id, text: a.name }); })));
      asel.value = z.artId;
      teile.push(h('div', { class: 'feld' }, h('label', { for: 'im-art', text: 'Fahrzeugart für alle Zeilen' }), h('div', { class: 'eingabe' }, asel),
        h('p', { class: 'hilfe', text: 'Sind in der Tabelle verschiedene Fahrzeugarten, wähle „steht in einer Spalte“ und ordne die Spalte „Fahrzeugart“ zu.' })));

      var zeilenHtml = [];
      for (var i = 0; i < n; i++) {
        (function (i) {
          var sel = h('select', { id: 'im-sp' + i, 'aria-label': 'Wohin kommt ' + kopfText(i) + '?', onchange: function () {
            var wahl = sel.value;
            if (wahl) { for (var j = 0; j < z.zuordnung.length; j++) { if (j !== i && z.zuordnung[j] === wahl) z.zuordnung[j] = ''; } }
            z.zuordnung[i] = wahl;
            zeigeZuordnung();
          } }, [h('option', { value: '', text: '– nicht übernehmen –' })].concat(ziele.map(function (f) { return h('option', { value: f.key, text: f.label }); })));
          sel.value = z.zuordnung[i] || '';
          zeilenHtml.push(h('div', { class: 'feld' },
            h('label', { for: 'im-sp' + i, text: kopfText(i) }),
            beispiele(i) ? h('p', { class: 'hilfe', text: 'z. B. ' + beispiele(i) }) : null,
            h('div', { class: 'eingabe' }, sel)));
        })(i);
      }
      teile.push(h('h2', { text: 'Welche Spalte gehört wohin?' }),
        h('p', { class: 'hilfe', text: 'Die App hat die Spalten nach ihren Überschriften zugeordnet. Prüfe es und ändere, was nicht stimmt. Spalten, die du nicht brauchst, lässt du auf „nicht übernehmen“.' }),
        zeilenHtml);
      var mitArt = z.artId || z.zuordnung.indexOf('__art') >= 0;
      var weiter = h('button', { class: 'knopf', type: 'button', text: 'Weiter zur Vorschau', onclick: function () {
        weiter.disabled = true;
        daten.importVorschau(opt()).then(function (v) {
          if (!v.ok) { weiter.disabled = false; zeigeZuordnung(v.fehler); return; }
          zeigeVorschau(v);
        }).catch(function (e) { weiter.disabled = false; zeigeZuordnung(e && e.message ? e.message : 'Das hat nicht geklappt.'); });
      } });
      behaelter.appendChild(h('div', { class: 'formular' },
        h('p', null, h('strong', { text: zeilenDaten().length + (zeilenDaten().length === 1 ? ' Zeile' : ' Zeilen') }), ' mit Daten in der Tabelle.'),
        teile,
        mitArt ? null : h('p', { class: 'hinweis', text: 'Bitte oben die Fahrzeugart wählen oder eine Spalte der Fahrzeugart zuordnen.' }),
        fehlertext ? h('p', { class: 'fehler', role: 'alert', text: fehlertext }) : null,
        h('p', { class: 'knopfzeile' }, weiter, h('button', { class: 'knopf leise', type: 'button', text: 'Andere Datei', onclick: function () { zeigeWahl(); } }))));
    }

    function zeigeVorschau(v) {
      behaelter.textContent = '';
      var c = v.zaehlung, MAX_ZEIGEN = 200;
      var zeilen = v.zeilen.slice(0, MAX_ZEIGEN).map(function (x) {
        var st = IMPORT_STATUS[x.status];
        return h('tr', null,
          h('td', { text: String(x.nr) }),
          h('td', null, h('span', { class: 'chip-status ' + st[1], text: st[0] })),
          h('td', null, h('strong', { text: x.bezeichnung || '–' }), x.artName ? h('div', { class: 'hilfe', text: x.artName + (x.kennung ? ', ' + x.kennung : '') }) : null,
            x.fehlerListe.length ? h('ul', { class: 'fehler' }, x.fehlerListe.map(function (t) { return h('li', { text: t }); })) : null));
      });
      var los = h('button', { class: 'knopf', type: 'button', text: c.neu === 1 ? '1 Fahrzeug übernehmen' : c.neu + ' Fahrzeuge übernehmen', disabled: c.neu ? null : 'disabled' });
      var fel = h('p', { class: 'fehler', role: 'alert' });
      los.addEventListener('click', function () {
        los.setAttribute('disabled', 'disabled'); fel.textContent = '';
        daten.importFahrzeuge(opt()).then(function (r) {
          if (!r.ok) { los.removeAttribute('disabled'); fel.textContent = r.fehler; return; }
          zeigeErgebnis(r);
        }).catch(function (e) { los.removeAttribute('disabled'); fel.textContent = 'Das hat nicht geklappt: ' + (e && e.message ? e.message : '') + ' Es wurde nichts verändert.'; });
      });
      behaelter.appendChild(h('div', { class: 'formular' },
        h('h2', { text: 'Vorschau' }),
        h('ul', { class: 'status-zeilen' },
          h('li', { class: 'status-ok', text: c.neu === 1 ? '1 neues Fahrzeug wird übernommen.' : c.neu + ' neue Fahrzeuge werden übernommen.' }),
          c.vorhanden ? h('li', { class: 'status-bald', text: c.vorhanden + ' gibt es schon (gleiches Kennzeichen, gleiche Nummer oder gleiche Bezeichnung). Sie werden übersprungen und nicht verändert.' }) : null,
          c.doppelt ? h('li', { class: 'status-bald', text: c.doppelt + (c.doppelt === 1 ? ' Zeile steht' : ' Zeilen stehen') + ' in der Tabelle doppelt. Nur die erste wird übernommen.' }) : null,
          c.fehler ? h('li', { class: 'status-ueberfaellig', text: c.fehler + (c.fehler === 1 ? ' Zeile hat' : ' Zeilen haben') + ' einen Fehler und werden nicht übernommen. Berichtige sie in der Tabelle und übernimm sie später noch einmal.' }) : null),
        v.nichtVerwendet.length ? h('p', { class: 'hinweis', text: 'Nicht übernommen, weil es zur Fahrzeugart nicht passt: ' + v.nichtVerwendet.join(', ') + '.' }) : null,
        h('div', { class: 'tabelle-rollen' }, h('table', { class: 'import-tabelle' },
          h('thead', null, h('tr', null, h('th', { text: 'Nr.' }), h('th', { text: 'Ergebnis' }), h('th', { text: 'Fahrzeug' }))),
          h('tbody', null, zeilen))),
        v.zeilen.length > MAX_ZEIGEN ? h('p', { class: 'hinweis', text: 'Gezeigt werden die ersten ' + MAX_ZEIGEN + ' Zeilen. Übernommen werden alle neuen.' }) : null,
        fel,
        h('p', { class: 'knopfzeile' }, los, h('button', { class: 'knopf leise', type: 'button', text: 'Zurück zur Zuordnung', onclick: function () { zeigeZuordnung(); } }))));
    }

    function zeigeErgebnis(r) {
      behaelter.textContent = '';
      behaelter.appendChild(h('section', { class: 'block' },
        h('h2', { text: r.anzahl === 1 ? '1 Fahrzeug übernommen' : r.anzahl + ' Fahrzeuge übernommen' }),
        r.vorhanden || r.doppelt || r.fehler ? h('p', { text: 'Übersprungen: ' + [r.vorhanden ? r.vorhanden + ' schon vorhanden' : null, r.doppelt ? r.doppelt + ' doppelt in der Tabelle' : null, r.fehler ? r.fehler + ' mit Fehler' : null].filter(Boolean).join(', ') + '.' }) : null,
        h('p', { text: 'Die Fahrzeuge stehen jetzt in deiner Fahrzeugliste. Weitere Angaben, Komponenten und Fristen trägst du dort nach.' }),
        h('p', { class: 'hinweis', text: 'Mache am besten jetzt eine Sicherung, damit die Daten nicht verloren gehen.' }),
        h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf', href: '#/fahrzeuge', text: 'Zu meinen Fahrzeugen' }), h('a', { class: 'knopf leise', href: '#/einstellungen/sichern', text: 'Sicherung erstellen' }))));
    }

    zeigeWahl();
    seite('Aus Excel oder CSV übernehmen', [
      krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen', '#/einstellungen'], ['Aus Excel oder CSV übernehmen']]),
      h('h1', { text: 'Fahrzeuge aus Excel oder CSV übernehmen' }), behaelter
    ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/einstellungen', text: 'Zurück' })));
    return Promise.resolve();
  }

  function seiteExport() {
    var behaelter = h('div');
    var auswahl = daten.exportAuswahl(), format = 'xlsx';

    function zeigeWahl(fehlertext) {
      behaelter.textContent = '';
      var boxen = auswahl.map(function (t) { return h('input', { type: 'checkbox', id: 'ex-' + t.wert, value: t.wert, checked: 'checked' }); });
      var fel = h('p', { class: 'fehler', role: 'alert', text: fehlertext || '' });
      var status = h('p', { class: 'hinweis', role: 'status' });
      var xl = h('input', { type: 'radio', name: 'ex-format', id: 'ex-xlsx', value: 'xlsx', checked: format === 'xlsx' ? 'checked' : null });
      var cs = h('input', { type: 'radio', name: 'ex-format', id: 'ex-csv', value: 'csv', checked: format === 'csv' ? 'checked' : null });
      var los = h('button', { class: 'knopf', type: 'button', text: 'Datei erstellen', onclick: function () {
        fel.textContent = '';
        var was = boxen.filter(function (b) { return b.checked; }).map(function (b) { return b.value; });
        format = cs.checked ? 'csv' : 'xlsx';
        los.disabled = true; status.textContent = 'Die Datei wird erstellt …';
        daten.exportDatei(was, format).then(function (r) {
          status.textContent = '';
          if (!r.ok) { los.disabled = false; fel.textContent = r.fehler; return; }
          zeigeErgebnis(r);
        }).catch(function (e) { los.disabled = false; status.textContent = ''; fel.textContent = 'Das hat nicht geklappt: ' + (e && e.message ? e.message : 'unbekannter Fehler') + '.'; });
      } });
      behaelter.appendChild(h('div', { class: 'formular' },
        h('p', { text: 'Gib deine Daten als Tabelle aus, zum Beispiel zum Auswerten in Excel.' }),
        h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
          h('legend', { class: 'fest-art', text: 'Was soll in die Datei?' }),
          auswahl.map(function (t, i) { return h('label', { class: 'checkzeile', for: 'ex-' + t.wert }, boxen[i], h('span', { text: t.label })); })),
        h('fieldset', { class: 'feld', style: 'border:0;padding:0;margin:0' },
          h('legend', { class: 'fest-art', text: 'Format' }),
          h('label', { class: 'checkzeile', for: 'ex-xlsx' }, xl, h('span', { text: 'Excel (.xlsx), mit einem Blatt je Tabelle' })),
          h('label', { class: 'checkzeile', for: 'ex-csv' }, cs, h('span', { text: 'CSV (.csv), nur eine Tabelle' }))),
        h('p', { class: 'hinweis', text: 'Das ist keine Sicherung. Zum Sichern aller Daten nimm die Sicherungsdatei unter Einstellungen. Die Tabelle ist nicht verschlüsselt. Gib sie nur weiter, wenn du es willst.' }),
        fel, status, h('p', null, los)));
    }

    function zeigeErgebnis(r) {
      behaelter.textContent = '';
      var teilen = null;
      try {
        var f = new global.File([r.bytes], r.name, { type: r.mime });
        if (global.navigator.canShare && global.navigator.canShare({ files: [f] })) {
          teilen = h('button', { class: 'knopf leise', type: 'button', text: 'Teilen oder in die Cloud legen', onclick: function () { global.navigator.share({ files: [f], title: r.name }).catch(function () {}); } });
        }
      } catch (e) { teilen = null; }
      behaelter.appendChild(h('section', { class: 'block' },
        h('h2', { text: 'Die Datei ist fertig' }),
        h('dl', { class: 'daten stapel' },
          h('dt', { text: 'Datei' }), h('dd', { text: r.name }),
          h('dt', { text: 'Größe' }), h('dd', { text: MM.Hilfen.groesse(r.groesse) }),
          h('dt', { text: 'Enthält' }), h('dd', { text: r.tabellen.map(function (t) { return t.name + ': ' + t.anzahl + (t.anzahl === 1 ? ' Zeile' : ' Zeilen'); }).join('; ') })),
        h('p', { class: 'knopfzeile' },
          h('button', { class: 'knopf', type: 'button', text: 'Auf dem Gerät speichern', onclick: function () { dateiSpeichern(r.bytes, r.name, r.mime); } }), teilen),
        h('p', { class: 'hinweis', text: 'Die Tabelle ist nicht verschlüsselt und keine Sicherung.' }),
        h('p', null, h('a', { class: 'knopf leise', href: '#/einstellungen', text: 'Fertig' }))));
    }

    zeigeWahl();
    seite('Als Excel oder CSV ausgeben', [
      krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen', '#/einstellungen'], ['Als Excel oder CSV ausgeben']]),
      h('h1', { text: 'Daten als Excel oder CSV ausgeben' }), behaelter
    ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/einstellungen', text: 'Zurück' })));
    return Promise.resolve();
  }

  function seiteEinstellungen() {
    return Promise.all([daten.dateienBelegung(), schaetzung(), daten.scansBelegung(), daten.sicherungInfo()]).then(function (r) {
      var dat = r[0], sp = r[1], scans = r[2], sicherung = r[3];
      var speicherZeilen = [
        h('p', { text: 'Dokumente auf diesem Gerät: ' + (dat.anzahl === 1 ? '1 Datei' : dat.anzahl + ' Dateien') + (dat.anzahl ? ', zusammen ' + MM.Hilfen.groesse(dat.bytes) : '') + '.' })
      ];
      speicherZeilen.push(h('p', { text: 'Scans und Fotos von Nachweisen: ' + (scans.anzahl === 1 ? '1 Datei' : scans.anzahl + ' Dateien') + (scans.anzahl ? ', zusammen ' + MM.Hilfen.groesse(scans.bytes) : '') + '. Sie bleiben immer nur auf diesem Gerät.' }));
      if (sp && sp.quota) {
        speicherZeilen.push(h('p', { text: 'Der Browser erlaubt MobiMory auf diesem Gerät insgesamt etwa ' + MM.Hilfen.groesse(sp.quota) + '. Davon sind etwa ' + MM.Hilfen.groesse(sp.usage) + ' belegt.' }));
        if (sp.dauerhaft !== null) speicherZeilen.push(h('p', { class: 'hinweis', text: sp.dauerhaft ? 'Der Browser löscht diese Daten nicht von selbst.' : 'Der Browser darf diese Daten bei Platzmangel löschen. Mit „Zum Startbildschirm hinzufügen“ ist das unwahrscheinlicher.' }));
      } else {
        speicherZeilen.push(h('p', { class: 'hinweis', text: 'Dieser Browser nennt keine Angabe zum freien Platz.' }));
      }
      seite('Einstellungen', [
        krumen([['Hauptmenü', '#/auswahl'], ['Einstellungen']]),
        h('h1', { text: 'Einstellungen' }),
        h('section', { class: 'block' },
          h('h2', { text: 'Deine Daten' }),
          h('p', { text: 'Deine Daten liegen nur auf diesem Gerät. Eine automatische Sicherung gibt es noch nicht. Mit der Sicherungsdatei schützt du dich davor, dass bei einem Geräteschaden alles weg ist.' })),
        sicherungBlock(sicherung),
        austauschBlock(),
        wetterKartenBlock(),
        h('section', { class: 'block' }, h('h2', { text: 'Speicher auf diesem Gerät' }), speicherZeilen),
        h('section', { class: 'block' },
          h('h2', { text: 'Über MobiMory' }),
          h('p', { text: 'Version ' + MM.VERSION + ' (' + MM.STUFE + ')' }),
          h('p', { text: MM.Texte.COPYRIGHT }),
          h('p', { class: 'hinweis', text: 'MobiMory ist eine Hilfestellung und trifft keine rechtliche Aussage. Die letzte Verantwortung hat der verantwortliche Skipper bzw. Fahrer.' })),
        h('details', { class: 'block test' },
          h('summary', { text: 'Nur für Tests' }),
          h('p', { text: 'Löscht alle Fahrzeuge und Dokumente auf diesem Gerät. Das lässt sich nicht rückgängig machen.' }),
          h('button', { class: 'knopf gefahr', type: 'button', text: 'Alle Daten auf diesem Gerät löschen',
            onclick: function () {
              if (global.confirm('Wirklich alle Daten auf diesem Gerät löschen?')) {
                daten.allesLoeschen().then(function () { return global.caches && global.caches.delete ? global.caches.delete(MM.Kartenablage.CACHE_NAME).catch(function () { return false; }) : false; }).then(function () { meldung = 'Alle Daten auf diesem Gerät wurden gelöscht.'; return zeige(); }).catch(fehlerSeite);
              }
            } }))
      ], h('div', { class: 'leiste' }, h('a', { class: 'knopf leise', href: '#/auswahl', text: 'Zurück' })));
    });
  }

  function fehlerSeite(err) {
    wurzel.textContent = '';
    wurzel.appendChild(kopf());
    wurzel.appendChild(h('main', { class: 'fehlerseite' },
      h('h1', { text: 'Das hat nicht geklappt' }),
      h('p', { text: (err && err.message) ? err.message : 'Es ist ein unbekannter Fehler aufgetreten.' }),
      h('p', null, h('a', { class: 'knopf', href: '#/auswahl', text: 'Zum Hauptmenü' }))));
  }

  /* ---------- Weiterleitung nach der Adresse ---------- */
  /*
   * Seiten werden immer der Reihe nach aufgebaut und lesen dabei die aktuelle Adresse.
   * So kann eine langsamere ältere Seite nie eine neuere überschreiben, wenn schnell
   * hintereinander getippt wird.
   */
  var aufbauKette = Promise.resolve();
  function zeige() {
    var aufgabe = aufbauKette.then(function () { return zeigeJetzt(); });
    aufbauKette = aufgabe.catch(function () {});
    return aufgabe;
  }

  function zeigeJetzt() {
    if (frageTimer) { global.clearTimeout(frageTimer); frageTimer = null; }
    if (wetterTimer) { global.clearTimeout(wetterTimer); wetterTimer = null; }
    if (fahrtTimer) { global.clearTimeout(fahrtTimer); fahrtTimer = null; }
    if (aktuelleKarte) { aktuelleKarte.zerstoeren(); aktuelleKarte = null; }
    gpsHorcher = null;
    gpsGebraucht = false;
    gpsSpurSichern(true);
    gpsWegSichern(true);
    fahrtSichern(true);
    var hash = (global.location.hash || '#/').replace(/^#/, '').split('?')[0];
    var teile = hash.split('/').filter(Boolean);
    var p;
    if (teile.length === 0) p = seiteStart();
    else if (teile[0] === 'auswahl') p = seiteHauptmenue();
    else if (teile[0] === 'stammdaten') p = seiteStammdaten();
    else if (teile[0] === 'fahrzeuge') p = seiteListe();
    else if (teile[0] === 'neu-im-programm') p = seiteNeuerungen();
    else if (teile[0] === 'einstellungen' && teile[1] === 'sichern') p = seiteSichern();
    else if (teile[0] === 'einstellungen' && teile[1] === 'wiederherstellen') p = seiteWiederherstellen();
    else if (teile[0] === 'einstellungen' && teile[1] === 'uebernehmen') p = seiteUebernehmen();
    else if (teile[0] === 'einstellungen' && teile[1] === 'import') p = seiteImport();
    else if (teile[0] === 'einstellungen' && teile[1] === 'export') p = seiteExport();
    else if (teile[0] === 'einstellungen') p = seiteEinstellungen();
    else if (teile[0] === 'neu') p = seiteFormular('neu');
    else if (teile[0] === 'funktionen') p = seiteFunktionen();
    else if (teile[0] === 'kassenbuch') p = seiteKassenbuch();
    else if (teile[0] === 'reisecheck' && teile[1] === 'dienst') p = seiteReisecheckDienst();
    else if (teile[0] === 'reisecheck' && teile[1] && teile[2] === 'tag' && teile[3]) p = seiteReisecheckAktivitaet(decodeURIComponent(teile[1]), teile[4] ? decodeURIComponent(teile[4]) : null, decodeURIComponent(teile[3]));
    else if (teile[0] === 'reisecheck' && teile[1]) p = seiteReisecheckAktivitaet(decodeURIComponent(teile[1]), teile[2] ? decodeURIComponent(teile[2]) : null);
    else if (teile[0] === 'reisecheck') p = seiteReisecheck();
    else if (teile[0] === 'aktivitaeten') p = seiteAktivitaeten();
    else if (teile[0] === 'fahrzeugarten') p = seiteFahrzeugarten();
    else if (teile[0] === 'fahrzeugart' && teile[1] === 'neu') p = fahrzeugartFormular('neu', null, (/eltern=([^&]+)/.exec(global.location.hash) || [])[1] ? decodeURIComponent(/eltern=([^&]+)/.exec(global.location.hash)[1]) : '');
    else if (teile[0] === 'fahrzeugart' && teile[1] && teile[2] === 'aendern') p = fahrzeugartFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeugart' && teile[1]) p = seiteFahrzeugart(decodeURIComponent(teile[1]));
    else if (teile[0] === 'schnellknoepfe' && teile[1]) p = schnellknoepfeFormular(decodeURIComponent(teile[1]), (/aktivitaet=([^&]+)/.exec(global.location.hash) || [])[1] ? decodeURIComponent(/aktivitaet=([^&]+)/.exec(global.location.hash)[1]) : '');
    else if (teile[0] === 'logbuch' && teile[1] === 'start') p = logbuchStartFormular((/fahrzeug=([^&]+)/.exec(global.location.hash) || [])[1] ? decodeURIComponent(/fahrzeug=([^&]+)/.exec(global.location.hash)[1]) : '');
    else if (teile[0] === 'aktivitaet' && teile[1] === 'neu') p = aktivitaetFormular('neu', (/fahrzeug=([^&]+)/.exec(global.location.hash) || [])[1] ? decodeURIComponent(/fahrzeug=([^&]+)/.exec(global.location.hash)[1]) : '');
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'tag' && teile[3] === 'neu') p = abschnittFormular('neu', decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'cockpit' && teile[3] === 'wechsel') p = cockpitWechselSeite(decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'cockpit' && (teile[3] === 'ereignis' || teile[3] === 'notiz' || teile[3] === 'foto')) p = cockpitFormular(teile[3], decodeURIComponent(teile[1]));
    else if (teile[0] === 'motoren' && teile[1]) p = seiteMotoren(decodeURIComponent(teile[1]), hashParam('aktivitaet'));
    else if (teile[0] === 'motorfrage') p = motorFrageFormular(hashParam('fahrzeug'), hashParam('aktivitaet'));
    else if (teile[0] === 'lauf' && teile[1] && teile[2] === 'korrigieren') p = laufKorrigierenFormular(decodeURIComponent(teile[1]), hashParam('fahrzeug'), hashParam('aktivitaet'));
    else if (teile[0] === 'tagesabschnitt' && teile[1] && teile[2] === 'abschluss') p = abschlussFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'tagesabschnitt' && teile[1] && teile[2] === 'aendern') p = abschnittFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'tagesabschnitt' && teile[1] && teile[2] === 'ereignis' && teile[3] === 'neu') p = ereignisFormular('neu', decodeURIComponent(teile[1]));
    else if (teile[0] === 'tagesabschnitt' && teile[1] && teile[2] === 'nachtragen') p = ereignisFormular('nachtragen', decodeURIComponent(teile[1]));
    else if (teile[0] === 'tagesabschnitt' && teile[1]) p = seiteTagesabschnitt(decodeURIComponent(teile[1]));
    else if (teile[0] === 'ereignis' && teile[1] && teile[2] === 'aendern') p = ereignisFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'ereignis' && teile[1]) p = seiteEreignis(decodeURIComponent(teile[1]));
    else if (teile[0] === 'wechsel' && teile[1] && teile[2] === 'aendern') p = wechselFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'wechsel' && teile[1]) p = seiteWechsel(decodeURIComponent(teile[1]));
    else if (teile[0] === 'ereignisarten') p = seiteEreignisarten();
    else if (teile[0] === 'ereignisart' && teile[1] === 'neu') p = ereignisartFormular('neu');
    else if (teile[0] === 'ereignisart' && teile[1] && teile[2] === 'aendern') p = ereignisartFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'karte' && teile[3] === 'offline') p = seiteKarteOffline(decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'karte') p = seiteKarte(decodeURIComponent(teile[1]));
    else if (teile[0] === 'wetterrhythmus') p = wetterRhythmusFormular();
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'route') p = seiteRoute(decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'reisekasse') p = seiteReisekasse(decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'kasse' && teile[3] === 'neu') p = kasseBuchenFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'kassensturz') p = kassensturzFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'besuch' && teile[3] === 'neu') p = besuchFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'aendern') p = aktivitaetFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'stornieren') p = stornoFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'besatzung' && teile[3] === 'neu') p = besatzungFormular('neu', decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1] && teile[2] === 'verantwortung') p = verantwortungFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaet' && teile[1]) p = seiteAktivitaet(decodeURIComponent(teile[1]));
    else if (teile[0] === 'besatzung' && teile[1] && teile[2] === 'aendern') p = besatzungFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'aktivitaetsarten') p = seiteAktivitaetsarten();
    else if (teile[0] === 'aktivitaetsart' && teile[1] === 'neu') p = aktivitaetsartFormular('neu');
    else if (teile[0] === 'aktivitaetsart' && teile[1] && teile[2] === 'aendern') p = aktivitaetsartFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'orte' && teile[1] === 'suchen') p = seiteOrtSuche('neu');
    else if (teile[0] === 'orte' && teile[1] === 'neu') p = benanntFormular('ort', 'neu');
    else if (teile[0] === 'orte') p = seiteBenanntListe('ort');
    else if (teile[0] === 'ort' && teile[1] && teile[2] === 'pruefen') p = seiteOrtSuche('pruefen', decodeURIComponent(teile[1]));
    else if (teile[0] === 'ort' && teile[1] && teile[2] === 'aendern') p = benanntFormular('ort', 'aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'ort' && teile[1] && teile[2] === 'standort' && teile[3] === 'neu') p = standortFormular('neu', decodeURIComponent(teile[1]));
    else if (teile[0] === 'ort' && teile[1]) p = seiteBenannt('ort', decodeURIComponent(teile[1]));
    else if (teile[0] === 'standort' && teile[1] && teile[2] === 'aendern') p = standortFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'gebiete' && teile[1] === 'neu') p = benanntFormular('gebiet', 'neu');
    else if (teile[0] === 'gebiete') p = seiteBenanntListe('gebiet');
    else if (teile[0] === 'gebiet' && teile[1] && teile[2] === 'aendern') p = benanntFormular('gebiet', 'aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'gebiet' && teile[1] && teile[2] === 'regel' && teile[3] === 'neu') p = regelFormular('neu', decodeURIComponent(teile[1]));
    else if (teile[0] === 'ort' && teile[1] && teile[2] === 'regel' && teile[3] === 'neu') p = regelFormular('neu', decodeURIComponent(teile[1]), true);
    else if (teile[0] === 'gebiet' && teile[1]) p = seiteBenannt('gebiet', decodeURIComponent(teile[1]));
    else if (teile[0] === 'regel' && teile[1] && teile[2] === 'aendern') p = regelFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'heimatstandort') p = heimatstandortFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'grundcheck') p = seiteGrundcheck(decodeURIComponent(teile[1]), teile[3] ? decodeURIComponent(teile[3]) : null);
    else if (teile[0] === 'anforderung' && teile[1] && teile[2] === 'aendern') p = anforderungFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'anforderung' && teile[3] === 'neu') p = anforderungFormular('neu', decodeURIComponent(teile[1]));
    else if (teile[0] === 'personen' && teile[1] === 'neu') p = besitzerFormular('person', 'neu');
    else if (teile[0] === 'personen') p = seiteBesitzerListe('person');
    else if (teile[0] === 'person' && teile[1] && teile[2] === 'aendern') p = besitzerFormular('person', 'aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'person' && teile[1] && teile[2] === 'nachweis' && teile[3] === 'neu') p = nachweisFormular('neu', 'person', decodeURIComponent(teile[1]));
    else if (teile[0] === 'person' && teile[1]) p = seiteBesitzer('person', decodeURIComponent(teile[1]));
    else if (teile[0] === 'tiere' && teile[1] === 'neu') p = besitzerFormular('tier', 'neu');
    else if (teile[0] === 'tiere') p = seiteBesitzerListe('tier');
    else if (teile[0] === 'tier' && teile[1] && teile[2] === 'aendern') p = besitzerFormular('tier', 'aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'tier' && teile[1] && teile[2] === 'nachweis' && teile[3] === 'neu') p = nachweisFormular('neu', 'tier', decodeURIComponent(teile[1]));
    else if (teile[0] === 'tier' && teile[1]) p = seiteBesitzer('tier', decodeURIComponent(teile[1]));
    else if (teile[0] === 'nachweis' && teile[1] && teile[2] === 'aendern') p = nachweisFormular('aendern', null, decodeURIComponent(teile[1]));
    else if (teile[0] === 'nachweis' && teile[1]) p = seiteNachweis(decodeURIComponent(teile[1]));
    else if (teile[0] === 'nachweisarten' && teile[1] === 'vorschlaege') p = seiteVorschlaege();
    else if (teile[0] === 'nachweisarten') p = seiteNachweisarten();
    else if (teile[0] === 'nachweisart' && teile[1] === 'neu') p = nachweisartFormular('neu');
    else if (teile[0] === 'nachweisart' && teile[1] && teile[2] === 'aendern') p = nachweisartFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'nachweisart' && teile[1]) p = seiteNachweisart(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'nachweis' && teile[3] === 'neu') p = nachweisFormular('neu', 'fahrzeug', decodeURIComponent(teile[1]));
    else if (teile[0] === 'vorgang' && teile[1] && teile[2] === 'dokument' && teile[3] === 'neu') p = dokumentFormular('neu-vorg', decodeURIComponent(teile[1]));
    else if (teile[0] === 'dokument' && teile[1] && teile[2] === 'aendern') p = dokumentFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'dokument' && teile[1]) p = seiteDokument(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'dokumente') p = seiteDokumente(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'dokument' && teile[3] === 'neu') p = dokumentFormular('neu-fz', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'dokument' && teile[3] === 'neu') p = dokumentFormular('neu-komp', decodeURIComponent(teile[1]));
    else if (teile[0] === 'adressen' && teile[1] === 'neu') p = adresseFormular('neu');
    else if (teile[0] === 'adressen') p = seiteAdressen();
    else if (teile[0] === 'adresse' && teile[1] && teile[2] === 'aendern') p = adresseFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'adresse' && teile[1]) p = seiteAdresse(decodeURIComponent(teile[1]));
    else if (teile[0] === 'besuch' && teile[1] && teile[2] === 'aendern') p = besuchAendernFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'besuch' && teile[1]) p = seiteBesuch(decodeURIComponent(teile[1]));
    else if (teile[0] === 'kosten' && teile[1] === 'listen' && teile[2] === 'art' && teile[3] === 'neu') p = kostenartNeuFormular();
    else if (teile[0] === 'kosten' && teile[1] === 'listen' && teile[2] === 'zahlung' && teile[3] === 'neu') p = zahlungsmittelNeuFormular();
    else if (teile[0] === 'kosten' && teile[1] === 'listen') p = seiteKostenListen();
    else if (teile[0] === 'kosten' && teile[1] && teile[2] === 'dokument' && teile[3] === 'neu') p = dokumentFormular('neu-kosten', decodeURIComponent(teile[1]));
    else if (teile[0] === 'kosten' && teile[1] && teile[2] === 'aendern') p = kostenFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'kosten' && teile[1]) p = seitePosten(decodeURIComponent(teile[1]));
    else if (teile[0] === 'kosten') p = seiteKostenUebersicht();
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'kosten' && teile[3] === 'neu') p = kostenFormular('neu', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'kosten') p = seiteKostenFahrzeug(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'kostenstamm') p = kostenstammFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'werkstatt') p = seiteWerkstattUebersicht();
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'werkstatt') p = seiteWerkstatt(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'stoerung' && teile[3] === 'neu') p = vorgangFormular('stoerung', 'fz', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'arbeit' && teile[3] === 'neu') p = vorgangFormular('arbeit', 'fz', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'stoerung' && teile[3] === 'neu') p = vorgangFormular('stoerung', 'komp', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'arbeit' && teile[3] === 'neu') p = vorgangFormular('arbeit', 'komp', decodeURIComponent(teile[1]));
    else if (teile[0] === 'vorgang' && teile[1] && teile[2] === 'aendern') p = vorgangFormular(null, 'aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'vorgang' && teile[1] && teile[2] === 'arbeit') p = vorgangZuArbeitFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'vorgang' && teile[1] && teile[2] === 'erledigt') p = vorgangErledigtFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'vorgang' && teile[1]) p = seiteVorgang(decodeURIComponent(teile[1]));
    else if (teile[0] === 'frist' && teile[1] && teile[2] === 'aendern') p = fristFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'frist' && teile[1] && teile[2] === 'erledigt') p = erledigtFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'frist' && teile[1]) p = seiteFrist(decodeURIComponent(teile[1]));
    else if (teile[0] === 'zaehler' && teile[1] && teile[2] === 'stand') p = standFormular(decodeURIComponent(teile[1]));
    else if (teile[0] === 'zaehler' && teile[1] && teile[2] === 'aendern') p = zaehlerFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'zaehler' && teile[1]) p = seiteZaehler(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'frist' && teile[3] === 'neu') p = fristFormular('neu-fz', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'zaehler' && teile[3] === 'neu') p = zaehlerFormular('neu-fz', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'frist' && teile[3] === 'neu') p = fristFormular('neu-komp', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'zaehler' && teile[3] === 'neu') p = zaehlerFormular('neu-komp', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'neu') p = seiteKomponentenFormular('neu-teil', decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'aendern') p = seiteKomponentenFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'merkmale' && teile[1] === 'einheit' && teile[2] === 'neu') p = einheitNeuFormular();
    else if (teile[0] === 'merkmale' && teile[1] === 'neu') p = merkmalNeuFormular();
    else if (teile[0] === 'merkmale') p = seiteMerkmaleListen();
    else if (teile[0] === 'komponente' && teile[1] && teile[2] === 'verschieben') p = seiteKomponentenVerschieben(decodeURIComponent(teile[1]));
    else if (teile[0] === 'komponente' && teile[1]) p = seiteKomponente(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'komponente' && teile[3] === 'neu') p = seiteKomponentenFormular('neu-haupt', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'abgeben') p = seiteAbgeben(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'uebergabe') p = seiteUebergabe(decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1] && teile[2] === 'aendern') p = seiteFormular('aendern', decodeURIComponent(teile[1]));
    else if (teile[0] === 'fahrzeug' && teile[1]) p = seiteFahrzeug(decodeURIComponent(teile[1]));
    else p = seiteStart();
    return p.then(function (x) { if (!gpsGebraucht) gpsStoppen(); return x; }).catch(fehlerSeite);
  }

  function starten(d, el) {
    daten = d; wurzel = el;
    global.addEventListener('hashchange', zeige);
    return zeige();
  }

  MM.Ansicht = { starten: starten, fehler: function (el, err) { wurzel = el; fehlerSeite(err); } };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
