'use strict';
/* 2.0.27, Schritt 8: Kosten – Posten, Verweise, Kostenstammdaten, Auswertung, Speicher und Sicherung. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/daten.js');
const MM = globalThis.MM;

/* feste Uhr: 3. November 2026, 12:00 Ortszeit */
const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const motor = (await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor Backbord' })).id;
  const wmMotor = (await d.komponenteAnlegen(wm, null, 'motor', { bezeichnung: 'Motor' })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = n => arten.find(x => x.aktuell.werte.bezeichnung === n).objekt.id;
  return { d, boot, wm, anna, motor, wmMotor, artId };
}
const toern = (c, extra) => Object.assign({ bezeichnung: 'Sommertörn', artId: c.artId('Törn'), fahrzeugId: c.boot, vonDatum: '2026-07-01', bisDatum: '2026-07-10', verantwortlichId: c.anna }, extra || {});
const liegeplatz = { gruppe: 'fix', bezeichnung: 'Liegeplatz Heimathafen', kostenart: 'stellplatz', betrag: '2.400', rhythmus: 'jaehrlich', datum: '2026-01-01' };
const diesel = { gruppe: 'variabel', bezeichnung: 'Diesel', kostenart: 'treibstoff', betrag: '180,50', datum: '2026-07-05' };
const kerzen = { gruppe: 'instandhaltung', bezeichnung: 'Zündkerzen', kostenart: 'teile', betrag: '45', datum: '2026-09-01' };

/* ---------- Anlegen und Prüfen ---------- */
test('Posten anlegen: Gruppe, Name und Betrag sind Pflicht, bei Fehlern wird nichts gespeichert', async () => {
  const c = await neu();
  const f = async roh => (await c.d.kostenAnlegen(c.boot, roh)).fehler || {};
  assert.ok((await f({ bezeichnung: 'x', betrag: '5' })).gruppe, 'ohne Gruppe');
  assert.ok((await f({ gruppe: 'wunsch', bezeichnung: 'x', betrag: '5' })).gruppe, 'unbekannte Gruppe');
  assert.ok((await f({ gruppe: 'variabel', bezeichnung: ' ', betrag: '5' })).bezeichnung);
  assert.ok((await f({ gruppe: 'variabel', bezeichnung: 'x' })).betrag, 'Betrag fehlt');
  assert.ok((await f({ gruppe: 'variabel', bezeichnung: 'x', betrag: 'viel' })).betrag);
  assert.ok((await f({ gruppe: 'variabel', bezeichnung: 'x', betrag: '0' })).betrag, 'Betrag muss größer als 0 sein');
  assert.ok((await f({ gruppe: 'variabel', bezeichnung: 'x', betrag: '-5' })).betrag, 'kein negativer Betrag');
  assert.ok((await f({ gruppe: 'variabel', bezeichnung: 'x', betrag: '99999999' })).betrag);
  assert.ok((await f({ gruppe: 'variabel', bezeichnung: 'x', betrag: '5', kostenart: 'versicherung' })).kostenart, 'Kostenart muss zur Gruppe passen');
  assert.ok((await f({ gruppe: 'variabel', bezeichnung: 'x', betrag: '5', datum: '2026-13-40' })).datum);
  assert.ok((await c.d.kostenAnlegen('gibt-es-nicht', diesel)).fehler.allgemein);
  assert.equal((await c.d.kostenListe(c.boot)).length, 0);
});

test('Fixkosten: der Rhythmus muss gewählt werden, das Ende nicht vor dem Beginn, einmalig hat kein Ende', async () => {
  const c = await neu();
  assert.ok((await c.d.kostenAnlegen(c.boot, Object.assign({}, liegeplatz, { rhythmus: '' }))).fehler.rhythmus);
  assert.ok((await c.d.kostenAnlegen(c.boot, Object.assign({}, liegeplatz, { rhythmus: 'taeglich' }))).fehler.rhythmus);
  assert.ok((await c.d.kostenAnlegen(c.boot, Object.assign({}, liegeplatz, { bis: '2025-12-31' }))).fehler.bis);
  const r = await c.d.kostenAnlegen(c.boot, Object.assign({}, liegeplatz, { rhythmus: 'einmalig', bis: '2027-01-01' }));
  assert.equal(r.ok, true);
  const w = (await c.d.kostenLaden(r.id)).aktuell.werte;
  assert.equal(w.rhythmus, 'einmalig'); assert.equal(w.bis, null, 'bei einer Einmalzahlung gibt es kein Ende');
});

test('Variable Kosten und Instandhaltung sind immer einmalig, ein Rhythmus von außen wird ignoriert', async () => {
  const c = await neu();
  const id = (await c.d.kostenAnlegen(c.boot, Object.assign({}, diesel, { rhythmus: 'monatlich', bis: '2027-01-01' }))).id;
  const w = (await c.d.kostenLaden(id)).aktuell.werte;
  assert.equal(w.rhythmus, 'einmalig'); assert.equal(w.bis, null);
});

test('Posten anlegen: Komma als Dezimalzeichen, auf Cent gerundet, Datum ohne Angabe heute, Zukunft erlaubt, Grundlage ohne Angabe eingegeben', async () => {
  const c = await neu();
  const id = (await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'Diesel', betrag: '180,505' })).id;
  const w = (await c.d.kostenLaden(id)).aktuell.werte;
  assert.equal(w.betrag, 180.51);
  assert.equal(w.datum, '2026-11-03');
  assert.equal(w.grundlage, 'eingegeben');
  assert.equal(w.ausgeblendet, 'nein');
  assert.equal(w.kostenart, null);
  const spaeter = await c.d.kostenAnlegen(c.boot, { gruppe: 'instandhaltung', bezeichnung: 'Service nächstes Jahr', betrag: '600', datum: '2027-03-01', grundlage: 'geschaetzt' });
  assert.equal(spaeter.ok, true, 'geplante Kosten in der Zukunft sind möglich');
  assert.equal((await c.d.kostenLaden(spaeter.id)).aktuell.werte.grundlage, 'geschaetzt');
  assert.ok((await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'x', betrag: '5', grundlage: 'gerechnet' })).fehler.grundlage, 'gerechnet trägt der Nutzer nicht ein');
});

test('Geldbeträge: der Punkt als Tausenderpunkt ist kein Komma („2.400“ sind 2400 Euro, nicht 2,4)', async () => {
  const c = await neu();
  const betrag = async t => (await c.d.kostenLaden((await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'x', betrag: t })).id)).aktuell.werte.betrag;
  assert.equal(await betrag('2.400'), 2400);
  assert.equal(await betrag('1.234,50'), 1234.5);
  assert.equal(await betrag('1.234.567'), 1234567);
  assert.equal(await betrag('12,5'), 12.5);
  assert.equal(await betrag('12.5'), 12.5, 'ein Punkt vor ein bis zwei Stellen ist ein Dezimalpunkt');
  assert.equal(await betrag('0,99'), 0.99);
  assert.equal(await betrag('€ 45'), 45);
  assert.equal(await betrag(' 1 500 '), 1500);
  await c.d.kostenstammSetzen(c.boot, { fahrzeugwert: '48.500', vergleichPreisTag: '1.200' });
  const w = (await c.d.kostenstammLaden(c.boot)).aktuell.werte;
  assert.equal(w.fahrzeugwert, 48500); assert.equal(w.vergleichPreisTag, 1200);
});

/* ---------- Verweise ---------- */
test('Verweise: Komponente muss zum Fahrzeug gehören', async () => {
  const c = await neu();
  const ok = await c.d.kostenAnlegen(c.boot, Object.assign({}, kerzen, { komponenteId: c.motor }));
  assert.equal(ok.ok, true);
  assert.equal((await c.d.kostenListe(c.boot))[0].komponenteName, 'Motor Backbord');
  assert.ok((await c.d.kostenAnlegen(c.boot, Object.assign({}, kerzen, { komponenteId: c.wmMotor }))).fehler.komponenteId, 'Komponente eines anderen Fahrzeugs');
  assert.ok((await c.d.kostenAnlegen(c.boot, Object.assign({}, kerzen, { komponenteId: 'gibt-es-nicht' }))).fehler.komponenteId);
});

test('Verweise: eine Aktivität gibt es nur bei variablen Kosten und nur am eigenen Fahrzeug', async () => {
  const c = await neu();
  const akt = (await c.d.aktivitaetAnlegen(toern(c))).id;
  const ok = await c.d.kostenAnlegen(c.boot, Object.assign({}, diesel, { aktivitaetId: akt }));
  assert.equal(ok.ok, true);
  assert.equal((await c.d.kostenListe(c.boot))[0].aktivitaetName, 'Sommertörn');
  assert.ok((await c.d.kostenAnlegen(c.boot, Object.assign({}, kerzen, { aktivitaetId: akt }))).fehler.aktivitaetId, 'bei Instandhaltung nicht');
  assert.ok((await c.d.kostenAnlegen(c.boot, Object.assign({}, liegeplatz, { aktivitaetId: akt }))).fehler.aktivitaetId, 'bei Fixkosten nicht');
  assert.ok((await c.d.kostenAnlegen(c.wm, Object.assign({}, diesel, { aktivitaetId: akt }))).fehler.aktivitaetId, 'Aktivität eines anderen Fahrzeugs');
  assert.ok((await c.d.kostenAnlegen(c.boot, Object.assign({}, diesel, { aktivitaetId: 'gibt-es-nicht' }))).fehler.aktivitaetId);
});

test('Betrag am Vorgang: nur Instandhaltung, am eigenen Fahrzeug, die Komponente des Vorgangs wird übernommen', async () => {
  const c = await neu();
  const vg = (await c.d.vorgangAnlegen(c.boot, c.motor, 'arbeit', { bezeichnung: 'Ölwechsel', ausfuehrung: 'werkstatt' })).id;
  const r = await c.d.kostenAnlegen(c.boot, Object.assign({}, kerzen, { vorgangId: vg }));
  assert.equal(r.ok, true);
  const k = await c.d.kostenLaden(r.id);
  assert.equal(k.aktuell.werte.vorgangId, vg);
  assert.equal(k.aktuell.werte.komponenteId, c.motor, 'die Komponente des Vorgangs');
  assert.equal(k.vorgangName, 'Ölwechsel');
  const gewaehlt = await c.d.kostenAnlegen(c.boot, Object.assign({}, kerzen, { vorgangId: vg, komponenteId: c.motor }));
  assert.equal(gewaehlt.ok, true);
  assert.ok((await c.d.kostenAnlegen(c.boot, Object.assign({}, diesel, { vorgangId: vg }))).fehler.gruppe, 'variable Kosten gehören nicht an einen Vorgang');
  assert.ok((await c.d.kostenAnlegen(c.wm, Object.assign({}, kerzen, { vorgangId: vg }))).fehler.vorgangId, 'Vorgang eines anderen Fahrzeugs');
  assert.ok((await c.d.kostenAnlegen(c.boot, Object.assign({}, kerzen, { vorgangId: 'gibt-es-nicht' }))).fehler.vorgangId);
});

/* ---------- Ändern, Ausblenden, Verlauf ---------- */
test('Posten ändern: neuer Eintrag im Verlauf, der alte bleibt sichtbar, ohne Änderung nichts', async () => {
  const c = await neu();
  const id = (await c.d.kostenAnlegen(c.boot, liegeplatz)).id;
  assert.equal((await c.d.kostenAendern(id, liegeplatz)).geaendert, false);
  const r = await c.d.kostenAendern(id, Object.assign({}, liegeplatz, { betrag: '2.600' }));
  assert.equal(r.ok, true); assert.equal(r.geaendert, true);
  const k = await c.d.kostenLaden(id);
  assert.equal(k.aktuell.werte.betrag, 2600);
  assert.equal(k.verlauf.length, 2);
  assert.equal(k.verlauf[0].aenderungen.find(a => a.key === 'betrag').alt, 2400, 'der frühere Betrag bleibt im Verlauf sichtbar');
  assert.ok((await c.d.kostenAendern(id, Object.assign({}, liegeplatz, { betrag: '' }))).fehler.betrag);
  assert.ok((await c.d.kostenAendern('gibt-es-nicht', liegeplatz)).fehler.allgemein);
});

test('Posten ändern: die Gruppe bleibt, der Vorgang bleibt, der Verlauf nennt Namen statt Kennungen', async () => {
  const c = await neu();
  const vg = (await c.d.vorgangAnlegen(c.boot, null, 'arbeit', { bezeichnung: 'Ölwechsel', ausfuehrung: 'selbst' })).id;
  const id = (await c.d.kostenAnlegen(c.boot, Object.assign({}, kerzen, { vorgangId: vg }))).id;
  await c.d.kostenAendern(id, Object.assign({}, kerzen, { gruppe: 'fix', rhythmus: 'monatlich', vorgangId: '', komponenteId: c.motor }));
  const k = await c.d.kostenLaden(id);
  assert.equal(k.aktuell.werte.gruppe, 'instandhaltung', 'die Gruppe lässt sich nicht ändern');
  assert.equal(k.aktuell.werte.rhythmus, 'einmalig');
  assert.equal(k.aktuell.werte.vorgangId, vg, 'der Vorgang bleibt');
  assert.equal(k.aktuell.werte.komponenteId, c.motor);
  const komp = k.verlauf[0].aenderungen.find(a => a.key === 'komponenteId');
  assert.equal(komp.feld.optionen.find(o => o.wert === c.motor).label, 'Motor Backbord');
});

test('Ausblenden statt Löschen: ausgeblendete Posten rechnen nicht mit und lassen sich wieder einblenden', async () => {
  const c = await neu();
  const id = (await c.d.kostenAnlegen(c.boot, diesel)).id;
  assert.equal((await c.d.kostenAuswertung(c.boot, 2026)).gruppen.variabel.summe, 180.5);
  assert.equal((await c.d.kostenAusblenden(id, true)).geaendert, true);
  const a = await c.d.kostenAuswertung(c.boot, 2026);
  assert.equal(a.gruppen.variabel.summe, 0);
  assert.equal(a.ausgeblendet.length, 1);
  assert.equal((await c.d.kostenListe(c.boot)).length, 1, 'nichts wird gelöscht');
  assert.equal((await c.d.kostenAusblenden(id, true)).geaendert, false, 'schon ausgeblendet');
  await c.d.kostenAusblenden(id, false);
  assert.equal((await c.d.kostenAuswertung(c.boot, 2026)).gruppen.variabel.summe, 180.5);
  assert.equal((await c.d.kostenLaden(id)).verlauf.length, 3);
  assert.ok((await c.d.kostenAusblenden('gibt-es-nicht', true)).fehler.allgemein);
});

test('Ändern behält „ausgeblendet“, wenn das Formular es nicht mitschickt', async () => {
  const c = await neu();
  const id = (await c.d.kostenAnlegen(c.boot, diesel)).id;
  await c.d.kostenAusblenden(id, true);
  const roh = Object.assign({}, diesel, { betrag: '200' }); delete roh.ausgeblendet;
  await c.d.kostenAendern(id, roh);
  assert.equal((await c.d.kostenLaden(id)).aktuell.werte.ausgeblendet, 'ja');
});

test('Liste: neueste zuerst, nur die Posten des Fahrzeugs', async () => {
  const c = await neu();
  await c.d.kostenAnlegen(c.boot, diesel);
  await c.d.kostenAnlegen(c.boot, kerzen);
  await c.d.kostenAnlegen(c.boot, liegeplatz);
  await c.d.kostenAnlegen(c.wm, diesel);
  const l = await c.d.kostenListe(c.boot);
  assert.deepEqual(l.map(x => x.aktuell.werte.bezeichnung), ['Zündkerzen', 'Diesel', 'Liegeplatz Heimathafen']);
  assert.equal((await c.d.kostenListe(c.wm)).length, 1);
});

/* ---------- Kostenstammdaten ---------- */
test('Kostenstammdaten: Wert ohne Datum gilt ab heute, Prozentsatz braucht einen Wert, Preis größer 0', async () => {
  const c = await neu();
  const f = async roh => (await c.d.kostenstammSetzen(c.boot, roh)).fehler || {};
  assert.ok((await f({ wertverlustProzent: '2' })).fahrzeugwert, 'ohne Wert kein Wertverlust');
  assert.ok((await f({ fahrzeugwert: '5000', wertverlustProzent: '120' })).wertverlustProzent);
  assert.ok((await f({ fahrzeugwert: '5000', wertverlustProzent: '-1' })).wertverlustProzent);
  assert.ok((await f({ fahrzeugwert: '0' })).fahrzeugwert);
  assert.ok((await f({ fahrzeugwert: '5000', wertDatum: '2027-01-01' })).wertDatum, 'nicht in der Zukunft');
  assert.ok((await f({ vergleichPreisTag: '0' })).vergleichPreisTag);
  assert.ok((await c.d.kostenstammSetzen('gibt-es-nicht', { fahrzeugwert: '5000' })).fehler.allgemein);
  assert.equal(await c.d.kostenstammLaden(c.boot), null, 'bei Fehlern wird nichts gespeichert');
  const r = await c.d.kostenstammSetzen(c.boot, { fahrzeugwert: '48.500', wertverlustProzent: '1,5', vergleichPreisTag: '240', vergleichBezeichnung: 'Motoryacht im Charter' });
  assert.equal(r.ok, true);
  const w = (await c.d.kostenstammLaden(c.boot)).aktuell.werte;
  assert.equal(w.fahrzeugwert, 48500); assert.equal(w.wertDatum, '2026-11-03'); assert.equal(w.wertverlustProzent, 1.5);
  assert.equal(w.vergleichPreisTag, 240); assert.equal(w.vergleichGrundlage, 'geschaetzt', 'ein Preis ohne Angabe gilt als geschätzt');
});

test('Kostenstammdaten: Verlauf, jede Änderung ein neuer Eintrag, eine Zeile je Fahrzeug', async () => {
  const c = await neu();
  await c.d.kostenstammSetzen(c.boot, { fahrzeugwert: '48500' });
  assert.equal((await c.d.kostenstammSetzen(c.boot, { fahrzeugwert: '48500' })).geaendert, false);
  assert.equal((await c.d.kostenstammSetzen(c.boot, { fahrzeugwert: '45000' })).geaendert, true);
  const x = await c.d.kostenstammLaden(c.boot);
  assert.equal(x.verlauf.length, 2);
  assert.equal(x.verlauf[0].aenderungen.find(a => a.key === 'fahrzeugwert').alt, 48500);
  assert.equal((await c.d.speicher.alle('kostenstamm')).length, 1);
  assert.equal(await c.d.kostenstammLaden(c.wm), null, 'jedes Fahrzeug hat seine eigenen Stammdaten');
});

test('„Der Wert stimmt noch“: setzt den Stand auf heute, der Wert bleibt', async () => {
  const c = await neu();
  assert.ok((await c.d.kostenstammWertBestaetigen(c.boot)).fehler.allgemein, 'ohne Wert nichts zu bestätigen');
  await c.d.kostenstammSetzen(c.boot, { fahrzeugwert: '48500', wertDatum: '2025-06-01', wertverlustProzent: '2' });
  assert.equal((await c.d.kostenAuswertung(c.boot, 2026)).wertFrage, true, 'der Wert ist älter als ein Jahr');
  assert.equal((await c.d.kostenstammWertBestaetigen(c.boot)).geaendert, true);
  const w = (await c.d.kostenstammLaden(c.boot)).aktuell.werte;
  assert.equal(w.wertDatum, '2026-11-03'); assert.equal(w.fahrzeugwert, 48500);
  assert.equal((await c.d.kostenAuswertung(c.boot, 2026)).wertFrage, false);
});

/* ---------- Auswertung ---------- */
test('Auswertung: die Gruppen mit ihren Posten, Posten ohne Anteil im Jahr stehen bei „andere“', async () => {
  const c = await neu();
  await c.d.kostenAnlegen(c.boot, liegeplatz);
  await c.d.kostenAnlegen(c.boot, diesel);
  await c.d.kostenAnlegen(c.boot, kerzen);
  await c.d.kostenAnlegen(c.boot, Object.assign({}, diesel, { bezeichnung: 'Diesel 2025', datum: '2025-08-01' }));
  const a = await c.d.kostenAuswertung(c.boot, 2026);
  assert.equal(a.ok, true);
  assert.equal(a.jahr, 2026);
  assert.equal(a.gruppen.fix.summe, 2400);
  assert.equal(a.gruppen.variabel.summe, 180.5);
  assert.equal(a.gruppen.instandhaltung.summe, 45);
  assert.equal(a.gesamt.summe, 2625.5);
  assert.equal(a.posten.fix.length, 1); assert.equal(a.posten.variabel.length, 1); assert.equal(a.posten.instandhaltung.length, 1);
  assert.deepEqual(a.andere.map(x => x.aktuell.werte.bezeichnung), ['Diesel 2025']);
  assert.equal(a.posten.fix[0].imJahr.summe, 2400);
  const v = await c.d.kostenAuswertung(c.boot, 2025);
  assert.equal(v.gruppen.variabel.summe, 180.5);
  assert.equal(v.gruppen.fix.summe, 0, 'der Liegeplatz beginnt erst 2026');
  assert.equal((await c.d.kostenAuswertung(c.boot)).jahr, 2026, 'ohne Jahr das laufende');
  assert.equal((await c.d.kostenAuswertung(c.boot, 'abc')).jahr, 2026, 'ein ungültiges Jahr wird ersetzt');
  assert.equal(await c.d.kostenAuswertung('gibt-es-nicht', 2026), null);
});

test('Auswertung: Nutzungstage aus den Aktivitäten, stornierte zählen nicht, andere Fahrzeuge nicht', async () => {
  const c = await neu();
  await c.d.kostenAnlegen(c.boot, liegeplatz);
  const akt = (await c.d.aktivitaetAnlegen(toern(c))).id;
  await c.d.aktivitaetAnlegen(toern(c, { bezeichnung: 'Spätsommer', vonDatum: '2026-09-01', bisDatum: '2026-09-03' }));
  await c.d.aktivitaetAnlegen(toern(c, { bezeichnung: 'Wohnmobil-Tour', fahrzeugId: c.wm, artId: c.artId('Urlaub'), vonDatum: '2026-06-01', bisDatum: '2026-06-20' }));
  let a = await c.d.kostenAuswertung(c.boot, 2026);
  assert.equal(a.nutzung.genutzt, 13, '10 Tage Törn und 3 Tage im September');
  assert.ok(a.proTag > 0);
  await c.d.aktivitaetStornieren(akt, 'Wetter');
  a = await c.d.kostenAuswertung(c.boot, 2026);
  assert.equal(a.nutzung.genutzt, 3);
});

test('Auswertung: Kilometer aus dem Zähler der Art Strecke am Fahrzeug', async () => {
  const c = await neu();
  await c.d.kostenAnlegen(c.wm, Object.assign({}, liegeplatz, { bezeichnung: 'Stellplatz' }));
  assert.equal((await c.d.kostenAuswertung(c.wm, 2026)).proKm, null, 'ohne Zähler nicht gerechnet');
  const z = (await c.d.zaehlerAnlegen(c.wm, null, 'strecke', { bezeichnung: 'Kilometerstand' })).id;
  await c.d.zaehlerStandEintragen(z, { wert: '10000', datum: '2025-12-20' });
  await c.d.zaehlerStandEintragen(z, { wert: '14000', datum: '2026-10-15' });
  const a = await c.d.kostenAuswertung(c.wm, 2026);
  assert.equal(a.km.km, 4000);
  assert.equal(a.kmZaehler, 'Kilometerstand');
  assert.equal(a.proKm, 0.55, '2.200 Euro bis heute durch 4.000 km');
  /* Der Zähler eines Motors zählt Betriebsstunden und gehört nicht dazu */
  const h = (await c.d.zaehlerAnlegen(c.wm, c.wmMotor, 'stunden', { bezeichnung: 'Betriebsstunden' })).id;
  await c.d.zaehlerStandEintragen(h, { wert: '100', datum: '2025-12-20' });
  await c.d.zaehlerStandEintragen(h, { wert: '150', datum: '2026-10-15' });
  assert.equal((await c.d.kostenAuswertung(c.wm, 2026)).km.km, 4000);
});

test('Auswertung: mit Wert und Wertverlust, mit Vergleichspreis', async () => {
  const c = await neu();
  await c.d.kostenAnlegen(c.boot, liegeplatz);
  await c.d.aktivitaetAnlegen(toern(c));
  await c.d.kostenstammSetzen(c.boot, { fahrzeugwert: '50000', wertDatum: '2026-01-01', wertverlustProzent: '2', vergleichPreisTag: '200', vergleichBezeichnung: 'Charterboot' });
  const a = await c.d.kostenAuswertung(c.boot, 2026);
  assert.equal(a.wertverlust.summe, 1000);
  assert.equal(a.gesamt.summe, 3400);
  assert.equal(a.vergleich.miete, 2000, '10 Tage zu 200 Euro');
  assert.equal(a.vergleich.guenstigerAbTage, 17);
  assert.equal(a.vergleich.bezeichnung, 'Charterboot');
  assert.equal(a.stamm.aktuell.werte.fahrzeugwert, 50000);
});

test('Übersicht: pro Fahrzeug die Auswertung des Jahres', async () => {
  const c = await neu();
  await c.d.kostenAnlegen(c.boot, liegeplatz);
  const u = await c.d.kostenUebersicht(2026);
  assert.equal(u.length, 2);
  assert.equal(u.find(x => x.aktuell.werte.bezeichnung === 'Boot').auswertung.gesamt.summe, 2400);
  assert.equal(u.find(x => x.aktuell.werte.bezeichnung === 'Wohnmobil').auswertung.gesamt.summe, 0);
});

/* ---------- Speicher und Sicherung ---------- */
test('Speicher: Datenbank-Version 12 mit den Tabellen kosten und kostenstamm', async () => {
  assert.equal(MM.Speicher.DB_VERSION, 16);
  assert.ok(MM.Speicher.TABELLEN.includes('kosten') && MM.Speicher.TABELLEN.includes('kostenstamm'));
  const c = await neu();
  assert.equal((await c.d.speicher.alleTabellen()).kosten.length, 0);
});

test('Sicherung: Posten und Kostenstammdaten sind enthalten und kommen samt Verweisen wieder', async () => {
  const c = await neu();
  const vg = (await c.d.vorgangAnlegen(c.boot, c.motor, 'arbeit', { bezeichnung: 'Ölwechsel', ausfuehrung: 'werkstatt' })).id;
  const id = (await c.d.kostenAnlegen(c.boot, Object.assign({}, kerzen, { vorgangId: vg }))).id;
  await c.d.kostenAnlegen(c.boot, liegeplatz);
  await c.d.kostenstammSetzen(c.boot, { fahrzeugwert: '50000', wertverlustProzent: '2', vergleichPreisTag: '200' });
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  assert.equal(s.zahlen.kosten, 2);

  const b = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => JETZT });
  await b.starten();
  const g = await b.sicherungLesen(s.bytes, '');
  assert.equal((await b.sicherungVorschau(g)).zahlen.kosten, 2);
  await b.sicherungEinspielen(g);
  const k = await b.kostenLaden(id);
  assert.equal(k.aktuell.werte.betrag, 45);
  assert.equal(k.vorgangName, 'Ölwechsel');
  assert.equal(k.komponenteName, 'Motor Backbord');
  assert.equal((await b.kostenstammLaden(c.boot)).aktuell.werte.vergleichPreisTag, 200);
  assert.equal((await b.kostenAuswertung(c.boot, 2026)).gesamt.summe, 2400 + 45 + 1000);
});

test('Sicherung: eine alte Sicherung ohne die Kosten-Tabellen lässt sich weiter einspielen', async () => {
  const c = await neu();
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  const g = await c.d.sicherungLesen(s.bytes, '');
  delete g.kopf.tabellen.kosten; delete g.kopf.tabellen.kostenstamm;
  const b = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => JETZT });
  await b.starten();
  const r = await b.sicherungEinspielen(g);
  assert.ok(r === undefined || r.ok !== false);
  assert.equal((await b.kostenListe(c.boot)).length, 0);
  assert.equal((await b.fahrzeugListe()).length, 2);
});
