'use strict';
/* Etappen (2.0.43): Orte je Tag, Wetter, Kosten, Reisecheck je Tag, Zusammenfassung. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/routen.js');
require('../js/etappen.js');
require('../js/reisecheck.js');
require('../js/daten.js');
const MM = globalThis.MM;
const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();

async function holeJson(url) {
  const t0 = Math.floor(Date.UTC(2026, 10, 3, 0, 0) / 1000), z = []; for (let i = 0; i < 16 * 24; i++) z.push(t0 + i * 3600);
  if (url.includes('marine-api')) return { hourly: { time: z, wave_height: z.map(() => 0.8), wave_direction: z.map(() => 270), wave_period: z.map(() => 5), sea_level_height_msl: z.map(() => 0) } };
  return { hourly: { time: z, temperature_2m: z.map(() => 9), precipitation: z.map(() => 0), precipitation_probability: z.map(() => 40), wind_speed_10m: z.map(() => 10), wind_gusts_10m: z.map(() => 22), wind_direction_10m: z.map(() => 225), weather_code: z.map(() => 3) } };
}
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(), holeJson });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = arten.find(a => a.aktuell.werte.bezeichnung === 'Urlaub').objekt.id;
  const a = (await d.ortAnlegen({ bezeichnung: 'Stuttgart', positionBreite: '48,78', positionLaenge: '9,18' })).id;
  const b = (await d.ortAnlegen({ bezeichnung: 'Ulm', positionBreite: '48,40', positionLaenge: '9,99' })).id;
  const c = (await d.ortAnlegen({ bezeichnung: 'München', positionBreite: '48,14', positionLaenge: '11,58' })).id;
  const frei = (await d.ortAnlegen({ bezeichnung: 'Nirgendwo' })).id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Reise', artId, fahrzeugId: wm, vonDatum: '2026-11-05', vonZeit: '08:00', bisDatum: '2026-11-06', verantwortlichId: anna, startOrtId: a, zielOrtId: c, zwischenzielIds: [b] });
  assert.equal(r.ok, true, JSON.stringify(r));
  await d.tagesabschnitteVorbereiten(r.id);
  const lb = await d.logbuchLaden(r.id);
  return { d, wm, akt: r.id, a, b, c, frei, tage: lb.abschnitte.map(x => x.objekt.id) };
}
const tagWerte = (datum, extra) => Object.assign({ datum, beginnZeit: '08:00', endeZeit: '12:00' }, extra || {});

test('Tag: Start- und Zielort speichern, falsche Orte werden abgelehnt, Text bleibt', async () => {
  const c = await neu();
  assert.equal(c.tage.length, 2);
  const r = await c.d.abschnittAendern(c.tage[0], tagWerte('2026-11-05', { startOrtId: c.a, zielOrtId: c.b }));
  assert.equal(r.ok, true);
  assert.equal((await c.d.abschnittAendern(c.tage[0], tagWerte('2026-11-05', { startOrtId: 'gibtsnicht' }))).fehler.startOrtId.includes('gibt es nicht'), true);
  const z = await c.d.reiseZusammenfassung(c.akt);
  assert.equal(z.tage[0].start.name, 'Stuttgart'); assert.equal(z.tage[0].ziel.name, 'Ulm');
  assert.equal(z.tage[1].start, null);
  /* ohne die Schlüssel im Formular bleiben die Orte erhalten */
  await c.d.abschnittAendern(c.tage[0], { datum: '2026-11-05', notiz: 'x' });
  assert.equal((await c.d.reiseZusammenfassung(c.akt)).tage[0].start.name, 'Stuttgart');
  const o = await c.d.etappeOrtOptionen(c.akt, []);
  assert.deepEqual(o.optionen.map(x => x.label).sort(), ['München', 'Stuttgart', 'Ulm']); assert.equal(o.nurPlan, true);
});

test('Wetter je Tag: unklar mit Grund, dann geholt, dann von Hand ersetzt', async () => {
  const c = await neu();
  let z = (await c.d.reiseZusammenfassung(c.akt)).tage[0];
  assert.equal(z.wetter.quelle, 'unklar'); assert.match(z.wetter.grund, /Start- und Zielort/);
  await c.d.abschnittAendern(c.tage[0], { datum: '2026-11-05', startOrtId: c.a, zielOrtId: c.frei });
  z = (await c.d.reiseZusammenfassung(c.akt)).tage[0];
  assert.match(z.wetter.grund, /Position/);
  await c.d.abschnittAendern(c.tage[0], { datum: '2026-11-05', startOrtId: c.a, zielOrtId: c.b });
  z = (await c.d.reiseZusammenfassung(c.akt)).tage[0];
  assert.match(z.wetter.grund, /Uhrzeit des Beginns/);
  await c.d.abschnittAendern(c.tage[0], tagWerte('2026-11-05', { startOrtId: c.a, zielOrtId: c.b }));
  const h = await c.d.etappeWetterAbrufen(c.tage[0]);
  assert.equal(h.ok, true, JSON.stringify(h)); assert.ok(h.punkte >= 2);
  z = (await c.d.reiseZusammenfassung(c.akt)).tage[0];
  assert.equal(z.wetter.quelle, 'online'); assert.equal(z.wetter.aktuell, true); assert.match(z.wetter.text, /Böen bis 22 km\/h/);
  assert.equal(z.strecke.art, 'luftlinie'); assert.ok(z.strecke.km > 60 && z.strecke.km < 90);
  await c.d.abschnittAendern(c.tage[0], tagWerte('2026-11-05', { startOrtId: c.a, zielOrtId: c.c }));
  assert.equal((await c.d.reiseZusammenfassung(c.akt)).tage[0].wetter.aktuell, false);
  await c.d.abschnittAendern(c.tage[0], tagWerte('2026-11-05', { startOrtId: c.a, zielOrtId: c.c, wetterHand: 'Sonne, 15 Grad' }));
  z = (await c.d.reiseZusammenfassung(c.akt)).tage[0];
  assert.equal(z.wetter.quelle, 'hand'); assert.equal(z.wetter.text, 'Sonne, 15 Grad');
  assert.equal((await c.d.etappeWetterAbrufen('nix')).ok, false);
});

test('Kosten je Tag: ausdrücklich, nach Datum, ohne Tag; die Summe bleibt die Summe aller Tage', async () => {
  const c = await neu();
  const k = (extra) => Object.assign({ gruppe: 'variabel', bezeichnung: 'Posten', betrag: '10', aktivitaetId: c.akt, datum: '2026-11-05' }, extra);
  assert.equal((await c.d.kostenAnlegen(c.wm, k({ abschnittId: c.tage[1], datum: '2026-11-05' }))).ok, true);
  assert.equal((await c.d.kostenAnlegen(c.wm, k({ betrag: '5' }))).ok, true);
  assert.equal((await c.d.kostenAnlegen(c.wm, k({ betrag: '2', datum: '2026-12-24' }))).ok, true);
  assert.equal((await c.d.kostenAnlegen(c.wm, { gruppe: 'reisekasse', bezeichnung: 'Pizza', betrag: '20', aktivitaetId: c.akt, datum: '2026-11-06' })).ok, true);
  const f = await c.d.kostenAnlegen(c.wm, k({ abschnittId: 'fremd' }));
  assert.ok(f.fehler.abschnittId);
  const nf = await c.d.kostenAnlegen(c.wm, { gruppe: 'fix', bezeichnung: 'V', betrag: '5', rhythmus: 'jaehrlich', abschnittId: c.tage[0] });
  assert.ok(nf.fehler.abschnittId);
  const z = await c.d.reiseZusammenfassung(c.akt);
  assert.equal(z.tage[0].kosten.summe, 5); assert.equal(z.tage[0].kosten.nachDatum, 1);
  assert.equal(z.tage[1].kosten.summe, 30);
  assert.equal(z.ohneTag.summe, 2); assert.equal(z.kostenSumme, 37);
  assert.equal(z.gesamt.ohneFix, 37);
  /* Ändern ohne das Feld behält den Tag */
  const id = (await c.d.kostenListe(c.wm)).find(x => x.aktuell.werte.abschnittId === c.tage[1]).objekt.id;
  await c.d.kostenAendern(id, k({ betrag: '11' }));
  assert.equal((await c.d.kostenLaden(id)).aktuell.werte.abschnittId, c.tage[1]);
});

test('Reisecheck je Tag: nur die zwei Orte des Tages, getrennt vom Gesamtcheck', async () => {
  const c = await neu();
  let q = await c.d.reisecheckAnfrage(c.akt, c.tage[0]);
  assert.equal(q.ok, false); assert.match(q.fehler.join(' '), /Start- und einen Zielort/);
  await c.d.abschnittAendern(c.tage[0], tagWerte('2026-11-05', { startOrtId: c.a, zielOrtId: c.b }));
  q = await c.d.reisecheckAnfrage(c.akt, c.tage[0]);
  assert.equal(q.ok, true, JSON.stringify(q));
  const wp = q.anfrage.trip.routePlan.waypoints;
  assert.deepEqual(wp.map(w => w.ortName), ['Stuttgart', 'Ulm']);
  assert.equal(q.anfrage.trip.start, '2026-11-05T08:00:00'); assert.equal(q.anfrage.trip.end, '2026-11-05T12:00:00');
  const g = await c.d.reisecheckAnfrage(c.akt);
  assert.equal(g.anfrage.trip.routePlan.waypoints.length, 3);
  assert.equal(await c.d.reisecheckAnfrage(c.akt, 'nix'), null);
  assert.deepEqual(await c.d.reisecheckListe(c.akt), []);
  assert.deepEqual(await c.d.reisecheckListe(c.akt, c.tage[0]), []);
});

test('Zusammenfassung: Summen, Ereignisse und ausgeblendete Tage', async () => {
  const c = await neu();
  await c.d.abschnittAendern(c.tage[1], { datum: '2026-11-06', ausgeblendet: 'ja' });
  const z = await c.d.reiseZusammenfassung(c.akt);
  assert.equal(z.tage.length, 1); assert.equal(z.streckeUnklar, 1); assert.equal(z.streckeSumme, 0);
  assert.equal(z.tage[0].ereignisse.anzahl, 0);
  assert.equal(await c.d.reiseZusammenfassung('nix'), null);
});

test('Sicherung enthält das Wetter eines Tages (Dokument in „einstellungen“)', async () => {
  const c = await neu();
  await c.d.abschnittAendern(c.tage[0], tagWerte('2026-11-05', { startOrtId: c.a, zielOrtId: c.b }));
  await c.d.etappeWetterAbrufen(c.tage[0]);
  assert.ok(await c.d.einstellungLesen('wetter-etappe-' + c.tage[0]));
});

test('„Neu im Programm“ nennt 2.0.43 mit Etappen, ohne die falsche Grenze von 30 Tagen', () => {
  require('../js/texte.js');
  const e = MM.Texte.NEUERUNGEN.find(x => x.version === '2.0.43');
  assert.ok(e, 'Eintrag 2.0.43 fehlt');
  assert.ok(e.punkte.join(' ').includes('Etappen'));
  assert.ok(!e.punkte.join(' ').includes('2 bis 30 Tage'));
  assert.ok(e.punkte.join(' ').includes('mehrere Tage'));
});
