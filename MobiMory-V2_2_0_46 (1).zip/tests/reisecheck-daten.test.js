'use strict';
/* Schritt 11 (2.0.38): Reisecheck, Datenfunktionen mit nachgebautem Dienst. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/routen.js');
require('../js/reisecheck.js');
require('../js/daten.js');
const MM = globalThis.MM;

const JETZT = new Date(2026, 10, 5, 12, 0, 0).toISOString();
const URL_DIENST = 'https://dienst.example.dev';
const ANF = (x) => Object.assign({ id: 'r1', area: 'Papiere', category: 'Pflicht', subjectKey: 'P1', subjectType: 'Person', trafficMode: 'Wasser', requirement: 'Führerschein für P1', proofKey: 'FS',
  status: 'Erfüllt', evidence: 'P1 hat Führerschein', explanation: 'passt', confidence: 'hoch', conflict: false, sources: [{ title: 'Amt', url: 'https://amt.example/x', publisher: 'Amt', official: true, updated: '' }] }, x || {});
const ANTWORT = { ok: true, model: 'm1', requestId: 'q1', researchedAt: '2026-11-05T11:00:00Z', result: { summary: 'Fertig', researchStatus: 'vollständig', warnings: [], route: { routingStatus: 'plausibel', summary: '', assumptions: [], routeWarnings: [] }, requirements: [ANF(), ANF({ id: 'r2', subjectKey: 'A1', requirement: 'Impfung für A1', status: 'Fehlt' })] } };

async function neu(opt) {
  const o = opt || {}; let t = 0; const gesendet = [];
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), {
    jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(),
    holeJson: async () => { if (o.aus) throw new Error('aus'); return { ok: true, configured: o.ohneSchluessel ? false : true, model: 'm1' }; },
    sendeJson: async (url, token, body) => { gesendet.push({ url, token, body }); if (o.fehler) { const e = new Error('x'); e.status = o.fehler; throw e; } return o.antwort || ANTWORT; }
  });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Seeschwalbe', marke: 'Bavaria', laenge: '9,5', registriernummer: 'KN-1234' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const bello = (await d.tierAnlegen({ bezeichnung: 'Bello', tierart: 'Hund', chipnummer: '276098106123456' })).id;
  const fs = (await d.nachweisartAusVorschlag('DE_FEV_FUEHRERSCHEIN_EU')).id;
  const nw = await d.nachweisAnlegen('person', anna, fs, { nummer: 'GEHEIM-1', gueltigBis: '2030-01-01' });
  assert.equal(nw.ok, true, JSON.stringify(nw));
  const gebiet = (await d.gebietAnlegen({ bezeichnung: 'Kroatien' })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = arten.find(a => a.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const akt = await d.aktivitaetAnlegen({ bezeichnung: 'Sommertörn', artId, fahrzeugId: boot, vonDatum: '2026-11-10', bisDatum: '2026-11-17', verantwortlichId: anna, gebietId: gebiet, tierIds: [bello] });
  assert.equal(akt.ok, true, JSON.stringify(akt));
  return { d, id: akt.id, gesendet, boot, anna };
}
async function bereit(c) {
  assert.equal((await c.d.reisecheckEinrichten({ dienstUrl: URL_DIENST + '/research', passwort: 'geheim1234' })).ok, true);
  assert.equal((await c.d.reisecheckZustimmen()).ok, true);
}

test('Speicher: Tabelle reisechecks, Version 16', () => {
  assert.equal(MM.Speicher.DB_VERSION, 16);
  assert.ok(MM.Speicher.TABELLEN.includes('reisechecks'));
});

test('Einrichten: Fehler, Passwort bleibt, Anzeige ohne Passwort', async () => {
  const c = await neu();
  const f = await c.d.reisecheckEinrichten({ dienstUrl: 'http://x', passwort: 'kurz' });
  assert.equal(f.ok, false); assert.ok(f.fehler.dienstUrl); assert.ok(f.fehler.passwort);
  await c.d.reisecheckEinrichten({ dienstUrl: URL_DIENST, passwort: 'geheim1234' });
  assert.equal((await c.d.reisecheckEinrichten({ dienstUrl: URL_DIENST + '/health', passwort: '' })).ok, true, 'leeres Passwort behält das alte');
  const e = await c.d.reisecheckEinstellung();
  assert.equal(e.eingerichtet, true); assert.equal(e.dienstUrl, URL_DIENST); assert.ok(!JSON.stringify(e).includes('geheim1234'));
});

test('Zustimmung: erst nach Einrichtung, mit Protokoll, Widerruf, andere Adresse widerruft', async () => {
  const c = await neu();
  assert.equal((await c.d.reisecheckZustimmen()).ok, false);
  await bereit(c);
  let e = await c.d.reisecheckEinstellung();
  assert.equal(e.zugestimmt, true); assert.equal(e.protokoll[0].text, MM.Reisecheck.ZUSTIMMUNG_TEXT);
  await c.d.reisecheckWiderrufen();
  e = await c.d.reisecheckEinstellung(); assert.equal(e.zugestimmt, false);
  await c.d.reisecheckZustimmen();
  const r = await c.d.reisecheckEinrichten({ dienstUrl: 'https://anders.example.dev', passwort: '' });
  assert.equal(r.zustimmungZurueck, true);
  assert.equal((await c.d.reisecheckEinstellung()).zugestimmt, false);
});

test('Verbindung: läuft, ohne Schlüssel, nicht erreichbar', async () => {
  let c = await neu(); await bereit(c);
  assert.deepEqual(await c.d.reisecheckVerbindung(), { ok: true, modell: 'm1' });
  c = await neu({ ohneSchluessel: true }); await bereit(c);
  assert.equal((await c.d.reisecheckVerbindung()).ok, false);
  c = await neu({ aus: true }); await bereit(c);
  assert.equal((await c.d.reisecheckVerbindung()).ok, false);
});

test('Anfrage: Namen und Nummern bleiben auf dem Gerät', async () => {
  const c = await neu();
  const q = await c.d.reisecheckAnfrage(c.id);
  assert.equal(q.ok, true, JSON.stringify(q));
  const s = JSON.stringify(q.anfrage);
  ['Anna', 'Bello', 'Seeschwalbe', 'Sommertörn', 'KN-1234', 'GEHEIM-1', '276098106123456'].forEach(x => assert.ok(!s.includes(x), x));
  assert.equal(q.anfrage.persons[0].qualifications[0].validTo, '2030-01-01');
  assert.equal(q.anfrage.animals[0].hasChip, true);
  assert.equal(q.namen.P1, 'Anna');
});

test('Starten: ohne Einrichtung oder Zustimmung wird nichts gesendet', async () => {
  const c = await neu();
  let r = await c.d.reisecheckStarten(c.id); assert.equal(r.ok, false); assert.equal(r.art, 'einrichtung');
  await c.d.reisecheckEinrichten({ dienstUrl: URL_DIENST, passwort: 'geheim1234' });
  r = await c.d.reisecheckStarten(c.id); assert.equal(r.art, 'zustimmung');
  assert.equal(c.gesendet.length, 0);
});

test('Starten: sendet an /research mit Passwort, speichert Ergebnis, Auswertung und Namen', async () => {
  const c = await neu(); await bereit(c);
  const r = await c.d.reisecheckStarten(c.id);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(c.gesendet[0].url, URL_DIENST + '/research'); assert.equal(c.gesendet[0].token, 'geheim1234');
  const l = await c.d.reisecheckLaden(r.id);
  assert.equal(l.auswertung.gesamt, 'fehlt');
  assert.equal(l.anforderungen[0].status, 'Fehlt');
  assert.equal(l.check.namen.A1, 'Bello');
  const a = await c.d.reisecheckAnsicht(c.id);
  assert.equal(a.checks.length, 1); assert.equal(a.checks[0].veraltet, false);
  assert.equal((await c.d.reisecheckUebersicht())[0].letzter.gesamt, 'fehlt');
});

test('Geänderte Daten machen den Check „veraltet“, mehrere Checks bleiben', async () => {
  const c = await neu(); await bereit(c);
  await c.d.reisecheckStarten(c.id);
  await c.d.aktivitaetAendern(c.id, { bezeichnung: 'Sommertörn', artId: (await c.d.aktivitaetLaden(c.id)).aktuell.werte.artId, fahrzeugId: c.boot, vonDatum: '2026-11-10', bisDatum: '2026-11-20', gebietId: (await c.d.aktivitaetLaden(c.id)).aktuell.werte.gebietId });
  assert.equal((await c.d.reisecheckAnsicht(c.id)).checks[0].veraltet, true);
  await c.d.reisecheckStarten(c.id);
  const a = await c.d.reisecheckAnsicht(c.id);
  assert.equal(a.checks.length, 2); assert.equal(a.checks[0].veraltet, false);
});

test('Fehler des Dienstes: verständlicher Text, nichts gespeichert', async () => {
  for (const [st, teil] of [[401, 'Passwort'], [403, 'App-Adresse'], [503, 'nicht fertig'], [500, 'nicht abschließen']]) {
    const c = await neu({ fehler: st }); await bereit(c);
    const r = await c.d.reisecheckStarten(c.id);
    assert.equal(r.ok, false); assert.ok(r.fehler.allgemein.includes(teil), r.fehler.allgemein);
    assert.equal((await c.d.reisecheckListe(c.id)).length, 0);
  }
  const c = await neu({ antwort: { ok: true, result: { requirements: [] } } }); await bereit(c);
  assert.equal((await c.d.reisecheckStarten(c.id)).ok, false);
  assert.equal((await c.d.reisecheckListe(c.id)).length, 0);
});

test('Aktivität ohne Gebiet und ohne Start/Ziel: keine Anfrage; storniert: kein Check', async () => {
  const c = await neu(); await bereit(c);
  const w = (await c.d.aktivitaetLaden(c.id)).aktuell.werte;
  await c.d.aktivitaetAendern(c.id, Object.assign({}, w, { gebietId: '', gebiet: '' }));
  const r = await c.d.reisecheckStarten(c.id);
  assert.equal(r.ok, false); assert.equal(r.art, 'daten'); assert.equal(c.gesendet.length, 0);
});

test('Sicherung: Ergebnisse ja, Passwort und Adresse nein', async () => {
  const c = await neu(); await bereit(c);
  await c.d.reisecheckStarten(c.id);
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  assert.equal(s.zahlen.reisechecks, 1);
  const g = await c.d.sicherungLesen(s.bytes, '');
  assert.ok(!JSON.stringify(g.kopf.tabellen.einstellungen).includes('geheim1234'));
  const b = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => JETZT });
  await b.starten(); await b.sicherungEinspielen(g);
  assert.equal((await b.reisecheckListe(c.id)).length, 1);
  assert.equal((await b.reisecheckEinstellung()).eingerichtet, false);
});
