/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.84';
  MM.STUFE = 'Gutscheincodes: Code-Feld beim Angebot, Mail beim Anlegen; Planung und Fahrzeugseiten unverändert';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
