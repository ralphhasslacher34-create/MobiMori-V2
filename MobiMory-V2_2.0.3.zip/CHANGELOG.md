# Änderungen

## 2.0.3
- Startseite neu gestaltet. Vor den drei Teilen des Kernsatzes stehen die Logo-Buchstaben V, T und D.
- Infotext nennt „Reisen planen“ statt „Reisen prüfen“.
- Das Logo ist eine einzige Datei (`icons/icon.svg`) und wird auf der Startseite, in der Kopfzeile und als App-Symbol verwendet. Das jetzige Zeichen ist ein Platzhalter.

## 2.0.2
- Startseite mit Logo, Kernsatz „Dein Fahrzeug. Dein Weg. Deine Daten.“, Copyright und den Knöpfen „Programm starten“ und „Neu im Programm“.
- Hauptmenü mit den Kacheln Stammdaten, Funktionen (kommt) und Einstellungen.
- Stammdaten mit Fahrzeugen. Personen und Tiere sind als „kommt“ vorgesehen.
- Seite „Neu im Programm“ mit der Liste der Änderungen (steht in `js/texte.js`).
- Einstellungen mit Datenhinweis, Versionsangabe und dem Testknopf zum Löschen.
- Die Fahrzeugliste ist jetzt unter Stammdaten erreichbar, der Rest aus 2.0.1 ist unverändert.
- Neue Prüfungen: Versionsnummer, Änderungsliste und Dateiliste für den Offline-Betrieb müssen zusammenpassen.

## 2.0.1 – Schritt 1
- Neu aufgebaut, nicht aus V1 geflickt.
- Fahrzeugliste mit Kennung (Schale 1) und äußere Hülle (Schale 2).
- Sieben feste Fahrzeugarten: Auto, Motorrad, Wohnmobil, Wohnwagen, Oldtimer, Boot, Flugzeug. Felder je nach Art, zum Beispiel Tiefgang nur beim Boot, Achsen nur an Land.
- Handeingabe mit Prüfung. Änderungen werden als neuer Eintrag „Korrektur zu …“ gespeichert, der alte Stand bleibt im Verlauf.
- Offline-fähig, Daten liegen lokal auf dem Gerät.
- Automatische Tests für die Daten-Schicht.
