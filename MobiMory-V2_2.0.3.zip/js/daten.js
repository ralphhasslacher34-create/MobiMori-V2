/*
 * Daten: die EINE Tür zu allen Fahrzeugdaten.
 *
 * Regeln aus den V2-Festlegungen, die hier gelten:
 *  - Eine Quelle: alle Teile der App fragen nur hier nach.
 *  - Handeingabe hat Vorrang. Es wird nichts überschrieben: Jede Änderung
 *    ist ein neuer Eintrag "Korrektur zu ...", der alte bleibt sichtbar.
 *  - Nichts wird gelöscht.
 *  - Jeder Fahrzeug-Eintrag nennt seine Herkunft (hier: "hand").
 *
 * Aufbau der gespeicherten Daten:
 *  datenraum  { id, name, erstelltAm }
 *  fahrzeug   { id, datenraumId, art, erstelltAm }
 *  eintrag    { id, fahrzeugId, nr, werte, quelle, korrekturZu, erstelltAm }
 *             "werte" enthält Bezeichnung und alle Felder der Fahrzeugart.
 *             Der aktuelle Stand ist der Eintrag mit der höchsten Nummer.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  function neueId(praefix) {
    var c = global.crypto;
    if (c && typeof c.randomUUID === 'function') return praefix + '-' + c.randomUUID();
    return praefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function Daten(speicher, optionen) {
    this.speicher = speicher;
    this.jetzt = (optionen && optionen.jetzt) || function () { return new Date().toISOString(); };
    this.datenraumId = null;
  }

  /* Beim ersten Start entsteht der eigene Datenraum auf diesem Gerät. */
  Daten.prototype.starten = function () {
    var self = this;
    return this.speicher.alle('datenraeume').then(function (liste) {
      if (liste.length) { self.datenraumId = liste[0].id; return liste[0]; }
      var dr = { id: neueId('dr'), name: 'Mein Datenraum', erstelltAm: self.jetzt() };
      return self.speicher.speichern('datenraeume', dr).then(function () {
        self.datenraumId = dr.id;
        return dr;
      });
    });
  };

  /* Eingaben prüfen und in saubere Werte umwandeln. */
  Daten.prototype.pruefen = function (artId, roh) {
    var felder = MM.Fahrzeugarten.felder(artId);
    var werte = {};
    var fehler = {};
    var jahr = new Date(this.jetzt()).getFullYear();
    roh = roh || {};

    var bez = String(roh.bezeichnung == null ? '' : roh.bezeichnung).trim();
    if (!bez) fehler.bezeichnung = 'Bitte eine Bezeichnung eingeben, zum Beispiel „Fahrzeug A“.';
    werte.bezeichnung = bez;

    felder.forEach(function (f) {
      var v = roh[f.key];
      v = (v === undefined || v === null) ? '' : v;
      if (typeof v === 'string') v = v.trim();

      if (f.typ === 'text') { werte[f.key] = v === '' ? null : String(v); return; }

      if (f.typ === 'auswahl') {
        if (v === '') { werte[f.key] = null; return; }
        if (f.optionen.indexOf(v) < 0) { fehler[f.key] = 'Bitte eine Möglichkeit aus der Liste wählen.'; }
        werte[f.key] = v;
        return;
      }

      if (f.typ === 'datum') {
        if (v === '') { werte[f.key] = null; return; }
        var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
        var d = m ? new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])) : null;
        if (!d || d.getUTCFullYear() !== +m[1] || d.getUTCMonth() !== +m[2] - 1 || d.getUTCDate() !== +m[3]) {
          fehler[f.key] = 'Bitte ein gültiges Datum eingeben.';
          werte[f.key] = null;
        } else { werte[f.key] = v; }
        return;
      }

      /* zahl und ganzzahl: Komma oder Punkt als Dezimalzeichen erlaubt */
      if (v === '') { werte[f.key] = null; return; }
      var text = String(v).replace(/\s/g, '').replace(',', '.');
      var n = /^-?\d+(\.\d+)?$/.test(text) ? Number(text) : NaN;
      if (isNaN(n)) {
        fehler[f.key] = f.typ === 'ganzzahl' ? 'Bitte eine ganze Zahl eingeben.' : 'Bitte eine Zahl eingeben, zum Beispiel 2,5.';
        werte[f.key] = null;
        return;
      }
      if (f.typ === 'ganzzahl' && Math.floor(n) !== n) { fehler[f.key] = 'Bitte eine ganze Zahl eingeben.'; werte[f.key] = null; return; }
      if (n < 0) { fehler[f.key] = 'Die Zahl darf nicht negativ sein.'; werte[f.key] = null; return; }
      if (f.key === 'baujahr' && (n < f.min || n > jahr + 1)) {
        fehler[f.key] = 'Bitte ein Baujahr zwischen ' + f.min + ' und ' + (jahr + 1) + ' eingeben.';
        werte[f.key] = null; return;
      }
      if (f.min !== undefined && f.key !== 'baujahr' && n < f.min) { fehler[f.key] = 'Der Wert muss mindestens ' + f.min + ' sein.'; werte[f.key] = null; return; }
      if (f.max !== undefined && n > f.max) { fehler[f.key] = 'Der Wert darf höchstens ' + f.max + ' sein.'; werte[f.key] = null; return; }
      werte[f.key] = n;
    });

    return { werte: werte, fehler: fehler, ok: Object.keys(fehler).length === 0 };
  };

  /* Was hat sich zwischen zwei Ständen geändert? */
  Daten.prototype.unterschiede = function (artId, alt, neu) {
    var liste = [{ key: 'bezeichnung', label: 'Bezeichnung' }].concat(MM.Fahrzeugarten.felder(artId));
    var res = [];
    liste.forEach(function (f) {
      var a = alt[f.key] === undefined ? null : alt[f.key];
      var n = neu[f.key] === undefined ? null : neu[f.key];
      if (a !== n) res.push({ key: f.key, label: f.label, feld: f, alt: a, neu: n });
    });
    return res;
  };

  Daten.prototype.fahrzeugAnlegen = function (artId, roh) {
    var self = this;
    if (!MM.Fahrzeugarten.art(artId)) {
      return Promise.resolve({ ok: false, fehler: { art: 'Bitte zuerst die Fahrzeugart wählen.' } });
    }
    var p = this.pruefen(artId, roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var jetzt = this.jetzt();
    var fahrzeug = { id: neueId('fz'), datenraumId: this.datenraumId, art: artId, erstelltAm: jetzt };
    var eintrag = { id: neueId('en'), fahrzeugId: fahrzeug.id, nr: 1, werte: p.werte,
      quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
    return this.speicher.mehrereSpeichern([
      { tabelle: 'fahrzeuge', objekt: fahrzeug },
      { tabelle: 'eintraege', objekt: eintrag }
    ]).then(function () { return { ok: true, id: fahrzeug.id }; });
  };

  /* Änderung = neuer Eintrag. Der alte bleibt unverändert erhalten. */
  Daten.prototype.fahrzeugAendern = function (fahrzeugId, roh) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      var p = self.pruefen(f.fahrzeug.art, roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var diff = self.unterschiede(f.fahrzeug.art, f.aktuell.werte, p.werte);
      if (!diff.length) return { ok: true, id: fahrzeugId, geaendert: false };
      var eintrag = { id: neueId('en'), fahrzeugId: fahrzeugId, nr: f.aktuell.nr + 1, werte: p.werte,
        quelle: 'hand', korrekturZu: f.aktuell.id, erstelltAm: self.jetzt() };
      return self.speicher.speichern('eintraege', eintrag)
        .then(function () { return { ok: true, id: fahrzeugId, geaendert: true }; });
    });
  };

  function neuester(eintraege) {
    return eintraege.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
  }

  /* Alle Fahrzeuge des Datenraums, jeweils mit aktuellem Stand (Schale 1). */
  Daten.prototype.fahrzeugListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('fahrzeuge'), this.speicher.alle('eintraege')]).then(function (r) {
      var nachFahrzeug = {};
      r[1].forEach(function (e) { (nachFahrzeug[e.fahrzeugId] = nachFahrzeug[e.fahrzeugId] || []).push(e); });
      var liste = r[0].filter(function (f) { return f.datenraumId === self.datenraumId; })
        .map(function (f) { return { fahrzeug: f, aktuell: neuester(nachFahrzeug[f.id] || []) }; })
        .filter(function (x) { return x.aktuell; });
      liste.sort(function (a, b) {
        return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return liste;
    });
  };

  /* Ein Fahrzeug mit aktuellem Stand und dem ganzen Verlauf (neueste zuerst). */
  Daten.prototype.fahrzeugLaden = function (id) {
    var self = this;
    return Promise.all([this.speicher.holen('fahrzeuge', id), this.speicher.wo('eintraege', 'fahrzeugId', id)])
      .then(function (r) {
        var fahrzeug = r[0];
        if (!fahrzeug || !r[1].length) return null;
        var eintraege = r[1].slice().sort(function (a, b) { return a.nr - b.nr; });
        var verlauf = eintraege.map(function (e, i) {
          var vorher = i > 0 ? eintraege[i - 1] : null;
          return { eintrag: e, vorher: vorher,
            aenderungen: vorher ? self.unterschiede(fahrzeug.art, vorher.werte, e.werte) : [] };
        }).reverse();
        return { fahrzeug: fahrzeug, aktuell: eintraege[eintraege.length - 1], verlauf: verlauf };
      });
  };

  /* Nur für Tests auf dem eigenen Gerät. */
  Daten.prototype.allesLoeschen = function () {
    var self = this;
    return this.speicher.allesLoeschen().then(function () { return self.starten(); });
  };

  MM.Daten = { Daten: Daten };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
