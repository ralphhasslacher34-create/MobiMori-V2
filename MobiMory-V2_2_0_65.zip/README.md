# MobiMory V2

Fahrzeuge, Reisen und Logbuch an einem Ort. V2 ist kein Flickwerk, sondern
baut Schritt für Schritt auf dem letzten Stand auf.

**Aktueller Stand: Version 2.0.65**
Startseite, Hauptmenü und Stammdaten, darunter die Fahrzeugliste (Schale 1) und
die äußere Hülle (Schale 2) mit Handeingabe, Änderungsverlauf und
Offline-Betrieb. Darunter die Hauptkomponenten (Schale 3) mit beliebig tiefer Aufschlüsselung.

Wege durch die App: Startseite → Hauptmenü → Stammdaten → Fahrzeuge → Fahrzeug → Hauptkomponente → Teil → Teil …

## Ausprobieren

**Am einfachsten:** Datei `index.html` im Browser öffnen. Die Daten bleiben
auf dem Gerät.

**Als App auf Handy oder Tablet** (mit Offline-Betrieb): die Seite über die
GitHub-Pages-Adresse öffnen und im Browser „Zum Startbildschirm hinzufügen“
wählen. Die Adresse steht nach der Einrichtung unter *Settings > Pages*.

## Auf GitHub einrichten (einmalig)

1. Neues Repository anlegen, zum Beispiel `MobiMory-V2`.
2. Den Inhalt dieses Ordners hochladen (alles, auch den versteckten Ordner `.github`).
3. Im Repository unter *Settings > Pages* bei *Source* den Eintrag **GitHub Actions** wählen.
4. Fertig. Bei jeder Änderung läuft zuerst die Prüfung, dann wird die App veröffentlicht.

## Aufbau des Ordners

| Datei | Aufgabe |
|---|---|
| `index.html` | Startseite |
| `css/styles.css` | Gestaltung |
| `js/daten.js` | **Die eine Tür** zu allen Fahrzeugdaten (Regeln, Prüfung, Verlauf) |
| `js/konto.js` | Konto: Prüfungen und Texte für die Anmeldung beim Dienst |
| `js/abgleich.js` | Abgleich zwischen Geräten: welche Datenarten zum Dienst gehen, was lokal bleibt, Zusammenführen (nur Rechnung) |
| `server/` | Konto-Dienst für Cloudflare (Worker, Tabellen, Einrichtung), kommt nicht in die App |
| `js/sicherung.js` | Sicherungsdatei: Aufbau, Verschlüsselung, Prüfsumme |
| `js/speicher.js` | Wo die Daten auf dem Gerät liegen (IndexedDB) |
| `js/fahrzeugarten.js` | Fahrzeugarten und ihre Felder, als Daten beschrieben |
| `js/komponenten.js` | Arten der Hauptkomponenten und die Felder jeder Komponente |
| `js/orte.js` | Orte, Standorte, Gebiete und Regeln: Felder und Rechnung (welche Regeln greifen, Soll gegen Ist bei der Pflichtausrüstung) |
| `js/nachweis-vorschlaege.js` | Vorschläge für Nachweisarten (Deutschland, EU) mit Quelle und Prüfstand |
| `js/aktivitaeten.js` | Aktivität: Besatzung, Verantwortung, Prüfung der Befähigung, Fristen im Zeitraum, Überschneidungen |
| `js/logbuch.js` | Logbuch-Kern: Tage aus dem Zeitraum, Zuordnung der Ereignisse, Wechsel als Ereignis, festgehaltene Prüfung (nur Rechnung) |
| `js/motoren.js` | Motorschalter: Rechnung für Laufzeit, Leiste im Cockpit (ein bis zwei Schalter, ab drei „Motoren“) und Texte |
| `js/nachweise.js` | Nachweise: gemeinsame Angaben, Status der Gültigkeit |
| `js/personen.js` | Felder von Personen und Tieren |
| `js/dokumente.js` | Dokumente: Arten, Link-Prüfung, Felder |
| `js/werkstatt.js` | Werkstatt: Vorgänge (Störung, Arbeit) und Adressen, Beschreibung und Regeln |
| `js/kosten.js` | Kosten: Gruppen, Rhythmen, Felder und die Rechnung (Anteil am Jahr, Wertverlust, Nutzungstage, Kilometer, Vergleich) |
| `js/austausch.js` | Import und Export: Excel (.xlsx) und CSV lesen und schreiben, Spalten zuordnen, deutsche Zahlen und Daten umwandeln (nur Rechnung, ohne Fremdprogramm) |
| `js/reiseorte.js` | Reiseorte: Besuche, Ortserkennung, Frage nach der Ankunft, Plan gegen Ist, Auswertung pro Ort und Reise |
| `js/fristen.js` | Fristen: Felder, Wirkungen und die Rechnung (Kalender, Zähler, was zuerst eintritt) |
| `js/ansicht.js` | Was der Nutzer sieht |
| `js/hilfen.js` | Anzeige von Zahlen und Datum in deutscher Schreibweise |
| `js/version.js` | Die Versionsnummer (steht zusätzlich in `sw.js`, ein Test prüft, dass beide gleich sind) |
| `js/texte.js` | Kernsatz, Infotext, Copyright und „Neu im Programm“, nur hier |
| `icons/icon.svg` | Logo und App-Symbol. Zum Austauschen einfach diese Datei ersetzen. Das jetzige Zeichen ist nur ein Platzhalter |
| `sw.js`, `manifest.webmanifest` | Offline-Betrieb und Installation als App |
| `tests/` | Automatische Prüfungen |
| `docs/SCHRITTE.md` | Was fertig ist und was als Nächstes kommt |

## Regeln, die im Code gelten

- **Eine Quelle:** Die Oberfläche fragt nur bei `daten.js` nach, nie direkt im Speicher.
- **Handeingabe hat Vorrang, nichts wird überschrieben:** Jede Änderung ist ein neuer Eintrag „Korrektur zu …“, der alte bleibt im Verlauf sichtbar.
- **Aufbau auf Aufbau:** Jeder Schritt setzt auf dem vorigen auf. Die Datenbank-Version steht in `speicher.js`; spätere Änderungen kommen als Umstellung, ohne Daten zu verlieren.
- **Eigene Fahrzeugarten später möglich:** Die Felder einer Art sind Daten in `fahrzeugarten.js`.

## Prüfen

```
npm test
```
Braucht Node.js ab Version 18. Es werden keine weiteren Pakete benötigt.

## Hinweis

MobiMory ist eine Hilfestellung und trifft keine rechtliche Aussage. Die letzte
Verantwortung hat der verantwortliche Skipper bzw. Fahrer.
