# Konto-Dienst einrichten (Schritt 13a, Abgleich und Sicherung 13b)

Das ist die Anleitung für den kleinen Dienst, bei dem sich die App anmeldet. Er läuft bei Cloudflare, wie schon der Recherchedienst.
Die Namen der Menüpunkte im Cloudflare-Dashboard können etwas anders heißen. Wenn etwas nicht passt, schreib mir, was du siehst.

Es gibt **zwei Dienste**, damit nichts durcheinanderkommt:

| | Test-Dienst | Echter Dienst |
|---|---|---|
| Name des Workers | `mobimory-konto-test` | `mobimory-konto` |
| Datenbank | `mobimory-konten-test` | `mobimory-konten` |
| `ENTWICKLUNG` | **1** (der Code erscheint in der App statt per E-Mail) | **nicht setzen, nie** |
| E-Mail-Versand | nicht nötig | nötig, eigene Domain |
| Kosten | kostenlos (siehe Hinweis unten) | bezahlter Tarif, etwa 5 $ im Monat |

Mit dem Test-Dienst kannst du alles ausprobieren, auch ohne eigene Domain. Der echte Dienst kommt erst vor dem öffentlichen Start.

## 1. Datenbank anlegen (EU, nur beim Anlegen einstellbar)

1. Cloudflare-Dashboard → **D1 SQL Database** → **Create Database**.
2. Name: `mobimory-konten-test`.
3. Bei **Data location** den Punkt **Specify jurisdiction** wählen und **European Union** auswählen. Das geht nur jetzt, später nicht mehr.
4. **Create**.
5. In der neuen Datenbank den Reiter **Console** öffnen, den ganzen Inhalt der Datei `server/schema.sql` einfügen und ausführen. Fünf Tabellen entstehen. Mehrfaches Ausführen schadet nicht.

## 2. Dateispeicher anlegen (jetzt anlegen, gebraucht ab Schritt 13d)

1. Dashboard → **R2** → **Create bucket**, Name `mobimory-daten-test`.
2. Beim Speicherort die Jurisdiktion **EU** wählen. Auch das geht nur beim Anlegen.

## 3. Worker anlegen

1. Dashboard → **Workers & Pages** → **Create** → **Worker**. Cloudflare vergibt dem Worker selbst einen Namen (zum Beispiel `winter-violet-1a11`). Den Namen nimmst du so, wie er ist. **Deploy**.
2. **Edit code**. Den ganzen vorhandenen Text löschen. Den Programmtext **in zwei Teilen** einfügen (die Zwischenablage kürzt ihn sonst): zuerst `Programmtext-Teil-1.txt`, dann ans Ende `Programmtext-Teil-2.txt`. Beide zusammen sind der Inhalt von `server/konto-dienst.mjs`. **Deploy**.

## 4. Verbinden und einstellen

Im Worker unter **Settings**:

1. **Bindings** → Add → **D1 database**. (Am Tablet muss man für „Add binding“ herauszoomen.) Name der Bindung: `DB` (genau so). Datenbank: `mobimory-konten-test`.
2. **Bindings** → Add → **R2 bucket**. Name der Bindung: `DATEN`. Bucket: `mobimory-daten-test`. (Wird erst in 13d gebraucht.)
3. **Variables and Secrets** → **Add variable**. Im Fenster weitere Zeilen mit **+ Add** ergänzen. Ein gelber Hinweis zu Wrangler darf ignoriert werden. Einzutragen:
   - Typ **Text**: `ERLAUBTE_URSPRUENGE` = die Adresse der App ohne Pfad und ohne Schrägstrich am Ende. Vermutlich `https://ralphhasslacher34-create.github.io` (die genaue Adresse steht in GitHub unter *Settings > Pages*). Kein Punkt und kein Schrägstrich am Ende (ein Punkt am Ende lässt den Dienst die App ablehnen). Mehrere Adressen mit Komma trennen.
   - Typ **Text**: `ENTWICKLUNG` = `1` (**nur beim Test-Dienst**).
   - Typ **Secret (Geheimnis)**: `PASSWORT_PEPPER` = eine lange Zufallsfolge, mindestens 32 Zeichen, am besten 40 bis 60 Buchstaben und Ziffern aus einem Passwortgenerator. **Gut aufbewahren und nie ändern.** Ohne dieses Geheimnis passt kein Passwort mehr, und eine Wiederherstellung gibt es nicht.
4. Speichern und neu bereitstellen.

## 5. In der App eintragen und ausprobieren

1. Die Adresse des Workers steht oben im Worker (`https://mobimory-konto-test.….workers.dev`).
2. In MobiMory: **Funktionen → Konto**. Adresse eintragen, **Speichern**, **Verbindung testen**. Die App sagt, falls noch etwas fehlt (Tabellen, Geheimnis, E-Mail).
3. **Neues Konto mit Passwort** oder **Anmelden mit Code**. Beim Test-Dienst steht der Code auf dem Bildschirm.

## Hinweise

- **Kostenloser Tarif:** Das Prüfen eines Passworts rechnet länger als die 10 Millisekunden, die der kostenlose Tarif pro Anfrage erlaubt. Es kann sein, dass Anmeldungen mit Passwort beim Test-Dienst mit einem Fehler wie „Exceeded CPU“ scheitern. Das ist kein Fehler im Dienst, dann brauchst du auch für den Test den bezahlten Tarif (etwa 5 $ im Monat). Die Anmeldung mit Code ist davon weniger betroffen. Schreib mir den genauen Fehler, dann sehen wir weiter.
- **Passwort-Abdruck:** Cloudflare erlaubt höchstens 100 000 Runden. Das ist weniger als die Empfehlung von OWASP (600 000). Das gehört auf die Liste für den Datenschutz-Fachmann vor dem öffentlichen Start.
- **E-Mail im echten Dienst:** Dafür braucht es eine eigene Domain, die bei Cloudflare für den E-Mail-Versand eingerichtet ist (Dashboard → Email Service), und die Bindung `EMAIL` (Typ *Send Email*) sowie die Variable `ABSENDER` (zum Beispiel `konto@deine-domain.de`). Nach der Cloudflare-Dokumentation sind im bezahlten Tarif 3 000 Mails im Monat enthalten, danach etwa 0,35 $ je 1 000. Vor dem Start die aktuellen Preise prüfen.
- **Nicht im Repository:** Das Geheimnis `PASSWORT_PEPPER` gehört nie in eine Datei, nie in GitHub und nie in einen Chat.
- **Wenn etwas schiefgeht:** Unter *Workers → mobimory-konto-test → Logs* stehen Fehlermeldungen. Schreib sie mir einfach ab.

## Einrichten mit wrangler (nur falls du es lieber so machst)

`server/wrangler.jsonc` ist dafür vorbereitet. Datenbank mit `npx wrangler d1 create mobimory-konten --jurisdiction eu`, Tabellen mit `npx wrangler d1 execute mobimory-konten --remote --file=schema.sql`, Geheimnis mit `npx wrangler secret put PASSWORT_PEPPER`, dann `npx wrangler deploy`.

## Update auf 13b (Abgleich und Sicherung, seit 2.0.65)

Der Dienst bleibt derselbe Worker, Datenbank, Variablen und Geheimnis bleiben. Zwei Dinge sind neu:

1. **Neue Tabellen:** In der D1-Datenbank → **Console** die Zeilen aus `SQL-einzeln.txt` nacheinander ausführen (sechs Zeilen, jede einzeln). Vorhandene Daten bleiben.
2. **Neuer Programmtext:** Worker → **Edit code**, alles löschen, `Programmtext-Teil-1.txt` einfügen, dann `Programmtext-Teil-2.txt` ans Ende. **Deploy**.

Prüfen: Adresse des Workers mit `/gesundheit` aufrufen. Es muss `"version":"13b-1"` und `"abgleich":true` stehen. In der App: Konto → Verbindung testen.
