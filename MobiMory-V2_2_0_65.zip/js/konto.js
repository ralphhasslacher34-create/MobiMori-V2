/*
 * Konto (Schritt 13a, seit 2.0.64): Prüfungen und Texte für die Anmeldung beim MobiMory-Konto-Dienst.
 * Die App arbeitet weiter ohne Konto und ohne Netz. Das Konto ist ein Zusatz.
 * Reine Funktionen, kein Netz, kein Speicher. Das Senden und Speichern steht in daten.js.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var MIN_PASSWORT = 10;
  var MAX_PASSWORT_BYTES = 200;
  var LOESCH_WORT = 'LÖSCHEN';

  function text(x) { return x === null || x === undefined ? '' : String(x).trim(); }

  /* Adresse des Konto-Dienstes: https, mit Punkt im Namen. Nur beim Entwickeln am eigenen Rechner ist http://localhost erlaubt. */
  function dienstAdresse(roh) {
    var t = text(roh);
    if (!t) return { ok: false, fehler: 'Bitte die Adresse des Konto-Dienstes eintragen.' };
    if (/\s/.test(t)) return { ok: false, fehler: 'Die Adresse darf keine Leerzeichen enthalten.' };
    var lokal = /^http:\/\/(localhost|127\.0\.0\.1)(:\d{1,5})?(\/|$)/i.test(t);
    if (!lokal && !/^https:\/\//i.test(t)) return { ok: false, fehler: 'Die Adresse muss mit https:// beginnen.' };
    var m = /^(https?):\/\/([^\/?#]+)([^?#]*)/i.exec(t);
    if (!m || !/^[a-z0-9.\-]+(:\d{1,5})?$/i.test(m[2]) || (!lokal && m[2].indexOf('.') < 0)) return { ok: false, fehler: 'Das ist keine gültige Adresse.' };
    var pfad = m[3].replace(/\/+$/, '').replace(/\/(gesundheit|konto)(\/.*)?$/i, '');
    return { ok: true, url: m[1].toLowerCase() + '://' + m[2].toLowerCase() + pfad };
  }

  function email(roh) {
    var t = text(roh).toLowerCase();
    if (!t) return { ok: false, fehler: 'Bitte die E-Mail-Adresse eintragen.' };
    if (t.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(t)) return { ok: false, fehler: 'Das ist keine gültige E-Mail-Adresse.' };
    return { ok: true, email: t };
  }

  function byteLaenge(s) {
    var n = 0;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c < 0x80) n += 1; else if (c < 0x800) n += 2;
      else if (c >= 0xd800 && c <= 0xdbff) { n += 4; i++; } else n += 3;
    }
    return n;
  }

  /* Das Passwort wird nicht getrimmt: Leerzeichen gehören dazu. */
  function passwort(roh) {
    var p = roh === null || roh === undefined ? '' : String(roh);
    if (!p) return { ok: false, fehler: 'Bitte ein Passwort eintragen.' };
    if (p.length < MIN_PASSWORT) return { ok: false, fehler: 'Das Passwort ist zu kurz. Es braucht mindestens ' + MIN_PASSWORT + ' Zeichen.' };
    if (byteLaenge(p) > MAX_PASSWORT_BYTES) return { ok: false, fehler: 'Das Passwort ist zu lang.' };
    return { ok: true, passwort: p };
  }

  function code(roh) {
    var t = text(roh).replace(/\s+/g, '');
    if (!/^\d{6}$/.test(t)) return { ok: false, fehler: 'Der Code besteht aus sechs Ziffern.' };
    return { ok: true, code: t };
  }

  function loeschWort(roh) {
    return text(roh).toUpperCase() === LOESCH_WORT || text(roh).toUpperCase() === 'LOESCHEN' ? { ok: true } : { ok: false, fehler: 'Zum Löschen bitte das Wort ' + LOESCH_WORT + ' eintippen.' };
  }

  /* Der Dienst schickt seine Fehler als { ok: false, error, feld? }. Das Gerät sagt in einfachen Worten, was los ist. */
  function fehlerText(err) {
    var s = err && err.status, m = err && err.message ? String(err.message) : '';
    if (s === 403) return 'Der Dienst lehnt diese App-Adresse ab. Im Dienst muss sie bei ERLAUBTE_URSPRUENGE stehen.';
    if (s === 401 || s === 400 || s === 429 || s === 502 || s === 503) return m || 'Der Dienst hat die Anfrage abgelehnt.';
    if (s) return 'Der Dienst konnte die Anfrage nicht ausführen' + (m ? ': ' + m : '.');
    if (err && err.name === 'AbortError') return 'Der Dienst hat zu lange gebraucht. Versuche es später noch einmal.';
    return 'Keine Verbindung zum Dienst. Prüfe das Netz und die Adresse. Ohne Netz geht das Anmelden nicht, die App selbst läuft weiter.';
  }

  MM.Konto = {
    MIN_PASSWORT: MIN_PASSWORT, LOESCH_WORT: LOESCH_WORT, GERAET_NAME_MAX: 60,
    dienstAdresse: dienstAdresse, email: email, passwort: passwort, code: code, loeschWort: loeschWort, fehlerText: fehlerText,
    TEXT_LOKAL: 'Deine Daten liegen auf diesem Gerät. Ein Konto brauchst du nur, wenn du später auf mehreren Geräten arbeiten, sichern oder teilen willst.',
    TEXT_DATEN: 'Auf dem Server speichert der Dienst deine E-Mail-Adresse, einen Abdruck des Passworts (nie das Passwort selbst) und deinen Datenraum. Beim Abgleich kommen Fahrzeuge, Komponenten, Fristen, Störungen, Aktivitäten, Besatzung, Ereignisse, Zähler und Prüfergebnisse dazu. Nachweise samt Scan, Geburtsdatum, Wohnort, GPS-Spur, Fotos und Notizen bleiben auf deinen Geräten.',
    TEXT_ABGLEICH: 'Hier gleichst du deine Fahrzeugdaten mit anderen Geräten ab, auf denen du mit demselben Konto angemeldet bist. Der Abgleich läuft nur, wenn du auf den Knopf tippst. Ohne Netz arbeitest du wie bisher weiter.',
    TEXT_ABGLEICH_REGELN: 'Wird dieselbe Sache auf zwei Geräten geändert, gilt bei Verläufen der zuletzt gemachte Eintrag, und der frühere bleibt im Verlauf sichtbar. Bei allem anderen gilt der Stand, der zuerst beim Dienst war, deine Fassung wird aufgehoben. Wurde etwas auf einem Gerät gelöscht und auf dem anderen geändert, bleibt es erhalten. Nach einer Wiederherstellung aus einer Sicherung gleicht der nächste Abgleich wieder mit dem Dienst ab, bei Unterschieden gilt dessen Stand.',
    TEXT_SICHERUNG: 'Die Sicherung enthält alle deine Daten auf diesem Gerät, aber ohne Dokumente, Scans und Fotos. Sie wird auf deinem Gerät mit deinem Schlüsselwort verschlüsselt, bevor sie zum Dienst geht. Der Dienst kann sie nicht lesen. Das Schlüsselwort kennt nur du. Vergisst du es, kann niemand die Sicherung öffnen, auch ich nicht.',
    TEXT_ABMELDEN: 'Beim Abmelden bleiben alle Daten auf diesem Gerät. Nur die Verbindung zum Konto wird beendet.'
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
