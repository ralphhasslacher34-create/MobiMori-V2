/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.101';
  MM.STUFE = 'Bildschirm bleibt im Cockpit an, Hinweis zur Aufzeichnung nur bei offener App, Ergebnisse des Reisechecks als Regeln in Orten und Gebieten, Ortserkennung mit 150 m, App-Version beim Konto-Dienst; Dokument erfassen (Smart Capture, Stufe 1): Ausweis, Führerschein, Funkzeugnis und Fahrzeugpapiere von Foto oder Scan lesen, mit dem Lesedienst (Google, EU) für Konten ab Mittel, sonst auf dem Gerät; Verwaltung mit Statistik und Zahlungseingängen für Admins; Schadensbericht mit automatischer Störung und Fotos; Planung je Tag mit Karte des Tages; Planung der ganzen Aktivität unverändert';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
