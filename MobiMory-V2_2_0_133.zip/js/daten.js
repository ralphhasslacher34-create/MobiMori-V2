/*
 * Daten: die EINE Tür zu allen Fahrzeugdaten.
 *
 * Regeln aus den V2-Festlegungen, die hier gelten:
 *  - Eine Quelle: alle Teile der App fragen nur hier nach.
 *  - Handeingabe hat Vorrang. Es wird nichts überschrieben: Jede Änderung
 *    ist ein neuer Eintrag "Korrektur zu ...", der alte bleibt sichtbar.
 *  - Nichts wird gelöscht.
 *  - Jeder Eintrag nennt seine Herkunft (hier: "hand").
 *
 * Aufbau der gespeicherten Daten:
 *  datenraum   { id, name, erstelltAm }
 *  fahrzeug    { id, datenraumId, art, erstelltAm }
 *  eintrag     { id, fahrzeugId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  komponente  { id, fahrzeugId, parentId, art, erstelltAm }
 *              parentId = null: Hauptkomponente (dann gilt "art"), sonst gehört
 *              sie zu einer anderen Komponente ("gehört zu").
 *  komponenteneintrag { id, komponenteId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  zaehler     { id, fahrzeugId, komponenteId|null, art, erstelltAm }      (Name im Verlauf)
 *  zaehlerstand { id, zaehlerId, nr, wert, datum, notiz, quelle, erstelltAm }
 *  frist       { id, fahrzeugId, komponenteId|null, erstelltAm }            (Angaben im Verlauf)
 *  verlauf     { id, objektTyp, objektId, nr, werte, quelle, korrekturZu, erstelltAm }
 *  durchfuehrung { id, fristId, datum, zaehlerstand, notiz, art, quelle, erstelltAm }
 *  dokument    { id, fahrzeugId, komponenteId|null, vorgangId|null, erstelltAm }  (Angaben im Verlauf; vorgangId seit 2.0.26: hängt am Werkstatt-Vorgang)
 *  datei       { id, dokumentId, name, mime, groesse, inhalt, erstelltAm }  (inhalt = die Datei selbst)
 *  person      { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  tier        { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  nachweisart { id, datenraumId, erstelltAm }                              (Angaben im Verlauf; offene Liste)
 *  nachweis    { id, datenraumId, artId, besitzerTyp, besitzerId, erstelltAm }  (Angaben im Verlauf)
 *  nachweisdatei { id, nachweisId, name, mime, groesse, inhalt, erstelltAm } (Scan oder Foto; seit 2.0.66 mit Schlüsselwort verschlüsselt auf dem Konto, sonst nur lokal)
 *  aktivitaet  { id, datenraumId, erstelltAm }                              (Angaben im Verlauf)
 *  aktivitaetsart { id, datenraumId, erstelltAm }                           (offene Liste, Angaben im Verlauf)
 *  besatzung   { id, aktivitaetId, personId, erstelltAm }                   (Rolle und "dabei von bis" im Verlauf)
 *  verantwortung { id, aktivitaetId, personId, ab, erstelltAm }             (Wechsel der Verantwortlichen, nur anhängen)
 *  anforderung { id, datenraumId, fahrzeugId, erstelltAm }                  (welche Nachweise Skipper und Fahrer brauchen)
 *  tagesabschnitt { id, datenraumId, aktivitaetId, herkunft, erstelltAm }   (Angaben im Verlauf; herkunft: vorbereitet oder hand)
 *  tagespruefung { id, datenraumId, aktivitaetId, abschnittId, stand, erstelltAm } (festgehaltene Prüfung zum Tagesbeginn, nur anhängen)
 *  ereignis    { id, datenraumId, aktivitaetId, abschnittId, erstelltAm }   (Angaben im Verlauf; Foto in ereignisdatei)
 *  ereignisart { id, datenraumId, erstelltAm }                              (offene Liste, Angaben im Verlauf)
 *  ereignisdatei { id, ereignisId, name, mime, groesse, inhalt, erstelltAm } (Foto; seit 2.0.66 auf dem Konto)
 *  kosten      { id, datenraumId, fahrzeugId, erstelltAm }                  (Angaben im Verlauf: Gruppe, Betrag, Rhythmus, Datum, Verweise auf Komponente, Aktivität, Vorgang; seit 2.0.27)
 *  besuche     { id, datenraumId, aktivitaetId, fahrzeugId, ereignisId, erstelltAm }  (Angaben im Verlauf: Status, Ort, Standort, Datum, Ausstattung, Plan, Notiz; seit 2.0.28)
 *  kostenstamm { id 'ks-<fahrzeugId>', datenraumId, fahrzeugId, erstelltAm } (Wert, Wertverlust, Vergleichspreis im Verlauf; seit 2.0.27)
 *  reisecheck  { id, datenraumId, aktivitaetId, fahrzeugId, erstelltAm, stand, anfrage, namen, ergebnis, dienst }  (Ergebnis des Online-Checks; seit 2.0.38)
 *  einstellung { id, ... }                                                  (zum Beispiel id "sicherung": letzteSicherung, erinnerungTage)
 *
 * "werte" enthält Bezeichnung und alle Felder. Der aktuelle Stand ist der
 * Eintrag mit der höchsten Nummer.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Holt JSON aus dem Netz (Wetter, Tide). Ohne Netz oder bei Fehler wird die Zusage abgelehnt, der Aufrufer behandelt das. */
  function standardHoleJson(url) {
    var f = global.fetch;
    if (typeof f !== 'function') return Promise.reject(new Error('Kein Netz verfügbar.'));
    var ctl = typeof global.AbortController === 'function' ? new global.AbortController() : null;
    var timer = ctl ? global.setTimeout(function () { ctl.abort(); }, 20000) : null;
    return f(url, ctl ? { signal: ctl.signal } : undefined).then(function (r) {
      if (timer) global.clearTimeout(timer);
      if (!r.ok) { var fe = new Error('Antwort ' + r.status); fe.status = r.status; throw fe; }
      return r.json();
    }, function (e) { if (timer) global.clearTimeout(timer); throw e; });
  }

  function neueId(praefix) {
    var c = global.crypto;
    if (c && typeof c.randomUUID === 'function') return praefix + '-' + c.randomUUID();
    return praefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
  }

  function Daten(speicher, optionen) {
    this.speicher = speicher;
    this.jetzt = (optionen && optionen.jetzt) || function () { return new Date().toISOString(); };
    /* Holt eine Antwort aus dem Netz (nur für Wetter und Tide, seit 2.0.33). Für Tests austauschbar. */
    this.holeJson = (optionen && optionen.holeJson) || standardHoleJson;
    /* Schickt eine Anfrage an den Recherche-Dienst des Reisechecks (seit 2.0.38). Für Tests austauschbar. */
    this.sendeJsonFn = (optionen && optionen.sendeJson) || null;
    /* Schickt eine Anfrage an den Konto-Dienst (seit 2.0.64). Für Tests austauschbar. */
    this.kontoAnfrageFn = (optionen && optionen.kontoAnfrage) || null;
    this.kontoBytesFn = (optionen && optionen.kontoBytes) || null;
    this.datenraumId = null;
  }

  /* Beim ersten Start entsteht der eigene Datenraum auf diesem Gerät. */
  Daten.prototype.starten = function () {
    var self = this;
    return this.speicher.alle('datenraeume').then(function (liste) {
      if (liste.length) { self.datenraumId = liste[0].id; return liste[0]; }
      var dr = { id: neueId('dr'), name: 'Mein Datenraum', erstelltAm: self.jetzt() };
      return self.speicher.speichern('datenraeume', dr).then(function () {
        self.datenraumId = dr.id;
        return dr;
      });
    }).then(function (dr) {
      /* Eigene Fahrzeugarten und Änderungen am Baum laden (seit 2.0.16). Ohne Angabe gilt der mitgelieferte Baum. */
      return self.speicher.holen('einstellungen', 'fahrzeugarten').then(function (dok) {
        MM.Fahrzeugarten.konfigurieren(dok);
        return dr;
      });
    }).then(function (dr) {
      /* Seit 2.0.86: Das Dokument „leihreisen“ (Plan, Check und Tagebuch der Leihreise, 2.0.79) gibt es nicht mehr. Alte Einträge werden einmalig gelöscht (Testdaten). */
      return self.speicher.mehrereLoeschen([{ tabelle: 'einstellungen', id: 'leihreisen' }]).then(function () { return dr; }, function () { return dr; });
    });
  };

  /* ---------- Prüfen und in saubere Werte umwandeln ---------- */
  function optWert(o) { return typeof o === 'string' ? o : o.wert; }

  function pruefeWerte(felder, roh, jahr, optionen) {
    var ohneBez = !!(optionen && optionen.ohneBezeichnung);
    var werte = {};
    var fehler = {};
    roh = roh || {};

    if (!ohneBez) {
      var bez = String(roh.bezeichnung == null ? '' : roh.bezeichnung).trim();
      if (!bez) fehler.bezeichnung = (optionen && optionen.bezeichnungFehler) || 'Bitte eine Bezeichnung eingeben, zum Beispiel „Fahrzeug A“.';
      werte.bezeichnung = bez;
    }

    felder.forEach(function (f) {
      if (f.typ === 'mehrfach') {
        var gewaehlt = Array.isArray(roh[f.key]) ? roh[f.key] : [];
        werte[f.key] = f.optionen.filter(function (o) { return gewaehlt.indexOf(optWert(o)) >= 0; }).map(optWert);
        return;
      }
      if (f.typ === 'reihenfolge') {
        /* Geordnete Liste (seit 2.0.123, Zwischenziele): Die Reihenfolge der Eingabe bleibt. Unbekannte und doppelte Einträge entfallen. */
        var geordnet = Array.isArray(roh[f.key]) ? roh[f.key] : [], erlaubt = {}, gesehenR = {}, saubereR = [];
        f.optionen.forEach(function (o) { erlaubt[optWert(o)] = true; });
        geordnet.forEach(function (x) { if (erlaubt[x] && !gesehenR[x]) { gesehenR[x] = true; saubereR.push(x); } });
        werte[f.key] = saubereR;
        return;
      }
      if (f.typ === 'fahrzeuge') {
        /* Kennungen zugeordneter Fahrzeuge (seit 2.0.103): ohne Leere und Doppelte, die Reihenfolge bleibt. Ob es die Fahrzeuge gibt, prüft fahrzeugListenPruefen. */
        var kennungen = Array.isArray(roh[f.key]) ? roh[f.key] : [], gesehenK = {}, saubereK = [];
        kennungen.forEach(function (x) {
          var t = String(x == null ? '' : x).trim();
          if (t && !gesehenK[t] && saubereK.length < 100) { gesehenK[t] = true; saubereK.push(t); }
        });
        werte[f.key] = saubereK;
        return;
      }
      if (f.typ === 'liste') {
        var zeilen = Array.isArray(roh[f.key]) ? roh[f.key] : [];
        var sauber = [];
        zeilen.forEach(function (z) {
          var n = String(z && z.name != null ? z.name : '').trim();
          var w = String(z && z.wert != null ? z.wert : '').trim();
          /* Seit 2.0.45 kann eine Zeile auch eine Einheit und eine Bezugsgröße haben. Alte Zeilen haben nur Name und Wert und bleiben so. */
          var e = String(z && z.einheit != null ? z.einheit : '').trim();
          var b = String(z && z.bezug != null ? z.bezug : '').trim();
          if (!n && !w && !e && !b) return;
          if (!n || !w) fehler[f.key] = 'Bitte bei jedem Merkmal Name und Wert eingeben.';
          else if (e.length > MM.Komponenten.MAX_EINHEIT) fehler[f.key] = 'Die Einheit darf höchstens ' + MM.Komponenten.MAX_EINHEIT + ' Zeichen haben.';
          else if (b.length > MM.Komponenten.MAX_BEZUG) fehler[f.key] = 'Die Bezugsgröße darf höchstens ' + MM.Komponenten.MAX_BEZUG + ' Zeichen haben.';
          var zeile = { name: n, wert: w };
          if (e) zeile.einheit = e;
          if (b) zeile.bezug = b;
          sauber.push(zeile);
        });
        werte[f.key] = sauber;
        return;
      }

      var v = roh[f.key];
      v = (v === undefined || v === null) ? '' : v;
      if (typeof v === 'string') v = v.trim();

      if (f.typ === 'text') {
        if (f.maxLaenge && String(v).length > f.maxLaenge) fehler[f.key] = 'Bitte höchstens ' + f.maxLaenge + ' Zeichen eingeben.';
        werte[f.key] = v === '' ? null : String(v);
        return;
      }

      if (f.typ === 'auswahl') {
        if (v === '') { werte[f.key] = null; return; }
        if (!f.optionen.some(function (o) { return optWert(o) === v; })) { fehler[f.key] = 'Bitte eine Möglichkeit aus der Liste wählen.'; }
        werte[f.key] = v;
        return;
      }

      if (f.typ === 'zeit') {
        if (v === '') { werte[f.key] = null; return; }
        if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(v)) { fehler[f.key] = 'Bitte eine Uhrzeit eingeben, zum Beispiel 14:30.'; werte[f.key] = null; } else { werte[f.key] = v; }
        return;
      }
      if (f.typ === 'datum') {
        if (v === '') { werte[f.key] = null; return; }
        var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
        var d = m ? new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])) : null;
        if (!d || d.getUTCFullYear() !== +m[1] || d.getUTCMonth() !== +m[2] - 1 || d.getUTCDate() !== +m[3]) {
          fehler[f.key] = 'Bitte ein gültiges Datum eingeben.';
          werte[f.key] = null;
        } else { werte[f.key] = v; }
        return;
      }

      /* zahl und ganzzahl: Komma oder Punkt als Dezimalzeichen erlaubt */
      if (v === '') { werte[f.key] = null; return; }
      var text = String(v).replace(/\s/g, '').replace(',', '.');
      var n = /^-?\d+(\.\d+)?$/.test(text) ? Number(text) : NaN;
      if (isNaN(n)) {
        fehler[f.key] = f.typ === 'ganzzahl' ? 'Bitte eine ganze Zahl eingeben.' : 'Bitte eine Zahl eingeben, zum Beispiel 2,5.';
        werte[f.key] = null;
        return;
      }
      if (f.typ === 'ganzzahl' && Math.floor(n) !== n) { fehler[f.key] = 'Bitte eine ganze Zahl eingeben.'; werte[f.key] = null; return; }
      if (n < 0) { fehler[f.key] = 'Die Zahl darf nicht negativ sein.'; werte[f.key] = null; return; }
      if (f.key === 'baujahr' && (n < f.min || n > jahr + 1)) {
        fehler[f.key] = 'Bitte ein Baujahr zwischen ' + f.min + ' und ' + (jahr + 1) + ' eingeben.';
        werte[f.key] = null; return;
      }
      if (f.min !== undefined && f.key !== 'baujahr' && n < f.min) { fehler[f.key] = 'Der Wert muss mindestens ' + f.min + ' sein.'; werte[f.key] = null; return; }
      if (f.max !== undefined && n > f.max) { fehler[f.key] = 'Der Wert darf höchstens ' + f.max + ' sein.'; werte[f.key] = null; return; }
      werte[f.key] = n;
    });

    return { werte: werte, fehler: fehler, ok: Object.keys(fehler).length === 0 };
  }

  Daten.prototype.pruefen = function (artId, roh) {
    var p = pruefeWerte(MM.Fahrzeugarten.felder(artId), roh, new Date(this.jetzt()).getFullYear());
    /* Anhänger ziehen geht nur mit Antrieb (seit 2.0.103). */
    if (p.werte.antrieb === 'ohne' && Array.isArray(p.werte.eignung) && p.werte.eignung.indexOf('anhaenger_ziehen') >= 0) {
      p.fehler.eignung = 'Anhänger ziehen geht nur bei einem Fahrzeug mit Antrieb. Nimm den Haken heraus oder wähle „Mit Antrieb“.';
      p.ok = false;
    }
    return p;
  };

  /*
   * Zugeordnete Fahrzeuge (seit 2.0.103): Zugfahrzeuge eines Anhängers und Boote auf einem Trailer. Jede Kennung muss ein Fahrzeug dieses Datenraums sein,
   * nicht das eigene und nicht abgegeben; Zugfahrzeuge sind Landfahrzeuge (kein Anhänger), Boote sind Wasserfahrzeuge.
   * Geprüft wird nur, was gegenüber dem bisherigen Stand (bisher) neu dazukommt. Gibt { feldKey: Fehlertext } zurück, leer wenn alles stimmt.
   */
  Daten.prototype.fahrzeugListenPruefen = function (artId, eigeneId, werte, bisher) {
    var keys = MM.Fahrzeugarten.felder(artId).filter(function (f) { return f.typ === 'fahrzeuge'; }).map(function (f) { return f.key; });
    var neu = {};
    keys.forEach(function (k) {
      var alt = (bisher && Array.isArray(bisher[k])) ? bisher[k] : [];
      var l = (werte[k] || []).filter(function (id) { return alt.indexOf(id) < 0; });
      if (l.length) neu[k] = l;
    });
    if (!Object.keys(neu).length) return Promise.resolve({});
    return this.fahrzeugListe({ alle: true }).then(function (liste) {
      var nachId = {}; liste.forEach(function (x) { nachId[x.fahrzeug.id] = x; });
      var fehler = {};
      Object.keys(neu).forEach(function (k) {
        neu[k].forEach(function (id) {
          if (fehler[k]) return;
          var x = nachId[id], a = x ? MM.Fahrzeugarten.art(x.fahrzeug.art) : null, name = x ? '„' + x.aktuell.werte.bezeichnung + '“' : '';
          if (id === eigeneId) fehler[k] = 'Ein Fahrzeug kann nicht zu sich selbst gehören.';
          else if (!x) fehler[k] = 'Ein gewähltes Fahrzeug wurde nicht gefunden.';
          else if (x.fahrzeug.abgabe) fehler[k] = name + ' ist abgegeben und steht nicht zur Auswahl.';
          else if (k === 'zugfahrzeuge' && (!a || a.welt !== 'land' || MM.Fahrzeugarten.istAnhaenger(x.fahrzeug.art))) fehler[k] = name + ' kann keinen Anhänger ziehen. Gewählt werden Landfahrzeuge mit Antrieb.';
          else if (k === 'bootsliste' && (!a || a.welt !== 'wasser')) fehler[k] = name + ' ist kein Boot.';
        });
      });
      return fehler;
    });
  };

  /* Die Auswahl für die Listen „Zugfahrzeuge“ und „Boote auf diesem Trailer“ (seit 2.0.103): { zugfahrzeuge: [{ wert, label }], bootsliste: [...] }.
     Nicht angeboten werden das Fahrzeug selbst, abgegebene Fahrzeuge, Anhänger als Zugfahrzeuge und Fahrzeuge der falschen Welt. */
  Daten.prototype.fahrzeugListenAuswahl = function (eigeneId) {
    return this.fahrzeugListe().then(function (liste) {
      var res = { zugfahrzeuge: [], bootsliste: [] };
      liste.forEach(function (x) {
        if (x.fahrzeug.id === eigeneId) return;
        var a = MM.Fahrzeugarten.art(x.fahrzeug.art);
        if (!a) return;
        var o = { wert: x.fahrzeug.id, label: x.aktuell.werte.bezeichnung + ' (' + a.name + ')' };
        if (a.welt === 'land' && !MM.Fahrzeugarten.istAnhaenger(x.fahrzeug.art)) res.zugfahrzeuge.push(o);
        if (a.welt === 'wasser') res.bootsliste.push(o);
      });
      return res;
    });
  };

  /* Namen aller Fahrzeuge dieses Datenraums nach Kennung, auch abgegebene (gekennzeichnet): { id: { name, abgegeben } } (seit 2.0.103). */
  Daten.prototype.fahrzeugNamen = function () {
    return this.fahrzeugListe({ alle: true }).then(function (liste) {
      var m = {};
      liste.forEach(function (x) { m[x.fahrzeug.id] = { name: x.aktuell.werte.bezeichnung, abgegeben: !!x.fahrzeug.abgabe }; });
      return m;
    });
  };

  Daten.prototype.pruefenKomponente = function (roh) {
    var p = pruefeWerte(MM.Komponenten.felder(), roh, new Date(this.jetzt()).getFullYear());
    var w = p.werte;
    if (w.eingebautAm && w.ausgebautAm && w.ausgebautAm < w.eingebautAm && !p.fehler.ausgebautAm) {
      p.fehler.ausgebautAm = 'Der Ausbau kann nicht vor dem Einbau liegen.';
      p.ok = false;
    }
    return p;
  };

  /* ---------- Unterschiede zwischen zwei Ständen ---------- */
  function gleich(a, b) {
    if (a === b) return true;
    if (a && b && typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) return JSON.stringify(a) === JSON.stringify(b);
    var la = Array.isArray(a) ? a : (a === null || a === undefined ? [] : null);
    var lb = Array.isArray(b) ? b : (b === null || b === undefined ? [] : null);
    if (la && lb) return JSON.stringify(la) === JSON.stringify(lb);
    return false;
  }

  function unterschiedeFelder(felder, alt, neu) {
    var liste = [{ key: 'bezeichnung', label: 'Bezeichnung' }].concat(felder);
    var res = [];
    liste.forEach(function (f) {
      var a = alt[f.key] === undefined ? null : alt[f.key];
      var n = neu[f.key] === undefined ? null : neu[f.key];
      if (!gleich(a, n)) res.push({ key: f.key, label: f.label, feld: f, alt: a, neu: n });
    });
    return res;
  }

  /* „Gehört zu“ (seit 2.0.45) gilt für jede Fahrzeugart. Es steht als Kennung des anderen Fahrzeugs in den Werten (hauptfahrzeugId). */
  var ZUORDNUNG_FELD = { key: 'hauptfahrzeugId', label: 'Gehört zu', typ: 'text' };

  Daten.prototype.unterschiede = function (artId, alt, neu) {
    return unterschiedeFelder(MM.Fahrzeugarten.felder(artId).concat([ZUORDNUNG_FELD]), alt, neu);
  };

  function neuester(eintraege) {
    return eintraege.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
  }
  function nachNr(a, b) { return a.nr - b.nr; }

  /* ---------- Fahrzeuge ---------- */
  /*
   * Gleiches Fahrzeug nicht doppelt (seit 2.0.46): Kennzeichen, Registriernummer, FIN und HIN gelten als Kennung. Verglichen wird ohne
   * Groß- und Kleinschreibung, Leerzeichen, Striche und Punkte (dieselbe Regel wie MM.Austausch.kennungNorm beim Import, ein Test hält beide gleich).
   * kennungTreffer(werte, ausserId) gibt die schon vorhandenen Fahrzeuge des Datenraums mit gleicher Kennung zurück, auch abgegebene
   * (gekennzeichnet), jeweils { id, name, artName, abgegeben, abgabeDatum }. Ohne Kennung gibt es keinen Treffer.
   */
  var KENNUNG_FELDER = ['kennzeichen', 'registriernummer', 'fin', 'hin'];
  function kennungNorm(s) { return String(s == null ? '' : s).toUpperCase().replace(/[\s\-.]/g, ''); }
  function kennungenVon(werte) {
    var res = [];
    KENNUNG_FELDER.forEach(function (k) {
      var n = werte && werte[k] ? kennungNorm(werte[k]) : '';
      if (n && res.indexOf(n) < 0) res.push(n);
    });
    return res;
  }
  /* Die Kennung, wie sie der Nutzer eingegeben hat (für den Hinweistext). */
  function kennungAnzeige(werte, treffer) {
    var da = {}; treffer.forEach(function (t) { (t.kennungen || []).forEach(function (n) { da[n] = true; }); });
    for (var i = 0; i < KENNUNG_FELDER.length; i++) {
      var v = werte && werte[KENNUNG_FELDER[i]];
      if (v && da[kennungNorm(v)]) return String(v).trim();
    }
    return '';
  }
  Daten.prototype.kennungTreffer = function (werte, ausserId) {
    var ids = kennungenVon(werte);
    if (!ids.length) return Promise.resolve([]);
    return this.fahrzeugListe({ alle: true }).then(function (liste) {
      return liste.filter(function (x) {
        if (ausserId && x.fahrzeug.id === ausserId) return false;
        var da = kennungenVon(x.aktuell.werte);
        return ids.some(function (k) { return da.indexOf(k) >= 0; });
      }).map(function (x) {
        var a = MM.Fahrzeugarten.art(x.fahrzeug.art), da = kennungenVon(x.aktuell.werte);
        return { id: x.fahrzeug.id, name: x.aktuell.werte.bezeichnung, artName: a ? a.name : '', abgegeben: !!x.fahrzeug.abgabe,
          abgabeDatum: x.fahrzeug.abgabe ? x.fahrzeug.abgabe.datum : null, kennungen: da.filter(function (k) { return ids.indexOf(k) >= 0; }) };
      });
    });
  };
  /* Der Satz zur Rückfrage: welches Fahrzeug es schon gibt. */
  function kennungTrefferText(werte, treffer) {
    var kennung = kennungAnzeige(werte, treffer);
    var namen = treffer.map(function (t) { return '„' + t.name + '“' + (t.abgegeben ? ' (abgegeben' + (t.abgabeDatum ? ' am ' + (MM.Hilfen ? MM.Hilfen.datum(t.abgabeDatum) : t.abgabeDatum) : '') + ')' : ''); }).join(', ');
    return 'Es gibt schon ' + (treffer.length === 1 ? 'ein Fahrzeug' : treffer.length + ' Fahrzeuge') + ' mit der Kennung „' + kennung + '“: ' + namen + '.';
  }
  Daten.prototype.kennungTrefferText = function (werte, treffer) { return kennungTrefferText(werte, treffer); };

  /* opt.trotzdem = true: ausdrücklich bestätigt, dass trotz gleicher Kennung ein neues Fahrzeug angelegt wird. */
  Daten.prototype.fahrzeugAnlegen = function (artId, roh, opt) {
    var gewaehlt = MM.Fahrzeugarten.art(artId);
    if (!gewaehlt || gewaehlt.gruppe) {
      return Promise.resolve({ ok: false, fehler: { art: 'Bitte zuerst die Fahrzeugart wählen.' } });
    }
    if (!MM.Fahrzeugarten.sichtbar(artId)) {
      return Promise.resolve({ ok: false, fehler: { art: 'Diese Fahrzeugart ist ausgeblendet. Blende sie unter „Fahrzeugarten verwalten“ wieder ein.' } });
    }
    var p = this.pruefen(artId, roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var self = this;
    var haupt = roh && roh.hauptfahrzeugId ? String(roh.hauptfahrzeugId).trim() : '';
    /* Fahrzeug-Grenze der Stufe (seit 2.0.70): zuerst prüfen, eine Rückfrage zur Kennung wäre sonst sinnlos. */
    return this.fahrzeugGrenzePruefen(1).then(function (g) {
      if (!g.ok) return { ok: false, grenze: g, fehler: { allgemein: g.text } };
      return self.kennungTreffer(p.werte, null).then(function (treffer) {
      /* Gleiche Kennung: nichts anlegen, erst fragen (seit 2.0.46). */
      if (treffer.length && !(opt && opt.trotzdem)) {
        return { ok: false, doppelt: treffer, fehler: { allgemein: kennungTrefferText(p.werte, treffer) } };
      }
      return Promise.all([self.zuordnungPruefen(null, haupt || null), self.fahrzeugListenPruefen(artId, null, p.werte, null)]).then(function (zl) {
        var zf = zl[0];
        if (zf) return { ok: false, fehler: { hauptfahrzeugId: zf } };
        if (Object.keys(zl[1]).length) return { ok: false, fehler: zl[1] };
        if (haupt) p.werte.hauptfahrzeugId = haupt;
        var jetzt = self.jetzt();
        var fahrzeug = { id: neueId('fz'), datenraumId: self.datenraumId, art: artId, erstelltAm: jetzt };
        var eintrag = { id: neueId('en'), fahrzeugId: fahrzeug.id, nr: 1, werte: p.werte, art: artId,
          quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'fahrzeuge', objekt: fahrzeug },
          { tabelle: 'eintraege', objekt: eintrag }
        ]).then(function () { return { ok: true, id: fahrzeug.id }; });
      });
      });
    });
  };

  /*
   * Zusammengehörige Fahrzeuge (seit 2.0.45): Der Trailer gehört zum Boot, das Dinghy zur Yacht, der Motorradanhänger zum Wohnmobil.
   * Jedes Fahrzeug bleibt eigenständig. „Gehört zu“ verweist auf ein anderes Fahrzeug des Datenraums, ist änderbar (mit Verlauf)
   * und darf eine Kette bilden (Motorrad auf Anhänger am Wohnmobil). Kein Selbstbezug, keine Kreise.
   * Gibt null zurück, wenn die Wahl in Ordnung ist, sonst den Fehlertext. eigeneId = null beim Anlegen.
   */
  Daten.prototype.zuordnungPruefen = function (eigeneId, zielId) {
    if (!zielId) return Promise.resolve(null);
    if (eigeneId && zielId === eigeneId) return Promise.resolve('Ein Fahrzeug kann nicht zu sich selbst gehören.');
    return this.fahrzeugListe({ alle: true }).then(function (liste) {
      var nachId = {}; liste.forEach(function (x) { nachId[x.fahrzeug.id] = x; });
      var ziel = nachId[zielId];
      if (!ziel) return 'Dieses Fahrzeug wurde nicht gefunden.';
      if (ziel.fahrzeug.abgabe) return 'Dieses Fahrzeug ist abgegeben und steht nicht zur Auswahl.';
      var c = ziel, n = 0;
      while (c && eigeneId && n++ < 50) {
        var weiter = c.aktuell.werte.hauptfahrzeugId || null;
        if (!weiter) break;
        if (weiter === eigeneId) return '„' + ziel.aktuell.werte.bezeichnung + '“ gehört schon ' + (c === ziel ? '' : 'über „' + c.aktuell.werte.bezeichnung + '“ ') + 'zu diesem Fahrzeug. So entstünde ein Kreis.';
        c = nachId[weiter];
      }
      return null;
    });
  };

  /*
   * Die Zuordnung eines Fahrzeugs: hauptfahrzeug (wozu es gehört), kette (von dort nach oben), direkt (was direkt zu ihm gehört)
   * und alle (alles darunter, auch über Ketten, mit Tiefe und dem Fahrzeug, zu dem es direkt gehört). Abgegebene Fahrzeuge fehlen.
   */
  Daten.prototype.fahrzeugZuordnung = function (fahrzeugId) {
    return this.fahrzeugListe({ alle: true }).then(function (liste) {
      var nachId = {}; liste.forEach(function (x) { nachId[x.fahrzeug.id] = x; });
      var ich = nachId[fahrzeugId];
      if (!ich) return null;
      function ref(x) { var a = MM.Fahrzeugarten.art(x.fahrzeug.art); return { id: x.fahrzeug.id, name: x.aktuell.werte.bezeichnung, artId: x.fahrzeug.art, artName: a ? a.name : '' }; }
      function gueltig(id) { return id && nachId[id] && !nachId[id].fahrzeug.abgabe ? nachId[id] : null; }
      var haupt = gueltig(ich.aktuell.werte.hauptfahrzeugId || null);
      var kette = [], c = haupt, n = 0;
      while (c && n++ < 50 && kette.every(function (k) { return k.id !== c.fahrzeug.id; }) && c.fahrzeug.id !== fahrzeugId) { kette.push(ref(c)); c = gueltig(c.aktuell.werte.hauptfahrzeugId || null); }
      function direktVon(id) { return liste.filter(function (x) { return !x.fahrzeug.abgabe && x.fahrzeug.id !== id && (x.aktuell.werte.hauptfahrzeugId || null) === id; }); }
      var alle = [], gesehen = {}; gesehen[fahrzeugId] = true;
      var front = [{ id: fahrzeugId, name: ich.aktuell.werte.bezeichnung, tiefe: 0 }];
      while (front.length) {
        var naechste = [];
        front.forEach(function (f) {
          direktVon(f.id).forEach(function (x) {
            if (gesehen[x.fahrzeug.id]) return;
            gesehen[x.fahrzeug.id] = true;
            var r = ref(x); r.tiefe = f.tiefe + 1; r.ueber = f.name; r.ueberId = f.id;
            alle.push(r); naechste.push({ id: r.id, name: r.name, tiefe: r.tiefe });
          });
        });
        front = naechste;
      }
      return { hauptfahrzeug: haupt ? ref(haupt) : null, kette: kette, direkt: direktVon(fahrzeugId).map(ref), alle: alle };
    });
  };

  /* Die Auswahl für „Gehört zu“: alle nicht abgegebenen Fahrzeuge außer diesem selbst und allem, was (über Ketten) zu ihm gehört. */
  Daten.prototype.zuordnungAuswahl = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.fahrzeugListe(), fahrzeugId ? this.fahrzeugZuordnung(fahrzeugId) : Promise.resolve(null)]).then(function (r) {
      var gesperrt = {}; if (fahrzeugId) gesperrt[fahrzeugId] = true;
      if (r[1]) r[1].alle.forEach(function (x) { gesperrt[x.id] = true; });
      return r[0].filter(function (x) { return !gesperrt[x.fahrzeug.id]; }).map(function (x) {
        var a = MM.Fahrzeugarten.art(x.fahrzeug.art);
        return { wert: x.fahrzeug.id, label: x.aktuell.werte.bezeichnung + (a ? ' (' + a.name + ')' : '') };
      });
    });
  };

  /* Wird ein Hauptfahrzeug abgegeben, verlieren die dazugehörigen Fahrzeuge nur die Zuordnung. Sie bleiben bestehen, der Verlauf zeigt es. Gibt ihre Namen zurück. */
  Daten.prototype.zuordnungenLoesen = function (hauptId) {
    var self = this;
    return this.fahrzeugListe().then(function (liste) {
      var betroffen = liste.filter(function (x) { return (x.aktuell.werte.hauptfahrzeugId || null) === hauptId; });
      if (!betroffen.length) return [];
      var jetzt = self.jetzt();
      var schreiben = betroffen.map(function (x) {
        var werte = Object.assign({}, x.aktuell.werte); werte.hauptfahrzeugId = null;
        return { tabelle: 'eintraege', objekt: { id: neueId('en'), fahrzeugId: x.fahrzeug.id, nr: x.aktuell.nr + 1, werte: werte, art: x.fahrzeug.art,
          quelle: 'hand', korrekturZu: x.aktuell.id, erstelltAm: jetzt } };
      });
      return self.speicher.mehrereSpeichern(schreiben).then(function () { return betroffen.map(function (x) { return x.aktuell.werte.bezeichnung; }); });
    });
  };

  /*
   * Änderung = neuer Eintrag. Der alte bleibt unverändert erhalten.
   * Mit neueArtId (seit 2.0.37) wird auch die Fahrzeugart gewechselt: Der neue Eintrag nennt die Art
   * (art) und die vorherige (artVorher), am Fahrzeug steht die Liste der Wechsel (artWechsel).
   * Felder, die es in der neuen Art nicht gibt, bleiben in den Werten erhalten und sind nur ausgeblendet.
   */
  /* opt.trotzdem = true (seit 2.0.63): ausdrücklich bestätigt, dass trotz gleicher Kennung bei einem anderen Fahrzeug gespeichert wird. Geprüft werden
   * Kennzeichen, Registriernummer, FIN und HIN, die sich mit dieser Änderung ändern oder neu dazukommen; das eigene Fahrzeug zählt nicht mit. */
  Daten.prototype.fahrzeugAendern = function (fahrzeugId, roh, neueArtId, opt) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (f.fahrzeug.geliehen) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug ist geliehen. Die Angaben kommen vom Besitzer und lassen sich hier nicht ändern.' } };
      if (f.fahrzeug.abgabe) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug ist abgegeben. Setze es zuerst wieder auf „aktiv“, wenn du etwas ändern willst.' } };
      var altArt = f.fahrzeug.art;
      var artNeu = neueArtId && neueArtId !== altArt ? neueArtId : null;
      if (artNeu) {
        var gewaehlt = MM.Fahrzeugarten.art(artNeu);
        if (!gewaehlt || gewaehlt.gruppe) return { ok: false, fehler: { art: 'Bitte eine Fahrzeugart wählen.' } };
        if (!MM.Fahrzeugarten.sichtbar(artNeu)) return { ok: false, fehler: { art: 'Diese Fahrzeugart ist ausgeblendet. Blende sie unter „Fahrzeugarten verwalten“ wieder ein.' } };
      }
      var zielArt = artNeu || altArt;
      var p = self.pruefen(zielArt, roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      /* „Gehört zu“ (seit 2.0.45): nur prüfen, wenn es sich ändert. Fehlt die Angabe in roh, bleibt der bisherige Wert. */
      var hatZuordnung = !!roh && Object.prototype.hasOwnProperty.call(roh, 'hauptfahrzeugId');
      var wunsch = hatZuordnung && roh.hauptfahrzeugId ? String(roh.hauptfahrzeugId).trim() : null;
      var bisherZu = f.aktuell.werte.hauptfahrzeugId || null;
      var zuPruefung = hatZuordnung && wunsch !== bisherZu ? self.zuordnungPruefen(fahrzeugId, wunsch) : Promise.resolve(null);
      /* Kennung bei einem anderen Fahrzeug (seit 2.0.63), wie beim Anlegen. Nur was sich ändert, sonst käme die Frage bei jeder Änderung neu. */
      var bisherKennung = kennungenVon(f.aktuell.werte), neuKennung = {};
      KENNUNG_FELDER.forEach(function (k) {
        var n = p.werte[k] ? kennungNorm(p.werte[k]) : '';
        if (n && bisherKennung.indexOf(n) < 0) neuKennung[k] = p.werte[k];
      });
      var kennungPruefung = Object.keys(neuKennung).length && !(opt && opt.trotzdem) ? self.kennungTreffer(neuKennung, fahrzeugId) : Promise.resolve([]);
      return Promise.all([zuPruefung, kennungPruefung, self.fahrzeugListenPruefen(zielArt, fahrzeugId, p.werte, f.aktuell.werte)]).then(function (zk) {
        var zf = zk[0], treffer = zk[1];
        if (treffer.length) return { ok: false, doppelt: treffer, fehler: { allgemein: kennungTrefferText(neuKennung, treffer) } };
        if (zf) return { ok: false, fehler: { hauptfahrzeugId: zf } };
        if (Object.keys(zk[2]).length) return { ok: false, fehler: zk[2] };
        /* Werte, die in der neuen Art nicht vorkommen, bleiben gespeichert. */
        var werte = {};
        Object.keys(f.aktuell.werte).forEach(function (k) { if (!Object.prototype.hasOwnProperty.call(p.werte, k)) werte[k] = f.aktuell.werte[k]; });
        Object.keys(p.werte).forEach(function (k) { werte[k] = p.werte[k]; });
        if (hatZuordnung && wunsch !== bisherZu) werte.hauptfahrzeugId = wunsch;
        var diff = self.unterschiede(zielArt, f.aktuell.werte, werte);
        if (!diff.length && !artNeu) return { ok: true, id: fahrzeugId, geaendert: false };
        var jetzt = self.jetzt();
        var eintrag = { id: neueId('en'), fahrzeugId: fahrzeugId, nr: f.aktuell.nr + 1, werte: werte, art: zielArt,
          quelle: 'hand', korrekturZu: f.aktuell.id, erstelltAm: jetzt };
        var liste = [{ tabelle: 'eintraege', objekt: eintrag }];
        if (artNeu) {
          eintrag.artVorher = altArt;
          var fz = Object.assign({}, f.fahrzeug);
          fz.art = artNeu;
          fz.artWechsel = (f.fahrzeug.artWechsel || []).concat([{ von: altArt, nach: artNeu, am: jetzt, eintragNr: eintrag.nr }]);
          liste.push({ tabelle: 'fahrzeuge', objekt: fz });
        }
        return self.speicher.mehrereSpeichern(liste)
          .then(function () { return { ok: true, id: fahrzeugId, geaendert: true, artGeaendert: !!artNeu }; });
      });
    });
  };

  /*
   * Was ändert sich, wenn die Fahrzeugart gewechselt wird? Für die Warnung vor dem Speichern.
   * Nichts wird verändert. Ergebnis: { ok, alt, neu, weltWechsel, entfallen: [{ label, wert }], neuFelder: [label],
   *   ereignisse: Anzahl erfasster Ereignisse, die nicht mehr zur Art gehören, anforderungen: Anzahl }
   */
  Daten.prototype.artWechselVorschau = function (fahrzeugId, neueArtId) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      var a = MM.Fahrzeugarten.artSicher(f.fahrzeug.art), n = MM.Fahrzeugarten.art(neueArtId);
      if (!n || n.gruppe) return { ok: false, fehler: { art: 'Bitte eine Fahrzeugart wählen.' } };
      var feldAlt = MM.Fahrzeugarten.felder(a.id), feldNeu = MM.Fahrzeugarten.felder(n.id);
      var inNeu = {}; feldNeu.forEach(function (x) { inNeu[x.key] = true; });
      var inAlt = {}; feldAlt.forEach(function (x) { inAlt[x.key] = true; });
      var entfallen = [];
      feldAlt.forEach(function (x) {
        if (inNeu[x.key]) return;
        var t = MM.Hilfen.wert(x, f.aktuell.werte[x.key]);
        if (t !== null) entfallen.push({ label: x.label, wert: t });
      });
      var neuFelder = feldNeu.filter(function (x) { return !inAlt[x.key]; }).map(function (x) { return x.label; });
      return Promise.all([self.speicher.wo('anforderungen', 'fahrzeugId', fahrzeugId), self.ereignisseDesFahrzeugs(fahrzeugId)]).then(function (r) {
        var nichtMehr = 0;
        r[1].forEach(function (e) { if (e.zuordnung !== undefined && !MM.Logbuch.ereignisartGilt(e.zuordnung, n.id)) nichtMehr++; });
        return { ok: true, alt: { id: a.id, name: a.name, welt: a.welt }, neu: { id: n.id, name: n.name, welt: n.welt },
          weltWechsel: a.welt !== n.welt, entfallen: entfallen, neuFelder: neuFelder, ereignisse: nichtMehr, anforderungen: r[0].length };
      });
    });
  };

  /* Der Verbrauch einer Aktivität (seit 2.0.56): Durchschnitt aus allen Tankungen dieser Aktivität, die einen Verbrauch gerechnet haben.
   * Ergebnis: null (nichts gerechnet) oder siehe MM.Verbrauch.durchschnitt. Nichts wird geraten. */
  Daten.prototype.aktivitaetVerbrauch = function (aktivitaetId) {
    return Promise.all([this.speicher.alle('ereignisse'), this.speicher.alle('verlaeufe')]).then(function (r) {
      var liste = [];
      neuesteStaende(r[0].filter(function (e) { return e.aktivitaetId === aktivitaetId; }), r[1], 'ereignis').forEach(function (e) {
        var w = e.aktuell.werte;
        if (w.ausgeblendet === 'ja' || !w.verbrauch) return;
        liste.push(w.verbrauch);
      });
      return MM.Verbrauch.durchschnitt(liste);
    });
  };

  /* Alle erfassten Ereignisse der Aktivitäten dieses Fahrzeugs, mit der Zuordnung ihrer Ereignisart (nur lesen). */
  Daten.prototype.ereignisseDesFahrzeugs = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.aktivitaetenListe(), this.ereignisartenListe(), this.speicher.alle('ereignisse'), this.speicher.alle('verlaeufe')]).then(function (r) {
      var meine = {};
      r[0].forEach(function (a) { if (a.aktuell.werte.fahrzeugId === fahrzeugId) meine[a.objekt.id] = true; });
      var zuo = {}; r[1].forEach(function (x) { zuo[x.objekt.id] = x.aktuell.werte.zuordnung; });
      var res = [];
      neuesteStaende(r[2].filter(function (e) { return meine[e.aktivitaetId]; }), r[3], 'ereignis').forEach(function (e) {
        var w = e.aktuell.werte;
        if (w.ausgeblendet === 'ja') return;
        res.push({ id: e.objekt.id, artId: w.artId || null, zuordnung: w.artId && Object.prototype.hasOwnProperty.call(zuo, w.artId) ? zuo[w.artId] : undefined });
      });
      return res;
    });
  };

  /*
   * Alle Fahrzeuge des Datenraums, jeweils mit aktuellem Stand (Schale 1).
   * Abgegebene Fahrzeuge (seit 2.0.37) stehen nur mit opt.alle = true in der Liste, sonst fehlen sie in allen Auswahllisten.
   */
  Daten.prototype.fahrzeugListe = function (opt) {
    var self = this, alle = !!(opt && opt.alle);
    return Promise.all([this.speicher.alle('fahrzeuge'), this.speicher.alle('eintraege')]).then(function (r) {
      var nachFahrzeug = {};
      r[1].forEach(function (e) { (nachFahrzeug[e.fahrzeugId] = nachFahrzeug[e.fahrzeugId] || []).push(e); });
      var liste = r[0].filter(function (f) { return f.datenraumId === self.datenraumId && (alle || !f.abgabe); })
        .map(function (f) { return { fahrzeug: f, aktuell: neuester(nachFahrzeug[f.id] || []) }; })
        .filter(function (x) { return x.aktuell; });
      liste.sort(function (a, b) {
        return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return liste;
    });
  };

  /* Die Fahrzeugart, die zu jedem Eintrag gehörte (alte Einträge ohne Angabe: die Art vor dem ersten Wechsel). */
  function artJeEintrag(fahrzeug, eintraege) {
    var ersterWechsel = null;
    eintraege.forEach(function (e) { if (ersterWechsel === null && e.artVorher) ersterWechsel = e.artVorher; });
    return eintraege.map(function (e) { return e.art || ersterWechsel || fahrzeug.art; });
  }

  /* Ein Fahrzeug mit aktuellem Stand und dem ganzen Verlauf (neueste zuerst). */
  Daten.prototype.fahrzeugLaden = function (id) {
    var self = this;
    return Promise.all([this.speicher.holen('fahrzeuge', id), this.speicher.wo('eintraege', 'fahrzeugId', id)])
      .then(function (r) {
        var fahrzeug = r[0];
        if (!fahrzeug || !r[1].length) return null;
        var eintraege = r[1].slice().sort(nachNr);
        var arten = artJeEintrag(fahrzeug, eintraege);
        var verlauf = eintraege.map(function (e, i) {
          var vorher = i > 0 ? eintraege[i - 1] : null;
          var aenderungen = vorher ? self.unterschiede(arten[i], vorher.werte, e.werte) : [];
          if (vorher && arten[i] !== arten[i - 1]) {
            var an = MM.Fahrzeugarten.art(arten[i - 1]), nn = MM.Fahrzeugarten.art(arten[i]);
            aenderungen.unshift({ key: 'art', label: 'Fahrzeugart', feld: { typ: 'text' }, alt: an ? an.name : arten[i - 1], neu: nn ? nn.name : arten[i] });
          }
          return { eintrag: e, vorher: vorher, aenderungen: aenderungen };
        }).reverse();
        return { fahrzeug: fahrzeug, aktuell: eintraege[eintraege.length - 1], verlauf: verlauf };
      }).then(function (res) {
        /* Im Verlauf steht bei „Gehört zu“ der Name des Fahrzeugs, nicht seine Kennung (seit 2.0.45). Ebenso bei den Listen der Zugfahrzeuge und Boote (seit 2.0.103). */
        function istListe(u) { return !!(u.feld && u.feld.typ === 'fahrzeuge'); }
        if (!res || !res.verlauf.some(function (v) { return v.aenderungen.some(function (u) { return u.key === 'hauptfahrzeugId' || istListe(u); }); })) return res;
        return self.fahrzeugListe({ alle: true }).then(function (liste) {
          var namen = {}; liste.forEach(function (x) { namen[x.fahrzeug.id] = x.aktuell.werte.bezeichnung; });
          res.verlauf.forEach(function (v) {
            v.aenderungen.forEach(function (u) {
              if (istListe(u)) {
                var text = function (l) { return Array.isArray(l) && l.length ? l.map(function (i) { return namen[i] || 'ein anderes Fahrzeug'; }).join(', ') : null; };
                u.alt = text(u.alt); u.neu = text(u.neu); u.feld = { typ: 'text', label: u.feld.label, key: u.feld.key };
                return;
              }
              if (u.key !== 'hauptfahrzeugId') return;
              u.alt = u.alt ? (namen[u.alt] || 'ein anderes Fahrzeug') : null;
              u.neu = u.neu ? (namen[u.neu] || 'ein anderes Fahrzeug') : null;
            });
          });
          return res;
        });
      });
  };

  /* ---------- Fahrzeug abgeben (seit 2.0.37) ---------- */
  var ABGABE_GRUENDE = [
    { wert: 'verkauft', label: 'Verkauft' }, { wert: 'verschenkt', label: 'Verschenkt' },
    { wert: 'verschrottet', label: 'Verschrottet' }, { wert: 'sonstiges', label: 'Anderer Grund' }
  ];

  Daten.prototype.abgabeGruende = function () { return ABGABE_GRUENDE.slice(); };

  /*
   * Das Fahrzeug steht danach auf „abgegeben“: weg aus allen Auswahllisten, aber lesbar mit seiner ganzen Historie.
   * Nichts wird gelöscht. Die Angabe bleibt als Liste (abgabeVerlauf) erhalten, auch wenn man es wieder aktiv setzt.
   */
  Daten.prototype.fahrzeugAbgeben = function (fahrzeugId, roh) {
    var self = this;
    roh = roh || {};
    return this.speicher.holen('fahrzeuge', fahrzeugId).then(function (fz) {
      if (!fz || fz.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (fz.geliehen) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug ist geliehen. Es gehört dir nicht und lässt sich nicht abgeben. Mit dem Ende der Freigabe wird es von selbst inaktiv.' } };
      if (fz.abgabe) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug ist schon abgegeben.' } };
      var fehler = {};
      var datum = String(roh.datum == null ? '' : roh.datum).trim();
      if (!/^\d{4}-\d{2}-\d{2}$/.test(datum) || isNaN(Date.parse(datum + 'T00:00:00Z')) || new Date(datum + 'T00:00:00Z').toISOString().slice(0, 10) !== datum) fehler.datum = 'Bitte ein Datum eingeben.';
      var heute = self.jetztLokal().slice(0, 10);
      if (!fehler.datum && datum > heute) fehler.datum = 'Das Datum darf nicht in der Zukunft liegen.';
      var grund = String(roh.grund == null ? '' : roh.grund).trim();
      if (!ABGABE_GRUENDE.some(function (g) { return g.wert === grund; })) fehler.grund = 'Bitte einen Grund wählen.';
      var notiz = String(roh.notiz == null ? '' : roh.notiz).trim();
      if (notiz.length > 500) fehler.notiz = 'Die Notiz darf höchstens 500 Zeichen haben.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var neu = Object.assign({}, fz);
      neu.abgabe = { datum: datum, grund: grund, notiz: notiz || null, erfasstAm: self.jetzt() };
      return self.speicher.speichern('fahrzeuge', neu).then(function () { return self.zuordnungenLoesen(fahrzeugId); })
        .then(function (namen) { return { ok: true, id: fahrzeugId, zuordnungGeloest: namen }; });
    });
  };

  /* Wieder aktiv setzen, zum Beispiel nach einem Fehler beim Testen. Die frühere Abgabe bleibt in abgabeVerlauf. */
  Daten.prototype.fahrzeugWiederAktiv = function (fahrzeugId) {
    var self = this;
    return this.speicher.holen('fahrzeuge', fahrzeugId).then(function (fz) {
      if (!fz || fz.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (!fz.abgabe) return { ok: true, id: fahrzeugId, geaendert: false };
      if (fz.geliehen) return { ok: false, fehler: { allgemein: 'Ein geliehenes Fahrzeug wird mit einer neuen Freigabe wieder aktiv, nicht von Hand.' } };
      var neu = Object.assign({}, fz);
      neu.abgabeVerlauf = (fz.abgabeVerlauf || []).concat([Object.assign({}, fz.abgabe, { zurueckAm: self.jetzt() })]);
      delete neu.abgabe;
      return self.speicher.speichern('fahrzeuge', neu).then(function () { return { ok: true, id: fahrzeugId, geaendert: true }; });
    });
  };

  /* Alle abgegebenen Fahrzeuge, neueste Abgabe zuerst. */
  Daten.prototype.fahrzeugeAbgegeben = function () {
    return this.fahrzeugListe({ alle: true }).then(function (l) {
      return l.filter(function (x) { return x.fahrzeug.abgabe; }).sort(function (a, b) { return a.fahrzeug.abgabe.datum < b.fahrzeug.abgabe.datum ? 1 : (a.fahrzeug.abgabe.datum > b.fahrzeug.abgabe.datum ? -1 : 0); });
    });
  };

  /* ---------- Komponenten (Schale 3 und tiefer) ---------- */

  /* Alle Komponenten eines Fahrzeugs mit aktuellem Stand, unsortiert. */
  Daten.prototype.komponentenListe = function (fahrzeugId) {
    return Promise.all([this.speicher.wo('komponenten', 'fahrzeugId', fahrzeugId), this.speicher.alle('komponenteneintraege')])
      .then(function (r) {
        var nach = {};
        r[1].forEach(function (e) { (nach[e.komponenteId] = nach[e.komponenteId] || []).push(e); });
        return r[0].map(function (k) {
          var eintraege = (nach[k.id] || []).slice().sort(nachNr);
          return { komponente: k, eintraege: eintraege, aktuell: eintraege[eintraege.length - 1] || null };
        }).filter(function (x) { return x.aktuell; });
      });
  };

  /* Reihenfolge: Hauptkomponenten nach Art, sonst nach Bezeichnung. */
  Daten.prototype.sortiereKomponenten = function (liste) {
    return liste.slice().sort(function (a, b) {
      var ia = MM.Komponenten.artIndex(a.komponente.art), ib = MM.Komponenten.artIndex(b.komponente.art);
      if (!a.komponente.parentId && !b.komponente.parentId && ia !== ib) return ia - ib;
      return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
  };

  /*
   * Neue Komponente. parentId = null: Hauptkomponente (art ist dann Pflicht),
   * sonst gehört sie zu der genannten Komponente (Art entfällt).
   */
  Daten.prototype.komponenteAnlegen = function (fahrzeugId, parentId, artId, roh) {
    var self = this;
    return merkmaleVorbereiten(this, roh, []).then(function (mv) {
      /* Verbraucher, Stoff und Quelle (seit 2.0.48): ein Tank ist eine Hauptkomponente der Art „Tank“. */
      return versorgungVorbereiten(self, fahrzeugId, null, !parentId && artId === 'tank', mv.roh, null).then(function (vv) {
        var p = self.pruefenKomponente(mv.roh);
        var fehler = p.fehler;
        if (mv.fehler) fehler.merkmale = mv.fehler;
        Object.keys(vv.fehler).forEach(function (k) { fehler[k] = vv.fehler[k]; });
        if (!parentId && !MM.Komponenten.art(artId)) fehler.art = 'Bitte zuerst die Art der Hauptkomponente wählen.';
        if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
        Object.assign(p.werte, vv.werte);
        return komponenteAnlegenPruefen(self, fahrzeugId, parentId, artId, p, mv.schreiben.concat(vv.schreiben));
      });
    });
  };

  function komponenteAnlegenPruefen(self, fahrzeugId, parentId, artId, p, schreibenListen) {
    return Promise.all([
      self.speicher.holen('fahrzeuge', fahrzeugId),
      parentId ? self.speicher.holen('komponenten', parentId) : Promise.resolve(null)
    ]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (parentId && (!r[1] || r[1].fahrzeugId !== fahrzeugId)) {
        return { ok: false, fehler: { allgemein: 'Die übergeordnete Komponente wurde nicht gefunden.' } };
      }
      if (!parentId && artId === 'motor') {
        return self.kurznameKollision(fahrzeugId, null, p.werte).then(function (f) {
          if (f) return { ok: false, fehler: f };
          return komponenteSpeichern();
        });
      }
      return komponenteSpeichern();
    });

    function komponenteSpeichern() {
      var jetzt = self.jetzt();
      var k = { id: neueId('ko'), fahrzeugId: fahrzeugId, parentId: parentId || null,
        art: parentId ? null : artId, erstelltAm: jetzt };
      var e = { id: neueId('ke'), komponenteId: k.id, nr: 1, werte: p.werte,
        quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'komponenten', objekt: k },
        { tabelle: 'komponenteneintraege', objekt: e }
      ].concat(schreibenListen || [])).then(function () { return { ok: true, id: k.id }; });
    }
  }

  /*
   * Zwei Motoren eines Fahrzeugs sollen nicht denselben Kurznamen haben, sonst sind ihre Schalter nicht zu
   * unterscheiden. Geprüft wird nur, wenn der Nutzer einen Kurznamen selbst einträgt (ohne Eintrag gilt der Vorschlag).
   * Gibt null oder { kurzname: Text } zurück.
   */
  Daten.prototype.kurznameKollision = function (fahrzeugId, eigeneId, werte) {
    var kurz = werte && werte.kurzname ? String(werte.kurzname).trim().toUpperCase() : '';
    if (!kurz) return Promise.resolve(null);
    return this.komponentenListe(fahrzeugId).then(function (liste) {
      var anderer = liste.filter(function (k) {
        return MM.Komponenten.istMotor(k.komponente) && k.komponente.id !== eigeneId &&
          MM.Komponenten.kurzAnzeige(k.aktuell.werte).toUpperCase() === kurz;
      })[0];
      return anderer ? { kurzname: 'Der Motor „' + anderer.aktuell.werte.bezeichnung + '“ hat schon den Kurznamen ' + kurz + '. Bitte einen anderen wählen.' } : null;
    });
  };

  /* Änderung = neuer Eintrag, wie beim Fahrzeug. */
  Daten.prototype.komponenteAendern = function (komponenteId, roh) {
    var self = this;
    return this.komponenteLaden(komponenteId).then(function (c) {
      if (!c) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      return merkmaleVorbereiten(self, roh, c.aktuell.werte.merkmale || []).then(function (mv) {
        return versorgungVorbereiten(self, c.fahrzeug.id, komponenteId, MM.Versorgung.istTank(c.komponente), mv.roh, c.aktuell.werte).then(function (vv) {
          var p = self.pruefenKomponente(mv.roh);
          if (mv.fehler && !p.fehler.merkmale) { p.fehler.merkmale = mv.fehler; p.ok = false; }
          Object.keys(vv.fehler).forEach(function (k) { p.fehler[k] = vv.fehler[k]; p.ok = false; });
          if (!p.ok) return { ok: false, fehler: p.fehler };
          Object.assign(p.werte, vv.werte);
          var diff = unterschiedeFelder(MM.Komponenten.felder().concat(MM.Versorgung.ANZEIGE_FELDER), c.aktuell.werte, p.werte);
          if (!diff.length) return { ok: true, id: komponenteId, geaendert: false };
          var pruefung = MM.Komponenten.istMotor(c.komponente) ? self.kurznameKollision(c.fahrzeug.id, komponenteId, p.werte) : Promise.resolve(null);
          return pruefung.then(function (f) {
            if (f) return { ok: false, fehler: f };
            var e = { id: neueId('ke'), komponenteId: komponenteId, nr: c.aktuell.nr + 1, werte: p.werte,
              quelle: 'hand', korrekturZu: c.aktuell.id, erstelltAm: self.jetzt() };
            return self.speicher.mehrereSpeichern([{ tabelle: 'komponenteneintraege', objekt: e }].concat(mv.schreiben).concat(vv.schreiben))
              .then(function () { return { ok: true, id: komponenteId, geaendert: true }; });
          });
        });
      });
    });
  };

  /*
   * Eine Komponente mit Stand, Verlauf, dem Weg von der Hauptkomponente bis
   * zu ihr (weg), den Teilen direkt darunter (kinder) und dem Fahrzeug.
   * tiefe: 3 = Hauptkomponente (Schale 3), 4 = Teil darunter, usw.
   */
  Daten.prototype.komponenteLaden = function (id) {
    var self = this;
    return this.speicher.holen('komponenten', id).then(function (k) {
      if (!k) return null;
      return Promise.all([self.komponentenListe(k.fahrzeugId), self.fahrzeugLaden(k.fahrzeugId)]).then(function (r) {
        var alle = r[0], fz = r[1];
        var nachId = {};
        alle.forEach(function (x) { nachId[x.komponente.id] = x; });
        var ich = nachId[id];
        if (!ich || !fz) return null;

        var weg = [];
        var p = ich.komponente.parentId;
        while (p && nachId[p]) { weg.unshift(nachId[p]); p = nachId[p].komponente.parentId; }

        function anzahlKinder(x) {
          return alle.filter(function (y) { return y.komponente.parentId === x.komponente.id; }).length;
        }
        var kinder = self.sortiereKomponenten(alle.filter(function (x) { return x.komponente.parentId === id; }))
          .map(function (x) { return { komponente: x.komponente, aktuell: x.aktuell, anzahlKinder: anzahlKinder(x) }; });

        var felder = MM.Komponenten.felder().concat(MM.Versorgung.ANZEIGE_FELDER);
        /* Im Verlauf stehen bei „Quelle (Tank)“ die Namen, nicht die Kennungen; ein gelöschter Tank heißt „gelöschter Tank“ (seit 2.0.48). */
        function quellenText(ids) {
          var t = (Array.isArray(ids) ? ids : []).map(function (q) { return nachId[q] ? nachId[q].aktuell.werte.bezeichnung : 'gelöschter Tank'; });
          return t.length ? t.join(', ') : null;
        }
        /* Weitere Versorgungen im Verlauf: „Gas (Flüssiggas) (Tank Heck); Strom 230 V“ (seit 2.0.59). */
        function weitereText(liste) {
          var t = (Array.isArray(liste) ? liste : []).map(function (v) {
            var vl = MM.Versorgung.versorgungenListe({ verbraucher: 'ja', stoff: v.stoff, quellen: v.quellen, spannung: v.spannung })[0];
            var n = vl ? MM.Versorgung.versorgungName(vl) : (v.stoff || '');
            var tanks = (v.quellen || []).map(function (q) { return nachId[q] ? nachId[q].aktuell.werte.bezeichnung : 'gelöschter Tank'; });
            return n + (tanks.length ? ' (' + tanks.join(', ') + ')' : '');
          });
          return t.length ? t.join('; ') : null;
        }
        var verlauf = ich.eintraege.map(function (e, i) {
          var vorher = i > 0 ? ich.eintraege[i - 1] : null;
          var aend = vorher ? unterschiedeFelder(felder, vorher.werte, e.werte) : [];
          aend.forEach(function (u) {
            if (u.key === 'quellen') { u.alt = quellenText(u.alt); u.neu = quellenText(u.neu); }
            if (u.key === 'weitere') { u.alt = weitereText(u.alt); u.neu = weitereText(u.neu); }
            if (u.key === 'verbraucher') { u.alt = u.alt === 'ja' ? 'Ja' : (u.alt === 'nein' ? 'Nein' : null); u.neu = u.neu === 'ja' ? 'Ja' : (u.neu === 'nein' ? 'Nein' : null); }
          });
          /* Verschieben, Ausblenden und Einblenden (seit 2.0.45) stehen als eigene Einträge im Verlauf, die Angaben bleiben gleich. */
          if (e.verschoben) aend.unshift({ key: 'verschoben', label: 'Verschoben', feld: { typ: 'text' }, alt: e.verschoben.von, neu: e.verschoben.nach });
          if (e.sichtbarkeit) aend.unshift({ key: 'sichtbarkeit', label: 'Sichtbarkeit', feld: { typ: 'text' }, alt: e.sichtbarkeit === 'ausgeblendet' ? 'sichtbar' : 'ausgeblendet', neu: e.sichtbarkeit === 'ausgeblendet' ? 'ausgeblendet' : 'sichtbar' });
          return { eintrag: e, vorher: vorher, aenderungen: aend, art: e.verschoben ? 'verschoben' : (e.sichtbarkeit ? e.sichtbarkeit : 'korrektur') };
        }).reverse();

        return { komponente: ich.komponente, aktuell: ich.aktuell, verlauf: verlauf, weg: weg, kinder: kinder,
          fahrzeug: fz.fahrzeug, fahrzeugAktuell: fz.aktuell, tiefe: weg.length + 3 };
      });
    });
  };

  /* ---------- Merkmale und Einheiten: offene Listen (seit 2.0.45) ---------- */
  /*
   * Zwei Listen mit Vorlage (MM.Komponenten.MERKMAL_VORLAGE und EINHEITEN_VORLAGE), eigenen Einträgen und Ausgeblendeten.
   * Sie liegen als Dokumente „merkmale“ und „einheiten“ in „einstellungen“ (keine Umstellung der Datenbank, die Sicherung nimmt sie mit).
   * Eine Zeile an einer Komponente trägt Name, Wert, Einheit und Bezugsgröße als Text. Ausblenden oder Ändern der Liste ändert keine Komponente.
   * Eine Einheit muss aus der Liste kommen (sonst steht einmal „kn“ und einmal „Knoten“). Neue Einheiten legt der Nutzer direkt im Formular an.
   */
  var MERKMALE_DOK = 'merkmale', EINHEITEN_DOK = 'einheiten';

  function listenDok(dok, id) {
    var d = dok ? JSON.parse(JSON.stringify(dok)) : { id: id };
    if (!Array.isArray(d.eigene)) d.eigene = [];
    if (!Array.isArray(d.ausgeblendet)) d.ausgeblendet = [];
    return d;
  }

  Daten.prototype.einheitenListe = function () {
    return this.speicher.holen('einstellungen', EINHEITEN_DOK).then(function (d) { return MM.Komponenten.einheitenListe(d); });
  };
  Daten.prototype.merkmaleListe = function () {
    return this.speicher.holen('einstellungen', MERKMALE_DOK).then(function (d) { return MM.Komponenten.merkmaleListe(d); });
  };

  Daten.prototype.einheitAnlegen = function (bezeichnung) {
    var self = this, bez = trimmed2(bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte eine Einheit eingeben, zum Beispiel „kn“.' } });
    if (bez.length > MM.Komponenten.MAX_EINHEIT) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte höchstens ' + MM.Komponenten.MAX_EINHEIT + ' Zeichen.' } });
    return this.speicher.holen('einstellungen', EINHEITEN_DOK).then(function (dok) {
      var d = listenDok(dok, EINHEITEN_DOK);
      var gleich = MM.Komponenten.einheitenListe(d).filter(function (x) { return MM.Komponenten.gleichText(x.label, bez); })[0];
      if (gleich) return { ok: false, fehler: { bezeichnung: gleich.ausgeblendet ? 'Diese Einheit gibt es schon, sie ist ausgeblendet. Blende sie wieder ein.' : 'Diese Einheit gibt es schon.' } };
      var id = neueId('ei');
      d.eigene.push({ wert: id, label: bez, erstelltAm: self.jetzt() });
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, id: id, label: bez }; });
    });
  };

  Daten.prototype.einheitAusblenden = function (wert, ausblenden) {
    var self = this;
    return this.speicher.holen('einstellungen', EINHEITEN_DOK).then(function (dok) {
      var d = listenDok(dok, EINHEITEN_DOK);
      if (!MM.Komponenten.einheitenListe(d).some(function (x) { return x.wert === wert; })) return { ok: false, fehler: { allgemein: 'Diese Einheit wurde nicht gefunden.' } };
      d.ausgeblendet = d.ausgeblendet.filter(function (x) { return x !== wert; });
      if (ausblenden) d.ausgeblendet.push(wert);
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  Daten.prototype.merkmalAnlegen = function (name, einheit, bezug) {
    var self = this, n = trimmed2(name), e = trimmed2(einheit), b = trimmed2(bezug);
    var fehler = {};
    if (!n) fehler.name = 'Bitte einen Namen für das Merkmal eingeben, zum Beispiel „Leistung“.';
    else if (n.length > MM.Komponenten.MAX_MERKMAL) fehler.name = 'Bitte höchstens ' + MM.Komponenten.MAX_MERKMAL + ' Zeichen.';
    if (b.length > MM.Komponenten.MAX_BEZUG) fehler.bezug = 'Bitte höchstens ' + MM.Komponenten.MAX_BEZUG + ' Zeichen.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return Promise.all([this.speicher.holen('einstellungen', MERKMALE_DOK), this.einheitenListe()]).then(function (r) {
      var d = listenDok(r[0], MERKMALE_DOK);
      if (MM.Komponenten.merkmaleListe(d).some(function (x) { return MM.Komponenten.gleichText(x.label, n); })) return { ok: false, fehler: { name: 'Dieses Merkmal gibt es schon.' } };
      if (e) {
        var u = r[1].filter(function (x) { return MM.Komponenten.gleichText(x.label, e); })[0];
        if (!u) return { ok: false, fehler: { einheit: 'Diese Einheit gibt es nicht in der Liste. Lege sie zuerst an.' } };
        e = u.label;
      }
      var id = neueId('me');
      d.eigene.push({ wert: id, label: n, einheit: e, bezug: b, erstelltAm: self.jetzt() });
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, id: id, label: n }; });
    });
  };

  Daten.prototype.merkmalAusblenden = function (wert, ausblenden) {
    var self = this;
    return this.speicher.holen('einstellungen', MERKMALE_DOK).then(function (dok) {
      var d = listenDok(dok, MERKMALE_DOK);
      if (!MM.Komponenten.merkmaleListe(d).some(function (x) { return x.wert === wert; })) return { ok: false, fehler: { allgemein: 'Dieses Merkmal wurde nicht gefunden.' } };
      d.ausgeblendet = d.ausgeblendet.filter(function (x) { return x !== wert; });
      if (ausblenden) d.ausgeblendet.push(wert);
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  /*
   * Vor dem Speichern einer Komponente: Die Einheit jeder Zeile muss aus der Liste kommen. Eine neu eingegebene Einheit
   * (Feld „neueEinheit“ der Zeile) kommt dabei in die Liste, ebenso ein neuer Merkmalname. Es wird erst geschrieben, wenn die
   * Komponente selbst gespeichert wird (die Rückgabe „schreiben“ geht mit in dieselbe Speicherung).
   * Zeilen, die schon vorher an der Komponente standen (bisher), füllen die Liste nicht von selbst.
   * Ergebnis: { roh, fehler: Text oder null, schreiben: [{ tabelle, objekt }] }
   */
  function merkmaleVorbereiten(self, roh, bisher) {
    roh = roh || {};
    var zeilen = Array.isArray(roh.merkmale) ? roh.merkmale : [];
    if (!zeilen.length) return Promise.resolve({ roh: roh, fehler: null, schreiben: [] });
    return Promise.all([self.speicher.holen('einstellungen', EINHEITEN_DOK), self.speicher.holen('einstellungen', MERKMALE_DOK)]).then(function (r) {
      var eDok = listenDok(r[0], EINHEITEN_DOK), mDok = listenDok(r[1], MERKMALE_DOK);
      var eListe = MM.Komponenten.einheitenListe(eDok), mListe = MM.Komponenten.merkmaleListe(mDok);
      var jetzt = self.jetzt(), eNeu = false, mNeu = false, fehler = null;
      var vorher = (bisher || []).map(function (z) { return String(z && z.name != null ? z.name : '').trim().toLowerCase(); });
      var neu = zeilen.map(function (z) {
        var c = Object.assign({}, z);
        var n = trimmed2(c.name), e = trimmed2(c.einheit), ne = trimmed2(c.neueEinheit), b = trimmed2(c.bezug);
        delete c.neueEinheit;
        if (ne) e = ne;
        if (e) {
          if (e.length > MM.Komponenten.MAX_EINHEIT) { fehler = fehler || 'Die Einheit darf höchstens ' + MM.Komponenten.MAX_EINHEIT + ' Zeichen haben.'; return c; }
          var g = eListe.filter(function (x) { return MM.Komponenten.gleichText(x.label, e); })[0];
          if (g) e = g.label;
          else if (ne) {
            var eid = neueId('ei');
            eDok.eigene.push({ wert: eid, label: e, erstelltAm: jetzt });
            eListe.push({ wert: eid, label: e, eigen: true, ausgeblendet: false });
            eNeu = true;
          } else fehler = fehler || 'Die Einheit „' + e + '“ gibt es in der Liste nicht. Bitte eine Einheit aus der Liste wählen oder eine neue anlegen.';
          c.einheit = e;
        }
        if (n && n.length <= MM.Komponenten.MAX_MERKMAL && vorher.indexOf(n.toLowerCase()) < 0 &&
            !mListe.some(function (x) { return MM.Komponenten.gleichText(x.label, n); })) {
          var mid = neueId('me');
          mDok.eigene.push({ wert: mid, label: n, einheit: e || '', bezug: b, erstelltAm: jetzt });
          mListe.push({ wert: mid, label: n, einheit: e || '', bezug: b, eigen: true, ausgeblendet: false });
          mNeu = true;
        }
        return c;
      });
      var schreiben = [];
      if (eNeu) schreiben.push({ tabelle: 'einstellungen', objekt: eDok });
      if (mNeu) schreiben.push({ tabelle: 'einstellungen', objekt: mDok });
      return { roh: Object.assign({}, roh, { merkmale: neu }), fehler: fehler, schreiben: schreiben };
    });
  }

  /* ---------- Stoffe, Verbraucher und Quelle (seit 2.0.48) ---------- */
  /*
   * Die Liste der Stoffe (Diesel, Benzin, Gas, Strom …) ist offen: Vorlage, eigene Einträge, Ausgeblendete. Sie liegt als Dokument „stoffe“
   * in „einstellungen“ (keine Umstellung der Datenbank, die Sicherung nimmt sie mit). Ein Stoff muss aus der Liste kommen, damit
   * „Diesel“ und „diesel“ nicht zwei Dinge sind. Einen neuen Stoff legt der Nutzer direkt im Formular der Komponente an.
   */
  var STOFFE_DOK = 'stoffe';
  /* Spannungen (seit 2.0.59): offene Liste wie die Stoffe, Dokument „spannungen“ in „einstellungen“ (in der Sicherung enthalten). */
  var SPANNUNGEN_DOK = 'spannungen';
  var MAX_WEITERE = 10;
  function spannungPruefen(liste, roh, fehler, key, bisher, praefix) {
    var t = roh === undefined ? trimmed2(bisher) : trimmed2(roh);
    if (!t) return null;
    var g = liste.filter(function (x) { return MM.Versorgung.gleichText(x.label, t); })[0];
    if (!g) { if (!fehler[key]) fehler[key] = (praefix || '') + 'Diese Spannung gibt es in der Liste nicht. Eigene Spannungen legst du unter „Spannungen“ an.'; return null; }
    return g.label;
  }

  Daten.prototype.spannungenListe = function () {
    return this.speicher.holen('einstellungen', SPANNUNGEN_DOK).then(function (d) { return MM.Versorgung.spannungenListe(d); });
  };

  Daten.prototype.spannungAnlegen = function (bezeichnung, art) {
    var self = this, bez = trimmed2(bezeichnung), V = MM.Versorgung;
    var fehler = {};
    if (!bez) fehler.bezeichnung = 'Bitte eine Spannung eingeben, zum Beispiel „48 V“.';
    else if (bez.length > V.MAX_SPANNUNG) fehler.bezeichnung = 'Bitte höchstens ' + V.MAX_SPANNUNG + ' Zeichen.';
    if (art !== 'gleich' && art !== 'wechsel') fehler.art = 'Bitte Gleichstrom oder Wechselstrom wählen.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return this.speicher.holen('einstellungen', SPANNUNGEN_DOK).then(function (dok) {
      var d = listenDok(dok, SPANNUNGEN_DOK);
      var gleichE = V.spannungenListe(d).filter(function (x) { return V.gleichText(x.label, bez); })[0];
      if (gleichE) return { ok: false, fehler: { bezeichnung: gleichE.ausgeblendet ? 'Diese Spannung gibt es schon, sie ist ausgeblendet. Blende sie wieder ein.' : 'Diese Spannung gibt es schon.' } };
      var id = neueId('sp');
      d.eigene.push({ wert: id, label: bez, art: art, erstelltAm: self.jetzt() });
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, id: id, label: bez }; });
    });
  };

  Daten.prototype.spannungAusblenden = function (wert, ausblenden) {
    var self = this;
    return this.speicher.holen('einstellungen', SPANNUNGEN_DOK).then(function (dok) {
      var d = listenDok(dok, SPANNUNGEN_DOK);
      if (!MM.Versorgung.spannungenListe(d).some(function (x) { return x.wert === wert; })) return { ok: false, fehler: { allgemein: 'Diese Spannung gibt es nicht.' } };
      d.ausgeblendet = d.ausgeblendet.filter(function (x) { return x !== wert; });
      if (ausblenden) d.ausgeblendet.push(wert);
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  Daten.prototype.stoffeListe = function () {
    return this.speicher.holen('einstellungen', STOFFE_DOK).then(function (d) { return MM.Versorgung.stoffeListe(d); });
  };

  Daten.prototype.stoffAnlegen = function (bezeichnung) {
    var self = this, bez = trimmed2(bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Stoff eingeben, zum Beispiel „Wasserstoff“.' } });
    if (bez.length > MM.Versorgung.MAX_STOFF) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte höchstens ' + MM.Versorgung.MAX_STOFF + ' Zeichen.' } });
    return this.speicher.holen('einstellungen', STOFFE_DOK).then(function (dok) {
      var d = listenDok(dok, STOFFE_DOK);
      var gleich = MM.Versorgung.stoffeListe(d).filter(function (x) { return MM.Versorgung.gleichText(x.label, bez); })[0];
      if (gleich) return { ok: false, fehler: { bezeichnung: gleich.ausgeblendet ? 'Diesen Stoff gibt es schon, er ist ausgeblendet. Blende ihn wieder ein.' : 'Diesen Stoff gibt es schon.' } };
      var id = neueId('st');
      d.eigene.push({ wert: id, label: bez, erstelltAm: self.jetzt() });
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, id: id, label: bez }; });
    });
  };

  /*
   * Die Komponentenliste für die Checkliste bei der Fahrzeuganlage (seit 2.0.53): Vorlage, eigene Einträge, Ausgeblendete.
   * Dokument „komponentenliste“ in „einstellungen“ (keine Umstellung der Datenbank, in der Sicherung enthalten).
   * Die Checkliste ist eine Hilfe gegen das Vergessen, kein Zwang.
   */
  var KOMPONENTENLISTE_DOK = 'komponentenliste';
  Daten.prototype.komponentenListeVorlage = function () {
    return this.speicher.holen('einstellungen', KOMPONENTENLISTE_DOK).then(function (d) { return MM.Komponenten.listeEintraege(d); });
  };

  /* Was die Checkliste für diese Fahrzeugart anbietet (ohne die ausgeblendeten Einträge). */
  Daten.prototype.komponentenAngebot = function (artId) {
    var self = this;
    return Promise.all([this.komponentenListeVorlage(), this.fahrzeugartMotor(artId)]).then(function (r) {
      var k = MM.Fahrzeugarten.knoten(artId);
      if (!k) return [];
      return MM.Komponenten.listeAngebot(r[0], MM.Fahrzeugarten.vorfahren(artId), k.welt || null, r[1] && r[1].hat === false ? false : true);
    });
  };

  Daten.prototype.komponentenListeAnlegen = function (roh) {
    var self = this, K = MM.Komponenten;
    roh = roh || {};
    var bez = trimmed2(roh.bezeichnung), fehler = {};
    if (!bez) fehler.bezeichnung = 'Bitte einen Namen eingeben, zum Beispiel „Kühlschrank“.';
    else if (bez.length > K.MAX_LISTE_NAME) fehler.bezeichnung = 'Bitte höchstens ' + K.MAX_LISTE_NAME + ' Zeichen.';
    if (!K.art(roh.art)) fehler.art = 'Bitte eine Art wählen.';
    var ver = trimmed2(roh.verbraucher);
    if (ver !== 'ja' && ver !== 'nein') fehler.verbraucher = 'Bitte Ja oder Nein wählen.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return this.speicher.holen('einstellungen', KOMPONENTENLISTE_DOK).then(function (dok) {
      var d = listenDok(dok, KOMPONENTENLISTE_DOK);
      var gleich = K.listeEintraege(d).filter(function (x) { return K.gleichText(x.label, bez); })[0];
      if (gleich) return { ok: false, fehler: { bezeichnung: gleich.ausgeblendet ? 'Diesen Eintrag gibt es schon, er ist ausgeblendet. Blende ihn wieder ein.' : 'Diesen Eintrag gibt es schon.' } };
      var id = neueId('kl');
      d.eigene.push({ wert: id, label: bez, art: roh.art, verbraucher: ver, erstelltAm: self.jetzt() });
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, id: id, label: bez }; });
    });
  };

  Daten.prototype.komponentenListeAusblenden = function (wert, ausblenden) {
    var self = this;
    return this.speicher.holen('einstellungen', KOMPONENTENLISTE_DOK).then(function (dok) {
      var d = listenDok(dok, KOMPONENTENLISTE_DOK);
      if (!MM.Komponenten.listeEintraege(d).some(function (x) { return x.wert === wert; })) return { ok: false, fehler: { allgemein: 'Diesen Eintrag gibt es nicht.' } };
      d.ausgeblendet = d.ausgeblendet.filter(function (x) { return x !== wert; });
      if (ausblenden) d.ausgeblendet.push(wert);
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  /*
   * Eintrag der Komponentenliste annehmen (seit 2.0.60). Ein neuer Eintrag der Vorlage ist „neu“, bis er angenommen oder ausgeblendet wird.
   * wert: die Kennung, oder 'alle' für alle neuen. Annehmen ändert nichts am Rest der Liste.
   */
  Daten.prototype.komponentenListeAnnehmen = function (wert) {
    var self = this, K = MM.Komponenten;
    return this.speicher.holen('einstellungen', KOMPONENTENLISTE_DOK).then(function (dok) {
      var d = listenDok(dok, KOMPONENTENLISTE_DOK);
      if (!Array.isArray(d.bekannt)) d.bekannt = [];
      var neue = K.listeEintraege(d).filter(function (x) { return x.neu; });
      var ziel = wert === 'alle' ? neue : neue.filter(function (x) { return x.wert === wert; });
      if (!ziel.length) return { ok: false, fehler: { allgemein: 'Dieser Eintrag ist nicht neu.' } };
      ziel.forEach(function (x) { if (d.bekannt.indexOf(x.wert) < 0) d.bekannt.push(x.wert); });
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, anzahl: ziel.length }; });
    });
  };

  /*
   * Ist ein Eintrag der Komponentenliste schon benutzt? Dann lässt er sich nur ausblenden, damit Historie und Berechnungen heil bleiben.
   * Benutzt heißt: Die Checkliste hat daraus eine Komponente angelegt (Vermerk im Dokument „benutzt“), oder irgendein Fahrzeug hat
   * eine Komponente (auch ausgeblendete oder ausgebaute) mit demselben Namen, auch mit angehängter Nummer („Motor 2“).
   * Ergebnis: { ok, eintrag, eigen, benutzt, gruende }
   */
  Daten.prototype.komponentenListeVerwendung = function (wert) {
    var self = this, K = MM.Komponenten;
    return Promise.all([this.speicher.holen('einstellungen', KOMPONENTENLISTE_DOK), this.speicher.alle('komponenten'), this.speicher.alle('komponenteneintraege')]).then(function (r) {
      var d = listenDok(r[0], KOMPONENTENLISTE_DOK);
      var eintrag = K.listeEintraege(d).filter(function (x) { return x.wert === wert; })[0];
      if (!eintrag) return { ok: false, fehler: { allgemein: 'Diesen Eintrag gibt es nicht.' } };
      var gruende = [];
      if (Array.isArray(d.benutzt) && d.benutzt.indexOf(wert) >= 0) gruende.push('Die Checkliste hat daraus schon eine Komponente angelegt.');
      var namen = {};
      r[1].forEach(function (k) { namen[k.id] = true; });
      var aktuell = {};
      r[2].slice().sort(nachNr).forEach(function (e) { if (namen[e.komponenteId]) aktuell[e.komponenteId] = e; });
      var passt = Object.keys(aktuell).some(function (id) {
        var b = String(aktuell[id].werte.bezeichnung || '').trim();
        if (K.gleichText(b, eintrag.label)) return true;
        /* „Motor 2“: Name der Liste, Leerzeichen, Nummer (so benennt die Checkliste bei Anzahl über 1) */
        var kopf = eintrag.label.toLowerCase() + ' ', bl = b.toLowerCase();
        return bl.indexOf(kopf) === 0 && /^\d+$/.test(bl.slice(kopf.length));
      });
      if (passt) gruende.push('An einem Fahrzeug gibt es eine Komponente mit diesem Namen.');
      return { ok: true, eintrag: eintrag, eigen: !!eintrag.eigen, benutzt: gruende.length > 0, gruende: gruende };
    });
  };

  /* Löschen (seit 2.0.60): nur eigene Einträge, die noch nicht benutzt sind. Mitgelieferte lassen sich nur ausblenden. */
  Daten.prototype.komponentenListeLoeschen = function (wert) {
    var self = this;
    return this.komponentenListeVerwendung(wert).then(function (v) {
      if (!v.ok) return v;
      if (!v.eigen) return { ok: false, fehler: { allgemein: 'Mitgelieferte Einträge lassen sich nur ausblenden, nicht löschen.' } };
      if (v.benutzt) return { ok: false, fehler: { allgemein: 'Dieser Eintrag ist schon benutzt (' + v.gruende.join(' ') + ') und lässt sich nur ausblenden, damit nichts verloren geht.' } };
      return self.speicher.holen('einstellungen', KOMPONENTENLISTE_DOK).then(function (dok) {
        var d = listenDok(dok, KOMPONENTENLISTE_DOK);
        d.eigene = d.eigene.filter(function (x) { return x.wert !== wert; });
        d.ausgeblendet = d.ausgeblendet.filter(function (x) { return x !== wert; });
        if (Array.isArray(d.benutzt)) d.benutzt = d.benutzt.filter(function (x) { return x !== wert; });
        return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
      });
    });
  };

  /* Die Checkliste hat aus diesem Eintrag eine Komponente angelegt: Vermerk, damit der Eintrag nicht mehr gelöscht werden kann. */
  Daten.prototype.komponentenListeBenutzt = function (wert) {
    var self = this;
    return this.speicher.holen('einstellungen', KOMPONENTENLISTE_DOK).then(function (dok) {
      var d = listenDok(dok, KOMPONENTENLISTE_DOK);
      if (!Array.isArray(d.benutzt)) d.benutzt = [];
      if (!wert || d.benutzt.indexOf(wert) >= 0) return { ok: true, geaendert: false };
      d.benutzt.push(wert);
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, geaendert: true }; });
    });
  };


  /* Die Vorgänge der Ver- und Entsorgung (seit 2.0.63): Vorlage, eigene und Ausgeblendete. Dokument „vorgaenge“ in „einstellungen“ (in der Sicherung enthalten). */
  var VORGAENGE_DOK = 'vorgaenge';
  function vorgangListeBauen(dok) {
    var versteckt = (dok && dok.ausgeblendet) || [];
    var l = MM.Tanken.VORGANG_VORLAGE.map(function (v) { return Object.assign({}, v, { eigen: false, ausgeblendet: versteckt.indexOf(v.id) >= 0 }); });
    ((dok && dok.eigene) || []).forEach(function (v) { l.push(Object.assign({}, v, { eigen: true, ausgeblendet: versteckt.indexOf(v.id) >= 0 })); });
    return l;
  }
  Daten.prototype.vorgangListe = function () { return this.speicher.holen('einstellungen', VORGAENGE_DOK).then(vorgangListeBauen); };
  Daten.prototype.versorgungsvorgangAnlegen = function (roh) {
    var self = this; roh = roh || {};
    var name = trimmed2(roh.name), fehler = {};
    if (!name) fehler.name = 'Bitte einen Namen eingeben, zum Beispiel „Trinkwasser abpumpen“.';
    else if (name.length > 60) fehler.name = 'Bitte höchstens 60 Zeichen.';
    if (['auf', 'leer', 'flasche'].indexOf(roh.art) < 0) fehler.art = 'Bitte wählen: auffüllen, entleeren oder Flasche tauschen.';
    var stoffe = Array.isArray(roh.stoffe) ? roh.stoffe.map(String).filter(Boolean) : [];
    if (!stoffe.length) fehler.stoffe = 'Bitte mindestens einen Stoff wählen. Es werden nur Tanks mit diesem Stoff angeboten.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return this.speicher.holen('einstellungen', VORGAENGE_DOK).then(function (dok) {
      var d = listenDok(dok, VORGAENGE_DOK);
      if (vorgangListeBauen(d).some(function (x) { return MM.Versorgung.gleichText(x.name, name); })) return { ok: false, fehler: { name: 'Diesen Vorgang gibt es schon.' } };
      var id = neueId('vo');
      d.eigene.push({ id: id, name: name, art: roh.art, stoffe: stoffe, kostenart: roh.kostenart || 'varsonst', erstelltAm: self.jetzt() });
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, id: id, name: name }; });
    });
  };
  Daten.prototype.vorgangAusblenden = function (id, ausblenden) {
    var self = this;
    return this.speicher.holen('einstellungen', VORGAENGE_DOK).then(function (dok) {
      var d = listenDok(dok, VORGAENGE_DOK);
      if (!vorgangListeBauen(d).some(function (x) { return x.id === id; })) return { ok: false, fehler: { allgemein: 'Diesen Vorgang gibt es nicht.' } };
      d.ausgeblendet = d.ausgeblendet.filter(function (x) { return x !== id; });
      if (ausblenden) d.ausgeblendet.push(id);
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };
  /* Für die Frage „Was?“: die Vorgänge, die dieses Fahrzeug anbieten kann, mit ihren passenden Tanks (nur Tanks, die es als Komponenten gibt). */
  /* Die Tanks des Fahrzeugs mit Stoff und Dichte (für Kraftstoffart und Liter oder kg). */
  Daten.prototype.tankAuswahl = function (fahrzeugId) {
    return Promise.all([this.komponentenListe(fahrzeugId), this.speicher.holen('einstellungen', STOFFE_DOK)]).then(function (r) {
      return r[0].filter(function (k) { return MM.Versorgung.istTank(k.komponente) && !k.aktuell.werte.ausgebautAm && !k.komponente.ausgeblendet; })
        .map(function (k) { return { id: k.komponente.id, name: k.aktuell.werte.bezeichnung, stoff: k.aktuell.werte.stoff || '', dichte: k.aktuell.werte.stoff ? MM.Versorgung.stoffDichte(r[1], k.aktuell.werte.stoff) : null }; });
    });
  };
  Daten.prototype.vorgangAuswahl = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.vorgangListe(), this.komponentenListe(fahrzeugId), this.speicher.holen('einstellungen', STOFFE_DOK)]).then(function (r) {
      var wasserOderStrom = function (st) { return MM.Versorgung.istStrom(st) || MM.Versorgung.istWasserStoff(st); };
      var tanks = r[1].filter(function (k) { return MM.Versorgung.istTank(k.komponente) && !k.aktuell.werte.ausgebautAm && !k.komponente.ausgeblendet; })
        .map(function (k) { return { id: k.komponente.id, name: k.aktuell.werte.bezeichnung, stoff: k.aktuell.werte.stoff || '', dichte: k.aktuell.werte.stoff ? MM.Versorgung.stoffDichte(r[2], k.aktuell.werte.stoff) : null }; });
      return MM.Tanken.vorgangAngebot(r[0].filter(function (v) { return !v.ausgeblendet; }), tanks, wasserOderStrom).map(function (v) {
        return { id: v.id, name: v.name, art: v.art, kostenart: v.kostenart, tanks: MM.Tanken.tanksFuerVorgang(v, tanks, wasserOderStrom) };
      });
    });
  };

  /* Dichte eines Stoffes eintragen (seit 2.0.63), kg je Liter. Leer = keine Dichte (dann nur Liter beim Tanken). */
  Daten.prototype.stoffDichteSetzen = function (wert, dichte) {
    var self = this;
    return this.speicher.holen('einstellungen', STOFFE_DOK).then(function (dok) {
      var d = listenDok(dok, STOFFE_DOK);
      var st = MM.Versorgung.stoffeListe(d).filter(function (x) { return x.wert === wert; })[0];
      if (!st) return { ok: false, fehler: { allgemein: 'Diesen Stoff gibt es nicht.' } };
      var leer = dichte === null || dichte === undefined || String(dichte).trim() === '';
      var n = leer ? null : MM.Tanken.zahl(String(dichte).replace(',', '.'));
      if (!leer && (n === null || !(n > 0) || n > 5)) return { ok: false, fehler: { dichte: 'Bitte die Dichte in kg je Liter eingeben, zum Beispiel 0,51.' } };
      d.dichten = d.dichten && typeof d.dichten === 'object' ? d.dichten : {};
      d.dichten[st.label] = n;
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, dichte: n }; });
    });
  };
  /* Die Dichte (kg je Liter) des Stoffes mit diesem Namen oder null. */
  Daten.prototype.stoffDichte = function (label) {
    return this.speicher.holen('einstellungen', STOFFE_DOK).then(function (d) { return MM.Versorgung.stoffDichte(d, label); });
  };

  Daten.prototype.stoffAusblenden = function (wert, ausblenden) {
    var self = this;
    return this.speicher.holen('einstellungen', STOFFE_DOK).then(function (dok) {
      var d = listenDok(dok, STOFFE_DOK);
      if (!MM.Versorgung.stoffeListe(d).some(function (x) { return x.wert === wert; })) return { ok: false, fehler: { allgemein: 'Diesen Stoff gibt es nicht.' } };
      d.ausgeblendet = d.ausgeblendet.filter(function (x) { return x !== wert; });
      if (ausblenden) d.ausgeblendet.push(wert);
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  /*
   * Vor dem Speichern einer Komponente: Verbraucher, Stoff und Quelle prüfen und in saubere Werte umwandeln.
   *  - Ein Tank (istTank) hat nur einen Inhalt (Stoff). „Verbraucher“ und Quelle gibt es bei ihm nicht.
   *  - Sonst: verbraucher ist 'ja', 'nein' oder leer (leer = noch nicht beantwortet). Nur bei 'ja' gelten Stoff und Quelle.
   *  - Der Stoff kommt aus der Liste oder ist neu (Feld „neuerStoff“, kommt dann in die Liste, in derselben Speicherung).
   *  - Quellen sind Tanks dieses Fahrzeugs (mehrere erlaubt). Für Strom gibt es noch keine Quelle (spätere Stufe).
   *  - Fehlen alle vier Schlüssel in roh, bleibt der bisherige Stand (bisher) unverändert.
   * Ergebnis: { werte: { verbraucher, stoff, quellen }, fehler, schreiben: [{ tabelle, objekt }] }
   */
  function versorgungVorbereiten(self, fahrzeugId, eigeneId, istTank, roh, bisher) {
    roh = roh || {};
    bisher = bisher || {};
    var V = MM.Versorgung;
    var vorhanden = ['verbraucher', 'stoff', 'neuerStoff', 'quellen', 'verbrauchAus', 'fuellstand', 'spannung', 'weitere'].some(function (k) { return Object.prototype.hasOwnProperty.call(roh, k); });
    if (!vorhanden) {
      var unveraendert = tankFelderUebernehmen({ verbraucher: bisher.verbraucher || null, stoff: bisher.stoff || null, quellen: V.quellenErste(bisher) }, bisher);
      if (bisher.spannung) unveraendert.spannung = bisher.spannung;
      if (Array.isArray(bisher.weitere) && bisher.weitere.length) unveraendert.weitere = JSON.parse(JSON.stringify(bisher.weitere));
      return Promise.resolve({ werte: unveraendert, fehler: {}, schreiben: [] });
    }
    var fehler = {};
    var ver = trimmed2(roh.verbraucher);
    if (!istTank && ver !== '' && ver !== 'ja' && ver !== 'nein') fehler.verbraucher = 'Bitte Ja oder Nein wählen.';
    var verbraucher = istTank ? null : (ver === 'ja' || ver === 'nein' ? ver : null);
    if (!istTank && verbraucher !== 'ja') {
      return Promise.resolve({ werte: { verbraucher: verbraucher, stoff: null, quellen: [] }, fehler: fehler, schreiben: [] });
    }
    /* Füllstand (nur Tank) und „Verbrauch rechnen aus“ (nur Verbraucher), seit 2.0.51 */
    var fuellRoh = istTank && Object.prototype.hasOwnProperty.call(roh, 'fuellstand') ? String(roh.fuellstand === undefined || roh.fuellstand === null ? '' : roh.fuellstand).trim() : '';
    var fuellNeu = null;
    if (fuellRoh !== '') {
      fuellNeu = MM.Tanken.zahl(fuellRoh);
      var kapRoh = MM.Tanken.kapazitaet({ merkmale: roh.merkmale });
      if (fuellNeu === null || fuellNeu < 0) fehler.fuellstand = 'Bitte eine Zahl in Litern eingeben, zum Beispiel 45 oder 0.';
      else if (fuellNeu > 1000000) fehler.fuellstand = 'Der Füllstand ist zu groß.';
      else if (kapRoh !== null && fuellNeu > kapRoh) fehler.fuellstand = 'Der Füllstand ist größer als der Tankinhalt (' + MM.Tanken.text(kapRoh) + ' l).';
    }
    var aus = null;
    if (!istTank) {
      var ausRoh = trimmed2(roh.verbrauchAus);
      if (ausRoh === 'stunden') aus = 'stunden';
      else if (ausRoh === 'fuellstand') aus = bisher.verbrauchAus !== undefined ? 'fuellstand' : null;
      else if (ausRoh === '') aus = bisher.verbrauchAus !== undefined ? bisher.verbrauchAus : null;
      else fehler.verbrauchAus = 'Bitte „Aus dem Füllstand“ oder „Aus den Betriebsstunden“ wählen.';
    }
    return Promise.all([self.speicher.holen('einstellungen', STOFFE_DOK), self.komponentenListe(fahrzeugId), self.speicher.holen('einstellungen', SPANNUNGEN_DOK)]).then(function (r) {
      var dok = listenDok(r[0], STOFFE_DOK), liste = V.stoffeListe(dok), schreiben = [];
      var spannungen = V.spannungenListe(listenDok(r[2], SPANNUNGEN_DOK));
      var stoff = trimmed2(roh.stoff), neu = trimmed2(roh.neuerStoff);
      if (neu) stoff = neu;
      if (stoff) {
        if (stoff.length > V.MAX_STOFF) fehler.stoff = 'Bitte höchstens ' + V.MAX_STOFF + ' Zeichen.';
        else {
          var g = liste.filter(function (x) { return V.gleichText(x.label, stoff); })[0];
          if (g) stoff = g.label;
          else if (neu) {
            var sid = neueId('st');
            dok.eigene.push({ wert: sid, label: stoff, erstelltAm: self.jetzt() });
            schreiben.push({ tabelle: 'einstellungen', objekt: dok });
          } else fehler.stoff = 'Den Stoff „' + stoff + '“ gibt es in der Liste nicht. Bitte einen Stoff aus der Liste wählen oder einen neuen anlegen.';
        }
      }
      if (istTank && stoff && V.istStrom(stoff) && !fehler.stoff) fehler.stoff = 'Ein Tank hält keinen Strom. Eine Batterie ist ein Bauteil (Kapazität, Spannung), ohne Ladezustand.';
      var quellen = [], spannung = null, weitere = [];
      if (!istTank) {
        (Array.isArray(roh.quellen) ? roh.quellen : []).forEach(function (q) { q = String(q); if (q && quellen.indexOf(q) < 0) quellen.push(q); });
        if (stoff && V.istStrom(stoff)) {
          if (quellen.length) fehler.quellen = 'Bei Strom gibt es keinen Tank. Woher der Strom kommt, wählst du beim Einschalten.';
          quellen = [];
          spannung = spannungPruefen(spannungen, roh.spannung, fehler, 'spannung', bisher.spannung);
        } else {
          var nachId = {};
          r[1].forEach(function (x) { nachId[x.komponente.id] = x; });
          if (quellen.some(function (q) { return !nachId[q] || !V.istTank(nachId[q].komponente) || q === eigeneId; })) fehler.quellen = 'Eine gewählte Quelle ist kein Tank dieses Fahrzeugs.';
        }
      }
      /* Weitere Versorgungen (seit 2.0.59): Stoff aus der Liste, bei Strom die Spannung, sonst die Tanks. Eine leere Zeile zählt nicht. */
      var hatWeitere = Object.prototype.hasOwnProperty.call(roh, 'weitere');
      var weitereRoh = hatWeitere ? (Array.isArray(roh.weitere) ? roh.weitere : []) : (Array.isArray(bisher.weitere) ? bisher.weitere : []);
      if (!istTank && weitereRoh.length) {
        if (weitereRoh.length > MAX_WEITERE) fehler.weitere = 'Bitte höchstens ' + MAX_WEITERE + ' weitere Versorgungen.';
        var tankIds = {};
        r[1].forEach(function (x) { if (V.istTank(x.komponente) && x.komponente.id !== eigeneId) tankIds[x.komponente.id] = true; });
        var vorherIds = (Array.isArray(bisher.weitere) ? bisher.weitere : []).map(function (v) { return String(v && v.id); });
        var benutzt = ['v1'];
        weitereRoh.forEach(function (v) { v = v || {}; if (v.id && vorherIds.indexOf(String(v.id)) >= 0 && benutzt.indexOf(String(v.id)) < 0) benutzt.push(String(v.id)); });
        var naechste = 2;
        weitereRoh.forEach(function (v, i) {
          v = v || {};
          var st = trimmed2(v.stoff), pre = 'Versorgung ' + (i + 2) + ': ';
          if (!st) return;
          var g = liste.filter(function (x) { return V.gleichText(x.label, st); })[0];
          if (!g) { if (!fehler.weitere) fehler.weitere = pre + 'Den Stoff „' + st + '“ gibt es in der Liste nicht. Neue Stoffe legst du bei der ersten Versorgung an.'; return; }
          var vid = v.id && vorherIds.indexOf(String(v.id)) >= 0 ? String(v.id) : null;
          if (!vid) { while (benutzt.indexOf('v' + naechste) >= 0) naechste++; vid = 'v' + naechste; benutzt.push(vid); }
          var eintrag = { id: vid, stoff: g.label, quellen: [] };
          if (V.istStrom(g.label)) eintrag.spannung = spannungPruefen(spannungen, v.spannung, fehler, 'weitere', null, pre);
          else {
            (Array.isArray(v.quellen) ? v.quellen : []).forEach(function (q) { q = String(q); if (q && eintrag.quellen.indexOf(q) < 0) eintrag.quellen.push(q); });
            if (eintrag.quellen.some(function (q) { return !tankIds[q]; }) && !fehler.weitere) fehler.weitere = pre + 'Eine gewählte Quelle ist kein Tank dieses Fahrzeugs.';
          }
          weitere.push(eintrag);
        });
      }
      var werte = { verbraucher: verbraucher, stoff: stoff || null, quellen: quellen };
      if (spannung) werte.spannung = spannung;
      if (weitere.length) werte.weitere = weitere;
      if (aus) werte.verbrauchAus = aus;
      var streckeKm = null;
      var ergebnis = function (stunden) {
        tankFelderUebernehmen(werte, bisher);
        if (istTank && fuellNeu !== null && !fehler.fuellstand && fuellNeu !== bisher.fuellstand) {
          werte.fuellstand = MM.Tanken.runde(fuellNeu, 2); werte.fuellstandArt = 'angegeben'; werte.fuellstandZeit = self.jetztLokal();
          werte.fuellstandStunden = stunden || {};
          if (typeof streckeKm === 'number') werte.fuellstandStrecke = streckeKm; else delete werte.fuellstandStrecke;
          var rw = MM.Tanken.reichweite(werte.fuellstand, bisher.verbrauch || null);
          if (rw) werte.reichweite = rw; else delete werte.reichweite;
        }
        return { werte: werte, fehler: fehler, schreiben: fehler.stoff ? [] : schreiben };
      };
      /* Wer den Füllstand neu angibt, hält auch den Stand der Betriebsstunden seiner Verbraucher fest (Grundlage für den Verbrauch). */
      if (istTank && fuellNeu !== null && !fehler.fuellstand && fuellNeu !== bisher.fuellstand && eigeneId) {
        var vids = V.verbraucherVon(r[1], [eigeneId]).map(function (x) { return x.komponente.id; });
        return Promise.all([self.stundenStaende(fahrzeugId, vids, eigeneId), self.streckenStandKm(fahrzeugId)]).then(function (zz) { streckeKm = zz[1]; return ergebnis(zz[0]); });
      }
      return ergebnis(null);
    });
  }

  var TANK_FELDER = ['fuellstand', 'fuellstandArt', 'fuellstandZeit', 'fuellstandStunden', 'fuellstandStrecke', 'verbrauch', 'reichweite'];
  /* Was am Tank von selbst entsteht (Füllstand, Verbrauch, Reichweite) und was beim Verbraucher eingestellt ist, bleibt bei jeder Änderung erhalten. */
  function tankFelderUebernehmen(ziel, bisher) {
    TANK_FELDER.forEach(function (k) { if (bisher[k] !== undefined && ziel[k] === undefined) ziel[k] = bisher[k]; });
    if (bisher.verbrauchAus !== undefined && ziel.verbrauchAus === undefined && ziel.verbraucher === 'ja') ziel.verbrauchAus = bisher.verbrauchAus;
    return ziel;
  }

  /* Der Kilometerstand des Fahrzeugs als Zahl in km, oder null (kein Zähler, kein Stand, andere Einheit). Seit 2.0.56. */
  Daten.prototype.streckenStandKm = function (fahrzeugId) {
    return this.streckenZaehler(fahrzeugId).then(function (z) {
      if (!z || !z.stand || typeof z.stand.wert !== 'number') return null;
      var e = String(z.einheit || 'km').trim().toLowerCase();
      return e === 'km' ? z.stand.wert : null;
    });
  };

  /* Die Einheit der Verbrauchsanzeige (seit 2.0.56): 'auto', 'stunde', 'km', 'sm' oder 'tag'. Liegt als Dokument „verbrauch-einheit“
   * in „einstellungen“ (keine Umstellung des Speichers, in der Sicherung enthalten). Sie bestimmt nur, was vorn steht; gerechnet wird immer alles. */
  Daten.prototype.verbrauchEinheit = function () {
    return this.speicher.holen('einstellungen', MM.Verbrauch.DOKUMENT).then(function (dok) { return MM.Verbrauch.einheitAus(dok); });
  };
  Daten.prototype.verbrauchEinheitSetzen = function (wert) {
    var self = this;
    if (!MM.Verbrauch.istEinheit(wert)) return Promise.resolve({ ok: false, fehler: { allgemein: 'Bitte eine Einheit aus der Liste wählen.' } });
    return this.speicher.holen('einstellungen', MM.Verbrauch.DOKUMENT).then(function (dok) {
      return self.speicher.speichern('einstellungen', MM.Verbrauch.dokumentSetzen(dok, wert));
    }).then(function () { return { ok: true, einheit: wert }; });
  };

  /* Stand der Betriebsstunden-Zähler der genannten Komponenten: { Kennung: Stand }. Ohne Zähler oder ohne Stand fehlt der Eintrag. */
  /* tankId (seit 2.0.59, freiwillig): Hat ein Verbraucher mehrere Versorgungen, zählen für diesen Tank nur die Betriebsstunden in den
   * Versorgungen, die aus diesem Tank beziehen (Summe seiner beendeten Läufe), nicht der ganze Zähler. */
  Daten.prototype.stundenStaende = function (fahrzeugId, ids, tankId) {
    var self = this;
    return Promise.all([this.zaehlerListe(fahrzeugId), tankId ? this.komponentenListe(fahrzeugId) : Promise.resolve(null), tankId ? laufDokument(this) : Promise.resolve(null)]).then(function (r) {
      var liste = r[0], o = {};
      (ids || []).forEach(function (id) {
        if (tankId) {
          var k = r[1].filter(function (x) { return x.komponente.id === id; })[0];
          var vl = k ? MM.Versorgung.versorgungenListe(k.aktuell.werte) : [];
          if (vl.length > 1) {
            var meine = r[2].laeufe.filter(function (l) { return l.komponenteId === id; });
            o[id] = MM.Versorgung.stundenAmTank(meine, vl, tankId);
            return;
          }
        }
        var z = liste.filter(function (x) { return x.komponenteId === id && x.art === 'stunden'; })[0];
        if (z && z.stand && typeof z.stand.wert === 'number') o[id] = z.stand.wert;
      });
      return o;
    });
  };

  /* Die Kette eines Fahrzeugs: Tanks mit ihren Verbrauchern, Verbraucher ohne Quelle, offene Fragen, Tank-Vorschläge. Siehe MM.Versorgung.kette. */
  Daten.prototype.versorgungKette = function (fahrzeugId) {
    return this.komponentenListe(fahrzeugId).then(function (liste) { return MM.Versorgung.kette(liste); });
  };

  /* Wassertank kennzeichnen (seit 2.0.132): Art „Tank“ und Inhalt in einem Schritt, damit er bei der Ver- und Entsorgung erscheint. Der Verlauf hält es fest. */
  Daten.prototype.wassertankKennzeichnen = function (id, stoff) {
    var self = this;
    if (!MM.Versorgung.WASSERTANK_STOFFE.some(function (x) { return x.stoff === stoff; })) return Promise.resolve({ ok: false, fehler: { allgemein: 'Bitte Frischwasser, Grauwasser oder Schwarzwasser wählen.' } });
    return this.komponenteLaden(id).then(function (c) {
      if (!c) return { ok: false, fehler: { allgemein: 'Diese Komponente gibt es nicht.' } };
      if (c.aktuell.werte.verbraucher === 'ja') return { ok: false, fehler: { allgemein: 'Diese Komponente ist als Verbraucher eingetragen. Ein Tank ist kein Verbraucher.' } };
      var vorab = MM.Versorgung.istTank(c.komponente) ? Promise.resolve({ ok: true }) : self.komponenteVerschieben(id, { parentId: null, art: 'tank' });
      return vorab.then(function (r) {
        if (!r.ok) return r;
        return self.komponenteLaden(id).then(function (n) {
          var werte = JSON.parse(JSON.stringify(n.aktuell.werte));
          werte.stoff = stoff;
          delete werte.verbraucher;
          var e = { id: neueId('ke'), komponenteId: id, nr: n.aktuell.nr + 1, werte: werte, quelle: 'hand', korrekturZu: n.aktuell.id, erstelltAm: self.jetzt() };
          return self.speicher.mehrereSpeichern([{ tabelle: 'komponenteneintraege', objekt: e }]).then(function () { return { ok: true, id: id }; });
        });
      });
    });
  };

  /* ---------- Komponenten löschen, ausblenden, verschieben (seit 2.0.45) ---------- */

  /*
   * Wird eine Komponente (oder ein Teil darunter) irgendwo benutzt? Das ist die EINE Stelle für diese Frage.
   * Benutzt heißt: Frist, Zähler, Motorlauf, Kosten (auch im Verlauf eines Postens), Werkstatt-Vorgang, Dokument
   * oder ein von dir bestätigter Name bei der Pflichtausrüstung („Habe ich unter anderem Namen“).
   * Ergebnis: { benutzt, gruende: [Text], anzahlUnter, inUnterteilen: ob die Verwendung an einem Teil darunter hängt }
   */
  Daten.prototype.komponenteVerwendung = function (id) {
    var self = this;
    return this.speicher.holen('komponenten', id).then(function (k) {
      if (!k) return null;
      var fid = k.fahrzeugId;
      return Promise.all([self.komponentenListe(fid), self.speicher.wo('zaehler', 'fahrzeugId', fid), self.speicher.wo('fristen', 'fahrzeugId', fid),
        self.speicher.wo('vorgaenge', 'fahrzeugId', fid), self.speicher.wo('dokumente', 'fahrzeugId', fid), self.speicher.alle('verlaeufe'),
        laufDokument(self), self.zuordnungenDokument()]).then(function (r) {
        var ids = MM.Komponenten.mitUnterkomponenten(r[0], id);
        function drin(x) { return ids.indexOf(x) >= 0; }
        var gruende = [], anUnter = false;
        function zaehle(n, einzahl, mehrzahl, objekte) {
          if (!n) return;
          gruende.push(n === 1 ? '1 ' + einzahl : n + ' ' + mehrzahl);
          if (objekte.some(function (x) { return x !== id; })) anUnter = true;
        }
        var z = r[1].filter(function (x) { return x.komponenteId && drin(x.komponenteId); });
        zaehle(z.length, 'Zähler', 'Zähler', z.map(function (x) { return x.komponenteId; }));
        var fr = r[2].filter(function (x) { return x.komponenteId && drin(x.komponenteId); });
        zaehle(fr.length, 'Frist', 'Fristen', fr.map(function (x) { return x.komponenteId; }));
        var vg = r[3].filter(function (x) { return x.komponenteId && drin(x.komponenteId); });
        zaehle(vg.length, 'Werkstatt-Vorgang', 'Werkstatt-Vorgänge', vg.map(function (x) { return x.komponenteId; }));
        var dk = r[4].filter(function (x) { return x.komponenteId && drin(x.komponenteId); });
        zaehle(dk.length, 'Dokument', 'Dokumente', dk.map(function (x) { return x.komponenteId; }));
        var posten = {}, postenKomp = [];
        r[5].forEach(function (x) {
          if (x.objektTyp === 'kosten' && x.werte && x.werte.komponenteId && drin(x.werte.komponenteId) && !posten[x.objektId]) { posten[x.objektId] = true; postenKomp.push(x.werte.komponenteId); }
        });
        zaehle(postenKomp.length, 'Kostenposten', 'Kostenposten', postenKomp);
        var lauf = (r[6].laeufe || []).filter(function (l) { return l.komponenteId && drin(l.komponenteId); });
        var nurMotorLauf = lauf.every(function (l) { var kk = r[0].filter(function (x) { return x.komponente.id === l.komponenteId; })[0]; return !!kk && MM.Komponenten.istMotor(kk.komponente); });
        zaehle(lauf.length, nurMotorLauf ? 'Motorlauf' : 'Lauf', nurMotorLauf ? 'Motorläufe' : 'Läufe', lauf.map(function (l) { return l.komponenteId; }));
        var namen = {};
        r[0].forEach(function (x) { if (drin(x.komponente.id)) namen[x.komponente.id] = x.aktuell.werte.bezeichnung; });
        var gleichGesetzt = [];
        ((r[7] && r[7].eintraege) || []).forEach(function (e) {
          (e.namen || []).forEach(function (nm) {
            Object.keys(namen).forEach(function (kid) { if (MM.Komponenten.gleichText(namen[kid], nm)) gleichGesetzt.push(kid); });
          });
        });
        if (gleichGesetzt.length) { gruende.push('bei der Pflichtausrüstung gleichgesetzt'); if (gleichGesetzt.some(function (x) { return x !== id; })) anUnter = true; }
        /* Ein Tank, aus dem ein Verbraucher bezieht (seit 2.0.48), wird benutzt. Dann nur ausblenden, sonst hängt die Quelle ins Leere. */
        var kunden = MM.Versorgung.verbraucherVon(r[0], ids).filter(function (x) { return !drin(x.komponente.id); });
        var bezogen = [];
        kunden.forEach(function (x) { MM.Versorgung.quellenIds(x.aktuell.werte).forEach(function (q) { if (drin(q)) bezogen.push(q); }); });
        zaehle(kunden.length, 'Verbraucher, der hier bezieht', 'Verbraucher, die hier beziehen', bezogen);
        return { benutzt: gruende.length > 0, gruende: gruende, anzahlUnter: ids.length - 1, inUnterteilen: anUnter, ids: ids };
      });
    });
  };

  /* Löschen nur, wenn nichts benutzt wird. Gelöscht werden die Komponente, alle Teile darunter und ihre Einträge. */
  Daten.prototype.komponenteLoeschen = function (id) {
    var self = this;
    return this.komponenteVerwendung(id).then(function (v) {
      if (!v) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      if (v.benutzt) return { ok: false, benutzt: true, gruende: v.gruende, fehler: { allgemein: 'Diese Komponente wird benutzt (' + v.gruende.join(', ') + (v.inUnterteilen ? ', zum Teil an einem Teil darunter' : '') + '). Benutzte Komponenten lassen sich nur ausblenden.' } };
      return self.speicher.alle('komponenteneintraege').then(function (alle) {
        var weg = v.ids.map(function (i) { return { tabelle: 'komponenten', id: i }; });
        alle.forEach(function (e) { if (v.ids.indexOf(e.komponenteId) >= 0) weg.push({ tabelle: 'komponenteneintraege', id: e.id }); });
        return self.speicher.mehrereLoeschen(weg).then(function () { return { ok: true, anzahl: v.ids.length, anzahlUnter: v.anzahlUnter }; });
      });
    });
  };

  /* Ausblenden oder wieder einblenden. Das steht als eigener Eintrag im Verlauf. Eine ausgeblendete Hauptkomponente verdeckt alles darunter. */
  Daten.prototype.komponenteAusblenden = function (id, ausblenden) {
    var self = this;
    ausblenden = !!ausblenden;
    return this.komponenteLaden(id).then(function (c) {
      if (!c) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      if (!!c.komponente.ausgeblendet === ausblenden) return { ok: true, id: id, geaendert: false };
      var k = Object.assign({}, c.komponente);
      if (ausblenden) k.ausgeblendet = true; else delete k.ausgeblendet;
      var e = { id: neueId('ke'), komponenteId: id, nr: c.aktuell.nr + 1, werte: JSON.parse(JSON.stringify(c.aktuell.werte)),
        quelle: 'hand', korrekturZu: c.aktuell.id, erstelltAm: self.jetzt(), sichtbarkeit: ausblenden ? 'ausgeblendet' : 'eingeblendet' };
      return self.speicher.mehrereSpeichern([{ tabelle: 'komponenten', objekt: k }, { tabelle: 'komponenteneintraege', objekt: e }])
        .then(function () { return { ok: true, id: id, geaendert: true }; });
    });
  };

  /*
   * Wohin darf eine Komponente verschoben werden? Unter jede andere Komponente desselben Fahrzeugs, nur nicht unter sich selbst
   * und nicht unter ein Teil darunter, oder direkt unters Fahrzeug (dann ist sie Hauptkomponente und braucht eine Art).
   * Ergebnis: [{ id, name, weg }] (weg = Text wie „Motor › Einspritzung“)
   */
  Daten.prototype.komponenteZiele = function (id) {
    var self = this;
    return this.speicher.holen('komponenten', id).then(function (k) {
      if (!k) return null;
      return self.komponentenListe(k.fahrzeugId).then(function (liste) {
        var nachId = {}; liste.forEach(function (x) { nachId[x.komponente.id] = x; });
        var gesperrt = MM.Komponenten.mitUnterkomponenten(liste, id);
        function weg(x) { var t = [x.aktuell.werte.bezeichnung], p = x.komponente.parentId, n = 0; while (p && nachId[p] && n++ < 50) { t.unshift(nachId[p].aktuell.werte.bezeichnung); p = nachId[p].komponente.parentId; } return t.join(' › '); }
        return self.sortiereKomponenten(liste.filter(function (x) { return gesperrt.indexOf(x.komponente.id) < 0; }))
          .map(function (x) { return { id: x.komponente.id, name: x.aktuell.werte.bezeichnung, weg: weg(x) }; });
      });
    });
  };

  /*
   * Verschiebt eine Komponente samt allem darunter. ziel: { parentId: Kennung oder null, art: Art (nur bei null Pflicht) }.
   * Geändert wird nur der Platz (parentId, bei einer Hauptkomponente die Art). Alle Verweise laufen über die Kennung und bleiben gültig.
   * Der Verlauf hält fest, von wo nach wo. In ein anderes Fahrzeug wird nicht verschoben.
   */
  Daten.prototype.komponenteVerschieben = function (id, ziel) {
    var self = this;
    ziel = ziel || {};
    var neuParent = ziel.parentId ? String(ziel.parentId) : null;
    return this.komponenteLaden(id).then(function (c) {
      if (!c) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      return self.komponentenListe(c.fahrzeug.id).then(function (liste) {
        var nachId = {}; liste.forEach(function (x) { nachId[x.komponente.id] = x; });
        if (neuParent) {
          if (!nachId[neuParent]) return { ok: false, fehler: { parentId: 'Diese Komponente gibt es an diesem Fahrzeug nicht. In ein anderes Fahrzeug lässt sich nicht verschieben.' } };
          if (MM.Komponenten.mitUnterkomponenten(liste, id).indexOf(neuParent) >= 0) return { ok: false, fehler: { parentId: 'Das geht nicht: Eine Komponente lässt sich nicht unter sich selbst oder unter ein Teil von sich verschieben.' } };
        } else if (!MM.Komponenten.art(ziel.art)) return { ok: false, fehler: { art: 'Bitte die Art der Hauptkomponente wählen (zum Beispiel „Sonstiges“).' } };
        var altParent = c.komponente.parentId || null, altArt = c.komponente.art || null;
        var neuArt = neuParent ? null : ziel.art;
        if (altParent === neuParent && altArt === neuArt) return { ok: true, id: id, geaendert: false };
        /* Tank und Verbraucher (seit 2.0.48): Ein Tank, aus dem Verbraucher beziehen, bleibt ein Tank. Ein Verbraucher wird kein Tank. */
        var warTank = MM.Versorgung.istTank(c.komponente), wirdTank = !neuParent && neuArt === 'tank';
        if (warTank && !wirdTank) {
          var kunden = MM.Versorgung.verbraucherVon(liste, id);
          if (kunden.length) return { ok: false, fehler: { allgemein: 'Dieser Tank versorgt ' + (kunden.length === 1 ? '1 Verbraucher' : kunden.length + ' Verbraucher') + ' (' + kunden.map(function (x) { return x.aktuell.werte.bezeichnung; }).join(', ') + '). Nimm ihn dort zuerst als Quelle heraus, dann lässt er sich verschieben oder umwandeln.' } };
        }
        if (wirdTank && !warTank && c.aktuell.werte.verbraucher === 'ja') return { ok: false, fehler: { art: 'Diese Komponente ist als Verbraucher eingetragen. Ein Tank ist kein Verbraucher. Ändere zuerst die Angabe „Verbraucher“.' } };
        function ortText(parentId, art) {
          if (!parentId) { var a = MM.Komponenten.art(art); return 'direkt am Fahrzeug' + (a ? ' (Art: ' + a.name + ')' : ''); }
          var t = [], p = parentId, n = 0; while (p && nachId[p] && n++ < 50) { t.unshift(nachId[p].aktuell.werte.bezeichnung); p = nachId[p].komponente.parentId; }
          return 'unter ' + t.join(' › ');
        }
        var pruefung = !neuParent && neuArt === 'motor' ? self.kurznameKollision(c.fahrzeug.id, id, c.aktuell.werte) : Promise.resolve(null);
        return pruefung.then(function (f) {
          if (f) return { ok: false, fehler: f };
          var k = Object.assign({}, c.komponente);
          k.parentId = neuParent; k.art = neuArt;
          var e = { id: neueId('ke'), komponenteId: id, nr: c.aktuell.nr + 1, werte: JSON.parse(JSON.stringify(c.aktuell.werte)),
            quelle: 'hand', korrekturZu: c.aktuell.id, erstelltAm: self.jetzt(),
            verschoben: { von: ortText(altParent, altArt), nach: ortText(neuParent, neuArt), vonParentId: altParent, nachParentId: neuParent, vonArt: altArt, nachArt: neuArt } };
          return self.speicher.mehrereSpeichern([{ tabelle: 'komponenten', objekt: k }, { tabelle: 'komponenteneintraege', objekt: e }])
            .then(function () { return { ok: true, id: id, geaendert: true }; });
        });
      });
    });
  };

  /* ---------- Hilfen für Zähler und Fristen ---------- */
  Daten.prototype.heute = function () {
    var d = new Date(this.jetzt());
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
  };

  function jahrVon(self) { return new Date(self.jetzt()).getFullYear(); }

  /* Prüft, ob Fahrzeug (und Komponente) existieren und zusammengehören. Gibt null oder einen Fehler zurück. */
  Daten.prototype.pruefeObjekt = function (fahrzeugId, komponenteId) {
    return Promise.all([
      this.speicher.holen('fahrzeuge', fahrzeugId),
      komponenteId ? this.speicher.holen('komponenten', komponenteId) : Promise.resolve(null)
    ]).then(function (r) {
      if (!r[0]) return { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' };
      if (komponenteId && (!r[1] || r[1].fahrzeugId !== fahrzeugId)) return { allgemein: 'Diese Komponente wurde nicht gefunden.' };
      return null;
    });
  };

  /* Verlauf der Angaben zu einem Objekt (Zähler, Frist): neueste zuerst, mit Unterschieden. */
  function verlaufAus(eintraege, felder) {
    var auf = eintraege.slice().sort(nachNr);
    return auf.map(function (e, i) {
      var vorher = i > 0 ? auf[i - 1] : null;
      return { eintrag: e, vorher: vorher, aenderungen: vorher ? unterschiedeFelder(felder, vorher.werte, e.werte) : [] };
    }).reverse();
  }
  function neuerVerlaufEintrag(typ, objektId, nr, werte, korrekturZu, jetzt) {
    return { id: neueId('vl'), objektTyp: typ, objektId: objektId, nr: nr, werte: werte,
      quelle: 'hand', korrekturZu: korrekturZu, erstelltAm: jetzt };
  }

  /* ---------- Zähler und Zählerstände ---------- */
  /*
   * Ein Zähler zählt Strecke (km) oder Betriebsstunden (h) und hängt am
   * Fahrzeug oder an einer einzelnen Komponente (zum Beispiel pro Motor).
   * Der Stand ist ein Verlauf von Einträgen. Der aktuelle Stand ist der
   * neueste Eintrag, ein Handeintrag hat Vorrang.
   */
  Daten.prototype.zaehlerAnlegen = function (fahrzeugId, komponenteId, art, roh) {
    var self = this;
    var p = pruefeWerte([], roh, jahrVon(this));
    var fehler = p.fehler;
    if (!MM.Fristen.zaehlerArt(art)) fehler.art = 'Bitte wählen, ob der Zähler Strecke oder Betriebsstunden zählt.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      var jetzt = self.jetzt();
      var z = { id: neueId('za'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, art: art, erstelltAm: jetzt };
      var e = neuerVerlaufEintrag('zaehler', z.id, 1, p.werte, null, jetzt);
      return self.speicher.mehrereSpeichern([{ tabelle: 'zaehler', objekt: z }, { tabelle: 'verlaeufe', objekt: e }])
        .then(function () { return { ok: true, id: z.id }; });
    });
  };

  Daten.prototype.zaehlerAendern = function (zaehlerId, roh) {
    var self = this;
    return this.zaehlerLaden(zaehlerId).then(function (z) {
      if (!z) return { ok: false, fehler: { allgemein: 'Dieser Zähler wurde nicht gefunden.' } };
      var p = pruefeWerte([], roh, jahrVon(self));
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (!unterschiedeFelder([], z.aktuell.werte, p.werte).length) return { ok: true, id: zaehlerId, geaendert: false };
      var e = neuerVerlaufEintrag('zaehler', zaehlerId, z.aktuell.nr + 1, p.werte, z.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: zaehlerId, geaendert: true }; });
    });
  };

  var FELDER_STAND = [
    { key: 'wert', label: 'Zählerstand', typ: 'zahl' },
    { key: 'datum', label: 'Abgelesen am', typ: 'datum' },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  Daten.prototype.zaehlerStandEintragen = function (zaehlerId, roh) {
    var self = this;
    var p = pruefeWerte(FELDER_STAND, roh, jahrVon(this), { ohneBezeichnung: true });
    var fehler = p.fehler, w = p.werte, heute = this.heute();
    if (w.wert === null && !fehler.wert) fehler.wert = 'Bitte den Zählerstand eingeben.';
    if (!w.datum && !fehler.datum) w.datum = heute;
    if (w.datum && w.datum > heute && !fehler.datum) fehler.datum = 'Das Datum liegt in der Zukunft.';
    return this.speicher.holen('zaehler', zaehlerId).then(function (z) {
      if (!z) return { ok: false, fehler: { allgemein: 'Dieser Zähler wurde nicht gefunden.' } };
      return self.speicher.wo('zaehlerstaende', 'zaehlerId', zaehlerId).then(function (staende) {
        var letzter = staende.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null);
        if (letzter && w.wert !== null && w.wert < letzter.wert && !fehler.wert) {
          var einheit = MM.Fristen.zaehlerArt(z.art).einheit;
          fehler.wert = 'Der Stand ist niedriger als der letzte Eintrag (' + MM.Hilfen.zahl(letzter.wert) + ' ' + einheit +
            ' vom ' + MM.Hilfen.datum(letzter.datum) + '). Zählerstände steigen. Wurde der Zähler getauscht, lege einen neuen Zähler an.';
        }
        if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
        var e = { id: neueId('zs'), zaehlerId: zaehlerId, nr: letzter ? letzter.nr + 1 : 1, wert: w.wert, datum: w.datum,
          notiz: w.notiz, quelle: 'hand', erstelltAm: self.jetzt() };
        return self.speicher.speichern('zaehlerstaende', e).then(function () { return { ok: true, id: e.id }; });
      });
    });
  };

  /* Alle Zähler eines Fahrzeugs mit Name, aktuellem Stand und Besitzer (Fahrzeug oder Komponente). */
  Daten.prototype.zaehlerListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([
      this.speicher.wo('zaehler', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.speicher.alle('zaehlerstaende'),
      this.komponentenListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'zaehler') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var sta = {}; r[2].forEach(function (e) { (sta[e.zaehlerId] = sta[e.zaehlerId] || []).push(e); });
      var kn = {}; r[3].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      return r[0].map(function (z) {
        var namen = (ver[z.id] || []).slice().sort(nachNr);
        var aktuell = namen[namen.length - 1];
        if (!aktuell) return null;
        var liste = (sta[z.id] || []).slice().sort(nachNr);
        var letzter = liste[liste.length - 1] || null;
        var art = MM.Fristen.zaehlerArt(z.art);
        var besitzer = z.komponenteId ? (kn[z.komponenteId] || 'Komponente') : 'Fahrzeug';
        return { zaehler: z, bezeichnung: aktuell.werte.bezeichnung, einheit: art.einheit, art: z.art,
          stand: letzter ? { wert: letzter.wert, datum: letzter.datum, quelle: letzter.quelle || 'hand' } : null,
          komponenteId: z.komponenteId, besitzer: besitzer,
          label: aktuell.werte.bezeichnung + ' (' + besitzer + ')' };
      }).filter(Boolean).sort(function (a, b) { return a.label.localeCompare(b.label, 'de', { numeric: true }); });
    });
  };

  Daten.prototype.zaehlerLaden = function (id) {
    var self = this;
    return this.speicher.holen('zaehler', id).then(function (z) {
      if (!z) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('zaehlerstaende', 'zaehlerId', id),
        self.fahrzeugLaden(z.fahrzeugId),
        self.komponentenListe(z.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[2]) return null;
        var staende = r[1].slice().sort(nachNr).reverse();
        var komp = z.komponenteId ? r[3].filter(function (k) { return k.komponente.id === z.komponenteId; })[0] : null;
        var art = MM.Fristen.zaehlerArt(z.art);
        return { zaehler: z, aktuell: eintraege[eintraege.length - 1], bezeichnung: eintraege[eintraege.length - 1].werte.bezeichnung,
          verlauf: verlaufAus(eintraege, []), staende: staende, stand: staende[0] || null, art: art, einheit: art.einheit,
          fahrzeug: r[2].fahrzeug, fahrzeugAktuell: r[2].aktuell, komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /*
   * Der Kilometer-Zähler eines Fahrzeugs (seit 2.0.20): der Zähler der Art Strecke, der am Fahrzeug selbst hängt.
   * Gibt es mehrere, gilt der mit dem jüngsten Stand (bei gleichem Datum der höhere). Null, wenn es keinen gibt.
   * Die Kilometer trägt der Nutzer von Hand ein; GPS wäre später nur eine weitere Quelle, nie Voraussetzung.
   */
  Daten.prototype.streckenZaehler = function (fahrzeugId) {
    return this.zaehlerListe(fahrzeugId).then(function (liste) {
      var meine = liste.filter(function (x) { return x.art === 'strecke' && !x.komponenteId; });
      if (!meine.length) return null;
      meine.sort(function (a, b) {
        var da = a.stand ? a.stand.datum : '', db = b.stand ? b.stand.datum : '';
        if (da !== db) return da < db ? 1 : -1;
        return (b.stand ? b.stand.wert : -1) - (a.stand ? a.stand.wert : -1);
      });
      var z = meine[0];
      return { id: z.zaehler.id, bezeichnung: z.bezeichnung, einheit: z.einheit, stand: z.stand };
    });
  };

  /* ---------- Läufe: Ein und Aus für jeden Verbraucher (Motor seit 2.0.19, allgemein seit 2.0.52) ---------- */
  /*
   * Ein Lauf hat Start, Stopp, Dauer und füllt den Betriebsstunden-Zähler des Verbrauchers. Das gilt für jeden Verbraucher
   * (Komponente mit „Verbraucher: ja“) und für jeden Motor; der Motor ist nur der erste Verbraucher mit dieser Fähigkeit.
   * Die Läufe liegen als ein Dokument „motorlaeufe“ in „einstellungen“ (keine Umstellung des Speichers, in der Sicherung enthalten;
   * der Name des Dokuments bleibt, damit bestehende Läufe gültig bleiben). Beim Stopp entsteht ein neuer Zählerstand
   * (Quelle „schalter“): letzter Stand plus Laufzeit. Nichts wird überschrieben: Eine Korrektur der Stoppzeit ist ein weiterer
   * Zählerstand (Quelle „korrektur“), der alte bleibt im Verlauf.
   * Allgemeine Namen: verbraucherStart, verbraucherStopp, verbraucherLaufKorrigieren, verbraucherZaehler, verbraucherListe,
   * verbraucherAuswahl. Die Namen motorStart, motorStopp, motorLaufKorrigieren, motorZaehler, motorenListe bleiben als
   * Weiterleitung mit den Texten und dem Verhalten für Motoren.
   */
  var MOTORLAEUFE = 'motorlaeufe';
  function laufDokument(self) {
    return self.speicher.holen('einstellungen', MOTORLAEUFE).then(function (d) { return d || { id: MOTORLAEUFE, laeufe: [] }; });
  }
  function laufFehler(text, feld) { var f = {}; f[feld || 'allgemein'] = text; return { ok: false, fehler: f }; }
  function neuesterStand(staende) { return staende.reduce(function (a, b) { return (!a || b.nr > a.nr) ? b : a; }, null); }
  function zeitMs(iso) { return new Date(iso).getTime(); }

  /* Ist beim Einschalten eine Wahl nötig? Ja bei mehreren Versorgungen und bei einer einzigen mit Wechselstrom (Quelle: Landstrom, Generator, Wechselrichter). */
  function versorgungWahlNoetig(vl, spannungen) {
    if (vl.length > 1) return true;
    return vl.length === 1 && vl[0].strom && MM.Versorgung.spannungArt(spannungen, vl[0].spannung) === 'wechsel';
  }

  /*
   * Die Wahl beim Einschalten prüfen (seit 2.0.59). Ergebnis: { fehler } oder { versorgung: { versorgungId, versorgungName, stromQuelle, erzeugerId } } oder { versorgung: null } (keine Versorgung angegeben).
   * Mehrere Versorgungen: der Nutzer muss wählen. Bei Wechselstrom muss er die Quelle wählen. Generator und Wechselrichter sind Komponenten des Fahrzeugs mit dem Feld
   * „Liefert Strom als“; gibt es genau eine, gilt sie von selbst. Gibt es keine, bleibt die Quelle ohne Gerät.
   */
  function versorgungWaehlen(w, komponentenListe, spannungen, optionen, eigeneId) {
    var V = MM.Versorgung, vl = V.versorgungenListe(w);
    if (!vl.length) return { versorgung: null };
    var gewaehlt = null;
    if (optionen.versorgungId) {
      gewaehlt = vl.filter(function (v) { return v.id === optionen.versorgungId; })[0];
      if (!gewaehlt) return { fehler: { versorgung: 'Diese Versorgung gibt es bei diesem Verbraucher nicht.' } };
    } else if (vl.length === 1) gewaehlt = vl[0];
    else return { fehler: { versorgung: 'Bitte wählen, womit dieser Verbraucher läuft.' } };
    var res = { versorgungId: gewaehlt.id, versorgungName: V.versorgungName(gewaehlt), stromQuelle: null, erzeugerId: null };
    if (!gewaehlt.strom) return { versorgung: res };
    var art = V.spannungArt(spannungen, gewaehlt.spannung);
    var erlaubt = art ? V.stromQuellenFuer(art).map(function (q) { return q.wert; }) : V.STROM_QUELLEN.map(function (q) { return q.wert; });
    var quelle = optionen.stromQuelle || null;
    if (!quelle && art === 'gleich') quelle = 'batterie';
    if (!quelle && art === 'wechsel') return { fehler: { stromQuelle: 'Bitte wählen, woher der Strom kommt (Landstrom, Generator oder Wechselrichter).' } };
    if (quelle && erlaubt.indexOf(quelle) < 0) return { fehler: { stromQuelle: 'Diese Quelle passt nicht zu ' + (gewaehlt.spannung || 'dieser Spannung') + '.' } };
    res.stromQuelle = quelle;
    if (quelle === 'generator' || quelle === 'wechselrichter') {
      var kandidaten = (komponentenListe || []).filter(function (x) {
        var r = x.aktuell.werte.stromRolle;
        return x.komponente.id !== eigeneId && !x.aktuell.werte.ausgebautAm && !x.komponente.ausgeblendet && r === quelle;
      });
      if (optionen.erzeugerId) {
        if (!kandidaten.some(function (x) { return x.komponente.id === optionen.erzeugerId; })) return { fehler: { erzeuger: 'Dieses Gerät ist nicht als ' + V.stromQuelleLabel(quelle) + ' angelegt.' } };
        res.erzeugerId = optionen.erzeugerId;
      } else if (kandidaten.length === 1) res.erzeugerId = kandidaten[0].komponente.id;
      else if (kandidaten.length > 1) return { fehler: { erzeuger: 'Bitte wählen, welcher ' + V.stromQuelleLabel(quelle) + ' es ist.' } };
    }
    return { versorgung: res };
  }

  /* Wörter für Meldungen: beim Motor wie bisher, sonst „Verbraucher“. */
  var WORT_MOTOR = { dieser: 'Dieser Motor', dieses: 'dieses Motors', lauf: 'Motorlauf', gestoppt: 'Motor gestoppt', stoppZiel: 'Stoppzeit von der Ankunft übernommen' };
  var WORT_VERBRAUCHER = { dieser: 'Dieser Verbraucher', dieses: 'dieses Verbrauchers', lauf: 'Lauf', gestoppt: 'Verbraucher gestoppt', stoppZiel: 'Stoppzeit von der Ankunft übernommen' };
  function laufWort(komponente) { return MM.Komponenten.istMotor(komponente) ? WORT_MOTOR : WORT_VERBRAUCHER; }

  /* Der Betriebsstunden-Zähler eines Verbrauchers. Gibt es keinen, entsteht er hier („Betriebsstunden“). */
  Daten.prototype.verbraucherZaehler = function (fahrzeugId, komponenteId) {
    var self = this;
    return this.zaehlerListe(fahrzeugId).then(function (liste) {
      var z = liste.filter(function (x) { return x.komponenteId === komponenteId && x.art === 'stunden'; })[0];
      if (z) return { ok: true, id: z.zaehler.id };
      return self.zaehlerAnlegen(fahrzeugId, komponenteId, 'stunden', { bezeichnung: 'Betriebsstunden' });
    });
  };
  Daten.prototype.motorZaehler = function (fahrzeugId, komponenteId) { return this.verbraucherZaehler(fahrzeugId, komponenteId); };

  /*
   * Die Läufe einer Auswahl von Komponenten eines Fahrzeugs in der Reihenfolge der Komponenten: Name, Kurzname (und was auf dem Knopf steht),
   * läuft oder nicht (seit wann), Zähler mit Stand und die letzten fünf Läufe. Eine ausgebaute oder ausgeblendete Komponente fehlt,
   * außer sie läuft noch. passt: Funktion über { komponente, aktuell }.
   */
  function laufListe(self, fahrzeugId, passt) {
    return Promise.all([self.komponentenListe(fahrzeugId), self.zaehlerListe(fahrzeugId), laufDokument(self), self.spannungenListe()]).then(function (r) {
      var heute = self.heute();
      var spannungenAlle = r[3];
      var verdeckt = MM.Komponenten.verdecktIds(r[0]);
      var motoren = self.sortiereKomponenten(r[0].filter(passt));
      return Promise.all(motoren.map(function (k) {
        var w = k.aktuell.werte, id = k.komponente.id;
        var meine = r[2].laeufe.filter(function (l) { return l.komponenteId === id; }).sort(function (a, b) { return zeitMs(b.start) - zeitMs(a.start); });
        var offen = meine.filter(function (l) { return !l.stopp; })[0] || null;
        if (w.ausgebautAm && w.ausgebautAm <= heute && !offen) return null;
        /* Ein ausgeblendeter Motor hat keinen Schalter, außer er läuft noch (seit 2.0.45). */
        if (verdeckt[id] && !offen) return null;
        var z = r[1].filter(function (x) { return x.komponenteId === id && x.art === 'stunden'; })[0] || null;
        var zu = z ? self.speicher.wo('zaehlerstaende', 'zaehlerId', z.zaehler.id) : Promise.resolve([]);
        return zu.then(function (staende) {
          var neuester = neuesterStand(staende);
          var zu_ = meine.filter(function (l) { return l.stopp; });
          return {
            komponenteId: id, name: w.bezeichnung, kurzname: w.kurzname || null, kurz: MM.Komponenten.kurzAnzeige(w), istMotor: MM.Komponenten.istMotor(k.komponente),
            laeuft: !!offen, seit: offen ? offen.start : null, laufId: offen ? offen.id : null,
            /* seit 2.0.59: Beim Einschalten ist eine Wahl nötig, wenn es mehrere Versorgungen gibt oder der Strom Wechselstrom ist (Quelle). */
            versorgungWahl: !offen && versorgungWahlNoetig(MM.Versorgung.versorgungenListe(w), spannungenAlle),
            laeuftMit: offen && offen.versorgungName ? offen.versorgungName + (offen.stromQuelle ? ' (' + (MM.Versorgung.stromQuelleLabel(offen.stromQuelle) || offen.stromQuelle) + ')' : '') : null,
            frageEreignisId: offen && offen.frage ? offen.frage.ereignisId : null, frageStufe: offen && offen.frage ? offen.frage.stufe : null,
            zaehler: z ? { id: z.zaehler.id, stand: z.stand, einheit: z.einheit } : null,
            laeufe: zu_.slice(0, 5).map(function (l, i) {
              return { id: l.id, start: l.start, stopp: l.stopp, stunden: l.stunden, standNachher: l.standNachher,
                korrigiert: !!(l.korrekturen && l.korrekturen.length),
                korrigierbar: i === 0 && !offen && !!neuester && neuester.id === l.standId };
            })
          };
        });
      })).then(function (liste) { return liste.filter(Boolean); });
    });
  }

  /*
   * Schalter für jeden Verbraucher (seit 2.0.53): Jeder Verbraucher (Komponente mit „Verbraucher: ja“, kein Motor) hat von selbst einen
   * Schalter, wie der Motor. Welche davon im Cockpit stehen, wählt der Nutzer je Fahrzeug: Das Dokument „cockpit-verbraucher“ in
   * „einstellungen“ (in der Sicherung enthalten) merkt nur, was er AUSGEBLENDET hat { versteckt: { fahrzeugId: [komponenteId] } }.
   * Ein neuer Verbraucher steht also ohne Zuordnung im Cockpit. Nichts wird gelöscht.
   * imCockpit: true, wenn der Schalter im Cockpit steht. kurz: Kurzname, sonst die ganze Bezeichnung (kein Vorschlag aus drei Buchstaben).
   */
  var COCKPIT_VERBRAUCHER = 'cockpit-verbraucher';
  Daten.prototype.verbraucherSchalter = function (fahrzeugId) {
    var self = this;
    return Promise.all([
      laufListe(this, fahrzeugId, function (k) { return !MM.Komponenten.istMotor(k.komponente) && MM.Komponenten.kannLaufen(k.komponente, k.aktuell.werte); }),
      this.speicher.holen('einstellungen', COCKPIT_VERBRAUCHER),
      this.nachtankenHinweise(fahrzeugId)
    ]).then(function (r) {
      var versteckt = (r[1] && r[1].versteckt && Array.isArray(r[1].versteckt[fahrzeugId])) ? r[1].versteckt[fahrzeugId] : [];
      return r[0].map(function (x) {
        x.kurz = x.kurzname || x.name;
        x.nachtanken = r[2][x.komponenteId] || null;
        x.imCockpit = versteckt.indexOf(x.komponenteId) < 0;
        return x;
      });
    });
  };

  /* zeigen: true = Schalter steht im Cockpit, false = nicht. Der Verbraucher selbst und seine Läufe bleiben, wie sie sind. */
  Daten.prototype.verbraucherImCockpit = function (fahrzeugId, komponenteId, zeigen) {
    var self = this;
    return this.komponenteLaden(komponenteId).then(function (c) {
      if (!c || c.fahrzeug.id !== fahrzeugId || MM.Komponenten.istMotor(c.komponente) || !MM.Komponenten.kannLaufen(c.komponente, c.aktuell.werte)) {
        return { ok: false, fehler: { allgemein: 'Dieser Verbraucher wurde nicht gefunden.' } };
      }
      return self.speicher.holen('einstellungen', COCKPIT_VERBRAUCHER).then(function (dok) {
        var d = dok ? JSON.parse(JSON.stringify(dok)) : { id: COCKPIT_VERBRAUCHER };
        if (!d.versteckt || typeof d.versteckt !== 'object') d.versteckt = {};
        var liste = (Array.isArray(d.versteckt[fahrzeugId]) ? d.versteckt[fahrzeugId] : []).filter(function (x) { return x !== komponenteId; });
        if (!zeigen) liste.push(komponenteId);
        var geaendert = JSON.stringify(liste.slice().sort()) !== JSON.stringify((Array.isArray(dok && dok.versteckt && dok.versteckt[fahrzeugId]) ? dok.versteckt[fahrzeugId] : []).slice().sort());
        d.versteckt[fahrzeugId] = liste;
        if (!geaendert) return { ok: true, geaendert: false };
        return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, geaendert: true }; });
      });
    });
  };

  /* Die Motoren eines Fahrzeugs (Schalter im Cockpit). Unverändert seit 2.0.19. */
  Daten.prototype.motorenListe = function (fahrzeugId) {
    return laufListe(this, fahrzeugId, function (k) { return MM.Komponenten.istMotor(k.komponente); });
  };

  /* Die übrigen Verbraucher eines Fahrzeugs (keine Motoren), die schon einen Lauf haben oder gerade laufen. */
  Daten.prototype.verbraucherListe = function (fahrzeugId) {
    return laufListe(this, fahrzeugId, function (k) { return !MM.Komponenten.istMotor(k.komponente) && MM.Komponenten.kannLaufen(k.komponente, k.aktuell.werte); })
      .then(function (liste) { return liste.filter(function (x) { return x.laeuft || x.laeufe.length; }); });
  };

  /* Alle Verbraucher des Fahrzeugs, die ein- und ausgeschaltet werden können (auch Motoren): für die Frage „Verbraucher“ im Baukasten. */
  Daten.prototype.verbraucherAuswahl = function (fahrzeugId) {
    return laufListe(this, fahrzeugId, function (k) { return MM.Komponenten.kannLaufen(k.komponente, k.aktuell.werte); }).then(function (liste) {
      return liste.map(function (x) { return { id: x.komponenteId, name: x.name, istMotor: x.istMotor, laeuft: x.laeuft, seit: x.seit }; });
    });
  };

  /*
   * Einschalten vorbereiten: prüft und liefert, was zu speichern ist (schreiben), damit der Aufrufer es mit anderem zusammen in einem
   * Schritt speichern kann. nurMotor: der Aufruf kommt vom Motorschalter, dann gelten die Texte und Prüfungen für Motoren.
   * optionen.zeitpunktWennMoeglich (ISO): Startzeit, zum Beispiel die Zeit eines Ereignisses. Sie gilt nur, wenn sie nicht in der Zukunft
   * und nicht vor dem Ende des letzten Laufs liegt, sonst gilt jetzt. optionen.ereignisId: das Ereignis, das den Lauf auslöst.
   */
  function laufStartVorbereiten(self, komponenteId, optionen, nurMotor) {
    optionen = optionen || {};
    return self.komponenteLaden(komponenteId).then(function (c) {
      var ok = !!c && (nurMotor ? MM.Komponenten.istMotor(c.komponente) : MM.Komponenten.kannLaufen(c.komponente, c.aktuell.werte));
      if (!ok) return laufFehler(nurMotor ? 'Dieser Motor wurde nicht gefunden.' : 'Dieser Verbraucher wurde nicht gefunden.');
      var W = laufWort(c.komponente), w = c.aktuell.werte;
      if (w.ausgebautAm && w.ausgebautAm <= self.heute()) return laufFehler(W.dieser + ' ist ausgebaut.');
      if (!MM.Komponenten.istMotor(c.komponente) && c.komponente.ausgeblendet) return laufFehler(W.dieser + ' ist ausgeblendet.');
      return Promise.all([laufDokument(self), self.spannungenListe(), self.komponentenListe(c.fahrzeug.id)]).then(function (rr) {
        var dok = rr[0];
        if (dok.laeufe.some(function (l) { return l.komponenteId === komponenteId && !l.stopp; })) return laufFehler(W.dieser + ' läuft schon.');
        var wahl = nurMotor ? { versorgung: null } : versorgungWaehlen(w, rr[2], rr[1], optionen, komponenteId);
        if (wahl.fehler) return { ok: false, fehler: wahl.fehler };
        return self.verbraucherZaehler(c.fahrzeug.id, komponenteId).then(function (zr) {
          if (!zr.ok) return laufFehler('Der Zähler für die Betriebsstunden konnte nicht angelegt werden.');
          var jetzt = self.jetzt(), start = jetzt, vomEreignis = false;
          if (optionen.zeitpunktWennMoeglich && !isNaN(zeitMs(optionen.zeitpunktWennMoeglich))) {
            var t = zeitMs(optionen.zeitpunktWennMoeglich);
            var letzterStopp = dok.laeufe.filter(function (l) { return l.komponenteId === komponenteId && l.stopp; }).reduce(function (m, l) { return Math.max(m, zeitMs(l.stopp)); }, 0);
            if (t <= zeitMs(jetzt) && t >= letzterStopp) { start = optionen.zeitpunktWennMoeglich; vomEreignis = true; }
          }
          var lauf = { id: neueId('ml'), fahrzeugId: c.fahrzeug.id, komponenteId: komponenteId, zaehlerId: zr.id, start: start,
            stopp: null, standVorher: null, standNachher: null, standId: null, stunden: null };
          if (optionen.ereignisId) lauf.startEreignisId = optionen.ereignisId;
          if (wahl.versorgung) {
            lauf.versorgungId = wahl.versorgung.versorgungId; lauf.versorgungName = wahl.versorgung.versorgungName;
            if (wahl.versorgung.stromQuelle) lauf.stromQuelle = wahl.versorgung.stromQuelle;
            if (wahl.versorgung.erzeugerId) lauf.erzeugerId = wahl.versorgung.erzeugerId;
          }
          dok.laeufe.push(lauf);
          return { ok: true, schreiben: [{ tabelle: 'einstellungen', objekt: dok }],
            ergebnis: { ok: true, id: lauf.id, start: lauf.start, name: w.bezeichnung, vomEreignis: vomEreignis,
              versorgung: wahl.versorgung ? wahl.versorgung.versorgungName : null, stromQuelle: wahl.versorgung ? wahl.versorgung.stromQuelle : null } };
        });
      });
    });
  }

  /*
   * Ausschalten vorbereiten (siehe laufStartVorbereiten). Ohne optionen: jetzt. Mit optionen.zeitpunkt (ISO): zu diesem Zeitpunkt, zum Beispiel
   * die Zeit der Ankunft (Motorstopp-Frage, seit 2.0.22); er darf nicht vor dem Start und nicht nach jetzt liegen. Mit optionen.zeitpunktWennMoeglich:
   * wie zeitpunkt, aber bei einer unpassenden Zeit gilt jetzt. optionen.ereignisId: das Ereignis, von dem die Stoppzeit stammt (kommt an den Lauf).
   */
  function laufStoppVorbereiten(self, komponenteId, optionen, nurMotor) {
    optionen = optionen || {};
    return Promise.all([laufDokument(self), self.komponenteLaden(komponenteId)]).then(function (rr) {
      var dok = rr[0], c = rr[1];
      var W = nurMotor ? WORT_MOTOR : (c ? laufWort(c.komponente) : WORT_VERBRAUCHER);
      var lauf = dok.laeufe.filter(function (l) { return l.komponenteId === komponenteId && !l.stopp; })[0];
      if (!lauf) return laufFehler(W.dieser + ' läuft nicht.');
      var jetzt = self.jetzt();
      var stoppZeit = jetzt, vomZiel = false, vomEreignis = false;
      if (optionen.zeitpunkt) {
        if (isNaN(zeitMs(optionen.zeitpunkt))) return laufFehler('Die Stoppzeit ist keine gültige Zeit.', 'zeit');
        if (zeitMs(optionen.zeitpunkt) < zeitMs(lauf.start)) return laufFehler('Der Stopp kann nicht vor dem Start liegen (Start: ' + MM.Hilfen.zeitpunkt(lauf.start) + ').', 'zeit');
        if (zeitMs(optionen.zeitpunkt) > zeitMs(jetzt)) return laufFehler('Die Zeit liegt in der Zukunft.', 'zeit');
        stoppZeit = optionen.zeitpunkt; vomZiel = true;
      } else if (optionen.zeitpunktWennMoeglich && !isNaN(zeitMs(optionen.zeitpunktWennMoeglich))) {
        var t = zeitMs(optionen.zeitpunktWennMoeglich);
        if (t >= zeitMs(lauf.start) && t <= zeitMs(jetzt)) { stoppZeit = optionen.zeitpunktWennMoeglich; vomEreignis = true; }
      }
      var stunden = MM.Motoren.laufStunden(lauf.start, stoppZeit);
      if (stunden === null) return laufFehler('Der Start liegt nach der jetzigen Uhrzeit des Geräts. Bitte die Uhr des Geräts prüfen.');
      return self.speicher.holen('zaehler', lauf.zaehlerId).then(function (z) {
        return z ? { ok: true, id: z.id } : self.verbraucherZaehler(lauf.fahrzeugId, komponenteId);
      }).then(function (zr) {
        if (!zr.ok) return laufFehler('Der Zähler für die Betriebsstunden wurde nicht gefunden.');
        return self.speicher.wo('zaehlerstaende', 'zaehlerId', zr.id).then(function (staende) {
          var letzter = neuesterStand(staende);
          var basis = letzter ? letzter.wert : 0;
          var neu = MM.Motoren.runde(basis + stunden);
          var stand = { id: neueId('zs'), zaehlerId: zr.id, nr: letzter ? letzter.nr + 1 : 1, wert: neu, datum: (vomZiel || vomEreignis) ? MM.Motoren.ortsdatum(stoppZeit) : self.heute(),
            notiz: W.lauf + ' ' + MM.Hilfen.zeitpunkt(lauf.start) + ' bis ' + MM.Hilfen.zeitpunkt(stoppZeit) + ' (' + MM.Motoren.stundenText(stunden) + ')' + (vomZiel ? ', ' + W.stoppZiel : (vomEreignis ? ', Stoppzeit vom Ereignis übernommen' : '')),
            quelle: 'schalter', laufId: lauf.id, erstelltAm: jetzt };
          lauf.stopp = stoppZeit; lauf.zaehlerId = zr.id; lauf.standVorher = basis; lauf.standNachher = neu; lauf.standId = stand.id; lauf.stunden = stunden;
          if (vomZiel) lauf.stoppVonEreignis = optionen.ereignisId || true;
          if (optionen.ereignisId) lauf.stoppEreignisId = optionen.ereignisId;
          return { ok: true, schreiben: [{ tabelle: 'zaehlerstaende', objekt: stand }, { tabelle: 'einstellungen', objekt: dok }],
            ergebnis: { ok: true, id: lauf.id, name: c ? c.aktuell.werte.bezeichnung : '', stunden: stunden, stand: neu, ohneStartstand: !letzter, stopp: stoppZeit, vomZiel: vomZiel, vomEreignis: vomEreignis } };
        });
      });
    });
  }

  function laufSpeichern(self, vorbereitet) {
    if (vorbereitet.ok === false) return Promise.resolve(vorbereitet);
    return self.speicher.mehrereSpeichern(vorbereitet.schreiben).then(function () { return vorbereitet.ergebnis; });
  }

  /*
   * Was beim Einschalten zur Wahl steht (seit 2.0.59): die Versorgungen des Verbrauchers (Gas, 12 V, 230 V …) und bei Wechselstrom die Quellen
   * mit den Geräten des Fahrzeugs (Generator, Wechselrichter), die dafür angelegt sind. Der Nutzer wählt, die Laufzeit zählt zu dieser Versorgung.
   */
  Daten.prototype.verbraucherEinschaltenKontext = function (komponenteId) {
    var self = this;
    return Promise.all([this.komponenteLaden(komponenteId), this.spannungenListe()]).then(function (r) {
      var c = r[0];
      if (!c || !MM.Komponenten.kannLaufen(c.komponente, c.aktuell.werte)) return { ok: false, fehler: { allgemein: 'Dieser Verbraucher wurde nicht gefunden.' } };
      return self.komponentenListe(c.fahrzeug.id).then(function (liste) {
        var V = MM.Versorgung, w = c.aktuell.werte;
        function geraete(rolle) {
          return liste.filter(function (x) {
            return x.komponente.id !== komponenteId && x.aktuell.werte.stromRolle === rolle && !x.aktuell.werte.ausgebautAm && !x.komponente.ausgeblendet;
          }).map(function (x) { return { id: x.komponente.id, name: x.aktuell.werte.bezeichnung }; });
        }
        var versorgungen = V.versorgungenListe(w).map(function (v) {
          var art = v.strom ? V.spannungArt(r[1], v.spannung) : null;
          var quellen = v.strom && art ? V.stromQuellenFuer(art).map(function (q) {
            return { wert: q.wert, label: q.label, geraete: (q.wert === 'generator' || q.wert === 'wechselrichter') ? geraete(q.wert) : [] };
          }) : [];
          return { id: v.id, name: V.versorgungName(v), strom: v.strom, art: art, quellen: quellen };
        });
        return { ok: true, id: komponenteId, name: w.bezeichnung, fahrzeugId: c.fahrzeug.id, versorgungen: versorgungen };
      });
    });
  };

  /* Laufzeit je Versorgung eines Verbrauchers (seit 2.0.59), dazu Laufzeit je Quelle bei Strom. Nur beendete Läufe. */
  Daten.prototype.verbraucherLaufzeiten = function (komponenteId) {
    return Promise.all([this.komponenteLaden(komponenteId), laufDokument(this)]).then(function (r) {
      var c = r[0];
      if (!c) return null;
      var vl = MM.Versorgung.versorgungenListe(c.aktuell.werte);
      return MM.Versorgung.laufzeiten(r[1].laeufe.filter(function (l) { return l.komponenteId === komponenteId; }), vl);
    });
  };

  /*
   * Nachtanken (seit 2.0.59) für Verbraucher mit Tank, die Strom liefern (Generator, Brennstoffzelle): { Kennung: { rest, warnung, text } }.
   * Es wird nur gerechnet, was bekannt ist (siehe MM.Versorgung.nachtanken); ohne Reichweite in Betriebsstunden gibt es keinen Eintrag.
   */
  Daten.prototype.nachtankenHinweise = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.komponentenListe(fahrzeugId), laufDokument(this)]).then(function (r) {
      var liste = MM.Komponenten.aktive(r[0]).filter(function (x) { return !x.aktuell.werte.ausgebautAm; });
      var kandidaten = liste.filter(function (x) { var rolle = x.aktuell.werte.stromRolle; return x.aktuell.werte.verbraucher === 'ja' && (rolle === 'generator' || rolle === 'efoy'); });
      var jetzt = self.jetzt();
      var res = {};
      return Promise.all(kandidaten.map(function (x) {
        var id = x.komponente.id, w = x.aktuell.werte;
        var vl = MM.Versorgung.versorgungenListe(w).filter(function (v) { return !v.strom && v.quellen.length; });
        var tank = vl.length ? liste.filter(function (t) { return t.komponente.id === vl[0].quellen[0] && MM.Versorgung.istTank(t.komponente); })[0] : null;
        if (!tank) return null;
        var tw = tank.aktuell.werte;
        if (!tw.fuellstandStunden || typeof tw.fuellstandStunden[id] !== 'number') return null;
        return self.stundenStaende(fahrzeugId, [id], tank.komponente.id).then(function (st) {
          if (typeof st[id] !== 'number') return null;
          var offen = r[1].laeufe.filter(function (l) { return l.komponenteId === id && !l.stopp; })[0];
          var laeuft = offen ? MM.Motoren.laufStunden(offen.start, jetzt) : 0;
          var n = MM.Versorgung.nachtanken({ name: w.bezeichnung, reichweite: tw.reichweite || [], stundenSeitTanken: st[id] - tw.fuellstandStunden[id], laeuftSeitStunden: laeuft || 0 });
          if (n) res[id] = n;
        });
      })).then(function () { return res; });
    });
  };

  /* ---------- Messwerte eines Gebers (seit 2.0.59, nur die Struktur) ---------- */
  /*
   * Ein Geber (Batteriewächter, Zähler) kann später Werte liefern, ohne dass die Daten umgebaut werden müssen. Jetzt gibt es keinen Geber:
   * Die App rechnet keinen Ladezustand und lässt keine Handeingabe zu. Dokument „messwerte“ in „einstellungen“ (in der Sicherung enthalten).
   * Ein Eintrag: { id, komponenteId, art (ladezustand, zaehlerstand, spannung), wert, einheit, zeit, quelle: 'geber', geber }.
   */
  var MESSWERTE_DOK = 'messwerte';
  Daten.prototype.messwertErfassen = function (komponenteId, art, wert, optionen) {
    var self = this; optionen = optionen || {};
    var a = MM.Versorgung.MESSWERT_ARTEN.filter(function (x) { return x.wert === art; })[0];
    if (optionen.quelle !== 'geber') return Promise.resolve({ ok: false, fehler: { allgemein: 'Messwerte kommen nur von einem Geber. Eine Handeingabe gibt es nicht.' } });
    if (!a) return Promise.resolve({ ok: false, fehler: { art: 'Diese Art von Messwert gibt es nicht.' } });
    if (typeof wert !== 'number' || !isFinite(wert) || wert < 0) return Promise.resolve({ ok: false, fehler: { wert: 'Der Wert muss eine Zahl ab 0 sein.' } });
    var zeit = optionen.zeit || this.jetzt();
    if (isNaN(new Date(zeit).getTime())) return Promise.resolve({ ok: false, fehler: { zeit: 'Die Zeit ist keine gültige Zeit.' } });
    return Promise.all([this.komponenteLaden(komponenteId), this.speicher.holen('einstellungen', MESSWERTE_DOK)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Diese Komponente wurde nicht gefunden.' } };
      var dok = r[1] ? JSON.parse(JSON.stringify(r[1])) : { id: MESSWERTE_DOK };
      if (!Array.isArray(dok.werte)) dok.werte = [];
      var e = { id: neueId('mw'), komponenteId: komponenteId, art: art, wert: wert, einheit: a.einheit, zeit: zeit, quelle: 'geber', geber: optionen.geber ? String(optionen.geber).slice(0, 60) : null };
      dok.werte.push(e);
      return self.speicher.speichern('einstellungen', dok).then(function () { return { ok: true, id: e.id }; });
    });
  };
  /* Die Messwerte einer Komponente, neueste zuerst. art: nur diese Art (freiwillig). */
  Daten.prototype.messwerteListe = function (komponenteId, art) {
    return this.speicher.holen('einstellungen', MESSWERTE_DOK).then(function (dok) {
      return ((dok && dok.werte) || []).filter(function (x) { return x.komponenteId === komponenteId && (!art || x.art === art); })
        .sort(function (a, b) { return new Date(b.zeit).getTime() - new Date(a.zeit).getTime(); });
    });
  };

  /* Intern für ereignisAblaufAusfuehren: prüft und liefert, was zu speichern ist, ohne selbst zu speichern. art: 'ein' oder 'aus'. */
  Daten.prototype.verbraucherLaufVorbereiten = function (art, komponenteId, optionen) {
    return art === 'ein' ? laufStartVorbereiten(this, komponenteId, optionen, false) : laufStoppVorbereiten(this, komponenteId, optionen, false);
  };

  /* Logbuch-Eintrag zu Ein und Aus (seit 2.0.107): nur wenn der Aufrufer die Aktivität nennt (Schalter im Cockpit) und das Ein oder Aus nicht schon von einem
   * Ereignis kommt (zum Beispiel Abfahrt oder Ankunft). Quelle: Nutzer, Zeit: Gerätezeit. Klappt der Eintrag nicht, bleibt der Lauf trotzdem gespeichert. */
  function laufEintrag(self, optionen, wort) {
    return function (r) {
      if (!r || r.ok === false || !optionen || !optionen.aktivitaetId || optionen.ereignisId) return r;
      return self.schalterArtSichern().then(function (artId) {
        return self.ereignisSchnell(optionen.aktivitaetId, MM.Logbuch.SCHALTER_ART, { artId: artId, text: r.name + ' ' + wort, position: optionen.position || null, quelle: 'nutzer' });
      }).then(function (e) { if (e && e.ok) r.ereignisId = e.id; return r; }, function () { return r; });
    };
  }
  Daten.prototype.schalterArtSichern = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var da = liste.filter(function (x) { return MM.Logbuch.istSchalterArt(x.aktuell.werte.bezeichnung); })[0];
      if (da) return da.objekt.id;
      return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: MM.Logbuch.SCHALTER_ART, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(['alle']) })
        .then(function (r) { return r.id; });
    });
  };
  Daten.prototype.verbraucherStart = function (komponenteId, optionen) { var s = this; return laufStartVorbereiten(s, komponenteId, optionen, false).then(laufSpeichern.bind(null, s)).then(laufEintrag(s, optionen, 'eingeschaltet')); };
  Daten.prototype.verbraucherStopp = function (komponenteId, optionen) { var s = this; return laufStoppVorbereiten(s, komponenteId, optionen, false).then(laufSpeichern.bind(null, s)).then(laufEintrag(s, optionen, 'ausgeschaltet')); };
  Daten.prototype.motorStart = function (komponenteId, optionen) { var s = this; return laufStartVorbereiten(s, komponenteId, null, true).then(laufSpeichern.bind(null, s)).then(laufEintrag(s, optionen, 'gestartet')); };
  Daten.prototype.motorStopp = function (komponenteId, optionen) { var s = this; return laufStoppVorbereiten(s, komponenteId, optionen, true).then(laufSpeichern.bind(null, s)).then(laufEintrag(s, optionen, 'gestoppt')); };

  /*
   * Der Nutzer sagt bei der Motorstopp-Frage „Läuft weiter“. stufe 'jetzt': die Frage nach der Ankunft ist beantwortet,
   * der Vorschlag nach der Wartezeit kommt später noch. stufe 'vorschlag': für dieses Ereignis kommt nichts mehr.
   */
  Daten.prototype.motorStoppFrageVerneinen = function (laufId, ereignisId, stufe) {
    var self = this;
    if (stufe !== 'jetzt' && stufe !== 'vorschlag') return Promise.resolve(laufFehler('Unbekannte Stufe der Frage.'));
    return laufDokument(this).then(function (dok) {
      var lauf = dok.laeufe.filter(function (l) { return l.id === laufId; })[0];
      if (!lauf) return laufFehler('Dieser Lauf wurde nicht gefunden.');
      if (lauf.stopp) return { ok: true, id: laufId, geaendert: false };
      var alt = lauf.frage && lauf.frage.ereignisId === ereignisId ? lauf.frage.stufe : null;
      if (alt === 'vorschlag' || alt === stufe) return { ok: true, id: laufId, geaendert: false };
      lauf.frage = { ereignisId: ereignisId, stufe: stufe };
      return self.speicher.speichern('einstellungen', dok).then(function () { return { ok: true, id: laufId, geaendert: true }; });
    });
  };

  /*
   * Stoppzeit eines beendeten Laufs korrigieren (zum Beispiel, wenn das Stoppen vergessen wurde).
   * roh: { datum, zeit } in Ortszeit. Nur der letzte Lauf eines Verbrauchers, und nur solange der Zählerstand danach nicht
   * weiterverändert wurde (sonst bleibt nur, den richtigen Stand von Hand einzutragen).
   */
  Daten.prototype.verbraucherLaufKorrigieren = function (laufId, roh) {
    var self = this; roh = roh || {};
    return laufDokument(this).then(function (dok) {
      var lauf = dok.laeufe.filter(function (l) { return l.id === laufId; })[0];
      if (!lauf) return laufFehler('Dieser Lauf wurde nicht gefunden.');
      return self.komponenteLaden(lauf.komponenteId).then(function (c) {
        var W = c ? laufWort(c.komponente) : WORT_VERBRAUCHER;
        if (!lauf.stopp) return laufFehler(W.dieser + ' läuft noch. Erst stoppen, dann die Zeit korrigieren.');
        var neuStopp = MM.Motoren.zeitpunktAusOrtszeit(roh.datum, roh.zeit);
        if (!neuStopp) return laufFehler('Bitte Datum und Uhrzeit angeben, zum Beispiel 14:30.', 'zeit');
        if (zeitMs(neuStopp) < zeitMs(lauf.start)) return laufFehler('Der Stopp kann nicht vor dem Start liegen (Start: ' + MM.Hilfen.zeitpunkt(lauf.start) + ').', 'zeit');
        var jetzt = self.jetzt();
        if (zeitMs(neuStopp) > zeitMs(jetzt)) return laufFehler('Die Zeit liegt in der Zukunft.', 'zeit');
        if (dok.laeufe.some(function (l) { return l.komponenteId === lauf.komponenteId && l.id !== lauf.id && zeitMs(l.start) >= zeitMs(lauf.start); })) {
          return laufFehler('Nur der letzte Lauf ' + W.dieses + ' lässt sich korrigieren. Trage den richtigen Zählerstand von Hand ein.');
        }
        return self.speicher.wo('zaehlerstaende', 'zaehlerId', lauf.zaehlerId).then(function (staende) {
          var letzter = neuesterStand(staende);
          if (!letzter || letzter.id !== lauf.standId) {
            return laufFehler('Seit diesem Lauf wurde der Zählerstand geändert. Die Zeit lässt sich nicht mehr korrigieren. Trage den richtigen Zählerstand von Hand ein.');
          }
          if (MM.Motoren.ortsdatum(neuStopp) === MM.Motoren.ortsdatum(lauf.stopp) && MM.Motoren.ortszeit(neuStopp) === MM.Motoren.ortszeit(lauf.stopp)) {
            return { ok: true, id: lauf.id, geaendert: false };
          }
          var stunden = MM.Motoren.laufStunden(lauf.start, neuStopp);
          var neu = MM.Motoren.runde((lauf.standVorher || 0) + stunden);
          var stand = { id: neueId('zs'), zaehlerId: lauf.zaehlerId, nr: letzter.nr + 1, wert: neu, datum: MM.Motoren.ortsdatum(neuStopp),
            notiz: 'Korrektur: ' + W.gestoppt + ' ' + MM.Hilfen.zeitpunkt(neuStopp) + ' statt ' + MM.Hilfen.zeitpunkt(lauf.stopp) + ' (' + MM.Motoren.stundenText(stunden) + ' Laufzeit)',
            quelle: 'korrektur', laufId: lauf.id, erstelltAm: jetzt };
          lauf.korrekturen = (lauf.korrekturen || []).concat([{ stoppAlt: lauf.stopp, standAlt: lauf.standNachher, korrigiertAm: jetzt }]);
          lauf.stopp = neuStopp; lauf.stunden = stunden; lauf.standNachher = neu; lauf.standId = stand.id;
          return self.speicher.mehrereSpeichern([{ tabelle: 'zaehlerstaende', objekt: stand }, { tabelle: 'einstellungen', objekt: dok }])
            .then(function () { return { ok: true, id: lauf.id, geaendert: true, stunden: stunden, stand: neu }; });
        });
      });
    });
  };
  Daten.prototype.motorLaufKorrigieren = function (laufId, roh) { return this.verbraucherLaufKorrigieren(laufId, roh); };

  /* ---------- Fristen ---------- */
  Daten.prototype.pruefenFrist = function (roh, mitAusgang) {
    var p = pruefeWerte(MM.Fristen.felder(mitAusgang), roh, jahrVon(this));
    var w = p.werte, f = p.fehler;
    if (!w.kategorie && !f.kategorie) f.kategorie = 'Bitte die Art der Frist wählen.';
    if (w.kalenderWert) { if (!w.kalenderEinheit) w.kalenderEinheit = 'monate'; } else { w.kalenderEinheit = null; }
    if (!w.wirkung) w.wirkung = 'warnen';
    if (w.vorwarnTage === null || w.vorwarnTage === undefined) w.vorwarnTage = 0;
    var hatZ = !!w.zaehlerId, hatW = w.zaehlerWert !== null && w.zaehlerWert !== undefined;
    if (hatZ && !hatW && !f.zaehlerWert) f.zaehlerWert = 'Bitte angeben, nach wie viel Strecke oder Stunden die Frist fällig wird.';
    if (!hatZ && hatW && !f.zaehlerId) f.zaehlerId = 'Bitte einen Zähler wählen oder die Zählergrenze leer lassen.';
    if (hatW && w.zaehlerWert <= 0 && !f.zaehlerWert) f.zaehlerWert = 'Die Grenze muss größer als null sein.';
    if (!w.kalenderWert && !(hatZ && hatW) && !f.kalenderWert && !f.zaehlerWert && !f.zaehlerId) {
      f.kalenderWert = 'Bitte mindestens eine Grenze angeben: Zeit oder Zähler.';
    }
    if (!hatZ) { w.zaehlerId = null; w.zaehlerWert = null; w.vorwarnZaehler = null; }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Letzte Erledigung: das späteste Datum, bei gleichem Datum die zuletzt eingetragene. */
  function letzteDurchfuehrung(liste) {
    return liste.reduce(function (a, b) {
      if (!a) return b;
      if (b.datum !== a.datum) return b.datum > a.datum ? b : a;
      return b.erstelltAm >= a.erstelltAm ? b : a;
    }, null);
  }

  function statusZu(self, frist, werte, durchfuehrungen, zaehlerInfo) {
    var letzte = letzteDurchfuehrung(durchfuehrungen);
    if (!letzte) return { status: 'unbekannt', kalender: null, zaehler: null, grund: 'Es gibt noch keine Erledigung als Ausgangswert.' };
    var res = MM.Fristen.berechne({ werte: werte, letzte: letzte, stand: zaehlerInfo ? zaehlerInfo.stand : null, heute: self.heute() });
    res.letzte = letzte;
    return res;
  }

  Daten.prototype.fristAnlegen = function (fahrzeugId, komponenteId, roh) {
    var self = this;
    var p = this.pruefenFrist(roh, true);
    var w = p.werte, fehler = p.fehler, heute = this.heute();
    var zuletztAm = w.zuletztAm, zuletztStand = w.zuletztStand;
    delete w.zuletztAm; delete w.zuletztStand;
    if (zuletztAm && zuletztAm > heute && !fehler.zuletztAm) fehler.zuletztAm = 'Das Datum liegt in der Zukunft.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return self.zaehlerListe(fahrzeugId).then(function (liste) {
        var z = w.zaehlerId ? liste.filter(function (x) { return x.zaehler.id === w.zaehlerId; })[0] : null;
        if (w.zaehlerId && !z) return { ok: false, fehler: { zaehlerId: 'Dieser Zähler gehört nicht zu diesem Fahrzeug.' } };
        var basisDatum = zuletztAm || heute;
        var basisStand = zuletztStand;
        if (basisStand === null && !zuletztAm && z && z.stand) basisStand = z.stand.wert;
        var e2 = {};
        if (z && basisStand === null) e2.zuletztStand = 'Bitte den Zählerstand angeben, bei dem die Frist zuletzt erledigt wurde, oder trage zuerst einen aktuellen Zählerstand ein.';
        if (z && basisStand !== null && z.stand && basisStand > z.stand.wert) {
          e2.zuletztStand = 'Dieser Stand ist höher als der aktuelle Zählerstand (' + MM.Hilfen.zahl(z.stand.wert) + ' ' + z.einheit + '). Trage zuerst den aktuellen Zählerstand ein.';
        }
        if (Object.keys(e2).length) return { ok: false, fehler: e2 };

        var jetzt = self.jetzt();
        var fr = { id: neueId('fr'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, erstelltAm: jetzt };
        var ve = neuerVerlaufEintrag('frist', fr.id, 1, w, null, jetzt);
        var du = { id: neueId('du'), fristId: fr.id, datum: basisDatum, zaehlerstand: z ? basisStand : null,
          notiz: 'Ausgangswert bei Anlage der Frist', art: 'ausgangswert', quelle: 'hand', erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'fristen', objekt: fr }, { tabelle: 'verlaeufe', objekt: ve }, { tabelle: 'durchfuehrungen', objekt: du }
        ]).then(function () { return { ok: true, id: fr.id }; });
      });
    });
  };

  Daten.prototype.fristAendern = function (fristId, roh) {
    var self = this;
    return this.fristLaden(fristId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Diese Frist wurde nicht gefunden.' } };
      var p = self.pruefenFrist(roh, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.zaehlerListe(f.frist.fahrzeugId).then(function (liste) {
        if (p.werte.zaehlerId && !liste.some(function (x) { return x.zaehler.id === p.werte.zaehlerId; })) {
          return { ok: false, fehler: { zaehlerId: 'Dieser Zähler gehört nicht zu diesem Fahrzeug.' } };
        }
        if (!unterschiedeFelder(MM.Fristen.felder(false), f.aktuell.werte, p.werte).length) return { ok: true, id: fristId, geaendert: false };
        var e = neuerVerlaufEintrag('frist', fristId, f.aktuell.nr + 1, p.werte, f.aktuell.id, self.jetzt());
        return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: fristId, geaendert: true }; });
      });
    });
  };

  var FELDER_ERLEDIGT = [
    { key: 'datum', label: 'Erledigt am', typ: 'datum' },
    { key: 'zaehlerstand', label: 'Zählerstand dabei', typ: 'zahl', min: 0 },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  /* Eine Erledigung (Prüfung, Kontrolle, Arbeit). Sie setzt die Rechnung der Frist neu an. */
  Daten.prototype.durchfuehrungAnlegen = function (fristId, roh) {
    var self = this;
    var p = pruefeWerte(FELDER_ERLEDIGT, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, fehler = p.fehler, heute = this.heute();
    if (!w.datum && !fehler.datum) w.datum = heute;
    if (w.datum && w.datum > heute && !fehler.datum) fehler.datum = 'Das Datum liegt in der Zukunft.';
    return this.fristLaden(fristId).then(function (f) {
      if (!f) return { ok: false, fehler: { allgemein: 'Diese Frist wurde nicht gefunden.' } };
      var z = f.zaehler;
      var neuerStand = null;
      if (z && !fehler.zaehlerstand) {
        if (w.zaehlerstand === null) {
          if (w.datum === heute && z.stand) w.zaehlerstand = z.stand.wert;
          else fehler.zaehlerstand = 'Bitte den Zählerstand angeben, bei dem die Frist erledigt wurde.';
        } else if (f.letzte && f.letzte.zaehlerstand !== null && f.letzte.zaehlerstand !== undefined && w.zaehlerstand < f.letzte.zaehlerstand) {
          fehler.zaehlerstand = 'Der Stand ist niedriger als bei der letzten Erledigung (' + MM.Hilfen.zahl(f.letzte.zaehlerstand) + ' ' + z.einheit + ').';
        }
        if (!fehler.zaehlerstand && w.zaehlerstand !== null && (!z.stand || w.zaehlerstand > z.stand.wert)) neuerStand = w.zaehlerstand;
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };

      var jetzt = self.jetzt();
      var du = { id: neueId('du'), fristId: fristId, datum: w.datum, zaehlerstand: w.zaehlerstand, notiz: w.notiz,
        art: 'erledigt', quelle: 'hand', erstelltAm: jetzt };
      var liste = [{ tabelle: 'durchfuehrungen', objekt: du }];
      if (neuerStand === null) return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: du.id }; });
      /* Ist der Stand höher als der bisher bekannte, wird er auch im Zähler eingetragen (eine Quelle). */
      return self.speicher.wo('zaehlerstaende', 'zaehlerId', z.zaehler.id).then(function (staende) {
        var nr = staende.reduce(function (m, e) { return Math.max(m, e.nr); }, 0) + 1;
        liste.push({ tabelle: 'zaehlerstaende', objekt: { id: neueId('zs'), zaehlerId: z.zaehler.id, nr: nr, wert: neuerStand,
          datum: w.datum, notiz: 'Bei Erledigung: ' + f.aktuell.werte.bezeichnung, quelle: 'hand', erstelltAm: jetzt } });
        return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: du.id }; });
      });
    });
  };

  /* Alle Fristen eines Fahrzeugs mit gerechnetem Stand. Sortiert: überfällig zuerst. */
  Daten.prototype.fristenListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([
      this.speicher.wo('fristen', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.speicher.alle('durchfuehrungen'),
      this.zaehlerListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'frist') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var du = {}; r[2].forEach(function (e) { (du[e.fristId] = du[e.fristId] || []).push(e); });
      var zl = {}; r[3].forEach(function (z) { zl[z.zaehler.id] = z; });
      var res = r[0].map(function (fr) {
        var eintraege = (ver[fr.id] || []).slice().sort(nachNr);
        var aktuell = eintraege[eintraege.length - 1];
        if (!aktuell) return null;
        var z = aktuell.werte.zaehlerId ? zl[aktuell.werte.zaehlerId] || null : null;
        return { frist: fr, aktuell: aktuell, zaehler: z, status: statusZu(self, fr, aktuell.werte, du[fr.id] || [], z) };
      }).filter(Boolean);
      res.sort(function (a, b) {
        var d = MM.Fristen.rang(b.status.status) - MM.Fristen.rang(a.status.status);
        return d || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true });
      });
      return res;
    });
  };

  Daten.prototype.fristLaden = function (id) {
    var self = this;
    return this.speicher.holen('fristen', id).then(function (fr) {
      if (!fr) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('durchfuehrungen', 'fristId', id),
        self.zaehlerListe(fr.fahrzeugId),
        self.fahrzeugLaden(fr.fahrzeugId),
        self.komponentenListe(fr.fahrzeugId)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[3]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        var zl = r[2];
        var z = aktuell.werte.zaehlerId ? zl.filter(function (x) { return x.zaehler.id === aktuell.werte.zaehlerId; })[0] || null : null;
        var du = r[1].slice().sort(function (a, b) { return a.datum !== b.datum ? (a.datum < b.datum ? 1 : -1) : (a.erstelltAm < b.erstelltAm ? 1 : -1); });
        var verlauf = verlaufAus(eintraege, MM.Fristen.felder(false));
        /* Zähler im Verlauf mit Namen statt Kennung zeigen */
        var namen = {}; zl.forEach(function (x) { namen[x.zaehler.id] = x.label; });
        verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'zaehlerId') { u.alt = u.alt ? (namen[u.alt] || 'unbekannter Zähler') : null; u.neu = u.neu ? (namen[u.neu] || 'unbekannter Zähler') : null; }
          });
        });
        var komp = fr.komponenteId ? r[4].filter(function (k) { return k.komponente.id === fr.komponenteId; })[0] : null;
        return { frist: fr, aktuell: aktuell, verlauf: verlauf, durchfuehrungen: du, letzte: letzteDurchfuehrung(r[1]),
          zaehler: z, zaehlerListe: zl, status: statusZu(self, fr, aktuell.werte, r[1], z),
          fahrzeug: r[3].fahrzeug, fahrzeugAktuell: r[3].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null };
      });
    });
  };

  /* Pro Fahrzeug: wie viele Fristen sind überfällig oder bald fällig? */
  Daten.prototype.fristenUebersicht = function () {
    var self = this;
    return this.fahrzeugListe().then(function (liste) {
      return Promise.all(liste.map(function (x) { return self.fristenListe(x.fahrzeug.id); })).then(function (alle) {
        var res = {};
        liste.forEach(function (x, i) {
          var z = { ueberfaellig: 0, bald: 0, unbekannt: 0 };
          alle[i].forEach(function (f) { if (z[f.status.status] !== undefined) z[f.status.status]++; });
          res[x.fahrzeug.id] = z;
        });
        return res;
      });
    });
  };

  /* ---------- Werkstatt: Vorgänge (Störungen und Arbeiten, seit 2.0.24) ---------- */
  /*
   * Ein Vorgang ist eine Störung oder eine Arbeit am Fahrzeug oder an einer Komponente.
   * Er ist offen oder erledigt, nichts wird gelöscht. Jede Änderung ist ein neuer Eintrag im
   * Verlauf. Aus einer Störung wird eine Arbeit (selbst oder durch eine Werkstatt).
   * Offene Vorgänge mit Einschränkung bremsen das Fahrzeug: Für versprochene Aktivitäten
   * kommt dann eine Warnung, und der Nutzer entscheidet pro Aktivität: trotzdem nutzen
   * oder absagen (Absagen läuft über das vorhandene Stornieren der Aktivität).
   */
  Daten.prototype.pruefenVorgang = function (roh, art) {
    var p = pruefeWerte(MM.Werkstatt.felder(art), roh, jahrVon(this), {
      bezeichnungFehler: 'Bitte kurz sagen, worum es geht, zum Beispiel „Motor springt schlecht an“ oder „Ölwechsel“.' });
    var w = p.werte, f = p.fehler, heute = this.heute();
    if (!w.auswirkung && !f.auswirkung) {
      if (art === 'stoerung') f.auswirkung = 'Bitte wählen, wie weit die Störung das Fahrzeug einschränkt.';
      else w.auswirkung = 'keine';
    }
    if (!w.gemeldetAm && !f.gemeldetAm) w.gemeldetAm = heute;
    if (w.gemeldetAm && w.gemeldetAm > heute && !f.gemeldetAm) f.gemeldetAm = 'Das Datum liegt in der Zukunft.';
    if (art === 'arbeit') {
      if (!w.ausfuehrung && !f.ausfuehrung) f.ausfuehrung = 'Bitte wählen, ob du die Arbeit selbst erledigst oder eine Werkstatt sie macht.';
    } else { w.ausfuehrung = null; w.arbeit = null; }
    /* Verweis auf die Adressliste (seit 2.0.25), nur bei einer Arbeit. Ob es die Adresse gibt, prüft pruefeAdresseDesVorgangs. */
    var aid = roh && typeof roh.adresseId === 'string' ? roh.adresseId.trim() : '';
    w.adresseId = (art === 'arbeit' && aid) ? aid : null;
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Prüft die gewählte Adresse eines Vorgangs. behalte = die Adresse, die schon am Vorgang hängt: sie bleibt erlaubt, auch wenn sie inzwischen ausgeblendet ist. */
  function pruefeAdresseDesVorgangs(self, adresseId, behalte) {
    if (!adresseId) return Promise.resolve(null);
    return self.mitVerlaufLaden('adressen', adresseId, adresseFelder()).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { adresseId: 'Diese Adresse gibt es nicht.' };
      if (x.aktuell.werte.ausgeblendet === 'ja' && adresseId !== behalte) return { adresseId: 'Diese Adresse ist ausgeblendet. Blende sie in der Adressliste wieder ein, wenn du sie brauchst.' };
      return null;
    });
  }

  Daten.prototype.vorgangAnlegen = function (fahrzeugId, komponenteId, art, roh) {
    var self = this;
    if (art !== 'stoerung' && art !== 'arbeit') return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Art von Vorgang gibt es nicht.' } });
    var p = this.pruefenVorgang(roh, art);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.pruefeObjekt(fahrzeugId, komponenteId || null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return pruefeAdresseDesVorgangs(self, p.werte.adresseId, null).then(function (af) {
        if (af) return { ok: false, fehler: af };
        var w = p.werte;
        w.art = art; w.status = 'offen'; w.erledigtAm = null; w.erledigtNotiz = null;
        var jetzt = self.jetzt();
        var v = { id: neueId('vg'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'vorgaenge', objekt: v }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('vorgang', v.id, 1, w, null, jetzt) }
        ]).then(function () { return { ok: true, id: v.id }; });
      });
    });
  };

  /* Ein Vorgang in einem neuen Stand. Die Änderung bekommt die Werte, gibt neue Werte oder einen Fehler zurück. */
  function vorgangNeuerStand(self, id, aenderung) {
    return self.vorgangLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
      var neu = aenderung(Object.assign({}, x.aktuell.werte), x);
      if (neu.fehler) return { ok: false, fehler: neu.fehler };
      return self.mitVerlaufAendern('vorgang', id, { aktuell: x.aktuell }, neu.werte, MM.Werkstatt.felderAlle());
    });
  }

  Daten.prototype.vorgangAendern = function (id, roh) {
    var self = this;
    var aid = roh && typeof roh.adresseId === 'string' ? roh.adresseId.trim() : '';
    return this.vorgangLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
      var aw = x.aktuell.werte;
      return pruefeAdresseDesVorgangs(self, aw.art === 'arbeit' ? aid : '', aw.adresseId || null);
    }).then(function (af) {
      if (af && af.ok === false) return af;
      if (af) return { ok: false, fehler: af };
      return vorgangNeuerStand(self, id, function (alt) {
        if (alt.status === 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist erledigt. Öffne ihn zuerst wieder, wenn du etwas ändern willst.' } };
        var p = self.pruefenVorgang(roh, alt.art);
        if (!p.ok) return { fehler: p.fehler };
        return { werte: Object.assign(alt, p.werte) };
      });
    });
  };

  /* Aus einer offenen Störung eine Arbeit machen: selbst erledigen oder durch eine Werkstatt. */
  Daten.prototype.vorgangZuArbeit = function (id, roh) {
    var self = this;
    var p = pruefeWerte(MM.Werkstatt.felder('arbeit').filter(function (x) { return x.key === 'ausfuehrung' || x.key === 'arbeit'; }), roh, jahrVon(this), { ohneBezeichnung: true });
    if (!p.werte.ausfuehrung && !p.fehler.ausfuehrung) p.fehler.ausfuehrung = 'Bitte wählen, ob du die Arbeit selbst erledigst oder eine Werkstatt sie macht.';
    if (Object.keys(p.fehler).length) return Promise.resolve({ ok: false, fehler: p.fehler });
    var aid = roh && typeof roh.adresseId === 'string' ? roh.adresseId.trim() : '';
    return pruefeAdresseDesVorgangs(this, aid, null).then(function (af) {
      if (af) return { ok: false, fehler: af };
      return vorgangNeuerStand(self, id, function (alt) {
        if (alt.status === 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist erledigt.' } };
        if (alt.art !== 'stoerung') return { fehler: { allgemein: 'Das ist schon eine Arbeit.' } };
        alt.art = 'arbeit'; alt.ausfuehrung = p.werte.ausfuehrung; alt.arbeit = p.werte.arbeit; alt.adresseId = aid || null;
        return { werte: alt };
      });
    });
  };

  Daten.prototype.vorgangErledigen = function (id, roh) {
    var self = this;
    var p = pruefeWerte([{ key: 'datum', label: 'Erledigt am', typ: 'datum' }, { key: 'notiz', label: 'Notiz', typ: 'text' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var heute = this.heute();
    if (!p.werte.datum && !p.fehler.datum) p.werte.datum = heute;
    if (p.werte.datum && p.werte.datum > heute && !p.fehler.datum) p.fehler.datum = 'Das Datum liegt in der Zukunft.';
    if (Object.keys(p.fehler).length) return Promise.resolve({ ok: false, fehler: p.fehler });
    return vorgangNeuerStand(this, id, function (alt) {
      if (alt.status === 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist schon erledigt.' } };
      if (alt.gemeldetAm && p.werte.datum < alt.gemeldetAm) return { fehler: { datum: 'Das Datum liegt vor dem Tag, an dem der Vorgang eingetragen wurde (' + MM.Hilfen.datum(alt.gemeldetAm) + ').' } };
      alt.status = 'erledigt'; alt.erledigtAm = p.werte.datum; alt.erledigtNotiz = p.werte.notiz;
      return { werte: alt };
    });
  };

  Daten.prototype.vorgangWiederOeffnen = function (id) {
    return vorgangNeuerStand(this, id, function (alt) {
      if (alt.status !== 'erledigt') return { fehler: { allgemein: 'Dieser Vorgang ist nicht erledigt.' } };
      alt.status = 'offen'; alt.erledigtAm = null; alt.erledigtNotiz = null;
      return { werte: alt };
    });
  };

  function vorgangEintrag(v, eintraege, namen) {
    var l = eintraege.slice().sort(nachNr);
    var a = l[l.length - 1];
    if (!a) return null;
    return { vorgang: v, aktuell: a, komponenteId: v.komponenteId, besitzer: v.komponenteId ? (namen[v.komponenteId] || 'Komponente') : null };
  }
  function vorgangSortieren(res) {
    res.sort(function (a, b) {
      var d = MM.Werkstatt.rang(b.aktuell.werte) - MM.Werkstatt.rang(a.aktuell.werte);
      if (d) return d;
      var wa = a.aktuell.werte, wb = b.aktuell.werte;
      var da = wa.status === 'erledigt' ? (wa.erledigtAm || '') : (wa.gemeldetAm || ''), db = wb.status === 'erledigt' ? (wb.erledigtAm || '') : (wb.gemeldetAm || '');
      if (da !== db) return da < db ? 1 : -1;
      return wa.bezeichnung.localeCompare(wb.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
    return res;
  }

  /* Alle Vorgänge eines Fahrzeugs und seiner Komponenten. Was das Fahrzeug am meisten bremst, steht oben, Erledigtes unten. */
  Daten.prototype.vorgaengeListe = function (fahrzeugId) {
    return Promise.all([this.speicher.wo('vorgaenge', 'fahrzeugId', fahrzeugId), this.speicher.alle('verlaeufe'), this.komponentenListe(fahrzeugId)]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'vorgang') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var kn = {}; r[2].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      return vorgangSortieren(r[0].map(function (v) { return vorgangEintrag(v, ver[v.id] || [], kn); }).filter(Boolean));
    });
  };

  /* Pro Fahrzeug: wie viele Vorgänge sind offen, wie viele bremsen das Fahrzeug? */
  Daten.prototype.vorgaengeUebersicht = function () {
    var self = this;
    return this.fahrzeugListe().then(function (liste) {
      return Promise.all(liste.map(function (x) { return self.vorgaengeListe(x.fahrzeug.id); })).then(function (alle) {
        var res = {};
        liste.forEach(function (x, i) {
          var z = { offen: 0, nicht: 0, bedingt: 0 };
          alle[i].forEach(function (v) {
            var w = v.aktuell.werte;
            if (w.status !== 'offen') return;
            z.offen++;
            if (MM.Werkstatt.bremst(w)) z[w.auswirkung]++;
          });
          res[x.fahrzeug.id] = z;
        });
        return res;
      });
    });
  };

  /* Entscheidungen „trotzdem nutzen“: neueste je Vorgang und Aktivität. */
  function neuesteEntscheidungen(liste) {
    var res = {};
    liste.forEach(function (e) {
      var k = e.vorgangId + '|' + e.aktivitaetId;
      if (!res[k] || e.nr > res[k].nr) res[k] = e;
    });
    return res;
  }

  Daten.prototype.vorgangLaden = function (id) {
    var self = this;
    return this.speicher.holen('vorgaenge', id).then(function (v) {
      if (!v) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.fahrzeugLaden(v.fahrzeugId),
        self.komponentenListe(v.fahrzeugId),
        self.speicher.wo('vorgangsentscheidungen', 'vorgangId', id),
        self.adressenListe()
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[1]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        /* Im Verlauf steht bei der Adresse ihr Name, nicht ihre Kennung. */
        var adressOpt = r[4].map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; });
        var felder = MM.Werkstatt.felderAlle().map(function (f) { return f.key === 'adresseId' ? Object.assign({}, f, { optionen: adressOpt }) : f; });
        var adresse = aktuell.werte.adresseId ? (r[4].filter(function (a) { return a.objekt.id === aktuell.werte.adresseId; })[0] || null) : null;
        var komp = v.komponenteId ? r[2].filter(function (k) { return k.komponente.id === v.komponenteId; })[0] : null;
        var neueste = neuesteEntscheidungen(r[3]), entscheidungen = {};
        Object.keys(neueste).forEach(function (k) { var e = neueste[k]; entscheidungen[e.aktivitaetId] = { entscheidung: e.entscheidung, am: e.erstelltAm }; });
        return { vorgang: v, aktuell: aktuell, verlauf: verlaufAus(eintraege, felder), adresse: adresse,
          fahrzeug: r[1].fahrzeug, fahrzeugAktuell: r[1].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null,
          entscheidungen: entscheidungen };
      });
    });
  };

  /*
   * Warnung für ein Fahrzeug: Bremsen offene Vorgänge das Fahrzeug, und ist es für die nächste Zeit
   * versprochen (Aktivität läuft oder ist geplant, nicht storniert)? Gibt immer ein Ergebnis zurück:
   * stufe 'nicht', 'bedingt' oder 'ok', die bremsenden Vorgänge und die betroffenen Aktivitäten.
   * Eine Aktivität gilt als entschieden („trotzdem nutzen“), wenn das für jeden bremsenden Vorgang bestätigt ist.
   */
  Daten.prototype.vorgangWarnung = function (fahrzeugId) {
    return Promise.all([this.vorgaengeListe(fahrzeugId), this.aktivitaetenListe(), this.speicher.alle('vorgangsentscheidungen')]).then(function (r) {
      var bremsend = r[0].filter(function (x) { return MM.Werkstatt.bremst(x.aktuell.werte); });
      var stufe = MM.Werkstatt.einsatz(r[0].map(function (x) { return x.aktuell.werte; }));
      var neueste = neuesteEntscheidungen(r[2]);
      var aktivitaeten = stufe === 'ok' ? [] : r[1].filter(function (a) {
        return a.aktuell.werte.fahrzeugId === fahrzeugId && (a.status === 'laeuft' || a.status === 'geplant');
      }).map(function (a) {
        var entschieden = bremsend.every(function (b) { var e = neueste[b.vorgang.id + '|' + a.objekt.id]; return e && e.entscheidung === 'trotzdem'; });
        return { aktivitaet: a, trotzdem: entschieden };
      });
      return { stufe: stufe, vorgaenge: bremsend, aktivitaeten: aktivitaeten };
    });
  };

  /* Entscheidung zu einer Aktivität: 'trotzdem' (trotzdem nutzen) oder 'offen' (zurückgenommen). Nichts wird gelöscht. */
  Daten.prototype.vorgangEntscheiden = function (vorgangId, aktivitaetId, entscheidung) {
    var self = this;
    if (entscheidung !== 'trotzdem' && entscheidung !== 'offen') return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Entscheidung gibt es nicht.' } });
    return Promise.all([this.speicher.holen('vorgaenge', vorgangId), this.speicher.holen('aktivitaeten', aktivitaetId), this.speicher.wo('vorgangsentscheidungen', 'vorgangId', vorgangId)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
      if (!r[1]) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var nr = r[2].filter(function (e) { return e.aktivitaetId === aktivitaetId; }).reduce(function (m, e) { return Math.max(m, e.nr); }, 0) + 1;
      var e = { id: neueId('vt'), vorgangId: vorgangId, aktivitaetId: aktivitaetId, nr: nr, entscheidung: entscheidung, erstelltAm: self.jetzt() };
      return self.speicher.speichern('vorgangsentscheidungen', e).then(function () { return { ok: true, id: e.id }; });
    });
  };

  /* ---------- Werkstatt: Adressen (Werkstätten, Lieferanten, Händler, seit 2.0.25) ---------- */
  /*
   * Eine einzige, zentrale Liste im Datenraum des Nutzers, nicht pro Fahrzeug. Jede Änderung ist ein neuer
   * Eintrag im Verlauf. Eine Adresse, auf die ein Vorgang verweist, wird nie gelöscht: Es gibt kein Löschen,
   * nur Ausblenden (wie bei Orten und Gebieten). Der Vorgang verweist mit adresseId auf sie.
   */
  function adresseFelder() { return MM.Werkstatt.adressFelder().concat([{ key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }]); }

  Daten.prototype.pruefenAdresse = function (roh) {
    var p = pruefeWerte(MM.Werkstatt.adressFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen eingeben, zum Beispiel „Autohaus Müller“.' });
    var w = p.werte, f = p.fehler;
    if (!w.art && !f.art) f.art = 'Bitte wählen, ob es eine Werkstatt, ein Lieferant oder ein Händler ist.';
    if (w.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(w.email)) f.email = 'Das ist keine gültige E-Mail-Adresse.';
    if (w.telefon && !/^[0-9+\-\/() ]{5,}$/.test(w.telefon)) f.telefon = 'Bitte nur Ziffern, Leerzeichen und + - / ( ) eingeben.';
    w.ausgeblendet = roh && roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Welche Vorgänge verweisen (im aktuellen Stand) auf welche Adresse? { adresseId: [{ vorgang, aktuell }] } */
  function vorgaengeNachAdresse(vorgaenge, verlaeufe) {
    var neu = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === 'vorgang' && (!neu[e.objektId] || e.nr > neu[e.objektId].nr)) neu[e.objektId] = e; });
    var res = {};
    vorgaenge.forEach(function (v) {
      var a = neu[v.id];
      if (a && a.werte.adresseId) (res[a.werte.adresseId] = res[a.werte.adresseId] || []).push({ vorgang: v, aktuell: a });
    });
    return res;
  }

  /* Alle Adressen, nach Namen sortiert, mit der Zahl der Vorgänge, die darauf verweisen. */
  Daten.prototype.adressenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('adressen'), this.speicher.alle('verlaeufe'), this.speicher.alle('vorgaenge')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'adresse');
      var karte = vorgaengeNachAdresse(r[2], r[1]);
      liste.forEach(function (x) { x.anzahlVorgaenge = (karte[x.objekt.id] || []).length; });
      return liste;
    });
  };

  function gleicheAdresse(liste, name, art, ausser) {
    var n = name.toLowerCase();
    return liste.some(function (x) { return x.objekt.id !== ausser && x.aktuell.werte.art === art && x.aktuell.werte.bezeichnung.toLowerCase() === n; });
  }

  Daten.prototype.adresseAnlegen = function (roh) {
    var self = this;
    var p = this.pruefenAdresse(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    p.werte.ausgeblendet = 'nein';
    return this.adressenListe().then(function (liste) {
      if (gleicheAdresse(liste, p.werte.bezeichnung, p.werte.art)) return { ok: false, fehler: { bezeichnung: 'Diese Adresse gibt es schon.' } };
      return self.mitVerlaufAnlegen('adressen', 'adresse', 'ad', p.werte);
    });
  };

  Daten.prototype.adresseAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('adressen', id, adresseFelder()), this.adressenListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Adresse wurde nicht gefunden.' } };
      var p = self.pruefenAdresse(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicheAdresse(r[1], p.werte.bezeichnung, p.werte.art, id)) return { ok: false, fehler: { bezeichnung: 'Diese Adresse gibt es schon.' } };
      return self.mitVerlaufAendern('adresse', id, x, p.werte, adresseFelder());
    });
  };

  /* Eine Adresse mit Verlauf und den Vorgängen, die darauf verweisen (mit Fahrzeug, offene zuerst). */
  Daten.prototype.adresseLaden = function (id) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('adressen', id, adresseFelder()), this.speicher.alle('vorgaenge'), this.speicher.alle('verlaeufe'), this.fahrzeugListe({ alle: true })]).then(function (r) {
      var x = r[0];
      if (!x || x.objekt.datenraumId !== self.datenraumId) return null;
      var fz = {}; r[3].forEach(function (f) { fz[f.fahrzeug.id] = f.aktuell.werte.bezeichnung; });
      x.vorgaenge = (vorgaengeNachAdresse(r[1], r[2])[id] || []).map(function (m) {
        var w = m.aktuell.werte;
        return { id: m.vorgang.id, bezeichnung: w.bezeichnung, art: w.art, status: w.status, fahrzeugName: fz[m.vorgang.fahrzeugId] || 'Fahrzeug' };
      }).sort(function (a, b) {
        if (a.status !== b.status) return a.status === 'offen' ? -1 : 1;
        return a.bezeichnung.localeCompare(b.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return x;
    });
  };

  /* ---------- Kosten (seit 2.0.27) ---------- */
  /*
   * Eine einzige Kosten-Liste für alle Fahrzeuge (Tabelle „kosten“, Index fahrzeugId). Ein Posten gehört zu einem
   * Fahrzeug und hat die Gruppe Fixkosten, variable Kosten oder Instandhaltung. Die Gruppe lässt sich nachträglich
   * nicht ändern. Verweise (in den Werten, damit sie im Verlauf stehen): komponenteId, aktivitaetId (nur variable
   * Kosten), vorgangId (nur Instandhaltung, nur beim Anlegen). Jede Änderung ist ein neuer Eintrag im Verlauf, nichts
   * wird gelöscht: Ein Posten lässt sich ausblenden und wieder einblenden, ausgeblendete rechnen nicht mit.
   * Die Kostenstammdaten (Tabelle „kostenstamm“, eine Zeile je Fahrzeug, Verlauf) halten Wert, Wertverlust und den
   * Vergleichspreis. Der Wertverlust ist keine Eingabe, sondern wird in der Auswertung gerechnet.
   */
  function trimmed2(v) { return typeof v === 'string' ? v.trim() : ''; }

  /* Geldbeträge: Der Punkt als Tausendertrennzeichen („2.400“, „1.234,50“) gilt als Tausenderpunkt, nicht als Komma:
     „2.400“ sind 2400 Euro und nicht 2,4. Alles andere (Komma oder Punkt als Dezimalzeichen, „12,5“ und „12.5“) bleibt, wie es ist. */
  function geldRoh(v) {
    if (typeof v !== 'string') return v;
    var t = v.replace(/\s/g, '').replace(/€/g, '');
    return /^\d{1,3}(\.\d{3})+(,\d+)?$/.test(t) ? t.replace(/\./g, '') : t;
  }

  /* arten (seit 2.0.29, freiwillig): die Kostenarten, die gelten (eingebaute und eigene). Ohne Angabe gelten nur die eingebauten. */
  Daten.prototype.pruefenKosten = function (roh, gruppe, arten) {
    roh = Object.assign({}, roh || {});
    roh.betrag = geldRoh(roh.betrag);
    var g = MM.Kosten.istGruppe(gruppe) ? gruppe : null;
    if (!g) return { werte: {}, fehler: { gruppe: 'Bitte wählen: Fixkosten, variable Kosten, Instandhaltung oder Reisekasse.' }, ok: false };
    var p = pruefeWerte(MM.Kosten.felder(g, arten), roh, jahrVon(this), {
      bezeichnungFehler: 'Bitte kurz sagen, wofür der Betrag ist, zum Beispiel „Liegeplatz Heimathafen“ oder „Zündkerzen“.' });
    var w = p.werte, f = p.fehler;
    w.gruppe = g;
    /* Währung (seit 2.0.29): nur bei variablen Kosten und in der Reisekasse. Ohne Angabe oder bei EUR steht nichts am Posten (Euro). */
    var wRoh = trimmed2(roh.waehrung), wc = wRoh ? MM.Reisekasse.waehrungNormal(wRoh) : null;
    if (wRoh && !wc) f.waehrung = 'Bitte ein Währungskürzel mit drei Buchstaben eingeben, zum Beispiel NOK.';
    var fremd = !!wc && wc !== 'EUR';
    if (fremd && g !== 'variabel' && g !== 'reisekasse') f.waehrung = 'Eine andere Währung gibt es nur bei variablen Kosten und in der Reisekasse.';
    var extra = pruefeWerte([{ key: 'betragWaehrung', typ: 'zahl' }, { key: 'ortText', typ: 'text', maxLaenge: 120 }],
      Object.assign({}, roh, { betragWaehrung: geldRoh(roh.betragWaehrung) }), jahrVon(this), { ohneBezeichnung: true });
    if (extra.fehler.ortText) f.ortText = extra.fehler.ortText;
    if (fremd && extra.fehler.betragWaehrung) f.betragWaehrung = extra.fehler.betragWaehrung;
    w.waehrung = fremd ? wc : null;
    w.betragWaehrung = null;
    if (fremd && !f.betragWaehrung) {
      var bw = extra.werte.betragWaehrung;
      if (!(bw > 0)) f.betragWaehrung = 'Bitte den Betrag in ' + wc + ' eingeben.';
      else if (bw > 1000000000) f.betragWaehrung = 'Der Betrag ist zu groß.';
      else w.betragWaehrung = MM.Kosten.runde(bw);
    }
    /* Der Euro-Betrag darf bei Fremdwährung fehlen: Dann rechnet ihn die App mit dem Kurs der Kasse. */
    if (w.betrag === null && !f.betrag && !fremd) f.betrag = 'Bitte einen Betrag eingeben.';
    else if (w.betrag !== null && !f.betrag) {
      if (!(w.betrag > 0)) f.betrag = 'Der Betrag muss größer als 0 sein.';
      else if (w.betrag > 10000000) f.betrag = 'Der Betrag ist zu groß.';
      else w.betrag = MM.Kosten.runde(w.betrag);
    }
    if (!w.datum && !f.datum) w.datum = this.heute();
    if (g === 'fix') {
      if (!w.rhythmus && !f.rhythmus) f.rhythmus = 'Bitte wählen, wie oft der Betrag fällig wird.';
      if (w.rhythmus === 'einmalig') w.bis = null;
      if (w.bis && w.datum && w.bis < w.datum && !f.bis) f.bis = 'Das Ende kann nicht vor dem Beginn liegen.';
    } else { w.rhythmus = 'einmalig'; w.bis = null; }
    if (!w.grundlage && !f.grundlage) w.grundlage = 'eingegeben';
    w.komponenteId = trimmed2(roh.komponenteId) || null;
    var mitAkt = g === 'variabel' || g === 'reisekasse';
    var aid = trimmed2(roh.aktivitaetId);
    if (aid && !mitAkt) f.aktivitaetId = 'Eine Aktivität kann nur bei variablen Kosten und in der Reisekasse gewählt werden.';
    if (g === 'reisekasse' && !aid && !f.aktivitaetId) f.aktivitaetId = 'Eine Ausgabe der Reisekasse gehört zu einer Aktivität. Bitte wählen.';
    w.aktivitaetId = mitAkt && aid ? aid : null;
    var oid = trimmed2(roh.ortId);
    if (oid && !mitAkt) f.ortId = 'Ein Ort kann nur bei variablen Kosten und in der Reisekasse gewählt werden.';
    w.ortId = mitAkt && oid ? oid : null;
    var ot = extra.werte.ortText;
    if (ot && !mitAkt) f.ortText = 'Ein Ort als Text kann nur bei variablen Kosten und in der Reisekasse stehen.';
    w.ortText = mitAkt && ot ? ot : null;
    /* Tag der Reise (seit 2.0.43): ein Posten einer Aktivität kann einem Tag (Etappe) zugeordnet werden. */
    var tid = trimmed2(roh.abschnittId);
    if (tid && !(mitAkt && aid)) f.abschnittId = 'Ein Tag kann nur bei Kosten einer Aktivität gewählt werden.';
    w.abschnittId = mitAkt && aid && tid ? tid : null;
    w.besuchId = null;
    w.vorgangId = null;
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Prüft, ob es die verknüpften Dinge gibt und ob sie zum Fahrzeug gehören. Gibt null oder die Fehler zurück. */
  function pruefeKostenVerweise(self, fahrzeugId, w, vorgangId) {
    return Promise.all([
      w.komponenteId ? self.speicher.holen('komponenten', w.komponenteId) : Promise.resolve(null),
      w.aktivitaetId ? self.aktivitaetLaden(w.aktivitaetId) : Promise.resolve(null),
      vorgangId ? self.speicher.holen('vorgaenge', vorgangId) : Promise.resolve(null),
      w.ortId ? self.speicher.holen('orte', w.ortId) : Promise.resolve(null),
      w.abschnittId ? self.speicher.holen('tagesabschnitte', w.abschnittId) : Promise.resolve(null)
    ]).then(function (r) {
      var fehler = {};
      if (w.abschnittId && (!r[4] || r[4].aktivitaetId !== w.aktivitaetId)) fehler.abschnittId = 'Diesen Tag gibt es bei dieser Aktivität nicht.';
      if (w.ortId && (!r[3] || r[3].datenraumId !== self.datenraumId)) fehler.ortId = 'Diesen Ort gibt es nicht.';
      if (w.komponenteId && (!r[0] || r[0].fahrzeugId !== fahrzeugId)) fehler.komponenteId = 'Diese Komponente gibt es an diesem Fahrzeug nicht.';
      if (w.aktivitaetId && (!r[1] || r[1].fahrzeug.id !== fahrzeugId)) fehler.aktivitaetId = 'Diese Aktivität gibt es für dieses Fahrzeug nicht.';
      if (vorgangId && (!r[2] || r[2].fahrzeugId !== fahrzeugId)) fehler.vorgangId = 'Diesen Vorgang gibt es an diesem Fahrzeug nicht.';
      return { fehler: Object.keys(fehler).length ? fehler : null, vorgang: r[2] };
    });
  }

  /* Neuer Posten. roh.gruppe ist Pflicht, roh.vorgangId (freiwillig) hängt den Betrag an einen Vorgang der Werkstatt.
     Seit 2.0.29: eigene Kostenarten, eine neue Art mitten im Formular (neueKostenart), Bezahlt mit (bezahltMit, neuesZahlungsmittel),
     Währung (waehrung, betragWaehrung), Ort als Text (ortText) und die Gruppe „reisekasse“ (gehört immer zu einer Aktivität). */
  Daten.prototype.kostenAnlegen = function (fahrzeugId, roh) {
    var self = this;
    roh = roh || {};
    var vid = trimmed2(roh.vorgangId), bid = trimmed2(roh.besuchId);
    return kostenVollstaendig(self, roh, roh.gruppe, null, null).then(function (p) {
      var fehler = p.ok ? {} : Object.assign({}, p.fehler);
      var gr = MM.Kosten.istGruppe(roh.gruppe) ? roh.gruppe : null;
      if (vid && gr && gr !== 'instandhaltung') fehler.gruppe = 'Ein Betrag an einem Vorgang gehört zur Instandhaltung.';
      if (bid && gr && gr !== 'variabel') fehler.gruppe = 'Ein Betrag an einem Besuch gehört zu den variablen Kosten.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      return self.pruefeObjekt(fahrzeugId, null).then(function (f) {
        if (f) return { ok: false, fehler: f };
        /* Ein Betrag an einem Besuch (seit 2.0.28) übernimmt Ort und Aktivität des Besuchs. */
        return (bid ? self.mitVerlaufLaden('besuche', bid, []) : Promise.resolve(null)).then(function (bx) {
          if (bid && (!bx || bx.objekt.fahrzeugId !== fahrzeugId || bx.aktuell.werte.status !== 'besucht')) return { ok: false, fehler: { besuchId: 'Diesen Besuch gibt es an diesem Fahrzeug nicht.' } };
          if (bx) { p.werte.ortId = bx.aktuell.werte.ortId || null; p.werte.aktivitaetId = bx.objekt.aktivitaetId || null; }
          return pruefeKostenVerweise(self, fahrzeugId, p.werte, vid || null).then(function (v) {
            if (v.fehler) return { ok: false, fehler: v.fehler };
            var w = p.werte;
            w.besuchId = bx ? bid : null;
            w.vorgangId = vid || null;
            if (v.vorgang && !w.komponenteId) w.komponenteId = v.vorgang.komponenteId || null;
            var jetzt = self.jetzt(), ko = { id: neueId('ko'), datenraumId: self.datenraumId, fahrzeugId: fahrzeugId, erstelltAm: jetzt };
            return self.speicher.mehrereSpeichern(p.schreiben.concat([{ tabelle: 'kosten', objekt: ko },
              { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kosten', ko.id, 1, w, null, jetzt) }])).then(function () { return { ok: true, id: ko.id }; });
          });
        });
      });
    });
  };

  Daten.prototype.kostenAendern = function (id, roh) {
    var self = this;
    roh = roh || {};
    return this.mitVerlaufLaden('kosten', id, MM.Kosten.felderAlle()).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieser Posten wurde nicht gefunden.' } };
      var alt = x.aktuell.werte;
      /* Ein Posten der Reisekasse bleibt an seiner Aktivität. */
      if (alt.gruppe === 'reisekasse') roh = Object.assign({}, roh, { aktivitaetId: alt.aktivitaetId });
      return kostenVollstaendig(self, roh, alt.gruppe, alt, null).then(function (p) {
        if (!p.ok) return { ok: false, fehler: p.fehler };
        if (!Object.prototype.hasOwnProperty.call(roh, 'ausgeblendet')) p.werte.ausgeblendet = alt.ausgeblendet || 'nein';
        return pruefeKostenVerweise(self, x.objekt.fahrzeugId, p.werte, null).then(function (v) {
          if (v.fehler) return { ok: false, fehler: v.fehler };
          p.werte.vorgangId = alt.vorgangId || null;
          /* Kommt das Feld „Tag“ nicht mit, bleibt der bisherige Tag erhalten. */
          if (!Object.prototype.hasOwnProperty.call(roh, 'abschnittId') && p.werte.aktivitaetId === (alt.aktivitaetId || null)) p.werte.abschnittId = alt.abschnittId || null;
          /* Ein Betrag aus einem Besuch behält Besuch und Ort (sonst stimmt die Historie des Ortes nicht mehr). */
          p.werte.besuchId = alt.besuchId || null;
          if (alt.besuchId) p.werte.ortId = alt.ortId || null;
          var aenderung = unterschiedeFelder(MM.Kosten.felderAlle(), alt, p.werte).length > 0;
          if (!aenderung && !p.schreiben.length) return { ok: true, id: id, geaendert: false };
          var e = aenderung ? neuerVerlaufEintrag('kosten', id, x.aktuell.nr + 1, p.werte, x.aktuell.id, self.jetzt()) : null;
          return self.speicher.mehrereSpeichern(p.schreiben.concat(e ? [{ tabelle: 'verlaeufe', objekt: e }] : []))
            .then(function () { return { ok: true, id: id, geaendert: aenderung }; });
        });
      });
    });
  };

  /* Ausblenden (der Posten rechnet nicht mehr mit) oder wieder einblenden. Nichts wird gelöscht. */
  Daten.prototype.kostenAusblenden = function (id, ausblenden) {
    var self = this;
    return this.mitVerlaufLaden('kosten', id, MM.Kosten.felderAlle()).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieser Posten wurde nicht gefunden.' } };
      var w = Object.assign({}, x.aktuell.werte, { ausgeblendet: ausblenden ? 'ja' : 'nein' });
      return self.mitVerlaufAendern('kosten', id, x, w, MM.Kosten.felderAlle());
    });
  };

  /*
   * Löschen (seit 2.0.46): Der Posten, sein ganzer Verlauf und seine Fotos und Belege (samt Dateien) werden endgültig entfernt.
   * Wer nur will, dass der Posten nicht mehr mitrechnet, blendet ihn aus. Die Kasse einer Reise rechnet aus den Posten, ein gelöschter
   * Betrag zählt dort nicht mehr. Ergebnis { ok, belege } mit der Zahl der mitgelöschten Fotos und Belege.
   */
  Daten.prototype.kostenLoeschen = function (id) {
    var self = this;
    return this.speicher.holen('kosten', id).then(function (o) {
      if (!o || o.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieser Posten wurde nicht gefunden.' } };
      return Promise.all([self.speicher.wo('verlaeufe', 'objektId', id), self.speicher.wo('dokumente', 'kostenId', id)]).then(function (r) {
        var docs = r[1].filter(function (d) { return d.kostenId === id; });
        return Promise.all(docs.map(function (d) {
          return Promise.all([self.speicher.wo('verlaeufe', 'objektId', d.id), self.speicher.wo('dateien', 'dokumentId', d.id)]);
        })).then(function (rd) {
          var weg = [{ tabelle: 'kosten', id: id }];
          r[0].forEach(function (e) { if (e.objektTyp === 'kosten') weg.push({ tabelle: 'verlaeufe', id: e.id }); });
          docs.forEach(function (d, i) {
            weg.push({ tabelle: 'dokumente', id: d.id });
            rd[i][0].forEach(function (e) { if (e.objektTyp === 'dokument') weg.push({ tabelle: 'verlaeufe', id: e.id }); });
            rd[i][1].forEach(function (f) { weg.push({ tabelle: 'dateien', id: f.id }); });
          });
          return self.speicher.mehrereLoeschen(weg).then(function () { return { ok: true, belege: docs.length }; });
        });
      });
    });
  };

  /* Namen für die Verweise der Posten eines Fahrzeugs: { komponenten, aktivitaeten, vorgaenge } (Kennung -> Name). */
  function kostenNamen(self, fahrzeugId) {
    return Promise.all([self.komponentenListe(fahrzeugId), self.aktivitaetenListe(), self.vorgaengeListe(fahrzeugId), self.orteListe()]).then(function (r) {
      var k = {}, a = {}, v = {}, o = {};
      r[0].forEach(function (x) { k[x.komponente.id] = x.aktuell.werte.bezeichnung; });
      r[1].forEach(function (x) { a[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      r[2].forEach(function (x) { v[x.vorgang.id] = x.aktuell.werte.bezeichnung; });
      r[3].forEach(function (x) { o[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      return { komponenten: k, aktivitaeten: a, vorgaenge: v, orte: o };
    });
  }

  function kostenSortieren(liste) {
    liste.sort(function (a, b) {
      var da = a.aktuell.werte.datum || '', db = b.aktuell.werte.datum || '';
      if (da !== db) return da < db ? 1 : -1;
      return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
    });
    return liste;
  }

  /* Alle Posten eines Fahrzeugs (auch ausgeblendete), neueste zuerst, mit den Namen der Verweise. */
  Daten.prototype.kostenListe = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.speicher.wo('kosten', 'fahrzeugId', fahrzeugId), this.speicher.alle('verlaeufe'), kostenNamen(this, fahrzeugId), this.kostenartenListe(), this.zahlungsmittelListe()]).then(function (r) {
      var artN = {}, zmN = {};
      r[3].forEach(function (x) { artN[x.wert] = x.label; }); r[4].forEach(function (x) { zmN[x.wert] = x.label; });
      var ver = {};
      r[1].forEach(function (e) { if (e.objektTyp === 'kosten') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var n = r[2];
      var liste = r[0].filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
        var l = (ver[o.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1];
        if (!a) return null;
        var w = a.werte;
        return { objekt: o, aktuell: a, komponenteName: w.komponenteId ? (n.komponenten[w.komponenteId] || 'Komponente') : null,
          aktivitaetName: w.aktivitaetId ? (n.aktivitaeten[w.aktivitaetId] || 'Aktivität') : null,
          vorgangName: w.vorgangId ? (n.vorgaenge[w.vorgangId] || 'Vorgang') : null,
          ortName: w.ortId ? (n.orte[w.ortId] || 'Ort') : null,
          artName: w.kostenart ? (artN[w.kostenart] || 'Art') : null, zahlungName: w.bezahltMit ? (zmN[w.bezahltMit] || 'Zahlungsmittel') : null };
      }).filter(Boolean);
      return kostenSortieren(liste);
    });
  };

  /* Ein Posten mit Verlauf (die Verweise im Verlauf mit Namen) und den verknüpften Dingen. */
  Daten.prototype.kostenLaden = function (id) {
    var self = this;
    return this.speicher.holen('kosten', id).then(function (o) {
      if (!o || o.datenraumId !== self.datenraumId) return null;
      return Promise.all([self.speicher.wo('verlaeufe', 'objektId', id), self.fahrzeugLaden(o.fahrzeugId), kostenNamen(self, o.fahrzeugId), self.kostenartenListe(), self.zahlungsmittelListe(), self.dokumenteFuerKosten(id)]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[1]) return null;
        var artN = {}, zmN = {};
        r[3].forEach(function (x) { artN[x.wert] = x.label; }); r[4].forEach(function (x) { zmN[x.wert] = x.label; });
        var n = r[2], aktuell = eintraege[eintraege.length - 1];
        function opt(karte) { return Object.keys(karte).map(function (k) { return { wert: k, label: karte[k] }; }); }
        var felder = MM.Kosten.felderAlle().map(function (f) {
          if (f.key === 'komponenteId') return Object.assign({}, f, { optionen: opt(n.komponenten) });
          if (f.key === 'aktivitaetId') return Object.assign({}, f, { optionen: opt(n.aktivitaeten) });
          if (f.key === 'vorgangId') return Object.assign({}, f, { optionen: opt(n.vorgaenge) });
          if (f.key === 'ortId') return Object.assign({}, f, { optionen: opt(n.orte) });
          if (f.key === 'kostenart') return Object.assign({}, f, { optionen: r[3].map(function (x) { return { wert: x.wert, label: x.label }; }) });
          if (f.key === 'bezahltMit') return Object.assign({}, f, { optionen: r[4].map(function (x) { return { wert: x.wert, label: x.label }; }) });
          return f;
        });
        var w = aktuell.werte;
        return { objekt: o, aktuell: aktuell, verlauf: verlaufAus(eintraege, felder), fahrzeug: r[1].fahrzeug, fahrzeugAktuell: r[1].aktuell,
          komponenteName: w.komponenteId ? (n.komponenten[w.komponenteId] || 'Komponente') : null,
          aktivitaetName: w.aktivitaetId ? (n.aktivitaeten[w.aktivitaetId] || 'Aktivität') : null,
          vorgangName: w.vorgangId ? (n.vorgaenge[w.vorgangId] || 'Vorgang') : null,
          ortName: w.ortId ? (n.orte[w.ortId] || 'Ort') : null,
          artName: w.kostenart ? (artN[w.kostenart] || 'Art') : null, zahlungName: w.bezahltMit ? (zmN[w.bezahltMit] || 'Zahlungsmittel') : null,
          dokumente: r[5] };
      });
    });
  };

  /* ---------- Offene Listen: Kostenarten und Zahlungsmittel (seit 2.0.29) ---------- */
  /*
   * Kostenarten: die eingebauten (Startliste in MM.Kosten.KOSTENARTEN, Kennung = ihr Name) und eigene (Tabelle „kostenarten“, mit Verlauf).
   * Eine Art gehört zu einer Gruppe. Benutzte Arten werden nur ausgeblendet, nicht gelöscht. Ausgeblendet bleibt eine Art an
   * bestehenden Posten gültig. Die eingebauten lassen sich ebenfalls ausblenden (Einstellung „kostenarten“).
   * Zahlungsmittel: „Bar“ ist fest (Kennung 'bar', gehört zur Kasse), alle weiteren sind eigene Bezeichnungen ohne Nummern.
   */
  var KOSTENART_FELDER = [{ key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: [{ wert: 'ja', label: 'Ja' }, { wert: 'nein', label: 'Nein' }] }];

  Daten.prototype.kostenartenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('kostenarten'), this.speicher.alle('verlaeufe'), this.speicher.holen('einstellungen', 'kostenarten')]).then(function (r) {
      var versteckt = (r[2] && r[2].ausgeblendet) || [];
      var liste = MM.Kosten.KOSTENARTEN.map(function (a) { return { wert: a.wert, label: a.label, gruppe: a.gruppe, eigen: false, ausgeblendet: versteckt.indexOf(a.wert) >= 0 }; });
      sammle(self, r[0], r[1], 'kostenart').forEach(function (x) {
        liste.push({ wert: x.objekt.id, label: x.aktuell.werte.bezeichnung, gruppe: x.aktuell.werte.gruppe, eigen: true, ausgeblendet: x.aktuell.werte.ausgeblendet === 'ja' });
      });
      return liste;
    });
  };

  Daten.prototype.kostenartAnlegen = function (gruppe, bezeichnung) {
    var self = this, bez = trimmed2(bezeichnung);
    if (!MM.Kosten.istGruppe(gruppe)) return Promise.resolve({ ok: false, fehler: { gruppe: 'Bitte die Gruppe wählen.' } });
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben, zum Beispiel „Kurtaxe“.' } });
    if (bez.length > 60) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte höchstens 60 Zeichen.' } });
    return this.kostenartenListe().then(function (liste) {
      if (liste.some(function (a) { return a.gruppe === gruppe && a.label.toLowerCase() === bez.toLowerCase(); })) return { ok: false, fehler: { bezeichnung: 'Diese Art gibt es in dieser Gruppe schon.' } };
      return self.mitVerlaufAnlegen('kostenarten', 'kostenart', 'kart', { bezeichnung: bez, gruppe: gruppe, ausgeblendet: 'nein' });
    });
  };

  /* Eine Art ausblenden oder wieder einblenden (eingebaut oder eigen). */
  Daten.prototype.kostenartAusblenden = function (wert, ausblenden) {
    var self = this;
    var eingebaut = MM.Kosten.KOSTENARTEN.some(function (a) { return a.wert === wert; });
    if (eingebaut) {
      return this.speicher.holen('einstellungen', 'kostenarten').then(function (e) {
        var l = ((e && e.ausgeblendet) || []).filter(function (x) { return x !== wert; });
        if (ausblenden) l.push(wert);
        return self.speicher.speichern('einstellungen', { id: 'kostenarten', ausgeblendet: l }).then(function () { return { ok: true }; });
      });
    }
    return this.mitVerlaufLaden('kostenarten', wert, KOSTENART_FELDER).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      return self.mitVerlaufAendern('kostenart', wert, x, Object.assign({}, x.aktuell.werte, { ausgeblendet: ausblenden ? 'ja' : 'nein' }), KOSTENART_FELDER);
    });
  };

  Daten.prototype.zahlungsmittelListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('zahlungsmittel'), this.speicher.alle('verlaeufe')]).then(function (r) {
      var liste = [{ wert: MM.Reisekasse.BAR, label: 'Bar', eigen: false, ausgeblendet: false }];
      sammle(self, r[0], r[1], 'zahlungsmittel').forEach(function (x) {
        liste.push({ wert: x.objekt.id, label: x.aktuell.werte.bezeichnung, eigen: true, ausgeblendet: x.aktuell.werte.ausgeblendet === 'ja' });
      });
      return liste;
    });
  };

  Daten.prototype.zahlungsmittelAnlegen = function (bezeichnung) {
    var self = this, bez = trimmed2(bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte eine Bezeichnung eingeben, zum Beispiel „Kreditkarte“. Keine Karten- oder Kontonummern.' } });
    if (bez.length > 40) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte höchstens 40 Zeichen.' } });
    return this.zahlungsmittelListe().then(function (liste) {
      if (liste.some(function (z) { return z.label.toLowerCase() === bez.toLowerCase(); })) return { ok: false, fehler: { bezeichnung: 'Dieses Zahlungsmittel gibt es schon.' } };
      return self.mitVerlaufAnlegen('zahlungsmittel', 'zahlungsmittel', 'zm', { bezeichnung: bez, ausgeblendet: 'nein' });
    });
  };

  Daten.prototype.zahlungsmittelAusblenden = function (id, ausblenden) {
    var self = this;
    if (id === MM.Reisekasse.BAR) return Promise.resolve({ ok: false, fehler: { allgemein: '„Bar“ gehört zur Kasse und bleibt immer da.' } });
    return this.mitVerlaufLaden('zahlungsmittel', id, KOSTENART_FELDER).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieses Zahlungsmittel wurde nicht gefunden.' } };
      return self.mitVerlaufAendern('zahlungsmittel', id, x, Object.assign({}, x.aktuell.werte, { ausgeblendet: ausblenden ? 'ja' : 'nein' }), KOSTENART_FELDER);
    });
  };

  /*
   * Prüft einen Posten ganz: Gruppe, Betrag, offene Arten (auch eine neue Art mitten im Formular), Zahlungsmittel (auch ein neues),
   * Währung und Kurs. alt = der bisherige Stand beim Ändern. ctx = gemeinsamer Merker mehrerer Zeilen (neue Arten nur einmal anlegen).
   * Gibt { ok: false, fehler } oder { ok: true, werte, schreiben } (schreiben: nur neue Arten und Zahlungsmittel, für mehrereSpeichern).
   */
  function kostenVollstaendig(self, roh, gruppe, alt, ctx) {
    ctx = ctx || { arten: {}, zm: {} };
    roh = Object.assign({}, roh || {});
    return Promise.all([self.kostenartenListe(), self.zahlungsmittelListe()]).then(function (r) {
      var arten = r[0].map(function (a) { return { wert: a.wert, label: a.label, gruppe: a.gruppe }; }), zms = r[1];
      var g = MM.Kosten.istGruppe(gruppe) ? gruppe : null, jetzt = self.jetzt(), schreiben = [], f0 = {};

      var neueArt = trimmed2(roh.neueKostenart);
      if (neueArt && g) {
        var gl = arten.filter(function (a) { return a.gruppe === g && a.label.toLowerCase() === neueArt.toLowerCase(); })[0];
        if (gl) roh.kostenart = gl.wert;
        else if (neueArt.length > 60) f0.neueKostenart = 'Bitte höchstens 60 Zeichen.';
        else {
          var k1 = g + '|' + neueArt.toLowerCase();
          if (!ctx.arten[k1]) {
            ctx.arten[k1] = neueId('kart');
            schreiben.push({ tabelle: 'kostenarten', objekt: { id: ctx.arten[k1], datenraumId: self.datenraumId, erstelltAm: jetzt } },
              { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kostenart', ctx.arten[k1], 1, { bezeichnung: neueArt, gruppe: g, ausgeblendet: 'nein' }, null, jetzt) });
          }
          roh.kostenart = ctx.arten[k1];
          arten.push({ wert: ctx.arten[k1], label: neueArt, gruppe: g });
        }
      }
      var p = self.pruefenKosten(roh, g, arten);
      var f = Object.assign({}, p.fehler, f0), w = p.werte;
      if (!g) return { ok: false, fehler: f };

      var zid = trimmed2(roh.bezahltMit), neuZm = trimmed2(roh.neuesZahlungsmittel);
      if (neuZm) {
        var gz = zms.filter(function (z) { return z.label.toLowerCase() === neuZm.toLowerCase(); })[0];
        if (gz) zid = gz.wert;
        else if (neuZm.length > 40) f.neuesZahlungsmittel = 'Bitte höchstens 40 Zeichen.';
        else {
          var k2 = neuZm.toLowerCase();
          if (!ctx.zm[k2]) {
            ctx.zm[k2] = neueId('zm');
            schreiben.push({ tabelle: 'zahlungsmittel', objekt: { id: ctx.zm[k2], datenraumId: self.datenraumId, erstelltAm: jetzt } },
              { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('zahlungsmittel', ctx.zm[k2], 1, { bezeichnung: neuZm, ausgeblendet: 'nein' }, null, jetzt) });
          }
          zid = ctx.zm[k2];
          zms.push({ wert: zid, label: neuZm });
        }
      }
      if (zid && !zms.some(function (z) { return z.wert === zid; })) f.bezahltMit = 'Dieses Zahlungsmittel gibt es nicht.';
      w.bezahltMit = zid || null;
      if (Object.keys(f).length) return { ok: false, fehler: f };

      var code = w.waehrung || 'EUR';
      return (w.aktivitaetId ? self.kasseInfo(w.aktivitaetId, code) : Promise.resolve(null)).then(function (ki) {
        if (w.bezahltMit === MM.Reisekasse.BAR && w.aktivitaetId && w.waehrung && !(ki && ki.vorhanden)) {
          return { ok: false, fehler: { bezahltMit: 'Für ' + code + ' gibt es in dieser Aktivität noch keine Kasse. Lege sie zuerst mit dem Anfangsbestand an.' } };
        }
        if (w.waehrung && (w.betrag === null || w.betrag === undefined)) {
          if (alt && alt.waehrung === w.waehrung && Number(alt.betragWaehrung) === w.betragWaehrung && Number(alt.betrag) > 0) {
            w.betrag = alt.betrag; w.grundlage = alt.grundlage || 'gerechnet';
          } else {
            var e = MM.Reisekasse.euroAus(w.betragWaehrung, ki && ki.rechnung ? ki.rechnung.kurs : null);
            if (e === null) return { ok: false, fehler: { betrag: 'Bitte den Betrag in Euro eingeben. Die App kennt noch keinen Kurs für ' + code + ': Er entsteht aus dem Anfangsbestand oder einer Einzahlung der Kasse.' } };
            w.betrag = e; w.grundlage = 'gerechnet';
          }
        }
        return { ok: true, werte: w, schreiben: schreiben };
      });
    });
  }

  /* ---------- Kassen der Reisekasse (seit 2.0.29) ---------- */
  /*
   * Eine Kasse gehört zu einer Aktivität und einer Währung (Tabelle „kassen“, Kennung aus beidem). Ihre Bewegungen stehen in
   * „kassenbuchungen“ (mit Verlauf): Anfangsbestand, Einzahlung (Umbuchung, keine Ausgabe) und Differenz (Kassensturz).
   * Die Ausgaben sind keine eigenen Einträge: Es sind die Posten der Kosten-Liste, die „Bar“ bezahlt wurden. Der Stand wird daraus
   * gerechnet (MM.Reisekasse.rechnen), nie gespeichert. So gibt es nur eine Quelle für jeden Betrag.
   */
  var KASSEN_FELDER = KOSTENART_FELDER;

  function kassenbuchungenSammeln(self, objekte, verlaeufe) {
    var ver = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === 'kassenbuchung') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
    return objekte.filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
      var l = (ver[o.id] || []).slice().sort(nachNr), a = l[l.length - 1];
      return a ? { objekt: o, aktuell: a } : null;
    }).filter(Boolean).sort(function (x, y) {
      var a = (x.aktuell.werte.datum || '') + x.objekt.erstelltAm, b = (y.aktuell.werte.datum || '') + y.objekt.erstelltAm;
      return a < b ? -1 : (a > b ? 1 : 0);
    });
  }

  function kasseRechnung(code, kasseIdent, buchungen, kosten, aktivitaetId) {
    var bu = buchungen.filter(function (b) { return b.objekt.kasseId === kasseIdent; });
    var aus = kosten.filter(function (k) {
      var w = k.aktuell.werte;
      return w.aktivitaetId === aktivitaetId && w.bezahltMit === MM.Reisekasse.BAR && (w.waehrung || 'EUR') === code;
    });
    return { buchungen: bu, ausgaben: aus, rechnung: MM.Reisekasse.rechnen({ waehrung: code,
      buchungen: bu.map(function (b) { return { werte: b.aktuell.werte }; }), ausgaben: aus.map(function (k) { return { werte: k.aktuell.werte }; }) }) };
  }

  function kassenDaten(self, aktivitaetId) {
    return Promise.all([self.speicher.wo('kassen', 'aktivitaetId', aktivitaetId), self.speicher.wo('kassenbuchungen', 'aktivitaetId', aktivitaetId),
      self.speicher.alle('verlaeufe'), kostenAlleSammeln(self)]).then(function (r) {
      return { kassen: r[0].filter(function (k) { return k.datenraumId === self.datenraumId; }), buchungen: kassenbuchungenSammeln(self, r[1], r[2]), kosten: r[3] };
    });
  }

  /* Eine Kasse (Aktivität und Währung): { vorhanden, kasse, waehrung, buchungen, ausgaben, rechnung }. Auch ohne angelegte Kasse (vorhanden false). */
  Daten.prototype.kasseInfo = function (aktivitaetId, waehrung) {
    var self = this, code = waehrung || 'EUR', id = MM.Reisekasse.kasseId(aktivitaetId, code);
    return kassenDaten(this, aktivitaetId).then(function (d) {
      var kasse = d.kassen.filter(function (k) { return k.id === id; })[0] || null;
      var x = kasseRechnung(code, id, d.buchungen, d.kosten, aktivitaetId);
      return { vorhanden: !!kasse, kasse: kasse, waehrung: code, buchungen: x.buchungen, ausgaben: x.ausgaben, rechnung: x.rechnung };
    });
  };

  /* Alle Kassen einer Aktivität, Euro zuerst. */
  Daten.prototype.kassenListe = function (aktivitaetId) {
    return kassenDaten(this, aktivitaetId).then(function (d) {
      return d.kassen.map(function (k) {
        var x = kasseRechnung(k.waehrung, k.id, d.buchungen, d.kosten, aktivitaetId);
        return { kasse: k, waehrung: k.waehrung, buchungen: x.buchungen, ausgaben: x.ausgaben, rechnung: x.rechnung };
      }).sort(function (a, b) { return a.waehrung === 'EUR' ? -1 : (b.waehrung === 'EUR' ? 1 : a.waehrung.localeCompare(b.waehrung)); });
    });
  };

  function kasseKontext(self, aktivitaetId) {
    return self.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (a.aktuell.werte.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      return { aktivitaet: a };
    });
  }

  /* Anfangsbestand oder Einzahlung. roh: art ('anfang' | 'einzahlung'), waehrung (ohne Angabe EUR), betrag, euro (bei Fremdwährung Pflicht), datum, notiz. */
  Daten.prototype.kasseBuchen = function (aktivitaetId, roh) {
    var self = this;
    roh = roh || {};
    var art = trimmed2(roh.art), code = MM.Reisekasse.waehrungNormal(trimmed2(roh.waehrung) || 'EUR'), f = {};
    if (art !== 'anfang' && art !== 'einzahlung') f.art = 'Bitte wählen: Anfangsbestand oder Einzahlung.';
    if (!code) f.waehrung = 'Bitte ein Währungskürzel mit drei Buchstaben eingeben, zum Beispiel NOK.';
    var p = pruefeWerte(MM.Reisekasse.buchungsFelder(art || 'anfang', code || 'EUR'), Object.assign({}, roh, { betrag: geldRoh(roh.betrag), euro: geldRoh(roh.euro) }), jahrVon(this), { ohneBezeichnung: true });
    Object.keys(p.fehler).forEach(function (k) { f[k] = p.fehler[k]; });
    var w = p.werte;
    if (!f.betrag) { if (!(w.betrag > 0)) f.betrag = 'Bitte einen Betrag größer als 0 eingeben.'; else if (w.betrag > 1000000000) f.betrag = 'Der Betrag ist zu groß.'; }
    if (code && code !== 'EUR') {
      if (!f.euro) { if (!(w.euro > 0)) f.euro = 'Bitte eingeben, wie viel Euro du dafür bezahlt hast. Daraus rechnet die App den Kurs.'; }
    }
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return kasseKontext(this, aktivitaetId).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      return self.kasseInfo(aktivitaetId, code).then(function (ki) {
        if (art === 'anfang' && ki.buchungen.some(function (b) { return b.aktuell.werte.art === 'anfang' && b.aktuell.werte.ausgeblendet !== 'ja'; })) {
          return { ok: false, fehler: { art: 'Der Anfangsbestand ist schon eingetragen. Geld, das du dazu holst, trägst du als Einzahlung ein.' } };
        }
        var jetzt = self.jetzt(), id = MM.Reisekasse.kasseId(aktivitaetId, code), liste = [];
        if (!ki.vorhanden) liste.push({ tabelle: 'kassen', objekt: { id: id, datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, fahrzeugId: k.aktivitaet.fahrzeug.id, waehrung: code, erstelltAm: jetzt } });
        var b = { id: neueId('kb'), datenraumId: self.datenraumId, kasseId: id, aktivitaetId: aktivitaetId, erstelltAm: jetzt };
        var werte = { art: art, betrag: MM.Reisekasse.runde(w.betrag), euro: code === 'EUR' ? null : MM.Reisekasse.runde(w.euro), waehrung: code,
          datum: w.datum || self.heute(), notiz: w.notiz || null, ausgeblendet: 'nein' };
        liste.push({ tabelle: 'kassenbuchungen', objekt: b }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kassenbuchung', b.id, 1, werte, null, jetzt) });
        return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: b.id, kasseId: id }; });
      });
    });
  };

  /* Kassensturz: roh.ist = was wirklich im Portemonnaie liegt. Weicht es vom Stand ab, speichert die App die Differenz als eigenen Eintrag. */
  Daten.prototype.kassensturz = function (aktivitaetId, roh) {
    var self = this;
    roh = roh || {};
    var code = MM.Reisekasse.waehrungNormal(trimmed2(roh.waehrung) || 'EUR');
    if (!code) return Promise.resolve({ ok: false, fehler: { waehrung: 'Bitte ein Währungskürzel mit drei Buchstaben eingeben, zum Beispiel NOK.' } });
    var p = pruefeWerte([{ key: 'ist', typ: 'zahl' }, { key: 'datum', typ: 'datum' }, { key: 'notiz', typ: 'text' }], Object.assign({}, roh, { ist: geldRoh(roh.ist) }), jahrVon(this), { ohneBezeichnung: true });
    var f = Object.assign({}, p.fehler);
    if (!f.ist && p.werte.ist === null) f.ist = 'Bitte eingeben, wie viel Geld in der Kasse liegt (auch 0 ist möglich).';
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return kasseKontext(this, aktivitaetId).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      return self.kasseInfo(aktivitaetId, code).then(function (ki) {
        if (!ki.vorhanden) return { ok: false, fehler: { waehrung: 'Für ' + code + ' gibt es noch keine Kasse. Lege sie zuerst mit dem Anfangsbestand an.' } };
        var diff = MM.Reisekasse.kassensturzDifferenz(ki.rechnung, p.werte.ist);
        if (diff === 0) return { ok: true, differenz: 0, geaendert: false, stand: ki.rechnung.stand };
        var jetzt = self.jetzt(), b = { id: neueId('kb'), datenraumId: self.datenraumId, kasseId: ki.kasse.id, aktivitaetId: aktivitaetId, erstelltAm: jetzt };
        var werte = { art: 'differenz', betrag: diff, euro: null, waehrung: code, datum: p.werte.datum || self.heute(), notiz: p.werte.notiz || null, ausgeblendet: 'nein' };
        return self.speicher.mehrereSpeichern([{ tabelle: 'kassenbuchungen', objekt: b },
          { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kassenbuchung', b.id, 1, werte, null, jetzt) }])
          .then(function () { return { ok: true, id: b.id, differenz: diff, geaendert: true, stand: MM.Reisekasse.runde(p.werte.ist) }; });
      });
    });
  };

  /* Eine Buchung ausblenden (zählt nicht mehr) oder wieder einblenden. Nichts wird gelöscht; eine falsche Buchung blendest du aus und trägst sie neu ein. */
  Daten.prototype.kasseBuchungAusblenden = function (buchungId, ausblenden) {
    var self = this;
    return this.mitVerlaufLaden('kassenbuchungen', buchungId, KASSEN_FELDER).then(function (x) {
      if (!x || x.objekt.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Diese Buchung wurde nicht gefunden.' } };
      return self.mitVerlaufAendern('kassenbuchung', buchungId, x, Object.assign({}, x.aktuell.werte, { ausgeblendet: ausblenden ? 'ja' : 'nein' }), KASSEN_FELDER);
    });
  };

  /* Eine Ausgabe der Reisekasse: wie kostenAnlegen, aber mit der Aktivität statt des Fahrzeugs. */
  Daten.prototype.reiseAusgabeAnlegen = function (aktivitaetId, roh) {
    var self = this;
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      return self.kostenAnlegen(a.fahrzeug.id, Object.assign({}, roh || {}, { gruppe: 'reisekasse', aktivitaetId: aktivitaetId }));
    });
  };

  /* ---------- Kostenstammdaten eines Fahrzeugs: Wert, Wertverlust, Vergleichspreis ---------- */
  function kostenstammId(fahrzeugId) { return 'ks-' + fahrzeugId; }

  Daten.prototype.kostenstammLaden = function (fahrzeugId) {
    return this.mitVerlaufLaden('kostenstamm', kostenstammId(fahrzeugId), MM.Kosten.stammFelder());
  };

  Daten.prototype.pruefenKostenstamm = function (roh) {
    roh = Object.assign({}, roh || {});
    roh.fahrzeugwert = geldRoh(roh.fahrzeugwert); roh.vergleichPreisTag = geldRoh(roh.vergleichPreisTag);
    var p = pruefeWerte(MM.Kosten.stammFelder(), roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler, heute = this.heute();
    if (w.fahrzeugwert !== null && !f.fahrzeugwert) {
      if (!(w.fahrzeugwert > 0)) f.fahrzeugwert = 'Der Wert muss größer als 0 sein.';
      else if (w.fahrzeugwert > 1000000000) f.fahrzeugwert = 'Der Wert ist zu groß.';
      else w.fahrzeugwert = MM.Kosten.runde(w.fahrzeugwert);
    }
    if (w.fahrzeugwert && !w.wertDatum && !f.wertDatum) w.wertDatum = heute;
    if (w.wertDatum && w.wertDatum > heute && !f.wertDatum) f.wertDatum = 'Das Datum liegt in der Zukunft.';
    if (w.wertverlustProzent !== null && !f.wertverlustProzent && !w.fahrzeugwert && !f.fahrzeugwert) f.fahrzeugwert = 'Für einen Wertverlust braucht die App den Wert des Fahrzeugs.';
    if (w.vergleichPreisTag !== null && !f.vergleichPreisTag) {
      if (!(w.vergleichPreisTag > 0)) f.vergleichPreisTag = 'Der Preis muss größer als 0 sein.';
      else if (w.vergleichPreisTag > 1000000) f.vergleichPreisTag = 'Der Preis ist zu groß.';
      else w.vergleichPreisTag = MM.Kosten.runde(w.vergleichPreisTag);
    }
    if (w.vergleichPreisTag === null) { w.vergleichGrundlage = null; }
    else if (!w.vergleichGrundlage && !f.vergleichGrundlage) w.vergleichGrundlage = 'geschaetzt';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.kostenstammSetzen = function (fahrzeugId, roh) {
    var self = this;
    var p = this.pruefenKostenstamm(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.pruefeObjekt(fahrzeugId, null).then(function (f) {
      if (f) return { ok: false, fehler: f };
      return self.kostenstammLaden(fahrzeugId).then(function (x) {
        if (x) return self.mitVerlaufAendern('kostenstamm', kostenstammId(fahrzeugId), x, p.werte, MM.Kosten.stammFelder());
        var jetzt = self.jetzt();
        var o = { id: kostenstammId(fahrzeugId), datenraumId: self.datenraumId, fahrzeugId: fahrzeugId, erstelltAm: jetzt };
        return self.speicher.mehrereSpeichern([
          { tabelle: 'kostenstamm', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kostenstamm', o.id, 1, p.werte, null, jetzt) }
        ]).then(function () { return { ok: true, id: o.id, geaendert: true }; });
      });
    });
  };

  /* „Der Wert stimmt noch“: der Stand des Werts wird auf heute gesetzt, der Wert bleibt. */
  Daten.prototype.kostenstammWertBestaetigen = function (fahrzeugId) {
    var self = this;
    return this.kostenstammLaden(fahrzeugId).then(function (x) {
      if (!x || !(Number(x.aktuell.werte.fahrzeugwert) > 0)) return { ok: false, fehler: { allgemein: 'Es ist noch kein Wert eingetragen.' } };
      var w = Object.assign({}, x.aktuell.werte, { wertDatum: self.heute() });
      return self.mitVerlaufAendern('kostenstamm', kostenstammId(fahrzeugId), x, w, MM.Kosten.stammFelder());
    });
  };

  /* ---------- Kosten: Auswertung ---------- */
  function jahrGueltig(jahr, standard) {
    var j = Number(jahr);
    return isFinite(j) && Math.floor(j) === j && j >= 1900 && j <= 2200 ? j : standard;
  }

  /*
   * Die Auswertung eines Fahrzeugs für ein Jahr (ohne Angabe: dieses Jahr). Rechnung steht in MM.Kosten.auswertung.
   * Dazu die Posten, nach Gruppen geordnet: posten.<gruppe> = die Posten, die im Jahr etwas zählen (mit imJahr),
   * andere = sichtbare Posten ohne Anteil in diesem Jahr, ausgeblendet = ausgeblendete Posten.
   */
  Daten.prototype.kostenAuswertung = function (fahrzeugId, jahr) {
    var self = this;
    var heute = this.heute();
    var j = jahrGueltig(jahr, +heute.slice(0, 4));
    return Promise.all([this.fahrzeugLaden(fahrzeugId), this.kostenListe(fahrzeugId), this.kostenstammLaden(fahrzeugId),
      this.aktivitaetenListe(), this.zaehlerListe(fahrzeugId), this.speicher.alle('zaehlerstaende')]).then(function (r) {
      if (!r[0]) return null;
      var liste = r[1], stamm = r[2];
      var sichtbar = liste.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; });
      var aktivitaeten = r[3].filter(function (a) { return a.aktuell.werte.fahrzeugId === fahrzeugId && a.status !== 'storniert'; })
        .map(function (a) { return { vonDatum: a.aktuell.werte.vonDatum, bisDatum: a.aktuell.werte.bisDatum }; });
      var km = r[4].filter(function (z) { return z.art === 'strecke' && !z.komponenteId; });
      var zaehler = km.length ? km[0] : null;
      var staende = zaehler ? r[5].filter(function (s) { return s.zaehlerId === zaehler.zaehler.id; }).map(function (s) { return { datum: s.datum, wert: s.wert }; }) : [];
      var a = MM.Kosten.auswertung({ jahr: j, heute: heute, eintraege: sichtbar.map(function (x) { return { werte: x.aktuell.werte }; }),
        stamm: stamm ? stamm.aktuell.werte : null, aktivitaeten: aktivitaeten, staende: staende });
      var posten = { fix: [], variabel: [], instandhaltung: [] }, ohneAnteil = { fix: [], variabel: [], instandhaltung: [] }, andere = [];
      sichtbar.forEach(function (x) {
        if (x.aktuell.werte.gruppe === 'reisekasse') return; /* die Reisekasse gehört zur Aktivität, nicht zu den Fahrzeugkosten */
        var y = Object.assign({}, x, { imJahr: MM.Kosten.imJahr(x.aktuell.werte, j, heute) });
        if (y.imJahr.summe > 0 && posten[x.aktuell.werte.gruppe]) posten[x.aktuell.werte.gruppe].push(y);
        else {
          /* Seit 2.0.63 bleibt ein Posten ohne Anteil in seiner Gruppe sichtbar, mit dem Grund (ohneAnteil). andere bleibt die Liste aller Posten ohne Anteil. */
          y.keinAnteil = { jahr: j, grund: MM.Kosten.keinAnteilGrund(x.aktuell.werte, j, heute) };
          if (ohneAnteil[x.aktuell.werte.gruppe]) ohneAnteil[x.aktuell.werte.gruppe].push(y);
          andere.push(y);
        }
      });
      a.ok = true;
      a.fahrzeug = r[0].fahrzeug; a.fahrzeugAktuell = r[0].aktuell;
      a.stamm = stamm; a.posten = posten; a.ohneAnteil = ohneAnteil; a.andere = andere;
      a.ausgeblendet = liste.filter(function (x) { return x.aktuell.werte.ausgeblendet === 'ja' && x.aktuell.werte.gruppe !== 'reisekasse'; });
      a.kmZaehler = zaehler ? zaehler.bezeichnung : null;
      a.heute = heute;
      return a;
    });
  };

  /* Pro Fahrzeug die Auswertung des Jahres, für die Kostenstartseite. */
  Daten.prototype.kostenUebersicht = function (jahr) {
    var self = this;
    return this.fahrzeugListe({ alle: true }).then(function (liste) {
      return Promise.all(liste.map(function (x) { return self.kostenAuswertung(x.fahrzeug.id, jahr); })).then(function (alle) {
        return liste.map(function (x, i) { return { fahrzeug: x.fahrzeug, aktuell: x.aktuell, auswertung: alle[i] }; });
      });
    });
  };

  /* ---------- Besuche und Reiseorte (seit 2.0.28) ---------- */
  /*
   * Ein Besuch ist die Antwort auf die freiwillige Abfrage nach einer Ankunft (oder von Hand nachgetragen). Tabelle „besuche“
   * (Index aktivitaetId, ereignisId), Angaben im Verlauf. Das Objekt hält, was sich nie ändert: Aktivität, Fahrzeug, Ereignis.
   * Ort, Standort, Datum, Ausstattung beim Besuch und Notiz stehen im Verlauf. Status „besucht“ zählt, „uebersprungen“ heißt:
   * Der Nutzer wollte nichts festhalten, die Frage kommt für dieses Ereignis nicht wieder.
   * Die Kosten eines Besuchs stehen nur in der Kosten-Liste (variable Kosten mit ortId, aktivitaetId und besuchId).
   * Die Ausstattung gehört zum Ort (die eine Quelle). Der Besuch hält nur, was beim Besuch gesagt wurde.
   * Hier und in js/reiseorte.js steht, was später teilbar wäre (Ort, Art, Position, Ausstattung): Nichts wird veröffentlicht. */
  function planAus(w) {
    return { startOrtId: (w && w.startOrtId) || null, zielOrtId: (w && w.zielOrtId) || null, zwischenzielIds: (w && w.zwischenzielIds) || [] };
  }

  /* Alle Posten der Kosten-Liste mit aktuellem Stand (alle Fahrzeuge). */
  function kostenAlleSammeln(self) {
    return Promise.all([self.speicher.alle('kosten'), self.speicher.alle('verlaeufe')]).then(function (r) {
      var ver = {};
      r[1].forEach(function (e) { if (e.objektTyp === 'kosten') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      return r[0].filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
        var l = (ver[o.id] || []).slice().sort(nachNr), a = l[l.length - 1];
        return a ? { objekt: o, aktuell: a } : null;
      }).filter(Boolean);
    });
  }

  /* Alle Besuche mit aktuellem Stand, nach Aktivität gefiltert, wenn eine genannt ist. */
  function besucheAlleSammeln(self, aktivitaetId) {
    var quelle = aktivitaetId ? self.speicher.wo('besuche', 'aktivitaetId', aktivitaetId) : self.speicher.alle('besuche');
    return Promise.all([quelle, self.speicher.alle('verlaeufe')]).then(function (r) {
      var ver = {};
      r[1].forEach(function (e) { if (e.objektTyp === 'besuch') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      return r[0].filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
        var l = (ver[o.id] || []).slice().sort(nachNr), a = l[l.length - 1];
        return a ? { objekt: o, aktuell: a } : null;
      }).filter(Boolean);
    });
  }

  /* Dauer der Aufenthalte (seit 2.0.58): zu jedem Besuch mit Ankunft die Dauer bis zur nächsten Abfahrt aus dem Logbuch. Nichts wird gespeichert,
   * die Zahl wird bei jedem Zeichnen aus den Ereignissen abgeleitet (auch für Besuche von früher). Ergebnis: { besuchId: aufenthalt oder null }. */
  function aufenthalteZuBesuchen(self, besuche) {
    var ids = [], proAkt = {};
    (besuche || []).forEach(function (b) {
      if (!b || !b.objekt || !b.objekt.ereignisId || !b.aktuell || b.aktuell.werte.status !== 'besucht') return;
      if (ids.indexOf(b.objekt.aktivitaetId) < 0) ids.push(b.objekt.aktivitaetId);
    });
    return Promise.all(ids.map(function (aid) {
      return self.logbuchLaden(aid).then(function (lb) {
        var liste = [];
        if (lb) lb.abschnitte.forEach(function (x) {
          if (x.ausgeblendet) return;
          x.ereignisse.forEach(function (e) { if (e.art === 'ereignis' && !e.ausgeblendet) liste.push({ id: e.id, artName: e.artName, zeitpunkt: e.zeitpunkt, datum: e.datum, zeit: e.zeit, ausgeblendet: false }); });
        });
        proAkt[aid] = liste;
      });
    })).then(function () {
      var aus = {};
      (besuche || []).forEach(function (b) {
        if (!b || !b.objekt || !b.objekt.ereignisId || !proAkt[b.objekt.aktivitaetId]) return;
        aus[b.objekt.id] = MM.Reiseorte.aufenthalt(proAkt[b.objekt.aktivitaetId], b.objekt.ereignisId);
      });
      return aus;
    });
  }
  Daten.prototype.aufenthalteZuBesuchen = function (besuche) { return aufenthalteZuBesuchen(this, besuche); };

  function besuchSchluessel(x) { var w = x.aktuell.werte; return (w.datum || '') + 'T' + (w.zeit || '00:00'); }

  /* Ein Ereignis in Kurzform: { id, aktivitaetId, artName, datum, zeit, breite, laenge, ortName, ausgeblendet } oder null. */
  Daten.prototype.ereignisKurz = function (ereignisId) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('ereignisse', ereignisId, []), this.ereignisartenListe()]).then(function (r) {
      var x = r[0];
      if (!x || x.objekt.datenraumId !== self.datenraumId) return null;
      var w = x.aktuell.werte, art = r[1].filter(function (a) { return a.objekt.id === w.artId; })[0];
      return { id: x.objekt.id, aktivitaetId: x.objekt.aktivitaetId, artName: art ? art.aktuell.werte.bezeichnung : 'unbekannt', datum: w.datum || null, zeit: w.zeit || null,
        breite: typeof w.breite === 'number' ? w.breite : null, laenge: typeof w.laenge === 'number' ? w.laenge : null, ortName: w.ortName || null, ausgeblendet: w.ausgeblendet === 'ja' };
    });
  };

  /*
   * Alles, was das Formular und die Prüfung brauchen: die Aktivität, ihr Plan, das Ereignis (mit Position), die Orte und
   * Standorte, ein Vorschlag aus der Position und der zuletzt bezahlte Preis je Ort.
   * Ergebnis: { ok, aktivitaet, plan, ereignis, orte, standorte, vorschlag, preise, besuchVorhanden }
   */
  Daten.prototype.besuchKontext = function (aktivitaetId, ereignisId) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.orteListe(), this.standorteListe(),
      ereignisId ? this.ereignisKurz(ereignisId) : Promise.resolve(null), this.speicher.wo('besuche', 'aktivitaetId', aktivitaetId), kostenAlleSammeln(this)]).then(function (r) {
      var a = r[0], e = r[3];
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (ereignisId && (!e || e.aktivitaetId !== aktivitaetId)) return { ok: false, fehler: { allgemein: 'Dieses Ereignis gehört nicht zu dieser Aktivität.' } };
      var vorhanden = ereignisId ? r[4].filter(function (b) { return b.ereignisId === ereignisId; })[0] : null;
      var preise = {};
      r[5].filter(function (k) { return k.aktuell.werte.ortId && k.aktuell.werte.ausgeblendet !== 'ja' && Number(k.aktuell.werte.betrag) > 0; })
        .sort(function (x, y) { return (x.aktuell.werte.datum || '') < (y.aktuell.werte.datum || '') ? -1 : 1; })
        .forEach(function (k) { preise[k.aktuell.werte.ortId] = { betrag: Number(k.aktuell.werte.betrag), datum: k.aktuell.werte.datum || null, grundlage: k.aktuell.werte.grundlage || 'eingegeben' }; });
      return { ok: true, aktivitaet: a, plan: planAus(a.aktuell.werte), ereignis: e, orte: r[1], standorte: r[2], preise: preise,
        vorschlag: e ? MM.Reiseorte.naechster(MM.Reiseorte.kandidaten(r[1], r[2]), e.breite, e.laenge) : null, besuchVorhanden: vorhanden ? vorhanden.id : null };
    });
  };

  /* Prüft die Angaben zu einem Besuch (ohne Ort und Kosten). Ohne Angabe bleibt ein Feld leer. */
  Daten.prototype.pruefenBesuch = function (roh) {
    roh = roh || {};
    var felder = [
      { key: 'datum', typ: 'datum' }, { key: 'zeit', typ: 'zeit' },
      { key: 'ausstattung', typ: 'mehrfach', optionen: MM.Orte.AUSSTATTUNG },
      { key: 'ausstattungSonst', typ: 'text', maxLaenge: 200 },
      { key: 'notiz', typ: 'text' },
      { key: 'landstrom', typ: 'auswahl', optionen: [{ wert: 'ja', label: 'Ja' }, { wert: 'nein', label: 'Nein' }] },
      { key: 'landstromAutomat', typ: 'auswahl', optionen: MM.Reiseorte.LANDSTROM_AUTOMAT },
      { key: 'landstromMenge', typ: 'zahl', max: 100000 }
    ];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    /* Landstrom (seit 2.0.59): Die Angaben zum Automaten gelten nur mit Haken. Eine Menge braucht die Art des Automaten. */
    if (p.werte.landstrom !== 'ja') { p.werte.landstromAutomat = null; p.werte.landstromMenge = null; delete p.fehler.landstromAutomat; delete p.fehler.landstromMenge; }
    else if (p.werte.landstromMenge !== null && p.werte.landstromMenge !== undefined && !p.werte.landstromAutomat && !p.fehler.landstromMenge) p.fehler.landstromAutomat = 'Bitte wählen, ob der Automat Zeit oder Strom (kWh) verkauft.';
    p.ok = Object.keys(p.fehler).length === 0;
    if (p.werte.datum && p.werte.datum > this.heute() && !p.fehler.datum) { p.fehler.datum = 'Ein Besuch liegt nicht in der Zukunft.'; p.ok = false; }
    return p;
  };

  /*
   * Einen Besuch festhalten. roh:
   *   ereignisId (freiwillig: das Ereignis der Ankunft), datum, zeit (ohne Angabe die des Ereignisses, sonst heute),
   *   ortId (vorhandener Ort) ODER neuerOrtName (mit neuerOrtArt, positionBreite, positionLaenge, sonst die Position des Ereignisses),
   *   standortId (freiwillig, nur bei vorhandenem Ort), ausstattung (Liste) und ausstattungSonst (werden auch am Ort gemerkt),
   *   notiz, betrag (freiwillig, dann entsteht ein variabler Posten), kostenart, grundlage, kostenBezeichnung.
   * Alles wird in einem Zug gespeichert, ganz oder gar nicht: neuer Ort, Besuch, Ausstattung am Ort, Posten.
   * Kennt der Ort noch keine Position und das Ereignis hat eine, bekommt der Ort sie.
   */
  Daten.prototype.besuchAnlegen = function (aktivitaetId, roh) {
    var self = this;
    roh = roh || {};
    var ereignisId = trimmed2(roh.ereignisId) || null;
    return this.besuchKontext(aktivitaetId, ereignisId).then(function (k) {
      if (!k.ok) return k;
      var a = k.aktivitaet;
      if (a.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      if (k.besuchVorhanden) return { ok: false, fehler: { allgemein: 'Zu dieser Ankunft gibt es schon einen Besuch.' } };
      var e = k.ereignis;
      var eingabe = Object.assign({}, roh);
      if (!trimmed2(eingabe.datum)) eingabe.datum = e && e.datum ? e.datum : self.heute();
      if (!trimmed2(eingabe.zeit) && e && e.zeit) eingabe.zeit = e.zeit;
      var p = self.pruefenBesuch(eingabe), w = p.werte, f = p.fehler;

      /* Ort */
      var ortId = trimmed2(roh.ortId), neuerName = trimmed2(roh.neuerOrtName), ort = null, neuerOrt = null;
      if (ortId) {
        ort = k.orte.filter(function (o) { return o.objekt.id === ortId; })[0] || null;
        if (!ort) f.ortId = 'Diesen Ort gibt es nicht.';
      } else if (neuerName) {
        var po = self.pruefenOrt({ bezeichnung: neuerName, ortart: roh.neuerOrtArt,
          positionBreite: roh.positionBreite !== undefined ? roh.positionBreite : (e ? e.breite : null),
          positionLaenge: roh.positionLaenge !== undefined ? roh.positionLaenge : (e ? e.laenge : null),
          ausstattung: Array.isArray(roh.ausstattung) ? roh.ausstattung : [], ausstattungSonst: roh.ausstattungSonst });
        var abbild = { bezeichnung: 'neuerOrtName', ortart: 'neuerOrtArt' };
        Object.keys(po.fehler).forEach(function (key) { f[abbild[key] || key] = po.fehler[key]; });
        if (gleicherName(k.orte, neuerName)) f.neuerOrtName = 'Diesen Ort gibt es schon. Wähle ihn oben aus der Liste.';
        if (!f.neuerOrtName || !Object.keys(po.fehler).length) neuerOrt = { id: neueId('or'), werte: po.werte };
      } else f.ortId = 'Bitte einen Ort wählen oder einen neuen Namen eingeben.';

      /* Standort */
      var standortId = trimmed2(roh.standortId) || null;
      if (standortId) {
        if (!ort) f.standortId = 'Ein Standort gehört zu einem schon vorhandenen Ort.';
        else if (!k.standorte.some(function (s) { return s.objekt.id === standortId && s.objekt.ortId === ort.objekt.id; })) f.standortId = 'Diesen Standort gibt es an diesem Ort nicht.';
      }

      /* Kosten: mehrere Zeilen je Besuch (seit 2.0.29, roh.zeilen: Art, Betrag) oder wie bisher ein Betrag. Jede Zeile wird ein eigener Posten. */
      var ortName = ort ? ort.aktuell.werte.bezeichnung : neuerName;
      var zz = besuchZeilen(roh, ortName), ctx = { arten: {}, zm: {} }, ergebnisse = [];
      /* Der Betrag am Automaten (seit 2.0.59) wird eine eigene Kostenzeile „Landstrom“, Art Stromzuschlag. */
      if (w.landstrom === 'ja' && trimmed2(roh.landstromBetrag == null ? '' : String(roh.landstromBetrag))) {
        zz.zeilen.push({ nr: 0, landstrom: true, roh: { bezeichnung: 'Landstrom', kostenart: 'strom', neueKostenart: '', betrag: roh.landstromBetrag } });
      }
      var kette = zz.zeilen.reduce(function (kk, z) {
        return kk.then(function () {
          return kostenVollstaendig(self, Object.assign({}, z.roh, { datum: w.datum, aktivitaetId: aktivitaetId, grundlage: roh.grundlage, bezahltMit: roh.bezahltMit,
            neuesZahlungsmittel: roh.neuesZahlungsmittel, waehrung: roh.waehrung,
            betrag: MM.Reisekasse.waehrungNormal(roh.waehrung) && MM.Reisekasse.waehrungNormal(roh.waehrung) !== 'EUR' ? '' : z.roh.betrag,
            betragWaehrung: z.roh.betrag }), 'variabel', null, ctx).then(function (e) { ergebnisse.push(e); });
        });
      }, Promise.resolve());
      return kette.then(function () {
        ergebnisse.forEach(function (e, i) {
          if (e.ok) return;
          Object.keys(e.fehler).forEach(function (key) {
            if (key === 'bezahltMit' || key === 'waehrung' || key === 'neuesZahlungsmittel') { f[key] = e.fehler[key]; return; }
            if (zz.zeilen[i].landstrom) { if (!f.landstromBetrag) f.landstromBetrag = e.fehler[key]; return; }
            if (!zz.neu) { f[key === 'bezeichnung' ? 'kostenBezeichnung' : key] = e.fehler[key]; return; }
            if (!f.zeilen) f.zeilen = 'Zeile ' + zz.zeilen[i].nr + ': ' + e.fehler[key];
          });
        });
        if (Object.keys(f).length) return { ok: false, fehler: f };

        var jetzt = self.jetzt(), fahrzeugId = a.fahrzeug.id;
        var endOrtId = ort ? ort.objekt.id : neuerOrt.id;
        var sendetAusstattung = Array.isArray(roh.ausstattung), sendetSonst = roh.ausstattungSonst !== undefined;
        var ausstattung = sendetAusstattung ? w.ausstattung : (ort ? (ort.aktuell.werte.ausstattung || []) : []);
        var sonst = sendetSonst ? w.ausstattungSonst : (ort ? (ort.aktuell.werte.ausstattungSonst || null) : null);
        var geplant = MM.Reiseorte.planVergleich(k.plan, endOrtId);
        var batch = [];

        if (neuerOrt) {
          batch.push({ tabelle: 'orte', objekt: { id: neuerOrt.id, datenraumId: self.datenraumId, erstelltAm: jetzt } },
            { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ort', neuerOrt.id, 1, neuerOrt.werte, null, jetzt) });
        } else {
          /* Die Angaben des Besuchs gelten auch am Ort (er ist die eine Quelle), und ein Ort ohne Position bekommt die der Ankunft. */
          var alt = ort.aktuell.werte, neu = Object.assign({}, alt, { ausstattung: ausstattung, ausstattungSonst: sonst });
          if (typeof alt.positionBreite !== 'number' && e && typeof e.breite === 'number' && typeof e.laenge === 'number') { neu.positionBreite = e.breite; neu.positionLaenge = e.laenge; }
          if (unterschiedeFelder(ORT_FELDER, alt, neu).length) batch.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ort', ort.objekt.id, ort.aktuell.nr + 1, neu, ort.aktuell.id, jetzt) });
        }

        var besuch = { id: neueId('bs'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, fahrzeugId: fahrzeugId, ereignisId: ereignisId, erstelltAm: jetzt };
        var besuchWerte = { status: 'besucht', ortId: endOrtId, standortId: standortId, datum: w.datum, zeit: w.zeit || null, geplant: geplant,
          ausstattung: ausstattung, ausstattungSonst: sonst, notiz: w.notiz || null, ausgeblendet: 'nein' };
        if (w.landstrom === 'ja') { besuchWerte.landstrom = 'ja'; besuchWerte.landstromAutomat = w.landstromAutomat || null; besuchWerte.landstromMenge = typeof w.landstromMenge === 'number' ? w.landstromMenge : null; }
        batch.push({ tabelle: 'besuche', objekt: besuch }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besuch', besuch.id, 1, besuchWerte, null, jetzt) });

        var kostenIds = [];
        ergebnisse.forEach(function (er) {
          er.schreiben.forEach(function (x) { batch.push(x); });
          var kw = er.werte;
          kw.ortId = endOrtId; kw.besuchId = besuch.id; kw.aktivitaetId = aktivitaetId;
          var ko = { id: neueId('ko'), datenraumId: self.datenraumId, fahrzeugId: fahrzeugId, erstelltAm: jetzt };
          kostenIds.push(ko.id);
          batch.push({ tabelle: 'kosten', objekt: ko }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('kosten', ko.id, 1, kw, null, jetzt) });
        });
        return self.speicher.mehrereSpeichern(batch).then(function () {
          return { ok: true, id: besuch.id, ortId: endOrtId, kostenId: kostenIds[0] || null, kostenIds: kostenIds, geplant: geplant, neuerOrt: !!neuerOrt };
        });
      });
    });
  };

  /* Die Kostenzeilen eines Besuchs: roh.zeilen (jede mit Betrag, Art oder neuer Art, freiwillig Bezeichnung) oder der eine Betrag von früher. */
  function besuchZeilen(roh, ortName) {
    var out = [];
    if (Array.isArray(roh.zeilen)) {
      roh.zeilen.forEach(function (z, i) {
        z = z || {};
        var b = trimmed2(z.betrag == null ? '' : String(z.betrag)), art = trimmed2(z.kostenart), neu = trimmed2(z.neueKostenart);
        if (!b && !art && !neu) return;
        out.push({ nr: i + 1, roh: { bezeichnung: trimmed2(z.bezeichnung) || ortName, kostenart: art, neueKostenart: neu, betrag: z.betrag } });
      });
      return { zeilen: out, neu: true };
    }
    var b0 = roh.betrag === undefined || roh.betrag === null ? '' : String(roh.betrag).trim();
    if (b0) out.push({ nr: 1, roh: { bezeichnung: trimmed2(roh.kostenBezeichnung) || ortName, kostenart: roh.kostenart || 'unterwegs', betrag: roh.betrag } });
    return { zeilen: out, neu: false };
  }

  /* „Nicht jetzt“: Die Frage zu dieser Ankunft kommt nicht wieder. Es wird nichts festgehalten und nichts gezählt. */
  Daten.prototype.besuchUeberspringen = function (aktivitaetId, ereignisId) {
    var self = this;
    return this.besuchKontext(aktivitaetId, ereignisId).then(function (k) {
      if (!k.ok) return k;
      if (!k.ereignis) return { ok: false, fehler: { allgemein: 'Es fehlt das Ereignis, zu dem die Frage gehört.' } };
      if (k.besuchVorhanden) return { ok: true, id: k.besuchVorhanden, geaendert: false };
      var jetzt = self.jetzt();
      var b = { id: neueId('bs'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, fahrzeugId: k.aktivitaet.fahrzeug.id, ereignisId: ereignisId, erstelltAm: jetzt };
      var w = { status: 'uebersprungen', ortId: null, standortId: null, datum: k.ereignis.datum, zeit: k.ereignis.zeit, geplant: null, ausstattung: [], ausstattungSonst: null, notiz: null, ausgeblendet: 'nein' };
      return self.speicher.mehrereSpeichern([{ tabelle: 'besuche', objekt: b }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besuch', b.id, 1, w, null, jetzt) }])
        .then(function () { return { ok: true, id: b.id, geaendert: true }; });
    });
  };

  /* Ein Besuch mit Verlauf (Orte und Standorte mit Namen), seinem Ort, seiner Aktivität und den Posten, die zu ihm gehören. */
  Daten.prototype.besuchLaden = function (id) {
    var self = this;
    return this.speicher.holen('besuche', id).then(function (o) {
      if (!o || o.datenraumId !== self.datenraumId) return null;
      return Promise.all([self.speicher.wo('verlaeufe', 'objektId', id), self.orteListe(), self.standorteListe(), self.aktivitaetLaden(o.aktivitaetId),
        self.kostenListe(o.fahrzeugId), self.fahrzeugLaden(o.fahrzeugId)]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length) return null;
        var aktuell = eintraege[eintraege.length - 1], w = aktuell.werte;
        var orte = {}; r[1].forEach(function (x) { orte[x.objekt.id] = x; });
        var standorte = {}; r[2].forEach(function (x) { standorte[x.objekt.id] = x; });
        var felder = MM.Reiseorte.besuchFelder().map(function (f) {
          if (f.key === 'ortId') return Object.assign({}, f, { optionen: r[1].map(function (x) { return { wert: x.objekt.id, label: x.aktuell.werte.bezeichnung }; }) });
          if (f.key === 'standortId') return Object.assign({}, f, { optionen: r[2].map(function (x) { return { wert: x.objekt.id, label: (orte[x.objekt.ortId] ? orte[x.objekt.ortId].aktuell.werte.bezeichnung + ', ' : '') + x.aktuell.werte.bezeichnung }; }) });
          return f;
        });
        var ort = w.ortId && orte[w.ortId] ? orte[w.ortId] : null, st = w.standortId && standorte[w.standortId] ? standorte[w.standortId] : null;
        var res = { objekt: o, aktuell: aktuell, verlauf: verlaufAus(eintraege, felder),
          ort: w.ortId ? { id: w.ortId, name: ort ? ort.aktuell.werte.bezeichnung : 'unbekannt', werte: ort ? ort.aktuell.werte : null } : null,
          standort: w.standortId ? { id: w.standortId, name: st ? st.aktuell.werte.bezeichnung : 'unbekannt' } : null,
          aktivitaet: r[3] ? { id: o.aktivitaetId, name: r[3].aktuell.werte.bezeichnung } : { id: o.aktivitaetId, name: 'unbekannt' },
          fahrzeug: r[5] ? { id: r[5].fahrzeug.id, name: r[5].aktuell.werte.bezeichnung } : { id: o.fahrzeugId, name: 'unbekannt' },
          kosten: r[4].filter(function (x) { return x.aktuell.werte.besuchId === id; }),
          geplantText: w.geplant ? MM.Reiseorte.labelVon(MM.Reiseorte.GEPLANT, w.geplant) : null, aufenthalt: null };
        return aufenthalteZuBesuchen(self, [{ objekt: o, aktuell: aktuell }]).then(function (d) {
          res.aufenthalt = d[o.id] || null;
          res.landstrom = MM.Reiseorte.landstromInfo(w, res.aufenthalt, self.jetztLokal());
          return res;
        });
      });
    });
  };

  /*
   * Angaben eines Besuchs ändern: Standort, Datum, Uhrzeit, Ausstattung beim Besuch, Notiz. Nur die Angaben, die der Aufruf nennt.
   * Der Ort bleibt (sonst stimmt die Historie des Ortes nicht mehr): Ein falscher Besuch wird ausgeblendet und neu eingetragen.
   * Die Ausstattung beim Besuch ändert nur den Besuch, nicht den Ort. Ausgeblendete Besuche zählen nicht mit, nichts wird gelöscht.
   */
  Daten.prototype.besuchAendern = function (id, roh) {
    var self = this;
    roh = roh || {};
    return Promise.all([this.besuchLaden(id), this.standorteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Besuch wurde nicht gefunden.' } };
      var alt = x.aktuell.werte;
      if (alt.status !== 'besucht') return { ok: false, fehler: { allgemein: 'Zu diesem Besuch wurde nichts festgehalten, es gibt nichts zu ändern.' } };
      var p = self.pruefenBesuch(roh), f = p.fehler;
      function da(k) { return Object.prototype.hasOwnProperty.call(roh, k); }
      if (da('datum') && !trimmed2(roh.datum) && !f.datum) f.datum = 'Bitte das Datum angeben.';
      var standortId = da('standortId') ? (trimmed2(roh.standortId) || null) : alt.standortId;
      if (da('standortId') && standortId && !r[1].some(function (s) { return s.objekt.id === standortId && s.objekt.ortId === alt.ortId; })) f.standortId = 'Diesen Standort gibt es an diesem Ort nicht.';
      if (Object.keys(f).length) return { ok: false, fehler: f };
      var neu = Object.assign({}, alt, { standortId: standortId });
      ['datum', 'zeit', 'ausstattung', 'ausstattungSonst', 'notiz'].forEach(function (k) { if (da(k)) neu[k] = p.werte[k]; });
      /* Landstrom (seit 2.0.59): Ohne Haken fallen die Angaben zum Automaten weg. Wer nur die Menge nennt, behält Haken und Art von vorher. */
      if (da('landstrom') || da('landstromAutomat') || da('landstromMenge')) {
        var lRoh = Object.assign({ landstrom: alt.landstrom, landstromAutomat: alt.landstromAutomat, landstromMenge: alt.landstromMenge }, roh);
        var lp = self.pruefenBesuch(lRoh);
        ['landstrom', 'landstromAutomat', 'landstromMenge'].forEach(function (k) { if (lp.fehler[k]) f[k] = lp.fehler[k]; });
        if (Object.keys(f).length) return { ok: false, fehler: f };
        neu.landstrom = lp.werte.landstrom; neu.landstromAutomat = lp.werte.landstromAutomat; neu.landstromMenge = lp.werte.landstromMenge;
      }
      if (da('ausgeblendet')) neu.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
      /* Ort, Plan und Status ändert dieser Weg nie. */
      var felder = MM.Reiseorte.besuchFelder();
      if (!unterschiedeFelder(felder, alt, neu).length) return { ok: true, id: id, geaendert: false };
      var e = neuerVerlaufEintrag('besuch', id, x.aktuell.nr + 1, neu, x.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: id, geaendert: true }; });
    });
  };

  Daten.prototype.besuchAusblenden = function (id, ausblenden) { return this.besuchAendern(id, { ausgeblendet: ausblenden ? 'ja' : 'nein' }); };

  /*
   * Besuche mit den Namen von Ort, Standort und Aktivität, neueste zuerst. opt: { ortId, aktivitaetId, mitUebersprungenen }
   * Ohne mitUebersprungenen stehen nur die Besuche mit Status „besucht“ in der Liste (auch ausgeblendete, mit Kennzeichen).
   */
  Daten.prototype.besuchListe = function (opt) {
    opt = opt || {};
    var self = this;
    return Promise.all([besucheAlleSammeln(this, opt.aktivitaetId || null), this.orteListe(), this.standorteListe(), this.aktivitaetenListe()]).then(function (r) {
      var orte = {}, standorte = {}, akt = {};
      r[1].forEach(function (x) { orte[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      r[2].forEach(function (x) { standorte[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      r[3].forEach(function (x) { akt[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      var liste = r[0].filter(function (x) {
        return (opt.mitUebersprungenen || x.aktuell.werte.status === 'besucht') && (!opt.ortId || x.aktuell.werte.ortId === opt.ortId);
      }).map(function (x) {
        var w = x.aktuell.werte;
        return Object.assign({}, x, { ortName: w.ortId ? (orte[w.ortId] || 'unbekannt') : null, standortName: w.standortId ? (standorte[w.standortId] || 'unbekannt') : null,
          aktivitaetName: akt[x.objekt.aktivitaetId] || 'unbekannt' });
      });
      liste.sort(function (a, b) { var ka = besuchSchluessel(a), kb = besuchSchluessel(b); return ka < kb ? 1 : (ka > kb ? -1 : 0); });
      return aufenthalteZuBesuchen(self, liste).then(function (d) { liste.forEach(function (x) { x.aufenthalt = d[x.objekt.id] || null; }); return liste; });
    });
  };

  /* Was ein Ort dich gekostet hat und wie oft du dort warst, dazu die Besuche und die Posten. null, wenn es den Ort nicht gibt. */
  Daten.prototype.ortAuswertung = function (ortId) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', ortId, []), this.besuchListe({ ortId: ortId }), kostenAlleSammeln(this)]).then(function (r) {
      if (!r[0] || r[0].objekt.datenraumId !== self.datenraumId) return null;
      var kosten = r[2].filter(function (x) { return x.aktuell.werte.ortId === ortId; })
        .sort(function (a, b) { return (a.aktuell.werte.datum || '') < (b.aktuell.werte.datum || '') ? 1 : -1; });
      var a = MM.Reiseorte.ortAuswertung(r[1].map(function (b) { return { werte: b.aktuell.werte }; }), kosten.map(function (k) { return { werte: k.aktuell.werte }; }));
      a.ok = true; a.besuche = r[1]; a.kosten = kosten;
      return a;
    });
  };

  /* Was hat eine Reise (Aktivität) gekostet, wie gliedert es sich auf, welche Orte waren dabei, was war geplant? null, wenn es die Aktivität nicht gibt. */
  Daten.prototype.reiseAuswertung = function (aktivitaetId, opts) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.orteListe(), besucheAlleSammeln(this, aktivitaetId), kostenAlleSammeln(this)]).then(function (r) {
      var a = r[0];
      if (!a) return null;
      var namen = {}; r[1].forEach(function (o) { namen[o.objekt.id] = o.aktuell.werte.bezeichnung; });
      var alleAkt = r[3].filter(function (x) { return x.aktuell.werte.aktivitaetId === aktivitaetId; });
      var kosten = alleAkt.filter(function (x) { return x.aktuell.werte.gruppe !== 'reisekasse'; }); /* Orte und Fahrzeug-Seite der Reise */
      var res = MM.Reiseorte.reiseAuswertung({ kosten: kosten.map(function (k) { return { werte: k.aktuell.werte }; }),
        besuche: r[2].map(function (b) { return { werte: b.aktuell.werte }; }), plan: planAus(a.aktuell.werte), orteNamen: namen });
      res.ok = true;
      return Promise.all([self.zahlungsmittelListe(), self.kostenartenListe(), self.kassenListe(aktivitaetId)]).then(function (z) {
        var zm = {}; z[0].forEach(function (x) { zm[x.wert] = x.label; });
        var artN = {}; z[1].forEach(function (x) { artN[x.wert] = x.label; });
        var fixPosten = r[3].filter(function (x) { return x.objekt.fahrzeugId === a.fahrzeug.id && x.aktuell.werte.gruppe === 'fix' && x.aktuell.werte.ausgeblendet !== 'ja'; })
          .map(function (x) { return { werte: x.aktuell.werte }; });
        res.gesamt = MM.Reisekasse.reiseGesamt({ kosten: alleAkt.map(function (x) { return { werte: x.aktuell.werte }; }), von: a.aktuell.werte.vonDatum, bis: a.aktuell.werte.bisDatum,
          personen: a.besatzung.length, fixPosten: fixPosten, fixEin: !(opts && opts.fixEin === false), zahlungsmittel: zm, heute: self.heute() });
        res.artNamen = artN; res.zahlungNamen = zm;
        res.kassen = z[2];
        res.reisekassePosten = alleAkt.filter(function (x) { return x.aktuell.werte.gruppe === 'reisekasse'; });
        res.besuche = r[2].filter(function (b) { return b.aktuell.werte.status === 'besucht'; }).map(function (b) { return Object.assign({}, b, { ortName: namen[b.aktuell.werte.ortId] || 'unbekannt' }); })
        .sort(function (x, y) { return besuchSchluessel(x) < besuchSchluessel(y) ? -1 : 1; });
        return aufenthalteZuBesuchen(self, res.besuche).then(function (d) { res.besuche.forEach(function (x) { x.aufenthalt = d[x.objekt.id] || null; }); return res; });
      });
    });
  };

  /*
   * Die kleine Abfrage im Cockpit: Gibt es eine Ankunft (Ankunft, Anlegen, Anker werfen), zu der noch nichts festgehalten oder
   * übersprungen wurde? Dann: das Ereignis, der Ort im Umfeld der Position (wenn es einen gibt) und wie es zum Plan der Aktivität
   * steht. ereignisse: die sichtbaren Ereignisse aus dem Logbuch. Gibt null, wenn nichts zu fragen ist.
   */
  Daten.prototype.reiseortFrage = function (aktivitaetId, ereignisse) {
    var self = this;
    return Promise.all([this.speicher.wo('besuche', 'aktivitaetId', aktivitaetId), this.mitVerlaufLaden('aktivitaeten', aktivitaetId, [])]).then(function (r) {
      var e = MM.Reiseorte.besuchFrage(ereignisse, r[0], self.jetztLokal());
      if (!e || !r[1]) return null;
      var plan = planAus(r[1].aktuell.werte);
      return Promise.all([self.orteListe(), self.standorteListe()]).then(function (o) {
        var namen = {}; o[0].forEach(function (x) { namen[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var vorschlag = MM.Reiseorte.naechster(MM.Reiseorte.kandidaten(o[0], o[1]), e.breite, e.laenge);
        var art = vorschlag ? MM.Reiseorte.planVergleich(plan, vorschlag.ortId) : null;
        return { ereignisId: e.id, artName: e.artName, datum: e.datum, zeit: e.zeit, breite: e.breite, laenge: e.laenge, ortName: e.ortName || null,
          vorschlag: vorschlag, plan: { vorhanden: MM.Reiseorte.planVergleich(plan, '-') !== null, art: art, text: MM.Reiseorte.planText(art),
            zielName: plan.zielOrtId ? (namen[plan.zielOrtId] || null) : null } };
      });
    });
  };

  /* ---------- Dokumente ---------- */
  /*
   * Ein Dokument ist eine Datei vom Gerät oder ein Link. Die Datei liegt in
   * einer eigenen Ablage, getrennt vom Eintrag. Das Dokument selbst bleibt
   * unverändert: Wer eine andere Datei will, legt ein neues Dokument an.
   */
  Daten.prototype.pruefenDokument = function (roh, quelle) {
    var p = pruefeWerte(MM.Dokumente.felder(quelle), roh, jahrVon(this));
    var w = p.werte, f = p.fehler;
    if (!w.art && !f.art) f.art = 'Bitte die Art des Dokuments wählen.';
    if (quelle === 'link') {
      if (!String(roh.link == null ? '' : roh.link).trim()) f.link = 'Bitte den Link eingeben.';
      else {
        var l = MM.Dokumente.normalisiereLink(roh.link);
        if (!l) { if (!f.link) f.link = 'Das ist kein gültiger Link. Er soll mit http oder https beginnen, zum Beispiel https://www.beispiel.de/anleitung.pdf'; }
        else w.link = l;
      }
    } else { w.link = null; }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  function istQuotaFehler(err) {
    return !!err && (err.name === 'QuotaExceededError' || /quota/i.test(String(err.message || '')));
  }

  /* vorgangId (seit 2.0.26, freiwillig): Das Dokument hängt an diesem Werkstatt-Vorgang (Bild, Beleg, Reparaturbuch-Seite). Fahrzeug und Komponente
     sind dann die des Vorgangs. */
  Daten.prototype.dokumentAnlegen = function (fahrzeugId, komponenteId, roh, vorgangId, kostenId) {
    var self = this;
    roh = roh || {};
    var quelle = roh.quelle, datei = roh.datei, fehler = {};
    if (quelle !== 'datei' && quelle !== 'link') fehler.quelle = 'Bitte wählen, ob du eine Datei oder einen Link ablegen möchtest.';
    if (quelle === 'datei' && !(datei && typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Bitte eine Datei auswählen.';
    var rohW = Object.assign({}, roh);
    if (quelle === 'datei' && !String(rohW.bezeichnung == null ? '' : rohW.bezeichnung).trim() && datei && datei.name) {
      rohW.bezeichnung = String(datei.name).replace(/\.[^.]+$/, '');
    }
    var p = this.pruefenDokument(rohW, quelle);
    Object.keys(p.fehler).forEach(function (k) { fehler[k] = p.fehler[k]; });
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });

    var vorgangPruefung = vorgangId ? this.speicher.holen('vorgaenge', vorgangId) : Promise.resolve(null);
    var kostenPruefung = kostenId ? this.speicher.holen('kosten', kostenId) : Promise.resolve(null);
    return Promise.all([vorgangPruefung, kostenPruefung]).then(function (rr) {
      var vg = rr[0], ko = rr[1];
      if (kostenId && (!ko || ko.fahrzeugId !== fahrzeugId || ko.datenraumId !== self.datenraumId)) return { ok: false, fehler: { allgemein: 'Dieser Posten wurde nicht gefunden.' } };
      if (vorgangId) {
        if (!vg || vg.fahrzeugId !== fahrzeugId) return { ok: false, fehler: { allgemein: 'Dieser Vorgang wurde nicht gefunden.' } };
        komponenteId = vg.komponenteId || null;
      }
      return self.pruefeObjekt(fahrzeugId, komponenteId || null);
    }).then(function (f) {
      if (f && f.ok === false) return f;
      if (f) return { ok: false, fehler: f };
      var jetzt = self.jetzt();
      var w = p.werte;
      w.quelle = quelle;
      w.dateiName = quelle === 'datei' ? String(datei.name || 'Datei') : null;
      w.dateiTyp = quelle === 'datei' ? String(datei.type || '') : null;
      w.dateiGroesse = quelle === 'datei' ? datei.size : null;
      var d = { id: neueId('do'), fahrzeugId: fahrzeugId, komponenteId: komponenteId || null, vorgangId: vorgangId || null, kostenId: kostenId || null, erstelltAm: jetzt };
      var liste = [
        { tabelle: 'dokumente', objekt: d },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('dokument', d.id, 1, w, null, jetzt) }
      ];
      if (quelle === 'datei') {
        liste.push({ tabelle: 'dateien', objekt: { id: neueId('da'), dokumentId: d.id, name: w.dateiName, mime: w.dateiTyp,
          groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      }
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: d.id }; })
        .catch(function (err) {
          if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei. Gib Platz frei oder wähle eine kleinere Datei.' } };
          throw err;
        });
    });
  };

  Daten.prototype.dokumentAendern = function (dokumentId, roh) {
    var self = this;
    return this.dokumentLaden(dokumentId).then(function (d) {
      if (!d) return { ok: false, fehler: { allgemein: 'Dieses Dokument wurde nicht gefunden.' } };
      var quelle = d.aktuell.werte.quelle;
      var p = self.pruefenDokument(roh, quelle);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, d.aktuell.werte, p.werte);
      if (!unterschiedeFelder(MM.Dokumente.felder(quelle), d.aktuell.werte, neu).length) return { ok: true, id: dokumentId, geaendert: false };
      var e = neuerVerlaufEintrag('dokument', dokumentId, d.aktuell.nr + 1, neu, d.aktuell.id, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: dokumentId, geaendert: true }; });
    });
  };

  Daten.prototype.dokumentLaden = function (id) {
    var self = this;
    return this.speicher.holen('dokumente', id).then(function (d) {
      if (!d) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id),
        self.speicher.wo('dateien', 'dokumentId', id),
        self.fahrzeugLaden(d.fahrzeugId),
        self.komponentenListe(d.fahrzeugId),
        d.vorgangId ? self.vorgangLaden(d.vorgangId) : Promise.resolve(null)
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length || !r[2]) return null;
        var aktuell = eintraege[eintraege.length - 1];
        var komp = d.komponenteId ? r[3].filter(function (k) { return k.komponente.id === d.komponenteId; })[0] : null;
        var datei = r[1][0] ? { id: r[1][0].id, name: r[1][0].name, mime: r[1][0].mime, groesse: r[1][0].groesse } : null;
        return { dokument: d, aktuell: aktuell, verlauf: verlaufAus(eintraege, MM.Dokumente.felder(aktuell.werte.quelle)), datei: datei,
          fahrzeug: r[2].fahrzeug, fahrzeugAktuell: r[2].aktuell,
          komponente: komp ? komp.komponente : null, komponenteAktuell: komp ? komp.aktuell : null,
          vorgang: r[4] ? r[4].vorgang : null, vorgangAktuell: r[4] ? r[4].aktuell : null };
      });
    });
  };

  /* Die Datei selbst (mit Inhalt), zum Öffnen oder Speichern. */
  Daten.prototype.dateiHolen = function (dokumentId) {
    return this.speicher.wo('dateien', 'dokumentId', dokumentId).then(function (l) { return l[0] || null; });
  };

  /* Alle Dokumente eines Fahrzeugs und seiner Komponenten. Zuerst das Fahrzeug, dann die Komponenten nach Name. */
  Daten.prototype.dokumenteListe = function (fahrzeugId) {
    return Promise.all([
      this.speicher.wo('dokumente', 'fahrzeugId', fahrzeugId),
      this.speicher.alle('verlaeufe'),
      this.komponentenListe(fahrzeugId),
      this.vorgaengeListe(fahrzeugId)
    ]).then(function (r) {
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'dokument') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var kn = {}; r[2].forEach(function (k) { kn[k.komponente.id] = k.aktuell.werte.bezeichnung; });
      var vn = {}; r[3].forEach(function (v) { vn[v.vorgang.id] = v.aktuell.werte.bezeichnung; });
      var res = r[0].map(function (d) {
        var l = (ver[d.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1];
        if (!a) return null;
        return { dokument: d, aktuell: a, komponenteId: d.komponenteId, besitzer: d.komponenteId ? (kn[d.komponenteId] || 'Komponente') : null,
          vorgangId: d.vorgangId || null, vorgangName: d.vorgangId ? (vn[d.vorgangId] || 'Vorgang') : null, kostenId: d.kostenId || null };
      }).filter(Boolean);
      res.sort(function (a, b) {
        if (!a.besitzer !== !b.besitzer) return a.besitzer ? 1 : -1;
        var o = (a.besitzer || '').localeCompare(b.besitzer || '', 'de', { numeric: true, sensitivity: 'base' });
        if (o) return o;
        var art = MM.Dokumente.artIndex(a.aktuell.werte.art) - MM.Dokumente.artIndex(b.aktuell.werte.art);
        return art || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return res;
    });
  };

  /* Die Dokumente und Bilder, die an einem Werkstatt-Vorgang hängen (seit 2.0.26), in der Reihenfolge der Liste. */
  Daten.prototype.dokumenteFuerVorgang = function (vorgangId) {
    var self = this;
    return this.speicher.holen('vorgaenge', vorgangId).then(function (v) {
      if (!v) return [];
      return self.dokumenteListe(v.fahrzeugId).then(function (l) { return l.filter(function (x) { return x.vorgangId === vorgangId; }); });
    });
  };

  /* Fotos und Belege an einem Posten der Kosten-Liste (seit 2.0.29), in der Reihenfolge der Liste. */
  Daten.prototype.dokumenteFuerKosten = function (kostenId) {
    var self = this;
    return this.speicher.holen('kosten', kostenId).then(function (k) {
      if (!k) return [];
      return self.dokumenteListe(k.fahrzeugId).then(function (l) { return l.filter(function (x) { return x.kostenId === kostenId; }); });
    });
  };

  /* Scans und Fotos von Nachweisen: bleiben immer nur auf diesem Gerät. */
  Daten.prototype.scansBelegung = function () {
    return this.speicher.alle('nachweisdateien').then(function (l) {
      l = l.filter(function (x) { return !!x.inhalt; });
      return { anzahl: l.length, bytes: l.reduce(function (s, x) { return s + (x.groesse || 0); }, 0) };
    });
  };

  /* Wie viel Platz belegen die Dateien auf diesem Gerät? */
  Daten.prototype.dateienBelegung = function () {
    return this.speicher.alle('dateien').then(function (l) {
      l = l.filter(function (x) { return !!x.inhalt; });
      return { anzahl: l.length, bytes: l.reduce(function (s, x) { return s + (x.groesse || 0); }, 0) };
    });
  };

  /* ---------- Personen und Tiere ---------- */
  function tabelleVon(typ) { return typ === 'person' ? 'personen' : (typ === 'tier' ? 'tiere' : 'fahrzeuge'); }
  function trimmed(v) { return String(v == null ? '' : v).trim(); }

  Daten.prototype.pruefenPerson = function (roh) {
    var p = pruefeWerte(MM.Personen.personFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen eingeben.' });
    var w = p.werte, f = p.fehler;
    if (w.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(w.email)) f.email = 'Das ist keine gültige E-Mail-Adresse.';
    if (w.telefon && !/^[0-9+\-\/() ]{5,}$/.test(w.telefon)) f.telefon = 'Bitte nur Ziffern, Leerzeichen und + - / ( ) eingeben.';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.pruefenTier = function (roh) {
    var p = pruefeWerte(MM.Personen.tierFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen eingeben.' });
    var w = p.werte, f = p.fehler;
    if (!w.tierart && !f.tierart) f.tierart = 'Bitte die Tierart wählen.';
    if (w.chipnummer) {
      var c = w.chipnummer.replace(/[\s-]/g, '');
      if (!/^\d{9,15}$/.test(c)) f.chipnummer = 'Die Chipnummer besteht aus Ziffern, meist 15.'; else w.chipnummer = c;
    }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Gemeinsame Bausteine für Dinge mit Verlauf: Person, Tier. */
  Daten.prototype.mitVerlaufAnlegen = function (tabelle, typ, praefix, werte, extra) {
    var jetzt = this.jetzt();
    var o = { id: neueId(praefix), datenraumId: this.datenraumId, erstelltAm: jetzt };
    if (extra) { for (var k in extra) { o[k] = extra[k]; } }
    return this.speicher.mehrereSpeichern([
      { tabelle: tabelle, objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag(typ, o.id, 1, werte, null, jetzt) }
    ]).then(function () { return { ok: true, id: o.id }; });
  };

  Daten.prototype.mitVerlaufLaden = function (tabelle, id, felder) {
    var self = this;
    return Promise.all([this.speicher.holen(tabelle, id), this.speicher.wo('verlaeufe', 'objektId', id)]).then(function (r) {
      if (!r[0] || !r[1].length) return null;
      var eintraege = r[1].slice().sort(nachNr);
      return { objekt: r[0], aktuell: eintraege[eintraege.length - 1], verlauf: verlaufAus(eintraege, felder || []) };
    });
  };

  Daten.prototype.mitVerlaufAendern = function (typ, id, geladen, neu, felder, zusatz) {
    if (!unterschiedeFelder(felder, geladen.aktuell.werte, neu).length) return Promise.resolve({ ok: true, id: id, geaendert: false });
    var e = neuerVerlaufEintrag(typ, id, geladen.aktuell.nr + 1, neu, geladen.aktuell.id, this.jetzt());
    if (zusatz) Object.keys(zusatz).forEach(function (k) { e[k] = zusatz[k]; });
    return this.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: id, geaendert: true }; });
  };

  Daten.prototype.personAnlegen = function (roh) {
    var p = this.pruefenPerson(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.mitVerlaufAnlegen('personen', 'person', 'pe', p.werte);
  };
  Daten.prototype.personAendern = function (id, roh) {
    var self = this;
    return this.personLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Person wurde nicht gefunden.' } };
      var p = self.pruefenPerson(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('person', id, x, p.werte, MM.Personen.personFelder());
    });
  };
  Daten.prototype.personLaden = function (id) { return this.mitVerlaufLaden('personen', id, MM.Personen.personFelder()); };
  Daten.prototype.personenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('personen'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'person');
    });
  };

  Daten.prototype.tierAnlegen = function (roh) {
    var p = this.pruefenTier(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.mitVerlaufAnlegen('tiere', 'tier', 'ti', p.werte);
  };
  Daten.prototype.tierAendern = function (id, roh) {
    var self = this;
    return this.tierLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Tier wurde nicht gefunden.' } };
      var p = self.pruefenTier(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('tier', id, x, p.werte, MM.Personen.tierFelder());
    });
  };
  Daten.prototype.tierLaden = function (id) { return this.mitVerlaufLaden('tiere', id, MM.Personen.tierFelder()); };
  Daten.prototype.tiereListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('tiere'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'tier');
    });
  };

  /* Objekte mit aktuellem Stand, nach Namen sortiert. */
  function sammle(self, objekte, verlaeufe, typ) {
    var ver = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === typ) (ver[e.objektId] = ver[e.objektId] || []).push(e); });
    var liste = objekte.filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
      var l = (ver[o.id] || []).slice().sort(nachNr);
      return { objekt: o, aktuell: l[l.length - 1] || null };
    }).filter(function (x) { return x.aktuell; });
    liste.sort(function (a, b) { return a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' }); });
    return liste;
  }

  /* ---------- Nachweisarten (offene Liste) ---------- */
  var ART_FELDER = [
    { key: 'bezeichnung', label: 'Name der Art' },
    { key: 'hatAblauf', label: 'Mit Ablaufdatum', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN },
    { key: 'land', label: 'Land', typ: 'text' },
    { key: 'beschreibung', label: 'Beschreibung', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN },
    { key: 'felder', label: 'Weitere Angaben', typ: 'zeilen' }
  ];

  Daten.prototype.pruefenNachweisart = function (roh, neu) {
    roh = roh || {};
    var f = {}, w = {};
    var bez = trimmed(roh.bezeichnung);
    if (!bez) f.bezeichnung = 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segelschein“.';
    w.bezeichnung = bez;
    if (neu) {
      if (!MM.Nachweise.BESITZER.some(function (b) { return b.wert === roh.gehoertZu; })) f.gehoertZu = 'Bitte wählen, wofür der Nachweis gilt: Person, Tier oder Fahrzeug.';
      else w.gehoertZu = roh.gehoertZu;
    }
    w.hatAblauf = roh.hatAblauf === 'ja' ? 'ja' : 'nein';
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    w.land = trimmed(roh.land) || null;
    w.beschreibung = trimmed(roh.beschreibung) || null;

    var zeilen = Array.isArray(roh.felder) ? roh.felder : [];
    var belegt = {}, hoechste = 0;
    zeilen.forEach(function (z) { var m = /^z(\d+)$/.exec(z && z.key || ''); if (m) { belegt[z.key] = true; hoechste = Math.max(hoechste, +m[1]); } });
    var sauber = [], benutzt = {};
    zeilen.forEach(function (z) {
      var label = trimmed(z && z.label), papier = trimmed(z && z.papier);
      if (!label && !papier) return;
      if (!label) { f.felder = 'Bitte bei jeder weiteren Angabe eine Beschriftung eingeben.'; return; }
      var typ = MM.Nachweise.FELDTYPEN.some(function (t) { return t.wert === z.typ; }) ? z.typ : 'text';
      var key = z.key && /^z\d+$/.test(z.key) && !benutzt[z.key] ? z.key : null;
      if (!key) { hoechste++; key = 'z' + hoechste; }
      benutzt[key] = true;
      sauber.push({ key: key, label: label, typ: typ, papier: papier });
    });
    w.felder = sauber;
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.nachweisartAnlegen = function (roh) {
    var p = this.pruefenNachweisart(roh, true);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var w = p.werte;
    w.gemeinsam = {}; w.ohne = []; w.herkunft = 'eigen'; w.vorschlagId = null;
    w.quelleTitel = null; w.quelleUrl = null; w.pruefstatus = null; w.geprueftAm = null;
    return this.mitVerlaufAnlegen('nachweisarten', 'nachweisart', 'na', w);
  };

  /* Übernimmt einen Vorschlag als eigene Art. Danach ist sie frei änderbar. */
  Daten.prototype.nachweisartAusVorschlag = function (vorschlagId) {
    var self = this;
    var v = MM.NachweisVorschlaege.finde(vorschlagId);
    if (!v) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diesen Vorschlag gibt es nicht.' } });
    return this.nachweisartenListe().then(function (liste) {
      var vorhanden = liste.filter(function (x) { return x.aktuell.werte.vorschlagId === vorschlagId; })[0];
      if (vorhanden) return { ok: false, vorhanden: true, id: vorhanden.objekt.id, fehler: { allgemein: 'Diese Art ist schon übernommen.' } };
      return self.mitVerlaufAnlegen('nachweisarten', 'nachweisart', 'na', {
        bezeichnung: v.name, gehoertZu: v.gehoertZu, hatAblauf: v.hatAblauf ? 'ja' : 'nein', ausgeblendet: 'nein',
        land: v.land, beschreibung: v.hinweis || null, gemeinsam: v.gemeinsam, ohne: v.ohne, felder: v.felder,
        herkunft: 'vorschlag', vorschlagId: v.id, quelleTitel: v.quelle ? v.quelle.titel : null, quelleUrl: v.quelle ? v.quelle.url : null,
        pruefstatus: v.pruefstatus, geprueftAm: v.geprueftAm
      });
    });
  };

  Daten.prototype.nachweisartAendern = function (id, roh) {
    var self = this;
    return this.nachweisartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var p = self.pruefenNachweisart(roh, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, x.aktuell.werte, p.werte);
      return self.mitVerlaufAendern('nachweisart', id, x, neu, ART_FELDER);
    });
  };

  Daten.prototype.nachweisartLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('nachweisarten', id, ART_FELDER).then(function (x) {
      if (!x) return null;
      return self.speicher.alle('nachweise').then(function (n) {
        x.anzahlNachweise = n.filter(function (k) { return k.artId === id; }).length;
        x.art = x.objekt; x.werte = x.aktuell.werte;
        return x;
      });
    });
  };

  /* Alle Arten, nach Besitzer (Person, Tier, Fahrzeug) und Name geordnet. */
  Daten.prototype.nachweisartenListe = function (gehoertZu) {
    var self = this;
    return Promise.all([this.speicher.alle('nachweisarten'), this.speicher.alle('verlaeufe'), this.speicher.alle('nachweise')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'nachweisart');
      var anzahl = {}; r[2].forEach(function (n) { anzahl[n.artId] = (anzahl[n.artId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlNachweise = anzahl[x.objekt.id] || 0; });
      if (gehoertZu) liste = liste.filter(function (x) { return x.aktuell.werte.gehoertZu === gehoertZu; });
      var reihenfolge = { person: 0, tier: 1, fahrzeug: 2 };
      liste.sort(function (a, b) {
        var o = reihenfolge[a.aktuell.werte.gehoertZu] - reihenfolge[b.aktuell.werte.gehoertZu];
        return o || a.aktuell.werte.bezeichnung.localeCompare(b.aktuell.werte.bezeichnung, 'de', { numeric: true, sensitivity: 'base' });
      });
      return liste;
    });
  };

  /* ---------- Nachweise ---------- */
  Daten.prototype.besitzerLaden = function (typ, id) {
    if (typ === 'fahrzeug') return this.fahrzeugLaden(id).then(function (f) { return f ? { name: f.aktuell.werte.bezeichnung, id: id } : null; });
    return this.mitVerlaufLaden(tabelleVon(typ), id, []).then(function (x) { return x ? { name: x.aktuell.werte.bezeichnung, id: id } : null; });
  };

  function artStatus(art, werte, heute) { return MM.Nachweise.status(art, werte, heute); }

  Daten.prototype.nachweisAnlegen = function (besitzerTyp, besitzerId, artId, roh) {
    var self = this;
    roh = roh || {};
    return Promise.all([this.nachweisartLaden(artId), this.besitzerLaden(besitzerTyp, besitzerId)]).then(function (r) {
      var art = r[0], besitzer = r[1];
      if (!art) return { ok: false, fehler: { artId: 'Bitte zuerst die Art des Nachweises wählen.' } };
      if (!besitzer) return { ok: false, fehler: { allgemein: 'Dazu wurde nichts gefunden.' } };
      var aw = art.aktuell.werte;
      if (aw.gehoertZu !== besitzerTyp) return { ok: false, fehler: { artId: 'Diese Art gilt nicht hierfür.' } };
      if (aw.ausgeblendet === 'ja') return { ok: false, fehler: { artId: 'Diese Art ist ausgeblendet.' } };

      var felder = MM.Nachweise.felderFuer(aw);
      var p = pruefeWerte(felder, roh, jahrVon(self), { ohneBezeichnung: true });
      var fehler = p.fehler, w = p.werte;
      if (w.ausgestelltAm && w.gueltigBis && w.gueltigBis < w.ausgestelltAm && !fehler.gueltigBis) fehler.gueltigBis = 'Das Ablaufdatum liegt vor dem Ausstellungsdatum.';
      var datei = roh.datei;
      if (datei && !(typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Diese Datei ist leer.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };

      var jetzt = self.jetzt();
      var n = { id: neueId('nw'), datenraumId: self.datenraumId, artId: artId, besitzerTyp: besitzerTyp, besitzerId: besitzerId, erstelltAm: jetzt };
      w.dateiName = datei ? String(datei.name || 'Datei') : null;
      w.dateiTyp = datei ? String(datei.type || '') : null;
      w.dateiGroesse = datei ? datei.size : null;
      var liste = [{ tabelle: 'nachweise', objekt: n }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('nachweis', n.id, 1, w, null, jetzt) }];
      if (datei) liste.push({ tabelle: 'nachweisdateien', objekt: { id: neueId('nd'), nachweisId: n.id, name: w.dateiName, mime: w.dateiTyp, groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: n.id }; }).catch(function (err) {
        if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei.' } };
        throw err;
      });
    });
  };

  Daten.prototype.nachweisAendern = function (id, roh) {
    var self = this;
    return this.nachweisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Nachweis wurde nicht gefunden.' } };
      var p = pruefeWerte(x.felder, roh || {}, jahrVon(self), { ohneBezeichnung: true });
      var fehler = p.fehler, w = p.werte;
      if (w.ausgestelltAm && w.gueltigBis && w.gueltigBis < w.ausgestelltAm && !fehler.gueltigBis) fehler.gueltigBis = 'Das Ablaufdatum liegt vor dem Ausstellungsdatum.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var neu = Object.assign({}, x.aktuell.werte, w);
      return self.mitVerlaufAendern('nachweis', id, { aktuell: x.aktuell }, neu, x.felder);
    });
  };

  Daten.prototype.nachweisLaden = function (id) {
    var self = this;
    return this.speicher.holen('nachweise', id).then(function (n) {
      if (!n) return null;
      return Promise.all([self.nachweisartLaden(n.artId), self.mitVerlaufLaden('nachweise', id, []), self.speicher.wo('nachweisdateien', 'nachweisId', id), self.besitzerLaden(n.besitzerTyp, n.besitzerId)]).then(function (r) {
        var art = r[0], x = r[1];
        if (!art || !x) return null;
        var felder = MM.Nachweise.felderFuer(art.aktuell.werte);
        var eintraege = x.verlauf.map(function (v) { return v.eintrag; });
        var verlauf = verlaufAus(eintraege, felder);
        var d = r[2][0] ? { id: r[2][0].id, name: r[2][0].name, mime: r[2][0].mime, groesse: r[2][0].groesse } : null;
        return { nachweis: n, aktuell: x.aktuell, verlauf: verlauf, art: art, felder: felder, datei: d, besitzer: r[3],
          status: artStatus(art.aktuell.werte, x.aktuell.werte, self.heute()) };
      });
    });
  };

  Daten.prototype.nachweisDateiHolen = function (nachweisId) {
    return this.speicher.wo('nachweisdateien', 'nachweisId', nachweisId).then(function (l) { return l[0] || null; });
  };

  /* Nachweise eines Besitzers, mit Status. Abgelaufene zuerst. */
  Daten.prototype.nachweiseListe = function (besitzerTyp, besitzerId) {
    var self = this;
    return Promise.all([this.speicher.wo('nachweise', 'besitzerId', besitzerId), this.speicher.alle('verlaeufe'), this.nachweisartenListe()]).then(function (r) {
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a; });
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'nachweis') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var heute = self.heute();
      var liste = r[0].filter(function (n) { return n.besitzerTyp === besitzerTyp; }).map(function (n) {
        var l = (ver[n.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1], art = arten[n.artId];
        if (!a || !art) return null;
        return { nachweis: n, aktuell: a, art: art, status: artStatus(art.aktuell.werte, a.werte, heute) };
      }).filter(Boolean);
      liste.sort(function (a, b) {
        var d = MM.Nachweise.rang(b.status.status) - MM.Nachweise.rang(a.status.status);
        return d || a.art.aktuell.werte.bezeichnung.localeCompare(b.art.aktuell.werte.bezeichnung, 'de', { numeric: true });
      });
      return liste;
    });
  };

  /* Pro Besitzer: wie viele Nachweise sind abgelaufen oder laufen bald ab? */
  Daten.prototype.nachweisUebersicht = function () {
    var self = this;
    return Promise.all([this.speicher.alle('nachweise'), this.speicher.alle('verlaeufe'), this.nachweisartenListe()]).then(function (r) {
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a; });
      var ver = {}; r[1].forEach(function (e) { if (e.objektTyp === 'nachweis') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      var heute = self.heute(), res = {};
      r[0].forEach(function (n) {
        var l = (ver[n.id] || []).slice().sort(nachNr);
        var a = l[l.length - 1], art = arten[n.artId];
        if (!a || !art) return;
        var s = artStatus(art.aktuell.werte, a.werte, heute).status;
        var z = res[n.besitzerId] = res[n.besitzerId] || { abgelaufen: 0, bald: 0, unbekannt: 0 };
        if (z[s] !== undefined) z[s]++;
      });
      return res;
    });
  };

  /* ---------- Aktivitäten: gemeinsame Hilfen ---------- */
  Daten.prototype.jetztLokal = function () {
    var d = new Date(this.jetzt());
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()) + 'T' + z(d.getHours()) + ':' + z(d.getMinutes());
  };

  /* ---------- Aktivitätsarten (offene Liste) ---------- */
  var AKTART_FELDER = [
    { key: 'bezeichnung', label: 'Name der Art' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  /* Seit 2.0.17 gilt jede Aktivitätsart für Fahrzeugarten (Baum, wie bei den Ereignisarten).
     Fehlt die Angabe (ältere Arten), gilt sie für alle. */
  var AKTIVITAETSART_FELDER = AKTART_FELDER.concat([{ key: 'zuordnung', label: 'Gilt für Fahrzeugarten', typ: 'text' }]);

  Daten.prototype.aktivitaetsartenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('aktivitaetsarten'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'aktivitaetsart');
    });
  };

  Daten.prototype.aktivitaetsartAnlegen = function (roh) {
    var self = this;
    var bez = trimmed(roh && roh.bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segeln“.' } });
    return this.aktivitaetsartenListe().then(function (liste) {
      if (liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === bez.toLowerCase(); })) {
        return { ok: false, fehler: { bezeichnung: 'Diese Art gibt es schon.' } };
      }
      return self.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: bez, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungNormal(roh.zuordnung) });
    });
  };

  /* Legt die Vorschläge an, die es noch nicht gibt. Gibt die Anzahl der neuen zurück. */
  Daten.prototype.aktivitaetsartenAusVorschlaegen = function () {
    var self = this;
    return this.aktivitaetsartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Aktivitaeten.VORSCHLAEGE_ARTEN.filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
      return neu.reduce(function (kette, n) {
        var gilt = MM.Aktivitaeten.zuordnungVorschlag(n);
        var zuordnung = gilt ? MM.Logbuch.zuordnungFuerKnoten(gilt) : MM.Logbuch.zuordnungNormal();
        return kette.then(function () { return self.mitVerlaufAnlegen('aktivitaetsarten', 'aktivitaetsart', 'ar', { bezeichnung: n, ausgeblendet: 'nein', zuordnung: zuordnung }); });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  /* Setzt die Starthilfe-Zuordnung bei den vorgeschlagenen Arten, die noch keine Zuordnung haben (ältere Arten).
     Was der Nutzer schon eingestellt hat, bleibt unberührt. */
  Daten.prototype.aktivitaetsartenVorauswahlUebernehmen = function () {
    var self = this;
    return this.aktivitaetsartenListe().then(function (liste) {
      var offen = liste.filter(function (x) { return x.aktuell.werte.zuordnung === undefined && MM.Aktivitaeten.zuordnungVorschlag(x.aktuell.werte.bezeichnung); });
      return offen.reduce(function (kette, x) {
        return kette.then(function () {
          return self.aktivitaetsartAendern(x.objekt.id, { bezeichnung: x.aktuell.werte.bezeichnung, ausgeblendet: x.aktuell.werte.ausgeblendet,
            zuordnung: MM.Logbuch.zuordnungFuerKnoten(MM.Aktivitaeten.zuordnungVorschlag(x.aktuell.werte.bezeichnung)) });
        });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: offen.length, namen: offen.map(function (x) { return x.aktuell.werte.bezeichnung; }) }; });
    });
  };

  /* Die Aktivitätsarten, die zu einer Fahrzeugart passen (ohne ausgeblendete). Eine Art, die schon an einer
     Aktivität hängt, bleibt auswählbar (behalteIds). Ohne Fahrzeugart: alle nicht ausgeblendeten. */
  Daten.prototype.aktivitaetsartenFuerFahrzeugart = function (artId, behalteIds) {
    var behalte = behalteIds || [];
    return this.aktivitaetsartenListe().then(function (liste) {
      return liste.filter(function (x) {
        if (behalte.indexOf(x.objekt.id) >= 0) return true;
        if (x.aktuell.werte.ausgeblendet === 'ja') return false;
        return !artId || MM.Logbuch.ereignisartGilt(x.aktuell.werte.zuordnung, artId);
      });
    });
  };

  Daten.prototype.aktivitaetsartLaden = function (id) { return this.mitVerlaufLaden('aktivitaetsarten', id, AKTIVITAETSART_FELDER); };

  Daten.prototype.aktivitaetsartAendern = function (id, roh) {
    var self = this;
    return this.aktivitaetsartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var bez = trimmed(roh && roh.bezeichnung);
      if (!bez) return { ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben.' } };
      var neu = { bezeichnung: bez, ausgeblendet: roh.ausgeblendet === 'ja' ? 'ja' : 'nein' };
      /* Ohne Angabe bleibt die Zuordnung, wie sie ist (bei alten Arten: gilt für alle). */
      if (roh.zuordnung !== undefined) neu.zuordnung = MM.Logbuch.zuordnungNormal(roh.zuordnung);
      else if (x.aktuell.werte.zuordnung !== undefined) neu.zuordnung = x.aktuell.werte.zuordnung;
      return self.mitVerlaufAendern('aktivitaetsart', id, x, neu, AKTIVITAETSART_FELDER);
    });
  };

  /* ---------- Anforderungen an Skipper und Fahrer (je Fahrzeug) ---------- */
  var ANF_FELDER = [
    { key: 'bezeichnung', label: 'Bezeichnung' },
    { key: 'artIds', label: 'Akzeptierte Nachweisarten', typ: 'mehrfach' },
    { key: 'gilt', label: 'Gilt', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  Daten.prototype.pruefenAnforderung = function (roh, personenArten) {
    roh = roh || {};
    var f = {}, w = {};
    w.bezeichnung = trimmed(roh.bezeichnung);
    if (!w.bezeichnung) f.bezeichnung = 'Bitte eine Bezeichnung eingeben, zum Beispiel „Führerschein Klasse B“.';
    var gew = Array.isArray(roh.artIds) ? roh.artIds : [];
    w.artIds = personenArten.filter(function (a) { return gew.indexOf(a) >= 0; });
    if (!w.artIds.length) f.artIds = 'Bitte mindestens eine Art von Nachweis wählen, die genügt.';
    w.gilt = roh.gilt === 'nein' ? 'nein' : 'ja';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  function personenArtIds(self) {
    return self.nachweisartenListe('person').then(function (l) { return l.map(function (x) { return x.objekt.id; }); });
  }

  Daten.prototype.anforderungAnlegen = function (fahrzeugId, roh) {
    var self = this;
    return Promise.all([this.pruefeObjekt(fahrzeugId, null), personenArtIds(this)]).then(function (r) {
      if (r[0]) return { ok: false, fehler: r[0] };
      var p = self.pruefenAnforderung(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAnlegen('anforderungen', 'anforderung', 'an', p.werte, { fahrzeugId: fahrzeugId });
    });
  };

  Daten.prototype.anforderungLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('anforderungen', id, ANF_FELDER).then(function (x) {
      if (!x) return null;
      return self.nachweisartenListe('person').then(function (arten) {
        var namen = {}; arten.forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artIds') {
              u.feld = { typ: 'text' };
              u.alt = (u.alt || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null;
              u.neu = (u.neu || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null;
            }
          });
        });
        x.arten = arten; x.namen = namen;
        return x;
      });
    });
  };

  Daten.prototype.anforderungAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.anforderungLaden(id), personenArtIds(this)]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Anforderung wurde nicht gefunden.' } };
      var p = self.pruefenAnforderung(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('anforderung', id, x, p.werte, ANF_FELDER);
    });
  };

  /* Anforderungen eines Fahrzeugs; nurGueltige blendet abgeschaltete aus. */
  Daten.prototype.anforderungenListe = function (fahrzeugId, nurGueltige) {
    var self = this;
    return Promise.all([this.speicher.wo('anforderungen', 'fahrzeugId', fahrzeugId), this.speicher.alle('verlaeufe'), this.nachweisartenListe('person')]).then(function (r) {
      var namen = {}; r[2].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      var liste = sammle(self, r[0], r[1], 'anforderung').map(function (x) {
        x.artNamen = x.aktuell.werte.artIds.map(function (i) { return namen[i] || 'unbekannte Art'; });
        return x;
      });
      return nurGueltige ? liste.filter(function (x) { return x.aktuell.werte.gilt !== 'nein'; }) : liste;
    });
  };

  /* ---------- Orte, Standorte, Gebiete und Regeln ---------- */
  var AUSGEBLENDET = { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN };
  /* Das Revier-Feld des Formulars (revierName) wird nicht gespeichert, gespeichert wird die Verknüpfung (revierId). */
  var ORT_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.ortFelder().filter(function (f) { return f.key !== 'revierName'; }), [
    { key: 'gebietId', label: 'Gebiet', typ: 'text' }, { key: 'revierId', label: 'Revier', typ: 'text' }, { key: 'ortGeprueft', label: 'Ort geprüft', typ: 'text' }, AUSGEBLENDET]);
  var STANDORT_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.standortFelder(), [AUSGEBLENDET]);
  var GEBIET_FELDER = [{ key: 'bezeichnung', label: 'Name' }].concat(MM.Orte.gebietFelder(), [AUSGEBLENDET,
    { key: 'ebene', label: 'Ebene', typ: 'text' }, { key: 'elternId', label: 'Gehört zu', typ: 'text' }, { key: 'schluessel', label: 'Schlüssel', typ: 'text' },
    { key: 'ortId', label: 'Ort', typ: 'text' }]);
  var REGEL_FELDER = [
    { key: 'bezeichnung', label: 'Bezeichnung' },
    { key: 'art', label: 'Art der Regel', typ: 'auswahl', optionen: MM.Orte.REGELARTEN },
    { key: 'pflichtAusruestung', label: 'Pflichtausrüstung', typ: 'text' },
    { key: 'menge', label: 'Menge', typ: 'ganzzahl' },
    { key: 'bezug', label: 'Bezugsgröße', typ: 'auswahl', optionen: MM.Orte.BEZUGSGROESSEN },
    { key: 'eignung', label: 'Gefordert (Eignung)', typ: 'text' },
    { key: 'fahrzeugArten', label: 'Gilt für Fahrzeugarten', typ: 'mehrfach' },
    { key: 'ausruestung', label: 'Nur mit Ausrüstung', typ: 'text' },
    { key: 'artIds', label: 'Genügt einer dieser Nachweise', typ: 'mehrfach' },
    { key: 'gilt', label: 'Gilt', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  /* Das Gebiet eines Ortes (Ebene „ort“, seit 2.0.42) trägt den Namen des Ortes und zählt beim Namensvergleich der Gebiete nicht mit. */
  function ohneOrtGebiete(liste) { return liste.filter(function (x) { return x.aktuell.werte.ebene !== 'ort'; }); }

  function gleicherName(liste, name, ausser) {
    var n = name.toLowerCase();
    return liste.some(function (x) { return x.objekt.id !== ausser && x.aktuell.werte.bezeichnung.toLowerCase() === n; });
  }

  /* Gemeinsame Prüfung für Ort, Standort und Gebiet: Name, freie Felder, „ausgeblendet“. */
  function pruefeBenannt(self, felder, roh, text) {
    var p = pruefeWerte(felder, roh, jahrVon(self), { bezeichnungFehler: text });
    p.werte.ausgeblendet = roh && roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    p.werte.herkunft = 'eigen';
    return p;
  }

  /* Position eines Ortes oder Standorts (seit 2.0.28): Breite und Länge als Dezimalgrad, beide oder keine. Gespeichert als Zahl. */
  function pruefeKoordinaten(p, roh) {
    roh = roh || {};
    var b = MM.Logbuch.koordinateLesen(roh.positionBreite, 'breite'), l = MM.Logbuch.koordinateLesen(roh.positionLaenge, 'laenge');
    p.werte.positionBreite = null; p.werte.positionLaenge = null;
    if (b.fehler) p.fehler.positionBreite = b.fehler;
    if (l.fehler) p.fehler.positionLaenge = l.fehler;
    if (!b.fehler && !l.fehler) {
      if (b.leer && !l.leer) p.fehler.positionBreite = 'Bitte auch die Breite eingeben. Breite und Länge gehören zusammen.';
      else if (l.leer && !b.leer) p.fehler.positionLaenge = 'Bitte auch die Länge eingeben. Breite und Länge gehören zusammen.';
      else if (!b.leer) { p.werte.positionBreite = b.wert; p.werte.positionLaenge = l.wert; }
    }
    p.ok = Object.keys(p.fehler).length === 0;
    return p;
  }

  Daten.prototype.pruefenOrt = function (roh) {
    var p = pruefeBenannt(this, MM.Orte.ortFelder(), roh, 'Bitte einen Namen für den Ort eingeben, zum Beispiel „Hafen Biograd“.');
    if (p.werte.telefon && !/^[0-9+\-\/() ]{5,}$/.test(p.werte.telefon)) { p.fehler.telefon = 'Bitte nur Ziffern, Leerzeichen und + - / ( ) eingeben.'; p.ok = false; }
    /* Der Name des Reviers ist nur Eingabe: Er wird beim Speichern zur Verknüpfung (revierId). null = Feld war nicht im Formular. */
    p.revierName = roh && typeof roh.revierName === 'string' ? roh.revierName.replace(/\s+/g, ' ').trim() : null;
    delete p.werte.revierName;
    return pruefeKoordinaten(p, roh);
  };
  Daten.prototype.pruefenStandort = function (roh) {
    return pruefeKoordinaten(pruefeBenannt(this, MM.Orte.standortFelder(), roh, 'Bitte einen Namen für den Standort eingeben, zum Beispiel „Liegeplatz 12“.'), roh);
  };
  Daten.prototype.pruefenGebiet = function (roh) {
    return pruefeBenannt(this, MM.Orte.gebietFelder(), roh, 'Bitte einen Namen für das Gebiet eingeben, zum Beispiel „Kroatien, Adria“.');
  };

  /* ----- Orte ----- */
  Daten.prototype.orteListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('orte'), this.speicher.alle('verlaeufe'), this.speicher.alle('standorte')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'ort');
      var anzahl = {}; r[2].forEach(function (s) { anzahl[s.ortId] = (anzahl[s.ortId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlStandorte = anzahl[x.objekt.id] || 0; });
      return liste;
    });
  };

  Daten.prototype.ortAnlegen = function (roh) {
    var self = this;
    var p = this.pruefenOrt(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    if (p.revierName) return Promise.resolve({ ok: false, fehler: { revierName: REVIER_OHNE_LAND } });
    return this.orteListe().then(function (liste) {
      if (gleicherName(liste, p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Diesen Ort gibt es schon.' } };
      /* Ohne Ortssuche bleibt der Ort ungeprüft: kein Gebiet, die Prüfung sagt dann „unklar“. */
      p.werte.gebietId = null; p.werte.revierId = null; p.werte.ortGeprueft = 'nein';
      return self.mitVerlaufAnlegen('orte', 'ort', 'or', p.werte);
    });
  };

  var REVIER_OHNE_LAND = 'Das Revier gehört zu einem Land. Prüfe den Ort zuerst über die Ortssuche, dann kann das Revier eingetragen werden.';

  /* Speichert eine Änderung am Ort zusammen mit neuen Gebieten, ganz oder gar nicht. */
  function ortAenderungSpeichern(self, id, x, neu, zusatz) {
    var gleich = !unterschiedeFelder(ORT_FELDER, x.aktuell.werte, neu).length;
    if (gleich && !zusatz.length) return Promise.resolve({ ok: true, id: id, geaendert: false });
    var liste = zusatz.slice();
    if (!gleich) liste.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ort', id, x.aktuell.nr + 1, neu, x.aktuell.id, self.jetzt()) });
    return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: id, geaendert: true }; });
  }

  Daten.prototype.ortAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', id, ORT_FELDER), this.orteListe(), this.gebieteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var p = self.pruefenOrt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(r[1], p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Diesen Ort gibt es schon.' } };
      /* Gebiet, Revier und „geprüft“ kommen aus der Ortssuche und bleiben beim Ändern der übrigen Angaben erhalten. */
      var alt = x.aktuell.werte, neu = p.werte, zusatz = [];
      neu.gebietId = alt.gebietId || null; neu.revierId = alt.revierId || null; neu.ortGeprueft = alt.ortGeprueft || 'nein';
      if (p.revierName !== null) {
        if (!p.revierName) neu.revierId = null;
        else {
          var weg = neu.gebietId ? MM.Gebiete.pfad(r[2], neu.gebietId) : [];
          if (!weg.length || weg[0].ebene !== 'land') return { ok: false, fehler: { revierName: REVIER_OHNE_LAND } };
          var rv = revierSichern(self, r[2], weg[0].id, p.revierName, self.jetzt());
          neu.revierId = rv.id; zusatz = rv.speichern;
        }
      }
      /* Hat der Ort eigene Regeln, heißt sein Gebiet wie der Ort (seit 2.0.42). */
      var wegL = neu.gebietId ? MM.Gebiete.pfad(r[2], neu.gebietId) : [];
      zusatz = zusatz.concat(ortGebietAbgleichen(self, r[2], id, neu.bezeichnung, wegL[0] && wegL[0].ebene === 'land' ? wegL[0].id : null, self.jetzt(), false).speichern);
      return ortAenderungSpeichern(self, id, x, neu, zusatz);
    });
  };

  /* Ein Ort mit seinen Standorten. */
  Daten.prototype.ortLaden = function (id) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', id, ORT_FELDER), this.standorteListe(id), this.gebieteListe()]).then(function (r) {
      if (!r[0]) return null;
      r[0].standorte = r[1];
      /* Das Gebiet des Ortes (seit 2.0.39): der Weg von oben, und das Revier, wenn es eingetragen ist. */
      var w = r[0].aktuell.werte;
      r[0].gebietPfad = w.gebietId ? MM.Gebiete.pfad(r[2], w.gebietId) : [];
      var rev = w.revierId ? MM.Gebiete.pfad(r[2], w.revierId) : [];
      r[0].revier = rev.length ? rev[rev.length - 1] : null;
      /* Eigene Regeln des Ortes (seit 2.0.42): Der Ort ist die unterste Ebene, aber nur mit eigenen Regeln. */
      var og = MM.Gebiete.ortGebiet(r[2], id);
      r[0].ortGebiet = og ? { id: og.objekt.id } : null;
      return (og ? self.regelnListe(og.objekt.id) : Promise.resolve([])).then(function (reg) { r[0].eigeneRegeln = reg; return r[0]; });
    });
  };

  /* Zu dieser Position: der nächste Ort oder Standort mit Position im Umfeld (150 m seit 2.0.101, vorher 300 m), oder null. { ortId, standortId, name, abstand } */
  Daten.prototype.ortZuPosition = function (breite, laenge) {
    if (typeof breite !== 'number' || typeof laenge !== 'number') return Promise.resolve(null);
    return Promise.all([this.orteListe(), this.standorteListe()]).then(function (r) {
      return MM.Reiseorte.naechster(MM.Reiseorte.kandidaten(r[0], r[1]), breite, laenge);
    });
  };

  /* Die Namen, die die App bei Ankünften gelernt hat und zu denen es noch keinen Ort gibt (gleicher Name, Groß- und Kleinschreibung egal). */
  Daten.prototype.gelernteNamenOffen = function () {
    return Promise.all([this.positionsnamenListe(), this.orteListe()]).then(function (r) {
      var vorhanden = {}; r[1].forEach(function (o) { vorhanden[o.aktuell.werte.bezeichnung.toLowerCase()] = true; });
      var gesehen = {}, offen = [];
      r[0].forEach(function (pt) {
        var n = String(pt.name || '').trim().toLowerCase();
        if (!n || vorhanden[n] || gesehen[n]) return;
        gesehen[n] = true; offen.push(pt);
      });
      return offen;
    });
  };

  /* Aus den gelernten Namen werden Orte (mit der gelernten Position). Alles in einem Zug, ganz oder gar nicht. */
  Daten.prototype.gelernteNamenUebernehmen = function () {
    var self = this;
    return this.gelernteNamenOffen().then(function (offen) {
      var liste = [], jetzt = self.jetzt(), angelegt = 0;
      offen.forEach(function (pt) {
        var p = self.pruefenOrt({ bezeichnung: pt.name, positionBreite: pt.breite, positionLaenge: pt.laenge });
        if (!p.ok) return;
        var o = { id: neueId('or'), datenraumId: self.datenraumId, erstelltAm: jetzt };
        liste.push({ tabelle: 'orte', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ort', o.id, 1, p.werte, null, jetzt) });
        angelegt++;
      });
      if (!liste.length) return { ok: true, angelegt: 0 };
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, angelegt: angelegt }; });
    });
  };

  /* ----- Standorte ----- */
  Daten.prototype.standorteListe = function (ortId) {
    var self = this;
    return Promise.all([this.speicher.alle('standorte'), this.speicher.alle('verlaeufe')]).then(function (r) {
      var rec = ortId ? r[0].filter(function (s) { return s.ortId === ortId; }) : r[0];
      return sammle(self, rec, r[1], 'standort');
    });
  };

  Daten.prototype.standortAnlegen = function (ortId, roh) {
    var self = this;
    return Promise.all([this.speicher.holen('orte', ortId), this.standorteListe(ortId)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var p = self.pruefenStandort(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(r[1], p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Diesen Standort gibt es an diesem Ort schon.' } };
      return self.mitVerlaufAnlegen('standorte', 'standort', 'so', p.werte, { ortId: ortId });
    });
  };

  Daten.prototype.standortLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('standorte', id, STANDORT_FELDER).then(function (x) {
      if (!x) return null;
      return self.mitVerlaufLaden('orte', x.objekt.ortId, ORT_FELDER).then(function (o) {
        x.ort = o ? { id: x.objekt.ortId, name: o.aktuell.werte.bezeichnung } : { id: x.objekt.ortId, name: 'unbekannt' };
        return x;
      });
    });
  };

  Daten.prototype.standortAendern = function (id, roh) {
    var self = this;
    return this.standortLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Standort wurde nicht gefunden.' } };
      var p = self.pruefenStandort(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.standorteListe(x.objekt.ortId).then(function (liste) {
        if (gleicherName(liste, p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Diesen Standort gibt es an diesem Ort schon.' } };
        return self.mitVerlaufAendern('standort', id, x, p.werte, STANDORT_FELDER);
      });
    });
  };

  /* ----- Heimatstandort eines Fahrzeugs (mit Verlauf, nichts wird überschrieben) ----- */
  Daten.prototype.fahrzeugStandortSetzen = function (fahrzeugId, standortId) {
    var self = this;
    standortId = standortId || null;
    return Promise.all([this.pruefeObjekt(fahrzeugId, null), standortId ? this.speicher.holen('standorte', standortId) : Promise.resolve(true),
      this.speicher.wo('verlaeufe', 'objektId', fahrzeugId)]).then(function (r) {
      if (r[0]) return { ok: false, fehler: r[0] };
      if (!r[1]) return { ok: false, fehler: { standortId: 'Dieser Standort wurde nicht gefunden.' } };
      var alt = r[2].filter(function (e) { return e.objektTyp === 'fahrzeugstandort'; }).sort(nachNr);
      var letzter = alt[alt.length - 1] || null;
      var bisher = letzter ? letzter.werte.standortId : null;
      if (bisher === standortId) return { ok: true, id: fahrzeugId, geaendert: false };
      var e = neuerVerlaufEintrag('fahrzeugstandort', fahrzeugId, letzter ? letzter.nr + 1 : 1, { standortId: standortId }, letzter ? letzter.id : null, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: fahrzeugId, geaendert: true }; });
    });
  };

  /* Heimatstandort eines Fahrzeugs: { standort: {id, name, ortId, ortName} | null, verlauf: [{ ... }] } */
  Daten.prototype.fahrzeugStandort = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.speicher.wo('verlaeufe', 'objektId', fahrzeugId), this.standorteListe(), this.orteListe()]).then(function (r) {
      var alt = r[0].filter(function (e) { return e.objektTyp === 'fahrzeugstandort'; }).sort(nachNr);
      var namen = {};
      r[1].forEach(function (s) {
        var o = r[2].filter(function (x) { return x.objekt.id === s.objekt.ortId; })[0];
        namen[s.objekt.id] = { id: s.objekt.id, name: s.aktuell.werte.bezeichnung, ortId: s.objekt.ortId, ortName: o ? o.aktuell.werte.bezeichnung : 'unbekannt' };
      });
      function text(id) { return id ? (namen[id] ? namen[id].ortName + ', ' + namen[id].name : 'unbekannt') : 'keiner'; }
      var verlauf = alt.map(function (e, i) { return { eintrag: e, alt: i ? text(alt[i - 1].werte.standortId) : null, neu: text(e.werte.standortId) }; }).reverse();
      var letzter = alt[alt.length - 1];
      return { standort: letzter && letzter.werte.standortId && namen[letzter.werte.standortId] ? namen[letzter.werte.standortId] : null, verlauf: verlauf };
    });
  };

  /* ----- Gebiete ----- */
  Daten.prototype.gebieteListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('gebiete'), this.speicher.alle('verlaeufe'), this.speicher.alle('regeln')]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'gebiet');
      var anzahl = {}; r[2].forEach(function (g) { anzahl[g.gebietId] = (anzahl[g.gebietId] || 0) + 1; });
      liste.forEach(function (x) { x.anzahlRegeln = anzahl[x.objekt.id] || 0; });
      return liste;
    });
  };

  Daten.prototype.gebietAnlegen = function (roh) {
    var self = this;
    var p = this.pruefenGebiet(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.gebieteListe().then(function (liste) {
      if (gleicherName(ohneOrtGebiete(liste), p.werte.bezeichnung)) return { ok: false, fehler: { bezeichnung: 'Dieses Gebiet gibt es schon.' } };
      return self.mitVerlaufAnlegen('gebiete', 'gebiet', 'ge', p.werte);
    });
  };

  Daten.prototype.gebietAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('gebiete', id, GEBIET_FELDER), this.gebieteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Gebiet wurde nicht gefunden.' } };
      var p = self.pruefenGebiet(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      if (gleicherName(ohneOrtGebiete(r[1]), p.werte.bezeichnung, id)) return { ok: false, fehler: { bezeichnung: 'Dieses Gebiet gibt es schon.' } };
      /* Ebene, Zugehörigkeit, Schlüssel, Ort und Herkunft kommen aus der Ortssuche und bleiben beim Umbenennen erhalten. */
      ['ebene', 'elternId', 'schluessel', 'ortId'].forEach(function (k) { if (x.aktuell.werte[k] !== undefined) p.werte[k] = x.aktuell.werte[k]; });
      /* Das Gebiet eines Ortes heißt wie der Ort. Umbenannt wird beim Ort. */
      if (x.aktuell.werte.ebene === 'ort') p.werte.bezeichnung = x.aktuell.werte.bezeichnung;
      if (x.aktuell.werte.herkunft) p.werte.herkunft = x.aktuell.werte.herkunft;
      return self.mitVerlaufAendern('gebiet', id, x, p.werte, GEBIET_FELDER);
    });
  };

  /* Ein Gebiet mit seinen Regeln. */
  Daten.prototype.gebietLaden = function (id) {
    return Promise.all([this.mitVerlaufLaden('gebiete', id, GEBIET_FELDER), this.regelnListe(id), this.gebieteListe(), this.orteListe()]).then(function (r) {
      if (!r[0]) return null;
      r[0].regeln = r[1];
      /* Das Gebiet eines Ortes (seit 2.0.42) verweist auf seinen Ort. */
      var ortId = r[0].aktuell.werte.ebene === 'ort' ? r[0].aktuell.werte.ortId : null;
      var ortX = ortId ? r[3].filter(function (o) { return o.objekt.id === ortId; })[0] : null;
      r[0].ort = ortX ? { id: ortId, name: ortX.aktuell.werte.bezeichnung } : null;
      /* Weg von oben und die Gebiete darunter (seit 2.0.39) */
      r[0].pfad = MM.Gebiete.pfad(r[2], id);
      r[0].unter = r[2].filter(function (x) { return x.aktuell.werte.elternId === id; }).map(function (x) { return { id: x.objekt.id, name: x.aktuell.werte.bezeichnung }; });
      return r[0];
    });
  };


  /* ---------- Ortssuche und Gebiete aus Orten (seit 2.0.39) ----------
   * Der Nutzer gibt nur Orte ein. Die Ortssuche liefert Treffer, aus dem gewählten Treffer entsteht die Kette
   * Land > Region > Kreis. Jedes Gebiet wird beim ersten Mal gespeichert und danach wiederverwendet. */
  Daten.prototype.ortSuchen = function (suche) { return MM.Ortssuche.suchen(suche, this.holeJson); };

  /* Baut die Kette. Was es schon gibt (gleicher Schlüssel), wird wiederverwendet. Ein eigenes Gebiet ohne Ebene mit dem
     gleichen Namen übernimmt die Ebene, seine Regeln bleiben. Nur Beschreibung, gespeichert wird später in einem Zug. */
  function gebietKetteBauen(self, liste, kette, jetzt) {
    var nachSchluessel = {}, frei = {};
    liste.forEach(function (x) {
      var w = x.aktuell.werte;
      if (w.schluessel) nachSchluessel[w.schluessel] = x;
      else if (!w.ebene) { var n = String(w.bezeichnung).toLowerCase(); (frei[n] = frei[n] || []).push(x); }
    });
    var speichern = [], ids = [], eltern = null, elternSchl = '', neu = 0, uebernommen = 0;
    kette.forEach(function (g) {
      var key = MM.Gebiete.schluessel(elternSchl, g.ebene, g.name, g.code), x = nachSchluessel[key], id;
      if (x) id = x.objekt.id;
      else {
        var f = (frei[String(g.name).toLowerCase()] || []).filter(function (y) { return !y.vergeben; })[0];
        if (f) {
          f.vergeben = true; id = f.objekt.id;
          var w2 = Object.assign({}, f.aktuell.werte, { ebene: g.ebene, elternId: eltern, schluessel: key });
          speichern.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('gebiet', id, f.aktuell.nr + 1, w2, f.aktuell.id, jetzt) });
          uebernommen++;
        } else {
          var o = { id: neueId('ge'), datenraumId: self.datenraumId, erstelltAm: jetzt };
          id = o.id;
          var w3 = { bezeichnung: g.name, notiz: null, ausgeblendet: 'nein', herkunft: 'ortssuche', ebene: g.ebene, elternId: eltern, schluessel: key };
          speichern.push({ tabelle: 'gebiete', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('gebiet', id, 1, w3, null, jetzt) });
          neu++;
        }
      }
      ids.push(id); eltern = id; elternSchl = key;
    });
    return { speichern: speichern, ids: ids, blatt: ids[ids.length - 1], neu: neu, uebernommen: uebernommen };
  }

  /* Ein Revier (Binnenwasserstraße) unter einem Land: vorhanden oder neu. */
  function revierSichern(self, liste, landId, name, jetzt) {
    var land = liste.filter(function (x) { return x.objekt.id === landId; })[0];
    var key = MM.Gebiete.schluessel(land ? land.aktuell.werte.schluessel : '', 'revier', name);
    var da = liste.filter(function (x) { return x.aktuell.werte.schluessel === key; })[0];
    if (da) return { id: da.objekt.id, speichern: [], neu: false };
    var o = { id: neueId('ge'), datenraumId: self.datenraumId, erstelltAm: jetzt };
    var w = { bezeichnung: name, notiz: null, ausgeblendet: 'nein', herkunft: 'eigen', ebene: 'revier', elternId: landId, schluessel: key };
    return { id: o.id, neu: true, speichern: [{ tabelle: 'gebiete', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('gebiet', o.id, 1, w, null, jetzt) }] };
  }

  /* Das Gebiet eines Ortes (Ebene „ort“, seit 2.0.42): die unterste Ebene der Kette (Land > Region > Kreis > Ort, Land > Revier > Ort).
     Es entsteht erst mit der ersten eigenen Regel des Ortes (anlegen = true). Name und Land ziehen mit dem Ort mit.
     Nur Beschreibung, gespeichert wird später in einem Zug. */
  function ortGebietAbgleichen(self, liste, ortId, name, landId, jetzt, anlegen) {
    var da = MM.Gebiete.ortGebiet(liste, ortId);
    if (da) {
      var w = da.aktuell.werte, neuName = name || w.bezeichnung, neuEltern = landId || w.elternId || null;
      if (w.bezeichnung === neuName && (w.elternId || null) === neuEltern) return { id: da.objekt.id, speichern: [], neu: false };
      var w2 = Object.assign({}, w, { bezeichnung: neuName, elternId: neuEltern });
      return { id: da.objekt.id, neu: false, speichern: [{ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('gebiet', da.objekt.id, da.aktuell.nr + 1, w2, da.aktuell.id, jetzt) }] };
    }
    if (!anlegen) return { id: null, speichern: [], neu: false };
    var o = { id: neueId('ge'), datenraumId: self.datenraumId, erstelltAm: jetzt };
    var w3 = { bezeichnung: name, notiz: null, ausgeblendet: 'nein', herkunft: 'eigen', ebene: 'ort', elternId: landId || null, schluessel: 'ort:' + ortId, ortId: ortId };
    return { id: o.id, neu: true, speichern: [{ tabelle: 'gebiete', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('gebiet', o.id, 1, w3, null, jetzt) }] };
  }

  var ORT_REGEL_OHNE_LAND = 'Eine eigene Regel gibt es erst, wenn der Ort geprüft ist, denn sie hängt unter dem Land des Ortes. Prüfe den Ort zuerst über die Ortssuche („Ort prüfen“).';

  /* Eine eigene Regel für einen Ort (seit 2.0.42). Der Ort wird zur untersten Ebene der Kette. Das Gebiet des Ortes entsteht mit der
     ersten Regel, vorher gibt es keins: Ohne eigene Regel gelten die Regeln der Ebenen darüber. Gebiet und Regel in einem Zug. */
  Daten.prototype.ortRegelAnlegen = function (ortId, roh) {
    var self = this;
    return Promise.all([this.mitVerlaufLaden('orte', ortId, ORT_FELDER), this.gebieteListe(), personenArtIds(this)]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var w = x.aktuell.werte, weg = w.gebietId ? MM.Gebiete.pfad(r[1], w.gebietId) : [];
      if (!weg.length || weg[0].ebene !== 'land') return { ok: false, fehler: { allgemein: ORT_REGEL_OHNE_LAND } };
      var p = self.pruefenRegel(roh, r[2]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var jetzt = self.jetzt();
      var g = ortGebietAbgleichen(self, r[1], ortId, w.bezeichnung, weg[0].id, jetzt, true);
      var rg = { id: neueId('rg'), datenraumId: self.datenraumId, erstelltAm: jetzt, gebietId: g.id };
      var liste = g.speichern.concat([{ tabelle: 'regeln', objekt: rg }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('regel', rg.id, 1, p.werte, null, jetzt) }]);
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: rg.id, gebietId: g.id, gebietNeu: g.neu }; });
    });
  };

  /* Die Kette sichern (ohne Ort), zum Beispiel für Tests oder später für den Reisecheck. */
  Daten.prototype.gebietKetteSichern = function (kette) {
    var self = this;
    return this.gebieteListe().then(function (liste) {
      var b = gebietKetteBauen(self, liste, kette, self.jetzt());
      var fertig = { ok: true, ids: b.ids, blatt: b.blatt, neu: b.neu, uebernommen: b.uebernommen };
      return b.speichern.length ? self.speicher.mehrereSpeichern(b.speichern).then(function () { return fertig; }) : fertig;
    });
  };

  /* Aus einem gewählten Treffer der Ortssuche entsteht ein neuer Ort mit seinem Gebiet. Gibt es den Namen schon, hängt die
     App das Gebiet an („Eutingen (Enzkreis)“), damit zwei Orte gleichen Namens nebeneinander bestehen. */
  Daten.prototype.ortAusTreffer = function (k) {
    var self = this;
    if (!k || !k.name || !k.land) return Promise.resolve({ ok: false, fehler: { allgemein: 'Der Treffer ist unvollständig.' } });
    return Promise.all([this.gebieteListe(), this.orteListe()]).then(function (r) {
      var b = gebietKetteBauen(self, r[0], MM.Ortssuche.kette(k), self.jetzt());
      var bestehende = r[1].filter(function (o) { return o.aktuell.werte.gebietId === b.blatt && o.aktuell.werte.bezeichnung.toLowerCase().indexOf(k.name.toLowerCase()) === 0
        && typeof o.aktuell.werte.positionBreite === 'number' && Math.abs(o.aktuell.werte.positionBreite - k.breite) < 0.02 && Math.abs(o.aktuell.werte.positionLaenge - k.laenge) < 0.02; })[0];
      if (bestehende) return { ok: true, id: bestehende.objekt.id, vorhanden: true, name: bestehende.aktuell.werte.bezeichnung };
      var name = k.name;
      if (gleicherName(r[1], name)) name = k.name + ' (' + (k.kreis || k.region || k.land) + ')';
      if (gleicherName(r[1], name)) name = k.name + ' (' + [k.kreis, k.region, k.land].filter(Boolean).join(', ') + ')';
      if (gleicherName(r[1], name)) return { ok: false, fehler: { allgemein: 'Diesen Ort gibt es schon.' } };
      var p = self.pruefenOrt({ bezeichnung: name, land: k.land, positionBreite: k.breite, positionLaenge: k.laenge });
      if (!p.ok) return { ok: false, fehler: p.fehler };
      p.werte.gebietId = b.blatt; p.werte.revierId = null; p.werte.ortGeprueft = 'ja';
      var jetzt = self.jetzt(), o = { id: neueId('or'), datenraumId: self.datenraumId, erstelltAm: jetzt };
      var liste = b.speichern.concat([{ tabelle: 'orte', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ort', o.id, 1, p.werte, null, jetzt) }]);
      return self.speicher.mehrereSpeichern(liste).then(function () {
        return { ok: true, id: o.id, vorhanden: false, name: name, gebiete: { neu: b.neu, uebernommen: b.uebernommen, ids: b.ids } };
      });
    });
  };

  /* Einen schon vorhandenen Ort nachträglich prüfen: der gewählte Treffer gibt ihm das Gebiet. Name, Notizen und Kosten bleiben,
     Land und Position werden nur ergänzt, wenn sie fehlen. */
  Daten.prototype.ortPruefungUebernehmen = function (id, k) {
    var self = this;
    if (!k || !k.name || !k.land) return Promise.resolve({ ok: false, fehler: { allgemein: 'Der Treffer ist unvollständig.' } });
    return Promise.all([this.mitVerlaufLaden('orte', id, ORT_FELDER), this.gebieteListe()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Ort wurde nicht gefunden.' } };
      var b = gebietKetteBauen(self, r[1], MM.Ortssuche.kette(k), self.jetzt());
      var neu = Object.assign({}, x.aktuell.werte);
      neu.gebietId = b.blatt; neu.ortGeprueft = 'ja';
      if (!neu.land) neu.land = k.land;
      if (typeof neu.positionBreite !== 'number' || typeof neu.positionLaenge !== 'number') { neu.positionBreite = k.breite; neu.positionLaenge = k.laenge; }
      /* Ein Revier gilt nur unter seinem Land. Wechselt das Land, fällt das Revier weg. */
      if (neu.revierId) {
        var rv = r[1].filter(function (g) { return g.objekt.id === neu.revierId; })[0];
        if (!rv || rv.aktuell.werte.elternId !== b.ids[0]) neu.revierId = null;
      }
      /* Hat der Ort eigene Regeln, hängt sein Gebiet nun unter dem neuen Land (seit 2.0.42). */
      var og = ortGebietAbgleichen(self, r[1], id, neu.bezeichnung, b.ids[0], self.jetzt(), false);
      return ortAenderungSpeichern(self, id, x, neu, b.speichern.concat(og.speichern)).then(function (res) {
        res.gebiete = { neu: b.neu, uebernommen: b.uebernommen, ids: b.ids };
        return res;
      });
    });
  };

  /* Welche Arten von Fahrzeugen gibt es im Konto? ['land', 'wasser', 'luft'] */
  Daten.prototype.kontoWelten = function () {
    return this.fahrzeugListe().then(function (liste) {
      var w = [];
      liste.forEach(function (x) { var a = MM.Fahrzeugarten.art(x.fahrzeug.art); var welt = a ? a.welt : 'land'; if (w.indexOf(welt) < 0) w.push(welt); });
      return w;
    });
  };

  /* Die Reviere unter einem Land (für die Vorschlagsliste beim Ort). */
  Daten.prototype.reviereZuLand = function (landId) {
    return this.gebieteListe().then(function (liste) {
      return liste.filter(function (x) { return x.aktuell.werte.ebene === 'revier' && x.aktuell.werte.elternId === landId && x.aktuell.werte.ausgeblendet !== 'ja'; })
        .map(function (x) { return x.aktuell.werte.bezeichnung; });
    });
  };

  /* ----- Regeln: WENN Gebiet, Fahrzeugart und Ausrüstung passen, DANN genügt einer der Nachweise ----- */
  function fahrzeugArtIds() { return MM.Fahrzeugarten.alle(true).map(function (a) { return a.id; }); }

  Daten.prototype.pruefenRegel = function (roh, personenArten) {
    roh = roh || {};
    var f = {}, w = {};
    w.bezeichnung = trimmed(roh.bezeichnung);
    if (!w.bezeichnung) f.bezeichnung = 'Bitte eine Bezeichnung eingeben, zum Beispiel „Funkzeugnis auf See“.';
    var fa = Array.isArray(roh.fahrzeugArten) ? roh.fahrzeugArten : [];
    w.fahrzeugArten = fahrzeugArtIds().filter(function (a) { return fa.indexOf(a) >= 0; });
    w.art = MM.Orte.regelArt(roh);
    if (w.art === 'ausruestung') {
      /* Pflichtausrüstung: Was muss am Fahrzeug eingetragen sein? Eine Bedingung „Ausrüstung“ und Nachweise gibt es hier nicht. */
      w.pflichtAusruestung = trimmed(roh.pflichtAusruestung) || null;
      if (!w.pflichtAusruestung) f.pflichtAusruestung = 'Bitte eintragen, was am Fahrzeug sein muss, zum Beispiel „Rettungsweste“.';
      w.ausruestung = null;
      w.artIds = [];
      /* Menge (ganze Zahl ab 1, leer = 1), Bezugsgröße und freiwillig die geforderte Eignung */
      var mt = String(roh.menge === undefined || roh.menge === null ? '' : roh.menge).trim();
      if (mt === '') { w.menge = 1; }
      else if (!/^\d+$/.test(mt) || Number(mt) < 1) { w.menge = 1; f.menge = 'Bitte eine ganze Zahl ab 1 eingeben, zum Beispiel 6.'; }
      else { w.menge = Number(mt); }
      w.bezug = MM.Orte.bezugsgroesse(roh);
      w.eignung = trimmed(roh.eignung) || null;
    } else {
      w.pflichtAusruestung = null;
      w.menge = null; w.bezug = null; w.eignung = null;
      w.ausruestung = trimmed(roh.ausruestung) || null;
      var gew = Array.isArray(roh.artIds) ? roh.artIds : [];
      w.artIds = personenArten.filter(function (a) { return gew.indexOf(a) >= 0; });
      if (!w.artIds.length) f.artIds = 'Bitte mindestens eine Art von Nachweis wählen, die genügt.';
    }
    w.gilt = roh.gilt === 'nein' ? 'nein' : 'ja';
    w.herkunft = 'eigen';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.regelAnlegen = function (gebietId, roh) {
    var self = this;
    return Promise.all([this.speicher.holen('gebiete', gebietId), personenArtIds(this)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieses Gebiet wurde nicht gefunden.' } };
      var p = self.pruefenRegel(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAnlegen('regeln', 'regel', 'rg', p.werte, { gebietId: gebietId });
    });
  };

  Daten.prototype.regelAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.regelLaden(id), personenArtIds(this)]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Regel wurde nicht gefunden.' } };
      if (MM.Orte.istReisecheckRegel(x.aktuell.werte)) return { ok: false, fehler: { allgemein: 'Eine Regel aus einem Reisecheck lässt sich nicht ändern. Du kannst sie abschalten.' } };
      if (!x.aktuell.werte.art) x.aktuell.werte = Object.assign({ art: 'befaehigung' }, x.aktuell.werte);
      if (x.aktuell.werte.art === 'ausruestung') x.aktuell.werte = Object.assign({ menge: 1, bezug: 'fahrzeug', eignung: null }, x.aktuell.werte);
      else x.aktuell.werte = Object.assign({ menge: null, bezug: null, eignung: null }, x.aktuell.werte);
      var p = self.pruefenRegel(roh, r[1]);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      return self.mitVerlaufAendern('regel', id, x, p.werte, REGEL_FELDER);
    });
  };

  Daten.prototype.regelLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('regeln', id, REGEL_FELDER).then(function (x) {
      if (!x) return null;
      return Promise.all([self.nachweisartenListe('person'), self.mitVerlaufLaden('gebiete', x.objekt.gebietId, GEBIET_FELDER)]).then(function (r) {
        var namen = {}; r[0].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        function arten(l) { return (l || []).map(function (a) { var z = MM.Fahrzeugarten.art(a); return z ? z.name : a; }).join(', ') || null; }
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artIds') { u.feld = { typ: 'text' }; u.alt = (u.alt || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null; u.neu = (u.neu || []).map(function (i) { return namen[i] || 'unbekannt'; }).join(', ') || null; }
            if (u.key === 'fahrzeugArten') { u.feld = { typ: 'text' }; u.alt = arten(u.alt); u.neu = arten(u.neu); }
            if (u.key === 'bezug') { u.feld = { typ: 'text' }; u.alt = u.alt ? (u.alt === 'person' ? 'je Person an Bord' : 'je Fahrzeug') : null; u.neu = u.neu ? (u.neu === 'person' ? 'je Person an Bord' : 'je Fahrzeug') : null; }
            if (u.key === 'art') { u.feld = { typ: 'text' }; u.alt = u.alt ? (u.alt === 'ausruestung' ? 'Pflichtausrüstung' : 'Befähigung') : 'Befähigung'; u.neu = u.neu === 'ausruestung' ? 'Pflichtausrüstung' : 'Befähigung'; }
          });
        });
        x.arten = r[0]; x.namen = namen;
        x.gebiet = { id: x.objekt.gebietId, name: r[1] ? r[1].aktuell.werte.bezeichnung : 'unbekannt', ortId: r[1] && r[1].aktuell.werte.ebene === 'ort' ? r[1].aktuell.werte.ortId || null : null };
        return x;
      });
    });
  };

  /* Regeln eines Gebiets (oder aller), mit Namen der Nachweisarten. */
  Daten.prototype.regelnListe = function (gebietId) {
    var self = this;
    return Promise.all([this.speicher.alle('regeln'), this.speicher.alle('verlaeufe'), this.nachweisartenListe('person')]).then(function (r) {
      var rec = gebietId ? r[0].filter(function (g) { return g.gebietId === gebietId; }) : r[0];
      var namen = {}; r[2].forEach(function (a) { namen[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      return sammle(self, rec, r[1], 'regel').map(function (x) {
        x.artNamen = x.aktuell.werte.artIds.map(function (i) { return namen[i] || 'unbekannte Art'; });
        x.fahrzeugArtNamen = (x.aktuell.werte.fahrzeugArten || []).map(function (a) { var z = MM.Fahrzeugarten.art(a); return z ? z.name : a; });
        return x;
      });
    });
  };

  /* ---------- Aktivitäten ---------- */
  var AKT_FELDER = [
    { key: 'bezeichnung', label: 'Name' },
    { key: 'artId', label: 'Art', typ: 'text' },
    { key: 'fahrzeugId', label: 'Fahrzeug', typ: 'text' },
    { key: 'vonDatum', label: 'Von (Datum)', typ: 'datum' },
    { key: 'vonZeit', label: 'Von (Uhrzeit)', typ: 'zeit' },
    { key: 'bisDatum', label: 'Bis (Datum)', typ: 'datum' },
    { key: 'bisZeit', label: 'Bis (Uhrzeit)', typ: 'zeit' },
    { key: 'gebiet', label: 'Gebiet (Text)', typ: 'text' },
    { key: 'gebietId', label: 'Gebiet', typ: 'text' },
    { key: 'geplanteStrecke', label: 'Geplante Strecke', typ: 'zahl' },
    { key: 'geplanteStunden', label: 'Geplante Betriebsstunden', typ: 'zahl' },
    { key: 'startOrtId', label: 'Start', typ: 'text' },
    { key: 'zielOrtId', label: 'Ziel', typ: 'text' },
    { key: 'zwischenzielIds', label: 'Zwischenziele', typ: 'mehrfach' },
    { key: 'tierIds', label: 'Tiere', typ: 'mehrfach' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'status', label: 'Status', typ: 'text' },
    { key: 'stornoGrund', label: 'Grund der Stornierung', typ: 'text' },
    { key: 'sperreUebergangenAm', label: 'Sperre übergangen am', typ: 'text' }
  ];

  Daten.prototype.aktivitaetKontext = function () {
    return Promise.all([this.aktivitaetsartenListe(), this.fahrzeugListe(), this.tiereListe(), this.personenListe(), this.gebieteListe(), this.orteListe()]).then(function (r) {
      return { arten: r[0], fahrzeuge: r[1], tiere: r[2], personen: r[3], gebiete: r[4], orte: r[5] };
    });
  };

  function planOrtOptionen(ctx, gewaehlt) {
    return (ctx.orte || []).filter(function (o) { return o.aktuell.werte.ausgeblendet !== 'ja' || gewaehlt.indexOf(o.objekt.id) >= 0; })
      .map(function (o) { return { wert: o.objekt.id, label: o.aktuell.werte.bezeichnung }; });
  }

  Daten.prototype.pruefenAktivitaet = function (roh, ctx, neu) {
    roh = roh || {};
    var gewaehlteArt = roh.artId;
    var felder = [
      { key: 'artId', typ: 'auswahl', optionen: ctx.arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || a.objekt.id === gewaehlteArt; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; }) },
      { key: 'fahrzeugId', typ: 'auswahl', optionen: ctx.fahrzeuge.map(function (x) { return { wert: x.fahrzeug.id, label: x.aktuell.werte.bezeichnung }; }) },
      { key: 'vonDatum', typ: 'datum' }, { key: 'vonZeit', typ: 'zeit' }, { key: 'bisDatum', typ: 'datum' }, { key: 'bisZeit', typ: 'zeit' },
      { key: 'gebiet', typ: 'text' },
      { key: 'gebietId', typ: 'auswahl', optionen: (ctx.gebiete || []).filter(function (g) { return g.aktuell.werte.ausgeblendet !== 'ja' || g.objekt.id === roh.gebietId; })
        .map(function (g) { return { wert: g.objekt.id, label: g.aktuell.werte.bezeichnung }; }) },
      { key: 'geplanteStrecke', typ: 'zahl', min: 0 }, { key: 'geplanteStunden', typ: 'zahl', min: 0 },
      /* Reiseplan (seit 2.0.28): Start, Ziel und Zwischenziele sind Orte aus der Orte-Liste. Ausgeblendete Orte bleiben nur, wenn sie schon gewählt waren. */
      { key: 'startOrtId', typ: 'auswahl', optionen: planOrtOptionen(ctx, [roh.startOrtId]) },
      { key: 'zielOrtId', typ: 'auswahl', optionen: planOrtOptionen(ctx, [roh.zielOrtId]) },
      { key: 'zwischenzielIds', typ: 'reihenfolge', optionen: planOrtOptionen(ctx, Array.isArray(roh.zwischenzielIds) ? roh.zwischenzielIds : []) },
      { key: 'tierIds', typ: 'mehrfach', optionen: ctx.tiere.map(function (t) { return { wert: t.objekt.id, label: t.aktuell.werte.bezeichnung }; }) },
      { key: 'notiz', typ: 'text' }
    ];
    var p = pruefeWerte(felder, roh, jahrVon(this), { bezeichnungFehler: 'Bitte einen Namen für die Aktivität eingeben, zum Beispiel „Sommertörn Kroatien“.' });
    var w = p.werte, f = p.fehler;
    if (!w.artId && !f.artId) f.artId = ctx.arten.length ? 'Bitte die Art der Aktivität wählen.' : 'Es gibt noch keine Art. Übernimm zuerst die Vorschläge oder lege eine Art an.';
    if (!w.fahrzeugId && !f.fahrzeugId) f.fahrzeugId = ctx.fahrzeuge.length ? 'Bitte das Fahrzeug wählen.' : 'Es gibt noch kein Fahrzeug. Lege zuerst ein Fahrzeug an.';
    if (!w.vonDatum && !f.vonDatum) f.vonDatum = 'Bitte das Datum angeben, an dem es losgeht.';
    if (!w.bisDatum && !f.bisDatum) f.bisDatum = 'Bitte das Datum angeben, an dem es endet.';
    if (w.vonDatum && w.bisDatum && !f.bisDatum) {
      if (w.bisDatum < w.vonDatum) f.bisDatum = 'Das Ende liegt vor dem Beginn.';
      else if (w.bisDatum === w.vonDatum && w.vonZeit && w.bisZeit && w.bisZeit < w.vonZeit && !f.bisZeit) f.bisZeit = 'Die Uhrzeit des Endes liegt vor der des Beginns.';
    }
    /* Zwischenziele (seit 2.0.123): so viele wie die Aktivität Tage hat (Datumsspanne), höchstens 25. */
    if (w.zwischenzielIds && w.zwischenzielIds.length && !f.zwischenzielIds) {
      var datumOk = w.vonDatum && w.bisDatum && !f.vonDatum && !f.bisDatum;
      var grenzText = !MM.Routen ? null : MM.Routen.zwischenzielGrenzeText(w.zwischenzielIds.length, datumOk ? w.vonDatum : null, datumOk ? w.bisDatum : null);
      if (grenzText) f.zwischenzielIds = grenzText;
    }
    if (neu) {
      var pid = roh.verantwortlichId;
      if (!ctx.personen.some(function (x) { return x.objekt.id === pid; })) {
        f.verantwortlichId = ctx.personen.length ? 'Bitte wählen, wer verantwortlich ist.' : 'Es gibt noch keine Person. Lege zuerst die Besatzung an.';
      }
    }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  Daten.prototype.aktivitaetAnlegen = function (roh) {
    var self = this;
    return this.aktivitaetKontext().then(function (ctx) {
      var p = self.pruefenAktivitaet(roh, ctx, true);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var w = p.werte, jetzt = self.jetzt();
      w.status = 'geplant'; w.stornoGrund = null; w.stornoAm = null; w.sperreUebergangenAm = null;
      var a = { id: neueId('ak'), datenraumId: self.datenraumId, erstelltAm: jetzt };
      var b = { id: neueId('be'), aktivitaetId: a.id, personId: roh.verantwortlichId, erstelltAm: jetzt };
      var v = { id: neueId('ve'), aktivitaetId: a.id, personId: roh.verantwortlichId, ab: MM.Aktivitaeten.von(w), erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'aktivitaeten', objekt: a },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('aktivitaet', a.id, 1, w, null, jetzt) },
        { tabelle: 'besatzung', objekt: b },
        { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besatzung', b.id, 1, { rolle: 'verantwortlich', dabeiVonDatum: null, dabeiVonZeit: null, dabeiBisDatum: null, dabeiBisZeit: null, entfernt: 'nein' }, null, jetzt) },
        { tabelle: 'verantwortung', objekt: v }
      ]).then(function () { return { ok: true, id: a.id }; });
    });
  };

  Daten.prototype.aktivitaetAendern = function (id, roh) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(id), this.aktivitaetKontext()]).then(function (r) {
      var x = r[0], ctx = r[1];
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (x.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenAktivitaet(roh, ctx, false);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var alt = x.aktuell.werte;
      var neu = Object.assign({}, alt, p.werte);
      var zeitraumGeaendert = ['fahrzeugId', 'vonDatum', 'vonZeit', 'bisDatum', 'bisZeit', 'geplanteStrecke', 'geplanteStunden'].some(function (k) { return !gleich(alt[k], neu[k]); });
      if (zeitraumGeaendert) neu.sperreUebergangenAm = null;
      return self.mitVerlaufAendern('aktivitaet', id, { aktuell: x.aktuell }, neu, AKT_FELDER);
    });
  };

  function aktivitaetNeuerStand(self, id, aenderung) {
    return self.mitVerlaufLaden('aktivitaeten', id, []).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var neu = aenderung(Object.assign({}, x.aktuell.werte));
      if (neu.fehler) return { ok: false, fehler: neu.fehler };
      return self.mitVerlaufAendern('aktivitaet', id, { aktuell: x.aktuell }, neu.werte, AKT_FELDER);
    });
  }

  /* Stornieren: Nichts wird gelöscht, der Status heißt "storniert". */
  Daten.prototype.aktivitaetStornieren = function (id, grund) {
    var self = this;
    return aktivitaetNeuerStand(this, id, function (w) {
      if (w.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist schon storniert.' } };
      w.status = 'storniert'; w.stornoGrund = trimmed(grund) || null; w.stornoAm = self.jetzt();
      return { werte: w };
    });
  };
  Daten.prototype.aktivitaetWiederherstellen = function (id) {
    return aktivitaetNeuerStand(this, id, function (w) {
      if (w.status !== 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist nicht storniert.' } };
      w.status = 'geplant'; w.stornoGrund = null; w.stornoAm = null;
      return { werte: w };
    });
  };
  /* Eine Sperre durch eine Frist ausdrücklich übergehen. Zeit wird festgehalten. */
  Daten.prototype.aktivitaetSperreUebergehen = function (id) {
    var self = this;
    return aktivitaetNeuerStand(this, id, function (w) { w.sperreUebergangenAm = self.jetzt(); return { werte: w }; });
  };

  /* ---------- Besatzung und Verantwortung ---------- */
  var BES_FELDER = [
    { key: 'rolle', label: 'Rolle', typ: 'text' },
    { key: 'dabeiVonDatum', label: 'Dabei von (Datum)', typ: 'datum' }, { key: 'dabeiVonZeit', label: 'Dabei von (Uhrzeit)', typ: 'zeit' },
    { key: 'dabeiBisDatum', label: 'Dabei bis (Datum)', typ: 'datum' }, { key: 'dabeiBisZeit', label: 'Dabei bis (Uhrzeit)', typ: 'zeit' },
    { key: 'entfernt', label: 'Nicht mehr dabei', typ: 'text' }
  ];

  Daten.prototype.pruefenBesatzung = function (roh) {
    roh = roh || {};
    var felder = [{ key: 'dabeiVonDatum', typ: 'datum' }, { key: 'dabeiVonZeit', typ: 'zeit' }, { key: 'dabeiBisDatum', typ: 'datum' }, { key: 'dabeiBisZeit', typ: 'zeit' }];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    var rolle = roh.rolle;
    if (rolle !== 'stellvertreter' && rolle !== 'crew' && rolle !== 'verantwortlich') f.rolle = 'Bitte wählen: Stellvertreter oder Crew.';
    else w.rolle = rolle;
    if (w.dabeiVonDatum && w.dabeiBisDatum && w.dabeiBisDatum < w.dabeiVonDatum && !f.dabeiBisDatum) f.dabeiBisDatum = 'Das Ende liegt vor dem Beginn.';
    w.entfernt = roh.entfernt === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Wer hängt gerade an der Verantwortung (letzter Eintrag der Verantwortung)? */
  function letzteVerantwortung(eintraege) {
    return eintraege.slice().sort(function (a, b) { return a.ab < b.ab ? -1 : (a.ab > b.ab ? 1 : 0); }).pop() || null;
  }

  Daten.prototype.besatzungHinzufuegen = function (aktivitaetId, personId, roh) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.personLaden(personId)]).then(function (r) {
      var a = r[0], person = r[1];
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (!person) return { ok: false, fehler: { personId: 'Bitte eine Person wählen.' } };
      var p = self.pruefenBesatzung(roh);
      if (p.werte.rolle === 'verantwortlich') p.fehler.rolle = 'Die verantwortliche Person wird über „Verantwortlicher Wechsel“ bestimmt.';
      if (Object.keys(p.fehler).length) return { ok: false, fehler: p.fehler };
      var vorhanden = a.besatzung.concat(a.entfernte).filter(function (b) { return b.besatzung.personId === personId; })[0];
      if (vorhanden && vorhanden.aktuell.werte.entfernt !== 'ja') return { ok: false, fehler: { personId: 'Diese Person ist schon dabei.' } };
      if (vorhanden) {
        /* Wieder aufnehmen: neuer Eintrag, die frühere Zeit bleibt sichtbar */
        return self.mitVerlaufAendern('besatzung', vorhanden.besatzung.id, { aktuell: vorhanden.aktuell }, p.werte, BES_FELDER)
          .then(function (res) { res.id = vorhanden.besatzung.id; return res; });
      }
      var jetzt = self.jetzt();
      var b = { id: neueId('be'), aktivitaetId: aktivitaetId, personId: personId, erstelltAm: jetzt };
      return self.speicher.mehrereSpeichern([
        { tabelle: 'besatzung', objekt: b }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('besatzung', b.id, 1, p.werte, null, jetzt) }
      ]).then(function () { return { ok: true, id: b.id }; });
    });
  };

  Daten.prototype.besatzungAendern = function (besatzungId, roh) {
    var self = this;
    return this.speicher.holen('besatzung', besatzungId).then(function (b) {
      if (!b) return { ok: false, fehler: { allgemein: 'Dieser Eintrag wurde nicht gefunden.' } };
      return Promise.all([self.mitVerlaufLaden('besatzung', besatzungId, BES_FELDER), self.speicher.wo('verantwortung', 'aktivitaetId', b.aktivitaetId)]).then(function (r) {
        var x = r[0], letzte = letzteVerantwortung(r[1]);
        var p = self.pruefenBesatzung(roh);
        var gleichBleibt = x.aktuell.werte.rolle === 'verantwortlich' && roh.rolle === 'verantwortlich';
        if (p.werte.rolle === 'verantwortlich' && !gleichBleibt) p.fehler.rolle = 'Die verantwortliche Person wird über „Verantwortlicher Wechsel“ bestimmt.';
        if (Object.keys(p.fehler).length) return { ok: false, fehler: p.fehler };
        var istLetzter = letzte && letzte.personId === b.personId;
        if (istLetzter && (p.werte.entfernt === 'ja' || p.werte.rolle === 'crew')) {
          return { ok: false, fehler: { allgemein: 'Diese Person ist zuletzt als verantwortlich eingetragen. Wechsle zuerst die Verantwortung auf eine andere Person.' } };
        }
        return self.mitVerlaufAendern('besatzung', besatzungId, x, p.werte, BES_FELDER).then(function (res) { res.id = besatzungId; return res; });
      });
    });
  };

  /* Position eines Wechsels (seit 2.0.115): beim Festhalten die GPS-Position des Geräts (Herkunft „gps“), von Hand korrigierbar (Herkunft „hand“).
     roh.position = { breite, laenge, genauigkeit } (frisch vom GPS), roh.breite / roh.laenge = von Hand eingegeben.
     Die GPS-Position gilt nur, wenn die Zeit „jetzt“ ist (Gerätezeit). Beim Nachtrag gibt es sie nicht, dort zählt nur die Eingabe von Hand.
     Ergebnis: { werte: { breite, laenge, positionQuelle, positionGenauigkeit } (leer, wenn es keine Position gibt), fehler: { breite?, laenge? } } */
  function wechselPosition(roh) {
    roh = roh || {};
    var gps = roh.position && typeof roh.position.breite === 'number' && typeof roh.position.laenge === 'number' ? roh.position : null;
    function leer(x) { return x === undefined || x === null || String(x).trim() === ''; }
    if (!leer(roh.breite) || !leer(roh.laenge)) {
      var p = MM.Logbuch.positionPruefen({ breite: roh.breite, laenge: roh.laenge, gpsBreite: gps ? gps.breite : null, gpsLaenge: gps ? gps.laenge : null, gpsGenauigkeit: gps ? gps.genauigkeit : null });
      if (Object.keys(p.fehler).length || p.werte.breite === null) return { werte: {}, fehler: p.fehler };
      return { werte: { breite: p.werte.breite, laenge: p.werte.laenge, positionQuelle: p.werte.positionQuelle, positionGenauigkeit: p.werte.positionGenauigkeit }, fehler: {} };
    }
    if (gps && MM.Logbuch.zeitHerkunftNormal(roh.zeitHerkunft) === 'geraet') {
      var gen = Number(gps.genauigkeit);
      return { werte: { breite: gps.breite, laenge: gps.laenge, positionQuelle: 'gps', positionGenauigkeit: isFinite(gen) && gen >= 0 ? Math.round(gen) : null }, fehler: {} };
    }
    return { werte: {}, fehler: {} };
  }
  function positionAnhaengen(ziel, pos) {
    Object.keys(pos.werte).forEach(function (k) { if (pos.werte[k] !== null && pos.werte[k] !== undefined) ziel[k] = pos.werte[k]; });
  }

  /* Darf diese Person ab „ab“ verantwortlich werden? null oder die Fehler (a = Ergebnis von aktivitaetLaden). */
  function verantwortungFehler(a, personId, ab) {
    var dabei = a.besatzung.filter(function (b) { return b.besatzung.personId === personId && (b.aktuell.werte.rolle === 'verantwortlich' || b.aktuell.werte.rolle === 'stellvertreter'); })[0];
    if (!dabei) return { personId: 'Verantwortlich kann nur sein, wer als ' + MM.Aktivitaeten.verantwortlichenName(a.fahrzeug.welt) + ' oder Stellvertreter dabei ist.' };
    var letzte = letzteVerantwortung(a.verantwortung);
    if (letzte && ab <= letzte.ab) return { abDatum: 'Der Wechsel muss nach dem letzten Wechsel liegen (' + letzte.ab.replace('T', ', ') + ' Uhr).' };
    if (letzte && letzte.personId === personId) return { personId: 'Diese Person ist schon verantwortlich.' };
    if (a.aktuell.werte.status === 'storniert') return { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' };
    return null;
  }

  /* Verantwortung ab einem Zeitpunkt auf eine andere Person übertragen. Nur Skipper/Fahrer und Stellvertreter.
     Seit 2.0.115 mit Position (roh.position vom GPS oder roh.breite/roh.laenge von Hand), siehe wechselPosition. */
  Daten.prototype.verantwortungWechseln = function (aktivitaetId, personId, roh) {
    var self = this;
    roh = roh || {};
    var p = pruefeWerte([{ key: 'abDatum', typ: 'datum' }, { key: 'abZeit', typ: 'zeit' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var f = p.fehler, w = p.werte;
    if (!w.abDatum && !f.abDatum) f.abDatum = 'Bitte das Datum des Wechsels angeben.';
    if (!w.abZeit && !f.abZeit) f.abZeit = 'Bitte die Uhrzeit des Wechsels angeben.';
    var pos = wechselPosition(roh);
    Object.keys(pos.fehler).forEach(function (k) { f[k] = pos.fehler[k]; });
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var ab = w.abDatum + 'T' + w.abZeit;
      var fehler = verantwortungFehler(a, personId, ab);
      if (fehler) return { ok: false, fehler: fehler };
      /* Beim Wechsel prüft die App die Befähigung der übernehmenden Person und hält das Ergebnis mit „geprüft am“ fest.
         Sie weist nur hin und sperrt den Wechsel nicht. Liegt der Zeitpunkt mehr als 5 Minuten vor jetzt, ist es ein Nachtrag. */
      return self.aktivitaetPruefung(aktivitaetId).then(function (pr) {
        var pruefung = MM.Logbuch.wechselPruefungFestgehalten(pr, personId);
        var nachgetragen = MM.Logbuch.zeitpunktArt(w.abDatum, w.abZeit, self.jetztLokal()) === 'nachtrag';
        var jetzt = self.jetzt();
        var v = { id: neueId('ve'), aktivitaetId: aktivitaetId, personId: personId, ab: ab, erstelltAm: jetzt };
        if (pruefung) v.pruefung = pruefung;
        if (nachgetragen) v.nachgetragenAm = jetzt;
        /* Herkunft der Zeit (seit 2.0.106): „geraet“, wenn der Aufrufer die Gerätezeit genommen hat, sonst von Hand. */
        v.zeitHerkunft = MM.Logbuch.zeitHerkunftNormal(roh.zeitHerkunft) || 'hand';
        positionAnhaengen(v, pos);
        return self.speicher.speichern('verantwortung', v).then(function () { return { ok: true, id: aktivitaetId, verantwortungId: v.id, pruefung: pruefung || null, nachgetragen: nachgetragen, position: pos.werte.breite !== undefined }; });
      });
    });
  };

  /* ---------- Rudergängerwechsel (seit 2.0.106, nur Wasserfahrzeuge) ----------
   * Gespeichert als ein Dokument „ruder-<aktivitaetId>“ in „einstellungen“ (keine Umstellung der Datenbank, in der Sicherung enthalten):
   *   { id, wechsel: [{ id, personId, ab "JJJJ-MM-TTTHH:MM", erstelltAm, nachgetragenAm, zeitHerkunft }] }
   * Der Skipper vom Anfang ist der erste Rudergänger und steht nicht im Dokument. Der Wechsel hat nichts mit der Verantwortung zu tun:
   * Der Skipper bleibt verantwortlich. Wer ans Ruder darf, entscheidet der Skipper, MobiMory prüft keine Befähigung. */
  /* Darf diese Person ab „ab“ ans Ruder? null oder die Fehler (a = Ergebnis von aktivitaetLaden). */
  function ruderFehler(a, personId, ab) {
    if (!MM.Rudergaenger.nurWasser(a.fahrzeug.welt)) return { allgemein: 'Einen Rudergänger gibt es nur bei Wasserfahrzeugen.' };
    if (a.aktuell.werte.status === 'storniert') return { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' };
    var person = a.besatzung.filter(function (b) { return b.besatzung.personId === personId; })[0];
    if (!person || !MM.Rudergaenger.dabei(person.aktuell.werte, ab)) return { personId: 'Ans Ruder kann nur, wer bei dieser Aktivität dabei ist.' };
    var letzte = a.rudergaenger[a.rudergaenger.length - 1];
    if (letzte && ab <= letzte.ab) return { abDatum: 'Der Wechsel muss nach dem letzten Wechsel liegen (' + letzte.ab.replace('T', ', ') + ' Uhr).' };
    var gerade = MM.Rudergaenger.aktuell(a.rudergaengerStart, a.rudergaenger, ab);
    if (gerade && gerade.personId === personId) return { personId: 'Diese Person steht schon am Ruder.' };
    return null;
  }

  Daten.prototype.rudergaengerWechseln = function (aktivitaetId, personId, roh) {
    var self = this;
    roh = roh || {};
    var p = pruefeWerte([{ key: 'abDatum', typ: 'datum' }, { key: 'abZeit', typ: 'zeit' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var f = p.fehler, w = p.werte;
    if (!w.abDatum && !f.abDatum) f.abDatum = 'Bitte das Datum des Wechsels angeben.';
    if (!w.abZeit && !f.abZeit) f.abZeit = 'Bitte die Uhrzeit des Wechsels angeben.';
    var pos = wechselPosition(roh);
    Object.keys(pos.fehler).forEach(function (k) { f[k] = pos.fehler[k]; });
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var ab = w.abDatum + 'T' + w.abZeit;
      var fehler = ruderFehler(a, personId, ab);
      if (fehler) return { ok: false, fehler: fehler };
      var person = a.besatzung.filter(function (b) { return b.besatzung.personId === personId; })[0];
      var gerade = MM.Rudergaenger.aktuell(a.rudergaengerStart, a.rudergaenger, ab);
      return self.speicher.holen('einstellungen', MM.Rudergaenger.dokumentId(aktivitaetId)).then(function (dok) {
        var jetzt = self.jetzt();
        var nachgetragen = MM.Logbuch.zeitpunktArt(w.abDatum, w.abZeit, self.jetztLokal()) === 'nachtrag';
        var eintrag = { id: neueId('ru'), personId: personId, ab: ab, erstelltAm: jetzt, nachgetragenAm: nachgetragen ? jetzt : null,
          zeitHerkunft: MM.Logbuch.zeitHerkunftNormal(roh.zeitHerkunft) || 'hand' };
        positionAnhaengen(eintrag, pos);
        var neu = { id: MM.Rudergaenger.dokumentId(aktivitaetId), wechsel: ((dok && dok.wechsel) || []).concat([eintrag]) };
        return self.speicher.speichern('einstellungen', neu).then(function () {
          return { ok: true, id: aktivitaetId, rudergaengerId: eintrag.id, name: person.person.name, vorher: gerade ? gerade.name : null, nachgetragen: nachgetragen, position: pos.werte.breite !== undefined };
        });
      });
    });
  };

  /* ---------- Verantwortlicher Wechsel (seit 2.0.115) ----------
   * Ein Vorgang für Skipper- und Rudergängerwechsel: roh.skipperPersonId und/oder roh.ruderPersonId (einer von beiden oder beide, auch dieselbe Person),
   * dazu abDatum, abZeit, zeitHerkunft und die Position (roh.position vom GPS oder roh.breite/roh.laenge von Hand).
   * Beide Wechsel werden zuerst geprüft, gespeichert wird erst, wenn beide in Ordnung sind. Der Skipper-Wechsel gilt auch an Land (dort der Fahrer),
   * der Rudergänger nur bei Wasserfahrzeugen. Der Skipper bleibt verantwortlich, auch wenn jemand anderes am Ruder steht. */
  Daten.prototype.verantwortlicherWechsel = function (aktivitaetId, roh) {
    var self = this;
    roh = roh || {};
    var skipper = roh.skipperPersonId || null, ruder = roh.ruderPersonId || null;
    if (!skipper && !ruder) return Promise.resolve({ ok: false, fehler: { allgemein: 'Bitte wählen, was wechselt, und wer neu eingetragen wird.' } });
    var p = pruefeWerte([{ key: 'abDatum', typ: 'datum' }, { key: 'abZeit', typ: 'zeit' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var f = p.fehler, w = p.werte;
    if (!w.abDatum && !f.abDatum) f.abDatum = 'Bitte das Datum des Wechsels angeben.';
    if (!w.abZeit && !f.abZeit) f.abZeit = 'Bitte die Uhrzeit des Wechsels angeben.';
    var pos = wechselPosition(roh);
    Object.keys(pos.fehler).forEach(function (k) { f[k] = pos.fehler[k]; });
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var ab = w.abDatum + 'T' + w.abZeit;
      var fehler = {};
      if (skipper) {
        var fs = verantwortungFehler(a, skipper, ab);
        if (fs) Object.keys(fs).forEach(function (k) { fehler[k === 'personId' ? 'skipperPersonId' : k] = fs[k]; });
      }
      if (ruder) {
        var fr = ruderFehler(a, ruder, ab);
        if (fr) Object.keys(fr).forEach(function (k) { var ziel = k === 'personId' ? 'ruderPersonId' : k; if (!fehler[ziel]) fehler[ziel] = fr[k]; });
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var erg = { ok: true, id: aktivitaetId, skipper: null, ruder: null, nachgetragen: false, position: pos.werte.breite !== undefined };
      return (skipper ? self.verantwortungWechseln(aktivitaetId, skipper, roh) : Promise.resolve(null)).then(function (r1) {
        if (r1 && !r1.ok) return r1;
        erg.skipper = r1;
        return ruder ? self.rudergaengerWechseln(aktivitaetId, ruder, roh) : null;
      }).then(function (r2) {
        if (r2 && !r2.ok) return r2;
        erg.ruder = r2;
        erg.nachgetragen = !!((erg.skipper && erg.skipper.nachgetragen) || (r2 && r2.nachgetragen));
        return erg;
      });
    });
  };

  /* Die Zeit am Ruder je Person von Beginn der Aktivität bis jetzt (oder bis zu ihrem Ende, wenn sie vorbei ist). Nur Wasserfahrzeuge.
     Ergebnis: [{ personId, name, minuten, abschnitte }] */
  Daten.prototype.rudergaengerZeiten = function (aktivitaetId) {
    var self = this;
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a || !MM.Rudergaenger.nurWasser(a.fahrzeug.welt)) return [];
      var w = a.aktuell.werte, von = MM.Aktivitaeten.von(w), ende = MM.Aktivitaeten.bis(w), jetzt = self.jetztLokal();
      var bis = ende && ende < jetzt ? ende : jetzt;
      return MM.Rudergaenger.zeiten(a.rudergaengerStart, a.rudergaenger, von, bis);
    });
  };

  /* ---------- Aktivität laden, listen, prüfen ---------- */
  Daten.prototype.aktivitaetLaden = function (id) {
    var self = this;
    return this.speicher.holen('aktivitaeten', id).then(function (a) {
      if (!a) return null;
      return Promise.all([
        self.speicher.wo('verlaeufe', 'objektId', id), self.speicher.wo('besatzung', 'aktivitaetId', id), self.speicher.alle('verlaeufe'),
        self.speicher.wo('verantwortung', 'aktivitaetId', id), self.personenListe(), self.tiereListe(), self.aktivitaetsartenListe(), self.fahrzeugListe({ alle: true }), self.gebieteListe(), self.orteListe(),
        self.speicher.holen('einstellungen', MM.Rudergaenger.dokumentId(id))
      ]).then(function (r) {
        var eintraege = r[0].slice().sort(nachNr);
        if (!eintraege.length) return null;
        var aktuell = eintraege[eintraege.length - 1], w = aktuell.werte;
        var personen = {}; r[4].forEach(function (p) { personen[p.objekt.id] = p.aktuell.werte.bezeichnung; });
        var tiere = {}; r[5].forEach(function (t) { tiere[t.objekt.id] = t.aktuell.werte.bezeichnung; });
        var arten = {}; r[6].forEach(function (x) { arten[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var gebiete = {}; r[8].forEach(function (x) { gebiete[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var orteNamen = {}; r[9].forEach(function (x) { orteNamen[x.objekt.id] = x.aktuell.werte.bezeichnung; });
        var fz = r[7].filter(function (x) { return x.fahrzeug.id === w.fahrzeugId; })[0] || null;
        var welt = fz ? MM.Fahrzeugarten.artSicher(fz.fahrzeug.art).welt : 'land';
        /* Gebiete aus den Orten der Aktivität (seit 2.0.39): Start, Ziel und Zwischenziele; welche Ebenen zählen, bestimmt das Fahrzeug. */
        var planIds = [w.startOrtId].concat(w.zwischenzielIds || [], [w.zielOrtId]).filter(Boolean);
        var planOrte = planIds.filter(function (i, n) { return planIds.indexOf(i) === n; }).map(function (i) {
          var o = r[9].filter(function (x) { return x.objekt.id === i; })[0];
          return o ? { id: i, name: o.aktuell.werte.bezeichnung, werte: o.aktuell.werte } : null;
        }).filter(Boolean);
        var ortGebiete = MM.Gebiete.kettenAusOrten({ gebiete: r[8], orte: planOrte, welt: welt });

        var verl = {}; r[2].forEach(function (e) { if (e.objektTyp === 'besatzung') (verl[e.objektId] = verl[e.objektId] || []).push(e); });
        var alleB = r[1].map(function (b) {
          var l = (verl[b.id] || []).slice().sort(nachNr);
          var ak = l[l.length - 1];
          return ak ? { besatzung: b, aktuell: ak, person: { id: b.personId, name: personen[b.personId] || 'unbekannt' }, rolleText: MM.Aktivitaeten.rolleLabel(ak.werte.rolle, welt) } : null;
        }).filter(Boolean);
        var reihenfolge = { verantwortlich: 0, stellvertreter: 1, crew: 2 };
        alleB.sort(function (x, y) { return reihenfolge[x.aktuell.werte.rolle] - reihenfolge[y.aktuell.werte.rolle] || x.person.name.localeCompare(y.person.name, 'de'); });
        var aktiv = alleB.filter(function (b) { return b.aktuell.werte.entfernt !== 'ja'; });
        var entfernt = alleB.filter(function (b) { return b.aktuell.werte.entfernt === 'ja'; });

        /* Korrekturen der Wechsel (Verlauf der Verantwortung): der neueste Stand gilt, der ursprüngliche Zeitpunkt bleibt sichtbar. */
        var vv = {}; r[2].forEach(function (e) { if (e.objektTyp === 'verantwortung') (vv[e.objektId] = vv[e.objektId] || []).push(e); });
        var ver = r[3].map(function (v) {
          var l = (vv[v.id] || []).slice().sort(nachNr), k = l[l.length - 1];
          return { id: v.id, personId: v.personId, name: personen[v.personId] || 'unbekannt',
            ab: k ? k.werte.abDatum + 'T' + k.werte.abZeit : v.ab, abUrspruenglich: v.ab, erstelltAm: v.erstelltAm,
            notiz: k ? (k.werte.notiz || null) : null, ausgeblendet: k ? (k.werte.ausgeblendet || 'nein') : 'nein', geaendert: !!k,
            nachgetragenAm: v.nachgetragenAm || null, pruefung: v.pruefung || null,
            breite: typeof v.breite === 'number' ? v.breite : null, laenge: typeof v.laenge === 'number' ? v.laenge : null, positionQuelle: v.positionQuelle || null,
            zeitHerkunft: k && k.werte.abDatum + 'T' + k.werte.abZeit !== v.ab ? 'hand' : (v.zeitHerkunft || null) };
        }).sort(function (x, y) { return x.ab < y.ab ? -1 : (x.ab > y.ab ? 1 : 0); });
        var jetzt = self.jetztLokal();
        var gerade = MM.Aktivitaeten.verantwortlicher(ver, jetzt);
        /* Rudergänger (seit 2.0.106, nur Wasserfahrzeuge): Der Skipper vom Anfang ist der erste Rudergänger, danach folgen die Wechsel. */
        var ruderListe = [], ruderStart = null, ruderJetzt = null;
        if (MM.Rudergaenger.nurWasser(welt)) {
          ruderStart = ver.length ? { personId: ver[0].personId, name: ver[0].name } : null;
          ruderListe = ((r[10] && r[10].wechsel) || []).map(function (x) {
            return { id: x.id, personId: x.personId, name: personen[x.personId] || 'unbekannt', ab: x.ab, erstelltAm: x.erstelltAm, nachgetragenAm: x.nachgetragenAm || null, zeitHerkunft: x.zeitHerkunft || null,
              breite: typeof x.breite === 'number' ? x.breite : null, laenge: typeof x.laenge === 'number' ? x.laenge : null, positionQuelle: x.positionQuelle || null };
          }).sort(function (x, y) { return x.ab < y.ab ? -1 : (x.ab > y.ab ? 1 : 0); });
          ruderJetzt = MM.Rudergaenger.aktuell(ruderStart, ruderListe, jetzt);
        }

        var verlauf = verlaufAus(eintraege, AKT_FELDER);
        verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            function wandeln(m, wert) { return wert ? m[wert] || 'unbekannt' : null; }
            if (u.key === 'artId') { u.feld = { typ: 'text' }; u.alt = wandeln(arten, u.alt); u.neu = wandeln(arten, u.neu); }
            if (u.key === 'fahrzeugId') { u.feld = { typ: 'text' }; u.alt = u.alt ? self.fahrzeugName(r[7], u.alt) : null; u.neu = u.neu ? self.fahrzeugName(r[7], u.neu) : null; }
            if (u.key === 'tierIds') { u.feld = { typ: 'text' }; u.alt = (u.alt || []).map(function (i) { return tiere[i] || 'unbekannt'; }).join(', ') || null; u.neu = (u.neu || []).map(function (i) { return tiere[i] || 'unbekannt'; }).join(', ') || null; }
            if (u.key === 'gebietId') { u.feld = { typ: 'text' }; u.alt = wandeln(gebiete, u.alt); u.neu = wandeln(gebiete, u.neu); }
            if (u.key === 'startOrtId' || u.key === 'zielOrtId') { u.feld = { typ: 'text' }; u.alt = wandeln(orteNamen, u.alt); u.neu = wandeln(orteNamen, u.neu); }
            if (u.key === 'zwischenzielIds') { u.feld = { typ: 'text' }; u.alt = (u.alt || []).map(function (i) { return orteNamen[i] || 'unbekannt'; }).join(', ') || null; u.neu = (u.neu || []).map(function (i) { return orteNamen[i] || 'unbekannt'; }).join(', ') || null; }
            if (u.key === 'sperreUebergangenAm' || u.key === 'status') { u.feld = { typ: 'text' }; }
          });
        });
        return { aktivitaet: a, aktuell: aktuell, verlauf: verlauf, ortGebiete: ortGebiete, gebiet: w.gebietId ? { id: w.gebietId, name: gebiete[w.gebietId] || 'unbekannt' } : null, art: w.artId ? { id: w.artId, name: arten[w.artId] || 'unbekannt' } : null,
          fahrzeug: fz ? { id: fz.fahrzeug.id, name: fz.aktuell.werte.bezeichnung, artId: fz.fahrzeug.art, welt: welt } : { id: w.fahrzeugId, name: 'unbekannt', artId: null, welt: 'land' },
          besatzung: aktiv, entfernte: entfernt, verantwortung: ver, verantwortlichJetzt: gerade, rudergaenger: ruderListe, rudergaengerStart: ruderStart, rudergaengerJetzt: ruderJetzt,
          tiere: (w.tierIds || []).map(function (i) { return { id: i, name: tiere[i] || 'unbekannt' }; }), status: MM.Aktivitaeten.status(w, jetzt),
          /* Reiseplan (seit 2.0.28): Start, Ziel und Zwischenziele mit Namen, null wenn nicht gewählt */
          startOrt: w.startOrtId ? { id: w.startOrtId, name: orteNamen[w.startOrtId] || 'unbekannt' } : null,
          zielOrt: w.zielOrtId ? { id: w.zielOrtId, name: orteNamen[w.zielOrtId] || 'unbekannt' } : null,
          zwischenziele: (w.zwischenzielIds || []).map(function (i) { return { id: i, name: orteNamen[i] || 'unbekannt' }; }) };
      });
    });
  };

  Daten.prototype.fahrzeugName = function (liste, id) {
    var f = liste.filter(function (x) { return x.fahrzeug.id === id; })[0];
    return f ? f.aktuell.werte.bezeichnung : 'unbekannt';
  };

  /* Alle Aktivitäten, mit Status und Überschneidungen am selben Fahrzeug. */
  Daten.prototype.aktivitaetenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('aktivitaeten'), this.speicher.alle('verlaeufe'), this.aktivitaetsartenListe(), this.fahrzeugListe({ alle: true })]).then(function (r) {
      var liste = sammle(self, r[0], r[1], 'aktivitaet');
      var arten = {}; r[2].forEach(function (a) { arten[a.objekt.id] = a.aktuell.werte.bezeichnung; });
      var fz = {}; r[3].forEach(function (f) { fz[f.fahrzeug.id] = f; });
      var jetzt = self.jetztLokal();
      liste.forEach(function (x) {
        var w = x.aktuell.werte;
        x.artName = arten[w.artId] || '';
        x.fahrzeugName = fz[w.fahrzeugId] ? fz[w.fahrzeugId].aktuell.werte.bezeichnung : 'unbekannt';
        x.status = MM.Aktivitaeten.status(w, jetzt);
        x.konflikte = [];
      });
      liste.forEach(function (x) {
        if (x.status === 'storniert') return;
        liste.forEach(function (y) {
          if (y !== x && y.status !== 'storniert' && y.aktuell.werte.fahrzeugId === x.aktuell.werte.fahrzeugId && MM.Aktivitaeten.ueberschneiden(x.aktuell.werte, y.aktuell.werte)) x.konflikte.push(y.objekt.id);
        });
      });
      var rang = { laeuft: 0, geplant: 1, vorbei: 2, storniert: 3 };
      liste.sort(function (a, b) {
        var d = rang[a.status] - rang[b.status];
        if (d) return d;
        var va = MM.Aktivitaeten.von(a.aktuell.werte), vb = MM.Aktivitaeten.von(b.aktuell.werte);
        return a.status === 'vorbei' ? (va < vb ? 1 : -1) : (va < vb ? -1 : (va > vb ? 1 : 0));
      });
      return liste;
    });
  };

  /*
   * Prüfung bei der Planung: Befähigung von Skipper/Fahrer und Stellvertretern,
   * Fristen bis zum Ende des Zeitraums, Überschneidungen am Fahrzeug.
   * Nur mit den Daten, die die App kennt. Keine rechtliche Aussage.
   */
  Daten.prototype.aktivitaetPruefung = function (id) {
    var self = this;
    return this.aktivitaetLaden(id).then(function (a) {
      if (!a) return null;
      var w = a.aktuell.werte;
      var pruefpersonen = a.besatzung.filter(function (b) { return b.aktuell.werte.rolle === 'verantwortlich' || b.aktuell.werte.rolle === 'stellvertreter'; });
      /* Die Regeln kommen vom gewählten Gebiet und von den Gebieten der Orte (Land, Region, Kreis oder Revier, je nach Fahrzeug). */
      var ortG = a.ortGebiete || { ids: [], ketten: [], ohneGebiet: [], ohneRevier: [] };
      var pruefIds = []; (w.gebietId ? [w.gebietId] : []).concat(ortG.ids).forEach(function (i) { if (pruefIds.indexOf(i) < 0) pruefIds.push(i); });
      var gebietNamen = (a.gebiet ? [a.gebiet.name] : []).concat(ortG.ketten.map(function (k) { return MM.Gebiete.pfadText(k); }));
      var gebietName = gebietNamen.join('; ');
      return Promise.all([
        self.anforderungenListe(w.fahrzeugId, true),
        Promise.all(pruefpersonen.map(function (b) { return self.nachweiseListe('person', b.person.id); })),
        self.fristenListe(w.fahrzeugId),
        self.aktivitaetenListe(),
        Promise.all(pruefIds.map(function (i) { return self.regelnListe(i); })).then(function (l) { return [].concat.apply([], l); }),
        self.komponentenListe(w.fahrzeugId),
        self.zuordnungenDokument(),
        self.gebieteListe()
      ]).then(function (r) {
        var anf = r[0].map(function (x) { return { bezeichnung: x.aktuell.werte.bezeichnung, artIds: x.aktuell.werte.artIds }; });
        /* Regeln des gewählten Gebiets: Sie gelten zusätzlich zu den Anforderungen am Fahrzeug. */
        var gebietInfo = null, ausruestungErgebnis = null;
        if (pruefIds.length) {
          /* Ausgebaute und ausgeblendete Komponenten (samt allem unter einer ausgeblendeten) zählen nicht (ausgeblendet seit 2.0.45). */
          var kompAktiv = MM.Komponenten.aktive(r[5]);
          var komp = kompAktiv.filter(function (k) { return !k.aktuell.werte.ausgebautAm; }).map(function (k) { return k.aktuell.werte.bezeichnung; });
          /* Regeln aus Reisechecks (seit 2.0.101) sind Hinweise und gehören nicht zur Prüfung der Befähigung und der Pflichtausrüstung. */
          var regelnPruefung = r[4].filter(function (x) { return !MM.Orte.istReisecheckRegel(x.aktuell.werte); });
          var ausw = MM.Orte.regelnAuswerten({
            regeln: regelnPruefung.map(function (x) { return Object.assign({ id: x.objekt.id, gebietId: x.objekt.gebietId }, x.aktuell.werte); }),
            fahrzeugArt: a.fahrzeug.artId, komponentenNamen: komp });
          var befGreifen = ausw.greifen.filter(function (g) { return MM.Orte.regelArt(g) === 'befaehigung'; });
          var ausGreifen = ausw.greifen.filter(function (g) { return MM.Orte.regelArt(g) === 'ausruestung'; });
          befGreifen.forEach(function (g) { anf.push({ bezeichnung: 'Gebiet ' + gebietName + ': ' + g.bezeichnung, artIds: g.artIds }); });
          var befNicht = ausw.nichtGreifen.filter(function (n) { return MM.Orte.regelArt(n.regel) === 'befaehigung'; });
          gebietInfo = { id: pruefIds[0], name: gebietName,
            regelnGesamt: regelnPruefung.filter(function (x) { return MM.Orte.regelArt(x.aktuell.werte) === 'befaehigung' && x.aktuell.werte.gilt !== 'nein'; }).length,
            greifen: befGreifen.map(function (g) { return g.bezeichnung; }),
            nichtGreifen: befNicht.map(function (n) { return { bezeichnung: n.regel.bezeichnung, grund: n.grund }; }) };
          /* Pflichtausrüstung: gesucht wird in den Namen der eingebauten Komponenten. Nicht eingetragen heißt „unklar“, nicht „fehlt“. */
          var kompDetail = kompAktiv.filter(function (k) { return !k.aktuell.werte.ausgebautAm; })
            .map(function (k) { return { name: k.aktuell.werte.bezeichnung, anzahl: k.aktuell.werte.anzahl, geprueft: k.aktuell.werte.eignungGeprueft }; });
          var pflicht = ausGreifen.map(function (g) {
            /* Bestätigte Namen des Nutzers (seit 2.0.41): Land der Regel (sonst das oberste Gebiet) und Art des Fahrzeugs. Nur was er gleichgesetzt hat, zählt. */
            var weg = g.gebietId ? MM.Gebiete.pfad(r[7], g.gebietId) : [];
            var landG = weg.filter(function (z) { return z.ebene === 'land'; })[0] || weg[0] || null;
            var gleich = landG ? MM.Orte.zuordnungNamen(MM.Orte.zuordnungenFuer(r[6], landG.name, a.fahrzeug.artId), 'ausruestung', g.pflichtAusruestung) : [];
            var e = MM.Orte.ausruestungPruefen({ regel: g, komponenten: MM.Orte.komponentenMitZuordnung(kompDetail, g.pflichtAusruestung, gleich), personen: a.besatzung.length });
            return { bezeichnung: g.bezeichnung, pflicht: g.pflichtAusruestung, status: e.status, soll: e.soll, ist: e.ist, istGeprueft: e.istGeprueft,
              menge: e.menge, bezug: e.bezug, eignung: e.eignung,
              text: e.text + (gleich.length ? ' Gleichgesetzt mit ' + gleich.map(function (n) { return '„' + n + '“'; }).join(', ') + ' (von dir bestätigt).' : '') };
          });
          ausruestungErgebnis = { liste: pflicht, ergebnis: !pflicht.length ? null : (pflicht.every(function (x) { return x.status === 'eingetragen'; }) ? 'erlaubt' : 'unklar') };
        }
        var personen = pruefpersonen.map(function (b, i) {
          var nachweise = r[1][i].map(function (n) { return { artId: n.nachweis.artId, artName: n.art.aktuell.werte.bezeichnung, hatAblauf: MM.Nachweise.hatAblauf(n.art.aktuell.werte), werte: n.aktuell.werte }; });
          var res = MM.Aktivitaeten.pruefeBefaehigung({ anforderungen: anf, nachweise: nachweise, endDatum: w.bisDatum });
          return { person: b.person, rolle: b.aktuell.werte.rolle, rolleText: b.rolleText, ergebnis: res.ergebnis, gruende: res.gruende };
        });
        var ergebnis = MM.Aktivitaeten.gesamtErgebnis(personen.map(function (x) { return x.ergebnis; }));
        var gebiet = gebietInfo ? gebietInfo.name : (trimmed(w.gebiet) || null);
        var gebietHinweis = null, ortHinweis = null;
        /* Fehlt bei einem Ort das Gebiet oder (beim Wasserfahrzeug) das Revier, ist das „unklar“. Gesperrt wird nichts. */
        if (ortG.ohneGebiet.length) ortHinweis = 'Bei ' + ortG.ohneGebiet.join(', ') + ' ist das Gebiet unklar, weil der Ort noch nicht über die Ortssuche geprüft ist (Stammdaten › Orte).';
        if (a.fahrzeug.welt === 'wasser' && ortG.ohneRevier.length && pruefIds.length) {
          ortHinweis = (ortHinweis ? ortHinweis + ' ' : '') + 'Für das Wasserfahrzeug fehlt bei ' + ortG.ohneRevier.join(', ') + ' das Revier (Binnenwasserstraße). Trage es beim Ort ein.';
        }
        if (gebietInfo) {
          /* Kennt die App für dieses Gebiet und dieses Fahrzeug keine Regel, bleibt sie vorsichtig: höchstens „unklar“. */
          if (!gebietInfo.greifen.length) {
            gebietHinweis = gebietInfo.regelnGesamt
              ? 'Für das Gebiet „' + gebietInfo.name + '“ trifft keine Regel auf dieses Fahrzeug zu. Die Prüfung gilt nur für die Anforderungen am Fahrzeug.'
              : 'Für das Gebiet „' + gebietInfo.name + '“ gibt es noch keine Regel für die Befähigung. Die Prüfung gilt nur für die Anforderungen am Fahrzeug.';
            if (ergebnis === 'erlaubt') ergebnis = 'unklar';
          }
        } else if (gebiet) {
          gebietHinweis = 'Das Gebiet „' + gebiet + '“ ist nur als Text eingetragen und wird nicht geprüft. Wähle ein Gebiet aus der Liste, damit seine Regeln gelten.';
          if (ergebnis === 'erlaubt') ergebnis = 'unklar';
        }
        if (ortHinweis) {
          gebietHinweis = (gebietHinweis ? gebietHinweis + ' ' : '') + ortHinweis;
          if (pruefIds.length && ergebnis === 'erlaubt') ergebnis = 'unklar';
        }
        /* Dieselbe Rechnung für das Fahrzeug der Aktivität und für alle dazugehörigen Fahrzeuge (seit 2.0.45). */
        function fristenFuer(fristListe) {
          var eingabe = fristListe.map(function (x) { return { bezeichnung: x.aktuell.werte.bezeichnung, werte: x.aktuell.werte, letzte: x.status.letzte, zaehler: x.zaehler }; });
          return MM.Aktivitaeten.fristenImZeitraum({ fristen: eingabe, heute: self.heute(), endDatum: w.bisDatum, geplanteStrecke: w.geplanteStrecke, geplanteStunden: w.geplanteStunden });
        }
        var fristen = fristenFuer(r[2]);
        var konflikte = r[3].filter(function (x) { return a.aktivitaet.id !== x.objekt.id && a.aktuell.werte.status !== 'storniert' && x.status !== 'storniert' && x.aktuell.werte.fahrzeugId === w.fahrzeugId && MM.Aktivitaeten.ueberschneiden(w, x.aktuell.werte); })
          .map(function (x) { return { id: x.objekt.id, name: x.aktuell.werte.bezeichnung, vonDatum: x.aktuell.werte.vonDatum, bisDatum: x.aktuell.werte.bisDatum }; });
        /* Dazugehörige Fahrzeuge (Anhänger, Dinghy, auch über Ketten): nur ihre Fristen werden mitgeprüft, als Hinweis, getrennt nach Fahrzeug.
           Befähigung, Pflichtausrüstung und Gebiet bleiben beim Fahrzeug der Aktivität. Abgegebene Fahrzeuge zählen nicht. */
        return self.fahrzeugZuordnung(w.fahrzeugId).then(function (zu) {
          var dazu = zu ? zu.alle : [];
          return Promise.all(dazu.map(function (x) { return self.fristenListe(x.id); })).then(function (listen) {
            var gespann = dazu.map(function (x, i) {
              var liste = fristenFuer(listen[i]);
              return { fahrzeugId: x.id, name: x.name, artName: x.artName, ueber: x.ueber, tiefe: x.tiefe, liste: liste, zusammenfassung: MM.Aktivitaeten.fristenZusammenfassung(liste) };
            });
            return { geprueftAm: self.jetztLokal(), anforderungen: anf.length,
              befaehigung: { ergebnis: ergebnis, personen: personen, gebiet: gebiet, gebietHinweis: gebietHinweis, gebietInfo: gebietInfo },
              ausruestung: ausruestungErgebnis,
              fristen: { liste: fristen, zusammenfassung: MM.Aktivitaeten.fristenZusammenfassung(fristen), gespann: gespann }, belegung: { konflikte: konflikte } };
          });
        });
      });
    });
  };

  /* ---------- Fahrzeugarten verwalten (seit 2.0.16) ----------
   * Eigene Arten und Änderungen liegen als ein Dokument in „einstellungen“ (Kennung „fahrzeugarten“),
   * dadurch keine Umstellung des Speichers. Die Regeln selbst stehen in js/fahrzeugarten.js. */
  function fahrzeugartenSpeichern(self) {
    return self.speicher.speichern('einstellungen', MM.Fahrzeugarten.dokument());
  }
  /* Die Arten, die ein Fahrzeug hat (eine Art je Fahrzeug, auch doppelt). */
  Daten.prototype.fahrzeugartenBenutzt = function () {
    return this.speicher.alle('fahrzeuge').then(function (liste) { return liste.map(function (f) { return f.art; }); });
  };

  /* Die Ansicht: alle Arten mit Zustand und Zahl der Fahrzeuge (mit Untergruppen), dazu was „Ungebrauchtes löschen“ träfe. */
  Daten.prototype.fahrzeugartenVerwaltung = function () {
    return this.fahrzeugartenBenutzt().then(function (benutzt) {
      var F = MM.Fahrzeugarten, zahl = {};
      benutzt.forEach(function (b) { F.vorfahren(b).forEach(function (i) { zahl[i] = (zahl[i] || 0) + 1; }); });
      var arten = F.verwaltung().map(function (k) { k.fahrzeuge = zahl[k.id] || 0; return k; });
      var weg = F.ungebraucht(benutzt);
      return { arten: arten, ungebraucht: weg.map(function (i) { return { id: i, name: F.art(i).name }; }), wiederherstellbar: F.wiederherstellbar().length };
    });
  };

  Daten.prototype.fahrzeugartAnlegen = function (roh) {
    var self = this;
    roh = roh || {};
    var r = MM.Fahrzeugarten.anlegen(neueId('fa'), roh.name, roh.eltern);
    if (!r.ok) return Promise.resolve(r);
    return fahrzeugartenSpeichern(self).then(function () { return r; });
  };

  /*
   * Ein eigener Punkt der Eignungsliste (seit 2.0.103). Legt ein Entwickler oder Admin ihn an, ist er sofort ein vorgegebener Punkt
   * (für Aktivitäten verwendbar), bei allen anderen ist er ein Merkzettel beim Fahrzeug. Gespeichert im Dokument „fahrzeugarten“.
   */
  Daten.prototype.eignungAnlegen = function (name) {
    var self = this;
    return this.rolle().then(function (rolle) {
      var r = MM.Fahrzeugarten.eignungAnlegen(neueId('ep'), name, !!rolle);
      if (!r.ok) return r;
      return fahrzeugartenSpeichern(self).then(function () { return r; });
    });
  };

  Daten.prototype.fahrzeugartAendern = function (id, roh) {
    var self = this;
    roh = roh || {};
    var r = MM.Fahrzeugarten.aendern(id, roh.name, roh.ausgeblendet);
    if (!r.ok || !r.geaendert) return Promise.resolve(r);
    return fahrzeugartenSpeichern(self).then(function () { return r; });
  };

  Daten.prototype.fahrzeugartLoeschen = function (id) {
    var self = this;
    return this.fahrzeugartenBenutzt().then(function (benutzt) {
      var r = MM.Fahrzeugarten.loeschen(id, benutzt);
      if (!r.ok) return r;
      return fahrzeugartenSpeichern(self).then(function () { return r; });
    });
  };

  /* Löscht alles Ungebrauchte (keine Gruppen Land, Wasser, Luft). Benutzte Arten bleiben. */
  Daten.prototype.fahrzeugartenBereinigen = function () {
    var self = this;
    return this.fahrzeugartenBenutzt().then(function (benutzt) {
      var r = MM.Fahrzeugarten.bereinigen(benutzt);
      if (!r.anzahl) return r;
      return fahrzeugartenSpeichern(self).then(function () { return r; });
    });
  };

  Daten.prototype.fahrzeugartenWiederherstellen = function () {
    var self = this;
    var r = MM.Fahrzeugarten.wiederherstellen();
    if (!r.anzahl) return Promise.resolve(r);
    return fahrzeugartenSpeichern(self).then(function () { return r; });
  };

  /* ---------- Logbuch-Kern: Ereignisarten (offene Liste) ---------- */
  /* Seit 2.0.15 gilt jede Ereignisart für Fahrzeugarten (Baum). Fehlt die Angabe (ältere Arten), gilt sie für alle. */
  var EREIGNISART_FELDER = AKTART_FELDER.concat([{ key: 'zuordnung', label: 'Gilt für Fahrzeugarten', typ: 'text' },
    { key: 'giltImStatus', label: 'Möglich im Status', typ: 'text' }, { key: 'danachStatus', label: 'Danach Status', typ: 'text' },
    { key: 'aktion', label: 'Aktion beim Antippen', typ: 'text' },
    /* Baukasten-Gerüst (seit 2.0.50): Fragen und Wirkungen nach Wo und Wann. Die Aktion aus 2.0.47 geht darin auf (js/baukasten.js). */
    { key: 'fragen', label: 'Fragen nach dem Antippen', typ: 'mehrfach', optionen: baukastenOptionen('fragen') },
    { key: 'wirkungen', label: 'Wirkungen nach dem Antippen', typ: 'mehrfach', optionen: baukastenOptionen('wirkungen') },
    { key: 'checkliste', label: 'Checkliste', typ: 'text' }]);

  function baukastenOptionen(was) {
    return MM.Baukasten ? MM.Baukasten[was]().map(function (x) { return { wert: x.id, label: x.name }; }) : [];
  }
  /* Fragen und Wirkungen aus der Eingabe: { gesetzt, fragen, wirkungen, fehler }. „gesetzt“ ist falsch, wenn die Eingabe keines der beiden Felder hat.
   * Eine Wirkung ohne ihre Frage wird nicht gespeichert (zum Beispiel Kostenposten ohne Betrag), es kommt eine Meldung am Feld „wirkungen“. */
  function baukastenPruefen(roh) {
    var B = MM.Baukasten;
    if (!B || !roh || (roh.fragen === undefined && roh.wirkungen === undefined)) return { gesetzt: false, fragen: [], wirkungen: [], fehler: {} };
    var z = { fragen: B.fragenNormal(roh.fragen), wirkungen: B.wirkungenNormal(roh.wirkungen) };
    var m = B.fehlendeFragen(z);
    return { gesetzt: true, fragen: z.fragen, wirkungen: z.wirkungen, fehler: m.length ? { wirkungen: m.join(' ') } : {} };
  }

  /* Aktion beim Antippen (seit 2.0.47): bekannte Kennung oder ''. Die Liste der Aktionen steht in js/aktionen.js. */
  function aktionNormal(id) { return MM.Aktionen ? MM.Aktionen.normal(id) : ''; }

  Daten.prototype.ereignisartenListe = function () {
    var self = this;
    return Promise.all([this.speicher.alle('ereignisarten'), this.speicher.alle('verlaeufe')]).then(function (r) {
      return sammle(self, r[0], r[1], 'ereignisart');
    });
  };

  Daten.prototype.ereignisartAnlegen = function (roh) {
    var self = this;
    var bez = trimmed(roh && roh.bezeichnung);
    if (!bez) return Promise.resolve({ ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben, zum Beispiel „Segel gesetzt“.' } });
    return this.ereignisartenListe().then(function (liste) {
      if (liste.some(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === bez.toLowerCase(); })) {
        return { ok: false, fehler: { bezeichnung: 'Diese Art gibt es schon.' } };
      }
      /* Status-Regel (seit 2.0.23): beides leer = Starthilfe nach dem Namen. */
      var sr = MM.Status.regelNormal(roh);
      if (!sr.ok) return { ok: false, fehler: sr.fehler };
      var neuWerte = { bezeichnung: bez, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungNormal(roh.zuordnung),
        giltImStatus: sr.werte.giltImStatus, danachStatus: sr.werte.danachStatus };
      /* Aktion beim Antippen (seit 2.0.47): nur gesetzt, wenn eine gewählt ist. Ohne Aktion bleibt der Knopf wie bisher. */
      var akt = aktionNormal(roh.aktion);
      if (akt) neuWerte.aktion = akt;
      /* Fragen und Wirkungen (seit 2.0.50): nur gesetzt, wenn etwas gewählt ist. Ohne beides bleibt der Knopf wie bisher. */
      var bk = baukastenPruefen(roh);
      if (Object.keys(bk.fehler).length) return { ok: false, fehler: bk.fehler };
      if (bk.fragen.length || bk.wirkungen.length) { neuWerte.fragen = bk.fragen; neuWerte.wirkungen = bk.wirkungen; }
      if (trimmed(roh.checkliste)) neuWerte.checkliste = trimmed(roh.checkliste).slice(0, 600);
      return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', neuWerte);
    });
  };

  /* Legt die Vorschläge an, die es noch nicht gibt. Gibt die Anzahl der neuen zurück. */
  Daten.prototype.ereignisartenAusVorschlaegen = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Logbuch.VORSCHLAEGE_EREIGNISARTEN.filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
      return neu.reduce(function (kette, n) {
        return kette.then(function () { return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: n, ausgeblendet: 'nein' }); });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  /* „Ablegen“ und „Anlegen“ (seit 2.0.114): Wasserfahrzeuge haben im Cockpit kein „Abfahrt“ und „Ankunft“. Die beiden Arten werden angelegt, falls es sie
     nicht gibt (Zuordnung: Wasserfahrzeuge, Status-Regel nach dem Namen). Eine ausgeblendete oder geänderte Art bleibt, wie sie ist. */
  Daten.prototype.wasserArtenSichern = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Logbuch.WASSER_ARTEN.filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
      return neu.reduce(function (kette, n) {
        return kette.then(function () { return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: n, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(['wasser']) }); });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  /* Die Vorschläge mit Zuordnung zu Fahrzeugarten (Anlegen, Segel setzen, ...). Gibt die Anzahl der neuen zurück. */
  Daten.prototype.ereignisartenVorauswahlUebernehmen = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = MM.Logbuch.ZUSATZ_VORSCHLAEGE.filter(function (v) { return vorhanden.indexOf(v.bezeichnung.toLowerCase()) < 0; });
      return neu.reduce(function (kette, v) {
        return kette.then(function () {
          var werte = { bezeichnung: v.bezeichnung, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(v.gilt) };
          /* „Ver- und Entsorgung“ (seit 2.0.63) kommt gleich mit ihren Fragen und Wirkungen, damit der Knopf im Cockpit sofort etwas tut. */
          if (v.bezeichnung === 'Ver- und Entsorgung' && MM.Baukasten && MM.Baukasten.vorlage('versorgung')) { var vl = MM.Baukasten.vorlage('versorgung'); werte.fragen = vl.fragen; werte.wirkungen = vl.wirkungen; }
          return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', werte);
        });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };

  /* Die Ereignisarten, die zu einer Fahrzeugart passen (ohne ausgeblendete). Eine Art, die schon an einem
     Eintrag hängt, bleibt auswählbar (behalteIds), auch wenn sie nicht mehr zur Fahrzeugart passt. */
  Daten.prototype.ereignisartenFuerFahrzeugart = function (artId, behalteIds) {
    var behalte = behalteIds || [];
    return this.ereignisartenListe().then(function (liste) {
      return liste.filter(function (x) {
        if (behalte.indexOf(x.objekt.id) >= 0) return true;
        if (x.aktuell.werte.ausgeblendet === 'ja') return false;
        if (MM.Logbuch.istLandWegArt(x.aktuell.werte.bezeichnung) && MM.Logbuch.istWasserArt(artId)) return false;
        return !artId || MM.Logbuch.ereignisartGilt(x.aktuell.werte.zuordnung, artId);
      });
    });
  };

  Daten.prototype.ereignisartLaden = function (id) { return this.mitVerlaufLaden('ereignisarten', id, EREIGNISART_FELDER); };

  Daten.prototype.ereignisartAendern = function (id, roh) {
    var self = this;
    return this.ereignisartLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Diese Art wurde nicht gefunden.' } };
      var bez = trimmed(roh && roh.bezeichnung);
      if (!bez) return { ok: false, fehler: { bezeichnung: 'Bitte einen Namen für die Art eingeben.' } };
      var neu = { bezeichnung: bez, ausgeblendet: roh.ausgeblendet === 'ja' ? 'ja' : 'nein' };
      /* Ohne Angabe bleibt die Zuordnung, wie sie ist (bei alten Arten: gilt für alle). */
      if (roh.zuordnung !== undefined) neu.zuordnung = MM.Logbuch.zuordnungNormal(roh.zuordnung);
      else if (x.aktuell.werte.zuordnung !== undefined) neu.zuordnung = x.aktuell.werte.zuordnung;
      /* Status-Regel (seit 2.0.23): ohne Angabe bleibt sie, wie sie ist. */
      if (roh.giltImStatus !== undefined || roh.danachStatus !== undefined) {
        var sr = MM.Status.regelNormal(roh);
        if (!sr.ok) return { ok: false, fehler: sr.fehler };
        neu.giltImStatus = sr.werte.giltImStatus; neu.danachStatus = sr.werte.danachStatus;
      } else {
        if (x.aktuell.werte.giltImStatus !== undefined) neu.giltImStatus = x.aktuell.werte.giltImStatus;
        if (x.aktuell.werte.danachStatus !== undefined) neu.danachStatus = x.aktuell.werte.danachStatus;
      }
      /* Aktion beim Antippen (seit 2.0.47): ohne Angabe bleibt sie, wie sie ist. Eine leere Wahl nimmt sie weg. */
      if (roh.aktion !== undefined) {
        var akt = aktionNormal(roh.aktion);
        if (akt || x.aktuell.werte.aktion) neu.aktion = akt;
      } else if (x.aktuell.werte.aktion !== undefined) neu.aktion = x.aktuell.werte.aktion;
      /* Fragen und Wirkungen (seit 2.0.50): ohne Angabe bleiben sie. Entspricht die Wahl der bisherigen Zusammenstellung (auch der aus dem
       * alten Feld „aktion“), wird nichts umgeschrieben. Eine leere Wahl nimmt die Zusammenstellung weg, auch die aus „aktion“. */
      var bk = baukastenPruefen(roh);
      if (Object.keys(bk.fehler).length) return { ok: false, fehler: bk.fehler };
      var altBk = x.aktuell.werte;
      var behalten = !bk.gesetzt || (MM.Baukasten && MM.Baukasten.gleich(MM.Baukasten.zusammenstellung(altBk), { fragen: bk.fragen, wirkungen: bk.wirkungen }));
      if (behalten) {
        if (altBk.fragen !== undefined) neu.fragen = altBk.fragen;
        if (altBk.wirkungen !== undefined) neu.wirkungen = altBk.wirkungen;
      } else { neu.fragen = bk.fragen; neu.wirkungen = bk.wirkungen; }
      if (roh.checkliste !== undefined) { var cl = trimmed(roh.checkliste).slice(0, 600); if (cl || x.aktuell.werte.checkliste) neu.checkliste = cl; }
      else if (x.aktuell.werte.checkliste !== undefined) neu.checkliste = x.aktuell.werte.checkliste;
      return self.mitVerlaufAendern('ereignisart', id, x, neu, EREIGNISART_FELDER);
    });
  };

  /* ---------- Logbuch ohne Planung starten (seit 2.0.15) ----------
   * Legt sofort eine Aktivität an: Beginn jetzt, Ende standardmäßig heute, Fahrzeug und verantwortliche Person Pflicht,
   * Stellvertreter und Crew freiwillig. Die Art wählt der Nutzer (seit 2.0.17) aus den Arten, die zum Fahrzeug passen;
   * ohne Angabe gilt „Ausfahrt“.
   * Die Aktivität läuft dann wie jede andere, mit derselben Prüfung. Nichts wird nebenbei gebaut.
   *  roh = { fahrzeugId, artId?, verantwortlichId, stellvertreterIds: [], crewIds: [], bisDatum? }  */
  Daten.prototype.logbuchSofortStarten = function (roh) {
    var self = this;
    roh = roh || {};
    return this.aktivitaetsartenAusVorschlaegen().then(function () { return self.aktivitaetKontext(); }).then(function (ctx) {
      var fz = ctx.fahrzeuge.filter(function (x) { return x.fahrzeug.id === roh.fahrzeugId; })[0];
      var fehler = {};
      if (!fz) fehler.fahrzeugId = ctx.fahrzeuge.length ? 'Bitte das Fahrzeug wählen.' : 'Es gibt noch kein Fahrzeug. Lege zuerst ein Fahrzeug an.';
      var welt = fz ? MM.Fahrzeugarten.artSicher(fz.fahrzeug.art).welt : null;
      var verantwortlich = MM.Aktivitaeten.verantwortlichenName(welt);
      if (!ctx.personen.some(function (x) { return x.objekt.id === roh.verantwortlichId; })) {
        fehler.verantwortlichId = ctx.personen.length ? 'Bitte wählen, wer ' + (welt ? verantwortlich : 'verantwortlich') + ' ist.' : 'Es gibt noch keine Person. Lege zuerst die Besatzung an.';
      }
      var stell = (roh.stellvertreterIds || []).filter(function (i) { return i && i !== roh.verantwortlichId; });
      var crew = (roh.crewIds || []).filter(function (i) { return i && i !== roh.verantwortlichId && stell.indexOf(i) < 0; });
      var bekannt = ctx.personen.map(function (x) { return x.objekt.id; });
      if (stell.concat(crew).some(function (i) { return bekannt.indexOf(i) < 0; })) fehler.crewIds = 'Eine gewählte Person gibt es nicht (mehr).';
      var gewaehlt = roh.artId
        ? ctx.arten.filter(function (a) { return a.objekt.id === roh.artId; })[0]
        : ctx.arten.filter(function (a) { return a.aktuell.werte.bezeichnung.toLowerCase() === 'ausfahrt' && a.aktuell.werte.ausgeblendet !== 'ja'; })[0];
      if (roh.artId && !gewaehlt) fehler.artId = 'Bitte eine Art wählen.';
      else if (gewaehlt && gewaehlt.aktuell.werte.ausgeblendet === 'ja') fehler.artId = 'Die Art „' + gewaehlt.aktuell.werte.bezeichnung + '“ ist ausgeblendet. Wähle eine andere Art.';
      else if (!gewaehlt && !Object.keys(fehler).length) fehler.allgemein = 'Die Art „Ausfahrt“ ist ausgeblendet oder fehlt. Blende sie unter „Arten von Aktivitäten“ wieder ein oder wähle eine andere Art.';
      else if (gewaehlt && fz && !MM.Logbuch.ereignisartGilt(gewaehlt.aktuell.werte.zuordnung, fz.fahrzeug.art)) {
        fehler.artId = 'Die Art „' + gewaehlt.aktuell.werte.bezeichnung + '“ gilt nicht für dieses Fahrzeug. Wähle eine passende Art.';
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var jetzt = self.jetztLokal(), tag = jetzt.slice(0, 10), zeit = jetzt.slice(11, 16);
      var a = {
        bezeichnung: gewaehlt.aktuell.werte.bezeichnung + ' ' + fz.aktuell.werte.bezeichnung + ' ' + tag.slice(8, 10) + '.' + tag.slice(5, 7) + '.' + tag.slice(0, 4),
        artId: gewaehlt.objekt.id, fahrzeugId: roh.fahrzeugId,
        vonDatum: tag, vonZeit: zeit, bisDatum: roh.bisDatum || tag, bisZeit: '',
        verantwortlichId: roh.verantwortlichId, tierIds: [], notiz: 'Ohne Planung gestartet'
      };
      return self.aktivitaetAnlegen(a).then(function (res) {
        if (!res.ok) return res;
        var kette = Promise.resolve();
        stell.forEach(function (pid) { kette = kette.then(function () { return self.besatzungHinzufuegen(res.id, pid, { rolle: 'stellvertreter' }); }); });
        crew.forEach(function (pid) { kette = kette.then(function () { return self.besatzungHinzufuegen(res.id, pid, { rolle: 'crew' }); }); });
        return kette.then(function () { return { ok: true, id: res.id }; });
      });
    });
  };

  /* ---------- Schnellstart (seit 2.0.124) ----------
   * Der geführte Einstieg: Person, Fahrzeug, erste Aktivität (Texte und reine Regeln in schnellstart.js). Der Stand liegt als Einstellung
   * 'schnellstart' auf dem Gerät: { stand, weg, personId, fahrzeugId, aktivitaetId }. Die Arten von Aktivitäten legt die App selbst an
   * (aktivitaetsartenAusVorschlaegen), die verantwortliche Person ist die gewählte Person. */
  Daten.prototype.schnellstartLesen = function () {
    return this.einstellungLesen(MM.Schnellstart.DOK_ID).then(function (dok) { return MM.Schnellstart.stand(dok); });
  };
  Daten.prototype.schnellstartSetzen = function (aenderung) {
    var self = this;
    return this.schnellstartLesen().then(function (alt) {
      var neu = MM.Schnellstart.stand(Object.assign({}, alt, aenderung || {}));
      neu.geaendert = self.jetzt();
      return self.einstellungSchreiben(neu).then(function () { return neu; });
    });
  };
  /* Soll die App beim Programmstart den Schnellstart anbieten? Nur ohne Entscheidung und ohne Person und Fahrzeug. */
  Daten.prototype.schnellstartNoetig = function () {
    return Promise.all([this.einstellungLesen(MM.Schnellstart.DOK_ID), this.speicher.alle('personen'), this.speicher.alle('fahrzeuge')]).then(function (r) {
      return MM.Schnellstart.noetig(r[0], r[1].length, r[2].length);
    });
  };
  /* Den Schnellstart beenden, ohne fertig zu sein. Ein fertiger Schnellstart bleibt fertig. */
  Daten.prototype.schnellstartUeberspringen = function () {
    var self = this;
    return this.schnellstartLesen().then(function (s) { return s.stand === 'fertig' ? s : self.schnellstartSetzen({ stand: 'uebersprungen' }); });
  };
  /* Weg gewählt (basic oder konto): der Schnellstart ist unterwegs. */
  Daten.prototype.schnellstartWeg = function (weg) {
    if (MM.Schnellstart.WEGE.indexOf(weg) < 0) return Promise.resolve({ ok: false, fehler: { allgemein: 'Bitte einen Weg wählen.' } });
    return this.schnellstartSetzen({ stand: 'unterwegs', weg: weg }).then(function (s) { return { ok: true, stand: s }; });
  };
  /* Schritt 1: eine vorhandene Person nehmen (personId) oder eine neue anlegen (bezeichnung). */
  Daten.prototype.schnellstartPerson = function (roh) {
    var self = this, p = MM.Schnellstart.pruefePerson(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    function merken(id) {
      return self.schnellstartLesen().then(function (s) { return self.schnellstartSetzen({ stand: 'unterwegs', weg: s.weg || 'basic', personId: id }); }).then(function () { return { ok: true, id: id }; });
    }
    if (roh.personId) {
      return this.personLaden(roh.personId).then(function (x) {
        return x ? merken(roh.personId) : { ok: false, fehler: { personId: 'Diese Person gibt es nicht (mehr).' } };
      });
    }
    return this.personAnlegen({ bezeichnung: String(roh.bezeichnung).trim() }).then(function (r) { return r.ok ? merken(r.id) : r; });
  };
  /* Schritt 2: ein vorhandenes Fahrzeug nehmen (fahrzeugId) oder ein neues anlegen (artId, bezeichnung). Die Vorbelegung der Art
     (zum Beispiel Antrieb „ohne“ beim Anhänger, Eignung beim Wohnmobil) gilt wie im Formular. */
  Daten.prototype.schnellstartFahrzeug = function (roh) {
    var self = this, p = MM.Schnellstart.pruefeFahrzeug(roh);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    function merken(id) { return self.schnellstartSetzen({ stand: 'unterwegs', fahrzeugId: id }).then(function () { return { ok: true, id: id }; }); }
    if (roh.fahrzeugId) {
      return this.fahrzeugLaden(roh.fahrzeugId).then(function (x) {
        return x ? merken(roh.fahrzeugId) : { ok: false, fehler: { fahrzeugId: 'Dieses Fahrzeug gibt es nicht (mehr).' } };
      });
    }
    var werte = Object.assign({}, MM.Fahrzeugarten.vorgabe(roh.artId), { bezeichnung: String(roh.bezeichnung).trim() });
    return this.fahrzeugAnlegen(roh.artId, werte).then(function (r) { return r.ok ? merken(r.id) : r; });
  };
  /* Schritt 3: das Logbuch jetzt starten, mit der gewählten Person als Verantwortlichem. Die Arten von Aktivitäten legt logbuchSofortStarten selbst an.
     Danach gilt der Schnellstart als fertig; die Adresse der Aktivität öffnet das Cockpit. */
  Daten.prototype.schnellstartStarten = function (roh) {
    var self = this;
    roh = roh || {};
    return this.schnellstartLesen().then(function (s) {
      if (!s.personId || !s.fahrzeugId) return { ok: false, fehler: { allgemein: 'Bitte lege zuerst eine Person und ein Fahrzeug an.' } };
      return self.logbuchSofortStarten({ fahrzeugId: s.fahrzeugId, verantwortlichId: s.personId, artId: roh.artId || '', bisDatum: roh.bisDatum || '' }).then(function (r) {
        if (!r.ok) return r;
        return self.schnellstartSetzen({ stand: 'fertig', aktivitaetId: r.id }).then(function () { return r; });
      });
    });
  };

  /* ---------- Logbuch-Kern: Tagesabschnitte, Ereignisse, Prüfung zum Tagesbeginn ---------- */
  var ABSCHNITT_FELDER = [
    { key: 'datum', label: 'Datum', typ: 'datum' },
    { key: 'beginnZeit', label: 'Beginn (Uhrzeit)', typ: 'zeit' },
    { key: 'endeZeit', label: 'Ende (Uhrzeit)', typ: 'zeit' },
    { key: 'von', label: 'Von', typ: 'text' },
    { key: 'nach', label: 'Nach', typ: 'text' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'zielTatsaechlich', label: 'Tatsächliches Ziel', typ: 'text' },
    { key: 'abschlussNotiz', label: 'Notiz zum Tagesabschluss', typ: 'text' },
    { key: 'startOrtId', label: 'Startort des Tages', typ: 'text' },
    { key: 'zielOrtId', label: 'Zielort des Tages', typ: 'text' },
    { key: 'wetterHand', label: 'Wetter (von Hand)', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];
  var EREIGNIS_FELDER = [
    { key: 'artId', label: 'Art', typ: 'text' },
    { key: 'datum', label: 'Datum', typ: 'datum' },
    { key: 'zeit', label: 'Uhrzeit', typ: 'zeit' },
    { key: 'text', label: 'Text', typ: 'text' },
    { key: 'breite', label: 'Breite', typ: 'text' },
    { key: 'laenge', label: 'Länge', typ: 'text' },
    { key: 'positionQuelle', label: 'Herkunft der Position', typ: 'text' },
    /* Quelle des Eintrags und Herkunft von Datum und Uhrzeit (seit 2.0.106) */
    { key: 'quelle', label: 'Quelle des Eintrags', typ: 'text' },
    { key: 'quelleName', label: 'Name des Geräts', typ: 'text' },
    { key: 'zeitHerkunft', label: 'Herkunft von Datum und Uhrzeit', typ: 'text' },
    { key: 'ortName', label: 'Ortsname', typ: 'text' },
    { key: 'ortNameQuelle', label: 'Herkunft des Ortsnamens', typ: 'text' },
    { key: 'zielOrtId', label: 'Ziel (Ort)', typ: 'text' },
    /* Antworten des Baukastens (seit 2.0.50) und der Kostenposten, den die Wirkung angelegt hat */
    { key: 'betrag', label: 'Betrag (€)', typ: 'zahl' },
    { key: 'ziel', label: 'Ziel', typ: 'text' },
    { key: 'kostenId', label: 'Kostenposten', typ: 'text' },
    /* Tanken (seit 2.0.51) */
    { key: 'tankName', label: 'Tank', typ: 'text' },
    { key: 'menge', label: 'Menge (l)', typ: 'zahl' },
    { key: 'literpreis', label: 'Literpreis (€)', typ: 'zahl' },
    { key: 'voll', label: 'Voll getankt', typ: 'text' },
    { key: 'fuellstandNach', label: 'Füllstand danach (l)', typ: 'zahl' },
    /* Störung als Zusammenstellung (seit 2.0.57) */
    { key: 'einschraenkung', label: 'Einschränkung', typ: 'auswahl', optionen: [{ wert: 'keine', label: 'Fahrzeug bleibt nutzbar' }, { wert: 'bedingt', label: 'Nur bedingt einsatzfähig' }, { wert: 'nicht', label: 'Nicht einsatzfähig' }] },
    { key: 'frist', label: 'Reparieren bis', typ: 'datum' },
    /* Segelmanöver (seit 2.0.129) */
    { key: 'segelNamen', label: 'Segel', typ: 'text' }, { key: 'reffstufe', label: 'Reffstufe', typ: 'text' }, { key: 'antrieb', label: 'Antrieb', typ: 'text' },
    { key: 'uebung', label: 'Übung oder Ernstfall', typ: 'text' }, { key: 'kursVor', label: 'Kurs vorher (°)', typ: 'zahl' }, { key: 'kursNach', label: 'Kurs nachher (°)', typ: 'zahl' },
    { key: 'endeStatus', label: 'Messung', typ: 'text' }, { key: 'windStaerke', label: 'Windstärke', typ: 'zahl' }, { key: 'windRichtung', label: 'Windrichtung', typ: 'text' },
    { key: 'windArt', label: 'Wind scheinbar oder wahr', typ: 'text' }, { key: 'logge', label: 'Logge', typ: 'text' }, { key: 'sicht', label: 'Sicht', typ: 'text' },
    { key: 'checklisteErledigt', label: 'Abgehakt', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];
  var WECHSEL_FELDER = [
    { key: 'abDatum', label: 'Datum des Wechsels', typ: 'datum' },
    { key: 'abZeit', label: 'Uhrzeit des Wechsels', typ: 'zeit' },
    { key: 'notiz', label: 'Notiz', typ: 'text' },
    { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }
  ];

  /* Neuester Stand je Objekt aus dem Verlauf. Kein Datenraum-Filter, kein Sortieren nach Name. */
  function neuesteStaende(objekte, verlaeufe, typ) {
    var ver = {};
    verlaeufe.forEach(function (e) { if (e.objektTyp === typ) (ver[e.objektId] = ver[e.objektId] || []).push(e); });
    return objekte.map(function (o) {
      var l = (ver[o.id] || []).slice().sort(nachNr);
      return { objekt: o, aktuell: l[l.length - 1] || null, eintraege: l };
    }).filter(function (x) { return x.aktuell; });
  }

  /* Nur Aktivitäten, die nicht storniert sind, nehmen neue Einträge an (wie bei „Angaben ändern“). */
  function logbuchAktivitaet(self, aktivitaetId, schreibend) {
    return self.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (schreibend && a.aktuell.werte.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      return { a: a };
    });
  }

  function ausserhalbVon(a, datum) { return datum < a.aktuell.werte.vonDatum || datum > a.aktuell.werte.bisDatum; }

  /*
   * Das Logbuch einer Aktivität: alle Tagesabschnitte mit ihren Ereignissen (handeingetragene und
   * automatische Wechsel des Verantwortlichen), der festgehaltenen Prüfung und dem Verantwortlichen
   * zum Tagesbeginn. Es wird nichts geschrieben.
   */
  Daten.prototype.logbuchLaden = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.speicher.wo('tagesabschnitte', 'aktivitaetId', aktivitaetId),
      this.speicher.wo('ereignisse', 'aktivitaetId', aktivitaetId), this.speicher.alle('verlaeufe'),
      this.speicher.wo('tagespruefungen', 'aktivitaetId', aktivitaetId), this.ereignisartenListe()]).then(function (r) {
      var a = r[0];
      if (!a) return null;
      var arten = {}, zuord = {}; r[5].forEach(function (x) { arten[x.objekt.id] = x.aktuell.werte.bezeichnung; zuord[x.objekt.id] = x.aktuell.werte.zuordnung; });
      var fzArt = a.fahrzeug ? a.fahrzeug.artId : null;
      /* Ereignis, dessen Art nicht (mehr) zur Fahrzeugart gehört, zum Beispiel nach einem Wechsel der Fahrzeugart (seit 2.0.37). Es bleibt erhalten. */
      function fremd(artId) { return !!(fzArt && artId && Object.prototype.hasOwnProperty.call(zuord, artId) && !MM.Logbuch.ereignisartGilt(zuord[artId], fzArt)); }
      var abschnitte = MM.Logbuch.abschnitteSortieren(neuesteStaende(r[1], r[3], 'tagesabschnitt'));
      var sichtbar = abschnitte.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; });
      var ziele = sichtbar.length ? sichtbar : abschnitte;

      var proAbschnitt = {};
      abschnitte.forEach(function (x) { proAbschnitt[x.objekt.id] = []; });
      neuesteStaende(r[2], r[3], 'ereignis').forEach(function (e) {
        var w = e.aktuell.werte;
        if (!proAbschnitt[e.objekt.abschnittId]) return;
        proAbschnitt[e.objekt.abschnittId].push({ art: 'ereignis', id: e.objekt.id, artName: arten[w.artId] || 'unbekannt', datum: w.datum, zeit: w.zeit,
          /* Segelmanöver (seit 2.0.129): Die festgehaltenen Werte stehen im Logbuch und auf der Karte hinter dem Text. */
          zeitpunkt: MM.Logbuch.ereignisZeit(w),
          manoeverLauf: w.endeStatus === 'laeuft' && w.ausgeblendet !== 'ja' ? { art: w.endeArt, startMs: w.startMs, kursVor: w.kursVor, geschwVor: w.geschwVor, mob: !!w.mob } : null, text: [w.text, MM.Segeln ? MM.Segeln.zusammenfassung(w) : '', MM.Mob ? MM.Mob.logbuchText(w) : ''].filter(Boolean).join(' · ') || null, ausgeblendet: w.ausgeblendet === 'ja',
          nachgetragen: w.nachgetragen === 'ja', nachgetragenAm: w.nachgetragenAm || null, erstelltAm: e.objekt.erstelltAm || null, hatFoto: !!w.dateiName, geaendert: e.eintraege.filter(function (v) { return v.quelle !== 'aktion'; }).length > 1, positionAenderungen: e.eintraege.filter(function (v) { return !!v.positionAenderung; }).sort(nachNr).map(function (v) { return v.positionAenderung; }), fremdeArt: fremd(w.artId),
          ortName: w.ortName || null, ortNameQuelle: w.ortNameQuelle || null, zielOrtId: w.zielOrtId || null, breite: typeof w.breite === 'number' ? w.breite : null, laenge: typeof w.laenge === 'number' ? w.laenge : null, positionQuelle: w.positionQuelle || null,
          quelle: MM.Logbuch.quelleNormal(w.quelle), quelleName: w.quelleName || null, zeitHerkunft: MM.Logbuch.zeitHerkunftNormal(w.zeitHerkunft) });
      });
      MM.Logbuch.wechselEreignisse(a.verantwortung).forEach(function (wz) {
        var ziel = MM.Logbuch.abschnittFuer(ziele, wz.datum);
        if (!ziel) return;
        proAbschnitt[ziel.objekt.id].push({ art: 'wechsel', id: wz.verantwortungId, artName: MM.Logbuch.WECHSEL_ART, datum: wz.datum, zeit: wz.zeit,
          zeitpunkt: wz.ab, text: wz.text, notiz: wz.notiz, ausgeblendet: wz.ausgeblendet, nachgetragen: !!wz.nachgetragenAm, nachgetragenAm: wz.nachgetragenAm, pruefung: wz.pruefung, hatFoto: false, geaendert: wz.geaendert,
          breite: typeof wz.breite === 'number' ? wz.breite : null, laenge: typeof wz.laenge === 'number' ? wz.laenge : null, positionQuelle: wz.positionQuelle || null,
          quelle: 'nutzer', quelleName: null, zeitHerkunft: wz.zeitHerkunft || null });
      });

      /* Rudergängerwechsel (seit 2.0.106): ein eigener automatischer Eintrag, getrennt vom Verantwortungswechsel */
      MM.Rudergaenger.wechselEreignisse(a.rudergaengerStart, a.rudergaenger).forEach(function (rz) {
        var ziel = MM.Logbuch.abschnittFuer(ziele, rz.datum);
        if (!ziel) return;
        proAbschnitt[ziel.objekt.id].push({ art: 'ruder', id: rz.rudergaengerId, aktivitaetId: a.aktivitaet.id, artName: MM.Rudergaenger.ART, datum: rz.datum, zeit: rz.zeit, zeitpunkt: rz.ab, text: rz.text, notiz: null,
          ausgeblendet: false, nachgetragen: !!rz.nachgetragenAm, nachgetragenAm: rz.nachgetragenAm, pruefung: null, hatFoto: false, geaendert: false,
          breite: typeof rz.breite === 'number' ? rz.breite : null, laenge: typeof rz.laenge === 'number' ? rz.laenge : null, positionQuelle: rz.positionQuelle || null,
          quelle: 'nutzer', quelleName: null, zeitHerkunft: rz.zeitHerkunft });
      });

      var pruefungen = {};
      r[4].slice().sort(function (x, y) { return x.erstelltAm < y.erstelltAm ? 1 : (x.erstelltAm > y.erstelltAm ? -1 : 0); })
        .forEach(function (p) { (pruefungen[p.abschnittId] = pruefungen[p.abschnittId] || []).push(p); });

      var liste = abschnitte.map(function (x) {
        var w = x.aktuell.werte;
        var tb = w.datum + 'T' + (w.beginnZeit || '00:00');
        var v = MM.Aktivitaeten.verantwortlicher(a.verantwortung, tb);
        var ereignisse = MM.Logbuch.ereignisseSortieren(proAbschnitt[x.objekt.id]);
        var verlauf = verlaufAus(x.eintraege, ABSCHNITT_FELDER);
        return { objekt: x.objekt, aktuell: x.aktuell, verlauf: verlauf, ausgeblendet: w.ausgeblendet === 'ja', ausserhalb: ausserhalbVon(a, w.datum),
          tagesbeginn: tb, verantwortlicher: v ? { personId: v.personId, name: v.name } : null,
          ereignisse: ereignisse, anzahlEreignisse: ereignisse.filter(function (e) { return !e.ausgeblendet; }).length,
          pruefungen: pruefungen[x.objekt.id] || [], pruefung: (pruefungen[x.objekt.id] || [])[0] || null };
      });
      var fehlend = MM.Logbuch.fehlendeTage(a.aktuell.werte, abschnitte.map(function (x) { return x.aktuell.werte.datum; }));
      return { aktivitaet: a, abschnitte: liste, fehlend: fehlend.neu.length, zuLang: fehlend.zuLang };
    });
  };

  /* Ein Abschnitt mit allem, was dazugehört (aus derselben Quelle wie das Logbuch). */
  Daten.prototype.abschnittLaden = function (id) {
    var self = this;
    return this.speicher.holen('tagesabschnitte', id).then(function (o) {
      if (!o) return null;
      return self.logbuchLaden(o.aktivitaetId).then(function (l) {
        if (!l) return null;
        var x = l.abschnitte.filter(function (y) { return y.objekt.id === id; })[0];
        return x ? { abschnitt: x, aktivitaet: l.aktivitaet } : null;
      });
    });
  };

  /* Prüft die Angaben eines Abschnitts. */
  Daten.prototype.pruefenAbschnitt = function (roh) {
    roh = roh || {};
    var felder = [{ key: 'datum', typ: 'datum' }, { key: 'beginnZeit', typ: 'zeit' }, { key: 'endeZeit', typ: 'zeit' },
      { key: 'von', typ: 'text' }, { key: 'nach', typ: 'text' }, { key: 'notiz', typ: 'text' }];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    if (!w.datum && !f.datum) f.datum = 'Bitte das Datum des Tages angeben.';
    if (w.beginnZeit && w.endeZeit && w.endeZeit < w.beginnZeit && !f.endeZeit) f.endeZeit = 'Die Uhrzeit des Endes liegt vor der des Beginns.';
    /* Etappe (seit 2.0.43): Start- und Zielort aus der Ortsliste und das Wetter von Hand. Nur was mitkommt, wird übernommen. */
    var hat = function (k) { return Object.prototype.hasOwnProperty.call(roh, k); };
    ['startOrtId', 'zielOrtId'].forEach(function (k) { if (hat(k)) w[k] = trimmed2(roh[k]) || null; });
    if (hat('wetterHand')) {
      var wh = trimmed2(roh.wetterHand);
      if (wh.length > 200) f.wetterHand = 'Bitte höchstens 200 Zeichen eingeben.';
      w.wetterHand = wh || null;
    }
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* Gibt es die gewählten Orte des Tages im eigenen Datenraum? null oder die Fehler. */
  function etappeOrteFehler(self, w) {
    var felder = [['startOrtId', 'Den Startort gibt es nicht.'], ['zielOrtId', 'Den Zielort gibt es nicht.']].filter(function (x) { return w[x[0]]; });
    if (!felder.length) return Promise.resolve(null);
    return Promise.all(felder.map(function (x) { return self.speicher.holen('orte', w[x[0]]); })).then(function (r) {
      var f = {};
      felder.forEach(function (x, i) { if (!r[i] || r[i].datenraumId !== self.datenraumId) f[x[0]] = x[1]; });
      return Object.keys(f).length ? f : null;
    });
  }

  /* Die App bereitet die Tage aus dem Zeitraum der Aktivität vor. Bestehende Abschnitte bleiben unberührt. */
  Daten.prototype.tagesabschnitteVorbereiten = function (aktivitaetId) {
    var self = this;
    return logbuchAktivitaet(this, aktivitaetId, true).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      return self.speicher.wo('tagesabschnitte', 'aktivitaetId', aktivitaetId).then(function (vorhanden) {
        return self.speicher.alle('verlaeufe').then(function (vl) {
          var daten = neuesteStaende(vorhanden, vl, 'tagesabschnitt').map(function (x) { return x.aktuell.werte.datum; });
          var f = MM.Logbuch.fehlendeTage(k.a.aktuell.werte, daten);
          if (f.zuLang) return { ok: false, fehler: { allgemein: 'Der Zeitraum ist länger als ' + MM.Logbuch.MAX_TAGE + ' Tage. Lege die Tage von Hand an.' } };
          var jetzt = self.jetzt(), liste = [];
          f.neu.forEach(function (w) {
            var o = { id: neueId('tg'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, herkunft: 'vorbereitet', erstelltAm: jetzt };
            liste.push({ tabelle: 'tagesabschnitte', objekt: o });
            liste.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('tagesabschnitt', o.id, 1, w, null, jetzt) });
          });
          if (!liste.length) return { ok: true, anzahl: 0 };
          return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, anzahl: f.neu.length }; });
        });
      });
    });
  };

  /* Einen Tag von Hand ergänzen. */
  Daten.prototype.abschnittAnlegen = function (aktivitaetId, roh) {
    var self = this;
    return logbuchAktivitaet(this, aktivitaetId, true).then(function (k) {
      if (k.fehler) return { ok: false, fehler: k.fehler };
      var p = self.pruefenAbschnitt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      p.werte.ausgeblendet = 'nein';
      return etappeOrteFehler(self, p.werte).then(function (fo) {
        if (fo) return { ok: false, fehler: fo };
        return self.mitVerlaufAnlegen('tagesabschnitte', 'tagesabschnitt', 'tg', p.werte, { aktivitaetId: aktivitaetId, herkunft: 'hand' });
      });
    });
  };

  Daten.prototype.abschnittAendern = function (id, roh) {
    var self = this;
    return this.abschnittLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenAbschnitt(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      /* Die Angaben des Tagesabschlusses stehen nicht im Formular „Tag ändern“ und bleiben unberührt. */
      var neu = Object.assign({}, x.abschnitt.aktuell.werte, p.werte);
      return etappeOrteFehler(self, neu).then(function (fo) {
        if (fo) return { ok: false, fehler: fo };
        return self.mitVerlaufAendern('tagesabschnitt', id, { aktuell: x.abschnitt.aktuell }, neu, ABSCHNITT_FELDER);
      });
    });
  };

  /* Die Prüfung der Aktivität zum Tagesbeginn festhalten (nur anhängen, nichts wird überschrieben). */
  Daten.prototype.tagesPruefungFesthalten = function (abschnittId) {
    var self = this;
    return this.abschnittLaden(abschnittId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      return self.aktivitaetPruefung(x.aktivitaet.aktivitaet.id).then(function (pr) {
        var stand = MM.Logbuch.pruefungFestgehalten(pr, x.abschnitt.verantwortlicher, x.abschnitt.tagesbeginn);
        var rec = { id: neueId('tp'), datenraumId: self.datenraumId, aktivitaetId: x.aktivitaet.aktivitaet.id, abschnittId: abschnittId, stand: stand, erstelltAm: self.jetzt() };
        return self.speicher.speichern('tagespruefungen', rec).then(function () { return { ok: true, id: rec.id }; });
      });
    });
  };

  /* ---------- Ereignisse ---------- */
  /* nachtragen = true: Der Zeitpunkt ist der echte, vergangene Zeitpunkt; das Ereignis steht dann als „nachgetragen am …“ da. */
  Daten.prototype.pruefenEreignis = function (roh, arten, nachtragen, bisherigeArt) {
    roh = roh || {};
    var felder = [
      { key: 'artId', typ: 'auswahl', optionen: arten.filter(function (a) { return a.aktuell.werte.ausgeblendet !== 'ja' || a.objekt.id === bisherigeArt; })
        .map(function (a) { return { wert: a.objekt.id, label: a.aktuell.werte.bezeichnung }; }) },
      { key: 'datum', typ: 'datum' }, { key: 'zeit', typ: 'zeit' }, { key: 'text', typ: 'text' }
    ];
    var p = pruefeWerte(felder, roh, jahrVon(this), { ohneBezeichnung: true });
    var w = p.werte, f = p.fehler;
    if (!w.artId && !f.artId) f.artId = arten.length ? 'Bitte die Art des Ereignisses wählen.' : 'Es gibt noch keine Art. Übernimm zuerst die Vorschläge oder lege eine Art an.';
    if (!w.datum && !f.datum) f.datum = 'Bitte das Datum angeben.';
    if (!w.zeit && !f.zeit) f.zeit = 'Bitte die Uhrzeit angeben.';
    if (nachtragen && w.datum && w.zeit && !f.datum && !f.zeit && w.datum + 'T' + w.zeit > this.jetztLokal()) {
      f.zeit = 'Ein Nachtrag liegt in der Vergangenheit. Der Zeitpunkt darf nicht nach jetzt liegen.';
    }
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    /* Position und Ortsname (seit 2.0.21): nur wenn die Eingaben sie überhaupt nennen, sonst bleibt ein bestehender Stand unverändert. */
    if (roh.breite !== undefined || roh.laenge !== undefined || roh.ortName !== undefined) {
      var pos = MM.Logbuch.positionPruefen(roh);
      Object.keys(pos.werte).forEach(function (k) { w[k] = pos.werte[k]; });
      Object.keys(pos.fehler).forEach(function (k) { f[k] = pos.fehler[k]; });
    }
    return { werte: w, fehler: f, ok: Object.keys(f).length === 0 };
  };

  /* ---------- Position: Gerät und gelernte Ortsnamen (seit 2.0.21) ---------- */
  var POSITIONSNAMEN_DOK = 'positionsnamen';

  /* Die Kennung dieses Geräts. Sie entsteht beim ersten Bedarf und gehört zum Gerät (nicht in die Sicherung). */
  Daten.prototype.geraetKennung = function () {
    var self = this;
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      if (dok && dok.geraetId) return dok.geraetId;
      var id = neueId('ge');
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, geraetId: id })).then(function () { return id; });
    });
  };

  /* Alle gelernten Ortsnamen, nach Name sortiert: [{ name, breite, laenge, n, zuletzt }] */
  Daten.prototype.positionsnamenListe = function () {
    return this.speicher.holen('einstellungen', POSITIONSNAMEN_DOK).then(function (dok) {
      return ((dok && dok.punkte) || []).slice().sort(function (a, b) { return a.name.localeCompare(b.name, 'de'); });
    });
  };

  /* Zu dieser Position: der Name eines bekannten Ortes im Umfeld, oder null. { name, abstand } */
  Daten.prototype.ortNameVorschlag = function (breite, laenge) {
    if (typeof breite !== 'number' || typeof laenge !== 'number') return Promise.resolve(null);
    /* Seit 2.0.28 zuerst die Orte mit Position (die eine Quelle), dann die gelernten Namen. Der näher liegende gewinnt, bei Gleichstand der Ort. */
    return Promise.all([this.speicher.holen('einstellungen', POSITIONSNAMEN_DOK), this.ortZuPosition(breite, laenge)]).then(function (r) {
      var gelernt = MM.Logbuch.ortSuchen(r[0] && r[0].punkte, breite, laenge), ort = r[1];
      if (ort && (!gelernt || ort.abstand <= gelernt.abstand)) return { name: ort.name, abstand: ort.abstand, ortId: ort.ortId, standortId: ort.standortId };
      return gelernt;
    });
  };

  /* Nach dem Speichern: Hat der Nutzer zur Position einen Namen eingegeben oder bestätigt, merkt sich die App ihn. */
  Daten.prototype.ortLernenNachSpeichern = function (w) {
    var self = this;
    if (!w || typeof w.breite !== 'number' || typeof w.laenge !== 'number' || !w.ortName || w.ortNameQuelle !== 'hand') return Promise.resolve(false);
    return this.speicher.holen('einstellungen', POSITIONSNAMEN_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', MM.Logbuch.ortLernen(dok, w.ortName, w.breite, w.laenge, self.jetzt()));
    }).then(function () { return true; });
  };

  Daten.prototype.ereignisAnlegen = function (abschnittId, roh, optionen) {
    var self = this;
    var nachtragen = !!(optionen && optionen.nachtragen);
    roh = roh || {};
    return Promise.all([this.abschnittLaden(abschnittId), this.ereignisartenListe(), this.geraetKennung()]).then(function (r) {
      var x = r[0];
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = self.pruefenEreignis(roh, r[1], nachtragen, optionen && optionen.erlaubteArt || null);
      var fehler = p.fehler, w = p.werte;
      /* Störung im Logbuch (seit 2.0.26): Das Ereignis „Störung“ legt den Werkstatt-Vorgang an, es gibt nur eine Störung.
         Ohne Angabe gilt „Fahrzeug bleibt nutzbar“ (vorbelegt, Festlegung des Nutzers vom 04.11.2026); der Nutzer ändert es beim Vorgang.
         Die Störung hängt am Fahrzeug der Aktivität. Auch ein Nachtrag legt den Vorgang an, mit dem Datum des Ereignisses. */
      var gewaehlteArt = r[1].filter(function (a) { return a.objekt.id === w.artId; })[0];
      var stoerung = !!gewaehlteArt && MM.Logbuch.istStoerungArt(gewaehlteArt.aktuell.werte.bezeichnung);
      var vorgangWerte = null;
      if (stoerung && !fehler.artId) {
        var au = roh.auswirkung === undefined || roh.auswirkung === null ? '' : String(roh.auswirkung).trim();
        if (!au) au = 'keine';
        if (!MM.Werkstatt.AUSWIRKUNGEN.some(function (o) { return o.wert === au; })) fehler.auswirkung = 'Bitte wählen, wie weit die Störung das Fahrzeug einschränkt.';
        else if (w.datum && w.zeit) {
          var vw = MM.Werkstatt.ausEreignis(w.text, w.datum, w.zeit, self.heute());
          var vp = self.pruefenVorgang({ bezeichnung: vw.bezeichnung, beschreibung: vw.beschreibung, auswirkung: au, gemeldetAm: vw.gemeldetAm }, 'stoerung');
          if (!vp.ok) fehler.allgemein = 'Die Störung konnte nicht als Vorgang in der Werkstatt angelegt werden: ' + Object.keys(vp.fehler).map(function (k) { return vp.fehler[k]; }).join(' ');
          else vorgangWerte = vp.werte;
        }
      }
      /* Schnelles Eintragen (Cockpit): Kennt die App den Ort im Umfeld, steht ihr Name als Vorschlag dabei. Gelernt wird er erst, wenn der Nutzer ihn bestätigt. */
      var vorschlag = optionen && optionen.ortVorschlag && !fehler.breite && !fehler.laenge && typeof w.breite === 'number' && !w.ortName
        ? self.ortNameVorschlag(w.breite, w.laenge) : Promise.resolve(null);
      return vorschlag.then(function (v) {
      if (v) { w.ortName = v.name; w.ortNameQuelle = 'vorschlag'; }
      /* Weicht die Zeit um mehr als 5 Minuten von jetzt ab (in der Vergangenheit), ist es automatisch ein Nachtrag (wie in V1). */
      if (!nachtragen && !Object.keys(fehler).length && MM.Logbuch.zeitpunktArt(w.datum, w.zeit, self.jetztLokal()) === 'nachtrag') nachtragen = true;
      var datei = roh.datei;
      if (datei && !(typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Diese Datei ist leer.';
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      /* Status des Fahrzeugs (seit 2.0.23): Ein Ereignis „jetzt“ wird nur gespeichert, wenn es im aktuellen Status möglich ist.
         Das Nachtragen mit früherer Uhrzeit wird nie gesperrt, damit Vergessenes nachgetragen werden kann. */
      var artGewaehlt = nachtragen ? null : r[1].filter(function (a) { return a.objekt.id === w.artId; })[0];
      var statusPruefung = artGewaehlt ? self.fahrzeugStatus(x.aktivitaet.aktuell.werte.fahrzeugId) : Promise.resolve(null);
      return statusPruefung.then(function (st) {
      if (st && st.ok) {
        var pr = st.pruefe(artGewaehlt.aktuell.werte.bezeichnung);
        if (!pr.erlaubt) return { ok: false, gesperrt: true, grund: pr.grund, status: pr.statusName,
          fehler: { allgemein: '„' + artGewaehlt.aktuell.werte.bezeichnung + '“ geht jetzt nicht, das Fahrzeug hat den Status „' + pr.statusName + '“ (' + pr.grund + '). Hast du etwas vergessen? Dann trage es mit der echten Uhrzeit nach.' } };
      }
      var jetzt = self.jetzt();
      w.ausgeblendet = 'nein';
      w.nachgetragen = nachtragen ? 'ja' : 'nein';
      w.nachgetragenAm = nachtragen ? jetzt : null;
      w.dateiName = datei ? String(datei.name || 'Foto') : null;
      w.dateiTyp = datei ? String(datei.type || '') : null;
      w.dateiGroesse = datei ? datei.size : null;
      w.geraetId = r[2];
      /* Quelle und Herkunft (seit 2.0.106): Ohne Angabe ist der Eintrag vom Nutzer und die Uhrzeit von Hand. */
      w.quelle = MM.Logbuch.quelleNormal(optionen && optionen.quelle);
      w.quelleName = w.quelle === 'fahrzeug' && optionen && optionen.quelleName ? String(optionen.quelleName) : null;
      w.zeitHerkunft = MM.Logbuch.zeitHerkunftNormal(optionen && optionen.zeitHerkunft) || 'hand';
      var e = { id: neueId('ev'), datenraumId: self.datenraumId, aktivitaetId: x.aktivitaet.aktivitaet.id, abschnittId: abschnittId, erstelltAm: jetzt };
      var liste = [{ tabelle: 'ereignisse', objekt: e }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ereignis', e.id, 1, w, null, jetzt) }];
      var vorgangId = null;
      if (vorgangWerte) {
        /* Ereignis, Vorgang und beider Verlauf werden zusammen gespeichert: ganz oder gar nicht. */
        vorgangWerte.art = 'stoerung'; vorgangWerte.status = 'offen'; vorgangWerte.erledigtAm = null; vorgangWerte.erledigtNotiz = null;
        var vg = { id: neueId('vg'), fahrzeugId: x.aktivitaet.aktuell.werte.fahrzeugId, komponenteId: null, erstelltAm: jetzt, ereignisId: e.id };
        vorgangId = vg.id; e.vorgangId = vg.id;
        liste.push({ tabelle: 'vorgaenge', objekt: vg }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('vorgang', vg.id, 1, vorgangWerte, null, jetzt) });
      }
      if (datei) liste.push({ tabelle: 'ereignisdateien', objekt: { id: neueId('ed'), ereignisId: e.id, name: w.dateiName, mime: w.dateiTyp, groesse: w.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      return self.speicher.mehrereSpeichern(liste).then(function () { return self.ortLernenNachSpeichern(w); }).then(function () {
        return { ok: true, id: e.id, vorgangId: vorgangId, breite: w.breite === undefined ? null : w.breite, laenge: w.laenge === undefined ? null : w.laenge, ortName: w.ortName || null, ortNameQuelle: w.ortNameQuelle || null };
      }).catch(function (err) {
        if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei.' } };
        throw err;
      });
      });
      });
    });
  };

  /* ---------- Status des Fahrzeugs (seit 2.0.23) ----------
   * Der Status gehört zum Fahrzeug und wird aus allen sichtbaren Ereignissen seiner Aktivitäten nach Uhrzeit gerechnet,
   * nichts wird dafür gemerkt. Die Regeln stehen in js/status.js, die Regel einer Art hängt an der Art (nicht am Namen).
   * Ergebnis: { ok, fahrzeugId, welt, hatStatus, stand (MM.Status.rechnen), regeln: [{ name, artId, regel }], pruefe(artName) } */
  Daten.prototype.fahrzeugStatus = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.fahrzeugListe({ alle: true }), this.aktivitaetenListe(), this.ereignisartenListe()]).then(function (r) {
      var fz = r[0].filter(function (f) { return f.fahrzeug.id === fahrzeugId; })[0];
      if (!fz) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      var welt = MM.Fahrzeugarten.artSicher(fz.fahrzeug.art).welt;
      var arten = {}, regeln = [];
      r[2].forEach(function (a) {
        var w = a.aktuell.werte;
        arten[String(w.bezeichnung || '').trim().toLowerCase()] = w;
        if (w.ausgeblendet === 'ja') return;
        if (!MM.Logbuch.ereignisartGilt(w.zuordnung, fz.fahrzeug.art)) return;
        regeln.push({ name: w.bezeichnung, artId: a.objekt.id, regel: MM.Status.regelFuer(w, welt) });
      });
      var meine = r[1].filter(function (a) { return a.aktuell.werte.fahrzeugId === fahrzeugId && a.aktuell.werte.status !== 'storniert' && a.status !== 'storniert'; });
      return Promise.all(meine.map(function (a) { return self.logbuchLaden(a.objekt.id); })).then(function (lbs) {
        var ereignisse = [];
        lbs.forEach(function (lb) {
          if (!lb) return;
          lb.abschnitte.forEach(function (x) {
            if (x.ausgeblendet) return;
            x.ereignisse.forEach(function (e) { if (e.art === 'ereignis' && !e.ausgeblendet) ereignisse.push({ id: e.id, artName: e.artName, zeitpunkt: e.zeitpunkt, erstelltAm: e.erstelltAm || null }); });
          });
        });
        var stand = MM.Status.rechnen(ereignisse, arten, welt, self.jetztLokal());
        function regelVonName(n) {
          var w = arten[String(n || '').trim().toLowerCase()];
          return MM.Status.regelFuer(w || { bezeichnung: n }, welt);
        }
        return { ok: true, fahrzeugId: fahrzeugId, welt: welt, hatStatus: MM.Status.hatStatus(welt), stand: stand, regeln: regeln,
          pruefe: function (artName) { return MM.Status.pruefen(regelVonName(artName), stand, regeln); } };
      });
    });
  };

  Daten.prototype.ereignisLaden = function (id) {
    var self = this;
    return this.mitVerlaufLaden('ereignisse', id, EREIGNIS_FELDER).then(function (x) {
      if (!x) return null;
      return Promise.all([self.ereignisartenListe(), self.abschnittLaden(x.objekt.abschnittId), self.speicher.wo('ereignisdateien', 'ereignisId', id)]).then(function (r) {
        var arten = {}; r[0].forEach(function (a) { arten[a.objekt.id] = a.aktuell.werte.bezeichnung; });
        x.verlauf.forEach(function (v) {
          v.aenderungen.forEach(function (u) {
            if (u.key === 'artId') { u.feld = { typ: 'text' }; u.alt = u.alt ? arten[u.alt] || 'unbekannt' : null; u.neu = u.neu ? arten[u.neu] || 'unbekannt' : null; }
            if (u.key === 'kostenId') { u.feld = { typ: 'text' }; u.alt = u.alt ? 'angelegt' : null; u.neu = u.neu ? 'angelegt' : null; }
            /* Herkunft in Worten (seit 2.0.21) */
            var herkunft = { gps: 'GPS', hand: u.key === 'ortNameQuelle' ? 'von dir eingegeben oder bestätigt' : 'von Hand', vorschlag: 'Vorschlag der App' };
            if (u.key === 'positionQuelle' || u.key === 'ortNameQuelle') { u.alt = u.alt ? herkunft[u.alt] || u.alt : null; u.neu = u.neu ? herkunft[u.neu] || u.neu : null; }
            if (u.key === 'quelle') { u.alt = u.alt ? MM.Logbuch.quelleText(u.alt) : null; u.neu = u.neu ? MM.Logbuch.quelleText(u.neu) : null; }
            if (u.key === 'zeitHerkunft') { u.alt = u.alt ? MM.Logbuch.zeitHerkunftText(u.alt) : null; u.neu = u.neu ? MM.Logbuch.zeitHerkunftText(u.neu) : null; }
          });
        });
        var w = x.aktuell.werte, d = r[2][0];
        return { ereignis: x.objekt, aktuell: x.aktuell, verlauf: x.verlauf, art: w.artId ? { id: w.artId, name: arten[w.artId] || 'unbekannt' } : null, arten: r[0],
          abschnitt: r[1] ? r[1].abschnitt : null, aktivitaet: r[1] ? r[1].aktivitaet : null,
          datei: d ? { id: d.id, name: d.name, mime: d.mime, groesse: d.groesse } : null };
      });
    });
  };

  /* Antworten nach dem Antippen eines Knopfes (seit 2.0.47, erweitert 2.0.50): Text, Foto, Betrag, Ziel (und die Kennung des Kostenpostens)
   * kommen zu einem Ereignis dazu, das schon gespeichert ist (Wo und Wann stehen davor fest). Der neue Stand im Verlauf hat die Quelle
   * „aktion“ und zählt im Logbuch nicht als „korrigiert“.
   * roh: { text, datei, betrag, ziel, kostenId }. Ein vorhandener Text bleibt, wenn kein neuer kommt. Zu einem Ereignis gehört höchstens eine Datei.
   * Ein Ziel steht zusätzlich als Zeile „Navigation zu: …“ im Text, wie seit 2.0.47. */
  Daten.prototype.ereignisAktionSpeichern = function (id, roh) {
    var self = this;
    roh = roh || {};
    return this.ereignisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      if (x.aktivitaet && x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var alt = x.aktuell.werte, neu = Object.assign({}, alt), datei = roh.datei || null, fehler = {}, geaendert = false;
      var text = roh.text === undefined || roh.text === null ? '' : String(roh.text).trim();
      if (text) {
        if (text.length > 2000) fehler.text = 'Der Text ist zu lang (höchstens 2000 Zeichen).';
        else { neu.text = text; }
      }
      var ziel = roh.ziel === undefined || roh.ziel === null ? '' : String(roh.ziel).trim();
      if (ziel) {
        if (ziel.length > 200) fehler.ziel = 'Das Ziel ist zu lang (höchstens 200 Zeichen).';
        else {
          neu.ziel = ziel;
          /* Eine frühere Zeile „Navigation zu: …“ wird ersetzt, der übrige Text bleibt. */
          var ohneZiel = String(neu.text || '').split('\n').filter(function (z) { return z.indexOf('Navigation zu: ') !== 0; }).join('\n').trim();
          neu.text = (ohneZiel ? ohneZiel + '\n' : '') + 'Navigation zu: ' + ziel;
          if (neu.text.length > 2000) fehler.text = 'Der Text ist zu lang (höchstens 2000 Zeichen).';
        }
      }
      /* Ziel aus der Ortsliste (seit 2.0.60): Der Ort steht beim Eintrag, dazu eine Zeile „Wunschziel: …“ im Text (wie „Navigation zu: …“).
       * Geprüft hat es ereignisAblaufAusfuehren. Ein leeres Ziel löscht nichts. */
      if (roh.zielOrt && roh.zielOrt.id) {
        neu.zielOrtId = roh.zielOrt.id;
        var ohneWunsch = String(neu.text || '').split('\n').filter(function (zl) { return zl.indexOf('Wunschziel: ') !== 0; }).join('\n').trim();
        neu.text = (ohneWunsch ? ohneWunsch + '\n' : '') + 'Wunschziel: ' + roh.zielOrt.name;
        if (neu.text.length > 2000) fehler.text = 'Der Text ist zu lang (höchstens 2000 Zeichen).';
      }
      if (roh.betrag !== undefined && roh.betrag !== null && String(roh.betrag).trim() !== '') {
        var b = Number(String(geldRoh(roh.betrag)).replace(',', '.'));
        if (!isFinite(b) || !(b > 0)) fehler.betrag = 'Bitte einen Betrag über 0 eingeben, zum Beispiel 45,50.';
        else if (b > 10000000) fehler.betrag = 'Der Betrag ist zu groß.';
        else neu.betrag = MM.Kosten ? MM.Kosten.runde(b) : Math.round(b * 100) / 100;
      }
      if (roh.kostenId) neu.kostenId = String(roh.kostenId);
      /* Tanken (seit 2.0.51): Die Antworten kommen unverändert zum Eintrag, geprüft hat sie ereignisAblaufAusfuehren. */
      if (roh.tank) {
        ['tankId', 'tankName', 'menge', 'literpreis', 'voll', 'fuellstandNach', 'tankGebucht', 'verbrauch', 'tankArt', 'tankStunden', 'tankStrecke', 'mengeEingabe', 'preisEingabe', 'entsorgungArt', 'entsorgungName', 'kraftstoff'].forEach(function (k) { if (roh.tank[k] !== undefined && roh.tank[k] !== null) neu[k] = roh.tank[k]; });
      }
      /* Ein und Aus (seit 2.0.52): Welcher Verbraucher, ein oder aus, und der Lauf. Geprüft und gebucht hat es ereignisAblaufAusfuehren. */
      if (roh.lauf) {
        ['verbraucherId', 'verbraucherName', 'laufArt', 'laufId', 'laufGebucht'].forEach(function (k) { if (roh.lauf[k] !== undefined && roh.lauf[k] !== null) neu[k] = roh.lauf[k]; });
      }
      /* Störung (seit 2.0.57): Einschränkung und Frist, so wie sie beim Vorgang gelandet sind. */
      if (roh.stoerung) {
        ['einschraenkung', 'frist'].forEach(function (k) { if (roh.stoerung[k] !== undefined && roh.stoerung[k] !== null) neu[k] = roh.stoerung[k]; });
      }
      if (roh.segel) {
        Object.keys(roh.segel).forEach(function (k) {
          if (JSON.stringify(neu[k]) !== JSON.stringify(roh.segel[k])) { neu[k] = roh.segel[k]; geaendert = true; }
        });
        neu.manoever = true;
      }
      if (datei) {
        if (!(typeof datei === 'object' && datei.size > 0)) fehler.datei = 'Diese Datei ist leer.';
        else if (x.datei) fehler.datei = 'Zu diesem Ereignis gehört schon eine Datei.';
        else { neu.dateiName = String(datei.name || 'Foto'); neu.dateiTyp = String(datei.type || ''); neu.dateiGroesse = datei.size; geaendert = true; }
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      ['text', 'ziel', 'zielOrtId', 'betrag', 'kostenId', 'tankId', 'tankName', 'menge', 'literpreis', 'voll', 'fuellstandNach', 'tankGebucht', 'verbrauch', 'tankArt', 'tankStunden', 'tankStrecke', 'mengeEingabe', 'preisEingabe', 'entsorgungArt', 'entsorgungName', 'kraftstoff', 'verbraucherId', 'verbraucherName', 'laufArt', 'laufId', 'laufGebucht', 'einschraenkung', 'frist'].forEach(function (k) { if (!gleich(alt[k] === undefined ? null : alt[k], neu[k] === undefined ? null : neu[k])) geaendert = true; });
      if (!geaendert) return { ok: true, id: id, geaendert: false };
      var jetzt = self.jetzt();
      var eintrag = neuerVerlaufEintrag('ereignis', id, x.aktuell.nr + 1, neu, x.aktuell.id, jetzt);
      eintrag.quelle = 'aktion';
      var liste = [{ tabelle: 'verlaeufe', objekt: eintrag }].concat(Array.isArray(roh.zusatz) ? roh.zusatz : []);
      if (datei) liste.push({ tabelle: 'ereignisdateien', objekt: { id: neueId('ed'), ereignisId: id, name: neu.dateiName, mime: neu.dateiTyp, groesse: neu.dateiGroesse, inhalt: datei, erstelltAm: jetzt } });
      return self.speicher.mehrereSpeichern(liste).then(function () { return { ok: true, id: id, geaendert: true }; }).catch(function (err) {
        if (istQuotaFehler(err)) return { ok: false, fehler: { datei: 'Auf diesem Gerät ist nicht genug Speicherplatz frei.' } };
        throw err;
      });
    });
  };

  /* Baukasten-Gerüst (seit 2.0.50): Nach Wo und Wann kommen die Fragen der Art, danach die Wirkungen (Muster Festhalten, Fragen, Wirkungen).
   * Hier steht, was die App selbst tut. Das Öffnen der Navigations-App macht die Oberfläche (sie braucht das Gerät).
   *  antworten: { text, datei, betrag, ziel, tankId, menge, literpreis, voll, verbraucherId }. Antworten zu Fragen, die die Art nicht stellt, werden nicht beachtet.
   * Pflicht ist nur, was eine Wirkung braucht: der Betrag für den Kostenposten, das Ziel für die Navigation.
   * Ergebnis: { ok, id, zusammenstellung, kostenId, kostenNeu, betrag, ziel, navi } oder { ok: false, fehler }.
   * Ein Kostenposten wird je Ereignis nur einmal angelegt: Wer das Formular noch einmal abschickt, legt keinen zweiten an. */
  Daten.prototype.ereignisAblaufAusfuehren = function (id, antworten) {
    var self = this;
    antworten = antworten || {};
    /* Seit 2.0.63: Dichte des Stoffes (Menge in kg) und der gewählte Vorgang der Ver- und Entsorgung werden vorher geladen. */
    if (antworten._geladen === undefined && (antworten.tankId || antworten.vorgangId)) {
      return Promise.all([antworten.tankId ? this.komponenteLaden(String(antworten.tankId)) : Promise.resolve(null), this.vorgangListe()]).then(function (rr) {
        var stoff = rr[0] && rr[0].aktuell.werte.stoff;
        return (stoff ? self.stoffDichte(stoff) : Promise.resolve(null)).then(function (d) {
          var vg = antworten.vorgangId ? rr[1].filter(function (v) { return v.id === String(antworten.vorgangId); })[0] || null : null;
          return self.ereignisAblaufAusfuehren(id, Object.assign({}, antworten, { _geladen: true, _dichte: d, _vorgang: vg, _tankStoff: stoff || '' }));
        });
      });
    }
    return this.ereignisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      if (x.aktivitaet && x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var w = x.aktuell.werte, B = MM.Baukasten;
      var artObjekt = x.arten.filter(function (a) { return a.objekt.id === w.artId; })[0];
      var z = B && artObjekt ? B.zusammenstellung(artObjekt.aktuell.werte) : { fragen: [], wirkungen: [] };
      if (!z.fragen.length && !z.wirkungen.length) return { ok: false, fehler: { allgemein: 'Zu dieser Art ist nichts eingestellt.' } };
      var artName = x.art ? x.art.name : 'Ereignis';
      var hat = function (f) { return z.fragen.indexOf(f) >= 0; }, wirkt = function (a) { return z.wirkungen.indexOf(a) >= 0; };
      var leerText = function (v) { return v === undefined || v === null || String(v).trim() === ''; };
      var fehler = {};

      var text = hat('text') ? antworten.text : '', betrag = hat('betrag') ? antworten.betrag : '', ziel = hat('ziel') ? antworten.ziel : '';
      var datei = hat('foto') && !x.datei ? (antworten.datei || null) : null;

      /* Tanken (seit 2.0.51): Tank, Menge, Literpreis, voll getankt. Ist der Tankvorgang schon verbucht, wird er nicht noch einmal verbucht. */
      var tankId = hat('tank') ? String(antworten.tankId === undefined || antworten.tankId === null ? '' : antworten.tankId).trim() : '';
      var mengeRoh = hat('menge') ? antworten.menge : '', preisRoh = hat('literpreis') ? antworten.literpreis : '';
      var vollRoh = hat('voll') ? String(antworten.voll === undefined || antworten.voll === null ? '' : antworten.voll).trim() : '';
      var tankWirkt = wirkt('fuellstand') || wirkt('verbrauch') || wirkt('reichweite');
      var tankBuchen = tankWirkt && !w.tankGebucht;
      var menge = null, literpreis = null, mengeEingabe = null, preisEingabe = null;
      var mengeEin = hat('menge') && antworten.mengeEinheit === 'kg' ? 'kg' : 'l';
      /* Ver- und Entsorgung: Der gewählte Vorgang bestimmt, was passiert (auffüllen, entleeren, Flasche tauschen) */
      var vorgangDef = hat('vorgang') ? antworten._vorgang || null : null;
      var tankArt = vorgangDef ? vorgangDef.art : 'auf';
      if (hat('vorgang') && !w.tankGebucht && !vorgangDef) fehler.vorgang = 'Bitte wählen, was es ist.';
      if (!w.tankGebucht) {
        if (!leerText(mengeRoh)) {
          var mm = MM.Tanken.mengeLiter(geldRoh(mengeRoh), mengeEin, antworten._dichte);
          if (!mm.ok) fehler.menge = mm.fehler;
          else if (!(mm.liter > 0)) fehler.menge = 'Bitte die Menge eingeben, zum Beispiel 45,5. Beim Erfassen muss sie über 0 sein (0 gibt es nur beim Ändern).';
          else if (mm.liter > 100000) fehler.menge = 'Die Menge ist zu groß.';
          else { menge = mm.liter; mengeEingabe = { wert: MM.Tanken.zahl(geldRoh(mengeRoh)), einheit: mengeEin }; }
        }
        if (!leerText(preisRoh)) {
          var pn = MM.Tanken.zahl(geldRoh(preisRoh));
          literpreis = pn === null ? null : MM.Tanken.preisJeLiter(pn, mengeEin, antworten._dichte);
          if (pn === null || !(pn > 0) || literpreis === null) fehler.literpreis = mengeEin === 'kg' && pn !== null ? 'Für den Preis je kg braucht der Stoff eine Dichte.' : 'Bitte den Preis eingeben, zum Beispiel 1,799.';
          else if (literpreis > 1000) fehler.literpreis = 'Der Preis ist zu groß.';
          else preisEingabe = { wert: pn, einheit: mengeEin };
        }
        if (vollRoh !== '' && vollRoh !== 'ja' && vollRoh !== 'nein') fehler.voll = 'Bitte Ja oder Nein wählen.';
        if (tankBuchen) {
          if (!tankId) fehler.tank = 'Bitte den Tank wählen.';
          if (tankArt === 'auf') {
            if (menge === null && !fehler.menge) fehler.menge = 'Bitte die Menge eingeben.';
            if (vollRoh === '' && !fehler.voll) fehler.voll = 'Bitte wählen: Ja oder Nein.';
          } else if (tankArt === 'leer') {
            if (menge === null && vollRoh !== 'ja' && !fehler.menge) fehler.menge = 'Bitte die entleerte Menge eingeben oder „ganz leer“ wählen.';
          }
        }
        if (literpreis !== null && menge === null && !fehler.menge && leerText(betrag)) fehler.menge = 'Für den Literpreis braucht die App die Menge.';
      }
      /* Betrag: Was der Nutzer einträgt. Fehlt er, rechnet die App Menge mal Literpreis (nur bei der Wirkung „Kostenposten Treibstoff und Energie“). */
      var betragRechnen = (wirkt('kostenTreibstoff') || (vorgangDef && wirkt('kosten'))) && !w.kostenId && leerText(betrag) && menge !== null && literpreis !== null && !fehler.menge && !fehler.literpreis;
      if (betragRechnen) betrag = String(MM.Kosten ? MM.Kosten.runde(menge * literpreis) : Math.round(menge * literpreis * 100) / 100).replace('.', ',');
      var tankAngaben = !w.tankGebucht && (tankId || menge !== null || literpreis !== null || vollRoh);

      /* Ein und Aus (seit 2.0.52): Der Verbraucher kommt aus der Frage „Verbraucher“, die Wirkung schaltet ihn ein oder aus. Ist der Lauf schon
       * gebucht, wird er nicht noch einmal gebucht. */
      var verbrId = hat('verbraucher') ? String(antworten.verbraucherId === undefined || antworten.verbraucherId === null ? '' : antworten.verbraucherId).trim() : '';
      var laufArt = wirkt('verbraucherEin') ? 'ein' : (wirkt('verbraucherAus') ? 'aus' : null);
      var laufBuchen = !!laufArt && !w.laufGebucht;
      if (laufBuchen && !verbrId) fehler.verbraucher = 'Bitte den Verbraucher wählen.';

      /* Ziel aus der Ortsliste (seit 2.0.60): ein vorhandener Ort mit Position, oder ein neuer mit Name und Position. Beides zugleich geht nicht. */
      var zielOrtRoh = hat('zielOrt') ? String(antworten.zielOrtId === undefined || antworten.zielOrtId === null ? '' : antworten.zielOrtId).trim() : '';
      var neuerOrtName = hat('zielOrt') ? String(antworten.neuerOrtName === undefined || antworten.neuerOrtName === null ? '' : antworten.neuerOrtName).trim() : '';
      var neuerOrtPos = hat('zielOrt') && neuerOrtName ? { positionBreite: antworten.neuerOrtBreite, positionLaenge: antworten.neuerOrtLaenge } : null;
      var zielOrtPruefen = hat('zielOrt') && (zielOrtRoh || neuerOrtName);
      if (zielOrtRoh && neuerOrtName) fehler.zielOrt = 'Bitte entweder einen Ort aus der Liste wählen oder einen neuen anlegen.';
      var neuerOrtWerte = null;
      if (neuerOrtName && !fehler.zielOrt) {
        var po = self.pruefenOrt({ bezeichnung: neuerOrtName, positionBreite: neuerOrtPos.positionBreite, positionLaenge: neuerOrtPos.positionLaenge });
        var ohnePos = typeof po.werte.positionBreite !== 'number' || typeof po.werte.positionLaenge !== 'number';
        if (!po.ok || ohnePos) {
          fehler.zielOrt = po.fehler.bezeichnung || po.fehler.positionBreite || po.fehler.positionLaenge || 'Der neue Ort braucht einen Namen und eine Position (Breite und Länge), zum Beispiel 54,32 und 10,14.';
        } else neuerOrtWerte = po.werte;
      }

      /* Segeln (seit 2.0.129): alle Antworten freiwillig */
      var segel = segelAntworten(z, antworten, fehler);

      /* Etwas muss eingetragen sein, sonst gibt es nichts zu speichern. Bei nur einer Frage nennt die Meldung ihr Feld.
       * Ausnahme: Hat die Art die Frage „Ziel (Ort aus der Liste)“ (Ablegen), lässt sich auch leer speichern: Ort und Zeit stehen schon fest. */
      var etwas = !!segel || hat('zielOrt') || !leerText(text) || !leerText(betrag) || !leerText(ziel) || !!datei || !!tankAngaben || !!verbrId
        || (hat('einschraenkung') && !leerText(antworten.einschraenkung)) || (hat('frist') && !leerText(antworten.frist));
      if (!etwas) {
        var nurEine = z.fragen.length === 1 ? z.fragen[0] : null;
        if (nurEine === 'text') fehler.text = 'Bitte den Text eintragen oder zurück zum Cockpit gehen.';
        else if (nurEine === 'foto') fehler.datei = x.datei ? 'Zu diesem Eintrag gehört schon ein Foto.' : 'Bitte ein Foto aufnehmen oder wählen oder zurück zum Cockpit gehen.';
        else if (nurEine === 'ziel') fehler.ziel = 'Bitte das Ziel eintragen.';
        else if (nurEine === 'betrag') fehler.betrag = 'Bitte den Betrag eintragen oder zurück zum Cockpit gehen.';
        else if (nurEine === 'verbraucher') fehler.verbraucher = 'Bitte den Verbraucher wählen oder zurück zum Cockpit gehen.';
        else fehler.allgemein = 'Bitte etwas eintragen oder zurück zum Cockpit gehen.';
      }
      if (wirkt('navi') && leerText(ziel) && !fehler.ziel) fehler.ziel = 'Bitte das Ziel eintragen.';

      /* Störung (seit 2.0.57): Die Wirkung „Vorgang“ legt den Vorgang in der Werkstatt an (Beschreibung aus dem Text, Einschränkung, Frist),
       * wie das Ereignis „Störung“ im Logbuch. Je Eintrag nur einmal: Hängt schon ein Vorgang am Eintrag (auch einer, den das Logbuch
       * für das Ereignis „Störung“ angelegt hat), bleibt er unverändert. Ohne Angabe gilt „Fahrzeug bleibt nutzbar“. */
      var vorgangVorhanden = !!(x.ereignis && x.ereignis.vorgangId);
      var vorgangBuchen = wirkt('vorgang') && !vorgangVorhanden;
      var einschrRoh = hat('einschraenkung') && !vorgangVorhanden ? String(antworten.einschraenkung === undefined || antworten.einschraenkung === null ? '' : antworten.einschraenkung).trim() : '';
      var fristRoh = hat('frist') && !vorgangVorhanden ? String(antworten.frist === undefined || antworten.frist === null ? '' : antworten.frist).trim() : '';
      var vorgangPlan = null;
      if (vorgangBuchen) {
        var einschr = einschrRoh || 'keine';
        if (!MM.Werkstatt.AUSWIRKUNGEN.some(function (o) { return o.wert === einschr; })) fehler.einschraenkung = 'Bitte wählen, wie weit die Störung das Fahrzeug einschränkt.';
        var vtext = leerText(text) ? (w.text || '') : text;
        var vw = MM.Werkstatt.ausEreignis(vtext, w.datum, w.zeit, self.heute());
        var vroh = { bezeichnung: vw.bezeichnung, beschreibung: vw.beschreibung, auswirkung: einschr, gemeldetAm: vw.gemeldetAm };
        if (wirkt('vorgangFrist') && fristRoh) vroh.reparierenBis = fristRoh;
        var vp = self.pruefenVorgang(vroh, 'stoerung');
        if (!vp.ok) {
          if (vp.fehler.reparierenBis) fehler.frist = vp.fehler.reparierenBis;
          else if (!fehler.einschraenkung) fehler.allgemein = 'Die Störung konnte nicht als Vorgang in der Werkstatt angelegt werden: ' + Object.keys(vp.fehler).map(function (k) { return vp.fehler[k]; }).join(' ');
        } else vorgangPlan = vp.werte;
      }
      var kostenRoh = null;
      /* Bei Ver- und Entsorgung sind die Kosten freiwillig (zum Beispiel Entsorgungsgebühr): ohne Betrag kein Kostenposten, aber auch keine Fehlermeldung. */
      var kostenWirkt = (wirkt('kosten') || wirkt('kostenTreibstoff')) && !w.kostenId && !(vorgangDef && leerText(betrag));
      if (kostenWirkt) {
        kostenRoh = { gruppe: 'variabel', bezeichnung: artName, betrag: betrag, datum: w.datum || self.heute(), abschnittId: x.ereignis.abschnittId || '',
          ortText: w.ortName ? String(w.ortName).slice(0, 120) : '' };
        if (wirkt('kostenTreibstoff')) kostenRoh.kostenart = vorgangDef && vorgangDef.kostenart ? vorgangDef.kostenart : 'treibstoff';
        if (vorgangDef) kostenRoh.bezeichnung = vorgangDef.name;
        if (leerText(betrag)) { if (!fehler.betrag) fehler.betrag = wirkt('kostenTreibstoff') ? 'Bitte den Betrag eintragen, oder Menge und Literpreis. Daraus wird der Kostenposten.' : 'Bitte den Betrag eintragen. Er wird zum Kostenposten.'; }
        else {
          var pk = self.pruefenKosten(Object.assign({}, kostenRoh, { aktivitaetId: x.ereignis.aktivitaetId }), 'variabel');
          if (!pk.ok) fehler.betrag = pk.fehler.betrag || pk.fehler.bezeichnung || 'Der Kostenposten lässt sich so nicht anlegen. Bitte den Betrag prüfen.';
        }
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };

      /* Tank prüfen und rechnen, bevor etwas gespeichert wird. Gespeichert wird alles in einem Schritt (Ereignis und Füllstand zusammen). */
      var segelVorab = segel && antworten.segelIds && antworten.segelIds.length ? self.aktivitaetLaden(x.ereignis.aktivitaetId).then(function (a) {
        return a ? self.segelListe(a.fahrzeug.id) : [];
      }).then(function (liste) {
        var gewaehlt = liste.filter(function (s) { return antworten.segelIds.indexOf(s.id) >= 0; });
        if (hat('segel') && gewaehlt.length) { segel.segelIds = gewaehlt.map(function (s) { return s.id; }); segel.segelNamen = gewaehlt.map(function (s) { return s.name; }).join(', '); }
      }) : Promise.resolve(null);

      var vorab = (tankBuchen || (tankAngaben && tankId)) ? self.aktivitaetLaden(x.ereignis.aktivitaetId).then(function (a) {
        if (!a) return { fehler: { allgemein: 'Die Aktivität zu diesem Ereignis wurde nicht gefunden.' } };
        return self.komponentenListe(a.fahrzeug.id).then(function (liste) {
          var tk = tankId ? liste.filter(function (k) { return k.komponente.id === tankId && MM.Versorgung.istTank(k.komponente); })[0] : null;
          if (!tk) return { fehler: { tank: 'Bitte einen Tank dieses Fahrzeugs wählen.' } };
          if (!tankBuchen) return { tk: tk, liste: liste, fahrzeugId: a.fahrzeug.id };
          var verb = MM.Versorgung.verbraucherVon(liste, [tankId]).filter(function (k) { return k.aktuell.werte.verbraucher === 'ja'; });
          return Promise.all([self.stundenStaende(a.fahrzeug.id, verb.map(function (k) { return k.komponente.id; }), tankId), self.streckenStandKm(a.fahrzeug.id), self.verbrauchEinheit()]).then(function (zz) {
            var st = zz[0];
            return { tk: tk, liste: liste, fahrzeugId: a.fahrzeug.id, strecke: zz[1], einheit: zz[2], verb: verb.map(function (k) {
              return { id: k.komponente.id, name: k.aktuell.werte.bezeichnung, aus: MM.Versorgung.verbrauchAus(k.aktuell.werte), motor: MM.Komponenten.istMotor(k.komponente), stunden: typeof st[k.komponente.id] === 'number' ? st[k.komponente.id] : null };
            }) };
          });
        });
      }) : Promise.resolve(null);

      /* Ein oder Aus: prüfen und vorbereiten, gespeichert wird zusammen mit dem Eintrag in einem Schritt. Die Zeit des Eintrags gilt als Zeit
       * des Laufs, wenn sie nicht in der Zukunft und nicht vor dem Start (Aus) oder dem Ende des letzten Laufs (Ein) liegt, sonst jetzt. */
      var laufVorab = (laufBuchen && verbrId) ? self.aktivitaetLaden(x.ereignis.aktivitaetId).then(function (a) {
        if (!a) return { fehler: { allgemein: 'Die Aktivität zu diesem Ereignis wurde nicht gefunden.' } };
        return self.komponenteLaden(verbrId).then(function (c) {
          if (!c || c.fahrzeug.id !== a.fahrzeug.id || !MM.Komponenten.kannLaufen(c.komponente, c.aktuell.werte)) return { fehler: { verbraucher: 'Bitte einen Verbraucher dieses Fahrzeugs wählen.' } };
          var zeitIso = w.datum && w.zeit ? MM.Motoren.zeitpunktAusOrtszeit(w.datum, w.zeit) : null;
          /* Seit 2.0.63 mit der Wahl des Nutzers (Womit läuft es, Woher kommt der Strom, Welches Gerät), wie beim Schalter im Cockpit. */
          var wahl = { zeitpunktWennMoeglich: zeitIso, ereignisId: id };
          if (laufArt === 'ein') {
            ['versorgungId', 'stromQuelle', 'erzeugerId'].forEach(function (n) {
              var wert = antworten[n] === undefined || antworten[n] === null ? '' : String(antworten[n]).trim();
              if (wert) wahl[n] = wert;
            });
          }
          return self.verbraucherLaufVorbereiten(laufArt, verbrId, wahl).then(function (p) {
            var name = c.aktuell.werte.bezeichnung;
            if (p.ok === false) {
              var f = p.fehler || {};
              /* Die Wahl hat eigene Felder (seit 2.0.63): die Meldung steht dort, nicht beim Verbraucher. */
              var feld = {};
              if (f.versorgung) feld.versorgungId = f.versorgung;
              if (f.stromQuelle) feld.stromQuelle = f.stromQuelle;
              if (f.erzeuger) feld.erzeugerId = f.erzeuger;
              if (Object.keys(feld).length) { feld.verbraucher = '„' + name + '“: ' + (f.versorgung || f.stromQuelle || f.erzeuger); return { fehler: feld }; }
              return { fehler: { verbraucher: '„' + name + '“: ' + (f.allgemein || f.zeit || f.versorgung || f.stromQuelle || f.erzeuger || 'Das ging nicht.') } }; }
            return { p: p, name: name };
          });
        });
      }) : Promise.resolve(null);

      var zielVorab = zielOrtPruefen && !fehler.zielOrt ? self.orteListe().then(function (orte) {
        if (zielOrtRoh) {
          var o = orte.filter(function (y) { return y.objekt.id === zielOrtRoh; })[0];
          if (!o) return { fehler: { zielOrt: 'Diesen Ort gibt es nicht.' } };
          var wo = o.aktuell.werte;
          if (typeof wo.positionBreite !== 'number' || typeof wo.positionLaenge !== 'number') return { fehler: { zielOrt: '„' + wo.bezeichnung + '“ hat noch keine Position. Trage sie beim Ort ein oder lege den Ort hier neu an.' } };
          return { id: o.objekt.id, name: wo.bezeichnung, neu: false };
        }
        if (gleicherName(orte, neuerOrtName)) return { fehler: { zielOrt: 'Diesen Ort gibt es schon. Wähle ihn aus der Liste.' } };
        return { id: neueId('or'), name: neuerOrtName, neu: true };
      }) : Promise.resolve(null);

      /* Nachgetragen (vor dem letzten Füllstand), Entleeren und Flasche tauschen: die Kette des Tanks wird neu gerechnet (seit 2.0.63) */
      function ketteVorab(v0) {
        if (!tankBuchen || !v0 || !v0.tk) return Promise.resolve(null);
        var zeitV = w.datum && w.zeit ? w.datum + 'T' + w.zeit : self.jetztLokal();
        var nachgetragen = v0.tk.aktuell.werte.fuellstandZeit && zeitV < v0.tk.aktuell.werte.fuellstandZeit;
        if (!nachgetragen && tankArt === 'auf') return Promise.resolve(null);
        var ew = Object.assign({}, w, { datum: zeitV.slice(0, 10), zeit: zeitV.slice(11, 16), tankId: tankId, menge: menge, voll: vollRoh || 'nein', tankArt: tankArt, literpreis: literpreis, tankGebucht: true });
        return tankKetteVorbereiten(self, v0.fahrzeugId, tankId, { id: id, e: x.ereignis ? { aktuell: x.aktuell } : null, werte: ew, stundenJetzt: nachgetragen ? null : stundenJetztVon(v0) });
      }
      function stundenJetztVon(v0) { var st = {}; (v0.verb || []).forEach(function (k) { if (typeof k.stunden === 'number') st[k.id] = k.stunden; }); return st; }
      return Promise.all([vorab, laufVorab, zielVorab, segelVorab]).then(function (vv0) { return vv0.slice(0, 3); }).then(function (vv) {
        return ketteVorab(vv[0]).then(function (kv) { return vv.concat([kv]); });
      }).then(function (vv) {
        var v = vv[0], lv = vv[1], zv = vv[2], kv = vv[3];
        if (v && v.fehler) return { ok: false, fehler: v.fehler };
        if (lv && lv.fehler) return { ok: false, fehler: lv.fehler };
        if (zv && zv.fehler) return { ok: false, fehler: zv.fehler };
        var tank = null, tankErg = null, zusatz = [], lauf = null, laufErg = null, stoerung = null, vorgangErg = null;
        if (vorgangPlan) {
          var vjetzt = self.jetzt();
          vorgangPlan.art = 'stoerung'; vorgangPlan.status = 'offen'; vorgangPlan.erledigtAm = null; vorgangPlan.erledigtNotiz = null;
          var vg = { id: neueId('vg'), fahrzeugId: x.aktivitaet.aktuell.werte.fahrzeugId, komponenteId: null, erstelltAm: vjetzt, ereignisId: id };
          zusatz.push({ tabelle: 'vorgaenge', objekt: vg }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('vorgang', vg.id, 1, vorgangPlan, null, vjetzt) },
            { tabelle: 'ereignisse', objekt: Object.assign({}, x.ereignis, { vorgangId: vg.id }) });
          stoerung = { einschraenkung: vorgangPlan.auswirkung, frist: vorgangPlan.reparierenBis || null };
          vorgangErg = { id: vg.id, einschraenkung: vorgangPlan.auswirkung, frist: vorgangPlan.reparierenBis || null };
        }
        if (zv && zv.neu && neuerOrtWerte) {
          var ojetzt = self.jetzt(), ow = Object.assign({}, neuerOrtWerte, { gebietId: null, revierId: null, ortGeprueft: 'nein' });
          zusatz.push({ tabelle: 'orte', objekt: { id: zv.id, datenraumId: self.datenraumId, erstelltAm: ojetzt } },
            { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('ort', zv.id, 1, ow, null, ojetzt) });
        }
        if (lv && lv.p) {
          zusatz = zusatz.concat(lv.p.schreiben);
          lauf = { verbraucherId: verbrId, verbraucherName: lv.name, laufArt: laufArt, laufId: lv.p.ergebnis.id, laufGebucht: true };
          laufErg = Object.assign({ verbraucherId: verbrId, name: lv.name, art: laufArt }, lv.p.ergebnis);
        }
        if (v && v.tk) {
          var altW = v.tk.aktuell.werte, tankName = altW.bezeichnung;
          tank = { tankId: tankId, tankName: tankName, menge: menge, literpreis: literpreis, voll: vollRoh || null };
          if (mengeEingabe) tank.mengeEingabe = mengeEingabe;
          if (preisEingabe) tank.preisEingabe = preisEingabe;
          if (tankBuchen) {
            tank.tankArt = tankArt;
            if (vorgangDef) { tank.entsorgungArt = vorgangDef.id; tank.entsorgungName = vorgangDef.name; }
            if (antworten._tankStoff || antworten.stoff) tank.kraftstoff = String(antworten.stoff || antworten._tankStoff);
          }
          if (tankBuchen && kv) {
            /* Kette neu gerechnet: nachgetragen, entleeren oder Flasche tauschen */
            if (kv.fehler) return { ok: false, fehler: kv.fehler };
            var ke = kv.ergebnisse[id] || { hinweise: [], fuellstandNach: null };
            zusatz = zusatz.concat(kv.schreiben);
            var zl = [];
            if (ke.setzen) zl.push('Füllstand ' + tankName + ': ' + MM.Tanken.text(ke.fuellstandNach) + ' l' + (tankArt === 'leer' && vollRoh === 'ja' ? ' (ganz leer)' : (tankArt === 'flasche' ? ' (neue Flasche, voll)' : (kv.stand && kv.stand.art === 'voll' ? ' (voll)' : ' (nur gerechnet)'))) + '.');
            if (ke.fuellstandNach !== null) tank.fuellstandNach = ke.fuellstandNach;
            if (ke.setzen && ke.verbrauch) { tank.verbrauch = ke.verbrauch; zl = zl.concat(MM.Tanken.verbrauchZeilen(ke.verbrauch, v.einheit)); }
            var nv = v.verb && v.verb.length ? {} : null;
            (v.verb || []).forEach(function (k) { if (typeof k.stunden === 'number') nv[k.id] = k.stunden; });
            if (tankArt !== 'auf' || !(w.datum && w.zeit && w.datum + 'T' + w.zeit < (altW.fuellstandZeit || ''))) { if (nv) tank.tankStunden = nv; if (typeof v.strecke === 'number') tank.tankStrecke = v.strecke; }
            tank.tankGebucht = true;
            if (kv.stand && kv.stand.reichweite && wirkt('reichweite')) zl = zl.concat(MM.Tanken.reichweiteZeilen(kv.stand.reichweite));
            tankErg = { tankId: tankId, name: tankName, setzen: !!ke.setzen, fuellstand: ke.setzen ? ke.fuellstandNach : null, art: kv.stand ? kv.stand.art : null, zeilen: zl, hinweise: (ke.hinweise || []).slice(),
              nachgetragen: tankArt === 'auf', kette: true };
          } else if (tankBuchen) {
            var zeit = w.datum && w.zeit ? w.datum + 'T' + w.zeit : self.jetztLokal();
            var erg = MM.Tanken.berechnen({ kapazitaet: MM.Tanken.kapazitaet(altW),
              alt: { fuellstand: altW.fuellstand, art: altW.fuellstandArt, zeit: altW.fuellstandZeit, stunden: altW.fuellstandStunden, strecke: altW.fuellstandStrecke },
              altVerbrauch: altW.verbrauch || null, menge: menge, voll: vollRoh === 'ja', zeit: zeit, verbraucher: v.verb, strecke: v.strecke });
            var zeilen = [];
            if (wirkt('fuellstand') && erg.setzen) {
              var neuW = Object.assign({}, altW, { fuellstand: erg.fuellstand, fuellstandArt: erg.art, fuellstandZeit: zeit, fuellstandStunden: erg.stunden });
              if (typeof erg.strecke === 'number') neuW.fuellstandStrecke = erg.strecke; else delete neuW.fuellstandStrecke;
              zeilen = zeilen.concat(MM.Tanken.zeilen(erg, tankName));
              if (wirkt('verbrauch') && erg.verbrauch) { neuW.verbrauch = erg.verbrauch; zeilen = zeilen.concat(MM.Tanken.verbrauchZeilen(erg.verbrauch, v.einheit)); }
              if (wirkt('reichweite')) {
                if (erg.reichweite) { neuW.reichweite = erg.reichweite; zeilen = zeilen.concat(MM.Tanken.reichweiteZeilen(erg.reichweite)); } else delete neuW.reichweite;
              }
              zusatz.push({ tabelle: 'komponenteneintraege', objekt: { id: neueId('ke'), komponenteId: tankId, nr: v.tk.aktuell.nr + 1, werte: neuW,
                quelle: 'aktion', korrekturZu: v.tk.aktuell.id, erstelltAm: self.jetzt() } });
              tank.fuellstandNach = erg.fuellstand;
              if (wirkt('verbrauch') && erg.verbrauch) tank.verbrauch = erg.verbrauch;
            }
            tank.tankGebucht = true;
            if (erg.setzen) { tank.tankStunden = erg.stunden; if (typeof erg.strecke === 'number') tank.tankStrecke = erg.strecke; }
            tankErg = { tankId: tankId, name: tankName, setzen: !!(wirkt('fuellstand') && erg.setzen), fuellstand: erg.setzen ? erg.fuellstand : null, art: erg.art,
              zeilen: zeilen, hinweise: erg.hinweise.slice() };
          }
        }

        return self.ereignisAktionSpeichern(id, { segel: segel, text: text, datei: datei, betrag: betrag, ziel: ziel, tank: tank, lauf: lauf, stoerung: stoerung, zusatz: zusatz,
          zielOrt: zv ? { id: zv.id, name: zv.name } : null }).then(function (r) {
          if (!r.ok) return r;
          var ergebnis = { ok: true, id: id, zusammenstellung: z, kostenId: w.kostenId || null, kostenNeu: false,
            zielOrt: zv ? { id: zv.id, name: zv.name, neu: !!zv.neu } : (w.zielOrtId ? { id: w.zielOrtId, name: null, neu: false } : null),
            betrag: leerText(betrag) ? null : Number(String(geldRoh(betrag)).replace(',', '.')), ziel: wirkt('navi') ? String(ziel).trim() : null, navi: wirkt('navi'),
            tank: tankErg, tankSchonGebucht: !!(tankWirkt && w.tankGebucht),
            lauf: laufErg, laufSchonGebucht: !!(laufArt && w.laufGebucht),
            vorgang: vorgangErg, vorgangSchonDa: !!(wirkt('vorgang') && vorgangVorhanden), vorgangId: vorgangErg ? vorgangErg.id : (vorgangVorhanden ? x.ereignis.vorgangId : null) };
          if (!kostenRoh) return ergebnis;
          return self.aktivitaetLaden(x.ereignis.aktivitaetId).then(function (a) {
            if (!a) return { ok: false, fehler: { allgemein: 'Die Aktivität zu diesem Ereignis wurde nicht gefunden.' } };
            return self.kostenAnlegen(a.fahrzeug.id, Object.assign({}, kostenRoh, { aktivitaetId: x.ereignis.aktivitaetId })).then(function (k) {
              if (!k.ok) {
                var f = k.fehler || {};
                return { ok: false, gespeichert: true, fehler: { allgemein: 'Die Angaben stehen beim Eintrag, aber der Kostenposten wurde nicht angelegt: ' + (f.betrag || f.allgemein || 'Bitte den Betrag prüfen.') } };
              }
              return self.ereignisAktionSpeichern(id, { kostenId: k.id }).then(function () {
                ergebnis.kostenId = k.id; ergebnis.kostenNeu = true;
                return ergebnis;
              });
            });
          });
        });
      });
    });
  };


  /* ---------- Tankvorgänge ändern und neu rechnen (seit 2.0.63) ---------- */
  /*
   * Ein Tankvorgang wird nie gelöscht. Er lässt sich ändern (Menge, Preis, Tank, voll getankt), auch auf 0 Liter. Dann geht der Tank auf den Stand
   * davor zurück, alles danach wird neu gerechnet. Der falsche Vorgang bleibt mit seinem Verlauf erhalten.
   * Die Kette eines Tanks: alle gebuchten Vorgänge seit dem letzten von Hand angegebenen Füllstand, nach Zeit geordnet (MM.Tanken.kette).
   */
  function tankVorgangZeit(w) { return w.datum && w.zeit ? w.datum + 'T' + w.zeit : (w.datum ? w.datum + 'T00:00' : null); }

  /* Der Anfang der Kette: der letzte von Hand angegebene Füllstand (Eintrag mit „angegeben“, dessen Zeit sich vom Eintrag davor unterscheidet). */
  function tankBasis(eintraege) {
    var b = null;
    eintraege.forEach(function (e, i) {
      var w = e.werte, p = i > 0 ? eintraege[i - 1].werte : null;
      if (w.fuellstandArt === 'angegeben' && typeof w.fuellstand === 'number' && w.fuellstandZeit &&
        (!p || p.fuellstandArt !== 'angegeben' || p.fuellstand !== w.fuellstand || p.fuellstandZeit !== w.fuellstandZeit)) b = w;
    });
    return b ? { fuellstand: b.fuellstand, art: 'angegeben', zeit: b.fuellstandZeit, stunden: b.fuellstandStunden || null, strecke: typeof b.fuellstandStrecke === 'number' ? b.fuellstandStrecke : null, verbrauch: null, reichweite: null } : null;
  }

  /* Alle gebuchten Tankvorgänge eines Tanks: [{ id, e (neuester Stand des Ereignisses), w (Werte), zeit, art }] */
  function tankVorgaengeLaden(self, fahrzeugId, tankId) {
    return Promise.all([self.aktivitaetenListe(), self.speicher.alle('ereignisse'), self.speicher.alle('verlaeufe')]).then(function (r) {
      var meine = {}; r[0].forEach(function (a) { if (a.aktuell.werte.fahrzeugId === fahrzeugId) meine[a.objekt.id] = true; });
      var res = [];
      neuesteStaende(r[1].filter(function (e) { return meine[e.aktivitaetId]; }), r[2], 'ereignis').forEach(function (e) {
        var w = e.aktuell.werte;
        if (w.ausgeblendet === 'ja' || !w.tankGebucht || w.tankId !== tankId) return;
        res.push({ id: e.objekt.id, e: e, w: w, zeit: tankVorgangZeit(w) });
      });
      return res;
    });
  }

  /*
   * Die Kette eines Tanks neu rechnen und die Schreibaufträge dazu bauen. aenderung (freiwillig): { id, werte } ersetzt (oder fügt hinzu) das Ereignis id
   * mit diesen Werten, { id, werte: null } nimmt es aus der Kette. Ergebnis: { schreiben, ergebnisse, stand, tank } oder { fehler }.
   * schreiben enthält die neuen Stände der anderen Ereignisse der Kette, deren Füllstand oder Verbrauch sich ändert, und den neuen Stand des Tanks.
   * Das geänderte Ereignis selbst schreibt der Aufrufer (ergebnisse[id] sagt, was hineinkommt).
   */
  function tankKetteVorbereiten(self, fahrzeugId, tankId, aenderung) {
    return Promise.all([self.komponentenListe(fahrzeugId), tankVorgaengeLaden(self, fahrzeugId, tankId), self.streckenStandKm(fahrzeugId)]).then(function (r) {
      var liste = r[0], tk = liste.filter(function (k) { return k.komponente.id === tankId && MM.Versorgung.istTank(k.komponente); })[0];
      if (!tk) return { fehler: { tank: 'Bitte einen Tank dieses Fahrzeugs wählen.' } };
      var vorg = r[1].filter(function (v) { return !aenderung || v.id !== aenderung.id; });
      if (aenderung && aenderung.werte) vorg.push({ id: aenderung.id, e: aenderung.e || null, w: aenderung.werte, zeit: tankVorgangZeit(aenderung.werte) });
      var basis = tankBasis(tk.eintraege);
      var bz = basis ? new Date(basis.zeit).getTime() : null;
      vorg = vorg.filter(function (v) { return v.zeit && (bz === null || new Date(v.zeit).getTime() >= bz); });
      vorg.sort(function (a, b) { return a.zeit < b.zeit ? -1 : (a.zeit > b.zeit ? 1 : 0); });
      var verb = MM.Versorgung.verbraucherVon(liste, [tankId]).filter(function (k) { return k.aktuell.werte.verbraucher === 'ja'; }).map(function (k) {
        return { id: k.komponente.id, name: k.aktuell.werte.bezeichnung, aus: MM.Versorgung.verbrauchAus(k.aktuell.werte), motor: MM.Komponenten.istMotor(k.komponente) };
      });
      var jetzt = vorg.length ? vorg[vorg.length - 1].zeit : null;
      var vv = vorg.map(function (v) {
        /* Betriebsstunden und Kilometer zur Zeit des Vorgangs: beim Buchen festgehalten. Bei älteren Vorgängen fehlt es, dann steht nur Verbrauch je Tag. */
        var treffer = !v.w.tankStunden && typeof v.w.tankStrecke !== 'number' ? tk.eintraege.filter(function (en) { return en.quelle === 'aktion' && en.werte.fuellstandZeit === v.zeit && en.werte.fuellstand === v.w.fuellstandNach; })[0] : null;
        var eigenLetzter = aenderung && v.id === aenderung.id && v.zeit === jetzt && !v.w.tankStunden && aenderung.stundenJetzt;
        return { id: v.id, zeit: v.zeit, art: v.w.tankArt === 'leer' || v.w.tankArt === 'flasche' ? v.w.tankArt : 'auf', menge: typeof v.w.menge === 'number' ? v.w.menge : (v.w.tankArt === 'flasche' ? null : null),
          voll: v.w.voll === 'ja', stunden: v.w.tankStunden || (treffer ? treffer.werte.fuellstandStunden || null : null) || (eigenLetzter ? aenderung.stundenJetzt : null), strecke: typeof v.w.tankStrecke === 'number' ? v.w.tankStrecke : (treffer && typeof treffer.werte.fuellstandStrecke === 'number' ? treffer.werte.fuellstandStrecke : (eigenLetzter && typeof r[2] === 'number' ? r[2] : null)) };
      });
      var kerg = MM.Tanken.kette({ kapazitaet: MM.Tanken.kapazitaet(tk.aktuell.werte), basis: basis, vorgaenge: vv, verbraucher: verb });
      var schreiben = [], jetztIso = self.jetzt();
      vorg.forEach(function (v) {
        if (aenderung && v.id === aenderung.id) return;
        var erg = kerg.ergebnisse[v.id]; if (!erg) return;
        var alt = v.w, neu = Object.assign({}, alt);
        if (erg.fuellstandNach === null) delete neu.fuellstandNach; else neu.fuellstandNach = erg.fuellstandNach;
        if (erg.setzen && erg.verbrauch) neu.verbrauch = erg.verbrauch; else delete neu.verbrauch;
        if (JSON.stringify(neu) !== JSON.stringify(alt)) schreiben.push({ tabelle: 'verlaeufe', objekt: Object.assign(neuerVerlaufEintrag('ereignis', v.id, v.e.aktuell.nr + 1, neu, v.e.aktuell.id, jetztIso), { quelle: 'aktion' }) });
      });
      /* Der Tank: nur schreiben, wenn sich Füllstand, Verbrauch oder Reichweite ändern */
      var altW = tk.aktuell.werte, neuW = Object.assign({}, altW), st = kerg.stand;
      if (st) {
        neuW.fuellstand = st.fuellstand; neuW.fuellstandArt = st.art; neuW.fuellstandZeit = st.zeit; neuW.fuellstandStunden = st.stunden || {};
        if (typeof st.strecke === 'number') neuW.fuellstandStrecke = st.strecke; else delete neuW.fuellstandStrecke;
        if (st.verbrauch) neuW.verbrauch = st.verbrauch; else delete neuW.verbrauch;
        if (st.reichweite) neuW.reichweite = st.reichweite; else delete neuW.reichweite;
      } else {
        ['fuellstand', 'fuellstandArt', 'fuellstandZeit', 'fuellstandStunden', 'fuellstandStrecke', 'verbrauch', 'reichweite'].forEach(function (k) { delete neuW[k]; });
      }
      var tankNeu = JSON.stringify(neuW) !== JSON.stringify(altW);
      if (tankNeu) schreiben.push({ tabelle: 'komponenteneintraege', objekt: { id: neueId('ke'), komponenteId: tankId, nr: tk.aktuell.nr + 1, werte: neuW, quelle: 'aktion', korrekturZu: tk.aktuell.id, erstelltAm: jetztIso } });
      return { schreiben: schreiben, ergebnisse: kerg.ergebnisse, stand: st, tank: tk, tankNeu: tankNeu };
    });
  }
  Daten.prototype.tankKetteVorbereiten = function (fahrzeugId, tankId, aenderung) { return tankKetteVorbereiten(this, fahrzeugId, tankId, aenderung); };

  /* Die Einheit der Eingabe (Liter oder kg) und die Dichte des Stoffes am Tank */
  function tankDichte(self, tk) {
    var stoff = tk && tk.aktuell.werte.stoff;
    return stoff ? self.stoffDichte(stoff) : Promise.resolve(null);
  }

  /*
   * Einen gebuchten Tankvorgang ändern (seit 2.0.63). roh: { menge, literpreis, voll ('ja' | 'nein'), tankId, mengeEinheit ('l' | 'kg') }.
   * Menge 0 ist erlaubt: der Vorgang zählt dann nicht, der Tank geht auf den Stand davor zurück, alles danach wird neu gerechnet.
   * Der Kostenposten des Vorgangs geht bei 0 Litern auf 0. Sonst wird sein Betrag nur neu gerechnet, wenn er vorher von der App aus Menge mal Preis kam.
   */
  Daten.prototype.tankvorgangAendern = function (ereignisId, roh) {
    var self = this; roh = roh || {};
    return this.ereignisLaden(ereignisId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      var alt = x.aktuell.werte;
      if (!alt.tankGebucht || !alt.tankId) return { ok: false, fehler: { allgemein: 'Zu diesem Ereignis gibt es keinen verbuchten Tankvorgang.' } };
      if (x.aktivitaet && x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var fahrzeugId = x.aktivitaet.aktuell.werte.fahrzeugId;
      var neuTankId = roh.tankId ? String(roh.tankId).trim() : alt.tankId;
      return self.komponentenListe(fahrzeugId).then(function (liste) {
        var tkNeu = liste.filter(function (k) { return k.komponente.id === neuTankId && MM.Versorgung.istTank(k.komponente); })[0];
        if (!tkNeu) return { ok: false, fehler: { tankId: 'Bitte einen Tank dieses Fahrzeugs wählen.' } };
        return tankDichte(self, tkNeu).then(function (dichte) {
          var fehler = {}, art = alt.tankArt === 'leer' || alt.tankArt === 'flasche' ? alt.tankArt : 'auf';
          var einheit = roh.mengeEinheit === 'kg' ? 'kg' : 'l';
          var menge = typeof alt.menge === 'number' ? alt.menge : null, mengeEingabe = alt.mengeEingabe || null;
          if (roh.menge !== undefined && String(roh.menge).trim() !== '') {
            var m = MM.Tanken.mengeLiter(geldRoh(roh.menge), einheit, dichte);
            if (!m.ok) fehler.menge = m.fehler; else if (m.liter > 100000) fehler.menge = 'Die Menge ist zu groß.';
            else { menge = m.liter; mengeEingabe = { wert: MM.Tanken.zahl(geldRoh(roh.menge)), einheit: einheit }; }
          } else if (art === 'auf' && menge === null) fehler.menge = 'Bitte die Menge eingeben, bei 0 zählt der Vorgang nicht.';
          var preis = typeof alt.literpreis === 'number' ? alt.literpreis : null, preisEingabe = alt.preisEingabe || null;
          if (roh.literpreis !== undefined) {
            if (String(roh.literpreis).trim() === '') { preis = null; preisEingabe = null; }
            else {
              var pn = MM.Tanken.zahl(geldRoh(roh.literpreis));
              var pl = pn === null ? null : MM.Tanken.preisJeLiter(pn, einheit, dichte);
              if (pn === null || !(pn > 0) || pl === null) fehler.literpreis = einheit === 'kg' && pn !== null ? 'Für den Preis je kg braucht der Stoff eine Dichte.' : 'Bitte den Preis eingeben, zum Beispiel 1,799.';
              else { preis = pl; preisEingabe = { wert: pn, einheit: einheit }; }
            }
          }
          var voll = roh.voll === 'ja' || roh.voll === 'nein' ? roh.voll : (alt.voll || 'nein');
          if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
          var tankName = tkNeu.aktuell.werte.bezeichnung;
          var neu = Object.assign({}, alt, { tankId: neuTankId, tankName: tankName, menge: menge, literpreis: preis, voll: voll });
          if (mengeEingabe) neu.mengeEingabe = mengeEingabe; else delete neu.mengeEingabe;
          if (preisEingabe) neu.preisEingabe = preisEingabe; else delete neu.preisEingabe;
          var tankeAlt = alt.tankId;
          var tanks = [neuTankId].concat(tankeAlt !== neuTankId ? [tankeAlt] : []);
          return Promise.all([tankKetteVorbereiten(self, fahrzeugId, neuTankId, { id: ereignisId, e: x.ereignis ? { aktuell: x.aktuell } : null, werte: neu })]
            .concat(tankeAlt !== neuTankId ? [tankKetteVorbereiten(self, fahrzeugId, tankeAlt, { id: ereignisId, werte: null })] : [])).then(function (ketten) {
            var k1 = ketten[0];
            if (k1.fehler) return { ok: false, fehler: k1.fehler };
            var e1 = k1.ergebnisse[ereignisId];
            if (e1) { if (e1.fuellstandNach === null) delete neu.fuellstandNach; else neu.fuellstandNach = e1.fuellstandNach; if (e1.setzen && e1.verbrauch) neu.verbrauch = e1.verbrauch; else delete neu.verbrauch; }
            else { delete neu.fuellstandNach; delete neu.verbrauch; }
            var jetzt = self.jetzt(), schreiben = [];
            ketten.forEach(function (k) { if (!k.fehler) schreiben = schreiben.concat(k.schreiben); });
            if (JSON.stringify(neu) !== JSON.stringify(alt)) schreiben.push({ tabelle: 'verlaeufe', objekt: Object.assign(neuerVerlaufEintrag('ereignis', ereignisId, x.aktuell.nr + 1, neu, x.aktuell.id, jetzt), { quelle: 'aktion' }) });
            return self.speicher.mehrereSpeichern(schreiben).then(function () {
              var ergebnis = { ok: true, id: ereignisId, geaendert: schreiben.length > 0, nullLiter: menge === 0, fuellstandNach: e1 ? e1.fuellstandNach : null, hinweise: e1 ? e1.hinweise.slice() : [], tank: tankName, kostenGeaendert: false };
              if (!alt.kostenId) return ergebnis;
              /* Kostenposten: bei 0 Litern auf 0; sonst nur neu rechnen, wenn der Betrag vorher Menge mal Preis war */
              return self.kostenLaden(alt.kostenId).then(function (kx) {
                if (!kx) return ergebnis;
                var kw = kx.aktuell.werte, neuBetrag = null;
                var vorherGerechnet = typeof alt.menge === 'number' && typeof alt.literpreis === 'number' && MM.Kosten.runde(alt.menge * alt.literpreis) === Number(kw.betrag);
                if (menge === 0) neuBetrag = 0;
                else if ((alt.menge === 0 || vorherGerechnet) && preis !== null) neuBetrag = MM.Kosten.runde(menge * preis);
                if (neuBetrag === null || neuBetrag === Number(kw.betrag)) return ergebnis;
                return self.mitVerlaufLaden('kosten', alt.kostenId, MM.Kosten.felderAlle()).then(function (kl) {
                  return self.mitVerlaufAendern('kosten', alt.kostenId, kl, Object.assign({}, kl.aktuell.werte, { betrag: neuBetrag }), MM.Kosten.felderAlle());
                }).then(function () { ergebnis.kostenGeaendert = true; ergebnis.kostenBetrag = neuBetrag; return ergebnis; });
              });
            });
          });
        });
      });
    });
  };

  Daten.prototype.ereignisDateiHolen = function (ereignisId) {
    return this.speicher.wo('ereignisdateien', 'ereignisId', ereignisId).then(function (l) { return l[0] || null; });
  };

  Daten.prototype.ereignisAendern = function (id, roh) {
    var self = this;
    return this.ereignisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      if (x.aktivitaet && x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var alt = x.aktuell.werte;
      var p = self.pruefenEreignis(roh, x.arten, alt.nachgetragen === 'ja', alt.artId);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      /* Störung (seit 2.0.26): Nur ein neues Ereignis „Störung“ legt den Vorgang in der Werkstatt an. Eine Art nachträglich auf „Störung“ zu stellen, würde die Werkstatt auslassen. */
      if (p.werte.artId !== alt.artId && !(x.ereignis && x.ereignis.vorgangId)) {
        var neueArt = x.arten.filter(function (a) { return a.objekt.id === p.werte.artId; })[0];
        if (neueArt && MM.Logbuch.istStoerungArt(neueArt.aktuell.werte.bezeichnung)) {
          return { ok: false, fehler: { artId: 'Eine Störung meldest du mit „Ereignis eintragen“ oder „Nachtragen“, damit sie auch in der Werkstatt steht. Ändere hier nicht die Art.' } };
        }
      }
      /* Ein verbuchter Tankvorgang wird nicht ausgeblendet oder gelöscht (seit 2.0.63): Er wird geändert, auch auf 0 Liter. */
      if (alt.tankGebucht && p.werte.ausgeblendet === 'ja' && alt.ausgeblendet !== 'ja') return { ok: false, fehler: { allgemein: 'Ein Tankvorgang wird nicht ausgeblendet oder gelöscht. Ändere ihn stattdessen („Tankvorgang ändern“), auch auf 0 Liter.' } };
      var neu = Object.assign({}, alt, p.werte);
      /* Person über Bord (seit 2.0.133): automatisch erfasste Zeiten und Positionen bleiben, wie sie sind. */
      if ((alt.mob && alt.startMs) || alt.mobZu) {
        var fest = ['datum', 'zeit', 'artId'].concat(typeof alt.breite === 'number' ? ['breite', 'laenge'] : []);
        var geaendertFest = fest.filter(function (k) { return (alt[k] === undefined ? null : alt[k]) !== (neu[k] === undefined ? null : neu[k]); });
        if (geaendertFest.length || (neu.ausgeblendet === 'ja' && alt.ausgeblendet !== 'ja' && alt.uebung !== 'uebung')) {
          return { ok: false, fehler: { allgemein: 'Bei „Person über Bord“ bleiben die automatisch erfassten Zeiten und Positionen unverändert, und ein Ernstfall wird nicht ausgeblendet. Ergänzungen trägst du als Text oder unter „Person über Bord: Angaben“ ein.' } };
        }
      }
      /* Wer Datum oder Uhrzeit ändert, hat sie von Hand gesetzt. Die Quelle des Eintrags bleibt, wie sie war (seit 2.0.106). */
      if (alt.datum !== neu.datum || alt.zeit !== neu.zeit) neu.zeitHerkunft = 'hand';
      /* Position ändern (seit 2.0.117): Pflichtfeld „Warum“. Der Verlauf hält fest, wer (der Verantwortliche der Aktivität), wann, warum, alte und neue Position. */
      var zahlOderNull = function (v) { return typeof v === 'number' ? v : null; };
      var zusatz = null;
      if (zahlOderNull(alt.breite) !== zahlOderNull(neu.breite) || zahlOderNull(alt.laenge) !== zahlOderNull(neu.laenge)) {
        var warum = typeof roh.positionWarum === 'string' ? roh.positionWarum.trim() : '';
        if (!warum) return { ok: false, fehler: { positionWarum: 'Bitte schreibe, warum die Position geändert wird. Das steht danach mit Zeit und Verantwortlichem im Verlauf.' } };
        if (warum.length > 300) return { ok: false, fehler: { positionWarum: 'Bitte höchstens 300 Zeichen eingeben.' } };
        var ver = x.aktivitaet && x.aktivitaet.verantwortung && x.aktivitaet.verantwortung.length ? MM.Aktivitaeten.verantwortlicher(x.aktivitaet.verantwortung, self.jetztLokal()) : null;
        zusatz = { positionAenderung: { am: self.jetzt(), warum: warum, wer: ver ? ver.name : 'kein Verantwortlicher eingetragen', werPersonId: ver ? ver.personId : null,
          alt: { breite: zahlOderNull(alt.breite), laenge: zahlOderNull(alt.laenge), quelle: alt.positionQuelle || null },
          neu: { breite: zahlOderNull(neu.breite), laenge: zahlOderNull(neu.laenge), quelle: neu.positionQuelle || null } } };
      }
      return self.mitVerlaufAendern('ereignis', id, { aktuell: x.aktuell }, neu, EREIGNIS_FELDER, zusatz).then(function (r) {
        var anders = alt.ortName !== neu.ortName || alt.ortNameQuelle !== neu.ortNameQuelle || alt.breite !== neu.breite || alt.laenge !== neu.laenge;
        if (r && r.ok && anders) return self.ortLernenNachSpeichern(neu).then(function () { return r; });
        return r;
      });
    });
  };

  /* ---------- 2.0.14: Cockpit (schnelles Eintragen) und Tagesabschluss ---------- */
  /* Der heutige Tag: der sichtbare Tag von heute wird geöffnet, gibt es keinen, legt die App ihn von selbst an
     (ohne vorheriges „Tage vorbereiten“). Nur wenn der heutige Tag im Zeitraum der Aktivität liegt und sie nicht storniert ist. */
  Daten.prototype.heutigerTag = function (aktivitaetId) {
    var self = this;
    return this.logbuchLaden(aktivitaetId).then(function (lb) {
      if (!lb) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      var a = lb.aktivitaet, heute = self.heute();
      var c = MM.Logbuch.cockpitMoeglich(a.aktuell.werte, heute);
      if (!c.moeglich) {
        var text = { storniert: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.',
          geplant: 'Die Aktivität beginnt erst am ' + MM.Hilfen.datum(a.aktuell.werte.vonDatum) + '. Das Cockpit trägt nur ein, wenn heute im Zeitraum liegt.',
          vorbei: 'Die Aktivität war bis ' + MM.Hilfen.datum(a.aktuell.werte.bisDatum) + '. Das Cockpit trägt nur ein, wenn heute im Zeitraum liegt. Im Logbuch kannst du Tage ergänzen und nachtragen.' }[c.grund];
        return { ok: false, fehler: { allgemein: text } };
      }
      var vorhanden = MM.Logbuch.heutigerAbschnitt(lb.abschnitte, heute);
      if (vorhanden) return { ok: true, abschnittId: vorhanden.objekt.id, neu: false };
      var werte = MM.Logbuch.fehlendeTage(a.aktuell.werte, []).neu.filter(function (x) { return x.datum === heute; })[0]
        || { datum: heute, beginnZeit: null, endeZeit: null, von: null, nach: null, notiz: null, ausgeblendet: 'nein' };
      return self.mitVerlaufAnlegen('tagesabschnitte', 'tagesabschnitt', 'tg', werte, { aktivitaetId: aktivitaetId, herkunft: 'vorbereitet' })
        .then(function (r) { return { ok: true, abschnittId: r.id, neu: true }; });
    });
  };

  /* Ein Tipp auf Abfahrt, Ankunft oder Notiz: Ereignis mit der Uhrzeit „jetzt“, ohne Formular.
     art: 'Abfahrt', 'Ankunft' oder 'Notiz' (Name der Art). Fehlen die Vorschläge der Arten, werden sie angelegt. */
  Daten.prototype.ereignisSchnell = function (aktivitaetId, artName, roh) {
    var self = this;
    roh = roh || {};
    return this.heutigerTag(aktivitaetId).then(function (t) {
      if (!t.ok) return t;
      return self.ereignisartenAusVorschlaegen().then(function () { return self.ereignisartenListe(); }).then(function (arten) {
        /* Ist die Art schon gewählt (artId), wird nicht nach dem Namen gesucht. */
        var art = roh.artId ? { objekt: { id: roh.artId }, aktuell: { werte: { ausgeblendet: 'nein' } } }
          : arten.filter(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === String(artName).toLowerCase(); })[0];
        if (!art) return { ok: false, fehler: { allgemein: 'Die Art „' + artName + '“ gibt es nicht.' } };
        if (art.aktuell.werte.ausgeblendet === 'ja') return { ok: false, fehler: { allgemein: 'Die Art „' + artName + '“ ist ausgeblendet. Blende sie unter „Arten von Ereignissen“ wieder ein.' } };
        /* Leere Zeit heißt „jetzt“ und wird erst beim Speichern genommen, nicht beim Öffnen der Seite. */
        var jetzt = self.jetztLokal();
        var werte = { artId: roh.artId || art.objekt.id, datum: roh.datum || jetzt.slice(0, 10), zeit: roh.zeit || jetzt.slice(11, 16), text: roh.text || '', datei: roh.datei || null };
        if (!roh.datum && roh.zeit) werte.datum = jetzt.slice(0, 10);
        /* Position (seit 2.0.21): vom GPS des Geräts, nur wenn der Aufrufer eine frische mitgibt und die Uhrzeit „jetzt“ ist (beim Nachtragen gibt es keine GPS-Position). */
        var pos = roh.position;
        var mitPosition = pos && !roh.zeit && typeof pos.breite === 'number' && typeof pos.laenge === 'number';
        if (mitPosition) {
          werte.breite = pos.breite; werte.laenge = pos.laenge;
          werte.gpsBreite = pos.breite; werte.gpsLaenge = pos.laenge; werte.gpsGenauigkeit = pos.genauigkeit;
        }
        if (roh.ortName !== undefined) werte.ortName = roh.ortName;
        if (roh.auswirkung !== undefined) werte.auswirkung = roh.auswirkung;
        /* Ohne Namen vom Nutzer schlägt die App einen bekannten Ort im Umfeld vor. Hat der Nutzer das Feld bewusst geleert (ortName ''), bleibt es leer. */
        var vorschlagen = mitPosition && roh.ortName === undefined;
        /* Leere Zeit heißt „jetzt“ und kommt von der Gerätezeit (seit 2.0.106). Die Quelle gibt der Aufrufer an (Standard: Nutzer). */
        return self.ereignisAnlegen(t.abschnittId, werte, { erlaubteArt: roh.artId || null, ortVorschlag: vorschlagen, quelle: roh.quelle, quelleName: roh.quelleName, zeitHerkunft: roh.zeit ? 'hand' : 'geraet' }).then(function (r) {
          if (r.ok) { r.zeit = werte.zeit; r.datum = werte.datum; r.abschnittId = t.abschnittId; }
          return r;
        });
      });
    });
  };

  /* ---------- Schnellknöpfe im Cockpit (seit 2.0.18) ----------
   * Die Belegung liegt als ein Dokument „schnellknoepfe“ in „einstellungen“ (keine Umstellung des Speichers, in der
   * Sicherung enthalten). Die Regeln stehen in js/logbuch.js. */
  /*
   * knoepfeAlle: alle Knöpfe, die für die Fahrzeugart belegt sind (bis 15).
   * knoepfe:     die Knöpfe, die dieses Gerät zeigt (die ersten „geraetMax“, seit 2.0.20).
   * sonstige:    alles, was nicht auf einem gezeigten Knopf liegt (auch die Knöpfe, die dieses Gerät nicht mehr zeigt).
   */
  Daten.prototype.schnellknoepfeFuerFahrzeugart = function (artId) {
    var self = this;
    var wasser = MM.Logbuch.istWasserArt(artId);
    return this.ereignisartenAusVorschlaegen().then(function () { return wasser ? self.wasserArtenSichern() : null; }).then(function () { return self.werkzeugArtenEinmalSichern(); }).then(function () { return MM.Segeln && MM.Fahrzeugarten.vorfahren(artId).indexOf('segelboot') >= 0 ? self.segelArtenSichern() : null; }).then(function () {
      return Promise.all([self.ereignisartenListe(), self.speicher.holen('einstellungen', 'schnellknoepfe'), self.geraetEinstellungen()]);
    }).then(function (r) {
      var angebot = MM.Logbuch.schnellAngebot(r[0], artId);
      var belegung = MM.Logbuch.schnellBelegung(r[1], artId);
      var alle = MM.Logbuch.schnellKnoepfe(belegung, angebot, wasser);
      /* seit 2.0.130: Hafen- und Stellplatzknöpfe stehen fest auf der dritten Cockpit-Seite und belegen hier keinen Platz */
      var welt = MM.Fahrzeugarten.artSicher(artId).welt;
      var fest = (MM.Logbuch.ABLAUF[welt] || []).map(function (n) { return n.toLowerCase(); });
      alle = alle.filter(function (x) { return !(x.typ === 'ereignis' && fest.indexOf(x.name.toLowerCase()) >= 0); });
      var knoepfe = MM.Logbuch.schnellAufGeraet(alle, r[2].knoepfe);
      return { artId: artId, angebot: angebot, knoepfe: knoepfe, knoepfeAlle: alle, sonstige: MM.Logbuch.schnellSonstige(knoepfe, angebot),
        eigene: belegung.eigene, von: belegung.von, standard: belegung.keys === null, max: MM.Logbuch.MAX_SCHNELL,
        geraetMax: r[2].knoepfe, geraetGesetzt: r[2].knoepfeGesetzt, versteckt: alle.length - knoepfe.length };
    });
  };

  /* slots: Liste von Schlüsseln in der Reihenfolge der Knöpfe, leere Felder dürfen vorkommen. Die Fehler heißen s1 bis s15. */
  Daten.prototype.schnellknoepfeSetzen = function (artId, slots) {
    var self = this;
    if (!MM.Fahrzeugarten.knoten(artId)) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Fahrzeugart gibt es nicht.' } });
    slots = (slots || []).slice(0, MM.Logbuch.MAX_SCHNELL);
    return this.schnellknoepfeFuerFahrzeugart(artId).then(function (info) {
      var gueltig = {}, fehler = {}, an = {}, keys = [];
      info.angebot.alle.forEach(function (x) { gueltig[x.key] = x.name; });
      slots.forEach(function (k, i) {
        if (!k) return;
        var feld = 's' + (i + 1);
        if (!gueltig[k]) fehler[feld] = 'Das gibt es für diese Fahrzeugart nicht (mehr). Wähle etwas anderes.';
        else if (an[k]) fehler[feld] = '„' + gueltig[k] + '“ liegt schon auf Knopf ' + an[k] + '.';
        else { an[k] = i + 1; keys.push(k); }
      });
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      return self.speicher.holen('einstellungen', 'schnellknoepfe').then(function (dok) {
        return self.speicher.speichern('einstellungen', MM.Logbuch.schnellDokumentSetzen(dok, artId, keys));
      }).then(function () { return { ok: true, id: artId, anzahl: keys.length }; });
    });
  };

  /* Die Art hat dann keine eigene Liste mehr und übernimmt die der Obergruppe (oder den Standard). */
  Daten.prototype.schnellknoepfeZuruecksetzen = function (artId) {
    var self = this;
    return this.speicher.holen('einstellungen', 'schnellknoepfe').then(function (dok) {
      if (!dok || !dok.belegung || !Array.isArray(dok.belegung[artId])) return { ok: true, id: artId, geaendert: false };
      return self.speicher.speichern('einstellungen', MM.Logbuch.schnellDokumentZuruecksetzen(dok, artId)).then(function () { return { ok: true, id: artId, geaendert: true }; });
    });
  };

  /* ---------- Hat die Fahrzeugart einen Motor? (seit 2.0.20) ----------
   * Die Einstellung des Nutzers liegt als ein Dokument „fahrzeugart-motor“ in „einstellungen“ (keine Umstellung des
   * Speichers, in der Sicherung enthalten). Die Regeln stehen in js/motoren.js. Es ist nur ein Hinweis, keine Sperre. */
  var MOTOR_DOK = 'fahrzeugart-motor';

  Daten.prototype.fahrzeugartMotor = function (artId) {
    return this.speicher.holen('einstellungen', MOTOR_DOK).then(function (dok) {
      var r = MM.Motoren.motorArt(dok, artId);
      r.artId = artId;
      return r;
    });
  };

  /* wert: 'ja' oder 'nein' */
  Daten.prototype.fahrzeugartMotorSetzen = function (artId, wert) {
    var self = this;
    if (wert !== 'ja' && wert !== 'nein') return Promise.resolve({ ok: false, fehler: { allgemein: 'Bitte „Hat einen Motor“ oder „Hat keinen Motor“ wählen.' } });
    if (!MM.Fahrzeugarten.knoten(artId)) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Fahrzeugart gibt es nicht.' } });
    return this.speicher.holen('einstellungen', MOTOR_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', MM.Motoren.motorDokumentSetzen(dok, artId, wert));
    }).then(function () { return { ok: true, id: artId, wert: wert }; });
  };

  /* Die Art hat dann keine eigene Einstellung mehr und übernimmt die der Obergruppe (oder die Voreinstellung). */
  Daten.prototype.fahrzeugartMotorZuruecksetzen = function (artId) {
    var self = this;
    return this.speicher.holen('einstellungen', MOTOR_DOK).then(function (dok) {
      if (!dok || !dok.werte || (dok.werte[artId] !== 'ja' && dok.werte[artId] !== 'nein')) return { ok: true, id: artId, geaendert: false };
      return self.speicher.speichern('einstellungen', MM.Motoren.motorDokumentSetzen(dok, artId, null)).then(function () { return { ok: true, id: artId, geaendert: true }; });
    });
  };

  /* ---------- Einstellungen dieses Geräts (seit 2.0.20) ----------
   * Was nur für das einzelne Gerät gilt (zum Beispiel wie viele Knöpfe das Cockpit zeigt), liegt als ein Dokument
   * „geraet“ in „einstellungen“. Es wird nicht in die Sicherung geschrieben und beim Einspielen einer Sicherung
   * nicht überschrieben: Ein Tablet bleibt ein Tablet, auch wenn die Daten vom Handy stammen. */
  var GERAET_DOK = 'geraet';

  Daten.prototype.geraetEinstellungen = function () {
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      var n = MM.Logbuch.geraetKnoepfeGueltig(dok && dok.knoepfe);
      return { knoepfe: n === null ? MM.Logbuch.SCHNELL_GERAET_STANDARD : n, knoepfeGesetzt: n !== null };
    });
  };

  /* Wartezeit der Motorstopp-Frage in Minuten auf diesem Gerät: { wartezeit, gesetzt } (Vorgabe MM.Motoren.WARTEZEIT_STANDARD). */
  Daten.prototype.geraetWartezeit = function () {
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      var wz = MM.Motoren.wartezeitGueltig(dok && dok.motorFrageMinuten);
      return { wartezeit: wz === null ? MM.Motoren.WARTEZEIT_STANDARD : wz, gesetzt: wz !== null };
    });
  };

  /* Wartezeit der Motorstopp-Frage in Minuten (1 bis 1440), nur für dieses Gerät (seit 2.0.22). */
  Daten.prototype.geraetWartezeitSetzen = function (wert) {
    var self = this;
    var n = MM.Motoren.wartezeitGueltig(wert);
    if (n === null) return Promise.resolve({ ok: false, fehler: { wartezeit: 'Bitte eine ganze Zahl von ' + MM.Motoren.WARTEZEIT_MIN + ' bis ' + MM.Motoren.WARTEZEIT_MAX + ' Minuten eintragen.' } });
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, motorFrageMinuten: n }));
    }).then(function () { return { ok: true, wartezeit: n }; });
  };

  /*
   * Anzeige im Cockpit auf diesem Gerät (seit 2.0.61): die Einheit (km oder sm) und die zuletzt benutzte Seite des Cockpits.
   * Beides liegt im Dokument „geraet“, nicht in der Sicherung. Erster Start: km und Seite 1.
   * Ergebnis: { einheit: 'km' | 'sm', seite: 0 bis MM.Logbuch.COCKPIT_SEITEN - 1 oder null }
   */
  Daten.prototype.geraetAnzeige = function () {
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      return { einheit: MM.Fahrt.einheitGueltig(dok && dok.anzeigeEinheit) || MM.Fahrt.EINHEIT_STANDARD,
        seite: MM.Logbuch.cockpitSeiteGueltig(dok && dok.cockpitSeite) };
    });
  };
  Daten.prototype.geraetEinheitSetzen = function (wert) {
    var self = this;
    var e = MM.Fahrt.einheitGueltig(wert);
    if (e === null) return Promise.resolve({ ok: false, fehler: { einheit: 'Bitte km oder sm wählen.' } });
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, anzeigeEinheit: e }));
    }).then(function () { return { ok: true, einheit: e }; });
  };
  Daten.prototype.geraetCockpitSeiteSetzen = function (wert) {
    var self = this;
    var n = MM.Logbuch.cockpitSeiteGueltig(wert);
    if (n === null) return Promise.resolve({ ok: false, fehler: { seite: 'Diese Seite gibt es nicht.' } });
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, cockpitSeite: n }));
    }).then(function () { return { ok: true, seite: n }; });
  };

  /* Höchstzahl der Knöpfe im Cockpit auf diesem Gerät: ganze Zahl von 0 bis 15. */
  Daten.prototype.geraetKnoepfeSetzen = function (wert) {
    var self = this;
    var n = MM.Logbuch.geraetKnoepfeGueltig(wert);
    if (n === null) return Promise.resolve({ ok: false, fehler: { geraet: 'Bitte eine Zahl von 0 bis ' + MM.Logbuch.MAX_SCHNELL + ' wählen.' } });
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, knoepfe: n }));
    }).then(function () { return { ok: true, knoepfe: n }; });
  };

  /* Tagesabschluss (wie in V1): tatsächliches Ziel und Notiz, als neue Felder am Tagesabschnitt.
     Der Zählerstand am Ende gehört zu Schritt 6 und ist nicht dabei. */
  Daten.prototype.tagesabschlussSpeichern = function (abschnittId, roh) {
    var self = this;
    roh = roh || {};
    return this.abschnittLaden(abschnittId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var p = pruefeWerte([{ key: 'zielTatsaechlich', typ: 'text' }, { key: 'abschlussNotiz', typ: 'text' }], roh, jahrVon(self), { ohneBezeichnung: true });
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, x.abschnitt.aktuell.werte, { zielTatsaechlich: p.werte.zielTatsaechlich || null, abschlussNotiz: p.werte.abschlussNotiz || null });
      return self.mitVerlaufAendern('tagesabschnitt', abschnittId, { aktuell: x.abschnitt.aktuell }, neu, ABSCHNITT_FELDER);
    });
  };

  /* ---------- Wechsel des Verantwortlichen als Ereignis ---------- */
  /* Der Wechsel selbst bleibt in der Tabelle „verantwortung“. Korrekturen stehen im Verlauf und gelten ab sofort überall. */
  Daten.prototype.wechselLaden = function (verantwortungId) {
    var self = this;
    return this.speicher.holen('verantwortung', verantwortungId).then(function (rec) {
      if (!rec) return null;
      return Promise.all([self.aktivitaetLaden(rec.aktivitaetId), self.speicher.wo('verlaeufe', 'objektId', verantwortungId)]).then(function (r) {
        var a = r[0];
        if (!a) return null;
        var wz = MM.Logbuch.wechselEreignisse(a.verantwortung).filter(function (x) { return x.verantwortungId === verantwortungId; })[0];
        if (!wz) return null;
        var eintraege = r[1].filter(function (e) { return e.objektTyp === 'verantwortung'; }).sort(nachNr);
        var basis = { id: 'basis', objektTyp: 'verantwortung', objektId: verantwortungId, nr: 0, quelle: 'hand', korrekturZu: null, erstelltAm: rec.erstelltAm,
          werte: { abDatum: rec.ab.slice(0, 10), abZeit: rec.ab.slice(11, 16), notiz: null, ausgeblendet: 'nein' } };
        return { wechsel: wz, aktivitaet: a, eintraege: eintraege, verlauf: verlaufAus([basis].concat(eintraege), WECHSEL_FELDER) };
      });
    });
  };

  Daten.prototype.wechselAendern = function (verantwortungId, roh) {
    var self = this;
    roh = roh || {};
    var p = pruefeWerte([{ key: 'abDatum', typ: 'datum' }, { key: 'abZeit', typ: 'zeit' }, { key: 'notiz', typ: 'text' }], roh, jahrVon(this), { ohneBezeichnung: true });
    var f = p.fehler, w = p.werte;
    if (!w.abDatum && !f.abDatum) f.abDatum = 'Bitte das Datum des Wechsels angeben.';
    if (!w.abZeit && !f.abZeit) f.abZeit = 'Bitte die Uhrzeit des Wechsels angeben.';
    w.ausgeblendet = roh.ausgeblendet === 'ja' ? 'ja' : 'nein';
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return this.wechselLaden(verantwortungId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Wechsel wurde nicht gefunden.' } };
      if (x.aktivitaet.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var ab = w.abDatum + 'T' + w.abZeit;
      var liste = x.aktivitaet.verantwortung;
      var i = liste.map(function (v) { return v.id; }).indexOf(verantwortungId);
      var davor = liste[i - 1], danach = liste[i + 1];
      if (davor && ab <= davor.ab) return { ok: false, fehler: { abDatum: 'Der Wechsel muss nach dem vorherigen Wechsel liegen (' + davor.ab.replace('T', ', ') + ' Uhr).' } };
      if (danach && ab >= danach.ab) return { ok: false, fehler: { abDatum: 'Der Wechsel muss vor dem nächsten Wechsel liegen (' + danach.ab.replace('T', ', ') + ' Uhr).' } };
      var jetztStand = x.verlauf[0].eintrag.werte;
      if (!unterschiedeFelder(WECHSEL_FELDER, jetztStand, w).length) return { ok: true, id: verantwortungId, geaendert: false };
      var letzte = x.eintraege[x.eintraege.length - 1];
      var e = neuerVerlaufEintrag('verantwortung', verantwortungId, letzte ? letzte.nr + 1 : 1, w, letzte ? letzte.id : null, self.jetzt());
      return self.speicher.speichern('verlaeufe', e).then(function () { return { ok: true, id: verantwortungId, geaendert: true }; });
    });
  };

  /* ---------- Import und Export (seit 2.0.30) ----------
   * Import: Fahrzeuge aus einer Tabelle (Excel oder CSV). Erst die Vorschau, dann das Übernehmen. Es wird nie etwas überschrieben:
   * Ein Fahrzeug, das es schon gibt (gleiches Kennzeichen, gleiche Registriernummer, FIN oder HIN, sonst gleiche Bezeichnung),
   * wird übersprungen. Die Fahrzeuge entstehen alle in einem Zug, oder keines.
   * Export: Fahrzeuge, Kosten und Orte als Tabellen (Excel oder CSV).
   * Das Lesen und Schreiben der Dateien steht in austausch.js. */
  var IMPORT_MAX = 1000;
  var ART_SYNONYME = { pkw: 'auto', pw: 'auto', kfz: 'auto', automobil: 'auto', wagen: 'auto', krad: 'motorrad', camper: 'wohnmobil', reisemobil: 'wohnmobil', womo: 'wohnmobil',
    caravan: 'wohnwagen', wohnanhaenger: 'wohnwagen', anhaenger: 'wohnwagen', segelyacht: 'segelboot-monohull', segler: 'segelboot-monohull', segelboot: 'segelboot-monohull', boot: 'motorboot', yacht: 'motorboot', katamaran: 'segelboot-katamaran',
    jolle: 'segelboot-jolle', flieger: 'flugzeug', motoryacht: 'motorboot', sportboot: 'motorboot', motorschiff: 'motorboot', wasserskiboot: 'motorboot', zeltanhaenger: 'anhaenger', oldtimer: 'auto' };

  function artAusText(text) {
    var A = MM.Austausch, n = A.norm(text);
    if (!n) return null;
    var arten = MM.Fahrzeugarten.alle(false), i;
    for (i = 0; i < arten.length; i++) { if (A.norm(arten[i].name) === n || A.norm(arten[i].id) === n) return arten[i].id; }
    var s = ART_SYNONYME[n];
    return s && MM.Fahrzeugarten.sichtbar(s) ? s : null;
  }

  function zelleLeer(z) { return z === null || z === undefined || String(z).trim() === ''; }
  function feldLabel(f) { return f.label + (f.einheit ? ' (' + f.einheit + ')' : ''); }

  /* Die Felder, die eine Spalte bekommen kann. Mit Art: die Felder dieser Art. Ohne Art (steht in einer Spalte): alle Felder aller Arten
     und dazu die Spalte „Fahrzeugart“. */
  Daten.prototype.importZielfelder = function (artId) {
    var liste = [{ key: 'bezeichnung', label: 'Bezeichnung' }], gesehen = { bezeichnung: true };
    if (!artId) liste.push({ key: '__art', label: 'Fahrzeugart' });
    var arten = artId ? [artId] : MM.Fahrzeugarten.alle(false).map(function (a) { return a.id; });
    arten.forEach(function (id) {
      MM.Fahrzeugarten.felder(id).forEach(function (f) {
        if (gesehen[f.key]) return;
        /* Listen von Fahrzeugen und die Eignung (seit 2.0.103) gehören nicht in Tabellen. */
        if (f.typ === 'fahrzeuge' || f.typ === 'mehrfach') return;
        gesehen[f.key] = true;
        liste.push({ key: f.key, label: feldLabel(f), feld: f });
      });
    });
    return liste;
  };

  /*
   * opt = { zeilen: [[Zelle, …], …] (nur Daten, ohne Kopfzeile), zuordnung: [Schlüssel je Spalte oder ''], artId: Art für alle Zeilen oder '',
   *         ersteNr: Zeilennummer der ersten Datenzeile in der Datei (für die Anzeige) }
   * Ergebnis: { ok, zeilen: [{ nr, status: 'neu' | 'vorhanden' | 'doppelt' | 'fehler', artId, artName, bezeichnung, kennung, werte, fehlerListe }], zaehlung, nichtVerwendet }
   */
  Daten.prototype.importVorschau = function (opt) {
    var self = this, A = MM.Austausch;
    opt = opt || {};
    var zeilen = opt.zeilen || [], zuordnung = opt.zuordnung || [], standardArt = opt.artId || null, ersteNr = opt.ersteNr || 1;
    if (zeilen.length > IMPORT_MAX) return Promise.resolve({ ok: false, fehler: 'Die Tabelle hat mehr als ' + IMPORT_MAX + ' Zeilen. Bitte in kleinere Dateien teilen.' });
    if (!zeilen.length) return Promise.resolve({ ok: false, fehler: 'Unter der Kopfzeile stehen keine Zeilen.' });
    if (standardArt) {
      var wahl = MM.Fahrzeugarten.art(standardArt);
      if (!wahl || wahl.gruppe || !MM.Fahrzeugarten.sichtbar(standardArt)) return Promise.resolve({ ok: false, fehler: 'Bitte die Fahrzeugart wählen.' });
    }
    var artSpalte = -1, hatName = false, sp;
    for (sp = 0; sp < zuordnung.length; sp++) {
      if (zuordnung[sp] === '__art') artSpalte = sp;
      if (zuordnung[sp] === 'bezeichnung' || zuordnung[sp] === 'marke' || zuordnung[sp] === 'modell') hatName = true;
    }
    if (!standardArt && artSpalte < 0) return Promise.resolve({ ok: false, fehler: 'Bitte die Fahrzeugart wählen oder eine Spalte mit der Fahrzeugart zuordnen.' });
    if (!hatName) return Promise.resolve({ ok: false, fehler: 'Bitte mindestens eine Spalte der Bezeichnung zuordnen. Es geht auch mit Marke oder Modell.' });
    var kennungen = ['kennzeichen', 'registriernummer', 'fin', 'hin'];
    var alleFelder = {};
    self.importZielfelder(null).forEach(function (z) { alleFelder[z.key] = z.label; });

    return this.fahrzeugListe().then(function (liste) {
      var da = { kennung: {}, bez: {} }, gesehen = { kennung: {}, bez: {} };
      liste.forEach(function (f) {
        var w = f.aktuell.werte, hat = false;
        kennungen.forEach(function (k) { if (w[k]) { da.kennung[A.kennungNorm(w[k])] = true; hat = true; } });
        da.bez[String(w.bezeichnung || '').trim().toLowerCase()] = true;
      });
      var nichtVerwendet = {}, ergebnis = [], zaehlung = { neu: 0, vorhanden: 0, doppelt: 0, fehler: 0 };
      zeilen.forEach(function (zelle, i) {
        var alleLeer = true, s;
        for (s = 0; s < zuordnung.length; s++) { if (zuordnung[s] && !zelleLeer(zelle[s])) { alleLeer = false; break; } }
        if (alleLeer) return;
        var nr = ersteNr + i, artId = standardArt, artFehler = null;
        if (artSpalte >= 0 && !zelleLeer(zelle[artSpalte])) {
          var a = artAusText(zelle[artSpalte]);
          if (a) artId = a; else artFehler = 'Die Fahrzeugart „' + String(zelle[artSpalte]).trim() + '“ kennt die App nicht.';
        }
        if (!artId && !artFehler) artFehler = 'In dieser Zeile steht keine Fahrzeugart.';
        if (artFehler) {
          zaehlung.fehler++;
          ergebnis.push({ nr: nr, status: 'fehler', artId: null, artName: '', bezeichnung: '', kennung: '', werte: null, fehlerListe: [artFehler] });
          return;
        }
        var felder = MM.Fahrzeugarten.felder(artId), nachKey = {};
        felder.forEach(function (f) { nachKey[f.key] = f; });
        var roh = {};
        for (s = 0; s < zuordnung.length; s++) {
          var key = zuordnung[s];
          if (!key || key === '__art') continue;
          if (key === 'bezeichnung') { roh.bezeichnung = zelleLeer(zelle[s]) ? '' : String(zelle[s]).trim(); continue; }
          var f = nachKey[key];
          if (!f) { if (!zelleLeer(zelle[s])) nichtVerwendet[key] = true; continue; }
          roh[key] = A.wertUmwandeln(f, zelle[s]);
        }
        var bezLeer = !String(roh.bezeichnung || '').trim();
        if (bezLeer) {
          var teile = [roh.marke, roh.modell].filter(function (t) { return t && String(t).trim(); });
          if (teile.length) roh.bezeichnung = teile.join(' ');
        }
        var p = self.pruefen(artId, roh), art = MM.Fahrzeugarten.art(artId), fehlerListe = [];
        if (!p.ok) {
          Object.keys(p.fehler).forEach(function (k) {
            if (k === 'bezeichnung') { fehlerListe.push('Die Zeile hat keine Bezeichnung, Marke oder Modell.'); return; }
            fehlerListe.push((nachKey[k] ? nachKey[k].label : k) + ': ' + p.fehler[k] + (roh[k] ? ' (gelesen: „' + roh[k] + '“)' : ''));
          });
        }
        var w = p.werte, ids = kennungen.filter(function (k) { return w[k]; }).map(function (k) { return A.kennungNorm(w[k]); });
        var eintrag = { nr: nr, status: 'neu', artId: artId, artName: art ? art.name : artId, bezeichnung: w.bezeichnung || '', kennung: w[art && art.kennung] || w.kennzeichen || w.registriernummer || '', werte: w, fehlerListe: fehlerListe };
        if (!p.ok) eintrag.status = 'fehler';
        else {
          var bezKey = String(w.bezeichnung).trim().toLowerCase();
          if (ids.length ? ids.some(function (k) { return da.kennung[k]; }) : da.bez[bezKey]) eintrag.status = 'vorhanden';
          else if (ids.length ? ids.some(function (k) { return gesehen.kennung[k]; }) : gesehen.bez[bezKey]) eintrag.status = 'doppelt';
          else { ids.forEach(function (k) { gesehen.kennung[k] = true; }); gesehen.bez[bezKey] = true; }
        }
        zaehlung[eintrag.status]++;
        ergebnis.push(eintrag);
      });
      if (!ergebnis.length) return { ok: false, fehler: 'In den zugeordneten Spalten steht nichts.' };
      return { ok: true, zeilen: ergebnis, zaehlung: zaehlung, nichtVerwendet: Object.keys(nichtVerwendet).map(function (k) { return alleFelder[k] || k; }) };
    });
  };

  /* Legt alle Fahrzeuge der Vorschau mit Status „neu“ an, in einem Zug. Die Vorschau wird dafür noch einmal gerechnet. */
  Daten.prototype.importFahrzeuge = function (opt) {
    var self = this;
    return this.importVorschau(opt).then(function (v) {
      if (!v.ok) return v;
      var neu = v.zeilen.filter(function (z) { return z.status === 'neu'; });
      if (!neu.length) return { ok: false, fehler: 'Es gibt nichts zu übernehmen.' };
      return self.fahrzeugGrenzePruefen(neu.length).then(function (g) {
      if (!g.ok) return { ok: false, grenze: g, fehler: g.text };
      var jetzt = self.jetzt(), schreiben = [], ids = [];
      neu.forEach(function (z) {
        var fz = { id: neueId('fz'), datenraumId: self.datenraumId, art: z.artId, erstelltAm: jetzt };
        var en = { id: neueId('en'), fahrzeugId: fz.id, nr: 1, werte: z.werte, quelle: 'import', korrekturZu: null, erstelltAm: jetzt };
        schreiben.push({ tabelle: 'fahrzeuge', objekt: fz }, { tabelle: 'eintraege', objekt: en });
        ids.push(fz.id);
      });
      return self.speicher.mehrereSpeichern(schreiben).then(function () {
        return { ok: true, anzahl: neu.length, vorhanden: v.zaehlung.vorhanden, doppelt: v.zaehlung.doppelt, fehler: v.zaehlung.fehler, ids: ids };
      });
      });
    });
  };

  /* ----- Export ----- */
  function exportZelle(feld, v) {
    if (v === null || v === undefined || v === '') return '';
    if (feld.typ === 'datum') return { d: v };
    if (feld.typ === 'zahl' || feld.typ === 'ganzzahl') return typeof v === 'number' ? v : Number(v);
    if (feld.typ === 'auswahl' || feld.typ === 'mehrfach' || feld.typ === 'liste') return MM.Hilfen ? (MM.Hilfen.wert(feld, v) || '') : String(v);
    return String(v);
  }
  function optLabel(felder, key, wert) {
    if (wert === null || wert === undefined || wert === '') return '';
    for (var i = 0; i < felder.length; i++) {
      if (felder[i].key !== key) continue;
      var o = (felder[i].optionen || []).filter(function (x) { return x.wert === wert; })[0];
      return o ? o.label : String(wert);
    }
    return String(wert);
  }

  function tabelleFahrzeuge(self) {
    return self.fahrzeugListe().then(function (liste) {
      var benutzt = {}, spalten = [], gesehen = {};
      liste.forEach(function (f) { benutzt[f.fahrzeug.art] = true; });
      var reihe = MM.Fahrzeugarten.alle(true).map(function (a) { return a.id; });
      Object.keys(benutzt).forEach(function (id) { if (reihe.indexOf(id) < 0) reihe.push(id); });
      reihe.forEach(function (id) {
        if (!benutzt[id] || !MM.Fahrzeugarten.art(id)) return;
        MM.Fahrzeugarten.felder(id).forEach(function (fe) { if (!gesehen[fe.key] && fe.typ !== 'fahrzeuge') { gesehen[fe.key] = true; spalten.push(fe); } });
      });
      var kopf = ['Bezeichnung', 'Art'].concat(spalten.map(feldLabel));
      var zeilen = liste.map(function (f) {
        var w = f.aktuell.werte, art = MM.Fahrzeugarten.art(f.fahrzeug.art);
        return [w.bezeichnung, art ? art.name : f.fahrzeug.art].concat(spalten.map(function (fe) { return exportZelle(fe, w[fe.key]); }));
      });
      return { name: 'Fahrzeuge', zeilen: [kopf].concat(zeilen) };
    });
  }

  function tabelleKosten(self) {
    var felder = MM.Kosten.felderAlle();
    return self.fahrzeugListe({ alle: true }).then(function (liste) {
      return Promise.all(liste.map(function (f) { return self.kostenListe(f.fahrzeug.id); })).then(function (alle) {
        var kopf = ['Fahrzeug', 'Datum', 'Bezeichnung', 'Gruppe', 'Art der Kosten', 'Betrag (€)', 'Wie oft', 'Bis', 'Grundlage', 'Bezahlt mit', 'Währung', 'Betrag in der Währung', 'Ort', 'Ort (Text)', 'Aktivität', 'Komponente', 'Vorgang', 'Notiz', 'Ausgeblendet'];
        var zeilen = [];
        alle.forEach(function (posten, i) {
          var fz = liste[i].aktuell.werte.bezeichnung;
          posten.forEach(function (k) {
            var w = k.aktuell.werte;
            zeilen.push([fz, w.datum ? { d: w.datum } : '', w.bezeichnung || '', optLabel(felder, 'gruppe', w.gruppe), k.artName || '', typeof w.betrag === 'number' ? w.betrag : '',
              optLabel(felder, 'rhythmus', w.rhythmus), w.bis ? { d: w.bis } : '', optLabel(felder, 'grundlage', w.grundlage), k.zahlungName || '', w.waehrung || '',
              typeof w.betragWaehrung === 'number' ? w.betragWaehrung : '', k.ortName || '', w.ortText || '', k.aktivitaetName || '', k.komponenteName || '', k.vorgangName || '', w.notiz || '',
              w.ausgeblendet === 'ja' ? 'Ja' : '']);
          });
        });
        return { name: 'Kosten', zeilen: [kopf].concat(zeilen) };
      });
    });
  }

  function tabelleOrte(self) {
    return self.orteListe().then(function (liste) {
      var kopf = ['Name', 'Art des Ortes', 'Land', 'Adresse', 'Breite (Dezimalgrad)', 'Länge (Dezimalgrad)', 'Ausstattung', 'Weitere Ausstattung', 'Ansprechpartner', 'Telefon', 'Notiz', 'Ausgeblendet'];
      var zeilen = liste.map(function (o) {
        var w = o.aktuell.werte;
        return [w.bezeichnung || '', w.ortart ? (MM.Orte.ortartLabel(w.ortart) || w.ortart) : '', w.land || '', w.adresse || '',
          typeof w.positionBreite === 'number' ? w.positionBreite : '', typeof w.positionLaenge === 'number' ? w.positionLaenge : '',
          Array.isArray(w.ausstattung) ? w.ausstattung.map(MM.Orte.ausstattungLabel).join(', ') : '', w.ausstattungSonst || '', w.ansprechpartner || '', w.telefon || '', w.notiz || '',
          w.ausgeblendet === 'ja' ? 'Ja' : ''];
      });
      return { name: 'Orte', zeilen: [kopf].concat(zeilen) };
    });
  }

  var EXPORT_TABELLEN = [{ wert: 'fahrzeuge', label: 'Fahrzeuge', bau: tabelleFahrzeuge }, { wert: 'kosten', label: 'Kosten (alle Fahrzeuge, auch die Reisekasse)', bau: tabelleKosten }, { wert: 'orte', label: 'Orte', bau: tabelleOrte }];
  Daten.prototype.exportAuswahl = function () { return EXPORT_TABELLEN.map(function (t) { return { wert: t.wert, label: t.label }; }); };

  /* was = Liste der Tabellen ('fahrzeuge', 'kosten', 'orte'), format = 'xlsx' oder 'csv' (CSV nur mit einer Tabelle). */
  Daten.prototype.exportDatei = function (was, format) {
    var self = this, A = MM.Austausch;
    was = (was || []).filter(function (w) { return EXPORT_TABELLEN.some(function (t) { return t.wert === w; }); });
    if (!was.length) return Promise.resolve({ ok: false, fehler: 'Bitte wählen, was ausgegeben werden soll.' });
    if (format !== 'xlsx' && format !== 'csv') return Promise.resolve({ ok: false, fehler: 'Bitte das Format wählen.' });
    if (format === 'csv' && was.length > 1) return Promise.resolve({ ok: false, fehler: 'Eine CSV-Datei enthält nur eine Tabelle. Wähle eine Tabelle oder das Format Excel.' });
    var bauer = {};
    EXPORT_TABELLEN.forEach(function (t) { bauer[t.wert] = t.bau; });
    return Promise.all(was.map(function (w) { return bauer[w](self); })).then(function (tabellen) {
      var tag = lokalesDatum(self.jetzt()), name = 'MobiMory-' + (tabellen.length === 1 ? tabellen[0].name : 'Daten') + '-' + tag;
      var bytes = format === 'xlsx' ? A.xlsxSchreiben(tabellen) : A.csvSchreiben(tabellen[0].zeilen);
      return { ok: true, bytes: bytes, name: name + '.' + format, groesse: bytes.length,
        mime: format === 'xlsx' ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' : 'text/csv',
        tabellen: tabellen.map(function (t) { return { name: t.name, anzahl: t.zeilen.length - 1 }; }) };
    });
  };

  /* ---------- Routen, Wetter und Tide, GPS-Strecke (seit 2.0.33, Schritt 9) ---------- */
  /*
   * Eine Route gehört zu einer Aktivität (Tabelle „routen“: id, datenraumId, aktivitaetId, fahrzeugId, format, dateiName, punkte, laengeKm,
   * anzahlGelesen, erstelltAm). Die Punkte stammen aus der eingelesenen Datei und ändern sich nicht. Name, Reisegeschwindigkeit, Abfahrt, Notiz
   * und „ausgeblendet“ stehen im Verlauf. Es gilt immer die neueste Route, die nicht ausgeblendet ist. Nichts wird gelöscht.
   * Wetter und Tide aus dem Netz liegen als Dokument „wetter-<routeId>“ in „einstellungen“ (gekürzt auf die Stunden um die Ankunftszeiten),
   * damit die Auswertung auch ohne Netz da ist. Die GPS-Strecke eines Geräts liegt als Dokument „gpsspur-<aktivitaetId>“ in „einstellungen“.
   * Beides ist in der Sicherung enthalten.
   */
  /* Als Funktion, damit das Modul Routen erst beim Gebrauch gebraucht wird. */
  function routeFelder() {
    return [
      { key: 'geschwindigkeit', label: 'Reisegeschwindigkeit', typ: 'zahl' },
      { key: 'einheit', label: 'Einheit der Geschwindigkeit', typ: 'auswahl', optionen: MM.Routen.EINHEITEN },
      { key: 'abfahrtDatum', label: 'Abfahrt (Datum)', typ: 'datum' },
      { key: 'abfahrtZeit', label: 'Abfahrt (Uhrzeit)', typ: 'zeit' },
      { key: 'wetterArt', label: 'Wetterpunkte: Abstand nach', typ: 'auswahl', optionen: MM.Routen.WETTER_ARTEN },
      { key: 'wetterAbstand', label: 'Wetterpunkte: Abstand', typ: 'zahl' },
      { key: 'wetterEinheit', label: 'Wetterpunkte: Einheit', typ: 'auswahl', optionen: [{ wert: 'km', label: 'km' }, { wert: 'sm', label: 'sm' }, { wert: 'h', label: 'Stunden' }] },
      { key: 'notiz', label: 'Notiz', typ: 'text' }
    ];
  }
  function routeVerlaufFelder() {
    return [{ key: 'bezeichnung', label: 'Name', typ: 'text' }].concat(routeFelder(), [{ key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: MM.Nachweise.JA_NEIN }]);
  }

  /* Alle Routen einer Aktivität, die neueste zuerst. */
  Daten.prototype.routenListe = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.speicher.wo('routen', 'aktivitaetId', aktivitaetId), this.speicher.alle('verlaeufe')]).then(function (r) {
      var ver = {};
      r[1].forEach(function (e) { if (e.objektTyp === 'route') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      return r[0].filter(function (o) { return o.datenraumId === self.datenraumId; }).map(function (o) {
        var l = (ver[o.id] || []).slice().sort(nachNr);
        return { objekt: o, aktuell: l[l.length - 1] || null };
      }).filter(function (x) { return x.aktuell; }).sort(function (a, b) { return a.objekt.erstelltAm < b.objekt.erstelltAm ? 1 : (a.objekt.erstelltAm > b.objekt.erstelltAm ? -1 : 0); });
    });
  };

  function routeFehler(text, feld) { var f = {}; f[feld || 'allgemein'] = text; return { ok: false, fehler: f }; }

  /*
   * Eine Routendatei übernehmen. text ist der Inhalt der Datei, dateiName ihr Name.
   * Die Route wird die gültige Route der Aktivität, frühere Routen werden ausgeblendet (bleiben aber erhalten).
   * Vorbelegt: Name aus der Datei, Einheit nach Fahrzeug (Knoten auf dem Wasser, sonst km/h), Abfahrt aus dem Beginn der Aktivität.
   */
  Daten.prototype.routeImportieren = function (aktivitaetId, text, dateiName, zusatz) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.routenListe(aktivitaetId)]).then(function (r) {
      var a = r[0], alte = r[1];
      if (!a) return routeFehler('Diese Aktivität wurde nicht gefunden.');
      if (a.aktuell.werte.status === 'storniert') return routeFehler('Diese Aktivität ist storniert. Stelle sie zuerst wieder her.');
      var gelesen = MM.Routen.lesen(text, dateiName);
      if (!gelesen.ok) return routeFehler(gelesen.fehler, 'datei');
      var name = trimmed(gelesen.name) || trimmed(String(dateiName || '').replace(/\.[A-Za-z0-9]+$/, '')) || 'Route';
      var w = { bezeichnung: name.slice(0, 120), geschwindigkeit: null, einheit: a.fahrzeug.welt === 'wasser' ? 'kn' : 'kmh',
        abfahrtDatum: a.aktuell.werte.vonDatum || null, abfahrtZeit: a.aktuell.werte.vonZeit || null, wetterArt: null, wetterAbstand: null, wetterEinheit: null, notiz: null, ausgeblendet: 'nein' };
      var jetzt = self.jetzt();
      var o = { id: neueId('ro'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, fahrzeugId: a.fahrzeug.id, format: gelesen.format, dateiName: trimmed(dateiName) || null,
        punkte: gelesen.punkte, laengeKm: gelesen.laengeKm, anzahlGelesen: gelesen.anzahlGelesen, wegart: gelesen.wegart || null, erstelltAm: jetzt };
      /* Eine geplante Route (seit 2.0.88) bringt Quelle, Warnungen und Maße mit. */
      if (zusatz && typeof zusatz === 'object') Object.keys(zusatz).forEach(function (k) { o[k] = zusatz[k]; });
      var batch = [{ tabelle: 'routen', objekt: o }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('route', o.id, 1, w, null, jetzt) }];
      alte.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; }).forEach(function (x) {
        batch.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('route', x.objekt.id, x.aktuell.nr + 1, Object.assign({}, x.aktuell.werte, { ausgeblendet: 'ja' }), x.aktuell.id, jetzt) });
      });
      return self.speicher.mehrereSpeichern(batch).then(function () {
        return { ok: true, id: o.id, name: w.bezeichnung, format: gelesen.format, wegart: gelesen.wegart || null, punkte: gelesen.punkte.length, laengeKm: gelesen.laengeKm, hinweise: gelesen.hinweise };
      });
    });
  };

  Daten.prototype.routeLaden = function (id) { return this.mitVerlaufLaden('routen', id, routeVerlaufFelder()); };

  /* Prüft Name, Geschwindigkeit und Abfahrt einer Route. */
  Daten.prototype.pruefenRoute = function (roh) {
    var p = pruefeWerte(routeFelder(), roh, jahrVon(this), { bezeichnungFehler: 'Bitte der Route einen Namen geben.' });
    var w = p.werte, f = p.fehler;
    if (w.bezeichnung && w.bezeichnung.length > 120) f.bezeichnung = 'Bitte höchstens 120 Zeichen eingeben.';
    if (w.geschwindigkeit !== null && !f.geschwindigkeit) {
      var grenze = w.einheit === 'kn' ? 80 : 300;
      if (!w.einheit) f.einheit = 'Bitte wählen, ob die Geschwindigkeit in Knoten oder km/h gemeint ist.';
      else if (w.geschwindigkeit <= 0) f.geschwindigkeit = 'Die Geschwindigkeit muss größer als 0 sein.';
      else if (w.geschwindigkeit > grenze) f.geschwindigkeit = 'Das ist sehr schnell (über ' + grenze + ' ' + (w.einheit === 'kn' ? 'Knoten' : 'km/h') + '). Bitte prüfen.';
    }
    if (w.abfahrtZeit && !w.abfahrtDatum && !f.abfahrtDatum) f.abfahrtDatum = 'Bitte auch das Datum der Abfahrt eingeben.';
    /* Regel der Wetterpunkte: entweder ganz leer (dann gilt die Voreinstellung) oder Art und Abstand zusammen. */
    if (!f.wetterArt && !f.wetterAbstand && !f.wetterEinheit) {
      if (w.wetterArt || w.wetterAbstand !== null) {
        if (!w.wetterArt) f.wetterArt = 'Bitte wählen, ob der Abstand nach Entfernung oder nach Fahrzeit gilt.';
        else if (w.wetterAbstand === null) f.wetterAbstand = 'Bitte den Abstand eingeben.';
        else if (w.wetterAbstand <= 0) f.wetterAbstand = 'Der Abstand muss größer als 0 sein.';
        else if (w.wetterArt === 'zeit') { w.wetterEinheit = 'h'; if (w.wetterAbstand < 0.1) f.wetterAbstand = 'Der Abstand muss mindestens 0,1 Stunden sein.'; }
        else if (w.wetterEinheit !== 'km' && w.wetterEinheit !== 'sm') f.wetterEinheit = 'Bitte km oder sm wählen.';
        else if (w.wetterAbstand * (w.wetterEinheit === 'sm' ? 1.852 : 1) < 0.1) f.wetterAbstand = 'Der Abstand muss mindestens 100 m sein.';
      } else w.wetterEinheit = null;
    }
    w.ausgeblendet = w.ausgeblendet || 'nein';
    return { ok: Object.keys(f).length === 0, werte: w, fehler: f };
  };

  /* Name, Reisegeschwindigkeit, Abfahrt und Notiz einer Route ändern. */
  Daten.prototype.routeAendern = function (id, roh) {
    var self = this;
    return this.routeLaden(id).then(function (x) {
      if (!x) return routeFehler('Diese Route wurde nicht gefunden.');
      var p = self.pruefenRoute(roh);
      if (!p.ok) return { ok: false, fehler: p.fehler };
      var neu = Object.assign({}, x.aktuell.werte, p.werte, { ausgeblendet: x.aktuell.werte.ausgeblendet });
      return self.mitVerlaufAendern('route', id, x, neu, routeVerlaufFelder());
    });
  };

  /* Diese Route gilt jetzt: Sie wird eingeblendet, alle anderen Routen der Aktivität werden ausgeblendet. */
  Daten.prototype.routeVerwenden = function (aktivitaetId, routeId) {
    var self = this;
    return this.routenListe(aktivitaetId).then(function (liste) {
      var ziel = liste.filter(function (x) { return x.objekt.id === routeId; })[0];
      if (!ziel) return routeFehler('Diese Route wurde nicht gefunden.');
      var jetzt = self.jetzt(), batch = [];
      liste.forEach(function (x) {
        var soll = x.objekt.id === routeId ? 'nein' : 'ja';
        if (x.aktuell.werte.ausgeblendet !== soll) batch.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('route', x.objekt.id, x.aktuell.nr + 1, Object.assign({}, x.aktuell.werte, { ausgeblendet: soll }), x.aktuell.id, jetzt) });
      });
      if (!batch.length) return { ok: true, geaendert: false };
      return self.speicher.mehrereSpeichern(batch).then(function () { return { ok: true, geaendert: true }; });
    });
  };

  /* Die Route ausblenden (nichts wird gelöscht). */
  Daten.prototype.routeAusblenden = function (id) {
    var self = this;
    return this.routeLaden(id).then(function (x) {
      if (!x) return routeFehler('Diese Route wurde nicht gefunden.');
      return self.mitVerlaufAendern('route', id, x, Object.assign({}, x.aktuell.werte, { ausgeblendet: 'ja' }), routeVerlaufFelder());
    });
  };

  /* Die Abfahrt als „JJJJ-MM-TTTHH:MM“, oder null, wenn Datum oder Uhrzeit fehlt. */
  function routeAbfahrt(w) { return w.abfahrtDatum && w.abfahrtZeit ? w.abfahrtDatum + 'T' + w.abfahrtZeit : null; }

  /*
   * Alles für die Seite „Route und Wetter“ einer Aktivität.
   * Ergebnis: { ok, aktivitaet: { id, name, welt, vonDatum, vonZeit, geplanteStrecke, storniert }, route: { id, werte, format, dateiName, laengeKm, punkte, anzahlGelesen, fahrplan, wetterRegel, regelEigene, messpunkte } | null, fruehere: [...] }
   */
  Daten.prototype.routeAnsicht = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.routenListe(aktivitaetId), this.orteListe()]).then(function (r) {
      var a = r[0], liste = r[1];
      if (!a) return routeFehler('Diese Aktivität wurde nicht gefunden.');
      return self.fahrzeugLaden(a.fahrzeug.id).then(function (fz) { return routeAnsichtBauen(self, aktivitaetId, a, liste, planungVon(a, r[2], fz), fz); }).then(function (res) {
        /* Wechselpunkte (seit 2.0.116): nur Wasserfahrzeuge, aus den Routenpunkten der Datei, mit den Namen, die der Nutzer geändert hat. */
        if (!res.ok || !res.route || a.fahrzeug.welt !== 'wasser') return res;
        return self.einstellungLesen(wechselpunktDokId(res.route.id)).then(function (dok) {
          res.route.wechselpunkte = MM.Routen.wechselpunkte(res.route.punkte, res.route.wegart, dok && dok.namen, dok && dok.eigene, dok && { abstandSm: dok.abstandSm, knickGrad: dok.knickGrad });
          return res;
        });
      });
    });
  };

  /* Planung (seit 2.0.88): Start, Ziel und Zwischenziele der Aktivität mit Position, dazu die Maße und Gewichte des Fahrzeugs. Nur Straßenfahrzeuge werden berechnet;
     bei Wasserfahrzeugen bekommt die App den Link für eine Navigations-App, bei Luftfahrzeugen gibt es nichts. */
  function planungVon(a, orte, fz) {
    function ort(ref) {
      if (!ref) return null;
      var o = orte.filter(function (x) { return x.objekt.id === ref.id; })[0], w = o ? o.aktuell.werte : null;
      return { id: ref.id, name: ref.name, breite: w && typeof w.positionBreite === 'number' ? w.positionBreite : null, laenge: w && typeof w.positionLaenge === 'number' ? w.positionLaenge : null };
    }
    var start = ort(a.startOrt), ziel = ort(a.zielOrt), via = (a.zwischenziele || []).map(ort);
    var welt = a.fahrzeug.welt;
    if (welt === 'luft') return { moeglich: false, welt: welt, grund: null, navi: null };
    if (welt === 'wasser') {
      var nz = ziel && MM.Routen.navigationsLink(ziel.breite, ziel.laenge, ziel.name);
      return { moeglich: false, welt: welt, grund: 'Für Wasserfahrzeuge plant MobiMory keine Route. Du kannst das Ziel in einer Navigations-App deines Geräts öffnen.', navi: nz ? { link: nz, name: ziel.name } : null };
    }
    var werte = fz ? fz.aktuell.werte : {};
    /* Seit 2.0.123: höchstens so viele Zwischenziele wie die Aktivität Tage hat (höchstens 25). */
    var maxVia = a.aktuell && a.aktuell.werte ? MM.Routen.maxZwischenziele(a.aktuell.werte.vonDatum, a.aktuell.werte.bisDatum) : MM.Routen.MAX_ZWISCHENZIELE;
    var q = MM.Routen.planungAnfrage(start, ziel, via, werte, maxVia);
    var grenzFehler = q.fehler.map(function (t) { return /^Es sind höchstens/.test(t) && a.aktuell && a.aktuell.werte ? (MM.Routen.zwischenzielGrenzeText(via.length, a.aktuell.werte.vonDatum, a.aktuell.werte.bisDatum) || t) : t; });
    return { moeglich: true, welt: welt, start: start, ziel: ziel, via: via, werte: werte, fehlend: q.fehlend, fehler: grenzFehler, navi: null, maxVia: maxVia };
  }

  function routeAnsichtBauen(self, aktivitaetId, a, liste, planung, fz) {
    {
      var gueltig = liste.filter(function (x) { return x.aktuell.werte.ausgeblendet !== 'ja'; })[0] || null;
      var res = { ok: true, aktivitaet: { id: aktivitaetId, name: a.aktuell.werte.bezeichnung, welt: a.fahrzeug.welt, vonDatum: a.aktuell.werte.vonDatum || null, vonZeit: a.aktuell.werte.vonZeit || null,
        geplanteStrecke: a.aktuell.werte.geplanteStrecke === undefined ? null : a.aktuell.werte.geplanteStrecke, storniert: a.aktuell.werte.status === 'storniert' }, route: null, planung: planung,
        fruehere: liste.filter(function (x) { return x !== gueltig; }).map(function (x) {
          return { id: x.objekt.id, name: x.aktuell.werte.bezeichnung, format: x.objekt.format, laengeKm: x.objekt.laengeKm, erstelltAm: x.objekt.erstelltAm };
        }) };
      if (!gueltig) return res;
      var o = gueltig.objekt;
      /* Reisegeschwindigkeit (seit 2.0.118): ohne eigenen Wert vorbelegt aus dem Fahrzeug, unterwegs aus Ø Tag oder Ø fahrend. Der Wert wird nicht gespeichert, nur gerechnet. */
      var tempo = MM.Routen.tempoVorschlag(gueltig.aktuell.werte, fz && fz.aktuell ? fz.aktuell.werte : null, a.fahrzeug.welt, typeof self.tempoLive === 'function' ? self.tempoLive(aktivitaetId) : null);
      var w = tempo.eigen || tempo.wert === null ? gueltig.aktuell.werte : Object.assign({}, gueltig.aktuell.werte, { geschwindigkeit: tempo.wert, einheit: tempo.einheit });
      var fp = MM.Routen.fahrplan(o.punkte, { geschwindigkeit: w.geschwindigkeit, einheit: w.einheit, abfahrt: routeAbfahrt(w) });
      var regel = MM.Routen.wetterRegel(w, a.fahrzeug.welt);
      res.route = { id: o.id, werte: w, tempo: tempo, format: o.format, wegart: o.wegart || null, dateiName: o.dateiName, laengeKm: o.laengeKm, punkte: o.punkte, anzahlGelesen: o.anzahlGelesen, fahrplan: fp,
        geplant: o.quelle === 'here' ? { warnungen: o.warnungen || [], am: o.geplantAm || null, dauerMin: o.dauerMin || null, fehlend: o.fehlendeAngaben || [] } : null,
        wetterRegel: regel, regelEigene: !!(w.wetterArt && w.wetterAbstand),
        messpunkte: fp.ok ? MM.Routen.messpunkte(o.punkte, w.geschwindigkeit, w.einheit, regel) : [] };
      return res;
    }
  }


  /* ---------- Wechselpunkte der Route (seit 2.0.116) ----------
   * Die Namen, die der Nutzer geändert hat, liegen als ein Dokument „wechselpunkte-<routeId>“ in „einstellungen“ (in der Sicherung enthalten):
   *   { id, routeId, namen: { "<Index des ersten Punkts>": "Name" } } */
  function wechselpunktDokId(routeId) { return 'wechselpunkte-' + routeId; }
  /* Mindestabstand und Kursänderung (seit 2.0.118) stehen im selben Dokument; alle Schreibstellen nehmen sie mit. */
  function wpDokRegel(dok) { return { abstandSm: dok && typeof dok.abstandSm === 'number' ? dok.abstandSm : null, knickGrad: dok && typeof dok.knickGrad === 'number' ? dok.knickGrad : null }; }
  /* Mindestabstand und Kursänderung der Wechselpunkte einer Route einstellen. roh { abstandSm, knickGrad }, beide leer = aus (nur Zusammenfassen auf 30 m wie vorher). */
  Daten.prototype.wechselpunktRegelSetzen = function (aktivitaetId, roh) {
    var self = this, p = MM.Routen.wpRegelPruefen(roh);
    if (p.fehler) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.routeAnsicht(aktivitaetId).then(function (ra) {
      if (!ra.ok) return ra;
      if (!ra.route || !ra.route.wechselpunkte || !ra.route.wechselpunkte.handErlaubt) return routeFehler('Für diese Route gibt es keine Wechselpunkte.');
      return self.einstellungLesen(wechselpunktDokId(ra.route.id)).then(function (dok) {
        return self.einstellungSchreiben({ id: wechselpunktDokId(ra.route.id), routeId: ra.route.id, namen: (dok && dok.namen) || {}, eigene: (dok && dok.eigene) || [], abstandSm: p.werte.abstandSm, knickGrad: p.werte.knickGrad, geaendertAm: self.jetzt() })
          .then(function () { return { ok: true }; });
      });
    });
  };

  /* Wechselpunkte von Hand (seit 2.0.117, nur Wasserfahrzeuge): im selben Dokument wie die Namen, als Liste „eigene“: { id, name, breite, laenge, am }.
     fn bekommt die bisherige Liste und gibt { eigene } oder { fehler } zurück. */
  var WP_HAND_MAX = 50;
  function wechselpunktHandAendern(self, aktivitaetId, fn) {
    return self.routeAnsicht(aktivitaetId).then(function (ra) {
      if (!ra.ok) return ra;
      if (!ra.route || !ra.route.wechselpunkte || !ra.route.wechselpunkte.handErlaubt) return routeFehler('Für diese Route kannst du keine Wechselpunkte eintragen.');
      return self.einstellungLesen(wechselpunktDokId(ra.route.id)).then(function (dok) {
        var erg = fn((dok && dok.eigene) || []);
        if (erg.fehler) return { ok: false, fehler: erg.fehler };
        return self.einstellungSchreiben({ id: wechselpunktDokId(ra.route.id), routeId: ra.route.id, namen: (dok && dok.namen) || {}, eigene: erg.eigene, abstandSm: wpDokRegel(dok).abstandSm, knickGrad: wpDokRegel(dok).knickGrad, geaendertAm: self.jetzt() })
          .then(function () { return { ok: true, id: erg.id || null }; });
      });
    });
  };
  /* Neuer Wechselpunkt: roh { name (freiwillig), breite, laenge }. Die Position kann „aktuelle Position nehmen“ oder getippt sein. */
  Daten.prototype.wechselpunktHandNeu = function (aktivitaetId, roh) {
    var self = this, p = MM.Routen.handPunktPruefen(roh);
    if (p.fehler) return Promise.resolve({ ok: false, fehler: p.fehler });
    return wechselpunktHandAendern(this, aktivitaetId, function (liste) {
      if (liste.length >= WP_HAND_MAX) return { fehler: { allgemein: 'Es sind höchstens ' + WP_HAND_MAX + ' Wechselpunkte von Hand möglich.' } };
      var id = neueId('wp');
      return { id: id, eigene: liste.concat([{ id: id, name: p.werte.name, breite: p.werte.breite, laenge: p.werte.laenge, am: self.jetzt() }]) };
    });
  };
  /* Einen Handpunkt umbenennen (leerer Name = „Punkt <Nummer>“). */
  Daten.prototype.wechselpunktHandBenennen = function (aktivitaetId, id, name) {
    var n = MM.Routen.wpNamenSetzen({}, 0, name);
    if (n.fehler) return Promise.resolve({ ok: false, fehler: { name: n.fehler } });
    var neu = String(name == null ? '' : name).trim();
    return wechselpunktHandAendern(this, aktivitaetId, function (liste) {
      if (!liste.some(function (e) { return e.id === id; })) return { fehler: { allgemein: 'Diesen Wechselpunkt gibt es nicht.' } };
      return { eigene: liste.map(function (e) { return e.id === id ? Object.assign({}, e, { name: neu }) : e; }) };
    });
  };
  /* Einen Handpunkt löschen. */
  Daten.prototype.wechselpunktHandLoeschen = function (aktivitaetId, id) {
    return wechselpunktHandAendern(this, aktivitaetId, function (liste) {
      if (!liste.some(function (e) { return e.id === id; })) return { fehler: { allgemein: 'Diesen Wechselpunkt gibt es nicht.' } };
      return { eigene: liste.filter(function (e) { return e.id !== id; }) };
    });
  };

  /* Einen Wechselpunkt umbenennen. index: Index des ersten Punkts (Feld „index“ des Wechselpunkts). Leerer Name stellt den Namen aus der Datei wieder her. */
  Daten.prototype.wechselpunktBenennen = function (aktivitaetId, index, name) {
    var self = this;
    return this.routeAnsicht(aktivitaetId).then(function (ra) {
      if (!ra.ok) return ra;
      if (!ra.route || !ra.route.wechselpunkte || !ra.route.wechselpunkte.moeglich) return routeFehler('Diese Route hat keine Wechselpunkte.');
      var vorhanden = ra.route.wechselpunkte.liste.filter(function (w) { return w.index === index && !w.hand; })[0];
      if (!vorhanden) return routeFehler('Diesen Wechselpunkt gibt es nicht.');
      return self.einstellungLesen(wechselpunktDokId(ra.route.id)).then(function (dok) {
        var n = MM.Routen.wpNamenSetzen(dok && dok.namen, index, name);
        if (n.fehler) return { ok: false, fehler: { name: n.fehler } };
        return self.einstellungSchreiben({ id: wechselpunktDokId(ra.route.id), routeId: ra.route.id, namen: n.namen, eigene: (dok && dok.eigene) || [], abstandSm: wpDokRegel(dok).abstandSm, knickGrad: wpDokRegel(dok).knickGrad, geaendertAm: self.jetzt() }).then(function () { return { ok: true, name: name }; });
      });
    });
  };

  /* ---------- Kurswechsel (seit 2.0.116, nur Wasserfahrzeuge) ----------
   * Ein Eintrag der Art „Kurswechsel“ im Logbuch (Datum, Uhrzeit, Position wie bei jedem Eintrag, Zeichen KW auf der Karte; die Position kann im Eintrag von Hand
   * geändert werden). Der Text hält Grund, Kurs über Grund (GPS) und eine freie Notiz fest. roh: { grund (aus KURSWECHSEL_GRUENDE), notiz, position (frischer GPS-Punkt
   * { breite, laenge, genauigkeit }), kurs (ganze Grad oder null), geschwindigkeit (m/s oder null) }. */
  Daten.prototype.kurswechsel = function (aktivitaetId, roh) {
    var self = this;
    roh = roh || {};
    var grund = String(roh.grund == null ? '' : roh.grund).trim(), notiz = String(roh.notiz == null ? '' : roh.notiz).trim();
    if (MM.Logbuch.KURSWECHSEL_GRUENDE.indexOf(grund) < 0) return Promise.resolve({ ok: false, fehler: { grund: 'Bitte einen Grund wählen.' } });
    if (notiz.length > 500) return Promise.resolve({ ok: false, fehler: { notiz: 'Die Notiz darf höchstens 500 Zeichen haben.' } });
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (a.fahrzeug.welt !== 'wasser') return { ok: false, fehler: { allgemein: 'Einen Kurswechsel gibt es nur bei Wasserfahrzeugen.' } };
      if (a.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var kurs = typeof roh.kurs === 'number' && isFinite(roh.kurs) ? Math.round(roh.kurs) % 360 : null;
      var text = MM.Logbuch.kurswechselText(grund, notiz, kurs, typeof roh.geschwindigkeit === 'number' ? roh.geschwindigkeit : null);
      /* seit 2.0.130: Steuerkurs von Hand und der Versatz des Schlags davor */
      var steuer = MM.Seemann.gradEingabe(roh.steuerkurs);
      if (steuer !== null && isNaN(steuer)) return { ok: false, fehler: { steuerkurs: 'Bitte den Steuerkurs als Zahl von 0 bis 360 eingeben.' } };
      return self.wasserArtenSichern().then(function () { return self.ereignisartenListe(); }).then(function (arten) {
        var art = arten.filter(function (x) { return MM.Logbuch.istKurswechselArt(x.aktuell.werte.bezeichnung); })[0];
        if (!art) return { ok: false, fehler: { allgemein: 'Die Art „Kurswechsel“ gibt es nicht.' } };
        return self.steuerkursLesen(aktivitaetId).then(function (alt) {
          var v = alt && alt.start && roh.position ? MM.Seemann.versatz(alt.grad, alt.start, roh.position) : null;
          if (v) text += ' Bisher Steuerkurs ' + MM.Seemann.kursText(alt.grad) + ' (' + MM.Seemann.quelleText(alt.quelle) + '), ' + MM.Seemann.versatzText(v.versatz) + '.';
          if (steuer !== null) text += ' Neuer Steuerkurs ' + MM.Seemann.kursText(steuer) + ' (von Hand).';
          return self.ereignisSchnell(aktivitaetId, MM.Logbuch.KURSWECHSEL_ART, { artId: art.objekt.id, text: text, position: roh.position || null }).then(function (r) {
            if (!r.ok) return r;
            r.kurs = kurs; r.position = !!(roh.position && typeof roh.position.breite === 'number'); r.text = text;
            /* Ein neuer Kurs macht den alten Steuerkurs ungültig. */
            if (!alt && steuer === null) return r;
            return self.steuerkursSetzen(aktivitaetId, steuer === null ? '' : steuer, roh.position || null).then(function () { return r; });
          });
        });
      });
    });
  };

  /* ---------- Hafen und Stellplatz (seit 2.0.130) ----------
   * Die Knöpfe für Ablegen, Anlegen, Anker bzw. Abfahrt, Anhalten, Ankunft stehen fest auf der dritten Cockpit-Seite.
   * Fehlende Arten werden angelegt; vorhandene (auch ausgeblendete) bleiben, wie sie sind. */
  Daten.prototype.ablaufArtenSichern = function (welt) {
    var self = this, namen = MM.Logbuch.ABLAUF[welt];
    if (!namen) return Promise.resolve({ ok: true, anzahl: 0 });
    return this.ereignisartenListe().then(function (liste) {
      var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
      var neu = namen.filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
      return neu.reduce(function (kette, n) {
        return kette.then(function () { return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: n, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten([welt]) }); });
      }, Promise.resolve()).then(function () { return { ok: true, anzahl: neu.length }; });
    });
  };
  /* { name klein: Ereignisart-Kennung } der Hafen- bzw. Stellplatzknöpfe, die es gibt und die zur Fahrzeugart passen */
  Daten.prototype.ablaufArten = function (fahrzeugArtId, welt) {
    var self = this;
    return this.ereignisartenAusVorschlaegen().then(function () { return self.ablaufArtenSichern(welt); }).then(function () { return self.ereignisartenListe(); }).then(function (liste) {
      return (MM.Logbuch.ABLAUF[welt] || []).map(function (n) {
        var x = liste.filter(function (a) { var w = a.aktuell.werte; return w.bezeichnung.toLowerCase() === n.toLowerCase() && w.ausgeblendet !== 'ja' && MM.Logbuch.ereignisartGilt(w.zuordnung, fahrzeugArtId); })[0];
        return x ? { typ: 'ereignis', id: x.objekt.id, name: x.aktuell.werte.bezeichnung,
          ablauf: MM.Baukasten ? MM.Baukasten.hatAblauf(x.aktuell.werte) : false } : null;
      }).filter(Boolean);
    });
  };

  /* ---------- Steuerkurs (seit 2.0.130): Dokument „steuerkurs-<aktivitaetId>“ ---------- */
  Daten.prototype.steuerkursLesen = function (aktivitaetId) {
    return this.einstellungLesen('steuerkurs-' + aktivitaetId).then(function (d) { return d && typeof d.grad === 'number' ? d : null; });
  };
  /* grad: Eingabe (leer löscht), position: frischer GPS-Punkt oder null (dann zählt der erste Punkt danach), quelle: 'hand' (später 'bordnetz', 'kompass') */
  Daten.prototype.steuerkursSetzen = function (aktivitaetId, grad, position, quelle) {
    var self = this, g = MM.Seemann.gradEingabe(grad);
    if (g !== null && isNaN(g)) return Promise.resolve({ ok: false, fehler: { grad: 'Bitte den Steuerkurs als Zahl von 0 bis 360 eingeben.' } });
    var pos = position && typeof position.breite === 'number' ? { breite: position.breite, laenge: position.laenge } : null;
    return this.einstellungSchreiben({ id: 'steuerkurs-' + aktivitaetId, aktivitaetId: aktivitaetId, grad: g, start: g === null ? null : pos, quelle: MM.Seemann.KURS_QUELLEN[quelle] ? quelle : 'hand', geaendertAm: self.jetzt() })
      .then(function () { return { ok: true, grad: g }; });
  };
  Daten.prototype.steuerkursStart = function (aktivitaetId, position) {
    var self = this;
    return this.steuerkursLesen(aktivitaetId).then(function (d) {
      if (!d || d.start) return d;
      var neu = Object.assign({}, d, { start: { breite: position.breite, laenge: position.laenge }, geaendertAm: self.jetzt() });
      return self.einstellungSchreiben(neu).then(function () { return neu; });
    });
  };

  /* ---------- Kreuzen (seit 2.0.130): Dokument „kreuzen-<aktivitaetId>“. stand: null (nichts), geplant (aktiv false) oder laufend ---------- */
  Daten.prototype.kreuzenLesen = function (aktivitaetId) {
    return this.einstellungLesen('kreuzen-' + aktivitaetId).then(function (d) { return d && d.stand ? d.stand : null; });
  };
  Daten.prototype.kreuzenSchreiben = function (aktivitaetId, stand) {
    return this.einstellungSchreiben({ id: 'kreuzen-' + aktivitaetId, aktivitaetId: aktivitaetId, stand: stand, geaendertAm: this.jetzt() }).then(function () { return { ok: true, stand: stand }; });
  };
  /* Planen (ohne Eintrag ins Logbuch) */
  Daten.prototype.kreuzenPlanen = function (aktivitaetId, roh) {
    var r = MM.Seemann.kreuzPlan(roh);
    if (!r.ok) return Promise.resolve(r);
    return this.kreuzenSchreiben(aktivitaetId, Object.assign({}, r.plan, { aktiv: false }));
  };
  /* Starten oder ändern: Eintrag „Kurswechsel: Kreuzen“ ins Logbuch, ab jetzt wird gezählt. opt: { notiz, position, kurs, geschwindigkeit } */
  Daten.prototype.kreuzenStarten = function (aktivitaetId, roh, opt) {
    var self = this, r = MM.Seemann.kreuzPlan(roh);
    if (!r.ok) return Promise.resolve(r);
    var o = opt || {}, notiz = [MM.Seemann.kreuzPlanText(r.plan), String(o.notiz || '').trim()].filter(Boolean).join('. ').slice(0, 500);
    return this.kurswechsel(aktivitaetId, { grund: MM.Seemann.KREUZ_GRUND, notiz: notiz, position: o.position, kurs: o.kurs, geschwindigkeit: o.geschwindigkeit, steuerkurs: r.plan.kurs1 === null ? '' : r.plan.kurs1 }).then(function (k) {
      if (!k.ok) return k;
      return self.kreuzenSchreiben(aktivitaetId, MM.Seemann.kreuzStart(r.plan, new Date(self.jetzt()).getTime())).then(function () { return k; });
    });
  };
  /* „Wende gefahren“ von Hand (die erkannte Wende schreibt die Seite selbst): neu zählen, bei „einmalig“ ist Schluss */
  Daten.prototype.kreuzenGedreht = function (aktivitaetId) {
    var self = this;
    return this.kreuzenLesen(aktivitaetId).then(function (z) {
      if (!z || !z.aktiv) return { ok: false };
      if (!z.wiederholt) return self.kreuzenSchreiben(aktivitaetId, null);
      z.schlag += 1; z.refKurs = null;
      MM.Seemann.kreuzNeuZaehlen(z, new Date(self.jetzt()).getTime(), 0);
      return self.kreuzenSchreiben(aktivitaetId, z);
    });
  };
  Daten.prototype.kreuzenBeenden = function (aktivitaetId) { return this.kreuzenSchreiben(aktivitaetId, null); };

  /* ---------- Fahrtarten (seit 2.0.130): aus Segel setzen/bergen, Motorläufen und Ablegen/Anlegen/Anker gerechnet ---------- */
  function ortMs(datum, zeit) { var m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(datum + 'T' + (zeit || '00:00')); return m ? new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]).getTime() : null; }
  Daten.prototype.fahrtarten = function (aktivitaetId) {
    var self = this;
    return this.logbuchLaden(aktivitaetId).then(function (lb) {
      if (!lb) return null;
      var a = lb.aktivitaet, w = a.aktuell.werte;
      if (a.fahrzeug.welt !== 'wasser' || MM.Fahrzeugarten.vorfahren(a.fahrzeug.artId).indexOf('segelboot') < 0) return null;
      return Promise.all([self.motorenListe(a.fahrzeug.id), self.speicher.holen('einstellungen', 'motorlaeufe'), self.speicher.wo('ereignisse', 'aktivitaetId', aktivitaetId), self.speicher.alle('verlaeufe'),
        self.gpsWegLesen(aktivitaetId), self.einstellungLesen('fahrtart-' + aktivitaetId), self.ereignisartenListe()]).then(function (r) {
        var motorIds = r[0].map(function (m) { return m.komponenteId; });
        var beginn = ortMs(w.vonDatum, '00:00'), grenze = ortMs(w.bisDatum || w.vonDatum, '00:00') + 86400000;
        var jetzt = new Date(self.jetzt()).getTime(), ende = Math.min(jetzt, grenze);
        var laeufe = ((r[1] && r[1].laeufe) || []).filter(function (l) { return motorIds.indexOf(l.komponenteId) >= 0; })
          .map(function (l) { return { von: new Date(l.start).getTime(), bis: l.stopp ? new Date(l.stopp).getTime() : null }; })
          .filter(function (l) { return (l.bis === null || l.bis > beginn) && l.von < ende; })
          .map(function (l) { return { von: Math.max(l.von, beginn), bis: l.bis }; });
        var arten = {}; r[6].forEach(function (x) { arten[x.objekt.id] = x.aktuell.werte; });
        var segel = [], fahrt = [];
        neuesteStaende(r[2], r[3], 'ereignis').forEach(function (e) {
          var v = e.aktuell.werte, art = arten[v.artId];
          if (v.ausgeblendet === 'ja' || !v.datum || !art) return;
          var ms = ortMs(v.datum, v.zeit), name = art.bezeichnung;
          var wirkung = v.segelWirkung || (/^segel setzen$/i.test(name) ? 'gesetzt' : (/^segel bergen$/i.test(name) ? 'geborgen' : null));
          if (wirkung) segel.push({ ms: ms, wirkung: wirkung, ids: v.segelIds || [], name: name });
          var regel = MM.Status.regelFuer(art, 'wasser');
          if (regel) fahrt.push({ ms: ms, unterwegs: regel.danach === 'in-fahrt' });
        });
        if (!segel.length && !laeufe.length) return { abschnitte: [], summen: MM.Seemann.fahrtSummen([]), laufend: null };
        var abschnitte = MM.Seemann.fahrtAbschnitte({ motorlaeufe: laeufe, segel: segel, fahrt: fahrt, endeMs: ende, aenderungen: (r[5] && r[5].liste) || [] });
        var punkte = (r[4] && r[4].punkte) || [];
        abschnitte.forEach(function (x) { x.sm = MM.Seemann.wegSm(punkte, x.von, x.bis); });
        var l = abschnitte[abschnitte.length - 1];
        return { abschnitte: abschnitte, summen: MM.Seemann.fahrtSummen(abschnitte), laufend: l && ende === jetzt && l.bis === ende ? l.art : null };
      });
    });
  };
  /* Nachträglich ändern: gilt für den Zeitraum des Abschnitts. art '' nimmt die Änderung zurück. */
  Daten.prototype.fahrtartAendern = function (aktivitaetId, von, bis, art) {
    var self = this;
    if (!(bis > von) || (art && !MM.Seemann.FAHRTARTEN[art])) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Fahrtart gibt es nicht.' } });
    return this.einstellungLesen('fahrtart-' + aktivitaetId).then(function (d) {
      var liste = ((d && d.liste) || []).filter(function (x) { return x.bis <= von || x.von >= bis; });
      if (art) liste.push({ von: von, bis: bis, art: art });
      return self.einstellungSchreiben({ id: 'fahrtart-' + aktivitaetId, aktivitaetId: aktivitaetId, liste: liste, geaendertAm: self.jetzt() }).then(function () { return { ok: true }; });
    });
  };

  /* ---------- Person über Bord: Weg des Boots (seit 2.0.130) ----------
   * Seit 2.0.133 im Dokument „gpsmob-<aktivitaetId>“ ({ mob: { ereignisId: [[breite, laenge, ms]] } }): ohne Punktgrenze und im verschlüsselten
   * GPS-Abgleich. Ältere Wege liegen weiter in „mobweg-<ereignisId>“ und werden mitgelesen. */
  function mobDokId(aktivitaetId) { return 'gpsmob-' + aktivitaetId; }
  Daten.prototype.mobAktivitaet = function (ereignisId) {
    return this.speicher.holen('ereignisse', ereignisId).then(function (e) { return e ? e.aktivitaetId : null; });
  };
  Daten.prototype.mobWegLesen = function (ereignisId) {
    var self = this;
    return Promise.all([this.einstellungLesen('mobweg-' + ereignisId), this.mobAktivitaet(ereignisId)]).then(function (r) {
      var alt = r[0] && r[0].punkte ? r[0].punkte : [];
      if (!r[1]) return alt;
      return self.einstellungLesen(mobDokId(r[1])).then(function (d) { return MM.Mob.wegZusammen(alt, d && d.mob ? d.mob[ereignisId] : []); });
    });
  };
  Daten.prototype.mobWegSpeichern = function (ereignisId, punkte) {
    var self = this;
    return this.mobAktivitaet(ereignisId).then(function (aktId) {
      if (!aktId) return null;
      return self.einstellungLesen(mobDokId(aktId)).then(function (d) {
        var mob = Object.assign({}, d && d.mob);
        mob[ereignisId] = MM.Mob.wegZusammen(mob[ereignisId], punkte);
        return self.einstellungSchreiben({ id: mobDokId(aktId), aktivitaetId: aktId, mob: mob, geaendertAm: self.jetzt() });
      });
    });
  };
  /* Welches Manöver zeichnet dieses Gerät gerade auf? Übersteht den Neustart der App. */
  Daten.prototype.mobLaeuftMerken = function (stand) { return this.einstellungSchreiben({ id: 'mobaktiv', stand: stand || null }); };
  Daten.prototype.mobLaeuft = function () {
    var self = this;
    return this.einstellungLesen('mobaktiv').then(function (d) {
      if (!d || !d.stand) return null;
      return self.ereignisLaden(d.stand.ereignisId).then(function (x) { return x && x.aktuell.werte.endeStatus === 'laeuft' ? d.stand : null; });
    });
  };
  function mobPosition(p) { return p && typeof p.breite === 'number' && typeof p.laenge === 'number' ? { breite: p.breite, laenge: p.laenge } : {}; }
  /* Eigene Zeile im Logbuch (gesichtet, wieder an Bord). Die Art ist ausgeblendet, damit sie nicht als Knopf erscheint. */
  Daten.prototype.mobZeile = function (ereignisId, name, text, position) {
    var self = this;
    return Promise.all([this.mobAktivitaet(ereignisId), this.ereignisartenListe()]).then(function (r) {
      if (!r[0]) return null;
      var da = r[1].filter(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === name.toLowerCase(); })[0];
      var art = da ? Promise.resolve(da.objekt.id) : self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: name, ausgeblendet: 'ja', zuordnung: MM.Logbuch.zuordnungFuerKnoten(['wasser']) }).then(function (x) { return x.id; });
      return art.then(function (artId) {
        return self.ereignisSchnell(r[0], name, { artId: artId, text: text, position: position && typeof position.breite === 'number' ? position : null }).then(function (n) {
          return n.ok ? self.manoeverSchreiben(n.id, { mobZu: ereignisId }).then(function () { return n; }) : n;
        });
      });
    });
  };
  /* „Person gesichtet“: neue Stelle, jede Sichtung bleibt. gezogen: die Stelle der Person auf der Karte; die GPS-Werte der Sichtung bleiben (seit 2.0.133). */
  Daten.prototype.mobGesichtet = function (ereignisId, position, gezogen) {
    var self = this;
    if (!position || typeof position.breite !== 'number') return Promise.resolve({ ok: false, fehler: { allgemein: 'Zurzeit gibt es keine GPS-Position.' } });
    return this.ereignisLaden(ereignisId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      var liste = (x.aktuell.werte.mobSichtungen || []).slice(), ms = new Date(self.jetzt()).getTime();
      var neu = { breite: position.breite, laenge: position.laenge, ms: ms };
      if (gezogen && liste.length) {
        liste[liste.length - 1] = Object.assign({}, liste[liste.length - 1], { person: neu });
        return self.manoeverSchreiben(ereignisId, { mobSichtungen: liste });
      }
      liste.push(neu);
      return self.manoeverSchreiben(ereignisId, { mobSichtungen: liste }).then(function (r) {
        return self.mobZeile(ereignisId, MM.Mob.ART_GESICHTET, 'Sichtung ' + liste.length + ' um ' + MM.Mob.uhr(ms) + ' Uhr, Position des Boots ' + MM.Mob.position(neu), position).then(function () { return r; });
      });
    });
  };
  /* Ende des Manövers: Zeit und Position festhalten, Zeile ins Logbuch. opt: { position, ms, uebung } */
  Daten.prototype.mobBeenden = function (ereignisId, opt) {
    var self = this, o = opt || {};
    return this.ereignisLaden(ereignisId).then(function (x) {
      if (!x || x.aktuell.werte.endeStatus !== 'laeuft') return { ok: false };
      var w = x.aktuell.werte, ms = o.ms || new Date(self.jetzt()).getTime(), uebung = o.uebung || w.uebung === 'uebung';
      var bergung = Object.assign({ ms: ms }, mobPosition(o.position));
      var start = MM.Mob.start(w);
      var werte = { endeStatus: 'erkannt', mobBergung: bergung, dauerS: start.ms ? Math.max(0, Math.round((ms - start.ms) / 1000)) : undefined };
      if (uebung) werte.uebung = 'uebung';
      var name = uebung ? MM.Mob.ART_UEBUNG_AN_BORD : MM.Mob.ART_AN_BORD;
      return self.manoeverSchreiben(ereignisId, werte).then(function (r) {
        var text = name + ' um ' + MM.Mob.uhr(ms) + ' Uhr, Position ' + MM.Mob.position(bergung) + (start.ms ? '. Beginn ' + MM.Mob.uhr(start.ms) + ' Uhr, ' + MM.Mob.position(start) + '. Dauer ' + MM.Mob.dauer(ms - start.ms) : '') +
          (w.skipperName ? '. Skipper: ' + w.skipperName : '') + (w.ruderName ? ', Rudergänger: ' + w.ruderName : '');
        return self.mobZeile(ereignisId, name, text, o.position).then(function () { return r; });
      });
    });
  };
  /* Angaben zum Manöver (seit 2.0.133). Nach dem Ende entsteht ein Nachtrag mit Datum und Uhrzeit. */
  Daten.prototype.mobAkteSpeichern = function (ereignisId, neu) {
    var self = this;
    return this.ereignisLaden(ereignisId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      var w = x.aktuell.werte, e = MM.Mob.einarbeiten(w, neu || {}, w.endeStatus !== 'laeuft', new Date(self.jetzt()).getTime());
      if (!e.geaendert) return { ok: true, geaendert: false };
      return self.manoeverSchreiben(ereignisId, e.werte).then(function () { return { ok: true, geaendert: true }; });
    });
  };
  /* Checkliste: Antippen hält die Zeit fest, die erste Zeit bleibt. */
  Daten.prototype.mobHaken = function (ereignisId, schluessel) {
    var self = this;
    return this.ereignisLaden(ereignisId).then(function (x) {
      if (!x) return { ok: false };
      var c = Object.assign({}, x.aktuell.werte.mobCheck);
      if (c[schluessel]) return { ok: true };
      c[schluessel] = new Date(self.jetzt()).getTime();
      return self.manoeverSchreiben(ereignisId, { mobCheck: c });
    });
  };
  /* Fotos zum Manöver: jedes Foto als eigene Zeile im Logbuch, dort gilt die Regel „eine Datei je Eintrag“ und der Abgleich wie bei jedem Foto. */
  Daten.prototype.mobFotoDazu = function (ereignisId, datei) {
    var self = this;
    if (!datei || !(datei.size > 0)) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Datei ist leer.' } });
    return this.mobZeile(ereignisId, 'Foto Person über Bord', String(datei.name || 'Foto'), null).then(function (n) {
      if (!n || !n.ok) return n || { ok: false, fehler: { allgemein: 'Das Foto konnte nicht gespeichert werden.' } };
      return self.ereignisAktionSpeichern(n.id, { datei: datei });
    });
  };
  Daten.prototype.mobFotos = function (ereignisId) {
    var self = this;
    return Promise.all([this.speicher.alle('verlaeufe'), this.mobAktivitaet(ereignisId)]).then(function (r) {
      if (!r[1]) return [];
      return self.speicher.wo('ereignisse', 'aktivitaetId', r[1]).then(function (l) {
        var ids = neuesteStaende(l, r[0], 'ereignis').filter(function (e) { return e.aktuell.werte.mobZu === ereignisId && e.aktuell.werte.dateiName; }).map(function (e) { return e.objekt.id; });
        return Promise.all(ids.map(function (id) { return self.ereignisDateiHolen(id); })).then(function (d) { return d.filter(Boolean); });
      });
    });
  };
  /* Alles zu einem Manöver: Eintrag, Weg, Strecke, Fotos, Aktivität, Personen an Bord zur Zeit des Sturzes. */
  Daten.prototype.mobLaden = function (ereignisId) {
    var self = this;
    return this.ereignisLaden(ereignisId).then(function (x) {
      if (!x || !x.ereignis) return null;
      return Promise.all([self.aktivitaetLaden(x.ereignis.aktivitaetId), self.mobWegLesen(ereignisId), self.mobFotos(ereignisId)]).then(function (r) {
        var a = r[0], w = x.aktuell.werte, start = MM.Mob.start(w);
        var jetzt = w.datum && w.zeit ? w.datum + 'T' + w.zeit : self.jetztLokal().slice(0, 16);
        var crew = a ? a.besatzung.filter(function (b) { return MM.Rudergaenger.dabei(b.aktuell.werte, jetzt); }) : [];
        return { x: x, werte: w, aktivitaet: a, weg: r[1], strecke: MM.Mob.strecke(r[1], MM.Seemann.meter), fotos: r[2], start: start, crew: crew.map(function (b) { return b.person.name; }) };
      });
    });
  };
  /* Alle Manöver und Übungen eines Fahrzeugs zum Vergleich der Zeiten, neueste zuerst. */
  Daten.prototype.mobVergleich = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.aktivitaetenListe(), this.speicher.alle('verlaeufe')]).then(function (r) {
      var meine = r[0].filter(function (a) { return a.aktuell.werte.fahrzeugId === fahrzeugId; });
      return Promise.all(meine.map(function (a) { return self.speicher.wo('ereignisse', 'aktivitaetId', a.objekt.id); })).then(function (listen) {
        return neuesteStaende([].concat.apply([], listen), r[1], 'ereignis').map(function (e) {
          var w = e.aktuell.werte;
          if (!w.mob || w.ausgeblendet === 'ja' || !w.startMs) return null;
          var s = MM.Mob.ersteSichtungMs(w), b = MM.Mob.bergungMs(w);
          return { id: e.objekt.id, ms: w.startMs, uebung: w.uebung === 'uebung', sichtungS: s ? Math.round((s - w.startMs) / 1000) : null,
            bergungS: b ? Math.round((b - w.startMs) / 1000) : (w.endeStatus !== 'laeuft' && typeof w.dauerS === 'number' ? w.dauerS : null) };
        }).filter(Boolean).sort(function (p, q) { return q.ms - p.ms; });
      });
    });
  };
  /* Wind und Strömung von Hand zum Suchbereich. Leere Felder löschen die Handangabe. */
  Daten.prototype.mobAngaben = function (ereignisId, roh) {
    var self = this, S = MM.Seemann, f = {};
    var kn = S.zahl(roh.windStaerke), sg = S.gradEingabe(roh.stromRichtung), sk = S.zahl(roh.stromKn);
    if (String(roh.windStaerke || '').trim() && (kn === null || kn < 0 || kn > 400)) f.windStaerke = 'Bitte die Windstärke als Zahl eingeben.';
    if (sg !== null && isNaN(sg)) f.stromRichtung = 'Richtung bitte 0 bis 360.';
    if (String(roh.stromKn || '').trim() && (sk === null || sk < 0 || sk > 15)) f.stromKn = 'Stärke bitte 0 bis 15 Knoten.';
    if (Object.keys(f).length) return Promise.resolve({ ok: false, fehler: f });
    return this.segelEinstellungen().then(function (e) {
      if (e.windEinheit === 'bft' && kn !== null && kn > 12) return { ok: false, fehler: { windStaerke: 'Beaufort geht von 0 bis 12. Die Einheit stellst du unter Einstellungen › Segeln um.' } };
      var i = MM.Segeln.HIMMEL.indexOf(roh.windRichtung);
      return self.manoeverSchreiben(ereignisId, {
        mobWindKn: kn === null ? null : Math.round(S.windKn(kn, e.windEinheit) * 10) / 10,
        mobWindAus: i >= 0 ? i * 22.5 : null,
        mobStromGrad: sg === null ? null : sg, mobStromKn: sk });
    });
  };

  /* ---------- Segeln (seit 2.0.129) ---------- */
  /* Die Antworten zu den Segel-Fragen. null, wenn nichts eingetragen ist. */
  function segelAntworten(z, a, fehler) {
    var hat = function (f) { return z.fragen.indexOf(f) >= 0; }, r = {};
    var t = function (v, max) { return String(v === undefined || v === null ? '' : v).trim().slice(0, max || 60); };
    if (hat('segel') && Array.isArray(a.segelIds) && a.segelIds.length) r.segelIds = a.segelIds.map(String);
    if (hat('reffstufe') && t(a.reffstufe)) r.reffstufe = t(a.reffstufe);
    if (hat('antrieb') && (a.antrieb === 'segel' || a.antrieb === 'motor')) r.antrieb = a.antrieb;
    if (hat('uebung') && (a.uebung === 'uebung' || a.uebung === 'ernstfall')) r.uebung = a.uebung;
    if (hat('wind')) {
      if (t(a.windStaerke)) {
        var n = Number(t(a.windStaerke).replace(',', '.'));
        if (!isFinite(n) || n < 0 || n > 400) fehler.windStaerke = 'Bitte die Windstärke als Zahl eingeben.';
        else { r.windStaerke = n; r.windEinheit = MM.Segeln.einstellungen({ windEinheit: a.windEinheit }).windEinheit; }
      }
      if (MM.Segeln.HIMMEL.indexOf(a.windRichtung) >= 0) r.windRichtung = a.windRichtung;
      if ((a.windArt === 'scheinbar' || a.windArt === 'wahr') && (r.windStaerke !== undefined || r.windRichtung)) r.windArt = a.windArt;
    }
    if (hat('logge')) { if (t(a.logge)) r.logge = t(a.logge); if (t(a.sicht)) r.sicht = t(a.sicht); }
    if (hat('checkliste') && Array.isArray(a.checklisteErledigt) && a.checklisteErledigt.length) r.checklisteErledigt = a.checklisteErledigt.map(String).join(', ').slice(0, 600);
    return Object.keys(r).length ? r : null;
  }

  /* Neuer Stand eines Ereignisses mit Manöverwerten. Zählt nicht als „korrigiert“. */
  Daten.prototype.manoeverSchreiben = function (id, werte) {
    var self = this;
    return this.ereignisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      var neu = Object.assign({}, x.aktuell.werte, werte, { manoever: true });
      var eintrag = neuerVerlaufEintrag('ereignis', id, x.aktuell.nr + 1, neu, x.aktuell.id, self.jetzt());
      eintrag.quelle = 'aktion';
      return self.speicher.mehrereSpeichern([{ tabelle: 'verlaeufe', objekt: eintrag }]).then(function () { return { ok: true, id: id, werte: neu }; });
    });
  };

  /* Direkt nach dem Antippen: Was von selbst geschieht (Kurs und Fahrt, Segelzustand, Zwischenfall, Skipper, Rudergänger).
   * messung: { kurs (Grad oder null), geschwindigkeit (m/s oder null) }. Nachgetragene Einträge bekommen keine Messwerte.
   * Ergebnis: { ok, manoever, endeArt, laeuft, seite (Fragen nötig), bedingungen, mob, zusammenstellung } */
  Daten.prototype.manoeverStarten = function (id, messung) {
    var self = this, m = messung || {};
    return this.ereignisLaden(id).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieses Ereignis wurde nicht gefunden.' } };
      var art = x.arten.filter(function (a) { return a.objekt.id === x.aktuell.werte.artId; })[0];
      var z = art ? MM.Baukasten.zusammenstellung(art.aktuell.werte) : { fragen: [], wirkungen: [] };
      var S = MM.Segeln, erg = { ok: true, id: id, manoever: S.istManoever(z), zusammenstellung: z, seite: S.brauchtSeite(z), endeArt: S.endeArt(z), laeuft: false,
        bedingungen: z.wirkungen.indexOf('bedingungen') >= 0, mob: z.wirkungen.indexOf('mob') >= 0, name: x.art ? x.art.name : 'Ereignis' };
      if (!erg.manoever) return erg;
      var nachtrag = x.aktuell.werte.nachgetragen === 'ja';
      /* Nachgetragen: auch kein Wetter von jetzt */
      if (nachtrag) erg.bedingungen = false;
      return self.aktivitaetLaden(x.ereignis.aktivitaetId).then(function (a) {
        var w = {};
        if (a && !nachtrag) {
          if (a.verantwortlichJetzt) w.skipperName = a.verantwortlichJetzt.name;
          if (a.rudergaengerJetzt) w.ruderName = a.rudergaengerJetzt.name;
        }
        if (S.segelWirkung(z)) w.segelWirkung = S.segelWirkung(z);
        if (z.wirkungen.indexOf('zwischenfall') >= 0) w.zwischenfall = true;
        if (/\(Übung\)/.test(erg.name)) w.uebung = 'uebung';
        if (erg.endeArt && !nachtrag) {
          w.endeArt = erg.endeArt;
          if (typeof m.kurs === 'number') w.kursVor = Math.round(m.kurs) % 360;
          if (typeof m.geschwindigkeit === 'number') w.geschwVor = Math.round(m.geschwindigkeit * 100) / 100;
          if (erg.endeArt !== 'sofort') { w.endeStatus = 'laeuft'; w.startMs = new Date(self.jetzt()).getTime(); erg.laeuft = true; erg.startMs = w.startMs; if (erg.mob) w.mob = true; erg.kursVor = typeof w.kursVor === 'number' ? w.kursVor : null; erg.geschwVor = typeof w.geschwVor === 'number' ? w.geschwVor : null; }
        }
        return self.manoeverSchreiben(id, w).then(function () { return erg; });
      });
    });
  };

  /* Ende eines laufenden Manövers. e: { status ('erkannt' | 'hand' | 'nicht erkannt' | 'abgebrochen'), kursNach, geschwNach, drehwinkel, dauerS } */
  Daten.prototype.manoeverBeenden = function (id, e) {
    var self = this;
    return this.ereignisLaden(id).then(function (x) {
      if (!x || x.aktuell.werte.endeStatus !== 'laeuft') return { ok: false };
      var w = { endeStatus: e.status };
      ['kursNach', 'geschwNach', 'drehwinkel', 'dauerS'].forEach(function (k) { if (typeof e[k] === 'number') w[k] = e[k]; });
      return self.manoeverSchreiben(id, w);
    });
  };

  /* Wetter, Wind, Welle und Luftdruck an der Position festschreiben (Open-Meteo). Ohne Netz oder Position bleibt es leer. */
  Daten.prototype.manoeverBedingungen = function (id, position) {
    var self = this;
    if (!position || typeof position.breite !== 'number' || typeof position.laenge !== 'number') return Promise.resolve({ ok: false });
    var sek = Math.round(new Date(self.jetzt()).getTime() / 1000);
    function holen(url) { return self.holeJson(url).then(function (x) { return x; }, function () { return null; }); }
    var url = MM.Karte.wetterJetztUrl(position.breite, position.laenge, 'kn').replace('&hourly=', '&hourly=pressure_msl,');
    return Promise.all([holen(url), holen(MM.Karte.meerJetztUrl(position.breite, position.laenge))]).then(function (r) {
      if (!r[0] && !r[1]) return { ok: false, offline: true };
      var wetter = r[0] ? MM.Routen.wetterZurZeit(r[0], sek) : null, meer = r[1] ? MM.Routen.meerZurZeit(r[1], sek) : null, druck = null;
      var hh = r[0] && r[0].hourly;
      if (hh && Array.isArray(hh.pressure_msl) && Array.isArray(hh.time)) {
        var best = -1;
        hh.time.forEach(function (t, i) { if (best < 0 || Math.abs(t - sek) < Math.abs(hh.time[best] - sek)) best = i; });
        if (best >= 0 && typeof hh.pressure_msl[best] === 'number' && Math.abs(hh.time[best] - sek) <= 5400) druck = hh.pressure_msl[best];
      }
      var text = MM.Segeln.bedingungenText(wetter, meer, druck);
      if (!text) return { ok: false };
      var werte = { wetterText: text };
      if (wetter && typeof wetter.wind === 'number') werte.wetterWindKn = wetter.wind;
      if (wetter && typeof wetter.windRichtung === 'number') werte.wetterWindAus = wetter.windRichtung;
      return self.manoeverSchreiben(id, werte).then(function () { return { ok: true, text: text }; });
    });
  };

  Daten.prototype.segelEinstellungen = function () {
    return this.einstellungLesen(MM.Segeln.DOKUMENT).then(function (d) { return MM.Segeln.einstellungen(d); });
  };
  Daten.prototype.segelEinstellungenSetzen = function (roh) {
    var werte = MM.Segeln.einstellungen(roh);
    return this.einstellungSchreiben(Object.assign({ id: MM.Segeln.DOKUMENT }, werte)).then(function () { return { ok: true, werte: werte }; });
  };

  /* Die Segel eines Fahrzeugs: [{ id, name, stufen }] */
  Daten.prototype.segelListe = function (fahrzeugId) {
    return this.komponentenListe(fahrzeugId).then(function (liste) {
      return MM.Komponenten.aktive(liste).filter(function (x) { return !x.komponente.parentId && x.komponente.art === 'segel' && !x.aktuell.werte.ausgebautAm; })
        .map(function (x) { return { id: x.komponente.id, name: x.aktuell.werte.bezeichnung, stufen: MM.Segeln.reffstufen(x.aktuell.werte.merkmale) }; });
    });
  };

  /* Zustand und Stunden je Segel aus allen Logbüchern des Fahrzeugs: { Kennung: { zustand, seitMs, reffstufe, stunden } } */
  Daten.prototype.segelStand = function (fahrzeugId) {
    var self = this;
    return Promise.all([this.aktivitaetenListe(), this.speicher.alle('verlaeufe')]).then(function (r) {
      var meine = r[0].filter(function (a) { return a.aktuell.werte.fahrzeugId === fahrzeugId && a.aktuell.werte.status !== 'storniert'; });
      return Promise.all(meine.map(function (a) { return self.speicher.wo('ereignisse', 'aktivitaetId', a.objekt.id); })).then(function (listen) {
        var alle = [].concat.apply([], listen), eintraege = [];
        neuesteStaende(alle, r[1], 'ereignis').forEach(function (e) {
          var w = e.aktuell.werte;
          if (w.ausgeblendet === 'ja' || !w.segelWirkung || !w.segelIds || !w.datum) return;
          var wirkung = w.segelWirkung === 'gesetzt' && w.reffstufe && w.reffstufe !== 'ganz offen' ? 'gerefft' : w.segelWirkung;
          eintraege.push({ ms: new Date(w.datum + 'T' + (w.zeit || '00:00')).getTime(), wirkung: wirkung, segelIds: w.segelIds, reffstufe: w.reffstufe || null });
        });
        return MM.Segeln.segelStand(eintraege);
      });
    });
  };

  function manoeverArtAnlegen(self, m, knoten) {
    return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: m.name, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(knoten), fragen: m.fragen.slice(), wirkungen: m.wirkungen.slice() });
  }
  /* Die mitgelieferten Manöver einmal anlegen (Segelboote). Vorhandene Arten bleiben; nur „Segel setzen“ und „Segel bergen“ ohne jede Einstellung
     bekommen die neuen Fragen und Wirkungen. Danach ändert die App nichts mehr daran. */
  Daten.prototype.segelArtenSichern = function () {
    var self = this;
    return this.einstellungLesen('segelarten').then(function (dok) {
      if (dok && dok.angelegt) return { ok: true, neu: 0 };
      return self.ereignisartenListe().then(function (liste) {
        var nach = {};
        liste.forEach(function (x) { nach[x.aktuell.werte.bezeichnung.toLowerCase()] = x; });
        var neu = 0;
        return MM.Segeln.MANOEVER.reduce(function (kette, m) {
          return kette.then(function () {
            var x = nach[m.name.toLowerCase()];
            if (!x) { neu++; return manoeverArtAnlegen(self, m, ['segelboot']); }
            var w = x.aktuell.werte;
            if ((m.name === 'Segel setzen' || m.name === 'Segel bergen') && w.fragen === undefined && w.wirkungen === undefined && !w.aktion) {
              return self.mitVerlaufAendern('ereignisart', x.objekt.id, x, Object.assign({}, w, { fragen: m.fragen.slice(), wirkungen: m.wirkungen.slice() }), EREIGNISART_FELDER);
            }
            return null;
          });
        }, Promise.resolve()).then(function () { return self.einstellungSchreiben({ id: 'segelarten', angelegt: true }); }).then(function () { return { ok: true, neu: neu }; });
      });
    });
  };

  /* „Person über Bord“ (alle Wasserfahrzeuge): ein Druck, ohne Rückfragen. Der Eintrag wird nie durch den Status gesperrt. */
  Daten.prototype.personUeberBord = function (aktivitaetId, roh) {
    var self = this;
    roh = roh || {};
    return this.heutigerTag(aktivitaetId).then(function (t) {
      if (!t.ok) return t;
      return self.ereignisartenListe().then(function (arten) {
        var da = arten.filter(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase() === MM.Segeln.MOB_NAME.toLowerCase(); })[0];
        return da ? { id: da.objekt.id } : manoeverArtAnlegen(self, MM.Segeln.MOB, ['wasser']);
      }).then(function (art) {
        return self.ereignisSchnell(aktivitaetId, MM.Segeln.MOB_NAME, { artId: art.id, position: roh.position || null });
      }).then(function (r) {
        if (!r.ok) return r;
        return self.manoeverStarten(r.id, roh).then(function () {
          var ms = new Date(self.jetzt()).getTime();
          return self.geraetKennung().then(function (geraet) {
            return self.manoeverSchreiben(r.id, { mob: true, endeArt: 'hand', endeStatus: 'laeuft', startMs: ms, mobStart: Object.assign({ ms: ms }, mobPosition(roh.position)), mobGeraet: geraet });
          });
        }).then(function () { return r; });
      });
    });
  };

  /* Warnungen aus der Antwort des Dienstes bereinigen (höchstens 30). */
  function planWarnungen(liste) {
    return (Array.isArray(liste) ? liste : []).slice(0, 30).map(function (w) {
      return { code: String(w.code || '').slice(0, 60), stufe: w.stufe === 'kritisch' ? 'kritisch' : 'hinweis', titel: String(w.titel || '').slice(0, 160), grund: String(w.grund || '').slice(0, 200),
        ort: w.ort && typeof w.ort.breite === 'number' && typeof w.ort.laenge === 'number' ? { breite: w.ort.breite, laenge: w.ort.laenge } : null };
    });
  }

  /*
   * Route planen (seit 2.0.88, Schritt 2.0.88): Start, Zwischenziele und Ziel der Aktivität und die Maße und Gewichte des Fahrzeugs gehen an den Konto-Dienst (Stufe und Zählung),
   * von dort an HERE (Straßenfahrzeuge). Die Antwort wird als Route der Aktivität gespeichert (wie eine eingelesene GPX-Datei), mit den Warnungen. Wirft nie.
   * Ergebnis: { ok, id, name, punkte, laengeKm, dauerMin, warnungen, kontingent } oder { ok: false, fehler: { allgemein }, art }.
   */
  Daten.prototype.routePlanen = function (aktivitaetId) {
    var self = this;
    return this.routeAnsicht(aktivitaetId).then(function (ra) {
      if (!ra.ok) return ra;
      if (ra.aktivitaet.storniert) return routeFehler('Diese Aktivität ist storniert. Stelle sie zuerst wieder her.');
      var p = ra.planung;
      if (!p.moeglich) return routeFehler(p.grund || 'Für dieses Fahrzeug gibt es keine Routenplanung.');
      var q = MM.Routen.planungAnfrage(p.start, p.ziel, p.via, p.werte, p.maxVia);
      if (!q.ok) return routeFehler((p.fehler && p.fehler.length ? p.fehler : q.fehler).join(' '));
      return self.rcGeraet().then(function (d) {
        if (!(d.kontoToken && d.kontoEmail)) return { ok: false, fehler: { allgemein: 'Die Routenplanung läuft über dein MobiMory-Konto (ab Stufe Mittel). Melde dich zuerst an.' }, art: 'anmeldung' };
        return self.kontoSenden('POST', '/route/planen', q.anfrage).then(function (r) {
          if (!r.ok) return { ok: false, fehler: { allgemein: r.fehler }, art: r.status === 402 ? 'kontingent' : (r.status === 401 ? 'anmeldung' : (r.status === 404 ? 'keine-route' : 'netz')) };
          var e = r.json && r.json.route;
          if (!e || !Array.isArray(e.punkte) || e.punkte.length < 2) return { ok: false, fehler: { allgemein: 'Die Antwort des Dienstes war nicht lesbar. Es wurde nichts gespeichert.' }, art: 'dienst' };
          var name = ((p.start.name || 'Start') + ' – ' + (p.ziel.name || 'Ziel')).slice(0, 120);
          var punkte = e.punkte.map(function (x, i) { return { breite: x.breite, laenge: x.laenge, name: i === 0 ? (p.start.name || null) : (i === e.punkte.length - 1 ? (p.ziel.name || null) : null) }; });
          var warn = planWarnungen(e.warnungen);
          return self.routeImportieren(aktivitaetId, MM.Routen.gpx(name, punkte), 'Planung.gpx', { quelle: 'here', warnungen: warn, geplantAm: self.jetzt(), dauerMin: typeof e.dauerMin === 'number' ? e.dauerMin : null, fehlendeAngaben: q.fehlend }).then(function (x) {
            if (!x.ok) return x;
            return { ok: true, id: x.id, name: x.name, punkte: x.punkte, laengeKm: typeof e.laengeKm === 'number' ? e.laengeKm : x.laengeKm, dauerMin: e.dauerMin || null, warnungen: warn, fehlend: q.fehlend, kontingent: r.json.kontingent || null };
          });
        });
      });
    });
  };

  /* Die Route als GPX-Datei: { ok, name (Dateiname), text }. */
  Daten.prototype.routeGpx = function (id) {
    return this.routeLaden(id).then(function (x) {
      if (!x) return routeFehler('Diese Route wurde nicht gefunden.');
      var name = x.aktuell.werte.bezeichnung;
      return { ok: true, name: (name.replace(/[^A-Za-z0-9ÄÖÜäöüß _-]+/g, '').trim().replace(/\s+/g, '-') || 'Route') + '.gpx', text: MM.Routen.gpx(name, x.objekt.punkte) };
    });
  };

  /* ---------- Tagesroute (seit 2.0.90) ----------
   * Je Tag (Etappe) eine eigene geplante Route, getrennt von der Route der Aktivität (Tabelle „routen“ bleibt unberührt). Sie liegt als Dokument
   * „tagroute-<abschnittId>“ in „einstellungen“ (in der Sicherung enthalten): { id, abschnittId, aktivitaetId, datum, startOrtId, zielOrtId, startName, zielName,
   * punkte, laengeKm, dauerMin, warnungen, geplantAm, fehlendeAngaben }. Eine neue Planung ersetzt die frühere desselben Tages. Jede Planung zählt 1 Route.
   * Start und Ziel kommen vom Tag (MM.Etappen.tagesOrte), Maße und Gewichte vom Fahrzeug. */
  function tagRouteDokId(abschnittId) { return 'tagroute-' + abschnittId; }

  /* Zwischenziele eines Tages (seit 2.0.123): bis zu 10, in der Reihenfolge der Fahrt. Sie stehen als Liste von Orten (viaOrtIds) im selben Dokument wie die Tagesroute
     und bleiben dort, auch wenn der Tag neu geplant wird. planViaOrtIds ist die Liste, mit der die gespeicherte Route geplant wurde. */
  function tagViaListe(dok) { return dok && Array.isArray(dok.viaOrtIds) ? dok.viaOrtIds.filter(function (x) { return typeof x === 'string' && x; }) : []; }

  function tagRoutePlanung(b, x, fz, dok) {
    var to = tagOrte(b, x), welt = b.lb.aktivitaet.fahrzeug.welt;
    var start = to.startOrtId ? b.orte[to.startOrtId] || null : null, ziel = to.zielOrtId ? b.orte[to.zielOrtId] || null : null;
    var viaIds = tagViaListe(dok);
    /* Zur Wahl stehen alle sichtbaren Orte mit Position, die Orte der Gesamtplanung der Reise zuerst. */
    var planIds = [b.lb.aktivitaet.aktuell.werte.startOrtId].concat(b.lb.aktivitaet.aktuell.werte.zwischenzielIds || [], [b.lb.aktivitaet.aktuell.werte.zielOrtId]).filter(Boolean);
    var viaOptionen = b.orteListe.filter(function (o) { return o.breite !== null && o.laenge !== null && (!o.ausgeblendet || viaIds.indexOf(o.id) >= 0); })
      .sort(function (p, q) { var a = planIds.indexOf(p.id) >= 0 ? 0 : 1, c = planIds.indexOf(q.id) >= 0 ? 0 : 1; return a - c || String(p.name).localeCompare(String(q.name), 'de'); })
      .map(function (o) { return { wert: o.id, label: o.name }; });
    var via = viaIds.map(function (id) { return b.orte[id] || { id: id, name: 'unbekannter Ort', breite: null, laenge: null }; });
    if (welt === 'luft') return { moeglich: false, welt: welt, grund: null, navi: null, start: start, ziel: ziel };
    if (welt === 'wasser') {
      var nz = ziel && MM.Routen.navigationsLink(ziel.breite, ziel.laenge, ziel.name);
      return { moeglich: false, welt: welt, start: start, ziel: ziel, grund: 'Für Wasserfahrzeuge plant MobiMory keine Route. Du kannst das Ziel dieses Tages in einer Navigations-App deines Geräts öffnen.', navi: nz ? { link: nz, name: ziel.name } : null };
    }
    var fehler = [];
    if (!start) fehler.push('Für diesen Tag ist kein Startort bekannt. Trage ihn bei „Tag ändern“ ein.');
    else if (start.breite === null || start.laenge === null) fehler.push('Der Startort „' + start.name + '“ hat keine Position. Trage sie beim Ort ein.');
    if (!ziel) fehler.push('Für diesen Tag ist kein Zielort bekannt. Trage ihn bei „Tag ändern“ ein.');
    else if (ziel.breite === null || ziel.laenge === null) fehler.push('Der Zielort „' + ziel.name + '“ hat keine Position. Trage sie beim Ort ein.');
    if (start && ziel && start.id === ziel.id && !via.length) fehler.push('Start und Ziel dieses Tages sind derselbe Ort. Mit mindestens einem Zwischenziel geht auch eine Rundfahrt.');
    via.forEach(function (o) { if (o.breite === null || o.laenge === null) fehler.push('Das Zwischenziel „' + o.name + '“ hat keine Position. Trage sie beim Ort ein.'); });
    if (via.length > MM.Routen.MAX_ZWISCHENZIELE_TAG) fehler.push('Für einen Tag sind höchstens ' + MM.Routen.MAX_ZWISCHENZIELE_TAG + ' Zwischenziele möglich.');
    var werte = fz ? fz.aktuell.werte : {}, q = MM.Routen.planungAnfrage(fehler.length ? null : start, fehler.length ? null : ziel, fehler.length ? [] : via, werte, MM.Routen.MAX_ZWISCHENZIELE_TAG);
    return { moeglich: true, welt: welt, start: start, ziel: ziel, via: via, viaOptionen: viaOptionen, maxVia: MM.Routen.MAX_ZWISCHENZIELE_TAG, werte: werte, fehlend: q.fehlend, fehler: fehler, anfrage: fehler.length ? null : q.anfrage, navi: null };
  }

  /* Alles für die Planung eines Tages: { ok, tagId, aktivitaetId, welt, storniert, planung, route } mit route = gespeicherte Tagesroute oder null
     (route.veraltet: Start oder Ziel des Tages sind seither andere). */
  Daten.prototype.tagRouteAnsicht = function (abschnittId) {
    var self = this;
    return this.abschnittLaden(abschnittId).then(function (t) {
      if (!t) return routeFehler('Dieser Tag wurde nicht gefunden.');
      var aid = t.aktivitaet.aktivitaet.id;
      return Promise.all([etappenBasis(self, aid), self.einstellungLesen(tagRouteDokId(abschnittId)), self.fahrzeugLaden(t.aktivitaet.fahrzeug.id)]).then(function (r) {
        var b = r[0], x = b ? b.lb.abschnitte.filter(function (y) { return y.objekt.id === abschnittId; })[0] : null;
        if (!x) return routeFehler('Dieser Tag wurde nicht gefunden.');
        var dok = r[1], pl = tagRoutePlanung(b, x, r[2], dok), to = tagOrte(b, x), route = null;
        if (dok && Array.isArray(dok.punkte) && dok.punkte.length >= 2) {
          route = { punkte: dok.punkte, laengeKm: dok.laengeKm, dauerMin: dok.dauerMin || null, warnungen: dok.warnungen || [], am: dok.geplantAm || null, fehlend: dok.fehlendeAngaben || [],
            startName: dok.startName || null, zielName: dok.zielName || null,
            viaNamen: Array.isArray(dok.viaNamen) ? dok.viaNamen : [],
            veraltet: dok.startOrtId !== to.startOrtId || dok.zielOrtId !== to.zielOrtId || JSON.stringify(Array.isArray(dok.planViaOrtIds) ? dok.planViaOrtIds : []) !== JSON.stringify(tagViaListe(dok)) };
        }
        return { ok: true, tagId: abschnittId, aktivitaetId: aid, welt: b.lb.aktivitaet.fahrzeug.welt, datum: x.aktuell.werte.datum,
          storniert: b.lb.aktivitaet.aktuell.werte.status === 'storniert', ausgeblendet: !!x.ausgeblendet, planung: pl, route: route };
      });
    });
  };

  /* Den Tag planen (zählt 1 Route im Konto-Dienst). Wirft nie. Ergebnis: { ok, laengeKm, dauerMin, warnungen, fehlend, kontingent } oder { ok: false, fehler, art }. */
  Daten.prototype.tagRoutePlanen = function (abschnittId) {
    var self = this;
    return this.tagRouteAnsicht(abschnittId).then(function (ra) {
      if (!ra.ok) return ra;
      if (ra.storniert) return routeFehler('Diese Aktivität ist storniert. Stelle sie zuerst wieder her.');
      if (ra.ausgeblendet) return routeFehler('Dieser Tag ist ausgeblendet.');
      var p = ra.planung;
      if (!p.moeglich) return routeFehler(p.grund || 'Für dieses Fahrzeug gibt es keine Routenplanung.');
      if (p.fehler.length) return routeFehler(p.fehler.join(' '));
      return self.rcGeraet().then(function (d) {
        if (!(d.kontoToken && d.kontoEmail)) return { ok: false, fehler: { allgemein: 'Die Routenplanung läuft über dein MobiMory-Konto (ab Stufe Mittel). Melde dich zuerst an.' }, art: 'anmeldung' };
        return self.kontoSenden('POST', '/route/planen', p.anfrage).then(function (r) {
          if (!r.ok) return { ok: false, fehler: { allgemein: r.fehler }, art: r.status === 402 ? 'kontingent' : (r.status === 401 ? 'anmeldung' : (r.status === 404 ? 'keine-route' : 'netz')) };
          var e = r.json && r.json.route;
          if (!e || !Array.isArray(e.punkte) || e.punkte.length < 2) return { ok: false, fehler: { allgemein: 'Die Antwort des Dienstes war nicht lesbar. Es wurde nichts gespeichert.' }, art: 'dienst' };
          var punkte = e.punkte.map(function (x, i) { return { breite: x.breite, laenge: x.laenge, name: i === 0 ? (p.start.name || null) : (i === e.punkte.length - 1 ? (p.ziel.name || null) : null) }; });
          var auf = MM.Routen.punkteAufbereiten(punkte), laenge = typeof e.laengeKm === 'number' ? e.laengeKm : auf.laengeKm;
          punkte = auf.punkte.map(function (q) { return { breite: q.breite, laenge: q.laenge, name: q.name || null }; });
          var warn = planWarnungen(e.warnungen);
          var dok = { id: tagRouteDokId(abschnittId), abschnittId: abschnittId, aktivitaetId: ra.aktivitaetId, datum: ra.datum || null, startOrtId: p.start.id, zielOrtId: p.ziel.id,
            startName: p.start.name || null, zielName: p.ziel.name || null, punkte: punkte, laengeKm: laenge, dauerMin: typeof e.dauerMin === 'number' ? e.dauerMin : null,
            warnungen: warn, geplantAm: self.jetzt(), fehlendeAngaben: p.fehlend,
            viaOrtIds: p.via.map(function (o) { return o.id; }), planViaOrtIds: p.via.map(function (o) { return o.id; }), viaNamen: p.via.map(function (o) { return o.name; }) };
          return self.einstellungSchreiben(dok).then(function () {
            return { ok: true, laengeKm: laenge, dauerMin: dok.dauerMin, warnungen: warn, fehlend: p.fehlend, kontingent: r.json.kontingent || null };
          });
        });
      });
    }).catch(function (err) { return { ok: false, fehler: { allgemein: 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler') }, art: 'netz' }; });
  };

  /* Die Zwischenziele eines Tages festlegen (seit 2.0.123): Liste von Orten in der Reihenfolge der Fahrt, bis zu 10. Sie liegen im Dokument der Tagesroute; eine schon geplante
     Route bleibt erhalten und gilt dann als veraltet, bis der Tag neu geplant wird. Wirft nie. Ergebnis: { ok, anzahl } oder { ok: false, fehler: { allgemein } }. */
  Daten.prototype.tagViaSetzen = function (abschnittId, ortIds) {
    var self = this;
    return this.tagRouteAnsicht(abschnittId).then(function (ra) {
      if (!ra.ok) return ra;
      if (ra.storniert) return routeFehler('Diese Aktivität ist storniert. Stelle sie zuerst wieder her.');
      if (ra.ausgeblendet) return routeFehler('Dieser Tag ist ausgeblendet.');
      if (!ra.planung.moeglich) return routeFehler('Für dieses Fahrzeug gibt es keine Routenplanung.');
      var ids = [], gesehen = {};
      (Array.isArray(ortIds) ? ortIds : []).forEach(function (id) { if (typeof id === 'string' && id && !gesehen[id]) { gesehen[id] = true; ids.push(id); } });
      if (ids.length > MM.Routen.MAX_ZWISCHENZIELE_TAG) return routeFehler('Für einen Tag sind höchstens ' + MM.Routen.MAX_ZWISCHENZIELE_TAG + ' Zwischenziele möglich.');
      var erlaubt = {}; ra.planung.viaOptionen.forEach(function (o) { erlaubt[o.wert] = true; });
      if (ids.some(function (id) { return !erlaubt[id]; })) return routeFehler('Ein gewählter Ort steht nicht (mehr) zur Wahl. Er braucht eine Position und darf nicht ausgeblendet sein.');
      return self.einstellungLesen(tagRouteDokId(abschnittId)).then(function (dok) {
        var neu = dok ? Object.assign({}, dok) : { id: tagRouteDokId(abschnittId), abschnittId: abschnittId, aktivitaetId: ra.aktivitaetId, datum: ra.datum || null };
        neu.viaOrtIds = ids;
        return self.einstellungSchreiben(neu).then(function () { return { ok: true, anzahl: ids.length }; });
      });
    }).catch(function (err) { return { ok: false, fehler: { allgemein: 'Das hat nicht geklappt: ' + (err && err.message ? err.message : 'unbekannter Fehler') } }; });
  };

  /* Die Tagesroute als GPX-Datei: { ok, name (Dateiname), text }. */
  Daten.prototype.tagRouteGpx = function (abschnittId) {
    return this.einstellungLesen(tagRouteDokId(abschnittId)).then(function (dok) {
      if (!dok || !Array.isArray(dok.punkte) || dok.punkte.length < 2) return routeFehler('Für diesen Tag gibt es noch keine geplante Route.');
      var name = ((dok.startName || 'Start') + ' – ' + (dok.zielName || 'Ziel') + (dok.datum ? ' ' + dok.datum : '')).slice(0, 120);
      return { ok: true, name: (name.replace(/[^A-Za-z0-9ÄÖÜäöüß _-]+/g, '').trim().replace(/\s+/g, '-') || 'Tagesroute') + '.gpx', text: MM.Routen.gpx(name, dok.punkte) };
    });
  };

  /* Die Karte eines Tages: gleiche Form wie kartenDaten, aber nur Tagesroute, Start, Ziel und Warnstellen (kein Wetter, kein gefahrener Weg). */
  Daten.prototype.tagKartenDaten = function (abschnittId) {
    var self = this;
    return this.tagRouteAnsicht(abschnittId).then(function (ra) {
      if (!ra.ok) return ra;
      return self.logbuchLaden(ra.aktivitaetId).then(function (lb) {
        var p = ra.planung;
        function planOrt(rolle, o) { return o && o.breite !== null && o.laenge !== null ? { rolle: rolle, name: o.name, breite: o.breite, laenge: o.laenge } : null; }
        /* Seit 2.0.123: die Zwischenziele des Tages in ihrer Reihenfolge, nummeriert (wie bei der Aktivität). */
        var viaOrte = (p.via || []).map(function (o, i) { var po = planOrt('zwischen', o); if (po) po.nr = i + 1; return po; });
        var planOrte = [planOrt('start', p.start), planOrt('ziel', p.ziel)].concat(viaOrte).filter(Boolean);
        var rt = ra.route;
        var route = rt ? { id: abschnittId, name: (rt.startName || 'Start') + ' – ' + (rt.zielName || 'Ziel'), punkte: rt.punkte, laengeKm: rt.laengeKm, kmh: null, abfahrtMs: null,
          warnstellen: rt.warnungen.filter(function (w) { return w.ort && typeof w.ort.breite === 'number' && typeof w.ort.laenge === 'number'; }) } : null;
        return { ok: true, nurRoute: true, aktivitaet: { id: ra.aktivitaetId, name: lb.aktivitaet.aktuell.werte.bezeichnung, welt: ra.welt, fahrzeugId: lb.aktivitaet.fahrzeug.id, fahrzeugName: lb.aktivitaet.fahrzeug.name,
          status: lb.aktivitaet.status, storniert: ra.storniert }, tagDatum: ra.datum, route: route, planOrte: planOrte, wetter: null, ereignisse: [], weg: null, veraltet: !!(rt && rt.veraltet) };
      });
    });
  };

  /* Die Länge der Route wird die geplante Strecke der Aktivität (damit rechnet die App Zähler-Fristen). Eine Handeingabe bleibt im Verlauf der Aktivität. */
  Daten.prototype.routeAlsGeplanteStrecke = function (aktivitaetId, routeId) {
    var self = this;
    return this.speicher.holen('routen', routeId).then(function (o) {
      if (!o || o.aktivitaetId !== aktivitaetId) return routeFehler('Diese Route wurde nicht gefunden.');
      var km = Math.round(o.laengeKm * 10) / 10;
      return aktivitaetNeuerStand(self, aktivitaetId, function (w) {
        if (w.status === 'storniert') return { fehler: { allgemein: 'Diese Aktivität ist storniert.' } };
        w.geplanteStrecke = km; w.sperreUebergangenAm = null;
        return { werte: w };
      }).then(function (r) { return r.ok ? Object.assign({}, r, { km: km }) : r; });
    });
  };

  /* ---- Wetter und Tide holen und auswerten ---- */
  function wetterDokId(routeId) { return 'wetter-' + routeId; }
  var WETTER_FENSTER_S = 8 * 3600, MEER_FENSTER_S = 16 * 3600;
  var MAX_VORLAUF_TAGE = 15;

  /*
   * Wetter (und bei Wasserfahrzeugen Wellen und Wasserstand) für die Messpunkte der Route zur geplanten Ankunftszeit holen und im Gerät merken.
   * Braucht Route, Geschwindigkeit und Abfahrt (Datum und Uhrzeit). Ohne Netz bleibt der alte Stand erhalten.
   * Ergebnis: { ok, punkte, ohneWetter, ohneMeer, abgerufenAm } oder { ok: false, fehler, offline? }
   */
  Daten.prototype.wetterAbrufen = function (aktivitaetId) {
    var self = this;
    return this.routeAnsicht(aktivitaetId).then(function (a) {
      if (!a.ok) return a;
      var r = a.route;
      if (!r) return routeFehler('Es gibt noch keine Route. Lies zuerst eine Routendatei ein.');
      if (!r.fahrplan.ok) return routeFehler('Bitte zuerst die Reisegeschwindigkeit der Route eintragen.', 'geschwindigkeit');
      var abfahrt = routeAbfahrt(r.werte);
      if (!abfahrt) return routeFehler('Bitte Datum und Uhrzeit der Abfahrt eintragen. Das Wetter gilt für die Ankunftszeit an jedem Punkt.', 'abfahrtDatum');
      var abfahrtMs = MM.Routen.zeitMs(abfahrt), jetztMs = new Date(self.jetzt()).getTime();
      if (abfahrtMs > jetztMs + MAX_VORLAUF_TAGE * 86400000) return routeFehler('Eine Prognose gibt es nur für die nächsten ' + MAX_VORLAUF_TAGE + ' Tage. Versuche es später noch einmal.', 'abfahrtDatum');
      if (abfahrtMs + r.fahrplan.dauerMin * 60000 < jetztMs - 86400000) return routeFehler('Die Fahrt liegt mehr als einen Tag in der Vergangenheit. Dafür holt die App kein Wetter.', 'abfahrtDatum');
      var mitMeer = a.aktivitaet.welt === 'wasser', punkte = r.messpunkte;
      var kmh = MM.Routen.geschwindigkeitKmh(r.werte.geschwindigkeit, r.werte.einheit), einheit = mitMeer ? 'kn' : 'kmh';
      return wetterAntwortenHolen(self, punkte, abfahrtMs, mitMeer, einheit).then(function (antworten) {
        var ohneWetter = antworten.filter(function (x) { return !x.wetter; }).length;
        if (ohneWetter === punkte.length) {
          return { ok: false, offline: true, fehler: { allgemein: 'Das Wetter konnte nicht geholt werden. Vermutlich ist gerade kein Netz da. Ein früher geholter Stand bleibt erhalten.' } };
        }
        var dok = { id: wetterDokId(r.id), routeId: r.id, aktivitaetId: aktivitaetId, abgerufenAm: self.jetzt(), abfahrt: abfahrt, geschwindigkeitKmh: kmh, laengeKm: r.laengeKm,
          mitMeer: mitMeer, windEinheit: einheit, regel: r.wetterRegel, messpunkte: punkte, antworten: antworten };
        return self.einstellungSchreiben(dok).then(function () {
          return { ok: true, punkte: punkte.length, ohneWetter: ohneWetter, ohneMeer: mitMeer ? antworten.filter(function (x) { return !x.meer; }).length : 0, abgerufenAm: dok.abgerufenAm };
        });
      });
    });
  };

  /*
   * Wetter (bei Wasserfahrzeugen auch Wellen und Wasserstand) für alle Punkte holen, immer vier gleichzeitig (das schont das Netz).
   * Ein Punkt ohne Antwort bleibt leer. Gemeinsam für die Route und für die Etappen (seit 2.0.43).
   * Ergebnis: Liste { wetter, meer } in der Reihenfolge der Punkte.
   */
  function wetterAntwortenHolen(self, punkte, abfahrtMs, mitMeer, einheit) {
    function holen(url) { return Promise.resolve().then(function () { return self.holeJson(url); }).catch(function () { return null; }); }
    var antworten = new Array(punkte.length), pos = 0;
    function gruppe() {
      if (pos >= punkte.length) return Promise.resolve();
      var von = pos, bis = Math.min(punkte.length, pos + 4);
      pos = bis;
      var arbeit = [];
      for (var i = von; i < bis; i++) {
        (function (i) {
          var p = punkte[i];
          arbeit.push(Promise.all([holen(MM.Routen.wetterUrl(p.breite, p.laenge, einheit)), mitMeer ? holen(MM.Routen.marineUrl(p.breite, p.laenge)) : Promise.resolve(null)]).then(function (x) {
            var eta = Math.round((abfahrtMs + p.minuten * 60000) / 1000);
            antworten[i] = { wetter: x[0] ? MM.Routen.kuerzen(x[0], eta - WETTER_FENSTER_S, eta + WETTER_FENSTER_S) : null, meer: x[1] ? MM.Routen.kuerzen(x[1], eta - MEER_FENSTER_S, eta + MEER_FENSTER_S) : null };
          }));
        })(i);
      }
      return Promise.all(arbeit).then(gruppe);
    }
    return gruppe().then(function () { return antworten; });
  }

  /* Das zuletzt geholte Wetter ist noch für diese Route, Geschwindigkeit und Abfahrt geholt worden? */
  function wetterAktuell(dok, route) {
    if (!dok || !route) return false;
    var kmh = MM.Routen.geschwindigkeitKmh(route.werte.geschwindigkeit, route.werte.einheit);
    return dok.routeId === route.id && dok.abfahrt === routeAbfahrt(route.werte) && kmh !== null && Math.abs(dok.geschwindigkeitKmh - kmh) < 0.001 && dok.laengeKm === route.laengeKm && sameRegel(dok.regel, route.wetterRegel);
  }
  /* Die Regel der Wetterpunkte beim Holen und jetzt. Ein älteres Dokument ohne Regel wurde mit der festen Regel von 2.0.34 geholt, seine Punkte passen nicht mehr. */
  function sameRegel(a, b) { if (!a) return false; if (!b) return false; return a.art === b.art && a.abstand === b.abstand && a.einheit === b.einheit; }

  var VERGLEICH_VERSATZ = [-120, -60, 0, 60, 120];

  /*
   * Das zuletzt geholte Wetter ausgewertet. versatzMin verschiebt die Abfahrt (früher oder später), die Antworten bleiben dieselben.
   * Ergebnis: { ok: false, keins: true } oder { ok, abgerufenAm, abfahrt, mitMeer, windEinheit, aktuell (passt zu den Angaben der Route), zeilen, schwerste, vergleich: [{ versatzMin, schwerste }] }
   */
  Daten.prototype.wetterStand = function (aktivitaetId, versatzMin) {
    var self = this;
    return this.routeAnsicht(aktivitaetId).then(function (a) {
      if (!a.ok) return a;
      if (!a.route) return { ok: false, keins: true };
      return self.einstellungLesen(wetterDokId(a.route.id)).then(function (dok) {
        if (!dok) return { ok: false, keins: true };
        var abfahrtMs = MM.Routen.zeitMs(dok.abfahrt), v = versatzMin || 0;
        var aus = MM.Routen.auswerten(dok.messpunkte, abfahrtMs, v, dok.antworten, dok.mitMeer);
        return { ok: true, abgerufenAm: dok.abgerufenAm, abfahrt: dok.abfahrt, mitMeer: dok.mitMeer, windEinheit: dok.windEinheit, aktuell: wetterAktuell(dok, a.route), versatzMin: v,
          zeilen: aus.zeilen, schwerste: aus.schwerste,
          vergleich: VERGLEICH_VERSATZ.map(function (m) { return { versatzMin: m, schwerste: MM.Routen.auswerten(dok.messpunkte, abfahrtMs, m, dok.antworten, dok.mitMeer).schwerste }; }) };
      });
    });
  };

  /* ---- Kilometer über GPS ---- */
  function gpsSpurId(aktivitaetId) { return 'gpsspur-' + aktivitaetId; }
  /* Die aufgezeichnete GPS-Strecke dieser Aktivität auf diesem Gerät: { km, letzter, punkte, verworfen }. */
  Daten.prototype.gpsSpurLesen = function (aktivitaetId) {
    return this.einstellungLesen(gpsSpurId(aktivitaetId)).then(function (d) { return d && d.spur ? d.spur : MM.Routen.spurNeu(); });
  };
  /* Seit 2.0.120 wird beim Schreiben mit dem gespeicherten Stand zusammengeführt (zwei Geräte fahren dieselbe Strecke); nur das Zurücksetzen nach der Übernahme
     in den Zähler ersetzt (opt.ersetzen). */
  Daten.prototype.gpsSpurSpeichern = function (aktivitaetId, spur, opt) {
    var self = this;
    if (opt && opt.ersetzen) return this.einstellungSchreiben({ id: gpsSpurId(aktivitaetId), aktivitaetId: aktivitaetId, spur: spur, geaendertAm: this.jetzt() });
    return this.einstellungLesen(gpsSpurId(aktivitaetId)).then(function (d) {
      var neu = d && d.spur ? MM.Routen.spurZusammen(d.spur, spur) : spur;
      return self.einstellungSchreiben({ id: gpsSpurId(aktivitaetId), aktivitaetId: aktivitaetId, spur: neu, geaendertAm: self.jetzt() });
    });
  };
  /*
   * Die GPS-Strecke in den Streckenzähler des Fahrzeugs übernehmen: neuer Stand = letzter Stand + Strecke, Quelle „gps“.
   * Der Nutzer löst das selbst aus, die App schreibt nie von allein. Hat der Zähler noch keinen Stand, trägt der Nutzer ihn zuerst von Hand ein (Handeingabe hat Vorrang).
   */
  Daten.prototype.gpsStreckeUebernehmen = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.gpsSpurLesen(aktivitaetId), this.aktivitaetLaden(aktivitaetId)]).then(function (r) {
      var spur = r[0], a = r[1];
      if (!a) return routeFehler('Diese Aktivität wurde nicht gefunden.');
      if (!(spur.km >= 0.05)) return routeFehler('Es ist noch keine GPS-Strecke aufgezeichnet.');
      return self.streckenZaehler(a.fahrzeug.id).then(function (z) {
        if (!z) return routeFehler('Am Fahrzeug gibt es keinen Zähler für die Strecke. Lege ihn am Fahrzeug unter „Zähler“ an und trage den Tachostand ein.');
        if (!z.stand) return routeFehler('Der Streckenzähler hat noch keinen Stand. Trage zuerst den Tachostand von Hand ein, dann kann die GPS-Strecke dazukommen.');
        return self.speicher.wo('zaehlerstaende', 'zaehlerId', z.id).then(function (staende) {
          var letzter = neuesterStand(staende), km = Math.round(spur.km * 10) / 10, neu = Math.round((letzter.wert + spur.km) * 10) / 10;
          var e = { id: neueId('zs'), zaehlerId: z.id, nr: letzter.nr + 1, wert: neu, datum: self.heute(),
            notiz: 'GPS-Strecke ' + String(km).replace('.', ',') + ' km (Luftlinie von Punkt zu Punkt, ' + spur.punkte + ' Punkte) in „' + a.aktuell.werte.bezeichnung + '“', quelle: 'gps', erstelltAm: self.jetzt() };
          /* ab: ab der nächsten vollen Minute zählt die Spur neu (so lässt sich eine ältere Fassung vom anderen Gerät beim Zusammenführen ausschließen) */
          var zurueck = { km: 0, letzter: spur.letzter, punkte: 0, verworfen: 0, luecken: 0, mi: {}, ab: (Math.floor(Date.now() / 60000) + 1) * 60000 };
          return self.speicher.speichern('zaehlerstaende', e).then(function () { return self.gpsSpurSpeichern(aktivitaetId, zurueck, { ersetzen: true }); }).then(function () {
            return { ok: true, km: km, stand: neu, einheit: z.einheit, zaehlerName: z.bezeichnung, spur: zurueck };
          });
        });
      });
    });
  };

  /* ---------- Geschwindigkeit aus dem GPS (seit 2.0.44) ----------
   * Der Zustand der laufenden Zählung liegt je Aktivität auf diesem Gerät als Dokument „gpsfahrt-<aktivitaetId>“ in „einstellungen“
   * (wie die GPS-Strecke, in der Sicherung enthalten). Gespeichert wird im Logbuch als Eintrag „Geschwindigkeit“:
   * beim Tagesabschluss (Ø fahrend, Ø Tag, Strecke, Fahrzeit, Gesamtzeit) und im Rhythmus der automatischen Einträge (derselbe wie beim Wetter). */
  function gpsFahrtId(aktivitaetId) { return 'gpsfahrt-' + aktivitaetId; }
  Daten.prototype.gpsFahrtLesen = function (aktivitaetId) {
    return this.einstellungLesen(gpsFahrtId(aktivitaetId)).then(function (d) { return d && d.fahrt ? d.fahrt : MM.Fahrt.neu(); });
  };
  Daten.prototype.gpsFahrtSpeichern = function (aktivitaetId, fahrt) {
    var self = this;
    return this.einstellungLesen(gpsFahrtId(aktivitaetId)).then(function (d) {
      var neu = d && d.fahrt ? MM.Fahrt.zusammen(d.fahrt, fahrt) : fahrt;
      return self.einstellungSchreiben({ id: gpsFahrtId(aktivitaetId), aktivitaetId: aktivitaetId, fahrt: neu, geaendertAm: self.jetzt() });
    });
  };

  /* Die Ereignisart „Geschwindigkeit“: vorhanden oder neu angelegt (gilt für alle Fahrzeugarten, ohne Status-Regel). Ergebnis: ihre Kennung. */
  Daten.prototype.geschwindigkeitsArtSichern = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var da = liste.filter(function (x) { return MM.Logbuch.istGeschwindigkeitsArt(x.aktuell.werte.bezeichnung); })[0];
      if (da) return da.objekt.id;
      return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: MM.Logbuch.GESCHWINDIGKEIT_ART, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(['alle']) })
        .then(function (r) { return r.id; });
    });
  };

  /*
   * Einen Eintrag „Geschwindigkeit“ ins Logbuch schreiben. opt: { fahrt: Zustand (live vom Gerät), art: 'rhythmus' | 'tag', position: frische GPS-Position oder null }.
   * Ohne begonnenen Tag (noch keine Bewegung) wird nichts geschrieben. Ergebnis: { ok, text, zeit } oder { ok: false, fehler }.
   */
  Daten.prototype.fahrtEintragen = function (aktivitaetId, opt) {
    var self = this, o = opt || {};
    var fahrt = o.fahrt || null;
    if (!fahrt || fahrt.startMs === null || fahrt.startMs === undefined) return Promise.resolve({ ok: false, fehler: { allgemein: 'Es gibt noch keine Bewegung, also noch keine Geschwindigkeit zu speichern.' } });
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return { ok: false, fehler: { allgemein: 'Diese Aktivität wurde nicht gefunden.' } };
      if (a.aktuell.werte.status === 'storniert') return { ok: false, fehler: { allgemein: 'Diese Aktivität ist storniert. Stelle sie zuerst wieder her.' } };
      var welt = a.fahrzeug.welt;
      var w = MM.Fahrt.werte(fahrt, Date.now());
      var text = MM.Fahrt.eintragText(w, welt, o.art === 'tag' ? 'tag' : 'rhythmus');
      return self.geschwindigkeitsArtSichern().then(function (artId) {
        return self.ereignisSchnell(aktivitaetId, MM.Logbuch.GESCHWINDIGKEIT_ART, { artId: artId, text: text, position: o.position || null, quelle: 'app' });
      }).then(function (r) { if (r.ok) r.text = text; return r; });
    });
  };

  /*
   * Tagesabschluss: Die Werte des Tages werden einmal als Eintrag „Geschwindigkeit“ ins Logbuch geschrieben, danach bleibt der Wert dieses Tages
   * auf dem Gerät stehen und die nächste Bewegung beginnt eine neue Zählung. Ohne laufende oder gerade abgeschlossene Zählung dieses Tages geschieht nichts.
   * Der Zustand wird hier aus dem Gerätespeicher gelesen (die Oberfläche sichert ihn vorher).
   * Ergebnis: { ok: true, geschrieben: Boolean, text? } oder { ok: false, fehler }.
   */
  Daten.prototype.fahrtTagAbschliessen = function (abschnittId, opt) {
    var self = this, o = opt || {};
    return this.abschnittLaden(abschnittId).then(function (x) {
      if (!x) return { ok: false, fehler: { allgemein: 'Dieser Tag wurde nicht gefunden.' } };
      var aktId = x.aktivitaet.aktivitaet.id, tagDatum = x.abschnitt.aktuell.werte.datum, welt = x.aktivitaet.fahrzeug.welt;
      return self.gpsFahrtLesen(aktId).then(function (f) {
        if (f.startMs === null || f.startMs === undefined || f.abgeschlossen || f.tagDatum !== tagDatum) return { ok: true, geschrieben: false };
        var jetztMs = Date.now();
        var zu = MM.Fahrt.abschliessen(f, jetztMs);
        var w = MM.Fahrt.werte(zu, jetztMs);
        var text = MM.Fahrt.eintragText(w, welt, 'tag');
        return self.geschwindigkeitsArtSichern().then(function (artId) {
          if (tagDatum === self.heute()) return self.ereignisSchnell(aktId, MM.Logbuch.GESCHWINDIGKEIT_ART, { artId: artId, text: text, position: o.position || null, quelle: 'app' });
          /* Ein früherer Tag: nachgetragen mit dem Datum des Tages */
          return self.ereignisAnlegen(abschnittId, { artId: artId, datum: tagDatum, zeit: '23:59', text: text }, { nachtragen: true, quelle: 'app', zeitHerkunft: 'app' });
        }).then(function (r) {
          if (!r.ok) return r;
          return self.gpsFahrtSpeichern(aktId, zu).then(function () { return { ok: true, geschrieben: true, text: text }; });
        });
      });
    });
  };

  /* ---------- Karte, Weg und Wetter jetzt (seit 2.0.34, Schritt 9b) ----------
   * Weg: der tatsächlich gefahrene Weg dieser Aktivität auf diesem Gerät, Dokument „gpsweg-<aktivitaetId>“ in „einstellungen“
   *      (getrennt von der GPS-Strecke in Kilometern, die beim Übernehmen in den Zähler auf 0 geht).
   * Wetter jetzt: Wetter und bei Wasserfahrzeugen Wellen und Wasserstand am aktuellen Standort, gespeichert als Logbuch-Eintrag „Wetter“
   *      mit Datum, Uhrzeit und Position. Ohne Netz wird nichts gespeichert.
   * Offline-Karte: welche Kacheln zu einer Aktivität gehören, steht als Dokument „karte-<aktivitaetId>“ in „einstellungen“;
   *      die Kacheln selbst liegen im Cache des Browsers (js/kartenablage.js). */
  function wegDokId(aktivitaetId) { return 'gpsweg-' + aktivitaetId; }
  function karteDokId(aktivitaetId) { return 'karte-' + aktivitaetId; }

  Daten.prototype.gpsWegLesen = function (aktivitaetId) {
    return this.einstellungLesen(wegDokId(aktivitaetId)).then(function (d) { return d && d.weg ? d.weg : MM.Karte.wegNeu(); });
  };
  Daten.prototype.gpsWegSpeichern = function (aktivitaetId, weg) {
    var self = this;
    return this.einstellungLesen(wegDokId(aktivitaetId)).then(function (d) {
      var neu = d && d.weg ? MM.Karte.wegZusammen(d.weg, weg) : weg;
      return self.einstellungSchreiben({ id: wegDokId(aktivitaetId), aktivitaetId: aktivitaetId, weg: neu, geaendertAm: self.jetzt() });
    });
  };

  /* Rhythmus der automatischen Wetterabfrage in Minuten (0 = aus), nur für dieses Gerät. */
  Daten.prototype.geraetWetterRhythmus = function () {
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      var n = MM.Karte.rhythmusGueltig(dok && dok.wetterRhythmus);
      return { minuten: n === null ? 0 : n, gesetzt: n !== null };
    });
  };
  Daten.prototype.geraetWetterRhythmusSetzen = function (wert) {
    var self = this, n = MM.Karte.rhythmusGueltig(wert);
    if (n === null) return Promise.resolve({ ok: false, fehler: { rhythmus: 'Bitte einen Rhythmus aus der Liste wählen.' } });
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (dok) {
      return self.speicher.speichern('einstellungen', Object.assign({}, dok || {}, { id: GERAET_DOK, wetterRhythmus: n }));
    }).then(function () { return { ok: true, minuten: n }; });
  };

  /* Cockpit-Wechsel (seit 2.0.104): die Einstellung gehört zur Aktivität, Dokument „wechsel-<aktivitaetId>“ in „einstellungen“.
     Ohne Dokument gilt die Grundeinstellung (aus, 30 Sekunden, die Seiten des Cockpits). Siehe js/cockpitwechsel.js. */
  Daten.prototype.cockpitWechsel = function (aktivitaetId) {
    return this.speicher.holen('einstellungen', 'wechsel-' + aktivitaetId).then(function (dok) { return MM.CockpitWechsel.lesen(dok); });
  };
  Daten.prototype.cockpitWechselSetzen = function (aktivitaetId, werte) {
    var self = this, p = MM.CockpitWechsel.ausFormular(werte);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var e = p.einstellung;
    return this.speicher.speichern('einstellungen', { id: 'wechsel-' + aktivitaetId, aktivitaetId: aktivitaetId, an: e.an, takt: e.takt, ansichten: e.ansichten, geaendertAm: self.jetzt() })
      .then(function () { return { ok: true, einstellung: e }; });
  };

  /* Die Ereignisarten „Wetter“ und „Karte“ (seit 2.0.35): beim ersten Öffnen des Cockpits einmal angelegt, falls es sie nicht gibt
     (gelten für alle Fahrzeugarten). Danach nie wieder: Wer sie löscht oder ausblendet, behält das so. Ein Dokument „werkzeugarten“ merkt es sich. */
  Daten.prototype.werkzeugArtenEinmalSichern = function () {
    var self = this;
    return this.speicher.holen('einstellungen', 'werkzeugarten').then(function (dok) {
      if (dok && dok.angelegt) return { ok: true, neu: 0 };
      return self.ereignisartenListe().then(function (liste) {
        var vorhanden = liste.map(function (x) { return x.aktuell.werte.bezeichnung.toLowerCase(); });
        var fehlt = [MM.Karte.WETTER_ART, MM.Karte.KARTE_ART].filter(function (n) { return vorhanden.indexOf(n.toLowerCase()) < 0; });
        return fehlt.reduce(function (kette, n) {
          return kette.then(function () {
            return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: n, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(['alle']) });
          });
        }, Promise.resolve()).then(function () {
          return self.speicher.speichern('einstellungen', { id: 'werkzeugarten', angelegt: true });
        }).then(function () { return { ok: true, neu: fehlt.length }; });
      });
    });
  };

  /* Die Ereignisart „Wetter“: vorhanden oder neu angelegt (gilt für alle Fahrzeugarten, ohne Status-Regel). Ergebnis: ihre Kennung. */
  Daten.prototype.wetterArtSichern = function () {
    var self = this;
    return this.ereignisartenListe().then(function (liste) {
      var da = liste.filter(function (x) { return MM.Karte.istWetterArt(x.aktuell.werte.bezeichnung); })[0];
      if (da) return da.objekt.id;
      return self.mitVerlaufAnlegen('ereignisarten', 'ereignisart', 'ea', { bezeichnung: MM.Karte.WETTER_ART, ausgeblendet: 'nein', zuordnung: MM.Logbuch.zuordnungFuerKnoten(['alle']) })
        .then(function (r) { return r.id; });
    });
  };

  /*
   * Wetter jetzt: holt das Wetter für die Position (Open-Meteo, Modellwert der aktuellen Stunde) und legt den Logbuch-Eintrag „Wetter“ an.
   * position: { breite, laenge, genauigkeit } (frische GPS-Position). opt.automatisch: Text kennzeichnet die automatische Abfrage.
   * Ergebnis: { ok, text, zeit, datum, wetter, meer } oder { ok: false, fehler, offline? }. Bei einem Fehler wird nichts gespeichert.
   */
  Daten.prototype.wetterJetzt = function (aktivitaetId, position, opt) {
    var self = this, o = opt || {};
    if (!position || typeof position.breite !== 'number' || typeof position.laenge !== 'number') {
      return Promise.resolve(routeFehler('Für das Wetter braucht die App deine Position, und es gibt gerade keine GPS-Position. Warte einen Moment und versuche es noch einmal.'));
    }
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a) return routeFehler('Diese Aktivität wurde nicht gefunden.');
      if (a.aktuell.werte.status === 'storniert') return routeFehler('Diese Aktivität ist storniert. Stelle sie zuerst wieder her.');
      var mitMeer = a.fahrzeug.welt === 'wasser', einheit = mitMeer ? 'kn' : 'kmh';
      var sek = Math.round(new Date(self.jetzt()).getTime() / 1000);
      function holen(url) { return self.holeJson(url).then(function (x) { return x; }, function () { return null; }); }
      return Promise.all([holen(MM.Karte.wetterJetztUrl(position.breite, position.laenge, einheit)), mitMeer ? holen(MM.Karte.meerJetztUrl(position.breite, position.laenge)) : Promise.resolve(null)]).then(function (x) {
        if (!x[0] && !x[1]) return { ok: false, offline: true, fehler: { allgemein: 'Das Wetter konnte nicht geholt werden. Vermutlich ist gerade kein Netz da. Es wurde nichts gespeichert.' } };
        var w = x[0] ? MM.Routen.wetterZurZeit(x[0], sek) : null, m = x[1] ? MM.Routen.meerZurZeit(x[1], sek) : null;
        var text = MM.Karte.wetterJetztText(w, m, einheit, !!o.automatisch);
        if (!text) return { ok: false, fehler: { allgemein: 'Für diese Stelle und diese Stunde liefert das Wettermodell keine Werte. Es wurde nichts gespeichert.' } };
        return self.wetterArtSichern().then(function (artId) {
          return self.ereignisSchnell(aktivitaetId, MM.Karte.WETTER_ART, { artId: artId, text: text, position: position, quelle: o.automatisch ? 'app' : 'nutzer' });
        }).then(function (r) {
          if (r.ok) { r.text = text; r.wetter = w; r.meer = m; r.windEinheit = einheit; }
          return r;
        });
      });
    });
  };

  /*
   * Alles für die Karte einer Aktivität: die geplante Route, Start, Ziel und Zwischenziele (Orte mit Position), die Wetterpunkte der Route
   * (der zuletzt geholte Stand, gerechnet mit versatzMin), die Wetter-Einträge und weitere Einträge mit Position aus dem Logbuch, und der gefahrene Weg.
   * Ergebnis: { ok, aktivitaet, route: { punkte, laengeKm, kmh, abfahrtMs, name } | null, planOrte, wetter, ereignisse, weg } oder { ok: false, fehler }.
   */
  Daten.prototype.kartenDaten = function (aktivitaetId, versatzMin) {
    var self = this;
    return Promise.all([this.routeAnsicht(aktivitaetId), this.logbuchLaden(aktivitaetId), this.gpsWegLesen(aktivitaetId), this.orteListe(), this.wetterStand(aktivitaetId, versatzMin || 0)]).then(function (r) {
      var ra = r[0], lb = r[1], ws = r[4];
      if (!ra.ok || !lb) return routeFehler('Diese Aktivität wurde nicht gefunden.');
      var a = lb.aktivitaet, w = a.aktuell.werte;
      var orte = {};
      r[3].forEach(function (x) { orte[x.objekt.id] = x.aktuell.werte; });
      function planOrt(rolle, id) {
        var ow = id ? orte[id] : null;
        if (!ow || typeof ow.positionBreite !== 'number' || typeof ow.positionLaenge !== 'number') return null;
        return { rolle: rolle, name: ow.bezeichnung, breite: ow.positionBreite, laenge: ow.positionLaenge };
      }
      var planOrte = [planOrt('start', w.startOrtId), planOrt('ziel', w.zielOrtId)].concat((w.zwischenzielIds || []).map(function (id, i) { var po = planOrt('zwischen', id); if (po) po.nr = i + 1; return po; })).filter(Boolean);
      var route = null;
      if (ra.route) {
        var rw = ra.route.werte;
        route = { id: ra.route.id, name: rw.bezeichnung || ra.route.dateiName || 'Route', punkte: ra.route.punkte, laengeKm: ra.route.laengeKm, wechselpunkte: ra.route.wechselpunkte && ra.route.wechselpunkte.moeglich ? ra.route.wechselpunkte.liste : [],
          kmh: MM.Routen.geschwindigkeitKmh(rw.geschwindigkeit, rw.einheit), abfahrtMs: routeAbfahrt(rw) ? MM.Routen.zeitMs(routeAbfahrt(rw)) : null,
          /* Warnstellen einer geplanten Route (seit 2.0.89): nur die mit Position */
          warnstellen: ra.route.geplant ? (ra.route.geplant.warnungen || []).filter(function (x) { return x.ort && typeof x.ort.breite === 'number' && typeof x.ort.laenge === 'number'; }) : [] };
      }
      var ereignisse = [];
      lb.abschnitte.forEach(function (t) {
        if (t.ausgeblendet) return;
        t.ereignisse.forEach(function (e) {
          if (e.ausgeblendet || typeof e.breite !== 'number' || typeof e.laenge !== 'number') return;
          /* Wechsel mit Position (seit 2.0.115): Skipper- und Rudergängerwechsel erscheinen mit eigenem Zeichen (SW, RW) */
          if (e.art === 'wechsel' || e.art === 'ruder') {
            ereignisse.push({ id: e.id, artName: MM.KartenEreignisse.wechselName(e.art, a.fahrzeug.welt), datum: e.datum, zeit: e.zeit, text: e.text, breite: e.breite, laenge: e.laenge, ortName: null, positionQuelle: e.positionQuelle || null, istWetter: false });
            return;
          }
          if (e.art !== 'ereignis') return;
          ereignisse.push({ id: e.id, artName: e.artName, datum: e.datum, zeit: e.zeit, text: e.text, breite: e.breite, laenge: e.laenge, ortName: e.ortName, positionQuelle: e.positionQuelle || null, istWetter: MM.Karte.istWetterArt(e.artName) });
        });
      });
      return self.kartenWahl(aktivitaetId).then(function (wahl) { return { ok: true, aktivitaet: { id: aktivitaetId, name: w.bezeichnung, welt: a.fahrzeug.welt, fahrzeugId: a.fahrzeug.id, fahrzeugName: a.fahrzeug.name, status: a.status, storniert: w.status === 'storniert' },
        route: route, planOrte: planOrte, ereignisse: ereignisse, weg: r[2], wahl: wahl,
        wetter: ws && ws.ok ? { abgerufenAm: ws.abgerufenAm, aktuell: ws.aktuell, windEinheit: ws.windEinheit, mitMeer: ws.mitMeer, zeilen: ws.zeilen, versatzMin: ws.versatzMin } : null }; });
    });
  };

  /* ---------- Ereignisse auf der Karte (seit 2.0.108): zweistufige Auswahl ----------
   * Generell: Dokument „kartenwahl“ in „einstellungen“. Je Aktivität: „kartenwahl-<aktivitaetId>“. Gespeichert wird, was abgewählt ist.
   * Ergebnis von kartenWahl: { generell, aktivitaet (oder null), wirksam, eigene } */
  Daten.prototype.kartenWahl = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.einstellungLesen(MM.KartenEreignisse.DOK_GENERELL), aktivitaetId ? this.einstellungLesen(MM.KartenEreignisse.dokJeAktivitaet(aktivitaetId)) : Promise.resolve(null)]).then(function (r) {
      var g = MM.KartenEreignisse.lesen(r[0]), a = r[1] && r[1].eigene === false ? null : MM.KartenEreignisse.lesen(r[1]);
      return { generell: g || MM.KartenEreignisse.standard(), aktivitaet: a, eigene: !!a, wirksam: MM.KartenEreignisse.wirksam(g, a) };
    });
  };
  /* Für diese Aktivität speichern. */
  Daten.prototype.kartenWahlAktivitaet = function (aktivitaetId, wahl) {
    return this.einstellungSchreiben(MM.KartenEreignisse.dokument(MM.KartenEreignisse.dokJeAktivitaet(aktivitaetId), wahl, aktivitaetId, this.jetzt())).then(function () { return { ok: true }; });
  };
  /* Als Vorauswahl für alle Aktivitäten speichern. Die eigene Auswahl dieser Aktivität fällt weg (sie gilt dann wie die generelle). */
  Daten.prototype.kartenWahlGenerell = function (wahl, aktivitaetId) {
    var self = this;
    return this.einstellungSchreiben(MM.KartenEreignisse.dokument(MM.KartenEreignisse.DOK_GENERELL, wahl, null, this.jetzt())).then(function () {
      /* Der Speicher hat keine Löschfunktion: Das Dokument der Aktivität wird als „keine eigene Auswahl“ markiert. */
      return aktivitaetId ? self.einstellungSchreiben({ id: MM.KartenEreignisse.dokJeAktivitaet(aktivitaetId), aktivitaetId: aktivitaetId, eigene: false, aus: [], seezeichen: null, geaendertAm: self.jetzt() }) : null;
    }).then(function () { return { ok: true }; });
  };

  /* ---------- Karten im Reisetagebuch (seit 2.0.108) ----------
   * Die Karte der ganzen Reise und je Tagesetappe wird als Bild (JPEG) bei der Reise gespeichert und im Reisebuch gezeigt. Ablage: Tabelle „ereignisdateien“
   * mit der Kennung „karte:<aktivitaetId>:<reise | tagId>“ (so ist es in der Sicherung enthalten, ohne Umstellung der Datenbank). Ein neues Bild ersetzt das alte. */
  function kartenbildKennung(aktivitaetId, tagId) { return 'karte:' + aktivitaetId + ':' + (tagId || 'reise'); }
  function kartenbildId(aktivitaetId, tagId) { return 'kb-' + aktivitaetId + '-' + (tagId || 'reise'); }

  /* Was auf das Bild kommt: Route, Weg, Orte und die gewählten Ereignisse mit Position. tagId: nur dieser Tag, sonst die ganze Reise.
   * Ergebnis: { ok, titel, route, wegStuecke, planOrte, marker, see, auto, hand } oder { ok: false, grund } */
  Daten.prototype.kartenbildDaten = function (aktivitaetId, tagId) {
    var self = this;
    return Promise.all([this.kartenDaten(aktivitaetId, 0), tagId ? this.logbuchLaden(aktivitaetId) : Promise.resolve(null), tagId ? this.tagKartenDaten(tagId).catch(function () { return null; }) : Promise.resolve(null)]).then(function (r) {
      var kd = r[0], lb = r[1], tk = r[2];
      if (!kd.ok) return { ok: false, grund: 'Diese Reise wurde nicht gefunden.' };
      var wahl = kd.wahl ? kd.wahl.wirksam : MM.KartenEreignisse.standard();
      var route = null, planOrte = kd.planOrte, weg = kd.weg, ereignisse = kd.ereignisse, titel = kd.aktivitaet.name;
      if (tagId) {
        var tag = lb && lb.abschnitte.filter(function (t) { return t.objekt.id === tagId; })[0];
        if (!tag) return { ok: false, grund: 'Dieser Tag wurde nicht gefunden.' };
        var datum = tag.aktuell.werte.datum, m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(datum || '');
        var von = m ? new Date(+m[1], +m[2] - 1, +m[3], 0, 0, 0, 0).getTime() : NaN, bis = von + 86400000;
        ereignisse = ereignisse.filter(function (e) { return e.datum === datum; });
        weg = weg && weg.punkte ? { punkte: weg.punkte.filter(function (p) { return p[2] * 1000 >= von && p[2] * 1000 < bis; }), verworfen: 0 } : null;
        route = tk && tk.ok && tk.route && tk.route.punkte && tk.route.punkte.length >= 2 ? tk.route.punkte.map(function (x) { return [x.breite, x.laenge]; }) : null;
        planOrte = tk && tk.ok ? tk.planOrte : [];
        titel = 'Tag ' + (lb.abschnitte.filter(function (t) { return !t.ausgeblendet; }).map(function (t) { return t.objekt.id; }).indexOf(tagId) + 1 || '') + ', ' + MM.Hilfen.datum(datum);
      } else if (kd.route && kd.route.punkte.length >= 2) route = kd.route.punkte.map(function (x) { return [x.breite, x.laenge]; });
      var sichtbar = MM.KartenEreignisse.filtern(ereignisse, wahl);
      var auto = 0, hand = 0;
      var marker = sichtbar.map(function (e) {
        if (e.positionQuelle === 'gps') auto++; else hand++;
        var a = MM.KartenEreignisse.aussehen(e.artName);
        return { breite: e.breite, laenge: e.laenge, symbol: a.symbol, farbe: a.farbe };
      });
      return { ok: true, titel: titel, route: route, wegStuecke: MM.Karte.wegStuecke(weg), planOrte: planOrte || [], marker: marker, see: kd.aktivitaet.welt === 'wasser' && !!wahl.seezeichen, auto: auto, hand: hand, welt: kd.aktivitaet.welt };
    });
  };

  /* Ein Bild ablegen (ersetzt das frühere). bytes: JPEG. meta: { hatHintergrund, beschriftung }. */
  Daten.prototype.kartenbildSichern = function (aktivitaetId, tagId, bytes, meta) {
    var inhalt = typeof Blob === 'function' ? new Blob([bytes], { type: 'image/jpeg' }) : bytes;
    meta = meta || {};
    return this.speicher.speichern('ereignisdateien', { id: kartenbildId(aktivitaetId, tagId), ereignisId: kartenbildKennung(aktivitaetId, tagId), name: 'Karte.jpg', mime: 'image/jpeg', groesse: bytes.length,
      inhalt: inhalt, erstelltAm: this.jetzt(), hatHintergrund: !!meta.hatHintergrund, beschriftung: meta.beschriftung || '', kartenbild: true }).then(function () { return { ok: true }; });
  };
  /* Das gespeicherte Bild oder null: { bytes, hatHintergrund, beschriftung, erstelltAm }. */
  Daten.prototype.kartenbildHolen = function (aktivitaetId, tagId) {
    return this.speicher.holen('ereignisdateien', kartenbildId(aktivitaetId, tagId)).then(function (d) {
      if (!d || !d.inhalt) return null;
      var roh = d.inhalt.arrayBuffer ? d.inhalt.arrayBuffer() : Promise.resolve(d.inhalt);
      return Promise.resolve(roh).then(function (ab) { return { bytes: ab instanceof Uint8Array ? ab : new Uint8Array(ab), hatHintergrund: !!d.hatHintergrund, beschriftung: d.beschriftung || '', erstelltAm: d.erstelltAm || null }; });
    });
  };
  /*
   * Das Bild neu zeichnen und ablegen. opt: { ablage, leinwand, bildLaden, hole, breite, hoehe } (im Browser die Standardwerte von MM.Kartenbild.browser).
   * Ergebnis: { ok, hatHintergrund, beschriftung, bytes } oder { ok: false, grund }. Ohne Punkte gibt es kein Bild („keine Karte an diesem Tag“).
   */
  Daten.prototype.kartenbildErzeugen = function (aktivitaetId, tagId, opt) {
    var self = this;
    opt = opt || {};
    if (!MM.Kartenbild) return Promise.resolve({ ok: false, grund: 'Das Zeichnen von Karten ist hier nicht verfügbar.' });
    var br = MM.Kartenbild.browser;
    return this.kartenbildDaten(aktivitaetId, tagId).then(function (kb) {
      if (!kb.ok) return kb;
      return MM.Kartenbild.erzeugen({ breite: opt.breite, hoehe: opt.hoehe, route: kb.route, wegStuecke: kb.wegStuecke, planOrte: kb.planOrte, marker: kb.marker, see: kb.see, titel: kb.titel,
        ablage: opt.ablage || null, hole: opt.hole || br.hole, leinwand: opt.leinwand || br.leinwand, bildLaden: opt.bildLaden || br.bildLaden }).then(function (res) {
        if (!res.ok) return res;
        var jetzt = self.jetztLokal();
        var text = 'Karte vom ' + MM.Hilfen.datum(jetzt.slice(0, 10)) + ', ' + jetzt.slice(11, 16) + ' Uhr. ' + (kb.auto + kb.hand ? 'Positionen der Ereignisse: ' + kb.auto + ' automatisch (GPS), ' + kb.hand + ' von Hand. ' : 'Keine Ereignisse mit Position. ')
          + (res.hatHintergrund ? res.quelle + '.' : 'Ohne Kartenhintergrund (kein Internet, keine Offline-Karte).') + ' Informationskarte, keine amtliche Karte.';
        return self.kartenbildSichern(aktivitaetId, tagId, res.bytes, { hatHintergrund: res.hatHintergrund, beschriftung: text }).then(function () {
          return { ok: true, hatHintergrund: res.hatHintergrund, beschriftung: text, bytes: res.bytes };
        });
      });
    });
  };
  /*
   * Die Karten für ein Reisebuch: das gespeicherte Bild, sonst wird es jetzt gezeichnet. neu: alle neu zeichnen. Ergebnis:
   * { reise: Bild | null, tage: { tagId: Bild | null }, ohneBild: Anzahl ohne Bild }. Bild: { bytes, hatHintergrund, beschriftung }. opt wie bei kartenbildErzeugen, dazu neu, reise, tageIds.
   */
  Daten.prototype.reisebuchKarten = function (aktivitaetId, opt) {
    var self = this;
    opt = opt || {};
    var aus = { reise: null, tage: {}, ohneBild: 0 };
    function eins(tagId) {
      return (opt.neu ? Promise.resolve(null) : self.kartenbildHolen(aktivitaetId, tagId)).then(function (b) {
        if (b) return b;
        return self.kartenbildErzeugen(aktivitaetId, tagId, opt).catch(function (e) { return { ok: false, grund: (e && e.message) || 'Das hat nicht geklappt.' }; });
      }).then(function (b) { return b && (b.bytes) && b.ok !== false ? b : null; });
    }
    var kette = Promise.resolve();
    if (opt.reise) kette = kette.then(function () { return eins(null); }).then(function (b) { aus.reise = b; if (!b) aus.ohneBild++; });
    (opt.tageIds || []).forEach(function (id) {
      kette = kette.then(function () { return eins(id); }).then(function (b) { aus.tage[id] = b; if (!b) aus.ohneBild++; });
    });
    return kette.then(function () { return aus; });
  };

  /* Die Punkte, für die eine Offline-Karte geholt wird: die Route, sonst Start, Ziel und Zwischenziele mit Position. */
  Daten.prototype.kartePunkte = function (aktivitaetId) {
    return this.kartenDaten(aktivitaetId, 0).then(function (kd) {
      if (!kd.ok) return { ok: false, fehler: kd.fehler, quelle: null, punkte: [] };
      if (kd.route && kd.route.punkte.length >= 2) return { ok: true, quelle: 'route', punkte: kd.route.punkte };
      if (kd.planOrte.length) return { ok: true, quelle: 'orte', punkte: kd.planOrte };
      return { ok: true, quelle: null, punkte: [] };
    });
  };

  /* Was würde eine Stufe der Offline-Karte holen? Siehe MM.Karte.planung. */
  Daten.prototype.kartePlanen = function (aktivitaetId, stufe) {
    return this.kartePunkte(aktivitaetId).then(function (p) {
      if (!p.ok) return { ok: false, grund: (p.fehler && p.fehler.allgemein) || 'Diese Aktivität wurde nicht gefunden.' };
      var pl = MM.Karte.planung(p.punkte, stufe);
      pl.quelle = p.quelle;
      return pl;
    });
  };

  /* Was ist für diese Aktivität schon im Gerät? { stufe, anzahl, bytes, geladenAm, keys } oder null. */
  Daten.prototype.karteInfo = function (aktivitaetId) {
    return this.einstellungLesen(karteDokId(aktivitaetId)).then(function (d) { return d && d.keys && d.keys.length ? d : null; });
  };

  /* Nach einem Abruf merken, welche Kacheln zu dieser Aktivität gehören (zusammen mit den früher geholten). keys: „z/x/y“, bytes: neu geholte Bytes. */
  Daten.prototype.karteMerken = function (aktivitaetId, stufe, keys, bytes) {
    var self = this;
    return this.karteInfo(aktivitaetId).then(function (alt) {
      var alle = {}, liste = [];
      ((alt && alt.keys) || []).concat(keys || []).forEach(function (k) { if (!alle[k]) { alle[k] = true; liste.push(k); } });
      var dok = { id: karteDokId(aktivitaetId), aktivitaetId: aktivitaetId, stufe: stufe, anzahl: liste.length, bytes: ((alt && alt.bytes) || 0) + (bytes || 0), geladenAm: self.jetzt(), keys: liste };
      return self.einstellungSchreiben(dok).then(function () { return { ok: true, anzahl: dok.anzahl, bytes: dok.bytes }; });
    });
  };

  /*
   * Die Offline-Karte dieser Aktivität freigeben: Das Dokument wird entfernt, zurück kommen die Kacheln, die keine andere Aktivität braucht
   * (die der Aufrufer dann aus dem Gerät löscht). Kacheln, die auch zu anderen Aktivitäten gehören, bleiben.
   */
  Daten.prototype.karteFreigeben = function (aktivitaetId) {
    var self = this;
    return this.speicher.alle('einstellungen').then(function (docs) {
      var meins = null, andere = {};
      docs.forEach(function (d) {
        if (!d.id || d.id.indexOf('karte-') !== 0 || !d.keys) return;
        if (d.id === karteDokId(aktivitaetId)) meins = d;
        else d.keys.forEach(function (k) { andere[k] = true; });
      });
      if (!meins) return { ok: true, keys: [] };
      var frei = meins.keys.filter(function (k) { return !andere[k]; });
      /* Der Speicher hat keine Löschfunktion (es wird nichts gelöscht): Das Dokument wird leer geschrieben. */
      return self.speicher.speichern('einstellungen', { id: meins.id, aktivitaetId: aktivitaetId, keys: [], anzahl: 0, bytes: 0, geladenAm: self.jetzt() }).then(function () { return { ok: true, keys: frei }; });
    });
  };

  /* ---------- Sicherung ---------- */
  var DATEI_TABELLEN = ['dateien', 'nachweisdateien', 'ereignisdateien'];
  var ZAEHL_TABELLEN = [['fahrzeuge', 'Fahrzeuge'], ['komponenten', 'Komponenten'], ['fristen', 'Fristen'], ['zaehler', 'Zähler'], ['personen', 'Personen'],
    ['tiere', 'Tiere'], ['nachweise', 'Nachweise'], ['aktivitaeten', 'Aktivitäten'], ['dokumente', 'Dokumente'],
    ['orte', 'Orte'], ['standorte', 'Standorte'], ['gebiete', 'Gebiete'], ['regeln', 'Regeln'],
    ['tagesabschnitte', 'Tagesabschnitte'], ['ereignisse', 'Ereignisse'], ['vorgaenge', 'Vorgänge'], ['adressen', 'Adressen'], ['kosten', 'Kostenposten'], ['besuche', 'Besuche'], ['kassenbuchungen', 'Kassenbuchungen'], ['routen', 'Routen'], ['reisechecks', 'Reisechecks']];

  function lokalesDatum(iso) {
    var d = new Date(iso);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate());
  }

  Daten.prototype.einstellungLesen = function (id) { return this.speicher.holen('einstellungen', id); };
  Daten.prototype.einstellungSchreiben = function (obj) {
    /* Neue GPS-Daten merken (seit 2.0.119): Sie gehen beim nächsten Seitenwechsel oder Ausblenden mit, nicht je Punkt. */
    if (obj && /^gps(spur|fahrt|weg|mob)-/.test(String(obj.id))) this.gpsGeaendert = true;
    return this.speicher.speichern('einstellungen', obj);
  };

  /* Wann wurde zuletzt gesichert, und wie oft soll erinnert werden? (0 = nie erinnern) */
  Daten.prototype.sicherungInfo = function () {
    return Promise.all([this.einstellungLesen('sicherung'), this.speicher.alle('fahrzeuge'), this.speicher.alle('personen'), this.speicher.alle('tiere')]).then(function (r) {
      var e = r[0] || {};
      return { letzte: e.letzteSicherung || null, erinnerungTage: e.erinnerungTage === undefined ? 30 : e.erinnerungTage, hatDaten: (r[1].length + r[2].length + r[3].length) > 0 };
    });
  };

  Daten.prototype.sicherungEinstellen = function (aenderung) {
    var self = this;
    return this.einstellungLesen('sicherung').then(function (alt) {
      return self.einstellungSchreiben(Object.assign({ id: 'sicherung', letzteSicherung: null, erinnerungTage: 30 }, alt || {}, aenderung));
    });
  };

  /* Soll die App an die Sicherung erinnern? Nur, wenn es Daten gibt und die Erinnerung nicht aus ist. */
  Daten.prototype.sicherungErinnerung = function () {
    var self = this;
    return this.sicherungInfo().then(function (i) {
      if (!i.hatDaten || !i.erinnerungTage) return { faellig: false };
      if (!i.letzte) return { faellig: true, grund: 'nie' };
      var tage = MM.Fristen.tageZwischen(lokalesDatum(i.letzte), self.heute());
      return tage >= i.erinnerungTage ? { faellig: true, grund: 'alt', tage: tage } : { faellig: false, tage: tage };
    });
  };

  /* Zahlen der Daten auf diesem Gerät, in derselben Form wie in einer Sicherung. */
  Daten.prototype.sicherungZahlen = function () {
    return this.speicher.alleTabellen().then(function (t) {
      var z = {};
      ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
      var dl = []; DATEI_TABELLEN.forEach(function (n) { dl = dl.concat(t[n] || []); });
      z.dateien = dl.length;
      z.dateiBytes = dl.reduce(function (s, d) { return s + (d.groesse || 0); }, 0);
      return z;
    });
  };

  /* Erzeugt die Sicherung. Gibt Bytes, Dateinamen und Zahlen zurück. */
  Daten.prototype.sicherungErzeugen = function (optionen) {
    var self = this;
    optionen = optionen || {};
    var mitDateien = !!optionen.mitDateien;
    return this.speicher.alleTabellen().then(function (alle) {
      var tabellen = {}, dateien = [], leer = 0;
      var kette = Promise.resolve();
      MM.Speicher.TABELLEN.forEach(function (name) {
        var liste = alle[name] || [];
        if (DATEI_TABELLEN.indexOf(name) >= 0) {
          if (!mitDateien) return;
          tabellen[name] = [];
          liste.forEach(function (rec) {
            kette = kette.then(function () {
              var kopie = Object.assign({}, rec);
              if (rec.inhalt && typeof rec.inhalt.arrayBuffer === 'function') {
                return rec.inhalt.arrayBuffer().then(function (buf) { kopie.inhalt = { $datei: dateien.length }; dateien.push(new Uint8Array(buf)); tabellen[name].push(kopie); });
              }
              leer++; kopie.inhalt = null; tabellen[name].push(kopie);
            });
          });
          return;
        }
        /* Die Einstellungen dieses Geräts (2.0.20) gehören nicht in die Sicherung. */
        tabellen[name] = name === 'einstellungen' ? liste.filter(function (e) { return e.id !== GERAET_DOK; }) : liste;
      });
      return kette.then(function () {
        var zaehlung = {}; Object.keys(tabellen).forEach(function (n) { zaehlung[n] = tabellen[n].length; });
        var kopf = { format: MM.Sicherung.FORMAT, app: MM.VERSION, dbVersion: MM.Speicher.DB_VERSION, erstelltAm: self.jetzt(), mitDateien: mitDateien, tabellen: tabellen, zaehlung: zaehlung };
        return MM.Sicherung.bauen(kopf, dateien, optionen.schluessel || '').then(function (bytes) {
          var z = {}; ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (tabellen[x[0]] || []).length; });
          var d = new Date(kopf.erstelltAm);
          function p(n) { return (n < 10 ? '0' : '') + n; }
          var name = 'MobiMory-Sicherung_' + d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '_' + p(d.getHours()) + '-' + p(d.getMinutes()) + '.mmsicherung';
          return { bytes: bytes, name: name, groesse: bytes.length, zahlen: z, dateien: dateien.length, ohneInhalt: leer, mitDateien: mitDateien, verschluesselt: !!optionen.schluessel, erstelltAm: kopf.erstelltAm };
        });
      });
    });
  };

  /* Prüft den Inhalt einer entpackten Sicherung. Wirft Fehler mit code und verständlichem Text. */
  function sicherungPruefen(gelesen) {
    function f(code, text) { var e = new Error(text); e.code = code; return e; }
    var k = gelesen.kopf;
    if (!k || typeof k !== 'object' || !k.tabellen || typeof k.tabellen !== 'object') throw f('beschaedigt', 'Die Datei ist beschädigt.');
    if (k.uebergabe) throw f('uebergabe', 'Das ist keine Sicherung, sondern eine Übergabedatei für ein einzelnes Fahrzeug. Sie ersetzt nichts. Lies sie unter „Fahrzeug übernehmen“ ein.');
    if (k.format !== MM.Sicherung.FORMAT) {
      throw f(k.format > MM.Sicherung.FORMAT ? 'neuer' : 'format', k.format > MM.Sicherung.FORMAT ? 'Diese Sicherung stammt aus einer neueren Version von MobiMory. Bitte zuerst die App aktualisieren.' : 'Das ist keine MobiMory-Sicherung.');
    }
    if (typeof k.dbVersion !== 'number' || k.dbVersion > MM.Speicher.DB_VERSION) throw f('neuer', 'Diese Sicherung stammt aus einer neueren Version von MobiMory (' + (k.app || '?') + '). Bitte zuerst die App aktualisieren.');
    var benutzt = {};
    Object.keys(k.tabellen).forEach(function (n) {
      if (MM.Speicher.TABELLEN.indexOf(n) < 0) throw f('beschaedigt', 'Die Sicherung enthält etwas Unbekanntes (' + n + ').');
      var liste = k.tabellen[n];
      if (!Array.isArray(liste)) throw f('beschaedigt', 'Die Datei ist beschädigt.');
      if (k.zaehlung && k.zaehlung[n] !== undefined && k.zaehlung[n] !== liste.length) throw f('beschaedigt', 'Die Datei ist beschädigt: Die Anzahl der Einträge stimmt nicht.');
      liste.forEach(function (o) {
        if (!o || typeof o !== 'object' || typeof o.id !== 'string' || !o.id) throw f('beschaedigt', 'Die Datei ist beschädigt: Ein Eintrag ist unvollständig.');
        if (DATEI_TABELLEN.indexOf(n) >= 0 && o.inhalt !== null && o.inhalt !== undefined) {
          var i = o.inhalt && o.inhalt.$datei;
          if (typeof i !== 'number' || i < 0 || i >= gelesen.dateien.length || benutzt[i]) throw f('beschaedigt', 'Die Datei ist beschädigt: Eine Datei fehlt.');
          benutzt[i] = true;
        }
      });
    });
    return true;
  }

  /* Entpackt und prüft eine Sicherung. Noch nichts wird verändert. */
  Daten.prototype.sicherungLesen = function (bytes, schluessel) {
    return MM.Sicherung.auspacken(bytes, schluessel || '').then(function (g) { sicherungPruefen(g); return g; });
  };

  /* Was steht in der Sicherung, und was ist jetzt auf dem Gerät? */
  Daten.prototype.sicherungVorschau = function (gelesen) {
    return this.sicherungZahlen().then(function (jetzt) {
      var t = gelesen.kopf.tabellen, z = {};
      ZAEHL_TABELLEN.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
      var bytes = gelesen.dateien.reduce(function (s, d) { return s + d.length; }, 0);
      return { erstelltAm: gelesen.kopf.erstelltAm, app: gelesen.kopf.app, mitDateien: !!gelesen.kopf.mitDateien, dateien: gelesen.dateien.length, dateiBytes: bytes, zahlen: z, jetzt: jetzt };
    });
  };

  /*
   * Ersetzt ALLE Daten auf dem Gerät durch die der Sicherung, in einem Schritt.
   * Schlägt etwas fehl, bleibt der bisherige Stand unverändert.
   */
  Daten.prototype.sicherungEinspielen = function (gelesen) {
    var self = this;
    try { sicherungPruefen(gelesen); } catch (e) { return Promise.reject(e); }
    var t = gelesen.kopf.tabellen, karte = {};
    MM.Speicher.TABELLEN.forEach(function (n) {
      var liste = t[n] || [];
      karte[n] = liste.map(function (o) {
        if (DATEI_TABELLEN.indexOf(n) >= 0) {
          var kopie = Object.assign({}, o);
          kopie.inhalt = (o.inhalt && typeof o.inhalt.$datei === 'number') ? new Blob([gelesen.dateien[o.inhalt.$datei]], { type: o.mime || '' }) : null;
          return kopie;
        }
        return o;
      });
    });
    var einst = (karte.einstellungen || []).filter(function (e) { return e.id === 'sicherung'; })[0] || {};
    karte.einstellungen = (karte.einstellungen || []).filter(function (e) { return e.id !== 'sicherung'; })
      .concat([{ id: 'sicherung', letzteSicherung: gelesen.kopf.erstelltAm, erinnerungTage: einst.erinnerungTage === undefined ? 30 : einst.erinnerungTage }]);
    /* Die Einstellungen dieses Geräts bleiben, wie sie sind (nicht die des Geräts, von dem die Sicherung stammt). */
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (geraet) {
      karte.einstellungen = karte.einstellungen.filter(function (e) { return e.id !== GERAET_DOK; }).concat(geraet ? [geraet] : []);
      return self.speicher.ersetzenAlles(karte);
    }).then(function () { return self.rcSchreiben({ abgleich: null }); }).then(function () { return self.starten(); });
  };


  /* ---------- Übergabe und Technik-Akte beim Abgeben (seit 2.0.37) ---------- */

  /*
   * Die Übergabedatei enthält NUR die technische Historie des Fahrzeugs: Fahrzeug mit Verlauf, Komponenten und
   * Ausrüstung, Zähler mit Ständen, Fristen und Erledigungen (auch HU), Werkstatt-Vorgänge und Störungen, Dokumente
   * an Fahrzeug, Komponente und Vorgang (auf Wunsch mit den Dateien) und die Namen der Werkstätten.
   * Nicht dabei: Aktivitäten, Logbuch, Reisekasse, Kosten, Personen, Besatzung, Orte, Nachweise, Standort.
   * Das Format ist das der Sicherungsdatei (Kopf mit uebergabe: true), damit Verschlüsselung und Prüfung dieselben bleiben.
   */
  var UEBERGABE_TABELLEN = ['fahrzeuge', 'eintraege', 'komponenten', 'komponenteneintraege', 'zaehler', 'zaehlerstaende',
    'fristen', 'durchfuehrungen', 'vorgaenge', 'dokumente', 'dateien', 'adressen', 'verlaeufe'];
  var UEBERGABE_ZAEHLUNG = [['komponenten', 'Komponenten'], ['zaehler', 'Zähler'], ['fristen', 'Fristen'], ['vorgaenge', 'Vorgänge'], ['dokumente', 'Dokumente']];
  /* Von der Adresse einer Werkstatt geht nur das Öffentliche mit, keine Ansprechpartner und Notizen. */
  var UEBERGABE_ADRESSFELDER = ['bezeichnung', 'art', 'plz', 'ort', 'land'];

  function idErsetzen(o, karte) {
    if (typeof o === 'string') return Object.prototype.hasOwnProperty.call(karte, o) ? karte[o] : o;
    if (Array.isArray(o)) return o.map(function (x) { return idErsetzen(x, karte); });
    if (o && typeof o === 'object' && !(typeof Blob !== 'undefined' && o instanceof Blob)) {
      var k = {}; Object.keys(o).forEach(function (n) { k[n] = idErsetzen(o[n], karte); }); return k;
    }
    return o;
  }
  function idPraefix(id) { var i = String(id).indexOf('-'); return i > 0 ? String(id).slice(0, i) : 'x'; }
  function dateiNameSauber(t) {
    return String(t || 'Fahrzeug').replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/Ä/g, 'Ae').replace(/Ö/g, 'Oe').replace(/Ü/g, 'Ue').replace(/ß/g, 'ss')
      .replace(/[^A-Za-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'Fahrzeug';
  }

  Daten.prototype.uebergabeErzeugen = function (fahrzeugId, optionen) {
    var self = this;
    optionen = optionen || {};
    var mitDateien = optionen.mitDateien !== false;
    return Promise.all([this.speicher.alleTabellen(), this.fahrzeugLaden(fahrzeugId)]).then(function (r) {
      var t = r[0], f = r[1];
      if (!f || f.fahrzeug.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (!f.fahrzeug.abgabe) return { ok: false, fehler: { allgemein: 'Das Fahrzeug ist noch nicht abgegeben. Gib es zuerst ab.' } };
      function wo(name, fn) { return (t[name] || []).filter(fn); }
      function mengeVon(liste) { var m = {}; liste.forEach(function (x) { m[x.id] = true; }); return m; }
      var fz = Object.assign({}, f.fahrzeug); delete fz.abgabe; delete fz.abgabeVerlauf;
      /* „Gehört zu“ (seit 2.0.45) verweist auf ein anderes Fahrzeug und hat in einem fremden Datenraum keine Bedeutung. */
      var eintr = wo('eintraege', function (x) { return x.fahrzeugId === fahrzeugId; }).map(function (x) {
        /* Ebenso die Listen der Zugfahrzeuge und Boote (seit 2.0.103). */
        if (!x.werte || !['hauptfahrzeugId', 'zugfahrzeuge', 'bootsliste'].some(function (k) { return Object.prototype.hasOwnProperty.call(x.werte, k); })) return x;
        var w = Object.assign({}, x.werte); delete w.hauptfahrzeugId; delete w.zugfahrzeuge; delete w.bootsliste;
        return Object.assign({}, x, { werte: w });
      });
      var komp = wo('komponenten', function (x) { return x.fahrzeugId === fahrzeugId; }), kM = mengeVon(komp);
      var kEin = wo('komponenteneintraege', function (x) { return kM[x.komponenteId]; });
      var zae = wo('zaehler', function (x) { return x.fahrzeugId === fahrzeugId; }), zM = mengeVon(zae);
      var zSt = wo('zaehlerstaende', function (x) { return zM[x.zaehlerId]; });
      var fri = wo('fristen', function (x) { return x.fahrzeugId === fahrzeugId; }), fM = mengeVon(fri);
      var dur = wo('durchfuehrungen', function (x) { return fM[x.fristId]; });
      var vor = wo('vorgaenge', function (x) { return x.fahrzeugId === fahrzeugId; }), vM = mengeVon(vor);
      /* Belege zu Kosten gehören zu deinen Kosten und gehen nicht mit. */
      var dok = wo('dokumente', function (x) { return x.fahrzeugId === fahrzeugId && !x.kostenId; }), dM = mengeVon(dok);
      var objM = {}; [fM, zM, vM, dM].forEach(function (m) { Object.keys(m).forEach(function (k) { objM[k] = true; }); });
      var verl = wo('verlaeufe', function (x) { return objM[x.objektId]; });
      var adrM = {};
      verl.forEach(function (x) { if (x.objektTyp === 'vorgang' && x.werte && x.werte.adresseId) adrM[x.werte.adresseId] = true; });
      var adr = wo('adressen', function (x) { return adrM[x.id]; });
      wo('verlaeufe', function (x) { return adrM[x.objektId]; }).forEach(function (x) {
        var w = {}; UEBERGABE_ADRESSFELDER.forEach(function (n) { w[n] = x.werte ? (x.werte[n] === undefined ? null : x.werte[n]) : null; });
        verl.push(Object.assign({}, x, { werte: w }));
      });
      var tabellen = { fahrzeuge: [fz], eintraege: eintr, komponenten: komp, komponenteneintraege: kEin, zaehler: zae, zaehlerstaende: zSt,
        fristen: fri, durchfuehrungen: dur, vorgaenge: vor, dokumente: dok, adressen: adr, verlaeufe: verl, dateien: [] };
      var dateien = [], leer = 0, kette = Promise.resolve();
      if (mitDateien) {
        wo('dateien', function (x) { return dM[x.dokumentId]; }).forEach(function (rec) {
          kette = kette.then(function () {
            var kopie = Object.assign({}, rec);
            if (rec.inhalt && typeof rec.inhalt.arrayBuffer === 'function') {
              return rec.inhalt.arrayBuffer().then(function (buf) { kopie.inhalt = { $datei: dateien.length }; dateien.push(new Uint8Array(buf)); tabellen.dateien.push(kopie); });
            }
            leer++; kopie.inhalt = null; tabellen.dateien.push(kopie);
          });
        });
      }
      return kette.then(function () {
        var zaehlung = {}; Object.keys(tabellen).forEach(function (n) { zaehlung[n] = tabellen[n].length; });
        var a = MM.Fahrzeugarten.art(f.fahrzeug.art);
        var kopf = { format: MM.Sicherung.FORMAT, uebergabe: true, app: MM.VERSION, dbVersion: MM.Speicher.DB_VERSION, erstelltAm: self.jetzt(), mitDateien: mitDateien,
          fahrzeug: { bezeichnung: f.aktuell.werte.bezeichnung, art: f.fahrzeug.art, artName: a ? a.name : f.fahrzeug.art,
            artPfad: MM.Fahrzeugarten.vorfahren(f.fahrzeug.art), abgabeDatum: f.fahrzeug.abgabe.datum, grund: f.fahrzeug.abgabe.grund,
            uebergabeId: fahrzeugId + '|' + f.fahrzeug.abgabe.datum + '|' + f.fahrzeug.abgabe.erfasstAm },
          tabellen: tabellen, zaehlung: zaehlung };
        return MM.Sicherung.bauen(kopf, dateien, optionen.schluessel || '').then(function (bytes) {
          var z = {}; UEBERGABE_ZAEHLUNG.forEach(function (x) { z[x[0]] = tabellen[x[0]].length; });
          var name = 'MobiMory-Uebergabe_' + dateiNameSauber(kopf.fahrzeug.bezeichnung) + '_' + f.fahrzeug.abgabe.datum + '.mmuebergabe';
          return { ok: true, bytes: bytes, name: name, groesse: bytes.length, zahlen: z, dateien: dateien.length, ohneInhalt: leer, mitDateien: mitDateien, verschluesselt: !!optionen.schluessel };
        });
      });
    });
  };

  function uebergabePruefen(gelesen) {
    function f(code, text) { var e = new Error(text); e.code = code; return e; }
    var k = gelesen.kopf;
    if (!k || typeof k !== 'object' || !k.tabellen || typeof k.tabellen !== 'object') throw f('beschaedigt', 'Die Datei ist beschädigt.');
    if (!k.uebergabe) throw f('keine-uebergabe', 'Das ist keine Übergabedatei. Eine Sicherung gehört unter Einstellungen zu „Wiederherstellen“.');
    if (k.format !== MM.Sicherung.FORMAT) throw f(k.format > MM.Sicherung.FORMAT ? 'neuer' : 'format', k.format > MM.Sicherung.FORMAT ? 'Diese Übergabedatei stammt aus einer neueren Version von MobiMory. Bitte zuerst die App aktualisieren.' : 'Das ist keine MobiMory-Übergabedatei.');
    if (typeof k.dbVersion !== 'number' || k.dbVersion > MM.Speicher.DB_VERSION) throw f('neuer', 'Diese Übergabedatei stammt aus einer neueren Version von MobiMory (' + (k.app || '?') + '). Bitte zuerst die App aktualisieren.');
    if (!k.fahrzeug || typeof k.fahrzeug !== 'object' || typeof k.fahrzeug.art !== 'string' || typeof k.fahrzeug.uebergabeId !== 'string') throw f('beschaedigt', 'Die Datei ist beschädigt.');
    var benutzt = {};
    Object.keys(k.tabellen).forEach(function (n) {
      if (UEBERGABE_TABELLEN.indexOf(n) < 0) throw f('beschaedigt', 'Die Übergabedatei enthält etwas Unbekanntes (' + n + ').');
      var liste = k.tabellen[n];
      if (!Array.isArray(liste)) throw f('beschaedigt', 'Die Datei ist beschädigt.');
      if (k.zaehlung && k.zaehlung[n] !== undefined && k.zaehlung[n] !== liste.length) throw f('beschaedigt', 'Die Datei ist beschädigt: Die Anzahl der Einträge stimmt nicht.');
      liste.forEach(function (o) {
        if (!o || typeof o !== 'object' || typeof o.id !== 'string' || !o.id) throw f('beschaedigt', 'Die Datei ist beschädigt: Ein Eintrag ist unvollständig.');
        if (n === 'dateien' && o.inhalt !== null && o.inhalt !== undefined) {
          var i = o.inhalt && o.inhalt.$datei;
          if (typeof i !== 'number' || i < 0 || i >= gelesen.dateien.length || benutzt[i]) throw f('beschaedigt', 'Die Datei ist beschädigt: Eine Datei fehlt.');
          benutzt[i] = true;
        }
      });
    });
    if (!k.tabellen.fahrzeuge || k.tabellen.fahrzeuge.length !== 1) throw f('beschaedigt', 'Die Datei ist beschädigt: Es muss genau ein Fahrzeug enthalten sein.');
    return true;
  }

  Daten.prototype.uebergabeLesen = function (bytes, schluessel) {
    return MM.Sicherung.auspacken(bytes, schluessel || '').then(function (g) { uebergabePruefen(g); return g; });
  };

  /* Die Art für die Übernahme: die eigene, sonst die nächste vorhandene darüber. Sonst null. */
  function artFuerUebernahme(kopfFahrzeug) {
    var ids = [kopfFahrzeug.art].concat(Array.isArray(kopfFahrzeug.artPfad) ? kopfFahrzeug.artPfad : []);
    for (var i = 0; i < ids.length; i++) {
      var a = MM.Fahrzeugarten.art(ids[i]);
      if (a && !a.gruppe && MM.Fahrzeugarten.sichtbar(a.id)) return { id: a.id, name: a.name, angepasst: i > 0 };
    }
    return null;
  }

  /* Die Angaben (neuester Eintrag) des Fahrzeugs in der Übergabedatei, für den Vergleich der Kennung (seit 2.0.46). */
  function uebergabeWerte(k) {
    var t = k.tabellen, fid = t.fahrzeuge && t.fahrzeuge[0] ? t.fahrzeuge[0].id : null;
    var e = (t.eintraege || []).filter(function (x) { return x.fahrzeugId === fid; }).sort(nachNr).pop();
    return e && e.werte ? e.werte : {};
  }

  Daten.prototype.uebergabeVorschau = function (gelesen) {
    var self = this, k = gelesen.kopf, t = k.tabellen;
    return Promise.all([this.fahrzeugListe({ alle: true }), this.kennungTreffer(uebergabeWerte(k), null)]).then(function (rr) {
      var liste = rr[0], treffer = rr[1];
      var schon = liste.filter(function (x) { return x.fahrzeug.uebernommen && x.fahrzeug.uebernommen.uebergabeId === k.fahrzeug.uebergabeId; })[0];
      var z = {}; UEBERGABE_ZAEHLUNG.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
      var art = artFuerUebernahme(k.fahrzeug);
      return { bezeichnung: k.fahrzeug.bezeichnung, artName: k.fahrzeug.artName, abgabeDatum: k.fahrzeug.abgabeDatum, grund: k.fahrzeug.grund, erstelltAm: k.erstelltAm, app: k.app,
        mitDateien: !!k.mitDateien, dateien: gelesen.dateien.length, dateiBytes: gelesen.dateien.reduce(function (s, d) { return s + d.length; }, 0), zahlen: z,
        schonUebernommen: schon ? { am: schon.fahrzeug.uebernommen.am, bezeichnung: schon.aktuell.werte.bezeichnung, id: schon.fahrzeug.id } : null,
        kennungTreffer: treffer, kennungText: treffer.length ? kennungTrefferText(uebergabeWerte(k), treffer) : null,
        art: art, artFehlt: !art };
    });
  };

  /*
   * Legt das Fahrzeug aus der Übergabedatei als NEUES Fahrzeug an. Alle Kennungen werden neu vergeben, so kollidiert nichts mit
   * Vorhandenem, auch nicht beim Einlesen auf demselben Gerät. Werkstätten, die es schon gibt (gleicher Name und Ort), werden wiederverwendet.
   * Alles passiert in einem Schritt: Schlägt etwas fehl, wird nichts angelegt.
   */
  Daten.prototype.uebergabeEinspielen = function (gelesen, opt) {
    var self = this;
    opt = opt || {};
    try { uebergabePruefen(gelesen); } catch (e) { return Promise.reject(e); }
    var k = gelesen.kopf, t = k.tabellen;
    return Promise.all([this.fahrzeugListe({ alle: true }), this.adressenListe(), this.kennungTreffer(uebergabeWerte(k), null)]).then(function (r) {
      var schon = r[0].filter(function (x) { return x.fahrzeug.uebernommen && x.fahrzeug.uebernommen.uebergabeId === k.fahrzeug.uebergabeId; })[0];
      if (schon && !opt.nochmal) return { ok: false, schonDa: true, fehler: { allgemein: 'Diese Übergabe ist schon übernommen (am ' + MM.Hilfen.zeitpunkt(schon.fahrzeug.uebernommen.am) + ').' } };
      /* Gleiche Kennung wie ein vorhandenes Fahrzeug: erst fragen (seit 2.0.46). „nochmal“ (schon übernommen) und „trotzdem“ sind die ausdrückliche Zustimmung. */
      if (r[2].length && !opt.trotzdem && !opt.nochmal) return { ok: false, doppelt: r[2], fehler: { allgemein: kennungTrefferText(uebergabeWerte(k), r[2]) } };
      var art = artFuerUebernahme(k.fahrzeug);
      if (!art) return { ok: false, fehler: { allgemein: 'Die Fahrzeugart „' + (k.fahrzeug.artName || k.fahrzeug.art) + '“ gibt es hier nicht. Lege sie unter „Fahrzeugarten verwalten“ an und lies die Datei danach noch einmal ein.' } };

      /* Fahrzeug-Grenze der Stufe (seit 2.0.70): Eine Übernahme legt ein Fahrzeug an. */
      return self.fahrzeugGrenzePruefen(1).then(function (g) {
      if (!g.ok) return { ok: false, grenze: g, fehler: { allgemein: g.text } };
      var karte = {};
      UEBERGABE_TABELLEN.forEach(function (n) { (t[n] || []).forEach(function (o) { karte[o.id] = neueId(idPraefix(o.id)); }); });
      /* vorhandene Werkstätten wiederverwenden */
      var vorhanden = {};
      r[1].forEach(function (x) { vorhanden[((x.aktuell.werte.bezeichnung || '') + '|' + (x.aktuell.werte.ort || '')).toLowerCase()] = x.objekt.id; });
      var uebersprungen = {};
      (t.adressen || []).forEach(function (a) {
        var st = (t.verlaeufe || []).filter(function (v) { return v.objektId === a.id; }).sort(nachNr).pop();
        if (!st) return;
        var key = ((st.werte.bezeichnung || '') + '|' + (st.werte.ort || '')).toLowerCase();
        if (vorhanden[key]) { karte[a.id] = vorhanden[key]; uebersprungen[a.id] = true; }
      });
      var jetzt = self.jetzt(), liste = [], neueFahrzeugId = karte[t.fahrzeuge[0].id];
      UEBERGABE_TABELLEN.forEach(function (n) {
        (t[n] || []).forEach(function (o) {
          if (n === 'adressen' && uebersprungen[o.id]) return;
          if (n === 'verlaeufe' && uebersprungen[o.objektId]) return;
          var neu = idErsetzen(o, karte);
          neu.id = karte[o.id];
          if (n === 'dateien') neu.inhalt = (o.inhalt && typeof o.inhalt.$datei === 'number') ? new Blob([gelesen.dateien[o.inhalt.$datei]], { type: o.mime || '' }) : null;
          if (Object.prototype.hasOwnProperty.call(neu, 'datenraumId')) neu.datenraumId = self.datenraumId;
          if (n === 'fahrzeuge') {
            neu.datenraumId = self.datenraumId;
            delete neu.abgabe; delete neu.abgabeVerlauf;
            neu.uebernommen = { am: jetzt, uebergabeId: k.fahrzeug.uebergabeId, abgabeDatum: k.fahrzeug.abgabeDatum, grund: k.fahrzeug.grund, app: k.app || null };
          }
          liste.push({ tabelle: n, objekt: neu });
        });
      });
      /* Gab es die Fahrzeugart hier nicht, gilt die nächste vorhandene darüber, auch in den Einträgen. */
      if (art.angepasst) {
        var orig = k.fahrzeug.art;
        liste.forEach(function (x) {
          var o = x.objekt;
          if (x.tabelle === 'fahrzeuge') {
            o.art = art.id;
            if (Array.isArray(o.artWechsel)) o.artWechsel = o.artWechsel.map(function (w) { return { von: w.von === orig ? art.id : w.von, nach: w.nach === orig ? art.id : w.nach, am: w.am, eintragNr: w.eintragNr }; });
          }
          if (x.tabelle === 'eintraege') { if (o.art === orig) o.art = art.id; if (o.artVorher === orig) o.artVorher = art.id; }
        });
      }
      return self.speicher.mehrereSpeichern(liste).then(function () {
        var z = {}; UEBERGABE_ZAEHLUNG.forEach(function (x) { z[x[0]] = (t[x[0]] || []).length; });
        return { ok: true, id: neueFahrzeugId, zahlen: z, artAngepasst: art.angepasst ? art.name : null };
      });
      });
    });
  };

  /* ---------- Technik-Akte als PDF ---------- */

  /* Ein Datum (JJJJ-MM-TT) um n Monate zurück, der Tag wird bei Bedarf auf das Monatsende gekürzt. */
  function monateZurueck(iso, n) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
    var y = Number(m[1]), mo = Number(m[2]) - 1 - n, d = Number(m[3]);
    while (mo < 0) { mo += 12; y--; }
    var ende = new Date(Date.UTC(y, mo + 1, 0)).getUTCDate();
    function z(x) { return (x < 10 ? '0' : '') + x; }
    return y + '-' + z(mo + 1) + '-' + z(Math.min(d, ende));
  }

  /*
   * Zeitraum der Technik-Akte: von der letzten HU bis zur Abgabe, höchstens 24 Monate.
   *  - Letzte HU höchstens 24 Monate vor der Abgabe: Beginn = Tag der HU.
   *  - Letzte HU länger her: Beginn = 24 Monate vor der Abgabe (die HU ist dann überfällig).
   *  - Keine HU erfasst: Beginn = Tag, an dem das Fahrzeug angelegt wurde, aber nicht früher als 24 Monate vor der Abgabe.
   * Ergebnis: { von, bis, art: 'hu' | 'hu-alt' | 'angelegt' | 'ohne-hu-grenze', huDatum }
   */
  function akteZeitraum(abgabeDatum, huDatum, angelegtDatum) {
    var grenze = monateZurueck(abgabeDatum, 24);
    if (huDatum) {
      if (huDatum >= grenze) return { von: huDatum, bis: abgabeDatum, art: 'hu', huDatum: huDatum };
      return { von: grenze, bis: abgabeDatum, art: 'hu-alt', huDatum: huDatum };
    }
    if (angelegtDatum && angelegtDatum >= grenze) return { von: angelegtDatum, bis: abgabeDatum, art: 'angelegt', huDatum: null };
    return { von: grenze, bis: abgabeDatum, art: 'ohne-hu-grenze', huDatum: null };
  }

  var HU_NAME = /(^|[^A-Za-zÄÖÜäöüß])(HU|Hauptuntersuchung|T[ÜU]V)([^A-Za-zÄÖÜäöüß]|$)/i;

  /* Die Daten der Akte, ohne PDF. Nur lesen. */
  Daten.prototype.akteDaten = function (fahrzeugId) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f || f.fahrzeug.datenraumId !== self.datenraumId) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (!f.fahrzeug.abgabe) return { ok: false, fehler: { allgemein: 'Das Fahrzeug ist noch nicht abgegeben. Gib es zuerst ab.' } };
      return Promise.all([self.komponentenListe(fahrzeugId), self.fristenListe(fahrzeugId), self.zaehlerListe(fahrzeugId), self.vorgaengeListe(fahrzeugId),
        self.speicher.alle('durchfuehrungen'), self.speicher.alle('zaehlerstaende')]).then(function (r) {
        var abgabe = f.fahrzeug.abgabe.datum, komp = r[0], fristen = r[1], zaehler = r[2], vorgaenge = r[3];
        var fristIds = {}; fristen.forEach(function (x) { fristIds[x.frist.id] = x; });
        var dur = r[4].filter(function (d) { return fristIds[d.fristId]; });
        var namen = {}; komp.forEach(function (k) { namen[k.komponente.id] = k.aktuell.werte.bezeichnung; });
        function besitzer(id) { return id ? (namen[id] || 'Komponente') : 'Fahrzeug'; }

        /* letzte HU: Frist am Fahrzeug, deren Name nach HU oder TÜV klingt, letzte Erledigung bis zur Abgabe */
        var huFristen = fristen.filter(function (x) { return !x.frist.komponenteId && HU_NAME.test(x.aktuell.werte.bezeichnung || ''); });
        var huDatum = null, huFrist = null;
        huFristen.forEach(function (x) {
          dur.filter(function (d) { return d.fristId === x.frist.id && d.datum && d.datum <= abgabe; }).forEach(function (d) {
            if (!huDatum || d.datum > huDatum) { huDatum = d.datum; huFrist = x; }
          });
        });
        var angelegt = f.verlauf[f.verlauf.length - 1].eintrag.erstelltAm;
        var angelegtDatum = angelegt ? new Date(angelegt).toISOString().slice(0, 10) : null;
        var zeit = akteZeitraum(abgabe, huDatum, f.fahrzeug.erstelltAm ? new Date(f.fahrzeug.erstelltAm).toISOString().slice(0, 10) : angelegtDatum);
        var huUeberfaellig = huFristen.some(function (x) { return x.status.status === 'ueberfaellig'; }) || zeit.art === 'hu-alt';

        var staende = zaehler.map(function (z) {
          var l = r[5].filter(function (s) { return s.zaehlerId === z.zaehler.id && s.datum && s.datum <= abgabe; }).sort(function (a, b) { return a.datum !== b.datum ? (a.datum < b.datum ? -1 : 1) : a.nr - b.nr; });
          var s = l[l.length - 1] || null;
          return { name: z.bezeichnung, besitzer: z.besitzer, einheit: z.einheit, wert: s ? s.wert : null, datum: s ? s.datum : null };
        });

        var erledigt = dur.filter(function (d) { return d.datum && d.datum >= zeit.von && d.datum <= zeit.bis; })
          .sort(function (a, b) { return a.datum < b.datum ? -1 : (a.datum > b.datum ? 1 : 0); })
          .map(function (d) { var x = fristIds[d.fristId]; return { datum: d.datum, name: x.aktuell.werte.bezeichnung, besitzer: besitzer(x.frist.komponenteId), zaehlerstand: d.zaehlerstand === undefined ? null : d.zaehlerstand, notiz: d.notiz || null, einheit: x.zaehler ? x.zaehler.einheit : null }; });
        var offene = fristen.map(function (x) {
          var st = x.status, letzte = st.letzte ? st.letzte.datum : null;
          var faellig = st.kalender && st.kalender.faelligAm ? st.kalender.faelligAm : null;
          return { name: x.aktuell.werte.bezeichnung, besitzer: besitzer(x.frist.komponenteId), status: st.status, letzte: letzte, faelligAm: faellig, wirkung: x.aktuell.werte.wirkung || null };
        });
        var werk = vorgaenge.filter(function (v) {
          var w = v.aktuell.werte;
          if (w.status === 'offen') return !w.gemeldetAm || w.gemeldetAm <= zeit.bis;
          return (w.gemeldetAm && w.gemeldetAm >= zeit.von && w.gemeldetAm <= zeit.bis) || (w.erledigtAm && w.erledigtAm >= zeit.von && w.erledigtAm <= zeit.bis);
        }).sort(function (a, b) { var x = a.aktuell.werte.gemeldetAm || '', y = b.aktuell.werte.gemeldetAm || ''; return x < y ? -1 : (x > y ? 1 : 0); })
          .map(function (v) { var w = v.aktuell.werte; return { gemeldetAm: w.gemeldetAm || null, art: w.art, bezeichnung: w.bezeichnung, besitzer: v.besitzer || 'Fahrzeug', status: w.status, erledigtAm: w.erledigtAm || null, auswirkung: w.auswirkung || null, notiz: w.erledigtNotiz || null }; });
        var haupt = self.sortiereKomponenten(komp.filter(function (x) { return !x.komponente.parentId && !x.aktuell.werte.ausgebautAm; }));
        return { ok: true, fahrzeug: f, abgabe: f.fahrzeug.abgabe, zeitraum: zeit, huFrist: huFrist ? huFrist.aktuell.werte.bezeichnung : null, huUeberfaellig: huUeberfaellig,
          staende: staende, erledigt: erledigt, fristen: offene, vorgaenge: werk, komponenten: haupt };
      });
    });
  };

  var GRUND_TEXT = { verkauft: 'verkauft', verschenkt: 'verschenkt', verschrottet: 'verschrottet', sonstiges: 'abgegeben' };
  var VORGANG_ART = { stoerung: 'Störung', arbeit: 'Arbeit' };
  var FRIST_STATUS = { ueberfaellig: 'Überfällig', bald: 'Bald fällig', ok: 'In Ordnung', unbekannt: 'Angaben fehlen' };

  /* Die Technik-Akte als PDF-Datei. */
  Daten.prototype.akteErzeugen = function (fahrzeugId) {
    var self = this;
    return this.akteDaten(fahrzeugId).then(function (a) {
      if (!a.ok) return a;
      var D = MM.Hilfen.datum, w = a.fahrzeug.aktuell.werte, art = MM.Fahrzeugarten.art(a.fahrzeug.fahrzeug.art), z = a.zeitraum;
      var d = MM.Pdf.neu({ fuss: 'MobiMory ' + MM.VERSION + ' · Technik-Akte ' + w.bezeichnung, titel: 'Technik-Akte ' + w.bezeichnung, datum: self.jetzt() });
      d.titel('Technik-Akte', w.bezeichnung + ' · ' + (GRUND_TEXT[a.abgabe.grund] || 'abgegeben') + ' am ' + D(a.abgabe.datum));
      d.absatz('Diese Akte enthält die technische Historie des Fahrzeugs. Aktivitäten, Fahrten, Kosten und Personen sind nicht enthalten.', { grau: true });

      d.abschnitt('Fahrzeug');
      d.zeile('Bezeichnung', w.bezeichnung);
      d.zeile('Fahrzeugart', art ? art.name : a.fahrzeug.fahrzeug.art);
      MM.Fahrzeugarten.gruppen(a.fahrzeug.fahrzeug.art).forEach(function (g) {
        g.felder.forEach(function (fe) { var t = MM.Hilfen.wert(fe, w[fe.key]); if (t !== null) d.zeile(fe.label, t); });
      });

      d.abschnitt('Zeitraum dieser Akte');
      d.zeile('Von', D(z.von));
      d.zeile('Bis (Abgabe)', D(z.bis));
      if (z.art === 'hu') d.zeile('Letzte HU', D(z.huDatum) + (a.huFrist ? ' (' + a.huFrist + ')' : ''));
      else if (z.art === 'hu-alt') d.zeile('Letzte HU', D(z.huDatum) + ' – mehr als 24 Monate vor der Abgabe');
      else d.zeile('Letzte HU', 'nicht erfasst');
      if (z.art === 'hu-alt') d.absatz('Die letzte HU liegt mehr als 24 Monate vor der Abgabe. Die Akte zeigt deshalb die letzten 24 Monate. Die HU war bei der Abgabe überfällig.', { fett: true });
      else if (z.art === 'angelegt') d.absatz('Es ist keine HU erfasst. Die Akte beginnt, als das Fahrzeug in MobiMory angelegt wurde.', { grau: true });
      else if (z.art === 'ohne-hu-grenze') d.absatz('Es ist keine HU erfasst. Die Akte zeigt die letzten 24 Monate vor der Abgabe.', { grau: true });
      else if (a.huUeberfaellig) d.absatz('Die HU ist überfällig.', { fett: true });

      d.abschnitt('Zählerstände bei der Abgabe');
      if (a.staende.length) d.tabelle([{ titel: 'Zähler', breite: 0 }, { titel: 'Gehört zu', breite: 110 }, { titel: 'Stand', breite: 90 }, { titel: 'Datum', breite: 70 }],
        a.staende.map(function (s) { return [s.name, s.besitzer, s.wert === null ? 'kein Stand' : MM.Hilfen.zahl(s.wert) + (s.einheit ? ' ' + s.einheit : ''), s.datum ? D(s.datum) : '']; }));
      else d.absatz('Es sind keine Zähler eingetragen.', { grau: true });

      d.abschnitt('Erledigte Wartungen und Prüfungen im Zeitraum');
      if (a.erledigt.length) d.tabelle([{ titel: 'Datum', breite: 62 }, { titel: 'Was', breite: 0 }, { titel: 'Gehört zu', breite: 100 }, { titel: 'Zählerstand', breite: 70 }],
        a.erledigt.map(function (e) { return [D(e.datum), e.name + (e.notiz ? ' – ' + e.notiz : ''), e.besitzer, e.zaehlerstand === null ? '' : MM.Hilfen.zahl(e.zaehlerstand) + (e.einheit ? ' ' + e.einheit : '')]; }));
      else d.absatz('Im Zeitraum ist nichts als erledigt eingetragen.', { grau: true });

      d.abschnitt('Offene und laufende Fristen');
      if (a.fristen.length) d.tabelle([{ titel: 'Frist', breite: 0 }, { titel: 'Gehört zu', breite: 100 }, { titel: 'Zuletzt erledigt', breite: 78 }, { titel: 'Stand', breite: 105 }],
        a.fristen.map(function (x) { return [x.name, x.besitzer, x.letzte ? D(x.letzte) : '', (FRIST_STATUS[x.status] || x.status) + (x.faelligAm ? ', fällig ' + D(x.faelligAm) : '')]; }));
      else d.absatz('Es sind keine Fristen eingetragen.', { grau: true });
      d.absatz('Der Stand der Fristen gilt am Tag, an dem die Akte erstellt wurde (' + D(self.heute()) + ').', { grau: true, groesse: 8 });

      d.abschnitt('Werkstatt: Störungen und Arbeiten im Zeitraum, dazu alle noch offenen');
      if (a.vorgaenge.length) d.tabelle([{ titel: 'Gemeldet', breite: 62 }, { titel: 'Art', breite: 48 }, { titel: 'Worum es geht', breite: 0 }, { titel: 'Betrifft', breite: 85 }, { titel: 'Stand', breite: 82 }],
        a.vorgaenge.map(function (v) { return [v.gemeldetAm ? D(v.gemeldetAm) : '', VORGANG_ART[v.art] || '', v.bezeichnung + (v.notiz ? ' – ' + v.notiz : ''), v.besitzer, v.status === 'offen' ? 'Offen' : 'Erledigt' + (v.erledigtAm ? ' ' + D(v.erledigtAm) : '')]; }));
      else d.absatz('Im Zeitraum gibt es keine Störungen oder Arbeiten und keine offenen Vorgänge.', { grau: true });

      d.abschnitt('Hauptkomponenten');
      if (a.komponenten.length) d.tabelle([{ titel: 'Komponente', breite: 0 }, { titel: 'Hersteller, Modell', breite: 170 }, { titel: 'Eingebaut', breite: 70 }],
        a.komponenten.map(function (k) { var v = k.aktuell.werte; return [v.bezeichnung, [v.hersteller, v.modell].filter(Boolean).join(' '), v.eingebautAm ? D(v.eingebautAm) : '']; }));
      else d.absatz('Es sind keine Hauptkomponenten eingetragen.', { grau: true });

      d.abstand(8);
      d.absatz('Alle Angaben stammen aus den Aufzeichnungen des bisherigen Besitzers in MobiMory. MobiMory trifft keine rechtliche Aussage.', { grau: true, groesse: 8 });
      var bytes = d.bytes();
      return { ok: true, bytes: bytes, seiten: d.seitenAnzahl(), groesse: bytes.length, mime: 'application/pdf',
        name: 'Technik-Akte_' + dateiNameSauber(w.bezeichnung) + '_' + a.abgabe.datum + '.pdf', zeitraum: z };
    });
  };

  /* Nur für Tests auf dem eigenen Gerät. */
  /* ---------- Reisecheck (Schritt 11, seit 2.0.38) ----------
   * Tabelle „reisechecks“: { id, datenraumId, aktivitaetId, fahrzeugId, erstelltAm, stand (Fingerabdruck der Anfrage),
   *   anfrage (genau das, was hinausging, ohne Namen), namen (P1 → Name, nur auf dem Gerät), ergebnis, dienst, von, bis }.
   * Adresse und Passwort des Dienstes und die Zustimmungen liegen im Geräte-Dokument. Sie sind pro Gerät und nicht in der Sicherung. */

  function rcFehler(text, art) { return { ok: false, fehler: { allgemein: text }, art: art || 'allgemein' }; }

  /* Der Reisecheck dauert oft eine bis zwei Minuten, weil der Dienst im Internet sucht. */
  function standardSendeJson(url, token, body) {
    var f = global.fetch;
    if (typeof f !== 'function') return Promise.reject(new Error('Kein Netz verfügbar.'));
    var ctl = typeof global.AbortController === 'function' ? new global.AbortController() : null;
    var timer = ctl ? global.setTimeout(function () { ctl.abort(); }, 240000) : null;
    function ende() { if (timer) global.clearTimeout(timer); }
    return f(url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Mobimory-Token': token }, body: JSON.stringify(body), signal: ctl ? ctl.signal : undefined })
      .then(function (r) {
        return r.json().catch(function () { return null; }).then(function (j) {
          ende();
          if (!r.ok) { var e = new Error((j && j.error) || ('Antwort ' + r.status)); e.status = r.status; throw e; }
          return j;
        });
      }, function (e) { ende(); throw e; });
  }

  function rcFehlerText(err) {
    var s = err && err.status, m = err && err.message ? String(err.message) : '';
    if (s === 401) return 'Das Passwort passt nicht zum Dienst. Prüfe es unter „Dienst einrichten“.';
    if (s === 403) return 'Der Dienst lehnt diese App-Adresse ab. Im Dienst muss die Adresse dieser App als erlaubt eingetragen sein.';
    if (s === 503) return 'Der Dienst ist noch nicht fertig eingerichtet' + (m ? ': ' + m : '.');
    if (s) return 'Der Dienst konnte die Recherche nicht abschließen' + (m ? ': ' + m : '.');
    if (err && err.name === 'AbortError') return 'Der Dienst hat zu lange gebraucht. Versuche es später noch einmal.';
    return 'Keine Verbindung zum Dienst. Prüfe das Netz und die Adresse. Ohne Netz geht der Reisecheck nicht.';
  }

  Daten.prototype.sendeJson = function (url, token, body) {
    return (this.sendeJsonFn || standardSendeJson)(url, token, body);
  };

  /* Der Konto-Dienst: die feste Adresse unter mobimory.com, nur im Entwickler-Bereich lässt sich eine andere eintragen (seit 2.0.68). */
  function kontoUrlVon(d) { return (d && d.kontoDienstUrl) || MM.Konto.STANDARD_DIENST; }

  Daten.prototype.rcGeraet = function () {
    return this.speicher.holen('einstellungen', GERAET_DOK).then(function (d) { return d || { id: GERAET_DOK }; });
  };
  Daten.prototype.rcSchreiben = function (aenderung) {
    var self = this;
    return this.rcGeraet().then(function (d) { return self.speicher.speichern('einstellungen', Object.assign({}, d, { id: GERAET_DOK }, aenderung)); });
  };

  /* Für die Anzeige: nie das Passwort selbst. */
  Daten.prototype.reisecheckEinstellung = function () {
    return this.rcGeraet().then(function (d) {
      var liste = Array.isArray(d.reisecheckZustimmungen) ? d.reisecheckZustimmungen : [];
      var letzte = liste.length ? liste[liste.length - 1] : null;
      var gilt = !!(letzte && letzte.aktion === 'zugestimmt' && letzte.version === MM.Reisecheck.ZUSTIMMUNG_VERSION);
      /* Seit 2.0.68 laufen die Checks über das Konto. Die Direktverbindung mit Adresse und Passwort gilt nur im Entwickler-Modus, den das Einrichten dort einschaltet. */
      var direkt = !!(d.entwicklerModus && d.reisecheckDienstUrl && d.reisecheckToken);
      var ueberKonto = !!(d.kontoToken && d.kontoEmail);
      return { dienstUrl: d.reisecheckDienstUrl || '', hatPasswort: !!d.reisecheckToken, eingerichtet: direkt, direkt: direkt, entwickler: !!d.entwicklerModus, ueberKonto: ueberKonto, bereit: direkt || ueberKonto,
        zugestimmt: gilt, zugestimmtAm: gilt ? letzte.am : null, zustimmungAlt: !!(letzte && letzte.aktion === 'zugestimmt' && !gilt),
        widerrufenAm: letzte && letzte.aktion === 'widerrufen' ? letzte.am : null, protokoll: liste.slice() };
    });
  };

  /* Adresse und Passwort speichern. Bleibt das Passwort leer, bleibt das alte. Eine andere Adresse macht die Zustimmung ungültig. */
  Daten.prototype.reisecheckEinrichten = function (roh) {
    var self = this;
    roh = roh || {};
    return this.rcGeraet().then(function (d) {
      var fehler = {}, u = MM.Reisecheck.dienstAdresse(roh.dienstUrl), token = d.reisecheckToken || '';
      if (!u.ok) fehler.dienstUrl = u.fehler;
      var neuesPasswort = String(roh.passwort === null || roh.passwort === undefined ? '' : roh.passwort).trim();
      if (neuesPasswort || !token) {
        var t = MM.Reisecheck.tokenPruefen(neuesPasswort);
        if (!t.ok) fehler.passwort = t.fehler; else token = t.token;
      }
      if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
      var aenderung = { reisecheckDienstUrl: u.url, reisecheckToken: token, entwicklerModus: true };
      var liste = Array.isArray(d.reisecheckZustimmungen) ? d.reisecheckZustimmungen.slice() : [];
      var letzte = liste.length ? liste[liste.length - 1] : null;
      var adresseNeu = !!d.reisecheckDienstUrl && d.reisecheckDienstUrl !== u.url;
      if (adresseNeu && letzte && letzte.aktion === 'zugestimmt') {
        liste.push({ am: self.jetzt(), aktion: 'widerrufen', version: MM.Reisecheck.ZUSTIMMUNG_VERSION, grund: 'Adresse des Dienstes geändert' });
        aenderung.reisecheckZustimmungen = liste;
      }
      return self.rcSchreiben(aenderung).then(function () { return { ok: true, zustimmungZurueck: !!aenderung.reisecheckZustimmungen }; });
    });
  };

  /* Ruft die Gesundheitsabfrage des Dienstes auf. Ein Passwort braucht sie nicht, das wird erst beim Check geprüft. */
  Daten.prototype.reisecheckVerbindung = function () {
    var self = this;
    return this.rcGeraet().then(function (d) {
      if (!d.reisecheckDienstUrl) return { ok: false, fehler: 'Bitte zuerst die Adresse des Dienstes speichern.' };
      return Promise.resolve().then(function () { return self.holeJson(d.reisecheckDienstUrl + '/health'); }).then(function (x) {
        if (!x || x.ok !== true) return { ok: false, fehler: 'Unter dieser Adresse läuft kein Recherche-Dienst von MobiMory.' };
        if (x.configured === false) return { ok: false, fehler: 'Der Dienst läuft, hat aber noch keinen KI-Schlüssel eingetragen.' };
        return { ok: true, modell: x.model ? String(x.model) : '' };
      }, function (e) {
        if (e && e.status === 403) return { ok: false, abgelehnt: true, fehler: 'Der Dienst lehnt diese App-Adresse ab. Im Dienst muss sie bei ERLAUBTE_URSPRUENGE stehen.' };
        return { ok: false, fehler: 'Der Dienst antwortet nicht. Prüfe die Adresse und das Netz. Stimmt beides, lehnt der Dienst vielleicht diese App-Adresse ab: Sie muss im Dienst bei ERLAUBTE_URSPRUENGE stehen, ohne Punkt und ohne Schrägstrich am Ende.' };
      });
    });
  };

  Daten.prototype.reisecheckZustimmen = function () {
    var self = this;
    return this.rcGeraet().then(function (d) {
      var direkt = !!(d.entwicklerModus && d.reisecheckDienstUrl && d.reisecheckToken), ueberKonto = !!(d.kontoToken && d.kontoEmail);
      if (!direkt && !ueberKonto) return rcFehler('Melde dich zuerst mit deinem Konto an. Danach kannst du zustimmen.', 'einrichtung');
      var liste = Array.isArray(d.reisecheckZustimmungen) ? d.reisecheckZustimmungen.slice() : [];
      liste.push({ am: self.jetzt(), aktion: 'zugestimmt', version: MM.Reisecheck.ZUSTIMMUNG_VERSION, text: MM.Reisecheck.ZUSTIMMUNG_TEXT, dienst: direkt ? d.reisecheckDienstUrl : kontoUrlVon(d) });
      return self.rcSchreiben({ reisecheckZustimmungen: liste.slice(-50) }).then(function () { return { ok: true }; });
    });
  };

  /* Schaltet die Direktverbindung zum Recherche-Dienst aus (Entwickler). Adresse und Passwort bleiben gespeichert. */
  Daten.prototype.reisecheckDirektAus = function () {
    return this.rcSchreiben({ entwicklerModus: false }).then(function () { return { ok: true }; });
  };

  Daten.prototype.reisecheckWiderrufen = function () {
    var self = this;
    return this.rcGeraet().then(function (d) {
      var liste = Array.isArray(d.reisecheckZustimmungen) ? d.reisecheckZustimmungen.slice() : [];
      liste.push({ am: self.jetzt(), aktion: 'widerrufen', version: MM.Reisecheck.ZUSTIMMUNG_VERSION });
      return self.rcSchreiben({ reisecheckZustimmungen: liste.slice(-50) }).then(function () { return { ok: true }; });
    });
  };

  /* ---------- Konto (Schritt 13a, seit 2.0.64) ----------
   * Adresse des Konto-Dienstes und die Anmeldung liegen im Geräte-Dokument (kontoDienstUrl, kontoToken, kontoEmail, kontoDatenraumId,
   * kontoSeit). Sie sind pro Gerät und nicht in der Sicherung. Die App arbeitet ohne Konto und ohne Netz weiter wie bisher.
   * Zum Dienst geht nur, was für die Anmeldung nötig ist: E-Mail-Adresse, Passwort, Code. Fahrzeuge und Dokumente gehen noch nicht hinaus. */

  /* Die App nennt dem Dienst ihre Version (Parameter „app“, seit 2.0.101). Ist sie zu alt, antwortet der Dienst mit 426 „Bitte zuerst aktualisieren“. */
  function mitAppVersion(url) {
    if (/[?&]app=/.test(url)) return url;
    return url + (url.indexOf('?') < 0 ? '?' : '&') + 'app=' + encodeURIComponent(MM.VERSION);
  }

  function kontoAnfrageStandard(url, methode, token, body) {
    url = mitAppVersion(url);
    var f = global.fetch;
    if (typeof f !== 'function') return Promise.reject(new Error('Kein Netz verfügbar.'));
    var ctl = typeof global.AbortController === 'function' ? new global.AbortController() : null;
    var text = body === undefined || body === null ? undefined : JSON.stringify(body);
    /* Größere Pakete (Sicherung, Abgleich) dürfen länger brauchen. */
    var lang = /\/check\/senden(\?|$)/.test(url); /* Die Recherche dauert ein bis zwei Minuten. */
    var timer = ctl ? global.setTimeout(function () { ctl.abort(); }, lang ? 180000 : (text && text.length > 100000 ? 60000 : 20000)) : null;
    function ende() { if (timer) global.clearTimeout(timer); }
    var kopf = {};
    if (text !== undefined) kopf['Content-Type'] = 'application/json';
    if (token) kopf['Authorization'] = 'Bearer ' + token;
    return f(url, { method: methode, headers: kopf, body: text, signal: ctl ? ctl.signal : undefined })
      .then(function (r) {
        return r.json().catch(function () { return null; }).then(function (j) {
          ende();
          if (!r.ok) { var e = new Error((j && j.error) || ('Antwort ' + r.status)); e.status = r.status; e.feld = j && j.feld; if (j && j.appZuAlt) e.appZuAlt = true; if (j && j.geraeteVoll) { e.geraeteVoll = true; e.aeltestes = j.aeltestes || null; } throw e; }
          return j;
        });
      }, function (e) { ende(); throw e; });
  }

  /* Ohne Anmeldung gehen nur diese Wege. Alles andere (auch Abgleich und Sicherung) schickt den Schlüssel der Anmeldung mit. */
  var KONTO_OHNE_TOKEN = { '/konto/registrieren': 1, '/konto/code-anfordern': 1, '/konto/code-pruefen': 1, '/konto/anmelden': 1 };

  /* Schickt eine Anfrage an den Konto-Dienst. Wirft nie: Ergebnis ist { ok, json } oder { ok: false, fehler, status, feld }. */
  Daten.prototype.kontoSenden = function (methode, pfad, body) {
    var self = this;
    return this.rcGeraet().then(function (d) {
      var token = KONTO_OHNE_TOKEN[pfad.split('?')[0]] ? '' : (d.kontoToken || '');
      var f = self.kontoAnfrageFn || kontoAnfrageStandard;
      return Promise.resolve().then(function () { return f(kontoUrlVon(d) + pfad, methode, token, body); }).then(
        function (j) { return { ok: true, json: j }; },
        function (e) { return { ok: false, fehler: MM.Konto.fehlerText(e), status: e && e.status, feld: e && e.feld, geraeteVoll: !!(e && e.geraeteVoll), aeltestes: (e && e.aeltestes) || null }; });
    });
  };

  /* Dateien gehen als Bytes zum Dienst und kommen als Bytes zurück (Schritt 13d). Wirft nie: { ok, json } oder { ok, bytes, verschluesselt } oder { ok: false, fehler, status }.
     Für die Tests lässt sich die Funktion über die Option „kontoBytes“ ersetzen. */
  function kontoBytesStandard(url, methode, token, bytes) {
    url = mitAppVersion(url);
    var f = global.fetch;
    if (typeof f !== 'function') return Promise.reject(new Error('Kein Netz verfügbar.'));
    var ctl = typeof global.AbortController === 'function' ? new global.AbortController() : null;
    var timer = ctl ? global.setTimeout(function () { ctl.abort(); }, 120000) : null;
    function ende() { if (timer) global.clearTimeout(timer); }
    var kopf = {};
    if (token) kopf.Authorization = 'Bearer ' + token;
    if (bytes) kopf['Content-Type'] = 'application/octet-stream';
    return f(url, { method: methode, headers: kopf, body: bytes || undefined, signal: ctl ? ctl.signal : undefined }).then(function (r) {
      if (!r.ok) {
        return r.json().catch(function () { return null; }).then(function (j) { ende(); var e = new Error((j && j.error) || ('Antwort ' + r.status)); e.status = r.status; if (j && j.appZuAlt) e.appZuAlt = true; throw e; });
      }
      if (methode === 'GET') return r.arrayBuffer().then(function (b) { ende(); return { bytes: new Uint8Array(b), verschluesselt: r.headers.get('X-Verschluesselt') === '1' }; });
      return r.json().then(function (j) { ende(); return { json: j }; });
    }, function (e) { ende(); throw e; });
  }

  Daten.prototype.kontoBytes = function (methode, pfad, bytes) {
    var self = this;
    return this.rcGeraet().then(function (d) {
      var f = self.kontoBytesFn || kontoBytesStandard;
      return Promise.resolve().then(function () { return f(kontoUrlVon(d) + pfad, methode, d.kontoToken || '', bytes); }).then(
        function (r) { return Object.assign({ ok: true }, r); },
        function (e) { return { ok: false, fehler: MM.Konto.fehlerText(e), status: e && e.status }; });
    });
  };

  /* Bezahlen (seit 2.0.72): produkt = mittel, voll oder recherche5; weg = paypal (Antwort mit Adresse zum Bezahlen) oder ueberweisung (Antwort mit Bankdaten und Verwendungszweck).
     Der Dienst legt die Bestellung an, schaltet nach der Zahlung frei und schickt den Beleg. Die App speichert nichts davon. */
  Daten.prototype.kontoBestellen = function (produkt, weg, code) {
    var body = { produkt: produkt, weg: weg };
    if (code) body.code = code;
    return this.kontoSenden('POST', '/bezahlen/starten', body).then(function (r) {
      if (!r.ok) return { ok: false, fehler: r.fehler, abgelaufen: r.status === 401 };
      return Object.assign({}, r.json, { ok: true });
    });
  };

  /*
   * Gutscheincodes (seit 2.0.83, Festlegung des Nutzers 15.11.2026). Alle Regeln prüft der Dienst (Neukunde, Grenze, Ablauf, Stufe), die App zeigt nur an.
   * gutscheinPruefen: Rabattcode (1 bis 25 %) liefert die Preise, Geschenkcode (100 %) liefert Stufe, Laufzeit und neues Ende. Ändert nichts.
   * gutscheinEinloesen: nur für Geschenkcodes, schaltet ohne Zahlung frei.
   * Liste, Anlegen und Löschen dürfen nur Admins (der Dienst prüft die Rolle).
   */
  function codeAntwort(r) {
    if (!r.ok) return { ok: false, fehler: r.fehler, abgelaufen: r.status === 401 };
    return Object.assign({}, r.json, { ok: true });
  }
  Daten.prototype.gutscheinPruefen = function (code) {
    return this.kontoSenden('POST', '/gutschein/pruefen', { code: code }).then(codeAntwort);
  };
  Daten.prototype.gutscheinEinloesen = function (code) {
    return this.kontoSenden('POST', '/gutschein/einloesen', { code: code }).then(codeAntwort);
  };
  Daten.prototype.gutscheinListe = function () {
    var self = this;
    return dienstFrage(this, 'GET', '/gutschein/liste').then(function (j) {
      return { ok: true, codes: Array.isArray(j.codes) ? j.codes : [] };
    }, function (e) { return dienstFehlerAus(self, e); });
  };
  Daten.prototype.gutscheinAnlegen = function (roh) {
    var self = this, e = roh || {};
    var body = { prozent: e.prozent, laeuftAb: e.laeuftAb };
    ['code', 'stufe', 'monate', 'grenze', 'notiz', 'empfaenger'].forEach(function (k) { if (e[k] !== undefined && e[k] !== '') body[k] = e[k]; });
    return this.kontoSenden('POST', '/gutschein/anlegen', body).then(function (r) { return r.ok ? { ok: true, code: r.json.code, mail: typeof r.json.mail === 'boolean' ? r.json.mail : null } : freigabeFehler(self, r); });
  };
  Daten.prototype.gutscheinLoeschen = function (code) {
    var self = this;
    return this.kontoSenden('POST', '/gutschein/loeschen', { code: code }).then(function (r) { return r.ok ? { ok: true } : freigabeFehler(self, r); });
  };

  /*
   * Verwaltung (seit 2.0.94, Festlegung des Nutzers 15.11.2026): Statistik der Konten nach Stufe (Admin und Entwickler) und Zahlungseingänge buchen (nur Admins).
   * Alles prüft der Dienst anhand der Rolle; die App zeigt an und schickt die Wahl. Die Anmeldung der App genügt, ein zweites Passwort gibt es dafür nicht.
   */
  Daten.prototype.verwaltungStatistik = function () {
    var self = this;
    return dienstFrage(this, 'GET', '/verwaltung/statistik').then(function (j) {
      var z = function (n) { return typeof n === 'number' && isFinite(n) ? n : 0; };
      return { ok: true, stand: j.stand || '', konten: z(j.konten), test: z(j.test), mittel: z(j.mittel), voll: z(j.voll), entwickler: z(j.entwickler), basic: z(j.basic), abgelaufen: z(j.abgelaufen) };
    }, function (e) { return dienstFehlerAus(self, e); });
  };
  Daten.prototype.verwaltungBestellungen = function () {
    var self = this;
    return dienstFrage(this, 'GET', '/verwaltung/bestellungen').then(function (j) {
      return { ok: true, bestellungen: Array.isArray(j.bestellungen) ? j.bestellungen : [] };
    }, function (e) { return dienstFehlerAus(self, e); });
  };
  Daten.prototype.verwaltungBestaetigen = function (referenz) {
    var self = this;
    return this.kontoSenden('POST', '/verwaltung/bestaetigen', { referenz: referenz }).then(function (r) { return r.ok ? { ok: true, nummer: r.json.nummer, bis: r.json.bis } : freigabeFehler(self, r); });
  };
  Daten.prototype.verwaltungDirekt = function (email, produkt) {
    var self = this;
    return this.kontoSenden('POST', '/verwaltung/direkt', { email: email, produkt: produkt }).then(function (r) { return r.ok ? { ok: true, nummer: r.json.nummer, bis: r.json.bis } : freigabeFehler(self, r); });
  };
  Daten.prototype.verwaltungLoeschen = function (referenz) {
    var self = this;
    return this.kontoSenden('POST', '/verwaltung/loeschen', { referenz: referenz }).then(function (r) { return r.ok ? { ok: true } : freigabeFehler(self, r); });
  };

  /* Die Stufe des Kontos mit Grenzen und Verbrauch (seit 2.0.68, Schritt 13e). Gezählt wird beim Dienst. */
  Daten.prototype.kontoStufe = function () {
    var self = this;
    return this.kontoSenden('GET', '/konto/stufe').then(function (r) {
      if (!r.ok) return { ok: false, fehler: r.fehler, abgelaufen: r.status === 401 };
      var erg = { ok: true, stufe: r.json.stufe, grenzen: r.json.grenzen, nutzung: r.json.nutzung };
      /* Die Rolle (seit 2.0.73): Admin oder Entwickler sehen den Bereich „Nur für Entwickler“. Die App merkt sie sich im Geräte-Dokument. */
      var aend = { rolle: r.json.rolle === 'admin' || r.json.rolle === 'entwickler' ? r.json.rolle : null, rolleAm: self.jetzt() };
      erg.rolle = aend.rolle;
      /* Die Fahrzeug-Grenze merkt sich die App im Geräte-Dokument, damit sie auch ohne Netz gilt (seit 2.0.70). */
      var g = r.json.grenzen;
      if (g && (g.fahrzeuge === null || typeof g.fahrzeuge === 'number')) {
        aend.fahrzeugGrenze = g.fahrzeuge; aend.fahrzeugGrenzeStufe = (r.json.stufe && r.json.stufe.name) || null; aend.fahrzeugGrenzeAm = self.jetzt();
      }
      /* Smart Capture (seit 2.0.98): die Scan-Grenze der Stufe merkt sich die App, damit sie auch ohne Netz gilt (0 = nicht dabei, null = ohne Grenze). */
      if (g && (g.scans === null || typeof g.scans === 'number')) { aend.scanGrenze = g.scans; aend.scanGrenzeAm = self.jetzt(); }
      return self.rcSchreiben(aend).then(function () { return erg; }, function () { return erg; });
    });
  };

  /*
   * Smart Capture mit Lesedienst (seit 2.0.98, Festlegung des Nutzers 16.11.2026): Ohne Konto kein Smart Capture. Der Lesedienst (Google über den Konto-Dienst) gilt nur für bezahlte Stufen
   * (Grenze je Monat steht beim Dienst). Zustimmung: allgemein, einmalig mit Datum, widerrufbar (pro Gerät); vor jedem Scan kommt zusätzlich der Hinweis mit „Abbrechen“.
   * Die Erkennung auf dem Gerät ist die Notlösung bei erreichter Grenze, ohne Zustimmung und ohne Netz. Das Foto geht nie ins Gerätedokument und nie in die Sicherung.
   */
  Daten.prototype.lesedienstZustimmung = function () {
    return this.rcGeraet().then(function (d) {
      var liste = Array.isArray(d.lesedienstZustimmungen) ? d.lesedienstZustimmungen : [];
      var letzte = liste.length ? liste[liste.length - 1] : null;
      var gilt = !!(letzte && letzte.aktion === 'zugestimmt' && letzte.version === MM.Konto.LESEDIENST_VERSION);
      return { gilt: gilt, am: gilt ? letzte.am : null, verlauf: liste.slice() };
    });
  };
  function lesedienstSchreiben(self, aktion) {
    return self.rcGeraet().then(function (d) {
      var liste = (Array.isArray(d.lesedienstZustimmungen) ? d.lesedienstZustimmungen : []).slice(-19);
      liste.push({ aktion: aktion, am: self.jetzt(), version: MM.Konto.LESEDIENST_VERSION });
      return self.rcSchreiben({ lesedienstZustimmungen: liste });
    });
  }
  Daten.prototype.lesedienstZustimmen = function () { return lesedienstSchreiben(this, 'zugestimmt').then(function () { return { ok: true }; }); };
  Daten.prototype.lesedienstWiderrufen = function () { return lesedienstSchreiben(this, 'widerrufen').then(function () { return { ok: true }; }); };

  /*
   * Was ist für Smart Capture möglich? Gibt { modus, grund, ... } mit modus:
   *   'gesperrt'  kein Smart Capture (grund: 'anmeldung' ohne Konto oder abgelaufen, 'stufe' bei Basic oder Testwoche, 'unbekannt' wenn die Stufe nicht zu erfahren ist)
   *   'geraet'    nur Erkennung auf dem Gerät (grund: 'limit' im Monat aufgebraucht, 'zustimmung' nicht zugestimmt, 'offline')
   *   'google'    Lesedienst (frei = noch freie Scans, null = ohne Grenze)
   * Wirft nie.
   */
  Daten.prototype.lesedienstStatus = function () {
    var self = this, K = MM.Konto, dok = null, zu = null;
    return Promise.all([this.rcGeraet(), this.lesedienstZustimmung()]).then(function (r) {
      dok = r[0]; zu = r[1];
      if (!(dok.kontoToken && dok.kontoEmail)) return { modus: 'gesperrt', grund: 'anmeldung', text: K.TEXT_LESEN_OHNE_KONTO };
      return self.kontoStufe().then(function (s) {
        if (s.ok) {
          var g = s.grenzen ? s.grenzen.scans : 0;
          if (g === 0 || g === undefined) return { modus: 'gesperrt', grund: 'stufe', stufe: s.stufe && s.stufe.name, text: K.TEXT_LESEN_STUFE };
          var frei = K.scanFrei(s), n = s.nutzung || {};
          var basis = { stufe: s.stufe && s.stufe.name, grenze: g, genutzt: n.scans || 0, frei: frei, zugestimmt: zu.gilt, zugestimmtAm: zu.am };
          if (frei === 0) return Object.assign(basis, { modus: 'geraet', grund: 'limit', text: (s.stufe && s.stufe.id === 'test' ? 'Deine Scans der Testwoche sind aufgebraucht (' + basis.genutzt + ' von ' + g + '). MobiMory liest jetzt auf dem Gerät, das ist weniger genau. Mit Mittel oder Voll gibt es jeden Monat neue Scans.' : 'Deine Scans für diesen Monat sind aufgebraucht (' + basis.genutzt + ' von ' + g + '). MobiMory liest jetzt auf dem Gerät, das ist weniger genau. Ab dem 1. des Monats geht es wieder mit dem Lesedienst.') });
          if (!zu.gilt) return Object.assign(basis, { modus: 'geraet', grund: 'zustimmung', text: 'Ohne deine Zustimmung zum Lesedienst liest MobiMory auf dem Gerät. Das ist weniger genau.' });
          return Object.assign(basis, { modus: 'google', grund: null });
        }
        if (s.abgelaufen) return { modus: 'gesperrt', grund: 'anmeldung', text: 'Deine Anmeldung ist abgelaufen. Bitte melde dich neu an.' };
        /* Kein Netz oder der Dienst antwortet nicht: die zuletzt bekannte Stufe gilt, nur die Erkennung auf dem Gerät */
        var c = dok.scanGrenze;
        if (c === 0) return { modus: 'gesperrt', grund: 'stufe', text: K.TEXT_LESEN_STUFE };
        if (c === null || typeof c === 'number') return { modus: 'geraet', grund: 'offline', zugestimmt: zu.gilt, zugestimmtAm: zu.am, text: 'Der Lesedienst ist gerade nicht erreichbar. MobiMory liest auf dem Gerät, das ist weniger genau.' };
        return { modus: 'gesperrt', grund: 'unbekannt', text: 'Deine Stufe konnte nicht geprüft werden. Bitte verbinde dich einmal mit dem Netz.' };
      });
    }).then(null, function () { return { modus: 'gesperrt', grund: 'unbekannt', text: 'Deine Stufe konnte nicht geprüft werden.' }; });
  };

  /* Schickt ein Foto (JPEG als Base64, ohne Kopfzeile) zum Lesen. Nur nach Zustimmung. Wirft nie: { ok, antwort } oder { ok: false, fehler, art }. art: anmeldung, kontingent, dienst. */
  Daten.prototype.lesedienstSenden = function (base64) {
    var self = this;
    return this.lesedienstZustimmung().then(function (z) {
      if (!z.gilt) return { ok: false, art: 'zustimmung', fehler: 'Ohne deine Zustimmung wird kein Foto gesendet.' };
      return self.kontoSenden('POST', '/lesen/senden', { bild: base64, zustimmung: true }).then(function (r) {
        if (!r.ok) return { ok: false, fehler: r.fehler, art: r.status === 402 ? 'kontingent' : (r.status === 401 ? 'anmeldung' : 'dienst'), status: r.status };
        var j = r.json;
        if (!j || !Array.isArray(j.woerter)) return { ok: false, art: 'dienst', fehler: 'Die Antwort des Lesedienstes war nicht lesbar.' };
        return { ok: true, antwort: j };
      });
    });
  };

  /*
   * Rollen (seit 2.0.73, Festlegung des Nutzers 13.11.2026): Die Tabelle „rolle“ beim Dienst nennt zu jeder E-Mail-Adresse Name und Funktion
   * (Admin oder Entwickler). Admin und Entwickler sehen den Bereich „Nur für Entwickler“, ändern dürfen die Tabelle nur Admins (der Dienst prüft das).
   * Die App merkt sich die Rolle beim Anmelden und beim Öffnen der Stufe; gilt nur, solange das Gerät angemeldet ist.
   */
  Daten.prototype.rolle = function () {
    return this.rcGeraet().then(function (d) { return d.kontoToken && (d.rolle === 'admin' || d.rolle === 'entwickler') ? d.rolle : null; });
  };
  /* Fragt den Dienst höchstens alle 12 Stunden (oder mit erzwingen) nach der Rolle. Gibt { rolle, geaendert } zurück, wirft nie. */
  Daten.prototype.rolleAktualisieren = function (erzwingen) {
    var self = this, vorher = null;
    return this.rcGeraet().then(function (d) {
      if (!d.kontoToken) return { rolle: null, geaendert: false };
      vorher = d.kontoToken && (d.rolle === 'admin' || d.rolle === 'entwickler') ? d.rolle : null;
      var seit = Date.parse(d.rolleAm), jetzt = Date.parse(self.jetzt());
      if (!erzwingen && isFinite(seit) && isFinite(jetzt) && jetzt - seit >= 0 && jetzt - seit < 12 * 60 * 60 * 1000) return { rolle: vorher, geaendert: false };
      return self.kontoStufe().then(function (r) {
        if (!r.ok) return { rolle: vorher, geaendert: false };
        return { rolle: r.rolle, geaendert: r.rolle !== vorher };
      });
    }).then(null, function () { return { rolle: vorher, geaendert: false }; });
  };
  Daten.prototype.rollenListe = function () {
    var self = this;
    return dienstFrage(this, 'GET', '/rolle/liste').then(function (j) {
      return { ok: true, rollen: Array.isArray(j.rollen) ? j.rollen : [] };
    }, function (e) { return dienstFehlerAus(self, e); });
  };
  Daten.prototype.rolleSetzen = function (roh) {
    var self = this, e = roh || {};
    return this.kontoSenden('POST', '/rolle/setzen', { email: e.email, name: e.name, funktion: e.funktion }).then(function (r) { return r.ok ? { ok: true } : freigabeFehler(self, r); });
  };
  Daten.prototype.rolleEntfernen = function (email) {
    var self = this;
    return this.kontoSenden('POST', '/rolle/entfernen', { email: email }).then(function (r) { return r.ok ? { ok: true } : freigabeFehler(self, r); });
  };

  /*
   * Fahrzeug-Grenze der Stufe (seit 2.0.70, Festlegung des Nutzers 12.11.2026): Basic 1, Mittel 3, Voll und Entwickler unbegrenzt, Testwoche 3.
   * Gezählt werden alle nicht abgegebenen Fahrzeuge, auch die „Gehört zu“-Fahrzeuge (Beiboot, Anhänger). Ohne Konto gilt Basic.
   * Wer angemeldet ist, bekommt die Grenze vom Dienst; die App merkt sich den letzten Wert (ohne Netz gilt er weiter). Der Dienst wird nur
   * gefragt, wenn der gemerkte Wert die Anlage sperren würde (zum Beispiel direkt nach einem Wechsel der Stufe).
   * Nichts wird gelöscht oder gesperrt: Vorhandene Fahrzeuge bleiben, es kommt nur kein neues dazu.
   * anzahlNeu = wie viele Fahrzeuge dazukommen sollen. Gibt { ok: true } oder { ok: false, grenze, anzahl, frei, stufe, text } zurück.
   */
  Daten.prototype.fahrzeugGrenzePruefen = function (anzahlNeu) {
    var self = this, neu = anzahlNeu || 1;
    return Promise.all([this.fahrzeugListe(), this.rcGeraet()]).then(function (r) {
      /* Geliehene Fahrzeuge (seit 2.0.80) zählen nicht zur Grenze der Stufe. */
      var anzahl = r[0].filter(function (x) { return !x.fahrzeug.geliehen; }).length, d = r[1];
      var angemeldet = !!(d.kontoToken && d.kontoEmail);
      var grenze = angemeldet && d.fahrzeugGrenze !== undefined ? d.fahrzeugGrenze : MM.Daten.standardFahrzeuggrenze;
      var stufe = angemeldet && d.fahrzeugGrenzeStufe ? d.fahrzeugGrenzeStufe : 'Basic';
      function urteil(g, st) {
        if (g === null || anzahl + neu <= g) return { ok: true };
        return { ok: false, grenze: g, anzahl: anzahl, frei: Math.max(0, g - anzahl), stufe: st, text: grenzeText(g, anzahl, neu, st) };
      }
      var u = urteil(grenze, stufe);
      if (u.ok || !angemeldet) return u;
      return self.kontoStufe().then(function (s) {
        if (s.ok && s.grenzen && (s.grenzen.fahrzeuge === null || typeof s.grenzen.fahrzeuge === 'number')) return urteil(s.grenzen.fahrzeuge, (s.stufe && s.stufe.name) || stufe);
        return u;
      });
    });
  };

  function grenzeText(grenze, anzahl, neu, stufe) {
    var t = 'Mit der Stufe ' + stufe + (grenze === 1 ? ' ist 1 Fahrzeug' : ' sind ' + grenze + ' Fahrzeuge') + ' möglich. Du hast schon ' + anzahl + ' (Fahrzeuge, die zu einem anderen gehören, zählen mit, abgegebene nicht).';
    if (neu > 1) t += ' Die Datei enthält ' + neu + ' neue Fahrzeuge, es ' + (grenze - anzahl === 1 ? 'passt noch 1' : 'passen noch ' + Math.max(0, grenze - anzahl)) + '.';
    return t + ' Deine vorhandenen Fahrzeuge bleiben erhalten, es kommt nur kein neues dazu. Mehr Fahrzeuge gibt es mit einer höheren Stufe.';
  }

  /* Für die Anzeige: nie der Schlüssel der Anmeldung. */
  Daten.prototype.kontoEinstellung = function () {
    return this.rcGeraet().then(function (d) {
      return { dienstUrl: kontoUrlVon(d), eingerichtet: true, eigeneAdresse: !!d.kontoDienstUrl, angemeldet: !!(d.kontoToken && d.kontoEmail),
        email: d.kontoEmail || '', datenraumId: d.kontoDatenraumId || '', seit: d.kontoSeit || null };
    });
  };

  /* Adresse speichern. Eine andere Adresse beendet die Anmeldung auf diesem Gerät (der Schlüssel gilt nur beim alten Dienst). */
  Daten.prototype.kontoDienstSpeichern = function (roh) {
    var self = this;
    var u = MM.Konto.dienstAdresse(roh);
    if (!u.ok) return Promise.resolve({ ok: false, fehler: { dienstUrl: u.fehler } });
    return this.rcGeraet().then(function (d) {
      var aenderung = { kontoDienstUrl: u.url }, abgemeldet = false;
      if (kontoUrlVon(d) !== u.url && (d.kontoToken || d.kontoEmail)) {
        aenderung.kontoToken = null; aenderung.kontoEmail = null; aenderung.kontoDatenraumId = null; aenderung.kontoSeit = null; abgemeldet = true;
      }
      return self.rcSchreiben(aenderung).then(function () { return { ok: true, abgemeldet: abgemeldet }; });
    });
  };

  /* Fragt die Gesundheitsabfrage ab und sagt in Worten, was am Dienst noch fehlt. */
  Daten.prototype.kontoVerbindung = function () {
    var self = this;
    return this.rcGeraet().then(function (d) {
      return Promise.resolve().then(function () { return self.holeJson(kontoUrlVon(d) + '/gesundheit'); }).then(function (x) {
        if (!x || x.ok !== true || x.dienst !== 'mobimory-konto') return { ok: false, fehler: 'Unter dieser Adresse läuft kein Konto-Dienst von MobiMory.' };
        var fehlt = [];
        if (!x.datenbank) fehlt.push('die Datenbank ist nicht verbunden');
        else if (!x.tabellen) fehlt.push('die Tabellen in der Datenbank fehlen noch');
        if (!x.pepper) fehlt.push('das Geheimnis PASSWORT_PEPPER fehlt oder ist zu kurz');
        if (!x.mail && !x.entwicklung) fehlt.push('der E-Mail-Versand ist nicht eingerichtet');
        /* Der Abgleich ist ein Zusatz: Fehlt er, geht Anmelden trotzdem. „abgleich“ gibt es erst ab Dienst 13b. */
        var abgleichFehlt = x.abgleich !== true;
        return { ok: fehlt.length === 0, laeuft: true, version: x.version || '', entwicklung: !!x.entwicklung, fehlt: fehlt, abgleich: !abgleichFehlt,
          abgleichHinweis: abgleichFehlt ? (x.abgleich === undefined ? 'Der Dienst hat noch den Stand von Schritt 13a. Für den Abgleich und die Sicherung muss der neue Programmtext eingefügt werden und es müssen neue Tabellen angelegt werden (Anleitung zu 2.0.65).' : 'Für den Abgleich und die Sicherung fehlen im Dienst noch Tabellen in der Datenbank (SQL-Zeilen zu Schritt 13b).') : '',
          fehler: fehlt.length ? 'Der Dienst läuft, aber ' + fehlt.join(' und ') + '.' : '' };
      }, function () { return { ok: false, fehler: 'Der Dienst antwortet nicht. Prüfe die Adresse und das Netz.' }; });
    });
  };

  function kontoCodeAntwort(r) {
    if (!r.ok) return { ok: false, fehler: { allgemein: r.fehler, feld: r.feld || null } };
    return { ok: true, gueltigMinuten: r.json.gueltigMinuten || 10, entwicklungsCode: r.json.entwicklungsCode || null };
  }

  Daten.prototype.kontoRegistrieren = function (roh) {
    var self = this;
    roh = roh || {};
    var e = MM.Konto.email(roh.email), p = MM.Konto.passwort(roh.passwort), fehler = {};
    if (!e.ok) fehler.email = e.fehler;
    if (!p.ok) fehler.passwort = p.fehler;
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return this.kontoSenden('POST', '/konto/registrieren', { email: e.email, passwort: p.passwort }).then(function (r) { return kontoCodeAntwort(r); });
  };

  Daten.prototype.kontoCodeAnfordern = function (roh) {
    var e = MM.Konto.email((roh || {}).email);
    if (!e.ok) return Promise.resolve({ ok: false, fehler: { email: e.fehler } });
    return this.kontoSenden('POST', '/konto/code-anfordern', { email: e.email }).then(function (r) { return kontoCodeAntwort(r); });
  };

  /* Nach erfolgreicher Anmeldung (Passwort oder Code) merkt sich das Gerät Schlüssel, Adresse und Datenraum des Kontos. */
  Daten.prototype.kontoAnmeldungMerken = function (j) {
    var self = this;
    return this.rcSchreiben({ kontoToken: j.token, kontoEmail: j.email, kontoDatenraumId: j.datenraum && j.datenraum.id ? j.datenraum.id : null, kontoSeit: self.jetzt() })
      .then(function () { return { ok: true, email: j.email, passwortGesetzt: !!j.passwortGesetzt }; });
  };

  /* Name und Kennung dieses Geräts für den Konto-Dienst (seit 2.0.68). Die Kennung ist zufällig, bleibt auf dem Gerät und sorgt dafür, dass ein Gerät
     bei erneutem Anmelden nicht doppelt zählt (der Dienst begrenzt die Geräte je Stufe). */
  Daten.prototype.kontoGeraetName = function () {
    var self = this;
    return this.rcGeraet().then(function (d) {
      var id = d.kontoGeraetId;
      if (!/^[a-f0-9]{8}$/.test(id || '')) {
        var c = global.crypto, hex = '';
        if (c && typeof c.getRandomValues === 'function') { var a = new Uint8Array(4); c.getRandomValues(a); for (var i = 0; i < a.length; i++) hex += ('0' + a[i].toString(16)).slice(-2); }
        else { for (var k = 0; k < 8; k++) hex += Math.floor(Math.random() * 16).toString(16); }
        id = hex;
        return self.rcSchreiben({ kontoGeraetId: id }).then(function () { return 'MobiMory ' + MM.VERSION + ' #' + id; });
      }
      return 'MobiMory ' + MM.VERSION + ' #' + id;
    });
  };

  Daten.prototype.kontoCodePruefen = function (roh) {
    var self = this;
    roh = roh || {};
    var e = MM.Konto.email(roh.email), c = MM.Konto.code(roh.code), fehler = {};
    if (!e.ok) fehler.email = e.fehler;
    if (!c.ok) fehler.code = c.fehler;
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return this.kontoGeraetName().then(function (gn) { var b = { email: e.email, code: c.code, geraet: gn }; if (roh.aeltestesAbmelden === true) b.aeltestesAbmelden = true; return self.kontoSenden('POST', '/konto/code-pruefen', b); }).then(function (r) {
      if (!r.ok) { var f = {}; f[r.feld === 'code' ? 'code' : 'allgemein'] = r.fehler; return { ok: false, fehler: f, geraeteVoll: r.geraeteVoll, aeltestes: r.aeltestes }; }
      return self.kontoAnmeldungMerken(r.json);
    });
  };

  Daten.prototype.kontoAnmelden = function (roh) {
    var self = this;
    roh = roh || {};
    var e = MM.Konto.email(roh.email), fehler = {};
    var p = roh.passwort === null || roh.passwort === undefined ? '' : String(roh.passwort);
    if (!e.ok) fehler.email = e.fehler;
    if (!p) fehler.passwort = 'Bitte das Passwort eintragen.';
    if (Object.keys(fehler).length) return Promise.resolve({ ok: false, fehler: fehler });
    return this.kontoGeraetName().then(function (gn) { var b = { email: e.email, passwort: p, geraet: gn }; if (roh.aeltestesAbmelden === true) b.aeltestesAbmelden = true; return self.kontoSenden('POST', '/konto/anmelden', b); }).then(function (r) {
      if (!r.ok) return { ok: false, fehler: { allgemein: r.fehler }, geraeteVoll: r.geraeteVoll, aeltestes: r.aeltestes };
      return self.kontoAnmeldungMerken(r.json);
    });
  };

  /* Prüft, ob die Anmeldung noch gilt. Ist sie abgelaufen, geht die Anmeldung auf diesem Gerät weg. Ohne Netz bleibt alles, wie es ist. */
  Daten.prototype.kontoSitzungPruefen = function () {
    var self = this;
    return this.kontoEinstellung().then(function (e) {
      if (!e.angemeldet) return { ok: true, angemeldet: false };
      return self.kontoSenden('GET', '/konto/ich').then(function (r) {
        if (r.ok) return { ok: true, angemeldet: true, email: r.json.email, passwortGesetzt: !!r.json.passwortGesetzt };
        if (r.status === 401) {
          return self.rcSchreiben({ kontoToken: null, kontoEmail: null, kontoDatenraumId: null, kontoSeit: null }).then(function () { return { ok: true, angemeldet: false, abgelaufen: true, fehler: r.fehler }; });
        }
        return { ok: false, angemeldet: true, offline: !r.status, fehler: r.fehler };
      });
    });
  };

  Daten.prototype.kontoPasswortSetzen = function (roh) {
    var p = MM.Konto.passwort((roh || {}).passwort);
    if (!p.ok) return Promise.resolve({ ok: false, fehler: { passwort: p.fehler } });
    return this.kontoSenden('POST', '/konto/passwort-setzen', { passwort: p.passwort }).then(function (r) {
      return r.ok ? { ok: true } : { ok: false, fehler: { allgemein: r.fehler } };
    });
  };

  /* Abmelden geht immer: Auf dem Gerät wird die Anmeldung sofort entfernt, dem Dienst wird es nach Möglichkeit mitgeteilt. */
  Daten.prototype.kontoAbmelden = function () {
    var self = this;
    return this.kontoEinstellung().then(function (e) {
      if (!e.angemeldet) return { ok: true, serverAbgemeldet: false };
      return self.kontoSenden('POST', '/konto/abmelden').then(function (r) {
        MM.Geheim.vergessen();
        return self.rcSchreiben({ kontoToken: null, kontoEmail: null, kontoDatenraumId: null, kontoSeit: null, geheimWort: null }).then(function () { return { ok: true, serverAbgemeldet: !!r.ok }; });
      });
    });
  };

  /* Alarm-Nachrichten (seit 2.0.120): Dieses Gerät meldet sich beim Konto-Dienst für Push an, und eine Wache löst die Nachricht an alle anderen Geräte aus.
     Der Text ist allgemein (keine Position, kein Fahrzeug). Ohne Konto, ohne Netz oder bei älterem Dienst bleibt nur der Alarm am eigenen Gerät. */
  function schluesselAus(text) {
    var pad = '='.repeat((4 - text.length % 4) % 4), b = global.atob((text + pad).replace(/-/g, '+').replace(/_/g, '/'));
    var out = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) out[i] = b.charCodeAt(i); return out;
  }
  Daten.prototype.alarmSenden = function (info, versuch) {
    var self = this, n = versuch || 0;
    return Promise.all([this.rcGeraet(), this.geraetKennung()]).then(function (r) {
      if (!r[0] || !r[0].kontoToken) return { ok: false, fehler: 'Kein Konto angemeldet.' };
      return self.kontoSenden('POST', '/alarm/senden', { geraet: r[1], art: info && info.art }).then(function (x) {
        if (!x.ok && n < 3 && x.status !== 401 && x.status !== 404 && x.status !== 429) {
          global.setTimeout(function () { self.alarmSenden(info, n + 1); }, 30000);
        }
        return x.ok ? { ok: true, push: x.json.push, mail: x.json.mail, fehlerAnzahl: x.json.fehler || 0, grund: Array.isArray(x.json.grund) ? x.json.grund : [] } : { ok: false, fehler: x.fehler };
      });
    });
  };
  /* ---------- Fahrzeug wiederfinden (seit 2.0.132) ----------
   * Positionen gehen nur als Block hinaus, der mit dem Schlüsselwort verschlüsselt ist. Ohne Konto oder Schlüsselwort wird nichts gesendet. */
  Daten.prototype.wiederfindenBereit = function () {
    var self = this;
    return Promise.all([this.rcGeraet(), this.geheimWortGesetzt()]).then(function (r) {
      var konto = !!(r[0] && r[0].kontoToken), wort = !!r[1];
      return { ok: konto && wort, konto: konto, wort: wort };
    });
  };
  Daten.prototype.wachePositionSenden = function (paket, alarmAm) {
    var self = this;
    return this.wiederfindenBereit().then(function (b) {
      if (!b.konto) return { ok: false, fehler: 'Kein Konto angemeldet.' };
      if (!b.wort) return { ok: false, fehler: 'Kein Schlüsselwort auf diesem Gerät.' };
      return Promise.all([self.geheimSchluessel(), self.geraetKennung()]).then(function (r) {
        return MM.Geheim.verschluesseln(r[0], MM.Wiederfinden.aad(r[1]), JSON.stringify(paket)).then(function (block) {
          return self.kontoSenden('POST', '/wache/position', { geraet: r[1], alarmAm: alarmAm, daten: block });
        }).then(function (x) {
          if (x.ok) return { ok: true, beendet: !!x.json.beendet };
          return { ok: false, fehler: x.status === 404 ? 'Der Dienst ist noch nicht auf Stand 13i.' : x.fehler };
        });
      });
    }).catch(function () { return { ok: false, fehler: 'Die Position konnte nicht gesendet werden.' }; });
  };
  /* Die laufenden Alarme der anderen Geräte. paket ist null, wenn sich der Block hier nicht öffnen lässt (kein oder anderes Schlüsselwort). */
  Daten.prototype.wacheLagen = function () {
    var self = this;
    return this.rcGeraet().then(function (g) {
      if (!g || !g.kontoToken) return { ok: false, fehler: 'Kein Konto angemeldet.', lagen: [] };
      return Promise.all([self.kontoSenden('GET', '/wache/lage'), self.geraetKennung(), self.geheimSchluessel()]).then(function (r) {
        var x = r[0];
        if (!x.ok) return { ok: false, fehler: x.status === 404 ? 'Der Dienst ist noch nicht auf Stand 13i.' : x.fehler, lagen: [] };
        var fremd = (x.json.lagen || []).filter(function (l) { return l.geraet !== r[1]; });
        return Promise.all(fremd.map(function (l) {
          var offen = r[2] ? MM.Geheim.oeffnen(r[2], MM.Wiederfinden.aad(l.geraet), l.daten).then(MM.Wiederfinden.lesen, function () { return null; }) : Promise.resolve(null);
          return offen.then(function (p) { return { geraet: l.geraet, alarmAm: l.alarmAm, alterMs: Math.max(0, x.json.jetzt - l.am), paket: p }; });
        })).then(function (lagen) { return { ok: true, lagen: lagen }; });
      });
    }).catch(function () { return { ok: false, fehler: 'Die Lage konnte nicht geholt werden.', lagen: [] }; });
  };
  Daten.prototype.wacheFernBeenden = function (geraet, alarmAm) {
    return this.kontoSenden('POST', '/wache/beenden', { geraet: geraet, alarmAm: alarmAm }).then(function (x) {
      return x.ok ? { ok: true } : { ok: false, fehler: x.fehler };
    });
  };
  /* Test-Nachricht (seit 2.0.122): geht an die anderen angemeldeten Geräte, ohne E-Mail. Ein älterer Dienst kennt „test“ nicht und sendet dann einen echten Alarmtext. */
  Daten.prototype.testNachricht = function () {
    var self = this;
    return Promise.all([this.rcGeraet(), this.geraetKennung()]).then(function (r) {
      if (!r[0] || !r[0].kontoToken) return { ok: false, fehler: 'Kein Konto angemeldet.' };
      return self.kontoSenden('POST', '/alarm/senden', { geraet: r[1], test: true }).then(function (x) {
        return x.ok ? { ok: true, push: x.json.push, mail: false, fehlerAnzahl: x.json.fehler || 0, grund: Array.isArray(x.json.grund) ? x.json.grund : [] } : { ok: false, fehler: x.fehler };
      });
    });
  };
  /* Android-Hülle (seit 2.0.121): Adresse bei Firebase holen und als art „fcm“ beim Dienst anmelden. frageNach falsch = nur still erneuern, wenn schon erlaubt. */
  Daten.prototype.pushAnmeldenHuelle = function (frageNach) {
    var self = this, H = MM.Huelle;
    return Promise.all([this.kontoSenden('GET', '/push/schluessel'), this.geraetKennung()]).then(function (r) {
      if (!r[0].ok) return { ok: false, fehler: r[0].status === 404 ? 'Der Dienst kennt Push-Nachrichten noch nicht (Stand 13h nötig).' : r[0].fehler };
      if (!r[0].json.fcm) return { ok: false, fehler: 'Der Dienst hat noch keinen Firebase-Schlüssel (Geheimnis FCM_KONTO, server/EINRICHTUNG.md).' };
      return H.pushToken(frageNach !== false).then(function (t) {
        if (!t.ok) return { ok: false, fehler: t.fehler, erlaubt: t.erlaubt };
        return self.kontoSenden('POST', '/push/anmelden', { geraet: r[1], art: 'fcm', ziel: t.token }).then(function (x) {
          if (x.ok) self.rcSchreiben({ pushAngemeldetAm: Date.now(), pushArt: 'fcm' }).catch(function () { /* nur Anzeige */ });
          return x.ok ? { ok: true } : { ok: false, fehler: x.fehler };
        });
      });
    }).catch(function () { return { ok: false, fehler: 'Das Anmelden für Nachrichten hat nicht geklappt.' }; });
  };
  /* Beim Start der Hülle: Ist ein Konto da und die Erlaubnis schon erteilt, wird die Adresse still erneuert (sie kann sich ändern). */
  Daten.prototype.pushAuffrischen = function () {
    var self = this, H = MM.Huelle;
    if (!H || !H.istHuelle() || !H.pushVerfuegbar()) return Promise.resolve({ ok: false, uebersprungen: true });
    return this.rcGeraet().then(function (g) {
      if (!g || !g.kontoToken) return { ok: false, uebersprungen: true };
      return H.pushErlaubnis(false).then(function (st) {
        if (st !== 'granted') return { ok: false, uebersprungen: true };
        return self.pushAnmeldenHuelle(false);
      });
    }).catch(function () { return { ok: false }; });
  };
  /* Für die Anzeige auf der Wache-Seite: wann dieses Gerät sich zuletzt für Nachrichten angemeldet hat (nur lokal vermerkt). */
  Daten.prototype.pushStatus = function () {
    return this.rcGeraet().then(function (g) { return { angemeldetAm: (g && g.pushAngemeldetAm) || null, art: (g && g.pushArt) || null, konto: !!(g && g.kontoToken) }; });
  };
  Daten.prototype.pushAnmelden = function () {
    var self = this, nav = global.navigator;
    if (MM.Huelle && MM.Huelle.istHuelle()) return MM.Huelle.pushVerfuegbar() ? this.pushAnmeldenHuelle(true) : Promise.resolve({ ok: false, fehler: 'Die Nachrichten-Funktion fehlt in dieser App. Bitte die neueste APK installieren.' });
    if (!nav || !nav.serviceWorker || !global.PushManager || !global.Notification) return Promise.resolve({ ok: false, fehler: 'Dieser Browser kann keine Push-Nachrichten empfangen.' });
    return Promise.all([this.kontoSenden('GET', '/push/schluessel'), this.geraetKennung()]).then(function (r) {
      if (!r[0].ok) return { ok: false, fehler: r[0].status === 404 ? 'Der Dienst kennt Push-Nachrichten noch nicht (Stand 13h nötig).' : r[0].fehler };
      if (!r[0].json.vapid) return { ok: false, fehler: 'Der Dienst hat noch keinen Push-Schlüssel (server/EINRICHTUNG.md).' };
      return global.Notification.requestPermission().then(function (p) {
        if (p !== 'granted') return { ok: false, fehler: 'Benachrichtigungen sind für MobiMory nicht erlaubt.' };
        return nav.serviceWorker.ready.then(function (reg) {
          return reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: schluesselAus(r[0].json.vapid) });
        }).then(function (sub) {
          return self.kontoSenden('POST', '/push/anmelden', { geraet: r[1], art: 'web', ziel: sub.endpoint });
        }).then(function (x) {
          if (x.ok) self.rcSchreiben({ pushAngemeldetAm: Date.now(), pushArt: 'web' }).catch(function () { /* nur Anzeige */ });
          return x.ok ? { ok: true } : { ok: false, fehler: x.fehler };
        });
      });
    }).catch(function (e) { return { ok: false, fehler: 'Das Anmelden für Nachrichten hat nicht geklappt.' }; });
  };

  /* Geräteverwaltung (seit 2.0.117): die angemeldeten Geräte des Kontos und das Abmelden eines fremden Geräts.
     Ein Dienst ohne diese Wege (älterer Stand) antwortet 404: Dann sagt die App, dass der Dienst erst aktualisiert werden muss. */
  var GERAETE_ALT = 'Der Dienst kennt die Geräteliste noch nicht. Er muss auf den Stand von MobiMory 2.0.117 gebracht werden (server/EINRICHTUNG.md).';
  Daten.prototype.kontoGeraete = function () {
    return this.kontoSenden('GET', '/konto/geraete').then(function (r) {
      if (!r.ok) return { ok: false, fehler: r.status === 404 ? GERAETE_ALT : r.fehler, abgelaufen: r.status === 401 };
      return { ok: true, geraete: (r.json.geraete || []).map(function (g) { return { kennung: g.kennung, name: g.name, erstelltAm: g.erstelltAm, laeuftAb: g.laeuftAb, eigenes: !!g.eigenes }; }) };
    });
  };
  Daten.prototype.kontoGeraetAbmelden = function (kennung) {
    return this.kontoSenden('POST', '/konto/geraet-abmelden', { kennung: String(kennung || '') }).then(function (r) {
      if (!r.ok) return { ok: false, fehler: r.status === 404 && r.feld !== 'kennung' ? GERAETE_ALT : r.fehler, abgelaufen: r.status === 401 };
      return { ok: true };
    });
  };

  /* Löscht das Konto beim Dienst. Die Daten auf dem Gerät bleiben unberührt. Nur wenn der Dienst es bestätigt, geht auch die Anmeldung vom Gerät. */
  Daten.prototype.kontoLoeschen = function (roh) {
    var self = this;
    var w = MM.Konto.loeschWort((roh || {}).bestaetigung);
    if (!w.ok) return Promise.resolve({ ok: false, fehler: { bestaetigung: w.fehler } });
    return this.kontoSenden('POST', '/konto/loeschen', { bestaetigung: MM.Konto.LOESCH_WORT }).then(function (r) {
      if (!r.ok) return { ok: false, fehler: { allgemein: r.fehler } };
      MM.Geheim.vergessen();
      return self.rcSchreiben({ kontoToken: null, kontoEmail: null, kontoDatenraumId: null, kontoSeit: null, geheimWort: null }).then(function () { return { ok: true }; });
    });
  };

  /* ---------- Abgleich zwischen Geräten und Sicherung beim Dienst (Schritt 13b, seit 2.0.65) ----------
   * Abgleich: Jeder Datensatz der festgelegten Datenarten (MM.Abgleich) wird als Text zum Dienst geschickt, wenn er sich seit dem letzten
   * Abgleich geändert hat, und was auf anderen Geräten geändert wurde, wird geholt. Was lokal bleibt (Notizen, Nachweise, Scans, Fotos, GPS-Spur,
   * Kosten, Routen, Dokumente, Einstellungen), verlässt das Gerät nicht. Der Stand des Abgleichs liegt im Geräte-Dokument („abgleich“, nicht in der Sicherung):
   *   { epoche, seit, zustand: { 'tabelle/id': { h: Abdruck, s: Nummer beim Dienst, g: 1 wenn gelöscht } }, letzter, konflikte: [...] }
   * Konfliktregeln (festgelegt in 2.0.65):
   *   1. Änderungsverläufe und Einträge sind „nur anhängen“: beide Geräte behalten alles, der zuletzt gemachte Eintrag gilt, die Nummern werden nach der Zeit neu vergeben.
   *   2. Ein anderer Datensatz, der auf zwei Geräten geändert wurde: Es gilt der Stand, der zuerst beim Dienst war. Die eigene Fassung wird aufgehoben und kann wieder eingesetzt werden.
   *   3. Gelöscht auf einem Gerät, geändert auf dem anderen: Der geänderte Datensatz bleibt.
   * Ohne Netz und ohne Konto ändert sich nichts. Der Abgleich ist nur auf Knopfdruck. */

  var ABGLEICH_UEBERLAPP = 100;
  var ABGLEICH_MAX_DURCHGAENGE = 3;

  /* ---------- Schlüsselwort für die empfindlichen Angaben (seit 2.0.119) ----------
   * Das Wort wird einmal je Gerät eingegeben und bleibt im Geräte-Dokument („geheimWort“, nicht in der Sicherung, nicht beim Dienst). Daraus entsteht der Schlüssel
   * (MM.Geheim). Ohne Wort bleiben Notizen, Telefon, E-Mail, Adressen, Nachweis-Nummern und GPS-Spur auf dem Gerät. Vergisst der Nutzer das Wort und hat kein Gerät mehr
   * mit gespeichertem Wort, sind diese Angaben beim Dienst nicht mehr zu öffnen. */
  Daten.prototype.geheimWortGesetzt = function () {
    return this.rcGeraet().then(function (d) { return typeof d.geheimWort === 'string' && d.geheimWort.length >= MM.Geheim.MIN_LAENGE; });
  };
  Daten.prototype.geheimWortSetzen = function (wort) {
    var self = this;
    if (typeof wort !== 'string' || wort.length < MM.Geheim.MIN_LAENGE) return Promise.resolve({ ok: false, fehler: { schluesselwort: 'Das Schlüsselwort braucht mindestens ' + MM.Geheim.MIN_LAENGE + ' Zeichen.' } });
    if (wort.length > 200) return Promise.resolve({ ok: false, fehler: { schluesselwort: 'Das Schlüsselwort ist zu lang (höchstens 200 Zeichen).' } });
    MM.Geheim.vergessen();
    return this.rcSchreiben({ geheimWort: wort }).then(function () { return { ok: true }; });
  };
  Daten.prototype.geheimWortEntfernen = function () {
    MM.Geheim.vergessen();
    return this.rcSchreiben({ geheimWort: null }).then(function () { return { ok: true }; });
  };
  /* Der Schlüssel zum gespeicherten Wort, oder null (kein Wort, nicht angemeldet). */
  Daten.prototype.geheimSchluessel = function () {
    return this.rcGeraet().then(function (d) {
      if (typeof d.geheimWort !== 'string' || d.geheimWort.length < MM.Geheim.MIN_LAENGE || !d.kontoToken || !d.kontoDatenraumId) return null;
      return MM.Geheim.schluessel(d.geheimWort, d.kontoDatenraumId);
    });
  };

  function abgleichLeer() { return { epoche: null, seit: 0, zustand: {}, letzter: null, konflikte: [], dateien: { epoche: null, oben: {}, gps: {} } }; }

  Daten.prototype.abgleichLesen = function () {
    return this.rcGeraet().then(function (d) {
      var a = d.abgleich;
      return a && typeof a === 'object' ? Object.assign(abgleichLeer(), a) : abgleichLeer();
    });
  };

  /* Alle lokalen Datensätze der Abgleich-Tabellen in der Form für den Dienst. karte: { 'tabelle/id': { x, rec } }
   * schl: der Schlüssel zum Schlüsselwort (MM.Geheim) oder null. Mit Schlüssel gehen die empfindlichen Angaben als verschlüsselter Block mit, ohne bleiben
   * sie auf dem Gerät („ohneWort“ zählt die Datensätze, die dann etwas zurückhalten). Ein Datensatz mit ungeöffnetem Block („geheim“) schickt den Block unverändert zurück. */
  function abgleichLokal(self, schl) {
    var namen = MM.Abgleich.tabellenListe();
    return Promise.all(namen.map(function (n) { return self.speicher.alle(n); })).then(function (r) {
      var plan = [], bloecke = {};
      function offenerBlock(rec) { return typeof rec.geheim === 'string' && rec.geheim; }
      if (schl) {
        namen.forEach(function (n, i) {
          r[i].forEach(function (rec) { if (offenerBlock(rec)) return; var gt = MM.Abgleich.geheimTeil(n, rec); if (gt) plan.push(gt); });
        });
      }
      return Promise.all(plan.map(function (gt) {
        return MM.Geheim.verschluesseln(schl, gt.aad, gt.text).then(function (b) { bloecke[gt.aad + '\u0000' + gt.text] = b; });
      })).then(function () {
        var karte = {}, zuGross = 0, verschlossen = 0, ohneWort = 0;
        namen.forEach(function (n, i) {
          r[i].forEach(function (rec) {
            var block;
            if (offenerBlock(rec)) { block = rec.geheim; verschlossen++; }
            else {
              var gt = MM.Abgleich.geheimTeil(n, rec);
              if (gt) { if (schl) block = bloecke[gt.aad + '\u0000' + gt.text]; else ohneWort++; }
            }
            var x = MM.Abgleich.fuerDienst(n, rec, self.datenraumId, block);
            if (!x) return;
            if (x.zuGross) { zuGross++; return; }
            karte[MM.Abgleich.schluessel(x.tabelle, x.id)] = { x: x, rec: rec };
          });
        });
        return { karte: karte, zuGross: zuGross, verschlossen: verschlossen, ohneWort: ohneWort };
      });
    });
  }

  function dienstFrage(self, methode, pfad, body) {
    return self.kontoSenden(methode, pfad, body).then(function (r) {
      if (r.ok) return r.json;
      var e = new Error(r.fehler); e.status = r.status; e.art = r.art; throw e;
    });
  }

  /* Nach einem Fehler: Ist die Anmeldung abgelaufen, geht sie auf diesem Gerät weg. */
  function dienstFehlerAus(self, e) {
    var text = e && e.message ? e.message : 'Der Dienst hat nicht geantwortet.';
    if (e && e.status === 401) {
      return self.rcSchreiben({ kontoToken: null, kontoEmail: null, kontoDatenraumId: null, kontoSeit: null }).then(function () { return { ok: false, abgelaufen: true, fehler: { allgemein: 'Deine Anmeldung ist abgelaufen. Bitte melde dich neu an.' } }; });
    }
    return Promise.resolve({ ok: false, offline: !(e && e.status), fehler: { allgemein: text } });
  }

  /* Was würde der Abgleich tun? Zahlen für die Anzeige, ohne etwas zu senden. */
  Daten.prototype.abgleichUebersicht = function () {
    var self = this;
    return this.geheimSchluessel().then(function (schl) {
      return Promise.all([self.abgleichLesen(), abgleichLokal(self, schl), self.geheimWortGesetzt()]);
    }).then(function (r) {
      var a = r[0], karte = r[1].karte, offen = 0, geloescht = 0;
      Object.keys(karte).forEach(function (k) { var z = a.zustand[k]; if (!z || z.h !== karte[k].x.abdruck) offen++; });
      Object.keys(a.zustand).forEach(function (k) { if (!karte[k] && !a.zustand[k].g) geloescht++; });
      return { letzter: a.letzter, offen: offen, geloescht: geloescht, vorhanden: Object.keys(karte).length, zuGross: r[1].zuGross, konflikte: a.konflikte.length,
        wortGesetzt: r[2], verschlossen: r[1].verschlossen, ohneWort: r[1].ohneWort, automatisch: a.automatisch,
        arten: MM.Abgleich.zusammenfassung(Object.keys(karte).map(function (k) { return karte[k].x; })) };
    });
  };

  Daten.prototype.abgleichKonflikte = function () {
    return this.abgleichLesen().then(function (a) {
      return a.konflikte.map(function (k, i) { return { nr: i, art: MM.Abgleich.TABELLEN_NAMEN[k.tabelle] || k.tabelle, tabelle: k.tabelle, id: k.id, am: k.am, text: k.text || '' }; });
    });
  };

  /* Die eigene Fassung wieder einsetzen. Beim nächsten Abgleich geht sie zum Dienst. */
  Daten.prototype.abgleichKonfliktEinsetzen = function (nr, behalten) {
    var self = this;
    return this.abgleichLesen().then(function (a) {
      var k = a.konflikte[nr];
      if (!k) return { ok: false, fehler: { allgemein: 'Diese Fassung gibt es nicht mehr.' } };
      var rest = a.konflikte.filter(function (x, i) { return i !== nr; });
      var schreiben = behalten ? Promise.resolve() : self.speicher.speichern(k.tabelle, k.rec);
      return schreiben.then(function () { a.konflikte = rest; return self.rcSchreiben({ abgleich: a }); }).then(function () { return { ok: true }; });
    });
  };

  /* Läuft der Abgleich, ruft er „fortschritt(text)“ auf. Ergebnis: { ok, gesendet, geholt, geloescht, konflikte, uebersprungen } oder { ok: false, fehler } */
  Daten.prototype.abgleichAusfuehren = function (fortschritt) {
    var self = this;
    var melde = typeof fortschritt === 'function' ? fortschritt : function () {};
    if (this.abgleichLaeuft) return Promise.resolve({ ok: false, fehler: { allgemein: 'Der Abgleich läuft schon.' } });
    var summe = { gesendet: 0, geholt: 0, geloescht: 0, konflikte: 0, uebersprungen: 0, zuGross: 0, verschlossen: 0, geoeffnet: 0, ohneWort: 0, falschesWort: false, wortGesetzt: false, dateiAngaben: 0 };
    var a = null, merke = null, erneut = false, schl = null;

    /* Die verschlüsselten Blöcke einer Liste vom Dienst öffnen (nur, wenn ein Schlüssel da ist). Ergebnis je Eintrag in „geheimErg“. */
    function entschluesseln(liste) {
      return Promise.all((liste || []).map(function (ein) {
        if (ein.geloescht) return null;
        var b = MM.Abgleich.geheimBlock(ein.nutzlast);
        if (!b) return null;
        if (!schl) { ein.geheimErg = { ok: false }; return null; }
        return MM.Geheim.oeffnen(schl, ein.tabelle + '/' + ein.id, b).then(function (t) { ein.geheimErg = MM.Abgleich.blockLesen(t); }, function (e) {
          ein.geheimErg = { ok: false };
          if (e && e.code === 'schluessel') summe.falschesWort = true;
        });
      }));
    }

    function speichereStand() { return self.rcSchreiben({ abgleich: a }); }
    function konfliktMerken(tabelle, id, rec, jetzt) {
      if (tabelle === 'verlaeufe' || !rec) return;
      var namen = MM.Abgleich.TABELLEN_NAMEN[tabelle] || tabelle;
      var t = rec.bezeichnung || (rec.werte && rec.werte.bezeichnung) || rec.datum || '';
      a.konflikte.push({ tabelle: tabelle, id: id, am: jetzt, rec: rec, text: namen + (t ? ': ' + t : '') });
      if (a.konflikte.length > MM.Abgleich.MAX_KONFLIKTE) a.konflikte = a.konflikte.slice(-MM.Abgleich.MAX_KONFLIKTE);
      summe.konflikte++;
    }

    /* Einen Datensatz vom Dienst übernehmen (oder bei Konflikt die eigene Fassung aufheben). schreiben/loeschen: Sammler. */
    function vomDienstUebernehmen(ein, lok, schreiben, loeschen, jetzt, konflikt) {
      var key = MM.Abgleich.schluessel(ein.tabelle, ein.id), z = a.zustand[key];
      if (ein.geloescht) {
        if (!lok) { a.zustand[key] = { h: '', s: ein.seq, g: 1 }; return; }
        if (z && !z.g && z.h === lok.x.abdruck) { loeschen.push({ tabelle: ein.tabelle, id: ein.id }); a.zustand[key] = { h: '', s: ein.seq, g: 1 }; summe.geloescht++; return; }
        /* Hier wurde etwas geändert, dort gelöscht: Der geänderte Datensatz bleibt und geht beim nächsten Durchgang wieder hinaus. */
        a.zustand[key] = { h: '', s: ein.seq }; erneut = true;
        return;
      }
      var hDienst = MM.Abgleich.abdruck(ein.nutzlast);
      if (lok && lok.x.abdruck === hDienst) { a.zustand[key] = { h: hDienst, s: ein.seq }; return; }
      var rec;
      try { rec = MM.Abgleich.vonDienst(ein.tabelle, ein.nutzlast, self.datenraumId, lok ? lok.rec : null, ein.geheimErg); } catch (e) { summe.uebersprungen++; return; }
      if (ein.geheimErg && !ein.geheimErg.ok) summe.verschlossen++;
      if (MM.Abgleich.DATEI_TABELLEN.indexOf(ein.tabelle) >= 0) summe.dateiAngaben++;
      if (lok && (konflikt || !(z && !z.g && z.h === lok.x.abdruck))) konfliktMerken(ein.tabelle, ein.id, lok.rec, jetzt);
      schreiben.push({ tabelle: ein.tabelle, objekt: rec });
      a.zustand[key] = { h: hDienst, s: ein.seq };
      summe.geholt++;
    }

    function anwenden(schreiben, loeschen) {
      var p = Promise.resolve(), vor = self.speicher.aenderungen;
      if (schreiben.length) p = p.then(function () { return self.speicher.mehrereSpeichern(schreiben); });
      if (loeschen.length) p = p.then(function () { return self.speicher.mehrereLoeschen(loeschen); });
      /* Was der Abgleich selbst schreibt, ist keine Änderung des Nutzers (der automatische Abgleich soll danach nicht gleich wieder laufen). */
      return p.then(function () { if (typeof vor === 'number') self.speicher.aenderungen = vor; });
    }

    /* Senden: alles, was sich seit dem letzten Abgleich geändert hat. */
    function senden() {
      return abgleichLokal(self, schl).then(function (l) {
        summe.zuGross = l.zuGross; summe.ohneWort = l.ohneWort;
        var liste = [], karte = l.karte;
        Object.keys(karte).forEach(function (k) {
          var z = a.zustand[k], x = karte[k].x;
          if (!z || z.h !== x.abdruck) liste.push({ key: k, tabelle: x.tabelle, id: x.id, basis: z ? z.s : 0, nutzlast: x.nutzlast, abdruck: x.abdruck });
        });
        Object.keys(a.zustand).forEach(function (k) {
          var z = a.zustand[k];
          if (!karte[k] && !z.g) { var t = k.split('/'); liste.push({ key: k, tabelle: t[0], id: t.slice(1).join('/'), basis: z.s, geloescht: true }); }
        });
        /* Pakete: höchstens SENDE_PAKET Datensätze und höchstens MAX_PAKET_BYTES Text (Routen und Reisechecks können groß sein). */
        var pakete = [], akt = [], aktBytes = 0, schonGezaehlt = 0, davor = [];
        liste.forEach(function (p) {
          var gr = (p.nutzlast ? p.nutzlast.length : 0) + 200;
          if (akt.length && (akt.length >= MM.Abgleich.SENDE_PAKET || aktBytes + gr > MM.Abgleich.MAX_PAKET_BYTES)) { pakete.push(akt); davor.push(schonGezaehlt); schonGezaehlt += akt.length; akt = []; aktBytes = 0; }
          akt.push(p); aktBytes += gr;
        });
        if (akt.length) { pakete.push(akt); davor.push(schonGezaehlt); }
        var gesendet = 0, nochmal = false, kette = Promise.resolve();
        pakete.forEach(function (paket, pi) {
          kette = kette.then(function () {
            melde('Senden: ' + Math.min(liste.length, davor[pi] + paket.length) + ' von ' + liste.length + ' …');
            return dienstFrage(self, 'POST', '/abgleich/senden', { eintraege: paket.map(function (p) { return p.geloescht ? { tabelle: p.tabelle, id: p.id, basis: p.basis, geloescht: true } : { tabelle: p.tabelle, id: p.id, basis: p.basis, nutzlast: p.nutzlast }; }) }).then(function (r) {
              return entschluesseln(r.konflikte).then(function () { return r; });
            }).then(function (r) {
              var nach = {}; paket.forEach(function (p) { nach[p.key] = p; });
              r.angenommen.forEach(function (x) {
                var p = nach[MM.Abgleich.schluessel(x.tabelle, x.id)];
                a.zustand[p.key] = p.geloescht ? { h: '', s: x.seq, g: 1 } : { h: p.abdruck, s: x.seq };
                gesendet++;
              });
              var schreiben = [], loeschen = [];
              (r.konflikte || []).forEach(function (c) {
                var key = MM.Abgleich.schluessel(c.tabelle, c.id), p = nach[key];
                if (!p) return;
                if (c.geloescht) {
                  if (p.geloescht) { a.zustand[key] = { h: '', s: c.seq, g: 1 }; return; }
                  a.zustand[key] = { h: '', s: c.seq }; nochmal = true; return;
                }
                if (!p.geloescht && MM.Abgleich.abdruck(c.nutzlast) === p.abdruck) { a.zustand[key] = { h: p.abdruck, s: c.seq }; return; }
                /* Der Dienst hat einen anderen Stand: Er gilt, die eigene Fassung wird aufgehoben. */
                vomDienstUebernehmen({ tabelle: c.tabelle, id: c.id, seq: c.seq, geloescht: false, nutzlast: c.nutzlast }, karte[key] || null, schreiben, loeschen, self.jetzt(), true);
              });
              return anwenden(schreiben, loeschen);
            });
          }).then(function () { if (pi % 10 === 9) return speichereStand(); });
        });
        return kette.then(function () { summe.gesendet += gesendet; return { gesendet: gesendet, nochmal: nochmal }; });
      });
    }

    /* Holen: alles, was auf anderen Geräten dazugekommen ist. */
    function holen() {
      return abgleichLokal(self, schl).then(function (l) {
        var karte = l.karte, seit = Math.max(0, a.seit - ABGLEICH_UEBERLAPP), neueVerlaeufe = false, jetzt = self.jetzt();
        function seite() {
          melde('Holen …');
          return dienstFrage(self, 'GET', '/abgleich/aenderungen?seit=' + seit).then(function (r) {
            return entschluesseln(r.eintraege).then(function () { return r; });
          }).then(function (r) {
            var schreiben = [], loeschen = [];
            r.eintraege.forEach(function (ein) {
              var key = MM.Abgleich.schluessel(ein.tabelle, ein.id), z = a.zustand[key];
              if (z && z.s === ein.seq) return;
              if (ein.tabelle === 'verlaeufe') neueVerlaeufe = true;
              vomDienstUebernehmen(ein, karte[key] || null, schreiben, loeschen, jetzt);
            });
            return anwenden(schreiben, loeschen).then(function () {
              if (r.weiter) { seit = r.bis; return speichereStand().then(seite); }
              a.seit = Math.max(r.bis, r.seq);
            });
          });
        }
        return seite().then(function () { return neueVerlaeufe; });
      });
    }

    /* Doppelte Nummern im Verlauf nach der Zeit neu vergeben (Regel 1). Gibt zurück, ob etwas geändert wurde. */
    function nummernPruefen() {
      var tabellen = Object.keys(MM.Abgleich.NUMMERN_TABELLEN), alle = false;
      return Promise.all(tabellen.map(function (t) { return self.speicher.alle(t); })).then(function (r) {
        var schreiben = [];
        tabellen.forEach(function (t, i) {
          var liste = t === 'verlaeufe' ? r[i].filter(function (e) { return MM.Abgleich.VERLAUF_TYPEN.indexOf(e.objektTyp) >= 0; }) : r[i];
          MM.Abgleich.nummernNeu(liste, MM.Abgleich.NUMMERN_TABELLEN[t]).forEach(function (e) { schreiben.push({ tabelle: t, objekt: e }); });
        });
        if (!schreiben.length) return false;
        return self.speicher.mehrereSpeichern(schreiben).then(function () { return true; });
      });
    }

    /* Passt das Wort zu dem, mit dem die anderen Geräte verschlüsselt haben? Das erste Gerät legt eine Prüfung beim Dienst ab („wortpruefung“). */
    function wortPruefen() {
      if (!schl) return Promise.resolve();
      return self.speicher.holen('einstellungen', MM.Abgleich.EINSTELLUNG_PRUEFUNG).then(function (d) {
        if (!d || typeof d.pruefung !== 'string') {
          return MM.Geheim.verschluesseln(schl, MM.Abgleich.EINSTELLUNG_PRUEFUNG, MM.Abgleich.PRUEFTEXT).then(function (b) {
            return self.speicher.speichern('einstellungen', { id: MM.Abgleich.EINSTELLUNG_PRUEFUNG, pruefung: b, erstelltAm: self.jetzt() });
          });
        }
        return MM.Geheim.oeffnen(schl, MM.Abgleich.EINSTELLUNG_PRUEFUNG, d.pruefung).then(function (t) {
          if (t !== MM.Abgleich.PRUEFTEXT) { summe.falschesWort = true; schl = null; }
        }, function () { summe.falschesWort = true; schl = null; });
      }).then(function () { if (summe.falschesWort) schl = null; });
    }

    /* Datensätze, die noch mit ungeöffnetem Block hier liegen (ohne Wort geholt), öffnen, sobald das Wort da ist und passt. */
    function oeffnenLokal() {
      if (!schl) return Promise.resolve();
      var namen = MM.Abgleich.tabellenListe();
      return Promise.all(namen.map(function (n) { return self.speicher.alle(n); })).then(function (r) {
        var jobs = [];
        namen.forEach(function (n, i) { r[i].forEach(function (rec) { if (typeof rec.geheim === 'string' && rec.geheim) jobs.push({ n: n, rec: rec }); }); });
        if (!jobs.length) return null;
        var schreiben = [], jetzt = self.jetzt();
        return Promise.all(jobs.map(function (j) {
          return MM.Geheim.oeffnen(schl, j.n + '/' + j.rec.id, j.rec.geheim).then(function (t) {
            var g = MM.Abgleich.blockLesen(t);
            if (!g.ok) return;
            /* Hat der Nutzer ohne Wort an diesem Datensatz Empfindliches eingetragen, bleibt seine Fassung unter „Konflikte“ erhalten. */
            if (MM.Abgleich.hatPrivates(j.n, j.rec)) konfliktMerken(j.n, j.rec.id, j.rec, jetzt);
            var x = MM.Abgleich.fuerDienst(j.n, j.rec, self.datenraumId, j.rec.geheim);
            if (!x) return;
            schreiben.push({ tabelle: j.n, objekt: MM.Abgleich.vonDienst(j.n, x.nutzlast, self.datenraumId, j.rec, g) });
            summe.geoeffnet++;
          }, function (e) { if (e && e.code === 'schluessel') summe.falschesWort = true; });
        })).then(function () { return anwenden(schreiben, []); });
      });
    }

    function durchgang(n) {
      var vorab = n === 1 && schl ? holen().then(wortPruefen).then(oeffnenLokal) : Promise.resolve();
      return vorab.then(senden).then(function (s) {
        return holen().then(function (neueVerlaeufe) {
          return nummernPruefen().then(function (geaendert) {
            var nochEinmal = geaendert || s.nochmal || erneut;
            erneut = false;
            if (nochEinmal && n < ABGLEICH_MAX_DURCHGAENGE) return speichereStand().then(function () { return durchgang(n + 1); });
          });
        });
      });
    }

    this.abgleichLaeuft = true;
    return this.kontoEinstellung().then(function (e) {
      if (!e.angemeldet) return { ok: false, fehler: { allgemein: 'Bitte zuerst anmelden (Funktionen › Konto).' } };
      return Promise.all([self.abgleichLesen(), dienstFrage(self, 'GET', '/abgleich/stand'), self.geheimSchluessel()]).then(function (r) {
        a = r[0]; merke = r[1]; schl = r[2]; summe.wortGesetzt = !!schl;
        if (a.epoche !== merke.epoche) { a.epoche = merke.epoche; a.seit = 0; a.zustand = {}; a.verschlossen = 0; }
        return durchgang(1);
      }).then(function () {
        a.letzter = self.jetzt();
        a.automatisch = merke.automatisch === true;
        return speichereStand().then(function () { return Object.assign({ ok: true, letzter: a.letzter, automatisch: merke.automatisch === true }, summe); });
      }, function (err) {
        var rest = a ? speichereStand().catch(function () {}) : Promise.resolve();
        return rest.then(function () { return dienstFehlerAus(self, err); });
      });
    }).then(function (res) { self.abgleichLaeuft = false; return res; }, function (err) { self.abgleichLaeuft = false; throw err; });
  };

  /* ---------- Automatischer Abgleich (seit 2.0.119) ----------
   * Festlegung des Nutzers (20.11.2026): Testwoche, Mittel und Voll gleichen von allein ab, Basic nur von Hand (Knopf). Der erste Abgleich auf einem Gerät ist von Hand.
   * Gesendet wird nur nach einer Änderung (kurz danach, mehrere Änderungen gebündelt), nachgefragt wird alle 60 Sekunden nur „gibt es einen neueren Stand?“ (eine Zahl).
   * Nicht mitten in einem offenen Formular, nicht bei verstecktem Fenster, nicht ohne Netz, nie zwei Läufe übereinander. Die GPS-Spur löst keinen Lauf aus,
   * sie geht mit, wenn ein Lauf stattfindet. Der Takt kommt von außen (MM.Ansicht): abgleichAutomatikTakt wird alle paar Sekunden gerufen.
   * opt: { jetztMs, formularOffen, sichtbar, online, sofort }. Ergebnis: { lief: false, grund } oder { lief: true, ergebnis, dateien } */
  var AUTO_RUHE_MS = 15 * 1000;
  var AUTO_TAKT_MS = 60 * 1000;
  var AUTO_VOLL_MS = 5 * 60 * 1000;

  Daten.prototype.abgleichAutomatikTakt = function (opt) {
    var self = this;
    opt = opt || {};
    var jetzt = typeof opt.jetztMs === 'number' ? opt.jetztMs : Date.now();
    var au = this.auto = this.auto || { zaehler: null, aenderungAm: 0, offen: false, abfrageAm: -Infinity, vollAm: jetzt, gpsOffen: true };
    function nein(grund) { return Promise.resolve({ lief: false, grund: grund }); }
    if (this.abgleichLaeuft || this.dateienLaeuft || this.autoLaeuft) return nein('laeuft');
    if (opt.sichtbar === false) return nein('unsichtbar');
    if (opt.online === false) return nein('offline');
    var z = this.speicher.aenderungen || 0;
    if (au.zaehler !== z) { au.zaehler = z; au.aenderungAm = jetzt; au.offen = true; }
    var lokalFaellig = au.offen && jetzt - au.aenderungAm >= AUTO_RUHE_MS;
    var abfrageFaellig = !!opt.sofort || jetzt - au.abfrageAm >= AUTO_TAKT_MS;
    /* Seit 2.0.120: Neue GPS-Daten gehen im Takt der Abfrage mit (nicht erst beim Ausblenden), und solange ein Cockpit mit GPS offen ist, wird im selben Takt auch geschaut,
       ob ein anderes Gerät eine neuere Spur geschickt hat. Der Abgleich der Daten selbst läuft weiter nur bei Änderungen. */
    if (abfrageFaellig && (this.gpsGeaendert || this.gpsAktiv)) { au.gpsOffen = true; this.gpsGeaendert = false; }
    if (!lokalFaellig && !abfrageFaellig) return nein('nichts faellig');
    if (opt.formularOffen) return nein('formular');
    this.autoLaeuft = true;
    function fertig(x) { self.autoLaeuft = false; return x; }
    return this.rcGeraet().then(function (d) {
      var a = d.abgleich;
      if (!d.kontoToken || !d.kontoEmail) return { lief: false, grund: 'nicht angemeldet' };
      if (!a || !a.letzter || !a.epoche) return { lief: false, grund: 'erster Abgleich von Hand' };
      if (a.automatisch === false && !abfrageFaellig) return { lief: false, grund: 'basic' };
      return dienstFrage(self, 'GET', '/abgleich/stand').then(function (st) {
        au.abfrageAm = jetzt;
        if (st.automatisch !== true) {
          if (a.automatisch !== false) return self.rcSchreiben({ abgleich: Object.assign({}, a, { automatisch: false }) }).then(function () { return { lief: false, grund: 'basic' }; });
          return { lief: false, grund: 'basic' };
        }
        if (st.epoche !== a.epoche) return { lief: false, grund: 'Dienst geleert, Abgleich von Hand' };
        var neuerStand = st.seq !== a.seit, voll = jetzt - au.vollAm >= AUTO_VOLL_MS;
        if (!neuerStand && !lokalFaellig && !voll) {
          if (!au.gpsOffen) return { lief: false, grund: 'kein neuer Stand' };
          /* Nur die GPS-Spur (und Dateien) sind neu: kein Abgleich der Daten nötig. */
          return self.dateienAbgleichen({}).then(function (dr) { if (dr.ok) au.gpsOffen = false; return { lief: true, ergebnis: null, dateien: dr }; });
        }
        var zStart = self.speicher.aenderungen || 0;
        return self.abgleichAusfuehren().then(function (res) {
          au.vollAm = jetzt;
          if (!res.ok) return { lief: false, grund: 'fehler', ergebnis: res };
          au.offen = false; au.zaehler = zStart;
          var dateienNoetig = res.gesendet > 0 || res.geholt > 0 || res.dateiAngaben > 0 || au.gpsOffen || voll;
          if (!dateienNoetig) return { lief: true, ergebnis: res, dateien: null };
          return self.dateienAbgleichen({}).then(function (dr) { if (dr.ok) au.gpsOffen = false; return { lief: true, ergebnis: res, dateien: dr }; });
        });
      });
    }).then(fertig, function (e) {
      return dienstFehlerAus(self, e).then(function (r) { return fertig({ lief: false, grund: 'fehler', ergebnis: r }); });
    });
  };

  /* Die App wird ausgeblendet oder geschlossen: Ist die GPS-Spur neu, soll sie beim nächsten Lauf mitgehen (Bündelung: Seitenwechsel, Pause, Abschluss). */
  Daten.prototype.abgleichSpurMerken = function () {
    if (!this.gpsGeaendert) return;
    this.gpsGeaendert = false;
    if (this.auto) this.auto.gpsOffen = true; else this.auto = { zaehler: null, aenderungAm: 0, offen: false, abfrageAm: -Infinity, vollAm: Date.now(), gpsOffen: true };
  };

  /* ---------- Dateien abgleichen (Schritt 13d, seit 2.0.66) ----------
   * Die Angaben zu Fotos, Scans und Dokumenten gehen mit dem normalen Abgleich (Tabellen dateien, nachweisdateien, ereignisdateien ohne „inhalt“).
   * Hier gehen die Dateien selbst: Was auf diesem Gerät liegt und beim Dienst fehlt, wird hochgeladen. Was in den Angaben steht und auf diesem Gerät
   * noch keine Datei hat, wird geholt. Scans von Nachweisen gehen nur mit dem Schlüsselwort verschlüsselt hinaus (der Dienst kann sie nicht lesen).
   * Gelöscht wird beim Dienst, wenn der Abgleich das Löschen der Angaben kennt. Der Stand steht im Geräte-Dokument („abgleich.dateien“).
   * Ohne Netz und ohne Konto ändert sich nichts. Nur auf Knopfdruck, nach dem normalen Abgleich. */

  function dateiKey(tabelle, id) { return tabelle + '/' + id; }
  function istDatei(b) { return !!b && typeof b === 'object' && typeof b.size === 'number' && b.size > 0; }

  /* Zahlen für die Anzeige, ohne etwas zu senden: wie viele Dateien liegen hier, wie viele fehlen hier (nur die Angaben sind da). */
  Daten.prototype.dateienUebersicht = function () {
    var self = this, namen = MM.Abgleich.DATEI_TABELLEN;
    return Promise.all(namen.map(function (n) { return self.speicher.alle(n); })).then(function (r) {
      var z = { hier: 0, hierBytes: 0, fehlenHier: 0, scans: 0, scansFehlen: 0 };
      namen.forEach(function (n, i) {
        var scan = MM.Abgleich.VERSCHLUESSELTE_DATEIEN.indexOf(n) >= 0;
        r[i].forEach(function (rec) {
          if (istDatei(rec.inhalt)) { z.hier++; z.hierBytes += rec.inhalt.size; if (scan) z.scans++; }
          else { z.fehlenHier++; if (scan) z.scansFehlen++; }
        });
      });
      return z;
    });
  };

  /* optionen: { schluesselwort, fortschritt }. Ergebnis: { ok, hochgeladen, geholt, geloescht, ohneWort, zuGross, fehlenBeimDienst, fehler } oder { ok: false, fehler } */
  Daten.prototype.dateienAbgleichen = function (optionen) {
    var self = this;
    optionen = optionen || {};
    var melde = typeof optionen.fortschritt === 'function' ? optionen.fortschritt : function () {};
    var wort = typeof optionen.schluesselwort === 'string' ? optionen.schluesselwort : '';
    if (this.dateienLaeuft || this.abgleichLaeuft) return Promise.resolve({ ok: false, fehler: { allgemein: 'Ein Abgleich läuft schon.' } });
    if (wort && wort.length < 8) return Promise.resolve({ ok: false, fehler: { schluesselwort: 'Das Schlüsselwort braucht mindestens 8 Zeichen.' } });
    var namen = MM.Abgleich.DATEI_TABELLEN;
    var summe = { hochgeladen: 0, geholt: 0, geloescht: 0, ohneWort: 0, zuGross: 0, fehlenBeimDienst: 0, fehler: 0, falschesWort: false, spurHoch: 0, spurRunter: 0, spurOhneWort: 0 };
    var a = null, liste = {};

    function bytesFrage(methode, pfad, bytes) {
      return self.kontoBytes(methode, pfad, bytes).then(function (r) {
        if (r.ok) return r;
        var e = new Error(r.fehler); e.status = r.status; e.art = r.art; throw e;
      });
    }
    function speichereStand() { return self.rcSchreiben({ abgleich: a }); }

    /* Was liegt beim Dienst? */
    function dienstListe() {
      var nach = '';
      function seite() {
        return dienstFrage(self, 'GET', '/datei/liste?nach=' + encodeURIComponent(nach)).then(function (r) {
          r.dateien.forEach(function (x) { liste[dateiKey(x.tabelle, x.id)] = x; });
          if (r.weiter) { nach = r.nach; return seite(); }
        });
      }
      return seite();
    }

    function lokaleDateien() {
      return Promise.all(namen.map(function (n) { return self.speicher.alle(n); })).then(function (r) {
        var alle = [];
        namen.forEach(function (n, i) { r[i].forEach(function (rec) { alle.push({ tabelle: n, rec: rec }); }); });
        return alle;
      });
    }

    function nacheinander(eintraege, f) {
      return eintraege.reduce(function (kette, e) { return kette.then(function () { return f(e); }); }, Promise.resolve());
    }

    /* 1. Löschen beim Dienst, wenn der Abgleich das Löschen der Angaben kennt. */
    function loeschen() {
      var weg = Object.keys(liste).filter(function (k) { return a.zustand[k] && a.zustand[k].g; });
      return nacheinander(weg, function (k) {
        var t = k.split('/');
        melde('Gelöschte Dateien beim Dienst entfernen …');
        return dienstFrage(self, 'POST', '/datei/loeschen', { tabelle: t[0], id: t.slice(1).join('/') }).then(function () {
          delete liste[k]; delete a.dateien.oben[k]; summe.geloescht++;
        });
      });
    }

    /* 2. Hochladen, was hier liegt und beim Dienst fehlt. */
    function hochladen(alle) {
      var offen = alle.filter(function (x) {
        if (!istDatei(x.rec.inhalt)) return false;
        var k = dateiKey(x.tabelle, x.rec.id), sv = liste[k], scan = MM.Abgleich.VERSCHLUESSELTE_DATEIEN.indexOf(x.tabelle) >= 0;
        if (a.zustand[k] && a.zustand[k].g) return false;
        if (sv && !!sv.verschluesselt === scan && (scan || sv.groesse === x.rec.inhalt.size)) return false;
        if (x.rec.inhalt.size > MM.Abgleich.MAX_DATEI_BYTES) { summe.zuGross++; return false; }
        if (scan && !wort) { summe.ohneWort++; return false; }
        return true;
      });
      var nr = 0;
      return nacheinander(offen, function (x) {
        var k = dateiKey(x.tabelle, x.rec.id), scan = MM.Abgleich.VERSCHLUESSELTE_DATEIEN.indexOf(x.tabelle) >= 0;
        nr++; melde('Dateien hochladen: ' + nr + ' von ' + offen.length + ' …');
        return x.rec.inhalt.arrayBuffer().then(function (buf) {
          var bytes = new Uint8Array(buf);
          return scan ? MM.Sicherung.bauen({ art: 'datei', tabelle: x.tabelle, id: x.rec.id }, [bytes], wort) : bytes;
        }).then(function (bytes) {
          if (bytes.length > MM.Abgleich.MAX_DATEI_BYTES) { summe.zuGross++; return; }
          return bytesFrage('PUT', '/datei?tabelle=' + encodeURIComponent(x.tabelle) + '&id=' + encodeURIComponent(x.rec.id) + (scan ? '&verschluesselt=1' : ''), bytes).then(function () {
            liste[k] = { tabelle: x.tabelle, id: x.rec.id, groesse: bytes.length, verschluesselt: scan };
            a.dateien.oben[k] = 1; summe.hochgeladen++;
          }, function (e) {
            if (e && (e.status === 401 || !e.status)) throw e;
            summe.fehler++;
          });
        }).then(function () { if (nr % 10 === 0) return speichereStand(); });
      });
    }

    /* 3. Holen, was in den Angaben steht und hier noch keine Datei hat. */
    function holen(alle) {
      var fehlt = alle.filter(function (x) { return !istDatei(x.rec.inhalt); });
      var nr = 0;
      return nacheinander(fehlt, function (x) {
        var k = dateiKey(x.tabelle, x.rec.id), sv = liste[k];
        if (!sv) { summe.fehlenBeimDienst++; return; }
        if (sv.verschluesselt && !wort) { summe.ohneWort++; return; }
        if (sv.verschluesselt && summe.falschesWort) return;
        nr++; melde('Dateien holen: ' + nr + ' von ' + fehlt.length + ' …');
        return bytesFrage('GET', '/datei?tabelle=' + encodeURIComponent(x.tabelle) + '&id=' + encodeURIComponent(x.rec.id)).then(function (r) {
          if (!r.verschluesselt) return r.bytes;
          return MM.Sicherung.auspacken(r.bytes, wort).then(function (g) { return g.dateien[0]; });
        }).then(function (bytes) {
          if (!bytes) { summe.fehler++; return; }
          var kopie = Object.assign({}, x.rec, { inhalt: new Blob([bytes], { type: x.rec.mime || '' }) });
          return self.speicher.speichern(x.tabelle, kopie).then(function () { a.dateien.oben[k] = 1; summe.geholt++; });
        }, function (e) {
          if (e && (e.code === 'schluessel' || e.code === 'beschaedigt')) { summe.falschesWort = true; return; }
          if (e && (e.status === 401 || !e.status)) throw e;
          summe.fehler++;
        });
      });
    }

    /* 4. GPS-Spur (seit 2.0.119): Je Aktivität eine verschlüsselte Datei mit Strecke, Fahrtwerten und gefahrenem Weg (Tabelle „gpsdaten“ beim Dienst).
     * Hochgeladen wird, wenn sich die Spur hier seit dem letzten Abgleich geändert hat, geholt, wenn sie beim Dienst von einem anderen Gerät neu ist.
     * Haben beide Geräte sie geändert, gilt die mit dem späteren Stand. Ohne Schlüsselwort bleibt die Spur auf dem Gerät. */
    var GPS_ARTEN = ['spur', 'fahrt', 'weg', 'mob']; /* „mob“ seit 2.0.133: Wege bei „Person über Bord“ */
    /* Das Paket einer Aktivität aus den Dokumenten (Spur, Fahrtwerte, Weg): { docs, stand, text, h } */
    function paketAus(teil) {
      var stand = '';
      GPS_ARTEN.forEach(function (n) { if (teil[n] && String(teil[n].geaendertAm || '') > stand) stand = String(teil[n].geaendertAm || ''); });
      var text = MM.Abgleich.kanonisch({ docs: teil });
      return { docs: teil, stand: stand, text: text, h: MM.Abgleich.abdruck(text) };
    }
    /* Seit 2.0.120: Vor dem Lesen schreibt das offene Cockpit seinen Stand weg (Spur, Weg, Fahrtwerte), damit nichts im Speicher der Seite hängen bleibt. */
    function vorGps() {
      if (typeof self.gpsVorAbgleich !== 'function') return null;
      return Promise.resolve().then(function () { return self.gpsVorAbgleich(); }).then(null, function () { /* nicht schlimm */ });
    }
    function gpsAbgleichen() {
      a.dateien.gps = a.dateien.gps || {};
      var gk = a.dateien.gps;
      return self.speicher.alle('einstellungen').then(function (docs) {
        var nach = {};
        docs.forEach(function (d) { var m = /^gps(spur|fahrt|weg|mob)-(.+)$/.exec(String(d.id)); if (m) { (nach[m[2]] = nach[m[2]] || {})[m[1]] = d; } });
        var ids = Object.keys(nach);
        Object.keys(liste).forEach(function (k) { if (k.indexOf('gpsdaten/') === 0 && ids.indexOf(k.slice(9)) < 0) ids.push(k.slice(9)); });
        function paket(id) { return nach[id] ? paketAus(nach[id]) : null; }
        return nacheinander(ids, function (id) {
          var k = 'gpsdaten/' + id, rem = liste[k] || null, lok = paket(id), rec = gk[id] || {};
          var hoch = !!lok && lok.h !== rec.h;
          var runter = !!rem && (rem.am === null || rem.am === undefined ? !lok : rem.am !== rec.am);
          if (!hoch && !runter) return null;
          if (!wort) { summe.spurOhneWort++; return null; }
          function hinauf(l) {
            var bytes = new TextEncoder().encode(JSON.stringify({ stand: l.stand, docs: l.docs }));
            if (bytes.length > MM.Abgleich.MAX_DATEI_BYTES) { summe.zuGross++; return null; }
            melde('GPS-Spur hochladen …');
            return MM.Sicherung.bauen({ art: 'gps', id: id }, [bytes], wort).then(function (b) {
              if (b.length > MM.Abgleich.MAX_DATEI_BYTES) { summe.zuGross++; return null; }
              return bytesFrage('PUT', '/datei?tabelle=gpsdaten&id=' + encodeURIComponent(id) + '&verschluesselt=1', b).then(function (r) {
                gk[id] = { h: l.h, am: r.json && r.json.am !== undefined ? r.json.am : null };
                liste[k] = { tabelle: 'gpsdaten', id: id, groesse: b.length, verschluesselt: true, am: gk[id].am };
                summe.spurHoch++;
              });
            });
          }
          function herunter() {
            melde('GPS-Spur holen …');
            return bytesFrage('GET', '/datei?tabelle=gpsdaten&id=' + encodeURIComponent(id)).then(function (r) {
              return MM.Sicherung.auspacken(r.bytes, wort);
            }).then(function (g) {
              var o = JSON.parse(new TextDecoder().decode(g.dateien[0]));
              return { stand: String(o.stand || ''), docs: o.docs && typeof o.docs === 'object' ? o.docs : {} };
            });
          }
          function uebernehmen(fern) {
            var schreiben = [];
            GPS_ARTEN.forEach(function (n) { if (fern.docs[n] && typeof fern.docs[n] === 'object') schreiben.push({ tabelle: 'einstellungen', objekt: Object.assign({}, fern.docs[n], { id: 'gps' + n + '-' + id }) }); });
            return self.speicher.mehrereSpeichern(schreiben).then(function () {
              var neu = {}; schreiben.forEach(function (e) { neu[e.objekt.id.slice(3).split('-')[0]] = e.objekt; });
              var t = MM.Abgleich.kanonisch({ docs: neu });
              gk[id] = { h: MM.Abgleich.abdruck(t), am: rem ? rem.am : null };
              summe.spurRunter++;
              if (typeof self.gpsNeuHorcher === 'function') { try { self.gpsNeuHorcher(id); } catch (e) { /* nicht schlimm */ } }
            });
          }
          /* Seit 2.0.120: Haben beide Geräte die Spur geändert, werden die Fassungen zusammengeführt (Weg nach Zeit gemischt, Kilometer je Minute, Fahrtwerte der größere Stand),
             nicht mehr die eine durch die andere ersetzt. Das Ergebnis geht zurück zum Dienst. */
          function mischen(fern) {
            var teil = {}, schreiben = [];
            GPS_ARTEN.forEach(function (n) {
              var l = lok.docs[n], f = fern.docs[n] && typeof fern.docs[n] === 'object' ? fern.docs[n] : null, d = null;
              if (l && f) {
                d = Object.assign({}, l);
                if (n === 'spur') d.spur = MM.Routen.spurZusammen(l.spur, f.spur);
                else if (n === 'weg') d.weg = MM.Karte.wegZusammen(l.weg, f.weg);
                else if (n === 'mob') { d.mob = Object.assign({}, f.mob, l.mob); Object.keys(f.mob || {}).forEach(function (e) { d.mob[e] = MM.Mob.wegZusammen((l.mob || {})[e], f.mob[e]); }); }
                else d.fahrt = MM.Fahrt.zusammen(l.fahrt, f.fahrt);
                d.geaendertAm = String(l.geaendertAm || '') >= String(f.geaendertAm || '') ? l.geaendertAm : f.geaendertAm;
              } else if (f) d = Object.assign({}, f, { id: 'gps' + n + '-' + id });
              else if (l) d = l;
              if (d) { teil[n] = d; schreiben.push({ tabelle: 'einstellungen', objekt: d }); }
            });
            return self.speicher.mehrereSpeichern(schreiben).then(function () {
              if (typeof self.gpsNeuHorcher === 'function') { try { self.gpsNeuHorcher(id); } catch (e) { /* nicht schlimm */ } }
              summe.spurGemischt = (summe.spurGemischt || 0) + 1;
              return hinauf(paketAus(teil));
            });
          }
          var arbeit;
          if (hoch && !runter) arbeit = hinauf(lok);
          else if (runter && !hoch) arbeit = herunter().then(uebernehmen);
          else arbeit = herunter().then(function (fern) { return lok ? mischen(fern) : uebernehmen(fern); });
          return arbeit.then(null, function (e) {
            if (e && (e.code === 'schluessel' || e.code === 'beschaedigt' || e.code === 'format')) { summe.falschesWort = true; return null; }
            if (e && (e.status === 401 || !e.status)) throw e;
            summe.fehler++;
          });
        });
      });
    }

    this.dateienLaeuft = true;
    return this.kontoEinstellung().then(function (e) {
      if (!e.angemeldet) return { ok: false, fehler: { allgemein: 'Bitte zuerst anmelden (Funktionen › Konto).' } };
      return Promise.all([self.abgleichLesen(), dienstFrage(self, 'GET', '/abgleich/stand'), self.rcGeraet()]).then(function (r) {
        a = r[0];
        /* Ohne eingetipptes Wort gilt das gespeicherte (seit 2.0.119). */
        if (!wort && typeof r[2].geheimWort === 'string' && r[2].geheimWort.length >= MM.Geheim.MIN_LAENGE) wort = r[2].geheimWort;
        if (a.epoche !== r[1].epoche) return { ok: false, fehler: { allgemein: 'Bitte zuerst die Daten abgleichen, dann die Dateien.' } };
        if (!a.dateien || a.dateien.epoche !== a.epoche) a.dateien = { epoche: a.epoche, oben: {}, gps: {} };
        melde('Dateien beim Dienst prüfen …');
        return dienstListe().then(loeschen).then(lokaleDateien).then(function (alle) {
          return hochladen(alle).then(function () { return holen(alle); }).then(vorGps).then(gpsAbgleichen);
        }).then(function () {
          return speichereStand().then(function () { return Object.assign({ ok: true }, summe); });
        }, function (err) {
          return (a ? speichereStand().catch(function () {}) : Promise.resolve()).then(function () { return dienstFehlerAus(self, err); });
        });
      }, function (err) { return dienstFehlerAus(self, err); });
    }).then(function (res) { self.dateienLaeuft = false; return res; }, function (err) { self.dateienLaeuft = false; throw err; });
  };

  /* Beim Dienst leeren: Alle abgeglichenen Daten und die Sicherungen bleiben dort nicht liegen (Konto und Anmeldung bleiben). Geräte gleichen danach von vorn ab. */
  Daten.prototype.abgleichLeeren = function (roh) {
    var self = this;
    var w = MM.Konto.loeschWort((roh || {}).bestaetigung);
    if (!w.ok) return Promise.resolve({ ok: false, fehler: { bestaetigung: w.fehler } });
    return dienstFrage(this, 'POST', '/abgleich/leeren', { bestaetigung: MM.Konto.LOESCH_WORT }).then(function () {
      return self.rcSchreiben({ abgleich: null }).then(function () { return { ok: true }; });
    }, function (e) { return dienstFehlerAus(self, e); });
  };

  /* ---------- verschlüsselte Sicherung beim Dienst ---------- */

  Daten.prototype.sicherungListeVomDienst = function () {
    var self = this;
    return dienstFrage(this, 'GET', '/sicherung/liste').then(function (r) {
      return { ok: true, sicherungen: r.sicherungen.map(function (x) { return { id: x.id, erstelltAm: new Date(x.erstelltAm).toISOString(), groesse: x.groesse, app: x.app || '', teile: x.teile, summe: x.summe }; }) };
    }, function (e) { return dienstFehlerAus(self, e); });
  };

  /* Sichert ohne Dateien (Scans, Fotos, Dokumente bleiben lokal), immer mit Schlüsselwort. Der Dienst sieht nur verschlüsselte Bytes. */
  Daten.prototype.sicherungZumDienst = function (wort, fortschritt) {
    var self = this;
    var melde = typeof fortschritt === 'function' ? fortschritt : function () {};
    if (typeof wort !== 'string' || wort.length < 8) return Promise.resolve({ ok: false, fehler: { schluessel: 'Das Schlüsselwort braucht mindestens 8 Zeichen.' } });
    return this.kontoEinstellung().then(function (e) {
      if (!e.angemeldet) return { ok: false, fehler: { allgemein: 'Bitte zuerst anmelden (Funktionen › Konto).' } };
      melde('Die Sicherung wird erstellt und verschlüsselt …');
      return self.sicherungErzeugen({ mitDateien: false, schluessel: wort }).then(function (s) {
        if (s.bytes.length > MM.Abgleich.MAX_SICHERUNG_BYTES) return { ok: false, fehler: { allgemein: 'Die Sicherung ist zu groß für den Dienst (' + MM.Hilfen.groesse(s.bytes.length) + ', erlaubt sind ' + MM.Hilfen.groesse(MM.Abgleich.MAX_SICHERUNG_BYTES) + ').' } };
        return MM.Sicherung.sha256(s.bytes).then(function (summe) {
          return dienstFrage(self, 'POST', '/sicherung/anfangen', { groesse: s.bytes.length, summe: summe, app: 'MobiMory ' + MM.VERSION }).then(function (r) {
            var kette = Promise.resolve();
            for (var i = 0; i < r.teile; i++) {
              (function (nr) {
                kette = kette.then(function () {
                  melde('Hochladen: Teil ' + (nr + 1) + ' von ' + r.teile + ' …');
                  var teil = s.bytes.subarray(nr * r.teilBytes, Math.min(s.bytes.length, (nr + 1) * r.teilBytes));
                  return dienstFrage(self, 'POST', '/sicherung/teil', { id: r.id, nr: nr, daten: MM.Abgleich.zuBase64(teil) });
                });
              })(i);
            }
            return kette.then(function () { return dienstFrage(self, 'POST', '/sicherung/fertig', { id: r.id }); }).then(function () {
              return self.rcSchreiben({ serverSicherungAm: self.jetzt() });
            }).then(function () { return { ok: true, groesse: s.bytes.length, zahlen: s.zahlen }; });
          });
        });
      });
    }).then(function (res) { return res; }, function (e) { return dienstFehlerAus(self, e); });
  };

  /* Lädt eine Sicherung vom Dienst und prüft die Summe. Gibt die Bytes zurück (verschlüsselt, zum Öffnen mit dem Schlüsselwort). */
  Daten.prototype.sicherungVomDienstLaden = function (id, fortschritt) {
    var self = this;
    var melde = typeof fortschritt === 'function' ? fortschritt : function () {};
    return this.sicherungListeVomDienst().then(function (l) {
      if (!l.ok) return l;
      var s = l.sicherungen.filter(function (x) { return x.id === id; })[0];
      if (!s) return { ok: false, fehler: { allgemein: 'Diese Sicherung gibt es beim Dienst nicht mehr.' } };
      var teile = [], kette = Promise.resolve();
      for (var i = 0; i < s.teile; i++) {
        (function (nr) {
          kette = kette.then(function () {
            melde('Herunterladen: Teil ' + (nr + 1) + ' von ' + s.teile + ' …');
            return dienstFrage(self, 'GET', '/sicherung/teil?id=' + encodeURIComponent(id) + '&nr=' + nr).then(function (r) { teile.push(MM.Abgleich.ausBase64(r.daten)); });
          });
        })(i);
      }
      return kette.then(function () {
        var n = 0; teile.forEach(function (t) { n += t.length; });
        var bytes = new Uint8Array(n), pos = 0;
        teile.forEach(function (t) { bytes.set(t, pos); pos += t.length; });
        if (n !== s.groesse) return { ok: false, fehler: { allgemein: 'Die Sicherung ist nicht vollständig angekommen. Bitte noch einmal versuchen.' } };
        return MM.Sicherung.sha256(bytes).then(function (summe) {
          if (summe !== s.summe) return { ok: false, fehler: { allgemein: 'Die Sicherung ist beim Übertragen beschädigt worden. Bitte noch einmal versuchen.' } };
          return { ok: true, bytes: bytes, erstelltAm: s.erstelltAm };
        });
      });
    }).then(function (res) { return res; }, function (e) { return dienstFehlerAus(self, e); });
  };

  Daten.prototype.sicherungVomDienstLoeschen = function (id) {
    var self = this;
    return dienstFrage(this, 'POST', '/sicherung/loeschen', { id: id }).then(function () { return { ok: true }; }, function (e) { return dienstFehlerAus(self, e); });
  };

  Daten.prototype.abgleichZeiten = function () {
    return Promise.all([this.abgleichLesen(), this.rcGeraet()]).then(function (r) { return { abgleichAm: r[0].letzter, sicherungAm: r[1].serverSicherungAm || null }; });
  };

  /* ---------- Freigaben und Kontroll-Freigabe (Schritt 13c, seit 2.0.67) ----------
   * Alles läuft über den Konto-Dienst, der die Rechte bei jeder Anfrage prüft. Ein Gast liest nur, und was er sieht, wird nicht auf dem Gerät gespeichert.
   * Der Kontrolleur braucht kein Konto: Die Adresse des Dienstes steht im Link, den der Besitzer weitergibt. */
  function freigabeFehler(self, r) {
    if (r.status === 401) return dienstFehlerAus(self, { status: 401, message: r.fehler });
    var f = {};
    f[r.feld || 'allgemein'] = r.fehler;
    if (r.feld && !/^(email|ab|planAb|bis|code|stunden|fahrzeugId|name|funktion|nachweisArt|nachweisBis|bestaetigt|rechte|gastName|ausnahmen|prozent|monate|grenze|laeuftAb|stufe|notiz|zaehlerId|wert|datum|betrag|bezeichnung|beschreibung|auswirkung|gruppe|kostenart|ortText|art)$/.test(r.feld)) f = { allgemein: r.fehler };
    return Promise.resolve({ ok: false, offline: !r.status, fehler: f });
  }

  Daten.prototype.freigabeListe = function () {
    var self = this;
    return dienstFrage(this, 'GET', '/freigabe/liste').then(function (j) {
      return { ok: true, gegeben: j.gegeben || [], erhalten: j.erhalten || [], kontrollen: j.kontrollen || [], verleih: j.verleih || null };
    }, function (e) { return dienstFehlerAus(self, e); });
  };

  /* Die eigenen Fahrzeuge zur Auswahl (ohne abgegebene). */
  Daten.prototype.freigabeFahrzeuge = function () {
    return this.fahrzeugListe().then(function (liste) {
      return liste.filter(function (x) { return !x.fahrzeug.abgabe && !x.fahrzeug.geliehen; }).map(function (x) { return { id: x.fahrzeug.id, name: x.aktuell.werte.bezeichnung || 'Fahrzeug' }; });
    });
  };

  /* Welche Nachweisarten kommen für dieses Fahrzeug in Frage? Die Anforderungen am Fahrzeug zuerst, sonst die üblichen. */
  Daten.prototype.verleihNachweisarten = function (fahrzeugId) {
    return this.anforderungenListe(fahrzeugId, true).then(function (l) {
      var namen = [];
      l.forEach(function (x) { (x.artNamen || []).forEach(function (n) { if (n && namen.indexOf(n) < 0) namen.push(n); }); });
      if (!namen.length) namen = ['Führerschein', 'Bootsführerschein'];
      namen.push('Anderer Nachweis');
      return namen;
    });
  };

  /* Prüfung vor dem Verleih: eigene Planung, andere Verleihe, Fristen bis zum Ende. Warnt nur. Ohne Netz fehlen die anderen Verleihe, der Rest geht. */
  Daten.prototype.verleihPruefen = function (roh) {
    var self = this, fz = roh.fahrzeugId, ab = roh.ab, bis = roh.bis;
    return Promise.all([this.aktivitaetenListe(), this.fristenListe(fz), this.freigabeListe()]).then(function (r) {
      var aktivitaeten = r[0].filter(function (x) { return x.aktuell.werte.fahrzeugId === fz; }).map(function (x) {
        var w = x.aktuell.werte; return { name: w.bezeichnung, vonDatum: w.vonDatum, bisDatum: w.bisDatum, status: x.status };
      });
      var eingabe = r[1].map(function (x) { return { bezeichnung: x.aktuell.werte.bezeichnung, werte: x.aktuell.werte, letzte: x.status.letzte, zaehler: x.zaehler }; });
      var fristen = MM.Aktivitaeten.fristenImZeitraum({ fristen: eingabe, heute: self.heute(), endDatum: bis, geplanteStrecke: 0, geplanteStunden: 0 });
      var freigaben = r[2].ok ? r[2].gegeben.filter(function (f) { return f.fahrzeugId === fz; }) : [];
      return MM.Freigaben.verleihHinweise({ ab: ab, bis: bis, email: roh.email, aktivitaeten: aktivitaeten, freigaben: freigaben, fristen: fristen });
    });
  };

  Daten.prototype.freigabeEinladen = function (roh) {
    var self = this, p = MM.Freigaben.einladung(roh, this.heute());
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.kontoSenden('POST', '/freigabe/einladen', p.werte).then(function (r) {
      if (!r.ok) return freigabeFehler(self, r);
      return { ok: true, id: r.json.id, ab: r.json.ab, bis: r.json.bis, codeGesendet: !!r.json.codeGesendet, entwicklungsCode: r.json.entwicklungsCode || null };
    });
  };

  Daten.prototype.freigabeAnnehmen = function (roh) {
    var self = this, c = MM.Freigaben.codeEinladung((roh || {}).code);
    if (!c.ok) return Promise.resolve({ ok: false, fehler: { code: c.fehler } });
    return this.kontoSenden('POST', '/freigabe/annehmen', { code: c.code }).then(function (r) { return r.ok ? { ok: true, id: r.json.id } : freigabeFehler(self, r); });
  };

  /* Widerruf durch den Besitzer oder Zurückgeben durch den Gast. */
  Daten.prototype.freigabeWiderrufen = function (id) {
    var self = this;
    return this.kontoSenden('POST', '/freigabe/widerrufen', { id: id }).then(function (r) { return r.ok ? { ok: true } : freigabeFehler(self, r); });
  };

  Daten.prototype.kontrolleErstellen = function (roh) {
    var self = this, s = MM.Freigaben.stunden((roh || {}).stunden);
    if (!s.ok) return Promise.resolve({ ok: false, fehler: { stunden: s.fehler } });
    return this.kontoSenden('POST', '/kontrolle/erstellen', { fahrzeugId: (roh || {}).fahrzeugId, stunden: s.stunden }).then(function (r) {
      if (!r.ok) return freigabeFehler(self, r);
      return self.rcGeraet().then(function (d) { return { ok: true, id: r.json.id, code: r.json.code, laeuftAb: r.json.laeuftAb, dienstUrl: kontoUrlVon(d) }; });
    });
  };

  Daten.prototype.kontrolleWiderrufen = function (id) {
    var self = this;
    return this.kontoSenden('POST', '/kontrolle/widerrufen', { id: id }).then(function (r) { return r.ok ? { ok: true } : freigabeFehler(self, r); });
  };

  /* Das freigegebene Fahrzeug eines Gastes: Ansicht aus den Datensätzen des Dienstes, nichts wird gespeichert. */
  Daten.prototype.geteiltLaden = function (freigabeId) {
    var self = this;
    return this.kontoSenden('GET', '/geteilt/fahrzeug?freigabe=' + encodeURIComponent(freigabeId)).then(function (r) {
      if (!r.ok) return freigabeFehler(self, r).then(function (x) { x.beendet = r.status === 403 || r.status === 404; return x; });
      var s = MM.Freigaben.sicht(r.json.datensaetze, self.heute());
      return s ? { ok: true, sicht: s, bis: r.json.bis, rechte: r.json.rechte === 'mitnutzen' ? 'mitnutzen' : 'lesen', eigene: Array.isArray(r.json.eigene) ? r.json.eigene : [],
          phase: r.json.phase === 'planung' ? 'planung' : 'nutzung', nutzungAb: r.json.nutzungAb || null, planAb: r.json.planAb || null }
        : { ok: false, beendet: true, fehler: { allgemein: 'Dieses Fahrzeug wird nicht mehr geteilt.' } };
    });
  };

  /* Mitnutzung (2.0.75): Der Gast trägt Kilometer, Fahrzeugkosten oder eine Störung ein. Der Dienst legt sie im Fahrzeug des Besitzers an, mit dem Namen des Gastes.
     Auf dem Gerät des Gastes wird nichts gespeichert. */
  Daten.prototype.geteiltErfassen = function (freigabeId, art, roh) {
    var self = this, p = MM.Freigaben.erfassung(art, roh, this.heute());
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    var body = Object.assign({ freigabe: freigabeId }, p.werte);
    return this.kontoSenden('POST', '/geteilt/erfassen', body).then(function (r) { return r.ok ? { ok: true, id: r.json.id, mail: r.json.mail === true } : freigabeFehler(self, r); });
  };

  /* Kontroll-Code durch den Gast (Campingplatz, Kontrolle unterwegs). Er gilt nie länger als die Freigabe. */
  Daten.prototype.geteiltKontrolle = function (freigabeId, stunden) {
    var self = this, s = MM.Freigaben.stunden(stunden === undefined ? 24 : stunden);
    if (!s.ok) return Promise.resolve({ ok: false, fehler: { stunden: s.fehler } });
    return this.kontoSenden('POST', '/geteilt/kontrolle', { freigabe: freigabeId, stunden: s.stunden }).then(function (r) {
      if (!r.ok) return freigabeFehler(self, r);
      return self.rcGeraet().then(function (d) { return { ok: true, id: r.json.id, code: r.json.code, laeuftAb: r.json.laeuftAb, dienstUrl: kontoUrlVon(d) }; });
    });
  };

  /* Die Dokumente eines Fahrzeugs zum Ausnehmen bei der Einladung (Name und Kennung). */
  Daten.prototype.verleihDokumente = function (fahrzeugId) {
    return this.dokumenteListe(fahrzeugId).then(function (l) {
      return l.filter(function (x) { return !x.komponenteId && !x.vorgangId; }).concat(l.filter(function (x) { return x.komponenteId || x.vorgangId; }))
        .map(function (x) { return { id: x.dokument.id, name: x.aktuell.werte.bezeichnung || 'Dokument' }; });
    });
  };

  Daten.prototype.geteiltDatei = function (freigabeId, dateiId) {
    return this.kontoBytes('GET', '/geteilt/datei?freigabe=' + encodeURIComponent(freigabeId) + '&id=' + encodeURIComponent(dateiId));
  };

  /* Kontroll-Freigabe lesen: ohne Konto, mit der Adresse des Dienstes aus dem Link. Das Gerät wird nicht eingerichtet und merkt sich nichts. */
  Daten.prototype.kontrolleLesen = function (dienstUrl, code) {
    var self = this, u = MM.Konto.dienstAdresse(dienstUrl), c = MM.Freigaben.codeKontrolle(code);
    if (!u.ok) return Promise.resolve({ ok: false, fehler: 'Im Link fehlt die Adresse des Dienstes oder sie ist ungültig.' });
    if (!c.ok) return Promise.resolve({ ok: false, fehler: c.fehler });
    var f = this.kontoAnfrageFn || kontoAnfrageStandard;
    return Promise.resolve().then(function () { return f(u.url + '/kontrolle/lesen?code=' + encodeURIComponent(c.code), 'GET', '', undefined); }).then(function (j) {
      var s = MM.Freigaben.sicht(j.datensaetze, self.heute());
      return s ? { ok: true, sicht: s, laeuftAb: j.laeuftAb, code: c.code, dienstUrl: u.url } : { ok: false, fehler: 'Dieses Fahrzeug wird nicht mehr geteilt.' };
    }, function (e) { return { ok: false, fehler: e && e.status === 404 ? 'Dieser Code gilt nicht (mehr).' : MM.Konto.fehlerText(e) }; });
  };

  Daten.prototype.kontrolleDatei = function (dienstUrl, code, dateiId) {
    var u = MM.Konto.dienstAdresse(dienstUrl), c = MM.Freigaben.codeKontrolle(code);
    if (!u.ok || !c.ok) return Promise.resolve({ ok: false, fehler: 'Der Link ist ungültig.' });
    var f = this.kontoBytesFn || kontoBytesStandard;
    return Promise.resolve().then(function () { return f(u.url + '/kontrolle/datei?code=' + encodeURIComponent(c.code) + '&id=' + encodeURIComponent(dateiId), 'GET', '', undefined); }).then(
      function (r) { return Object.assign({ ok: true }, r); }, function (e) { return { ok: false, fehler: MM.Konto.fehlerText(e), status: e && e.status }; });
  };

  /* Alle Angaben, die der Check aus den Daten braucht (noch mit Namen, sie verlassen das Gerät nicht). */
  Daten.prototype.reisecheckEingabe = function (aktivitaetId, abschnittId) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), abschnittId ? this.abschnittLaden(abschnittId) : Promise.resolve(null), abschnittId ? this.gebieteListe() : Promise.resolve([]), abschnittId ? etappenBasis(this, aktivitaetId) : Promise.resolve(null)]).then(function (rr) {
      var a = rr[0], tag = rr[1];
      if (!a) return null;
      if (abschnittId && (!tag || tag.aktivitaet.aktivitaet.id !== aktivitaetId)) return null;
      var w = a.aktuell.werte;
      function zeilen(liste) {
        return liste.map(function (n) {
          var v = n.aktuell.werte, aw = n.art.aktuell.werte;
          return { art: aw.bezeichnung, gescannt: !!v.dateiName, ausgestelltAm: v.ausgestelltAm || null, gueltigBis: MM.Nachweise.hatAblauf(aw) ? (v.gueltigBis || null) : null, klassen: v.klassen || null };
        });
      }
      return Promise.all([
        self.fahrzeugLaden(w.fahrzeugId), self.komponentenListe(w.fahrzeugId), self.nachweiseListe('fahrzeug', w.fahrzeugId),
        Promise.all(a.besatzung.map(function (b) { return self.nachweiseListe('person', b.person.id); })),
        Promise.all(a.tiere.map(function (t) { return self.nachweiseListe('tier', t.id); })),
        self.personenListe(), self.tiereListe(), self.orteListe()
      ]).then(function (r) {
        var fz = r[0], vwerte = fz ? fz.aktuell.werte : {};
        var funktionen = {}; r[5].forEach(function (p) { funktionen[p.objekt.id] = p.aktuell.werte.funktionen || []; });
        var tierWerte = {}; r[6].forEach(function (t) { tierWerte[t.objekt.id] = t.aktuell.werte; });
        var orte = {}; r[7].forEach(function (o) { orte[o.objekt.id] = o.aktuell.werte; });
        function wegpunkt(art, id) {
          var o = id ? orte[id] : null;
          return o ? { art: art, name: o.bezeichnung, land: o.land || '', breite: o.positionBreite, laenge: o.positionLaenge } : null;
        }
        var wege = [wegpunkt('start', w.startOrtId)].concat((w.zwischenzielIds || []).map(function (i) { return wegpunkt('zwischenziel', i); }), [wegpunkt('ziel', w.zielOrtId)]).filter(Boolean);
        var tw = tag ? tag.abschnitt.aktuell.werte : null, ortGeb = a.ortGebiete, tagHerkunft = null;
        if (tw) {
          /* Reisecheck für einen Tag (Etappe, seit 2.0.43): nur die zwei Orte des Tages, nur dieser Tag, nur die Gebiete dieser Orte.
             Seit 2.0.63 aus derselben Quelle wie Wetter, Zusammenfassung und Karte: die abgeleiteten Orte (tagOrte), nicht nur die gespeicherten. */
          var to = rr[3] && rr[3].tagOrte && rr[3].tagOrte[abschnittId] ? rr[3].tagOrte[abschnittId] : { startOrtId: tw.startOrtId || null, startHerkunft: tw.startOrtId ? 'tag' : null, zielOrtId: tw.zielOrtId || null, zielHerkunft: tw.zielOrtId ? 'tag' : null };
          tagHerkunft = { start: to.startHerkunft || null, ziel: to.zielHerkunft || null };
          wege = [wegpunkt('start', to.startOrtId), wegpunkt('ziel', to.zielOrtId)].filter(Boolean);
          var tagOrte = [to.startOrtId, to.zielOrtId].filter(function (i, n, l) { return i && l.indexOf(i) === n; }).map(function (i) { return orte[i] ? { id: i, name: orte[i].bezeichnung, werte: orte[i] } : null; }).filter(Boolean);
          ortGeb = MM.Gebiete.kettenAusOrten({ gebiete: rr[2], orte: tagOrte, welt: a.fahrzeug.welt });
        }
        var art = MM.Fahrzeugarten.art(a.fahrzeug.artId);
        return {
          aktivitaet: { id: a.aktivitaet.id, name: w.bezeichnung, fahrzeugId: w.fahrzeugId, fahrzeugName: a.fahrzeug.name, vonDatum: w.vonDatum, bisDatum: w.bisDatum, status: a.status, storniert: w.status === 'storniert',
            abschnittId: tag ? abschnittId : null, tagDatum: tw ? tw.datum : null, tagHerkunft: tagHerkunft },
          eingabe: {
            vonDatum: tw ? tw.datum : w.vonDatum, vonZeit: tw ? (tw.beginnZeit || '') : (w.vonZeit || ''), bisDatum: tw ? tw.datum : w.bisDatum, bisZeit: tw ? (tw.endeZeit || '') : (w.bisZeit || ''),
            fahrzeug: { name: a.fahrzeug.name, artName: art ? art.name : '', welt: a.fahrzeug.welt, werte: vwerte,
              komponenten: MM.Komponenten.aktive(r[1]).filter(function (k) { return !k.aktuell.werte.ausgebautAm; }).map(function (k) { return { name: k.aktuell.werte.bezeichnung, anzahl: k.aktuell.werte.anzahl }; }),
              nachweise: zeilen(r[2]) },
            gebiete: (a.gebiet ? [{ name: a.gebiet.name }] : []).concat((ortGeb ? ortGeb.ketten : []).map(function (k) { return { name: MM.Gebiete.pfadText(k, ', ') }; })), gebietText: w.gebiet || '',
            wegpunkte: wege,
            personen: a.besatzung.map(function (b, i) { return { name: b.person.name, rolle: b.rolleText, funktionen: funktionen[b.person.id] || [], nachweise: zeilen(r[3][i]) }; }),
            tiere: a.tiere.map(function (t, i) { var tw = tierWerte[t.id] || {}; return { name: t.name, tierart: tw.tierart || '', hatChip: !!tw.chipnummer, nachweise: zeilen(r[4][i]) }; })
          }
        };
      });
    });
  };

  /* Die anonymisierte Anfrage samt Vorschau (was geht hinaus) und Fingerabdruck. */
  Daten.prototype.reisecheckAnfrage = function (aktivitaetId, abschnittId) {
    return this.reisecheckEingabe(aktivitaetId, abschnittId).then(function (x) {
      if (!x) return null;
      var b = MM.Reisecheck.anfrageBauen(x.eingabe);
      /* Bei einem Tag müssen beide Orte da sein, sonst wäre es ein Check ohne Orte. */
      if (abschnittId && !(x.eingabe.wegpunkte && x.eingabe.wegpunkte.length >= 2)) return { ok: false, fehler: ['Der Tag braucht einen Start- und einen Zielort aus der Ortsliste (Tag ändern).'], aktivitaet: x.aktivitaet };
      if (!b.ok) return { ok: false, fehler: b.fehler, aktivitaet: x.aktivitaet };
      return { ok: true, fehler: [], aktivitaet: x.aktivitaet, anfrage: b.anfrage, namen: b.namen, vorschau: MM.Reisecheck.vorschau(b.anfrage), stand: MM.Reisecheck.fingerabdruck(b.anfrage) };
    });
  };

  /* Schickt eine Check-Anfrage ab (seit 2.0.68, Schritt 13e). Im Entwickler-Modus geht sie direkt an den Recherche-Dienst. Sonst geht sie über das Konto:
     Der Dienst prüft Stufe und Kontingent, zählt auf dem Server und reicht sie weiter. quelle „gespeichert“ holt ein früheres Ergebnis und zählt nicht.
     Wirft nie: { ok, antwort, gespeichert, stand, kontingent } oder { ok: false, fehler, art }. */
  Daten.prototype.checkSenden = function (art, anfrage, cfg, d, quelle, freigabeId) {
    var self = this;
    if (cfg.direkt) {
      if (quelle === 'gespeichert') return Promise.resolve({ ok: false, fehler: 'Gespeicherte Checks gibt es nur über das Konto.', art: 'allgemein' });
      return Promise.resolve().then(function () { return self.sendeJson(d.reisecheckDienstUrl + '/research', d.reisecheckToken, anfrage); }).then(
        function (antwort) { return { ok: true, antwort: antwort, gespeichert: false, stand: null, kontingent: null }; },
        function (err) { return { ok: false, fehler: rcFehlerText(err), art: 'netz' }; });
    }
    var koerper = { art: art, anfrage: anfrage, quelle: quelle === 'gespeichert' ? 'gespeichert' : 'frisch' };
    if (freigabeId) koerper.freigabe = freigabeId;
    return this.kontoSenden('POST', '/check/senden', koerper).then(function (r) {
      if (!r.ok) return { ok: false, fehler: r.fehler, art: r.status === 402 ? 'kontingent' : (r.status === 401 ? 'anmeldung' : (r.status === 404 ? 'nichtgespeichert' : 'netz')) };
      return { ok: true, antwort: r.json.antwort, gespeichert: !!r.json.gespeichert, stand: r.json.stand || null, kontingent: r.json.kontingent || null };
    });
  };

  Daten.prototype.reisecheckStarten = function (aktivitaetId, abschnittId, optionen) {
    var self = this;
    return Promise.all([this.rcGeraet(), this.reisecheckEinstellung(), this.reisecheckAnfrage(aktivitaetId, abschnittId)]).then(function (r) {
      var d = r[0], cfg = r[1], q = r[2];
      if (!q) return rcFehler('Diese Aktivität wurde nicht gefunden.');
      if (q.aktivitaet.storniert) return rcFehler('Diese Aktivität ist storniert. Stelle sie zuerst wieder her.');
      if (!cfg.bereit) return rcFehler('Online-Checks laufen über dein MobiMory-Konto (ab Stufe Mittel). Melde dich zuerst an.', 'einrichtung');
      if (!cfg.zugestimmt) return rcFehler('Bitte stimme zuerst zu, dass die Angaben zur Reise an den Dienst gehen dürfen.', 'zustimmung');
      if (!q.ok) return rcFehler(q.fehler.join(' '), 'daten');
      var gesendetAm = self.jetzt();
      return self.leihCheckWeg(q.aktivitaet.fahrzeugId).then(function (weg) {
      if (weg.fehler) return rcFehler(weg.fehler, 'leihe');
      return self.checkSenden(abschnittId ? 'tag' : 'reise', q.anfrage, cfg, d, optionen && optionen.quelle, weg.freigabeId).then(function (res) {
        if (!res.ok) return rcFehler(res.fehler, res.art);
        var p = MM.Reisecheck.antwortPruefen(res.antwort);
        if (!p.ok) return rcFehler(p.fehler, 'dienst');
        var rec = { id: neueId('rc'), datenraumId: self.datenraumId, aktivitaetId: aktivitaetId, fahrzeugId: q.aktivitaet.fahrzeugId, erstelltAm: gesendetAm, stand: q.stand,
          anfrage: q.anfrage, namen: q.namen, ergebnis: p.ergebnis, dienst: p.dienst };
        if (res.gespeichert) { rec.gespeichert = true; rec.gespeichertStand = res.stand ? new Date(res.stand).toISOString() : null; }
        /* Ein Check für einen Tag (seit 2.0.43) zählt nicht als Gesamtcheck und nicht im Kontingent (die Entscheidung kommt mit dem Kostenmodell). */
        if (abschnittId) { rec.art = 'etappe'; rec.abschnittId = abschnittId; }
        return self.speicher.speichern('reisechecks', rec).then(function () {
          /* Die Ergebnisse des Checks werden als Regeln in den betroffenen Orten und Gebieten gespeichert (seit 2.0.101). Das darf den Check nie scheitern lassen. */
          return self.reisecheckRegelnSpeichern(aktivitaetId, abschnittId || null, rec).then(
            function (sr) { return { ok: true, id: rec.id, regeln: sr }; },
            function () { return { ok: true, id: rec.id, regeln: { ok: false, grund: 'fehler' } }; });
        });
      });
      });
    });
  };

  /* ---------- Reisecheck und Regeln (seit 2.0.101) ----------
   * Die Ergebnisse eines Reisechecks werden als Regeln (art 'reisecheck') in den betroffenen Orten und Gebieten gespeichert, mit dem Datum des Checks.
   * Bei einer erneuten Reise in dasselbe Gebiet gibt es zuerst einen Überblick aus diesen Regeln („Stand: Datum, die Daten können veraltet sein“).
   * Die Rechnung steht in js/reisecheck-regeln.js. */

  /* Die Orte und Gebiete einer Reise (oder eines Tages): { welt, orte: [{ id, name }] (nur Orte mit Land), ketten, gebiete (Liste), ortGebiete: [{ ortId, name, gebietId }] } oder null */
  function reisecheckBereiche(self, aktivitaetId, abschnittId) {
    return Promise.all([self.aktivitaetLaden(aktivitaetId), self.orteListe(), self.gebieteListe(), abschnittId ? self.abschnittLaden(abschnittId) : Promise.resolve(null),
      abschnittId ? etappenBasis(self, aktivitaetId) : Promise.resolve(null)]).then(function (r) {
      var a = r[0];
      if (!a) return null;
      var w = a.aktuell.werte, welt = a.fahrzeug.welt, gebiete = r[2], tag = r[3];
      var ortIds;
      if (abschnittId && tag && tag.aktivitaet.aktivitaet.id === aktivitaetId) {
        var tw = tag.abschnitt.aktuell.werte;
        var to = r[4] && r[4].tagOrte && r[4].tagOrte[abschnittId] ? r[4].tagOrte[abschnittId] : { startOrtId: tw.startOrtId || null, zielOrtId: tw.zielOrtId || null };
        ortIds = [to.startOrtId, to.zielOrtId];
      } else {
        ortIds = [w.startOrtId].concat(w.zwischenzielIds || [], [w.zielOrtId]);
      }
      ortIds = ortIds.filter(function (i, n, l) { return i && l.indexOf(i) === n; });
      var orteAlle = ortIds.map(function (i) {
        var o = r[1].filter(function (x) { return x.objekt.id === i; })[0];
        return o ? { id: i, name: o.aktuell.werte.bezeichnung, werte: o.aktuell.werte } : null;
      }).filter(Boolean);
      var ketten = MM.Gebiete.kettenAusOrten({ gebiete: gebiete, orte: orteAlle, welt: welt }).ketten.slice();
      /* Das Gebiet, das bei der Aktivität von Hand gewählt wurde, zählt mit (nicht bei einem einzelnen Tag). */
      if (!abschnittId && w.gebietId) {
        var weg = MM.Gebiete.pfad(gebiete, w.gebietId);
        if (weg.length && !ketten.some(function (k) { return k[k.length - 1].id === weg[weg.length - 1].id; })) ketten.push(weg);
      }
      /* Orte mit Land: Nur sie können ein eigenes Gebiet (Ebene „ort“) bekommen. */
      var orte = [], ortGebiete = [];
      orteAlle.forEach(function (o) {
        var gp = o.werte.gebietId ? MM.Gebiete.pfad(gebiete, o.werte.gebietId) : [];
        if (!gp.length || gp[0].ebene !== 'land') return;
        orte.push({ id: o.id, name: o.name, landId: gp[0].id });
        var og = MM.Gebiete.ortGebiet(gebiete, o.id);
        if (og) ortGebiete.push({ ortId: o.id, name: o.name, gebietId: og.objekt.id });
      });
      return { welt: welt, orte: orte, ketten: ketten, gebiete: gebiete, ortGebiete: ortGebiete };
    });
  }

  /* Das Datum des Checks: bei einem gespeicherten Check der Stand des Dienstes, sonst der Tag der Recherche. */
  function reisecheckDatum(rec) {
    var R = MM.ReisecheckRegeln;
    return (rec.gespeichert && R.datumVon(rec.gespeichertStand)) || R.datumVon(rec.dienst && rec.dienst.recherchiertAm) || R.datumVon(rec.erstelltAm);
  }

  /* Speichert die Anforderungen eines Checks als Regeln. Ergebnis: { ok, neu, aktualisiert, gleich, ziele: [{ typ, name, neu, aktualisiert }], ohneZiel, grund } */
  Daten.prototype.reisecheckRegelnSpeichern = function (aktivitaetId, abschnittId, rec) {
    var self = this, R = MM.ReisecheckRegeln;
    var leer = { ok: true, neu: 0, aktualisiert: 0, gleich: 0, ziele: [], ohneZiel: 0, grund: null };
    if (!rec || !rec.ergebnis || !(rec.ergebnis.anforderungen || []).length) return Promise.resolve(Object.assign({}, leer, { grund: 'leer' }));
    return reisecheckBereiche(this, aktivitaetId, abschnittId).then(function (b) {
      if (!b) return Object.assign({}, leer, { ok: false, grund: 'nicht-gefunden' });
      var datum = reisecheckDatum(rec);
      var z = R.zuordnen({ anforderungen: rec.ergebnis.anforderungen, ketten: b.ketten, orte: b.orte });
      if (!z.ziele.length) return Object.assign({}, leer, { ohneZiel: z.ohneZiel, grund: z.grund || 'kein-gebiet' });
      return Promise.all([self.speicher.alle('regeln'), self.speicher.alle('verlaeufe'), self.gebieteListe()]).then(function (r) {
        var alle = sammle(self, r[0], r[1], 'regel'), jetzt = self.jetzt(), liste = [], res = Object.assign({}, leer);
        z.ziele.forEach(function (ziel) {
          var gebietId = ziel.id;
          if (ziel.typ === 'ort') {
            var ort = b.orte.filter(function (o) { return o.id === ziel.id; })[0];
            var g = ortGebietAbgleichen(self, r[2], ziel.id, ziel.name, ort.landId, jetzt, true);
            gebietId = g.id; g.speichern.forEach(function (x) { liste.push(x); });
          }
          var vorhanden = alle.filter(function (x) { return x.objekt.gebietId === gebietId && R.ist(x.aktuell.werte); })
            .map(function (x) { return { id: x.objekt.id, nr: x.aktuell.nr, aktuellId: x.aktuell.id, werte: x.aktuell.werte }; });
          var f = R.fortschreiben({ vorhanden: vorhanden, neu: ziel.anforderungen.map(function (a) { return R.regelWerte(a, datum, rec.id); }) });
          f.anlegen.forEach(function (w) {
            var rg = { id: neueId('rg'), datenraumId: self.datenraumId, erstelltAm: jetzt, gebietId: gebietId };
            liste.push({ tabelle: 'regeln', objekt: rg }, { tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('regel', rg.id, 1, w, null, jetzt) });
          });
          f.aendern.forEach(function (c) {
            var v = vorhanden.filter(function (x) { return x.id === c.id; })[0];
            liste.push({ tabelle: 'verlaeufe', objekt: neuerVerlaufEintrag('regel', c.id, v.nr + 1, c.werte, v.aktuellId, jetzt) });
          });
          res.neu += f.anlegen.length; res.aktualisiert += f.aendern.length; res.gleich += f.gleich;
          res.ziele.push({ typ: ziel.typ, name: ziel.name, neu: f.anlegen.length, aktualisiert: f.aendern.length });
        });
        res.ohneZiel = z.ohneZiel;
        return (liste.length ? self.speicher.mehrereSpeichern(liste) : Promise.resolve()).then(function () { return res; });
      });
    });
  };

  /* Der Überblick aus den gespeicherten Regeln für die Orte und Gebiete einer Reise oder eines Tages (MM.ReisecheckRegeln.ueberblick), oder null. */
  Daten.prototype.reisecheckRegelnUeberblick = function (aktivitaetId, abschnittId) {
    var self = this;
    return reisecheckBereiche(this, aktivitaetId, abschnittId).then(function (b) {
      if (!b) return null;
      return Promise.all([self.speicher.alle('regeln'), self.speicher.alle('verlaeufe')]).then(function (r) {
        var alle = sammle(self, r[0], r[1], 'regel');
        function regelnVon(gid) { return alle.filter(function (x) { return x.objekt.gebietId === gid; }).map(function (x) { return x.aktuell.werte; }); }
        var gruppen = [], gesehen = {};
        /* Von unten nach oben: erst der Ort, dann die Gebiete der Ketten (genauestes zuerst). */
        b.ortGebiete.forEach(function (o) { gesehen[o.gebietId] = true; gruppen.push({ name: o.name, ebene: 'ort', regeln: regelnVon(o.gebietId) }); });
        b.ketten.forEach(function (k) {
          k.slice().reverse().forEach(function (g) {
            if (g.ebene === 'ort' || gesehen[g.id]) return;
            gesehen[g.id] = true; gruppen.push({ name: g.name, ebene: g.ebene || null, regeln: regelnVon(g.id) });
          });
        });
        return MM.ReisecheckRegeln.ueberblick({ gruppen: gruppen, datumText: MM.Hilfen.datum });
      });
    });
  };

  /* Eine Regel aus einem Reisecheck ein- oder ausschalten (gilt ja/nein). Sie bleibt gespeichert, der Überblick zeigt abgeschaltete nicht. */
  Daten.prototype.reisecheckRegelSchalten = function (regelId, gilt) {
    var self = this;
    return this.mitVerlaufLaden('regeln', regelId, REGEL_FELDER).then(function (x) {
      if (!x || !MM.ReisecheckRegeln.ist(x.aktuell.werte)) return { ok: false, fehler: { allgemein: 'Diese Regel wurde nicht gefunden.' } };
      var neu = Object.assign({}, x.aktuell.werte, { gilt: gilt === 'nein' ? 'nein' : 'ja' });
      return self.mitVerlaufAendern('regel', regelId, x, neu, REGEL_FELDER);
    });
  };

  /* ---------- Geliehene Fahrzeuge in der Fahrzeugliste (2.0.80, Bau 3b) ----------
   * Wer ein Fahrzeug geliehen bekommt, hat es in seiner Fahrzeugliste, im Block „Geliehen“. Dahinter steht ein eigenes Fahrzeug im Datenraum der Person
   * (fahrzeug.geliehen = { freigabeId, quelleFahrzeugId, von, ab, planAb, bis, rechte, beendetAm, aktualisiertAm }). Logbuch, Reisen, Kosten, Check und Tagebuch
   * laufen darüber wie bei einem eigenen Fahrzeug und bleiben ausschließlich bei der Person. Der Besitzer sieht nichts davon, sein Fahrzeug und seine Historie
   * bleiben unverändert (auch Kosten). Nur bei „mitnutzen“ geht ein Eintrag über die Seite „Geteiltes Fahrzeug“ in das Fahrzeug des Besitzers (2.0.75).
   * Das geliehene Fahrzeug zählt nicht zur Fahrzeuggrenze der Stufe. Online-Checks laufen über die Freigabe und zählen zum Kontingent des Besitzers.
   * Endet die Freigabe, wird das Fahrzeug inaktiv (technisch: abgabe mit Grund „leihende“): nichts Neues anlegen, keine Online-Checks, Lesen geht.
   * Wird dasselbe Fahrzeug später wieder geliehen, wird derselbe Platz wieder aktiv, damit die Daten der Person beisammen bleiben. */
  var LEIH_SYNC_MS = 5 * 60 * 1000, LEIH_DATEN_MS = 24 * 3600 * 1000;

  function stabilJson(o) {
    if (o === null || typeof o !== 'object') return JSON.stringify(o === undefined ? null : o);
    if (Array.isArray(o)) return '[' + o.map(stabilJson).join(',') + ']';
    return '{' + Object.keys(o).sort().map(function (k) { return JSON.stringify(k) + ':' + stabilJson(o[k]); }).join(',') + '}';
  }
  /* Die Art, unter der das geliehene Fahrzeug bei der Person steht: die des Besitzers, wenn sie hier bekannt ist, sonst die erste passende der Welt. */
  function leihArt(artId, welt) {
    var a = artId ? MM.Fahrzeugarten.art(artId) : null;
    if (a && !a.gruppe) return a.id;
    var alle = MM.Fahrzeugarten.alle(true);
    var passend = alle.filter(function (x) { return x.welt === welt; })[0] || alle[0];
    return passend ? passend.id : null;
  }

  Daten.prototype.leihFahrzeuge = function () {
    return this.fahrzeugListe({ alle: true }).then(function (l) { return l.filter(function (x) { return !!x.fahrzeug.geliehen; }); });
  };

  /* Über welche Freigabe läuft ein Online-Check für dieses Fahrzeug? Eigenes Fahrzeug: über das eigene Konto (freigabeId null).
     Geliehenes Fahrzeug: nur mit gültiger Freigabe, über das Kontingent des Besitzers. Ist die Leihe zu Ende, gibt es keinen Check. */
  Daten.prototype.leihCheckWeg = function (fahrzeugId) {
    return this.speicher.holen('fahrzeuge', fahrzeugId).then(function (fz) {
      if (!fz || !fz.geliehen) return { freigabeId: null };
      if (fz.abgabe || fz.geliehen.beendetAm) return { fehler: 'Die Leihe dieses Fahrzeugs ist zu Ende. Online-Checks gibt es nur, solange die Freigabe gilt. Du kannst alles weiter lesen.' };
      return { freigabeId: fz.geliehen.freigabeId };
    });
  };

  function leihWerteAusSicht(sicht) {
    var w = Object.assign({}, sicht.fahrzeug.check && sicht.fahrzeug.check.werte ? sicht.fahrzeug.check.werte : {});
    w.bezeichnung = sicht.fahrzeug.bezeichnung || w.bezeichnung || 'Geliehenes Fahrzeug';
    delete w.hauptfahrzeugId; delete w.zugfahrzeuge; delete w.bootsliste;
    return w;
  }

  /* Gleicht die geliehenen Fahrzeuge mit den erhaltenen Freigaben ab: neue anlegen, laufende aktuell halten, beendete inaktiv setzen.
     Ohne Konto oder ohne Netz passiert nichts (nichts wird gelöscht oder beendet). Höchstens alle 5 Minuten, außer opt.erzwingen. Wirft nie. */
  Daten.prototype.leihSynchronisieren = function (opt) {
    var self = this;
    if (this._leihLaeuft) return this._leihLaeuft;
    if (!(opt && opt.erzwingen) && this._leihSyncAm && Date.now() - this._leihSyncAm < LEIH_SYNC_MS) return Promise.resolve({ ok: true, uebersprungen: true, neu: 0, beendet: 0 });
    var p = this.rcGeraet().then(function (d) {
      if (!(d.kontoToken && d.kontoEmail)) return { ok: false, keinKonto: true, neu: 0, beendet: 0 };
      return Promise.all([self.freigabeListe(), self.leihFahrzeuge()]).then(function (r) {
        var l = r[0], lokal = r[1];
        if (!l.ok) return { ok: false, offline: !!l.offline, neu: 0, beendet: 0 };
        var heute = self.heute(), erhalten = l.erhalten || [], zaehl = { neu: 0, beendet: 0, aktualisiert: 0 };
        function nachId(id) { return erhalten.filter(function (e) { return e.id === id; })[0] || null; }
        var kette = Promise.resolve();

        /* 1. Beendete Leihen inaktiv setzen. */
        lokal.forEach(function (x) {
          var g = x.fahrzeug.geliehen;
          if (x.fahrzeug.abgabe) return;
          var f = nachId(g.freigabeId);
          if (f && f.status !== 'abgelaufen' && f.status !== 'widerrufen') return;
          var bis = (f && f.bis) || g.bis || heute, datum = bis < heute ? bis : heute;
          kette = kette.then(function () {
            var neu = Object.assign({}, x.fahrzeug);
            neu.geliehen = Object.assign({}, g, { beendetAm: datum });
            neu.abgabe = { datum: datum, grund: 'leihende', notiz: null, erfasstAm: self.jetzt() };
            return self.speicher.speichern('fahrzeuge', neu).then(function () { zaehl.beendet++; });
          });
        });

        /* 2. Laufende Freigaben anlegen oder aktuell halten. */
        erhalten.filter(function (f) { return f.status === 'planung' || f.status === 'aktiv'; }).forEach(function (f) {
          var treffer = lokal.filter(function (x) { return x.fahrzeug.geliehen.freigabeId === f.id; })[0]
            || lokal.filter(function (x) { return x.fahrzeug.abgabe && x.fahrzeug.geliehen.quelleFahrzeugId === f.fahrzeugId && (x.fahrzeug.geliehen.von || '') === (f.von || ''); })[0] || null;
          var braucht = !treffer || !!treffer.fahrzeug.abgabe || Date.now() - (Date.parse(treffer.fahrzeug.geliehen.aktualisiertAm || '') || 0) > LEIH_DATEN_MS;
          kette = kette.then(function () {
            var meta = { freigabeId: f.id, quelleFahrzeugId: f.fahrzeugId || null, von: f.von || '', ab: f.ab || null, planAb: f.planAb || null, bis: f.bis || null, rechte: f.rechte === 'mitnutzen' ? 'mitnutzen' : 'lesen', beendetAm: null };
            if (!braucht) {
              /* Nur die Zeiten und Rechte nachziehen, wenn sie sich geändert haben. */
              var alt = treffer.fahrzeug.geliehen, neuMeta = Object.assign({}, alt, meta, { aktualisiertAm: alt.aktualisiertAm });
              if (stabilJson(neuMeta) === stabilJson(alt)) return null;
              return self.speicher.speichern('fahrzeuge', Object.assign({}, treffer.fahrzeug, { geliehen: neuMeta })).then(function () { zaehl.aktualisiert++; });
            }
            return self.geteiltLaden(f.id).then(function (g) {
              if (!g.ok) return null;
              var jetzt = self.jetzt(), werte = leihWerteAusSicht(g.sicht), fz = g.sicht.fahrzeug;
              var artId = leihArt(fz.artId, fz.check && fz.check.welt);
              meta.aktualisiertAm = jetzt; meta.ab = g.nutzungAb || meta.ab; meta.planAb = g.planAb || meta.planAb; meta.bis = g.bis || meta.bis; meta.rechte = g.rechte;
              if (!treffer) {
                if (!artId) return null;
                var neuFz = { id: neueId('fz'), datenraumId: self.datenraumId, art: artId, erstelltAm: jetzt, geliehen: meta };
                var eintrag = { id: neueId('en'), fahrzeugId: neuFz.id, nr: 1, werte: werte, art: artId, quelle: 'hand', korrekturZu: null, erstelltAm: jetzt };
                return self.speicher.mehrereSpeichern([{ tabelle: 'fahrzeuge', objekt: neuFz }, { tabelle: 'eintraege', objekt: eintrag }]).then(function () { zaehl.neu++; });
              }
              var fzNeu = Object.assign({}, treffer.fahrzeug, { geliehen: meta });
              if (fzNeu.abgabe) { fzNeu.abgabeVerlauf = (fzNeu.abgabeVerlauf || []).concat([Object.assign({}, fzNeu.abgabe, { zurueckAm: jetzt })]); delete fzNeu.abgabe; }
              var liste = [{ tabelle: 'fahrzeuge', objekt: fzNeu }];
              if (stabilJson(treffer.aktuell.werte) !== stabilJson(werte)) {
                liste.push({ tabelle: 'eintraege', objekt: { id: neueId('en'), fahrzeugId: fzNeu.id, nr: treffer.aktuell.nr + 1, werte: werte, art: treffer.aktuell.art || fzNeu.art, quelle: 'hand', korrekturZu: treffer.aktuell.id, erstelltAm: jetzt } });
              }
              return self.speicher.mehrereSpeichern(liste).then(function () { zaehl.aktualisiert++; });
            });
          });
        });

        return kette.then(function () { self._leihSyncAm = Date.now(); return { ok: true, neu: zaehl.neu, beendet: zaehl.beendet, aktualisiert: zaehl.aktualisiert }; });
      });
    }).then(function (res) { self._leihLaeuft = null; return res; }, function () { self._leihLaeuft = null; return { ok: false, neu: 0, beendet: 0 }; });
    this._leihLaeuft = p;
    return p;
  };

  /* Die Texte und Angaben für die Fahrzeugseite und die Liste. */
  Daten.prototype.leihInfo = function (fz) {
    var g = fz && fz.geliehen;
    if (!g) return null;
    return { freigabeId: g.freigabeId, von: g.von || '', ab: g.ab || null, planAb: g.planAb || null, bis: g.bis || null, rechte: g.rechte === 'mitnutzen' ? 'mitnutzen' : 'lesen',
      beendet: !!(fz.abgabe || g.beendetAm), beendetAm: g.beendetAm || (fz.abgabe ? fz.abgabe.datum : null) };
  };

  /* ---------- Reisebuch (2.0.81, Bau 4) ----------
   * Aus einer eigenen Reise ein Buch machen (Seite und PDF). Es liest nur und schreibt nichts. Die Rechnung steht in MM.Reisebuch.
   * Geliehene Fahrzeuge: Eine Reise mit einem geliehenen Fahrzeug ist eine Reise wie jede andere (seit 2.0.86 gibt es kein eigenes Leihreise-Tagebuch mehr). */
  Daten.prototype.reisebuecherListe = function () {
    return this.aktivitaetenListe().then(function (liste) {
      return liste.filter(function (x) { return x.status !== 'storniert'; }).map(function (x) {
        var w = x.aktuell.werte;
        return { id: x.objekt.id, name: w.bezeichnung, artName: x.artName, fahrzeugName: x.fahrzeugName, vonDatum: w.vonDatum, bisDatum: w.bisDatum, status: x.status };
      }).sort(function (a, b) { return a.vonDatum < b.vonDatum ? 1 : (a.vonDatum > b.vonDatum ? -1 : 0); });
    });
  };

  /* Die nackten Angaben der Ereignisse einer Reise für die Zahlen im Reisebuch (seit 2.0.85): nur lesen. Ausgeblendete sind markiert. */
  Daten.prototype.reiseRohEreignisse = function (aktivitaetId) {
    return Promise.all([this.speicher.wo('ereignisse', 'aktivitaetId', aktivitaetId), this.speicher.alle('verlaeufe'), this.ereignisartenListe()]).then(function (r) {
      var arten = {}; r[2].forEach(function (x) { arten[x.objekt.id] = x.aktuell.werte.bezeichnung; });
      return neuesteStaende(r[0], r[1], 'ereignis').map(function (e) {
        var w = e.aktuell.werte;
        return { id: e.objekt.id, abschnittId: e.objekt.abschnittId, artName: arten[w.artId] || '', datum: w.datum || '', zeit: w.zeit || '', text: w.text || '', ausgeblendet: w.ausgeblendet === 'ja',
          tankGebucht: !!w.tankGebucht, tankArt: w.tankArt || null, menge: typeof w.menge === 'number' ? w.menge : null, kraftstoff: w.kraftstoff || '', tankName: w.tankName || '',
          entsorgungName: w.entsorgungName || '', verbrauch: w.verbrauch || null, einschraenkung: w.einschraenkung || '' };
      });
    });
  };

  Daten.prototype.reisebuchLaden = function (aktivitaetId) {
    var self = this;
    return Promise.all([this.logbuchLaden(aktivitaetId), this.reiseZusammenfassung(aktivitaetId), this.reiseAuswertung(aktivitaetId), this.reiseRohEreignisse(aktivitaetId), this.orteListe(),
      this.rudergaengerZeiten(aktivitaetId), this.reiseMotorzeiten(aktivitaetId)]).then(function (r) {
      var lb = r[0], zus = r[1], au = r[2], rohEv = r[3], ortarten = {};
      r[4].forEach(function (o) { if (o.aktuell.werte.ortart) ortarten[o.objekt.id] = o.aktuell.werte.ortart; });
      if (!lb || !lb.aktivitaet) return null;
      var a = lb.aktivitaet, w = a.aktuell.werte;
      var zeilen = {}; ((zus && zus.tage) || []).forEach(function (t) { zeilen[t.id] = t; });
      var tage = lb.abschnitte.filter(function (t) { return !t.ausgeblendet; }).map(function (t) {
        var tw = t.aktuell.werte, z = zeilen[t.objekt.id] || {};
        return { id: t.objekt.id, datum: tw.datum, beginn: tw.beginnZeit || '', ende: tw.endeZeit || '', start: z.start ? z.start.name : '', ziel: z.ziel ? z.ziel.name : '',
          von: z.vonText || tw.von || '', nach: z.nachText || tw.nach || '', strecke: z.strecke && typeof z.strecke.km === 'number' ? z.strecke.km : null,
          verantwortlicher: t.verantwortlicher ? t.verantwortlicher.name : '', notiz: tw.notiz || '', abschlussZiel: tw.zielTatsaechlich || '', abschlussNotiz: tw.abschlussNotiz || '',
          /* Seit 2.0.106 mit allen Arten (Ereignis, Wechsel der Verantwortung, Rudergängerwechsel), Position und Herkunft. Welche davon im Buch stehen, bestimmt die Auswahl. */
          ereignisse: t.ereignisse.map(function (e) {
            return { id: e.id, kind: e.art, datum: e.datum || '', zeit: e.zeit || '', art: e.artName, text: e.text || '', ort: e.ortName || '', hatFoto: !!e.hatFoto, ausgeblendet: !!e.ausgeblendet, nachgetragen: !!e.nachgetragen,
              nachgetragenAm: e.nachgetragenAm || null, geaendert: !!e.geaendert, positionAenderungen: e.positionAenderungen || [], breite: typeof e.breite === 'number' ? e.breite : null, laenge: typeof e.laenge === 'number' ? e.laenge : null, positionQuelle: e.positionQuelle || null,
              quelle: e.quelle || 'nutzer', quelleName: e.quelleName || null, zeitHerkunft: e.zeitHerkunft || null };
          }) };
      });
      var g = au && au.gesamt ? au.gesamt : null;
      return {
        id: aktivitaetId, titel: w.bezeichnung, vonDatum: w.vonDatum, bisDatum: w.bisDatum, welt: a.fahrzeug.welt, einheit: 'km',
        fahrzeug: { name: a.fahrzeug.name, artName: a.fahrzeug.artId && MM.Fahrzeugarten.art(a.fahrzeug.artId) ? MM.Fahrzeugarten.art(a.fahrzeug.artId).name : '' },
        art: a.art ? a.art.name : '', start: a.startOrt ? a.startOrt.name : '', ziel: a.zielOrt ? a.zielOrt.name : '',
        zwischenziele: (a.zwischenziele || []).map(function (o) { return o.name; }), gebiet: a.gebiet ? a.gebiet.name : (w.gebiet || ''), notiz: w.notiz || '',
        besatzung: (a.besatzung || []).map(function (b) { return { name: b.person.name, rolle: b.rolleText }; }), tiere: (a.tiere || []).map(function (t) { return t.name; }),
        tage: tage, streckeSumme: zus ? zus.streckeSumme : 0,
        besuche: ((au && au.besuche) || []).map(function (b) { return { ort: b.ortName, datum: b.aktuell.werte.datum || '', zeit: b.aktuell.werte.zeit || '', notiz: b.aktuell.werte.notiz || '', ortId: b.aktuell.werte.ortId || null }; }),
        ortarten: ortarten, rohEreignisse: rohEv, ruderzeiten: r[5] || [], motorzeiten: r[6] || [],
        kosten: g ? { gesamt: g.gesamt, fahrzeug: g.fahrzeug ? g.fahrzeug.summe : 0, reisekasse: g.reisekasse ? g.reisekasse.summe : 0, proPerson: g.proPerson, proTag: g.proTag } : null
      };
    });
  };

  /* Motorlaufzeiten dieser Reise (seit 2.0.106): die Läufe der Motoren des Fahrzeugs, soweit sie in den Zeitraum der Aktivität fallen (bis zu ihrem Ende, sonst bis jetzt).
     Ergebnis: [{ name, minuten, laeufe }], die längste zuerst. Ein noch laufender Lauf zählt bis zum Ende des Zeitraums. */
  Daten.prototype.reiseMotorzeiten = function (aktivitaetId) {
    var self = this;
    return this.aktivitaetLaden(aktivitaetId).then(function (a) {
      if (!a || !a.fahrzeug || !a.fahrzeug.id) return [];
      return Promise.all([laufDokument(self), self.komponentenListe(a.fahrzeug.id)]).then(function (r) {
        var w = a.aktuell.werte, jetzt = self.jetztLokal();
        var von = MM.Aktivitaeten.von(w), ende = MM.Aktivitaeten.bis(w), bis = ende && ende < jetzt ? ende : jetzt;
        var vonMs = von ? new Date(von).getTime() : NaN, bisMs = new Date(bis).getTime();
        if (isNaN(vonMs) || isNaN(bisMs) || bisMs <= vonMs) return [];
        var namen = {};
        r[1].forEach(function (k) { if (MM.Komponenten.istMotor(k.komponente)) namen[k.komponente.id] = k.aktuell.werte.bezeichnung; });
        var je = {}, reihe = [];
        (r[0].laeufe || []).forEach(function (l) {
          if (!namen[l.komponenteId] || l.fahrzeugId !== a.fahrzeug.id) return;
          var s0 = zeitMs(l.start), s1 = l.stopp ? zeitMs(l.stopp) : bisMs;
          if (isNaN(s0) || isNaN(s1)) return;
          var min = (Math.min(s1, bisMs) - Math.max(s0, vonMs)) / 60000;
          if (!(min > 0)) return;
          if (!je[l.komponenteId]) { je[l.komponenteId] = { name: namen[l.komponenteId], minuten: 0, laeufe: 0 }; reihe.push(je[l.komponenteId]); }
          je[l.komponenteId].minuten += min; je[l.komponenteId].laeufe++;
        });
        reihe.forEach(function (x) { x.minuten = Math.round(x.minuten); });
        return reihe.sort(function (x, y) { return y.minuten - x.minuten || x.name.localeCompare(y.name, 'de'); });
      });
    });
  };

  /* Gespeicherte Zusammenstellungen des Reisebuchs (seit 2.0.106): ein Dokument „reisebuchvorlagen“ in „einstellungen“ (keine Umstellung der Datenbank,
     in der Sicherung enthalten). Sie gelten für jede Reise, nicht nur für die, bei der sie gespeichert wurden. */
  Daten.prototype.reisebuchZusammenstellungen = function () {
    return this.speicher.holen('einstellungen', 'reisebuchvorlagen').then(function (dok) { return MM.Reisebuch.zusammenstellungenListe(dok); });
  };
  Daten.prototype.reisebuchZusammenstellungSpeichern = function (name, opt) {
    var self = this;
    return this.speicher.holen('einstellungen', 'reisebuchvorlagen').then(function (dok) {
      var r = MM.Reisebuch.zusammenstellungNeu(dok, name, opt, self.jetzt(), function () { return neueId('rv'); });
      if (!r.ok) return r;
      return self.speicher.speichern('einstellungen', r.dokument).then(function () { return { ok: true, id: r.id }; });
    });
  };
  Daten.prototype.reisebuchZusammenstellungLoeschen = function (id) {
    var self = this;
    return this.speicher.holen('einstellungen', 'reisebuchvorlagen').then(function (dok) {
      var liste = ((dok && dok.vorlagen) || []);
      if (!liste.some(function (v) { return v.id === id; })) return { ok: false, fehler: 'Diese Zusammenstellung gibt es nicht.' };
      return self.speicher.speichern('einstellungen', { id: 'reisebuchvorlagen', vorlagen: liste.filter(function (v) { return v.id !== id; }) }).then(function () { return { ok: true }; });
    });
  };

  /* Ein Foto fürs Buch als JPEG-Bytes, im Browser verkleinert (lange Seite höchstens opt.maxPx, Standard 1400). Null, wenn das Foto nicht auf diesem Gerät liegt
     oder sich nicht als JPEG liefern lässt. */
  Daten.prototype.reisebuchBild = function (ereignisId, opt) {
    var maxPx = opt && opt.maxPx || 1400;
    return this.ereignisDateiHolen(ereignisId).then(function (d) {
      if (!d || !d.inhalt) return null;
      return jpegAusBlob(d.inhalt, maxPx);
    });
  };

  /* Ein Bild (Blob) als JPEG-Bytes, im Browser verkleinert (lange Seite höchstens maxPx). Null, wenn es sich nicht als JPEG liefern lässt.
     Gemeinsam für das Reisebuch und den Schadensbericht (seit 2.0.91). */
  function jpegAusBlob(blob, maxPx) {
      function roh() {
        return (blob.arrayBuffer ? blob.arrayBuffer() : Promise.reject(new Error('nicht lesbar'))).then(function (ab) {
          var b = new Uint8Array(ab);
          return MM.Pdf.jpegInfo(b) ? b : null;
        });
      }
      var g = typeof self !== 'undefined' ? self : null;
      var kannZeichnen = g && typeof g.createImageBitmap === 'function' && (typeof g.OffscreenCanvas === 'function' || (g.document && g.document.createElement));
      if (!kannZeichnen) return roh();
      return g.createImageBitmap(blob).then(function (bm) {
        var f = Math.min(1, maxPx / Math.max(bm.width, bm.height)), w = Math.max(1, Math.round(bm.width * f)), h = Math.max(1, Math.round(bm.height * f));
        var c = typeof g.OffscreenCanvas === 'function' ? new g.OffscreenCanvas(w, h) : Object.assign(g.document.createElement('canvas'), { width: w, height: h });
        var cx = c.getContext('2d');
        cx.fillStyle = '#fff'; cx.fillRect(0, 0, w, h);
        cx.drawImage(bm, 0, 0, w, h);
        if (bm.close) bm.close();
        var nachBlob = c.convertToBlob ? c.convertToBlob({ type: 'image/jpeg', quality: 0.78 }) : new Promise(function (ok) { c.toBlob(ok, 'image/jpeg', 0.78); });
        return nachBlob.then(function (jb) { return jb ? jb.arrayBuffer() : null; }).then(function (ab) { return ab ? new Uint8Array(ab) : null; });
      }).catch(function () { return roh().catch(function () { return null; }); });
  }

  /* Das PDF des Reisebuchs. opt: { bilder, kosten, notizen }. Ergebnis: { ok, bytes, name, mime, bilder, ohneBild, zuViele } oder { ok: false, fehler }. */
  Daten.prototype.reisebuchPdf = function (aktivitaetId, opt, kartenOpt) {
    var self = this;
    return this.reisebuchLaden(aktivitaetId).then(function (roh) {
      if (!roh) return { ok: false, fehler: 'Diese Reise wurde nicht gefunden.' };
      var buch = MM.Reisebuch.bauen(roh, opt, { datum: self.jetztLokal() });
      var ids = buch.bildIds.slice(0, MM.Reisebuch.MAX_BILDER_PDF), bilder = {};
      var kette = Promise.resolve();
      ids.forEach(function (id) { kette = kette.then(function () { return self.reisebuchBild(id).then(function (b) { if (b) bilder[id] = b; }).catch(function () {}); }); });
      /* Karten (seit 2.0.108): das gespeicherte Bild, sonst wird es jetzt gezeichnet */
      var karten = { reise: null, tage: {} };
      kette = kette.then(function () {
        var tageIds = buch.tage.filter(function (t) { return t.karte; }).map(function (t) { return t.tagId; });
        if (!buch.uebersichtskarte && !tageIds.length) return null;
        return self.reisebuchKarten(aktivitaetId, Object.assign({}, kartenOpt || {}, { reise: buch.uebersichtskarte, tageIds: tageIds })).then(function (k) { karten = k; });
      });
      return kette.then(function () {
        var p = MM.Reisebuch.pdf(buch, bilder, { datum: self.jetztLokal(), karten: karten });
        return { ok: true, bytes: p.bytes, name: MM.Reisebuch.dateiName(buch, '.pdf'), mime: 'application/pdf', bilder: p.bilder, ohneBild: p.ohneBild, zuViele: p.zuViele, karten: p.karten, ohneKarte: p.ohneKarte };
      });
    });
  };

  /* ---------- Smart Capture (2.0.96): Nachweise und Fahrzeugpapiere von Foto oder Scan ----------
   * Die Erkennung läuft nur auf dem Gerät (js/erfassung*.js). Hier liegt, was dauerhaft gespeichert wird:
   *  - Vorlagen: Dokument „erfassungsvorlagen“ in „einstellungen“ (keine Umstellung der Datenbank, in der Sicherung enthalten).
   *    { id, vorlagen: { <artId>: { felder: { <rolle>: { x0, y0, x1, y1 } } , gelernt: <Anzahl> } } }
   *    Die Vorlage ist die STRUKTUR (wo steht was, relativ zum Dokument). Persönliche Angaben stehen nie darin, sie liegen im Nachweis.
   *  - Das Anlegen: Person oder Fahrzeug (falls neu) und der Nachweis mit dem Original-Scan. */
  var ERFASSUNG_DOK = 'erfassungsvorlagen';

  Daten.prototype.erfassungVorlagen = function () {
    return this.speicher.holen('einstellungen', ERFASSUNG_DOK).then(function (d) { return (d && d.vorlagen) || {}; });
  };
  Daten.prototype.erfassungVorlageMerken = function (artId, rolle, box) {
    var self = this;
    if (!artId || !rolle || !box) return Promise.resolve({ ok: false });
    ['x0', 'y0', 'x1', 'y1'].forEach(function (k) { box[k] = Math.max(0, Math.min(1, Number(box[k]))); });
    return this.speicher.holen('einstellungen', ERFASSUNG_DOK).then(function (dok) {
      var d = dok ? JSON.parse(JSON.stringify(dok)) : { id: ERFASSUNG_DOK };
      d.vorlagen = d.vorlagen || {};
      var v = d.vorlagen[artId] = d.vorlagen[artId] || { felder: {}, gelernt: 0 };
      v.felder[rolle] = { x0: box.x0, y0: box.y0, x1: box.x1, y1: box.y1 };
      v.gelernt = (v.gelernt || 0) + 1;
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  /* Gelernte Stellen zurücksetzen (nur Struktur, keine Personendaten): auf Wunsch, wenn eine Stelle falsch gelernt wurde. */
  Daten.prototype.erfassungVorlagenZuruecksetzen = function () {
    var self = this;
    return this.speicher.holen('einstellungen', ERFASSUNG_DOK).then(function (dok) {
      if (!dok) return { ok: true };
      var d = JSON.parse(JSON.stringify(dok)); d.vorlagen = {};
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  /* Eigene Dokumentarten (seit 2.0.100): Dokument „erfassungsarten“ in „einstellungen“ (in der Sicherung enthalten, keine Umstellung der Datenbank).
     { id, arten: { <EIGEN_…>: { id, name, gehoertZu, welt, angaben: [{ rolle, label, typ }], schluessel: [Text] } } }. Es steht nie ein persönlicher Wert darin, nur die Beschriftungen und die Stichworte zum Erkennen. */
  var ERFASSUNG_ARTEN_DOK = 'erfassungsarten';
  Daten.prototype.erfassungEigeneArten = function () {
    return this.speicher.holen('einstellungen', ERFASSUNG_ARTEN_DOK).then(function (d) {
      var liste = d && d.arten ? Object.keys(d.arten).map(function (k) { return d.arten[k]; }) : [];
      liste.forEach(function (def) { MM.Erfassung.eigeneArtRegistrieren(def); });
      return liste;
    });
  };
  Daten.prototype.erfassungEigeneArtMerken = function (def) {
    var self = this;
    if (!def || !/^EIGEN_/.test(def.id || '') || !String(def.name || '').trim()) return Promise.resolve({ ok: false });
    return this.speicher.holen('einstellungen', ERFASSUNG_ARTEN_DOK).then(function (dok) {
      var d = dok ? JSON.parse(JSON.stringify(dok)) : { id: ERFASSUNG_ARTEN_DOK };
      d.arten = d.arten || {};
      d.arten[def.id] = { id: def.id, name: String(def.name).trim(), gehoertZu: def.gehoertZu === 'person' ? 'person' : 'fahrzeug', welt: def.welt || '',
        angaben: (def.angaben || []).map(function (a) { return { rolle: a.rolle, label: a.label, typ: a.typ || 'text' }; }), schluessel: (def.schluessel || []).slice(0, 3) };
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  /* Eine gescannte Rechnung als Kostenposten eines Fahrzeugs, die Datei als Beleg daran (seit 2.0.100).
     opt: { fahrzeugId, gruppe, werte: { lieferant, rechnungsnummer, datum, betrag }, datei }. Gibt { ok, kostenId, dokumentId } oder { ok: false, fehler }. */
  Daten.prototype.erfassungRechnungSpeichern = function (opt) {
    var self = this, w = opt.werte || {};
    var roh = { gruppe: opt.gruppe || 'instandhaltung', bezeichnung: [w.lieferant || 'Rechnung', w.rechnungsnummer ? 'Nr. ' + w.rechnungsnummer : ''].filter(Boolean).join(' '),
      betrag: w.betrag, datum: w.datum || self.heute(), grundlage: 'eingegeben', notiz: w.rechnungsnummer ? 'Rechnungsnummer ' + w.rechnungsnummer : '' };
    return this.kostenAnlegen(opt.fahrzeugId, roh).then(function (k) {
      if (!k.ok) return k;
      if (!opt.datei) return { ok: true, kostenId: k.id };
      return self.dokumentAnlegen(opt.fahrzeugId, null, { quelle: 'datei', art: 'beleg', bezeichnung: 'Rechnung ' + (w.lieferant || ''), datei: opt.datei }, null, k.id).then(function (d) {
        return d.ok ? { ok: true, kostenId: k.id, dokumentId: d.id } : { ok: true, kostenId: k.id, dokumentFehler: d.fehler };
      });
    });
  };

  /* Die Personen mit den Angaben, an denen man sie erkennt (Name, Vorname, Geburtsdatum), gelesen aus ihren Nachweisen. */
  Daten.prototype.erfassungPersonen = function () {
    var self = this;
    return Promise.all([this.personenListe(), this.speicher.alle('nachweise'), this.speicher.alle('verlaeufe'), this.nachweisartenListe('person')]).then(function (r) {
      var arten = {}; r[3].forEach(function (a) { arten[a.objekt.id] = a; });
      var ver = {}; r[2].forEach(function (e) { if (e.objektTyp === 'nachweis') (ver[e.objektId] = ver[e.objektId] || []).push(e); });
      return r[0].map(function (p) {
        var ident = {};
        r[1].filter(function (n) { return n.besitzerTyp === 'person' && n.besitzerId === p.objekt.id; }).forEach(function (n) {
          var l = (ver[n.id] || []).slice().sort(nachNr), a = l[l.length - 1], art = arten[n.artId];
          if (!a || !art) return;
          var i = MM.Erfassung.identitaetAus(MM.Nachweise.felderFuer(art.aktuell.werte), a.werte);
          Object.keys(i).forEach(function (k) { if (i[k] && !ident[k]) ident[k] = i[k]; });
        });
        return { id: p.objekt.id, name: p.aktuell.werte.bezeichnung, nachweisAnzahl: 0, nachname: ident.nachname || '', vorname: ident.vorname || '', geburtsdatum: ident.geburtsdatum || '' };
      });
    });
  };

  /* Die Art des Nachweises für den Nutzer bereitstellen: übernimmt den Vorschlag, wenn es die Art noch nicht gibt, und ergänzt fehlende Felder.
     Gibt { ok, art, felder } mit den Feldern, in die geschrieben wird. */
  Daten.prototype.erfassungArtBereit = function (vorschlagId, angaben, werte) {
    var self = this;
    return this.nachweisartenListe().then(function (liste) {
      var eigen = /^EIGEN_/.test(vorschlagId) ? MM.Erfassung.ARTEN[vorschlagId] : null;
      var da = liste.filter(function (x) {
        if (x.aktuell.werte.ausgeblendet === 'ja') return false;
        return eigen ? String(x.aktuell.werte.bezeichnung || '').toLowerCase() === eigen.name.toLowerCase() && x.aktuell.werte.gehoertZu === eigen.gehoertZu : x.aktuell.werte.vorschlagId === vorschlagId;
      })[0];
      if (da) return da;
      /* Eigene Dokumentart: die Nachweisart wird beim ersten Speichern mit den Feldern angelegt, die der Nutzer zugeordnet hat */
      var anlegen = eigen
        ? self.nachweisartAnlegen({ bezeichnung: eigen.name, gehoertZu: eigen.gehoertZu, hatAblauf: 'ja', ausgeblendet: 'nein', land: '', beschreibung: 'Von dir angelegt beim Erfassen eines unbekannten Dokuments.',
          felder: eigen.angaben.filter(function (an) { return an.rolle !== 'nummer' && an.rolle !== 'aussteller' && an.rolle !== 'ausgestelltAm' && an.rolle !== 'gueltigBis'; }).map(function (an) { return { label: an.label, typ: an.typ === 'datum' ? 'datum' : 'text', papier: '' }; }) })
        : self.nachweisartAusVorschlag(vorschlagId);
      return anlegen.then(function (r) {
        if (!r.ok) return null;
        return self.nachweisartLaden(r.id);
      }).then(function (x) { return x ? { objekt: x.objekt, aktuell: x.aktuell } : null; });
    }).then(function (art) {
      if (!art) return { ok: false, fehler: { allgemein: 'Die Art des Nachweises konnte nicht bereitgestellt werden.' } };
      var aw = art.aktuell.werte, felder = MM.Nachweise.felderFuer(aw);
      var ab = MM.Erfassung.aufFelderAbbilden(vorschlagId, felder, werte);
      if (!ab.fehlend.length) return { ok: true, artId: art.objekt.id, felder: felder, abbild: ab };
      /* Die Art kennt noch kein Feld für diese Angaben (zum Beispiel Name auf dem Funkzeugnis): als weitere Angabe ergänzen. */
      var neu = (aw.felder || []).map(function (z) { return { key: z.key, label: z.label, typ: z.typ, papier: z.papier || '' }; });
      var gesehen = {};
      ab.fehlend.forEach(function (an) {
        if (gesehen[an.rolle]) return; gesehen[an.rolle] = true;
        if (an.rolle === 'geburtsort' || an.rolle === 'geburtsdatum') {
          if (gesehen.geburt) return; gesehen.geburt = true;
          neu.push({ label: 'Geburtsdatum und Geburtsort', typ: 'text', papier: '' }); return;
        }
        neu.push({ label: an.label, typ: an.typ === 'datum' ? 'datum' : 'text', papier: an.papier || '' });
      });
      return self.nachweisartAendern(art.objekt.id, { bezeichnung: aw.bezeichnung, hatAblauf: aw.hatAblauf, land: aw.land, beschreibung: aw.beschreibung, ausgeblendet: aw.ausgeblendet, felder: neu }).then(function (r) {
        return self.nachweisartLaden(art.objekt.id);
      }).then(function (x) {
        var f2 = MM.Nachweise.felderFuer(x.aktuell.werte);
        return { ok: true, artId: art.objekt.id, felder: f2, abbild: MM.Erfassung.aufFelderAbbilden(vorschlagId, f2, werte) };
      });
    });
  };

  /*
   * Übernimmt das bestätigte Ergebnis.
   *  opt: { vorschlagId, werte: { rolle: Text }, datei: Blob (Original-Scan), personId | neuePerson: true, fahrzeugId | fahrzeugArt + bezeichnung, trotzdem }
   * Nichts wird gespeichert, bevor der Nutzer bestätigt hat (das ruft die Ansicht erst dann auf).
   */
  Daten.prototype.erfassungSpeichern = function (opt) {
    var self = this, a = MM.Erfassung.ARTEN[opt.vorschlagId], werte = opt.werte || {};
    if (!a) return Promise.resolve({ ok: false, fehler: { allgemein: 'Diese Art wird nicht unterstützt.' } });
    var vorher = a.gehoertZu === 'person'
      ? (opt.personId ? Promise.resolve({ ok: true, id: opt.personId })
        : self.personAnlegen({ bezeichnung: [werte.vorname, werte.nachname].filter(Boolean).join(' ').trim() || 'Neue Person' }))
      : (opt.fahrzeugId ? Promise.resolve({ ok: true, id: opt.fahrzeugId }) : self.erfassungFahrzeugAnlegen(opt));
    return vorher.then(function (b) {
      if (!b.ok) return b;
      return self.erfassungArtBereit(opt.vorschlagId, a.angaben, werte).then(function (art) {
        if (!art.ok) return art;
        var roh = Object.assign({}, art.abbild.werte);
        if (opt.datei) roh.datei = opt.datei;
        return self.nachweisAnlegen(a.gehoertZu, b.id, art.artId, roh).then(function (n) {
          if (!n.ok) return { ok: false, fehler: n.fehler, besitzerId: b.id };
          var erg = { ok: true, besitzerId: b.id, besitzerTyp: a.gehoertZu, nachweisId: n.id, neu: !opt.personId && !opt.fahrzeugId };
          /* Ein neues Fahrzeug bekommt gleich seine Motoren als Komponenten (seit 2.0.99). */
          if (a.gehoertZu !== 'fahrzeug' || opt.fahrzeugId || !(opt.motoren > 0)) return erg;
          return self.erfassungMotorenAnlegen(b.id, werte, opt.motoren, { teilen: opt.vorschlagId === 'DE_IBS' }).then(function (m) { erg.motoren = m.angelegt; if (m.geteilt) erg.motorenGeteilt = true; if (m.fehler) erg.motorenFehler = m.fehler; return erg; });
        });
      });
    });
  };

  /* Die Motoren eines neuen Fahrzeugs als Komponenten der Art „Motor“ (seit 2.0.99, erweitert 2.0.100).
     Leistung (kW), Hubraum (cm³) und Kraftstoff stehen als technische Merkmale an jedem Motor, dazu Hersteller (Fabrikat), Baujahr und die Motornummer aus dem Papier.
     bei mehreren heißen die Motoren „Motor 1“, „Motor 2“ …; der Nutzer ändert sie später je Motor.
     Steht die Leistung einmal für alle Motoren im Papier (Bootsschein), teilt MobiMory sie gleichmäßig auf (opt.teilen) und vermerkt das am Motor; der Nutzer korrigiert später.
     Gibt { angelegt: Anzahl, geteilt: true | undefined, fehler: Text | undefined }. */
  Daten.prototype.erfassungMotorenAnlegen = function (fahrzeugId, w, anzahl, opt) {
    var self = this, n = Math.max(0, Math.min(6, parseInt(anzahl, 10) || 0)), i = 0, angelegt = 0, fehler, geteilt = false;
    opt = opt || {};
    var nummern = String(w.motorNummer || '').split(/[,;\s]+/).filter(Boolean);
    function kw() {
      if (!w.leistung) return '';
      var v = parseFloat(String(w.leistung).replace(',', '.'));
      if (!isFinite(v)) return String(w.leistung);
      if (opt.teilen && n > 1) { geteilt = true; v = v / n; }
      return String(Math.round(v * 10) / 10);
    }
    var leistung = kw();
    function weiter() {
      if (i >= n) return Promise.resolve({ angelegt: angelegt, geteilt: geteilt || undefined, fehler: fehler });
      i++;
      var merk = [];
      if (leistung) merk.push({ name: 'Leistung', wert: leistung, einheit: 'kW' });
      if (geteilt) merk.push({ name: 'Hinweis zur Leistung', wert: 'Vom Bootsschein auf die Motoren aufgeteilt, bitte prüfen', einheit: '' });
      if (w.hubraum) merk.push({ name: 'Hubraum', wert: String(w.hubraum), einheit: 'cm³' });
      if (w.kraftstoff) merk.push({ name: 'Kraftstoff', wert: String(w.kraftstoff) });
      if (w.einbauart) merk.push({ name: 'Einbau', wert: String(w.einbauart) });
      var roh = { bezeichnung: n > 1 ? 'Motor ' + i : 'Motor', merkmale: merk };
      if (w.motorFabrikat) roh.hersteller = w.motorFabrikat;
      if (w.motorBaujahr) roh.baujahr = w.motorBaujahr;
      var nr = nummern.length === n ? nummern[i - 1] : (n === 1 && nummern.length ? nummern[0] : '');
      if (nr) roh.seriennummer = nr;
      return self.komponenteAnlegen(fahrzeugId, null, 'motor', roh).then(function (r) {
        if (r.ok) angelegt++; else fehler = fehler || (r.fehler && (r.fehler.allgemein || Object.keys(r.fehler).map(function (k) { return r.fehler[k]; }).join(' '))) || 'Ein Motor konnte nicht angelegt werden.';
        return weiter();
      });
    }
    return weiter();
  };

  /* Fahrzeug aus den gelesenen Angaben der Zulassungsbescheinigung oder des Bootsscheins. */
  Daten.prototype.erfassungFahrzeugAnlegen = function (opt) {
    var w = opt.werte || {}, art = opt.fahrzeugArt || 'auto', fa = MM.Fahrzeugarten.art(art), boot = opt.vorschlagId === 'DE_IBS' || /^EIGEN_/.test(opt.vorschlagId || '');
    var roh = { bezeichnung: opt.bezeichnung || w.bootsname || [w.marke, w.modell].filter(Boolean).join(' ').trim() || w.kennzeichen || w.nummer || 'Neues Fahrzeug' };
    var erlaubt = fa ? fa.felder : [];
    function mm(v) { var n = parseFloat(String(v).replace(',', '.')); return isFinite(n) ? (boot ? n : n / 1000) : ''; }
    function zahl(v) { var n = parseFloat(String(v).replace(',', '.')); return isFinite(n) ? n : ''; }
    ['marke', 'modell', 'typ', 'kennzeichen', 'fin', 'erstzulassung', 'plaetze', 'leergewicht', 'gesamtgewicht', 'hoechstgeschwindigkeit', 'achsen', 'hin', 'heimathafen', 'baumaterial'].forEach(function (k) { if (w[k] && erlaubt.indexOf(k) >= 0) roh[k] = w[k]; });
    ['laenge', 'breite', 'hoehe'].forEach(function (k) { if (w[k] && erlaubt.indexOf(k) >= 0) roh[k] = mm(w[k]); });
    ['tiefgang', 'durchfahrtshoehe', 'verdraengung'].forEach(function (k) { if (w[k] && erlaubt.indexOf(k) >= 0) roh[k] = zahl(w[k]); });
    if (w.baujahr && erlaubt.indexOf('baujahr') >= 0) { var bj = parseInt(w.baujahr, 10); if (isFinite(bj)) roh.baujahr = bj; }
    if (art !== 'auto' && w.nummer && erlaubt.indexOf('registriernummer') >= 0) roh.registriernummer = w.nummer;
    var ks = MM.Erfassung.kraftstoffWahl(w.kraftstoff);
    if (ks && erlaubt.indexOf('kraftstoff') >= 0) roh.kraftstoff = ks;
    return this.fahrzeugAnlegen(art, roh, { trotzdem: !!opt.trotzdem });
  };

  /* ---------- Schadensbericht (2.0.91, Bau C) ----------
   * Ein Bericht gehört zu einem Fahrzeug und hängt freiwillig an einem Werkstatt-Vorgang (Störung). Alle Berichte liegen in einem Dokument
   * „schadensberichte“ in „einstellungen“ (in der Sicherung enthalten, keine Umstellung der Datenbank):
   * { id, berichte: [{ id, fahrzeugId, vorgangId|null, erstelltAm, geaendertAm, ausgeblendet, werte }] }. Nichts wird gelöscht, nur ausgeblendet.
   * Belege (Fotos, Kostenvoranschlag, Gutachten, Rechnungen) kommen aus der Dokumentenliste des Vorgangs (7c), nichts wird doppelt abgelegt. */
  var SCHADEN_DOK = 'schadensberichte';

  function schadenDok(dok) {
    var d = dok ? JSON.parse(JSON.stringify(dok)) : { id: SCHADEN_DOK };
    if (!Array.isArray(d.berichte)) d.berichte = [];
    return d;
  }

  function kennzeichenVon(art, werte) {
    var a = MM.Fahrzeugarten.artSicher(art);
    return text2(werte && (werte[a && a.kennung] || werte.kennzeichen || werte.registriernummer));
  }
  function text2(v) { return v === null || v === undefined ? '' : String(v).trim(); }

  /* Die Berichte eines Fahrzeugs, neueste zuerst. mitAusgeblendeten: auch die ausgeblendeten. */
  Daten.prototype.schadensberichteListe = function (fahrzeugId, mitAusgeblendeten) {
    return this.speicher.holen('einstellungen', SCHADEN_DOK).then(function (dok) {
      return schadenDok(dok).berichte.filter(function (b) { return b.fahrzeugId === fahrzeugId && (mitAusgeblendeten || !b.ausgeblendet); })
        .sort(function (a, b) { var x = a.werte.datum || '', y = b.werte.datum || ''; return x < y ? 1 : (x > y ? -1 : (a.erstelltAm < b.erstelltAm ? 1 : -1)); });
    });
  };

  /* Wie viele Berichte (nicht ausgeblendet) je Fahrzeug, für die Übersicht. */
  Daten.prototype.schadensberichteAnzahl = function () {
    return this.speicher.holen('einstellungen', SCHADEN_DOK).then(function (dok) {
      var z = {};
      schadenDok(dok).berichte.forEach(function (b) { if (!b.ausgeblendet) z[b.fahrzeugId] = (z[b.fahrzeugId] || 0) + 1; });
      return z;
    });
  };

  /* Die Vorgänge des Fahrzeugs zur Auswahl im Formular (neueste zuerst, wie die Werkstatt sie sortiert). */
  Daten.prototype.schadensberichtVorgaenge = function (fahrzeugId) {
    return this.vorgaengeListe(fahrzeugId).then(function (l) {
      return l.map(function (x) { return { wert: x.vorgang.id, label: x.aktuell.werte.bezeichnung + (x.aktuell.werte.status === 'erledigt' ? ' (erledigt)' : '') }; });
    });
  };

  /* Was das Formular vorab weiß: Fahrzeug und Kennzeichen zur Anzeige, Datum, Zeit und Ort aus dem Logbuch, wenn der Bericht aus einer Störung entsteht.
     Ergebnis { ok, fahrzeug: { id, name, artName, kennzeichen }, vorgangId, vorgangName, werte } oder { ok: false, fehler }. */
  Daten.prototype.schadensberichtVorschlag = function (fahrzeugId, vorgangId) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (f) {
      if (!f) return { ok: false, fehler: 'Dieses Fahrzeug wurde nicht gefunden.' };
      var fz = { id: fahrzeugId, name: f.aktuell.werte.bezeichnung, artName: MM.Fahrzeugarten.artSicher(f.fahrzeug.art).name, kennzeichen: kennzeichenVon(f.fahrzeug.art, f.aktuell.werte), schadenTelefon: text2(f.aktuell.werte.schadenTelefon) };
      var fzW = f.aktuell.werte, vers = { versicherung: text2(fzW.versicherung), schadennummer: text2(fzW.versicherungsnummer) };
      if (!vorgangId) return { ok: true, fahrzeug: fz, vorgangId: null, vorgangName: '', werte: Object.assign(MM.Schadensbericht.leer(), vers) };
      return self.vorgangLaden(vorgangId).then(function (v) {
        if (!v || v.fahrzeug.id !== fahrzeugId) return { ok: false, fehler: 'Dieser Vorgang wurde nicht gefunden.' };
        var eint = v.vorgang.ereignisId ? self.ereignisKurz(v.vorgang.ereignisId) : Promise.resolve(null);
        return eint.then(function (e) {
          return { ok: true, fahrzeug: fz, vorgangId: vorgangId, vorgangName: v.aktuell.werte.bezeichnung, werte: Object.assign(MM.Schadensbericht.vorschlag(e, v.aktuell.werte), vers) };
        });
      });
    });
  };

  function schadenVorgangPruefen(self, fahrzeugId, vorgangId) {
    if (!vorgangId) return Promise.resolve(null);
    return self.speicher.holen('vorgaenge', vorgangId).then(function (v) {
      return v && v.fahrzeugId === fahrzeugId ? null : { vorgangId: 'Dieser Vorgang gehört nicht zu diesem Fahrzeug.' };
    });
  }

  /* Die Störung zu einem Bericht anlegen (seit 2.0.93): Schadenart und Datum als Bezeichnung, Hergang gekürzt als Beschreibung, Einschränkung „keine“.
     Ergebnis { ok, id } oder { ok: false, fehler }. */
  function schadenStoerungAnlegen(self, fahrzeugId, werte) {
    return self.vorgangAnlegen(fahrzeugId, null, 'stoerung', MM.Schadensbericht.stoerungAus(werte)).then(function (v) {
      return v.ok ? v : { ok: false, fehler: { allgemein: 'Die Störung zum Bericht konnte nicht angelegt werden.' } };
    });
  }

  /* Anlegen. Ohne vorgangId legt MobiMory die Störung dazu (genau eine); mit vorgangId hängt der Bericht an dieser Störung und es entsteht keine zweite.
     Ergebnis { ok, id, vorgangId, stoerungNeu }. */
  Daten.prototype.schadensberichtAnlegen = function (fahrzeugId, vorgangId, roh) {
    var self = this;
    var p = MM.Schadensbericht.pruefen(roh, this.heute());
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return Promise.all([this.fahrzeugLaden(fahrzeugId), schadenVorgangPruefen(this, fahrzeugId, vorgangId || null)]).then(function (r) {
      if (!r[0]) return { ok: false, fehler: { allgemein: 'Dieses Fahrzeug wurde nicht gefunden.' } };
      if (r[1]) return { ok: false, fehler: r[1] };
      var stoerung = vorgangId ? Promise.resolve({ ok: true, id: vorgangId, vorhanden: true }) : schadenStoerungAnlegen(self, fahrzeugId, p.werte);
      return stoerung.then(function (st) {
        if (!st.ok) return st;
        return self.speicher.holen('einstellungen', SCHADEN_DOK).then(function (dok) {
          var d = schadenDok(dok), jetzt = self.jetzt();
          var b = { id: neueId('sb'), fahrzeugId: fahrzeugId, vorgangId: st.id, erstelltAm: jetzt, geaendertAm: jetzt, ausgeblendet: false, werte: p.werte };
          d.berichte.push(b);
          return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, id: b.id, vorgangId: st.id, stoerungNeu: !st.vorhanden }; });
        });
      });
    });
  };

  /* Ändern: vorgangId ist der (neu) gewählte Vorgang oder null. Die Angaben werden ersetzt, der Bericht bleibt derselbe. */
  Daten.prototype.schadensberichtAendern = function (id, vorgangId, roh) {
    var self = this;
    var p = MM.Schadensbericht.pruefen(roh, this.heute());
    if (!p.ok) return Promise.resolve({ ok: false, fehler: p.fehler });
    return this.speicher.holen('einstellungen', SCHADEN_DOK).then(function (dok) {
      var d = schadenDok(dok), b = d.berichte.filter(function (x) { return x.id === id; })[0];
      if (!b) return { ok: false, fehler: { allgemein: 'Dieser Bericht wurde nicht gefunden.' } };
      return schadenVorgangPruefen(self, b.fahrzeugId, vorgangId || null).then(function (f) {
        if (f) return { ok: false, fehler: f };
        b.werte = p.werte; b.vorgangId = vorgangId || b.vorgangId || null; b.geaendertAm = self.jetzt(); /* ohne neue Wahl bleibt der Bericht an seiner Störung (keine zweite) */
        return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true, id: id }; });
      });
    });
  };

  /* Ein Foto oder Beleg zum Bericht (seit 2.0.93). roh: { datei, bezeichnung? }. Das Dokument hängt an der Störung des Berichts; hat der Bericht noch keine
     (von Hand angelegt, vor 2.0.93), entsteht sie jetzt, einmal. Bilder sind „Foto“, alles andere „Beleg“. Ergebnis { ok, id (Dokument), vorgangId, stoerungNeu }. */
  Daten.prototype.schadensberichtFotoAnlegen = function (berichtId, roh) {
    var self = this;
    roh = roh || {};
    var datei = roh.datei;
    if (!(datei && typeof datei === 'object' && datei.size > 0)) return Promise.resolve({ ok: false, fehler: { datei: 'Bitte ein Foto aufnehmen oder eine Datei auswählen.' } });
    return this.speicher.holen('einstellungen', SCHADEN_DOK).then(function (dok) {
      var b = schadenDok(dok).berichte.filter(function (x) { return x.id === berichtId; })[0];
      if (!b) return { ok: false, fehler: { allgemein: 'Dieser Bericht wurde nicht gefunden.' } };
      var stoerung;
      if (b.vorgangId) stoerung = Promise.resolve({ ok: true, id: b.vorgangId, vorhanden: true });
      else {
        stoerung = schadenStoerungAnlegen(self, b.fahrzeugId, b.werte).then(function (st) {
          if (!st.ok) return st;
          return self.speicher.holen('einstellungen', SCHADEN_DOK).then(function (dok2) {
            var d = schadenDok(dok2), b2 = d.berichte.filter(function (x) { return x.id === berichtId; })[0];
            b2.vorgangId = st.id; b2.geaendertAm = self.jetzt();
            return self.speicher.speichern('einstellungen', d).then(function () { return st; });
          });
        });
      }
      return stoerung.then(function (st) {
        if (!st.ok) return st;
        return self.dokumenteFuerVorgang(st.id).then(function (vorhanden) {
          var istBild = /^image\//.test(String(datei.type || ''));
          var name = String(roh.bezeichnung == null ? '' : roh.bezeichnung).trim() || ((istBild ? 'Schadensfoto ' : 'Beleg ') + (vorhanden.length + 1));
          return self.dokumentAnlegen(b.fahrzeugId, null, { quelle: 'datei', datei: datei, art: istBild ? 'foto' : 'beleg', bezeichnung: name }, st.id).then(function (r) {
            return r.ok ? { ok: true, id: r.id, vorgangId: st.id, stoerungNeu: !st.vorhanden } : r;
          });
        });
      });
    });
  };

  Daten.prototype.schadensberichtAusblenden = function (id, ausblenden) {
    var self = this;
    return this.speicher.holen('einstellungen', SCHADEN_DOK).then(function (dok) {
      var d = schadenDok(dok), b = d.berichte.filter(function (x) { return x.id === id; })[0];
      if (!b) return { ok: false, fehler: { allgemein: 'Dieser Bericht wurde nicht gefunden.' } };
      b.ausgeblendet = !!ausblenden; b.geaendertAm = self.jetzt();
      return self.speicher.speichern('einstellungen', d).then(function () { return { ok: true }; });
    });
  };

  /* Ein Bericht mit allem, was die Seite und das PDF brauchen. Liest nur. Null, wenn es ihn nicht gibt.
     Belege: die Dokumente des Vorgangs; istBild = eine Bilddatei (image/…). */
  Daten.prototype.schadensberichtLaden = function (id) {
    var self = this;
    return this.speicher.holen('einstellungen', SCHADEN_DOK).then(function (dok) {
      var b = schadenDok(dok).berichte.filter(function (x) { return x.id === id; })[0];
      if (!b) return null;
      return Promise.all([self.fahrzeugLaden(b.fahrzeugId), b.vorgangId ? self.vorgangLaden(b.vorgangId) : Promise.resolve(null), b.vorgangId ? self.dokumenteFuerVorgang(b.vorgangId) : Promise.resolve([])]).then(function (r) {
        var f = r[0];
        if (!f) return null;
        var belege = r[2].map(function (x) {
          var w = x.aktuell.werte;
          return { id: x.dokument.id, bezeichnung: w.bezeichnung, art: MM.Dokumente.artLabel(w.art), istBild: w.quelle === 'datei' && /^image\//.test(w.dateiTyp || '') };
        });
        return { bericht: b, erstelltAm: b.erstelltAm, werte: b.werte, vorgang: r[1] ? { id: b.vorgangId, name: r[1].aktuell.werte.bezeichnung } : null, belege: belege,
          fahrzeug: { id: b.fahrzeugId, name: f.aktuell.werte.bezeichnung, artName: MM.Fahrzeugarten.artSicher(f.fahrzeug.art).name, kennzeichen: kennzeichenVon(f.fahrzeug.art, f.aktuell.werte), schadenTelefon: text2(f.aktuell.werte.schadenTelefon) } };
      });
    });
  };

  /* Ein Foto aus den Belegen als Blob (für die Seite) oder null. */
  Daten.prototype.schadensberichtBeleg = function (dokumentId) {
    return this.dateiHolen(dokumentId).then(function (d) { return d && d.inhalt ? d.inhalt : null; });
  };

  /* Das PDF. Ergebnis { ok, bytes, name, mime, bilder, ohneBild, zuViele } oder { ok: false, fehler }. */
  Daten.prototype.schadensberichtPdf = function (id) {
    var self = this;
    return this.schadensberichtLaden(id).then(function (roh) {
      if (!roh) return { ok: false, fehler: 'Dieser Bericht wurde nicht gefunden.' };
      var buch = MM.Schadensbericht.bauen(roh), bilder = {}, kette = Promise.resolve();
      buch.bildIds.slice(0, MM.Schadensbericht.MAX_BILDER_PDF).forEach(function (did) {
        kette = kette.then(function () {
          return self.dateiHolen(did).then(function (d) { return d && d.inhalt ? jpegAusBlob(d.inhalt, 1400) : null; }).then(function (b) { if (b) bilder[did] = b; }).catch(function () {});
        });
      });
      return kette.then(function () {
        var p = MM.Schadensbericht.pdf(buch, bilder, { datum: self.jetzt() });
        return { ok: true, bytes: p.bytes, name: MM.Schadensbericht.dateiName(buch, '.pdf'), mime: 'application/pdf', bilder: p.bilder, ohneBild: p.ohneBild, zuViele: p.zuViele };
      });
    });
  };

  function rcZeile(rec, aktuellerStand) {
    var a = MM.Reisecheck.auswerten(rec.ergebnis);
    return { id: rec.id, erstelltAm: rec.erstelltAm, gesamt: a.gesamt, zaehl: a.zaehl, wichtigFehlt: a.wichtigFehlt, wichtigPruefen: a.wichtigPruefen,
      veraltet: aktuellerStand === undefined ? null : rec.stand !== aktuellerStand, recherche: rec.ergebnis.recherche };
  }

  /* Die Checks einer Aktivität: ohne abschnittId die Gesamtchecks, mit abschnittId die Checks dieses Tages. */
  Daten.prototype.reisecheckListe = function (aktivitaetId, abschnittId) {
    return this.speicher.wo('reisechecks', 'aktivitaetId', aktivitaetId).then(function (l) {
      return l.filter(function (rec) { return abschnittId ? rec.abschnittId === abschnittId : !rec.abschnittId; }).slice().sort(function (x, y) { return x.erstelltAm < y.erstelltAm ? 1 : (x.erstelltAm > y.erstelltAm ? -1 : 0); });
    });
  };

  Daten.prototype.reisecheckLaden = function (id) {
    return this.speicher.holen('reisechecks', id).then(function (rec) {
      if (!rec) return null;
      var a = MM.Reisecheck.auswerten(rec.ergebnis);
      return { check: rec, auswertung: a, anforderungen: MM.Reisecheck.sortiert(rec.ergebnis) };
    });
  };

  /* Die Seite zu einer Aktivität: Einstellung, was hinausginge, frühere Checks (mit „veraltet“). */
  Daten.prototype.reisecheckAnsicht = function (aktivitaetId, abschnittId) {
    var self = this;
    return Promise.all([this.reisecheckAnfrage(aktivitaetId, abschnittId), this.reisecheckEinstellung(), this.reisecheckListe(aktivitaetId, abschnittId),
      this.reisecheckRegelnUeberblick(aktivitaetId, abschnittId).catch(function () { return null; })]).then(function (r) {
      var q = r[0];
      if (!q) return null;
      return { aktivitaet: q.aktivitaet, einstellung: r[1], anfrage: q.ok ? { vorschau: q.vorschau, stand: q.stand } : null, fehler: q.ok ? [] : q.fehler,
        checks: r[2].map(function (rec) { return rcZeile(rec, q.ok ? q.stand : undefined); }), regeln: r[3] };
    });
  };

  /* Für die Funktionenseite: pro Aktivität der letzte Check. */
  Daten.prototype.reisecheckUebersicht = function () {
    var self = this;
    return Promise.all([this.aktivitaetenListe(), this.speicher.alle('reisechecks')]).then(function (r) {
      var nach = {};
      r[1].forEach(function (rec) { if (rec.art === 'grund' || rec.abschnittId) return; if (!nach[rec.aktivitaetId] || nach[rec.aktivitaetId].erstelltAm < rec.erstelltAm) nach[rec.aktivitaetId] = rec; });
      return r[0].filter(function (x) { return x.status !== 'storniert'; }).map(function (x) {
        return { id: x.objekt.id, name: x.aktuell.werte.bezeichnung, fahrzeugName: x.fahrzeugName, vonDatum: x.aktuell.werte.vonDatum, bisDatum: x.aktuell.werte.bisDatum,
          status: x.status, letzter: nach[x.objekt.id] ? rcZeile(nach[x.objekt.id]) : null };
      });
    });
  };

  /* ---------- Etappen (Mehrtagesreisen, seit 2.0.43) ----------
   * Die Etappe ist der vorhandene Tagesabschnitt des Logbuchs, es gibt keine zweite Struktur. Der Tag hat Startort und Zielort (Felder
   * startOrtId und zielOrtId im Verlauf), das Wetter ergibt sich aus diesen zwei Orten, ein Wetter von Hand (wetterHand) ersetzt es.
   * Das online geholte Wetter liegt je Tag als Dokument „wetter-etappe-<tagId>“ in „einstellungen“ (wie bei der Route, in der Sicherung enthalten).
   * Kosten hängen mit dem Feld abschnittId am Tag. Alles zusammen liefert reiseZusammenfassung (eine Quelle für Aktivität, Logbuch und Tag). */
  function etappeWetterDokId(abschnittId) { return 'wetter-etappe-' + abschnittId; }

  function ortKurz(o) {
    var w = o.aktuell.werte;
    function pos(v) { return v === null || v === undefined || v === '' ? null : (isFinite(Number(v)) ? Number(v) : null); }
    return { id: o.objekt.id, name: w.bezeichnung, breite: pos(w.positionBreite), laenge: pos(w.positionLaenge), ausgeblendet: w.ausgeblendet === 'ja', land: w.land || '' };
  }

  /* Alles, was Wetter und Zusammenfassung brauchen: das Logbuch der Aktivität, die Orte und die gültige Route (oder null). */
  function etappenBasis(self, aktivitaetId) {
    return Promise.all([self.logbuchLaden(aktivitaetId), self.orteListe(), self.routeAnsicht(aktivitaetId), besucheAlleSammeln(self, aktivitaetId)]).then(function (r) {
      if (!r[0]) return null;
      var orte = {}; r[1].forEach(function (o) { orte[o.objekt.id] = ortKurz(o); });
      var b = { lb: r[0], orte: orte, orteListe: Object.keys(orte).map(function (id) { return orte[id]; }), route: r[2] && r[2].ok ? r[2].route : null, besuche: r[3] };
      b.tagOrte = tagOrteAbleiten(b);
      /* Die geplanten Tagesrouten (seit 2.0.125): Strecke und ETA eines Tages rechnen mit ihnen, nicht mit der Route der ganzen Aktivität. */
      return Promise.all(r[0].abschnitte.map(function (x) { return self.einstellungLesen(tagRouteDokId(x.objekt.id)); })).then(function (doks) {
        b.tagRouten = {};
        r[0].abschnitte.forEach(function (x, i) { b.tagRouten[x.objekt.id] = tagRouteAufbereiten(b, x, doks[i]); });
        return b;
      });
    });
  }

  /* Die gespeicherte Tagesroute für die Rechnung: { laengeKm, punkte (mit km), kmEnde, veraltet } oder null, wenn der Tag keine hat. */
  function tagRouteAufbereiten(b, x, dok) {
    if (!dok || !Array.isArray(dok.punkte) || dok.punkte.length < 2) return null;
    var to = tagOrte(b, x), auf = MM.Routen.punkteAufbereiten(dok.punkte);
    return { laengeKm: typeof dok.laengeKm === 'number' ? dok.laengeKm : auf.laengeKm, punkte: auf.punkte, kmEnde: auf.laengeKm,
      veraltet: dok.startOrtId !== to.startOrtId || dok.zielOrtId !== to.zielOrtId || JSON.stringify(Array.isArray(dok.planViaOrtIds) ? dok.planViaOrtIds : []) !== JSON.stringify(tagViaListe(dok)) };
  }

  /*
   * Welche Strecke gilt für einen Tag? Straßenfahrzeuge: die geplante Tagesroute. { pflicht: true, route, grund } mit route = null und einem Grund, wenn es keine
   * (oder nur eine veraltete) gibt. Wasser und Luft haben keine Tagesplanung: { pflicht: false }.
   */
  function tagRouteLage(b, x) {
    var welt = b.lb.aktivitaet.fahrzeug.welt;
    if (welt === 'wasser' || welt === 'luft') return { pflicht: false, route: null, grund: null };
    var t = x && b.tagRouten ? b.tagRouten[x.objekt.id] : null;
    if (!t) return { pflicht: true, route: null, grund: 'Für diesen Tag ist noch keine Route geplant. Bitte plane den Tag.' };
    if (t.veraltet) return { pflicht: true, route: null, grund: 'Start, Ziel oder Zwischenziele des Tages haben sich seit der Planung geändert. Bitte plane den Tag neu.' };
    return { pflicht: true, route: t, grund: null };
  }

  /*
   * Start und Ziel jedes sichtbaren Tages (seit 2.0.60), abgeleitet und nicht gespeichert (MM.Etappen.tagesOrte). Der Nutzer ändert jeden Tag von Hand.
   * Aus dem Logbuch kommt das beim Ablegen gewählte Ziel (letztes Ereignis des Tages mit Zielort), aus den Besuchen der Ort, an dem er an diesem Tag angelegt hat
   * (letzter Besuch des Tages). Ergebnis: { abschnittId: { startOrtId, startHerkunft, zielOrtId, zielHerkunft } }
   */
  function tagOrteAbleiten(b) {
    var a = b.lb.aktivitaet.aktuell.werte;
    var sichtbar = b.lb.abschnitte.filter(function (x) { return !x.ausgeblendet; });
    var tage = sichtbar.map(function (x) {
      var w = x.aktuell.werte, wunsch = null, tatsaechlich = null;
      x.ereignisse.forEach(function (e) {
        if (e.art !== 'ereignis' || e.ausgeblendet || !e.zielOrtId) return;
        if (!wunsch || (e.zeitpunkt || '') >= (wunsch.zeitpunkt || '')) wunsch = e;
      });
      (b.besuche || []).forEach(function (bs) {
        var v = bs.aktuell.werte;
        if (v.status !== 'besucht' || v.ausgeblendet === 'ja' || !v.ortId || v.datum !== w.datum) return;
        if (!tatsaechlich || (v.zeit || '') >= (tatsaechlich.zeit || '')) tatsaechlich = v;
      });
      return { id: x.objekt.id, datum: w.datum, startOrtId: w.startOrtId || null, zielOrtId: w.zielOrtId || null,
        wunschOrtId: wunsch && b.orte[wunsch.zielOrtId] ? wunsch.zielOrtId : null, tatsaechlichOrtId: tatsaechlich && b.orte[tatsaechlich.ortId] ? tatsaechlich.ortId : null };
    });
    return MM.Etappen.tagesOrte({ tage: tage, reiseStartId: a.startOrtId || null, reiseZielId: a.zielOrtId || null, eintaegig: !a.bisDatum || a.bisDatum === a.vonDatum });
  }
  function tagOrte(b, x) { return (b.tagOrte && b.tagOrte[x.objekt.id]) || { startOrtId: null, startHerkunft: null, zielOrtId: null, zielHerkunft: null }; }

  function tagPlan(b, x) {
    var w = x.aktuell.werte, rt = b.route, o = tagOrte(b, x), lage = tagRouteLage(b, x);
    /* Straßenfahrzeug: Die Route der ganzen Aktivität zählt für die Strecke des Tages nicht mehr (bei Rundreisen falsch); sie liefert nur noch die Geschwindigkeit. */
    return MM.Etappen.tagesPlan({ datum: w.datum, beginnZeit: w.beginnZeit || '', endeZeit: w.endeZeit || '',
      start: o.startOrtId ? b.orte[o.startOrtId] || null : null, ziel: o.zielOrtId ? b.orte[o.zielOrtId] || null : null,
      routePunkte: rt && !lage.pflicht ? rt.punkte : null, tagStrecke: lage.route ? { km: lage.route.laengeKm } : null,
      routeKmh: rt ? MM.Routen.geschwindigkeitKmh(rt.werte.geschwindigkeit, rt.werte.einheit) : null });
  }
  function tagRegel(b) { return b.route ? b.route.wetterRegel : MM.Routen.wetterRegel(null, b.lb.aktivitaet.fahrzeug.welt); }

  /*
   * Das Wetter eines Tages holen: Open-Meteo für die Punkte zwischen Start- und Zielort (Abstandsregel der Route, sonst die Voreinstellung)
   * zur Ankunftszeit. Ergebnis: { ok, punkte, ohneWetter, abgerufenAm } oder { ok: false, fehler, offline? }. Bei einem Fehler bleibt ein früherer Stand erhalten.
   */
  Daten.prototype.etappeWetterAbrufen = function (abschnittId) {
    var self = this;
    return this.abschnittLaden(abschnittId).then(function (t) {
      if (!t) return routeFehler('Dieser Tag wurde nicht gefunden.');
      var aid = t.aktivitaet.aktivitaet.id;
      return etappenBasis(self, aid).then(function (b) {
        var x = b.lb.abschnitte.filter(function (y) { return y.objekt.id === abschnittId; })[0];
        if (!x) return routeFehler('Dieser Tag wurde nicht gefunden.');
        var pl = tagPlan(b, x);
        if (pl.grund) return routeFehler(pl.grund);
        var abfahrtMs = MM.Routen.zeitMs(pl.abfahrt), jetztMs = new Date(self.jetzt()).getTime();
        if (abfahrtMs > jetztMs + MAX_VORLAUF_TAGE * 86400000) return routeFehler('Eine Prognose gibt es nur für die nächsten ' + MAX_VORLAUF_TAGE + ' Tage. Versuche es später noch einmal.');
        if (abfahrtMs < jetztMs - 86400000) return routeFehler('Dieser Tag liegt mehr als einen Tag in der Vergangenheit. Dafür holt die App kein Wetter.');
        var w = x.aktuell.werte, mitMeer = b.lb.aktivitaet.fahrzeug.welt === 'wasser', einheit = mitMeer ? 'kn' : 'kmh', regel = tagRegel(b);
        var to = tagOrte(b, x);
        var punkte = MM.Etappen.wetterMesspunkte(b.orte[to.startOrtId], b.orte[to.zielOrtId], pl.kmh, 'kmh', regel);
        if (!punkte.length) return routeFehler('Für diesen Tag lassen sich keine Wetterpunkte rechnen.');
        return wetterAntwortenHolen(self, punkte, abfahrtMs, mitMeer, einheit).then(function (antworten) {
          var ohneWetter = antworten.filter(function (a) { return !a.wetter; }).length;
          if (ohneWetter === punkte.length) return { ok: false, offline: true, fehler: { allgemein: 'Das Wetter konnte nicht geholt werden. Vermutlich ist gerade kein Netz da. Ein früher geholter Stand bleibt erhalten.' } };
          var dok = { id: etappeWetterDokId(abschnittId), abschnittId: abschnittId, aktivitaetId: aid, abgerufenAm: self.jetzt(), abfahrt: pl.abfahrt, geschwindigkeitKmh: pl.kmh,
            startOrtId: to.startOrtId, zielOrtId: to.zielOrtId, regel: regel, mitMeer: mitMeer, windEinheit: einheit, messpunkte: punkte, antworten: antworten };
          return self.einstellungSchreiben(dok).then(function () { return { ok: true, punkte: punkte.length, ohneWetter: ohneWetter, abgerufenAm: dok.abgerufenAm }; });
        });
      });
    });
  };

  /* Das Wetter eines Tages für die Anzeige: von Hand, online geholt (mit „aktuell“: passt noch zu Orten, Uhrzeit und Geschwindigkeit) oder unklar. */
  function tagWetter(x, dok, pl, regel, to) {
    var w = x.aktuell.werte;
    if (w.wetterHand) return { quelle: 'hand', text: w.wetterHand, aktuell: true, abgerufenAm: null, grund: null, zeilen: [] };
    if (dok) {
      var aus = MM.Routen.auswerten(dok.messpunkte, MM.Routen.zeitMs(dok.abfahrt), 0, dok.antworten, dok.mitMeer);
      var aktuell = !pl.grund && dok.abfahrt === pl.abfahrt && dok.startOrtId === to.startOrtId && dok.zielOrtId === to.zielOrtId && Math.abs(dok.geschwindigkeitKmh - pl.kmh) < 0.001
        && !!dok.regel && !!regel && dok.regel.art === regel.art && dok.regel.abstand === regel.abstand && dok.regel.einheit === regel.einheit;
      var text = MM.Etappen.wetterKurz(aus.schwerste, dok.windEinheit);
      return { quelle: 'online', text: text || 'Das Wettermodell liefert für diesen Tag keine Werte.', aktuell: aktuell, abgerufenAm: dok.abgerufenAm, grund: null, zeilen: aus.zeilen };
    }
    return { quelle: 'unklar', text: null, aktuell: false, abgerufenAm: null, grund: pl.grund, zeilen: [] };
  }

  /*
   * Die Zusammenfassung der ganzen Reise: eine Zeile je sichtbarem Tag (Start, Ziel, Strecke, Kosten, Ereignisse, Wetter), die Summen und die Gesamtsumme.
   * opts.fixEin: Fixkosten-Anteil in der Gesamtsumme (wie in der Reiseauswertung). Ergebnis: null oder { ok, aktivitaet, tage, streckeSumme, streckeUnklar, kostenSumme, ohneTag, gesamt, ... }.
   */
  Daten.prototype.reiseZusammenfassung = function (aktivitaetId, opts) {
    var self = this;
    return Promise.all([etappenBasis(this, aktivitaetId), kostenAlleSammeln(this), this.reiseAuswertung(aktivitaetId, opts)]).then(function (r) {
      var b = r[0], auswertung = r[2];
      if (!b || !auswertung) return null;
      var tage = b.lb.abschnitte.filter(function (x) { return !x.ausgeblendet; });
      var kosten = r[1].filter(function (k) { return k.aktuell.werte.aktivitaetId === aktivitaetId; }).map(function (k) { return { id: k.objekt.id, werte: k.aktuell.werte }; });
      var ka = MM.Etappen.kostenAnTage(kosten, tage.map(function (x) { return { id: x.objekt.id, datum: x.aktuell.werte.datum }; }));
      return Promise.all(tage.map(function (x) { return self.einstellungLesen(etappeWetterDokId(x.objekt.id)); })).then(function (doks) {
        var regel = tagRegel(b);
        var zeilen = tage.map(function (x, i) {
          var w = x.aktuell.werte, pl = tagPlan(b, x), to = tagOrte(b, x);
          return { id: x.objekt.id, datum: w.datum, beginnZeit: w.beginnZeit || null, endeZeit: w.endeZeit || null, ausserhalb: x.ausserhalb,
            start: to.startOrtId ? b.orte[to.startOrtId] || null : null, ziel: to.zielOrtId ? b.orte[to.zielOrtId] || null : null,
            startHerkunft: to.startHerkunft, zielHerkunft: to.zielHerkunft, vonText: w.von || null, nachText: w.nach || null,
            strecke: pl.strecke, ereignisse: MM.Etappen.ereignisKurz(x.ereignisse), wetter: tagWetter(x, doks[i], pl, regel, to), wetterGrund: pl.grund, planKmh: pl.kmh };
        });
        var z = MM.Etappen.zusammenfassung({ tage: zeilen, kosten: ka });
        return { ok: true, aktivitaet: { id: aktivitaetId, name: b.lb.aktivitaet.aktuell.werte.bezeichnung, welt: b.lb.aktivitaet.fahrzeug.welt },
          tage: z.zeilen, streckeSumme: z.streckeSumme, streckeUnklar: z.streckeUnklar, kostenSumme: z.kostenSumme, ohneTag: z.ohneTag, gesamt: auswertung.gesamt,
          planOrte: [b.lb.aktivitaet.aktuell.werte.startOrtId].concat(b.lb.aktivitaet.aktuell.werte.zwischenzielIds || [], [b.lb.aktivitaet.aktuell.werte.zielOrtId]).filter(Boolean),
          orteListe: b.orteListe };
      });
    });
  };

  /*
   * Die ETA zum Wunsch- oder Vorgabeziel (seit 2.0.60), für den Tag und für das Ablegen. Start und Ziel kommen vom Tag (MM.Etappen.tagesOrte),
   * ein anderes Ziel (zum Beispiel das gerade beim Ablegen gewählte) gibt opt.zielOrtId vor. Die Rechnung steht in MM.Etappen.eta.
   *  opt: { zielOrtId, startOrtId, vonPosition: { breite, laenge } (Start, wenn der Tag keinen Startort hat), abfahrtMs, jetztMs,
   *         live: { unterwegs, tagKmh, fahrendKmh, aktuellKmh, position: { breite, laenge } } }
   * Ergebnis: { ok, eta, startName, zielName, welt, verantwortlich } oder { ok: false, grund }
   * Die Geschwindigkeit des Fahrzeugs (Reise- und Höchstgeschwindigkeit) kommt aus den Angaben des Fahrzeugs, nicht aus der Route.
   */
  Daten.prototype.etaZumZiel = function (aktivitaetId, abschnittId, opt) {
    var self = this;
    opt = opt || {};
    return this.etaKontext(aktivitaetId, abschnittId, opt).then(function (k) {
      if (!k.ok) return k;
      var jetztMs = typeof opt.jetztMs === 'number' ? opt.jetztMs : new Date(self.jetzt()).getTime();
      var r = MM.Etappen.etaAusKontext(k, opt.live || {}, jetztMs);
      return { ok: true, welt: k.welt, verantwortlich: k.verantwortlich, eta: r.eta, startName: k.startName, zielName: k.zielName, zielHerkunft: k.zielHerkunft };
    });
  };

  /*
   * Alles, was die ETA außer den lebenden Werten braucht (seit 2.0.61): Ziel, Start, Route, Geschwindigkeiten des Fahrzeugs, geplante Abfahrt.
   * Dieselben Angaben wie bei etaZumZiel (opt: zielOrtId, startOrtId, vonPosition, abfahrtMs). Das Cockpit holt den Kontext einmal und rechnet
   * mit MM.Etappen.etaAusKontext bei jedem GPS-Punkt neu. Ergebnis: { ok, welt, verantwortlich, zielName, startName, zielHerkunft, ziel, startPunkt, punkte,
   * reiseKmh, hoechstKmh, abfahrtMs } oder { ok: false, grund, welt?, verantwortlich? }.
   */
  Daten.prototype.etaKontext = function (aktivitaetId, abschnittId, opt) {
    var self = this;
    opt = opt || {};
    return etappenBasis(this, aktivitaetId).then(function (b) {
      if (!b) return { ok: false, grund: 'Diese Aktivität wurde nicht gefunden.' };
      var x = b.lb.abschnitte.filter(function (y) { return y.objekt.id === abschnittId; })[0] || null;
      var to = x ? tagOrte(b, x) : { startOrtId: null, zielOrtId: null };
      var zielId = opt.zielOrtId || to.zielOrtId, startId = opt.startOrtId || to.startOrtId;
      var ziel = zielId ? b.orte[zielId] || null : null, start = startId ? b.orte[startId] || null : null;
      var welt = b.lb.aktivitaet.fahrzeug.welt;
      var basis = { ok: false, welt: welt, verantwortlich: MM.Aktivitaeten.verantwortlichenName(welt) };
      if (!ziel) return Object.assign(basis, { grund: 'Es ist noch kein Ziel gewählt.' });
      var hatPos = function (o) { return !!o && typeof o.breite === 'number' && typeof o.laenge === 'number'; };
      var startPunkt = hatPos(start) ? start : (hatPos(opt.vonPosition) ? opt.vonPosition : null);
      var lage = tagRouteLage(b, x);
      /* Die Tagesroute gilt nur für den Start und das Ziel des Tages. Wählt jemand ein anderes Ziel oder einen anderen Start, passt sie nicht. */
      var passt = !opt.zielOrtId || opt.zielOrtId === to.zielOrtId;
      if (opt.startOrtId && opt.startOrtId !== to.startOrtId) passt = false;
      if (!to.startOrtId && opt.vonPosition) passt = false;
      var tagRoute = lage.route && passt ? lage.route : null;
      var tagGrund = lage.pflicht && !tagRoute ? (lage.route ? 'Für dieses Ziel gibt es keine geplante Tagesroute. Bitte plane den Tag.' : lage.grund) : null;
      var rt = b.route, punkte = rt && !lage.pflicht ? rt.punkte : null;
      return self.fahrzeugLaden(b.lb.aktivitaet.fahrzeug.id).then(function (fz) {
        var fw = fz && fz.aktuell ? fz.aktuell.werte : {};
        var w = x ? x.aktuell.werte : {};
        var abfahrtMs = typeof opt.abfahrtMs === 'number' ? opt.abfahrtMs : (x && w.beginnZeit ? MM.Routen.zeitMs(w.datum + 'T' + w.beginnZeit) : null);
        return Object.assign(basis, { ok: true, zielName: ziel.name, startName: start ? start.name : null, zielHerkunft: opt.zielOrtId ? null : to.zielHerkunft,
          ziel: ziel, startPunkt: startPunkt, punkte: punkte, tagRoutePflicht: lage.pflicht, tagRoute: tagRoute, tagRouteGrund: tagGrund,
          reiseKmh: typeof fw.reisegeschwindigkeit === 'number' ? fw.reisegeschwindigkeit : null,
          hoechstKmh: typeof fw.hoechstgeschwindigkeit === 'number' ? fw.hoechstgeschwindigkeit : null,
          abfahrtMs: abfahrtMs });
      });
    });
  };

  /* Das Ziel, mit dem die Ablegen-Seite vorbelegt wird (seit 2.0.60): das Ziel des Tages (eigenes, beim Ablegen gewähltes, bei eintägiger Reise das der Reise). */
  Daten.prototype.ablegenVorbelegung = function (aktivitaetId, abschnittId) {
    return etappenBasis(this, aktivitaetId).then(function (b) {
      var x = b ? b.lb.abschnitte.filter(function (y) { return y.objekt.id === abschnittId; })[0] : null;
      var id = x ? tagOrte(b, x).zielOrtId : null;
      return { zielOrtId: id && b.orte[id] ? id : null };
    });
  };

  /* Orte, aus denen ein Tag Start und Ziel wählt: die Gesamtplanung der Reise, ohne Planung alle Orte (zusätzlich der schon gewählte). */
  Daten.prototype.etappeOrtOptionen = function (aktivitaetId, gewaehlt, abschnittId) {
    var self = this;
    return Promise.all([this.aktivitaetLaden(aktivitaetId), this.orteListe()]).then(function (r) {
      var a = r[0]; if (!a) return [];
      var w = a.aktuell.werte, plan = [w.startOrtId].concat(w.zwischenzielIds || [], [w.zielOrtId]).filter(Boolean);
      var orte = r[1].map(function (o) { var k = ortKurz(o); return { id: k.id, name: k.name, ausgeblendet: k.ausgeblendet }; });
      var opt = MM.Etappen.ortOptionen(plan, orte, null);
      (gewaehlt || []).forEach(function (g) { if (g && !opt.some(function (o) { return o.wert === g; })) { var o = orte.filter(function (x) { return x.id === g; })[0]; if (o) opt.push({ wert: o.id, label: o.name }); } });
      return { optionen: opt, nurPlan: plan.length > 0 };
    }).then(function (res) {
      /* Was die App für diesen Tag von selbst nimmt, wenn nichts eingetragen ist (seit 2.0.60). */
      if (!abschnittId || !res || !res.optionen) return res;
      return etappenBasis(self, aktivitaetId).then(function (b) {
        var x = b ? b.lb.abschnitte.filter(function (y) { return y.objekt.id === abschnittId; })[0] : null;
        if (!x) return res;
        var to = tagOrte(b, x);
        function nenn(id, h) { var o = id ? b.orte[id] : null; return o ? { id: id, name: o.name, herkunft: h, herkunftText: MM.Etappen.herkunftText(h) } : null; }
        res.abgeleitet = { start: to.startHerkunft === 'tag' ? null : nenn(to.startOrtId, to.startHerkunft), ziel: to.zielHerkunft === 'tag' ? null : nenn(to.zielOrtId, to.zielHerkunft) };
        return res;
      });
    });
  };

  /* ---------- Grundcheck (Schritt 11b, seit 2.0.40) ----------
   * Was braucht das Fahrzeug an seinem Heimatort (Heimatland) legal? Kein Datum, keine Besatzung.
   * Gespeichert wird in der Tabelle „reisechecks“ mit art „grund“ und aktivitaetId null (Datenbank-Version bleibt 16).
   * Der Vergleich mit dem Fahrzeug wird bei jedem Öffnen neu gerechnet, damit eine Eintragung sofort wirkt und
   * der Check nicht jedes Mal online wiederholt werden muss. Gezählt wird nichts (Entscheidung mit dem Kostenmodell). */

  /* Heimatland: der Heimatstandort des Fahrzeugs, dessen Ort und das Land darüber. { land, ortName, standortName, herkunft } */
  Daten.prototype.heimatland = function (fahrzeugId) {
    var self = this;
    return this.fahrzeugStandort(fahrzeugId).then(function (info) {
      if (!info.standort) return { land: null, ortName: null, standortName: null, herkunft: null, grund: 'Es ist noch kein Heimatstandort gewählt.' };
      return self.ortLaden(info.standort.ortId).then(function (o) {
        if (!o) return { land: null, ortName: info.standort.ortName, standortName: info.standort.name, herkunft: null, grund: 'Der Ort des Heimatstandorts wurde nicht gefunden.' };
        var land = o.gebietPfad.filter(function (g) { return g.ebene === 'land'; })[0];
        if (land) return { land: land.name, ortName: info.standort.ortName, standortName: info.standort.name, herkunft: 'gebiet', grund: null };
        var text = trimmed(o.aktuell.werte.land);
        if (text) return { land: text, ortName: info.standort.ortName, standortName: info.standort.name, herkunft: 'ort', grund: null };
        return { land: null, ortName: info.standort.ortName, standortName: info.standort.name, herkunft: null, grund: 'Beim Ort „' + info.standort.ortName + '“ ist das Land nicht bekannt. Prüfe den Ort über die Ortssuche (Stammdaten › Orte).' };
      });
    });
  };

  /* Alles, was der Check am Fahrzeug braucht (noch mit Namen, nichts davon geht hinaus außer der anonymisierten Anfrage). */
  Daten.prototype.grundcheckEingabe = function (fahrzeugId) {
    var self = this;
    return this.fahrzeugLaden(fahrzeugId).then(function (fz) {
      if (!fz) return null;
      return Promise.all([self.komponentenListe(fahrzeugId), self.nachweiseListe('fahrzeug', fahrzeugId), self.heimatland(fahrzeugId)]).then(function (r) {
        var art = MM.Fahrzeugarten.art(fz.fahrzeug.art);
        var werte = fz.aktuell.werte;
        var komponenten = MM.Komponenten.aktive(r[0]).filter(function (k) { return !k.aktuell.werte.ausgebautAm; });
        return {
          fahrzeug: { id: fz.fahrzeug.id, name: werte.bezeichnung, abgegeben: !!(fz.fahrzeug.abgabe), artId: fz.fahrzeug.art, artName: art ? art.name : '', welt: art ? art.welt : 'land', werte: werte,
            komponenten: komponenten.map(function (k) { return { name: k.aktuell.werte.bezeichnung, anzahl: k.aktuell.werte.anzahl }; }),
            nachweise: r[1].map(function (n) { return { art: n.art.aktuell.werte.bezeichnung, gescannt: !!n.aktuell.werte.dateiName, ausgestelltAm: n.aktuell.werte.ausgestelltAm || null,
              gueltigBis: MM.Nachweise.hatAblauf(n.art.aktuell.werte) ? (n.aktuell.werte.gueltigBis || null) : null, klassen: n.aktuell.werte.klassen || null }; }) },
          vergleich: {
            komponenten: komponenten.map(function (k) { return { name: k.aktuell.werte.bezeichnung, anzahl: k.aktuell.werte.anzahl, geprueft: k.aktuell.werte.eignungGeprueft }; }),
            nachweise: r[1].map(function (n) { return { artName: n.art.aktuell.werte.bezeichnung, gescannt: !!n.aktuell.werte.dateiName }; }),
            plaetze: werte.plaetze || null
          },
          heimat: r[2]
        };
      });
    });
  };

  /* Die anonymisierte Anfrage samt Vorschau und Fingerabdruck. */
  Daten.prototype.grundcheckAnfrage = function (fahrzeugId) {
    var self = this;
    return this.grundcheckEingabe(fahrzeugId).then(function (x) {
      if (!x) return null;
      var b = MM.Grundcheck.anfrageBauen({ heute: self.heute(), land: x.heimat.land, fahrzeug: x.fahrzeug });
      if (!b.ok) return { ok: false, fehler: b.fehler, eingabe: x };
      /* Der Fingerabdruck gilt ohne Datum, damit derselbe Stand an einem anderen Tag nicht als „geändert“ zählt. */
      var ohneDatum = JSON.parse(JSON.stringify(b.anfrage)); ohneDatum.trip.start = ''; ohneDatum.trip.end = '';
      return { ok: true, fehler: [], eingabe: x, anfrage: b.anfrage, vorschau: MM.Grundcheck.vorschau(b.anfrage), stand: MM.Reisecheck.fingerabdruck(ohneDatum) };
    });
  };

  Daten.prototype.grundcheckStarten = function (fahrzeugId, optionen) {
    var self = this;
    return Promise.all([this.rcGeraet(), this.reisecheckEinstellung(), this.grundcheckAnfrage(fahrzeugId)]).then(function (r) {
      var d = r[0], cfg = r[1], q = r[2];
      if (!q) return rcFehler('Dieses Fahrzeug wurde nicht gefunden.');
      if (q.eingabe.fahrzeug.abgegeben) return rcFehler('Dieses Fahrzeug ist abgegeben.');
      if (!cfg.bereit) return rcFehler('Online-Checks laufen über dein MobiMory-Konto (ab Stufe Mittel). Melde dich zuerst an.', 'einrichtung');
      if (!cfg.zugestimmt) return rcFehler('Bitte stimme zuerst zu, dass die Angaben zum Fahrzeug an den Dienst gehen dürfen.', 'zustimmung');
      if (!q.ok) return rcFehler(q.fehler.join(' '), 'daten');
      var gesendetAm = self.jetzt();
      return self.leihCheckWeg(fahrzeugId).then(function (weg) {
      if (weg.fehler) return rcFehler(weg.fehler, 'leihe');
      return self.checkSenden('grund', q.anfrage, cfg, d, optionen && optionen.quelle, weg.freigabeId).then(function (res) {
        if (!res.ok) return rcFehler(res.fehler, res.art);
        var p = MM.Reisecheck.antwortPruefen(res.antwort);
        if (!p.ok) return rcFehler(p.fehler, 'dienst');
        var rec = { id: neueId('rc'), datenraumId: self.datenraumId, art: 'grund', aktivitaetId: null, fahrzeugId: fahrzeugId, erstelltAm: gesendetAm, stand: q.stand,
          land: q.anfrage.trip.areas[0].name, anfrage: q.anfrage, namen: {}, ergebnis: p.ergebnis, dienst: p.dienst };
        if (res.gespeichert) { rec.gespeichert = true; rec.gespeichertStand = res.stand ? new Date(res.stand).toISOString() : null; }
        return self.speicher.speichern('reisechecks', rec).then(function () { return { ok: true, id: rec.id }; });
      });
      });
    });
  };

  /* Die Tabelle hat nur einen Index auf die Aktivität, darum wird hier gefiltert (es sind wenige Einträge). */
  Daten.prototype.grundcheckListe = function (fahrzeugId) {
    return this.speicher.alle('reisechecks').then(function (l) {
      return l.filter(function (x) { return x.art === 'grund' && x.fahrzeugId === fahrzeugId; })
        .sort(function (x, y) { return x.erstelltAm < y.erstelltAm ? 1 : (x.erstelltAm > y.erstelltAm ? -1 : 0); });
    });
  };

  /* Die Seite zum Fahrzeug: Einstellung, was hinausginge, der letzte Check mit dem Vergleich gegen den heutigen Stand. */
  Daten.prototype.grundcheckAnsicht = function (fahrzeugId, checkId) {
    var self = this;
    return Promise.all([this.grundcheckAnfrage(fahrzeugId), this.reisecheckEinstellung(), this.grundcheckListe(fahrzeugId), this.zuordnungenDokument()]).then(function (r) {
      var q = r[0];
      if (!q) return null;
      var liste = r[2];
      var gewaehlt = checkId ? liste.filter(function (x) { return x.id === checkId; })[0] || null : (liste[0] || null);
      var x = q.eingabe, gelesen = null, zeilen = [], zusammen = null;
      if (gewaehlt) {
        gelesen = MM.Grundcheck.punkteLesen(gewaehlt.ergebnis, gewaehlt.dienst);
        /* Bestätigte Namen („Habe ich unter anderem Namen“) gelten für das Land dieses Checks und die Art dieses Fahrzeugs. */
        zeilen = MM.Grundcheck.vergleichen({ punkte: gelesen.punkte, komponenten: x.vergleich.komponenten, nachweise: x.vergleich.nachweise, plaetze: x.vergleich.plaetze, fahrzeugId: fahrzeugId,
          zuordnungen: MM.Orte.zuordnungenFuer(r[3], gewaehlt.land, x.fahrzeug.artId) });
        zusammen = MM.Grundcheck.zusammenfassung(zeilen);
      }
      return { fahrzeug: { id: x.fahrzeug.id, name: x.fahrzeug.name, artName: x.fahrzeug.artName, abgegeben: x.fahrzeug.abgegeben }, heimat: x.heimat, einstellung: r[1],
        anfrage: q.ok ? { vorschau: q.vorschau, stand: q.stand } : null, fehler: q.ok ? [] : q.fehler,
        checks: liste.map(function (rec) { return { id: rec.id, erstelltAm: rec.erstelltAm, land: rec.land, veraltet: q.ok ? rec.stand !== q.stand : null, recherche: rec.ergebnis.recherche }; }),
        gewaehlt: gewaehlt ? { id: gewaehlt.id, erstelltAm: gewaehlt.erstelltAm, land: gewaehlt.land, recherche: gewaehlt.ergebnis.recherche, zusammenfassung: gewaehlt.ergebnis.zusammenfassung,
          warnungen: gewaehlt.ergebnis.warnungen || [], dienst: gewaehlt.dienst, veraltet: q.ok ? gewaehlt.stand !== q.stand : null,
          landWechsel: !!(x.heimat.land && gewaehlt.land && x.heimat.land !== gewaehlt.land) } : null,
        zeilen: zeilen, zaehl: zusammen, nichtLesbar: gelesen ? gelesen.nichtLesbar : [],
        kandidaten: { ausruestung: namenListe(x.vergleich.komponenten.map(function (k) { return k.name; })), papier: namenListe(x.vergleich.nachweise.map(function (n) { return n.artName; })) } };
    });
  };

  /* ---------- Zuordnung „Habe ich unter anderem Namen“ (seit 2.0.41) ----------
   * Gespeichert als ein Dokument „zuordnungen“ in der Tabelle „einstellungen“ (Datenbank-Version bleibt 16). Es gehört dem Nutzer,
   * nicht einem Fahrzeug: je Land und Fahrzeugart. Gilt im Grundcheck und bei der Pflichtausrüstung der Gebietsregeln im Reisecheck.
   * Die App setzt nichts von selbst gleich. Nur was der Nutzer ausdrücklich wählt, wird gespeichert. */
  function namenListe(l) {
    var res = [];
    (l || []).forEach(function (n) { var t = trimmed(n); if (t && res.indexOf(t) < 0) res.push(t); });
    return res.sort(function (a, b) { return a.localeCompare(b, 'de', { numeric: true }); });
  }

  Daten.prototype.zuordnungenDokument = function () {
    return this.speicher.holen('einstellungen', 'zuordnungen').then(function (d) { return d && d.eintraege ? d : MM.Orte.zuordnungenLeer(); });
  };

  /* Alle Zuordnungen für die Übersicht, nach Land und Fahrzeugart sortiert. */
  Daten.prototype.zuordnungenListe = function () {
    return this.zuordnungenDokument().then(function (d) {
      return d.eintraege.slice().sort(function (a, b) { return (a.land + a.punkt).localeCompare(b.land + b.punkt, 'de'); }).map(function (e) {
        var art = MM.Fahrzeugarten.art(e.artId);
        return { schluessel: e.schluessel, land: e.land, artId: e.artId, artName: art ? art.name : e.artId, art: e.art, punkt: e.punkt, namen: e.namen.slice() };
      });
    });
  };

  /* p: { art: 'ausruestung' | 'papier', punkt, land, ziel }. Das Ziel muss am Fahrzeug wirklich eingetragen sein (Komponente oder Nachweis). */
  Daten.prototype.grundcheckZuordnen = function (fahrzeugId, p) {
    var self = this;
    p = p || {};
    return Promise.all([this.grundcheckEingabe(fahrzeugId), this.zuordnungenDokument()]).then(function (r) {
      var x = r[0];
      if (!x) return rcFehler('Dieses Fahrzeug wurde nicht gefunden.');
      var art = p.art === 'papier' ? 'papier' : 'ausruestung', land = trimmed(p.land), punkt = MM.Orte.suchbegriff(p.punkt), ziel = trimmed(p.ziel);
      if (!land) return rcFehler('Das Land des Checks ist nicht bekannt.');
      if (!punkt) return rcFehler('Der Punkt hat keinen Namen.');
      if (!ziel) return rcFehler('Bitte wähle aus, wie dieser Punkt bei dir heißt.');
      var da = art === 'papier' ? x.vergleich.nachweise.map(function (n) { return n.artName; }) : x.vergleich.komponenten.map(function (k) { return k.name; });
      if (da.indexOf(ziel) < 0) return rcFehler('„' + ziel + '“ ist am Fahrzeug nicht eingetragen. Wähle einen Eintrag aus der Liste.');
      if (ziel.toLowerCase() === punkt.toLowerCase()) return rcFehler('Das ist schon derselbe Name. Eine Zuordnung ist nicht nötig.');
      var doc = MM.Orte.zuordnungSetzen(r[1], { land: land, artId: x.fahrzeug.artId, art: art, punkt: punkt, ziel: ziel, jetzt: self.jetzt() });
      return self.speicher.speichern('einstellungen', doc).then(function () { return { ok: true }; });
    });
  };

  /* Hebt die Zuordnung auf. Ohne ziel fallen alle Namen dieses Punktes weg. */
  Daten.prototype.grundcheckZuordnungAufheben = function (fahrzeugId, p) {
    var self = this;
    p = p || {};
    return Promise.all([this.grundcheckEingabe(fahrzeugId), this.zuordnungenDokument()]).then(function (r) {
      var x = r[0];
      if (!x) return rcFehler('Dieses Fahrzeug wurde nicht gefunden.');
      var doc = MM.Orte.zuordnungEntfernen(r[1], { land: trimmed(p.land), artId: x.fahrzeug.artId, art: p.art === 'papier' ? 'papier' : 'ausruestung', punkt: MM.Orte.suchbegriff(p.punkt), ziel: trimmed(p.ziel) });
      return self.speicher.speichern('einstellungen', doc).then(function () { return { ok: true }; });
    });
  };

  Daten.prototype.allesLoeschen = function () {
    var self = this;
    return this.speicher.allesLoeschen().then(function () { return self.starten(); });
  };

  /* Alles löschen bei angemeldetem Konto (seit 2.0.104): erst beim Dienst (abgeglichene Daten und Sicherungen, mit dem Wort LÖSCHEN), dann auf diesem Gerät.
     Klappt es beim Dienst nicht (zum Beispiel ohne Netz), bleibt auf dem Gerät alles, wie es ist. Danach ist das Gerät auch abgemeldet,
     denn die Anmeldung liegt in den Geräteeinstellungen. Andere Geräte mit demselben Konto behalten ihre Daten und müssen selbst gelöscht werden. */
  Daten.prototype.allesLoeschenMitDienst = function (roh) {
    var self = this;
    return this.abgleichLeeren(roh).then(function (r) {
      if (!r.ok) return r;
      return self.allesLoeschen().then(function () { return { ok: true }; });
    });
  };

  /* Grenze für Geräte ohne Konto (Basic: 1 Fahrzeug, seit 2.0.70). null = unbegrenzt. Nur die Tests setzen diesen Wert (tests/vorlauf.js). */
  MM.Daten = { Daten: Daten, akteZeitraum: akteZeitraum, monateZurueck: monateZurueck, standardFahrzeuggrenze: 1 };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
