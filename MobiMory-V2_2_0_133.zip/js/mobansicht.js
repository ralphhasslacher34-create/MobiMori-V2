/* „Person über Bord“: Tafeln auf der Vollbildseite und die Seite „Bericht“ (seit 2.0.133). Die Rechnung steht in js/mob.js. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  function fehlerText(e) { return (e && e.message) || 'Das hat nicht geklappt.'; }

  /* Eingabefelder für alle Angaben. Ergebnis: { element, werte() (nur geänderte Felder) } */
  function formular(h, w, crew) {
    var alt = MM.Mob.angaben(w), leser = [];
    var element = h('div', { class: 'mob-formular' }, MM.Mob.GRUPPEN.map(function (g, gi) {
      return h('fieldset', null, h('legend', { text: g.titel }), g.felder.map(function (d) {
        var id = 'mob-f-' + d.key, v = alt[d.key], ein, lesen, zusatz = null, vorher;
        if (d.typ === 'mehrfach') {
          var gewaehlt = Array.isArray(v) ? v : [];
          var kaesten = d.optionen.map(function (o) { var c = h('input', { type: 'checkbox', value: o }); c.checked = gewaehlt.indexOf(o) >= 0; return c; });
          ein = h('div', { class: 'mob-wahl', id: id }, kaesten.map(function (c, i) { return h('label', null, c, ' ' + d.optionen[i]); }));
          lesen = function () { return kaesten.filter(function (c) { return c.checked; }).map(function (c) { return c.value; }); };
        } else {
          if (d.typ === 'wahl') ein = h('select', { id: id }, h('option', { value: '', text: '– offen –' }), d.optionen.map(function (o) { return h('option', { value: o, text: o }); }));
          else if (d.typ === 'lang') ein = h('textarea', { id: id, rows: '2' });
          else ein = h('input', { type: d.typ === 'zeit' ? 'time' : 'text', id: id, autocomplete: 'off', list: d.typ === 'person' ? 'mob-crew' : null });
          if (d.typ === 'person') zusatz = h('datalist', { id: 'mob-crew' }, (crew || []).map(function (n) { return h('option', { value: n }); }));
          ein.value = v === undefined || v === null ? '' : String(v);
          lesen = function () { return ein.value; };
        }
        vorher = JSON.stringify(lesen());
        leser.push({ key: d.key, lesen: lesen, vorher: vorher });
        return h('div', { class: 'feld' }, h('label', { class: 'feld-label', for: id, text: d.label }), h('div', { class: 'eingabe' }, ein), zusatz);
      }));
    }));
    return { element: element, werte: function () {
      var r = {};
      leser.forEach(function (l) { var v = l.lesen(); if (JSON.stringify(v) !== l.vorher) r[l.key] = v; });
      return r;
    } };
  }

  /* o: { h, daten, blatt, ereignisId, melden, neuLesen, werte() } */
  function erzeugen(o) {
    var h = o.h, blatt = o.blatt;
    function zu() { blatt.hidden = true; blatt.textContent = ''; }
    function auf(titel, inhalt, knoepfe) {
      blatt.textContent = '';
      blatt.setAttribute('aria-label', titel);
      blatt.appendChild(h('h2', { text: titel }));
      [].concat(inhalt).forEach(function (x) { if (x) blatt.appendChild(x); });
      blatt.appendChild(h('p', { class: 'knopfzeile' }, knoepfe || [], h('button', { class: 'knopf leise', type: 'button', text: 'Schließen', onclick: zu })));
      blatt.hidden = false;
      blatt.scrollTop = 0;
    }
    function fehler(e) { o.melden(fehlerText(e)); }

    function fragen(frage, jaText, ja) {
      auf(frage, h('p', { class: 'knopfzeile' }, h('button', { class: 'knopf gefahr', type: 'button', text: jaText, onclick: function () { zu(); ja(); } }),
        h('button', { class: 'knopf', type: 'button', text: 'Nein, weiter suchen', onclick: zu })));
    }

    function checkliste() {
      var w = o.werte(), c = w.mobCheck || {};
      auf('Checkliste', h('div', { class: 'mob-liste' }, MM.Mob.CHECKLISTE.map(function (p) {
        return h('button', { class: 'knopf' + (c[p[0]] ? ' leise' : ''), type: 'button', text: (c[p[0]] ? '✓ ' + MM.Mob.uhr(c[p[0]]) + '  ' : '') + p[1], onclick: function () {
          o.daten.mobHaken(o.ereignisId, p[0]).then(o.neuLesen).then(checkliste).catch(fehler);
        } });
      })));
    }

    function angaben() {
      o.daten.mobLaden(o.ereignisId).then(function (m) {
        var f = formular(h, m.werte, m.crew);
        auf('Angaben', [f.element], h('button', { class: 'knopf', type: 'button', text: 'Speichern', onclick: function () {
          o.daten.mobAkteSpeichern(o.ereignisId, f.werte()).then(function (r) {
            if (!r.ok) { o.melden(r.fehler.allgemein); return null; }
            zu(); o.melden('Gespeichert.'); return o.neuLesen();
          }).catch(fehler);
        } }));
      }).catch(fehler);
    }

    var revier = null, sprache = 'de';
    function notruf() {
      o.daten.mobLaden(o.ereignisId).then(function (m) {
        var fz = m.aktivitaet && m.aktivitaet.fahrzeug;
        return (fz ? o.daten.fahrzeugLaden(fz.id) : Promise.resolve(null)).then(function (f) {
          var v = f ? f.aktuell.werte : {};
          /* Vorauswahl: mit MMSI See, mit ATIS ohne MMSI Binnen */
          if (!revier) revier = v.atis && !v.mmsi ? 'binnen' : 'see';
          var km = h('input', { type: 'text', id: 'mob-km', inputmode: 'decimal', autocomplete: 'off' });
          var ziel = h('div');
          function zeigeText() {
            var n = MM.Mob.notruf({ revier: revier, sprache: sprache, name: v.bezeichnung, rufzeichen: v.rufzeichen, mmsi: v.mmsi, atis: v.atis, start: m.start, personen: m.crew.length, stromkilometer: km.value.trim() });
            ziel.textContent = '';
            ziel.appendChild(h('h3', { text: n.titel }));
            ziel.appendChild(h('ol', null, n.schritte.map(function (s) { return h('li', { text: s }); })));
            ziel.appendChild(h('div', { class: 'mob-funk' }, n.zeilen.map(function (z) { return h('p', { text: z || ' ' }); })));
            if (n.buchstabiert.length) ziel.appendChild(h('dl', null, n.buchstabiert.map(function (b) { return [h('dt', { text: b[0] }), h('dd', { class: 'mob-funk', text: b[1] })]; })));
            ziel.appendChild(h('details', null, h('summary', { text: 'Buchstabiertafel' }), h('p', { class: 'mob-tafel' }, n.tafel.map(function (t) { return h('span', { text: t }); }))));
          }
          function wahl(text, an, tun) { return h('button', { class: 'knopf klein' + (an ? '' : ' leise'), type: 'button', 'aria-pressed': an ? 'true' : 'false', text: text, onclick: function () { tun(); notruf(); } }); }
          km.addEventListener('input', zeigeText);
          zeigeText();
          var fehlt = !v.rufzeichen || (revier === 'see' && !v.mmsi);
          auf('Notruf', [
            h('p', { class: 'knopfzeile' }, wahl('See', revier === 'see', function () { revier = 'see'; }), wahl('Binnen', revier === 'binnen', function () { revier = 'binnen'; }),
              wahl('Deutsch', sprache === 'de', function () { sprache = 'de'; }), wahl('English', sprache === 'en', function () { sprache = 'en'; })),
            h('p', { class: 'mob-position' }, 'Position beim Knopfdruck:', MM.Mob.position(m.start).split('  ').map(function (t) { return [h('br'), h('strong', { text: t })]; })),
            h('p', { class: 'mob-position' }, 'Zeit: ', h('strong', { text: MM.Mob.zeitpunkt(m.start.ms) })),
            revier === 'binnen' ? h('div', { class: 'feld' }, h('label', { class: 'feld-label', for: 'mob-km', text: 'Stromkilometer' }), h('div', { class: 'eingabe' }, km)) : null,
            ziel,
            fehlt ? h('p', { class: 'hinweis', text: 'Rufzeichen und MMSI trägst du beim Boot unter den Fahrzeugdaten ein, dann stehen sie hier.' }) : null,
            revier === 'see' ? h('div', null, h('h3', { text: 'Mit dem Telefon (du tippst selbst)' }), MM.Mob.TELEFON_SEE.map(function (t) {
              return h('p', null, h('a', { class: 'knopf gefahr', href: 'tel:' + t[0], text: t[1] }), h('br'), h('span', { class: 'hilfe', text: t[2] }));
            })) : null,
            h('p', { class: 'hilfe', text: 'MobiMory setzt selbst keinen Notruf ab. Die Vorlage ersetzt kein Funkzeugnis.' })
          ]);
        });
      }).catch(fehler);
    }
    return { fragen: fragen, checkliste: checkliste, angaben: angaben, notruf: notruf, zu: zu };
  }

  /* ---------- Seite „Bericht“ ---------- */
  var kartenLauf = 0;
  /* Karte als Bild: Weg des Boots, Sturz, Sichtungen, Bergung. */
  function kartenbild(o) {
    var m = o.m, w = m.werte, marker = [];
    if (typeof m.start.breite === 'number') marker.push({ breite: m.start.breite, laenge: m.start.laenge, symbol: 'X', farbe: '#c0262d' });
    (w.mobSichtungen || []).forEach(function (s, i) { var p = s.person || s; marker.push({ breite: p.breite, laenge: p.laenge, symbol: String(i + 1), farbe: '#7a3fb0' }); });
    if (w.mobBergung && typeof w.mobBergung.breite === 'number') marker.push({ breite: w.mobBergung.breite, laenge: w.mobBergung.laenge, symbol: 'B', farbe: '#1f8a3b' });
    return MM.Kartenbild.erzeugen({ breite: 1200, hoehe: 800, wegStuecke: m.weg.length > 1 ? [m.weg.map(function (p) { return [p[0], p[1]]; })] : [], marker: marker, see: true, ablage: o.ablage,
      hole: MM.Kartenbild.browser.hole, leinwand: MM.Kartenbild.browser.leinwand, bildLaden: MM.Kartenbild.browser.bildLaden });
  }
  function bytesVon(blob) { return blob && blob.arrayBuffer ? blob.arrayBuffer().then(function (a) { return new Uint8Array(a); }) : Promise.resolve(null); }

  /* o: { h, daten, m (aus mobLaden), vergleich, id, seite, zeige, speichern, ablage, krumen } */
  function berichtSeite(o) {
    var h = o.h, m = o.m, w = m.werte, offen = w.endeStatus === 'laeuft';
    var uebung = w.uebung === 'uebung';
    var status = h('p', { class: 'hinweis', role: 'status' });
    var dateiName = 'Person-ueber-Bord-' + (w.datum || '') + (uebung ? '-Uebung' : '');
    var lauf = ++kartenLauf, karte = null;
    var bildBox = h('div', { class: 'mob-bericht-karte' }, h('p', { class: 'hinweis', text: 'Karte wird gezeichnet …' }));
    var karteFertig = kartenbild(o).then(function (r) {
      if (lauf !== kartenLauf) return;
      bildBox.textContent = '';
      if (!r.ok) { bildBox.appendChild(h('p', { class: 'hinweis', text: r.grund })); return; }
      karte = { bytes: r.bytes, beschriftung: 'Orange: Weg des Boots. X über Bord, Zahlen gesichtet, B wieder an Bord. ' + r.quelle };
      var url = global.URL.createObjectURL(new global.Blob([r.bytes], { type: 'image/jpeg' }));
      bildBox.appendChild(h('img', { src: url, alt: 'Karte mit dem Weg des Boots', onload: function () { global.URL.revokeObjectURL(url); } }));
      bildBox.appendChild(h('p', { class: 'hilfe', text: karte.beschriftung }));
    }).catch(function () { bildBox.textContent = 'Die Karte konnte nicht gezeichnet werden.'; });

    var pdfKnopf = h('button', { class: 'knopf', type: 'button', text: 'Bericht als PDF', onclick: function () {
      status.textContent = 'PDF wird erstellt …';
      karteFertig.then(function () { return Promise.all(m.fotos.map(function (f) { return bytesVon(f.inhalt).then(function (b) { return b ? { name: f.name, bytes: b } : null; }); })); }).then(function (fotos) {
        var fz = m.aktivitaet && m.aktivitaet.fahrzeug;
        var bytes = MM.Mob.bericht({ werte: w, strecke: m.strecke, fahrzeug: fz && fz.name, aktivitaet: m.aktivitaet && m.aktivitaet.aktuell.werte.bezeichnung, karte: karte, fotos: fotos.filter(Boolean), datum: o.daten.jetzt() });
        o.speichern(bytes, dateiName + '.pdf', 'application/pdf');
        status.textContent = 'PDF erstellt.';
      }).catch(function (e) { status.textContent = fehlerText(e); });
    } });
    var gpxKnopf = h('button', { class: 'knopf leise', type: 'button', text: 'Weg als GPX', onclick: function () {
      o.speichern(new global.TextEncoder().encode(MM.Mob.gpx(w, m.weg)), dateiName + '.gpx', 'application/gpx+xml');
    } });

    var f = formular(h, w, m.crew);
    var speichern = h('button', { class: 'knopf', type: 'button', text: offen ? 'Speichern' : 'Als Nachtrag speichern', onclick: function () {
      o.daten.mobAkteSpeichern(o.id, f.werte()).then(function (r) {
        if (!r.ok) { status.textContent = r.fehler.allgemein; return null; }
        return o.zeige();
      }).catch(function (e) { status.textContent = fehlerText(e); });
    } });
    var foto = h('input', { type: 'file', accept: 'image/*', id: 'mob-foto', multiple: true, onchange: function () {
      var liste = Array.prototype.slice.call(foto.files || []);
      status.textContent = 'Foto wird gespeichert …';
      liste.reduce(function (p, datei) { return p.then(function () { return o.daten.mobFotoDazu(o.id, datei).then(function (r) { if (!r.ok) throw new Error(r.fehler.datei || r.fehler.allgemein); }); }); }, Promise.resolve())
        .then(o.zeige).catch(function (e) { status.textContent = fehlerText(e); });
    } });

    function tabelle(kopf, zeilen) {
      return h('div', { class: 'mob-tabelle' }, h('table', null, h('thead', null, h('tr', null, kopf.map(function (k) { return h('th', { text: k }); }))),
        h('tbody', null, zeilen.map(function (z) { return h('tr', null, z.map(function (c) { return h('td', { text: c }); })); }))));
    }
    var nachtraege = MM.Mob.nachtraege(w);
    var vergleich = (o.vergleich || []).map(function (v) {
      return [MM.Mob.zeitpunkt(v.ms) + (v.id === o.id ? ' (diese)' : ''), v.uebung ? 'Übung' : 'Ernstfall', v.sichtungS === null ? '–' : MM.Mob.dauer(v.sichtungS * 1000), v.bergungS === null ? '–' : MM.Mob.dauer(v.bergungS * 1000)];
    });

    o.seite('Person über Bord', [o.krumen,
      h('h1', { text: 'Person über Bord' + (uebung ? ' – Übung' : '') }),
      offen ? h('p', { class: 'knopfzeile' }, h('a', { class: 'knopf gefahr', href: '#/aktivitaet/' + encodeURIComponent(m.x.ereignis.aktivitaetId) + '/cockpit/mob/' + encodeURIComponent(o.id), text: 'Läuft noch: zurück zur Suche' })) : null,
      status,
      h('p', { class: 'knopfzeile' }, pdfKnopf, gpxKnopf),
      h('h2', { text: 'Ablauf' }), tabelle(['Zeitpunkt', 'Was', 'Position'], MM.Mob.ablauf(w)),
      h('h2', { text: 'Karte' }), bildBox,
      h('h2', { text: 'Zusammenfassung' }), h('dl', { class: 'mob-dl' }, MM.Mob.zusammenfassung(w, m.strecke).map(function (z) { return [h('dt', { text: z[0] }), h('dd', { text: z[1] })]; })),
      nachtraege.length ? [h('h2', { text: 'Nachträge' }), tabelle(['Am', 'Änderung'], nachtraege)] : null,
      h('h2', { text: 'Angaben eintragen' }), f.element, h('p', { class: 'knopfzeile' }, speichern),
      h('h2', { text: 'Fotos' }), m.fotos.length ? h('ul', null, m.fotos.map(function (x) {
        return h('li', null, h('button', { class: 'knopf leise klein', type: 'button', text: x.name, onclick: function () { bytesVon(x.inhalt).then(function (b) { if (b) o.speichern(b, x.name, x.mime); else status.textContent = 'Dieses Foto ist auf diesem Gerät noch nicht da.'; }); } }));
      })) : h('p', { class: 'hinweis', text: 'Noch kein Foto.' }),
      h('div', { class: 'feld' }, h('label', { class: 'feld-label', for: 'mob-foto', text: 'Foto hinzufügen' }), h('div', { class: 'eingabe' }, foto)),
      h('h2', { text: 'Zeiten im Vergleich' }), vergleich.length ? tabelle(['Zeitpunkt', 'Art', 'bis gesichtet', 'bis an Bord'], vergleich) : h('p', { class: 'hinweis', text: 'Noch nichts zu vergleichen.' })
    ]);
    return Promise.resolve(null);
  }

  MM.MobAnsicht = { erzeugen: erzeugen, berichtSeite: berichtSeite };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
