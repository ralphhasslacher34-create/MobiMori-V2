/* „Person über Bord“ dokumentieren (seit 2.0.133): Angaben, Texte, Weg, GPX, Notruf-Vorlage, Bericht. Nur Rechnung, kein Netz, kein Speicher.
 *
 * Am Eintrag „Person über Bord“ stehen:
 *   mobStart { ms, breite, laenge }, mobSichtungen [{ breite, laenge, ms, person? }], mobBergung { ms, breite, laenge },
 *   mobBedingungen, mobFunk (Notruf, externe Rettung), mobCheck { Schlüssel: ms }, mobGeraet (zeichnet den Weg auf),
 *   mobAkte { notiz: { angaben, nachtraege } }: Angaben zu Personen. Der Schlüssel „notiz“ geht nie im Klartext zum Dienst,
 *   beim Abgleich wird er mit dem Schlüsselwort verschlüsselt (js/abgleich.js, LOKALE_SCHLUESSEL). */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var ART_GESICHTET = 'Person gesichtet', ART_AN_BORD = 'Person wieder an Bord', ART_UEBUNG_AN_BORD = 'Übung beendet (Person über Bord)';

  function f(key, label, typ, optionen, privat) { return { key: key, label: label, typ: typ || 'text', optionen: optionen || null, privat: !!privat }; }
  var JN = ['ja', 'nein'];
  var GRUPPEN = [
    { titel: 'Wer und warum', felder: [f('wer', 'Wer ist über Bord gegangen?', 'person', null, true), f('warum', 'Warum?', 'lang', null, true),
      f('weste', 'Rettungsweste getragen', 'wahl', JN, true), f('lifeline', 'Lifeline eingepickt', 'wahl', JN, true), f('notsender', 'Notsender (PLB, AIS) dabei', 'wahl', JN, true)] },
    { titel: 'Nach der Bergung', felder: [f('zustand', 'Zustand der Person', 'lang', null, true),
      f('massnahmen', 'Maßnahmen', 'mehrfach', ['Aufwärmen', 'Trockene Kleidung', 'Erste Hilfe', 'Herz-Lungen-Wiederbelebung', 'Stabile Seitenlage', 'Arzt oder Rettungsdienst', 'Überwacht'], true),
      f('massnahmenText', 'Weitere Maßnahmen', 'lang', null, true)] },
    { titel: 'Notruf und externe Rettung', felder: [f('notruf', 'Notruf abgesetzt', 'wahl', JN), f('notrufUm', 'Notruf um (Uhrzeit)', 'zeit'), f('notrufWeg', 'Notruf über', 'wahl', ['DSC', 'Funk', 'Telefon']),
      f('extern', 'Externe Rettung angefordert', 'wahl', JN), f('externWer', 'Wer kam?', 'text', null, true), f('externEintreffen', 'Eingetroffen um (Uhrzeit)', 'zeit'), f('externUebergabe', 'Übergabe (an wen, wann)', 'lang', null, true)] },
    { titel: 'Zeugen und Schilderung', felder: [f('zeugen', 'Zeugen', 'lang', null, true), f('schilderung', 'Schilderung', 'lang', null, true)] },
    { titel: 'Bedingungen', felder: [f('wind', 'Wind'), f('welle', 'Welle'), f('sicht', 'Sicht'), f('wasser', 'Wassertemperatur (°C)'), f('licht', 'Licht', 'wahl', ['Tag', 'Dämmerung', 'Nacht'])] }
  ];
  var FELDER = GRUPPEN.reduce(function (l, g) { return l.concat(g.felder); }, []);
  var BEDINGUNGEN = ['wind', 'welle', 'sicht', 'wasser', 'licht'];

  var CHECKLISTE = [['rettungsmittel', 'Rettungsmittel werfen (Ring, Boje, Licht)'], ['ausguck', 'Ausguck: eine Person zeigt auf die Person im Wasser'],
    ['plotter', 'MOB-Taste am Plotter drücken'], ['funk', 'Funk: Notruf absetzen']];

  function privatVon(w) { var a = w && w.mobAkte && w.mobAkte.notiz; return a && typeof a === 'object' ? a : { angaben: {}, nachtraege: [] }; }
  /* Alle Angaben eines Eintrags, flach: { key: wert } */
  function angaben(w) {
    var r = {};
    [w && w.mobFunk, w && w.mobBedingungen, privatVon(w).angaben].forEach(function (o) { Object.keys(o || {}).forEach(function (k) { r[k] = o[k]; }); });
    return r;
  }
  function wertText(v) { return Array.isArray(v) ? v.join(', ') : String(v === undefined || v === null ? '' : v); }

  /* Neue Angaben einarbeiten. nach: true, wenn das Manöver schon beendet ist (dann entsteht ein Nachtrag mit alt und neu).
     Ergebnis: { werte (Felder für den Eintrag), geaendert } */
  function einarbeiten(w, neu, nach, jetztMs) {
    var alt = angaben(w), p = Object.assign({}, privatVon(w).angaben), funk = Object.assign({}, w.mobFunk), bed = Object.assign({}, w.mobBedingungen), aend = [];
    FELDER.forEach(function (d) {
      if (!Object.prototype.hasOwnProperty.call(neu, d.key)) return;
      var v = Array.isArray(neu[d.key]) ? neu[d.key].slice() : String(neu[d.key] === undefined || neu[d.key] === null ? '' : neu[d.key]).trim().slice(0, 2000);
      if (wertText(v) === wertText(alt[d.key])) return;
      aend.push({ feld: d.label, alt: wertText(alt[d.key]), neu: wertText(v) });
      (d.privat ? p : (BEDINGUNGEN.indexOf(d.key) >= 0 ? bed : funk))[d.key] = v;
    });
    if (!aend.length) return { werte: null, geaendert: false };
    var nachtraege = (privatVon(w).nachtraege || []).slice();
    if (nach) nachtraege.push({ ms: jetztMs, aenderungen: aend });
    return { geaendert: true, werte: { mobFunk: funk, mobBedingungen: bed, mobAkte: { notiz: { angaben: p, nachtraege: nachtraege } } } };
  }

  /* ---------- Zeiten und Positionen ---------- */
  function zwei(n) { return (n < 10 ? '0' : '') + n; }
  function uhr(ms) { var d = new Date(ms); return zwei(d.getHours()) + ':' + zwei(d.getMinutes()) + ':' + zwei(d.getSeconds()); }
  function datum(ms) { var d = new Date(ms); return zwei(d.getDate()) + '.' + zwei(d.getMonth() + 1) + '.' + d.getFullYear(); }
  function zeitpunkt(ms) { return datum(ms) + ', ' + uhr(ms) + ' Uhr'; }
  function utc(ms) { var d = new Date(ms); return zwei(d.getUTCHours()) + ':' + zwei(d.getUTCMinutes()) + ' UTC'; }
  function dauer(ms) {
    var s = Math.max(0, Math.round(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60);
    return h ? h + ' h ' + zwei(m) + ' min ' + zwei(s % 60) + ' s' : (m ? m + ' min ' + zwei(s % 60) + ' s' : s + ' s');
  }
  function hatPos(p) { return !!p && typeof p.breite === 'number' && typeof p.laenge === 'number'; }
  /* Grad und Dezimalminuten, wie sie am Funk angesagt werden: 54° 12,345' N */
  function minuten(wert, plus, minus, stellen) {
    var a = Math.abs(wert), g = Math.floor(a), m = ((a - g) * 60).toFixed(3);
    if (Number(m) >= 60) { g++; m = '0.000'; }
    var gs = String(g); while (gs.length < stellen) gs = '0' + gs;
    return gs + '° ' + (Number(m) < 10 ? '0' : '') + String(m).replace('.', ',') + '\' ' + (wert < 0 ? minus : plus);
  }
  function position(p, englisch) { return hatPos(p) ? minuten(p.breite, 'N', 'S', 2) + '  ' + minuten(p.laenge, englisch ? 'E' : 'O', 'W', 3) : 'ohne Position'; }

  function start(w) { return w.mobStart || { ms: w.startMs, breite: w.breite, laenge: w.laenge }; }
  function bergungMs(w) { return w.mobBergung ? w.mobBergung.ms : null; }
  function ersteSichtungMs(w) { var l = w.mobSichtungen || []; return l.length ? l[0].ms : null; }

  /* Kurzer Text für die Zeile im Logbuch */
  function logbuchText(w) {
    if (!w || !w.mob) return '';
    var a = angaben(w), s = start(w), t = [];
    if (s.ms) t.push('über Bord ' + uhr(s.ms));
    if (w.mobBergung) t.push('an Bord ' + uhr(w.mobBergung.ms));
    if (a.wer) t.push('Wer: ' + a.wer);
    if (a.warum) t.push('Warum: ' + a.warum);
    if (a.zustand) t.push('Zustand: ' + a.zustand);
    var m = [wertText(a.massnahmen), a.massnahmenText].filter(Boolean).join(', ');
    if (m) t.push('Maßnahmen: ' + m);
    if (a.notruf) t.push('Notruf: ' + a.notruf + (a.notruf === 'ja' ? [a.notrufUm ? ' um ' + a.notrufUm : '', a.notrufWeg ? ' über ' + a.notrufWeg : ''].join('') : ''));
    if (a.extern) t.push('Externe Rettung: ' + a.extern);
    return t.join(' · ');
  }

  /* Ablauf in Zeilen [Zeit, Ereignis, Position] */
  function ablauf(w) {
    var s = start(w), l = [];
    if (s.ms) l.push([zeitpunkt(s.ms), 'Person über Bord', position(s)]);
    (w.mobSichtungen || []).forEach(function (x, i) {
      l.push([zeitpunkt(x.ms), 'Gesichtet (' + (i + 1) + '), Position des Boots', position(x)]);
      if (x.person) l.push([zeitpunkt(x.person.ms), 'Stelle der Person auf der Karte gesetzt (zu Sichtung ' + (i + 1) + ')', position(x.person)]);
    });
    CHECKLISTE.forEach(function (c) { if (w.mobCheck && w.mobCheck[c[0]]) l.push([zeitpunkt(w.mobCheck[c[0]]), 'Erledigt: ' + c[1], '']); });
    if (w.mobBergung) l.push([zeitpunkt(w.mobBergung.ms), w.uebung === 'uebung' ? 'Übung beendet' : 'Person wieder an Bord', position(w.mobBergung)]);
    return l;
  }

  /* Alle Angaben als [Bezeichnung, Wert], leere als „–“ */
  function zusammenfassung(w, strecke) {
    var s = start(w), a = angaben(w), z = [];
    z.push(['Art', w.uebung === 'uebung' ? 'Übung' : 'Ernstfall']);
    z.push(['Beginn', s.ms ? zeitpunkt(s.ms) : '–']);
    z.push(['Position Beginn', position(s)]);
    z.push(['Ende', w.mobBergung ? zeitpunkt(w.mobBergung.ms) : '–']);
    z.push(['Position Ende', w.mobBergung ? position(w.mobBergung) : '–']);
    z.push(['Dauer', w.mobBergung && s.ms ? dauer(w.mobBergung.ms - s.ms) : '–']);
    z.push(['Skipper', w.skipperName || '–']);
    z.push(['Rudergänger', w.ruderName || '–']);
    if (strecke) z.push(['Weg des Boots', strecke.punkte + ' GPS-Punkte' + (strecke.punkte > 1 ? ', ' + Math.round(strecke.meter) + ' m' : '') + (strecke.luecken ? ', ' + strecke.luecken + ' Lücken über 5 s (längste ' + dauer(strecke.laengste) + ')' : '')]);
    if (w.wetterText) z.push(['Wetterdienst beim Sturz', w.wetterText]);
    FELDER.forEach(function (d) { z.push([d.label.replace(/\?$/, ''), wertText(a[d.key]) || '–']); });
    return z;
  }
  function nachtraege(w) {
    return (privatVon(w).nachtraege || []).map(function (n) {
      return [zeitpunkt(n.ms), n.aenderungen.map(function (x) { return x.feld.replace(/\?$/, '') + ': ' + (x.alt || 'leer') + ' → ' + (x.neu || 'leer'); }).join('; ')];
    });
  }

  /* ---------- Weg: [[breite, laenge, ms]] ---------- */
  function wegZusammen(a, b) {
    var nach = {};
    (a || []).concat(b || []).forEach(function (p) { if (p && p.length === 3) nach[p[2]] = p; });
    return Object.keys(nach).map(Number).sort(function (x, y) { return x - y; }).map(function (k) { return nach[k]; });
  }
  /* Nimmt einen Punkt an, höchstens einen je Sekunde. Auch ohne Bewegung. */
  function wegPunkt(punkte, breite, laenge, ms) {
    var p = punkte[punkte.length - 1];
    if (p && Math.abs(ms - p[2]) < 900) return false;
    punkte.push([breite, laenge, ms]);
    return true;
  }
  function strecke(punkte, meterFunktion) {
    var r = { punkte: punkte.length, meter: 0, luecken: 0, laengste: 0 };
    for (var i = 1; i < punkte.length; i++) {
      var a = punkte[i - 1], b = punkte[i];
      r.meter += meterFunktion(a[0], a[1], b[0], b[1]);
      if (b[2] - a[2] > 5000) { r.luecken++; r.laengste = Math.max(r.laengste, b[2] - a[2]); }
    }
    return r;
  }

  function xml(t) { return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function gpx(w, punkte) {
    var z = ['<?xml version="1.0" encoding="UTF-8"?>', '<gpx version="1.1" creator="MobiMory" xmlns="http://www.topografix.com/GPX/1/1">'];
    function wpt(p, name) { if (hatPos(p)) z.push('<wpt lat="' + p.breite + '" lon="' + p.laenge + '"><time>' + new Date(p.ms).toISOString() + '</time><name>' + xml(name) + '</name></wpt>'); }
    wpt(start(w), 'Person über Bord');
    (w.mobSichtungen || []).forEach(function (x, i) { wpt(x, 'Gesichtet ' + (i + 1)); if (x.person) wpt(x.person, 'Person ' + (i + 1)); });
    if (w.mobBergung) wpt(w.mobBergung, 'Wieder an Bord');
    z.push('<trk><name>Weg des Boots</name><trkseg>');
    punkte.forEach(function (p) { z.push('<trkpt lat="' + p[0] + '" lon="' + p[1] + '"><time>' + new Date(p[2]).toISOString() + '</time></trkpt>'); });
    z.push('</trkseg></trk></gpx>');
    return z.join('\n');
  }

  /* ---------- Notruf zum Ablesen ----------
   * Aufbau Binnen: Handbuch Binnenschifffahrtsfunk, Allgemeiner Teil (ZKR 2017), Notanruf und Notmeldung, Beispiel Person über Bord auf Kanal 10.
   * Aufbau See: DSC-Notalarm (Kanal 70), dann Sprechfunk auf Kanal 16. Der Wortlaut ist eine Vorlage und ersetzt kein Funkzeugnis. */
  var TAFEL = { A: 'Alfa', B: 'Bravo', C: 'Charlie', D: 'Delta', E: 'Echo', F: 'Foxtrot', G: 'Golf', H: 'Hotel', I: 'India', J: 'Juliett', K: 'Kilo', L: 'Lima', M: 'Mike',
    N: 'November', O: 'Oscar', P: 'Papa', Q: 'Quebec', R: 'Romeo', S: 'Sierra', T: 'Tango', U: 'Uniform', V: 'Victor', W: 'Whiskey', X: 'X-ray', Y: 'Yankee', Z: 'Zulu' };
  function buchstabiert(text) {
    var t = String(text || '').toUpperCase().replace(/Ä/g, 'AE').replace(/Ö/g, 'OE').replace(/Ü/g, 'UE').replace(/ß|ẞ/g, 'SS');
    return t.split(/\s+/).filter(Boolean).map(function (wort) {
      return wort.split('').map(function (c) { return TAFEL[c] || (/[0-9]/.test(c) ? c : ''); }).filter(Boolean).join(' · ');
    }).filter(Boolean).join('   /   ');
  }

  /* d: { revier: 'see' | 'binnen', sprache: 'de' | 'en', name, rufzeichen, mmsi, atis, start { ms, breite, laenge }, personen, stromkilometer }
     Ergebnis: { titel, schritte: [Text], zeilen: [Text (laut sprechen)], buchstabiert: [[was, Text]] } */
  function notruf(d) {
    var en = d.sprache === 'en', see = d.revier !== 'binnen', offen = '________';
    var name = d.name || offen, ruf = d.rufzeichen || offen;
    var kennung = see ? ruf + ', MMSI ' + (d.mmsi || offen) : ruf + (d.atis ? ', ATIS ' + d.atis : '');
    var s = d.start || {};
    var zeit = s.ms ? utc(s.ms) + ' (' + uhr(s.ms).slice(0, 5) + (en ? ' local' : ' Ortszeit') + ')' : offen;
    var personen = typeof d.personen === 'number' && d.personen > 0 ? String(d.personen) : offen;
    var schritte = see
      ? (en ? ['DSC radio: lift the cover, hold the DISTRESS button until the alert is sent.', 'Switch to VHF channel 16, high power.', 'Press the key and read aloud:']
        : ['DSC-Funkgerät: Klappe öffnen, rote DISTRESS-Taste halten, bis der Alarm gesendet ist.', 'Auf UKW-Kanal 16 schalten, hohe Leistung.', 'Sprechtaste drücken und laut vorlesen:'])
      : (en ? ['VHF channel 10 (ship to ship).', 'Press the key and read aloud:'] : ['UKW-Kanal 10 (Schiff–Schiff) einschalten.', 'Sprechtaste drücken und laut vorlesen:']);
    var z = ['MAYDAY MAYDAY MAYDAY', 'THIS IS', name + ', ' + name + ', ' + name, kennung, '', 'MAYDAY', name + ', ' + kennung];
    if (!see) z.push((en ? 'river kilometre ' : 'Stromkilometer ') + (d.stromkilometer || offen));
    z.push((en ? 'position ' : 'Position ') + position(s, true));
    z.push((en ? 'time ' : 'Zeit ') + zeit);
    z.push(en ? 'person over board' : 'Person über Bord');
    z.push(en ? 'I require immediate assistance' : 'Ich benötige sofortige Hilfe');
    z.push((en ? 'persons on board: ' : 'Personen an Bord: ') + personen);
    z.push('OVER');
    return { titel: see ? (en ? 'Distress call at sea (VHF 16)' : 'Notruf See (UKW 16)') : (en ? 'Distress call inland (VHF 10)' : 'Notruf Binnen (Kanal 10)'), schritte: schritte, zeilen: z,
      buchstabiert: [[en ? 'Boat name' : 'Bootsname', buchstabiert(d.name)], [en ? 'Call sign' : 'Rufzeichen', buchstabiert(d.rufzeichen)]].filter(function (x) { return x[1]; }),
      tafel: Object.keys(TAFEL).map(function (k) { return k + ' ' + TAFEL[k]; }) };
  }
  var TELEFON_SEE = [['124124', 'Seenotleitung anrufen: 124 124', 'Nur aus deutschen Mobilfunknetzen, deutsche Küste.'], ['+49421536870', 'Seenotleitung Bremen: +49 421 53687-0', 'Deutsche Seenotleitung, auch aus dem Ausland erreichbar.']];

  /* ---------- Bericht als PDF ---------- */
  function bericht(o) {
    var w = o.werte, uebung = w.uebung === 'uebung';
    var titel = 'Person über Bord' + (uebung ? ' – Übung' : '');
    var d = MM.Pdf.neu({ fuss: 'MobiMory ' + (MM.VERSION || '') + ' · ' + titel, titel: titel, datum: o.datum });
    d.titel(titel, [o.fahrzeug, o.aktivitaet].filter(Boolean).join(' · '));
    d.abschnitt('Angaben');
    zusammenfassung(w, o.strecke).forEach(function (z) { d.zeile(z[0], z[1]); });
    d.abschnitt('Ablauf');
    d.tabelle([{ titel: 'Zeitpunkt', breite: 120 }, { titel: 'Was', breite: 0 }, { titel: 'Position', breite: 170 }], ablauf(w));
    if (o.karte) { d.abschnitt('Karte'); d.bild(o.karte.bytes, { maxH: 330, unterschrift: o.karte.beschriftung || '' }); }
    var n = nachtraege(w);
    if (n.length) { d.abschnitt('Nachträge nach dem Ende'); d.tabelle([{ titel: 'Am', breite: 120 }, { titel: 'Änderung', breite: 0 }], n); }
    if (o.fotos && o.fotos.length) { d.abschnitt('Fotos'); o.fotos.forEach(function (x) { if (!d.bild(x.bytes, { maxH: 260, unterschrift: x.name })) d.absatz('Foto nicht im PDF (kein JPEG): ' + x.name); }); }
    d.abschnitt('Hinweis');
    d.absatz('Zeiten und Positionen stammen vom GPS und der Uhr des Geräts. Alle Punkte des Wegs stehen in der GPX-Datei.');
    return d.bytes();
  }

  MM.Mob = {
    ART_GESICHTET: ART_GESICHTET, ART_AN_BORD: ART_AN_BORD, ART_UEBUNG_AN_BORD: ART_UEBUNG_AN_BORD, GRUPPEN: GRUPPEN, FELDER: FELDER, CHECKLISTE: CHECKLISTE, TELEFON_SEE: TELEFON_SEE,
    angaben: angaben, einarbeiten: einarbeiten, uhr: uhr, zeitpunkt: zeitpunkt, dauer: dauer, position: position, start: start, bergungMs: bergungMs, ersteSichtungMs: ersteSichtungMs,
    logbuchText: logbuchText, ablauf: ablauf, zusammenfassung: zusammenfassung, nachtraege: nachtraege, wegZusammen: wegZusammen, wegPunkt: wegPunkt, strecke: strecke, gpx: gpx,
    buchstabiert: buchstabiert, notruf: notruf, bericht: bericht
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
