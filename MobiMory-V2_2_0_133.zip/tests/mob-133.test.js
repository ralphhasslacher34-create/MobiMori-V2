'use strict';
/* Bau 2.0.133: „Person über Bord“ dokumentieren, Punkte 1–17. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'geheim', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'segeln', 'seemann', 'mob', 'pdf', 'karte', 'konto', 'abgleich', 'texte', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

const APP = 'https://app.example.org';
const PW = 'Sehr-sicheres-Passwort-1';
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) { return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, extra || {}); }
function uhr() { const u = { t: Date.UTC(2026, 10, 10, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
const text = (s) => new TextEncoder().encode(s);

async function ruf(env, u, methode, weg, body, token) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
  return { status: r.status, json: await r.json() };
}
/* Bytes hoch (PUT) und runter (GET). Content-Length setzt in der echten Welt der Browser. */
async function bytesRuf(env, u, methode, weg, bytes, token, ohneLaenge) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (token) kopf.Authorization = 'Bearer ' + token;
  if (bytes) { kopf['Content-Type'] = 'application/octet-stream'; if (!ohneLaenge) kopf['Content-Length'] = String(bytes.length); }
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: bytes || undefined }), env, { jetzt: u.jetzt });
  return r;
}
async function konto(env, u, email) {
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email, passwort: PW });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode });
  return b.json.token;
}

function geraetBauen(env, u) {
  return async function () {
    const d0 = await laden();
    const f = async (url, methode, token, body) => {
      const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.7' };
      if (body !== undefined && body !== null) kopf['Content-Type'] = 'application/json';
      if (token) kopf.Authorization = 'Bearer ' + token;
      const r = await d0.behandeln(new Request(url, { method: methode, headers: kopf, body: body === undefined || body === null ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
      const j = await r.json();
      if (!r.ok) { const e = new Error(j.error); e.status = r.status; throw e; }
      return j;
    };
    const fb = async (url, methode, token, bytes) => {
      const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.7', Authorization: 'Bearer ' + token };
      if (bytes) { kopf['Content-Type'] = 'application/octet-stream'; kopf['Content-Length'] = String(bytes.length); }
      const r = await d0.behandeln(new Request(url, { method: methode, headers: kopf, body: bytes || undefined }), env, { jetzt: u.jetzt });
      if (!r.ok) { const j = await r.json(); const e = new Error(j.error); e.status = r.status; throw e; }
      if (methode === 'GET') return { bytes: new Uint8Array(await r.arrayBuffer()), verschluesselt: r.headers.get('X-Verschluesselt') === '1' };
      return { json: await r.json() };
    };
    let n = 0;
    const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { kontoAnfrage: (...a) => d.netz(...a), kontoBytes: (...a) => d.netzBytes(...a), jetzt: () => new Date(u.t + (n++) * 1000).toISOString() });
    d.netz = f; d.netzBytes = fb;
    await d.starten();
    await d.kontoDienstSpeichern('https://konto.example.workers.dev');
    return d;
  };
}
async function zweiGeraete() {
  const env = umgebung(), u = uhr(), neu = geraetBauen(env, u);
  const a = await neu(), b = await neu();
  const r = await a.kontoRegistrieren({ email: 'anna@example.org', passwort: PW });
  assert.equal((await a.kontoCodePruefen({ email: 'anna@example.org', code: r.entwicklungsCode })).ok, true);
  const c = await b.kontoCodeAnfordern({ email: 'anna@example.org' });
  assert.equal((await b.kontoCodePruefen({ email: 'anna@example.org', code: c.entwicklungsCode })).ok, true);
  return { env, u, a, b, neu };
}

const WORT = 'mein-Schluesselwort';
const GPS = { breite: 54.40123, laenge: 10.15432, genauigkeit: 5 };
async function toern(d) {
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen('motorboot', { bezeichnung: 'Möwe', rufzeichen: 'DA1234', mmsi: '211000000' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const art = (await d.aktivitaetsartenListe()).find((x) => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const tag = d.jetztLokal().slice(0, 10);
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Ostsee', artId: art, fahrzeugId: fz, vonDatum: tag, vonZeit: '00:00', bisDatum: tag, bisZeit: '23:59', verantwortlichId: anna });
  assert.ok(r.ok, JSON.stringify(r));
  await d.heutigerTag(r.id);
  return { id: r.id, fz };
}
function neu() {
  const u = { ms: new Date(2026, 6, 3, 14, 0, 0).getTime() };
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(u.ms++).toISOString() });
  return { d, u };
}
const werte = async (d, id) => (await d.ereignisLaden(id)).aktuell.werte;

test('Ablauf: Knopfdruck, Weg ohne Punktgrenze, Sichtungen, Bergung, Logbuchzeilen, Sperre, Nachtrag, Foto, Vergleich', async () => {
  const { d, u } = neu(); await d.starten();
  const c = await toern(d);
  const r = await d.personUeberBord(c.id, { position: GPS });
  assert.ok(r.ok, JSON.stringify(r));
  let w = await werte(d, r.id);
  assert.equal(w.mobStart.breite, GPS.breite); assert.ok(w.mobGeraet);
  await d.mobLaeuftMerken({ ereignisId: r.id, aktivitaetId: c.id });
  assert.equal((await d.mobLaeuft()).ereignisId, r.id);

  /* 6000 Sekunden, ohne Bewegung: jeder Punkt bleibt, auch der erste */
  const punkte = [];
  for (let s = 0; s < 6000; s++) assert.ok(MM.Mob.wegPunkt(punkte, GPS.breite, GPS.laenge, u.ms + s * 1000));
  assert.equal(MM.Mob.wegPunkt(punkte, GPS.breite, GPS.laenge, punkte[5999][2] + 200), false, 'höchstens einer je Sekunde');
  await d.mobWegSpeichern(r.id, punkte.slice(0, 3000)); await d.mobWegSpeichern(r.id, punkte.slice(2000));
  const weg = await d.mobWegLesen(r.id);
  assert.equal(weg.length, 6000); assert.equal(weg[0][2], punkte[0][2]);

  u.ms += 60000;
  assert.ok((await d.mobGesichtet(r.id, { breite: 54.402, laenge: 10.155 })).ok);
  u.ms += 30000;
  assert.ok((await d.mobGesichtet(r.id, { breite: 54.403, laenge: 10.156 })).ok);
  await d.mobGesichtet(r.id, { breite: 54.5, laenge: 10.5 }, true);
  w = await werte(d, r.id);
  assert.equal(w.mobSichtungen.length, 2); assert.equal(w.mobSichtungen[1].breite, 54.403, 'GPS-Wert bleibt'); assert.equal(w.mobSichtungen[1].person.breite, 54.5);
  await d.mobHaken(r.id, 'funk'); const zeit = (await werte(d, r.id)).mobCheck.funk; u.ms += 5000; await d.mobHaken(r.id, 'funk');
  assert.equal((await werte(d, r.id)).mobCheck.funk, zeit);

  /* Angaben während des Manövers: kein Nachtrag */
  assert.ok((await d.mobAkteSpeichern(r.id, { wer: 'Bernd', notruf: 'ja', notrufWeg: 'DSC' })).ok);
  assert.equal(MM.Mob.nachtraege(await werte(d, r.id)).length, 0);

  u.ms += 120000;
  assert.ok((await d.mobBeenden(r.id, { position: { breite: 54.404, laenge: 10.157 } })).ok);
  assert.equal((await d.mobBeenden(r.id, {})).ok, false, 'nur einmal');
  assert.equal(await d.mobLaeuft(), null);
  w = await werte(d, r.id);
  assert.equal(w.endeStatus, 'erkannt'); assert.equal(w.mobBergung.breite, 54.404); assert.ok(w.dauerS >= 215);

  /* Nach dem Ende: Nachtrag mit alt und neu */
  assert.ok((await d.mobAkteSpeichern(r.id, { warum: 'Welle', massnahmen: ['Aufwärmen'], zustand: 'unterkühlt' })).ok);
  assert.equal((await d.mobAkteSpeichern(r.id, { warum: 'Welle' })).geaendert, false);
  w = await werte(d, r.id);
  assert.equal(MM.Mob.nachtraege(w).length, 1); assert.match(MM.Mob.nachtraege(w)[0][1], /Warum: leer → Welle/);
  assert.equal(MM.Mob.angaben(w).wer, 'Bernd'); assert.equal(MM.Mob.angaben(w).notruf, 'ja');

  /* Logbuch: je eine Zeile */
  const alles = JSON.stringify(await d.logbuchLaden(c.id));
  assert.equal((alles.match(/Sichtung \d um/g) || []).length, 2); assert.match(alles, /Person wieder an Bord um/); assert.match(alles, /über Bord \d\d:\d\d:\d\d/); assert.match(alles, /Wer: Bernd/);

  /* Sperre: Zeit und Position nicht änderbar, Ernstfall nicht ausblendbar */
  const x = await d.ereignisLaden(r.id);
  const roh = { artId: x.aktuell.werte.artId, datum: w.datum, zeit: '00:01', text: w.text, breite: String(w.breite), laenge: String(w.laenge), positionWarum: 'Test', ortName: w.ortName || '' };
  const a1 = await d.ereignisAendern(r.id, roh);
  assert.equal(a1.ok, false, JSON.stringify(a1));
  const a2 = await d.ereignisAendern(r.id, Object.assign({}, roh, { zeit: w.zeit, text: 'Ergänzung' }));
  assert.ok(a2.ok, JSON.stringify(a2));

  /* Foto */
  const f = await d.mobFotoDazu(r.id, new Blob(['bild'], { type: 'image/jpeg' }));
  assert.ok(f.ok, JSON.stringify(f));
  await d.mobFotoDazu(r.id, new Blob(['bild2'], { type: 'image/jpeg' }));
  const m = await d.mobLaden(r.id);
  assert.equal(m.fotos.length, 2); assert.equal(m.weg.length, 6000); assert.deepEqual(m.crew, ['Anna']);

  const v = await d.mobVergleich(c.fz);
  assert.equal(v.length, 1); assert.equal(v[0].uebung, false); assert.ok(v[0].sichtungS >= 60); assert.ok(v[0].bergungS >= 215);

  const gpx = MM.Mob.gpx(w, m.weg);
  assert.equal((gpx.match(/<trkpt /g) || []).length, 6000); assert.match(gpx, /<name>Wieder an Bord<\/name>/);
  const pdf = MM.Mob.bericht({ werte: w, strecke: m.strecke, fahrzeug: 'Möwe', aktivitaet: 'Ostsee', fotos: [], karte: null, datum: d.jetzt() });
  assert.equal(new TextDecoder('latin1').decode(pdf.slice(0, 5)), '%PDF-');
});

test('Übung: eigene Zeile, im Vergleich als Übung', async () => {
  const { d, u } = neu(); await d.starten();
  const c = await toern(d);
  const r = await d.personUeberBord(c.id, {});
  u.ms += 90000;
  await d.mobBeenden(r.id, { uebung: true });
  const w = await werte(d, r.id);
  assert.equal(w.uebung, 'uebung'); assert.equal(w.mobBergung.breite, undefined);
  assert.match(JSON.stringify(await d.logbuchLaden(c.id)), /Übung beendet \(Person über Bord\)/);
  assert.equal((await d.mobVergleich(c.fz))[0].uebung, true);
});

test('Notruf-Vorlage: See und Binnen, Deutsch und Englisch', () => {
  const o = { revier: 'see', sprache: 'de', name: 'Möwe', rufzeichen: 'DA1234', mmsi: '211000000', start: { ms: Date.UTC(2026, 6, 3, 12, 5), breite: 54.40123, laenge: -10.15432 }, personen: 3 };
  const see = MM.Mob.notruf(o);
  assert.deepEqual(see.zeilen.slice(0, 4), ['MAYDAY MAYDAY MAYDAY', 'THIS IS', 'Möwe, Möwe, Möwe', 'DA1234, MMSI 211000000']);
  assert.ok(see.zeilen.includes('Position 54° 24,074\' N  010° 09,259\' W'), see.zeilen.join('|'));
  assert.ok(see.zeilen.some((z) => z.startsWith('Zeit 12:05 UTC'))); assert.ok(see.zeilen.includes('Personen an Bord: 3'));
  assert.equal(see.buchstabiert[0][1], 'Mike · Oscar · Echo · Whiskey · Echo');
  const bin = MM.Mob.notruf(Object.assign({}, o, { revier: 'binnen', sprache: 'en', stromkilometer: '1501,3', atis: '9211', mmsi: '' }));
  assert.ok(bin.zeilen.includes('river kilometre 1501,3')); assert.match(bin.schritte[0], /channel 10/); assert.ok(bin.zeilen.includes('DA1234, ATIS 9211'));
  assert.match(MM.Mob.notruf({ revier: 'see', sprache: 'de' }).zeilen.join(' '), /________/);
});

test('Zwei Geräte: Angaben zu Personen nur verschlüsselt beim Dienst, Weg und Angaben kommen an', async () => {
  const { env, a, b } = await zweiGeraete();
  await a.geheimWortSetzen(WORT);
  const c = await toern(a);
  const r = await a.personUeberBord(c.id, { position: GPS });
  await a.mobAkteSpeichern(r.id, { wer: 'Geheimname', schilderung: 'Vertraulicher Hergang', notruf: 'ja' });
  const punkte = []; for (let s = 0; s < 4500; s++) MM.Mob.wegPunkt(punkte, GPS.breite, GPS.laenge, 1000000 + s * 1000);
  await a.mobWegSpeichern(r.id, punkte);
  await a.mobBeenden(r.id, { position: GPS });
  const s1 = await a.abgleichAusfuehren(); assert.equal(s1.ok, true, JSON.stringify(s1));
  const d1 = await a.dateienAbgleichen({ schluesselwort: WORT }); assert.equal(d1.ok, true, JSON.stringify(d1));
  const tabellen = env.DB.roh.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((t) => t.name);
  const alles = tabellen.map((t) => JSON.stringify(env.DB.roh.prepare('SELECT * FROM "' + t + '"').all())).join('') + [...env.DATEN.m.values()].map((v) => new TextDecoder('latin1').decode(v)).join('');
  assert.ok(!alles.includes('Geheimname'), 'Name im Klartext beim Dienst'); assert.ok(!alles.includes('Vertraulicher Hergang'));
  await b.geheimWortSetzen(WORT);
  assert.equal((await b.abgleichAusfuehren()).ok, true);
  const d2 = await b.dateienAbgleichen({ schluesselwort: WORT }); assert.equal(d2.ok, true, JSON.stringify(d2));
  const w = (await b.ereignisLaden(r.id)).aktuell.werte;
  assert.equal(w.mobBergung.breite, GPS.breite);
  assert.equal(MM.Mob.angaben(w).wer, 'Geheimname'); assert.equal(MM.Mob.angaben(w).schilderung, 'Vertraulicher Hergang');
  assert.equal((await b.mobWegLesen(r.id)).length, 4500);
});
