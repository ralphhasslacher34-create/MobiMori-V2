/* Handbuch 2.0.128: Schrittlisten in den Kapiteln, Kapitel „Häufige Fragen“, Hilfe an der Stelle („? Hilfe“). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
require('../js/handbuch.js');
const H = global.MM.Handbuch;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

const schritteVon = (id, sp) => H.kapitel(id, sp || 'de').bloecke.filter((b) => b.typ === 'schritte').reduce((n, b) => n + b.punkte.length, 0);

test('Kapitel, die vorher keine Schritte hatten, haben jetzt welche (deutsch und englisch gleich viele)', () => {
  ['stammdaten', 'fahrzeug', 'personen', 'orte', 'listen', 'checks', 'unterwegs', 'karte', 'kasse', 'stoerung', 'geraete', 'erfassen'].forEach((id) => {
    assert.ok(schritteVon(id) >= 3, 'zu wenig Schritte: ' + id);
    assert.equal(schritteVon(id, 'en'), schritteVon(id, 'de'), 'Sprachen ungleich: ' + id);
  });
});

test('Dokument erfassen: die Knopfnamen der Scan-Seite stehen im Kapitel', () => {
  const t = H.kapitel('erfassen', 'de').bloecke.map((b) => (b.text || '') + ' ' + (b.punkte || []).join(' ')).join(' ');
  const scan = lesen('js/erfassung-ansicht.js');
  ['Mit der Kamera aufnehmen', 'Aus Datei', 'Aufnehmen', 'Foto senden und lesen', 'Stattdessen auf dem Gerät lesen', 'Neu aufnehmen', 'Stelle auf dem Bild markieren', 'Diese Stelle lesen', 'Weitere Seite aufnehmen', 'Angaben sind richtig, speichern', 'Verwerfen', 'Ich stimme zu', 'Zustimmung widerrufen', 'Neue Person', 'Neues Fahrzeug', 'Als Kosten eintragen'].forEach((n) => {
    assert.ok(scan.includes("'" + n + "'"), 'Knopf nicht in der App: ' + n);
    assert.ok(t.includes('„' + n + '“'), 'Knopf nicht im Handbuch: ' + n);
  });
});

test('Knopfnamen der neuen Schritte gibt es in der App', () => {
  const ansicht = lesen('js/ansicht.js');
  ['Hauptkomponente hinzufügen', 'Teil hinzufügen', 'Frist hinzufügen', 'Zähler hinzufügen', 'Dokument hinzufügen', 'Erledigt eintragen', 'Neuen Stand eintragen', 'Angaben ändern', 'Angaben speichern',
    'Nachweis hinzufügen', 'Standort hinzufügen', 'Regel hinzufügen', 'Adresse anlegen', 'Ort suchen und anlegen', 'Ort suchen', 'Vorschläge übernehmen', 'Eigene Art anlegen', 'Ausblenden', 'Wieder einblenden',
    'Grundcheck öffnen', 'Grundcheck starten', 'Logbuch jetzt starten', 'Tagesabschluss', 'Nachtragen', 'Offline-Karte holen', 'Reisekasse öffnen', 'Kasse anlegen', 'Einzahlung', 'Ausgabe eintragen', 'Kassensturz',
    'Neuer Bericht', 'Schlüsselwort speichern', 'Schlüsselwort von diesem Gerät entfernen', 'Person hinzufügen', 'Tier hinzufügen'].forEach((n) => {
    assert.ok(ansicht.includes(n), 'Knopf nicht in der App: ' + n);
  });
});

test('Kapitel „Häufige Fragen“: letztes Kapitel, Fragen und Antworten in beiden Sprachen', () => {
  const ids = H.inhaltsliste('de').map((k) => k.id);
  assert.equal(ids[ids.length - 1], 'faq');
  const de = H.kapitel('faq', 'de'), en = H.kapitel('faq', 'en');
  assert.equal(de.bloecke.length, en.bloecke.length);
  assert.ok(de.bloecke.filter((b) => b.typ === 'kopf').length === 11);
  assert.ok(de.bloecke.every((b) => (b.text || '').trim() || (b.punkte || []).length));
  /* Zahlen der Antworten stammen aus den Stufen im Code */
  require('../js/konto.js');
  const st = global.MM.Konto.STUFEN;
  const t = de.bloecke.map((b) => b.text || '').join(' ');
  assert.ok(t.includes('Basic: ' + st.basic.geraete + ', Testwoche: ' + st.test.geraete + ', Mittel: ' + st.mittel.geraete + ', Voll: ' + st.voll.geraete));
  assert.ok(t.includes('in der Testwoche (' + st.test.scans + ' Scans im Monat), mit Mittel (' + st.mittel.scans + ') und mit Voll (' + st.voll.scans + ')'));
  assert.ok(t.includes('Mittel hat ' + st.mittel.checks + ', Voll ' + st.voll.checks + ' Online-Checks'));
});

test('Hilfe an der Stelle: jede Hilfe verweist auf ein vorhandenes Kapitel, Texte in beiden Sprachen', () => {
  const ids = H.inhaltsliste('de').map((k) => k.id);
  assert.ok(H.HILFEN.length >= 15);
  H.HILFEN.forEach((x) => {
    assert.ok(ids.includes(x.kapitel), 'Kapitel fehlt: ' + x.kapitel);
    assert.ok(x.de.length > 40 && x.en.length > 40);
    assert.ok(x.de.length < 400, 'Hilfe zu lang: ' + x.de.slice(0, 40));
    assert.equal(/peilung/i.test(x.de + x.en), false);
  });
  const f = H.hilfeFuer(['fahrzeug', 'abc'], 'de');
  assert.equal(f.kapitel, 'fahrzeug'); assert.equal(f.nr, 5); assert.ok(f.titel && f.text);
  assert.equal(H.hilfeFuer(['fahrzeug', 'abc', 'grundcheck'], 'de').kapitel, 'checks');
  assert.equal(H.hilfeFuer(['fahrzeug', 'abc', 'abgeben'], 'de').kapitel, 'verleih');
  assert.equal(H.hilfeFuer(['fahrzeug', 'abc', 'frist', 'neu'], 'de').kapitel, 'fahrzeug');
  assert.equal(H.hilfeFuer(['konto'], 'en').nr, 19);
  assert.equal(H.hilfeFuer(['aktivitaet', 'x', 'karte'], 'de').kapitel, 'karte');
  assert.equal(H.hilfeFuer(['handbuch', 'fahrzeug'], 'de'), null);
  assert.equal(H.hilfeFuer(['auswahl'], 'de'), null);
  assert.equal(H.hilfeFuer([], 'de'), null);
  assert.notEqual(H.hilfeFuer(['konto'], 'de').text, H.hilfeFuer(['konto'], 'en').text);
});

test('Einbau: Hilfekasten in ansicht.js und Stil, Neuerung mit „Wo und wie“, Changelog', () => {
  require('../js/texte.js');
  const ansicht = lesen('js/ansicht.js');
  assert.ok(ansicht.includes('function hilfeKasten(h1)') && ansicht.includes('hilfeKasten(h1);'));
  assert.ok(ansicht.includes("class: 'hilfe-kasten'"));
  assert.ok(lesen('css/styles.css').includes('.hilfe-kasten'));
  const n = global.MM.Texte.NEUERUNGEN[5];
  assert.equal(n.version, '2.0.128');
  assert.match(n.punkte.join(' '), /Häufige Fragen/); assert.match(n.punkte.join(' '), /\? Hilfe/);
  assert.ok(lesen('CHANGELOG.md').startsWith('# Änderungen\n\n## 2.0.133'));
  assert.equal(/peilung/i.test(ansicht.slice(ansicht.indexOf('function hilfeKasten'), ansicht.indexOf('function hilfeKasten') + 1500)), false);
});
