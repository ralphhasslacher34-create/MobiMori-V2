# Schritte beim Aufbau von V2

Grundlage ist das Dokument „MobiMory V2 – Festlegungen und Datenstruktur“.
Jeder Schritt baut auf dem letzten auf und endet mit einem sichtbaren Ergebnis.

| Schritt | Inhalt | Stand |
|---|---|---|
| 1 | Fahrzeug: Fahrzeugliste (Schale 1) und äußere Hülle (Schale 2), Handeingabe, Verlauf, offline | fertig (2.0.1) |
| 1a | Ansicht der äußeren Schalen: Startseite, Hauptmenü, Stammdaten, Neu im Programm, Einstellungen | fertig (2.0.2) |
| 2 | Hauptkomponenten (Schale 3), beliebig tief verschachtelt, mit Hersteller, Modell, Seriennummer, Baujahr, Einbau, technischen Merkmalen | fertig (2.0.4) |
| 3 | Fristen an Fahrzeug und Komponenten (Kalender und Zähler), Zählerstände von Hand, Erledigungen | fertig (2.0.5) |
| 3a | Dokumente an Fahrzeug und Komponente (Datei oder Link), Gesamtliste | fertig (2.0.6) |
| 3b | Personen, Tiere und Nachweise (offene Nachweisarten mit Vorschlägen DE/EU) | fertig (2.0.7) |
| 4 | Aktivität mit gemeinsamem Kern (Besatzung aus den Personen, Prüfung bei der Planung) | fertig (2.0.8) |
| 4b | Sicherungsdatei: sichern, verschlüsseln, wiederherstellen, Erinnerung | fertig (2.0.9) |
| 4a | Orte und Gebiete mit Regeln (Stufe 1: eigene Regeln, einfache Gebietsliste) | fertig (2.0.10, erweitert in 2.0.11), noch nicht getestet |
| 4c | Testrunde mit echten Daten (Wohnmobil und Boot) | offen |
| 5 | Smart Capture (Fahrzeugschein und Nachweise einlesen) | offen |
| 6 | Zähler automatisch: Start/Stopp-Schalter für Motorlaufzeit, Motorstopp-Frage nach Ankunft | offen |
| … | Weitere Schritte nach der Reihenfolge im Festlegungsdokument | offen |

## Noch nicht drin, weil sie auf anderen Teilen aufbauen
- Weitere feste Standorte der äußeren Hülle: Der Heimatstandort ist seit 2.0.10 da, weitere folgen nach Bedarf.
- Konto und Anmeldung, Server, Sicherung: kommen später. Schritt 1 arbeitet nur lokal (Basis-Version).
- Wertverlauf und Kosten: kommen mit der Kostenstruktur.
- Fristen, Kosten und Nachweise an den Komponenten: kommen mit den jeweiligen Schritten.
- Feste Merkmal-Kataloge je Komponente (bisher frei eintragbar): im Festlegungsdokument noch nicht besprochen.
- Funktionen, Personen und Tiere: Kacheln sind da und zeigen „kommt“.
- Dokumente auf dem Server und auf mehreren Geräten (Original auf dem Server, Kopie „offline verfügbar“ auf dem Gerät): kommt mit Konten und Server.
- Smart Capture (Fahrzeugschein einlesen): eigener Schritt, nutzt die Ablage für Dateien.
- Vorschläge für Nachweisarten aus weiteren Ländern: kommen nach Bedarf, Land für Land, jeweils mit Quelle und Prüfdatum.
- Prüfung „erlaubt, nicht erlaubt, unklar“ für Skipper und Fahrer: kommt mit der Aktivität.
- Prüfung gegen Anforderungen eines Gebiets: seit 2.0.10 mit eigenen Regeln. Ein Gebiet nur als Text wird weiter nicht geprüft.
- Prüfung zu jedem Tagesbeginn und bei jedem Wechsel des Verantwortlichen unterwegs: kommt mit dem Logbuch.
- Automatische Sicherung und Umzug zwischen mehreren Geräten ohne Datei: kommt mit Konten und Server.
- Regeln mit Quelle und Prüfdatum (Stufe 2) und weitere Länder sowie Motorleistung und Gewicht als Bedingungen (Stufe 3): erst nach der Testrunde.
