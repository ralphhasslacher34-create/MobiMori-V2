/*
 * Reisebuch (Bau 4, seit 2.0.81): aus einer eigenen Reise (Aktivität) ein Buch machen. Reine Rechnung und Texte, kein Netz, kein Speicher.
 * Das Sammeln der Daten und der Bilder steht in daten.js, die Seite in ansicht.js.
 *
 * Festlegung (Nutzer, 14./15.11.2026): Jeder MobiMory-Nutzer kann aus seinen eigenen Reisen ein Reisebuch erstellen. Ausgabe: Seite in der App
 * und PDF zum Drucken (dazu der Druck der Seite). Inhalt: Daten aus MobiMory (Reise, Tage, Ereignisse, Orte) plus die gespeicherten Fotos.
 * Kosten sind Privatsache und kommen nur auf Wunsch hinein. Das Reisebuch verändert nichts an den Daten und geht nie ins Netz.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Fotos im PDF: höchstens so viele, damit die Datei handlich bleibt. Die Seite zeigt alle. */
  var MAX_BILDER_PDF = 60;
  var STANDARD = { bilder: true, kosten: false, notizen: true };

  function text(x) { return x === null || x === undefined ? '' : String(x).trim(); }
  function datum(d) { return d && MM.Hilfen && MM.Hilfen.datum ? MM.Hilfen.datum(d) : text(d); }
  function zahlText(n) { return MM.Hilfen && MM.Hilfen.zahl ? MM.Hilfen.zahl(n) : String(n); }
  function mitEinheit(n, einheit) { return zahlText(n) + (einheit ? ' ' + einheit : ''); }
  function betrag(n) { return typeof n === 'number' && isFinite(n) ? n.toFixed(2).replace('.', ',') + ' €' : ''; }
  function pluralisiert(n, eins, viele) { return n + ' ' + (n === 1 ? eins : viele); }

  function optionen(roh) {
    var o = Object.assign({}, STANDARD);
    if (roh && typeof roh === 'object') Object.keys(STANDARD).forEach(function (k) { if (typeof roh[k] === 'boolean') o[k] = roh[k]; });
    return o;
  }

  /* Wie viele Tage (inklusive) von bis. */
  function tageZwischen(von, bis) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text(von)) || !/^\d{4}-\d{2}-\d{2}$/.test(text(bis))) return null;
    var a = Date.parse(von + 'T00:00:00Z'), b = Date.parse(bis + 'T00:00:00Z');
    return isNaN(a) || isNaN(b) || b < a ? null : Math.round((b - a) / 86400000) + 1;
  }

  /*
   * Das Buch aus den gesammelten Angaben (siehe Daten.reisebuchLaden). Nichts Ausgeblendetes kommt hinein.
   * Ergebnis: { titel, untertitel, steckbrief: [[Name, Wert]], zahlen: [[Name, Wert]], tage: [{ nr, kopf, zeilen, notiz, ereignisse: [{ id, zeit, art, text, ort, bildId }] }],
   *             besuche: [{ ort, datum, notiz }], kosten: { zeilen } oder null, bildIds: [Ereignis-IDs mit Foto], optionen }
   */
  function bauen(roh, opt) {
    roh = roh || {};
    var o = optionen(opt);
    var tage = (roh.tage || []).map(function (t, i) {
      var zeilen = [];
      var weg = [text(t.start), text(t.ziel)].filter(Boolean).join(' → ') || [text(t.von), text(t.nach)].filter(Boolean).join(' → ');
      if (weg) zeilen.push(['Strecke', weg]);
      if (typeof t.strecke === 'number' && t.strecke > 0) zeilen.push(['Entfernung', mitEinheit(t.strecke, roh.einheit || 'km')]);
      if (t.beginn || t.ende) zeilen.push(['Zeit', [text(t.beginn), text(t.ende)].filter(Boolean).join(' bis ')]);
      if (text(t.verantwortlicher)) zeilen.push([roh.welt === 'wasser' ? 'Skipper' : 'Am Steuer', text(t.verantwortlicher)]);
      if (text(t.wetter)) zeilen.push(['Wetter', text(t.wetter)]);
      var ereignisse = (t.ereignisse || []).filter(function (e) { return !e.ausgeblendet; }).map(function (e) {
        return { id: e.id, zeit: text(e.zeit), art: text(e.art) || 'Ereignis', text: o.notizen ? text(e.text) : '', ort: text(e.ort), bildId: o.bilder && e.hatFoto ? e.id : null, nachgetragen: !!e.nachgetragen };
      });
      return { nr: i + 1, datum: t.datum, kopf: 'Tag ' + (i + 1) + ', ' + datum(t.datum), zeilen: zeilen, notiz: o.notizen ? text(t.notiz) : '', ereignisse: ereignisse };
    });

    var ereignisAnzahl = 0, fotoAnzahl = 0, bildIds = [];
    tage.forEach(function (t) { t.ereignisse.forEach(function (e) { ereignisAnzahl++; if (e.bildId) { fotoAnzahl++; bildIds.push(e.bildId); } }); });
    /* Auch ohne Bilder in der Ausgabe zählt die Zahl der Fotos der Reise. */
    var fotosGesamt = 0;
    (roh.tage || []).forEach(function (t) { (t.ereignisse || []).forEach(function (e) { if (!e.ausgeblendet && e.hatFoto) fotosGesamt++; }); });

    var steck = [];
    var zeitraum = roh.vonDatum && roh.bisDatum ? (roh.vonDatum === roh.bisDatum ? datum(roh.vonDatum) : datum(roh.vonDatum) + ' bis ' + datum(roh.bisDatum)) : '';
    if (zeitraum) steck.push(['Zeitraum', zeitraum]);
    if (roh.fahrzeug && text(roh.fahrzeug.name)) steck.push(['Fahrzeug', text(roh.fahrzeug.name) + (text(roh.fahrzeug.artName) ? ' (' + text(roh.fahrzeug.artName) + ')' : '')]);
    if (text(roh.art)) steck.push(['Art der Reise', text(roh.art)]);
    var route = [text(roh.start)].concat((roh.zwischenziele || []).map(text), [text(roh.ziel)]).filter(Boolean);
    if (route.length) steck.push(['Route', route.join(' → ')]);
    if (text(roh.gebiet)) steck.push(['Gebiet', text(roh.gebiet)]);
    if ((roh.besatzung || []).length) steck.push(['Besatzung', roh.besatzung.map(function (b) { return text(b.name) + (text(b.rolle) ? ' (' + text(b.rolle) + ')' : ''); }).join(', ')]);
    if ((roh.tiere || []).length) steck.push(['Tiere', roh.tiere.map(text).join(', ')]);
    if (o.notizen && text(roh.notiz)) steck.push(['Notiz', text(roh.notiz)]);

    var zahlen = [];
    var dauer = tageZwischen(roh.vonDatum, roh.bisDatum);
    if (dauer) zahlen.push(['Reisetage', String(dauer)]);
    zahlen.push(['Tage im Logbuch', String(tage.length)]);
    zahlen.push(['Ereignisse', String(ereignisAnzahl)]);
    if (fotosGesamt) zahlen.push(['Fotos', String(fotosGesamt)]);
    if (typeof roh.streckeSumme === 'number' && roh.streckeSumme > 0) zahlen.push(['Strecke gesamt', mitEinheit(roh.streckeSumme, roh.einheit || 'km')]);
    var besuche = (roh.besuche || []).map(function (b) { return { ort: text(b.ort) || 'Ort', datum: text(b.datum), notiz: o.notizen ? text(b.notiz) : '' }; });
    if (besuche.length) zahlen.push(['Orte besucht', String(besuche.length)]);

    var kosten = null;
    if (o.kosten && roh.kosten && typeof roh.kosten.gesamt === 'number') {
      var kz = [['Gesamt', betrag(roh.kosten.gesamt)]];
      if (typeof roh.kosten.fahrzeug === 'number' && roh.kosten.fahrzeug) kz.push(['Rund ums Fahrzeug', betrag(roh.kosten.fahrzeug)]);
      if (typeof roh.kosten.reisekasse === 'number' && roh.kosten.reisekasse) kz.push(['Reisekasse', betrag(roh.kosten.reisekasse)]);
      if (typeof roh.kosten.proPerson === 'number') kz.push(['Je Person', betrag(roh.kosten.proPerson)]);
      if (typeof roh.kosten.proTag === 'number') kz.push(['Je Tag', betrag(roh.kosten.proTag)]);
      kosten = { zeilen: kz };
    }

    return {
      titel: text(roh.titel) || 'Reisebuch', untertitel: zeitraum, steckbrief: steck, zahlen: zahlen, tage: tage, besuche: besuche, kosten: kosten,
      bildIds: bildIds, optionen: o, fotosGesamt: fotosGesamt, fahrzeugName: roh.fahrzeug ? text(roh.fahrzeug.name) : ''
    };
  }

  /* Dateiname ohne Sonderzeichen. */
  function dateiName(buch, endung) {
    var n = text(buch && buch.titel).replace(/[^A-Za-z0-9ÄÖÜäöüß_-]+/g, '_').replace(/^_+|_+$/g, '') || 'Reise';
    return 'Reisebuch_' + n + (endung || '.pdf');
  }

  /*
   * Das PDF. bilder: { <Ereignis-ID>: Uint8Array mit JPEG } (fehlende oder unlesbare Fotos werden mit einem Hinweis übersprungen).
   * ctx: { fuss, datum }. Gibt { bytes, bilder, ohneBild, zuViele } zurück.
   */
  function pdf(buch, bilder, ctx) {
    ctx = ctx || {};
    bilder = bilder || {};
    var d = MM.Pdf.neu({ fuss: ctx.fuss || ('MobiMory · Reisebuch ' + buch.titel), titel: 'Reisebuch ' + buch.titel, datum: ctx.datum });
    var eingefuegt = 0, ohne = 0, zuViele = 0;
    d.titel(buch.titel, buch.untertitel || '');
    if (buch.steckbrief.length) { d.abschnitt('Die Reise'); buch.steckbrief.forEach(function (z) { d.zeile(z[0], z[1]); }); }
    if (buch.zahlen.length) { d.abschnitt('Auf einen Blick'); buch.zahlen.forEach(function (z) { d.zeile(z[0], z[1]); }); }
    buch.tage.forEach(function (t) {
      d.abschnitt(t.kopf);
      t.zeilen.forEach(function (z) { d.zeile(z[0], z[1]); });
      if (t.notiz) d.absatz(t.notiz, { grau: true });
      if (!t.ereignisse.length) d.absatz('Keine Einträge an diesem Tag.', { grau: true });
      t.ereignisse.forEach(function (e) {
        d.absatz((e.zeit ? e.zeit + '  ' : '') + e.art + (e.ort ? ', ' + e.ort : '') + (e.nachgetragen ? ' (nachgetragen)' : '') + (e.text ? ': ' + e.text : ''), { groesse: 10 });
        if (e.bildId) {
          if (eingefuegt >= MAX_BILDER_PDF) { zuViele++; return; }
          var b = bilder[e.bildId];
          if (b && d.bild(b, { maxH: 230, unterschrift: e.art + (e.zeit ? ', ' + e.zeit : '') })) eingefuegt++;
          else { ohne++; d.absatz('(Foto liegt nicht auf diesem Gerät oder ist nicht lesbar.)', { grau: true, groesse: 8 }); }
        }
      });
    });
    if (buch.besuche.length) {
      d.abschnitt('Orte');
      d.tabelle([{ titel: 'Datum', breite: 70 }, { titel: 'Ort', breite: 160 }, { titel: 'Notiz', breite: 0 }],
        buch.besuche.map(function (b) { return [b.datum ? datum(b.datum) : '', b.ort, b.notiz]; }));
    }
    if (buch.kosten) { d.abschnitt('Kosten'); buch.kosten.zeilen.forEach(function (z) { d.zeile(z[0], z[1]); }); }
    if (zuViele) d.absatz('Aus Platzgründen sind nicht alle Fotos im PDF. Die Seite in MobiMory zeigt alle (' + zuViele + ' weitere).', { grau: true, groesse: 8 });
    return { bytes: d.bytes(), bilder: eingefuegt, ohneBild: ohne, zuViele: zuViele };
  }

  MM.Reisebuch = {
    STANDARD: STANDARD, MAX_BILDER_PDF: MAX_BILDER_PDF, optionen: optionen, bauen: bauen, dateiName: dateiName, pdf: pdf, tageZwischen: tageZwischen, pluralisiert: pluralisiert,
    TEXT_EINLEITUNG: 'Aus deiner Reise wird ein Buch: Reise, Tag für Tag, Ereignisse, besuchte Orte und deine Fotos. Du kannst es hier lesen, ausdrucken oder als PDF speichern. MobiMory ändert dabei nichts an deinen Daten und schickt nichts ins Netz.',
    TEXT_KOSTEN: 'Kosten stehen nur im Buch, wenn du es willst. Wer das Buch weitergibt, sieht sonst keine Beträge.',
    TEXT_FOTOS: 'Fotos stehen nur im Buch, wenn sie auf diesem Gerät liegen. Im PDF sind sie verkleinert, damit die Datei handlich bleibt.'
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
