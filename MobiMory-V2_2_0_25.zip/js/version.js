/* Die Versionsnummer steht nur hier. Wer sie ändert, ändert sie überall. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  MM.VERSION = '2.0.25';
  MM.STUFE = 'Werkstatt: Adressen (Werkstätten, Lieferanten, Händler)';
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
