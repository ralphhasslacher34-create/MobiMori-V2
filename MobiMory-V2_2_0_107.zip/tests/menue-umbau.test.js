'use strict';
/* 2.0.73 (Dienst 13e-5): Menü-Umbau (Bau A) und Rollen-Tabelle. Dienst mit nachgebauter Datenbank, App-Teil über Quelltext und Daten-Schicht. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

const APP = 'https://app.example.org';
const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) {
  return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, extra || {});
}
function uhr() { const u = { t: Date.UTC(2026, 10, 14, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
async function ruf(env, u, methode, weg, body, token) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
  return { status: r.status, json: await r.json() };
}
async function konto(env, u, email) {
  u.t += 13 * 60 * 1000;
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email });
  const r = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode, geraet: 'Test #01234567' });
  assert.equal(r.status, 200, JSON.stringify(r.json));
  return r.json.token;
}
function rolleDirekt(env, email, name, funktion) { env.DB.roh.prepare('INSERT OR REPLACE INTO rolle (email, name, funktion) VALUES (?, ?, ?)').run(email, name, funktion); }
function tabelle(env) { env.DB.roh.exec("CREATE TABLE IF NOT EXISTS rolle (email TEXT PRIMARY KEY, name TEXT NOT NULL, funktion TEXT NOT NULL CHECK (funktion IN ('admin', 'entwickler')))"); }

test('Dienst 13e-5: Version, eine SQL-Zeile steht auch im Schema, der erste Admin ist eine eigene Datei', async () => {
  const d = await laden();
  assert.equal(d.VERSION, '13g');
  const sql = lesen('server/13e-5.sql').trim().split('\n');
  assert.equal(sql.length, 1);
  assert.match(sql[0], /^CREATE TABLE IF NOT EXISTS rolle /);
  assert.ok(lesen('server/schema.sql').includes(sql[0]));
  assert.match(lesen('server/13e-5-erster-admin.sql'), /INSERT OR REPLACE INTO rolle .* 'admin'/);
  assert.ok(lesen('server/EINRICHTUNG.md').includes('Update auf 13e-5'));
  assert.deepEqual(d.FUNKTIONEN, ['admin', 'entwickler']);
});

test('Rolle: ohne Tabelle keine Rolle und Gesundheit „rollen: false“; mit Tabelle meldet /konto/stufe die eigene Funktion', async () => {
  const env = umgebung(), u = uhr();
  const tok = await konto(env, u, 'ralph@example.org');
  env.DB.roh.exec('DROP TABLE rolle');
  assert.equal((await ruf(env, u, 'GET', '/gesundheit')).json.rollen, false);
  assert.equal((await ruf(env, u, 'GET', '/konto/stufe', undefined, tok)).json.rolle, null);
  tabelle(env);
  assert.equal((await ruf(env, u, 'GET', '/gesundheit')).json.rollen, true);
  assert.equal((await ruf(env, u, 'GET', '/konto/stufe', undefined, tok)).json.rolle, null, 'nicht eingetragen: keine Rolle');
  rolleDirekt(env, 'ralph@example.org', 'Ralph', 'admin');
  assert.equal((await ruf(env, u, 'GET', '/konto/stufe', undefined, tok)).json.rolle, 'admin');
  rolleDirekt(env, 'ralph@example.org', 'Ralph', 'entwickler');
  assert.equal((await ruf(env, u, 'GET', '/konto/stufe', undefined, tok)).json.rolle, 'entwickler');
});

test('Rolle: Die Stufe „entwickler“ allein macht niemanden zum Entwickler im Menü', async () => {
  const env = umgebung(), u = uhr();
  tabelle(env);
  const tok = await konto(env, u, 'stufe@example.org');
  const n = env.DB.roh.prepare('SELECT id FROM nutzer WHERE email = ?').get('stufe@example.org');
  env.DB.roh.prepare('INSERT INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) VALUES (?, ?, ?, ?)').run(n.id, 'entwickler', null, 1);
  const s = await ruf(env, u, 'GET', '/konto/stufe', undefined, tok);
  assert.equal(s.json.stufe.id, 'entwickler'); assert.equal(s.json.rolle, null);
});

test('Rollen-Tabelle: Admin und Entwickler lesen, nur Admin ändert; ohne Rolle und ohne Anmeldung geht nichts', async () => {
  const env = umgebung(), u = uhr();
  tabelle(env);
  const admin = await konto(env, u, 'admin@example.org'), ent = await konto(env, u, 'ent@example.org'), fremd = await konto(env, u, 'fremd@example.org');
  rolleDirekt(env, 'admin@example.org', 'Ralph', 'admin'); rolleDirekt(env, 'ent@example.org', 'Entwicklerin', 'entwickler');
  const l = await ruf(env, u, 'GET', '/rolle/liste', undefined, admin);
  assert.equal(l.status, 200); assert.deepEqual(l.json.rollen.map((x) => x.email).sort(), ['admin@example.org', 'ent@example.org']);
  assert.equal((await ruf(env, u, 'GET', '/rolle/liste', undefined, ent)).status, 200, 'Entwickler darf lesen');
  assert.equal((await ruf(env, u, 'GET', '/rolle/liste', undefined, fremd)).status, 403);
  assert.equal((await ruf(env, u, 'GET', '/rolle/liste')).status, 401);
  const neu = { email: 'Neu@Example.org', name: 'Neue Person', funktion: 'entwickler' };
  assert.equal((await ruf(env, u, 'POST', '/rolle/setzen', neu, ent)).status, 403, 'Entwickler darf nicht ändern');
  assert.equal((await ruf(env, u, 'POST', '/rolle/setzen', neu, fremd)).status, 403);
  assert.equal((await ruf(env, u, 'POST', '/rolle/entfernen', { email: 'ent@example.org' }, ent)).status, 403);
  assert.equal((await ruf(env, u, 'POST', '/rolle/setzen', neu, admin)).status, 200);
  const l2 = await ruf(env, u, 'GET', '/rolle/liste', undefined, admin);
  assert.ok(l2.json.rollen.some((x) => x.email === 'neu@example.org' && x.name === 'Neue Person' && x.funktion === 'entwickler'), 'E-Mail wird klein gespeichert');
  /* ändern statt doppelt */
  assert.equal((await ruf(env, u, 'POST', '/rolle/setzen', { email: 'neu@example.org', name: 'Neue Person', funktion: 'admin' }, admin)).status, 200);
  const l3 = await ruf(env, u, 'GET', '/rolle/liste', undefined, admin);
  assert.equal(l3.json.rollen.filter((x) => x.email === 'neu@example.org').length, 1);
  assert.equal(l3.json.rollen.find((x) => x.email === 'neu@example.org').funktion, 'admin');
  assert.equal((await ruf(env, u, 'POST', '/rolle/entfernen', { email: 'neu@example.org' }, admin)).status, 200);
  assert.ok(!(await ruf(env, u, 'GET', '/rolle/liste', undefined, admin)).json.rollen.some((x) => x.email === 'neu@example.org'));
});

test('Rollen-Tabelle: Eingaben werden geprüft, man kann sich nicht selbst entfernen oder herabstufen', async () => {
  const env = umgebung(), u = uhr();
  tabelle(env);
  const admin = await konto(env, u, 'admin@example.org');
  rolleDirekt(env, 'admin@example.org', 'Ralph', 'admin');
  const fehler = async (body) => ruf(env, u, 'POST', '/rolle/setzen', body, admin);
  assert.equal((await fehler({ email: 'kaputt', name: 'X', funktion: 'admin' })).status, 400);
  assert.equal((await fehler({ email: 'a@example.org', name: '', funktion: 'admin' })).status, 400);
  assert.equal((await fehler({ email: 'a@example.org', name: 'x'.repeat(81), funktion: 'admin' })).status, 400);
  assert.equal((await fehler({ email: 'a@example.org', name: 'A', funktion: 'chef' })).status, 400);
  assert.equal((await fehler({ email: 'admin@example.org', name: 'Ralph', funktion: 'entwickler' })).status, 400, 'sich selbst herabstufen');
  assert.equal((await ruf(env, u, 'POST', '/rolle/entfernen', { email: 'admin@example.org' }, admin)).status, 400, 'sich selbst entfernen');
  assert.equal((await ruf(env, u, 'GET', '/konto/stufe', undefined, admin)).json.rolle, 'admin');
});

test('Rollen-Tabelle: höchstens 50 Einträge', async () => {
  const env = umgebung(), u = uhr();
  tabelle(env);
  const admin = await konto(env, u, 'admin@example.org');
  rolleDirekt(env, 'admin@example.org', 'Ralph', 'admin');
  for (let i = 0; i < 49; i++) rolleDirekt(env, 'p' + i + '@example.org', 'P' + i, 'entwickler');
  const r = await ruf(env, u, 'POST', '/rolle/setzen', { email: 'zuviel@example.org', name: 'Zu viel', funktion: 'entwickler' }, admin);
  assert.equal(r.status, 400);
  assert.equal((await ruf(env, u, 'POST', '/rolle/setzen', { email: 'p3@example.org', name: 'Geändert', funktion: 'entwickler' }, admin)).status, 200, 'ändern geht weiter');
});

test('App: Funktionen zeigt Verleih, Fahrzeug abgeben, Kontrollpapiere, Schadensbericht; Freigaben, Konto und Entwickler sind dort weg', () => {
  const an = lesen('js/ansicht.js');
  const f = an.slice(an.indexOf('function seiteFunktionen()'), an.indexOf('/* ---------- Konto (seit 2.0.64'));
  ['Aktivitäten', 'Reisecheck', 'Cockpit und Logbuch', 'Werkstatt', 'Kassenbuch', 'Kosten', 'Verleih', 'Fahrzeug abgeben', 'Kontrollpapiere', 'Schadensbericht'].forEach((n) => assert.ok(f.includes("kachel('" + n + "'"), n));
  ['Freigaben', 'Konto', 'Entwickler'].forEach((n) => assert.ok(!f.includes("kachel('" + n + "'"), n + ' entfällt'));
  assert.match(f, /kachel\('Schadensbericht', '[^']+', '#\/schadensbericht'\)/, 'Schadensbericht ist seit 2.0.91 (Bau C) eine Kachel mit Link');
});

test('App: Hauptmenü hat „Nur für Entwickler“ nur mit Rolle', () => {
  const an = lesen('js/ansicht.js');
  const m = an.slice(an.indexOf('function seiteHauptmenue()'), an.indexOf('function seiteStammdaten()'));
  assert.match(m, /rolle \? kachel\('Nur für Entwickler'[^)]*'#\/nur-entwickler'\) : null/);
});

test('App: Einstellungen als Kacheln; Austausch entfällt, Import, Export und Übergabedatei stehen bei den Fahrzeugen', () => {
  const an = lesen('js/ansicht.js');
  const e = an.slice(an.indexOf('function seiteEinstellungen()'), an.indexOf('function seiteEinstellungenDaten()'));
  ['Deine Daten', 'Anzeige', 'Über MobiMory'].forEach((n) => assert.ok(e.includes("kachel('" + n + "'"), n));
  assert.ok(!e.includes('Import') && !e.includes('Austausch'));
  const d = an.slice(an.indexOf('function seiteEinstellungenDaten()'), an.indexOf('function seiteEinstellungenSicherung()'));
  assert.ok(d.indexOf("kachel('Konto'") < d.indexOf("kachel('Sicherung'"), 'Konto ist die erste Funktion');
  ['Sicherung', 'Speicher', 'Alle Daten löschen'].forEach((n) => assert.ok(d.includes("kachel('" + n + "'"), n));
  const a = an.slice(an.indexOf('function seiteEinstellungenAnzeige()'), an.indexOf('function seiteEinstellungenUeber()'));
  assert.ok(a.includes("kachel('Wetter und Karten'") && a.includes("kachel('Verbrauchseinheit'"));
  assert.ok(!an.includes('function austauschBlock'));
  const l = an.slice(an.indexOf('function seiteListe()'), an.indexOf('function seiteFahrzeug('));
  ['#/einstellungen/import', '#/einstellungen/export', '#/einstellungen/uebernehmen'].forEach((h) => assert.ok(l.includes(h), h));
  const ue = an.slice(an.indexOf('function seiteEinstellungenUeber()'), an.indexOf('function fehlerSeite'));
  assert.ok(ue.includes('MM.VERSION') && ue.includes('MM.Texte.COPYRIGHT') && ue.includes('Verantwortung'));
  const lo = an.slice(an.indexOf('function seiteEinstellungenLoeschen()'), an.indexOf('function seiteEinstellungenAnzeige()'));
  assert.ok(lo.includes('global.confirm('), 'die Rückfrage bleibt');
});

test('App: Router kennt die neuen Adressen, #/freigaben leitet zum Verleih', () => {
  const an = lesen('js/ansicht.js');
  [/teile\[0\] === 'verleih'\) p = seiteFreigaben\('verleih'\)/, /teile\[0\] === 'kontrollpapiere'\) p = seiteFreigaben\('kontrolle'\)/, /teile\[0\] === 'abgeben'\) p = seiteAbgebenWahl\(\)/,
    /teile\[0\] === 'nur-entwickler'\) p = seiteNurEntwickler\(\)/, /teile\[0\] === 'rollen'\) p = seiteRollen\(\)/, /teile\[0\] === 'freigaben'\) \{ global\.location\.replace\('#\/verleih'\)/,
    /teile\[1\] === 'daten'\) p = seiteEinstellungenDaten\(\)/, /teile\[1\] === 'anzeige'\) p = seiteEinstellungenAnzeige\(\)/, /teile\[1\] === 'ueber'\) p = seiteEinstellungenUeber\(\)/].forEach((re) => assert.match(an, re, String(re)));
});

test('App: Verleih und Kontrollpapiere teilen die alte Seite, jeder zeigt nur seinen Teil', () => {
  const an = lesen('js/ansicht.js');
  const f = an.slice(an.indexOf('function seiteFreigaben(teil)'), an.indexOf('/* Ein Fahrzeug, das mir freigegeben wurde.'));
  assert.match(f, /var verleih = teil !== 'kontrolle', titel = verleih \? 'Verleih' : 'Kontrollpapiere'/);
  assert.match(f, /if \(verleih\) verleihTeil\(\); else kontrollTeil\(\);/);
  const v = f.slice(f.indexOf('function verleihTeil()'), f.indexOf('function kontrollTeil()')), k = f.slice(f.indexOf('function kontrollTeil()'));
  ['Fahrzeug verleihen', 'Von mir freigegeben', 'Mit mir geteilt'].forEach((x) => { assert.ok(v.includes(x), x); assert.ok(!k.includes("text: '" + x + "'"), x + ' nicht bei Kontrollpapieren'); });
  assert.ok(k.includes('Kontroll-Freigabe per Code') && !v.includes('Kontroll-Freigabe per Code'));
  assert.ok(f.indexOf('var fzOpt') > 0 && f.indexOf('var fzOpt') < f.indexOf('function verleihTeil()'), 'die Fahrzeugliste gilt für beide Teile (Fehler „fzOpt is not defined“ bei den Kontrollpapieren)');
});

test('App: Entwickler-Seiten prüfen die Rolle selbst, nicht nur das Menü', () => {
  const an = lesen('js/ansicht.js');
  assert.match(an, /function seiteEntwickler\(\) \{\s*return nurEntwickler\('Entwickler'/);
  assert.match(an, /function seiteNurEntwickler\(\) \{\s*return nurEntwickler\(/);
  assert.match(an, /function seiteRollen\(\) \{[\s\S]{0,80}return nurEntwickler\('Rollen'/);
  const n = an.slice(an.indexOf('function nurEntwickler('), an.indexOf('function seiteNurEntwickler()'));
  assert.ok(n.includes('if (!rolle)') && n.includes('Diese Seite gibt es für dich nicht.'));
  const r = an.slice(an.indexOf('function seiteRollen()'), an.indexOf('var meldungRollen'));
  assert.ok(r.includes("var admin = rolle === 'admin'") && r.includes('if (admin) {'), 'Formular nur für Admin');
});

function neueDaten() {
  require('../js/version.js'); require('../js/fahrzeugarten.js'); require('../js/komponenten.js'); require('../js/verbrauch.js'); require('../js/tanken.js'); require('../js/fristen.js');
  require('../js/dokumente.js'); require('../js/nachweis-vorschlaege.js'); require('../js/nachweise.js'); require('../js/aktivitaeten.js'); require('../js/logbuch.js'); require('../js/status.js');
  require('../js/personen.js'); require('../js/orte.js'); require('../js/gebiete.js'); require('../js/ortssuche.js'); require('../js/sicherung.js'); require('../js/speicher.js');
  require('../js/hilfen.js'); require('../js/reiseorte.js'); require('../js/konto.js'); require('../js/freigaben.js'); require('../js/rudergaenger.js');
require('../js/daten.js');
  const MM = globalThis.MM;
  let t = Date.UTC(2026, 10, 14, 12, 0, 0);
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(t).toISOString() });
  d.uhrStellen = (ms) => { t += ms; };
  return d;
}

test('Daten: Die Rolle gilt nur bei angemeldetem Gerät, wird aus /konto/stufe gemerkt und höchstens alle 12 Stunden neu geholt', async () => {
  const d = neueDaten(); await d.starten();
  let aufrufe = 0, rolle = 'admin';
  d.kontoAnfrageFn = async (url, methode) => {
    if (/\/konto\/stufe$/.test(url)) { aufrufe++; return { ok: true, stufe: { id: 'basic', name: 'Basic', bis: null }, grenzen: { geraete: 2, checks: 0, fahrzeuge: 1, online: false }, nutzung: {}, rolle }; }
    throw new Error('unerwartet ' + url);
  };
  assert.equal(await d.rolle(), null, 'ohne Anmeldung keine Rolle');
  await d.rcSchreiben({ kontoToken: 'tok', kontoEmail: 'ralph@example.org' });
  assert.equal(await d.rolle(), null, 'noch nicht geholt');
  let x = await d.rolleAktualisieren(false);
  assert.deepEqual(x, { rolle: 'admin', geaendert: true }); assert.equal(aufrufe, 1);
  assert.equal(await d.rolle(), 'admin');
  x = await d.rolleAktualisieren(false);
  assert.deepEqual(x, { rolle: 'admin', geaendert: false }); assert.equal(aufrufe, 1, 'innerhalb von 12 Stunden kein neuer Aufruf');
  rolle = null;
  d.uhrStellen(13 * 60 * 60 * 1000);
  x = await d.rolleAktualisieren(false);
  assert.deepEqual(x, { rolle: null, geaendert: true }); assert.equal(aufrufe, 2, 'nach 12 Stunden wird wieder gefragt');
  rolle = 'admin';
  x = await d.rolleAktualisieren(true);
  assert.deepEqual(x, { rolle: 'admin', geaendert: true }); assert.equal(aufrufe, 3);
  rolle = null; await d.rolleAktualisieren(true);
  assert.equal(await d.rolle(), null);
  rolle = 'entwickler'; await d.rolleAktualisieren(true);
  assert.equal(await d.rolle(), 'entwickler');
  await d.rcSchreiben({ kontoToken: null, kontoEmail: null });
  assert.equal(await d.rolle(), null, 'abgemeldet: Rolle verborgen');
});

test('Version 2.0.95 überall gleich, Neu im Programm nennt den Menü-Umbau', () => {
  require('../js/version.js'); require('../js/texte.js');
  const MM = globalThis.MM;
  assert.equal(MM.VERSION, '2.0.107');
  assert.ok(lesen('sw.js').includes("var VERSION = '2.0.107';"));
  assert.equal(JSON.parse(lesen('package.json')).version, '2.0.107');
  assert.ok(lesen('README.md').includes('Version 2.0.107'));
  assert.ok(lesen('CHANGELOG.md').startsWith('# Änderungen\n\n## 2.0.107'));
  assert.equal(MM.Texte.NEUERUNGEN[32].version, '2.0.73');
  const text = MM.Texte.NEUERUNGEN[32].punkte.join(' ');
  ['Verleih', 'Kontrollpapiere', 'Nur für Entwickler', 'Rollen-Tabelle'].forEach((w) => assert.ok(text.includes(w), w));
  assert.ok(lesen('docs/SCHRITTE.md').includes('2.0.73'));
});
