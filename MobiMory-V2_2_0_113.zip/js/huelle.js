/*
 * Android-Hülle (seit 2.0.110): Die App läuft im Browser wie bisher oder, zusätzlich, in einer Android-App (Capacitor).
 * In der Hülle liefert ein Dauerdienst die GPS-Punkte (Plugin @capacitor-community/background-geolocation), auch wenn die App
 * im Hintergrund ist oder der Bildschirm gesperrt wird. Android zeigt dazu eine Dauer-Benachrichtigung.
 *
 * Hier steht nur die Erkennung der Hülle und die Verwaltung des Dauerdienstes. Im Browser tut dieses Modul nichts:
 * istHuelle() ist dort falsch, und die App benutzt weiter navigator.geolocation.
 * Die Umgebung (window mit Capacitor) wird übergeben, damit sich alles testen lässt.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var TITEL = 'MobiMory zeichnet auf';
  var MELDUNG = 'Position und Kilometer werden aufgezeichnet, solange das Cockpit offen ist.';

  function erzeugen(umgebung) {
    var cap = umgebung && umgebung.Capacitor;
    var plug = null, geholt = false;
    var kennung = null, laeuft = false, startNr = 0;

    function istHuelle() {
      try { return !!(cap && typeof cap.isNativePlatform === 'function' && cap.isNativePlatform()); } catch (e) { return false; }
    }
    /* Das Plugin wird einmal geholt. Im Browser und ohne Plugin ist es null. */
    function plugin() {
      if (geholt) return plug;
      geholt = true;
      if (!istHuelle()) return null;
      try {
        if (typeof cap.registerPlugin === 'function') plug = cap.registerPlugin('BackgroundGeolocation');
        else if (cap.Plugins && cap.Plugins.BackgroundGeolocation) plug = cap.Plugins.BackgroundGeolocation;
      } catch (e) {
        plug = (cap.Plugins && cap.Plugins.BackgroundGeolocation) || null;
      }
      return plug;
    }
    function verfuegbar() { var p = plugin(); return !!(p && typeof p.addWatcher === 'function'); }

    /* Ein Punkt des Dienstes in die Form, die die App kennt (wie bei navigator.geolocation, aber flach). */
    function punkt(l) {
      if (!l || typeof l.latitude !== 'number' || typeof l.longitude !== 'number') return null;
      return {
        breite: l.latitude, laenge: l.longitude,
        genauigkeit: typeof l.accuracy === 'number' ? l.accuracy : null,
        geschwindigkeit: typeof l.speed === 'number' && isFinite(l.speed) && l.speed >= 0 ? l.speed : null,
        zeitMs: typeof l.time === 'number' && isFinite(l.time) ? l.time : null
      };
    }
    function verweigert(err) { return !!(err && err.code === 'NOT_AUTHORIZED'); }

    /* Startet den Dauerdienst. beiPunkt(punkt), beiFehler({ verweigert: bool }). Gibt eine Zusage zurück, die bei fehlendem Plugin
       oder verweigerter Erlaubnis abgelehnt wird (dann ist beiFehler schon aufgerufen). Zweimal starten tut nichts. */
    function starten(beiPunkt, beiFehler) {
      var p = plugin();
      if (!p || typeof p.addWatcher !== 'function') return Promise.reject(new Error('kein Dauerdienst'));
      if (laeuft) return Promise.resolve(kennung);
      laeuft = true; var nr = ++startNr;
      var zusage;
      try {
        zusage = Promise.resolve(p.addWatcher({
          backgroundTitle: TITEL, backgroundMessage: MELDUNG,
          requestPermissions: true, stale: false, distanceFilter: 0
        }, function (ort, err) {
          if (nr !== startNr) return;
          if (err) { beiFehler({ verweigert: verweigert(err) }); return; }
          var pt = punkt(ort);
          if (pt) beiPunkt(pt);
        }));
      } catch (e) { zusage = Promise.reject(e); }
      return zusage.then(function (id) {
        /* Wurde inzwischen gestoppt, wird der Dienst gleich wieder beendet. */
        if (nr !== startNr || !laeuft) { try { p.removeWatcher({ id: id }); } catch (e) { /* nichts zu tun */ } return null; }
        kennung = id; return id;
      }, function (err) {
        if (nr === startNr) { laeuft = false; kennung = null; }
        beiFehler({ verweigert: verweigert(err) });
        throw err;
      });
    }

    function stoppen() {
      var p = plugin(), id = kennung;
      laeuft = false; kennung = null; startNr++;
      if (p && id !== null && typeof p.removeWatcher === 'function') {
        try { var z = p.removeWatcher({ id: id }); if (z && typeof z.catch === 'function') z.catch(function () { /* nichts zu tun */ }); } catch (e) { /* nichts zu tun */ }
      }
    }

    /* Öffnet die Android-Einstellungen der App (wenn der Standort verweigert wurde). */
    function einstellungen() {
      var p = plugin();
      if (p && typeof p.openSettings === 'function') { try { p.openSettings(); } catch (e) { /* nichts zu tun */ } return true; }
      return false;
    }

    return { istHuelle: istHuelle, verfuegbar: verfuegbar, punkt: punkt, starten: starten, stoppen: stoppen, einstellungen: einstellungen,
      laeuft: function () { return laeuft; } };
  }

  MM.Huelle = erzeugen(global);
  MM.Huelle.erzeugen = erzeugen;
  MM.Huelle.TITEL = TITEL;
  MM.Huelle.MELDUNG = MELDUNG;
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
