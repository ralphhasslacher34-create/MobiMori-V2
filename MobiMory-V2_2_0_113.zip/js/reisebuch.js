/*
 * Reisebuch (Bau 4, seit 2.0.81): aus einer eigenen Reise (Aktivität) ein Buch machen. Reine Rechnung und Texte, kein Netz, kein Speicher.
 * Das Sammeln der Daten und der Bilder steht in daten.js, die Seite in ansicht.js.
 *
 * Festlegung (Nutzer, 14./15.11.2026): Jeder MobiMory-Nutzer kann aus seinen eigenen Reisen ein Reisebuch erstellen. Ausgabe: Seite in der App
 * und PDF zum Drucken (dazu der Druck der Seite). Inhalt: Daten aus MobiMory (Reise, Tage, Ereignisse, Orte) plus die gespeicherten Fotos.
 * Kosten sind Privatsache und kommen nur auf Wunsch hinein. Das Reisebuch verändert nichts an den Daten und geht nie ins Netz.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Fotos im PDF: höchstens so viele, damit die Datei handlich bleibt. Die Seite zeigt alle. */
  var MAX_BILDER_PDF = 60;
  var STANDARD = { bilder: true, kosten: false, notizen: true };

  function text(x) { return x === null || x === undefined ? '' : String(x).trim(); }
  function datum(d) { return d && MM.Hilfen && MM.Hilfen.datum ? MM.Hilfen.datum(d) : text(d); }
  function zahlText(n) { return MM.Hilfen && MM.Hilfen.zahl ? MM.Hilfen.zahl(n) : String(n); }
  function mitEinheit(n, einheit) { return zahlText(n) + (einheit ? ' ' + einheit : ''); }
  function betrag(n) { return typeof n === 'number' && isFinite(n) ? n.toFixed(2).replace('.', ',') + ' €' : ''; }
  function pluralisiert(n, eins, viele) { return n + ' ' + (n === 1 ? eins : viele); }


  /* ---------- Die Zahlen dieser Reise (seit 2.0.85) ----------
   * Alles wird aus dem gelesen, was in dieser Reise steht (Ereignisse, Tagesabschlüsse, Besuche). Nichts wird geschätzt:
   * Was fehlt, fehlt auch im Buch. Gefahrene Strecke und Zeit stammen aus den Einträgen „Geschwindigkeit (Tagesabschluss)“,
   * die die App selbst beim Tagesabschluss schreibt (GPS-Fahrt). */
  function fmt(n, st) { var f = Math.pow(10, st === undefined ? 1 : st); return String(Math.round(n * f) / f).replace('.', ','); }
  function dauerMin(min) { var h = Math.floor(min / 60), m = Math.round(min - h * 60); if (m === 60) { h++; m = 0; } return h ? h + ' h ' + (m < 10 ? '0' : '') + m + ' min' : m + ' min'; }
  function deZahl(t) { var n = Number(String(t).replace(/\./g, '').replace(',', '.')); return isFinite(n) ? n : null; }
  function mal(n) { return n + '-mal'; }

  /* „Geschwindigkeit (Tagesabschluss): …, Strecke 12,3 km, Fahrzeit 2 h 05 min, …“ -> { wert, einheit, min } oder null */
  function fahrtAusText(t) {
    t = text(t);
    if (!/^Geschwindigkeit \(Tagesabschluss\)/.test(t)) return null;
    var s = /Strecke ([\d.,]+) (km|sm)/.exec(t), z = /Fahrzeit (?:(\d+) h )?(\d+) min/.exec(t);
    if (!s || !z) return null;
    var w = deZahl(s[1]);
    return w === null ? null : { wert: w, einheit: s[2], min: (Number(z[1]) || 0) * 60 + Number(z[2]) };
  }

  var WASSER_STOFFE = ['frischwasser', 'grauwasser', 'schwarzwasser (fäkalien)', 'chemietoilette'];
  function istWasserStoff(t) {
    if (global.MM && MM.Versorgung && MM.Versorgung.istWasserStoff) return MM.Versorgung.istWasserStoff(t);
    return WASSER_STOFFE.indexOf(text(t).toLowerCase()) >= 0;
  }
  function istStoerung(name) { return text(name).toLowerCase() === 'störung'; }

  /* Nächte nach Platzart: je Welt die drei, die der Nutzer genannt hat; weitere Arten nur, wenn es sie gab. */
  var NAECHTE_WASSER = [['hafen', 'Nächte im Hafen'], ['anker', 'Nächte vor Anker'], ['frei', 'Nächte frei liegend']];
  var NAECHTE_LAND = [['camping', 'Nächte auf Campingplatz'], ['stellplatz', 'Nächte auf Stellplatz'], ['frei', 'Nächte frei stehend']];
  var NAECHTE_WEITER = [['hafen', 'Nächte im Hafen'], ['anker', 'Nächte vor Anker'], ['camping', 'Nächte auf Campingplatz'], ['stellplatz', 'Nächte auf Stellplatz'],
    ['parkplatz', 'Nächte auf Parkplatz oder Garage'], ['sonst', 'Nächte an einem sonstigen Ort'], ['ohneArt', 'Nächte an einem Ort ohne Angabe der Art']];

  /*
   * roh: { welt, vonDatum, bisDatum, tage: [{ id, datum, abschlussZiel, abschlussNotiz }], besuche: [{ ortId, datum, zeit }], ortarten: { ortId: Art },
   *        rohEreignisse: [{ id, abschnittId, artName, text, ausgeblendet, tankGebucht, tankArt, menge, kraftstoff, tankName, entsorgungName, verbrauch, einschraenkung, datum, zeit }] }
   * Ergebnis: { jeTag: { tagId: { km|sm, min, text } }, verdichtet: { ereignisId: true }, gesamt: [[Name, Wert]], abschnitte: [{ titel, zeilen, hinweis }], stoerungen: [{ datum, zeit, text }] }
   */
  function zahlenAus(roh) {
    roh = roh || {};
    var ev = (roh.rohEreignisse || []).filter(function (e) { return e && !e.ausgeblendet; });
    var wasser = roh.welt === 'wasser';
    var res = { jeTag: {}, verdichtet: {}, gesamt: [], abschnitte: [], stoerungen: [] };

    /* Gefahrene Strecke und Zeit */
    var summe = { km: 0, sm: 0 }, minGes = 0, hatFahrt = false;
    ev.forEach(function (e) {
      var f = fahrtAusText(e.text);
      if (!f) return;
      hatFahrt = true; res.verdichtet[e.id] = true;
      summe[f.einheit] += f.wert; minGes += f.min;
      var j = res.jeTag[e.abschnittId] = res.jeTag[e.abschnittId] || { km: 0, sm: 0, min: 0 };
      j[f.einheit] += f.wert; j.min += f.min;
    });
    Object.keys(res.jeTag).forEach(function (k) {
      var j = res.jeTag[k], t = [];
      if (j.km > 0) t.push(fmt(j.km) + ' km');
      if (j.sm > 0) t.push(fmt(j.sm) + ' sm');
      res.jeTag[k].text = (t.join(' und ') || '0 ' + (wasser ? 'sm' : 'km')) + ' in ' + dauerMin(j.min);
    });
    if (hatFahrt) {
      var st = [];
      if (summe.km > 0) st.push(fmt(summe.km) + ' km');
      if (summe.sm > 0) st.push(fmt(summe.sm) + ' sm');
      res.gesamt.push(['Gefahrene Strecke', st.join(' und ') || '0 ' + (wasser ? 'sm' : 'km')]);
      res.gesamt.push(['Gefahrene Zeit', dauerMin(minGes)]);
    }

    /* Treibstoff, Ver- und Entsorgung */
    var gruppen = {}, reihenfolge = [], verbrauchsListe = [];
    function gruppe(schluessel, titel, art) {
      if (!gruppen[schluessel]) { gruppen[schluessel] = { titel: titel, art: art, liter: 0, anzahl: 0 }; reihenfolge.push(schluessel); }
      return gruppen[schluessel];
    }
    ev.forEach(function (e) {
      if (!e.tankGebucht) return;
      var art = e.tankArt === 'leer' || e.tankArt === 'flasche' ? e.tankArt : 'auf';
      var stoff = text(e.kraftstoff) || text(e.tankName) || 'Tank';
      var m = typeof e.menge === 'number' ? e.menge : null;
      if (m === 0) return; /* 0 Liter: der Vorgang zählt nicht */
      var w = istWasserStoff(stoff), g;
      if (art === 'flasche') { g = gruppe('f|' + stoff, 'Flasche getauscht: ' + stoff, 'flasche'); g.anzahl++; return; }
      if (art === 'leer') { g = gruppe('l|' + stoff, 'Entleert: ' + stoff, 'leer'); g.anzahl++; if (m) g.liter += m; return; }
      if (m === null) return;
      if (w) g = gruppe('w|' + stoff, 'Aufgefüllt: ' + stoff, 'auf');
      else { g = gruppe('t|' + stoff, 'Getankt: ' + stoff, 'tank'); if (e.verbrauch && typeof e.verbrauch.liter === 'number') verbrauchsListe.push(e.verbrauch); }
      g.anzahl++; g.liter += m;
    });
    var kraft = [], versorgung = [];
    var rang = { tank: 0, auf: 1, leer: 2, flasche: 3 };
    reihenfolge.slice().sort(function (a, b) { return rang[gruppen[a].art] - rang[gruppen[b].art]; }).forEach(function (k) {
      var g = gruppen[k], wert;
      if (g.art === 'tank') wert = fmt(g.liter) + ' l (' + pluralisiert(g.anzahl, 'Tankung', 'Tankungen') + ')';
      else if (g.art === 'auf') wert = fmt(g.liter) + ' l (' + mal(g.anzahl) + ')';
      else if (g.art === 'leer') wert = mal(g.anzahl) + (g.liter > 0 ? ', zusammen ' + fmt(g.liter) + ' l' : '');
      else wert = mal(g.anzahl);
      (g.art === 'tank' ? kraft : versorgung).push([g.titel, wert]);
    });
    if (verbrauchsListe.length && global.MM && MM.Verbrauch && MM.Verbrauch.durchschnitt) {
      var d = MM.Verbrauch.durchschnitt(verbrauchsListe);
      if (d) {
        var v = fmt(d.liter) + ' l in ' + fmt(d.tage) + ' Tagen (' + fmt(d.lProTag, 2) + ' l je Tag';
        if (wasser && d.lProSm) v += ', ' + fmt(d.lProSm, 2) + ' l je sm'; else if (d.lProKm) v += ', ' + fmt(d.lProKm, 2) + ' l je km';
        kraft.push(['Verbrauch, aus dem Füllstand gerechnet', v + ')']);
      }
    }
    var tv = kraft.concat(versorgung);
    if (tv.length) res.abschnitte.push({ titel: 'Treibstoff und Versorgung', zeilen: tv, hinweis: null });

    /* Störungen */
    ev.filter(function (e) { return istStoerung(e.artName); }).sort(function (a, b) { return (a.datum + 'T' + (a.zeit || '')) < (b.datum + 'T' + (b.zeit || '')) ? -1 : 1; }).forEach(function (e) {
      res.stoerungen.push({ datum: text(e.datum), zeit: text(e.zeit), text: text(e.text), einschraenkung: text(e.einschraenkung) });
    });
    res.gesamt.push(['Störungen', res.stoerungen.length ? String(res.stoerungen.length) : 'keine']);

    /* Nächte nach Platzart */
    var tage = roh.tage || [];
    var eintaegig = !roh.bisDatum || roh.bisDatum === roh.vonDatum;
    var arten = roh.ortarten || {}, zaehl = {}, ohne = 0, nSumme = 0;
    if (!eintaegig) tage.forEach(function (t, i) {
      var letzte = null;
      (roh.besuche || []).forEach(function (b) { if (b.ortId && b.datum === t.datum && (!letzte || text(b.zeit) >= text(letzte.zeit))) letzte = b; });
      var key;
      if (letzte) { key = arten[letzte.ortId] || 'ohneArt'; if (key === 'heimat') return; }
      else if (text(t.abschlussZiel) || text(t.abschlussNotiz)) key = 'frei';
      else { if (i < tage.length - 1) ohne++; return; }
      zaehl[key] = (zaehl[key] || 0) + 1; nSumme++;
    });
    if (!eintaegig) {
      var haupt = wasser ? NAECHTE_WASSER : NAECHTE_LAND, gezeigt = {}, nz = [];
      haupt.forEach(function (x) { gezeigt[x[0]] = true; nz.push([x[1], String(zaehl[x[0]] || 0)]); });
      NAECHTE_WEITER.forEach(function (x) { if (!gezeigt[x[0]] && zaehl[x[0]]) nz.push([x[1], String(zaehl[x[0]])]); });
      if (ohne) nz.push(['Tage ohne Angabe', String(ohne)]);
      res.abschnitte.push({ titel: 'Übernachtungen', zeilen: nz, hinweis: TEXT_NAECHTE });
      res.gesamt.push(['Nächte mit Platz', String(nSumme)]);
    }
    return res;
  }
  var TEXT_NAECHTE = 'Der Platz einer Nacht ist der Ort, an dem du am Tag zuletzt angekommen bist. Als „frei“ zählt ein Tag mit Tagesabschluss, aber ohne bekannten Ort. „Tage ohne Angabe“ haben weder einen Ort noch einen Tagesabschluss. Zu Hause zählt nicht.';

  /* ---------- Auswahl (seit 2.0.106) ----------
   * Die Auswahl wird nach der Reise getroffen, nicht vorher. Aus derselben Reise können mehrere Ausgaben entstehen: ein Reisetagebuch für jedermann,
   * ein vollständiges Logbuch für sich selbst oder einen Richter, oder etwas dazwischen. Titelseite und Seitenzahlen gehören immer dazu (nicht abwählbar).
   * Jeder Schalter hat einen Standard; die Standardwerte der ersten drei (bilder, kosten, notizen) sind die von früher. */
  var SCHALTER = [
    { gruppe: 'Die Reise', key: 'steckbrief', label: 'Angaben zur Reise', hilfe: 'Zeitraum, Fahrzeug, Art, Route, Gebiet, Besatzung, Tiere.', standard: true },
    { gruppe: 'Die Reise', key: 'zahlen', label: 'Zahlen der Reise', hilfe: 'Strecke, Zeit, Treibstoff, Versorgung, Übernachtungen.', standard: true },
    { gruppe: 'Die Reise', key: 'ruderzeiten', label: 'Zeiten am Ruder je Person', hilfe: 'Nur bei Wasserfahrzeugen.', standard: false },
    { gruppe: 'Die Reise', key: 'motorzeiten', label: 'Motorlaufzeiten', hilfe: 'Wie lange die Motoren in dieser Reise liefen.', standard: false },
    { gruppe: 'Die Reise', key: 'stoerungen', label: 'Störungen', hilfe: null, standard: true },
    { gruppe: 'Die Reise', key: 'orte', label: 'Besuchte Orte', hilfe: null, standard: true },
    { gruppe: 'Tag für Tag', key: 'tage', label: 'Die Tage der Reise', hilfe: null, standard: true },
    { gruppe: 'Tag für Tag', key: 'tagKopf', label: 'Strecke, Zeit, Wetter und Skipper je Tag', hilfe: null, standard: true },
    { gruppe: 'Tag für Tag', key: 'tagestexte', label: 'Texte aus dem Tagesabschluss', hilfe: 'Notiz zum Tag und Tagesabschluss.', standard: true },
    { gruppe: 'Tag für Tag', key: 'eintraege', label: 'Einträge des Tages', hilfe: null, standard: true },
    { gruppe: 'Tag für Tag', key: 'nurMitInhalt', label: 'Nur Einträge mit Foto oder Text', hilfe: 'Lässt reine Zeitmarken wie „Abfahrt“ ohne Text weg.', standard: false },
    { gruppe: 'Tag für Tag', key: 'alleEintraege', label: 'Jeder Eintrag einzeln, auch die automatischen', hilfe: 'Auch Geschwindigkeit, Wetter, Wechsel der Verantwortung und Rudergängerwechsel. Ohne Auslassung.', standard: false },
    { gruppe: 'Karten', key: 'uebersichtskarte', label: 'Übersichtskarte der Reise', hilfe: 'Die ganze Reise auf einer Karte: Route, gefahrener Weg und Ereignisse mit Position, als Bild.', standard: false },
    { gruppe: 'Karten', key: 'tageskarten', label: 'Karte je Tag', hilfe: 'Zu jedem Tag eine Karte mit dem Weg und den Ereignissen dieses Tages. Welche Ereignisarten erscheinen, stellst du auf der Kartenseite unter „Ereignisse“ ein.', standard: false },
    { gruppe: 'Einträge', key: 'bilder', label: 'Mit Fotos', hilfe: null, standard: true },
    { gruppe: 'Einträge', key: 'notizen', label: 'Mit Notizen und Texten', hilfe: null, standard: true },
    { gruppe: 'Einträge', key: 'datumJeEintrag', label: 'Datum bei jedem Eintrag', hilfe: null, standard: false },
    { gruppe: 'Einträge', key: 'position', label: 'Position bei jedem Eintrag', hilfe: 'Wo die App eine Position hat.', standard: false },
    { gruppe: 'Einträge', key: 'herkunft', label: 'Quelle und Herkunft bei jedem Eintrag', hilfe: 'Von wem der Eintrag kommt (Nutzer, App, Dienst, Fahrzeug) und woher Datum, Uhrzeit und Position stammen. Mit Hinweis auf nachträglich geänderte und nachgetragene Einträge.', standard: false },
    { gruppe: 'Weiteres', key: 'kosten', label: 'Mit Kosten', hilfe: null, standard: false },
    { gruppe: 'Weiteres', key: 'druckDatum', label: 'Datum des Ausdrucks', hilfe: 'Steht auf der Titelseite und auf jeder Seite.', standard: false }
  ];

  /* Fertige Zusammenstellungen als Startpunkt. Der Nutzer ändert danach alles und kann eine eigene mit Namen speichern. */
  function vorlageWerte(aus) {
    var o = {};
    SCHALTER.forEach(function (x) { o[x.key] = typeof aus[x.key] === 'boolean' ? aus[x.key] : x.standard; });
    return o;
  }
  var VORLAGEN = [
    { id: 'tagebuch', name: 'Reisetagebuch', text: 'Für jedermann: Bilder und die Texte aus dem Tagesabschluss.',
      optionen: vorlageWerte({ steckbrief: true, zahlen: false, stoerungen: false, orte: true, tage: true, tagKopf: false, tagestexte: true, eintraege: true, nurMitInhalt: true, bilder: true, notizen: true, uebersichtskarte: true, tageskarten: true }) },
    { id: 'logbuch', name: 'Vollständiges Logbuch', text: 'Für dich selbst oder einen Richter: jeder Schritt der Reise, jeder Eintrag mit Datum, Uhrzeit, Position und Herkunft, dazu Motorlaufzeiten, Wetter und Störungen. Ohne Auslassung.',
      optionen: vorlageWerte({ steckbrief: true, zahlen: true, ruderzeiten: true, motorzeiten: true, stoerungen: true, orte: true, tage: true, tagKopf: true, tagestexte: true, eintraege: true, nurMitInhalt: false, alleEintraege: true,
        bilder: false, notizen: true, datumJeEintrag: true, position: true, herkunft: true, kosten: false, druckDatum: true, uebersichtskarte: true, tageskarten: true }) },
    { id: 'zahlen', name: 'Nur Zahlen der Reise', text: 'Angaben zur Reise und die Zahlen, ohne Tage.',
      optionen: vorlageWerte({ steckbrief: true, zahlen: true, stoerungen: true, orte: false, tage: false, bilder: false }) },
    { id: 'tagesabschluesse', name: 'Tagesabschlüsse ohne Bilder', text: 'Je Tag die Texte aus dem Tagesabschluss, ohne Einträge und ohne Bilder.',
      optionen: vorlageWerte({ steckbrief: true, zahlen: false, stoerungen: false, orte: false, tage: true, tagKopf: false, tagestexte: true, eintraege: false, bilder: false, notizen: true }) }
  ];
  function vorlage(id) { return VORLAGEN.filter(function (v) { return v.id === id; })[0] || null; }

  function optionen(roh) {
    var o = Object.assign({}, STANDARD);
    SCHALTER.forEach(function (x) { if (!(x.key in o)) o[x.key] = x.standard; });
    if (roh && typeof roh === 'object') {
      Object.keys(o).forEach(function (k) { if (typeof roh[k] === 'boolean') o[k] = roh[k]; });
      /* Die Texte des Tagesabschlusses folgen „Mit Notizen und Texten“, solange nichts anderes gewählt ist (so war es bis 2.0.105). */
      if (typeof roh.tagestexte !== 'boolean') o.tagestexte = o.notizen;
    }
    return o;
  }

  /* Gespeicherte Zusammenstellungen (Dokument „reisebuchvorlagen“ in „einstellungen“). Gilt für jede Reise: Man kann sie bei einer anderen Reise wieder ausgeben. */
  var MAX_NAME = 60, MAX_ZUSAMMENSTELLUNGEN = 30;
  function zusammenstellungNeu(dok, name, opt, jetzt, neueId) {
    var n = text(name).replace(/\s+/g, ' ');
    if (!n) return { ok: false, fehler: 'Bitte gib der Zusammenstellung einen Namen.' };
    if (n.length > MAX_NAME) return { ok: false, fehler: 'Der Name darf höchstens ' + MAX_NAME + ' Zeichen haben.' };
    var liste = ((dok && dok.vorlagen) || []).map(function (v) { return Object.assign({}, v); });
    var gleich = liste.filter(function (v) { return v.name.toLowerCase() === n.toLowerCase(); })[0];
    var werte = optionen(opt);
    if (gleich) { gleich.optionen = werte; gleich.geaendertAm = jetzt; }
    else {
      if (liste.length >= MAX_ZUSAMMENSTELLUNGEN) return { ok: false, fehler: 'Es sind schon ' + MAX_ZUSAMMENSTELLUNGEN + ' Zusammenstellungen gespeichert. Lösche zuerst eine.' };
      gleich = { id: neueId(), name: n, optionen: werte, erstelltAm: jetzt };
      liste.push(gleich);
    }
    return { ok: true, id: gleich.id, dokument: { id: 'reisebuchvorlagen', vorlagen: liste } };
  }
  function zusammenstellungenListe(dok) {
    return ((dok && dok.vorlagen) || []).map(function (v) { return { id: v.id, name: v.name, optionen: optionen(v.optionen) }; })
      .sort(function (a, b) { return a.name.localeCompare(b.name, 'de'); });
  }

  /* Wie viele Tage (inklusive) von bis. */
  function tageZwischen(von, bis) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text(von)) || !/^\d{4}-\d{2}-\d{2}$/.test(text(bis))) return null;
    var a = Date.parse(von + 'T00:00:00Z'), b = Date.parse(bis + 'T00:00:00Z');
    return isNaN(a) || isNaN(b) || b < a ? null : Math.round((b - a) / 86400000) + 1;
  }

  /*
   * Das Buch aus den gesammelten Angaben (siehe Daten.reisebuchLaden). Nichts Ausgeblendetes kommt hinein.
   * Ergebnis: { titel, untertitel, steckbrief: [[Name, Wert]], zahlen: [[Name, Wert]], tage: [{ nr, kopf, zeilen, notiz, ereignisse: [{ id, zeit, art, text, ort, bildId }] }],
   *             besuche: [{ ort, datum, notiz }], kosten: { zeilen } oder null, bildIds: [Ereignis-IDs mit Foto], optionen }
   */
  /* Datum und Uhrzeit eines Eintrags für die Ausgabe: nur die Uhrzeit, oder mit Datum (vollständiges Logbuch). */
  function eintragWann(e, mitDatum) {
    var z = text(e.zeit);
    if (!mitDatum) return z;
    var d = text(e.datum) ? datum(e.datum) : '';
    return d && z ? d + ', ' + z + ' Uhr' : (d || (z ? z + ' Uhr' : ''));
  }
  /* Die Zeile mit Position und Herkunft eines Eintrags (leer, wenn beides nicht gewählt ist). */
  function eintragZusatz(e, o) {
    var t = [];
    if (o.position && typeof e.breite === 'number' && typeof e.laenge === 'number' && MM.Logbuch) t.push('Position ' + MM.Logbuch.positionText(e.breite, e.laenge));
    if (o.herkunft && MM.Logbuch) {
      t.push(MM.Logbuch.herkunftKurz({ quelle: e.quelle, quelleName: e.quelleName, zeitHerkunft: e.zeitHerkunft, breite: e.breite, laenge: e.laenge, positionQuelle: e.positionQuelle }));
      if (e.nachgetragen) t.push('nachgetragen' + (e.nachgetragenAm ? ' am ' + datum(String(e.nachgetragenAm).slice(0, 10)) + ', ' + String(e.nachgetragenAm).slice(11, 16) + ' Uhr' : ''));
      if (e.geaendert) t.push('nachträglich geändert (der frühere Stand steht in MobiMory im Verlauf)');
    }
    return t.join(' · ');
  }
  /* „2 h 05 min“ für die Zeit am Ruder und die Motorlaufzeiten (Minuten) */
  function dauerZeile(min, n, wort) { return dauerMin(min) + (n ? ', ' + pluralisiert(n, wort[0], wort[1]) : ''); }

  function bauen(roh, opt, ctx) {
    roh = roh || {};
    ctx = ctx || {};
    var o = optionen(opt);
    var zz = zahlenAus(roh);
    var tage = (roh.tage || []).map(function (t, i) {
      var zeilen = [];
      var weg = [text(t.start), text(t.ziel)].filter(Boolean).join(' → ') || [text(t.von), text(t.nach)].filter(Boolean).join(' → ');
      if (weg) zeilen.push(['Strecke', weg]);
      if (typeof t.strecke === 'number' && t.strecke > 0) zeilen.push(['Geplante Entfernung', mitEinheit(t.strecke, roh.einheit || 'km')]);
      if (zz.jeTag[t.id]) zeilen.push(['Gefahren', zz.jeTag[t.id].text]);
      if (t.beginn || t.ende) zeilen.push(['Zeit', [text(t.beginn), text(t.ende)].filter(Boolean).join(' bis ')]);
      if (text(t.verantwortlicher)) zeilen.push([roh.welt === 'wasser' ? 'Skipper' : 'Am Steuer', text(t.verantwortlicher)]);
      if (text(t.wetter)) zeilen.push(['Wetter', text(t.wetter)]);
      if (text(t.abschlussZiel)) zeilen.push(['Tatsächliches Ziel', text(t.abschlussZiel)]);
      if (!o.tagKopf) zeilen = o.tagestexte ? zeilen.filter(function (z) { return z[0] === 'Tatsächliches Ziel'; }) : [];
      /* Einträge: sonst nur die vom Nutzer, ohne die verdichteten Tageswerte; „jeder Eintrag einzeln“ nimmt alles mit, auch Wechsel (seit 2.0.106). */
      var ereignisse = !o.eintraege ? [] : (t.ereignisse || []).filter(function (e) {
        if (e.ausgeblendet) return false;
        if (o.alleEintraege) return true;
        if (MM.Logbuch && MM.Logbuch.istSchalterArt && MM.Logbuch.istSchalterArt(e.art)) return false;
        return (!e.kind || e.kind === 'ereignis') && !zz.verdichtet[e.id];
      }).filter(function (e) {
        return !o.nurMitInhalt || !!(text(e.text) || e.hatFoto);
      }).map(function (e) {
        return { id: e.id, zeit: text(e.zeit), art: text(e.art) || 'Ereignis', text: o.notizen ? text(e.text) : '', ort: text(e.ort), bildId: o.bilder && e.hatFoto ? e.id : null, nachgetragen: !!e.nachgetragen,
          wann: eintragWann(e, o.datumJeEintrag), zusatz: eintragZusatz(e, o) };
      });
      return { nr: i + 1, tagId: t.id, karte: !!o.tageskarten, datum: t.datum, kopf: 'Tag ' + (i + 1) + ', ' + datum(t.datum), zeilen: zeilen, notiz: o.tagestexte ? text(t.notiz) : '', abschluss: o.tagestexte ? text(t.abschlussNotiz) : '', ereignisse: ereignisse };
    });

    /* Die Zahl der Ereignisse zählt die Einträge des Nutzers, unabhängig davon, was die Ausgabe zeigt. */
    var ereignisAnzahl = 0, fotoAnzahl = 0, bildIds = [];
    (roh.tage || []).forEach(function (t) { (t.ereignisse || []).forEach(function (e) { if (!e.ausgeblendet && (!e.kind || e.kind === 'ereignis') && !zz.verdichtet[e.id] && !(MM.Logbuch && MM.Logbuch.istSchalterArt && MM.Logbuch.istSchalterArt(e.art))) ereignisAnzahl++; }); });
    if (o.tage) tage.forEach(function (t) { t.ereignisse.forEach(function (e) { if (e.bildId) { fotoAnzahl++; bildIds.push(e.bildId); } }); });
    /* Auch ohne Bilder in der Ausgabe zählt die Zahl der Fotos der Reise. */
    var fotosGesamt = 0;
    (roh.tage || []).forEach(function (t) { (t.ereignisse || []).forEach(function (e) { if (!e.ausgeblendet && e.hatFoto) fotosGesamt++; }); });

    var steck = [];
    var zeitraum = roh.vonDatum && roh.bisDatum ? (roh.vonDatum === roh.bisDatum ? datum(roh.vonDatum) : datum(roh.vonDatum) + ' bis ' + datum(roh.bisDatum)) : '';
    if (zeitraum) steck.push(['Zeitraum', zeitraum]);
    if (roh.fahrzeug && text(roh.fahrzeug.name)) steck.push(['Fahrzeug', text(roh.fahrzeug.name) + (text(roh.fahrzeug.artName) ? ' (' + text(roh.fahrzeug.artName) + ')' : '')]);
    if (text(roh.art)) steck.push(['Art der Reise', text(roh.art)]);
    var route = [text(roh.start)].concat((roh.zwischenziele || []).map(text), [text(roh.ziel)]).filter(Boolean);
    if (route.length) steck.push(['Route', route.join(' → ')]);
    if (text(roh.gebiet)) steck.push(['Gebiet', text(roh.gebiet)]);
    if ((roh.besatzung || []).length) steck.push(['Besatzung', roh.besatzung.map(function (b) { return text(b.name) + (text(b.rolle) ? ' (' + text(b.rolle) + ')' : ''); }).join(', ')]);
    if ((roh.tiere || []).length) steck.push(['Tiere', roh.tiere.map(text).join(', ')]);
    if (o.notizen && text(roh.notiz)) steck.push(['Notiz', text(roh.notiz)]);

    var zahlen = [];
    var dauer = tageZwischen(roh.vonDatum, roh.bisDatum);
    if (dauer) zahlen.push(['Reisetage', String(dauer)]);
    zahlen.push(['Tage im Logbuch', String(tage.length)]);
    zahlen.push(['Ereignisse', String(ereignisAnzahl)]);
    if (fotosGesamt) zahlen.push(['Fotos', String(fotosGesamt)]);
    if (typeof roh.streckeSumme === 'number' && roh.streckeSumme > 0) zahlen.push(['Geplante Strecke', mitEinheit(roh.streckeSumme, roh.einheit || 'km')]);
    var besuche = (roh.besuche || []).map(function (b) { return { ort: text(b.ort) || 'Ort', datum: text(b.datum), notiz: o.notizen ? text(b.notiz) : '' }; });
    if (besuche.length) zahlen.push(['Orte besucht', String(besuche.length)]);
    zz.gesamt.forEach(function (z) { zahlen.push(z); });

    var kosten = null;
    if (o.kosten && roh.kosten && typeof roh.kosten.gesamt === 'number') {
      var kz = [['Gesamt', betrag(roh.kosten.gesamt)]];
      if (typeof roh.kosten.fahrzeug === 'number' && roh.kosten.fahrzeug) kz.push(['Rund ums Fahrzeug', betrag(roh.kosten.fahrzeug)]);
      if (typeof roh.kosten.reisekasse === 'number' && roh.kosten.reisekasse) kz.push(['Reisekasse', betrag(roh.kosten.reisekasse)]);
      if (typeof roh.kosten.proPerson === 'number') kz.push(['Je Person', betrag(roh.kosten.proPerson)]);
      if (typeof roh.kosten.proTag === 'number') kz.push(['Je Tag', betrag(roh.kosten.proTag)]);
      kosten = { zeilen: kz };
    }

    /* Zeiten am Ruder je Person (nur Wasser) und Motorlaufzeiten: aus dem, was in der Reise steht (seit 2.0.106) */
    var ruder = null, motoren = null;
    if (o.ruderzeiten && roh.welt === 'wasser' && (roh.ruderzeiten || []).length) {
      ruder = { zeilen: roh.ruderzeiten.map(function (r) { return [text(r.name), dauerZeile(r.minuten, r.abschnitte, ['Abschnitt', 'Abschnitte'])]; }),
        hinweis: 'Der Skipper steht am Anfang am Ruder. Danach gelten die Rudergängerwechsel. Die Zeit zählt bis zum Ende der Reise, bei einer laufenden Reise bis jetzt.' };
    }
    if (o.motorzeiten && (roh.motorzeiten || []).length) {
      motoren = { zeilen: roh.motorzeiten.map(function (m) { return [text(m.name), dauerZeile(m.minuten, m.laeufe, ['Lauf', 'Läufe'])]; }),
        hinweis: 'Gezählt werden die Läufe des Motorschalters innerhalb der Reise.' };
    }
    var druck = '';
    if (o.druckDatum && ctx.datum) druck = 'Ausgedruckt am ' + datum(String(ctx.datum).slice(0, 10)) + ', ' + String(ctx.datum).slice(11, 16) + ' Uhr';

    return {
      titel: text(roh.titel) || 'Reisebuch', untertitel: zeitraum, steckbrief: o.steckbrief ? steck : [], zahlen: o.zahlen ? zahlen : [], tage: o.tage ? tage : [], uebersichtskarte: !!o.uebersichtskarte, besuche: o.orte ? besuche : [], kosten: kosten,
      bildIds: bildIds, optionen: o, fotosGesamt: fotosGesamt, abschnitte: o.zahlen ? zz.abschnitte : [], stoerungen: o.stoerungen ? zz.stoerungen : [], welt: roh.welt || '', fahrzeugName: roh.fahrzeug ? text(roh.fahrzeug.name) : '',
      ruder: ruder, motoren: motoren, druckDatum: druck, titelSteckbrief: steck
    };
  }

  /* Die Zeilen unter dem Titel der Titelseite: wer, womit, wohin. */
  function titelZeilen(buch) {
    var z = [];
    (buch.titelSteckbrief || buch.steckbrief || []).forEach(function (x) { if (['Fahrzeug', 'Route', 'Besatzung'].indexOf(x[0]) >= 0) z.push(x); });
    return z;
  }

  /* Dateiname ohne Sonderzeichen. */
  function dateiName(buch, endung) {
    var n = text(buch && buch.titel).replace(/[^A-Za-z0-9ÄÖÜäöüß_-]+/g, '_').replace(/^_+|_+$/g, '') || 'Reise';
    return 'Reisebuch_' + n + (endung || '.pdf');
  }

  /*
   * Das PDF. bilder: { <Ereignis-ID>: Uint8Array mit JPEG } (fehlende oder unlesbare Fotos werden mit einem Hinweis übersprungen).
   * ctx: { fuss, datum }. Gibt { bytes, bilder, ohneBild, zuViele } zurück.
   */
  function pdf(buch, bilder, ctx) {
    ctx = ctx || {};
    bilder = bilder || {};
    /* Titelseite und Seitenzahlen („Seite 3 von 12“) hat jede Ausgabe. Mit „Datum des Ausdrucks“ steht es auch in der Fußzeile jeder Seite (seit 2.0.106). */
    var d = MM.Pdf.neu({ fuss: (ctx.fuss || ('MobiMory · Reisebuch ' + buch.titel)) + (buch.druckDatum ? ' · ' + buch.druckDatum : ''), titel: 'Reisebuch ' + buch.titel, datum: ctx.datum });
    var eingefuegt = 0, ohne = 0, zuViele = 0;
    d.titelseite({ kopf: 'Reisebuch', titel: buch.titel, untertitel: buch.untertitel || '', zeilen: titelZeilen(buch).concat(buch.druckDatum ? [['Ausdruck', buch.druckDatum.replace(/^Ausgedruckt am /, '')]] : []), fuss: 'Erstellt mit MobiMory' + (ctx.datum ? ' am ' + datum(String(ctx.datum).slice(0, 10)) : '') });
    d.titel(buch.titel, buch.untertitel || '');
    if (buch.steckbrief.length) { d.abschnitt('Die Reise'); buch.steckbrief.forEach(function (z) { d.zeile(z[0], z[1]); }); }
    if (buch.zahlen.length) { d.abschnitt('Auf einen Blick'); buch.zahlen.forEach(function (z) { d.zeile(z[0], z[1]); }); }
    /* Karten (seit 2.0.108): als Bild, mit Beschriftung (Datum, Herkunft der Positionen, Quelle der Karte). ctx.karten: { reise, tage: { tagId } } */
    var karten = ctx.karten || { reise: null, tage: {} }, kartenEingefuegt = 0, kartenOhne = 0;
    function karteEinfuegen(k, name) {
      if (k && k.bytes && d.bild(k.bytes, { maxH: 250, unterschrift: name })) { kartenEingefuegt++; if (k.beschriftung) d.absatz(k.beschriftung, { grau: true, groesse: 8 }); }
      else { kartenOhne++; d.absatz('(Keine Karte: keine Route, kein Weg und keine Ereignisse mit Position, oder die Karte lässt sich nicht zeichnen.)', { grau: true, groesse: 8 }); }
    }
    if (buch.uebersichtskarte) { d.abschnitt('Karte der Reise'); karteEinfuegen(karten.reise, 'Karte der Reise'); }
    if (buch.ruder) { d.abschnitt('Zeiten am Ruder'); buch.ruder.zeilen.forEach(function (z) { d.zeile(z[0], z[1]); }); d.absatz(buch.ruder.hinweis, { grau: true, groesse: 8 }); }
    if (buch.motoren) { d.abschnitt('Motorlaufzeiten'); buch.motoren.zeilen.forEach(function (z) { d.zeile(z[0], z[1]); }); d.absatz(buch.motoren.hinweis, { grau: true, groesse: 8 }); }
    (buch.abschnitte || []).forEach(function (a) {
      d.abschnitt(a.titel); a.zeilen.forEach(function (z) { d.zeile(z[0], z[1]); });
      if (a.hinweis) d.absatz(a.hinweis, { grau: true, groesse: 8 });
    });
    if ((buch.stoerungen || []).length) {
      d.abschnitt('Störungen');
      buch.stoerungen.forEach(function (x) { d.absatz((x.datum ? datum(x.datum) + (x.zeit ? ', ' + x.zeit : '') + ': ' : '') + (x.text || 'Störung') + (x.einschraenkung ? ' (' + x.einschraenkung + ')' : ''), { groesse: 10 }); });
    }
    buch.tage.forEach(function (t) {
      d.abschnitt(t.kopf);
      t.zeilen.forEach(function (z) { d.zeile(z[0], z[1]); });
      if (t.karte) karteEinfuegen((karten.tage || {})[t.tagId], 'Karte: ' + t.kopf);
      if (t.notiz) d.absatz(t.notiz, { grau: true });
      if (t.abschluss) d.absatz('Tagesabschluss: ' + t.abschluss, { grau: true });
      if (!t.ereignisse.length && buch.optionen.eintraege) d.absatz('Keine Einträge an diesem Tag.', { grau: true });
      t.ereignisse.forEach(function (e) {
        d.absatz(((e.wann || e.zeit) ? (e.wann || e.zeit) + '  ' : '') + e.art + (e.ort ? ', ' + e.ort : '') + (e.nachgetragen ? ' (nachgetragen)' : '') + (e.text ? ': ' + e.text : ''), { groesse: 10 });
        if (e.zusatz) d.absatz(e.zusatz, { grau: true, groesse: 8 });
        if (e.bildId) {
          if (eingefuegt >= MAX_BILDER_PDF) { zuViele++; return; }
          var b = bilder[e.bildId];
          if (b && d.bild(b, { maxH: 230, unterschrift: e.art + (e.zeit ? ', ' + e.zeit : '') })) eingefuegt++;
          else { ohne++; d.absatz('(Foto liegt nicht auf diesem Gerät oder ist nicht lesbar.)', { grau: true, groesse: 8 }); }
        }
      });
    });
    if (buch.besuche.length) {
      d.abschnitt('Orte');
      d.tabelle([{ titel: 'Datum', breite: 70 }, { titel: 'Ort', breite: 160 }, { titel: 'Notiz', breite: 0 }],
        buch.besuche.map(function (b) { return [b.datum ? datum(b.datum) : '', b.ort, b.notiz]; }));
    }
    if (buch.kosten) { d.abschnitt('Kosten'); buch.kosten.zeilen.forEach(function (z) { d.zeile(z[0], z[1]); }); }
    if (zuViele) d.absatz('Aus Platzgründen sind nicht alle Fotos im PDF. Die Seite in MobiMory zeigt alle (' + zuViele + ' weitere).', { grau: true, groesse: 8 });
    return { bytes: d.bytes(), bilder: eingefuegt, ohneBild: ohne, zuViele: zuViele, karten: kartenEingefuegt, ohneKarte: kartenOhne };
  }

  MM.Reisebuch = {
    STANDARD: STANDARD, SCHALTER: SCHALTER, VORLAGEN: VORLAGEN, vorlage: vorlage, zusammenstellungNeu: zusammenstellungNeu, zusammenstellungenListe: zusammenstellungenListe, MAX_ZUSAMMENSTELLUNGEN: MAX_ZUSAMMENSTELLUNGEN, MAX_BILDER_PDF: MAX_BILDER_PDF, optionen: optionen, bauen: bauen, titelZeilen: titelZeilen, dateiName: dateiName, pdf: pdf, tageZwischen: tageZwischen, pluralisiert: pluralisiert, zahlenAus: zahlenAus, fahrtAusText: fahrtAusText, TEXT_NAECHTE: TEXT_NAECHTE,
    TEXT_EINLEITUNG: 'Aus deiner Reise wird ein Buch: Reise, Tag für Tag, Ereignisse, besuchte Orte und deine Fotos. Du kannst es hier lesen, ausdrucken oder als PDF speichern. MobiMory ändert dabei nichts an deinen Daten und schickt nichts ins Netz.',
    TEXT_KOSTEN: 'Kosten stehen nur im Buch, wenn du es willst. Wer das Buch weitergibt, sieht sonst keine Beträge.',
    TEXT_FOTOS: 'Fotos stehen nur im Buch, wenn sie auf diesem Gerät liegen. Im PDF sind sie verkleinert, damit die Datei handlich bleibt.'
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
