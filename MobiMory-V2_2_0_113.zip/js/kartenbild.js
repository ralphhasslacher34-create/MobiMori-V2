/*
 * Kartenbild (seit 2.0.108): Die Karte einer Reise oder eines Tages als Bild (JPEG), für das Reisetagebuch.
 *
 * Warum ein Bild: Es sieht später auch ohne Internet und nach einem Wechsel der Kartenquelle genauso aus wie am Tag der Reise. Es wird bei der Reise
 * gespeichert (Daten.kartenbildSichern) und im Reisebuch als Seite und im PDF gezeigt.
 *
 * Gezeigt werden: Kartenkacheln (aus dem Gerät, sonst aus dem Netz), bei Wasserfahrzeugen auf Wunsch die Seezeichen, die geplante Route, der gefahrene Weg,
 * Start und Ziel und die Ereignisse mit Position. Die Quelle der Karte steht im Bild (© OpenStreetMap-Mitwirkende, bei Seezeichen auch OpenSeaMap).
 * Fehlt der Kartenhintergrund (kein Netz und keine Offline-Karte für das Gebiet), steht ein Hinweis im Bild. Route und Punkte stimmen trotzdem.
 *
 * Die Rechnung (Ausschnitt, Pixel) steht hier ohne Browser. Das Zeichnen braucht eine Leinwand; sie kommt als Funktion herein, damit es sich testen lässt.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var KACHEL = 256, MAX_ZOOM = 16, MIN_ZOOM = 2, MAX_KACHELN = 40, RAND = 40;

  function weltX(laenge, z) { return (laenge + 180) / 360 * KACHEL * Math.pow(2, z); }
  function weltY(breite, z) {
    var b = Math.max(-85.0511, Math.min(85.0511, breite)) * Math.PI / 180;
    return (1 - Math.log(Math.tan(b) + 1 / Math.cos(b)) / Math.PI) / 2 * KACHEL * Math.pow(2, z);
  }

  /*
   * Der Ausschnitt, der alle Punkte zeigt. punkte: [[breite, laenge]]. Ergebnis: { z, x0, y0, breite, hoehe, kacheln: [{ z, x, y, px, py }] } oder null (keine Punkte).
   * Der Zoom ist der größte, bei dem alles mit Rand ins Bild passt (höchstens 16, bei einem einzelnen Punkt 13), und der die Kachelzahl begrenzt.
   */
  function ausschnitt(punkte, breite, hoehe) {
    var gut = (punkte || []).filter(function (p) { return p && isFinite(p[0]) && isFinite(p[1]) && Math.abs(p[0]) <= 90 && Math.abs(p[1]) <= 180; });
    if (!gut.length) return null;
    for (var z = MAX_ZOOM; z >= MIN_ZOOM; z--) {
      var xs = gut.map(function (p) { return weltX(p[1], z); }), ys = gut.map(function (p) { return weltY(p[0], z); });
      var minX = Math.min.apply(null, xs), maxX = Math.max.apply(null, xs), minY = Math.min.apply(null, ys), maxY = Math.max.apply(null, ys);
      if (maxX - minX > breite - 2 * RAND || maxY - minY > hoehe - 2 * RAND) continue;
      if (gut.length === 1 && z > 13) continue;
      var x0 = (minX + maxX) / 2 - breite / 2, y0 = (minY + maxY) / 2 - hoehe / 2;
      var kacheln = kachelnFuer(z, x0, y0, breite, hoehe);
      if (kacheln.length > MAX_KACHELN) continue;
      return { z: z, x0: x0, y0: y0, breite: breite, hoehe: hoehe, kacheln: kacheln };
    }
    return null;
  }
  function kachelnFuer(z, x0, y0, breite, hoehe) {
    var n = Math.pow(2, z), res = [];
    for (var ty = Math.floor(y0 / KACHEL); ty <= Math.floor((y0 + hoehe) / KACHEL); ty++) {
      for (var tx = Math.floor(x0 / KACHEL); tx <= Math.floor((x0 + breite) / KACHEL); tx++) {
        if (ty < 0 || ty >= n || tx < 0 || tx >= n) continue;
        res.push({ z: z, x: tx, y: ty, px: Math.round(tx * KACHEL - x0), py: Math.round(ty * KACHEL - y0) });
      }
    }
    return res;
  }
  /* Der Bildpunkt zu Breite und Länge. */
  function pixel(a, breite, laenge) { return [weltX(laenge, a.z) - a.x0, weltY(breite, a.z) - a.y0]; }

  function abgekuerzt(text, max) { text = String(text == null ? '' : text); return text.length > max ? text.slice(0, max - 1) + '…' : text; }

  /*
   * opt: {
   *   breite, hoehe (Bild in Pixeln, Standard 1200 mal 800),
   *   route: [[breite, laenge]] oder null, wegStuecke: [[[breite, laenge]]] oder null, planOrte: [{ rolle, breite, laenge }],
   *   marker: [{ breite, laenge, symbol, farbe }], see: Seezeichen zeigen (nur Wasser),
   *   titel: Text oben links oder null,
   *   ablage: Kartenablage (Kacheln aus dem Gerät) oder null, hole(url): Zusage mit Blob oder null (Kachel aus dem Netz),
   *   leinwand(breite, hoehe): { zeichnen: Kontext, nachBytes(qualitaet): Zusage mit Uint8Array (JPEG) oder null },
   *   bildLaden(blob): Zusage mit etwas, das drawImage zeichnen kann, oder null
   * }
   * Ergebnis: { ok: true, bytes, hatHintergrund, kacheln, fehlend, see, quelle } oder { ok: false, grund }
   */
  function erzeugen(opt) {
    opt = opt || {};
    var b = opt.breite || 1200, h = opt.hoehe || 800;
    var alle = [];
    if (opt.route) opt.route.forEach(function (p) { alle.push(p); });
    (opt.wegStuecke || []).forEach(function (s) { s.forEach(function (p) { alle.push(p); }); });
    (opt.planOrte || []).forEach(function (o) { alle.push([o.breite, o.laenge]); });
    (opt.marker || []).forEach(function (m) { alle.push([m.breite, m.laenge]); });
    var a = ausschnitt(alle, b, h);
    if (!a) return Promise.resolve({ ok: false, grund: 'Es gibt keine Punkte, die eine Karte zeigen könnte (keine Route, kein Weg, keine Ereignisse mit Position).' });
    if (typeof opt.leinwand !== 'function') return Promise.resolve({ ok: false, grund: 'Auf diesem Gerät kann kein Kartenbild gezeichnet werden.' });
    var lw = opt.leinwand(b, h);
    if (!lw || !lw.zeichnen) return Promise.resolve({ ok: false, grund: 'Auf diesem Gerät kann kein Kartenbild gezeichnet werden.' });
    var cx = lw.zeichnen;
    var mitSee = !!opt.see && a.z >= MM.Karte.SEE_QUELLE.minZoom;
    var geladen = 0, fehlend = 0, seeGeladen = 0;

    function kachelBlob(url) {
      var lokal = opt.ablage ? opt.ablage.blob(url) : Promise.resolve(null);
      return lokal.then(function (blob) {
        if (blob) return blob;
        return opt.hole ? Promise.resolve(opt.hole(url)).then(function (x) { return x || null; }, function () { return null; }) : null;
      });
    }
    function kachelHolen(k, see) {
      var url = see ? MM.Karte.seeKachelUrl(k.z, k.x, k.y) : MM.Karte.kachelUrl(k.z, k.x, k.y);
      return kachelBlob(url).then(function (blob) {
        if (!blob) return null;
        return Promise.resolve(opt.bildLaden ? opt.bildLaden(blob) : null).then(function (bild) { return bild || null; }, function () { return null; });
      }).then(function (bild) { return { k: k, bild: bild }; });
    }
    /* Kacheln in kleinen Gruppen holen (höchstens vier gleichzeitig). */
    function gruppen(liste, see) {
      var ergebnis = [], i = 0;
      function weiter() {
        if (i >= liste.length) return Promise.resolve();
        var teil = liste.slice(i, i + 4); i += 4;
        return Promise.all(teil.map(function (k) { return kachelHolen(k, see); })).then(function (r) { r.forEach(function (x) { ergebnis.push(x); }); return weiter(); });
      }
      return weiter().then(function () { return ergebnis; });
    }

    return gruppen(a.kacheln, false).then(function (basis) {
      cx.fillStyle = '#e8eef3'; cx.fillRect(0, 0, b, h);
      basis.forEach(function (x) {
        if (x.bild) { cx.drawImage(x.bild, x.k.px, x.k.py, KACHEL, KACHEL); geladen++; } else fehlend++;
      });
      if (!mitSee) return null;
      var seeListe = a.kacheln.filter(function (k) { return k.z <= MM.Karte.SEE_QUELLE.maxZoom; });
      return gruppen(seeListe, true).then(function (see) {
        see.forEach(function (x) { if (x.bild) { cx.drawImage(x.bild, x.k.px, x.k.py, KACHEL, KACHEL); seeGeladen++; } });
      });
    }).then(function () {
      var hatHintergrund = geladen > 0;
      if (!hatHintergrund) {
        cx.fillStyle = '#d9e2ea'; cx.fillRect(0, 0, b, h);
        cx.strokeStyle = '#c3cfd9'; cx.lineWidth = 1;
        for (var gx = 0; gx <= b; gx += 100) { cx.beginPath(); cx.moveTo(gx, 0); cx.lineTo(gx, h); cx.stroke(); }
        for (var gy = 0; gy <= h; gy += 100) { cx.beginPath(); cx.moveTo(0, gy); cx.lineTo(b, gy); cx.stroke(); }
      }
      function linie(punkte, farbe, breite, deckung) {
        if (!punkte || punkte.length < 2) return;
        cx.strokeStyle = farbe; cx.lineWidth = breite; cx.globalAlpha = deckung; cx.lineJoin = 'round'; cx.lineCap = 'round';
        cx.beginPath();
        punkte.forEach(function (p, i) { var q = pixel(a, p[0], p[1]); if (i === 0) cx.moveTo(q[0], q[1]); else cx.lineTo(q[0], q[1]); });
        cx.stroke(); cx.globalAlpha = 1;
      }
      linie(opt.route, '#1d5fbf', 5, 0.75);
      (opt.wegStuecke || []).forEach(function (s) { linie(s, '#e07b00', 4, 0.95); });
      function punkt(breiteGrad, laengeGrad, farbe, symbol, radius) {
        var q = pixel(a, breiteGrad, laengeGrad);
        cx.beginPath(); cx.arc(q[0], q[1], radius, 0, Math.PI * 2);
        cx.fillStyle = farbe; cx.fill(); cx.lineWidth = 3; cx.strokeStyle = '#ffffff'; cx.stroke();
        if (symbol) { cx.fillStyle = '#ffffff'; cx.font = '700 ' + Math.round(radius * 1.1) + 'px sans-serif'; cx.textAlign = 'center'; cx.textBaseline = 'middle'; cx.fillText(symbol, q[0], q[1] + 1); }
      }
      (opt.planOrte || []).forEach(function (o) {
        if (o.rolle === 'start') punkt(o.breite, o.laenge, '#1f8a3b', 'S', 13);
        else if (o.rolle === 'ziel') punkt(o.breite, o.laenge, '#c0262d', 'Z', 13);
      });
      (opt.marker || []).forEach(function (m) { punkt(m.breite, m.laenge, m.farbe || '#5f6b76', m.symbol || '•', 12); });

      /* Quelle und Hinweis im Bild */
      var quelle = '© OpenStreetMap-Mitwirkende' + (mitSee && seeGeladen ? ' · © OpenSeaMap-Mitwirkende' : '');
      cx.fillStyle = 'rgba(255,255,255,0.85)'; cx.fillRect(0, h - 26, b, 26);
      cx.fillStyle = '#212529'; cx.font = '13px sans-serif'; cx.textAlign = 'left'; cx.textBaseline = 'middle';
      cx.fillText((hatHintergrund ? quelle : 'Kartenhintergrund fehlt (kein Internet, keine Offline-Karte für dieses Gebiet). Route und Punkte stimmen trotzdem.'), 10, h - 13);
      cx.textAlign = 'right'; cx.fillText('MobiMory · Informationskarte', b - 10, h - 13);
      if (opt.titel) {
        var t = abgekuerzt(opt.titel, 70);
        cx.font = '700 16px sans-serif';
        var tb = (cx.measureText ? cx.measureText(t).width : t.length * 9) + 20;
        cx.fillStyle = 'rgba(255,255,255,0.88)'; cx.fillRect(0, 0, tb, 32);
        cx.fillStyle = '#212529'; cx.textAlign = 'left'; cx.textBaseline = 'middle'; cx.fillText(t, 10, 16);
      }
      return Promise.resolve(lw.nachBytes ? lw.nachBytes(0.85) : null).then(function (bytes) {
        if (!bytes) return { ok: false, grund: 'Das Kartenbild konnte nicht in eine Datei umgewandelt werden.' };
        return { ok: true, bytes: bytes, hatHintergrund: hatHintergrund, kacheln: geladen, fehlend: fehlend, see: mitSee && seeGeladen > 0, quelle: quelle, breite: b, hoehe: h };
      });
    });
  }

  /* Die Leinwand im Browser (Canvas oder OffscreenCanvas). Ohne Zeichenfläche null. */
  function browserLeinwand(b, h) {
    var g = global, c;
    if (typeof g.OffscreenCanvas === 'function') c = new g.OffscreenCanvas(b, h);
    else if (g.document && g.document.createElement) { c = g.document.createElement('canvas'); c.width = b; c.height = h; }
    else return null;
    var cx = c.getContext('2d');
    if (!cx) return null;
    return { zeichnen: cx, nachBytes: function (q) {
      var blob = c.convertToBlob ? c.convertToBlob({ type: 'image/jpeg', quality: q }) : new Promise(function (ok) { c.toBlob(ok, 'image/jpeg', q); });
      return Promise.resolve(blob).then(function (jb) { return jb ? jb.arrayBuffer() : null; }).then(function (ab) { return ab ? new Uint8Array(ab) : null; }, function () { return null; });
    } };
  }
  function browserBild(blob) { return typeof global.createImageBitmap === 'function' ? global.createImageBitmap(blob) : Promise.resolve(null); }
  /* Eine Kachel aus dem Netz holen (mit Zeitgrenze). Die Kartenserver erlauben das Lesen aus der App (CORS), sonst bleibt die Kachel leer. */
  function browserHole(url) {
    var f = global.fetch;
    if (typeof f !== 'function') return Promise.resolve(null);
    var ctrl = typeof global.AbortController === 'function' ? new global.AbortController() : null;
    var uhr = ctrl ? global.setTimeout(function () { ctrl.abort(); }, 8000) : null;
    return f(url, { mode: 'cors', credentials: 'omit', signal: ctrl ? ctrl.signal : undefined }).then(function (r) { return r && r.ok ? r.blob() : null; })
      .then(function (blob) { if (uhr) global.clearTimeout(uhr); return blob && blob.size ? blob : null; }, function () { if (uhr) global.clearTimeout(uhr); return null; });
  }

  MM.Kartenbild = {
    ausschnitt: ausschnitt, pixel: pixel, erzeugen: erzeugen, KACHEL: KACHEL, MAX_KACHELN: MAX_KACHELN,
    browser: { leinwand: browserLeinwand, bildLaden: browserBild, hole: browserHole }
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
