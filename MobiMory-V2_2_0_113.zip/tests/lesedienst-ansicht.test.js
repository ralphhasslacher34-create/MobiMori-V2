'use strict';
/* 2.0.98: Die Bildschirme von „Dokument erfassen“ mit dem Lesedienst (nachgebaute Seitenbausteine, kein Browser): Sperre ohne Konto, Hinweis vor jedem Foto,
   Abbrechen sendet nichts, Lesedienst-Weg bis zum Ergebnis, Rückfall aufs Gerät bei Dienstfehler, keine gelernten Stellen beim Lesedienst. */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'texte', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche',
  'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'karte', 'konto', 'erfassung', 'daten', 'erfassung-motor', 'erfassung-ansicht'].forEach((m) => require('../js/' + m + '.js'));
const MM = globalThis.MM;
const JETZT = new Date(2026, 10, 16, 12, 0, 0).toISOString();

function el(tag) {
  const e = { tag, attrs: {}, kinder: [], parentNode: null,
    appendChild(k) { if (k && typeof k === 'object') k.parentNode = e; e.kinder.push(k); return k; },
    insertBefore(k, ref) { k.parentNode = e; const i = e.kinder.indexOf(ref); if (i < 0) e.kinder.push(k); else e.kinder.splice(i, 0, k); return k; },
    removeChild(k) { const i = e.kinder.indexOf(k); if (i >= 0) e.kinder.splice(i, 1); k.parentNode = null; return k; },
    classList: { toggle() {} } };
  Object.defineProperty(e, 'textContent', { get() { return e.kinder.filter((k) => typeof k === 'string').join(''); }, set(v) { e.kinder = v ? [String(v)] : []; } });
  return e;
}
function h(tag, attrs) {
  const e = el(tag);
  if (attrs) Object.keys(attrs).forEach((k) => { const v = attrs[k]; if (v === null || v === undefined || v === false) return; if (k === 'text') e.kinder.push(String(v)); else e.attrs[k] = v; });
  const rein = (k) => { if (k === null || k === undefined) return; if (Array.isArray(k)) k.forEach(rein); else { if (typeof k === 'object') k.parentNode = e; e.kinder.push(k); } };
  for (let i = 2; i < arguments.length; i++) rein(arguments[i]);
  return e;
}
const text = (e) => (typeof e === 'string' ? e : (e && e.kinder ? e.kinder.map(text).join(' ') : ''));
const finde = (e, fn, aus) => { aus = aus || []; if (!e || typeof e === 'string' || !e.kinder) return aus; if (fn(e)) aus.push(e); e.kinder.forEach((k) => finde(k, fn, aus)); return aus; };
const knopf = (wurzel, t) => finde(wurzel, (e) => e.tag === 'button' && text(e) === t)[0];

const stufe = (id, name, scans, genutzt) => ({ ok: true, stufe: { id, name, bis: null }, grenzen: { geraete: 4, checks: 3, routen: 100, fahrzeuge: 3, online: true, scans }, nutzung: { geraete: 1, checks: 0, checksFrei: 3, extra: 0, routen: 0, routenFrei: 100, routenExtra: 0, scans: genutzt, scansFrei: scans === null ? null : Math.max(0, scans - genutzt) }, rolle: null });

async function aufbau(opt) {
  opt = opt || {};
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  d.kontoAnfrageFn = async () => stufe(opt.stufe || 'mittel', 'Mittel', opt.scans === undefined ? 50 : opt.scans, opt.genutzt || 0);
  if (opt.konto !== false) await d.rcSchreiben({ kontoToken: 'tok', kontoEmail: 'a@example.org' });
  if (opt.zustimmung) await d.lesedienstZustimmen();
  const seiten = [];
  const kit = { h, seite: (titel, inhalt, fuss) => { const w = el('seite'); w.titel = titel; w.kinder = [].concat(inhalt, fuss ? [fuss] : []); w.kinder.forEach((k) => { if (k && typeof k === 'object') k.parentNode = w; }); seiten.push(w); },
    krumen: () => h('nav'), daten: () => d, neuZeichnen: () => {}, melden: () => {} };
  MM.AnsichtKit = kit;
  globalThis.location = { hash: '' };
  return { d, seiten, letzte: () => seiten[seiten.length - 1] };
}
const WORTE = (zeilen) => ({ breite: 600, hoehe: 400, woerter: zeilen.flatMap((z, i) => { let x = 20; return z.split(' ').map((w, j, a) => { const b = w.length * 12; const o = { t: w, v: [x, 20 + i * 40, x + b, 20 + i * 40, x + b, 40 + i * 40, x, 40 + i * 40], k: 90, e: j === a.length - 1 ? 1 : 0 }; x += b + 10; return o; }); }) });
const AUSWEIS = WORTE(['BUNDESREPUBLIK DEUTSCHLAND PERSONALAUSWEIS', 'IDD<<T220001293<<<<<<<<<<<<<<<', '6408125<2710314D<<<<<<<<<<<<<<<4', 'MUSTERMANN<<ERIKA<<<<<<<<<<<<<<']);

test('Ohne Konto und mit Basic: keine Aufnahme, nur der Hinweis und der Weg zum Konto', async () => {
  const a = await aufbau({ konto: false });
  await MM.ErfassungAnsicht.zeige(['erfassung']);
  let s = a.letzte(), t = text(s);
  assert.match(t, /Smart Capture ist ein Teil der Konten ab Stufe Mittel/); assert.ok(finde(s, (e) => e.tag === 'a' && e.attrs.href === '#/konto').length === 1);
  assert.equal(finde(s, (e) => e.tag === 'input').length, 0); assert.equal(finde(s, (e) => e.tag === 'button').length, 0);
  const b = await aufbau({ stufe: 'basic', scans: 0 });
  await MM.ErfassungAnsicht.zeige(['erfassung']);
  s = b.letzte(); assert.match(text(s), /Stufe Mittel oder Voll/); assert.equal(finde(s, (e) => e.tag === 'input').length, 0);
  await MM.ErfassungAnsicht.zeige(['erfassung', 'weiter']);
  assert.equal(globalThis.location.hash, '#/erfassung', 'die Seite „Weitere Seite“ führt ohne Berechtigung zurück');
});

test('Mittel ohne Zustimmung: Aufnahme geht, liest auf dem Gerät, Zustimmungstext mit Knopf; zustimmen und widerrufen', async () => {
  const a = await aufbau();
  await MM.ErfassungAnsicht.zeige(['erfassung']);
  const s = a.letzte(), t = text(s);
  assert.match(t, /Ohne deine Zustimmung zum Lesedienst liest MobiMory auf dem Gerät/); assert.match(t, /Ich stimme zu, dass Fotos von Dokumenten/);
  assert.ok(finde(s, (e) => e.tag === 'input').length >= 2); assert.ok(knopf(s, 'Ich stimme zu'));
  await new Promise((ok) => { knopf(s, 'Ich stimme zu').attrs.onclick(); setTimeout(ok, 5); });
  assert.equal((await a.d.lesedienstZustimmung()).gilt, true);
  await MM.ErfassungAnsicht.zeige(['erfassung']);
  const s2 = a.letzte(); assert.match(text(s2), /Noch 50 von 50 Scans in diesem Monat frei/); assert.match(text(s2), /Du hast dem Lesedienst am 16\.11\.2026 zugestimmt/); assert.ok(knopf(s2, 'Zustimmung widerrufen'));
  await new Promise((ok) => { knopf(s2, 'Zustimmung widerrufen').attrs.onclick(); setTimeout(ok, 5); });
  assert.equal((await a.d.lesedienstZustimmung()).gilt, false);
});

test('Lesedienst: vor jedem Foto der Hinweis; „Abbrechen“ sendet nichts; „Foto senden“ liest über den Dienst bis zum Ergebnis; gelernte Stellen werden nicht gebraucht', async () => {
  const a = await aufbau({ zustimmung: true, genutzt: 2 });
  const motor = MM.ErfassungMotor, orig = { lesenGoogle: motor.lesenGoogle, lesen: motor.lesen, rechteckLesen: motor.rechteckLesen };
  const aufrufe = { google: 0, geraet: 0, rechteck: 0, gesendet: [] };
  motor.lesenGoogle = async (blob, meld, senden) => {
    aufrufe.google++;
    const r = await senden('QUJD'); aufrufe.gesendet.push(r);
    const g = MM.Erfassung.seitenAusGoogle(AUSWEIS);
    return { seite: g.seite, weitere: g.weitere, reihen: g.weitere[0], bild: new Blob(['x'], { type: 'image/jpeg' }), breite: g.breite, hoehe: g.hoehe, drehung: 0, quelle: 'google', kontingent: { genutzt: 3, grenze: 50 } };
  };
  motor.lesen = async () => { aufrufe.geraet++; throw new Error('Gerät darf hier nicht lesen'); };
  motor.rechteckLesen = async () => { aufrufe.rechteck++; return ''; };
  a.d.kontoAnfrageFn = async (url, methode) => { if (/\/lesen\/senden$/.test(url)) return { ok: true, woerter: [], breite: 1, hoehe: 1 }; return stufe('mittel', 'Mittel', 50, 2); };
  try {
    await MM.ErfassungAnsicht.zeige(['erfassung']);
    const s = a.letzte(), datei = finde(s, (e) => e.tag === 'input' && e.attrs.id === 'er-datei')[0];
    assert.match(text(s), /Noch 48 von 50 Scans/);
    const status = finde(s, (e) => e.tag === 'p' && e.attrs.role === 'status' && !e.kinder.length)[0] || finde(s, (e) => e.tag === 'p' && e.attrs.role === 'status')[0];
    /* 1. Foto: Abbrechen */
    datei.attrs.onchange({ target: { files: [new Blob(['f'])] } });
    await new Promise((ok) => setTimeout(ok, 5));
    let panel = finde(s, (e) => e.attrs && e.attrs.role === 'alertdialog')[0];
    assert.ok(panel, 'Der Hinweis steht auf der Seite'); assert.match(text(panel), /Dieses Foto wird jetzt zum Lesen an Google gesendet und dort nicht gespeichert\. Es zählt als 1 Scan\. Danach sind noch 47 von 50 Scans/);
    assert.ok(knopf(panel, 'Stattdessen auf dem Gerät lesen')); knopf(panel, 'Abbrechen').attrs.onclick();
    await new Promise((ok) => setTimeout(ok, 5));
    assert.equal(aufrufe.google, 0); assert.equal(aufrufe.geraet, 0); assert.equal(finde(s, (e) => e.attrs && e.attrs.role === 'alertdialog').length, 0, 'der Hinweis ist weg');
    assert.match(text(s), /Abgebrochen\. Das Foto wurde nicht gesendet/);
    /* 2. Foto: senden */
    datei.attrs.onchange({ target: { files: [new Blob(['f'])] } });
    await new Promise((ok) => setTimeout(ok, 5));
    panel = finde(s, (e) => e.attrs && e.attrs.role === 'alertdialog')[0];
    knopf(panel, 'Foto senden und lesen').attrs.onclick();
    await new Promise((ok) => setTimeout(ok, 80));
    assert.equal(aufrufe.google, 1); assert.equal(aufrufe.gesendet[0].ok, true); assert.equal(aufrufe.geraet, 0); assert.equal(aufrufe.rechteck, 0);
    assert.equal(globalThis.location.hash, '#/erfassung/ergebnis');
    await MM.ErfassungAnsicht.zeige(['erfassung', 'ergebnis']);
    const erg = a.letzte(), et = text(erg);
    assert.match(et, /Gelesen mit dem Lesedienst \(Google\)\. Das Foto wurde dort nicht gespeichert/); assert.match(et, /Personalausweis/); assert.match(et, /Mustermann|MUSTERMANN/i);
    /* der Zähler der Seite zählt mit: danach noch 47 */
    await MM.ErfassungAnsicht.zeige(['erfassung', 'weiter']);
    assert.ok(a.letzte().titel === 'Weitere Seite');
  } finally { Object.assign(motor, orig); }
});

test('Dienstfehler: Rückfall aufs Gerät mit Hinweis im Ergebnis; abgelaufene Anmeldung stoppt ohne Rückfall', async () => {
  const motor = MM.ErfassungMotor, orig = { lesenGoogle: motor.lesenGoogle, lesen: motor.lesen };
  try {
    const a = await aufbau({ zustimmung: true });
    let geraet = 0;
    motor.lesenGoogle = async (blob, meld, senden) => { const r = await senden('QUJD'); const e = new Error(r.fehler); e.art = r.art; throw e; };
    motor.lesen = async () => { geraet++; const g = MM.Erfassung.seitenAusGoogle(AUSWEIS); return { seite: g.seite, weitere: [], bild: new Blob(['x']), breite: 600, hoehe: 400, drehung: 0 }; };
    let modus = 502;
    a.d.kontoAnfrageFn = async (url) => { if (/\/lesen\/senden$/.test(url)) { const e = new Error(modus === 401 ? 'Anmeldung abgelaufen' : 'Der Lesedienst ist gerade nicht erreichbar.'); e.status = modus; throw e; } return stufe('mittel', 'Mittel', 50, 0); };
    await MM.ErfassungAnsicht.zeige(['erfassung']);
    const s = a.letzte(), datei = finde(s, (e) => e.tag === 'input' && e.attrs.id === 'er-datei')[0];
    datei.attrs.onchange({ target: { files: [new Blob(['f'])] } }); await new Promise((ok) => setTimeout(ok, 5));
    knopf(finde(s, (e) => e.attrs && e.attrs.role === 'alertdialog')[0], 'Foto senden und lesen').attrs.onclick(); await new Promise((ok) => setTimeout(ok, 80));
    assert.equal(geraet, 1); assert.equal(globalThis.location.hash, '#/erfassung/ergebnis');
    await MM.ErfassungAnsicht.zeige(['erfassung', 'ergebnis']);
    assert.match(text(a.letzte()), /Der Lesedienst wurde nicht benutzt: .*Dieses Foto wurde auf dem Gerät gelesen, das ist weniger genau/);
    /* abgelaufene Anmeldung: kein Rückfall, klare Meldung */
    modus = 401; globalThis.location.hash = '';
    await MM.ErfassungAnsicht.zeige(['erfassung']);
    const s2 = a.letzte(), datei2 = finde(s2, (e) => e.tag === 'input' && e.attrs.id === 'er-datei')[0];
    datei2.attrs.onchange({ target: { files: [new Blob(['f'])] } }); await new Promise((ok) => setTimeout(ok, 5));
    knopf(finde(s2, (e) => e.attrs && e.attrs.role === 'alertdialog')[0], 'Foto senden und lesen').attrs.onclick(); await new Promise((ok) => setTimeout(ok, 80));
    assert.equal(geraet, 1, 'kein zweiter Gerätelauf'); assert.equal(globalThis.location.hash, ''); assert.match(text(s2), /Deine Anmeldung ist abgelaufen\. Bitte melde dich unter Konto neu an/);
  } finally { Object.assign(motor, orig); }
});
