'use strict';
/* 2.0.105: Cockpit-Wechsel (Takt, Ansichten, Pause, Speicherung, Einbau ins Cockpit). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'texte', 'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'fahrt', 'reisecheck', 'karte', 'cockpitwechsel', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM, CW = MM.CockpitWechsel;
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

/* ---------- Regeln ---------- */
test('Takt: 10 bis 120 Sekunden in 10er-Schritten, Grundeinstellung 30', () => {
  assert.deepEqual(CW.taktListe(), [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120]);
  assert.equal(CW.TAKT_STANDARD, 30);
  [10, 30, 120, '60'].forEach(x => assert.notEqual(CW.taktGueltig(x), null, String(x)));
  [0, 5, 15, 125, 130, -10, 'x', null, '', 30.5].forEach(x => assert.equal(CW.taktGueltig(x), null, String(x)));
});

test('Grundeinstellung: aus, 30 Sekunden, die Seiten des Cockpits', () => {
  assert.deepEqual(CW.standard(), { an: false, takt: 30, ansichten: ['info', 'knoepfe', 'mehr'] });
  assert.deepEqual(CW.lesen(null), CW.standard());
  assert.deepEqual(CW.lesen({ an: 'ja', takt: 33, ansichten: ['gibtesnicht'] }), CW.standard());
});

test('Ansichten: nur bekannte, jede einmal, in der gewählten Reihenfolge', () => {
  assert.deepEqual(CW.ansichtenGueltig(['karte', 'info', 'karte', 'x', 'ereignisse']), ['karte', 'info', 'ereignisse']);
  assert.deepEqual(CW.ansichtenGueltig(null), []);
  assert.deepEqual(CW.ANSICHTEN.map(a => a.id), ['info', 'knoepfe', 'mehr', 'karte', 'ereignisse']);
  assert.deepEqual(CW.ANSICHTEN.filter(a => a.seite !== null).map(a => a.seite), [0, 1, 2]);
});

test('Nächste Ansicht: am Ende wieder die erste, unbekannte aktuelle gibt die erste', () => {
  const l = ['info', 'karte', 'ereignisse'];
  assert.equal(CW.naechste(l, 'info'), 'karte');
  assert.equal(CW.naechste(l, 'ereignisse'), 'info');
  assert.equal(CW.naechste(l, 'mehr'), 'info');
  assert.equal(CW.naechste([], 'info'), null);
  assert.equal(CW.naechste(['info'], 'info'), 'info');
});

test('Formular: prüft Takt und mindestens eine Ansicht', () => {
  const gut = CW.ausFormular({ an: 'an', takt: '40', platz1: 'karte', platz2: '', platz3: 'info', platz4: 'karte', platz5: '' });
  assert.equal(gut.ok, true);
  assert.deepEqual(gut.einstellung, { an: true, takt: 40, ansichten: ['karte', 'info'] });
  assert.equal(CW.ausFormular({ an: 'aus', takt: '30', platz1: 'info' }).einstellung.an, false);
  const schlecht = CW.ausFormular({ an: 'an', takt: '35', platz1: '' });
  assert.equal(schlecht.ok, false);
  assert.ok(schlecht.fehler.takt && schlecht.fehler.platz1);
});

/* ---------- Steuerung mit nachgebauter Zeit ---------- */
function umgebung() {
  const u = { zeit: 0, aufgaben: [], sichtbar: true, pausiert: false, nr: 0 };
  u.jetzt = () => u.zeit;
  u.setzeZeitgeber = (f, ms) => { const id = ++u.nr; u.aufgaben.push({ id, f, an: u.zeit + ms }); return id; };
  u.loescheZeitgeber = id => { u.aufgaben = u.aufgaben.filter(a => a.id !== id); };
  u.sichtbarFn = () => u.sichtbar;
  u.vor = sek => {
    const ziel = u.zeit + sek * 1000;
    for (;;) {
      u.aufgaben.sort((a, b) => a.an - b.an);
      const a = u.aufgaben[0];
      if (!a || a.an > ziel) break;
      u.aufgaben.shift(); u.zeit = a.an; a.f();
    }
    u.zeit = ziel;
  };
  return u;
}
function bauen(u, gezeigt) {
  return CW.steuerung({ jetzt: u.jetzt, setzeZeitgeber: u.setzeZeitgeber, loescheZeitgeber: u.loescheZeitgeber, sichtbar: () => u.sichtbar, pausiert: () => u.pausiert }, id => gezeigt.push(id));
}
const E = (an, takt, ansichten) => ({ an, takt, ansichten });

test('Steuerung: aus tut nichts', () => {
  const u = umgebung(), g = [], s = bauen(u, g);
  s.starten(E(false, 30, ['info', 'knoepfe']), 'info');
  u.vor(600);
  assert.deepEqual(g, []);
  assert.equal(s.laeuft(), false);
});

test('Steuerung: wechselt im eingestellten Takt der Reihe nach und beginnt wieder vorn', () => {
  const u = umgebung(), g = [], s = bauen(u, g);
  s.starten(E(true, 30, ['info', 'knoepfe', 'mehr']), 'info');
  u.vor(29); assert.deepEqual(g, []);
  u.vor(2); assert.deepEqual(g, ['knoepfe']);
  u.vor(30); u.vor(30);
  assert.deepEqual(g, ['knoepfe', 'mehr', 'info']);
});

test('Steuerung: Takt 10 und 120 Sekunden', () => {
  [10, 120].forEach(t => {
    const u = umgebung(), g = [], s = bauen(u, g);
    s.starten(E(true, t, ['info', 'karte']), 'info');
    u.vor(t - 1); assert.equal(g.length, 0);
    u.vor(2); assert.deepEqual(g, ['karte']);
  });
});

test('Steuerung: Tippen hält den Wechsel an, nach der Ruhezeit läuft er weiter', () => {
  const u = umgebung(), g = [], s = bauen(u, g);
  s.starten(E(true, 30, ['info', 'knoepfe']), 'info');
  u.vor(25); s.eingabe();
  u.vor(40); assert.deepEqual(g, [], 'bei 65 s: erst 40 s seit dem Tippen');
  u.vor(30); assert.deepEqual(g, ['knoepfe'], 'nach 60 s Ruhe geht es weiter');
});

test('Steuerung: eine offene Frage oder ein Formular hält den Wechsel an', () => {
  const u = umgebung(), g = [], s = bauen(u, g);
  s.starten(E(true, 30, ['info', 'knoepfe']), 'info');
  u.pausiert = true; u.vor(300); assert.deepEqual(g, []);
  u.pausiert = false; u.vor(15); assert.deepEqual(g, ['knoepfe']);
});

test('Steuerung: bei verstecktem Dokument (App nicht offen) wird nicht gewechselt', () => {
  const u = umgebung(), g = [], s = bauen(u, g);
  s.starten(E(true, 30, ['info', 'knoepfe']), 'info');
  u.sichtbar = false; u.vor(300); assert.deepEqual(g, []);
  u.sichtbar = true; u.vor(15); assert.deepEqual(g, ['knoepfe']);
});

test('Steuerung: Anhalten stoppt, Neustart merkt sich die Ansicht', () => {
  const u = umgebung(), g = [], s = bauen(u, g);
  s.starten(E(true, 30, ['info', 'knoepfe', 'mehr']), 'info');
  u.vor(31); assert.equal(s.aktuell(), 'knoepfe');
  s.anhalten(); u.vor(300); assert.deepEqual(g, ['knoepfe']);
  const jetzt = s.starten(E(true, 30, ['info', 'knoepfe', 'mehr']), s.aktuell());
  assert.equal(jetzt, 'knoepfe');
  u.vor(31); assert.deepEqual(g, ['knoepfe', 'mehr']);
});

/* ---------- Speicherung je Aktivität ---------- */
async function neu() {
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(2026, 10, 17, 10, 0, 0).toISOString() });
  await d.starten();
  return d;
}
test('Daten: ohne Eintrag gilt die Grundeinstellung, gespeichert gehört sie zur Aktivität', async () => {
  const d = await neu();
  assert.deepEqual(await d.cockpitWechsel('a1'), CW.standard());
  const r = await d.cockpitWechselSetzen('a1', { an: 'an', takt: '50', platz1: 'karte', platz2: 'info', platz3: '', platz4: '', platz5: '' });
  assert.equal(r.ok, true);
  assert.deepEqual(await d.cockpitWechsel('a1'), { an: true, takt: 50, ansichten: ['karte', 'info'] });
  assert.deepEqual(await d.cockpitWechsel('a2'), CW.standard());
});
test('Daten: ungültige Eingabe wird nicht gespeichert', async () => {
  const d = await neu();
  const r = await d.cockpitWechselSetzen('a1', { an: 'an', takt: '7', platz1: '' });
  assert.equal(r.ok, false);
  assert.deepEqual(await d.cockpitWechsel('a1'), CW.standard());
});

/* ---------- Einbau ---------- */
test('Einbau: Skript, Service Worker, Route, Formular und Aufräumen', () => {
  assert.match(lesen('index.html'), /js\/cockpitwechsel\.js/);
  assert.match(lesen('sw.js'), /js\/cockpitwechsel\.js/);
  const a = lesen('js/ansicht.js');
  assert.match(a, /teile\[3\] === 'ansichten'\) p = cockpitWechselFormular/);
  assert.match(a, /wechselStoppen\(\);\s*\n\s*if \(aktuelleKarte\)/);
  assert.match(a, /daten\.cockpitWechsel\(id\)\]\)/);
  assert.match(a, /'Ansichten-Wechsel: ' \+ \(wechsel\.an \? 'an' : 'aus'\)/);
  /* Die Karte wird nur geholt, wenn der Wechsel an ist und sie vorkommt, und nur einmal gestartet */
  assert.match(a, /x\[11\]\.an && x\[11\]\.ansichten\.indexOf\('karte'\) >= 0/);
  assert.match(a, /if \(!kvGestartet\) \{ kvGestartet = true; kv\.start\(\); \} else kv\.groesse\(\)/);
  assert.match(a, /Kein Internet\./);
  /* Die Punkte unten führen aus der Fläche zurück auf eine Seite */
  assert.match(a, /function seiteWaehlen\(n, weich\) \{\s*\n\s*if \(wechsler\) wechsler\.verbergen\(\);/);
  const k = lesen('js/kartenansicht.js');
  assert.match(k, /opt\.eingebettet \? null/);
  assert.match(k, /eingebettetKnoepfe/);
  assert.match(k, /groesse: function/);
  assert.match(lesen('css/styles.css'), /\.cv-zusatz\[hidden\]/);
});
