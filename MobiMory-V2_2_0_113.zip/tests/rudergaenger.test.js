'use strict';
/* 2.0.106: Rudergängerwechsel bei Wasserfahrzeugen (Rechnung, Speichern, Logbuch, Einbau). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'reiseorte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = p => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

/* ---------- reine Rechnung ---------- */
const START = { personId: 'a', name: 'Anna' };
const WECHSEL = [
  { id: 'r1', personId: 'b', name: 'Ben', ab: '2026-11-03T11:00' },
  { id: 'r2', personId: 'a', name: 'Anna', ab: '2026-11-03T12:30' }
];

test('Rudergänger: Der Skipper vom Anfang steht zuerst am Ruder, danach gelten die Wechsel', () => {
  assert.equal(MM.Rudergaenger.aktuell(START, WECHSEL, '2026-11-03T10:59').name, 'Anna');
  assert.equal(MM.Rudergaenger.aktuell(START, WECHSEL, '2026-11-03T11:00').name, 'Ben');
  assert.equal(MM.Rudergaenger.aktuell(START, WECHSEL, '2026-11-03T13:00').name, 'Anna');
  assert.equal(MM.Rudergaenger.aktuell(null, [], '2026-11-03T10:00'), null);
});

test('Rudergänger: Zeiten, genau gerechnet', () => {
  /* 09:00 bis 11:00 Anna (120), 11:00 bis 12:30 Ben (90), 12:30 bis 14:00 Anna (90) */
  const z = MM.Rudergaenger.zeiten(START, WECHSEL, '2026-11-03T09:00', '2026-11-03T14:00');
  assert.deepEqual(z.map(x => [x.name, x.minuten, x.abschnitte]), [['Anna', 210, 2], ['Ben', 90, 1]]);
  const teil = MM.Rudergaenger.abschnitte(START, WECHSEL, '2026-11-03T11:30', '2026-11-03T12:00');
  assert.deepEqual(teil.map(x => [x.name, x.minuten]), [['Ben', 30]], 'ein Zeitraum mitten im Wechsel');
  assert.deepEqual(MM.Rudergaenger.zeiten(null, WECHSEL, '2026-11-03T09:00', '2026-11-03T14:00'), []);
  assert.equal(MM.Rudergaenger.dauerText(125), '2 h 05 min');
});

test('Rudergänger: Ereignisse fürs Logbuch haben eine eigene Art, nicht die des Verantwortungswechsels', () => {
  const e = MM.Rudergaenger.wechselEreignisse(START, WECHSEL);
  assert.deepEqual(e.map(x => x.art), ['ruder', 'ruder']);
  assert.equal(e[0].text, 'Ben steht ab jetzt am Ruder (vorher Anna).');
  assert.equal(e[1].text, 'Anna steht ab jetzt am Ruder (vorher Ben).');
  assert.notEqual(MM.Rudergaenger.ART, MM.Logbuch.WECHSEL_ART);
});

test('Rudergänger: Wer dabei ist, darf ans Ruder, ohne Prüfung der Befähigung', () => {
  assert.equal(MM.Rudergaenger.dabei({ entfernt: 'nein' }, '2026-11-03T10:00'), true);
  assert.equal(MM.Rudergaenger.dabei({ entfernt: 'ja' }, '2026-11-03T10:00'), false);
  assert.equal(MM.Rudergaenger.dabei({ entfernt: 'nein', dabeiVonDatum: '2026-11-03', dabeiVonZeit: '12:00' }, '2026-11-03T11:00'), false);
  assert.equal(MM.Rudergaenger.dabei({ entfernt: 'nein', dabeiBisDatum: '2026-11-03', dabeiBisZeit: '10:00' }, '2026-11-03T11:00'), false);
});

/* ---------- mit Speicher ---------- */
function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 3, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (std, min) => { uhr.ms = new Date(2026, 10, 3, std, min, 0).getTime(); };
  return d;
}
async function mitBoot(fahrzeug) {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen(fahrzeug || 'boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const ben = (await d.personAnlegen({ bezeichnung: 'Ben', funktionen: ['Skipper'] })).id;
  const cora = (await d.personAnlegen({ bezeichnung: 'Cora', funktionen: ['Crew'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Sommertörn', artId: toern, fahrzeugId: boot, vonDatum: '2026-11-03', vonZeit: '09:00', bisDatum: '2026-11-05', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok);
  assert.ok((await d.besatzungHinzufuegen(r.id, ben, { rolle: 'stellvertreter' })).ok);
  assert.ok((await d.besatzungHinzufuegen(r.id, cora, { rolle: 'crew' })).ok);
  return { d, id: r.id, anna, ben, cora };
}

test('Rudergänger: Am Anfang steht der Skipper am Ruder, auch die Crew kann ans Ruder, der Skipper bleibt verantwortlich', async () => {
  const c = await mitBoot();
  let a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.rudergaengerJetzt.name, 'Anna');
  assert.deepEqual(a.rudergaenger, []);
  const r = await c.d.rudergaengerWechseln(c.id, c.cora, { abDatum: '2026-11-03', abZeit: '12:00' });
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal(r.vorher, 'Anna');
  a = await c.d.aktivitaetLaden(c.id);
  assert.equal(a.rudergaengerJetzt.name, 'Cora');
  assert.equal(a.verantwortlichJetzt.name, 'Anna', 'der Skipper bleibt verantwortlich');
  assert.equal(a.verantwortung.length, 1, 'kein Verantwortungswechsel entstanden');
});

test('Rudergänger: nicht dieselbe Person, nicht vor dem letzten Wechsel, nur wer dabei ist, nicht an Land', async () => {
  const c = await mitBoot();
  assert.ok((await c.d.rudergaengerWechseln(c.id, c.ben, { abDatum: '2026-11-03', abZeit: '12:00' })).ok);
  assert.ok((await c.d.rudergaengerWechseln(c.id, c.ben, { abDatum: '2026-11-03', abZeit: '12:10' })).fehler.personId, 'Ben steht schon am Ruder');
  assert.ok((await c.d.rudergaengerWechseln(c.id, c.anna, { abDatum: '2026-11-03', abZeit: '11:00' })).fehler.abDatum, 'vor dem letzten Wechsel');
  const fremd = (await c.d.personAnlegen({ bezeichnung: 'Fremd' })).id;
  assert.ok((await c.d.rudergaengerWechseln(c.id, fremd, { abDatum: '2026-11-03', abZeit: '12:10' })).fehler.personId, 'nicht dabei');
  assert.ok((await c.d.rudergaengerWechseln(c.id, c.anna, { abDatum: '', abZeit: '' })).fehler.abDatum);
  const land = await mitBoot('wohnmobil');
  const r = await land.d.rudergaengerWechseln(land.id, land.ben, { abDatum: '2026-11-03', abZeit: '12:00' });
  assert.equal(r.ok, false);
  assert.ok(r.fehler.allgemein);
  const a = await land.d.aktivitaetLaden(land.id);
  assert.deepEqual(a.rudergaenger, []); assert.equal(a.rudergaengerJetzt, null, 'an Land gibt es keinen Rudergänger');
});

test('Rudergänger: erscheint als eigener automatischer Eintrag im Logbuch, getrennt vom Verantwortungswechsel', async () => {
  const c = await mitBoot();
  await c.d.heutigerTag(c.id);
  assert.ok((await c.d.verantwortungWechseln(c.id, c.ben, { abDatum: '2026-11-03', abZeit: '12:05', zeitHerkunft: 'geraet' })).ok);
  c.d.stelle(12, 20);
  assert.ok((await c.d.rudergaengerWechseln(c.id, c.cora, { abDatum: '2026-11-03', abZeit: '12:20', zeitHerkunft: 'geraet' })).ok);
  const ev = (await c.d.logbuchLaden(c.id)).abschnitte.flatMap(t => t.ereignisse);
  const w = ev.filter(e => e.art === 'wechsel'), ru = ev.filter(e => e.art === 'ruder');
  assert.equal(w.length, 1); assert.equal(ru.length, 1);
  assert.equal(ru[0].artName, 'Rudergängerwechsel');
  assert.equal(ru[0].text, 'Cora steht ab jetzt am Ruder (vorher Anna).');
  assert.equal(ru[0].quelle, 'nutzer'); assert.equal(ru[0].zeitHerkunft, 'geraet');
  assert.equal(ru[0].aktivitaetId, c.id);
});

test('Rudergänger: Zeit am Ruder je Person, eine Reise ohne Wechsel gehört ganz dem Skipper', async () => {
  const c = await mitBoot();
  c.d.stelle(12, 0);
  let z = await c.d.rudergaengerZeiten(c.id);
  assert.deepEqual(z.map(x => [x.name, x.minuten]), [['Anna', 180]], '09:00 bis 12:00');
  assert.ok((await c.d.rudergaengerWechseln(c.id, c.ben, { abDatum: '2026-11-03', abZeit: '11:00' })).ok, 'Nachtrag');
  z = await c.d.rudergaengerZeiten(c.id);
  assert.deepEqual(z.map(x => [x.name, x.minuten]), [['Anna', 120], ['Ben', 60]]);
  const land = await mitBoot('wohnmobil');
  assert.deepEqual(await land.d.rudergaengerZeiten(land.id), []);
});

test('Rudergänger: Nachtragen merkt sich „nachgetragen“, die Zeit ist von Hand', async () => {
  const c = await mitBoot();
  const r = await c.d.rudergaengerWechseln(c.id, c.ben, { abDatum: '2026-11-03', abZeit: '10:00', zeitHerkunft: 'hand' });
  assert.ok(r.ok); assert.equal(r.nachgetragen, true);
  const a = await c.d.aktivitaetLaden(c.id);
  assert.ok(a.rudergaenger[0].nachgetragenAm); assert.equal(a.rudergaenger[0].zeitHerkunft, 'hand');
});

test('Rudergänger: Sicherung enthält das Dokument, Neue Adressen kollidieren nicht mit dem Verantwortungswechsel', () => {
  const ansicht = lesen('js/ansicht.js');
  assert.ok(ansicht.includes("teile[3] === 'rudergaenger') p = cockpitRuderSeite("));
  assert.ok(ansicht.includes("teile[3] === 'wechsel') p = cockpitWechselSeite("), 'der Verantwortungswechsel bleibt, wo er war');
  assert.equal((ansicht.match(/teile\[3\] === 'wechsel'/g) || []).length, 1);
  assert.ok(ansicht.includes("MM.Rudergaenger.NAME + ' wechseln', 'leise'"));
  assert.ok(ansicht.includes("a.fahrzeug.welt === 'wasser' ? h('p', null, h('span', { class: 'frist-info', text: MM.Rudergaenger.NAME + ' jetzt' })"));
});

test('Rudergänger: Modul steht in index.html und im Service Worker', () => {
  assert.ok(lesen('index.html').includes('js/rudergaenger.js'));
  assert.ok(lesen('index.html').indexOf('js/rudergaenger.js') < lesen('index.html').indexOf('js/daten.js'));
  assert.ok(lesen('sw.js').includes("'js/rudergaenger.js'"));
});
