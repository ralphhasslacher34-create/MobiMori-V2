'use strict';
/* 2.0.75 (Bau 1): Mitnutzung, App-Teil. Regeln für Einladung und Eintrag, Daten-Schicht, Anzeige beim Besitzer nach dem Abgleich (Ende zu Ende mit dem Dienst). */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'personen', 'orte', 'gebiete',
  'ortssuche', 'sicherung', 'speicher', 'hilfen', 'logbuch', 'rudergaenger', 'status', 'reiseorte', 'werkstatt', 'kosten', 'reisekasse', 'konto', 'abgleich', 'freigaben', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const F = MM.Freigaben;
const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

const HEUTE = '2026-11-14';
const BASIS = { fahrzeugId: 'fz-1', email: 'kind@example.org', ab: HEUTE, bis: '2027-01-31', nachweisArt: 'Führerschein', nachweisBis: '', bestaetigt: true };

test('Einladung: ohne Angabe wie bisher; Mitnutzung braucht einen Namen; Rechte und Ausnahmen werden sauber weitergegeben', () => {
  const alt = F.einladung(BASIS, HEUTE);
  assert.ok(alt.ok); assert.equal(alt.werte.rechte, undefined); assert.equal(alt.werte.gastName, undefined); assert.equal(alt.werte.ausnahmen, undefined);
  const ohne = F.einladung(Object.assign({}, BASIS, { rechte: 'mitnutzen' }), HEUTE);
  assert.equal(ohne.ok, false); assert.match(ohne.fehler.gastName, /Namen/);
  assert.equal(F.einladung(Object.assign({}, BASIS, { rechte: 'alles' }), HEUTE).fehler.rechte, 'Bitte wählen: nur lesen oder mitnutzen.');
  assert.ok(F.einladung(Object.assign({}, BASIS, { rechte: 'mitnutzen', gastName: 'x'.repeat(41) }), HEUTE).fehler.gastName);
  const ok = F.einladung(Object.assign({}, BASIS, { rechte: 'mitnutzen', gastName: ' Anna ', ausnahmen: ['do-3', 'do-3', '', 'do-4'] }), HEUTE);
  assert.ok(ok.ok); assert.equal(ok.werte.rechte, 'mitnutzen'); assert.equal(ok.werte.gastName, 'Anna'); assert.deepEqual(ok.werte.ausnahmen, ['do-3', 'do-4']);
  const lesenNur = F.einladung(Object.assign({}, BASIS, { rechte: 'lesen', gastName: 'Anna' }), HEUTE);
  assert.ok(lesenNur.ok); assert.equal(lesenNur.werte.rechte, 'lesen');
});

test('Eintrag: Kilometer, Kosten und Störung werden geprüft, Fixkosten und Reisekasse sind für den Gast tabu', () => {
  const km = F.erfassung('kilometer', { zaehlerId: 'za-1', wert: '51.800', datum: '' }, HEUTE);
  assert.ok(km.ok); assert.equal(km.werte.wert, 51800); assert.equal(km.werte.datum, HEUTE);
  assert.equal(F.erfassung('kilometer', { zaehlerId: '', wert: 'abc' }, HEUTE).fehler.wert.length > 0, true);
  assert.ok(F.erfassung('kilometer', { zaehlerId: 'za-1', wert: 5, datum: '2026-12-31' }, HEUTE).fehler.datum);
  assert.ok(F.erfassung('kilometer', { zaehlerId: 'za-1', wert: 5, datum: '2026-11-15' }, HEUTE).ok, 'morgen ist erlaubt (andere Zeitzone)');
  const k = F.erfassung('kosten', { gruppe: 'variabel', kostenart: 'treibstoff', bezeichnung: 'Diesel', betrag: '82,50', datum: '2026-11-10', ortText: 'Malmö' }, HEUTE);
  assert.ok(k.ok); assert.equal(k.werte.betrag, 82.5);
  assert.equal(F.erfassung('kosten', { gruppe: 'fix', bezeichnung: 'Versicherung', betrag: 5 }, HEUTE).fehler.gruppe, 'Fixkosten legt nur der Besitzer an.');
  assert.match(F.erfassung('kosten', { gruppe: 'reisekasse', bezeichnung: 'Eis', betrag: 3 }, HEUTE).fehler.gruppe, /bleiben bei dir/);
  assert.ok(F.erfassung('kosten', { gruppe: 'variabel', bezeichnung: 'x', betrag: 0 }, HEUTE).fehler.betrag);
  assert.ok(F.erfassung('kosten', { gruppe: 'variabel', bezeichnung: '', betrag: 3 }, HEUTE).fehler.bezeichnung);
  const s = F.erfassung('stoerung', { bezeichnung: 'Kühlschrank', auswirkung: 'bedingt' }, HEUTE);
  assert.ok(s.ok); assert.equal(s.werte.auswirkung, 'bedingt');
  assert.ok(F.erfassung('stoerung', { bezeichnung: 'Kühlschrank', auswirkung: 'schlimm' }, HEUTE).fehler.auswirkung);
  assert.ok(F.erfassung('verkaufen', {}, HEUTE).fehler.art);
});

test('Zeilen „Meine Einträge“ in einfachen Worten', () => {
  assert.equal(F.eintragText({ art: 'kilometer', wert: 52000 }), 'Kilometerstand 52.000 km');
  assert.equal(F.eintragText({ art: 'kosten', titel: 'Maut', betrag: 12 }), 'Maut: 12,00 €');
  assert.match(F.eintragText({ art: 'kosten', titel: 'Maut', betrag: 12, ausgeblendet: true }), /vom Besitzer ausgeblendet/);
  assert.equal(F.eintragText({ art: 'stoerung', titel: 'Licht', status: 'offen', auswirkung: 'keine' }), 'Störung: Licht (offen, fahrzeug bleibt nutzbar)');
  assert.equal(F.eintragText({ art: 'stoerung', titel: 'Licht', status: 'erledigt' }), 'Störung: Licht (erledigt)');
});

test('Daten-Schicht: prüft vorher, schickt Freigabe und Eingaben an den Dienst, meldet Fehler in einfachen Worten', async () => {
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => '2026-11-14T10:00:00.000Z' });
  await d.starten();
  const gesendet = [];
  d.kontoSenden = (m, weg, body) => { gesendet.push([m, weg, body]); return Promise.resolve({ ok: true, json: { id: 'ko-g-1', code: 'ABCDEFGH', laeuftAb: 1 } }); };
  d.rcGeraet = () => Promise.resolve({ kontoDienstUrl: 'https://konto.example.org' });
  const falsch = await d.geteiltErfassen('fr-1', 'kosten', { gruppe: 'fix', bezeichnung: 'x', betrag: 1 });
  assert.equal(falsch.ok, false); assert.equal(gesendet.length, 0, 'bei einem Fehler geht nichts hinaus');
  const ok = await d.geteiltErfassen('fr-1', 'kosten', { gruppe: 'variabel', bezeichnung: 'Diesel', betrag: '10', datum: '2026-11-14' });
  assert.deepEqual([ok.ok, ok.id], [true, 'ko-g-1']);
  assert.deepEqual(gesendet[0], ['POST', '/geteilt/erfassen', { freigabe: 'fr-1', art: 'kosten', gruppe: 'variabel', bezeichnung: 'Diesel', betrag: 10, datum: '2026-11-14' }]);
  const k = await d.geteiltKontrolle('fr-1', 24);
  assert.equal(k.ok, true); assert.equal(k.code, 'ABCDEFGH'); assert.equal(k.dienstUrl, 'https://konto.example.org');
  assert.deepEqual(gesendet[1], ['POST', '/geteilt/kontrolle', { freigabe: 'fr-1', stunden: 24 }]);
  assert.equal((await d.geteiltKontrolle('fr-1', 500)).ok, false);
  d.kontoSenden = () => Promise.resolve({ ok: false, status: 403, fehler: 'Diese Freigabe erlaubt nur das Ansehen.', feld: null });
  const nein = await d.geteiltErfassen('fr-1', 'kilometer', { zaehlerId: 'za-1', wert: 5 });
  assert.equal(nein.ok, false); assert.match(nein.fehler.allgemein, /nur das Ansehen/);
});

test('Ende zu Ende: Der Gast trägt ein, der Besitzer holt es beim Abgleich und sieht es mit dem Namen in Kosten, Werkstatt und Zählerstand', async () => {
  const APP = 'https://app.example.org';
  const dienst = await import('../server/konto-dienst.mjs');
  const env = { DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' };
  const uhr = { t: Date.UTC(2026, 10, 14, 12, 0, 0) };
  async function ruf(m, weg, body, tok) {
    const r = await dienst.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: m, headers: Object.assign({ Origin: APP, 'CF-Connecting-IP': '203.0.113.5' }, body !== undefined ? { 'Content-Type': 'application/json' } : {}, tok ? { Authorization: 'Bearer ' + tok } : {}), body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: () => uhr.t });
    return { status: r.status, json: await r.json() };
  }
  async function konto(email) {
    const a = await ruf('POST', '/konto/registrieren', { email, passwort: 'Sehr-sicheres-Passwort-1' });
    return (await ruf('POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode })).json.token;
  }
  /* Besitzer: Fahrzeug mit Kilometerzähler auf dem Gerät, abgleichen */
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.t).toISOString() });
  await d.starten();
  const fz = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'LMC Wohnmobil' })).id;
  const za = (await d.zaehlerAnlegen(fz, null, 'strecke', { bezeichnung: 'Kilometerstand' })).id;
  assert.equal((await d.zaehlerStandEintragen(za, { wert: 51000, datum: '2026-11-01' })).ok, true);
  const tok = await konto('ralph@example.org');
  const dr = d.datenraumId;
  const senden = [];
  for (const tab of ['fahrzeuge', 'eintraege', 'zaehler', 'zaehlerstaende', 'verlaeufe']) {
    for (const rec of await d.speicher.alle(tab)) { const x = MM.Abgleich.fuerDienst(tab, rec, dr); if (x) senden.push({ tabelle: x.tabelle, id: x.id, basis: 0, nutzlast: x.nutzlast }); }
  }
  assert.equal((await ruf('POST', '/abgleich/senden', { eintraege: senden }, tok)).status, 200);
  /* Einladung mit Mitnutzung, Gast nimmt an */
  const gast = await konto('kind@example.org');
  const e = await ruf('POST', '/freigabe/einladen', { fahrzeugId: fz, email: 'kind@example.org', bis: '2027-01-31', nachweisArt: 'Führerschein', bestaetigt: true, rechte: 'mitnutzen', gastName: 'Anna' }, tok);
  assert.equal(e.status, 200, JSON.stringify(e.json));
  assert.equal((await ruf('POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, gast)).status, 200);
  /* Gast trägt ein, mit der Daten-Schicht seiner App */
  const g = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.t).toISOString() });
  await g.starten();
  g.kontoSenden = (m, weg, body) => ruf(m, weg, body, gast).then((r) => r.status === 200 ? { ok: true, json: r.json } : { ok: false, status: r.status, fehler: r.json.error, feld: r.json.feld });
  const geladen = await ruf('GET', '/geteilt/fahrzeug?freigabe=' + e.json.id, undefined, gast);
  const sicht = MM.Freigaben.sicht(geladen.json.datensaetze, HEUTE);
  assert.equal(geladen.json.rechte, 'mitnutzen');
  const kmZaehler = sicht.zaehler.filter((z) => z.einheit === 'km');
  assert.equal(kmZaehler.length, 1); assert.equal(kmZaehler[0].stand, 51000);
  assert.equal((await g.geteiltErfassen(e.json.id, 'kilometer', { zaehlerId: kmZaehler[0].id, wert: '51.800', datum: HEUTE })).ok, true);
  assert.equal((await g.geteiltErfassen(e.json.id, 'kosten', { gruppe: 'variabel', kostenart: 'treibstoff', bezeichnung: 'Diesel Malmö', betrag: '82,50', datum: HEUTE })).ok, true);
  assert.equal((await g.geteiltErfassen(e.json.id, 'stoerung', { bezeichnung: 'Kühlschrank geht nicht', auswirkung: 'bedingt' })).ok, true);
  assert.equal((await g.geteiltErfassen(e.json.id, 'kosten', { gruppe: 'fix', bezeichnung: 'Versicherung', betrag: 5 })).ok, false);
  /* Besitzer holt die Änderungen wie beim Abgleich */
  const holen = (await ruf('GET', '/abgleich/aenderungen?seit=0', undefined, tok)).json.eintraege;
  for (const x of holen) {
    if (x.geloescht) continue;
    const eigene = await d.speicher.holen(x.tabelle, x.id);
    await d.speicher.speichern(x.tabelle, MM.Abgleich.vonDienst(x.tabelle, x.nutzlast, dr, eigene || null));
  }
  const kosten = await d.kostenListe(fz);
  assert.equal(kosten.length, 1, 'der Posten des Gastes liegt im Fahrzeug des Besitzers');
  assert.equal(kosten[0].aktuell.werte.betrag, 82.5); assert.equal(kosten[0].objekt.gast.name, 'Anna'); assert.equal(kosten[0].aktuell.werte.gruppe, 'variabel');
  const vorgaenge = await d.vorgaengeListe(fz);
  assert.equal(vorgaenge.length, 1); assert.equal(vorgaenge[0].aktuell.werte.status, 'offen'); assert.equal(vorgaenge[0].vorgang.gast.name, 'Anna'); assert.equal(vorgaenge[0].aktuell.werte.art, 'stoerung');
  const z = await d.zaehlerLaden(za);
  assert.equal(z.staende.length, 2); assert.equal(z.staende[0].wert, 51800); assert.equal(z.staende[0].gast.name, 'Anna'); assert.equal(z.staende[0].nr, 2);
  /* Der Gast sieht seine drei Einträge */
  const nochmal = await g.geteiltLaden(e.json.id);
  assert.equal(nochmal.ok, true); assert.equal(nochmal.rechte, 'mitnutzen'); assert.equal(nochmal.eigene.length, 3);
});

test('Ansicht: Einladungsformular, Seite des Gastes und Anzeige „von …“ stehen im Quelltext', () => {
  const a = lesen('js/ansicht.js');
  ["'fg-rechte'", "'fg-gname'", 'dokumenteLaden', 'daten.verleihDokumente', "TEXT_MITNUTZUNG", 'function gastMitnutzung', 'daten.geteiltErfassen(', 'daten.geteiltKontrolle(', "'Meine Einträge'",
    "'eingetragen von '", "'gemeldet von '", "'Mitnutzen (Kilometer, Kosten und Störungen eintragen)'", 'Im Dienst fehlt die SQL-Zeile 13f-2'].forEach((s) => assert.ok(a.includes(s), s));
  assert.ok(a.includes("MM.Freigaben.TEXT_GAST_MITNUTZUNG"));
  assert.ok(F.TEXT_MITNUTZUNG.includes('Reisekosten') && F.TEXT_GAST_MITNUTZUNG.includes('Reisekosten'));
});

test('Server-Dateien: 13f-2.sql, Schema, Einrichtung; Nutzlast der Einträge enthält nichts, was nur auf dem Gerät bleibt', () => {
  const sql = lesen('server/13f-2.sql').trim().split('\n');
  assert.equal(sql.length, 3);
  const schema = lesen('server/schema.sql');
  sql.forEach((z) => assert.ok(schema.includes(z), z));
  assert.ok(lesen('server/EINRICHTUNG.md').includes('Update auf 13f-2'));
  assert.ok(!MM.Abgleich.LOKALE_SCHLUESSEL.includes('gast'), 'das Feld „gast“ geht mit zum Besitzer');
});
