'use strict';
/* 2.0.108: Karten-Umbau. Ereignisse auf der Karte mit zweistufiger Auswahl, Seezeichen, Peilung auf eine Tonne. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'texte', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'rudergaenger', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche',
  'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'etappen', 'reisecheck', 'karte', 'kartenereignisse', 'kartenablage', 'kartenbild', 'pdf', 'reisebuch', 'daten'].forEach((m) => require('../js/' + m + '.js'));
const MM = globalThis.MM;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const KE = MM.KartenEreignisse;
const JETZT = new Date(2026, 10, 17, 12, 0, 0);

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(JETZT.getTime() + (t++)).toISOString() });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = (x) => arten.find((a) => a.aktuell.werte.bezeichnung === x).objekt.id;
  return { d, boot, wm, anna, artId };
}
const heute = (c, fz, extra) => c.d.aktivitaetAnlegen(Object.assign({ bezeichnung: 'Törn', artId: c.artId('Törn'), fahrzeugId: fz, vonDatum: '2026-11-17', vonZeit: '08:00', bisDatum: '2026-11-18', verantwortlichId: c.anna }, extra || {}))
  .then((r) => { assert.equal(r.ok, true, JSON.stringify(r)); return r.id; });
const pos = { breite: 54.32, laenge: 10.14, genauigkeit: 6 };

test('Auswahl: Schlüssel, Standard (Geschwindigkeit aus), Wirksamkeit generell und je Aktivität', () => {
  assert.equal(KE.schluessel('  Störung '), 'störung');
  assert.deepEqual(KE.standard(), { aus: ['geschwindigkeit'], seezeichen: true });
  const g = KE.lesen({ aus: ['Notiz', 'notiz', 'Wetter'], seezeichen: false });
  assert.deepEqual(g, { aus: ['notiz', 'wetter'], seezeichen: false });
  assert.equal(KE.lesen(null), null);
  assert.deepEqual(KE.wirksam(null, null), KE.standard());
  assert.deepEqual(KE.wirksam(g, null), { aus: ['notiz', 'wetter'], seezeichen: false });
  /* Die eigene Auswahl der Aktivität ergänzt oder verkleinert: sie ersetzt die Liste, die Seezeichen bleiben generell, wenn nichts anderes gilt. */
  const a = KE.lesen({ aus: ['störung'], seezeichen: null });
  assert.deepEqual(KE.wirksam(g, a), { aus: ['störung'], seezeichen: false });
  assert.deepEqual(KE.wirksam(g, KE.lesen({ aus: [], seezeichen: true })), { aus: [], seezeichen: true });
});

test('Auswahl: filtern, Liste der Arten (auch abgewählte ohne Eintrag), umschalten', () => {
  const ev = [{ artName: 'Wetter' }, { artName: 'Störung' }, { artName: 'störung' }, { artName: 'Geschwindigkeit' }];
  const wahl = KE.standard();
  assert.deepEqual(KE.filtern(ev, wahl).map((e) => e.artName), ['Wetter', 'Störung', 'störung']);
  const liste = KE.artenListe(ev, wahl);
  assert.deepEqual(liste.map((x) => x.schluessel + ':' + x.anzahl + ':' + x.an), ['geschwindigkeit:1:false', 'störung:2:true', 'wetter:1:true']);
  const w2 = KE.umschalten(wahl, 'Wetter', false);
  assert.deepEqual(w2.aus.sort(), ['geschwindigkeit', 'wetter']);
  assert.deepEqual(KE.umschalten(w2, 'wetter', true).aus, ['geschwindigkeit']);
  /* eine abgewählte Art ohne Eintrag bleibt in der Liste, damit man sie wieder anschalten kann */
  const l2 = KE.artenListe([], { aus: ['notiz'], seezeichen: true });
  assert.equal(l2.length, 1); assert.equal(l2[0].an, false);
  assert.equal(KE.aussehen('Störung').symbol, '!'); assert.equal(KE.aussehen('Irgendwas').symbol, '•');
  assert.equal(KE.aussehen('Peilung auf eine Tonne').symbol, 'P');
});

test('Auswahl speichern: generell, je Aktivität, Rückkehr zur Vorauswahl', async () => {
  const c = await neu();
  const id = await heute(c, c.boot);
  let w = await c.d.kartenWahl(id);
  assert.deepEqual(w.wirksam, KE.standard()); assert.equal(w.eigene, false);
  await c.d.kartenWahlGenerell({ aus: ['notiz'], seezeichen: true }, null);
  w = await c.d.kartenWahl(id);
  assert.deepEqual(w.wirksam.aus, ['notiz']); assert.equal(w.eigene, false);
  await c.d.kartenWahlAktivitaet(id, { aus: ['wetter'], seezeichen: false });
  w = await c.d.kartenWahl(id);
  assert.deepEqual(w.wirksam, { aus: ['wetter'], seezeichen: false }); assert.equal(w.eigene, true);
  /* eine zweite Aktivität sieht nur die generelle Auswahl */
  const id2 = await heute(c, c.wm, { bezeichnung: 'Tour' });
  assert.deepEqual((await c.d.kartenWahl(id2)).wirksam.aus, ['notiz']);
  /* als Vorauswahl speichern: die eigene Auswahl dieser Aktivität fällt weg */
  await c.d.kartenWahlGenerell({ aus: ['störung'], seezeichen: true }, id);
  w = await c.d.kartenWahl(id);
  assert.deepEqual(w.wirksam, { aus: ['störung'], seezeichen: true }); assert.equal(w.eigene, false);
  /* die Kartendaten tragen die Wahl */
  const kd = await c.d.kartenDaten(id, 0);
  assert.deepEqual(kd.wahl.wirksam.aus, ['störung']);
  /* Die Dokumente beginnen nicht mit „karte-“ (das sind die Offline-Karten) */
  assert.ok(MM.KartenEreignisse.DOK_GENERELL.indexOf('karte-') !== 0 && KE.dokJeAktivitaet('x').indexOf('karte-') !== 0);
});

test('Kartendaten: Einträge aller Arten mit Position kommen, ohne Position nicht', async () => {
  const c = await neu();
  const id = await heute(c, c.boot);
  await c.d.ereignisSchnell(id, 'Störung', { text: 'Motor überhitzt', position: pos });
  await c.d.ereignisSchnell(id, 'Notiz', { text: 'Ankerplatz', position: pos });
  await c.d.ereignisSchnell(id, 'Notiz', { text: 'ohne Position' });
  const kd = await c.d.kartenDaten(id, 0);
  assert.deepEqual(kd.ereignisse.map((e) => e.artName).sort(), ['Notiz', 'Störung']);
});

test('Peilung: Prüfung der Eingaben', () => {
  const L = MM.Logbuch;
  assert.equal(L.PEILUNG_ART, 'Peilung auf eine Tonne');
  assert.equal(L.istPeilungsArt(' peilung AUF eine tonne'), true);
  assert.deepEqual(L.peilungPruefen({ objekt: ' Tonne  12 ', grad: '245', text: ' bei Nebel ' }), { ok: true, objekt: 'Tonne 12', grad: 245, text: 'bei Nebel' });
  assert.equal(L.peilungPruefen({ objekt: 'T', grad: '12,5°' }).grad, 12.5);
  assert.equal(L.peilungPruefen({ objekt: 'T', grad: '360' }).ok, true);
  assert.ok(L.peilungPruefen({ objekt: '', grad: '10' }).fehler.objekt);
  assert.ok(L.peilungPruefen({ objekt: 'T', grad: '' }).fehler.grad);
  assert.ok(L.peilungPruefen({ objekt: 'T', grad: '361' }).fehler.grad);
  assert.ok(L.peilungPruefen({ objekt: 'T', grad: 'abc' }).fehler.grad);
  assert.ok(L.peilungPruefen({ objekt: 'x'.repeat(81), grad: '1' }).fehler.objekt);
  assert.equal(L.peilungText('Tonne 12', 245, ''), 'Peilung 245° auf Tonne 12');
  assert.equal(L.peilungText('Tonne 12', 12.5, 'bei Nebel'), 'Peilung 12,5° auf Tonne 12. bei Nebel');
});

test('Peilung eintragen: Boot mit GPS-Position und von Hand, Wohnmobil und Fehler werden abgewiesen, Art gibt es nur einmal', async () => {
  const c = await neu();
  const id = await heute(c, c.boot);
  const r = await c.d.peilungEintragen(id, { objekt: 'Tonne 12', grad: '245', position: pos });
  assert.equal(r.ok, true, JSON.stringify(r));
  const r2 = await c.d.peilungEintragen(id, { objekt: 'Leuchtfeuer Kiel', grad: '90', breite: '54,5', laenge: '10,2' });
  assert.equal(r2.ok, true, JSON.stringify(r2));
  const lb = await c.d.logbuchLaden(id);
  const e = lb.abschnitte[0].ereignisse.filter((x) => x.artName === 'Peilung auf eine Tonne');
  assert.equal(e.length, 2);
  const gps = e.find((x) => /Tonne 12/.test(x.text)), hand = e.find((x) => /Kiel/.test(x.text));
  assert.equal(gps.text, 'Peilung 245° auf Tonne 12'); assert.equal(gps.positionQuelle, 'gps'); assert.equal(gps.breite, 54.32);
  assert.equal(hand.positionQuelle, 'hand'); assert.equal(hand.breite, 54.5); assert.equal(hand.laenge, 10.2);
  assert.equal((await c.d.ereignisartenListe()).filter((a) => a.aktuell.werte.bezeichnung === 'Peilung auf eine Tonne').length, 1);
  /* ohne Position bleibt der Eintrag ohne Position */
  const r3 = await c.d.peilungEintragen(id, { objekt: 'Tonne 3', grad: '10' });
  assert.equal(r3.ok, true);
  /* Fehler: Eingabe, halbe Position, Landfahrzeug */
  assert.ok((await c.d.peilungEintragen(id, { objekt: '', grad: '10' })).fehler.objekt);
  assert.ok((await c.d.peilungEintragen(id, { objekt: 'T', grad: '10', breite: '54,5', laenge: '' })).fehler.position);
  const idWm = await heute(c, c.wm, { bezeichnung: 'Tour' });
  const rl = await c.d.peilungEintragen(idWm, { objekt: 'T', grad: '10', position: pos });
  assert.equal(rl.ok, false); assert.match(rl.fehler.allgemein, /nur bei Wasserfahrzeugen/);
  /* die Peilung steht in den Kartendaten (mit Position) */
  const kd = await c.d.kartenDaten(id, 0);
  assert.equal(kd.ereignisse.filter((x) => x.artName === 'Peilung auf eine Tonne').length, 2);
});

test('Seezeichen: Quelle, Kacheln nur im Zoombereich, Ablage holt und löscht sie getrennt von den Straßenkacheln', async () => {
  const q = MM.Karte.SEE_QUELLE;
  assert.equal(MM.Karte.seeKachelUrl(10, 550, 335), 'https://tiles.openseamap.org/seamark/10/550/335.png');
  assert.match(q.nachweis, /OpenSeaMap/);
  const k = MM.Karte.seeKacheln([{ z: 5, x: 1, y: 1 }, { z: 9, x: 2, y: 3 }, { z: 18, x: 4, y: 5 }, { z: 19, x: 6, y: 7 }]);
  assert.deepEqual(k.map((x) => x.z), [9, 18]);
  assert.ok(k.every((x) => x.ebene === 'see'));
  const store = new Map();
  const cache = { match: async (u) => store.get(u) || undefined, put: async (u, r) => { store.set(u, r); }, delete: async (u) => store.delete(u) };
  const holte = [];
  const ablage = new MM.Kartenablage({ pauseMs: 0, oeffnen: async () => cache, hole: async (u) => { holte.push(u); return { ok: true, status: 200, clone() { return this; }, blob: async () => ({ size: 10 }) }; } });
  const res = await ablage.holen(k);
  assert.equal(res.ok, true); assert.deepEqual(holte.sort(), ['https://tiles.openseamap.org/seamark/18/4/5.png', 'https://tiles.openseamap.org/seamark/9/2/3.png']);
  assert.deepEqual(res.urls.sort(), ['see/18/4/5', 'see/9/2/3']);
  const gemischt = await ablage.holen([{ z: 9, x: 2, y: 3 }]);
  assert.equal(gemischt.ok, true);
  assert.equal(store.size, 3);
  assert.equal(await ablage.loeschen(['see/9/2/3']), 1);
  assert.equal(store.size, 2);
  assert.ok(store.has('https://tile.openstreetmap.org/9/2/3.png'));
});

test('Code: Karte füllt die Seite, Auswahl, Seezeichen, Peilung und Wege sind verdrahtet', () => {
  const k = lesen('js/kartenansicht.js'), a = lesen('js/ansicht.js'), css = lesen('css/styles.css'), idx = lesen('index.html'), sw = lesen('sw.js');
  assert.ok(k.includes('kv-info-kopf') && k.includes('kv-panel') && k.includes('KE.filtern(kd.ereignisse, wahl)') && k.includes('seeAnwenden'));
  assert.ok(css.includes('.kv-info-kopf') && css.includes('.kv-panel') && css.includes('.kv-art-peilung'));
  assert.ok(a.includes('wahlSpeichern: kartenWahlSpeichern(id)') && a.includes('cockpitPeilungSeite') && a.includes("'/cockpit/peilung'"));
  assert.ok(idx.includes('js/kartenereignisse.js') && sw.includes('js/kartenereignisse.js'));
  assert.ok(idx.indexOf('js/kartenereignisse.js') < idx.indexOf('js/kartenansicht.js'));
});


/* ---------- Karten im Reisetagebuch ---------- */
const JPEG = Uint8Array.from([0xFF, 0xD8, 0xFF, 0xC0, 0x00, 0x11, 0x08, 0x00, 0x03, 0x00, 0x02, 0x03, 1, 0x11, 0, 2, 0x11, 0, 3, 0x11, 0, 0xFF, 0xD9]);
function falscheLeinwand(aufrufe) {
  const kontext = new Proxy({}, { get(_, name) { if (name === 'measureText') return () => ({ width: 100 }); return (...a) => { aufrufe.push([String(name), a]); }; }, set(_, name, wert) { aufrufe.push(['set:' + String(name), [wert]]); return true; } });
  return (b, h) => ({ zeichnen: kontext, nachBytes: async () => JPEG, breite: b, hoehe: h });
}

test('Kartenbild: Ausschnitt zeigt alle Punkte mit Rand, ein Punkt bekommt Zoom 13, ohne Punkte nichts', () => {
  const K = MM.Kartenbild;
  assert.equal(K.ausschnitt([], 1200, 800), null);
  const e = K.ausschnitt([[54.3, 10.1]], 1200, 800);
  assert.equal(e.z, 13); assert.ok(e.kacheln.length >= 4 && e.kacheln.length <= K.MAX_KACHELN);
  const punkte = [[54.0, 10.0], [54.6, 11.2], [54.3, 10.5]];
  const a = K.ausschnitt(punkte, 1200, 800);
  assert.ok(a.z >= 8 && a.z <= 11, 'Zoom ' + a.z);
  punkte.forEach((p) => { const q = K.pixel(a, p[0], p[1]); assert.ok(q[0] >= 40 && q[0] <= 1160 && q[1] >= 40 && q[1] <= 760, JSON.stringify(q)); });
  assert.ok(a.kacheln.every((k) => k.px > -256 && k.px < 1200 && k.py > -256 && k.py < 800));
  /* weit auseinander: kleiner Zoom, aber immer in der Kachelgrenze */
  const w = K.ausschnitt([[40, -10], [60, 30]], 1200, 800);
  assert.ok(w.z < a.z && w.kacheln.length <= K.MAX_KACHELN);
});

test('Kartenbild: zeichnet Kacheln, Route, Weg, Marker, Quelle; ohne Kacheln steht ein Hinweis im Bild; Seezeichen nur bei Wasser', async () => {
  const aufrufe = [], geholt = [];
  const mit = await MM.Kartenbild.erzeugen({ route: [[54.0, 10.0], [54.4, 10.4]], wegStuecke: [[[54.1, 10.1], [54.2, 10.2]]], planOrte: [{ rolle: 'start', breite: 54.0, laenge: 10.0 }, { rolle: 'ziel', breite: 54.4, laenge: 10.4 }],
    marker: [{ breite: 54.2, laenge: 10.2, symbol: '!', farbe: '#c0262d' }], see: true, titel: 'Tag 1, 17.11.2026',
    hole: async (url) => { geholt.push(url); return { size: 5 }; }, bildLaden: async () => ({ bild: 1 }), leinwand: falscheLeinwand(aufrufe) });
  assert.equal(mit.ok, true); assert.equal(mit.hatHintergrund, true); assert.deepEqual(Array.from(mit.bytes), Array.from(JPEG));
  assert.equal(mit.see, true); assert.match(mit.quelle, /OpenStreetMap/); assert.match(mit.quelle, /OpenSeaMap/);
  assert.ok(geholt.some((u) => u.startsWith('https://tile.openstreetmap.org/')) && geholt.some((u) => u.startsWith('https://tiles.openseamap.org/seamark/')));
  assert.ok(aufrufe.some((a) => a[0] === 'drawImage') && aufrufe.some((a) => a[0] === 'lineTo') && aufrufe.some((a) => a[0] === 'arc'));
  assert.ok(aufrufe.some((a) => a[0] === 'fillText' && /OpenStreetMap/.test(a[1][0])));
  /* ohne Netz und ohne Offline-Karte: Hinweis statt leerem Bild, kein Seezeichen-Nachweis */
  const a2 = [];
  const ohne = await MM.Kartenbild.erzeugen({ route: [[54.0, 10.0], [54.4, 10.4]], see: true, hole: async () => null, bildLaden: async () => null, leinwand: falscheLeinwand(a2) });
  assert.equal(ohne.ok, true); assert.equal(ohne.hatHintergrund, false); assert.equal(ohne.see, false);
  assert.ok(a2.some((a) => a[0] === 'fillText' && /Kartenhintergrund fehlt/.test(a[1][0])));
  /* ohne Punkte, ohne Leinwand */
  assert.equal((await MM.Kartenbild.erzeugen({ leinwand: falscheLeinwand([]) })).ok, false);
  assert.equal((await MM.Kartenbild.erzeugen({ route: [[54, 10], [54.1, 10.1]] })).ok, false);
  /* Kacheln aus dem Gerät gehen vor dem Netz */
  const nurLokal = [];
  const lokal = await MM.Kartenbild.erzeugen({ route: [[54.0, 10.0], [54.4, 10.4]], ablage: { blob: async () => ({ size: 1 }) }, hole: async (u) => { nurLokal.push(u); return null; }, bildLaden: async () => ({}), leinwand: falscheLeinwand([]) });
  assert.equal(lokal.hatHintergrund, true); assert.equal(nurLokal.length, 0);
});

async function reiseMitKarte(c) {
  const id = await heute(c, c.boot);
  await c.d.ereignisSchnell(id, 'Störung', { text: 'Motor überhitzt', position: pos });
  await c.d.ereignisSchnell(id, 'Notiz', { text: 'Ankerplatz', position: { breite: 54.4, laenge: 10.2, genauigkeit: 5 } });
  await c.d.peilungEintragen(id, { objekt: 'Tonne 12', grad: '245', breite: '54,35', laenge: '10,15' });
  return id;
}

test('Kartenbild-Daten: Ereignisse nach der Auswahl, Herkunft der Positionen gezählt, Seezeichen nur bei Wasser', async () => {
  const c = await neu();
  const id = await reiseMitKarte(c);
  let kb = await c.d.kartenbildDaten(id, null);
  assert.equal(kb.ok, true); assert.equal(kb.marker.length, 3); assert.equal(kb.auto, 2); assert.equal(kb.hand, 1); assert.equal(kb.see, true);
  assert.deepEqual(kb.marker.map((m) => m.symbol).sort(), ['!', 'N', 'P']);
  await c.d.kartenWahlAktivitaet(id, { aus: ['notiz'], seezeichen: false });
  kb = await c.d.kartenbildDaten(id, null);
  assert.equal(kb.marker.length, 2); assert.equal(kb.see, false);
  const idWm = await heute(c, c.wm, { bezeichnung: 'Tour' });
  await c.d.ereignisSchnell(idWm, 'Notiz', { text: 'Stellplatz', position: pos });
  assert.equal((await c.d.kartenbildDaten(idWm, null)).see, false);
  /* ein Tag: nur Ereignisse dieses Tages */
  const lb = await c.d.logbuchLaden(id);
  const tag = lb.abschnitte[0];
  const kt = await c.d.kartenbildDaten(id, tag.objekt.id);
  assert.equal(kt.ok, true); assert.match(kt.titel, /^Tag 1, 17\.11\.2026$/);
  assert.equal((await c.d.kartenbildDaten(id, 'gibtsnicht')).ok, false);
  assert.equal((await c.d.kartenbildDaten('x', null)).ok, false);
});

test('Kartenbild speichern und holen: erzeugen legt es bei der Reise ab, ein neues ersetzt das alte, ohne Punkte gibt es keins', async () => {
  const c = await neu();
  const id = await reiseMitKarte(c);
  const opt = { leinwand: falscheLeinwand([]), bildLaden: async () => ({}), hole: async () => ({ size: 1 }) };
  assert.equal(await c.d.kartenbildHolen(id, null), null);
  const r = await c.d.kartenbildErzeugen(id, null, opt);
  assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.hatHintergrund, true);
  assert.match(r.beschriftung, /Positionen der Ereignisse: 2 automatisch \(GPS\), 1 von Hand/);
  assert.match(r.beschriftung, /Informationskarte, keine amtliche Karte/);
  const b = await c.d.kartenbildHolen(id, null);
  assert.deepEqual(Array.from(b.bytes), Array.from(JPEG)); assert.equal(b.hatHintergrund, true); assert.equal(b.beschriftung, r.beschriftung);
  /* ohne Kartenhintergrund merkt sich das Bild das */
  const r2 = await c.d.kartenbildErzeugen(id, null, { leinwand: falscheLeinwand([]), bildLaden: async () => null, hole: async () => null });
  assert.equal(r2.hatHintergrund, false); assert.match(r2.beschriftung, /Ohne Kartenhintergrund/);
  assert.equal((await c.d.kartenbildHolen(id, null)).hatHintergrund, false);
  /* eine Reise ohne Position hat keine Karte */
  const leer = await heute(c, c.boot, { bezeichnung: 'Leer' });
  const r3 = await c.d.kartenbildErzeugen(leer, null, opt);
  assert.equal(r3.ok, false); assert.match(r3.grund, /keine Punkte/);
  assert.equal(await c.d.kartenbildHolen(leer, null), null);
});

test('Reisebuch: Karten als Schalter, Vorlagen, Karten für das Buch (gespeichert oder neu gezeichnet), PDF mit Karte', async () => {
  const c = await neu();
  const id = await reiseMitKarte(c);
  const S = MM.Reisebuch.SCHALTER.map((x) => x.key);
  assert.ok(S.includes('uebersichtskarte') && S.includes('tageskarten'));
  assert.equal(MM.Reisebuch.optionen(null).uebersichtskarte, false);
  assert.equal(MM.Reisebuch.vorlage('tagebuch').optionen.uebersichtskarte, true); assert.equal(MM.Reisebuch.vorlage('logbuch').optionen.tageskarten, true);
  assert.equal(MM.Reisebuch.vorlage('zahlen').optionen.tageskarten, false);
  const roh = await c.d.reisebuchLaden(id);
  const buch = MM.Reisebuch.bauen(roh, { uebersichtskarte: true, tageskarten: true }, {});
  assert.equal(buch.uebersichtskarte, true); assert.equal(buch.tage[0].karte, true); assert.ok(buch.tage[0].tagId);
  assert.equal(MM.Reisebuch.bauen(roh, {}, {}).uebersichtskarte, false);
  const opt = { leinwand: falscheLeinwand([]), bildLaden: async () => ({}), hole: async () => ({ size: 1 }) };
  const k = await c.d.reisebuchKarten(id, Object.assign({ reise: true, tageIds: [buch.tage[0].tagId] }, opt));
  assert.ok(k.reise && k.reise.bytes); assert.ok(k.tage[buch.tage[0].tagId]); assert.equal(k.ohneBild, 0);
  /* gespeichert: ohne Zeichenfläche kommt trotzdem das gespeicherte Bild, „neu“ ohne Zeichenfläche gibt keins */
  const nurGespeichert = await c.d.reisebuchKarten(id, { reise: true, tageIds: [] });
  assert.ok(nurGespeichert.reise);
  const neuOhne = await c.d.reisebuchKarten(id, { reise: true, tageIds: [], neu: true, leinwand: () => null });
  assert.equal(neuOhne.reise, null); assert.equal(neuOhne.ohneBild, 1);
  /* PDF mit der Karte */
  const pdf = await c.d.reisebuchPdf(id, { uebersichtskarte: true, tageskarten: true }, opt);
  assert.equal(pdf.ok, true, JSON.stringify(pdf));
  assert.equal(pdf.karten, 2); assert.equal(pdf.ohneKarte, 0);
  const text = Buffer.from(pdf.bytes).toString('latin1');
  assert.match(text, /\/Subtype \/Image/);
  /* ohne Zeichenfläche und ohne gespeichertes Bild steht ein Hinweis statt einer Karte */
  const c2 = await neu(); const id2 = await reiseMitKarte(c2);
  const pdf2 = await c2.d.reisebuchPdf(id2, { uebersichtskarte: true }, { leinwand: () => null });
  assert.equal(pdf2.ok, true); assert.equal(pdf2.karten, 0); assert.equal(pdf2.ohneKarte, 1);
});

test('Karten im Reisetagebuch: Code verdrahtet (Seite, PDF, Tagesabschluss, Ablage in der Sicherung)', () => {
  const a = lesen('js/ansicht.js'), d = lesen('js/daten.js'), idx = lesen('index.html'), sw = lesen('sw.js');
  assert.ok(a.includes('reisebuchKarten(id, { ablage: ablage()') && a.includes('Karten neu zeichnen') && a.includes('kartenbildErzeugen(a.aktivitaet.id, id'));
  assert.ok(d.includes("'karte:' + aktivitaetId") && d.includes("speichern('ereignisdateien'"));
  assert.ok(idx.includes('js/kartenbild.js') && sw.includes('js/kartenbild.js'));
  assert.ok(idx.indexOf('js/kartenbild.js') < idx.indexOf('js/kartenansicht.js'));
});
