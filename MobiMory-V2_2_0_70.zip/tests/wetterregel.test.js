'use strict';
/* Schritt 9d (2.0.36): Abstand der Wetterpunkte einstellbar (nach km, sm oder Fahrzeit), Voreinstellung wie in V1. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/routen.js');
require('../js/daten.js');
const MM = globalThis.MM, R = MM.Routen;

const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
/* Eine gerade Route nach Norden, etwa 44,4 km lang. */
const GPX = `<gpx><metadata><name>Rhein Törn</name></metadata><rte>
<rtept lat="48.0" lon="8.0"><name>Start</name></rtept><rtept lat="48.2" lon="8.0"/><rtept lat="48.4" lon="8.0"><name>Ziel</name></rtept></rte></gpx>`;

function punkteAusGpx() { return R.lesen(GPX, 'x.gpx').punkte; }
const kmListe = m => m.map(p => p.km);
const abstaende = m => m.slice(1).map((p, i) => Math.round((p.km - m[i].km) * 10) / 10);

/* ---------- reine Regel ---------- */
test('Voreinstellung wie in V1: Wasser alle 10 sm, sonst jede Stunde', () => {
  assert.deepEqual(R.wetterRegelStandard('wasser'), { art: 'strecke', abstand: 10, einheit: 'sm' });
  assert.deepEqual(R.wetterRegelStandard('land'), { art: 'zeit', abstand: 1, einheit: 'h' });
  assert.equal(R.regelText(R.wetterRegelStandard('wasser')), 'alle 10 sm');
  assert.equal(R.regelText(R.wetterRegelStandard('land')), 'jede Stunde');
  assert.equal(R.regelText({ art: 'zeit', abstand: 2, einheit: 'h' }), 'alle 2 Stunden');
  assert.equal(R.regelText({ art: 'strecke', abstand: 7.5, einheit: 'km' }), 'alle 7,5 km');
});

test('Regel aus den Angaben der Route: leer oder unsinnig gilt die Voreinstellung, Einheit passt zur Art', () => {
  assert.deepEqual(R.wetterRegel({}, 'wasser'), R.wetterRegelStandard('wasser'));
  assert.deepEqual(R.wetterRegel(null, 'land'), R.wetterRegelStandard('land'));
  assert.deepEqual(R.wetterRegel({ wetterArt: 'strecke', wetterAbstand: 0, wetterEinheit: 'km' }, 'land'), R.wetterRegelStandard('land'));
  assert.deepEqual(R.wetterRegel({ wetterArt: 'blabla', wetterAbstand: 5, wetterEinheit: 'km' }, 'land'), R.wetterRegelStandard('land'));
  assert.deepEqual(R.wetterRegel({ wetterArt: 'strecke', wetterAbstand: 25, wetterEinheit: 'km' }, 'wasser'), { art: 'strecke', abstand: 25, einheit: 'km' });
  assert.deepEqual(R.wetterRegel({ wetterArt: 'strecke', wetterAbstand: 5, wetterEinheit: 'sm' }, 'wasser'), { art: 'strecke', abstand: 5, einheit: 'sm' });
  assert.deepEqual(R.wetterRegel({ wetterArt: 'zeit', wetterAbstand: 2, wetterEinheit: 'km' }, 'wasser'), { art: 'zeit', abstand: 2, einheit: 'h' }, 'bei Fahrzeit immer Stunden');
});

test('Abstand in Kilometern: km, sm (1,852 km) und Fahrzeit mal Geschwindigkeit, mindestens 100 m', () => {
  assert.equal(R.regelSchrittKm({ art: 'strecke', abstand: 10, einheit: 'km' }, 20), 10);
  assert.ok(Math.abs(R.regelSchrittKm({ art: 'strecke', abstand: 10, einheit: 'sm' }, 20) - 18.52) < 1e-9);
  assert.equal(R.regelSchrittKm({ art: 'zeit', abstand: 2, einheit: 'h' }, 15), 30);
  assert.equal(R.regelSchrittKm({ art: 'strecke', abstand: 0.01, einheit: 'km' }, 20), 0.1);
});

/* ---------- Messpunkte mit Regel ---------- */
test('Messpunkte nach Entfernung: gleiche Abstände, Start vorn, Ziel hinten, Zeit je Punkt aus der Geschwindigkeit', () => {
  const pts = punkteAusGpx();
  const m = R.messpunkte(pts, 10, 'kmh', { art: 'strecke', abstand: 10, einheit: 'km' });
  assert.equal(m[0].km, 0); assert.equal(m[0].name, 'Start');
  assert.equal(m[m.length - 1].name, 'Ziel');
  assert.ok(Math.abs(m[m.length - 1].km - pts[pts.length - 1].km) < 0.01);
  abstaende(m).slice(0, -1).forEach(a => assert.equal(a, 10, 'Abstand ' + a));
  assert.deepEqual(m.map(p => p.nr), m.map((_, i) => i + 1));
  m.forEach(p => assert.equal(p.minuten, Math.round(p.km / 10 * 60)));
});

test('Messpunkte nach Fahrzeit: alle x Stunden entspricht Geschwindigkeit mal Stunden', () => {
  const pts = punkteAusGpx();
  const eine = R.messpunkte(pts, 10, 'kmh', { art: 'zeit', abstand: 1, einheit: 'h' });
  const zehn = R.messpunkte(pts, 10, 'kmh', { art: 'strecke', abstand: 10, einheit: 'km' });
  assert.deepEqual(kmListe(eine), kmListe(zehn));
  const zwei = R.messpunkte(pts, 10, 'kmh', { art: 'zeit', abstand: 2, einheit: 'h' });
  abstaende(zwei).slice(0, -1).forEach(a => assert.equal(a, 20));
  assert.ok(zwei.length < eine.length);
  const halb = R.messpunkte(pts, 10, 'kmh', { art: 'zeit', abstand: 0.5, einheit: 'h' });
  abstaende(halb).slice(0, -1).forEach(a => assert.equal(a, 5));
});

test('Messpunkte in Seemeilen: 5 sm sind 9,26 km, das Boot rechnet mit Knoten', () => {
  const pts = punkteAusGpx();
  const m = R.messpunkte(pts, 10, 'kn', { art: 'strecke', abstand: 5, einheit: 'sm' });
  abstaende(m).slice(0, -1).forEach(a => assert.ok(Math.abs(a - 9.3) < 0.06, 'Abstand ' + a));
  /* zeitlich: 10 kn = 18,52 km/h, 5 sm in 30 Minuten */
  assert.equal(m[1].minuten, 30);
});

test('Ohne Regel bleibt die alte Berechnung (höchstens 12 Punkte), mit sehr engem Abstand höchstens 24', () => {
  const pts = punkteAusGpx();
  assert.ok(R.messpunkte(pts, 10, 'kmh').length <= R.MAX_MESSPUNKTE);
  const eng = R.messpunkte(pts, 10, 'kmh', { art: 'strecke', abstand: 1, einheit: 'km' });
  assert.equal(eng.length, R.MAX_MESSPUNKTE_REGEL);
  assert.equal(eng[0].name, 'Start'); assert.equal(eng[eng.length - 1].name, 'Ziel', 'Start und Ziel bleiben immer');
});

test('Benannte Wegpunkte bleiben mit Regel erhalten', () => {
  const gpx = `<gpx><rte><rtept lat="48.0" lon="8.0"><name>Start</name></rtept><rtept lat="48.2" lon="8.0"><name>Schleuse</name></rtept><rtept lat="48.4" lon="8.0"><name>Ziel</name></rtept></rte></gpx>`;
  const pts = R.lesen(gpx, 'x.gpx').punkte;
  const m = R.messpunkte(pts, 10, 'kmh', { art: 'strecke', abstand: 15, einheit: 'km' });
  assert.ok(m.some(p => p.name === 'Schleuse'), 'Schleuse ist ein Wetterpunkt');
  assert.deepEqual(R.messpunkte(pts, null, 'kmh', { art: 'strecke', abstand: 15, einheit: 'km' }), [], 'ohne Geschwindigkeit keine Punkte');
});

/* ---------- Daten ---------- */
function netz() {
  const t0 = Math.floor(Date.UTC(2026, 10, 3, 0, 0) / 1000);
  const zeiten = []; for (let i = 0; i < 16 * 24; i++) zeiten.push(t0 + i * 3600);
  const aufrufe = [];
  async function holeJson(url) {
    aufrufe.push(url);
    if (url.includes('marine-api')) return { hourly: { time: zeiten, wave_height: zeiten.map(() => 0.8), wave_direction: zeiten.map(() => 270), wave_period: zeiten.map(() => 5), sea_level_height_msl: zeiten.map(() => 0.5) } };
    return { hourly: { time: zeiten, temperature_2m: zeiten.map(() => 9), precipitation: zeiten.map(() => 0), precipitation_probability: zeiten.map(() => 10),
      wind_speed_10m: zeiten.map(() => 12), wind_gusts_10m: zeiten.map(() => 20), wind_direction_10m: zeiten.map(() => 225), weather_code: zeiten.map(() => 3) } };
  }
  return { holeJson, aufrufe };
}
async function neu() {
  let t = 0;
  const n = netz();
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(), holeJson: n.holeJson });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = x => arten.find(a => a.aktuell.werte.bezeichnung === x).objekt.id;
  return { d, boot, wm, anna, artId, netz: n };
}
async function route(c, fahrzeug, artName, ges, einheit) {
  const r = await c.d.aktivitaetAnlegen({ bezeichnung: 'Fahrt', artId: c.artId(artName), fahrzeugId: fahrzeug, vonDatum: '2026-11-05', vonZeit: '08:00', bisDatum: '2026-11-06', verantwortlichId: c.anna });
  assert.equal(r.ok, true, JSON.stringify(r));
  const ro = await c.d.routeImportieren(r.id, GPX, 'x.gpx');
  assert.equal(ro.ok, true);
  const ae = await c.d.routeAendern(ro.id, { bezeichnung: 'Rhein Törn', geschwindigkeit: ges, einheit: einheit, abfahrtDatum: '2026-11-05', abfahrtZeit: '08:00' });
  assert.equal(ae.ok, true, JSON.stringify(ae));
  return { aktId: r.id, routeId: ro.id };
}
const regelFelder = (art, abstand, einheit) => ({ wetterArt: art, wetterAbstand: abstand, wetterEinheit: einheit });
const aendern = (c, x, extra) => c.d.routeAendern(x.routeId, Object.assign({ bezeichnung: 'Rhein Törn', geschwindigkeit: '10', einheit: 'kn', abfahrtDatum: '2026-11-05', abfahrtZeit: '08:00' }, extra));

test('Ohne eigene Eingabe gilt die Voreinstellung nach Fahrzeugart: Boot 10 sm, Wohnmobil jede Stunde', async () => {
  const c = await neu();
  const b = await route(c, c.boot, 'Törn', '10', 'kn');
  let a = await c.d.routeAnsicht(b.aktId);
  assert.deepEqual(a.route.wetterRegel, { art: 'strecke', abstand: 10, einheit: 'sm' });
  assert.equal(a.route.regelEigene, false);
  const w = await route(c, c.wm, 'Ausfahrt', '60', 'kmh');
  a = await c.d.routeAnsicht(w.aktId);
  assert.deepEqual(a.route.wetterRegel, { art: 'zeit', abstand: 1, einheit: 'h' });
  assert.equal(a.route.regelEigene, false);
  /* Wohnmobil 60 km/h, 44 km Route, jede Stunde = alle 60 km: nur Start und Ziel */
  assert.equal(a.route.messpunkte.length, 2);
});

test('Eigene Regel speichern: sie gilt für die Punkte, die Route selbst bleibt unverändert', async () => {
  const c = await neu();
  const b = await route(c, c.boot, 'Törn', '10', 'kn');
  const vorher = await c.d.routeAnsicht(b.aktId);
  const r = await aendern(c, b, regelFelder('strecke', '5', 'sm'));
  assert.equal(r.ok, true, JSON.stringify(r));
  const a = await c.d.routeAnsicht(b.aktId);
  assert.deepEqual(a.route.wetterRegel, { art: 'strecke', abstand: 5, einheit: 'sm' });
  assert.equal(a.route.regelEigene, true);
  assert.ok(a.route.messpunkte.length > vorher.route.messpunkte.length, 'mehr Punkte bei engerem Abstand');
  assert.deepEqual(a.route.punkte, vorher.route.punkte, 'die Punkte der Route sind dieselben');
  assert.equal(a.route.laengeKm, vorher.route.laengeKm);
  const l = await c.d.routeAendern(b.routeId, { bezeichnung: 'Rhein Törn', geschwindigkeit: '10', einheit: 'kn', abfahrtDatum: '2026-11-05', abfahrtZeit: '08:00', wetterArt: 'zeit', wetterAbstand: '0,5', wetterEinheit: 'h' });
  assert.equal(l.ok, true);
  assert.deepEqual((await c.d.routeAnsicht(b.aktId)).route.wetterRegel, { art: 'zeit', abstand: 0.5, einheit: 'h' });
  /* zurück auf die Voreinstellung */
  assert.equal((await aendern(c, b, regelFelder('', '', ''))).ok, true);
  const z = await c.d.routeAnsicht(b.aktId);
  assert.equal(z.route.regelEigene, false);
  assert.deepEqual(z.route.wetterRegel, { art: 'strecke', abstand: 10, einheit: 'sm' });
});

test('Prüfungen der Regel: Art und Abstand gehören zusammen, größer als 0, passende Einheit', async () => {
  const c = await neu();
  const b = await route(c, c.boot, 'Törn', '10', 'kn');
  assert.ok((await aendern(c, b, regelFelder('', '5', 'km'))).fehler.wetterArt, 'Abstand ohne Art');
  assert.ok((await aendern(c, b, regelFelder('strecke', '', 'km'))).fehler.wetterAbstand, 'Art ohne Abstand');
  assert.ok((await aendern(c, b, regelFelder('strecke', '0', 'km'))).fehler.wetterAbstand, 'Abstand 0');
  assert.ok((await aendern(c, b, regelFelder('strecke', '-3', 'km'))).fehler.wetterAbstand, 'negativ');
  assert.ok((await aendern(c, b, regelFelder('strecke', 'viel', 'km'))).fehler.wetterAbstand, 'keine Zahl');
  assert.ok((await aendern(c, b, regelFelder('strecke', '5', ''))).fehler.wetterEinheit, 'Entfernung ohne Einheit');
  assert.ok((await aendern(c, b, regelFelder('strecke', '5', 'h'))).fehler.wetterEinheit, 'Entfernung in Stunden');
  assert.ok((await aendern(c, b, regelFelder('strecke', '0,05', 'km'))).fehler.wetterAbstand, 'unter 100 m');
  assert.ok((await aendern(c, b, regelFelder('zeit', '0,01', 'h'))).fehler.wetterAbstand, 'unter 0,1 Stunden');
  assert.equal((await aendern(c, b, regelFelder('zeit', '1,5', ''))).ok, true, 'bei Fahrzeit ist die Einheit immer Stunden');
  assert.deepEqual((await c.d.routeAnsicht(b.aktId)).route.wetterRegel, { art: 'zeit', abstand: 1.5, einheit: 'h' });
});

test('Wetter holen: so viele Anfragen wie Wetterpunkte der Regel, Änderung der Regel macht den Stand veraltet', async () => {
  const c = await neu();
  const b = await route(c, c.wm, 'Ausfahrt', '40', 'kmh');
  assert.equal((await aendern(c, b, Object.assign({ geschwindigkeit: '40', einheit: 'kmh' }, regelFelder('strecke', '10', 'km')))).ok, true);
  const n = (await c.d.routeAnsicht(b.aktId)).route.messpunkte.length;
  assert.ok(n >= 5);
  const x = await c.d.wetterAbrufen(b.aktId);
  assert.equal(x.ok, true, JSON.stringify(x));
  assert.equal(x.punkte, n);
  assert.equal(c.netz.aufrufe.length, n, 'eine Wetteranfrage je Punkt (Land, keine Tide)');
  let s = await c.d.wetterStand(b.aktId);
  assert.equal(s.ok, true); assert.equal(s.aktuell, true); assert.equal(s.zeilen.length, n);
  /* anderer Abstand: der geholte Stand gehört nicht mehr zur Regel */
  assert.equal((await aendern(c, b, Object.assign({ geschwindigkeit: '40', einheit: 'kmh' }, regelFelder('strecke', '20', 'km')))).ok, true);
  s = await c.d.wetterStand(b.aktId);
  assert.equal(s.aktuell, false, 'Abstand geändert, Wetter muss neu geholt werden');
  const y = await c.d.wetterAbrufen(b.aktId);
  assert.ok(y.punkte < n);
  assert.equal((await c.d.wetterStand(b.aktId)).aktuell, true);
});

test('Ein Wetterstand ohne Regel (aus 2.0.34) gilt nicht mehr als aktuell', async () => {
  const c = await neu();
  const b = await route(c, c.wm, 'Ausfahrt', '40', 'kmh');
  await c.d.wetterAbrufen(b.aktId);
  const dok = await c.d.einstellungLesen('wetter-' + b.routeId);
  assert.ok(dok.regel, 'die Regel wird mitgespeichert');
  delete dok.regel;
  await c.d.einstellungSchreiben(dok);
  assert.equal((await c.d.wetterStand(b.aktId)).aktuell, false);
});

test('Die Regel steht im Verlauf der Route und kommt mit der Sicherung zurück', async () => {
  const c = await neu();
  const b = await route(c, c.boot, 'Törn', '10', 'kn');
  await aendern(c, b, regelFelder('strecke', '5', 'sm'));
  const rl = await c.d.routeLaden(b.routeId);
  assert.equal(rl.aktuell.werte.wetterArt, 'strecke'); assert.equal(rl.aktuell.werte.wetterAbstand, 5); assert.equal(rl.aktuell.werte.wetterEinheit, 'sm');
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  const b2 = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => JETZT });
  await b2.starten();
  await b2.sicherungEinspielen(await b2.sicherungLesen(s.bytes, ''));
  assert.deepEqual((await b2.routeAnsicht(b.aktId)).route.wetterRegel, { art: 'strecke', abstand: 5, einheit: 'sm' });
});

test('Alte Routen ohne die neuen Angaben (aus 2.0.35) funktionieren mit der Voreinstellung', async () => {
  const c = await neu();
  const b = await route(c, c.boot, 'Törn', '10', 'kn');
  const rl = await c.d.routeLaden(b.routeId);
  const alt = Object.assign({}, rl.aktuell.werte); delete alt.wetterArt; delete alt.wetterAbstand; delete alt.wetterEinheit;
  rl.aktuell.werte = alt;
  assert.deepEqual(R.wetterRegel(alt, 'wasser'), { art: 'strecke', abstand: 10, einheit: 'sm' });
  assert.equal(R.messpunkte(punkteAusGpx(), 10, 'kn', R.wetterRegel(alt, 'wasser')).length > 1, true);
});

test('Version und „Neu im Programm“ passen zusammen', () => {
  assert.equal(MM.VERSION, '2.0.70');
  require('../js/texte.js');
  assert.equal(MM.Texte.NEUERUNGEN[0].version, MM.VERSION);
});
