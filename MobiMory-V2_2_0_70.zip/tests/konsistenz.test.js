'use strict';
/* Prüft, dass Versionsnummer, Änderungsliste und Dateiliste zusammenpassen.
   So bleibt "eine Quelle" auch bei den Begleitdateien wahr. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/texte.js');
const MM = globalThis.MM;
const wurzel = path.join(__dirname, '..');
const lesen = f => fs.readFileSync(path.join(wurzel, f), 'utf8');

test('Neueste Version in "Neu im Programm" ist die aktuelle Version', () => {
  assert.equal(MM.Texte.NEUERUNGEN[0].version, MM.VERSION);
});

test('Versionen in "Neu im Programm" sind eindeutig und absteigend', () => {
  const v = MM.Texte.NEUERUNGEN.map(n => n.version.split('.').map(Number));
  for (let i = 1; i < v.length; i++) {
    const a = v[i - 1], b = v[i];
    const groesser = a[0] !== b[0] ? a[0] > b[0] : a[1] !== b[1] ? a[1] > b[1] : a[2] > b[2];
    assert.ok(groesser, 'Reihenfolge falsch bei ' + v[i].join('.'));
  }
});

test('CHANGELOG und package.json nennen die aktuelle Version', () => {
  assert.ok(lesen('CHANGELOG.md').includes('## ' + MM.VERSION), 'CHANGELOG.md fehlt der Abschnitt ' + MM.VERSION);
  assert.equal(JSON.parse(lesen('package.json')).version, MM.VERSION);
});

test('Alle Dateien aus index.html liegen im Offline-Speicher (sw.js) und existieren', () => {
  const html = lesen('index.html');
  const sw = lesen('sw.js');
  const dateien = [...html.matchAll(/(?:src|href)="([^"#]+)"/g)].map(m => m[1])
    .filter(f => !/^https?:/.test(f));
  assert.ok(dateien.length >= 8);
  dateien.forEach(f => {
    assert.ok(fs.existsSync(path.join(wurzel, f)), f + ' fehlt');
    assert.ok(sw.includes("'" + f + "'"), f + ' fehlt in sw.js');
  });
});

test('Kernsatz, Infotext und Copyright sind gesetzt', () => {
  assert.equal(MM.Texte.KERNSATZ.split('. ').length, 3);
  assert.ok(MM.Texte.COPYRIGHT.includes('Ralph Hasslacher'));
  assert.ok(MM.Texte.INFOTEXT.length > 20);
});

test('Die Versionsnummer in sw.js passt zu js/version.js', () => {
  const m = /var VERSION = '([^']+)'/.exec(lesen('sw.js'));
  assert.ok(m, 'sw.js nennt keine VERSION');
  assert.equal(m[1], MM.VERSION);
});
