'use strict';
/* 2.0.65 (Schritt 13b): Abgleich, reine Rechnung. Was zum Dienst geht, was lokal bleibt, Zusammenführen, Nummern im Verlauf. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
require('../js/abgleich.js');
const MM = globalThis.MM, A = MM.Abgleich;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

test('Lokale Schlüssel werden in jeder Tiefe entfernt, das Datenraum-Kennzeichen wird zu @', () => {
  const rec = { id: 'fz-1', datenraumId: 'dr-1', art: 'boot', abgabe: { datum: '2026-01-01', notiz: 'privat' }, liste: [{ x: 1, telefon: '123' }] };
  const x = A.fuerDienst('fahrzeuge', rec, 'dr-1');
  const o = JSON.parse(x.nutzlast);
  assert.equal(o.datenraumId, '@');
  assert.ok(!('notiz' in o.abgabe) && !('telefon' in o.liste[0]));
  assert.ok(!x.nutzlast.includes('privat') && !x.nutzlast.includes('123'));
  assert.equal(o.abgabe.datum, '2026-01-01');
  assert.deepEqual(rec.abgabe, { datum: '2026-01-01', notiz: 'privat' }, 'die lokale Fassung bleibt unverändert');
});

test('Nur die festgelegten Tabellen gehen hinaus, Einstellungen, Standorte und Anforderungen nicht (seit 2.0.66 auch Kosten, Dokumente, Routen und Nachweise)', () => {
  ['einstellungen', 'standorte', 'anforderungen', 'datenraeume', 'unbekannt'].forEach((t) => {
    assert.equal(A.fuerDienst(t, { id: 'x-1' }, 'dr-1'), null, t);
  });
  ['fahrzeuge', 'fristen', 'aktivitaeten', 'ereignisse', 'zaehler', 'tagespruefungen',
    'kosten', 'kostenstamm', 'kostenarten', 'zahlungsmittel', 'kassen', 'kassenbuchungen', 'routen', 'besuche', 'reisechecks',
    'dokumente', 'dateien', 'ereignisdateien', 'nachweisdateien', 'nachweisarten', 'nachweise'].forEach((t) => assert.ok(A.fuerDienst(t, { id: 'x-1' }, 'dr-1'), t));
});

test('Verläufe: nur die festgelegten Typen, Person, Tier und Adresse nur mit öffentlichen Angaben', () => {
  const v = (typ, werte) => A.fuerDienst('verlaeufe', { id: 'vl-1', objektTyp: typ, objektId: 'o-1', nr: 1, werte, quelle: 'hand', korrekturZu: null, erstelltAm: 'x' }, 'dr-1');
  assert.equal(v('fahrzeugstandort', { ort: 'x' }), null);
  assert.equal(v('unbekannt', {}), null);
  /* seit 2.0.66: Kosten, Routen und Besuche mit allen Angaben außer den lokalen Schlüsseln */
  assert.deepEqual(JSON.parse(v('kosten', { betrag: 5, notiz: 'n' }).nutzlast).werte, { betrag: 5 });
  assert.ok(v('route', { bezeichnung: 'R' }));
  /* Vom Nachweis gehen nur Gültigkeit und Dateiangaben hinaus, nie Nummer, Aussteller, Klassen und Notiz */
  assert.deepEqual(JSON.parse(v('nachweis', { gueltigBis: '2030-01-01', ausgestelltAm: '2020-01-01', nummer: 'B123', aussteller: 'Amt', klassen: 'B', notiz: 'n', dateiName: 'a.jpg', dateiTyp: 'image/jpeg', dateiGroesse: 5 }).nutzlast).werte,
    { ausgestelltAm: '2020-01-01', gueltigBis: '2030-01-01', dateiName: 'a.jpg', dateiTyp: 'image/jpeg', dateiGroesse: 5 });
  const p = JSON.parse(v('person', { bezeichnung: 'Anna', funktionen: ['Skipper'], email: 'a@b.de', telefon: '1', notiz: 'n', geburtsdatum: '1990-01-01', irgendwas: 'x' }).nutzlast);
  assert.deepEqual(p.werte, { bezeichnung: 'Anna', funktionen: ['Skipper'] });
  const t = JSON.parse(v('tier', { bezeichnung: 'Rex', tierart: 'Hund', chipnummer: '123456789012345' }).nutzlast);
  assert.deepEqual(t.werte, { bezeichnung: 'Rex', tierart: 'Hund' });
  const ad = JSON.parse(v('adresse', { bezeichnung: 'Werft', art: 'werkstatt', plz: '74372', ort: 'Sersheim', land: 'DE', telefon: '1', ansprechpartner: 'X' }).nutzlast);
  assert.deepEqual(ad.werte, { bezeichnung: 'Werft', art: 'werkstatt', plz: '74372', ort: 'Sersheim', land: 'DE' });
  const o = JSON.parse(v('ort', { bezeichnung: 'Hafen', land: 'Kroatien', positionBreite: '1', adresse: 'Hafenstr. 1', ansprechpartner: 'Hafenmeister', telefon: '1', notiz: 'n' }).nutzlast);
  assert.deepEqual(o.werte, { bezeichnung: 'Hafen', land: 'Kroatien', positionBreite: '1' });
  const f = JSON.parse(v('frist', { bezeichnung: 'HU', notiz: 'n' }).nutzlast);
  assert.deepEqual(f.werte, { bezeichnung: 'HU' });
});

test('Prüfergebnis: nur Ergebnis, geprüft am, Tagesbeginn und Zahlen gehen hinaus, ohne Namen und Gründe', () => {
  const stand = { geprueftAm: '2026-11-10T10:00:00Z', tagesbeginn: '08:00', verantwortlich: { personId: 'pe-1', name: 'Anna', ergebnis: 'erlaubt' },
    befaehigung: { ergebnis: 'erlaubt', gebiet: 'Rhein', gebietHinweis: null, personen: [{ name: 'Anna', rolleText: 'Skipper', ergebnis: 'erlaubt', gruende: [{ ergebnis: 'erlaubt', text: 'Führerschein SBF' }] }] },
    ausruestung: { ergebnis: 'ok', liste: [{ bezeichnung: 'Weste', status: 'ok', text: 't' }] },
    fristen: { betroffen: 1, sperre: 0, eingeschraenkt: 1, liste: [{ bezeichnung: 'HU', status: 'faellig', text: 'HU fällig' }], gesamt: 3 } };
  const rec = { id: 'tp-1', datenraumId: 'dr-1', aktivitaetId: 'ak-1', abschnittId: 'tg-1', stand, erstelltAm: 'x' };
  const x = A.fuerDienst('tagespruefungen', rec, 'dr-1');
  assert.ok(!/Anna|Führerschein|Rhein|Weste|HU/.test(x.nutzlast), x.nutzlast);
  const o = JSON.parse(x.nutzlast);
  assert.deepEqual(o.stand, { geprueftAm: '2026-11-10T10:00:00Z', tagesbeginn: '08:00', ergebnis: 'erlaubt', fristen: { betroffen: 1, sperre: 0, eingeschraenkt: 1 } });
  /* Auf dem zweiten Gerät bekommen die Seiten wieder die gewohnte Form */
  const dort = A.vonDienst('tagespruefungen', x.nutzlast, 'dr-2', null);
  assert.equal(dort.datenraumId, 'dr-2');
  assert.equal(dort.stand.befaehigung.ergebnis, 'erlaubt'); assert.deepEqual(dort.stand.befaehigung.personen, []); assert.equal(dort.stand.ausruestung, null); assert.deepEqual(dort.stand.fristen.liste, []);
  /* Auf dem eigenen Gerät bleibt die ausführliche Fassung, solange sich das Ergebnis nicht ändert */
  assert.deepEqual(A.vonDienst('tagespruefungen', x.nutzlast, 'dr-1', rec).stand, stand);
});

test('Zu große Datensätze bleiben lokal und werden gemeldet', () => {
  const x = A.fuerDienst('ereignisse', { id: 'er-1', text: 'a'.repeat(A.MAX_NUTZLAST + 10) }, 'dr-1');
  assert.equal(x.zuGross, true);
});

test('Kanonischer Text: gleiche Daten, gleiche Reihenfolge der Schlüssel egal, gleicher Abdruck', () => {
  const a = A.fuerDienst('fahrzeuge', { id: 'fz-1', art: 'boot', erstelltAm: 'x', datenraumId: 'd' }, 'd');
  const b = A.fuerDienst('fahrzeuge', { erstelltAm: 'x', datenraumId: 'd', art: 'boot', id: 'fz-1' }, 'd');
  assert.equal(a.nutzlast, b.nutzlast); assert.equal(a.abdruck, b.abdruck);
  const c = A.fuerDienst('fahrzeuge', { id: 'fz-1', art: 'auto', erstelltAm: 'x', datenraumId: 'd' }, 'd');
  assert.notEqual(a.abdruck, c.abdruck);
});

test('Vom Dienst zurück: lokale Felder der eigenen Fassung werden wieder eingesetzt, auch verschachtelt', () => {
  const eigene = { id: 'fz-1', datenraumId: 'dr-1', art: 'boot', abgabe: { datum: '2026-01-01', notiz: 'privat' }, liste: [{ x: 1, telefon: '123' }, { x: 2 }] };
  const x = A.fuerDienst('fahrzeuge', Object.assign({}, eigene, { art: 'auto' }), 'dr-1');
  const neu = A.vonDienst('fahrzeuge', x.nutzlast, 'dr-1', eigene);
  assert.equal(neu.art, 'auto'); assert.equal(neu.abgabe.notiz, 'privat'); assert.equal(neu.liste[0].telefon, '123'); assert.equal(neu.datenraumId, 'dr-1');
  const ohne = A.vonDienst('fahrzeuge', x.nutzlast, 'dr-9', null);
  assert.equal(ohne.datenraumId, 'dr-9'); assert.ok(!('notiz' in ohne.abgabe));
});

test('Doppelte Nummern im Verlauf: nach der Zeit neu vergeben, nichts geht verloren, ohne Doppelte bleibt alles', () => {
  const e = (id, nr, zeit, obj) => ({ id, objektTyp: 'frist', objektId: obj || 'fr-1', nr, werte: {}, erstelltAm: zeit });
  const ok = [e('a', 1, '2026-01-01'), e('b', 2, '2026-01-02')];
  assert.deepEqual(A.nummernNeu(ok), []);
  /* Gerät 1 und Gerät 2 haben beide Nummer 2 vergeben, Gerät 2 danach noch Nummer 3 */
  const l = [e('a', 1, '2026-01-01T10:00'), e('g1', 2, '2026-01-02T12:00'), e('g2', 2, '2026-01-02T11:00'), e('g2b', 3, '2026-01-02T11:30'), e('x', 1, '2026-01-01', 'fr-2')];
  const neu = A.nummernNeu(l);
  const nach = {}; l.forEach((x) => { nach[x.id] = x.nr; }); neu.forEach((x) => { nach[x.id] = x.nr; });
  assert.deepEqual([nach.a, nach.g2, nach.g2b, nach.g1], [1, 2, 3, 4]);
  assert.equal(nach.x, 1, 'andere Objekte bleiben unberührt');
  /* Zweimal gerechnet ergibt dasselbe (beide Geräte kommen zum gleichen Ergebnis) */
  const nochmal = A.nummernNeu(l.map((x) => Object.assign({}, x, { nr: nach[x.id] })));
  assert.deepEqual(nochmal, []);
});

test('Base64 für die Teile der Sicherung: Hin und zurück, auch bei großen Stücken', () => {
  const b = new Uint8Array(300000); for (let i = 0; i < b.length; i++) b[i] = (i * 7 + 3) % 256;
  const s = A.zuBase64(b);
  assert.ok(/^[A-Za-z0-9+/]+=*$/.test(s));
  assert.deepEqual(Array.from(A.ausBase64(s)), Array.from(b));
});

test('Zusammenfassung nach Datenart zählt und nennt die Art', () => {
  const z = A.zusammenfassung([{ tabelle: 'fahrzeuge' }, { tabelle: 'eintraege' }, { tabelle: 'fristen' }, { tabelle: 'verlaeufe' }]);
  assert.deepEqual(z.map((x) => [x.art, x.anzahl]), [['fahrzeuge', 2], ['fristen', 1], ['verlaeufe', 1]]);
});

test('Jede Tabelle des Abgleichs gibt es im Speicher, jeder Verlauf-Typ kommt im Programm vor', () => {
  require('../js/speicher.js');
  A.tabellenListe().forEach((t) => assert.ok(MM.Speicher.TABELLEN.includes(t), t));
  const daten = lesen('js/daten.js');
  A.VERLAUF_TYPEN.forEach((typ) => assert.ok(daten.includes("'" + typ + "'"), typ));
});

test('Programm und Dienst führen dieselben Listen (Schlüssel, Tabellen, Verlauf-Typen)', async () => {
  const d = await import('../server/konto-dienst.mjs');
  assert.deepEqual(d.LOKALE_SCHLUESSEL, A.LOKALE_SCHLUESSEL);
  assert.deepEqual([...d.ABGLEICH_TABELLEN].sort(), A.tabellenListe().sort());
  assert.deepEqual([...d.ABGLEICH_VERLAUF_TYPEN].sort(), [...A.VERLAUF_TYPEN].sort());
});

test('Modul ist in index.html (vor daten.js) und im Service Worker', () => {
  const idx = lesen('index.html');
  assert.ok(idx.includes('<script src="js/abgleich.js"></script>'));
  assert.ok(idx.indexOf('js/abgleich.js') < idx.indexOf('js/daten.js'));
  assert.ok(lesen('sw.js').includes("'js/abgleich.js'"));
});

test('13d: Datei-Angaben gehen ohne Inhalt hinaus, beim Zurückholen steht der Inhalt auf „fehlt“ oder bleibt, wie er war', () => {
  const blob = new Blob(['abc'], { type: 'image/jpeg' });
  const rec = { id: 'da-1', dokumentId: 'do-1', name: 'a.jpg', mime: 'image/jpeg', groesse: 3, inhalt: blob, erstelltAm: 'x' };
  ['dateien', 'ereignisdateien', 'nachweisdateien'].forEach((t) => {
    const x = A.fuerDienst(t, rec, 'dr-1');
    assert.ok(x); assert.ok(!x.nutzlast.includes('inhalt'));
    const neu = A.vonDienst(t, x.nutzlast, 'dr-2', null);
    assert.equal(neu.inhalt, null, 'neue Angabe ohne Datei');
    assert.equal(A.vonDienst(t, x.nutzlast, 'dr-2', rec).inhalt, blob, 'vorhandene Datei bleibt');
  });
  /* Der Inhalt ändert den Abdruck nicht: Eine geholte Datei löst keinen neuen Abgleich aus */
  assert.equal(A.fuerDienst('dateien', rec, 'dr-1').abdruck, A.fuerDienst('dateien', Object.assign({}, rec, { inhalt: null }), 'dr-1').abdruck);
  assert.deepEqual(A.DATEI_TABELLEN, ['dateien', 'nachweisdateien', 'ereignisdateien']);
  assert.deepEqual(A.VERSCHLUESSELTE_DATEIEN, ['nachweisdateien']);
});

test('13d: Im Reisecheck bleiben die Namen hinter den Decknamen auf dem Gerät, die Anfrage geht anonymisiert mit', () => {
  const rec = { id: 'rc-1', datenraumId: 'dr-1', aktivitaetId: 'ak-1', anfrage: { trip: { areas: [] } }, namen: { person1: 'Anna Muster' }, ergebnis: { x: 1 }, erstelltAm: 'x' };
  const x = A.fuerDienst('reisechecks', rec, 'dr-1');
  assert.ok(!x.nutzlast.includes('Anna Muster')); assert.ok(!x.nutzlast.includes('namen'));
  assert.deepEqual(A.vonDienst('reisechecks', x.nutzlast, 'dr-1', rec).namen, { person1: 'Anna Muster' });
  assert.deepEqual(A.vonDienst('reisechecks', x.nutzlast, 'dr-1', null).namen, {}, 'auf einem anderen Gerät ohne Namen, die Seite nimmt dann die Decknamen');
});
