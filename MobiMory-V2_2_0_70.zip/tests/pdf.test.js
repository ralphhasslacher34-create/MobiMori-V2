'use strict';
/* 2.0.37: PDF-Modul (Technik-Akte). */
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/version.js'); require('../js/pdf.js');
const P = globalThis.MM.Pdf;
const lat = b => Buffer.from(b).toString('latin1');

test('Breite: schmale Buchstaben sind schmaler, fett ist breiter, Umlaute wie ihr Grundbuchstabe', () => {
  assert.ok(P.breite('iii', 10) < P.breite('WWW', 10));
  assert.ok(P.breite('Hallo', 10, true) > P.breite('Hallo', 10, false));
  assert.equal(P.breite('ä', 10), P.breite('a', 10));
  assert.equal(P.breite('', 10), 0);
  assert.ok(Math.abs(P.breite('A', 1000) - 667) < 0.001);
});

test('Kodieren: Klammern und Schrägstrich geschützt, Umlaute und Euro in der Windows-Tabelle', () => {
  assert.equal(P.kodiert('a(b)c\\d'), 'a\\(b\\)c\\\\d');
  assert.equal(P.kodiert('ä'), '\\344'); assert.equal(P.kodiert('ß'), '\\337'); assert.equal(P.kodiert('€'), '\\200');
  assert.equal(P.kodiert('日'), '?');
  assert.equal(P.kodiert('a\nb'), 'a b');
});

test('Umbruch: keine Zeile ist breiter als erlaubt, auch nicht bei sehr langen Wörtern, Absätze bleiben', () => {
  const t = 'Das ist ein längerer Text mit Donaudampfschifffahrtsgesellschaftskapitänsmütze und noch mehr Wörtern dahinter';
  const z = P.umbrechen(t, 100, 10, false);
  assert.ok(z.length > 3);
  z.forEach(x => assert.ok(P.breite(x, 10) <= 100 + 0.01, x));
  assert.equal(z.join('').replace(/\s/g, ''), t.replace(/\s/g, ''), 'nichts geht verloren');
  assert.deepEqual(P.umbrechen('a\n\nb', 100, 10), ['a', '', 'b']);
  assert.deepEqual(P.umbrechen('', 100, 10), ['']);
});

function pruefeAufbau(bytes) {
  const s = lat(bytes);
  assert.ok(s.startsWith('%PDF-1.4')); assert.ok(s.endsWith('%%EOF\n'));
  const sx = Number(/startxref\n(\d+)\n/.exec(s)[1]);
  assert.equal(s.slice(sx, sx + 4), 'xref');
  const n = Number(/xref\n0 (\d+)\n/.exec(s)[1]);
  const zeilen = s.slice(sx).split('\n').slice(2, 2 + n);
  assert.equal(zeilen[0], '0000000000 65535 f ');
  for (let i = 1; i < n; i++) {
    const off = Number(zeilen[i].slice(0, 10));
    assert.equal(s.slice(off, off + (i + ' 0 obj').length), i + ' 0 obj', 'Objekt ' + i + ' liegt an der angegebenen Stelle');
  }
  return s;
}

test('Eine einfache Seite: gültiger Aufbau, Text steht drin, Fußzeile mit Seitenzahl', () => {
  const d = P.neu({ fuss: 'MobiMory Test', titel: 'Prüfung' });
  d.titel('Technik-Akte', 'Fahrzeug A'); d.abschnitt('Fahrzeug'); d.zeile('Bezeichnung', 'Seestern'); d.zeile('Leer', ''); d.absatz('Ein Absatz (mit Klammern).');
  const s = pruefeAufbau(d.bytes());
  assert.equal(d.seitenAnzahl(), 1);
  assert.ok(s.includes('(Technik-Akte) Tj') && s.includes('(Seestern) Tj') && s.includes('(Seite 1 von 1) Tj') && s.includes('(MobiMory Test) Tj'));
  assert.ok(s.includes('/Count 1'));
  assert.ok(s.includes('(Ein Absatz \\(mit Klammern\\).) Tj'));
});

test('Lange Tabelle: mehrere Seiten, Kopfzeile wiederholt sich, Seitenzahlen stimmen', () => {
  const d = P.neu({ fuss: 'x' });
  d.titel('T');
  const zeilen = []; for (let i = 0; i < 120; i++) zeilen.push(['0' + (i % 9 + 1) + '.01.2026', 'Vorgang ' + i + ' mit einem Text, der in der Zelle umbrechen muss, damit sie mehrzeilig wird', 'ok']);
  d.tabelle([{ titel: 'Datum', breite: 60 }, { titel: 'Was', breite: 0 }, { titel: 'Stand', breite: 40 }], zeilen);
  const n = d.seitenAnzahl();
  assert.ok(n >= 3);
  const s = pruefeAufbau(d.bytes());
  assert.equal((s.match(/\(Datum\) Tj/g) || []).length, n, 'die Kopfzeile steht auf jeder Seite');
  assert.ok(s.includes('(Seite ' + n + ' von ' + n + ') Tj'));
  assert.ok(s.includes('/Count ' + n));
  assert.ok(s.includes('(Vorgang 119'), 'die letzte Zeile ist dabei');
});

test('Nichts läuft über den Rand: keine Zeile beginnt außerhalb der Seite', () => {
  const d = P.neu({});
  d.absatz('Wort '.repeat(300));
  const s = lat(d.bytes());
  const pos = [...s.matchAll(/(-?[\d.]+) (-?[\d.]+) Td/g)].map(m => [Number(m[1]), Number(m[2])]);
  assert.ok(pos.length > 10);
  pos.forEach(([x, y]) => { assert.ok(x >= 0 && x < 595); assert.ok(y > 0 && y < 842); });
});
