'use strict';
/* Schritt 11c (2.0.41): „Habe ich unter anderem Namen“, die reinen Regeln. */
const test = require('node:test');
const assert = require('node:assert/strict');

['version', 'fahrzeugarten', 'komponenten', 'orte', 'reisecheck', 'grundcheck'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const O = MM.Orte, G = MM.Grundcheck;

const punkt = (name, menge, bezug, art) => ({ id: 'p' + name, name, menge, bezug, art: art || 'ausruestung', erklaerung: '', kategorie: 'Pflicht', vertrauen: 'hoch', widerspruch: false, quellen: [], stand: '' });
const setzen = (doc, p) => O.zuordnungSetzen(doc, Object.assign({ land: 'Frankreich', artId: 'boot', art: 'ausruestung', punkt: 'Persönliche Schwimmhilfe', ziel: 'Rettungsweste', jetzt: '2026-11-05T12:00:00.000Z' }, p || {}));

test('Schlüssel: Land, Art und Name ohne Klammern, Groß- und Kleinschreibung egal', () => {
  assert.equal(O.zuordnungSchluessel('Frankreich', 'boot', 'ausruestung', 'Persönliche Schwimmhilfe (EN ISO 12402)'), 'frankreich|boot|ausruestung|persönliche schwimmhilfe');
  assert.equal(O.zuordnungSchluessel(' FRANKREICH ', 'boot', 'ausruestung', ' persönliche   schwimmhilfe '), O.zuordnungSchluessel('Frankreich', 'boot', 'ausruestung', 'Persönliche Schwimmhilfe'));
  assert.notEqual(O.zuordnungSchluessel('Italien', 'boot', 'ausruestung', 'X'), O.zuordnungSchluessel('Frankreich', 'boot', 'ausruestung', 'X'));
  assert.notEqual(O.zuordnungSchluessel('Italien', 'boot', 'papier', 'X'), O.zuordnungSchluessel('Italien', 'boot', 'ausruestung', 'X'));
});

test('Setzen und Entfernen: neues Dokument, das alte bleibt unverändert, mehrere Namen je Punkt, keine Doppelten', () => {
  const leer = O.zuordnungenLeer();
  const a = setzen(leer);
  assert.equal(leer.eintraege.length, 0);
  assert.equal(a.id, 'zuordnungen'); assert.equal(a.eintraege.length, 1);
  assert.deepEqual(a.eintraege[0].namen, ['Rettungsweste']);
  assert.equal(a.eintraege[0].punkt, 'Persönliche Schwimmhilfe'); assert.equal(a.eintraege[0].bestaetigtAm, '2026-11-05T12:00:00.000Z');
  const b = setzen(setzen(a), { ziel: 'Auftriebsweste' });
  assert.equal(b.eintraege.length, 1); assert.deepEqual(b.eintraege[0].namen, ['Rettungsweste', 'Auftriebsweste']);
  const c = O.zuordnungEntfernen(b, { land: 'Frankreich', artId: 'boot', art: 'ausruestung', punkt: 'persönliche schwimmhilfe', ziel: 'Rettungsweste' });
  assert.deepEqual(c.eintraege[0].namen, ['Auftriebsweste']);
  const d = O.zuordnungEntfernen(c, { land: 'Frankreich', artId: 'boot', art: 'ausruestung', punkt: 'Persönliche Schwimmhilfe' });
  assert.equal(d.eintraege.length, 0);
  assert.equal(b.eintraege[0].namen.length, 2, 'das Ausgangsdokument bleibt unverändert');
});

test('Filter: gilt nur für das Land und die Fahrzeugart, nicht für andere', () => {
  let doc = setzen(O.zuordnungenLeer());
  doc = setzen(doc, { land: 'Italien', punkt: 'Giubbotto', ziel: 'Rettungsweste' });
  doc = setzen(doc, { artId: 'wohnmobil', punkt: 'Warnweste', ziel: 'Sicherheitsweste' });
  assert.equal(O.zuordnungenFuer(doc, 'frankreich', 'boot').length, 1);
  assert.equal(O.zuordnungenFuer(doc, 'Italien', 'boot').length, 1);
  assert.equal(O.zuordnungenFuer(doc, 'Deutschland', 'boot').length, 0);
  assert.equal(O.zuordnungenFuer(doc, 'Frankreich', 'segelboot').length, 0, 'genau diese Art, keine Obergruppe');
  const fr = O.zuordnungenFuer(doc, 'Frankreich', 'boot');
  assert.deepEqual(O.zuordnungNamen(fr, 'ausruestung', 'Persönliche Schwimmhilfe'), ['Rettungsweste']);
  assert.deepEqual(O.zuordnungNamen(fr, 'ausruestung', 'Giubbotto'), []);
  assert.deepEqual(O.zuordnungNamen(fr, 'papier', 'Persönliche Schwimmhilfe'), []);
  assert.deepEqual(O.zuordnungNamen(null, 'ausruestung', 'x'), []);
});

test('Komponenten: nur ein genau gleicher Name zählt, Anzahl und Eignungshaken bleiben, die Eingabe wird nicht verändert', () => {
  const komp = [{ name: 'Rettungsweste', anzahl: 4, geprueft: 'ja' }, { name: 'Rettungsweste Kind', anzahl: 2 }, { name: 'Feuerlöscher', anzahl: 1 }];
  const neu = O.komponentenMitZuordnung(komp, 'Persönliche Schwimmhilfe', ['rettungsweste']);
  assert.equal(neu[0].name, 'Persönliche Schwimmhilfe (Rettungsweste)'); assert.equal(neu[0].anzahl, 4); assert.equal(neu[0].geprueft, 'ja');
  assert.equal(neu[1].name, 'Rettungsweste Kind', 'ein Teilwort wird nicht geraten');
  assert.equal(komp[0].name, 'Rettungsweste');
  assert.equal(O.komponentenMitZuordnung(komp, 'Persönliche Schwimmhilfe', []), komp);
  /* Heißt die Komponente schon wie der Punkt, bleibt sie, wie sie ist. */
  const gleich = [{ name: 'Persönliche Schwimmhilfe Set', anzahl: 2 }];
  assert.equal(O.komponentenMitZuordnung(gleich, 'Persönliche Schwimmhilfe', ['Persönliche Schwimmhilfe Set'])[0].name, 'Persönliche Schwimmhilfe Set');
});

test('Grundcheck-Vergleich: ohne Zuordnung „fehlt“, mit Zuordnung wird gerechnet, nur für den bestätigten Namen', () => {
  const pt = punkt('Persönliche Schwimmhilfe', 1, 'person');
  const basis = { punkte: [pt], komponenten: [{ name: 'Rettungsweste', anzahl: 3 }, { name: 'Rettungsweste Kind', anzahl: 5 }], nachweise: [], plaetze: 4, fahrzeugId: 'f1' };
  const ohne = G.vergleichen(basis)[0];
  assert.equal(ohne.status, 'fehlt'); assert.deepEqual(ohne.zugeordnet, []);
  const mit = G.vergleichen(Object.assign({}, basis, { zuordnungen: O.zuordnungenFuer(setzen(O.zuordnungenLeer()), 'Frankreich', 'boot') }))[0];
  assert.equal(mit.status, 'zu_wenig'); assert.equal(mit.soll, 4); assert.equal(mit.ist, 3, 'nur die bestätigte Komponente zählt');
  assert.deepEqual(mit.zugeordnet, ['Rettungsweste']);
  assert.match(mit.text, /Gleichgesetzt mit „Rettungsweste“ \(von dir bestätigt\)/);
  const genug = G.vergleichen(Object.assign({}, basis, { komponenten: [{ name: 'Rettungsweste', anzahl: 4 }], zuordnungen: O.zuordnungenFuer(setzen(O.zuordnungenLeer()), 'Frankreich', 'boot') }))[0];
  assert.equal(genug.status, 'vorhanden'); assert.equal(genug.link, null);
});

test('Grundcheck-Vergleich: ohne Plätze bleibt „je Person“ unklar, auch mit Zuordnung', () => {
  const pt = punkt('Persönliche Schwimmhilfe', 1, 'person');
  const z = G.vergleichen({ punkte: [pt], komponenten: [{ name: 'Rettungsweste', anzahl: 3 }], nachweise: [], plaetze: null, fahrzeugId: 'f1', zuordnungen: O.zuordnungenFuer(setzen(O.zuordnungenLeer()), 'Frankreich', 'boot') })[0];
  assert.equal(z.status, 'unklar');
});

test('Grundcheck-Vergleich: Eignungshaken der bestätigten Komponente gilt, Papier über bestätigten Nachweis', () => {
  const doc = setzen(setzen(O.zuordnungenLeer()), { art: 'papier', punkt: 'Zulassungsbescheinigung Teil 1', ziel: 'Internationaler Bootsschein' });
  const zu = O.zuordnungenFuer(doc, 'Frankreich', 'boot');
  const papier = punkt('Zulassungsbescheinigung Teil 1', 1, 'fahrzeug', 'papier');
  const f = nw => G.vergleichen({ punkte: [papier], komponenten: [], nachweise: nw, plaetze: 4, fahrzeugId: 'f1', zuordnungen: zu })[0];
  assert.equal(f([]).status, 'fehlt');
  assert.equal(f([{ artName: 'Internationaler Bootsschein', gescannt: false }]).status, 'unklar');
  const ok = f([{ artName: 'Internationaler Bootsschein', gescannt: true }]);
  assert.equal(ok.status, 'vorhanden'); assert.deepEqual(ok.zugeordnet, ['Internationaler Bootsschein']);
  assert.equal(G.vergleichen({ punkte: [papier], komponenten: [], nachweise: [{ artName: 'Internationaler Bootsschein', gescannt: true }], plaetze: 4, fahrzeugId: 'f1' })[0].status, 'fehlt', 'ohne Zuordnung rät die App nicht');
});

test('suchbegriff: eine Quelle in MM.Orte, der Grundcheck ruft sie auf', () => {
  assert.equal(O.suchbegriff('Verbandskasten (DIN 13164)'), 'Verbandskasten');
  assert.equal(G.suchbegriff('Verbandskasten (DIN 13164)'), O.suchbegriff('Verbandskasten (DIN 13164)'));
});
