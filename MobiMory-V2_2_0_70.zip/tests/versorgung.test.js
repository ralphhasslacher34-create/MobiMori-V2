'use strict';
/* 2.0.48: Verbraucher und Quelle: Tank als Komponente, Stoff je Komponente, Quelle (mehrere Tanks möglich), Kette am Fahrzeug,
   Tank-Vorschlag bei „Tankinhalt“, Schutz beim Löschen und Verschieben. */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren', 'personen', 'orte',
  'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 8, 12, 0, t++)).toISOString() });
  await d.starten();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wohnmobil = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  return { d, boot, wohnmobil };
}
const werte = async (c, id) => (await c.d.komponenteLaden(id)).aktuell.werte;
const tank = (c, fz, name, extra) => c.d.komponenteAnlegen(fz, null, 'tank', Object.assign({ bezeichnung: name, stoff: 'Diesel' }, extra || {}));
const motor = (c, fz, name, extra) => c.d.komponenteAnlegen(fz, null, 'motor', Object.assign({ bezeichnung: name, verbraucher: 'ja', stoff: 'Diesel' }, extra || {}));

test('Tank ist eine Art der Hauptkomponente und hat nur einen Inhalt', async () => {
  const c = await neu();
  assert.ok(MM.Komponenten.art('tank'));
  const t = await tank(c, c.boot, 'Dieseltank');
  assert.ok(t.ok);
  const w = await werte(c, t.id);
  assert.equal(w.stoff, 'Diesel');
  assert.equal(w.verbraucher, null);
  assert.deepEqual(w.quellen, []);
  assert.ok(MM.Versorgung.istTank((await c.d.komponenteLaden(t.id)).komponente));
});

test('Ein Tank hält keinen Strom, und der Stoff muss aus der Liste kommen', async () => {
  const c = await neu();
  const r = await tank(c, c.boot, 'Tank', { stoff: 'Strom' });
  assert.equal(r.ok, false);
  assert.ok(r.fehler.stoff.includes('Strom'));
  const f = await tank(c, c.boot, 'Tank', { stoff: 'Kerosin' });
  assert.equal(f.ok, false);
  assert.ok(f.fehler.stoff.includes('Kerosin'));
  assert.equal((await c.d.komponentenListe(c.boot)).length, 0);
});

test('Liste der Stoffe: Vorlage ist da, neuer Stoff im Formular kommt in die Liste, gleiche Schreibweise nur einmal', async () => {
  const c = await neu();
  const liste = await c.d.stoffeListe();
  ['Diesel', 'Benzin', 'Gas (Flüssiggas)', 'Strom'].forEach(s => assert.ok(liste.some(x => x.label === s), s));
  const r = await tank(c, c.boot, 'Wasserstofftank', { stoff: '', neuerStoff: 'Wasserstoff' });
  assert.ok(r.ok);
  assert.equal((await werte(c, r.id)).stoff, 'Wasserstoff');
  const r2 = await tank(c, c.boot, 'Zweiter', { stoff: '', neuerStoff: 'wasserstoff' });
  assert.ok(r2.ok);
  assert.equal((await werte(c, r2.id)).stoff, 'Wasserstoff');
  assert.equal((await c.d.stoffeListe()).filter(x => x.label.toLowerCase() === 'wasserstoff').length, 1);
  assert.ok((await c.d.stoffAnlegen('Wasserstoff')).fehler.bezeichnung);
  assert.ok((await c.d.stoffAnlegen('')).fehler.bezeichnung);
  assert.ok((await c.d.stoffAnlegen('x'.repeat(31))).fehler.bezeichnung);
  const neuer = await c.d.stoffAnlegen('Ethanol');
  assert.ok(neuer.ok);
  await c.d.stoffAusblenden('Diesel', true);
  assert.equal((await c.d.stoffeListe()).find(x => x.label === 'Diesel').ausgeblendet, true);
  await c.d.stoffAusblenden('Diesel', false);
  assert.equal((await c.d.stoffeListe()).find(x => x.label === 'Diesel').ausgeblendet, false);
});

test('Verbraucher: Ja, Nein oder noch nicht beantwortet; nur bei Ja gelten Stoff und Quelle', async () => {
  const c = await neu();
  const t = (await tank(c, c.boot, 'Dieseltank')).id;
  const m = await motor(c, c.boot, 'Motor', { quellen: [t] });
  assert.ok(m.ok);
  assert.deepEqual(await werte(c, m.id), Object.assign({}, await werte(c, m.id), { verbraucher: 'ja', stoff: 'Diesel', quellen: [t] }));
  const nein = await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Radio', verbraucher: 'nein', stoff: 'Diesel', quellen: [t] });
  assert.ok(nein.ok);
  const wn = await werte(c, nein.id);
  assert.equal(wn.verbraucher, 'nein'); assert.equal(wn.stoff, null); assert.deepEqual(wn.quellen, []);
  const offen = await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Pumpe' });
  assert.equal((await werte(c, offen.id)).verbraucher, null);
  const falsch = await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'X', verbraucher: 'vielleicht' });
  assert.equal(falsch.ok, false);
  assert.ok(falsch.fehler.verbraucher);
});

test('Die vier Kombinationen: ein Motor ein Tank, zwei Motoren ein Tank, ein Motor mehrere Tanks, zwei Motoren mehrere Tanks', async () => {
  const c = await neu();
  const t1 = (await tank(c, c.boot, 'Tank 1')).id, t2 = (await tank(c, c.boot, 'Tank 2')).id;
  const a = (await motor(c, c.boot, 'Motor A', { quellen: [t1] })).id;
  const b = (await motor(c, c.boot, 'Motor B', { quellen: [t1, t2] })).id;
  const k = await c.d.versorgungKette(c.boot);
  assert.deepEqual(k.tanks.map(x => [x.name, x.verbraucher.map(v => v.name)]), [['Tank 1', ['Motor A', 'Motor B']], ['Tank 2', ['Motor B']]]);
  assert.equal(k.ohneQuelle.length, 0);
  assert.deepEqual(MM.Versorgung.quellenIds(await werte(c, b)), [t1, t2]);
  assert.ok(a);
});

test('Wohnmobil: Heizung mit Gas ohne Verbindung zum Dieseltank; Boot: Standheizung am Dieseltank oder an eigenem Tank', async () => {
  const c = await neu();
  const dieselW = (await tank(c, c.wohnmobil, 'Dieseltank')).id;
  const gas = (await tank(c, c.wohnmobil, 'Gasflasche', { stoff: 'Gas (Flüssiggas)' })).id;
  await c.d.komponenteAnlegen(c.wohnmobil, null, 'motor', { bezeichnung: 'Motor', verbraucher: 'ja', stoff: 'Diesel', quellen: [dieselW] });
  await c.d.komponenteAnlegen(c.wohnmobil, null, 'heizung', { bezeichnung: 'Heizung', verbraucher: 'ja', stoff: 'Gas (Flüssiggas)', quellen: [gas] });
  const kw = await c.d.versorgungKette(c.wohnmobil);
  assert.deepEqual(kw.tanks.map(x => [x.name, x.stoff, x.verbraucher.map(v => v.name)]), [['Dieseltank', 'Diesel', ['Motor']], ['Gasflasche', 'Gas (Flüssiggas)', ['Heizung']]]);
  const dieselB = (await tank(c, c.boot, 'Dieseltank')).id;
  await c.d.komponenteAnlegen(c.boot, null, 'heizung', { bezeichnung: 'Standheizung', verbraucher: 'ja', stoff: 'Diesel', quellen: [dieselB] });
  assert.deepEqual((await c.d.versorgungKette(c.boot)).tanks[0].verbraucher.map(v => v.name), ['Standheizung']);
  /* Die Fahrzeuge bleiben getrennt: Ein Tank des Wohnmobils ist am Boot keine Quelle. */
  const fremd = await c.d.komponenteAnlegen(c.boot, null, 'heizung', { bezeichnung: 'Heizung 2', verbraucher: 'ja', stoff: 'Diesel', quellen: [dieselW] });
  assert.equal(fremd.ok, false);
  assert.ok(fremd.fehler.quellen);
});

test('Quelle muss ein Tank sein, nie die Komponente selbst; Strom hat noch keine Quelle', async () => {
  const c = await neu();
  const t = (await tank(c, c.boot, 'Tank')).id;
  const m = (await motor(c, c.boot, 'Motor', { quellen: [t] })).id;
  const nurMotor = await c.d.komponenteAnlegen(c.boot, null, 'heizung', { bezeichnung: 'Heizung', verbraucher: 'ja', stoff: 'Diesel', quellen: [m] });
  assert.equal(nurMotor.ok, false);
  assert.ok(nurMotor.fehler.quellen);
  const selbst = await c.d.komponenteAendern(m, { bezeichnung: 'Motor', verbraucher: 'ja', stoff: 'Diesel', quellen: [m] });
  assert.equal(selbst.ok, false);
  const strom = await c.d.komponenteAnlegen(c.boot, null, 'strom', { bezeichnung: 'Kühlschrank', verbraucher: 'ja', stoff: 'Strom', quellen: [t] });
  assert.equal(strom.ok, false);
  assert.ok(strom.fehler.quellen.includes('Strom'));
  const ok = await c.d.komponenteAnlegen(c.boot, null, 'strom', { bezeichnung: 'Kühlschrank', verbraucher: 'ja', stoff: 'Strom' });
  assert.ok(ok.ok);
  const k = await c.d.versorgungKette(c.boot);
  assert.deepEqual(k.strom.map(x => x.name), ['Kühlschrank']);
  assert.equal(k.ohneQuelle.some(x => x.name === 'Kühlschrank'), false);
});

test('Verbraucher ohne Quelle und offene Fragen stehen in der Kette, nichts wird geraten', async () => {
  const c = await neu();
  await tank(c, c.boot, 'Tank');
  await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'Motor', verbraucher: 'ja', stoff: 'Diesel' });
  await c.d.komponenteAnlegen(c.boot, null, 'getriebe', { bezeichnung: 'Getriebe' });
  await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Radio', verbraucher: 'nein' });
  const k = await c.d.versorgungKette(c.boot);
  assert.deepEqual(k.ohneQuelle.map(x => [x.name, x.grund]), [['Motor', 'keine']]);
  assert.deepEqual(k.offen.map(x => x.name), ['Getriebe']);
  assert.equal(k.leer, false);
  assert.equal((await c.d.versorgungKette(c.wohnmobil)).leer, true);
});

test('Ausgeblendeter oder ausgebauter Tank zählt in der Kette nicht mehr als Quelle', async () => {
  const c = await neu();
  const t = (await tank(c, c.boot, 'Tank')).id;
  const m = (await motor(c, c.boot, 'Motor', { quellen: [t] })).id;
  await c.d.komponenteAusblenden(t, true);
  let k = await c.d.versorgungKette(c.boot);
  assert.equal(k.tanks.length, 0);
  assert.deepEqual(k.ohneQuelle.map(x => [x.name, x.grund]), [['Motor', 'inaktiv']]);
  await c.d.komponenteAusblenden(t, false);
  assert.equal((await c.d.versorgungKette(c.boot)).tanks.length, 1);
  await c.d.komponenteAendern(t, { bezeichnung: 'Tank', stoff: 'Diesel', ausgebautAm: '2026-11-01' });
  k = await c.d.versorgungKette(c.boot);
  assert.equal(k.tanks.length, 0);
  assert.equal(k.ohneQuelle[0].grund, 'inaktiv');
  assert.ok(m);
});

test('Ändern: Verlauf zeigt Namen statt Kennungen, ohne Versorgungs-Schlüssel bleibt der Stand', async () => {
  const c = await neu();
  const t1 = (await tank(c, c.boot, 'Tank 1')).id, t2 = (await tank(c, c.boot, 'Tank 2')).id;
  const m = (await motor(c, c.boot, 'Motor', { quellen: [t1] })).id;
  const r = await c.d.komponenteAendern(m, { bezeichnung: 'Motor', verbraucher: 'ja', stoff: 'Diesel', quellen: [t1, t2] });
  assert.ok(r.geaendert);
  const u = (await c.d.komponenteLaden(m)).verlauf[0].aenderungen.find(x => x.key === 'quellen');
  assert.equal(MM.Hilfen.wert(u.feld, u.alt), 'Tank 1');
  assert.equal(MM.Hilfen.wert(u.feld, u.neu), 'Tank 1, Tank 2');
  /* Ein Aufruf ohne die Schlüssel (zum Beispiel von einer anderen Stelle) lässt Verbraucher, Stoff und Quelle in Ruhe. */
  const s = await c.d.komponenteAendern(m, { bezeichnung: 'Motor neu' });
  assert.ok(s.geaendert);
  const w = await werte(c, m);
  assert.equal(w.verbraucher, 'ja'); assert.equal(w.stoff, 'Diesel'); assert.deepEqual(w.quellen, [t1, t2]);
  /* Gleiche Angaben noch einmal speichern ist keine Änderung. */
  assert.equal((await c.d.komponenteAendern(m, { bezeichnung: 'Motor neu', verbraucher: 'ja', stoff: 'Diesel', quellen: [t1, t2] })).geaendert, false);
  /* Auf Nein stellen räumt Stoff und Quelle auf, der Verlauf hält den alten Stand fest. */
  await c.d.komponenteAendern(m, { bezeichnung: 'Motor neu', verbraucher: 'nein' });
  const w2 = await werte(c, m);
  assert.equal(w2.verbraucher, 'nein'); assert.equal(w2.stoff, null); assert.deepEqual(w2.quellen, []);
  const v = await c.d.komponenteLaden(m);
  assert.ok(v.verlauf[0].aenderungen.some(x => x.key === 'verbraucher' && x.alt === 'Ja' && x.neu === 'Nein'));
});

test('Alte Einträge ohne die neuen Felder ändern nichts am Verlauf und zählen als „noch nicht beantwortet“', async () => {
  const c = await neu();
  const m = (await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'Motor' })).id;
  const e = (await c.d.speicher.alle('komponenteneintraege'))[0];
  const alt = JSON.parse(JSON.stringify(e));
  delete alt.werte.verbraucher; delete alt.werte.stoff; delete alt.werte.quellen;
  await c.d.speicher.speichern('komponenteneintraege', alt);
  assert.equal((await c.d.komponenteAendern(m, { bezeichnung: 'Motor' })).geaendert, false);
  assert.deepEqual((await c.d.versorgungKette(c.boot)).offen.map(x => x.name), ['Motor']);
});

test('Tank mit Verbrauchern lässt sich nicht löschen, nur ausblenden; ohne Verbraucher geht Löschen', async () => {
  const c = await neu();
  const t = (await tank(c, c.boot, 'Tank')).id;
  const frei = (await tank(c, c.boot, 'Reservetank')).id;
  const m = (await motor(c, c.boot, 'Motor', { quellen: [t] })).id;
  const v = await c.d.komponenteVerwendung(t);
  assert.equal(v.benutzt, true);
  assert.ok(v.gruende.some(x => x.includes('Verbraucher')));
  const l = await c.d.komponenteLoeschen(t);
  assert.equal(l.ok, false);
  assert.ok(await c.d.komponenteLaden(t));
  assert.equal((await c.d.komponenteVerwendung(frei)).benutzt, false);
  assert.ok((await c.d.komponenteLoeschen(frei)).ok);
  /* Nimmt man den Tank als Quelle heraus, geht das Löschen. */
  await c.d.komponenteAendern(m, { bezeichnung: 'Motor', verbraucher: 'ja', stoff: 'Diesel', quellen: [] });
  assert.ok((await c.d.komponenteLoeschen(t)).ok);
  assert.equal((await c.d.versorgungKette(c.boot)).tanks.length, 0);
});

test('Ein Tank, der Verbraucher versorgt, bleibt ein Tank: kein Verschieben unter ein Teil, keine andere Art', async () => {
  const c = await neu();
  const t = (await tank(c, c.boot, 'Tank')).id;
  const h = (await c.d.komponenteAnlegen(c.boot, null, 'heizung', { bezeichnung: 'Heizung' })).id;
  const m = (await motor(c, c.boot, 'Motor', { quellen: [t] })).id;
  const r1 = await c.d.komponenteVerschieben(t, { parentId: h });
  assert.equal(r1.ok, false);
  assert.ok(r1.fehler.allgemein.includes('Motor'));
  const r2 = await c.d.komponenteVerschieben(t, { parentId: null, art: 'sonstiges' });
  assert.equal(r2.ok, false);
  assert.equal((await c.d.komponenteLaden(t)).komponente.art, 'tank');
  await c.d.komponenteAendern(m, { bezeichnung: 'Motor', verbraucher: 'ja', stoff: 'Diesel', quellen: [] });
  assert.ok((await c.d.komponenteVerschieben(t, { parentId: h })).ok);
});

test('Tank-Vorschlag: Komponenten mit dem Merkmal „Tankinhalt“ werden angeboten, Motoren und Verbraucher nicht', async () => {
  const c = await neu();
  const a = (await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Dieselbehälter', merkmale: [{ name: 'Tankinhalt', wert: '80', einheit: 'l' }] })).id;
  await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'Motor', merkmale: [{ name: 'tankinhalt', wert: '5', einheit: 'l' }] });
  await c.d.komponenteAnlegen(c.boot, null, 'heizung', { bezeichnung: 'Heizung', verbraucher: 'ja', stoff: 'Diesel', merkmale: [{ name: 'Tankinhalt', wert: '2', einheit: 'l' }] });
  const teil = (await c.d.komponenteAnlegen(c.boot, a, null, { bezeichnung: 'Zusatzbehälter', merkmale: [{ name: 'Tankinhalt', wert: '20', einheit: 'l' }] })).id;
  const k = await c.d.versorgungKette(c.boot);
  assert.deepEqual(k.umwandelbar.map(x => [x.name, x.inhalt, x.istTeil]), [['Dieselbehälter', '80 l', false], ['Zusatzbehälter', '20 l', true]]);
  assert.equal(k.umwandelbar[1].ueber, 'Dieselbehälter');
  /* Umwandeln = die Art auf „Tank“ stellen (derselbe Weg wie Verschieben, der Verlauf hält es fest). */
  const r = await c.d.komponenteVerschieben(a, { parentId: null, art: 'tank' });
  assert.ok(r.ok && r.geaendert);
  const c2 = await c.d.komponenteLaden(a);
  assert.equal(c2.komponente.art, 'tank');
  assert.equal(c2.verlauf[0].art, 'verschoben');
  assert.ok(c2.verlauf[0].aenderungen[0].neu.includes('Tank'));
  const k2 = await c.d.versorgungKette(c.boot);
  assert.deepEqual(k2.tanks.map(x => [x.name, x.inhalt]), [['Dieselbehälter', '80 l']]);
  assert.deepEqual(k2.umwandelbar.map(x => x.name), ['Zusatzbehälter']);
  assert.ok(teil);
});

test('Ein Verbraucher wird nicht zum Tank', async () => {
  const c = await neu();
  const h = (await c.d.komponenteAnlegen(c.boot, null, 'heizung', { bezeichnung: 'Heizung', verbraucher: 'ja', stoff: 'Diesel', merkmale: [{ name: 'Tankinhalt', wert: '2', einheit: 'l' }] })).id;
  const r = await c.d.komponenteVerschieben(h, { parentId: null, art: 'tank' });
  assert.equal(r.ok, false);
  assert.ok(r.fehler.art.includes('Verbraucher'));
});

test('Übergabe an den nächsten Besitzer: die Quellen zeigen danach auf die neuen Tanks', async () => {
  const c = await neu();
  const t = (await tank(c, c.boot, 'Tank')).id;
  await motor(c, c.boot, 'Motor', { quellen: [t] });
  await c.d.fahrzeugAbgeben(c.boot, { datum: '2026-11-08', grund: 'verkauft' });
  const u = await c.d.uebergabeErzeugen(c.boot, { mitDateien: false });
  assert.ok(u.ok);
  const g = await c.d.uebergabeLesen(u.bytes);
  const e = await c.d.uebergabeEinspielen(g, { trotzdem: true });
  assert.ok(e.ok);
  const k = await c.d.versorgungKette(e.id);
  assert.equal(k.tanks.length, 1);
  assert.deepEqual(k.tanks[0].verbraucher.map(x => x.name), ['Motor']);
  assert.notEqual(k.tanks[0].id, t);
});

test('Sicherung und Wiederherstellen nehmen die Liste der Stoffe und die Quellen mit', async () => {
  const c = await neu();
  await c.d.stoffAnlegen('Ethanol');
  const t = (await tank(c, c.boot, 'Tank')).id;
  await motor(c, c.boot, 'Motor', { quellen: [t] });
  const tabellen = await c.d.speicher.alleTabellen();
  assert.ok((tabellen.einstellungen || []).some(x => x.id === 'stoffe'));
  assert.ok(tabellen.komponenteneintraege.some(x => (x.werte.quellen || []).includes(t)));
});
