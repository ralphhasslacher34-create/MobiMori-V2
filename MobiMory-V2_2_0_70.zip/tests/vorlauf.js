'use strict';
/* Vorlauf für alle Tests (package.json: node --require ./tests/vorlauf.js --test).
   Seit 2.0.70 gilt ohne Konto die Grenze von Basic (1 Fahrzeug). Viele ältere Tests legen mehrere Fahrzeuge an, ohne mit der Grenze zu tun zu haben:
   Für sie ist die Grenze ohne Konto aufgehoben. Die Tests zur Grenze (tests/fahrzeug-grenze.test.js) stellen sie wieder auf 1. */
const Module = require('module');
const original = Module.prototype.require;
Module.prototype.require = function (name) {
  const erg = original.apply(this, arguments);
  if (/daten\.js$/.test(String(name)) && globalThis.MM && globalThis.MM.Daten && globalThis.MM.Daten.standardFahrzeuggrenze === 1) {
    globalThis.MM.Daten.standardFahrzeuggrenze = null;
  }
  return erg;
};
