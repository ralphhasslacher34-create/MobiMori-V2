'use strict';
/* 2.0.60: Anzahl in der Checkliste, Löschen und „neu“ in der Komponentenliste, Start und Ziel der Tage, Ablegen mit Ortsauswahl, ETA. */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM, K = MM.Komponenten, E = MM.Etappen;

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(2026, 10, 9, 12, 0, 0).getTime() + (t++) * 1000).toISOString() });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  return d;
}

/* ---------- Punkt 1: Anzahl ---------- */
test('Anzahl: aus 2 werden zwei Zeilen mit Nummer, 1 und leer bleiben eine Zeile mit dem Namen der Liste', () => {
  const motor = { wert: 'motor', label: 'Motor', art: 'motor', verbraucher: 'ja' }, tank = { wert: 'tank', label: 'Tank', art: 'tank', verbraucher: 'nein' };
  const z = K.anlageZeilen([{ eintrag: motor, anzahl: '2' }, { eintrag: tank, anzahl: '' }]);
  assert.deepEqual(z.map(x => x.label), ['Motor 1', 'Motor 2', 'Tank']);
  assert.equal(z[1].nummer, 2); assert.equal(z[1].von, 2); assert.equal(z[2].von, 1);
  assert.equal(K.anzahlNormal('abc'), 1); assert.equal(K.anzahlNormal('0'), 1); assert.equal(K.anzahlNormal('2,5'), 1);
  assert.equal(K.anzahlNormal('500'), K.MAX_ANZAHL_ANLAGE);
});
test('Anzahl: Rettungswesten als Sätze, jede Zeile eine eigene Komponente mit Stückzahl und eigenem Prüfdatum', async () => {
  const d = await neu();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const zeilen = K.anlageZeilen([{ eintrag: { wert: 'x', label: 'Rettungswesten', art: 'sonstiges', verbraucher: 'nein' }, anzahl: 2 }]);
  const a = await d.komponenteAnlegen(boot, null, 'sonstiges', { bezeichnung: zeilen[0].label, anzahl: '4' });
  const b = await d.komponenteAnlegen(boot, null, 'sonstiges', { bezeichnung: zeilen[1].label, anzahl: '4' });
  assert.ok(a.ok && b.ok);
  const l = await d.komponentenListe(boot);
  assert.equal(l.length, 2);
  assert.ok(l.every(k => k.aktuell.werte.anzahl === 4));
});
test('Stromrolle bleibt in der Zeile der Checkliste erhalten', () => {
  const z = K.anlageZeilen([{ eintrag: { wert: 'generator', label: 'Generator', art: 'sonstiges', verbraucher: 'ja', stromRolle: 'generator' }, anzahl: 1 }]);
  assert.equal(z[0].stromRolle, 'generator');
});

/* ---------- Punkt 2: Löschen ---------- */
test('Liste: eigener unbenutzter Eintrag lässt sich löschen, benutzter und mitgelieferter nicht', async () => {
  const d = await neu();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const a = await d.komponentenListeAnlegen({ bezeichnung: 'Bugstrahlruder', art: 'sonstiges', verbraucher: 'ja' });
  const b = await d.komponentenListeAnlegen({ bezeichnung: 'Ankerwinde', art: 'sonstiges', verbraucher: 'ja' });
  const c = await d.komponentenListeAnlegen({ bezeichnung: 'Radar', art: 'sonstiges', verbraucher: 'nein' });
  assert.equal((await d.komponentenListeVerwendung(a.id)).benutzt, false);
  assert.equal((await d.komponentenListeLoeschen(a.id)).ok, true);
  assert.equal((await d.komponentenListeVorlage()).some(x => x.wert === a.id), false);
  /* gleicher Name an einem Fahrzeug, auch mit Nummer */
  await d.komponenteAnlegen(boot, null, 'sonstiges', { bezeichnung: 'Ankerwinde 2' });
  const v = await d.komponentenListeVerwendung(b.id);
  assert.equal(v.benutzt, true);
  const l = await d.komponentenListeLoeschen(b.id);
  assert.equal(l.ok, false); assert.ok(l.fehler.allgemein.includes('ausblenden'));
  /* Vermerk der Checkliste */
  await d.komponentenListeBenutzt(c.id);
  assert.equal((await d.komponentenListeLoeschen(c.id)).ok, false);
  assert.equal((await d.komponentenListeLoeschen('motor')).ok, false);
  assert.equal((await d.komponentenListeLoeschen('gibtsnicht')).ok, false);
  /* ausblenden geht immer */
  assert.equal((await d.komponentenListeAusblenden(b.id, true)).ok, true);
});
test('Liste: gelöschter Eintrag ist auch aus Ausgeblendeten und Vermerken entfernt', async () => {
  const d = await neu();
  const a = await d.komponentenListeAnlegen({ bezeichnung: 'Radar', art: 'sonstiges', verbraucher: 'nein' });
  await d.komponentenListeAusblenden(a.id, true);
  assert.equal((await d.komponentenListeLoeschen(a.id)).ok, true);
  const dok = await d.speicher.holen('einstellungen', 'komponentenliste');
  assert.deepEqual(dok.ausgeblendet, []); assert.deepEqual(dok.eigene, []);
});

/* ---------- Punkt 3: neu ---------- */
const NEUE_VORLAGE = K.LISTE_VORLAGE.concat([{ wert: 'kompass', label: 'Kompass', art: 'sonstiges', verbraucher: 'nein' }, { wert: 'tv', label: 'Fernseher', art: 'sonstiges', verbraucher: 'ja' }]);
test('Neu: nur Einträge, die nicht zur Basis gehören; alte Einträge sind nie neu', () => {
  const l = K.listeEintraege(null, NEUE_VORLAGE);
  assert.deepEqual(l.filter(x => x.neu).map(x => x.wert), ['kompass', 'tv']);
  assert.ok(K.listeEintraege(null).every(x => !x.neu));
  assert.ok(K.LISTE_VORLAGE.every(x => K.LISTE_BASIS.indexOf(x.wert) >= 0));
});
test('Neu: angenommen, ausgeblendet oder als eigener Eintrag vorhanden ist nicht mehr neu; Ausgeblendetes kommt nicht zurück', () => {
  const dok = { eigene: [{ wert: 'kl-1', label: 'fernseher', art: 'sonstiges', verbraucher: 'ja' }], ausgeblendet: ['motor'], bekannt: ['kompass'] };
  const l = K.listeEintraege(dok, NEUE_VORLAGE);
  assert.equal(l.filter(x => x.neu).length, 0);
  assert.equal(l.find(x => x.wert === 'motor').ausgeblendet, true);
  assert.equal(K.listeEintraege({ ausgeblendet: ['tv'] }, NEUE_VORLAGE).find(x => x.wert === 'tv').neu, false);
});
test('Neu: die Checkliste bietet einen neuen Eintrag erst nach dem Annehmen an', () => {
  const alle = K.listeEintraege(null, NEUE_VORLAGE);
  const vorher = K.listeAngebot(alle, ['wohnmobil'], 'wasser', true).map(x => x.wert);
  assert.ok(!vorher.includes('kompass'));
  const nachher = K.listeAngebot(K.listeEintraege({ bekannt: ['kompass'] }, NEUE_VORLAGE), ['wohnmobil'], 'wasser', true).map(x => x.wert);
  assert.ok(nachher.includes('kompass') && !nachher.includes('tv'));
});
test('Annehmen: nichts Neues da meldet es, sonst wird der Eintrag bekannt', async () => {
  const d = await neu();
  assert.equal((await d.komponentenListeAnnehmen('alle')).ok, false);
});

/* ---------- Punkt 4: Start und Ziel der Tage ---------- */
test('Tage: Tag 1 nimmt den Start der Reise, Tag 2 das tatsächliche Ziel des Vortags, sonst sein geplantes Ziel; eigenes gilt zuerst', () => {
  const tage = [{ id: 'a', datum: '2026-07-01' }, { id: 'b', datum: '2026-07-02' }, { id: 'c', datum: '2026-07-03', startOrtId: 'EIGEN' }];
  let r = E.tagesOrte({ tage, reiseStartId: 'S', reiseZielId: 'Z' });
  assert.deepEqual([r.a.startOrtId, r.a.startHerkunft], ['S', 'reise']);
  assert.equal(r.b.startOrtId, null);
  tage[0].zielOrtId = 'P'; r = E.tagesOrte({ tage, reiseStartId: 'S' });
  assert.deepEqual([r.b.startOrtId, r.b.startHerkunft], ['P', 'vortag']);
  tage[0].tatsaechlichOrtId = 'X'; r = E.tagesOrte({ tage, reiseStartId: 'S' });
  assert.equal(r.b.startOrtId, 'X');
  assert.deepEqual([r.c.startOrtId, r.c.startHerkunft], ['EIGEN', 'tag']);
  assert.equal(r.a.zielOrtId, 'P'); assert.equal(r.a.zielHerkunft, 'tag');
});
test('Tage: eintägige Reise übernimmt Start und Ziel, mehrtägige nicht das Ziel der Reise', () => {
  const r1 = E.tagesOrte({ tage: [{ id: 'a', datum: '2026-07-01' }], reiseStartId: 'S', reiseZielId: 'Z', eintaegig: true });
  assert.deepEqual([r1.a.startOrtId, r1.a.zielOrtId, r1.a.zielHerkunft], ['S', 'Z', 'reise']);
  const r2 = E.tagesOrte({ tage: [{ id: 'a', datum: '2026-07-01' }, { id: 'b', datum: '2026-07-02' }], reiseStartId: 'S', reiseZielId: 'Z', eintaegig: false });
  assert.equal(r2.a.zielOrtId, null); assert.equal(r2.b.zielOrtId, null);
});
test('Tage: beim Ablegen gewähltes Ziel wird Ziel des Tages, eigenes Ziel geht vor', () => {
  let r = E.tagesOrte({ tage: [{ id: 'a', datum: '2026-07-01', wunschOrtId: 'W' }] });
  assert.deepEqual([r.a.zielOrtId, r.a.zielHerkunft], ['W', 'ablegen']);
  r = E.tagesOrte({ tage: [{ id: 'a', datum: '2026-07-01', wunschOrtId: 'W', zielOrtId: 'E' }] });
  assert.equal(r.a.zielOrtId, 'E');
});

async function reise(extra) {
  const d = await neu();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot', reisegeschwindigkeit: '10', hoechstgeschwindigkeit: '20' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const art = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const ort = async (n, b, l) => (await d.ortAnlegen({ bezeichnung: n, positionBreite: b, positionLaenge: l })).id;
  const kiel = await ort('Kiel', '54,32', '10,14'), laboe = await ort('Laboe', '54,40', '10,22'), ohne = (await d.ortAnlegen({ bezeichnung: 'Ohne Position' })).id;
  const r = await d.aktivitaetAnlegen(Object.assign({ bezeichnung: 'Törn', artId: art, fahrzeugId: boot, vonDatum: '2026-11-09', vonZeit: '09:00', bisDatum: '2026-11-09', bisZeit: '17:00', verantwortlichId: anna, startOrtId: kiel, zielOrtId: laboe }, extra || {}));
  assert.ok(r.ok, JSON.stringify(r));
  const t = await d.heutigerTag(r.id);
  await d.abschnittAendern(t.abschnittId, { datum: '2026-11-09', beginnZeit: '09:00' });
  return { d, boot, akt: r.id, tag: t.abschnittId, kiel, laboe, ohne };
}
test('Tag einer eintägigen Reise: Start und Ziel kommen aus der Reise und stehen in der Zusammenfassung mit Herkunft', async () => {
  const c = await reise();
  const z = await c.d.reiseZusammenfassung(c.akt);
  assert.equal(z.tage[0].start.name, 'Kiel'); assert.equal(z.tage[0].ziel.name, 'Laboe');
  assert.equal(z.tage[0].startHerkunft, 'reise'); assert.equal(z.tage[0].zielHerkunft, 'reise');
  assert.ok(z.tage[0].strecke && z.tage[0].strecke.km > 5);
  const gespeichert = (await c.d.abschnittLaden(c.tag)).abschnitt.aktuell.werte;
  assert.ok(!gespeichert.startOrtId && !gespeichert.zielOrtId);
});

/* ---------- Punkt 6: ETA ---------- */
test('ETA: vor dem Start Reisegeschwindigkeit, unterwegs Ø Tag, nie Höchstgeschwindigkeit, mit Herkunft und Hinweisen', () => {
  const basis = { strecke: { km: 60, art: 'route' }, reiseKmh: 20, hoechstKmh: 40, abfahrtMs: 0, jetztMs: 3600000, welt: 'wasser' };
  let e = E.eta(basis);
  assert.equal(e.herkunft, 'reise'); assert.equal(e.fahrzeitMin, 180); assert.equal(e.etaMs, 180 * 60000); assert.equal(e.herkunftText, 'mit Reisegeschwindigkeit');
  e = E.eta(Object.assign({}, basis, { unterwegs: true, tagKmh: 15, restKm: 30 }));
  assert.equal(e.herkunft, 'tag'); assert.equal(e.fahrzeitMin, 120); assert.equal(e.etaMs, 3600000 + 120 * 60000);
  /* bis genug Fahrt da ist: Reisegeschwindigkeit */
  e = E.eta(Object.assign({}, basis, { unterwegs: true, tagKmh: null, restKm: 40 }));
  assert.equal(e.herkunft, 'reise'); assert.equal(e.fahrzeitMin, 120);
  /* Ø fahrend nur als Zweitwert, aktuell nur Anzeige */
  e = E.eta(Object.assign({}, basis, { fahrendKmh: 30, aktuellKmh: 55 }));
  assert.equal(e.kmh, 20); assert.equal(e.zweit.kmh, 30); assert.equal(e.aktuellKmh, 55);
  assert.ok(e.hinweise.some(t => t.includes('Strömung, Schleusen, Pausen und Tide')));
});
test('ETA: ohne Reisegeschwindigkeit unklar, Höchstgeschwindigkeit wird nicht ersatzweise genommen, Wert über der Grenze wird übersprungen', () => {
  let e = E.eta({ strecke: { km: 10, art: 'route' }, reiseKmh: null, hoechstKmh: 30 });
  assert.equal(e.ok, false); assert.ok(e.grund.includes('Reisegeschwindigkeit'));
  e = E.eta({ strecke: { km: 10, art: 'route' }, reiseKmh: 50, hoechstKmh: 30 });
  assert.equal(e.ok, false);
  e = E.eta({ strecke: { km: 10, art: 'route' }, reiseKmh: 20, hoechstKmh: 30, unterwegs: true, tagKmh: 99 });
  assert.equal(e.herkunft, 'reise');
  assert.equal(E.eta({ strecke: null, reiseKmh: 20 }).ok, false);
});
test('ETA: Luftlinie wird als zu optimistisch gekennzeichnet, ohne Beginnzeit nur Fahrzeit', () => {
  const e = E.eta({ strecke: { km: 10, art: 'luftlinie' }, reiseKmh: 10, welt: 'wasser' });
  assert.equal(e.etaMs, null); assert.equal(e.fahrzeitMin, 60);
  assert.ok(e.hinweise.some(t => t.includes('Luftlinie') && t.includes('optimistisch')));
  assert.ok(e.hinweise.some(t => t.includes('Uhrzeit des Beginns')));
});
test('ETA zum Ziel des Tages aus den Daten: Reisegeschwindigkeit des Fahrzeugs, Ziel der Reise', async () => {
  const c = await reise();
  const r = await c.d.etaZumZiel(c.akt, c.tag, {});
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal(r.zielName, 'Laboe'); assert.equal(r.eta.ok, true); assert.equal(r.eta.herkunft, 'reise'); assert.equal(r.eta.kmh, 10);
  assert.ok(r.eta.etaMs > new Date('2026-11-09T09:00').getTime());
  assert.equal(r.verantwortlich, 'Skipper');
  const live = await c.d.etaZumZiel(c.akt, c.tag, { live: { unterwegs: true, tagKmh: 5, position: { breite: 54.36, laenge: 10.18 } }, jetztMs: new Date('2026-11-09T10:00').getTime() });
  assert.equal(live.eta.herkunft, 'tag'); assert.ok(live.eta.km < r.eta.km);
});
test('ETA: Fahrzeug ohne Reisegeschwindigkeit ergibt unklar mit Grund', async () => {
  const c = await reise();
  const fz = await c.d.fahrzeugLaden(c.boot);
  await c.d.fahrzeugAendern(c.boot, Object.assign({}, fz.aktuell.werte, { reisegeschwindigkeit: '' }));
  const r = await c.d.etaZumZiel(c.akt, c.tag, {});
  assert.equal(r.ok, true); assert.equal(r.eta.ok, false); assert.ok(r.eta.grund.includes('Reisegeschwindigkeit'));
});

/* ---------- Punkt 5: Ablegen ---------- */
async function ablegen(c, fragen) {
  const a = await c.d.ereignisartAnlegen({ bezeichnung: 'Ablegen X', fragen: fragen || MM.Baukasten.vorlage('ablegen').fragen, wirkungen: [] });
  assert.ok(a.ok, JSON.stringify(a));
  const e = await c.d.ereignisSchnell(c.akt, 'Ablegen X', { artId: a.id, ortName: 'Kiel', position: { breite: 54.32, laenge: 10.14, genauigkeit: 5 } });
  assert.ok(e.ok, JSON.stringify(e));
  return e.id;
}
test('Vorlage Ablegen: Text, Foto, Ziel aus der Ortsliste; „Ziel“ und „Ziel (Ort)“ passen nicht zusammen', () => {
  assert.deepEqual(MM.Baukasten.vorlage('ablegen').fragen, ['text', 'foto', 'zielOrt']);
  assert.deepEqual(MM.Baukasten.fehlendeFragen({ fragen: ['text', 'foto', 'zielOrt'], wirkungen: [] }), []);
  assert.equal(MM.Baukasten.fehlendeFragen({ fragen: ['ziel', 'zielOrt'], wirkungen: [] }).length, 1);
});
test('Ablegen: leer speichern geht, Ort und Zeit stehen schon fest', async () => {
  const c = await reise(); const id = await ablegen(c);
  const r = await c.d.ereignisAblaufAusfuehren(id, {});
  assert.ok(r.ok, JSON.stringify(r)); assert.equal(r.zielOrt, null);
});
test('Ablegen: Ort aus der Liste wählen, Zeile Wunschziel im Eintrag, Ziel des Tages und Vorbelegung', async () => {
  const c = await reise(); const id = await ablegen(c);
  const r = await c.d.ereignisAblaufAusfuehren(id, { text: 'Los geht es', zielOrtId: c.laboe });
  assert.ok(r.ok, JSON.stringify(r)); assert.equal(r.zielOrt.name, 'Laboe'); assert.equal(r.zielOrt.neu, false);
  const e = await c.d.ereignisLaden(id);
  assert.equal(e.aktuell.werte.zielOrtId, c.laboe);
  assert.equal(e.aktuell.werte.text, 'Los geht es\nWunschziel: Laboe');
  assert.equal((await c.d.ablegenVorbelegung(c.akt, c.tag)).zielOrtId, c.laboe);
  /* noch einmal mit anderem Text: Wunschziel wird ersetzt, nicht doppelt */
  const r2 = await c.d.ereignisAblaufAusfuehren(id, { text: 'Anderer Text', zielOrtId: c.kiel });
  assert.ok(r2.ok);
  assert.equal((await c.d.ereignisLaden(id)).aktuell.werte.text, 'Anderer Text\nWunschziel: Kiel');
});
test('Ablegen: Ort ohne Position, unbekannter Ort und beides zugleich werden abgelehnt', async () => {
  const c = await reise(); const id = await ablegen(c);
  assert.ok((await c.d.ereignisAblaufAusfuehren(id, { zielOrtId: c.ohne })).fehler.zielOrt.includes('keine Position'));
  assert.ok((await c.d.ereignisAblaufAusfuehren(id, { zielOrtId: 'nix' })).fehler.zielOrt.includes('gibt es nicht'));
  assert.ok((await c.d.ereignisAblaufAusfuehren(id, { zielOrtId: c.kiel, neuerOrtName: 'Neu', neuerOrtBreite: '1', neuerOrtLaenge: '2' })).fehler.zielOrt);
  assert.equal((await c.d.ereignisLaden(id)).aktuell.werte.zielOrtId, undefined);
});
test('Ablegen: neuer Ort direkt im Zielfeld (Name plus Position), Name doppelt oder Position fehlt wird abgelehnt', async () => {
  const c = await reise(); const id = await ablegen(c);
  assert.ok((await c.d.ereignisAblaufAusfuehren(id, { neuerOrtName: 'Strande' })).fehler.zielOrt);
  assert.ok((await c.d.ereignisAblaufAusfuehren(id, { neuerOrtName: 'kiel', neuerOrtBreite: '54,4', neuerOrtLaenge: '10,2' })).fehler.zielOrt.includes('gibt es schon'));
  const vorher = (await c.d.orteListe()).length;
  const r = await c.d.ereignisAblaufAusfuehren(id, { neuerOrtName: 'Strande', neuerOrtBreite: '54,43', neuerOrtLaenge: '10,17' });
  assert.ok(r.ok, JSON.stringify(r)); assert.equal(r.zielOrt.neu, true);
  const orte = await c.d.orteListe();
  assert.equal(orte.length, vorher + 1);
  const o = orte.find(x => x.aktuell.werte.bezeichnung === 'Strande');
  assert.equal(o.aktuell.werte.positionBreite, 54.43);
  assert.equal((await c.d.ereignisLaden(id)).aktuell.werte.zielOrtId, o.objekt.id);
});
test('Ablegen: das Ziel mit Text für die Navigation bleibt wie bisher', async () => {
  const c = await reise();
  const a = await c.d.ereignisartAnlegen({ bezeichnung: 'Navi', aktion: 'navi' });
  const e = await c.d.ereignisSchnell(c.akt, 'Navi', { artId: a.id });
  assert.ok((await c.d.ereignisAblaufAusfuehren(e.id, {})).fehler.ziel);
  const r = await c.d.ereignisAblaufAusfuehren(e.id, { ziel: 'Hafen Rovinj' });
  assert.ok(r.ok); assert.equal(r.ziel, 'Hafen Rovinj'); assert.equal(r.zielOrt, null);
});
test('Mehrtägig: das beim Ablegen gewählte Ziel ist das Wunschziel des Tages, das Anlegen bestimmt den Start des nächsten Tages', async () => {
  const c = await reise({ bisDatum: '2026-11-10' });
  await c.d.tagesabschnitteVorbereiten(c.akt);
  const id = await ablegen(c);
  await c.d.ereignisAblaufAusfuehren(id, { zielOrtId: c.laboe });
  let z = await c.d.reiseZusammenfassung(c.akt);
  assert.equal(z.tage[0].ziel.name, 'Laboe'); assert.equal(z.tage[0].zielHerkunft, 'ablegen');
  assert.equal(z.tage[1].start.name, 'Laboe'); assert.equal(z.tage[1].startHerkunft, 'vortag');
  /* Anlegen am Ort Strande (Besuch) bestimmt den Start von Tag 2 */
  const an = await c.d.ereignisartAnlegen({ bezeichnung: 'Anlegen X', fragen: ['text'], wirkungen: [] });
  const e2 = await c.d.ereignisSchnell(c.akt, 'Anlegen X', { artId: an.id, ortName: 'Strande' });
  const strande = (await c.d.ortAnlegen({ bezeichnung: 'Strande', positionBreite: '54,43', positionLaenge: '10,17' })).id;
  const b = await c.d.besuchAnlegen(c.akt, { ereignisId: e2.id, ortId: strande });
  assert.ok(b.ok, JSON.stringify(b));
  z = await c.d.reiseZusammenfassung(c.akt);
  assert.equal(z.tage[1].start.name, 'Strande');
});
