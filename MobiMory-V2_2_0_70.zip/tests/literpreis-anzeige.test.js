'use strict';
const test = require('node:test');
const assert = require('node:assert');
require('../js/hilfen.js');
const H = globalThis.MM.Hilfen;

test('Literpreis wird mit mindestens 3 Stellen angezeigt', () => {
  const f = { key: 'literpreis', label: 'Literpreis (€)', typ: 'zahl' };
  assert.strictEqual(H.wert(f, 1.759), '1,759');
  assert.strictEqual(H.wert(f, 1.79), '1,790');
  assert.strictEqual(H.wert(f, 1.7599), '1,7599');
});

test('Menge, Füllstand und Betrag bleiben unverändert', () => {
  assert.strictEqual(H.wert({ key: 'menge', label: 'Menge (l)', typ: 'zahl' }, 45.5), '45,5');
  assert.strictEqual(H.wert({ key: 'fuellstandNach', label: 'Füllstand danach (l)', typ: 'zahl' }, 60), '60');
  assert.strictEqual(H.wert({ key: 'betrag', label: 'Betrag', typ: 'zahl', einheit: '€' }, 80.567), '80,57 €');
});
