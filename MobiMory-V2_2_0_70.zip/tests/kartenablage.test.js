'use strict';
/* Schritt 9b (2.0.34): Kacheln holen, ablegen, lesen und löschen. Cache und Netz sind nachgebaut. */
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/version.js'); require('../js/routen.js'); require('../js/karte.js'); require('../js/kartenablage.js');
const MM = globalThis.MM;

function falscherCache() {
  const m = new Map();
  return { m, async match(u) { const x = m.get(u); return x ? new Response(x.buf, { status: 200 }) : undefined; },
    async put(u, r) { m.set(u, { buf: await r.arrayBuffer() }); }, async delete(u) { return m.delete(u); } };
}
const bild = () => new Response(new Blob([new Uint8Array(100)]), { status: 200 });
const kacheln = n => Array.from({ length: n }, (_, i) => ({ z: 6, x: i, y: 1 }));
function ablage(o) {
  const cache = falscherCache(), aufrufe = [];
  const a = new MM.Kartenablage(Object.assign({ oeffnen: async () => cache, pauseMs: 0, hole: async u => { aufrufe.push(u); return bild(); } }, o || {}));
  return { a, cache, aufrufe };
}

test('Holen: alle Kacheln werden geholt, abgelegt und sind danach lesbar', async () => {
  const t = ablage();
  const fort = [];
  const r = await t.a.holen(kacheln(7), { fortschritt: (f, g) => fort.push([f, g]) });
  assert.equal(r.ok, true); assert.equal(r.neu, 7); assert.equal(r.schon, 0); assert.equal(r.fehler, 0); assert.equal(r.bytes, 700); assert.equal(r.urls.length, 7);
  assert.deepEqual(fort[fort.length - 1], [7, 7]);
  assert.equal(await t.a.hat(MM.Karte.kachelUrl(6, 3, 1)), true);
  assert.equal((await t.a.blob(MM.Karte.kachelUrl(6, 3, 1))).size, 100);
  assert.equal(await t.a.blob('https://x/y.png'), null);
});

test('Holen: was schon da ist, wird nicht noch einmal geholt', async () => {
  const t = ablage();
  await t.a.holen(kacheln(4));
  t.aufrufe.length = 0;
  const r = await t.a.holen(kacheln(6));
  assert.equal(r.schon, 4); assert.equal(r.neu, 2); assert.equal(t.aufrufe.length, 2); assert.equal(r.urls.length, 6);
});

test('Holen: höchstens zwei gleichzeitig', async () => {
  let gleich = 0, max = 0;
  const t = ablage({ hole: async () => { gleich++; max = Math.max(max, gleich); await new Promise(r => setTimeout(r, 5)); gleich--; return bild(); } });
  await t.a.holen(kacheln(10));
  assert.ok(max <= 2, 'gleichzeitig ' + max);
});

test('Holen: mehr als erlaubt wird gar nicht erst begonnen', async () => {
  const t = ablage();
  const r = await t.a.holen(kacheln(MM.Karte.QUELLE.maxKacheln + 1));
  assert.equal(r.ok, false); assert.equal(t.aufrufe.length, 0); assert.match(r.grund, /mehr als/);
});

test('Holen: fünf Fehler hintereinander brechen ab, schon Geholtes bleibt', async () => {
  let n = 0;
  const t = ablage({ hole: async () => { if (++n > 3) throw new Error('aus'); return bild(); } });
  const r = await t.a.holen(kacheln(40));
  assert.equal(r.ok, false); assert.match(r.grund, /kein Netz/); assert.equal(r.neu, 3);
  assert.ok(n < 15, 'es wurde nicht weiter geklopft: ' + n);
  assert.equal(r.urls.length, 3);
});

test('Holen: schlechte Antwort (Status, leer) zählt als Fehler; einzelne Fehler brechen nicht ab', async () => {
  let n = 0;
  const t = ablage({ hole: async () => { n++; if (n === 2) return new Response('x', { status: 429 }); if (n === 3) return new Response(new Blob([]), { status: 200 }); return bild(); } });
  const r = await t.a.holen(kacheln(6));
  assert.equal(r.ok, true); assert.equal(r.fehler, 2); assert.equal(r.neu, 4); assert.match(r.grund, /2 von 6/);
});

test('Holen: Abbrechen stoppt sauber', async () => {
  const t = ablage();
  let k = 0;
  const r = await t.a.holen(kacheln(20), { abbrechen: () => ++k > 5 });
  assert.equal(r.abgebrochen, true); assert.ok(r.neu < 20 && r.neu >= 1);
});

test('Ohne Cache im Gerät: klare Meldung statt Absturz; Löschen entfernt Kacheln', async () => {
  const k = new MM.Kartenablage({ oeffnen: async () => { throw new Error('Dieses Gerät kann keine Karten im Gerät ablegen.'); }, pauseMs: 0 });
  const r = await k.holen(kacheln(2));
  assert.equal(r.ok, false); assert.match(r.grund, /ablegen/);
  assert.equal(await k.hat('u'), false); assert.equal(await k.blob('u'), null); assert.equal(await k.loeschen(['6/1/1']), 0);
  const t = ablage();
  await t.a.holen(kacheln(3));
  assert.equal(await t.a.loeschen(['6/0/1', '6/1/1', '9/9/9']), 2);
  assert.equal(await t.a.hat(MM.Karte.kachelUrl(6, 0, 1)), false);
  assert.equal(await t.a.hat(MM.Karte.kachelUrl(6, 2, 1)), true);
});
