'use strict';
/* 2.0.59: Strom, erste Stufe: Spannungen, mehrere Versorgungen, Einschalten mit Wahl und Quelle, Laufzeit je Versorgung,
   Nachtanken, Landstrom im Aufenthalt, Messwerte eines Gebers. */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'aktionen', 'baukasten', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const V = MM.Versorgung;

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 9, 8, 0, 0) + (t++) * 3600000).toISOString() });
  await d.starten();
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  return { d, wm };
}
const werte = async (c, id) => (await c.d.komponenteLaden(id)).aktuell.werte;

test('Spannungen: Vorlage mit Gleich- und Wechselstrom, eigene ergänzen, ausblenden, nichts doppelt', async () => {
  const c = await neu();
  const liste = await c.d.spannungenListe();
  assert.deepEqual(liste.map(x => x.label), ['12 V', '24 V', '110/120 V', '220/230/240 V', '380/400 V']);
  assert.equal(V.spannungArt(liste, '12 V'), 'gleich');
  assert.equal(V.spannungArt(liste, '220/230/240 V'), 'wechsel');
  const r = await c.d.spannungAnlegen('48 V', 'gleich');
  assert.ok(r.ok);
  assert.ok((await c.d.spannungAnlegen('48 v', 'gleich')).fehler.bezeichnung);
  assert.ok((await c.d.spannungAnlegen('', 'gleich')).fehler.bezeichnung);
  assert.ok((await c.d.spannungAnlegen('5 V', 'x')).fehler.art);
  await c.d.spannungAusblenden('12 V', true);
  assert.equal((await c.d.spannungenListe()).find(x => x.label === '12 V').ausgeblendet, true);
  const tabellen = await c.d.speicher.alleTabellen();
  assert.ok((tabellen.einstellungen || []).some(x => x.id === 'spannungen'));
});

test('Mehrere Versorgungen: Gas mit Tank, 12 V und 230 V an einem Verbraucher', async () => {
  const c = await neu();
  const gas = (await c.d.komponenteAnlegen(c.wm, null, 'tank', { bezeichnung: 'Gasflasche', stoff: 'Gas (Flüssiggas)' })).id;
  const k = await c.d.komponenteAnlegen(c.wm, null, 'sonstiges', { bezeichnung: 'Kühlschrank', verbraucher: 'ja', stoff: 'Gas (Flüssiggas)', quellen: [gas],
    weitere: [{ stoff: 'Strom', spannung: '12 V' }, { stoff: 'Strom', spannung: '220/230/240 V' }] });
  assert.ok(k.ok, JSON.stringify(k));
  const w = await werte(c, k.id);
  const vl = V.versorgungenListe(w);
  assert.deepEqual(vl.map(v => v.id), ['v1', 'v2', 'v3']);
  assert.deepEqual(vl.map(v => V.versorgungName(v)), ['Gas (Flüssiggas)', 'Strom 12 V', 'Strom 220/230/240 V']);
  const kette = await c.d.versorgungKette(c.wm);
  assert.equal(kette.tanks[0].verbraucher.length, 1);
  assert.equal(kette.strom.length, 1);
  assert.equal(kette.ohneQuelle.length, 0);
  /* Spannung muss aus der Liste kommen, Strom hat keinen Tank */
  const f = await c.d.komponenteAnlegen(c.wm, null, 'sonstiges', { bezeichnung: 'X', verbraucher: 'ja', stoff: 'Strom', spannung: '99 V' });
  assert.equal(f.ok, false); assert.ok(f.fehler.spannung);
  const g = await c.d.komponenteAnlegen(c.wm, null, 'sonstiges', { bezeichnung: 'Y', verbraucher: 'ja', stoff: 'Diesel', weitere: [{ stoff: 'Unbekannt' }] });
  assert.equal(g.ok, false); assert.ok(g.fehler.weitere);
  /* Änderung ohne Angaben zur Versorgung lässt alles, wie es war */
  const a = await c.d.komponenteAendern(k.id, { bezeichnung: 'Kühlschrank groß' });
  assert.ok(a.ok);
  assert.equal((await werte(c, k.id)).weitere.length, 2);
  assert.deepEqual((await werte(c, k.id)).weitere.map(v => v.id), ['v2', 'v3']);
});

test('Einschalten: Wahl der Versorgung, bei Wechselstrom die Quelle, Laufzeit zählt zur Versorgung', async () => {
  const c = await neu();
  const gen = (await c.d.komponenteAnlegen(c.wm, null, 'sonstiges', { bezeichnung: 'Generator', verbraucher: 'ja', stoff: 'Benzin', stromRolle: 'generator' })).id;
  const k = (await c.d.komponenteAnlegen(c.wm, null, 'sonstiges', { bezeichnung: 'Kühlschrank', verbraucher: 'ja', stoff: 'Strom', spannung: '12 V',
    weitere: [{ stoff: 'Strom', spannung: '220/230/240 V' }] })).id;
  const liste = await c.d.verbraucherSchalter(c.wm);
  assert.equal(liste.find(x => x.komponenteId === k).versorgungWahl, true);
  assert.equal(liste.find(x => x.komponenteId === gen).versorgungWahl, false);
  const o = await c.d.verbraucherStart(k);
  assert.equal(o.ok, false); assert.ok(o.fehler.versorgung);
  const p = await c.d.verbraucherStart(k, { versorgungId: 'v2' });
  assert.equal(p.ok, false); assert.ok(p.fehler.stromQuelle);
  const q = await c.d.verbraucherStart(k, { versorgungId: 'v2', stromQuelle: 'batterie' });
  assert.equal(q.ok, false); assert.ok(q.fehler.stromQuelle);
  const s1 = await c.d.verbraucherStart(k, { versorgungId: 'v2', stromQuelle: 'generator' });
  assert.ok(s1.ok, JSON.stringify(s1));
  assert.equal(s1.stromQuelle, 'generator');
  assert.equal((await c.d.verbraucherSchalter(c.wm)).find(x => x.komponenteId === k).laeuftMit, 'Strom 220/230/240 V (Generator)');
  await c.d.verbraucherStopp(k);
  /* 12 V: die Quelle ist die Batterie, ohne Frage */
  const s2 = await c.d.verbraucherStart(k, { versorgungId: 'v1' });
  assert.ok(s2.ok); assert.equal(s2.stromQuelle, 'batterie');
  await c.d.verbraucherStopp(k);
  const lz = await c.d.verbraucherLaufzeiten(k);
  assert.equal(lz.liste.length, 2);
  assert.ok(lz.liste[0].stunden > 0 && lz.liste[1].stunden > 0);
  assert.ok(lz.liste[1].jeQuelle.generator > 0);
  assert.ok(lz.liste[0].jeQuelle.batterie > 0);
  const kontext = await c.d.verbraucherEinschaltenKontext(k);
  const gq = kontext.versorgungen[1].quellen.find(x => x.wert === 'generator');
  assert.deepEqual(gq.geraete.map(x => x.name), ['Generator']);
});

test('Laufzeit je Versorgung und Stunden am Tank (rein)', () => {
  const vl = V.versorgungenListe({ verbraucher: 'ja', stoff: 'Gas (Flüssiggas)', quellen: ['t1'], weitere: [{ id: 'v2', stoff: 'Strom', spannung: '12 V' }] });
  const laeufe = [{ stopp: 'x', stunden: 2 }, { stopp: 'x', stunden: 1.5, versorgungId: 'v2', stromQuelle: 'batterie' }, { stopp: 'x', stunden: 3, versorgungId: 'v1' }, { stopp: null, stunden: null }];
  const r = V.laufzeiten(laeufe, vl);
  assert.equal(r.liste[0].stunden, 5);
  assert.equal(r.liste[1].stunden, 1.5);
  assert.equal(V.stundenAmTank(laeufe, vl, 't1'), 5);
  assert.equal(V.stundenAmTank(laeufe, vl, 'andere'), 0);
});

test('Nachtanken: nur rechnen, was bekannt ist', () => {
  const rw = [{ name: 'Generator', wert: 10, einheit: 'Betriebsstunden' }];
  assert.equal(V.nachtanken({ name: 'Generator', reichweite: [], stundenSeitTanken: 1, laeuftSeitStunden: 0 }), null);
  const a = V.nachtanken({ name: 'Generator', reichweite: rw, stundenSeitTanken: 4, laeuftSeitStunden: 0.5 });
  assert.equal(a.rest, 5.5); assert.equal(a.warnung, false); assert.ok(a.text.includes('5,5'));
  const b = V.nachtanken({ name: 'Generator', reichweite: rw, stundenSeitTanken: 10, laeuftSeitStunden: 0 });
  assert.equal(b.warnung, true); assert.equal(b.rest, 0);
});

test('Landstrom: Zeit-Automat mit „Strom aus um“ und Restzeit, kWh-Automat ohne Restguthaben', () => {
  const R = MM.Reiseorte;
  const w = { landstrom: 'ja', landstromAutomat: 'zeit', landstromMenge: 3, datum: '2026-07-02', zeit: '20:00' };
  const i = R.landstromInfo(w, null, '2026-07-02T21:30');
  assert.deepEqual(i.aus, { datum: '2026-07-02', zeit: '23:00' });
  assert.equal(i.restMinuten, 90); assert.equal(i.restText, 'Noch 1 h 30 min');
  const ab = R.landstromInfo(w, { text: '2 h', von: { datum: '2026-07-02', zeit: '20:00' } }, '2026-07-02T21:30');
  assert.equal(ab.zeit, '2 h'); assert.equal(ab.restText, null);
  assert.equal(R.landstromInfo(w, null, '2026-07-02T23:30').abgelaufen, true);
  const k = R.landstromInfo({ landstrom: 'ja', landstromAutomat: 'kwh', landstromMenge: 15, datum: '2026-07-02', zeit: '20:00' }, null, '2026-07-02T21:30');
  assert.equal(k.mengeText, '15 kWh gekauft'); assert.equal(k.restText, null); assert.equal(k.aus, null);
  assert.equal(R.landstromInfo({ landstrom: 'nein' }, null, ''), null);
});

test('Besuch mit Landstrom: Angaben gespeichert, Betrag wird Kostenposten, Prüfungen', async () => {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 6, 5, 12, 0, 0) + (t++) * 1000).toISOString() });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const aktId = (await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: arten.find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id, fahrzeugId: boot, vonDatum: '2026-07-01', bisDatum: '2026-07-10', verantwortlichId: anna })).id;
  const mitMenge = await d.besuchAnlegen(aktId, { neuerOrtName: 'Hafen A', neuerOrtArt: 'hafen', landstrom: 'ja', landstromMenge: '3' });
  assert.equal(mitMenge.ok, false); assert.ok(mitMenge.fehler.landstromAutomat);
  const b = await d.besuchAnlegen(aktId, { neuerOrtName: 'Hafen A', neuerOrtArt: 'hafen', datum: '2026-07-02', zeit: '20:00', landstrom: 'ja', landstromAutomat: 'zeit', landstromMenge: '3', landstromBetrag: '6,50' });
  assert.ok(b.ok, JSON.stringify(b));
  const x = await d.besuchLaden(b.id);
  assert.equal(x.aktuell.werte.landstrom, 'ja'); assert.equal(x.aktuell.werte.landstromMenge, 3);
  assert.equal(x.landstrom.aus.zeit, '23:00');
  assert.equal(x.kosten.length, 1);
  assert.equal(x.kosten[0].aktuell.werte.kostenart, 'strom');
  assert.equal(Number(x.kosten[0].aktuell.werte.betrag), 6.5);
  /* ändern: Haken weg, Angaben zum Automaten fallen weg */
  const a = await d.besuchAendern(b.id, { landstrom: 'nein' });
  assert.ok(a.ok && a.geaendert);
  const y = await d.besuchLaden(b.id);
  assert.equal(y.landstrom, null); assert.equal(y.aktuell.werte.landstromMenge, null);
  /* ohne Haken kein Kostenposten aus dem Feld */
  const o = await d.besuchAnlegen(aktId, { neuerOrtName: 'Hafen B', neuerOrtArt: 'hafen', landstromBetrag: '5' });
  assert.ok(o.ok); assert.equal(o.kostenIds.length, 0);
});

test('Messwerte: nur von einem Geber, keine Handeingabe, nichts wird gerechnet', async () => {
  const c = await neu();
  const b = (await c.d.komponenteAnlegen(c.wm, null, 'strom', { bezeichnung: 'Aufbaubatterie' })).id;
  assert.equal((await c.d.messwertErfassen(b, 'ladezustand', 80, {})).ok, false);
  assert.equal((await c.d.messwertErfassen(b, 'ladezustand', 80, { quelle: 'hand' })).ok, false);
  assert.ok((await c.d.messwertErfassen(b, 'quatsch', 80, { quelle: 'geber' })).fehler.art);
  assert.ok((await c.d.messwertErfassen(b, 'ladezustand', -1, { quelle: 'geber' })).fehler.wert);
  const r = await c.d.messwertErfassen(b, 'ladezustand', 80, { quelle: 'geber', geber: 'Victron' });
  assert.ok(r.ok);
  const l = await c.d.messwerteListe(b);
  assert.equal(l.length, 1); assert.equal(l[0].einheit, 'Prozent'); assert.equal(l[0].quelle, 'geber');
  assert.equal((await werte(c, b)).ladezustand, undefined);
});

test('Checkliste: Generator, EFOY und Wechselrichter mit Rolle; Methanol ist ein Stoff', async () => {
  const c = await neu();
  const e = MM.Komponenten.listeEintraege(null);
  assert.equal(e.find(x => x.wert === 'efoy').stromRolle, 'efoy');
  assert.equal(e.find(x => x.wert === 'generator').stromRolle, 'generator');
  assert.equal(e.find(x => x.wert === 'wechselrichter').stromRolle, 'wechselrichter');
  const k = await c.d.komponenteAnlegen(c.wm, null, 'sonstiges', { bezeichnung: 'EFOY', verbraucher: 'ja', stoff: 'Methanol', stromRolle: 'efoy' });
  assert.ok(k.ok);
  assert.equal((await werte(c, k.id)).stromRolle, 'efoy');
  assert.equal((await c.d.komponenteAnlegen(c.wm, null, 'sonstiges', { bezeichnung: 'Z', stromRolle: 'quatsch' })).ok, false);
});

test('Oberfläche (Quelltext): Routen, Wahl beim Einschalten, Landstrom in beiden Formularen, Spannungen in der Liste', () => {
  const fs = require('node:fs');
  const a = fs.readFileSync(require('node:path').join(__dirname, '..', 'js/ansicht.js'), 'utf8');
  assert.match(a, /teile\[0\] === 'verbraucher' && teile\[1\] && teile\[2\] === 'einschalten'\) p = verbraucherEinschaltenFormular/);
  assert.match(a, /teile\[1\] === 'spannung' && teile\[2\] === 'neu'\) p = spannungNeuFormular\(\)/);
  assert.match(a, /if \(!m\.laeuft && m\.versorgungWahl\)/);
  assert.equal((a.match(/landstromGruppe\(z, (true|false)\)/g) || []).length, 2);
  assert.match(a, /daten\.spannungAusblenden\.bind\(daten\)/);
  assert.match(a, /'feld wv-liste/);
});
