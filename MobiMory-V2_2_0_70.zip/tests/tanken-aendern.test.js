'use strict';
/* 2.0.51: Tanken komplett: Füllstand, Verbrauch, Reichweite, Kostenposten (Kostenart „Treibstoff und Energie“).
   Festlegungen vom 09.11.2026: Füllstand einmal angeben, nicht voll = Stand plus Menge (nur gerechnet), Verbrauch je Verbraucher aus Füllstand oder Betriebsstunden. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/aktionen.js');
require('../js/baukasten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/karte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const T = MM.Tanken, B = MM.Baukasten;
const TAG = 86400000;

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 8, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.uhr = uhr;
  return d;
}
/* Boot mit zwei Tanks (Steuerbord, Backbord) und einem Gastank */
async function boot() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: fz, vonDatum: '2026-11-08', vonZeit: '09:00', bisDatum: '2026-11-20', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok, JSON.stringify(r));
  const mk = (n, stoff, inh) => d.komponenteAnlegen(fz, null, 'tank', { bezeichnung: n, stoff, merkmale: [{ name: 'Tankinhalt', wert: String(inh), einheit: 'l' }] });
  const stb = await mk('Steuerbordtank', 'Diesel', 400), bb = await mk('Backbordtank', 'Diesel', 400), gas = await mk('Gastank', 'Gas (Flüssiggas)', 20);
  [stb, bb, gas].forEach(x => assert.ok(x.ok, JSON.stringify(x)));
  const art = await d.ereignisartAnlegen({ bezeichnung: 'Tanken', fragen: B.vorlage('tanken').fragen, wirkungen: B.vorlage('tanken').wirkungen });
  assert.ok(art.ok, JSON.stringify(art));
  return { d, id: r.id, fz, stb: stb.id, bb: bb.id, gas: gas.id, art: art.id };
}
const tw = async (c, id) => (await c.d.komponenteLaden(id)).aktuell.werte;
async function stand(c, id, name, liter, inh) {
  const r = await c.d.komponenteAendern(id, { bezeichnung: name, stoff: 'Diesel', fuellstand: String(liter), merkmale: [{ name: 'Tankinhalt', wert: String(inh), einheit: 'l' }] });
  assert.ok(r.ok, JSON.stringify(r));
}
async function tanken(c, antw, datum, zeit) {
  const e = await c.d.ereignisSchnell(c.id, 'Tanken', { artId: c.art, ortName: 'Horrheim', datum, zeit });
  assert.ok(e.ok, JSON.stringify(e));
  const r = await c.d.ereignisAblaufAusfuehren(e.id, antw);
  assert.ok(r.ok, JSON.stringify(r));
  return { id: e.id, r };
}

test('Falscher Tank: Vorgang auf 0 Liter ändern, der Tank geht auf den Stand davor, der richtige wird neu erfasst', async () => {
  const c = await boot();
  await stand(c, c.stb, 'Steuerbordtank', 100, 400);
  await stand(c, c.bb, 'Backbordtank', 50, 400);
  c.d.uhr.ms += TAG;
  const falsch = await tanken(c, { tankId: c.stb, menge: '300', literpreis: '1,80', voll: 'nein' });
  assert.equal((await tw(c, c.stb)).fuellstand, 400);
  assert.equal((await tw(c, c.stb)).fuellstandArt, 'gerechnet');
  const kostenId = (await c.d.ereignisLaden(falsch.id)).aktuell.werte.kostenId;
  const a = await c.d.tankvorgangAendern(falsch.id, { menge: '0' });
  assert.ok(a.ok, JSON.stringify(a));
  assert.equal(a.nullLiter, true);
  assert.equal((await tw(c, c.stb)).fuellstand, 100, 'Steuerbord steht wieder auf dem Stand davor');
  assert.equal((await tw(c, c.stb)).fuellstandArt, 'angegeben');
  /* Der falsche Vorgang bleibt mit Verlauf erhalten */
  const e = await c.d.ereignisLaden(falsch.id);
  assert.equal(e.aktuell.werte.menge, 0);
  assert.ok(e.verlauf.length >= 3);
  assert.equal(e.verlauf.some(v => (v.aenderungen || []).some(u => u.key === 'menge')), true, 'die alte Menge steht im Verlauf');
  /* Kosten dieses Vorgangs gehen auf 0 */
  assert.equal(a.kostenGeaendert, true);
  assert.equal((await c.d.kostenLaden(kostenId)).aktuell.werte.betrag, 0);
  /* Der richtige Vorgang: gleiches Datum, gleiche Uhrzeit, gleicher Preis, richtiger Tank */
  const w0 = e.aktuell.werte;
  const richtig = await tanken(c, { tankId: c.bb, menge: '300', literpreis: '1,80', voll: 'nein' }, w0.datum, w0.zeit);
  assert.equal((await tw(c, c.bb)).fuellstand, 350);
  assert.equal((await tw(c, c.stb)).fuellstand, 100);
  assert.ok(richtig.r.kostenNeu);
});

test('Ändern ist nicht Löschen: Menge von 0 wieder hochsetzen rechnet alles neu, Betrag wieder Menge mal Preis', async () => {
  const c = await boot();
  await stand(c, c.stb, 'Steuerbordtank', 100, 400);
  c.d.uhr.ms += TAG;
  const v = await tanken(c, { tankId: c.stb, menge: '100', literpreis: '2', voll: 'nein' });
  const kostenId = (await c.d.ereignisLaden(v.id)).aktuell.werte.kostenId;
  await c.d.tankvorgangAendern(v.id, { menge: '0' });
  const b = await c.d.tankvorgangAendern(v.id, { menge: '150' });
  assert.ok(b.ok, JSON.stringify(b));
  assert.equal((await tw(c, c.stb)).fuellstand, 250);
  assert.equal((await c.d.kostenLaden(kostenId)).aktuell.werte.betrag, 300);
});

test('Spätere Vorgänge werden neu gerechnet: Volltanken danach liefert den Verbrauch aus dem berichtigten Stand', async () => {
  const c = await boot();
  await stand(c, c.stb, 'Steuerbordtank', 100, 400);
  c.d.uhr.ms += TAG;
  const v1 = await tanken(c, { tankId: c.stb, menge: '50', literpreis: '1,5', voll: 'nein' });
  c.d.uhr.ms += TAG;
  const v2 = await tanken(c, { tankId: c.stb, menge: '320', literpreis: '1,5', voll: 'ja' });
  const vorher = (await tw(c, c.stb)).verbrauch;
  assert.ok(!vorher, 'vorher war der Stand nur gerechnet, also kein Verbrauch');
  /* Vorgang 1 war falsch (Menge 0): jetzt gilt Stand 100, voll mit 320 ergibt 20 l Verbrauch */
  const a = await c.d.tankvorgangAendern(v1.id, { menge: '0' });
  assert.ok(a.ok, JSON.stringify(a));
  const w = await tw(c, c.stb);
  assert.equal(w.fuellstand, 400);
  assert.equal(w.verbrauch.liter, 20);
  assert.equal((await c.d.ereignisLaden(v2.id)).aktuell.werte.verbrauch.liter, 20, 'auch der spätere Vorgang trägt den neuen Verbrauch');
});

test('Tank des Vorgangs ändern: beide Tanks werden neu gerechnet', async () => {
  const c = await boot();
  await stand(c, c.stb, 'Steuerbordtank', 100, 400);
  await stand(c, c.bb, 'Backbordtank', 50, 400);
  c.d.uhr.ms += TAG;
  const v = await tanken(c, { tankId: c.stb, menge: '200', literpreis: '1,5', voll: 'nein' });
  assert.equal((await tw(c, c.stb)).fuellstand, 300);
  const a = await c.d.tankvorgangAendern(v.id, { tankId: c.bb });
  assert.ok(a.ok, JSON.stringify(a));
  assert.equal((await tw(c, c.stb)).fuellstand, 100);
  assert.equal((await tw(c, c.bb)).fuellstand, 250);
  assert.equal((await c.d.ereignisLaden(v.id)).aktuell.werte.tankName, 'Backbordtank');
});

test('Nachtragen: Ein Vorgang mit früherer Zeit wird zeitlich richtig einsortiert und alles danach neu gerechnet', async () => {
  const c = await boot();
  await stand(c, c.stb, 'Steuerbordtank', 100, 400);
  c.d.uhr.ms += 2 * TAG;
  await tanken(c, { tankId: c.stb, menge: '100', literpreis: '1,5', voll: 'nein' }, '2026-11-10', '10:00');
  assert.equal((await tw(c, c.stb)).fuellstand, 200);
  /* nachgetragen: am 9.11. wurden 50 l getankt */
  const n = await tanken(c, { tankId: c.stb, menge: '50', literpreis: '1,5', voll: 'nein' }, '2026-11-09', '10:00');
  assert.equal((await tw(c, c.stb)).fuellstand, 250, 'Stand nach beiden Vorgängen');
  assert.equal((await c.d.ereignisLaden(n.id)).aktuell.werte.fuellstandNach, 150, 'der nachgetragene Vorgang steht zeitlich zuerst');
});

test('Ändern ohne Menge geht nicht, ohne verbuchten Vorgang geht es nicht', async () => {
  const c = await boot();
  await stand(c, c.stb, 'Steuerbordtank', 100, 400);
  const v = await tanken(c, { tankId: c.stb, menge: '10', literpreis: '1,5', voll: 'nein' });
  const k = await c.d.tankvorgangAendern(v.id, { menge: 'viel' });
  assert.equal(k.ok, false); assert.ok(k.fehler.menge);
  const e = await c.d.ereignisSchnell(c.id, 'Tanken', { artId: c.art, ortName: 'X' });
  const o = await c.d.tankvorgangAendern(e.id, { menge: '5' });
  assert.equal(o.ok, false);
});

test('Gas in kg: Dichte in der Stoffliste, Menge und Preis in kg, der Tank rechnet in Litern', async () => {
  const c = await boot();
  const liste = await c.d.stoffeListe();
  assert.equal(liste.find(x => x.label === 'Gas (Flüssiggas)').dichte, 0.51, 'Vorlagewert für Gas');
  assert.equal(liste.find(x => x.label === 'Diesel').dichte, null, 'ohne Dichte nur Liter');
  const r = await c.d.komponenteAendern(c.gas, { bezeichnung: 'Gastank', stoff: 'Gas (Flüssiggas)', fuellstand: '5', merkmale: [{ name: 'Tankinhalt', wert: '20', einheit: 'l' }] });
  assert.ok(r.ok, JSON.stringify(r));
  c.d.uhr.ms += TAG;
  const v = await tanken(c, { tankId: c.gas, menge: '5,1', mengeEinheit: 'kg', literpreis: '2', voll: 'nein' });
  const w = (await c.d.ereignisLaden(v.id)).aktuell.werte;
  assert.equal(w.menge, 10, '5,1 kg bei 0,51 kg je Liter sind 10 Liter');
  assert.deepEqual(w.mengeEingabe, { wert: 5.1, einheit: 'kg' });
  assert.equal(w.literpreis, 1.02, '2 € je kg sind 1,02 € je Liter');
  assert.equal((await tw(c, c.gas)).fuellstand, 15);
  assert.equal((await c.d.kostenLaden(w.kostenId)).aktuell.werte.betrag, 10.2, 'der Betrag ist, was bezahlt wurde: 5,1 kg mal 2 €');
  /* Diesel hat keine Dichte: kg geht nicht */
  const e = await c.d.ereignisSchnell(c.id, 'Tanken', { artId: c.art, ortName: 'X' });
  const bad = await c.d.ereignisAblaufAusfuehren(e.id, { tankId: c.stb, menge: '5', mengeEinheit: 'kg', voll: 'nein' });
  assert.equal(bad.ok, false); assert.match(bad.fehler.menge, /Dichte/);
  /* Dichte ändern */
  assert.ok((await c.d.stoffDichteSetzen('Diesel', '0,83')).ok);
  assert.equal(await c.d.stoffDichte('Diesel'), 0.83);
  assert.equal((await c.d.stoffDichteSetzen('Diesel', 'abc')).ok, false);
  assert.ok((await c.d.stoffDichteSetzen('Gas (Flüssiggas)', '')).ok);
  assert.equal(await c.d.stoffDichte('Gas (Flüssiggas)'), null, 'bewusst ohne Dichte');
});

test('Kraftstoffart: mit dem Stoff des Tanks vorbelegt, abweichend nur ein Hinweis, ohne Stoff nichts', () => {
  assert.deepEqual(T.stoffHinweis('Diesel', 'Diesel', 'Tank'), { vorbelegung: 'Diesel', hinweis: null });
  assert.deepEqual(T.stoffHinweis('Diesel', '', 'Tank'), { vorbelegung: 'Diesel', hinweis: null });
  const h = T.stoffHinweis('Diesel', 'Benzin', 'Dieseltank');
  assert.equal(h.vorbelegung, 'Diesel'); assert.match(h.hinweis, /nur ein Hinweis/);
  assert.deepEqual(T.stoffHinweis('', 'Benzin', 'Tank'), { vorbelegung: '', hinweis: null });
});
