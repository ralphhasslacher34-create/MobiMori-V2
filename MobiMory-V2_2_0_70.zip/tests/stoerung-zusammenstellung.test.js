'use strict';
/* 2.0.57: Störung als Zusammenstellung (Frage Einschränkung und Frist, Wirkung Vorgang und Frist). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/aktionen.js');
require('../js/baukasten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/karte.js');
require('../js/daten.js');
const MM = globalThis.MM;

const B = MM.Baukasten;
function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 9, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.uhr = uhr;
  return d;
}
async function mitAktivitaet() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: boot, vonDatum: '2026-11-09', vonZeit: '09:00', bisDatum: '2026-11-11', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok);
  return { d, id: r.id, boot };
}
async function ereignisMit(c, art, name) {
  const a = await c.d.ereignisartAnlegen(Object.assign({ bezeichnung: name || 'Defekt' }, art));
  assert.ok(a.ok, JSON.stringify(a));
  const e = await c.d.ereignisSchnell(c.id, name || 'Defekt', { artId: a.id, ortName: 'Horrheim' });
  assert.ok(e.ok, JSON.stringify(e));
  return e.id;
}
const VORLAGE = () => { const v = B.vorlage('stoerung'); return { fragen: v.fragen, wirkungen: v.wirkungen }; };

test('Vorlage Störung: Fragen und Wirkungen stehen in der Liste, die Regeln sind erfüllt', () => {
  const v = B.vorlage('stoerung');
  assert.deepEqual(v.fragen, ['text', 'foto', 'einschraenkung', 'frist']);
  assert.deepEqual(v.wirkungen, ['vorgang', 'vorgangFrist']);
  assert.deepEqual(B.fehlendeFragen({ fragen: v.fragen, wirkungen: v.wirkungen }), []);
  /* Die Frist-Wirkung braucht den Vorgang und die Frage „Reparieren bis“ */
  assert.ok(B.fehlendeFragen({ fragen: ['text'], wirkungen: ['vorgangFrist'] }).length >= 2);
});

test('Störung aus Bausteinen: Vorgang in der Werkstatt mit Text, Einschränkung und Frist; Foto kommt zum Eintrag', async () => {
  const c = await mitAktivitaet();
  const id = await ereignisMit(c, VORLAGE());
  const foto = new Blob(['bild'], { type: 'image/jpeg' }); Object.defineProperty(foto, 'name', { value: 'schaden.jpg' });
  const r = await c.d.ereignisAblaufAusfuehren(id, { text: 'Motor springt schlecht an', einschraenkung: 'bedingt', frist: '2026-11-20', datei: foto });
  assert.ok(r.ok, JSON.stringify(r));
  assert.ok(r.vorgang && r.vorgang.id);
  assert.equal(r.vorgang.einschraenkung, 'bedingt');
  assert.equal(r.vorgang.frist, '2026-11-20');
  const v = await c.d.vorgangLaden(r.vorgang.id);
  const w = v.aktuell.werte;
  assert.equal(w.art, 'stoerung');
  assert.equal(w.status, 'offen');
  assert.equal(w.bezeichnung, 'Motor springt schlecht an');
  assert.equal(w.auswirkung, 'bedingt');
  assert.equal(w.reparierenBis, '2026-11-20');
  assert.equal(v.vorgang.fahrzeugId, c.boot);
  assert.equal(v.vorgang.ereignisId, id);
  const e = await c.d.ereignisLaden(id);
  assert.equal(e.ereignis.vorgangId, r.vorgang.id);
  assert.equal(e.aktuell.werte.einschraenkung, 'bedingt');
  assert.equal(e.aktuell.werte.frist, '2026-11-20');
  assert.ok(e.datei, 'das Foto gehört zum Eintrag');
  /* Das Fahrzeug zeigt die Einschränkung (nur bedingt einsatzfähig) */
  const liste = await c.d.vorgaengeListe(c.boot);
  assert.equal(liste.length, 1);
});

test('Störung aus Bausteinen: ohne Angabe gilt „Fahrzeug bleibt nutzbar“, ohne Frist keine Frist', async () => {
  const c = await mitAktivitaet();
  const id = await ereignisMit(c, VORLAGE());
  const r = await c.d.ereignisAblaufAusfuehren(id, { text: 'Lampe flackert' });
  assert.ok(r.ok, JSON.stringify(r));
  const w = (await c.d.vorgangLaden(r.vorgang.id)).aktuell.werte;
  assert.equal(w.auswirkung, 'keine');
  assert.ok(!w.reparierenBis);
});

test('Störung aus Bausteinen: ein zweites Abschicken legt keinen zweiten Vorgang an', async () => {
  const c = await mitAktivitaet();
  const id = await ereignisMit(c, VORLAGE());
  const r1 = await c.d.ereignisAblaufAusfuehren(id, { text: 'Pumpe läuft nicht', einschraenkung: 'nicht' });
  const r2 = await c.d.ereignisAblaufAusfuehren(id, { text: 'Pumpe läuft nicht', einschraenkung: 'nicht', frist: '2026-11-15' });
  assert.ok(r1.ok && r2.ok);
  assert.equal(r2.vorgang, null);
  assert.equal(r2.vorgangSchonDa, true);
  assert.equal(r2.vorgangId, r1.vorgang.id);
  assert.equal((await c.d.vorgaengeListe(c.boot)).length, 1);
});

test('Störung aus Bausteinen: falsche Einschränkung und ungültige Frist werden am Feld gemeldet, nichts wird gespeichert', async () => {
  const c = await mitAktivitaet();
  const id = await ereignisMit(c, VORLAGE());
  const a = await c.d.ereignisAblaufAusfuehren(id, { text: 'x', einschraenkung: 'quatsch' });
  assert.equal(a.ok, false);
  assert.ok(a.fehler.einschraenkung);
  const b = await c.d.ereignisAblaufAusfuehren(id, { text: 'x', frist: '31.02.2026' });
  assert.equal(b.ok, false);
  assert.ok(b.fehler.frist);
  assert.equal((await c.d.vorgaengeListe(c.boot)).length, 0);
  const leer = await c.d.ereignisAblaufAusfuehren(id, {});
  assert.equal(leer.ok, false);
});

test('Das Ereignis „Störung“ im Logbuch bleibt, wie es war: legt den Vorgang selbst an, ohne Frist', async () => {
  const c = await mitAktivitaet();
  await c.d.ereignisartenAusVorschlaegen();
  const abschnitt = (await c.d.heutigerTag(c.id)).abschnittId;
  const art = (await c.d.ereignisartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Störung').objekt.id;
  const r = await c.d.ereignisAnlegen(abschnitt, { artId: art, datum: '2026-11-09', zeit: '12:00', text: 'Ruder klemmt', auswirkung: 'nicht' });
  assert.ok(r.ok, JSON.stringify(r));
  const w = (await c.d.vorgangLaden(r.vorgangId)).aktuell.werte;
  assert.equal(w.auswirkung, 'nicht');
  assert.ok(!w.reparierenBis);
});

test('Frist: überfällig ist nur ein offener Vorgang mit Datum vor heute', () => {
  const W = MM.Werkstatt;
  assert.equal(W.ueberfaellig({ status: 'offen', reparierenBis: '2026-11-08' }, '2026-11-09'), true);
  assert.equal(W.ueberfaellig({ status: 'offen', reparierenBis: '2026-11-09' }, '2026-11-09'), false);
  assert.equal(W.ueberfaellig({ status: 'erledigt', reparierenBis: '2026-11-01' }, '2026-11-09'), false);
  assert.equal(W.ueberfaellig({ status: 'offen' }, '2026-11-09'), false);
});

test('Frist am Vorgang: bei „Angaben ändern“ setzen und wieder leeren; ein Datum in der Vergangenheit ist erlaubt', async () => {
  const c = await mitAktivitaet();
  const id = await ereignisMit(c, VORLAGE());
  const r = await c.d.ereignisAblaufAusfuehren(id, { text: 'Heizung kalt', frist: '2026-11-12' });
  const vid = r.vorgang.id;
  const a = await c.d.vorgangAendern(vid, { bezeichnung: 'Heizung kalt', auswirkung: 'bedingt', gemeldetAm: '2026-11-09', reparierenBis: '2026-11-01' });
  assert.ok(a.ok, JSON.stringify(a));
  assert.equal((await c.d.vorgangLaden(vid)).aktuell.werte.reparierenBis, '2026-11-01');
  const b = await c.d.vorgangAendern(vid, { bezeichnung: 'Heizung kalt', auswirkung: 'bedingt', gemeldetAm: '2026-11-09', reparierenBis: '' });
  assert.ok(b.ok, JSON.stringify(b));
  assert.ok(!(await c.d.vorgangLaden(vid)).aktuell.werte.reparierenBis);
});
