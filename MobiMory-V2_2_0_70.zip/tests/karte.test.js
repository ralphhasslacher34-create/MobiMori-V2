'use strict';
/* Schritt 9b (2.0.34): Karte – Kachel-Rechnung, Weg, Position auf der Route, Wettertext, Rhythmus. Reine Rechnung, ohne Netz. */
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/version.js');
require('../js/routen.js');
require('../js/karte.js');
const K = globalThis.MM.Karte;

test('Kachelnummer: Berlin bei Zoom 10 ist 550/335, die Adresse hat keine offenen Platzhalter', () => {
  const k = K.kachelNr(52.52, 13.405, 10);
  assert.deepEqual(k, { x: 550, y: 335 });
  const u = K.kachelUrl(10, 550, 335);
  assert.equal(u, 'https://tile.openstreetmap.org/10/550/335.png');
  assert.ok(!/[{}]/.test(u));
  assert.equal(K.kachelKey(10, 550, 335), '10/550/335');
});

test('Kachelnummer: Ränder bleiben im gültigen Bereich', () => {
  assert.deepEqual(K.kachelNr(89, 179.9999, 3), { x: 7, y: 0 });
  assert.deepEqual(K.kachelNr(-89, -180, 3), { x: 0, y: 7 });
  assert.deepEqual(K.kachelNr(0, 180, 0), { x: 0, y: 0 });
});

test('Streifen entlang der Route: Start und Ziel sind dabei, keine Doppelten, nach Stufe sortiert, bis Zoom 11 beiderseits eine Kachel mehr', () => {
  const punkte = [{ breite: 48.0, laenge: 8.0 }, { breite: 48.4, laenge: 8.3 }];
  const r = K.korridorKacheln(punkte, 8, 12);
  const keys = r.kacheln.map(k => K.kachelKey(k.z, k.x, k.y));
  assert.equal(new Set(keys).size, keys.length);
  for (let z = 8; z <= 12; z++) {
    const a = K.kachelNr(48.0, 8.0, z), b = K.kachelNr(48.4, 8.3, z);
    assert.ok(keys.includes(K.kachelKey(z, a.x, a.y)), 'Start bei ' + z);
    assert.ok(keys.includes(K.kachelKey(z, b.x, b.y)), 'Ziel bei ' + z);
  }
  for (let i = 1; i < r.kacheln.length; i++) assert.ok(r.kacheln[i - 1].z <= r.kacheln[i].z);
  /* Zoom 8: Puffer 1, also mindestens 3 mal 3 um den Start */
  const z8 = r.kacheln.filter(k => k.z === 8);
  assert.ok(z8.length >= 9, 'Puffer bei Zoom 8: ' + z8.length);
  /* Zoom 12: nur direkt an der Linie, deutlich weniger als ein Streifen mit Puffer */
  const a12 = K.kachelNr(48.0, 8.0, 12), b12 = K.kachelNr(48.4, 8.3, 12);
  const z12 = r.kacheln.filter(k => k.z === 12);
  assert.ok(z12.length <= (Math.abs(b12.x - a12.x) + Math.abs(b12.y - a12.y) + 3) * 2, 'Zoom 12 hat ' + z12.length);
});

test('Streifen: ohne gültige Punkte leer, ein einzelner Punkt gibt eine Kachel je Stufe (mit Puffer mehr)', () => {
  assert.deepEqual(K.korridorKacheln([], 5, 9).kacheln, []);
  assert.deepEqual(K.korridorKacheln([{ breite: 200, laenge: 0 }], 5, 9).kacheln, []);
  const r = K.korridorKacheln([{ breite: 50, laenge: 8 }], 12, 13);
  assert.equal(r.kacheln.length, 2);
});

test('Planung: kleine Route ist möglich mit Anzahl und Größe, eine sehr lange Route bei feiner Stufe ist zu groß, ohne Punkte ein klarer Grund', () => {
  const kurz = [{ breite: 48.0, laenge: 8.0 }, { breite: 48.1, laenge: 8.1 }];
  const g = K.planung(kurz, 'grob'), m = K.planung(kurz, 'mittel'), f = K.planung(kurz, 'fein');
  [g, m, f].forEach(p => { assert.equal(p.ok, true, JSON.stringify(p).slice(0, 200)); assert.ok(p.anzahl > 0 && p.anzahl <= K.QUELLE.maxKacheln); });
  assert.ok(g.anzahl < m.anzahl && m.anzahl < f.anzahl);
  assert.equal(f.bytes, f.anzahl * K.QUELLE.kachelBytes);
  assert.equal(f.kacheln.length, f.anzahl);
  const lang = [{ breite: 48.0, laenge: 8.0 }, { breite: 70.0, laenge: 25.0 }];
  const l = K.planung(lang, 'fein');
  assert.equal(l.ok, false);
  assert.equal(l.zuGross, true);
  assert.match(l.grund, /gröbere Stufe/);
  assert.equal(K.planung([], 'grob').ok, false);
  assert.match(K.planung([], 'grob').grund, /Route/);
  assert.equal(K.planung(kurz, 'riesig').ok, false);
});

test('Planung: nie mehr Kacheln als erlaubt', () => {
  const pt = [{ breite: 40, laenge: -10 }, { breite: 60, laenge: 30 }, { breite: 40, laenge: 50 }];
  K.STUFEN.forEach(st => { const p = K.planung(pt, st.wert); if (p.ok) assert.ok(p.anzahl <= K.QUELLE.maxKacheln); });
});

test('Größe als Text', () => {
  assert.equal(K.groesseText(500), '500 Byte');
  assert.equal(K.groesseText(20480), '20 KB');
  assert.equal(K.groesseText(2.5 * 1048576), '2,5 MB');
});

/* ---------- Weg ---------- */
const fix = (b, l, sek, gen) => ({ breite: b, laenge: l, zeitMs: sek * 1000, genauigkeit: gen === undefined ? 10 : gen });

test('Weg: erster Punkt kommt dazu, zu nahe Punkte nicht, genügend weit entfernte schon, der alte Weg bleibt unverändert', () => {
  const w0 = K.wegNeu();
  const w1 = K.wegPunkt(w0, fix(48.0, 8.0, 1000), 'land');
  assert.equal(w1.punkte.length, 1);
  assert.equal(w0.punkte.length, 0);
  const w2 = K.wegPunkt(w1, fix(48.00005, 8.0, 1005), 'land');      /* etwa 5 m */
  assert.equal(w2.punkte.length, 1);
  const w3 = K.wegPunkt(w2, fix(48.0005, 8.0, 1030), 'land');       /* etwa 55 m in 30 s */
  assert.equal(w3.punkte.length, 2);
  assert.equal(w1.punkte.length, 1);
});

test('Weg: ungenaue Punkte (über 50 m) und Sprünge werden verworfen und gezählt', () => {
  let w = K.wegPunkt(K.wegNeu(), fix(48.0, 8.0, 1000), 'land');
  w = K.wegPunkt(w, fix(48.01, 8.0, 1010, 80), 'land');
  assert.equal(w.punkte.length, 1); assert.equal(w.verworfen, 1);
  w = K.wegPunkt(w, fix(48.5, 8.0, 1020), 'land');                    /* 55 km in 20 s */
  assert.equal(w.punkte.length, 1); assert.equal(w.verworfen, 2);
  w = K.wegPunkt(w, null, 'land');
  w = K.wegPunkt(w, { breite: 'x', laenge: 1, zeitMs: 1 }, 'land');
  assert.equal(w.punkte.length, 1);
});

test('Weg: Auf dem Wasser gilt eine niedrigere Höchstgeschwindigkeit als an Land', () => {
  const a = fix(48.0, 8.0, 1000);
  const land = K.wegPunkt(K.wegPunkt(K.wegNeu(), a, 'land'), fix(48.0200, 8.0, 1000 + 60), 'land');
  const wasser = K.wegPunkt(K.wegPunkt(K.wegNeu(), a, 'wasser'), fix(48.0200, 8.0, 1000 + 60), 'wasser');
  assert.equal(land.punkte.length, 2);   /* etwa 2,2 km in 60 s = 133 km/h: an Land glaubhaft */
  assert.equal(wasser.punkte.length, 1); /* auf dem Wasser nicht */
});

test('Weg: nach einer Lücke von mehr als 10 Minuten beginnt ein neues Stück, es gibt keine gerade Linie dazwischen', () => {
  let w = K.wegPunkt(K.wegNeu(), fix(48.0, 8.0, 1000), 'land');
  w = K.wegPunkt(w, fix(48.001, 8.0, 1060), 'land');
  w = K.wegPunkt(w, fix(48.05, 8.05, 1060 + 15 * 60), 'land');
  w = K.wegPunkt(w, fix(48.051, 8.05, 1060 + 15 * 60 + 60), 'land');
  const stuecke = K.wegStuecke(w);
  assert.equal(stuecke.length, 2);
  assert.equal(stuecke[0].length, 2); assert.equal(stuecke[1].length, 2);
  /* Länge zählt nur innerhalb der Stücke: etwa 111 m + 111 m */
  assert.ok(Math.abs(K.wegLaengeKm(w) - 0.22) < 0.03, 'Länge ' + K.wegLaengeKm(w));
});

test('Weg: bei zu vielen Punkten wird ausgedünnt, der erste und der letzte bleiben', () => {
  let w = { punkte: [], verworfen: 0 };
  for (let i = 0; i < K.MAX_WEG; i++) w.punkte.push([48 + i * 0.0003, 8, 1000 + i * 30, 0]);
  const letzter = w.punkte[w.punkte.length - 1];
  w = K.wegPunkt(w, fix(48 + K.MAX_WEG * 0.0003, 8, 1000 + K.MAX_WEG * 30), 'land');
  assert.ok(w.punkte.length < K.MAX_WEG, 'Anzahl ' + w.punkte.length);
  assert.deepEqual(w.punkte[0], [48, 8, 1000, 0]);
  assert.ok(w.punkte[w.punkte.length - 1][0] > letzter[0]);
});

/* ---------- Position auf der Route ---------- */
const route = [{ breite: 48.0, laenge: 8.0, km: 0 }, { breite: 48.2, laenge: 8.0, km: 22.24 }, { breite: 48.4, laenge: 8.0, km: 44.48 }];

test('Position auf der Route: auf der Linie, daneben, vor dem Start und hinter dem Ziel', () => {
  const a = K.aufRoute(route, 48.1, 8.0);
  assert.ok(Math.abs(a.km - 11.12) < 0.1 && a.abstandKm < 0.02, JSON.stringify(a));
  const b = K.aufRoute(route, 48.3, 8.01);                       /* etwa 0,74 km daneben */
  assert.ok(Math.abs(b.km - 33.36) < 0.1 && Math.abs(b.abstandKm - 0.74) < 0.05, JSON.stringify(b));
  const c = K.aufRoute(route, 47.9, 8.0);
  assert.equal(c.km, 0); assert.ok(c.abstandKm > 10);
  const d = K.aufRoute(route, 48.6, 8.0);
  assert.ok(Math.abs(d.km - 44.48) < 0.01);
  assert.equal(K.aufRoute([route[0]], 48, 8), null);
  assert.equal(K.aufRoute(route, 200, 8), null);
});

test('Verspätung: im Plan, später, früher, vor der Abfahrt keine Aussage, zu weit weg keine Aussage', () => {
  const abfahrt = Date.UTC(2026, 10, 5, 8, 0);
  const pos = { km: 20, abstandKm: 0.2 };
  /* bei 10 km/h sollst du bei km 20 nach 2 Stunden sein */
  const v = (jetztMin, p) => K.verspaetungMin({ position: p || pos, kmh: 10, abfahrtMs: abfahrt, jetztMs: abfahrt + jetztMin * 60000 });
  assert.equal(v(120), 0);
  assert.equal(v(150), 30);
  assert.equal(v(105), -15);
  assert.equal(K.verspaetungMin({ position: pos, kmh: 10, abfahrtMs: abfahrt, jetztMs: abfahrt - 60000 }), null);
  assert.equal(v(150, { km: 20, abstandKm: 5 }), null);
  assert.equal(K.verspaetungMin({ position: null, kmh: 10, abfahrtMs: abfahrt, jetztMs: abfahrt + 150 * 60000 }), null);
  assert.equal(K.verspaetungMin({ position: pos, kmh: 0, abfahrtMs: abfahrt, jetztMs: abfahrt + 1 }), null);
  assert.equal(v(2000), null);
  assert.equal(K.verspaetungText(0), 'im Plan');
  assert.equal(K.verspaetungText(4), 'im Plan');
  assert.equal(K.verspaetungText(25), '25 min später als geplant');
  assert.equal(K.verspaetungText(-75), '1 h 15 min früher als geplant');
  assert.equal(K.verspaetungText(null), '');
});

/* ---------- Wetter jetzt ---------- */
test('Wettertext: Landfahrzeug mit km/h, Wasserfahrzeug mit Knoten, Wellen und Wasserstand; ohne Werte kein Text', () => {
  const w = { himmel: 'bedeckt', temperatur: 12.5, wind: 18, boeen: 30, windRichtung: 225, regenMm: 0, regenWahrscheinlichkeit: 20 };
  const t = K.wetterJetztText(w, null, 'kmh', false);
  assert.match(t, /^Wetter: bedeckt, 12,5 °C, Wind 18 km\/h aus SW, Böen 30 km\/h, Regen 0 mm, Regenwahrscheinlichkeit 20 %/);
  assert.match(t, /Modellwert der aktuellen Stunde/);
  const m = { welle: 0.8, wasserstand: 0.35, trend: 'steigend' };
  const t2 = K.wetterJetztText(w, m, 'kn', true);
  assert.match(t2, /^Wetter \(automatisch\): /);
  assert.match(t2, /Wind 18 kn aus SW/);
  assert.match(t2, /Welle 0,8 m, Wasserstand 0,35 m steigend/);
  assert.equal(K.wetterJetztText(null, null, 'kmh', false), null);
  assert.equal(K.wetterJetztText({ himmel: null, temperatur: null, wind: null, boeen: null, regenMm: null, regenWahrscheinlichkeit: null }, null, 'kmh'), null);
});

test('Wetter jetzt: die Abfrage holt nur zwei Tage und nutzt die Quellen aus Schritt 9', () => {
  const u = K.wetterJetztUrl(48.1, 8.2, 'kn');
  assert.match(u, /^https:\/\/api\.open-meteo\.com\/v1\/forecast\?latitude=48\.1&longitude=8\.2/);
  assert.match(u, /forecast_days=2/); assert.doesNotMatch(u, /forecast_days=16/); assert.match(u, /wind_speed_unit=kn/);
  const m = K.meerJetztUrl(54, 7);
  assert.match(m, /^https:\/\/marine-api\.open-meteo\.com/); assert.match(m, /forecast_days=2/); assert.doesNotMatch(m, /forecast_days=8/);
});

test('Rhythmus: nur Werte aus der Liste, fällig nach Ablauf, nach einem Versuch erst nach 10 Minuten wieder', () => {
  assert.equal(K.rhythmusGueltig('60'), 60); assert.equal(K.rhythmusGueltig(0), 0); assert.equal(K.rhythmusGueltig(45), null); assert.equal(K.rhythmusGueltig('x'), null);
  const min = 60000, jetzt = 100 * 60 * min;
  assert.equal(K.wetterFaellig(0, null, null, jetzt), false);
  assert.equal(K.wetterFaellig(60, null, null, jetzt), true);
  assert.equal(K.wetterFaellig(60, jetzt - 59 * min, null, jetzt), false);
  assert.equal(K.wetterFaellig(60, jetzt - 60 * min, null, jetzt), true);
  assert.equal(K.wetterFaellig(60, jetzt - 120 * min, jetzt - 5 * min, jetzt), false);
  assert.equal(K.wetterFaellig(60, jetzt - 120 * min, jetzt - 11 * min, jetzt), true);
});

test('Letzter Wetter-Eintrag wird aus den Ereignissen gelesen (Name egal in Groß- und Kleinschreibung)', () => {
  const e = [{ artName: 'Abfahrt', datum: '2026-11-04', zeit: '10:00' }, { artName: 'Wetter', datum: '2026-11-04', zeit: '09:15' }, { artName: 'wetter', datum: '2026-11-04', zeit: '11:30' }, { artName: 'Wetter', datum: null, zeit: '12:00' }];
  assert.equal(K.letztesWetterMs(e), new Date(2026, 10, 4, 11, 30).getTime());
  assert.equal(K.letztesWetterMs([]), null);
  assert.equal(K.istWetterArt(' Wetter '), true); assert.equal(K.istWetterArt('Wetterwarnung'), false);
});

test('Es gibt genau eine Quelle der Kacheln mit Nachweis, Grenzen und Vorsicht beim Abruf', () => {
  const q = K.QUELLE;
  assert.match(q.url, /\{z\}\/\{x\}\/\{y\}/);
  assert.match(q.nachweis, /OpenStreetMap/);
  assert.ok(q.maxKacheln <= 300 && q.parallel <= 2 && q.pauseMs >= 100);
  assert.ok(q.maxZoom >= 13);
  K.STUFEN.forEach(s => assert.ok(s.zMax <= 13 && s.zMin >= q.minZoom));
});
