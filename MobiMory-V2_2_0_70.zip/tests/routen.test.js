'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/version.js');
require('../js/routen.js');
const R = globalThis.MM.Routen;

const GPX_RTE = `<?xml version="1.0"?>
<gpx version="1.1" creator="x"><metadata><name>Rhein bei Gamsheim</name></metadata>
<rte><name>Testroute</name>
<rtept lon="8.0" lat="48.0"><name>Start &amp; Hafen</name></rtept>
<rtept lat="48.1" lon="8.0"/>
<rtept lat="48.2" lon="8.0"><name>Schleuse</name></rtept>
</rte></gpx>`;

test('GPX-Route: Punkte, Namen, Länge, Attribute in beliebiger Reihenfolge, selbstschließende Punkte', () => {
  const r = R.lesen(GPX_RTE, 'x.gpx');
  assert.equal(r.ok, true);
  assert.equal(r.format, 'gpx');
  assert.equal(r.name, 'Rhein bei Gamsheim');
  assert.equal(r.punkte.length, 3);
  assert.equal(r.punkte[0].name, 'Start & Hafen');
  assert.equal(r.punkte[2].name, 'Schleuse');
  assert.equal(r.punkte[1].name, undefined);
  assert.ok(Math.abs(r.laengeKm - 22.239) < 0.05, 'Länge ' + r.laengeKm);
  assert.equal(r.punkte[0].km, 0);
});

test('GPX-Spur: Punkte aus trkpt, benannter Wegpunkt nahe am Weg wird benannter Punkt', () => {
  const t = `<gpx><wpt lat="48.1001" lon="8.0001"><name>Anleger</name></wpt>
  <trk><name>Spur</name><trkseg>
  <trkpt lat="48.0" lon="8.0"><ele>1</ele></trkpt><trkpt lat="48.1" lon="8.0"><ele>1</ele></trkpt><trkpt lat="48.2" lon="8.0"/></trkseg></trk></gpx>`;
  const r = R.lesen(t, 'spur.gpx');
  assert.equal(r.ok, true);
  assert.equal(r.punkte.length, 3);
  assert.equal(r.punkte[1].name, 'Anleger');
  assert.equal(r.name, 'Spur');
});

test('GPX nur mit Wegpunkten: sie bilden die Route, mit Hinweis', () => {
  const r = R.lesen('<gpx><wpt lat="1" lon="1"><name>A</name></wpt><wpt lat="1" lon="2"><name>B</name></wpt></gpx>', 'w.gpx');
  assert.equal(r.ok, true);
  assert.equal(r.punkte.length, 2);
  assert.ok(r.hinweise.length === 1);
});

test('KML: Linie und benannter Punkt', () => {
  const t = `<kml><Document><name>Törn</name>
  <Placemark><name>Weg</name><LineString><coordinates>8.0,48.0,0 8.0,48.1,0 8.0,48.2,0</coordinates></LineString></Placemark>
  <Placemark><name>Mitte</name><Point><coordinates>8.0,48.1,0</coordinates></Point></Placemark></Document></kml>`;
  const r = R.lesen(t, 'a.kml');
  assert.equal(r.ok, true);
  assert.equal(r.format, 'kml');
  assert.equal(r.punkte.length, 3);
  assert.equal(r.punkte[1].name, 'Mitte');
  assert.equal(r.name, 'Törn');
});

test('GeoJSON: LineString und Point, Länge/Breite-Reihenfolge ist Länge zuerst', () => {
  const t = JSON.stringify({ type: 'FeatureCollection', features: [
    { type: 'Feature', properties: { name: 'Route A' }, geometry: { type: 'LineString', coordinates: [[8, 48], [8, 48.1], [8, 48.2]] } },
    { type: 'Feature', properties: { name: 'Halt' }, geometry: { type: 'Point', coordinates: [8, 48.1] } }] });
  const r = R.lesen(t, 'r.geojson');
  assert.equal(r.ok, true);
  assert.equal(r.format, 'geojson');
  assert.equal(r.punkte[0].breite, 48);
  assert.equal(r.punkte[0].laenge, 8);
  assert.equal(r.punkte[1].name, 'Halt');
  assert.equal(r.name, 'Route A');
});

test('Fehler: unbekanntes Format, leere Datei, keine Route, kaputtes JSON, ungültige Koordinaten', () => {
  assert.equal(R.lesen('hallo', 'x.txt').ok, false);
  assert.equal(R.lesen('', 'x.gpx').ok, false);
  assert.match(R.lesen('<gpx></gpx>', 'x.gpx').fehler, /mindestens zwei Punkte/);
  assert.equal(R.lesen('{kaputt', 'x.json').ok, false);
  assert.equal(R.lesen('<gpx><rte><rtept lat="95" lon="8"/><rtept lat="48" lon="8"/></rte></gpx>', 'x.gpx').ok, false);
});

test('Vereinfachen: zu viele Punkte werden weniger, Länge bleibt, Anfang, Ende und Namen bleiben', () => {
  const pts = [];
  for (let i = 0; i <= 3000; i++) pts.push({ breite: 48 + i * 0.0001, laenge: 8 + Math.sin(i / 50) * 0.001 });
  pts[1500].name = 'Mitte';
  const r = R.punkteAufbereiten(pts);
  assert.ok(r.punkte.length <= R.MAX_PUNKTE, 'Anzahl ' + r.punkte.length);
  assert.equal(r.punkte[0].km, 0);
  assert.ok(r.punkte.some(p => p.name === 'Mitte'));
  assert.equal(r.punkte[r.punkte.length - 1].km, r.laengeKm);
  assert.ok(r.laengeKm > 33 && r.laengeKm < 36, 'Länge ' + r.laengeKm);
});

test('Fahrplan: 100 km mit 50 km/h sind 2 h; Knoten werden umgerechnet; Abfahrt gibt Ankunftszeiten', () => {
  const punkte = [{ km: 0, breite: 48, laenge: 8, name: 'A' }, { km: 40, breite: 48.3, laenge: 8 }, { km: 100, breite: 48.9, laenge: 8, name: 'B' }];
  const f = R.fahrplan(punkte, { geschwindigkeit: 50, einheit: 'kmh', abfahrt: '2026-11-10T08:00' });
  assert.equal(f.ok, true);
  assert.equal(f.dauerMin, 120);
  assert.equal(f.ankunft, '2026-11-10T10:00');
  assert.equal(f.zeilen[1].eta, '2026-11-10T08:48');
  const kn = R.fahrplan(punkte, { geschwindigkeit: 10, einheit: 'kn', abfahrt: '2026-11-10T08:00' });
  assert.equal(kn.dauerMin, Math.round(100 / 18.52 * 60));
  const ohneZeit = R.fahrplan(punkte, { geschwindigkeit: 50, einheit: 'kmh' });
  assert.equal(ohneZeit.zeilen[2].eta, null);
  assert.equal(R.fahrplan(punkte, { geschwindigkeit: 0, einheit: 'kmh' }).grund, 'keine_geschwindigkeit');
  assert.equal(R.fahrplan([punkte[0]], { geschwindigkeit: 5, einheit: 'kn' }).grund, 'keine_route');
});

test('Fahrplan über Mitternacht rechnet den Tag weiter', () => {
  const punkte = [{ km: 0, breite: 0, laenge: 0 }, { km: 60, breite: 0.5, laenge: 0 }];
  const f = R.fahrplan(punkte, { geschwindigkeit: 30, einheit: 'kmh', abfahrt: '2026-12-31T23:00' });
  assert.equal(f.ankunft, '2027-01-01T01:00');
});

test('Messpunkte: Start und Ziel dabei, nicht mehr als 12, aufsteigend, benannte Punkte bleiben', () => {
  const pts = [];
  for (let i = 0; i <= 100; i++) pts.push({ km: i * 5, breite: 48 + i * 0.045, laenge: 8, name: i === 40 ? 'Hafen X' : undefined });
  const m = R.messpunkte(pts, 10, 'kn');
  assert.ok(m.length >= 3 && m.length <= R.MAX_MESSPUNKTE, 'Anzahl ' + m.length);
  assert.equal(m[0].km, 0);
  assert.equal(m[m.length - 1].km, 500);
  for (let i = 1; i < m.length; i++) assert.ok(m[i].km > m[i - 1].km);
  assert.ok(m.some(x => x.name === 'Hafen X'));
  assert.deepEqual(R.messpunkte(pts, null, 'kn'), []);
});

test('Wetter zur Zeit: nächste Stunde, Himmel als Text, nichts außerhalb der Reihe', () => {
  const t0 = 1800000000;
  const antwort = { hourly: { time: [t0, t0 + 3600, t0 + 7200], temperature_2m: [10, 12.34, 11], precipitation: [0, 0.5, 0], precipitation_probability: [10, 60, 20],
    wind_speed_10m: [12.4, 18.6, 9], wind_gusts_10m: [20, 31.2, 15], wind_direction_10m: [90, 270, 0], weather_code: [1, 61, 3] } };
  const w = R.wetterZurZeit(antwort, t0 + 3500);
  assert.equal(w.temperatur, 12.3);
  assert.equal(w.wind, 19);
  assert.equal(w.boeen, 31);
  assert.equal(w.himmel, 'leichter Regen');
  assert.equal(w.regenWahrscheinlichkeit, 60);
  assert.equal(R.wetterZurZeit(antwort, t0 + 86400), null);
  assert.equal(R.wetterZurZeit(null, t0), null);
  assert.equal(R.himmelsrichtung(270), 'W');
  assert.equal(R.himmelsrichtung(350), 'N');
});

function tideReihe(stunden, amplitude, periodeH) {
  const t0 = 1800000000, time = [], s = [];
  for (let i = 0; i < stunden; i++) { time.push(t0 + i * 3600); s.push(Math.round(amplitude * Math.sin(2 * Math.PI * i / periodeH) * 100) / 100); }
  return { hourly: { time, sea_level_height_msl: s, wave_height: s.map(() => 0.5) }, t0 };
}

test('Gezeiten: Hoch- und Niedrigwasser aus einer Wasserstandsreihe, Zeit über die Parabel verfeinert', () => {
  const a = tideReihe(60, 1.5, 12.42);
  const g = R.gezeiten(a);
  assert.ok(g.length >= 8 && g.length <= 10, 'Anzahl ' + g.length);
  const ersteHoch = g.find(x => x.art === 'hoch');
  const soll = a.t0 + (12.42 / 4) * 3600;
  assert.ok(Math.abs(ersteHoch.sek - soll) < 900, 'Abweichung ' + (ersteHoch.sek - soll));
  assert.ok(Math.abs(ersteHoch.hoehe - 1.5) < 0.1);
  for (let i = 1; i < g.length; i++) { assert.notEqual(g[i].art, g[i - 1].art); assert.ok(g[i].sek > g[i - 1].sek); }
  const n = R.naechsteGezeiten(g, a.t0 + 3600 * 5);
  assert.equal(n.hoch.art, 'hoch');
  assert.equal(n.niedrig.art, 'niedrig');
});

test('Gezeiten: ohne Schwankung (kein Tidenmeer) kommen keine Hoch- und Niedrigwasser', () => {
  assert.deepEqual(R.gezeiten(tideReihe(48, 0.03, 12.42)), []);
  assert.deepEqual(R.gezeiten({}), []);
});

test('Auswerten: Abfahrt früher oder später verschiebt die Zeit am Punkt, schwerste Stelle wird gefunden', () => {
  const t0 = Math.floor(new Date(2026, 10, 10, 8, 0).getTime() / 1000);
  const stunden = [];
  for (let i = 0; i < 24; i++) stunden.push(t0 - 3600 * 4 + i * 3600);
  const wetter = { hourly: { time: stunden, wind_speed_10m: stunden.map((_, i) => 5 + i), wind_gusts_10m: stunden.map((_, i) => 10 + i * 2), weather_code: stunden.map(() => 1) } };
  const mp = [{ nr: 1, name: 'Start', km: 0, minuten: 0, breite: 48, laenge: 8 }, { nr: 2, name: 'Ziel', km: 20, minuten: 120, breite: 48.2, laenge: 8 }];
  const abfahrt = t0 * 1000;
  const norm = R.auswerten(mp, abfahrt, 0, [{ wetter }, { wetter }], false);
  const spaet = R.auswerten(mp, abfahrt, 60, [{ wetter }, { wetter }], false);
  assert.equal(norm.zeilen[1].wetter.boeen, 10 + 6 * 2);
  assert.equal(spaet.zeilen[1].wetter.boeen, 10 + 7 * 2);
  assert.equal(norm.schwerste.boeen.nr, 2);
  assert.equal(norm.zeilen[0].meer, null);
});

test('GPX-Ausgabe lässt sich wieder einlesen, Sonderzeichen bleiben erhalten', () => {
  const pts = [{ breite: 48, laenge: 8, name: 'A & B <1>' }, { breite: 48.1, laenge: 8.1 }];
  const r = R.lesen(R.gpx('Meine "Route"', pts), 'x.gpx');
  assert.equal(r.ok, true);
  assert.equal(r.punkte.length, 2);
  assert.equal(r.punkte[0].name, 'A & B <1>');
  assert.equal(r.name, 'Meine "Route"');
});

test('URLs für Wetter und Marine nennen Ort, Windeinheit und Variablen', () => {
  const u = R.wetterUrl(48.5, 8.25, 'kn');
  assert.ok(u.startsWith('https://api.open-meteo.com/v1/forecast?latitude=48.5&longitude=8.25'));
  assert.ok(u.includes('wind_speed_unit=kn') && u.includes('wind_gusts_10m') && u.includes('timeformat=unixtime'));
  assert.ok(R.wetterUrl(1, 2, 'kmh').includes('wind_speed_unit=kmh'));
  const m = R.marineUrl(54.1, 7.9);
  assert.ok(m.startsWith('https://marine-api.open-meteo.com/v1/marine?') && m.includes('sea_level_height_msl') && m.includes('wave_height'));
});

test('GPS-Spur: zählt Bewegung, ignoriert Stehen, ungenaue Punkte und Sprünge', () => {
  let s = R.spurNeu();
  const t0 = 1800000000000;
  const pos = (i, extra) => Object.assign({ breite: 48, laenge: 8 + i * 0.0009, genauigkeit: 8, zeitMs: t0 + i * 10000 }, extra || {});
  for (let i = 0; i <= 10; i++) s = R.spurPunkt(s, pos(i), 'land');
  assert.ok(s.km > 0.6 && s.km < 0.7, 'km ' + s.km);
  const vorher = s.km;
  s = R.spurPunkt(s, Object.assign(pos(10), { zeitMs: t0 + 200000 }), 'land');
  assert.equal(s.km, vorher, 'Stehen zählt nicht');
  s = R.spurPunkt(s, Object.assign(pos(11), { genauigkeit: 120, zeitMs: t0 + 210000 }), 'land');
  assert.equal(s.km, vorher, 'ungenau zählt nicht');
  assert.equal(s.verworfen, 1);
  s = R.spurPunkt(s, { breite: 49, laenge: 8, genauigkeit: 5, zeitMs: t0 + 220000 }, 'land');
  assert.equal(s.km, vorher, 'Sprung zählt nicht');
  assert.equal(s.verworfen, 2);
  assert.equal(R.spurPunkt(s, null, 'land').km, vorher);
});

test('GPS-Spur: ohne „Zählen“ (nicht in Fahrt) merkt sich die App nur die Position, nach einer Lücke zählt der Sprung nicht', () => {
  let s = R.spurNeu();
  const t0 = 1800000000000;
  s = R.spurPunkt(s, { breite: 48, laenge: 8, genauigkeit: 5, zeitMs: t0 }, 'wasser', false);
  assert.equal(s.km, 0); assert.equal(s.letzter.laenge, 8);
  s = R.spurPunkt(s, { breite: 48, laenge: 8.01, genauigkeit: 5, zeitMs: t0 + 20000 }, 'wasser', false);
  assert.equal(s.km, 0, 'nicht in Fahrt: nichts zählt'); assert.equal(s.letzter.laenge, 8.01);
  s = R.spurPunkt(s, { breite: 48, laenge: 8.0109, genauigkeit: 5, zeitMs: t0 + 40000 }, 'wasser', true);
  assert.ok(s.km > 0.06 && s.km < 0.07, 'km ' + s.km);
  const vorLuecke = s.km;
  s = R.spurPunkt(s, { breite: 48.2, laenge: 8.2, genauigkeit: 5, zeitMs: t0 + 40000 + 3600000 }, 'wasser', true);
  assert.equal(s.km, vorLuecke, 'nach einer Stunde Pause (App im Hintergrund) wird nichts geschätzt');
  assert.equal(s.luecken, 1); assert.equal(s.letzter.breite, 48.2);
});
