'use strict';
/* 2.0.44: Aufbau von Cockpit, Tagesabschluss und Tag-Auswahl im Quelltext (es gibt keinen echten Browser im Test). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const ansicht = lesen('js/ansicht.js');
function funktion(name) {
  const start = ansicht.indexOf('  function ' + name + '(');
  assert.ok(start >= 0, 'Funktion fehlt: ' + name);
  return ansicht.slice(start, ansicht.indexOf('\n  }\n', start));
}

test('GPS-Punkte laufen auch in die Geschwindigkeit, mit der Geschwindigkeit des Geräts', () => {
  assert.match(ansicht, /geschwindigkeit: typeof p\.coords\.speed/);
  assert.match(ansicht, /gpsSpurPunkt\(\);\s*gpsFahrtPunkt\(\);/);
});
test('Das Wechselfeld wird nicht bei jedem GPS-Punkt neu gebaut', () => {
  assert.ok(!funktion('gpsZeichnen').includes("h('button'"));
  assert.match(funktion('gpsZeichnen'), /tempoAktualisieren\(\)/);
  assert.match(funktion('positionZeile'), /tempoKnopfBauen\(\)/);
});
test('Die Wetter-Meldung verschwindet von selbst', () => {
  const f = funktion('cockpitVollbild');
  assert.match(f, /meldungKurz/); assert.match(f, /setTimeout\(meldungWeg, 6000\)/);
  assert.match(f, /fahrtAutoPlanen\(/);
});
test('Der Tagesabschluss schreibt die Geschwindigkeit', () => {
  assert.match(funktion('abschlussFormular'), /daten\.fahrtTagAbschliessen\(/);
});
test('Zusammenfassung und Logbuch zeigen bei der Auswahl nur den gewählten Tag', () => {
  assert.match(funktion('zusammenfassungBlock'), /tagWaehler\(aktId, wahl\)/);
  assert.match(funktion('logbuchPanel'), /tagWaehler\(id, wahl\)/);
  assert.match(ansicht, /pageYOffset/);
});
test('Neue Module sind in index.html und sw.js eingetragen', () => {
  ['js/fahrt.js', 'js/tagwahl.js'].forEach(m => { assert.ok(lesen('index.html').includes(m)); assert.ok(lesen('sw.js').includes(m)); });
});
