'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/reiseorte.js');
require('../js/daten.js');
const MM = globalThis.MM;

const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
function neueDaten(jetzt) {
  let t = 0;
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: jetzt || (() => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString()) });
}
const datei = (name, inhalt, typ) => new Blob([inhalt], { type: typ || 'application/pdf' });
Object.defineProperty(Blob.prototype, 'name', { configurable: true, get() { return this._name || 'datei'; } });
const mitName = (b, n) => { b._name = n; return b; };

/* Ein Gerät mit Fahrzeug, Dokument (Datei), Person, Nachweis mit Scan, Aktivität, Frist */
async function gefuellt() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot', registriernummer: 'D-1234' })).id;
  const m = (await d.komponenteAnlegen(fz, null, 'motor', { bezeichnung: 'Motor' })).id;
  const z = (await d.zaehlerAnlegen(fz, m, 'stunden', { bezeichnung: 'Betriebsstunden' })).id;
  await d.zaehlerStandEintragen(z, { wert: '100' });
  await d.fristAnlegen(fz, m, { bezeichnung: 'Ölwechsel', kategorie: 'wartung', zaehlerId: z, zaehlerWert: '100' });
  const dok = await d.dokumentAnlegen(fz, m, { quelle: 'datei', datei: mitName(datei('a', 'PDF-INHALT-ANLEITUNG'), 'anleitung.pdf'), art: 'bedienung', bezeichnung: 'Anleitung Motor' });
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna Beispiel', funktionen: ['Skipper'] })).id;
  const art = (await d.nachweisartAusVorschlag('DE_SPFV_SBF')).id;
  const nw = await d.nachweisAnlegen('person', anna, art, { nummer: 'SBF-42', datei: mitName(datei('s', 'SCAN-AUSWEIS-BYTES', 'image/jpeg'), 'sbf.jpg') });
  const arten = await d.aktivitaetsartenListe();
  const akt = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: arten[0].objekt.id, fahrzeugId: fz, vonDatum: '2026-12-01', bisDatum: '2026-12-05', verantwortlichId: anna });
  await d.sicherungEinstellen({ erinnerungTage: 14 });
  return { d, fz, m, z, dok: dok.id, anna, nw: nw.id, akt: akt.id };
}
const text = async blob => new TextDecoder().decode(await blob.arrayBuffer());

test('Sichern mit Dateien und wieder einspielen auf einem leeren Gerät: alles ist wieder da', async () => {
  const a = await gefuellt();
  const s = await a.d.sicherungErzeugen({ mitDateien: true });
  assert.match(s.name, /^MobiMory-Sicherung_2026-11-03_12-\d\d\.mmsicherung$/);
  assert.equal(s.dateien, 2); assert.equal(s.verschluesselt, false);
  assert.equal(s.zahlen.fahrzeuge, 1); assert.equal(s.zahlen.personen, 1); assert.equal(s.zahlen.nachweise, 1); assert.equal(s.zahlen.dokumente, 1);

  const b = neueDaten();
  await b.starten();
  assert.equal((await b.fahrzeugListe()).length, 0);
  const g = await b.sicherungLesen(s.bytes, '');
  const v = await b.sicherungVorschau(g);
  assert.equal(v.zahlen.fahrzeuge, 1); assert.equal(v.jetzt.fahrzeuge, 0); assert.equal(v.dateien, 2); assert.equal(v.mitDateien, true);
  await b.sicherungEinspielen(g);

  assert.deepEqual((await b.fahrzeugListe()).map(x => x.aktuell.werte.bezeichnung), ['Boot']);
  const dokNeu = await b.dokumentLaden(a.dok);
  assert.equal(dokNeu.aktuell.werte.bezeichnung, 'Anleitung Motor');
  assert.equal(await text((await b.dateiHolen(a.dok)).inhalt), 'PDF-INHALT-ANLEITUNG');
  assert.equal((await b.dateiHolen(a.dok)).name, 'anleitung.pdf');
  assert.equal(await text((await b.nachweisDateiHolen(a.nw)).inhalt), 'SCAN-AUSWEIS-BYTES');
  const nw = await b.nachweisLaden(a.nw);
  assert.equal(nw.aktuell.werte.nummer, 'SBF-42'); assert.equal(nw.besitzer.name, 'Anna Beispiel');
  assert.equal((await b.aktivitaetLaden(a.akt)).aktuell.werte.bezeichnung, 'Törn');
  assert.equal((await b.zaehlerLaden(a.z)).stand.wert, 100);
  assert.equal((await b.fristenListe(a.fz)).length, 1);
  assert.equal(b.datenraumId, a.d.datenraumId, 'derselbe Datenraum');
  /* Verläufe und Korrekturen sind mit dabei */
  await b.personAendern(a.anna, { bezeichnung: 'Anna Beispiel', funktionen: ['Skipper', 'Crew'] });
  assert.equal((await b.personLaden(a.anna)).verlauf.length, 2);
});

test('Nach dem Einspielen gilt als letzte Sicherung das Datum der Sicherung, die Erinnerung bleibt', async () => {
  const a = await gefuellt();
  const s = await a.d.sicherungErzeugen({ mitDateien: false });
  const b = neueDaten(); await b.starten();
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  const info = await b.sicherungInfo();
  assert.equal(info.letzte, s.erstelltAm);
  assert.equal(info.erinnerungTage, 14);
});

test('Sichern ohne Dateien: Dokumente bleiben als Eintrag, die Dateien fehlen und das wird sichtbar', async () => {
  const a = await gefuellt();
  const s = await a.d.sicherungErzeugen({ mitDateien: false });
  assert.equal(s.dateien, 0); assert.equal(s.mitDateien, false);
  const b = neueDaten(); await b.starten();
  const g = await b.sicherungLesen(s.bytes, '');
  assert.equal((await b.sicherungVorschau(g)).mitDateien, false);
  await b.sicherungEinspielen(g);
  assert.equal((await b.dokumentLaden(a.dok)).aktuell.werte.dateiName, 'anleitung.pdf');
  assert.equal(await b.dateiHolen(a.dok), null);
  assert.equal(await b.nachweisDateiHolen(a.nw), null);
  assert.ok(s.bytes.length < (await a.d.sicherungErzeugen({ mitDateien: true })).bytes.length);
});

test('Verschlüsselte Sicherung: nichts im Klartext, mit Schlüsselwort wieder lesbar', async () => {
  const a = await gefuellt();
  const s = await a.d.sicherungErzeugen({ mitDateien: true, schluessel: 'mein geheimes wort' });
  assert.equal(s.verschluesselt, true);
  const roh = Buffer.from(s.bytes).toString('latin1');
  for (const geheim of ['Anna Beispiel', 'SBF-42', 'SCAN-AUSWEIS-BYTES', 'Boot', 'D-1234']) assert.equal(roh.includes(geheim), false, geheim);
  const b = neueDaten(); await b.starten();
  await assert.rejects(b.sicherungLesen(s.bytes, ''), e => e.code === 'schluessel_noetig');
  await assert.rejects(b.sicherungLesen(s.bytes, 'falsch'), e => e.code === 'schluessel');
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, 'mein geheimes wort'));
  assert.equal((await b.personenListe())[0].aktuell.werte.bezeichnung, 'Anna Beispiel');
  assert.equal(await text((await b.nachweisDateiHolen(a.nw)).inhalt), 'SCAN-AUSWEIS-BYTES');
});

test('Wiederherstellen ersetzt alles: Daten, die nicht in der Sicherung stehen, sind danach weg', async () => {
  const a = await gefuellt();
  const s = await a.d.sicherungErzeugen({ mitDateien: true });
  await a.d.personAnlegen({ bezeichnung: 'Nach der Sicherung' });
  await a.d.fahrzeugAnlegen('auto', { bezeichnung: 'Auto nach der Sicherung' });
  assert.equal((await a.d.personenListe()).length, 2);
  await a.d.sicherungEinspielen(await a.d.sicherungLesen(s.bytes, ''));
  assert.deepEqual((await a.d.personenListe()).map(x => x.aktuell.werte.bezeichnung), ['Anna Beispiel']);
  assert.deepEqual((await a.d.fahrzeugListe()).map(x => x.aktuell.werte.bezeichnung), ['Boot']);
});

test('Defekte Sicherung: klare Fehler, und auf dem Gerät ändert sich nichts', async () => {
  const a = await gefuellt();
  const s = await a.d.sicherungErzeugen({ mitDateien: true });
  const vorher = await a.d.sicherungZahlen();
  const verdreht = s.bytes.slice(); verdreht[verdreht.length - 3] ^= 255;
  await assert.rejects(a.d.sicherungLesen(verdreht, ''), e => e.code === 'beschaedigt');
  await assert.rejects(a.d.sicherungLesen(s.bytes.slice(0, s.bytes.length - 10), ''), e => e.code === 'beschaedigt');
  await assert.rejects(a.d.sicherungLesen(new TextEncoder().encode('kein MobiMory'), ''), e => e.code === 'format');
  assert.deepEqual(await a.d.sicherungZahlen(), vorher);
});

test('Sicherung aus einer neueren Version oder mit unbekanntem Inhalt wird abgelehnt', async () => {
  const d = neueDaten(); await d.starten();
  const bau = async kopf => d.sicherungLesen(await MM.Sicherung.bauen(kopf, [], ''), '');
  await assert.rejects(bau({ format: 2, dbVersion: 7, tabellen: {} }), e => e.code === 'neuer');
  await assert.rejects(bau({ format: 1, dbVersion: 99, app: '9.9.9', tabellen: {} }), e => e.code === 'neuer');
  await assert.rejects(bau({ format: 1, dbVersion: 7, tabellen: { geheimtabelle: [] } }), e => e.code === 'beschaedigt');
  await assert.rejects(bau({ format: 1, dbVersion: 7, tabellen: { fahrzeuge: [{ name: 'ohne id' }] } }), e => e.code === 'beschaedigt');
  await assert.rejects(bau({ format: 1, dbVersion: 7, tabellen: { fahrzeuge: [{ id: 'a' }] }, zaehlung: { fahrzeuge: 5 } }), e => e.code === 'beschaedigt');
  await assert.rejects(bau({ format: 1, dbVersion: 7, tabellen: { dateien: [{ id: 'x', inhalt: { $datei: 3 } }] } }), e => e.code === 'beschaedigt');
  /* eine ältere Sicherung mit weniger Tabellen ist in Ordnung */
  const alt = await bau({ format: 1, dbVersion: 5, app: '2.0.7', tabellen: { fahrzeuge: [{ id: 'f1', datenraumId: 'dr', art: 'auto', erstelltAm: 'x' }] } });
  assert.equal(alt.kopf.app, '2.0.7');
});

test('Wiederherstellen ist alles oder nichts: scheitert das Schreiben, bleibt der alte Stand', async () => {
  const a = await gefuellt();
  const s = await a.d.sicherungErzeugen({ mitDateien: true });
  const g = await a.d.sicherungLesen(s.bytes, '');
  await a.d.personAnlegen({ bezeichnung: 'Neu' });
  const vorher = await a.d.sicherungZahlen();
  const orig = a.d.speicher.ersetzenAlles;
  a.d.speicher.ersetzenAlles = () => Promise.reject(new Error('Speicher voll'));
  await assert.rejects(a.d.sicherungEinspielen(g), /Speicher voll/);
  a.d.speicher.ersetzenAlles = orig;
  assert.deepEqual(await a.d.sicherungZahlen(), vorher);
  /* und der Speicher selbst lehnt Unbekanntes vor jeder Änderung ab */
  await assert.rejects(a.d.speicher.ersetzenAlles({ geheim: [{ id: 'x' }] }), /Unbekannte Tabelle/);
  assert.deepEqual(await a.d.sicherungZahlen(), vorher);
});

test('Erinnerung: nie gesichert, zu alt, frisch, ausgeschaltet, ohne Daten', async () => {
  let jetzt = new Date(2026, 10, 3, 12, 0, 0);
  const d = neueDaten(() => jetzt.toISOString());
  await d.starten();
  assert.deepEqual(await d.sicherungErinnerung(), { faellig: false }, 'ohne Daten keine Erinnerung');
  await d.personAnlegen({ bezeichnung: 'Anna' });
  assert.deepEqual(await d.sicherungErinnerung(), { faellig: true, grund: 'nie' });
  await d.sicherungEinstellen({ letzteSicherung: new Date(2026, 9, 30, 9, 0).toISOString() });
  const frisch = await d.sicherungErinnerung();
  assert.equal(frisch.faellig, false); assert.equal(frisch.tage, 4);
  jetzt = new Date(2026, 11, 3, 12, 0, 0);
  const alt = await d.sicherungErinnerung();
  assert.equal(alt.faellig, true); assert.equal(alt.grund, 'alt'); assert.equal(alt.tage, 34);
  await d.sicherungEinstellen({ erinnerungTage: 90 });
  assert.equal((await d.sicherungErinnerung()).faellig, false);
  await d.sicherungEinstellen({ erinnerungTage: 0 });
  assert.equal((await d.sicherungErinnerung()).faellig, false, 'Erinnerung aus');
});

test('Zahlen für die Vorschau: Platz der Dateien und Anzahl', async () => {
  const a = await gefuellt();
  const z = await a.d.sicherungZahlen();
  assert.equal(z.dateien, 2);
  assert.equal(z.dateiBytes, 'PDF-INHALT-ANLEITUNG'.length + 'SCAN-AUSWEIS-BYTES'.length);
  assert.equal(z.aktivitaeten, 1); assert.equal(z.komponenten, 1); assert.equal(z.fristen, 1); assert.equal(z.zaehler, 1);
});

test('Löschen aller Daten leert auch die Einstellungen', async () => {
  const a = await gefuellt();
  await a.d.allesLoeschen();
  assert.equal((await a.d.speicher.alle('einstellungen')).length, 0);
});
