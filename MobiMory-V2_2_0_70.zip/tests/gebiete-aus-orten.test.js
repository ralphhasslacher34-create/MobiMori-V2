'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'reiseorte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;

const JETZT = new Date(2026, 10, 5, 12, 0, 0).toISOString();
const item = (id, name, lat, lon, adr) => ({ osm_type: 'node', osm_id: id, name, lat: String(lat), lon: String(lon), address: Object.assign({ country: 'Deutschland', country_code: 'de', state: 'Baden-Württemberg' }, adr) });
const TREFFER = {
  boeblingen: item(1, 'Eutingen', 48.5651, 8.8951, { village: 'Eutingen', municipality: 'Gäufelden', county: 'Landkreis Böblingen' }),
  enzkreis: item(2, 'Eutingen', 48.9181, 8.7803, { village: 'Eutingen an der Enz', county: 'Enzkreis' }),
  sersheim: item(3, 'Sersheim', 48.9561, 9.0546, { village: 'Sersheim', county: 'Landkreis Ludwigsburg' }),
  kroatien: { osm_type: 'node', osm_id: 4, name: 'Biograd na Moru', lat: '43.9387', lon: '15.4443', address: { town: 'Biograd na Moru', county: 'Zadarska županija', country: 'Kroatien', country_code: 'hr' } }
};
const treffer = (daten, key) => MM.Ortssuche.kandidaten([TREFFER[key]])[0];

async function neu(opt) {
  let t = 0;
  const anfragen = [];
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), {
    jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(),
    holeJson: url => { anfragen.push(url); return opt && opt.netz === false ? Promise.reject(new Error('kein Netz')) : Promise.resolve([TREFFER.boeblingen, TREFFER.enzkreis]); }
  });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = n => arten.find(x => x.aktuell.werte.bezeichnung === n).objekt.id;
  const sbf = (await d.nachweisartAnlegen({ bezeichnung: 'Sportbootführerschein', gehoertZu: 'person', hatAblauf: 'nein' })).id;
  return { d, boot, wm, anna, artId, sbf, anfragen };
}
const akt = (c, extra) => Object.assign({ bezeichnung: 'Törn', artId: c.artId('Törn'), fahrzeugId: c.boot, vonDatum: '2026-12-01', bisDatum: '2026-12-10', verantwortlichId: c.anna }, extra || {});
const scan = { name: 'scan.jpg', type: 'image/jpeg', size: 100 };
const namen = async d => (await d.gebieteListe()).map(x => x.aktuell.werte.bezeichnung);

test('Ortssuche über die Datenschicht: Treffer mit nachgebautem Netz, ohne Netz ein klarer Hinweis, nichts wird gespeichert', async () => {
  const c = await neu(); const r = await c.d.ortSuchen('Eutingen');
  assert.equal(r.ok, true); assert.equal(r.kandidaten.length, 2);
  assert.equal(c.anfragen.length, 1); assert.ok(c.anfragen[0].includes('Eutingen'));
  const o = await neu({ netz: false }); const x = await o.d.ortSuchen('Eutingen');
  assert.equal(x.ok, false); assert.equal(x.grund, 'netz');
  assert.equal((await o.d.orteListe()).length, 0); assert.equal((await o.d.gebieteListe()).length, 0);
});

test('Ort aus Treffer: Ort mit Position und die Gebiete Land, Region, Kreis in einem Zug, Ort gilt als geprüft', async () => {
  const c = await neu(); const d = c.d;
  const r = await d.ortAusTreffer(treffer(d, 'sersheim'));
  assert.equal(r.ok, true); assert.equal(r.name, 'Sersheim'); assert.deepEqual(r.gebiete.neu, 3);
  assert.deepEqual((await namen(d)).sort(), ['Baden-Württemberg', 'Deutschland', 'Landkreis Ludwigsburg']);
  const o = await d.ortLaden(r.id);
  assert.equal(o.aktuell.werte.ortGeprueft, 'ja'); assert.equal(o.aktuell.werte.land, 'Deutschland');
  assert.equal(o.aktuell.werte.positionBreite, 48.9561);
  assert.deepEqual(o.gebietPfad.map(g => g.name), ['Deutschland', 'Baden-Württemberg', 'Landkreis Ludwigsburg']);
  assert.deepEqual(o.gebietPfad.map(g => g.ebene), ['land', 'region', 'kreis']);
  const liste = await d.gebieteListe();
  assert.ok(liste.every(x => x.aktuell.werte.herkunft === 'ortssuche'));
});

test('Gebietsbibliothek: gleiche Ketten werden wiederverwendet, ein neuer Kreis kommt nur einmal dazu', async () => {
  const c = await neu(); const d = c.d;
  const a = await d.ortAusTreffer(treffer(d, 'sersheim'));
  const b = await d.ortAusTreffer(treffer(d, 'boeblingen'));
  assert.equal(b.gebiete.neu, 1, 'nur der Landkreis Böblingen ist neu');
  assert.equal((await d.gebieteListe()).length, 4);
  const ids = (await d.ortLaden(b.id)).gebietPfad.map(g => g.id), ids2 = (await d.ortLaden(a.id)).gebietPfad.map(g => g.id);
  assert.equal(ids[0], ids2[0]); assert.equal(ids[1], ids2[1]); assert.notEqual(ids[2], ids2[2]);
  /* Derselbe Treffer noch einmal: kein zweiter Ort, kein neues Gebiet */
  const noch = await d.ortAusTreffer(treffer(d, 'sersheim'));
  assert.equal(noch.vorhanden, true); assert.equal(noch.id, a.id);
  assert.equal((await d.orteListe()).length, 2); assert.equal((await d.gebieteListe()).length, 4);
});

test('Gleicher Ortsname an zwei Stellen: beide Orte bestehen, der zweite trägt den Kreis im Namen', async () => {
  const c = await neu(); const d = c.d;
  const a = await d.ortAusTreffer(treffer(d, 'boeblingen'));
  const b = await d.ortAusTreffer(treffer(d, 'enzkreis'));
  assert.equal(a.name, 'Eutingen'); assert.equal(b.name, 'Eutingen (Enzkreis)');
  assert.equal((await d.orteListe()).length, 2);
  assert.equal((await d.ortLaden(b.id)).gebietPfad[2].name, 'Enzkreis');
});

test('Ein eigenes Gebiet gleichen Namens übernimmt die Ebene, seine Regeln und seine Nummer bleiben', async () => {
  const c = await neu(); const d = c.d;
  const eigen = (await d.gebietAnlegen({ bezeichnung: 'Deutschland' })).id;
  await d.regelAnlegen(eigen, { bezeichnung: 'SBF Binnen', fahrzeugArten: ['boot'], artIds: [c.sbf] });
  const r = await d.ortAusTreffer(treffer(d, 'sersheim'));
  assert.equal(r.gebiete.uebernommen, 1); assert.equal(r.gebiete.neu, 2);
  const g = await d.gebietLaden(eigen);
  assert.equal(g.aktuell.werte.ebene, 'land'); assert.equal(g.regeln.length, 1);
  assert.equal(g.aktuell.werte.herkunft, 'eigen', 'bleibt „von dir eingetragen“');
  assert.equal(g.verlauf.length, 2);
  assert.equal((await d.ortLaden(r.id)).gebietPfad[0].id, eigen);
  assert.equal((await namen(d)).filter(n => n === 'Deutschland').length, 1, 'kein zweites Deutschland');
});

test('Umbenennen eines Gebiets von Hand behält Ebene und Zugehörigkeit', async () => {
  const c = await neu(); const d = c.d;
  const r = await d.ortAusTreffer(treffer(d, 'sersheim'));
  const kreis = (await d.ortLaden(r.id)).gebietPfad[2];
  const x = await d.gebietLaden(kreis.id);
  assert.equal((await d.gebietAendern(kreis.id, { bezeichnung: 'LK Ludwigsburg', notiz: 'mein Kreis' })).ok, true);
  const y = await d.gebietLaden(kreis.id);
  assert.equal(y.aktuell.werte.ebene, 'kreis'); assert.equal(y.aktuell.werte.elternId, x.aktuell.werte.elternId);
  assert.equal(y.aktuell.werte.schluessel, x.aktuell.werte.schluessel); assert.equal(y.aktuell.werte.herkunft, 'ortssuche');
  const again = await d.ortAusTreffer(treffer(d, 'sersheim'));
  assert.equal(again.vorhanden, true, 'der Schlüssel findet das Gebiet trotz neuem Namen');
  assert.equal((await d.gebieteListe()).length, 3);
});

test('Vorhandenen Ort nachträglich prüfen: Name, Notiz und Position bleiben, nur das Gebiet kommt dazu', async () => {
  const c = await neu(); const d = c.d;
  const o = (await d.ortAnlegen({ bezeichnung: 'Heimathafen', notiz: 'mein Platz', positionBreite: '49,1', positionLaenge: '9,2' })).id;
  assert.equal((await d.ortLaden(o)).aktuell.werte.ortGeprueft, 'nein');
  assert.deepEqual((await d.ortLaden(o)).gebietPfad, []);
  const r = await d.ortPruefungUebernehmen(o, treffer(d, 'sersheim'));
  assert.equal(r.ok, true); assert.equal(r.geaendert, true);
  const x = await d.ortLaden(o);
  assert.equal(x.aktuell.werte.bezeichnung, 'Heimathafen'); assert.equal(x.aktuell.werte.notiz, 'mein Platz');
  assert.equal(x.aktuell.werte.positionBreite, 49.1, 'vorhandene Position bleibt');
  assert.equal(x.aktuell.werte.land, 'Deutschland', 'fehlendes Land wird ergänzt');
  assert.equal(x.aktuell.werte.ortGeprueft, 'ja'); assert.equal(x.gebietPfad.length, 3); assert.equal(x.verlauf.length, 2);
  assert.equal((await d.ortPruefungUebernehmen(o, treffer(d, 'sersheim'))).geaendert, false, 'ein zweites Mal ändert nichts');
});

test('Ort ohne Prüfung bleibt möglich; Ändern behält das Gebiet; Revier nur bei geprüftem Ort', async () => {
  const c = await neu(); const d = c.d;
  const frei = (await d.ortAnlegen({ bezeichnung: 'Irgendwo' })).id;
  assert.equal((await d.ortAnlegen({ bezeichnung: 'Mit Revier', revierName: 'Rhein' })).fehler.revierName.includes('Ortssuche'), true);
  assert.ok((await d.ortAendern(frei, { bezeichnung: 'Irgendwo', revierName: 'Rhein' })).fehler.revierName);
  const g = await d.ortAusTreffer(treffer(d, 'sersheim'));
  assert.equal((await d.ortAendern(g.id, { bezeichnung: 'Sersheim Hafen', land: 'Deutschland' })).ok, true);
  const x = await d.ortLaden(g.id);
  assert.equal(x.gebietPfad.length, 3, 'Gebiet bleibt beim Umbenennen'); assert.equal(x.aktuell.werte.ortGeprueft, 'ja');
});

test('Revier: wird unter dem Land gespeichert, wiederverwendet, lässt sich leeren; ohne Feld bleibt es', async () => {
  const c = await neu(); const d = c.d;
  const a = (await d.ortAusTreffer(treffer(d, 'sersheim'))).id, b = (await d.ortAusTreffer(treffer(d, 'boeblingen'))).id;
  assert.equal((await d.ortAendern(a, { bezeichnung: 'Sersheim', land: 'Deutschland', revierName: '  Rhein ' })).ok, true);
  const land = (await d.ortLaden(a)).gebietPfad[0];
  assert.equal((await d.ortLaden(a)).revier.name, 'Rhein');
  assert.deepEqual(await d.reviereZuLand(land.id), ['Rhein']);
  assert.equal((await d.ortAendern(b, { bezeichnung: 'Eutingen', land: 'Deutschland', revierName: 'rhein' })).ok, true);
  assert.equal((await d.ortLaden(b)).revier.id, (await d.ortLaden(a)).revier.id, 'ein Revier, zwei Orte');
  assert.equal((await d.gebieteListe()).filter(x => x.aktuell.werte.ebene === 'revier').length, 1);
  /* Formular ohne Revier-Feld (kein Wasserfahrzeug im Konto): das Revier bleibt */
  assert.equal((await d.ortAendern(a, { bezeichnung: 'Sersheim 2', land: 'Deutschland' })).ok, true);
  assert.equal((await d.ortLaden(a)).revier.name, 'Rhein');
  assert.equal((await d.ortAendern(a, { bezeichnung: 'Sersheim 2', land: 'Deutschland', revierName: '' })).ok, true);
  assert.equal((await d.ortLaden(a)).revier, null);
  /* Wechselt das Land bei der Prüfung, fällt das Revier weg */
  assert.equal((await d.ortPruefungUebernehmen(b, treffer(d, 'kroatien'))).ok, true);
  assert.equal((await d.ortLaden(b)).revier, null); assert.equal((await d.ortLaden(b)).gebietPfad[0].name, 'Kroatien');
});

test('Konto: welche Arten von Fahrzeugen es gibt', async () => {
  const c = await neu();
  assert.deepEqual((await c.d.kontoWelten()).sort(), ['land', 'wasser']);
  const nur = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher()); await nur.starten();
  assert.deepEqual(await nur.kontoWelten(), []);
  await nur.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'WM' });
  assert.deepEqual(await nur.kontoWelten(), ['land']);
});

test('Aktivität: Gebiete aus den Orten, je nach Fahrzeug Straße (Land, Region, Kreis) oder Wasser (Land, Revier)', async () => {
  const c = await neu(); const d = c.d;
  const a = (await d.ortAusTreffer(treffer(d, 'sersheim'))).id, b = (await d.ortAusTreffer(treffer(d, 'boeblingen'))).id;
  await d.ortAendern(b, { bezeichnung: 'Eutingen', land: 'Deutschland', revierName: 'Neckar' });
  const w = await d.aktivitaetAnlegen(akt(c, { fahrzeugId: c.wm, startOrtId: a, zielOrtId: b }));
  const am = await d.aktivitaetLaden(w.id);
  assert.deepEqual(am.ortGebiete.ketten.map(k => k.map(g => g.name)), [['Deutschland', 'Baden-Württemberg', 'Landkreis Ludwigsburg'], ['Deutschland', 'Baden-Württemberg', 'Landkreis Böblingen']]);
  const s = await d.aktivitaetAnlegen(akt(c, { startOrtId: a, zielOrtId: b }));
  const as = await d.aktivitaetLaden(s.id);
  assert.deepEqual(as.ortGebiete.ketten.map(k => k.map(g => g.name)), [['Deutschland'], ['Deutschland', 'Neckar']]);
  assert.deepEqual(as.ortGebiete.ohneRevier, ['Sersheim']);
});

test('Prüfung: Regeln der Gebiete der Orte gelten, fehlt das Revier oder die Ortsprüfung, wird aus „erlaubt“ „unklar“, nichts wird gesperrt', async () => {
  const c = await neu(); const d = c.d;
  const land = (await d.ortAusTreffer(treffer(d, 'sersheim')));
  const ortId = land.id;
  const deutschland = (await d.ortLaden(ortId)).gebietPfad[0].id;
  await d.regelAnlegen(deutschland, { bezeichnung: 'SBF Binnen', fahrzeugArten: ['boot'], artIds: [c.sbf] });
  await d.nachweisAnlegen('person', c.anna, c.sbf, { nummer: '1', datei: scan });
  const r = await d.aktivitaetAnlegen(akt(c, { startOrtId: ortId }));
  let p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.anforderungen, 1);
  assert.ok(p.befaehigung.personen[0].gruende.some(x => x.text.includes('Gebiet Deutschland') && x.text.includes('SBF Binnen')));
  assert.equal(p.befaehigung.personen[0].ergebnis, 'erlaubt');
  assert.equal(p.befaehigung.ergebnis, 'unklar', 'Wasserfahrzeug, aber kein Revier beim Ort');
  assert.ok(p.befaehigung.gebietHinweis.includes('Revier'));
  /* Revier eintragen: die Prüfung ist klar */
  await d.ortAendern(ortId, { bezeichnung: 'Sersheim', land: 'Deutschland', revierName: 'Neckar' });
  p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.befaehigung.ergebnis, 'erlaubt'); assert.equal(p.befaehigung.gebietHinweis, null);
  assert.equal(p.befaehigung.gebiet, 'Deutschland › Neckar');
  /* Ein zweiter Ort ohne Prüfung: unklar, mit Hinweis, aber die Aktivität bleibt anlegbar */
  const frei = (await d.ortAnlegen({ bezeichnung: 'Irgendwo' })).id;
  const r2 = await d.aktivitaetAnlegen(akt(c, { bezeichnung: 'Zwei', startOrtId: ortId, zielOrtId: frei }));
  assert.equal(r2.ok, true);
  p = await d.aktivitaetPruefung(r2.id);
  assert.equal(p.befaehigung.ergebnis, 'unklar'); assert.ok(p.befaehigung.gebietHinweis.includes('Irgendwo'));
  /* Landfahrzeug: die Regel gilt nur für Boote und greift nicht */
  const wm = await d.aktivitaetAnlegen(akt(c, { bezeichnung: 'Landfahrt', fahrzeugId: c.wm, startOrtId: ortId }));
  p = await d.aktivitaetPruefung(wm.id);
  assert.ok(p.befaehigung.gebietHinweis.includes('trifft keine Regel'));
});

test('Ohne Orte und Gebiet verhält sich die Prüfung wie bisher; Orte ohne Gebiet allein sperren nichts und machen nichts unklar', async () => {
  const c = await neu(); const d = c.d;
  await d.nachweisAnlegen('person', c.anna, c.sbf, { nummer: '1', datei: scan });
  await d.anforderungAnlegen(c.boot, { bezeichnung: 'SBF', artIds: [c.sbf] });
  const frei = (await d.ortAnlegen({ bezeichnung: 'Irgendwo' })).id;
  const r = await d.aktivitaetAnlegen(akt(c, { startOrtId: frei }));
  const p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.befaehigung.ergebnis, 'erlaubt');
  assert.ok(p.befaehigung.gebietHinweis && p.befaehigung.gebietHinweis.includes('Irgendwo'), 'der Hinweis steht trotzdem da');
});

test('Reisecheck: die Ketten der Orte gehen als Gebiete in die Eingabe', async () => {
  const c = await neu(); const d = c.d;
  const a = (await d.ortAusTreffer(treffer(d, 'sersheim'))).id;
  const r = await d.aktivitaetAnlegen(akt(c, { fahrzeugId: c.wm, startOrtId: a }));
  const x = await d.reisecheckEingabe(r.id);
  assert.deepEqual(x.eingabe.gebiete, [{ name: 'Deutschland, Baden-Württemberg, Landkreis Ludwigsburg' }]);
});

test('Gebiet laden: Schlüssel, Weg von oben und die Gebiete darunter', async () => {
  const c = await neu(); const d = c.d;
  const o = (await d.ortAusTreffer(treffer(d, 'sersheim'))).id;
  const g = (await d.ortLaden(o)).gebietPfad[2].id;
  const geladen = await d.gebietLaden(g);
  assert.ok(geladen.aktuell.werte.schluessel.includes('landkreis ludwigsburg'));
  assert.deepEqual(geladen.pfad.map(x => x.name), ['Deutschland', 'Baden-Württemberg', 'Landkreis Ludwigsburg']);
  assert.equal((await d.gebietLaden(geladen.pfad[0].id)).unter[0].name, 'Baden-Württemberg');
});
