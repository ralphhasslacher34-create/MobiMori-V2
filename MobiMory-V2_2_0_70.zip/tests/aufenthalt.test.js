'use strict';
/* 2.0.58: Aufenthalte als Zusammenstellung (Baukasten) und die Dauer von der Ankunft bis zur Abfahrt. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/aktionen.js');
require('../js/baukasten.js');
require('../js/daten.js');
const MM = globalThis.MM;
const R = MM.Reiseorte, B = MM.Baukasten;

const ev = (id, artName, datum, zeit, extra) => Object.assign({ id, artName, datum, zeit, zeitpunkt: datum + 'T' + (zeit || '00:00'), ausgeblendet: false }, extra || {});

test('Dauer: von der Ankunft bis zur nächsten Abfahrt, in Minuten und als Text', () => {
  const l = [ev('a', 'Anlegen', '2026-07-05', '10:00'), ev('b', 'Ablegen', '2026-07-05', '12:15')];
  const r = R.aufenthalt(l, 'a');
  assert.equal(r.minuten, 135); assert.equal(r.text, '2 h 15 min');
  assert.deepEqual(r.von, { datum: '2026-07-05', zeit: '10:00' });
  assert.equal(r.bis.artName, 'Ablegen');
  assert.equal(R.aufenthalt([ev('a', 'Ankunft', '2026-07-05', '10:00'), ev('b', 'Abfahrt', '2026-07-05', '10:45')], 'a').text, '45 min');
  assert.equal(R.aufenthalt([ev('a', 'Anker werfen', '2026-07-05', '18:00'), ev('b', 'Anker lichten', '2026-07-05', '18:00')], 'a').minuten, 0);
});

test('Dauer über Mitternacht und über mehrere Tage', () => {
  const nacht = R.aufenthalt([ev('a', 'Anker werfen', '2026-07-05', '22:30'), ev('b', 'Anker lichten', '2026-07-06', '06:10')], 'a');
  assert.equal(nacht.minuten, 460); assert.equal(nacht.text, '7 h 40 min');
  const tage = R.aufenthalt([ev('a', 'Ankunft', '2026-07-05', '10:00'), ev('b', 'Abfahrt', '2026-07-08', '13:00')], 'a');
  assert.equal(tage.text, '3 Tage 3 h');
  assert.equal(R.aufenthalt([ev('a', 'Ankunft', '2026-07-05', '10:00'), ev('b', 'Abfahrt', '2026-07-06', '10:00')], 'a').text, '1 Tag');
  /* Monatswechsel und Jahreswechsel */
  assert.equal(R.aufenthalt([ev('a', 'Ankunft', '2026-12-31', '23:00'), ev('b', 'Abfahrt', '2027-01-01', '01:00')], 'a').minuten, 120);
});

test('Ohne Abfahrt keine falsche Zahl', () => {
  assert.equal(R.aufenthalt([ev('a', 'Anlegen', '2026-07-05', '10:00')], 'a'), null, 'noch keine Abfahrt');
  assert.equal(R.aufenthalt([ev('a', 'Anlegen', '2026-07-05', '10:00'), ev('b', 'Anlegen', '2026-07-06', '09:00'), ev('c', 'Ablegen', '2026-07-06', '11:00')], 'a'), null, 'vorher schon die nächste Ankunft');
  assert.equal(R.aufenthalt([ev('a', 'Anlegen', '2026-07-05', '10:00'), ev('b', 'Ablegen', '2026-07-05', '12:00', { ausgeblendet: true })], 'a'), null, 'ausgeblendete Abfahrt zählt nicht');
  assert.equal(R.aufenthalt([ev('a', 'Anlegen', '2026-07-05', '10:00'), ev('b', 'Ablegen', '2026-07-05', null)], 'a'), null, 'Abfahrt ohne Uhrzeit');
  assert.equal(R.aufenthalt([ev('a', 'Anlegen', '2026-07-05', null), ev('b', 'Ablegen', '2026-07-05', '12:00')], 'a'), null, 'Ankunft ohne Uhrzeit');
  assert.equal(R.aufenthalt([ev('b', 'Ablegen', '2026-07-05', '12:00')], 'a'), null, 'Ankunft unbekannt');
  assert.equal(R.aufenthalt([ev('a', 'Anlegen', '2026-07-05', '10:00', { ausgeblendet: true }), ev('b', 'Ablegen', '2026-07-05', '12:00')], 'a'), null, 'ausgeblendete Ankunft');
  assert.equal(R.aufenthalt(undefined, 'a'), null);
  assert.equal(R.dauerText(-5), '');
});

test('Dauer: andere Ereignisse dazwischen stören nicht, die erste Abfahrt gilt', () => {
  const l = [ev('a', 'Anlegen', '2026-07-05', '10:00'), ev('n', 'Notiz', '2026-07-05', '10:30'), ev('t', 'Tanken', '2026-07-05', '11:00'),
    ev('b', 'Ablegen', '2026-07-05', '12:00'), ev('c', 'Ablegen', '2026-07-05', '15:00')];
  assert.equal(R.aufenthalt(l, 'a').minuten, 120);
});

test('Baukasten: Vorlage „Aufenthalt“, Wirkung „Besuch anlegen“ und ihre Regeln', () => {
  const v = B.vorlage('aufenthalt');
  assert.deepEqual(v.fragen, ['ort', 'ausstattung', 'besuchKosten']); assert.deepEqual(v.wirkungen, ['besuch']);
  assert.deepEqual(B.fehlendeFragen({ fragen: v.fragen, wirkungen: v.wirkungen }), [], 'die Vorlage selbst ist in Ordnung');
  assert.equal(B.hatAblauf({ fragen: v.fragen, wirkungen: v.wirkungen }), true);
  assert.deepEqual(B.wirkung('besuch').braucht, ['ort']);
  assert.ok(B.fehlendeFragen({ fragen: [], wirkungen: ['besuch'] }).some(m => /Ort/.test(m)), 'braucht die Frage Ort');
  assert.ok(B.fehlendeFragen({ fragen: ['ort', 'text'], wirkungen: ['besuch'] }).length >= 1, 'keine fremden Fragen');
  assert.ok(B.fehlendeFragen({ fragen: ['ort', 'betrag'], wirkungen: ['besuch', 'kosten'] }).length >= 1, 'keine anderen Wirkungen');
  assert.ok(B.fehlendeFragen({ fragen: ['ort'], wirkungen: [] }).length === 1, 'Ort ohne Besuch ergibt Hinweis');
  /* Bestehendes bleibt: Störung und Tanken sind unverändert ohne Meldung */
  assert.deepEqual(B.fehlendeFragen({ fragen: B.vorlage('stoerung').fragen, wirkungen: B.vorlage('stoerung').wirkungen }), []);
  assert.deepEqual(B.fehlendeFragen({ fragen: B.vorlage('tanken').fragen, wirkungen: B.vorlage('tanken').wirkungen }), []);
  assert.match(B.ablaufText(v), /Wirkungen: Besuch anlegen/);
});

const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const aktId = (await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: arten.find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id, fahrzeugId: boot, vonDatum: '2026-07-01', bisDatum: '2026-07-10', verantwortlichId: anna })).id;
  await d.ereignisartenAusVorschlaegen();
  await d.ereignisartenVorauswahlUebernehmen();
  await d.tagesabschnitteVorbereiten(aktId);
  return { d, aktId };
}
async function ereignis(c, art, datum, zeit) {
  const lb = await c.d.logbuchLaden(c.aktId);
  const tag = lb.abschnitte.filter(x => x.aktuell.werte.datum === datum)[0] || lb.abschnitte[0];
  const artId = (await c.d.ereignisartenListe()).find(a => a.aktuell.werte.bezeichnung === art).objekt.id;
  const r = await c.d.ereignisAnlegen(tag.objekt.id, { artId, datum, zeit }, { nachtragen: true });
  assert.equal(r.ok, true, JSON.stringify(r));
  return r.id;
}

test('Daten: Besuch, Besuchsliste und Reiseauswertung zeigen die Dauer; ohne Abfahrt keine', async () => {
  const c = await neu();
  const an = await ereignis(c, 'Anlegen', '2026-07-02', '20:00');
  const b = await c.d.besuchAnlegen(c.aktId, { ereignisId: an, neuerOrtName: 'Hafen Rovinj', neuerOrtArt: 'hafen' });
  assert.equal(b.ok, true, JSON.stringify(b));
  assert.equal((await c.d.besuchLaden(b.id)).aufenthalt, null, 'noch keine Abfahrt');
  assert.equal((await c.d.besuchListe({ aktivitaetId: c.aktId }))[0].aufenthalt, null);

  await ereignis(c, 'Ablegen', '2026-07-03', '08:30');   /* über Mitternacht */
  const geladen = await c.d.besuchLaden(b.id);
  assert.equal(geladen.aufenthalt.minuten, 750); assert.equal(geladen.aufenthalt.text, '12 h 30 min');
  const liste = await c.d.besuchListe({ aktivitaetId: c.aktId });
  assert.equal(liste[0].aufenthalt.text, '12 h 30 min');
  const reise = await c.d.reiseAuswertung(c.aktId);
  assert.equal(reise.besuche[0].aufenthalt.text, '12 h 30 min');
  /* Auf der Seite des Ortes */
  const ort = await c.d.ortAuswertung(b.ortId);
  assert.equal(ort.besuche[0].aufenthalt.text, '12 h 30 min');
});

test('Daten: ein Besuch ohne Ankunfts-Ereignis und ein übersprungener Besuch haben keine Dauer', async () => {
  const c = await neu();
  const b = await c.d.besuchAnlegen(c.aktId, { neuerOrtName: 'Stellplatz X', neuerOrtArt: 'stellplatz' });
  assert.equal(b.ok, true, JSON.stringify(b));
  assert.equal((await c.d.besuchLaden(b.id)).aufenthalt, null);
  const an = await ereignis(c, 'Anlegen', '2026-07-02', '10:00');
  await ereignis(c, 'Ablegen', '2026-07-02', '11:00');
  await c.d.besuchUeberspringen(c.aktId, an);
  const alle = await c.d.besuchListe({ aktivitaetId: c.aktId, mitUebersprungenen: true });
  assert.ok(alle.every(x => x.aufenthalt === null));
});

test('Daten: zwei Aufenthalte nacheinander, jeder mit seiner eigenen Dauer', async () => {
  const c = await neu();
  const a1 = await ereignis(c, 'Anlegen', '2026-07-02', '10:00');
  await ereignis(c, 'Ablegen', '2026-07-02', '12:00');
  const a2 = await ereignis(c, 'Anker werfen', '2026-07-02', '16:00');
  await ereignis(c, 'Anker lichten', '2026-07-02', '16:20');
  const b1 = await c.d.besuchAnlegen(c.aktId, { ereignisId: a1, neuerOrtName: 'Hafen A', neuerOrtArt: 'hafen' });
  const b2 = await c.d.besuchAnlegen(c.aktId, { ereignisId: a2, neuerOrtName: 'Bucht B', neuerOrtArt: 'anker' });
  assert.equal((await c.d.besuchLaden(b1.id)).aufenthalt.text, '2 h');
  assert.equal((await c.d.besuchLaden(b2.id)).aufenthalt.text, '20 min');
});
