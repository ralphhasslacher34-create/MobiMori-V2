'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/austausch.js');
const A = globalThis.MM.Austausch;
const enc = s => new TextEncoder().encode(s);

test('CSV: Semikolon, Anführungszeichen, Zeilenumbruch im Feld und Zeichen für UTF-8', () => {
  const z = A.csvLesen('\uFEFFName;Wert\r\n"Müller; Hans";"Zeile 1\nZeile 2"\r\n"sagt ""hallo""";3,5\r\n\r\n');
  assert.deepEqual(z, [['Name', 'Wert'], ['Müller; Hans', 'Zeile 1\nZeile 2'], ['sagt "hallo"', '3,5']]);
});

test('CSV: Komma und Tabulator werden erkannt, ein Semikolon in Anführungszeichen zählt nicht', () => {
  assert.deepEqual(A.csvLesen('a,b,c\n1,2,3'), [['a', 'b', 'c'], ['1', '2', '3']]);
  assert.deepEqual(A.csvLesen('a\tb\n1\t2'), [['a', 'b'], ['1', '2']]);
  assert.deepEqual(A.csvLesen('"a;b",c\n1,2'), [['a;b', 'c'], ['1', '2']]);
});

test('CSV schreiben: Semikolon, Komma bei Zahlen, Datum deutsch, UTF-8 mit Kennzeichen, Formeln entschärft', () => {
  const b = A.csvSchreiben([['Name', 'Betrag', 'Datum'], ['Müller "M"; Co', 12.5, { d: '2026-11-04' }], ['=SUMME(A1)', 3, null]]);
  assert.deepEqual([...b.subarray(0, 3)], [0xEF, 0xBB, 0xBF]);
  const t = new TextDecoder().decode(b.subarray(3));
  assert.equal(t, 'Name;Betrag;Datum\r\n"Müller ""M""; Co";12,5;04.11.2026\r\n\'=SUMME(A1);3;\r\n');
  /* und wieder lesen */
  const z = A.csvLesen(new TextDecoder().decode(b));
  assert.equal(z[1][0], 'Müller "M"; Co');
  assert.equal(z[1][2], '04.11.2026');
});

test('Zeichensatz: Windows-Excel-CSV (ANSI) wird richtig gelesen', async () => {
  /* „Länge“ in Windows-1252: ä = 0xE4 */
  const bytes = new Uint8Array([0x4C, 0xE4, 0x6E, 0x67, 0x65, 0x3B, 0x42, 0x0D, 0x0A, 0x38, 0x3B, 0x31]);
  const r = await A.dateiLesen(bytes);
  assert.equal(r.art, 'csv');
  assert.deepEqual(r.blaetter[0].zeilen[0], ['Länge', 'B']);
});

test('CRC32 stimmt mit dem bekannten Wert überein', () => {
  assert.equal(A.crc32(enc('123456789')), 0xCBF43926);
});

test('Excel schreiben und wieder lesen: Texte, Zahlen, Daten, mehrere Blätter, Sonderzeichen', async () => {
  const bytes = A.xlsxSchreiben([
    { name: 'Fahrzeuge', zeilen: [['Bezeichnung', 'Länge (m)', 'Erstzulassung', 'Notiz'], ['Boot <A> & "B"', 7.5, { d: '2019-06-30' }, 'Zeile 1\nZeile 2'], ['Auto', 4, null, '=1+1']] },
    { name: 'Kosten', zeilen: [['Betrag'], [12.34]] }
  ]);
  assert.equal(bytes[0], 0x50); assert.equal(bytes[1], 0x4B);
  const r = await A.dateiLesen(bytes);
  assert.equal(r.art, 'xlsx');
  assert.deepEqual(r.blaetter.map(b => b.name), ['Fahrzeuge', 'Kosten']);
  const z = r.blaetter[0].zeilen;
  assert.deepEqual(z[0], ['Bezeichnung', 'Länge (m)', 'Erstzulassung', 'Notiz']);
  assert.equal(z[1][0], 'Boot <A> & "B"');
  assert.equal(z[1][1], 7.5);
  assert.equal(z[1][2], '2019-06-30');
  assert.equal(z[1][3], 'Zeile 1\nZeile 2');
  assert.equal(z[2][3], "'=1+1", 'Beim Schreiben bekommt der Text ein Hochkomma, damit Excel ihn nicht als Formel nimmt');
  assert.equal(A.wertUmwandeln({ key: 't', typ: 'text' }, z[2][3]), '=1+1', 'Beim Übernehmen wird es wieder entfernt');
  assert.equal(r.blaetter[1].zeilen[1][0], 12.34);
});

test('Excel lesen: gemeinsame Texte, Datum über Zellformat, Lücken, Wahrheitswert', async () => {
  const x = (name, text) => ({ name, bytes: enc(text) });
  const K = '<?xml version="1.0"?>';
  const bytes = A.zipSchreiben([
    x('[Content_Types].xml', K + '<Types/>'),
    x('xl/workbook.xml', K + '<workbook xmlns:r="r"><sheets><sheet name="Mein Blatt" sheetId="1" r:id="rId1"/></sheets></workbook>'),
    x('xl/_rels/workbook.xml.rels', K + '<Relationships><Relationship Id="rId1" Type="t" Target="worksheets/sheet1.xml"/></Relationships>'),
    x('xl/sharedStrings.xml', K + '<sst><si><t>Kennzeichen</t></si><si><r><t>HN-</t></r><r><t>AB 123</t></r></si><si><t>Datum</t></si></sst>'),
    x('xl/styles.xml', K + '<styleSheet><numFmts count="1"><numFmt numFmtId="164" formatCode="dd.mm.yyyy"/></numFmts><cellXfs count="3"><xf numFmtId="0"/><xf numFmtId="14"/><xf numFmtId="164"/></cellXfs></styleSheet>'),
    x('xl/worksheets/sheet1.xml', K + '<worksheet><sheetData><row r="1"><c r="A1" t="s"><v>0</v></c><c r="C1" t="s"><v>2</v></c></row>' +
      '<row r="3"><c r="A3" t="s"><v>1</v></c><c r="B3" t="b"><v>1</v></c><c r="C3" s="2"><v>46330</v></c><c r="D3" s="1"><v>43646</v></c><c r="E3"><v>3500</v></c></row></sheetData></worksheet>')
  ]);
  const r = await A.dateiLesen(bytes);
  const z = r.blaetter[0].zeilen;
  assert.equal(r.blaetter[0].name, 'Mein Blatt');
  assert.deepEqual(z[0], ['Kennzeichen', '', 'Datum']);
  assert.deepEqual(z[1], ['HN-AB 123', 'Ja', '2026-11-04', '2019-06-30', 3500]);
});

test('Dateien erkennen: altes .xls, kaputte ZIP, leere Datei', async () => {
  await assert.rejects(A.dateiLesen(new Uint8Array([0xD0, 0xCF, 0x11, 0xE0, 1, 2, 3])), e => e.code === 'xls');
  await assert.rejects(A.dateiLesen(new Uint8Array([0x50, 0x4B, 1, 2, 3, 4, 5, 6])), e => e.code === 'zip');
  await assert.rejects(A.dateiLesen(new Uint8Array([])), e => e.code === 'leer');
  /* eine ZIP-Datei, die keine Excel-Datei ist */
  const andere = A.zipSchreiben([{ name: 'datei.txt', bytes: enc('x') }]);
  await assert.rejects(A.dateiLesen(andere), e => e.code === 'format');
});

const FELDER = [{ key: 'bezeichnung', label: 'Bezeichnung' }, { key: '__art', label: 'Fahrzeugart' }, { key: 'marke', label: 'Marke' }, { key: 'kennzeichen', label: 'Kennzeichen' },
  { key: 'gesamtgewicht', label: 'Zulässiges Gesamtgewicht' }, { key: 'laenge', label: 'Länge' }, { key: 'erstzulassung', label: 'Erstzulassung' }, { key: 'fin', label: 'FIN (Fahrgestellnummer)' }];

test('Spalten raten: Überschriften, Synonyme, Klammern, jedes Feld nur einmal', () => {
  const r = A.spaltenRaten(['Name', 'Hersteller', 'Amtl. Kennzeichen', 'zul. Gesamtgewicht (kg)', 'Länge (m)', 'EZ', 'Fahrgestellnummer', 'Art', 'Bemerkung', 'Marke'], FELDER);
  assert.deepEqual(r, ['bezeichnung', 'marke', 'kennzeichen', 'gesamtgewicht', 'laenge', 'erstzulassung', 'fin', '__art', '', '']);
});

test('Spalten raten: „Art“ nimmt nichts weg, was genauer passt', () => {
  const r = A.spaltenRaten(['Art', 'Fahrzeugart'], FELDER);
  assert.deepEqual(r, ['__art', '']);
});

const zahl = { key: 'x', typ: 'zahl' }, kg = { key: 'g', typ: 'zahl', einheit: 'kg' }, ganz = { key: 'b', typ: 'ganzzahl' };

test('Zahlen: deutsch, englisch, mit Einheit, mit Tausenderpunkt', () => {
  const u = A.wertUmwandeln;
  assert.equal(u(zahl, '7,5'), '7.5');
  assert.equal(u(zahl, '7,5 m'), '7.5');
  assert.equal(u(zahl, '1.234,5'), '1234.5');
  assert.equal(u(zahl, '1,234.5'), '1234.5');
  assert.equal(u(kg, '3.500 kg'), '3500');
  assert.equal(u(kg, '3.500,5'), '3500.5');
  assert.equal(u(zahl, '2.5'), '2.5');
  assert.equal(u(zahl, 7.5), '7.5');
  assert.equal(u(ganz, '2019.0'), '2019');
  assert.equal(u(zahl, ''), '');
  assert.equal(u(zahl, 'viel'), 'viel');
  assert.equal(u(kg, '1 234 567'), '1234567');
});

test('Datum: deutsch, mit Strichen, zweistelliges Jahr, ISO, Excel-Nummer', () => {
  const d = { key: 'd', typ: 'datum' }, u = A.wertUmwandeln;
  assert.equal(u(d, '03.11.2026'), '2026-11-03');
  assert.equal(u(d, '3.1.2019'), '2019-01-03');
  assert.equal(u(d, '03/11/2026'), '2026-11-03');
  assert.equal(u(d, '2026-11-03T10:00:00'), '2026-11-03');
  assert.equal(u(d, '15.06.98'), '1998-06-15');
  assert.equal(u(d, 46330), '2026-11-04');
  assert.equal(u(d, 'bald'), 'bald');
});

test('Auswahl: Kraftstoff nach Name, Anfang und Synonym', () => {
  const k = { key: 'kraftstoff', typ: 'auswahl', optionen: ['Benzin', 'Diesel', 'Autogas (LPG)', 'Erdgas (CNG)', 'Elektro', 'Hybrid', 'Wasserstoff', 'Sonstiger'] }, u = A.wertUmwandeln;
  assert.equal(u(k, 'diesel'), 'Diesel');
  assert.equal(u(k, ' SUPER '), 'Benzin');
  assert.equal(u(k, 'LPG'), 'Autogas (LPG)');
  assert.equal(u(k, 'Elek'), 'Elektro');
  assert.equal(u(k, 'Dampf'), 'Dampf');
  assert.equal(u({ key: 'a', typ: 'auswahl', optionen: [{ wert: 'ja', label: 'Ja' }] }, 'JA'), 'ja');
});

test('Kennung vergleichen: Groß, ohne Leerzeichen und Striche', () => {
  assert.equal(A.kennungNorm('hn-ab 123'), 'HNAB123');
});
