'use strict';
/* 2.0.29, Schritt 8c: Reisekasse – Beschreibung und Rechnung (ohne Speicher). */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/hilfen.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
const MM = globalThis.MM;
const R = MM.Reisekasse;

test('Währung: drei Buchstaben, groß, sonst nichts', () => {
  assert.equal(R.waehrungNormal(' nok '), 'NOK');
  assert.equal(R.waehrungNormal('Krone'), null);
  assert.equal(R.waehrungNormal(''), null);
  assert.equal(R.waehrungNormal('N0K'), null);
});

test('Kasse in Euro: Stand aus Anfang, Einzahlung, Differenz und Ausgaben, ausgeblendete zählen nicht', () => {
  const b = (art, betrag, extra) => ({ werte: Object.assign({ art, betrag, ausgeblendet: 'nein' }, extra || {}) });
  const r = R.rechnen({ waehrung: 'EUR', buchungen: [b('anfang', 300), b('einzahlung', 200), b('differenz', -5.5), b('einzahlung', 999, { ausgeblendet: 'ja' })],
    ausgaben: [{ werte: { betrag: 24.5 } }, { werte: { betrag: 10, ausgeblendet: 'ja' } }] });
  assert.equal(r.stand, 470);
  assert.equal(r.einzahlungen, 200);
  assert.equal(r.differenz, -5.5);
  assert.equal(r.ausgaben, 24.5);
  assert.equal(r.kurs.euroProEinheit, 1);
});

test('Kasse in Fremdwährung: Durchschnittskurs aus den Euro-Beträgen, Ausgaben in der Währung', () => {
  const b = (art, betrag, euro) => ({ werte: { art, betrag, euro, ausgeblendet: 'nein' } });
  const r = R.rechnen({ waehrung: 'NOK', buchungen: [b('anfang', 1150, 100), b('einzahlung', 1000, 100)],
    ausgaben: [{ werte: { betrag: 20, betragWaehrung: 215 } }] });
  assert.equal(r.stand, 1935);
  assert.equal(r.euroEingezahlt, 200);
  assert.equal(Math.round(r.kurs.einheitenProEuro * 100) / 100, 10.75);
  assert.equal(R.euroAus(215, r.kurs), 20);
  assert.equal(R.euroAus(5, null), null);
  const ohne = R.rechnen({ waehrung: 'NOK', buchungen: [{ werte: { art: 'anfang', betrag: 100, ausgeblendet: 'nein' } }] });
  assert.equal(ohne.kurs, null, 'ohne Euro-Betrag kein Kurs');
});

test('Kassensturz: Differenz zum Stand, Kurstext und Zahlen mit Komma', () => {
  const rc = R.rechnen({ waehrung: 'EUR', buchungen: [{ werte: { art: 'anfang', betrag: 100 } }], ausgaben: [{ werte: { betrag: 10 } }] });
  assert.equal(R.kassensturzDifferenz(rc, 85.5), -4.5);
  assert.equal(R.kassensturzDifferenz(rc, 90), 0);
  assert.equal(R.zahlText(1234.5), '1.234,50');
  assert.equal(R.kursText('NOK', { einheitenProEuro: 11.5 }), '1 € = 11,50 NOK');
  assert.equal(R.kursText('EUR', { einheitenProEuro: 1 }), null);
});

test('Reisetage: erster und letzter Tag zählen, Fixanteil je Jahr', () => {
  assert.equal(R.reiseTage('2026-07-01', '2026-07-10'), 10);
  assert.equal(R.reiseTage('2026-07-01', null), 1);
  assert.equal(R.reiseTage(null, null), null);
  const fix = [{ werte: { betrag: 3650, rhythmus: 'jaehrlich', datum: '2026-01-01', gruppe: 'fix' } }];
  assert.equal(R.fixAnteil(fix, '2026-07-01', '2026-07-10', '2026-11-04').summe, 100);
  assert.equal(R.fixAnteil([], '2026-07-01', '2026-07-10', '2026-11-04').summe, 0);
  const ueber = R.fixAnteil(fix, '2026-12-30', '2027-01-02', '2026-11-04');
  assert.equal(ueber.jahre.length, 2);
});

test('Gesamt der Reise: Fahrzeug und Reisekasse getrennt, Fixanteil ein und aus, pro Tag und Person', () => {
  const k = [{ werte: { gruppe: 'variabel', betrag: 100, grundlage: 'eingegeben', bezahltMit: 'bar' } },
    { werte: { gruppe: 'reisekasse', betrag: 60, kostenart: 'rkessen', grundlage: 'gerechnet', bezahltMit: 'zm1' } },
    { werte: { gruppe: 'reisekasse', betrag: 10, kostenart: 'rkessen', grundlage: 'eingegeben' } },
    { werte: { gruppe: 'reisekasse', betrag: 99, ausgeblendet: 'ja' } }];
  const fix = [{ werte: { betrag: 3650, rhythmus: 'jaehrlich', datum: '2026-01-01' } }];
  const p = { kosten: k, von: '2026-07-01', bis: '2026-07-10', personen: 2, fixPosten: fix, zahlungsmittel: { zm1: 'Kreditkarte' }, heute: '2026-11-04' };
  const g = R.reiseGesamt(p);
  assert.equal(g.fahrzeug.summe, 100);
  assert.equal(g.reisekasse.summe, 70);
  assert.equal(g.reisekasse.grundlage, 'gemischt');
  assert.equal(g.gesamt, 270);
  assert.equal(g.proTag, 27);
  assert.equal(g.proPerson, 135);
  assert.equal(g.proTagPerson, 13.5);
  const aus = R.reiseGesamt(Object.assign({}, p, { fixEin: false }));
  assert.equal(aus.gesamt, 170);
  assert.equal(aus.fixAnteil.summe, 100);
  assert.equal(aus.fixAnteil.eingerechnet, false);
  assert.deepEqual(g.nachZahlungsmittel.map(x => x.label), ['Bar', 'Kreditkarte', 'ohne Angabe']);
  const leer = R.reiseGesamt({ kosten: [], von: '2026-07-01', bis: '2026-07-02', personen: 0, fixPosten: [], heute: '2026-11-04' });
  assert.equal(leer.gesamt, 0);
  assert.equal(leer.proTag, null);
  assert.equal(leer.proPerson, null);
});

test('Kosten: Grundlage gerechnet wird in Summen erkannt, Reisekasse ist keine Fahrzeuggruppe', () => {
  assert.equal(MM.Kosten.grundlageVon(['gerechnet', 'gerechnet']), 'gerechnet');
  assert.equal(MM.Kosten.grundlageVon(['gerechnet', 'eingegeben']), 'gemischt');
  assert.ok(!MM.Kosten.GRUPPEN.some(g => g.wert === 'reisekasse'));
  assert.ok(MM.Kosten.istGruppe('reisekasse') && MM.Kosten.istGruppe('fix') && !MM.Kosten.istGruppe('wunsch'));
  assert.ok(MM.Kosten.kostenartenFuer('reisekasse').length >= 6);
});
