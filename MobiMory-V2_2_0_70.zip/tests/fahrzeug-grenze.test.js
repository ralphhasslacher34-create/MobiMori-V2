'use strict';
/* 2.0.70: Fahrzeug-Grenze der Stufe in der App. Basic 1, Mittel 3, Voll unbegrenzt, Testwoche 3. Unterfahrzeuge zählen mit, abgegebene nicht,
   ohne Konto gilt Basic, die App merkt sich den letzten Wert (auch ohne Netz), vorhandene Fahrzeuge bleiben immer. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'reisecheck', 'grundcheck', 'konto', 'austausch', 'daten']
  .forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = (f) => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');

/* Der Vorlauf der Tests hebt die Grenze ohne Konto auf. Hier gilt sie wie in der echten App. */
MM.Daten.standardFahrzeuggrenze = 1;

const STUFEN = {
  basic: { stufe: { id: 'basic', name: 'Basic', bis: null }, grenzen: { geraete: 2, checks: 0, fahrzeuge: 1, online: false } },
  mittel: { stufe: { id: 'mittel', name: 'Mittel', bis: null }, grenzen: { geraete: 4, checks: 3, fahrzeuge: 3, online: true } },
  test: { stufe: { id: 'test', name: 'Testwoche', bis: null }, grenzen: { geraete: 4, checks: 1, fahrzeuge: 3, online: true } },
  voll: { stufe: { id: 'voll', name: 'Voll', bis: null }, grenzen: { geraete: 10, checks: 10, fahrzeuge: null, online: true } }
};

/* Ein Gerät. dienst.stufe = Name der Stufe, die der Dienst nennt; dienst.netz = false: kein Netz. */
async function geraet(angemeldet, stufe) {
  const dienst = { stufe: stufe || 'basic', netz: true, aufrufe: 0 };
  let n = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), {
    jetzt: () => new Date(new Date(2026, 10, 12, 12, 0, 0).getTime() + (n++) * 1000).toISOString(),
    kontoAnfrage: async (url, methode, token) => {
      dienst.aufrufe++;
      if (!dienst.netz) throw new Error('Kein Netz');
      if (url.endsWith('/konto/stufe')) return Object.assign({ ok: true, nutzung: { geraete: 1, checks: 0, checksFrei: 0, zeitraumTage: 365 } }, STUFEN[dienst.stufe]);
      throw new Error('unerwartet ' + url);
    }
  });
  await d.starten();
  if (angemeldet) await d.rcSchreiben({ kontoToken: 'tok', kontoEmail: 'a@b.de', kontoDatenraumId: 'dr-x' });
  return { d, dienst };
}
const anlegen = (d, name, extra) => d.fahrzeugAnlegen('boot', Object.assign({ bezeichnung: name }, extra || {}));
const anzahl = async (d) => (await d.fahrzeugListe()).length;

test('Ohne Konto gilt Basic: ein Fahrzeug geht, das zweite nicht, mit Hinweis auf die Stufe, nichts wird gelöscht', async () => {
  const { d } = await geraet(false);
  assert.equal((await anlegen(d, 'Boot 1')).ok, true);
  const r = await anlegen(d, 'Boot 2');
  assert.equal(r.ok, false);
  assert.match(r.fehler.allgemein, /Stufe Basic/);
  assert.match(r.fehler.allgemein, /1 Fahrzeug/);
  assert.match(r.fehler.allgemein, /bleiben erhalten/);
  assert.equal(r.grenze.grenze, 1); assert.equal(r.grenze.anzahl, 1); assert.equal(r.grenze.frei, 0);
  assert.equal(await anzahl(d), 1);
});

test('Ein gespeicherter Wert gilt ohne Konto nicht: ohne Anmeldung bleibt es bei Basic', async () => {
  const { d } = await geraet(false);
  await d.rcSchreiben({ fahrzeugGrenze: 10, fahrzeugGrenzeStufe: 'Voll' });
  assert.equal((await anlegen(d, 'A')).ok, true);
  const r = await anlegen(d, 'B');
  assert.equal(r.ok, false);
  assert.match(r.fehler.allgemein, /Stufe Basic/);
});

test('Mittel: 3 Fahrzeuge, das vierte nicht; Unterfahrzeuge („Gehört zu“) zählen mit', async () => {
  const { d } = await geraet(true, 'mittel');
  const boot = await anlegen(d, 'Segelyacht');
  assert.equal(boot.ok, true);
  const dinghy = await anlegen(d, 'Beiboot', { hauptfahrzeugId: boot.id });
  assert.equal(dinghy.ok, true);
  const anh = await d.fahrzeugAnlegen('boot', { bezeichnung: 'Trailer', hauptfahrzeugId: boot.id });
  assert.equal(anh.ok, true);
  const r = await anlegen(d, 'Viertes');
  assert.equal(r.ok, false);
  assert.match(r.fehler.allgemein, /Stufe Mittel sind 3 Fahrzeuge/);
  assert.equal(await anzahl(d), 3);
});

test('Abgegebene Fahrzeuge zählen nicht mit', async () => {
  const { d } = await geraet(false);
  const a = await anlegen(d, 'Altes Boot');
  assert.equal((await anlegen(d, 'Neues Boot')).ok, false);
  const ab = await d.fahrzeugAbgeben(a.id, { datum: '2026-11-01', grund: 'verkauft' });
  assert.equal(ab.ok, true);
  assert.equal((await anlegen(d, 'Neues Boot')).ok, true);
  assert.equal(await anzahl(d), 1);
});

test('Voll ist unbegrenzt (Dienst nennt null)', async () => {
  const { d } = await geraet(true, 'voll');
  for (let i = 0; i < 6; i++) assert.equal((await anlegen(d, 'Boot ' + i)).ok, true, 'Fahrzeug ' + i);
  assert.equal(await anzahl(d), 6);
});

test('Die App merkt sich die Grenze vom Dienst (Geräte-Dokument), sobald die Stufe abgefragt wird', async () => {
  const { d } = await geraet(true, 'mittel');
  const s = await d.kontoStufe();
  assert.equal(s.ok, true);
  const g = await d.rcGeraet();
  assert.equal(g.fahrzeugGrenze, 3);
  assert.equal(g.fahrzeugGrenzeStufe, 'Mittel');
  assert.ok(g.fahrzeugGrenzeAm);
});

test('Ohne Netz gilt der gemerkte Wert: Mittel mit 3 Fahrzeugen, das vierte wird abgelehnt, ohne dass der Dienst gebraucht wird', async () => {
  const { d, dienst } = await geraet(true, 'mittel');
  await d.kontoStufe();
  dienst.netz = false;
  for (let i = 0; i < 3; i++) assert.equal((await anlegen(d, 'Boot ' + i)).ok, true);
  const r = await anlegen(d, 'Boot 3');
  assert.equal(r.ok, false);
  assert.match(r.fehler.allgemein, /Stufe Mittel/);
  assert.equal(await anzahl(d), 3);
});

test('Ohne Netz und ohne gemerkten Wert gilt Basic, auch wenn angemeldet', async () => {
  const { d, dienst } = await geraet(true, 'voll');
  dienst.netz = false;
  assert.equal((await anlegen(d, 'A')).ok, true);
  const r = await anlegen(d, 'B');
  assert.equal(r.ok, false);
  assert.match(r.fehler.allgemein, /Stufe Basic/);
});

test('Stufenwechsel nach oben: Ist der gemerkte Wert zu klein, fragt die App den Dienst und legt dann an', async () => {
  const { d, dienst } = await geraet(true, 'basic');
  await d.kontoStufe();
  assert.equal((await anlegen(d, 'A')).ok, true);
  assert.equal((await anlegen(d, 'B')).ok, false, 'Basic: das zweite nicht');
  dienst.stufe = 'mittel';
  const r = await anlegen(d, 'B');
  assert.equal(r.ok, true, 'der Dienst nennt jetzt Mittel');
  assert.equal((await d.rcGeraet()).fahrzeugGrenze, 3, 'der neue Wert ist gemerkt');
  assert.equal(await anzahl(d), 2);
});

test('Nach der Testwoche (Basic, 3 Fahrzeuge da): nichts wird gelöscht, nur kein neues Fahrzeug', async () => {
  const { d, dienst } = await geraet(true, 'test');
  await d.kontoStufe();
  for (let i = 0; i < 3; i++) assert.equal((await anlegen(d, 'Boot ' + i)).ok, true);
  dienst.stufe = 'basic';
  const r = await anlegen(d, 'Boot 3');
  assert.equal(r.ok, false);
  assert.match(r.fehler.allgemein, /Stufe Basic ist 1 Fahrzeug möglich. Du hast schon 3/);
  assert.equal(r.grenze.frei, 0);
  assert.equal(await anzahl(d), 3, 'vorhandene Fahrzeuge bleiben');
  /* Vorhandene lassen sich weiter bearbeiten. */
  const liste = await d.fahrzeugListe();
  const e = await d.fahrzeugAendern(liste[0].fahrzeug.id, { bezeichnung: liste[0].aktuell.werte.bezeichnung + ' neu' });
  assert.equal(e.ok, true);
});

test('Entwurfsfehler vor der Grenze: ein ungültiges Fahrzeug meldet seinen Fehler, nicht die Grenze', async () => {
  const { d } = await geraet(false);
  await anlegen(d, 'A');
  const r = await d.fahrzeugAnlegen('boot', { bezeichnung: '   ' });
  assert.equal(r.ok, false);
  assert.ok(r.fehler.bezeichnung);
});

test('Gleiche Kennung: Die Grenze kommt zuerst, die Rückfrage danach', async () => {
  const { d } = await geraet(true, 'mittel');
  await d.kontoStufe();
  const a = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'WM', kennzeichen: 'LB-MM 123' });
  assert.equal(a.ok, true);
  const r = await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'WM 2', kennzeichen: 'LB-MM 123' });
  assert.equal(r.ok, false);
  assert.ok(r.doppelt, 'Mittel hat noch Platz: die Frage nach der Kennung kommt');
});

test('Import: passen nicht alle neuen Fahrzeuge, wird nichts angelegt und der Hinweis nennt die Stufe und den freien Platz', async () => {
  const { d } = await geraet(true, 'mittel');
  await d.kontoStufe();
  await anlegen(d, 'Vorhanden');
  const kopf = ['Bezeichnung'];
  const z = MM.Austausch.spaltenRaten(kopf, d.importZielfelder('boot'));
  const opt = { zeilen: [['Neu 1'], ['Neu 2'], ['Neu 3']], zuordnung: z, artId: 'boot' };
  const r = await d.importFahrzeuge(opt);
  assert.equal(r.ok, false);
  assert.match(r.fehler, /Stufe Mittel/);
  assert.match(r.fehler, /3 neue Fahrzeuge/);
  assert.match(r.fehler, /passen noch 2/);
  assert.equal(await anzahl(d), 1);
  const ok = await d.importFahrzeuge({ zeilen: [['Neu 1'], ['Neu 2']], zuordnung: z, artId: 'boot' });
  assert.equal(ok.ok, true);
  assert.equal(ok.anzahl, 2);
  assert.equal(await anzahl(d), 3);
});

test('Übernahme einer Übergabe-Datei zählt als ein neues Fahrzeug', async () => {
  const { d: quelle } = await geraet(true, 'voll');
  const f = await anlegen(quelle, 'Weitergabe');
  await quelle.fahrzeugAbgeben(f.id, { datum: '2026-11-01', grund: 'verkauft' });
  const dat = await quelle.uebergabeErzeugen(f.id, {});
  assert.equal(dat.ok, true, JSON.stringify(dat.fehler || ''));
  const gelesen = await (async () => { const l = await quelle.uebergabeLesen(dat.bytes, dat.schluessel || undefined); return l.gelesen || l; })();
  const { d } = await geraet(false);
  await anlegen(d, 'Eigenes Boot');
  const r = await d.uebergabeEinspielen(gelesen, {});
  assert.equal(r.ok, false);
  assert.match(r.fehler.allgemein, /Stufe Basic/);
  assert.equal(await anzahl(d), 1);
});

test('Anzeige: Das Formular zeigt den Hinweistext der Grenze statt „Bitte eine Angabe prüfen“', () => {
  const a = lesen('js/ansicht.js');
  assert.ok(a.includes("text: zustand.fehler.allgemein ? zustand.fehler.allgemein : (fk.length === 1 ? 'Bitte eine Angabe prüfen.'"));
});

test('docs/SCHRITTE.md: 13e als am Gerät getestet, Fahrzeug-Grenze als gebaut (2.0.70)', () => {
  const s = lesen('docs/SCHRITTE.md');
  assert.ok(/13e[^\n]*am Gerät getestet \(Nutzer, 12\.11\.2026\)/.test(s));
  assert.ok(/Fahrzeug-Grenze[^\n]*2\.0\.70/.test(s));
});
