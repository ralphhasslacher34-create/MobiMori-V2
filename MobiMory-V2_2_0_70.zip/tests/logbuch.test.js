'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/hilfen.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
const MM = globalThis.MM;
const L = MM.Logbuch;

test('Tage im Zeitraum: einschließlich, über Monats- und Jahresgrenze, falsche Reihenfolge ergibt nichts', () => {
  assert.deepEqual(L.tageImZeitraum('2026-12-01', '2026-12-03').tage, ['2026-12-01', '2026-12-02', '2026-12-03']);
  assert.deepEqual(L.tageImZeitraum('2026-12-30', '2027-01-02').tage, ['2026-12-30', '2026-12-31', '2027-01-01', '2027-01-02']);
  assert.deepEqual(L.tageImZeitraum('2028-02-28', '2028-03-01').tage, ['2028-02-28', '2028-02-29', '2028-03-01'], 'Schaltjahr');
  assert.deepEqual(L.tageImZeitraum('2026-12-01', '2026-12-01').tage, ['2026-12-01']);
  assert.deepEqual(L.tageImZeitraum('2026-12-05', '2026-12-01').tage, []);
  assert.deepEqual(L.tageImZeitraum('', '2026-12-01').tage, []);
});

test('Tage im Zeitraum: genau 366 Tage gehen, mehr nicht', () => {
  assert.equal(L.tageImZeitraum('2026-01-01', '2026-12-31').tage.length, 365);
  assert.equal(L.tageImZeitraum('2028-01-01', '2028-12-31').tage.length, 366);
  const z = L.tageImZeitraum('2028-01-01', '2029-01-01');
  assert.equal(z.zuLang, true);
  assert.deepEqual(z.tage, []);
});

test('Wochentag', () => {
  assert.equal(L.wochentag('2026-11-03'), 'Di');
  assert.equal(L.wochentag('2026-11-08'), 'So');
  assert.equal(L.wochentag('kaputt'), '');
});

test('Fehlende Tage: Uhrzeit nur am ersten und letzten Tag, vorhandene Tage werden übersprungen', () => {
  const a = { vonDatum: '2026-12-01', vonZeit: '09:00', bisDatum: '2026-12-03', bisZeit: '17:30' };
  const alle = L.fehlendeTage(a, []);
  assert.equal(alle.neu.length, 3);
  assert.equal(alle.neu[0].beginnZeit, '09:00'); assert.equal(alle.neu[0].endeZeit, null);
  assert.equal(alle.neu[1].beginnZeit, null); assert.equal(alle.neu[1].endeZeit, null);
  assert.equal(alle.neu[2].beginnZeit, null); assert.equal(alle.neu[2].endeZeit, '17:30');
  assert.ok(alle.neu.every(w => w.ausgeblendet === 'nein'));
  const rest = L.fehlendeTage(a, ['2026-12-02']);
  assert.deepEqual(rest.neu.map(w => w.datum), ['2026-12-01', '2026-12-03']);
  assert.equal(L.fehlendeTage(a, ['2026-12-01', '2026-12-02', '2026-12-03']).neu.length, 0);
});

test('Fehlende Tage: ein Tag bekommt Beginn und Ende; ohne Uhrzeit bleibt sie leer; zu langer Zeitraum wird gemeldet', () => {
  const eins = L.fehlendeTage({ vonDatum: '2026-12-01', vonZeit: '08:00', bisDatum: '2026-12-01', bisZeit: '18:00' }, []);
  assert.equal(eins.neu.length, 1);
  assert.equal(eins.neu[0].beginnZeit, '08:00'); assert.equal(eins.neu[0].endeZeit, '18:00');
  const ohne = L.fehlendeTage({ vonDatum: '2026-12-01', vonZeit: null, bisDatum: '2026-12-02', bisZeit: null }, []);
  assert.ok(ohne.neu.every(w => w.beginnZeit === null && w.endeZeit === null));
  const lang = L.fehlendeTage({ vonDatum: '2026-01-01', bisDatum: '2028-01-01' }, []);
  assert.equal(lang.zuLang, true); assert.equal(lang.neu.length, 0);
});

const abs = (datum, beginn) => ({ objekt: { id: 'a-' + datum + (beginn || '') }, aktuell: { werte: { datum, beginnZeit: beginn || null, ausgeblendet: 'nein' } } });

test('Abschnitte sortieren nach Datum und Beginn', () => {
  const s = L.abschnitteSortieren([abs('2026-12-02'), abs('2026-12-01', '14:00'), abs('2026-12-01', '08:00')]);
  assert.deepEqual(s.map(x => x.objekt.id), ['a-2026-12-0108:00', 'a-2026-12-0114:00', 'a-2026-12-02']);
});

test('Abschnitt für einen Zeitpunkt: gleicher Tag, sonst der letzte davor, sonst der erste, ohne Abschnitte nichts', () => {
  const liste = [abs('2026-12-01'), abs('2026-12-03')];
  assert.equal(L.abschnittFuer(liste, '2026-12-03').objekt.id, 'a-2026-12-03');
  assert.equal(L.abschnittFuer(liste, '2026-12-02').objekt.id, 'a-2026-12-01', 'Lücke: der Tag davor');
  assert.equal(L.abschnittFuer(liste, '2026-12-09').objekt.id, 'a-2026-12-03', 'nach dem Ende: der letzte');
  assert.equal(L.abschnittFuer(liste, '2026-11-20').objekt.id, 'a-2026-12-01', 'vor dem Anfang: der erste');
  assert.equal(L.abschnittFuer([], '2026-12-01'), null);
});

test('Wechsel als Ereignisse: der erste Eintrag ist der Beginn und kein Wechsel, die Reihenfolge richtet sich nach der Zeit', () => {
  const ver = [
    { id: 'v3', personId: 'p1', name: 'Anna', ab: '2026-12-04T08:00' },
    { id: 'v1', personId: 'p1', name: 'Anna', ab: '2026-12-01T00:00' },
    { id: 'v2', personId: 'p2', name: 'Ben', ab: '2026-12-02T10:30', notiz: 'Seekrank', ausgeblendet: 'nein', geaendert: true }
  ];
  const w = L.wechselEreignisse(ver);
  assert.equal(w.length, 2);
  assert.equal(w[0].verantwortungId, 'v2'); assert.equal(w[0].datum, '2026-12-02'); assert.equal(w[0].zeit, '10:30');
  assert.equal(w[0].vorher, 'Anna'); assert.equal(w[0].notiz, 'Seekrank'); assert.equal(w[0].geaendert, true);
  assert.equal(w[0].text, 'Ben ist ab jetzt verantwortlich (vorher Anna).');
  assert.equal(w[1].verantwortungId, 'v3'); assert.equal(w[1].geaendert, false);
  assert.deepEqual(L.wechselEreignisse([ver[1]]), [], 'ein einziger Eintrag ist kein Wechsel');
  assert.deepEqual(L.wechselEreignisse([]), []);
});

test('Ereignisse sortieren nach Zeitpunkt', () => {
  const s = L.ereignisseSortieren([{ zeitpunkt: '2026-12-01T12:00', id: 2 }, { zeitpunkt: '2026-12-01T08:00', id: 1 }, { zeitpunkt: '2026-12-02T01:00', id: 3 }]);
  assert.deepEqual(s.map(x => x.id), [1, 2, 3]);
  assert.equal(L.ereignisZeit({ datum: '2026-12-01', zeit: '07:05' }), '2026-12-01T07:05');
});

const pr = {
  geprueftAm: '2026-11-03T12:00',
  befaehigung: { ergebnis: 'unklar', gebiet: 'Kroatien', gebietHinweis: 'Hinweis',
    personen: [
      { person: { id: 'p1', name: 'Anna' }, rolleText: 'Skipper', ergebnis: 'erlaubt', gruende: [{ ergebnis: 'erlaubt', text: 'SBF mit Scan' }] },
      { person: { id: 'p2', name: 'Ben' }, rolleText: 'Stellvertreter', ergebnis: 'unklar', gruende: [{ ergebnis: 'unklar', text: 'Kein Nachweis' }] }] },
  ausruestung: { ergebnis: 'unklar', liste: [{ bezeichnung: 'Rettungsweste', status: 'fehlt', text: 'Eingetragen sind 1, Soll ist 2', pflicht: 'x' }] },
  fristen: { zusammenfassung: { betroffen: 1, sperre: false, eingeschraenkt: true },
    liste: [{ bezeichnung: 'Motorservice', status: 'faellig', wirkung: 'eingeschraenkt', text: 'Zeit: fällig' }, { bezeichnung: 'Gasprüfung', status: 'ok', text: 'ok' }] }
};

test('Prüfung festhalten: feste Form mit Verantwortlichem, nur Auffälliges bei den Fristen', () => {
  const p = L.pruefungFestgehalten(pr, { personId: 'p2', name: 'Ben' }, '2026-12-02T00:00');
  assert.equal(p.geprueftAm, '2026-11-03T12:00');
  assert.equal(p.tagesbeginn, '2026-12-02T00:00');
  assert.deepEqual(p.verantwortlich, { personId: 'p2', name: 'Ben', ergebnis: 'unklar' });
  assert.equal(p.befaehigung.ergebnis, 'unklar');
  assert.equal(p.befaehigung.personen[0].name, 'Anna');
  assert.equal(p.befaehigung.personen[0].gruende[0].text, 'SBF mit Scan');
  assert.deepEqual(p.ausruestung.liste, [{ bezeichnung: 'Rettungsweste', status: 'fehlt', text: 'Eingetragen sind 1, Soll ist 2' }]);
  assert.equal(p.fristen.liste.length, 1);
  assert.equal(p.fristen.gesamt, 2);
  assert.equal(p.fristen.eingeschraenkt, true);
  assert.ok(!JSON.stringify(p).includes('pflicht'), 'nur das Nötige wird festgehalten');
});

test('Prüfung festhalten: ohne Verantwortlichen, ohne Ausrüstung', () => {
  const p = L.pruefungFestgehalten(Object.assign({}, pr, { ausruestung: null }), null, '2026-12-01T00:00');
  assert.equal(p.verantwortlich, null);
  assert.equal(p.ausruestung, null);
  const q = L.pruefungFestgehalten(pr, { personId: 'unbekannt', name: 'Cora' }, '2026-12-01T00:00');
  assert.equal(q.verantwortlich.ergebnis, null, 'wer nicht geprüft wurde, hat kein Ergebnis');
});

test('Prüfung kurz: ein Satz', () => {
  const p = L.pruefungFestgehalten(pr, { personId: 'p1', name: 'Anna' }, '2026-12-01T00:00');
  assert.equal(L.pruefungKurz(p), 'Befähigung: Unklar, Ausrüstung: Unklar, Fristen: 1 betroffen');
  assert.equal(L.pruefungKurz(null), null);
  const q = L.pruefungFestgehalten(Object.assign({}, pr, { ausruestung: null, fristen: { zusammenfassung: { betroffen: 0, sperre: false, eingeschraenkt: false }, liste: [] } }), null, 'x');
  assert.equal(L.pruefungKurz(q), 'Befähigung: Unklar, Fristen: keine betroffen');
});

test('Vorschläge für Ereignisarten sind die der Übergabe', () => {
  assert.deepEqual(L.VORSCHLAEGE_EREIGNISARTEN, ['Abfahrt', 'Ankunft', 'Wechsel des Verantwortlichen', 'Störung', 'Notiz']);
});
