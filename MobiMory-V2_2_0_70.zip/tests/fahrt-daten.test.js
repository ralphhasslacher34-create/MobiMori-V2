'use strict';
/* Geschwindigkeit im Logbuch (2.0.44): Eintrag im Rhythmus, Tagesabschluss, Zustand auf dem Gerät. */
const test = require('node:test');
const assert = require('node:assert/strict');

['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren', 'personen', 'orte',
  'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'etappen', 'karte', 'fahrt', 'reisecheck', 'daten']
  .forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();

async function neu(welt, von, bis) {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(), holeJson: async () => null });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen(welt === 'wasser' ? 'boot' : 'wohnmobil', { bezeichnung: welt === 'wasser' ? 'Boot' : 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: [welt === 'wasser' ? 'Skipper' : 'Fahrer'] })).id;
  const artId = (await d.aktivitaetsartenListe()).find(a => a.aktuell.werte.bezeichnung === (welt === 'wasser' ? 'Törn' : 'Urlaub')).objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Reise', artId, fahrzeugId: fz, vonDatum: von || '2026-11-03', vonZeit: '08:00', bisDatum: bis || '2026-11-04', verantwortlichId: anna });
  assert.equal(r.ok, true, JSON.stringify(r));
  await d.tagesabschnitteVorbereiten(r.id);
  return { d, fz, akt: r.id };
}
const zustand = (extra) => Object.assign(MM.Fahrt.neu(), { tagDatum: '2026-11-03', startMs: Date.now() - 4 * 3600000, km: 120, fahrMs: 2 * 3600000, aktuell: { kmh: 55, zeitMs: Date.now() } }, extra || {});
const eintraege = async (c) => {
  const lb = await c.d.logbuchLaden(c.akt);
  return lb.abschnitte.flatMap(x => x.ereignisse).filter(e => e.art === 'ereignis' && MM.Logbuch.istGeschwindigkeitsArt(e.artName));
};

test('Zustand der Zählung: lesen, speichern, je Aktivität getrennt', async () => {
  const c = await neu();
  assert.equal((await c.d.gpsFahrtLesen(c.akt)).startMs, null);
  await c.d.gpsFahrtSpeichern(c.akt, zustand());
  assert.equal((await c.d.gpsFahrtLesen(c.akt)).km, 120);
  assert.equal((await c.d.gpsFahrtLesen('andere')).km, 0);
});

test('Rhythmus: ohne begonnenen Tag nichts, sonst ein Eintrag mit Text und der Art, die nur einmal angelegt wird', async () => {
  const c = await neu();
  assert.equal((await c.d.fahrtEintragen(c.akt, { fahrt: MM.Fahrt.neu(), art: 'rhythmus' })).ok, false);
  assert.equal((await eintraege(c)).length, 0);
  const r = await c.d.fahrtEintragen(c.akt, { fahrt: zustand(), art: 'rhythmus', position: { breite: 48.1, laenge: 9.2, genauigkeit: 5 } });
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.match(r.text, /^Geschwindigkeit \(automatisch\): aktuell 55,0 km\/h, Ø fahrend 60,0 km\/h, Ø Tag 30,0 km\/h, Strecke 120,0 km, Fahrzeit 2 h 00 min, Gesamtzeit 4 h 00 min/);
  assert.equal((await c.d.fahrtEintragen(c.akt, { fahrt: zustand(), art: 'rhythmus' })).ok, true);
  const e = await eintraege(c);
  assert.equal(e.length, 2);
  assert.equal(typeof e[0].breite, 'number', 'mit Position');
  const arten = (await c.d.ereignisartenListe()).filter(a => MM.Logbuch.istGeschwindigkeitsArt(a.aktuell.werte.bezeichnung));
  assert.equal(arten.length, 1, 'die Art gibt es nur einmal');
});

test('Wasserfahrzeug: Knoten und Seemeilen im Eintrag', async () => {
  const c = await neu('wasser');
  const r = await c.d.fahrtEintragen(c.akt, { fahrt: zustand({ km: 37.04, fahrMs: 4 * 3600000 }), art: 'tag' });
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.match(r.text, /Ø fahrend 5,0 kn/); assert.match(r.text, /Strecke 20,0 sm/);
});

test('Tagesabschluss: schreibt den Tageswert genau einmal, danach bleibt der Wert stehen', async () => {
  const c = await neu();
  const tag = (await c.d.logbuchLaden(c.akt)).abschnitte[0].objekt.id;
  /* ohne Zählung: nichts */
  assert.deepEqual(await c.d.fahrtTagAbschliessen(tag), { ok: true, geschrieben: false });
  await c.d.gpsFahrtSpeichern(c.akt, zustand());
  const r = await c.d.fahrtTagAbschliessen(tag);
  assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.geschrieben, true);
  assert.match(r.text, /^Geschwindigkeit \(Tagesabschluss\): Ø fahrend 60,0 km\/h, Ø Tag 30,0 km\/h, Strecke 120,0 km/);
  assert.doesNotMatch(r.text, /aktuell/);
  assert.equal((await eintraege(c)).length, 1);
  const f = await c.d.gpsFahrtLesen(c.akt);
  assert.equal(f.abgeschlossen, true); assert.equal(typeof f.schlussMs, 'number');
  assert.equal((await c.d.fahrtTagAbschliessen(tag)).geschrieben, false, 'ein zweiter Abschluss schreibt nichts mehr');
  assert.equal((await eintraege(c)).length, 1);
});

test('Tagesabschluss eines anderen Tages berührt die Zählung nicht', async () => {
  const c = await neu();
  const lb = await c.d.logbuchLaden(c.akt);
  const morgen = lb.abschnitte.find(x => x.aktuell.werte.datum === '2026-11-04').objekt.id;
  await c.d.gpsFahrtSpeichern(c.akt, zustand());
  assert.equal((await c.d.fahrtTagAbschliessen(morgen)).geschrieben, false);
  assert.equal((await c.d.gpsFahrtLesen(c.akt)).abgeschlossen, false);
});

test('Tagesabschluss eines früheren Tages: nachgetragen mit dem Datum des Tages', async () => {
  const c = await neu('land', '2026-11-01', '2026-11-02');
  const tag = (await c.d.logbuchLaden(c.akt)).abschnitte.find(x => x.aktuell.werte.datum === '2026-11-02').objekt.id;
  await c.d.gpsFahrtSpeichern(c.akt, zustand({ tagDatum: '2026-11-02' }));
  const r = await c.d.fahrtTagAbschliessen(tag);
  assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.geschrieben, true);
  const e = await eintraege(c);
  assert.equal(e.length, 1); assert.equal(e[0].datum, '2026-11-02');
  assert.equal((await c.d.gpsFahrtLesen(c.akt)).abgeschlossen, true);
});

test('Die Art „Geschwindigkeit“ erscheint nicht im Angebot der Schnellknöpfe', async () => {
  const c = await neu();
  await c.d.fahrtEintragen(c.akt, { fahrt: zustand(), art: 'rhythmus' });
  const fz = await c.d.fahrzeugLaden(c.fz);
  const sk = await c.d.schnellknoepfeFuerFahrzeugart(fz.aktuell.werte.artId || fz.fahrzeug.artId || 'wohnmobil');
  assert.ok(!sk.angebot.alle.some(x => MM.Logbuch.istGeschwindigkeitsArt(x.name)));
});
