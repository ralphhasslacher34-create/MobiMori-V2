'use strict';
/* 2.0.23: Status des Fahrzeugs und Regeln der Ereignisse (Festlegung vom 04.11.2026). */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/reiseorte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const S = MM.Status;

/* ---------- Rechnung ohne Speicher ---------- */
test('Status je Welt: Land hat zwei, Wasser drei, Luft keinen', () => {
  assert.deepEqual(S.statusIds('land'), ['stillstand', 'in-fahrt']);
  assert.deepEqual(S.statusIds('wasser'), ['festgemacht', 'in-fahrt', 'vor-anker']);
  assert.deepEqual(S.statusIds('luft'), []);
  assert.equal(S.hatStatus('luft'), false);
  assert.equal(S.statusName('wasser', 'vor-anker'), 'Vor Anker');
});

test('Regel einer Art: Starthilfe nach dem Namen, nur wenn die Status zur Welt passen', () => {
  assert.deepEqual(S.regelFuer({ bezeichnung: 'Abfahrt' }, 'land'), { gilt: ['stillstand'], danach: 'in-fahrt', quelle: 'standard' });
  assert.deepEqual(S.regelFuer({ bezeichnung: ' ANKER WERFEN ' }, 'wasser'), { gilt: ['in-fahrt'], danach: 'vor-anker', quelle: 'standard' });
  assert.equal(S.regelFuer({ bezeichnung: 'Abfahrt' }, 'wasser'), null, 'Abfahrt gibt es beim Boot nicht als Status-Ereignis');
  assert.equal(S.regelFuer({ bezeichnung: 'Anlegen' }, 'land'), null);
  assert.equal(S.regelFuer({ bezeichnung: 'Notiz' }, 'land'), null);
  assert.equal(S.regelFuer({ bezeichnung: 'Abfahrt' }, 'luft'), null);
});

test('Eigene Regel hat Vorrang vor dem Namen, „keine“ schaltet die Wirkung ab', () => {
  const eigene = S.regelFuer({ bezeichnung: 'Abfahrt', giltImStatus: 'in-fahrt', danachStatus: 'stillstand' }, 'land');
  assert.deepEqual(eigene, { gilt: ['in-fahrt'], danach: 'stillstand', quelle: 'eigene' });
  assert.equal(S.regelFuer({ bezeichnung: 'Abfahrt', danachStatus: 'keine' }, 'land'), null);
  assert.equal(S.regelFuer({ bezeichnung: 'Schleuse', giltImStatus: 'in-fahrt', danachStatus: 'vor-anker' }, 'land'), null, 'Status passt nicht zur Welt');
});

test('Eingabe der Regel: beides leer ist die Starthilfe, sonst müssen beide Angaben stimmen', () => {
  assert.deepEqual(S.regelNormal({}), { ok: true, werte: { giltImStatus: '', danachStatus: '' } });
  assert.deepEqual(S.regelNormal({ giltImStatus: [], danachStatus: '' }).werte, { giltImStatus: '', danachStatus: '' });
  assert.equal(S.regelNormal({ giltImStatus: ['in-fahrt'], danachStatus: '' }).ok, false);
  assert.ok(S.regelNormal({ danachStatus: 'festgemacht' }).fehler.giltImStatus);
  assert.ok(S.regelNormal({ giltImStatus: ['in-fahrt'], danachStatus: 'quatsch' }).fehler.danachStatus);
  assert.deepEqual(S.regelNormal({ giltImStatus: ['vor-anker', 'in-fahrt', 'in-fahrt', 'x'], danachStatus: 'festgemacht' }).werte,
    { giltImStatus: 'vor-anker,in-fahrt', danachStatus: 'festgemacht' });
  assert.deepEqual(S.regelNormal({ danachStatus: 'keine' }).werte, { giltImStatus: '', danachStatus: 'keine' });
});

test('Status aus den Ereignissen: nach Uhrzeit, ohne Ausgeblendete und ohne Zukunft', () => {
  const e = (n, z, extra) => Object.assign({ artName: n, zeitpunkt: z }, extra || {});
  const jetzt = '2026-11-04T12:00';
  let st = S.rechnen([], {}, 'land', jetzt);
  assert.equal(st.status, null); assert.equal(st.unbekannt, true); assert.equal(st.wirksam, 'stillstand');
  /* Eintippen in anderer Reihenfolge als die Uhrzeit */
  st = S.rechnen([e('Ankunft', '2026-11-04T10:00'), e('Abfahrt', '2026-11-04T08:00')], {}, 'land', jetzt);
  assert.equal(st.status, 'stillstand'); assert.equal(st.durch, 'Ankunft'); assert.equal(st.name, 'Stillstand');
  st = S.rechnen([e('Abfahrt', '2026-11-04T08:00'), e('Ankunft', '2026-11-04T10:00', { ausgeblendet: true })], {}, 'land', jetzt);
  assert.equal(st.status, 'in-fahrt');
  st = S.rechnen([e('Abfahrt', '2026-11-04T08:00'), e('Ankunft', '2026-11-04T13:00')], {}, 'land', jetzt);
  assert.equal(st.status, 'in-fahrt', 'ein Ereignis in der Zukunft zählt nicht');
  st = S.rechnen([e('Notiz', '2026-11-04T09:00'), e('Foto', '2026-11-04T09:30')], {}, 'land', jetzt);
  assert.equal(st.unbekannt, true, 'Notiz und Foto ändern den Status nicht');
  assert.equal(S.rechnen([e('Abfahrt', '2026-11-04T08:00')], {}, 'luft', jetzt).status, null);
});

test('Grund für gesperrte Knöpfe: der kürzeste Weg im Statusmodell', () => {
  const regeln = (welt) => ['Abfahrt', 'Ankunft', 'Ablegen', 'Anlegen', 'Anker werfen', 'Anker lichten', 'Notiz']
    .map(n => ({ name: n, regel: S.regelFuer({ bezeichnung: n }, welt) })).filter(x => x.regel || x.name === 'Notiz');
  const stand = (welt, status) => S.rechnen(status ? [{ artName: { 'in-fahrt': welt === 'land' ? 'Abfahrt' : 'Ablegen', 'festgemacht': 'Anlegen', 'vor-anker': 'Anker werfen', 'stillstand': 'Ankunft' }[status], zeitpunkt: '2026-11-04T08:00' }] : [], {}, welt, '2026-11-04T12:00');
  const pruef = (welt, status, name) => S.pruefen(S.regelFuer({ bezeichnung: name }, welt), stand(welt, status), regeln(welt));
  assert.equal(pruef('land', null, 'Abfahrt').erlaubt, true, 'beim ersten Mal ist der Anfang frei');
  assert.equal(pruef('land', null, 'Ankunft').grund, 'erst Abfahrt');
  assert.equal(pruef('land', 'in-fahrt', 'Abfahrt').grund, 'erst Ankunft');
  assert.equal(pruef('wasser', null, 'Anlegen').grund, 'erst Ablegen');
  assert.equal(pruef('wasser', null, 'Anker lichten').grund, 'erst Ablegen, dann Anker werfen');
  assert.equal(pruef('wasser', 'in-fahrt', 'Ablegen').grund, 'erst Anlegen');
  assert.equal(pruef('wasser', 'vor-anker', 'Anlegen').grund, 'erst Anker lichten');
  assert.equal(pruef('wasser', 'vor-anker', 'Ablegen').grund, 'erst Anker lichten, dann Anlegen');
  assert.equal(pruef('wasser', 'vor-anker', 'Anker lichten').erlaubt, true);
  assert.equal(pruef('wasser', 'in-fahrt', 'Anker werfen').erlaubt, true);
  assert.equal(S.pruefen(null, stand('land', 'in-fahrt'), regeln('land')).erlaubt, true, 'ohne Regel ist alles erlaubt');
  assert.equal(pruef('wasser', 'vor-anker', 'Anlegen').statusName, 'Vor Anker');
});

/* ---------- Mit Speicher ---------- */
function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 4, 8, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.stelle = (jahr, monat, tag, std, min) => { uhr.ms = new Date(jahr, monat - 1, tag, std, min, 0).getTime(); t = 0; };
  return d;
}
async function neuesFahrzeug(artId, artName, von, bis) {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  await d.ereignisartenVorauswahlUebernehmen();
  const fz = (await d.fahrzeugAnlegen(artId, { bezeichnung: 'Fahrzeug' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const art = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === artName).objekt.id;
  const neueAktivitaet = async (vonDatum, bisDatum) => {
    const r = await d.aktivitaetAnlegen({ bezeichnung: 'Fahrt ' + vonDatum, artId: art, fahrzeugId: fz, vonDatum, vonZeit: '06:00', bisDatum, bisZeit: '20:00', verantwortlichId: anna });
    assert.ok(r.ok, JSON.stringify(r));
    return r.id;
  };
  const id = await neueAktivitaet(von || '2026-11-04', bis || '2026-11-05');
  return { d, fz, id, neueAktivitaet };
}
async function eintragen(c, name, roh) {
  const r = await c.d.ereignisSchnell(c.id, name, roh || {});
  assert.ok(r.ok, name + ': ' + JSON.stringify(r));
  return r;
}
async function gesperrt(c, name, roh) {
  const r = await c.d.ereignisSchnell(c.id, name, roh || {});
  assert.equal(r.ok, false, name + ' hätte gesperrt sein müssen');
  assert.equal(r.gesperrt, true, JSON.stringify(r));
  return r;
}
async function status(c) { return (await c.d.fahrzeugStatus(c.fz)).stand; }

test('Straßenfahrzeug: Abfahrt, Ankunft im Wechsel, alles andere ist gesperrt, Notiz stört nie', async () => {
  const c = await neuesFahrzeug('auto', 'Ausfahrt');
  assert.equal((await status(c)).wirksam, 'stillstand');
  const r1 = await gesperrt(c, 'Ankunft');
  assert.equal(r1.grund, 'erst Abfahrt');
  assert.match(r1.fehler.allgemein, /Stillstand/);
  c.d.stelle(2026, 11, 4, 9, 0);
  await eintragen(c, 'Abfahrt');
  assert.equal((await status(c)).name, 'In Fahrt');
  assert.equal((await gesperrt(c, 'Abfahrt')).grund, 'erst Ankunft');
  await eintragen(c, 'Notiz', { text: 'Pause' });
  await eintragen(c, 'Tanken');
  c.d.stelle(2026, 11, 4, 10, 0);
  await eintragen(c, 'Ankunft');
  assert.equal((await status(c)).name, 'Stillstand');
  await eintragen(c, 'Abfahrt');
});

test('Wasserfahrzeug: die drei Status mit Ablegen, Anlegen, Anker werfen und Anker lichten', async () => {
  const c = await neuesFahrzeug('boot', 'Törn');
  assert.equal((await gesperrt(c, 'Anlegen')).grund, 'erst Ablegen');
  assert.equal((await gesperrt(c, 'Anker werfen')).grund, 'erst Ablegen');
  assert.equal((await gesperrt(c, 'Anker lichten')).grund, 'erst Ablegen, dann Anker werfen');
  c.d.stelle(2026, 11, 4, 9, 0); await eintragen(c, 'Ablegen');
  assert.equal((await status(c)).name, 'In Fahrt');
  assert.equal((await gesperrt(c, 'Ablegen')).grund, 'erst Anlegen');
  c.d.stelle(2026, 11, 4, 10, 0); await eintragen(c, 'Anker werfen');
  assert.equal((await status(c)).name, 'Vor Anker');
  assert.equal((await gesperrt(c, 'Anlegen')).grund, 'erst Anker lichten');
  assert.equal((await gesperrt(c, 'Anker werfen')).grund, 'erst Anker lichten');
  c.d.stelle(2026, 11, 4, 11, 0); await eintragen(c, 'Anker lichten');
  assert.equal((await status(c)).name, 'In Fahrt');
  c.d.stelle(2026, 11, 4, 12, 0); await eintragen(c, 'Anlegen');
  const st = await status(c);
  assert.equal(st.name, 'Festgemacht'); assert.equal(st.seit, '2026-11-04T12:00'); assert.equal(st.durch, 'Anlegen');
  await eintragen(c, 'Ablegen');
});

test('Gesperrt wird nichts gespeichert, und die Antwort sagt, was zu tun ist', async () => {
  const c = await neuesFahrzeug('boot', 'Törn');
  const vorher = (await c.d.logbuchLaden(c.id)).abschnitte.flatMap(t => t.ereignisse).length;
  const r = await gesperrt(c, 'Anlegen');
  assert.equal(r.status, 'Festgemacht');
  assert.match(r.fehler.allgemein, /erst Ablegen/);
  assert.match(r.fehler.allgemein, /nach/);
  const nachher = (await c.d.logbuchLaden(c.id)).abschnitte.flatMap(t => t.ereignisse).length;
  assert.equal(nachher, vorher);
});

test('Nachtragen wird nie gesperrt, der Status richtet sich nach der Uhrzeit', async () => {
  const c = await neuesFahrzeug('auto', 'Ausfahrt');
  c.d.stelle(2026, 11, 4, 12, 0);
  /* Vergessen: erst die Ankunft nachgetragen, dann die Abfahrt davor */
  await eintragen(c, 'Ankunft', { zeit: '11:00' });
  assert.equal((await status(c)).name, 'Stillstand');
  await eintragen(c, 'Abfahrt', { zeit: '09:00' });
  const st = await status(c);
  assert.equal(st.name, 'Stillstand'); assert.equal(st.durch, 'Ankunft', 'die Ankunft um 11:00 liegt nach der Abfahrt um 09:00');
  await eintragen(c, 'Abfahrt');
  assert.equal((await status(c)).name, 'In Fahrt');
});

test('Gleiche Minute: Es zählt die Reihenfolge des Eintippens', async () => {
  const c = await neuesFahrzeug('boot', 'Törn');
  c.d.stelle(2026, 11, 4, 9, 0);
  await eintragen(c, 'Ablegen');
  await eintragen(c, 'Anker werfen');
  const st = await status(c);
  assert.equal(st.name, 'Vor Anker'); assert.equal(st.durch, 'Anker werfen');
  await eintragen(c, 'Anker lichten');
  assert.equal((await status(c)).name, 'In Fahrt');
  assert.equal((await gesperrt(c, 'Anker lichten')).grund, 'erst Anker werfen');
});

test('Gleiche Minute in der reinen Rechnung: erstelltAm entscheidet, sonst die Reihenfolge der Liste', () => {
  const z = '2026-11-04T09:00';
  const a = [{ artName: 'Ablegen', zeitpunkt: z, erstelltAm: '2026-11-04T09:00:00.002Z' }, { artName: 'Anker werfen', zeitpunkt: z, erstelltAm: '2026-11-04T09:00:00.005Z' }];
  assert.equal(S.rechnen(a, {}, 'wasser', '2026-11-04T12:00').status, 'vor-anker');
  assert.equal(S.rechnen(a.slice().reverse(), {}, 'wasser', '2026-11-04T12:00').status, 'vor-anker');
  const ohne = [{ artName: 'Ablegen', zeitpunkt: z }, { artName: 'Anker werfen', zeitpunkt: z }];
  assert.equal(S.rechnen(ohne, {}, 'wasser', '2026-11-04T12:00').status, 'vor-anker');
});

test('Der Status gehört zum Fahrzeug, nicht zur Aktivität', async () => {
  const c = await neuesFahrzeug('boot', 'Törn', '2026-11-02', '2026-11-03');
  c.d.stelle(2026, 11, 2, 9, 0);
  await eintragen(c, 'Ablegen');
  await eintragen(c, 'Anker werfen');
  /* Zwei Tage später, neue Aktivität am selben Boot: Es liegt noch vor Anker */
  const zweite = await c.neueAktivitaet('2026-11-04', '2026-11-05');
  c.d.stelle(2026, 11, 4, 8, 0);
  const c2 = { d: c.d, fz: c.fz, id: zweite };
  assert.equal((await status(c2)).name, 'Vor Anker');
  assert.equal((await gesperrt(c2, 'Ablegen')).grund, 'erst Anker lichten, dann Anlegen');
  await eintragen(c2, 'Anker lichten');
  assert.equal((await status(c2)).name, 'In Fahrt');
});

test('Eine stornierte Aktivität und ausgeblendete Ereignisse zählen für den Status nicht', async () => {
  const c = await neuesFahrzeug('auto', 'Ausfahrt');
  c.d.stelle(2026, 11, 4, 9, 0);
  const r = await eintragen(c, 'Abfahrt');
  assert.equal((await status(c)).name, 'In Fahrt');
  const x = await c.d.ereignisLaden(r.id);
  const w = x.aktuell.werte;
  const a = await c.d.ereignisAendern(r.id, { artId: w.artId, datum: w.datum, zeit: w.zeit, text: w.text || '', ausgeblendet: 'ja' });
  assert.ok(a.ok, JSON.stringify(a));
  assert.equal((await status(c)).name, 'Stillstand', 'ausgeblendet: das Fahrzeug steht wieder');
  assert.equal((await status(c)).unbekannt, true);
  await eintragen(c, 'Abfahrt');
  assert.equal((await status(c)).name, 'In Fahrt');
  const st = await c.d.aktivitaetStornieren(c.id, 'Test');
  assert.ok(st.ok, JSON.stringify(st));
  assert.equal((await status(c)).unbekannt, true, 'eine stornierte Aktivität zählt nicht');
});

test('Eigene Regel einer Ereignisart: gesperrt, wenn der Status nicht passt, und „keine“ sperrt nie', async () => {
  const c = await neuesFahrzeug('boot', 'Törn');
  const neu = await c.d.ereignisartAnlegen({ bezeichnung: 'Mittagshalt', giltImStatus: ['in-fahrt'], danachStatus: 'in-fahrt' });
  assert.ok(neu.ok, JSON.stringify(neu));
  const art = await c.d.ereignisartLaden(neu.id);
  assert.equal(art.aktuell.werte.giltImStatus, 'in-fahrt'); assert.equal(art.aktuell.werte.danachStatus, 'in-fahrt');
  assert.equal((await gesperrt(c, 'Mittagshalt')).grund, 'erst Ablegen');
  c.d.stelle(2026, 11, 4, 9, 0); await eintragen(c, 'Ablegen');
  await eintragen(c, 'Mittagshalt');
  assert.equal((await status(c)).name, 'In Fahrt');
  const frei = await c.d.ereignisartAendern(neu.id, { bezeichnung: 'Mittagshalt', danachStatus: 'keine' });
  assert.ok(frei.ok, JSON.stringify(frei));
  await eintragen(c, 'Anker werfen');
  await eintragen(c, 'Mittagshalt');
  assert.equal((await status(c)).name, 'Vor Anker', 'Mittagshalt ändert den Status jetzt nicht');
});

test('Eigene Regel eintragen: unvollständig wird abgelehnt, ohne Angabe bleibt die Regel', async () => {
  const c = await neuesFahrzeug('boot', 'Törn');
  const schlecht = await c.d.ereignisartAnlegen({ bezeichnung: 'Hafen', danachStatus: 'festgemacht' });
  assert.equal(schlecht.ok, false); assert.ok(schlecht.fehler.giltImStatus);
  const gut = await c.d.ereignisartAnlegen({ bezeichnung: 'Hafen', giltImStatus: ['in-fahrt'], danachStatus: 'festgemacht' });
  assert.ok(gut.ok);
  const ohne = await c.d.ereignisartAendern(gut.id, { bezeichnung: 'Hafen' });
  assert.ok(ohne.ok);
  const art = await c.d.ereignisartLaden(gut.id);
  assert.equal(art.aktuell.werte.danachStatus, 'festgemacht'); assert.equal(art.aktuell.werte.giltImStatus, 'in-fahrt');
  const falsch = await c.d.ereignisartAendern(gut.id, { bezeichnung: 'Hafen', giltImStatus: [], danachStatus: 'vor-anker' });
  assert.equal(falsch.ok, false); assert.ok(falsch.fehler.giltImStatus);
  const zurueck = await c.d.ereignisartAendern(gut.id, { bezeichnung: 'Hafen', giltImStatus: [], danachStatus: '' });
  assert.ok(zurueck.ok);
  assert.equal((await c.d.ereignisartLaden(gut.id)).aktuell.werte.danachStatus, '');
});

test('Luftfahrzeug: keine Status, nichts wird gesperrt', async () => {
  const c = await neuesFahrzeug('flugzeug', 'Ausfahrt');
  const st = await c.d.fahrzeugStatus(c.fz);
  assert.equal(st.hatStatus, false);
  assert.equal(st.pruefe('Abfahrt').erlaubt, true);
  await eintragen(c, 'Ankunft');
  await eintragen(c, 'Ankunft');
});

test('Unbekanntes Fahrzeug: klare Antwort statt Fehler', async () => {
  const d = neueDaten(); await d.starten();
  const r = await d.fahrzeugStatus('gibt-es-nicht');
  assert.equal(r.ok, false); assert.ok(r.fehler.allgemein);
});

test('Das Cockpit trägt keine Sperre ein, wo es keine Regel gibt: Abfahrt beim Boot hat keine Wirkung', async () => {
  const c = await neuesFahrzeug('boot', 'Törn');
  await eintragen(c, 'Abfahrt');
  await eintragen(c, 'Abfahrt');
  assert.equal((await status(c)).unbekannt, true);
  const st = await c.d.fahrzeugStatus(c.fz);
  assert.equal(st.pruefe('Abfahrt').erlaubt, true);
});

test('Der Status braucht keine eigene Tabelle (er wird aus den Ereignissen gerechnet)', () => {
  assert.ok(MM.Speicher.DB_VERSION >= 9);
  assert.ok(!MM.Speicher.TABELLEN.some(n => /status/i.test(n)));
});
