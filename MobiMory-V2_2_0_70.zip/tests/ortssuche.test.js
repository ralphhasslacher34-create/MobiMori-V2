'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/ortssuche.js');
const MM = globalThis.MM;
const S = MM.Ortssuche;

/* Nachgebaute Antworten des Suchdienstes (gekürzt auf das, was die App liest). */
const EUTINGEN = [
  { osm_type: 'node', osm_id: 1, name: 'Eutingen', lat: '48.5651', lon: '8.8951',
    address: { village: 'Eutingen', municipality: 'Gäufelden', county: 'Landkreis Böblingen', state: 'Baden-Württemberg', country: 'Deutschland', country_code: 'de' } },
  { osm_type: 'node', osm_id: 2, name: 'Eutingen', lat: '48.9181', lon: '8.7803',
    address: { village: 'Eutingen an der Enz', municipality: 'Niefern-Öschelbronn', county: 'Enzkreis', state: 'Baden-Württemberg', country: 'Deutschland', country_code: 'de' } },
  { osm_type: 'node', osm_id: 3, name: 'Eutingen im Gäu', lat: '48.4772', lon: '8.7733',
    address: { town: 'Eutingen im Gäu', county: 'Landkreis Freudenstadt', state: 'Baden-Württemberg', country: 'Deutschland', country_code: 'de' } }
];

test('Anfrage: nur der Ortsname geht hinaus, richtig kodiert, deutsch', () => {
  const u = S.anfrageUrl('  Bad  Säckingen ');
  assert.ok(u.startsWith(S.DIENST + '?'));
  assert.ok(u.includes('q=Bad%20S%C3%A4ckingen'));
  assert.ok(u.includes('accept-language=de'));
  assert.ok(u.includes('addressdetails=1'));
});

test('Treffer: derselbe Name mehrfach bleibt eine Auswahlliste mit unterscheidbaren Beschriftungen', () => {
  const k = S.kandidaten(EUTINGEN);
  assert.equal(k.length, 3);
  assert.equal(new Set(k.map(x => x.label)).size, 3, 'alle Beschriftungen verschieden');
  assert.ok(k[0].label.includes('Landkreis Böblingen'));
  assert.ok(k[1].label.includes('Enzkreis'));
  assert.equal(k[0].region, 'Baden-Württemberg');
  assert.equal(k[0].landCode, 'DE');
  assert.equal(k[0].breite, 48.5651);
});

test('Kette: Land, Region, Kreis; in Frankreich Région und Département', () => {
  const de = S.kette(S.kandidaten(EUTINGEN)[1]);
  assert.deepEqual(de.map(g => g.ebene), ['land', 'region', 'kreis']);
  assert.deepEqual(de.map(g => g.name), ['Deutschland', 'Baden-Württemberg', 'Enzkreis']);
  const fr = S.kandidaten([{ osm_type: 'relation', osm_id: 9, name: 'Strasbourg', lat: '48.58', lon: '7.75',
    address: { city: 'Strasbourg', county: 'Bas-Rhin', state: 'Grand Est', country: 'Frankreich', country_code: 'fr' } }]);
  assert.deepEqual(S.kette(fr[0]).map(g => g.name), ['Frankreich', 'Grand Est', 'Bas-Rhin']);
});

test('Kette: ohne Kreis oder wenn Kreis und Region gleich heißen entfällt die Ebene', () => {
  const k = S.kandidaten([{ osm_type: 'relation', osm_id: 5, name: 'Berlin', lat: '52.5', lon: '13.4',
    address: { city: 'Berlin', state: 'Berlin', county: 'Berlin', country: 'Deutschland', country_code: 'de' } }]);
  assert.deepEqual(S.kette(k[0]).map(g => g.ebene), ['land', 'region']);
});

test('Unvollständige und doppelte Treffer fallen weg, Unsinn wird ignoriert', () => {
  const k = S.kandidaten([
    null, 'x', { name: 'Ohne Land', lat: '1', lon: '1', address: {} },
    { name: 'Ohne Position', address: { country: 'Deutschland' } },
    EUTINGEN[0], EUTINGEN[0]
  ]);
  assert.equal(k.length, 1);
  assert.deepEqual(S.kandidaten({ keine: 'liste' }), []);
});

test('Suchen: zu kurz, kein Treffer, kein Netz, Treffer', async () => {
  const geholt = [];
  const hole = antwort => url => { geholt.push(url); return antwort instanceof Error ? Promise.reject(antwort) : Promise.resolve(antwort); };
  const kurz = await S.suchen('E', hole([]));
  assert.equal(kurz.ok, false); assert.equal(kurz.grund, 'zukurz'); assert.equal(geholt.length, 0, 'zu kurz: keine Anfrage');
  const leer = await S.suchen('Nirgendwo', hole([]));
  assert.equal(leer.ok, false); assert.equal(leer.grund, 'leer'); assert.ok(leer.text.includes('Nirgendwo'));
  const netz = await S.suchen('Eutingen', hole(new Error('offline')));
  assert.equal(netz.ok, false); assert.equal(netz.grund, 'netz'); assert.ok(netz.text.includes('ohne Prüfung'));
  const ok = await S.suchen('Eutingen', hole(EUTINGEN));
  assert.equal(ok.ok, true); assert.equal(ok.kandidaten.length, 3);
  assert.equal(geholt.length, 3);
});
