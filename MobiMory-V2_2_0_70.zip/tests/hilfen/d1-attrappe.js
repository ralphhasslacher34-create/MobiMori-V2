'use strict';
/* Eine kleine Nachbildung der Cloudflare-Datenbank (D1) für die Tests, gebaut auf node:sqlite.
   Sie kann prepare, bind, first, all, run und batch, mehr braucht der Konto-Dienst nicht. */
const fs = require('node:fs');
const path = require('node:path');

function neueDatenbank() {
  const { DatabaseSync } = require('node:sqlite');
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys = ON');
  db.exec(fs.readFileSync(path.join(__dirname, '..', '..', 'server', 'schema.sql'), 'utf8'));
  function anweisung(sql, werte) {
    return {
      bind: (...w) => anweisung(sql, w),
      first: async () => { const r = db.prepare(sql).get(...werte); return r === undefined ? null : Object.assign({}, r); },
      all: async () => ({ results: db.prepare(sql).all(...werte).map((r) => Object.assign({}, r)) }),
      run: async () => { const r = db.prepare(sql).run(...werte); return { success: true, meta: { changes: Number(r.changes) } }; },
      _ausfuehren: () => db.prepare(sql).run(...werte)
    };
  }
  return {
    roh: db,
    prepare: (sql) => anweisung(sql, []),
    batch: async (liste) => {
      db.exec('BEGIN');
      let erg;
      try { erg = liste.map((a) => a._ausfuehren()); db.exec('COMMIT'); } catch (e) { db.exec('ROLLBACK'); throw e; }
      return erg.map((r) => ({ success: true, meta: { changes: Number(r.changes) } }));
    }
  };
}
module.exports = { neueDatenbank };
