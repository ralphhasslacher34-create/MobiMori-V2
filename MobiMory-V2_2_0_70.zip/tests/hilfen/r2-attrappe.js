'use strict';
/* Eine kleine Nachbildung des Cloudflare-Dateispeichers (R2) für die Tests: put, get, delete und list. */
function neuerR2() {
  const m = new Map();
  return {
    m,
    async put(k, body) { const buf = new Uint8Array(await new Response(body).arrayBuffer()); m.set(k, buf); return { size: buf.length }; },
    async get(k) { const b = m.get(k); return b ? { body: new Response(b).body, size: b.length } : null; },
    async delete(k) { (Array.isArray(k) ? k : [k]).forEach((x) => m.delete(x)); },
    async list(o) {
      const alle = [...m.keys()].filter((k) => k.startsWith((o && o.prefix) || '')).sort(), n = (o && o.limit) || 1000;
      return { objects: alle.slice(0, n).map((key) => ({ key })), truncated: alle.length > n };
    }
  };
}
module.exports = { neuerR2 };
