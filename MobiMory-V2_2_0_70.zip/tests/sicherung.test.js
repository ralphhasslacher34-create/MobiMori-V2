'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/sicherung.js');
const S = globalThis.MM.Sicherung;

const bytes = (...n) => new Uint8Array(n);
const gleich = (a, b) => Buffer.compare(Buffer.from(a), Buffer.from(b)) === 0;

test('Nicht verschlüsselt: Kopf und Dateien kommen unverändert zurück', async () => {
  const d1 = bytes(1, 2, 3, 4, 5), d2 = bytes(250, 251);
  const datei = await S.bauen({ format: 1, tabellen: { fahrzeuge: [{ id: 'a' }] } }, [d1, d2], '');
  assert.equal(S.beginntMitKennung(datei), true);
  assert.equal(S.istVerschluesselt(datei), false);
  const r = await S.auspacken(datei, '');
  assert.deepEqual(r.kopf.tabellen, { fahrzeuge: [{ id: 'a' }] });
  assert.equal(r.dateien.length, 2);
  assert.ok(gleich(r.dateien[0], d1) && gleich(r.dateien[1], d2));
});

test('Ohne Dateien geht es auch', async () => {
  const datei = await S.bauen({ format: 1, tabellen: {} }, [], '');
  const r = await S.auspacken(datei, '');
  assert.equal(r.dateien.length, 0);
});

test('Verschlüsselt: mit Schlüsselwort lesbar, Inhalt nicht im Klartext zu finden', async () => {
  const geheim = new TextEncoder().encode('GEHEIM-GEHEIM-GEHEIM');
  const datei = await S.bauen({ format: 1, tabellen: { personen: [{ id: 'p', name: 'Anna Beispiel' }] } }, [geheim], 'mein Schlüsselwort');
  assert.equal(S.istVerschluesselt(datei), true);
  const text = Buffer.from(datei).toString('latin1');
  assert.equal(text.includes('Anna Beispiel'), false);
  assert.equal(text.includes('GEHEIM-GEHEIM'), false);
  const r = await S.auspacken(datei, 'mein Schlüsselwort');
  assert.equal(r.kopf.tabellen.personen[0].name, 'Anna Beispiel');
  assert.ok(gleich(r.dateien[0], geheim));
});

test('Verschlüsselt: ohne oder mit falschem Schlüsselwort klare Fehler', async () => {
  const datei = await S.bauen({ format: 1, tabellen: {} }, [], 'richtig');
  await assert.rejects(S.auspacken(datei, ''), e => e.code === 'schluessel_noetig');
  await assert.rejects(S.auspacken(datei, 'falsch'), e => e.code === 'schluessel');
});

test('Verschlüsselt: eine veränderte Datei wird erkannt', async () => {
  const datei = await S.bauen({ format: 1, tabellen: {} }, [bytes(1, 2, 3)], 'richtig');
  const kaputt = datei.slice(); kaputt[kaputt.length - 5] ^= 1;
  await assert.rejects(S.auspacken(kaputt, 'richtig'), e => e.code === 'schluessel');
});

test('Nicht verschlüsselt: veränderte Dateien oder abgeschnittene Datei werden erkannt', async () => {
  const datei = await S.bauen({ format: 1, tabellen: {} }, [bytes(1, 2, 3, 4)], '');
  const verdreht = datei.slice(); verdreht[verdreht.length - 1] ^= 1;
  await assert.rejects(S.auspacken(verdreht, ''), e => e.code === 'beschaedigt');
  await assert.rejects(S.auspacken(datei.slice(0, datei.length - 2), ''), e => e.code === 'beschaedigt');
  await assert.rejects(S.auspacken(datei.slice(0, 25), ''), e => e.code === 'beschaedigt');
});

test('Fremde Dateien werden abgelehnt', async () => {
  await assert.rejects(S.auspacken(new TextEncoder().encode('{"hallo": "welt"}'), ''), e => e.code === 'format');
  await assert.rejects(S.auspacken(new Uint8Array(0), ''), e => e.code === 'format');
  assert.equal(S.beginntMitKennung(new Uint8Array(5)), false);
});

test('Zwei Sicherungen derselben Daten sind verschlüsselt nicht gleich (zufälliges Salz)', async () => {
  const a = await S.bauen({ format: 1, tabellen: {} }, [], 'x12345678');
  const b = await S.bauen({ format: 1, tabellen: {} }, [], 'x12345678');
  assert.equal(gleich(a, b), false);
});

test('Größere Dateien (3 MB) laufen durch', async () => {
  const gross = new Uint8Array(3 * 1024 * 1024); for (let i = 0; i < gross.length; i += 4099) gross[i] = i % 251;
  const datei = await S.bauen({ format: 1, tabellen: {} }, [gross], 'passwort12');
  const r = await S.auspacken(datei, 'passwort12');
  assert.ok(gleich(r.dateien[0], gross));
});
