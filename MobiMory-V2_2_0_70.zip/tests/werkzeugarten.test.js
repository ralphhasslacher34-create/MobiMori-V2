'use strict';
/* Schritt 9c (2.0.35): „Wetter“ und „Karte“ sind normale Ereignisarten (keine feste Zeile im Cockpit). */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'reiseorte', 'karte', 'daten'].forEach(m => require('../js/' + m + '.js'));
const MM = globalThis.MM;
const K = MM.Karte, L = MM.Logbuch;

const JETZT = new Date(2026, 10, 4, 12, 0, 0).toISOString();
function neueDaten() {
  let t = 0;
  return new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
}
const namen = l => l.map(x => x.name);
async function art(d, n) { return (await d.ereignisartenListe()).find(x => x.aktuell.werte.bezeichnung === n); }
async function zahl(d, n) { return (await d.ereignisartenListe()).filter(x => x.aktuell.werte.bezeichnung.toLowerCase() === n.toLowerCase()).length; }

test('Die Namen: „Karte“ wird an einer Stelle festgelegt und unabhängig von Groß- und Kleinschreibung erkannt', () => {
  assert.equal(K.KARTE_ART, 'Karte');
  assert.equal(K.istKartenArt('Karte'), true);
  assert.equal(K.istKartenArt('  karte '), true);
  assert.equal(K.istKartenArt('Kartenspiel'), false);
  assert.equal(K.istKartenArt(null), false);
  assert.equal(K.istWetterArt('Karte'), false);
  assert.equal(K.istKartenArt('Wetter'), false);
});

test('Vorschläge: „Karte“ gilt für alle Fahrzeugarten', () => {
  const v = L.ZUSATZ_VORSCHLAEGE.find(x => x.bezeichnung === 'Karte');
  assert.ok(v); assert.deepEqual(v.gilt, ['alle']);
});

test('Beim ersten Öffnen des Cockpits gibt es „Wetter“ und „Karte“ genau einmal, für Land und Wasser, als Knöpfe im Standard', async () => {
  const d = neueDaten(); await d.starten();
  const wm = await d.schnellknoepfeFuerFahrzeugart('wohnmobil');
  const boot = await d.schnellknoepfeFuerFahrzeugart('segelboot-katamaran');
  [wm, boot].forEach(i => {
    assert.ok(namen(i.knoepfe).includes('Wetter') && namen(i.knoepfe).includes('Karte'));
    assert.deepEqual(namen(i.sonstige.ereignisse).filter(n => n === 'Wetter' || n === 'Karte'), []);
  });
  assert.equal(await zahl(d, 'Wetter'), 1); assert.equal(await zahl(d, 'Karte'), 1);
  await d.schnellknoepfeFuerFahrzeugart('wohnmobil');
  assert.equal(await zahl(d, 'Wetter'), 1); assert.equal(await zahl(d, 'Karte'), 1, 'auch beim zweiten Öffnen nicht doppelt');
});

test('Gibt es „Wetter“ schon (aus 2.0.34), wird nur „Karte“ ergänzt', async () => {
  const d = neueDaten(); await d.starten();
  await d.wetterArtSichern();
  assert.equal(await zahl(d, 'Wetter'), 1);
  const r = await d.werkzeugArtenEinmalSichern();
  assert.deepEqual([r.ok, r.neu], [true, 1]);
  assert.equal(await zahl(d, 'Wetter'), 1); assert.equal(await zahl(d, 'Karte'), 1);
});

test('Wer „Karte“ ausblendet, behält das so: sie kommt nicht wieder, der Knopf ist weg', async () => {
  const d = neueDaten(); await d.starten();
  await d.werkzeugArtenEinmalSichern();
  const k = await art(d, 'Karte');
  assert.equal((await d.ereignisartAendern(k.objekt.id, { bezeichnung: 'Karte', ausgeblendet: 'ja' })).ok, true);
  const i = await d.schnellknoepfeFuerFahrzeugart('wohnmobil');
  assert.ok(!namen(i.angebot.ereignisse).includes('Karte'));
  assert.ok(namen(i.knoepfe).includes('Wetter'), 'Wetter bleibt');
  assert.deepEqual([(await d.werkzeugArtenEinmalSichern()).neu, await zahl(d, 'Karte')], [0, 1], 'nichts wird neu angelegt');
});

test('Eigene Belegung bleibt unverändert: „Wetter“ und „Karte“ liegen dann unter Sonstige, bis der Nutzer sie auf einen Knopf legt', async () => {
  const d = neueDaten(); await d.starten();
  const a0 = await d.schnellknoepfeFuerFahrzeugart('wohnmobil');
  const key = n => a0.angebot.alle.find(x => x.name === n).key;
  assert.equal((await d.schnellknoepfeSetzen('wohnmobil', [key('Abfahrt'), key('Ankunft')])).ok, true);
  const i = await d.schnellknoepfeFuerFahrzeugart('wohnmobil');
  assert.deepEqual(namen(i.knoepfe), ['Abfahrt', 'Ankunft']);
  assert.ok(namen(i.sonstige.ereignisse).includes('Wetter') && namen(i.sonstige.ereignisse).includes('Karte'));
  assert.equal((await d.schnellknoepfeSetzen('wohnmobil', [key('Abfahrt'), key('Karte'), key('Wetter')])).ok, true);
  assert.deepEqual(namen((await d.schnellknoepfeFuerFahrzeugart('wohnmobil')).knoepfe), ['Abfahrt', 'Karte', 'Wetter']);
});

test('Die Vorschläge mit Zuordnung ergänzen „Karte“, auch wenn die Art schon da ist, nicht doppelt', async () => {
  const d = neueDaten(); await d.starten();
  await d.ereignisartenAusVorschlaegen();
  await d.werkzeugArtenEinmalSichern();
  await d.ereignisartenVorauswahlUebernehmen();
  assert.equal(await zahl(d, 'Karte'), 1); assert.equal(await zahl(d, 'Wetter'), 1);
});
