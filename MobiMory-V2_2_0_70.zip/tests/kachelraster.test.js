'use strict';
/* 2.0.31: Kachelseiten. Wie viele Spalten und welche Zeilenhöhe füllen den freien Platz gut? */
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/version.js');
require('../js/hilfen.js');
const R = globalThis.MM.Hilfen.kachelRaster;
const REM = 18;

test('Keine Kacheln: eine Spalte, keine Zeile', () => {
  const x = R({ breite: 800, hoehe: 600, anzahl: 0, rem: REM });
  assert.equal(x.spalten, 1);
  assert.equal(x.zeilen, 0);
});

test('Tablet quer, drei Kacheln: drei Spalten, höchstens 15 rem hoch', () => {
  const x = R({ breite: 1250, hoehe: 640, anzahl: 3, rem: REM });
  assert.equal(x.spalten, 3);
  assert.equal(x.zeilen, 1);
  assert.ok(x.hoehe <= 15 * REM, 'zu hoch: ' + x.hoehe);
});

test('Handy hochkant, drei Kacheln: eine Spalte, jede füllt ihren Teil der Höhe', () => {
  const x = R({ breite: 358, hoehe: 480, anzahl: 3, rem: REM });
  assert.equal(x.spalten, 1);
  assert.ok(x.hoehe >= 4.8 * REM && x.hoehe <= 15 * REM);
});

test('Handy hochkant, zwölf Kacheln: zwei Spalten, nie niedriger als 4,8 rem', () => {
  const x = R({ breite: 358, hoehe: 520, anzahl: 12, rem: REM });
  assert.equal(x.spalten, 2);
  assert.equal(x.zeilen, 6);
  assert.ok(x.hoehe >= Math.round(4.8 * REM));
});

test('Mehr Kacheln werden nicht größer als weniger Kacheln', () => {
  const wenig = R({ breite: 1250, hoehe: 640, anzahl: 4, rem: REM });
  const viel = R({ breite: 1250, hoehe: 640, anzahl: 12, rem: REM });
  assert.ok(viel.hoehe <= wenig.hoehe);
  assert.ok(viel.spalten >= wenig.spalten);
});

test('Spalten und Zeilen reichen immer für alle Kacheln, keine Spalte schmaler als 8,5 rem', () => {
  for (const breite of [320, 358, 600, 800, 1250, 2000]) {
    for (const hoehe of [300, 520, 640, 900]) {
      for (let n = 1; n <= 30; n++) {
        const x = R({ breite: breite, hoehe: hoehe, anzahl: n, rem: REM });
        assert.ok(x.spalten * x.zeilen >= n, `zu wenig Plätze bei ${breite}x${hoehe}, ${n} Kacheln`);
        const gap = 0.85 * REM, w = (breite - (x.spalten - 1) * gap) / x.spalten;
        assert.ok(x.spalten === 1 || w >= 8.5 * REM - 1, `Spalte zu schmal bei ${breite}x${hoehe}, ${n} Kacheln`);
        assert.ok(x.hoehe >= Math.round(4.8 * REM) && x.hoehe <= 15 * REM);
      }
    }
  }
});

test('Ohne Höhenangabe gibt es trotzdem ein brauchbares Raster', () => {
  const x = R({ breite: 800, anzahl: 5, rem: REM });
  assert.ok(x.spalten >= 1 && x.hoehe > 0);
});

test('hoechstSpalten begrenzt die Spaltenzahl (2.0.32)', () => {
  const frei = R({ breite: 1250, hoehe: 640, anzahl: 6, rem: REM });
  assert.ok(frei.spalten >= 2);
  const eng = R({ breite: 1250, hoehe: 640, anzahl: 6, rem: REM, hoechstSpalten: 2 });
  assert.ok(eng.spalten <= 2, 'zu viele Spalten: ' + eng.spalten);
  const eine = R({ breite: 1250, hoehe: 640, anzahl: 6, rem: REM, hoechstSpalten: 1 });
  assert.equal(eine.spalten, 1);
  assert.equal(eine.zeilen, 6);
});
