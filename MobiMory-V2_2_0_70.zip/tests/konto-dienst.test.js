'use strict';
/* 2.0.64 (Schritt 13a): Konto-Dienst. Anmelden mit Passwort und mit Code, Sperren, Datenraum, Löschen. */
const t = require('node:test');
/* Die Datenbank-Attrappe braucht node:sqlite (Node 22). Fehlt es, werden diese Tests übersprungen statt die Prüfung zu stören. */
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');

const APP = 'https://app.example.org';
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }

function umgebung(extra) {
  return Object.assign({ DB: neueDatenbank(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, extra || {});
}
function uhr() { const u = { t: Date.UTC(2026, 10, 10, 12, 0, 0) }; u.jetzt = () => u.t; return u; }

async function ruf(env, u, methode, weg, body, opt) {
  const d = await laden();
  const kopf = Object.assign({ Origin: APP, 'CF-Connecting-IP': '203.0.113.5' }, (opt && opt.kopf) || {});
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
  return { status: r.status, kopf: r.headers, json: await r.json() };
}
const PW = 'Sehr-sicheres-Passwort-1';

async function konto(env, u, email) {
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email, passwort: PW });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode });
  return b.json;
}

test('Gesundheit: zeigt, was eingerichtet ist, ohne Anmeldung', async () => {
  const env = umgebung(); const u = uhr();
  const r = await ruf(env, u, 'GET', '/gesundheit');
  assert.equal(r.status, 200);
  assert.deepEqual([r.json.ok, r.json.dienst, r.json.datenbank, r.json.tabellen, r.json.pepper, r.json.mail, r.json.speicher, r.json.entwicklung], [true, 'mobimory-konto', true, true, true, false, false, true]);
  const leer = await ruf({ ERLAUBTE_URSPRUENGE: APP }, u, 'GET', '/gesundheit');
  assert.equal(leer.json.datenbank, false); assert.equal(leer.json.tabellen, false); assert.equal(leer.json.pepper, false);
});

test('Fremde App-Adressen werden abgelehnt, die erlaubte bekommt die Kopfzeilen, Vorabfrage geht', async () => {
  const env = umgebung(); const u = uhr();
  const fremd = await ruf(env, u, 'GET', '/gesundheit', undefined, { kopf: { Origin: 'https://boese.example.net' } });
  assert.equal(fremd.status, 403);
  /* Die Ablehnung trägt die Kopfzeile für die fremde Adresse (2.0.65), damit die App sie von „keine Verbindung“ unterscheiden kann. Sie enthält nur den Fehlertext. */
  assert.equal(fremd.kopf.get('Access-Control-Allow-Origin'), 'https://boese.example.net');
  assert.deepEqual(Object.keys(fremd.json).sort(), ['error', 'ok']);
  const ok = await ruf(env, u, 'GET', '/gesundheit');
  assert.equal(ok.kopf.get('Access-Control-Allow-Origin'), APP);
  assert.equal(ok.kopf.get('Cache-Control'), 'no-store');
  const d = await laden();
  const pre = await d.behandeln(new Request('https://x.example/konto/anmelden', { method: 'OPTIONS', headers: { Origin: APP } }), env, { jetzt: u.jetzt });
  assert.equal(pre.status, 204); assert.match(pre.headers.get('Access-Control-Allow-Headers'), /Authorization/);
  const aus = ({ ERLAUBTE_URSPRUENGE: APP + '/' });
  const mitSchraegstrich = await ruf(Object.assign(umgebung(), aus), u, 'GET', '/gesundheit');
  assert.equal(mitSchraegstrich.status, 200, 'ein Schrägstrich am Ende der Einstellung schadet nicht');
});

test('Unbekannte Adresse: 404', async () => {
  const r = await ruf(umgebung(), uhr(), 'GET', '/gibt-es-nicht');
  assert.equal(r.status, 404);
});

test('Registrieren mit Passwort: erst der Code bestätigt, dann gibt es Sitzung, Datenraum und Anmeldung mit Passwort', async () => {
  const env = umgebung(); const u = uhr();
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email: ' Anna@Example.org ', passwort: PW });
  assert.equal(a.status, 200); assert.equal(a.json.codeGesendet, true); assert.match(a.json.entwicklungsCode, /^\d{6}$/);
  /* vor dem Bestätigen geht keine Anmeldung */
  const vor = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'anna@example.org', passwort: PW });
  assert.equal(vor.status, 401);
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'anna@example.org', code: a.json.entwicklungsCode });
  assert.equal(b.status, 200); assert.equal(b.json.email, 'anna@example.org'); assert.equal(b.json.passwortGesetzt, true);
  assert.ok(b.json.token.length >= 40); assert.ok(b.json.datenraum.id);
  const c = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'ANNA@example.org', passwort: PW });
  assert.equal(c.status, 200); assert.equal(c.json.datenraum.id, b.json.datenraum.id, 'derselbe Datenraum');
  assert.notEqual(c.json.token, b.json.token);
  const n = env.DB.roh.prepare('SELECT COUNT(*) AS n FROM datenraum').get().n;
  assert.equal(n, 1);
});

test('Nur Abdrücke in der Datenbank: kein Passwort, kein Sitzungsschlüssel, kein Code im Klartext', async () => {
  const env = umgebung(); const u = uhr();
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email: 'x@example.org', passwort: PW });
  const code = a.json.entwicklungsCode;
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'x@example.org', code });
  const alles = JSON.stringify([
    env.DB.roh.prepare('SELECT * FROM nutzer').all(), env.DB.roh.prepare('SELECT * FROM sitzung').all(),
    env.DB.roh.prepare('SELECT * FROM drossel').all()]);
  assert.ok(!alles.includes(PW)); assert.ok(!alles.includes(b.json.token));
  assert.ok(!alles.includes('x@example.org') || JSON.stringify(env.DB.roh.prepare('SELECT * FROM drossel').all()).indexOf('x@example.org') < 0, 'die Bremse speichert keine Adresse');
  const nutzer = env.DB.roh.prepare('SELECT passwort_hash FROM nutzer').get();
  assert.match(nutzer.passwort_hash, /^pbkdf2-sha256-hmac\$100000\$/);
  const a2 = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'x@example.org' });
  const roh = JSON.stringify(env.DB.roh.prepare('SELECT * FROM code').all());
  assert.ok(!roh.includes(a2.json.entwicklungsCode));
});

test('Falsches Passwort und unbekannte Adresse: dieselbe Antwort', async () => {
  const env = umgebung(); const u = uhr();
  await konto(env, u, 'anna@example.org');
  const falsch = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'anna@example.org', passwort: 'falsches-Passwort-1' });
  const fremd = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'niemand@example.org', passwort: 'falsches-Passwort-1' });
  assert.equal(falsch.status, 401); assert.equal(fremd.status, 401);
  assert.equal(falsch.json.error, fremd.json.error);
});

test('Passwort-Regeln und E-Mail-Prüfung', async () => {
  const env = umgebung(); const u = uhr();
  const kurz = await ruf(env, u, 'POST', '/konto/registrieren', { email: 'a@example.org', passwort: 'kurz' });
  assert.equal(kurz.status, 400); assert.equal(kurz.json.feld, 'passwort');
  const lang = await ruf(env, u, 'POST', '/konto/registrieren', { email: 'a@example.org', passwort: 'a'.repeat(201) });
  assert.equal(lang.status, 400);
  const mail = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'keine-adresse' });
  assert.equal(mail.status, 400); assert.equal(mail.json.feld, 'email');
  const kein = await ruf(env, u, 'POST', '/konto/code-anfordern', 'text');
  assert.equal(kein.status, 400);
});

test('Anmelden nur mit Code: legt bei der ersten Anmeldung das Konto an, ohne Passwort', async () => {
  const env = umgebung(); const u = uhr();
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'neu@example.org' });
  assert.equal(a.status, 200);
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'neu@example.org', code: a.json.entwicklungsCode, geraet: 'Tablet' });
  assert.equal(b.status, 200); assert.equal(b.json.passwortGesetzt, false);
  const mitPw = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'neu@example.org', passwort: PW });
  assert.equal(mitPw.status, 401, 'ohne Passwort keine Anmeldung mit Passwort');
  const s = env.DB.roh.prepare('SELECT geraet FROM sitzung').get();
  assert.equal(s.geraet, 'Tablet');
});

test('Code: gilt einmal, läuft nach 10 Minuten ab, fünf falsche Eingaben sperren ihn, ein neuer macht den alten ungültig', async () => {
  const env = umgebung(); const u = uhr();
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'c@example.org' });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'c@example.org', code: a.json.entwicklungsCode });
  assert.equal(b.status, 200);
  const nochmal = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'c@example.org', code: a.json.entwicklungsCode });
  assert.equal(nochmal.status, 400, 'ein Code gilt nur einmal');

  const a2 = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'c@example.org' });
  u.t += 10 * 60 * 1000 + 1;
  const spaet = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'c@example.org', code: a2.json.entwicklungsCode });
  assert.equal(spaet.status, 400, 'nach 10 Minuten abgelaufen');

  const a3 = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'c@example.org' });
  const falschCode = a3.json.entwicklungsCode === '000000' ? '111111' : '000000';
  for (let i = 0; i < 5; i++) assert.equal((await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'c@example.org', code: falschCode })).status, 400);
  const gesperrt = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'c@example.org', code: a3.json.entwicklungsCode });
  assert.equal(gesperrt.status, 400, 'nach fünf falschen Eingaben hilft auch der richtige Code nicht mehr');

  const a4 = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'c@example.org' });
  const a5 = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'c@example.org' });
  if (a4.json.entwicklungsCode !== a5.json.entwicklungsCode) {
    assert.equal((await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'c@example.org', code: a4.json.entwicklungsCode })).status, 400, 'der ältere Code ist ungültig');
  }
  assert.equal((await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'c@example.org', code: a5.json.entwicklungsCode })).status, 200);
});

test('Ein fremder Code für eine vorgemerkte Registrierung kann kein Passwort unterschieben', async () => {
  const env = umgebung(); const u = uhr();
  /* Jemand trägt die Adresse des Opfers mit seinem Passwort ein, der Code geht ans Opfer */
  await ruf(env, u, 'POST', '/konto/registrieren', { email: 'opfer@example.org', passwort: 'Passwort-des-Angreifers-1' });
  /* Das Opfer fordert selbst einen Code zum Anmelden an und bestätigt ihn */
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'opfer@example.org' });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'opfer@example.org', code: a.json.entwicklungsCode });
  assert.equal(b.status, 200); assert.equal(b.json.passwortGesetzt, false, 'das vorgemerkte Passwort ist verworfen');
  const an = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'opfer@example.org', passwort: 'Passwort-des-Angreifers-1' });
  assert.equal(an.status, 401);
});

test('Registrieren für eine schon bestätigte Adresse: gleiche Antwort, das alte Passwort bleibt, es kommt ein Anmelde-Code', async () => {
  const env = umgebung(); const u = uhr();
  await konto(env, u, 'anna@example.org');
  const r = await ruf(env, u, 'POST', '/konto/registrieren', { email: 'anna@example.org', passwort: 'Neues-Passwort-des-Fremden-1' });
  assert.equal(r.status, 200); assert.equal(r.json.codeGesendet, true);
  const alt = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'anna@example.org', passwort: PW });
  assert.equal(alt.status, 200, 'das bisherige Passwort gilt weiter');
  const neu = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'anna@example.org', passwort: 'Neues-Passwort-des-Fremden-1' });
  assert.equal(neu.status, 401);
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'anna@example.org', code: r.json.entwicklungsCode });
  assert.equal(b.status, 200); assert.equal(b.json.passwortGesetzt, true, 'ein Anmelde-Code ändert das Passwort nicht');
});

test('Bremse: zehn falsche Anmeldungen je Adresse, danach 429, nach 15 Minuten wieder frei', async () => {
  const env = umgebung(); const u = uhr();
  await konto(env, u, 'anna@example.org');
  let letzte;
  for (let i = 0; i < 10; i++) letzte = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'anna@example.org', passwort: 'falsch-falsch-1' }, { kopf: { 'CF-Connecting-IP': '198.51.100.' + i } });
  assert.equal(letzte.status, 401);
  const gesperrt = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'anna@example.org', passwort: PW });
  assert.equal(gesperrt.status, 429); assert.ok(gesperrt.json.wartenSekunden > 0);
  u.t += 15 * 60 * 1000 + 1000;
  const frei = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'anna@example.org', passwort: PW });
  assert.equal(frei.status, 200);
});

test('Bremse: höchstens fünf Codes je Adresse und Stunde', async () => {
  const env = umgebung(); const u = uhr();
  for (let i = 0; i < 5; i++) assert.equal((await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'v@example.org' })).status, 200);
  assert.equal((await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'v@example.org' })).status, 429);
  assert.equal((await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'andere@example.org' })).status, 200, 'andere Adressen sind nicht betroffen');
});

test('Sitzung: „ich“ zeigt Adresse und Datenraum, falscher und fehlender Schlüssel gehen nicht, nach 90 Tagen vorbei', async () => {
  const env = umgebung(); const u = uhr();
  const k = await konto(env, u, 'anna@example.org');
  const ich = await ruf(env, u, 'GET', '/konto/ich', undefined, { kopf: { Authorization: 'Bearer ' + k.token } });
  assert.equal(ich.status, 200); assert.equal(ich.json.email, 'anna@example.org'); assert.equal(ich.json.datenraum.id, k.datenraum.id);
  assert.equal((await ruf(env, u, 'GET', '/konto/ich')).status, 401);
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, { kopf: { Authorization: 'Bearer ' + 'x'.repeat(43) } })).status, 401);
  u.t += 91 * 24 * 3600 * 1000;
  const alt = await ruf(env, u, 'GET', '/konto/ich', undefined, { kopf: { Authorization: 'Bearer ' + k.token } });
  assert.equal(alt.status, 401);
});

test('Sitzung wird verlängert, wenn weniger als 30 Tage bleiben', async () => {
  const env = umgebung(); const u = uhr();
  const k = await konto(env, u, 'anna@example.org');
  u.t += 70 * 24 * 3600 * 1000;
  const r = await ruf(env, u, 'GET', '/konto/ich', undefined, { kopf: { Authorization: 'Bearer ' + k.token } });
  assert.equal(r.status, 200);
  assert.ok(r.json.laeuftAb >= u.t + 89 * 24 * 3600 * 1000);
});

test('Abmelden beendet nur diese Sitzung', async () => {
  const env = umgebung(); const u = uhr();
  const k = await konto(env, u, 'anna@example.org');
  const zweite = await ruf(env, u, 'POST', '/konto/anmelden', { email: 'anna@example.org', passwort: PW });
  const ab = await ruf(env, u, 'POST', '/konto/abmelden', undefined, { kopf: { Authorization: 'Bearer ' + k.token } });
  assert.equal(ab.status, 200);
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, { kopf: { Authorization: 'Bearer ' + k.token } })).status, 401);
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, { kopf: { Authorization: 'Bearer ' + zweite.json.token } })).status, 200);
});

test('Passwort setzen: auch für ein Konto ohne Passwort, danach geht die Anmeldung mit Passwort, andere Sitzungen enden', async () => {
  const env = umgebung(); const u = uhr();
  const a = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'neu@example.org' });
  const k = (await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'neu@example.org', code: a.json.entwicklungsCode })).json;
  const a2 = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'neu@example.org' });
  const andere = (await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'neu@example.org', code: a2.json.entwicklungsCode })).json;
  const kurz = await ruf(env, u, 'POST', '/konto/passwort-setzen', { passwort: 'kurz' }, { kopf: { Authorization: 'Bearer ' + k.token } });
  assert.equal(kurz.status, 400);
  const ok = await ruf(env, u, 'POST', '/konto/passwort-setzen', { passwort: PW }, { kopf: { Authorization: 'Bearer ' + k.token } });
  assert.equal(ok.status, 200);
  assert.equal((await ruf(env, u, 'POST', '/konto/anmelden', { email: 'neu@example.org', passwort: PW })).status, 200);
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, { kopf: { Authorization: 'Bearer ' + andere.token } })).status, 401, 'die andere Sitzung ist beendet');
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, { kopf: { Authorization: 'Bearer ' + k.token } })).status, 200, 'diese bleibt');
  assert.equal((await ruf(env, u, 'POST', '/konto/passwort-setzen', { passwort: PW })).status, 401, 'ohne Anmeldung geht es nicht');
});

test('Konto löschen: nur mit dem Wort LÖSCHEN, danach sind Konto, Datenraum und Sitzungen weg', async () => {
  const env = umgebung(); const u = uhr();
  const k = await konto(env, u, 'anna@example.org');
  const kopf = { kopf: { Authorization: 'Bearer ' + k.token } };
  assert.equal((await ruf(env, u, 'POST', '/konto/loeschen', {}, kopf)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/konto/loeschen', { bestaetigung: 'loeschen' }, kopf)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/konto/loeschen', { bestaetigung: 'LÖSCHEN' }, kopf)).status, 200);
  const z = (t) => env.DB.roh.prepare('SELECT COUNT(*) AS n FROM ' + t).get().n;
  assert.deepEqual([z('nutzer'), z('datenraum'), z('sitzung')], [0, 0, 0]);
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, kopf)).status, 401);
});

test('Zwei Konten haben getrennte Datenräume', async () => {
  const env = umgebung(); const u = uhr();
  const a = await konto(env, u, 'a@example.org'), b = await konto(env, u, 'b@example.org');
  assert.notEqual(a.datenraum.id, b.datenraum.id);
});

test('Ohne E-Mail-Versand und ohne Entwicklungsmodus: 503, der Code bleibt nicht liegen', async () => {
  const env = umgebung({ ENTWICKLUNG: undefined }); const u = uhr();
  const r = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'a@example.org' });
  assert.equal(r.status, 503); assert.ok(!('entwicklungsCode' in r.json));
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM code').get().n, 0);
});

test('Mit E-Mail-Versand: die E-Mail geht an die Adresse, enthält den Code, die Antwort verrät ihn nicht', async () => {
  const gesendet = [];
  const env = umgebung({ ENTWICKLUNG: undefined, ABSENDER: 'konto@example.org', EMAIL: { send: async (m) => { gesendet.push(m); return {}; } } });
  const u = uhr();
  const r = await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'Anna@Example.org' });
  assert.equal(r.status, 200); assert.ok(!('entwicklungsCode' in r.json));
  assert.equal(gesendet.length, 1); assert.equal(gesendet[0].to, 'anna@example.org'); assert.equal(gesendet[0].from, 'konto@example.org');
  const code = /(\d{6})/.exec(gesendet[0].text)[1];
  assert.ok(gesendet[0].html && gesendet[0].html.includes(code));
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email: 'anna@example.org', code });
  assert.equal(b.status, 200);
});

test('Wenn der Versand scheitert: 502 und der Code wird nicht aufbewahrt', async () => {
  const env = umgebung({ ENTWICKLUNG: undefined, ABSENDER: 'konto@example.org', EMAIL: { send: async () => { throw new Error('kaputt'); } } });
  const r = await ruf(env, uhr(), 'POST', '/konto/code-anfordern', { email: 'a@example.org' });
  assert.equal(r.status, 502);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM code').get().n, 0);
});

test('Ohne Geheimnis PASSWORT_PEPPER oder ohne Datenbank: 503 mit Hinweis', async () => {
  const u = uhr();
  const a = await ruf(umgebung({ PASSWORT_PEPPER: 'zu-kurz' }), u, 'POST', '/konto/code-anfordern', { email: 'a@example.org' });
  assert.equal(a.status, 503); assert.match(a.json.error, /PASSWORT_PEPPER/);
  const b = await ruf({ ERLAUBTE_URSPRUENGE: APP }, u, 'POST', '/konto/code-anfordern', { email: 'a@example.org' });
  assert.equal(b.status, 503); assert.match(b.json.error, /Datenbank/);
});

test('Nie bestätigte Adressen verschwinden nach sieben Tagen, abgelaufene Sitzungen und Codes ebenfalls', async () => {
  const env = umgebung(); const u = uhr();
  await ruf(env, u, 'POST', '/konto/registrieren', { email: 'nie@example.org', passwort: PW });
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM nutzer').get().n, 1);
  u.t += 8 * 24 * 3600 * 1000;
  await ruf(env, u, 'POST', '/konto/code-anfordern', { email: 'x@example.org' });
  assert.equal(env.DB.roh.prepare("SELECT COUNT(*) AS n FROM nutzer WHERE email = 'nie@example.org'").get().n, 0);
});

test('Passwort-Abdruck: richtige und falsche Eingabe, kaputter Abdruck, Abdruck mit weniger Runden gilt als veraltet und wird beim Anmelden erneuert', async () => {
  const d = await laden(); const g = 'g'.repeat(40);
  const h = await d.passwortHashen('Ein-gutes-Passwort', g);
  assert.deepEqual(await d.passwortPruefen('Ein-gutes-Passwort', h, g), { ok: true, veraltet: false });
  assert.equal((await d.passwortPruefen('Ein-schlechtes', h, g)).ok, false);
  assert.equal((await d.passwortPruefen('Ein-gutes-Passwort', h, 'h'.repeat(40))).ok, false, 'anderes Geheimnis, anderer Abdruck');
  assert.equal((await d.passwortPruefen('x', 'quatsch', g)).ok, false);
  assert.equal((await d.passwortPruefen('x', 'pbkdf2-sha256-hmac$999999999$AA$AA', g)).ok, false);

  const env = umgebung(); const u = uhr();
  await konto(env, u, 'anna@example.org');
  const teile = env.DB.roh.prepare('SELECT passwort_hash FROM nutzer').get().passwort_hash.split('$');
  const salt = Uint8Array.from(Buffer.from(teile[2], 'base64url'));
  /* Abdruck mit 50 000 Runden von Hand bauen */
  const hm = await crypto.subtle.importKey('raw', new TextEncoder().encode('p'.repeat(40)), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const vor = new Uint8Array(await crypto.subtle.sign('HMAC', hm, new TextEncoder().encode(PW)));
  const pk = await crypto.subtle.importKey('raw', vor, 'PBKDF2', false, ['deriveBits']);
  const bits = Buffer.from(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 50000 }, pk, 256)).toString('base64url');
  env.DB.roh.prepare('UPDATE nutzer SET passwort_hash = ?').run('pbkdf2-sha256-hmac$50000$' + teile[2] + '$' + bits);
  assert.equal((await ruf(env, u, 'POST', '/konto/anmelden', { email: 'anna@example.org', passwort: PW })).status, 200);
  assert.match(env.DB.roh.prepare('SELECT passwort_hash FROM nutzer').get().passwort_hash, /^pbkdf2-sha256-hmac\$100000\$/);
});
