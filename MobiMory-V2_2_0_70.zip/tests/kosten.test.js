'use strict';
/* 2.0.27, Schritt 8: Kosten – Beschreibung und Rechnung (ohne Speicher). */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/hilfen.js');
require('../js/kosten.js');
const MM = globalThis.MM;
const K = MM.Kosten;
const HEUTE = '2026-11-04';

/* ---------- Beschreibung ---------- */
test('Drei Gruppen zum Eintragen, der Wertverlust ist eine vierte, die die App rechnet', () => {
  assert.deepEqual(K.GRUPPEN.map(g => g.wert), ['fix', 'variabel', 'instandhaltung']);
  assert.equal(K.WERTVERLUST.wert, 'wertverlust');
  assert.ok(!K.GRUPPEN.some(g => g.wert === 'wertverlust'), 'Wertverlust wird nicht eingetragen');
  K.GRUPPEN.forEach(g => assert.ok(K.kostenartenFuer(g.wert).length >= 3, g.wert));
});

test('Kostenarten gehören je zu einer Gruppe, die Festlegungen aus den Gesprächen sind dabei', () => {
  const fix = K.kostenartenFuer('fix').map(a => a.wert), var_ = K.kostenartenFuer('variabel').map(a => a.wert), inst = K.kostenartenFuer('instandhaltung').map(a => a.wert);
  ['stellplatz', 'pruefung', 'versicherung'].forEach(w => assert.ok(fix.includes(w), w));
  assert.ok(var_.includes('unterwegs'), 'Liegeplätze und Parkplätze auf Reisen sind variabel');
  ['teile', 'arbeit', 'fremd'].forEach(w => assert.ok(inst.includes(w), w));
  const alle = K.KOSTENARTEN.map(a => a.wert);
  assert.equal(new Set(alle).size, alle.length, 'jede Kostenart hat eine eigene Kennung');
});

test('Felder: nur Fixkosten haben Rhythmus und Ende, die Kostenart passt zur Gruppe', () => {
  const keys = g => K.felder(g).map(f => f.key);
  assert.deepEqual(keys('fix'), ['kostenart', 'betrag', 'rhythmus', 'datum', 'bis', 'grundlage', 'notiz']);
  assert.deepEqual(keys('variabel'), ['kostenart', 'betrag', 'datum', 'grundlage', 'notiz']);
  assert.deepEqual(keys('instandhaltung'), ['kostenart', 'betrag', 'datum', 'grundlage', 'notiz']);
  const art = K.felder('variabel')[0].optionen.map(o => o.wert);
  assert.ok(art.includes('treibstoff') && !art.includes('versicherung'));
});

test('Rhythmen: einmalig und wiederkehrend, Monate je Rhythmus', () => {
  assert.equal(K.monateVon('einmalig'), 0);
  assert.equal(K.monateVon('monatlich'), 1);
  assert.equal(K.monateVon('jaehrlich'), 12);
  assert.equal(K.monateVon('zweijaehrlich'), 24);
  assert.equal(K.monateVon('gibt-es-nicht'), 0);
});

test('Euro wird deutsch angezeigt, Felder mit Einheit € zeigen den Betrag in Euro', () => {
  assert.equal(MM.Hilfen.euro(1234.5), '1.234,50 €');
  assert.equal(MM.Hilfen.euro(0), '0,00 €');
  assert.equal(MM.Hilfen.wert({ typ: 'zahl', einheit: '€' }, 99), '99,00 €');
  assert.equal(MM.Hilfen.wert({ typ: 'zahl', einheit: '%' }, 2.5), '2,5 %');
});

/* ---------- Anteil am Jahr ---------- */
test('Einmalig: zählt im Jahr des Datums, bisher bis heute, der Rest ist Vorschau', () => {
  const w = { betrag: 80, rhythmus: 'einmalig', datum: '2026-05-01' };
  assert.deepEqual(K.imJahr(w, 2026, HEUTE), { summe: 80, bisher: 80, noch: 0, monate: 0 });
  assert.equal(K.imJahr(w, 2025, HEUTE).summe, 0);
  assert.equal(K.imJahr(w, 2027, HEUTE).summe, 0);
  const geplant = { betrag: 500, rhythmus: 'einmalig', datum: '2026-12-15' };
  assert.deepEqual(K.imJahr(geplant, 2026, HEUTE), { summe: 500, bisher: 0, noch: 500, monate: 0 });
});

test('Monatlich: für jeden ganzen Monat, in dem der Betrag gilt (ab dem Monat des Datums)', () => {
  const w = { betrag: 100, rhythmus: 'monatlich', datum: '2026-03-15' };
  assert.deepEqual(K.imJahr(w, 2026, HEUTE), { summe: 1000, bisher: 900, noch: 100, monate: 10 });
  assert.equal(K.imJahr(w, 2025, HEUTE).summe, 0, 'vor dem Beginn zählt nichts');
  assert.equal(K.imJahr(w, 2027, HEUTE).summe, 1200, 'ohne Ende läuft er weiter, das ganze nächste Jahr ist Vorschau');
  assert.equal(K.imJahr(w, 2027, HEUTE).bisher, 0);
});

test('Jährlich und alle zwei Jahre: Betrag geteilt durch die Monate des Rhythmus, anteilig verteilt', () => {
  const j = { betrag: 600, rhythmus: 'jaehrlich', datum: '2024-05-01' };
  assert.equal(K.imJahr(j, 2026, HEUTE).summe, 600);
  assert.equal(K.imJahr(j, 2023, HEUTE).summe, 0);
  assert.equal(K.imJahr(Object.assign({}, j, { bis: '2026-06-30' }), 2026, HEUTE).summe, 300, 'Ende im Juni: Januar bis Juni');
  const zwei = { betrag: 240, rhythmus: 'zweijaehrlich', datum: '2025-01-01' };
  assert.equal(K.imJahr(zwei, 2026, HEUTE).summe, 120, 'HU alle 2 Jahre: halber Betrag pro Jahr');
  const v = { betrag: 90, rhythmus: 'vierteljaehrlich', datum: '2026-01-01' };
  assert.equal(K.imJahr(v, 2026, HEUTE).summe, 360);
});

test('Ungültiges ergibt null und stürzt nicht ab', () => {
  assert.equal(K.imJahr(null, 2026, HEUTE).summe, 0);
  assert.equal(K.imJahr({ betrag: 'x', datum: '2026-01-01' }, 2026, HEUTE).summe, 0);
  assert.equal(K.imJahr({ betrag: 10 }, 2026, HEUTE).summe, 0);
  assert.equal(K.imJahr({ betrag: -5, rhythmus: 'einmalig', datum: '2026-01-01' }, 2026, HEUTE).summe, 0);
});

test('Summe der einmaligen Posten, wiederkehrende werden nur gezählt', () => {
  assert.deepEqual(K.summeEinmalig([{ betrag: 10.5, rhythmus: 'einmalig' }, { betrag: 20 }, { betrag: 5, rhythmus: 'monatlich' }]), { summe: 30.5, wiederkehrend: 1 });
  assert.deepEqual(K.summeEinmalig([]), { summe: 0, wiederkehrend: 0 });
});

/* ---------- Grundlage ---------- */
test('Grundlage: eingegeben, geschätzt oder gemischt', () => {
  assert.equal(K.grundlageVon([]), null);
  assert.equal(K.grundlageVon(['eingegeben', 'eingegeben']), 'eingegeben');
  assert.equal(K.grundlageVon(['geschaetzt']), 'geschaetzt');
  assert.equal(K.grundlageVon(['eingegeben', 'geschaetzt']), 'gemischt');
});

/* ---------- Wertverlust ---------- */
test('Wertverlust: Wert mal Prozent pro Jahr, ohne Angabe keine Wertveränderung', () => {
  const s = { fahrzeugwert: 50000, wertverlustProzent: 2, wertDatum: '2026-01-01' };
  const w = K.wertverlust(s, 2026, HEUTE);
  assert.equal(w.summe, 1000);
  assert.equal(w.grundlage, 'gerechnet');
  assert.equal(w.angegeben, true);
  assert.equal(w.bisher, 916.67, 'November: 11 von 12 Monaten');
  assert.equal(w.noch, 83.33);
  assert.equal(K.wertverlust(s, 2025, HEUTE).summe, 0, 'vor dem eingetragenen Wert wird nichts gerechnet');
  assert.equal(K.wertverlust(s, 2027, HEUTE).bisher, 0);
  assert.equal(K.wertverlust(null, 2026, HEUTE).summe, 0);
  assert.equal(K.wertverlust({ fahrzeugwert: 50000 }, 2026, HEUTE).summe, 0, 'Wert ohne Prozentsatz: keine Wertveränderung');
  assert.equal(K.wertverlust({ fahrzeugwert: 50000, wertverlustProzent: 0 }, 2026, HEUTE).angegeben, false);
  assert.equal(K.wertverlust({ wertverlustProzent: 3 }, 2026, HEUTE).summe, 0, 'Prozentsatz ohne Wert');
});

test('Wertfrage: der Wert ist älter als ein Jahr', () => {
  assert.equal(K.wertFrage({ fahrzeugwert: 5000, wertDatum: '2025-10-01' }, HEUTE), true);
  assert.equal(K.wertFrage({ fahrzeugwert: 5000, wertDatum: '2026-01-01' }, HEUTE), false);
  assert.equal(K.wertFrage({ fahrzeugwert: 5000, wertDatum: '2025-11-04' }, HEUTE), false, 'genau ein Jahr ist noch nicht älter');
  assert.equal(K.wertFrage({ wertDatum: '2020-01-01' }, HEUTE), false, 'ohne Wert keine Frage');
  assert.equal(K.wertFrage(null, HEUTE), false);
});

/* ---------- Nutzungstage und Kilometer ---------- */
test('Nutzungstage: jeder Tag nur einmal, auf das Jahr beschnitten, bis heute genutzt und danach geplant', () => {
  const a = [{ vonDatum: '2026-07-01', bisDatum: '2026-07-10' }, { vonDatum: '2026-07-08', bisDatum: '2026-07-12' }];
  assert.deepEqual(K.nutzungstage(a, 2026, HEUTE), { genutzt: 12, geplant: 0 });
  assert.deepEqual(K.nutzungstage([{ vonDatum: '2025-12-30', bisDatum: '2026-01-02' }], 2026, HEUTE), { genutzt: 2, geplant: 0 });
  assert.deepEqual(K.nutzungstage([{ vonDatum: '2026-11-03', bisDatum: '2026-11-06' }], 2026, HEUTE), { genutzt: 2, geplant: 2 }, '3. und 4. November sind genutzt, 5. und 6. geplant');
  assert.deepEqual(K.nutzungstage([{ vonDatum: '2026-12-01', bisDatum: '2026-12-03' }], 2027, HEUTE), { genutzt: 0, geplant: 0 });
  assert.deepEqual(K.nutzungstage([], 2026, HEUTE), { genutzt: 0, geplant: 0 });
});

test('Kilometer im Jahr: Stand am Ende minus Stand vor dem Jahresbeginn', () => {
  const st = [{ datum: '2025-12-20', wert: 1000 }, { datum: '2026-05-01', wert: 2200 }, { datum: '2026-10-01', wert: 3000 }];
  assert.deepEqual(K.kilometerImJahr(st, 2026, HEUTE), { km: 2000, ab: '2025-12-20', bis: '2026-10-01', ohneAnfang: false });
  const ohne = K.kilometerImJahr([{ datum: '2026-05-01', wert: 2200 }, { datum: '2026-10-01', wert: 3000 }], 2026, HEUTE);
  assert.equal(ohne.km, 800); assert.equal(ohne.ohneAnfang, true);
  assert.equal(K.kilometerImJahr([{ datum: '2026-05-01', wert: 2200 }], 2026, HEUTE), null, 'ein einziger Stand reicht nicht');
  assert.equal(K.kilometerImJahr([], 2026, HEUTE), null);
  assert.equal(K.kilometerImJahr(st, 2024, HEUTE), null);
  assert.equal(K.kilometerImJahr([{ datum: '2026-12-20', wert: 9000 }, { datum: '2025-12-20', wert: 1000 }], 2026, HEUTE), null, 'Stände nach heute zählen nicht');
});

/* ---------- Auswertung ---------- */
function beispiel() {
  return {
    jahr: 2026, heute: HEUTE,
    eintraege: [
      { werte: { gruppe: 'fix', betrag: 100, rhythmus: 'monatlich', datum: '2026-01-01', grundlage: 'eingegeben' } },
      { werte: { gruppe: 'variabel', betrag: 300, rhythmus: 'einmalig', datum: '2026-07-10', grundlage: 'eingegeben' } },
      { werte: { gruppe: 'instandhaltung', betrag: 500, rhythmus: 'einmalig', datum: '2026-09-01', grundlage: 'eingegeben' } }
    ],
    stamm: { fahrzeugwert: 10000, wertDatum: '2026-01-01', wertverlustProzent: 2, vergleichPreisTag: 100, vergleichGrundlage: 'geschaetzt', vergleichBezeichnung: 'Wohnmobil für vier' },
    aktivitaeten: [{ vonDatum: '2026-07-01', bisDatum: '2026-07-10' }],
    staende: [{ datum: '2025-12-31', wert: 1000 }, { datum: '2026-10-01', wert: 3000 }]
  };
}

test('Auswertung: Gruppen, Wertverlust, Gesamtsumme, pro Monat, pro Tag, pro Kilometer', () => {
  const a = K.auswertung(beispiel());
  assert.deepEqual([a.gruppen.fix.summe, a.gruppen.fix.bisher, a.gruppen.fix.noch], [1200, 1100, 100]);
  assert.equal(a.gruppen.variabel.summe, 300);
  assert.equal(a.gruppen.instandhaltung.summe, 500);
  assert.equal(a.wertverlust.summe, 200);
  assert.equal(a.gesamt.summe, 2200);
  assert.equal(a.gesamt.bisher, 2083.33);
  assert.equal(a.gesamt.noch, 116.67);
  assert.equal(a.gesamtGrundlage, 'gerechnet');
  assert.equal(a.proJahr, 2200);
  assert.equal(a.proMonat, 183.33);
  assert.equal(a.nutzung.genutzt, 10);
  assert.equal(a.proTag, 208.33, 'Kosten bis heute durch genutzte Tage');
  assert.equal(a.km.km, 2000);
  assert.equal(a.proKm, 1.04);
  assert.equal(a.wertFrage, false);
});

test('Auswertung: Vergleich mit Mieten rechnet mit den genutzten Tagen und nennt, ab wann das eigene Fahrzeug günstiger ist', () => {
  const v = K.auswertung(beispiel()).vergleich;
  assert.equal(v.preisTag, 100);
  assert.equal(v.grundlage, 'geschaetzt');
  assert.equal(v.bezeichnung, 'Wohnmobil für vier');
  assert.equal(v.tage, 10);
  assert.equal(v.miete, 1000);
  assert.equal(v.eigen, 2083.33);
  assert.equal(v.differenz, 1083.33, 'positiv: das eigene Fahrzeug war teurer');
  assert.equal(v.guenstigerAbTage, 22, 'Jahressumme 2200 durch 100 Euro pro Tag');
});

test('Auswertung: Grundlage der Gruppe wird gemischt, sobald ein Betrag geschätzt ist', () => {
  const p = beispiel();
  p.eintraege.push({ werte: { gruppe: 'variabel', betrag: 50, rhythmus: 'einmalig', datum: '2026-08-01', grundlage: 'geschaetzt' } });
  const a = K.auswertung(p);
  assert.equal(a.gruppen.variabel.grundlage, 'gemischt');
  assert.equal(a.gruppen.fix.grundlage, 'eingegeben');
  assert.equal(a.gruppen.variabel.anzahl, 2);
});

test('Auswertung ohne Angaben: alles null, keine Teilung durch null, kein Vergleich', () => {
  const a = K.auswertung({ jahr: 2026, heute: HEUTE, eintraege: [], stamm: null, aktivitaeten: [], staende: [] });
  assert.equal(a.gesamt.summe, 0);
  assert.equal(a.gesamtGrundlage, null);
  assert.equal(a.proMonat, 0);
  assert.equal(a.proTag, null);
  assert.equal(a.proKm, null);
  assert.equal(a.vergleich, null);
  assert.equal(a.wertverlust.summe, 0, 'ohne Angabe keine Wertveränderung');
  ['fix', 'variabel', 'instandhaltung'].forEach(g => assert.equal(a.gruppen[g].grundlage, null));
});

test('Auswertung: ohne genutzte Tage kein Preis pro Tag, aber Vergleichswert „ab wie vielen Tagen“ bleibt', () => {
  const p = beispiel(); p.aktivitaeten = [];
  const a = K.auswertung(p);
  assert.equal(a.proTag, null);
  assert.equal(a.vergleich.tage, 0);
  assert.equal(a.vergleich.miete, 0);
  assert.equal(a.vergleich.guenstigerAbTage, 22);
});

test('Auswertung: ein Jahr in der Vorschau zählt nur Vorschau, nichts bis heute', () => {
  const p = beispiel(); p.jahr = 2027;
  const a = K.auswertung(p);
  assert.equal(a.gruppen.fix.summe, 1200);
  assert.equal(a.gruppen.fix.bisher, 0);
  assert.equal(a.gesamt.bisher, 0);
  assert.equal(a.gruppen.variabel.summe, 0, 'einmalige Beträge von 2026 gehören nicht zu 2027');
});
