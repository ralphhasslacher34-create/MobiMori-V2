'use strict';
/* Etappen (2.0.43): Regeln ohne Speicher und Netz. */
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/routen.js');
require('../js/etappen.js');
const E = globalThis.MM.Etappen;
const S = { name: 'A', breite: 48.0, laenge: 8.0 }, Z = { name: 'B', breite: 48.4, laenge: 8.0 };
const ROUTE = [{ breite: 47.0, laenge: 8.0, km: 0 }, { breite: 48.0, laenge: 8.0, km: 111 }, { breite: 48.4, laenge: 8.0, km: 155.4 }, { breite: 49.0, laenge: 8.0, km: 222 }];

test('Strecke: auf der Route, sonst Luftlinie, ohne Position unklar', () => {
  const r = E.strecke(ROUTE, S, Z);
  assert.equal(r.art, 'route'); assert.ok(Math.abs(r.km - 44.4) < 0.3);
  assert.equal(E.strecke(null, S, Z).art, 'luftlinie');
  assert.equal(E.strecke(ROUTE, S, { name: 'weit', breite: 48.2, laenge: 9.5 }).art, 'luftlinie');
  assert.equal(E.strecke(ROUTE, S, { name: 'x' }), null);
});
test('Wetterpunkte nur zwischen den zwei Orten, Abstandsregel gilt', () => {
  const p = E.wetterMesspunkte(S, Z, 40, 'kmh', { art: 'strecke', abstand: 10, einheit: 'km' });
  assert.equal(p[0].name, 'A'); assert.equal(p[p.length - 1].name, 'B'); assert.ok(p.length >= 4 && p.length <= 6);
  assert.deepEqual(E.wetterMesspunkte(S, { name: 'x' }, 40, 'kmh', null), []);
  assert.deepEqual(E.wetterMesspunkte(S, Z, null, 'kmh', null), []);
});
test('Tagesplan: nennt, was fehlt', () => {
  const p = { datum: '2026-11-05', beginnZeit: '08:00', endeZeit: '10:00', start: S, ziel: Z, routePunkte: null, routeKmh: null };
  const ok = E.tagesPlan(p); assert.equal(ok.grund, null); assert.ok(ok.kmh > 20 && ok.kmh < 25); assert.equal(ok.herkunft, 'zeiten');
  assert.equal(E.tagesPlan(Object.assign({}, p, { routeKmh: 50 })).herkunft, 'route');
  assert.match(E.tagesPlan(Object.assign({}, p, { start: null })).grund, /Start- und Zielort/);
  assert.match(E.tagesPlan(Object.assign({}, p, { beginnZeit: '' })).grund, /Beginns/);
  assert.match(E.tagesPlan(Object.assign({}, p, { endeZeit: '' })).grund, /Geschwindigkeit/);
});
test('Kosten an Tage: ausdrücklich vor Datum, doppeltes Datum bleibt ohne Tag', () => {
  const tage = [{ id: 't1', datum: '2026-11-05' }, { id: 't2', datum: '2026-11-06' }, { id: 't3', datum: '2026-11-06' }];
  const k = (w) => ({ werte: w });
  const r = E.kostenAnTage([k({ betrag: 10, datum: '2026-11-05' }), k({ betrag: 5, datum: '2026-11-06' }), k({ betrag: 3, abschnittId: 't3' }),
    k({ betrag: 99, ausgeblendet: 'ja' }), k({ betrag: 0 }), k({ betrag: 1, datum: '2027-01-01' })], tage);
  assert.equal(r.proTag.t1.summe, 10); assert.equal(r.proTag.t1.nachDatum, 1); assert.equal(r.proTag.t3.summe, 3);
  assert.equal(r.ohneTag.summe, 6); assert.equal(r.summe, 19);
});
test('Ereignisse und Wetter kurz', () => {
  assert.deepEqual(E.ereignisKurz([{ art: 'ereignis', artName: 'Abfahrt' }, { art: 'ereignis', artName: 'Wetter' }, { art: 'ereignis', artName: 'Wetter' }, { art: 'wechsel', artName: 'W' }, { art: 'ereignis', artName: 'X', ausgeblendet: true }]), { anzahl: 3, text: 'Abfahrt, Wetter (2)' });
  assert.equal(E.wetterKurz({ boeen: { wert: 35 }, regen: { wert: 60 }, welle: { wert: 0.8 } }, 'kmh'), 'Böen bis 35 km/h, Regen bis 60 %, Welle bis 0,8 m');
  assert.equal(E.wetterKurz({ boeen: null, regen: null, welle: null }), null);
});
