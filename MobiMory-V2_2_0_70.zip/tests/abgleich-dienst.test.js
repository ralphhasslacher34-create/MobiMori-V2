'use strict';
/* 2.0.65 (Schritt 13b): Dienst (Abgleich, Sicherung) und zwei Geräte gegen denselben Dienst, mit der nachgebauten Datenbank. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'konto', 'abgleich', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;

const APP = 'https://app.example.org';
const PW = 'Sehr-sicheres-Passwort-1';
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }

function umgebung(extra) { return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, extra || {}); }
function uhr() { const u = { t: Date.UTC(2026, 10, 10, 12, 0, 0) }; u.jetzt = () => u.t; return u; }

async function ruf(env, u, methode, weg, body, token) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
  return { status: r.status, json: await r.json() };
}

async function konto(env, u, email) {
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email, passwort: PW });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode });
  return b.json.token;
}

function satz(tabelle, id, extra, basis) {
  const o = Object.assign({ id, datenraumId: '@' }, extra || {});
  return { tabelle, id, basis: basis || 0, nutzlast: JSON.stringify(o) };
}

/* ---------- Dienst ---------- */
test('Dienst: Ohne Anmeldung geht nichts, mit Anmeldung kommt ein Stand mit Kennung', async () => {
  const env = umgebung(), u = uhr();
  assert.equal((await ruf(env, u, 'GET', '/abgleich/stand')).status, 401);
  assert.equal((await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [] })).status, 401);
  assert.equal((await ruf(env, u, 'GET', '/sicherung/liste')).status, 401);
  const tok = await konto(env, u, 'a@example.org');
  const s = await ruf(env, u, 'GET', '/abgleich/stand', undefined, tok);
  assert.equal(s.status, 200); assert.equal(s.json.seq, 0); assert.ok(s.json.epoche); assert.equal(s.json.anzahl, 0);
  const g = await ruf(env, u, 'GET', '/gesundheit');
  assert.equal(g.json.abgleich, true);
});

test('Dienst: Senden nimmt Pakete an, vergibt fortlaufende Nummern, Holen liefert sie in Seiten', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  const alle = []; for (let i = 0; i < 40; i++) alle.push(satz('fristen', 'fr-' + i, { fahrzeugId: 'fz-1' }));
  const r = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: alle }, tok);
  assert.equal(r.status, 200); assert.equal(r.json.angenommen.length, 40); assert.deepEqual(r.json.konflikte, []);
  assert.deepEqual(r.json.angenommen.map((x) => x.seq), Array.from({ length: 40 }, (_, i) => i + 1));
  const r2 = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [satz('fahrzeuge', 'fz-1')] }, tok);
  assert.equal(r2.json.angenommen[0].seq, 41);
  const seite1 = await ruf(env, u, 'GET', '/abgleich/aenderungen?seit=0', undefined, tok);
  assert.equal(seite1.json.eintraege.length, 41); assert.equal(seite1.json.weiter, false); assert.equal(seite1.json.seq, 41);
  const ab = await ruf(env, u, 'GET', '/abgleich/aenderungen?seit=40', undefined, tok);
  assert.deepEqual(ab.json.eintraege.map((x) => x.id), ['fz-1']);
  const dr = env.DB.roh.prepare("SELECT fahrzeug_id FROM abgleich WHERE objekt_id = 'fr-3'").get();
  assert.equal(dr.fahrzeug_id, 'fz-1');
  const viele = []; for (let i = 0; i < 41; i++) viele.push(satz('fristen', 'x-' + i));
  assert.equal((await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: viele }, tok)).status, 400, 'mehr als 40 je Paket');
});

test('Dienst: Seiten beim Holen (mehr als eine Seite)', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  for (let k = 0; k < 3; k++) {
    const l = []; for (let i = 0; i < 40; i++) l.push(satz('zaehlerstaende', 'zs-' + k + '-' + i));
    await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: l }, tok);
  }
  const s1 = await ruf(env, u, 'GET', '/abgleich/aenderungen?seit=0', undefined, tok);
  assert.equal(s1.json.eintraege.length, 60); assert.equal(s1.json.weiter, true); assert.equal(s1.json.bis, 60);
  const s2 = await ruf(env, u, 'GET', '/abgleich/aenderungen?seit=' + s1.json.bis, undefined, tok);
  assert.equal(s2.json.eintraege.length, 60); assert.equal(s2.json.weiter, false);
});

test('Dienst: Nur die festgelegten Datenarten, keine lokalen Schlüssel, nichts Ungültiges', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  const senden = (e) => ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [e] }, tok);
  assert.equal((await senden(satz('einstellungen', 'ei-1'))).status, 400);
  assert.equal((await senden(satz('standorte', 'st-1'))).status, 400);
  assert.equal((await senden(satz('kosten', 'ko-1'))).status, 200, 'Kosten gehen seit 2.0.66 mit');
  assert.equal((await senden(satz('dateien', 'da-1', { name: 'a.jpg' }))).status, 200, 'Angaben zur Datei gehen mit');
  assert.equal((await senden(satz('dateien', 'da-2', { inhalt: 'x' }))).status, 400, 'der Inhalt nie im Abgleich');
  assert.equal((await senden(satz('reisechecks', 'rc-1', { namen: { a: 'Anna' } }))).status, 400, 'Namen hinter den Decknamen bleiben lokal');
  assert.equal((await senden(satz('reisechecks', 'rc-2', { anfrage: {} }))).status, 200);
  const notiz = await senden(satz('fristen', 'fr-1', { werte: { notiz: 'privat' } }));
  assert.equal(notiz.status, 400); assert.match(notiz.json.error, /notiz/);
  for (const k of ['email', 'telefon', 'geburtsdatum', 'wohnort', 'chipnummer', 'adresse', 'ansprechpartner', 'inhalt', 'spur', 'abschlussNotiz', 'erledigtNotiz']) {
    assert.equal((await senden(satz('ereignisse', 'er-1', { tief: [{ [k]: 'x' }] }))).status, 400, k);
  }
  assert.equal((await senden(satz('verlaeufe', 'vl-1', { objektTyp: 'fahrzeugstandort' }))).status, 400, 'Verlauf einer lokalen Art');
  assert.equal((await senden(satz('verlaeufe', 'vl-n1', { objektTyp: 'nachweis', werte: { nummer: 'B123' } }))).status, 400, 'Nummer des Nachweises bleibt lokal');
  assert.equal((await senden(satz('verlaeufe', 'vl-n2', { objektTyp: 'nachweis', werte: { gueltigBis: '2030-01-01' } }))).status, 200);
  assert.equal((await senden(satz('verlaeufe', 'vl-1', { objektTyp: 'frist', werte: { a: 1 } }))).status, 200);
  assert.equal((await senden({ tabelle: 'fristen', id: 'fr-2', basis: 0, nutzlast: 'kein json' })).status, 400);
  assert.equal((await senden({ tabelle: 'fristen', id: 'fr-2', basis: 0, nutzlast: JSON.stringify({ id: 'anders' }) })).status, 400, 'Kennung passt nicht');
  assert.equal((await senden({ tabelle: 'fristen', id: 'fr/../x', basis: 0, nutzlast: '{}' })).status, 400);
  assert.equal((await senden({ tabelle: 'fristen', id: 'fr-3', nutzlast: '{"id":"fr-3"}' })).status, 400, 'Stand fehlt');
  assert.equal((await senden({ tabelle: 'fristen', id: 'fr-3', basis: 0, nutzlast: JSON.stringify({ id: 'fr-3', x: 'a'.repeat(300 * 1024) }) })).status, 400, 'zu groß');
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM abgleich').get().n, 5, 'abgelehnt heißt: nichts gespeichert (angenommen: kosten, dateien, reisechecks und zwei Verläufe)');
});

test('Dienst: Veralteter Stand überschreibt nichts, der Konflikt kommt mit dem Stand des Dienstes zurück', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  const a = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [satz('komponenten', 'ko-1', { v: 'A' })] }, tok);
  const s1 = a.json.angenommen[0].seq;
  const b = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [satz('komponenten', 'ko-1', { v: 'B' }, s1)] }, tok);
  assert.equal(b.json.angenommen.length, 1);
  const alt = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [satz('komponenten', 'ko-1', { v: 'C' }, s1), satz('komponenten', 'ko-2', { v: 'neu' })] }, tok);
  assert.equal(alt.json.angenommen.length, 1); assert.equal(alt.json.angenommen[0].id, 'ko-2');
  assert.equal(alt.json.konflikte.length, 1);
  assert.equal(JSON.parse(alt.json.konflikte[0].nutzlast).v, 'B', 'der Dienst behält B');
  assert.equal(JSON.parse(env.DB.roh.prepare("SELECT nutzlast FROM abgleich WHERE objekt_id = 'ko-1'").get().nutzlast).v, 'B');
  /* Neu angelegt (Stand 0), obwohl es den Datensatz schon gibt: ebenfalls Konflikt */
  const neu = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [satz('komponenten', 'ko-1', { v: 'D' }, 0)] }, tok);
  assert.equal(neu.json.konflikte.length, 1);
  /* Löschen mit richtigem Stand: bleibt als Marke */
  const aktuell = (await ruf(env, u, 'GET', '/abgleich/aenderungen?seit=0', undefined, tok)).json.eintraege.find((x) => x.id === 'ko-1').seq;
  const weg = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [{ tabelle: 'komponenten', id: 'ko-1', basis: aktuell, geloescht: true }] }, tok);
  assert.equal(weg.json.angenommen.length, 1);
  const row = env.DB.roh.prepare("SELECT geloescht, nutzlast FROM abgleich WHERE objekt_id = 'ko-1'").get();
  assert.deepEqual([row.geloescht, row.nutzlast], [1, null]);
  const hol = (await ruf(env, u, 'GET', '/abgleich/aenderungen?seit=0', undefined, tok)).json.eintraege.find((x) => x.id === 'ko-1');
  assert.deepEqual([hol.geloescht, hol.nutzlast], [true, null]);
});

test('Dienst: Jedes Konto sieht nur seinen eigenen Datenraum', async () => {
  const env = umgebung(), u = uhr(), t1 = await konto(env, u, 'a@example.org'), t2 = await konto(env, u, 'b@example.org');
  await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [satz('fahrzeuge', 'fz-1')] }, t1);
  const b = await ruf(env, u, 'GET', '/abgleich/aenderungen?seit=0', undefined, t2);
  assert.deepEqual(b.json.eintraege, []);
  /* Dieselbe Kennung in zwei Datenräumen stört sich nicht */
  const r = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [satz('fahrzeuge', 'fz-1')] }, t2);
  assert.equal(r.json.angenommen.length, 1);
});

test('Dienst: Leeren ändert die Kennung des Standes, Konto bleibt; falsches Wort wird abgelehnt', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  const e1 = (await ruf(env, u, 'GET', '/abgleich/stand', undefined, tok)).json.epoche;
  await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [satz('fahrzeuge', 'fz-1')] }, tok);
  assert.equal((await ruf(env, u, 'POST', '/abgleich/leeren', { bestaetigung: 'nein' }, tok)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/abgleich/leeren', { bestaetigung: 'LÖSCHEN' }, tok)).status, 200);
  const s = (await ruf(env, u, 'GET', '/abgleich/stand', undefined, tok)).json;
  assert.notEqual(s.epoche, e1); assert.equal(s.seq, 0); assert.equal(s.anzahl, 0);
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, tok)).status, 200);
});

test('Dienst: Konto löschen räumt auch Abgleich und Sicherungen weg', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [satz('fahrzeuge', 'fz-1')] }, tok);
  const s = await ruf(env, u, 'POST', '/sicherung/anfangen', { groesse: 10, summe: 'a'.repeat(64) }, tok);
  await ruf(env, u, 'POST', '/sicherung/teil', { id: s.json.id, nr: 0, daten: 'QUJD' }, tok);
  await ruf(env, u, 'POST', '/sicherung/fertig', { id: s.json.id }, tok);
  assert.equal((await ruf(env, u, 'POST', '/konto/loeschen', { bestaetigung: 'LÖSCHEN' }, tok)).status, 200);
  for (const tb of ['abgleich', 'abgleich_stand', 'sicherung', 'sicherungsteil', 'datenraum']) assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM ' + tb).get().n, 0, tb);
});

test('Dienst: Fehlen die Tabellen von 13b, kommt ein klarer Hinweis, Anmelden geht weiter', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  env.DB.roh.exec('DROP TABLE sicherungsteil; DROP TABLE sicherung; DROP TABLE abgleich; DROP TABLE abgleich_stand;');
  const r = await ruf(env, u, 'GET', '/abgleich/stand', undefined, tok);
  assert.equal(r.status, 503); assert.match(r.json.error, /Tabellen/);
  const g = await ruf(env, u, 'GET', '/gesundheit');
  assert.equal(g.json.abgleich, false); assert.equal(g.json.tabellen, true);
  assert.equal((await ruf(env, u, 'GET', '/konto/ich', undefined, tok)).status, 200);
  assert.equal((await ruf(env, u, 'POST', '/konto/loeschen', { bestaetigung: 'LÖSCHEN' }, tok)).status, 200, 'Konto löschen geht auch ohne die neuen Tabellen');
});

test('Dienst: Sicherung in Teilen, nur fertige zählen, die letzten zwei bleiben, Prüfungen', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  const sum = 'a'.repeat(64);
  assert.equal((await ruf(env, u, 'POST', '/sicherung/anfangen', { groesse: 0, summe: sum }, tok)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/sicherung/anfangen', { groesse: 9 * 1024 * 1024, summe: sum }, tok)).status, 400, 'zu groß');
  assert.equal((await ruf(env, u, 'POST', '/sicherung/anfangen', { groesse: 10, summe: 'zz' }, tok)).status, 400);
  const neu = async (teile) => {
    const s = await ruf(env, u, 'POST', '/sicherung/anfangen', { groesse: teile * 256 * 1024 - 5, summe: sum, app: 'MobiMory test' }, tok);
    assert.equal(s.json.teile, teile); assert.equal(s.json.teilBytes, 256 * 1024);
    return s.json.id;
  };
  const id1 = await neu(2);
  assert.equal((await ruf(env, u, 'POST', '/sicherung/teil', { id: id1, nr: 2, daten: 'QUJD' }, tok)).status, 400, 'Nummer außerhalb');
  assert.equal((await ruf(env, u, 'POST', '/sicherung/teil', { id: id1, nr: 0, daten: 'kein base64!' }, tok)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/sicherung/teil', { id: id1, nr: 0, daten: 'A'.repeat(350000) }, tok)).status, 400, 'Teil zu groß');
  await ruf(env, u, 'POST', '/sicherung/teil', { id: id1, nr: 0, daten: 'QUJD' }, tok);
  assert.equal((await ruf(env, u, 'POST', '/sicherung/fertig', { id: id1 }, tok)).status, 400, 'es fehlt ein Teil');
  assert.deepEqual((await ruf(env, u, 'GET', '/sicherung/liste', undefined, tok)).json.sicherungen, [], 'unfertige zählen nicht');
  await ruf(env, u, 'POST', '/sicherung/teil', { id: id1, nr: 1, daten: 'REVG' }, tok);
  assert.equal((await ruf(env, u, 'POST', '/sicherung/fertig', { id: id1 }, tok)).status, 200);
  assert.equal((await ruf(env, u, 'POST', '/sicherung/teil', { id: id1, nr: 0, daten: 'QUJD' }, tok)).status, 404, 'fertige ändert man nicht');
  const ids = [id1];
  for (let i = 0; i < 2; i++) {
    u.t += 60000;
    const id = await neu(1);
    await ruf(env, u, 'POST', '/sicherung/teil', { id, nr: 0, daten: 'QUJD' }, tok);
    await ruf(env, u, 'POST', '/sicherung/fertig', { id }, tok);
    ids.push(id);
  }
  const liste = (await ruf(env, u, 'GET', '/sicherung/liste', undefined, tok)).json.sicherungen;
  assert.deepEqual(liste.map((x) => x.id), [ids[2], ids[1]], 'die letzten zwei, neueste zuerst');
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM sicherungsteil WHERE sicherung_id = ?').get(ids[0]).n, 0, 'die älteste ist samt Teilen weg');
  assert.equal((await ruf(env, u, 'GET', '/sicherung/teil?id=' + ids[1] + '&nr=0', undefined, tok)).json.daten, 'QUJD');
  assert.equal((await ruf(env, u, 'GET', '/sicherung/teil?id=' + ids[0] + '&nr=0', undefined, tok)).status, 404);
  const t2 = await konto(env, u, 'b@example.org');
  assert.equal((await ruf(env, u, 'GET', '/sicherung/teil?id=' + ids[1] + '&nr=0', undefined, t2)).status, 404, 'fremde Sicherung nicht lesbar');
  assert.equal((await ruf(env, u, 'POST', '/sicherung/loeschen', { id: ids[1] }, t2)).status, 200);
  assert.equal((await ruf(env, u, 'GET', '/sicherung/liste', undefined, tok)).json.sicherungen.length, 2, 'fremdes Löschen ändert nichts');
  assert.equal((await ruf(env, u, 'POST', '/sicherung/loeschen', { id: ids[1] }, tok)).status, 200);
  assert.equal((await ruf(env, u, 'GET', '/sicherung/liste', undefined, tok)).json.sicherungen.length, 1);
});

/* ---------- Zwei Geräte gegen denselben Dienst ---------- */
function geraetBauen(env, u) {
  return async function () {
    const d0 = await laden();
    const f = async (url, methode, token, body) => {
      const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.7' };
      if (body !== undefined && body !== null) kopf['Content-Type'] = 'application/json';
      if (token) kopf.Authorization = 'Bearer ' + token;
      const r = await d0.behandeln(new Request(url, { method: methode, headers: kopf, body: body === undefined || body === null ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
      const j = await r.json();
      if (!r.ok) { const e = new Error(j.error); e.status = r.status; throw e; }
      return j;
    };
    let n = 0;
    const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { kontoAnfrage: (...a) => d.netz(...a), jetzt: () => new Date(u.t + (n++) * 1000).toISOString() });
    d.netz = f;
    await d.starten();
    await d.kontoDienstSpeichern('https://konto.example.workers.dev');
    return d;
  };
}
async function zweiGeraete() {
  const env = umgebung(), u = uhr(), neu = geraetBauen(env, u);
  const a = await neu(), b = await neu();
  const r = await a.kontoRegistrieren({ email: 'anna@example.org', passwort: PW });
  assert.equal((await a.kontoCodePruefen({ email: 'anna@example.org', code: r.entwicklungsCode })).ok, true);
  const c = await b.kontoCodeAnfordern({ email: 'anna@example.org' });
  assert.equal((await b.kontoCodePruefen({ email: 'anna@example.org', code: c.entwicklungsCode })).ok, true);
  return { env, u, a, b, neu };
}
async function alleServer(env) { return env.DB.roh.prepare('SELECT tabelle, objekt_id, nutzlast, geloescht FROM abgleich').all(); }

test('Zwei Geräte: Fahrzeug, Frist und Person kommen an, Notiz, E-Mail und Telefon bleiben lokal, der Dienst sieht sie nie', async () => {
  const { env, a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil', kennzeichen: 'LB-MM 1' });
  const fr = await a.fristAnlegen(fz.id, null, { bezeichnung: 'Verbandskasten', kategorie: 'pruefung', kalenderWert: '24', kalenderEinheit: 'monate', vorwarnTage: '30', notiz: 'liegt im Heck' });
  assert.equal(fr.ok, true, JSON.stringify(fr));
  const pe = await a.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'], email: 'anna-privat@example.org', telefon: '0171 555', notiz: 'Allergie' });
  assert.equal(pe.ok, true);
  const r1 = await a.abgleichAusfuehren();
  assert.equal(r1.ok, true, JSON.stringify(r1)); assert.ok(r1.gesendet >= 5); assert.equal(r1.geholt, 0);
  const server = await alleServer(env);
  const text = JSON.stringify(server.map((x) => x.nutzlast));
  ['liegt im Heck', 'anna-privat@example.org', '0171 555', 'Allergie'].forEach((x) => assert.ok(!text.includes(x), x));
  assert.ok(text.includes('Wohnmobil') && text.includes('Anna') && text.includes('Verbandskasten'));
  const r2 = await b.abgleichAusfuehren();
  assert.equal(r2.ok, true, JSON.stringify(r2)); assert.ok(r2.geholt >= 5);
  const liste = await b.fahrzeugListe();
  assert.equal(liste.length, 1); assert.equal(liste[0].aktuell.werte.bezeichnung, 'Wohnmobil');
  assert.equal(liste[0].fahrzeug.datenraumId, b.datenraumId, 'Datenraum dieses Geräts');
  assert.notEqual(a.datenraumId, b.datenraumId);
  const personen = await b.personenListe();
  assert.equal(personen.length, 1); assert.equal(personen[0].aktuell.werte.bezeichnung, 'Anna'); assert.ok(!personen[0].aktuell.werte.email && !personen[0].aktuell.werte.notiz);
  const frs = await b.fristenListe(fz.id);
  assert.equal(frs.length, 1); assert.ok(!frs[0].aktuell.werte.notiz);
  /* Zweiter Abgleich ohne Änderung schickt nichts */
  const r3 = await a.abgleichAusfuehren();
  assert.deepEqual([r3.gesendet, r3.geholt, r3.konflikte], [0, 0, 0]);
  const u = await a.abgleichUebersicht();
  assert.equal(u.offen, 0); assert.ok(u.arten.length >= 3);
  /* Eigene Notiz bleibt auf dem eigenen Gerät erhalten, auch nach dem Holen von anderen Änderungen */
  const eig = await a.mitVerlaufLaden('personen', pe.id, []);
  assert.equal(eig.aktuell.werte.notiz, 'Allergie');
});

test('Zwei Geräte: Einstellungen und Standorte gehen nie hinaus, von Nachweisen nur Gültigkeit, nie Nummer und Scan-Inhalt (seit 2.0.66 gehen Kosten und Dokumente mit)', async () => {
  const { env, a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  await a.speicher.speichern('kosten', { id: 'ko-1', datenraumId: a.datenraumId, fahrzeugId: fz.id, erstelltAm: 'x' });
  await a.speicher.speichern('nachweise', { id: 'na-1', datenraumId: a.datenraumId, besitzerId: 'pe-1', besitzerTyp: 'person', artId: 'ar-1', erstelltAm: 'x' });
  await a.speicher.speichern('nachweisdateien', { id: 'nd-1', nachweisId: 'na-1', name: 'scan.jpg', mime: 'image/jpeg', groesse: 6, inhalt: new Blob(['geheim']), erstelltAm: 'x' });
  await a.speicher.speichern('dokumente', { id: 'do-1', fahrzeugId: fz.id, erstelltAm: 'x' });
  await a.speicher.speichern('einstellungen', { id: 'gpsspur-ak-1', spur: [[1, 2]] });
  await a.speicher.speichern('standorte', { id: 'st-1', ortId: 'or-1' });
  await a.speicher.speichern('verlaeufe', { id: 'vl-k', objektTyp: 'kosten', objektId: 'ko-1', nr: 1, werte: { betrag: 5, notiz: 'privat' }, erstelltAm: 'x' });
  await a.speicher.speichern('verlaeufe', { id: 'vl-n', objektTyp: 'nachweis', objektId: 'na-1', nr: 1, werte: { gueltigBis: '2030-01-01', nummer: 'B-4711', aussteller: 'Landratsamt', notiz: 'n' }, erstelltAm: 'x' });
  const r = await a.abgleichAusfuehren();
  assert.equal(r.ok, true, JSON.stringify(r));
  const server = await alleServer(env), tabellen = new Set(server.map((x) => x.tabelle)), text = JSON.stringify(server);
  ['einstellungen', 'standorte'].forEach((x) => assert.ok(!tabellen.has(x), x));
  ['kosten', 'nachweise', 'nachweisdateien', 'dokumente'].forEach((x) => assert.ok(tabellen.has(x), x));
  ['B-4711', 'Landratsamt', 'privat', 'geheim', 'gpsspur'].forEach((x) => assert.ok(!text.includes(x), x));
  assert.ok(text.includes('gueltigBis') && text.includes('\\"betrag\\"'));
  /* Das zweite Gerät bekommt die Angaben, aber noch keine Datei */
  const rb = await b.abgleichAusfuehren();
  assert.equal(rb.ok, true, JSON.stringify(rb));
  const nd = (await b.speicher.holen('nachweisdateien', 'nd-1'));
  assert.ok(nd && nd.inhalt === null && nd.name === 'scan.jpg');
});

test('Zwei Geräte: Beide ändern dasselbe Fahrzeug, nichts geht verloren, beide kommen zum selben Stand, der Verlauf zeigt beide Änderungen', async () => {
  const { a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto', marke: 'Opel' });
  await a.abgleichAusfuehren(); await b.abgleichAusfuehren();
  await a.fahrzeugAendern(fz.id, { bezeichnung: 'Auto', marke: 'Ford' });
  await b.fahrzeugAendern(fz.id, { bezeichnung: 'Auto', marke: 'Audi' });
  await a.abgleichAusfuehren();
  const rb = await b.abgleichAusfuehren();
  assert.equal(rb.ok, true, JSON.stringify(rb));
  await a.abgleichAusfuehren(); await b.abgleichAusfuehren(); await a.abgleichAusfuehren();
  const la = await a.fahrzeugLaden(fz.id), lb = await b.fahrzeugLaden(fz.id);
  assert.equal(la.aktuell.werte.marke, lb.aktuell.werte.marke, 'gleicher Stand auf beiden Geräten');
  const marken = (x) => x.verlauf.map((v) => v.eintrag.werte.marke).sort();
  assert.deepEqual(marken(la), ['Audi', 'Ford', 'Opel']); assert.deepEqual(marken(lb), ['Audi', 'Ford', 'Opel']);
  const nr = la.verlauf.map((v) => v.eintrag.nr).sort(), nrB = lb.verlauf.map((v) => v.eintrag.nr).sort();
  assert.deepEqual(nr, [1, 2, 3]); assert.deepEqual(nrB, [1, 2, 3]);
  /* der später gemachte Eintrag gilt */
  const zeiten = la.verlauf.map((v) => v.eintrag).sort((x, y) => x.nr - y.nr);
  assert.ok(zeiten[0].erstelltAm <= zeiten[1].erstelltAm && zeiten[1].erstelltAm <= zeiten[2].erstelltAm);
  assert.equal(la.aktuell.id, zeiten[2].id);
});

test('Zwei Geräte: Anderer Datensatz auf beiden geändert, der Dienst gewinnt, die eigene Fassung wird aufgehoben und lässt sich wieder einsetzen', async () => {
  const { a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  const ko = await a.komponenteAnlegen(fz.id, null, 'motor', { bezeichnung: 'Motor' });
  await a.abgleichAusfuehren(); await b.abgleichAusfuehren();
  const von = async (d, wert) => { const k = await d.speicher.holen('komponenten', ko.id); await d.speicher.speichern('komponenten', Object.assign({}, k, { testFeld: wert })); };
  await von(a, 'von A'); await von(b, 'von B');
  assert.equal((await a.abgleichAusfuehren()).konflikte, 0);
  const rb = await b.abgleichAusfuehren();
  assert.equal(rb.ok, true); assert.equal(rb.konflikte, 1);
  assert.equal((await b.speicher.holen('komponenten', ko.id)).testFeld, 'von A', 'der Stand des Dienstes gilt');
  const k = await b.abgleichKonflikte();
  assert.equal(k.length, 1); assert.match(k[0].text, /Komponente/);
  assert.equal((await b.abgleichKonfliktEinsetzen(0, false)).ok, true);
  assert.equal((await b.speicher.holen('komponenten', ko.id)).testFeld, 'von B');
  assert.deepEqual(await b.abgleichKonflikte(), []);
  await b.abgleichAusfuehren(); await a.abgleichAusfuehren();
  assert.equal((await a.speicher.holen('komponenten', ko.id)).testFeld, 'von B', 'eingesetzt und abgeglichen');
  /* Verwerfen entfernt die Fassung, ohne etwas zu ändern */
  await von(a, 'A2'); await von(b, 'B2');
  await a.abgleichAusfuehren(); await b.abgleichAusfuehren();
  assert.equal((await b.abgleichKonflikte()).length, 1);
  await b.abgleichKonfliktEinsetzen(0, true);
  assert.deepEqual(await b.abgleichKonflikte(), []);
  assert.equal((await b.speicher.holen('komponenten', ko.id)).testFeld, 'A2');
});

test('Zwei Geräte: Löschen kommt an; wurde derweil auf dem anderen Gerät geändert, bleibt der Datensatz', async () => {
  const { a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  const k1 = await a.komponenteAnlegen(fz.id, null, 'motor', { bezeichnung: 'Motor' });
  const k2 = await a.komponenteAnlegen(fz.id, null, 'motor', { bezeichnung: 'Zweitmotor' });
  await a.abgleichAusfuehren(); await b.abgleichAusfuehren();
  await a.speicher.mehrereLoeschen([{ tabelle: 'komponenten', id: k1.id }]);
  assert.equal((await a.abgleichUebersicht()).geloescht, 1);
  assert.equal((await a.abgleichAusfuehren()).ok, true);
  const rb = await b.abgleichAusfuehren();
  assert.equal(rb.geloescht, 1); assert.equal(await b.speicher.holen('komponenten', k1.id), null);
  assert.ok(await b.speicher.holen('komponenten', k2.id));
  /* gelöscht gegen geändert */
  await a.speicher.mehrereLoeschen([{ tabelle: 'komponenten', id: k2.id }]);
  const k = await b.speicher.holen('komponenten', k2.id); await b.speicher.speichern('komponenten', Object.assign({}, k, { testFeld: 'bleibt' }));
  await a.abgleichAusfuehren();
  const r = await b.abgleichAusfuehren();
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal((await b.speicher.holen('komponenten', k2.id)).testFeld, 'bleibt');
  await a.abgleichAusfuehren();
  assert.equal((await a.speicher.holen('komponenten', k2.id)).testFeld, 'bleibt', 'der geänderte Datensatz ist zurück');
});

test('Zwei Geräte: Ohne Netz ändert sich nichts, nach Netz geht es weiter; abgelaufene Anmeldung wird erkannt', async () => {
  const { env, a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  const echt = a.netz;
  a.netz = async () => { throw new Error('kein Netz'); };
  const vorher = JSON.stringify(await a.speicher.alleTabellen());
  const r = await a.abgleichAusfuehren();
  assert.equal(r.ok, false); assert.equal(r.offline, true); assert.match(r.fehler.allgemein, /Keine Verbindung/);
  assert.equal(JSON.stringify(await a.speicher.alleTabellen()), vorher, 'lokale Daten unverändert');
  assert.equal((await a.kontoEinstellung()).angemeldet, true);
  a.netz = echt;
  assert.equal((await a.abgleichAusfuehren()).ok, true);
  assert.equal((await b.abgleichAusfuehren()).ok, true);
  assert.equal((await b.fahrzeugListe()).length, 1);
  /* Anmeldung beim Dienst weg */
  env.DB.roh.exec('DELETE FROM sitzung');
  await a.fahrzeugAendern(fz.id, { bezeichnung: 'Auto 2' });
  const x = await a.abgleichAusfuehren();
  assert.equal(x.ok, false); assert.equal(x.abgelaufen, true);
  assert.equal((await a.kontoEinstellung()).angemeldet, false);
  assert.equal((await a.fahrzeugListe())[0].aktuell.werte.bezeichnung, 'Auto 2', 'die Daten bleiben');
});

test('Zwei Geräte: Ohne Anmeldung kein Abgleich, zwei Läufe gleichzeitig werden abgewiesen', async () => {
  const { a } = await zweiGeraete();
  const { neu } = await zweiGeraete();
  const lose = await neu();
  assert.match((await lose.abgleichAusfuehren()).fehler.allgemein, /anmelden/);
  const p1 = a.abgleichAusfuehren(), p2 = a.abgleichAusfuehren();
  const [r1, r2] = await Promise.all([p1, p2]);
  assert.equal(r1.ok, true); assert.equal(r2.ok, false); assert.match(r2.fehler.allgemein, /läuft schon/);
  assert.equal((await a.abgleichAusfuehren()).ok, true, 'danach wieder möglich');
});

test('Zwei Geräte: Leeren beim Dienst, danach schickt der nächste Abgleich alles wieder hin; die Daten auf dem Gerät bleiben', async () => {
  const { env, a, b } = await zweiGeraete();
  await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  await a.abgleichAusfuehren(); await b.abgleichAusfuehren();
  assert.equal((await a.abgleichLeeren({ bestaetigung: 'nein' })).ok, false);
  assert.equal((await a.abgleichLeeren({ bestaetigung: 'LÖSCHEN' })).ok, true);
  assert.equal((await alleServer(env)).length, 0);
  assert.equal((await a.fahrzeugListe()).length, 1);
  const r = await b.abgleichAusfuehren();
  assert.equal(r.ok, true); assert.ok(r.gesendet > 0, 'B merkt die neue Kennung und schickt alles hin');
  assert.ok((await alleServer(env)).length > 0);
  const r2 = await a.abgleichAusfuehren();
  assert.equal(r2.ok, true); assert.equal((await a.fahrzeugListe()).length, 1, 'kein Doppeltes');
});

test('Zwei Geräte: Sicherung beim Dienst, verschlüsselt, Dienst sieht nichts, Wiederherstellen mit Schlüsselwort, ohne Dateien', async () => {
  const { env, a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Geheimauto-4711' });
  await a.personAnlegen({ bezeichnung: 'Geheimperson-0815', email: 'geheim@example.org', notiz: 'Geheimnotiz-42' });
  await a.speicher.speichern('nachweise', { id: 'na-1', datenraumId: a.datenraumId, besitzerId: 'x', artId: 'y', besitzerTyp: 'person', erstelltAm: 'x' });
  await a.speicher.speichern('nachweisdateien', { id: 'nd-1', nachweisId: 'na-1', name: 'scan.jpg', mime: 'image/jpeg', groesse: 6, inhalt: new Blob(['GEHEIM']), erstelltAm: 'x' });
  assert.equal((await a.sicherungZumDienst('kurz')).ok, false);
  const r = await a.sicherungZumDienst('mein-Schluesselwort');
  assert.equal(r.ok, true, JSON.stringify(r));
  const row = env.DB.roh.prepare('SELECT daten FROM sicherungsteil').all();
  const alles = row.map((x) => Buffer.from(x.daten, 'base64').toString('latin1')).join('');
  ['Geheimauto-4711', 'Geheimperson-0815', 'geheim@example.org', 'Geheimnotiz-42', 'GEHEIM'].forEach((x) => assert.ok(!alles.includes(x), 'für den Dienst nicht lesbar: ' + x));
  const l = await b.sicherungListeVomDienst();
  assert.equal(l.ok, true); assert.equal(l.sicherungen.length, 1);
  const g = await b.sicherungVomDienstLaden(l.sicherungen[0].id);
  assert.equal(g.ok, true, JSON.stringify(g));
  assert.equal(MM.Sicherung.istVerschluesselt(g.bytes), true);
  await assert.rejects(b.sicherungLesen(g.bytes, 'falsches-Wort'), (e) => e.code === 'schluessel');
  const gelesen = await b.sicherungLesen(g.bytes, 'mein-Schluesselwort');
  assert.equal(gelesen.kopf.mitDateien, false);
  assert.deepEqual(gelesen.kopf.tabellen.nachweisdateien || [], []);
  assert.equal(gelesen.kopf.tabellen.nachweise.length, 1, 'die Angaben des Nachweises sind in der verschlüsselten Sicherung, der Scan nicht');
  assert.equal(gelesen.kopf.tabellen.fahrzeuge.length, 1);
  /* Wiederherstellen auf dem anderen Gerät, danach beginnt der Abgleich von vorn */
  await b.sicherungEinspielen(gelesen);
  assert.equal((await b.fahrzeugListe())[0].aktuell.werte.bezeichnung, 'Geheimauto-4711');
  assert.equal((await b.abgleichLesen()).epoche, null);
  assert.equal((await b.abgleichAusfuehren()).ok, true);
  assert.ok((await a.rcGeraet()).serverSicherungAm);
  /* Eine beschädigte Übertragung wird erkannt */
  env.DB.roh.exec("UPDATE sicherungsteil SET daten = 'QUJD' WHERE nr = 0");
  const kaputt = await b.sicherungVomDienstLaden(l.sicherungen[0].id);
  assert.equal(kaputt.ok, false); assert.match(kaputt.fehler.allgemein, /nicht vollständig|beschädigt/);
  assert.equal((await b.sicherungVomDienstLoeschen(l.sicherungen[0].id)).ok, true);
  assert.equal((await b.sicherungListeVomDienst()).sicherungen.length, 0);
  assert.equal(fz.ok, true);
});

test('Zwei Geräte: Große Sicherung geht in mehreren Teilen hin und unverändert zurück', async () => {
  const { a, b, env } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  /* viele Ereignisse, damit die Sicherung mehr als einen Teil von 256 KB braucht */
  const lauf = [];
  for (let i = 0; i < 1500; i++) lauf.push({ tabelle: 'zaehlerstaende', objekt: { id: 'zs-' + i, zaehlerId: 'za-1', nr: i, wert: i, datum: '2026-01-01', quelle: 'hand', erstelltAm: 'x', fuell: 'x'.repeat(200) + Math.random() } });
  await a.speicher.mehrereSpeichern(lauf);
  const r = await a.sicherungZumDienst('mein-Schluesselwort');
  assert.equal(r.ok, true, JSON.stringify(r));
  const teile = env.DB.roh.prepare('SELECT COUNT(*) AS n FROM sicherungsteil').get().n;
  assert.ok(teile >= 2, 'mehrere Teile: ' + teile);
  const l = await b.sicherungListeVomDienst();
  const g = await b.sicherungVomDienstLaden(l.sicherungen[0].id);
  assert.equal(g.ok, true, JSON.stringify(g));
  const gelesen = await b.sicherungLesen(g.bytes, 'mein-Schluesselwort');
  assert.equal(gelesen.kopf.tabellen.zaehlerstaende.length, 1500);
  assert.equal(fz.ok, true);
});

test('Zwei Geräte: Zu viele Datensätze für ein Paket werden in Pakete geteilt, über 100 Datensätze kommen vollständig an', async () => {
  const { a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  const z = await a.zaehlerAnlegen(fz.id, null, 'strecke', { bezeichnung: 'Kilometer' });
  assert.equal(z.ok, true, JSON.stringify(z));
  const mehr = []; for (let i = 0; i < 130; i++) mehr.push({ tabelle: 'zaehlerstaende', objekt: { id: 'zs-' + i, zaehlerId: z.id, nr: i + 2, wert: 100 + i, datum: '2026-01-01', quelle: 'hand', erstelltAm: '2026-01-01T00:00:00.000Z' } });
  await a.speicher.mehrereSpeichern(mehr);
  const r = await a.abgleichAusfuehren();
  assert.equal(r.ok, true); assert.ok(r.gesendet >= 130);
  const rb = await b.abgleichAusfuehren();
  assert.equal(rb.ok, true, JSON.stringify(rb));
  assert.equal((await b.speicher.wo('zaehlerstaende', 'zaehlerId', z.id)).length, 130, 'alle Stände');
});

test('Texte und Seiten: Abgleich-Abschnitte stehen auf der Konto-Seite, Dienst und App melden den Stand', () => {
  const fs = require('node:fs'), path = require('node:path');
  const ansicht = fs.readFileSync(path.join(__dirname, '..', 'js/ansicht.js'), 'utf8');
  assert.ok(ansicht.includes('function kontoAbgleichTeile') && ansicht.includes('kontoAbgleichTeile(neu)'));
  ['Jetzt abgleichen', 'Sicherung beim Dienst', 'Konflikte', 'Abgeglichene Daten beim Dienst löschen', 'Jetzt beim Dienst sichern'].forEach((x) => assert.ok(ansicht.includes(x), x));
  assert.ok(ansicht.includes('vorgeladeneSicherung'), 'Wiederherstellen vom Dienst führt zur bekannten Seite');
  assert.equal(MM.Konto.TEXT_DATEN.includes('Notizen bleiben auf deinen Geräten'), true);
  assert.match(MM.Konto.TEXT_SICHERUNG, /Dienst kann sie nicht lesen/);
});
