'use strict';
/* Schritt 11b (2.0.40): Grundcheck, Datenfunktionen mit nachgebautem Dienst. */
const test = require('node:test');
const assert = require('node:assert/strict');

['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'reisecheck', 'grundcheck', 'daten']
  .forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;

const JETZT = new Date(2026, 10, 5, 12, 0, 0).toISOString();
const URL_DIENST = 'https://dienst.example.dev';
const QUELLE = { title: 'FZV', url: 'https://amt.example/fzv', publisher: 'BMDV', official: true, updated: '2026-05-12' };
const req = (requirement, proofKey, extra) => Object.assign({ id: 'r' + requirement.length + proofKey.length, area: 'Fahrzeug', category: 'Pflicht', subjectKey: 'vehicle', subjectType: 'Fahrzeug', trafficMode: 'Strasse',
  requirement, proofKey, status: 'Prüfen', evidence: '', explanation: '', confidence: 'hoch', conflict: false, sources: [QUELLE] }, extra || {});
const ANTWORT = { ok: true, model: 'm1', requestId: 'q1', researchedAt: '2026-11-05T11:00:00Z', result: { summary: 'Grundausstattung Deutschland', researchStatus: 'vollständig', warnings: [],
  route: { routingStatus: 'nicht erforderlich', summary: '', countries: [], borders: [], assumptions: [], routeWarnings: [] },
  requirements: [
    req('Zulassungsbescheinigung Teil 1 | 1 | je Fahrzeug | mitführen', 'Papier'),
    req('Zulassungsbescheinigung Teil 2 | 1 | je Fahrzeug | nicht mitführen, aber vorhanden', 'Papier'),
    req('Warndreieck | 1 | je Fahrzeug | Pflicht', 'Ausrüstung'),
    req('Warnweste | 1 | je Person | je Person im Fahrzeug', 'Ausrüstung'),
    req('Feuerlöscher | 1 | je Fahrzeug | Empfehlung', 'Ausrüstung'),
    req('Es gibt noch regionale Besonderheiten', 'Hinweis', { category: 'Hinweis' })
  ] } };
const scan = { name: 'scan.jpg', type: 'image/jpeg', size: 100 };
const treffer = MM.Ortssuche.kandidaten([{ osm_type: 'node', osm_id: 3, name: 'Sersheim', lat: '48.9561', lon: '9.0546',
  address: { country: 'Deutschland', country_code: 'de', state: 'Baden-Württemberg', village: 'Sersheim', county: 'Landkreis Ludwigsburg' } }])[0];

async function neu(opt) {
  const o = opt || {}; let t = 0; const gesendet = [];
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), {
    jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(),
    holeJson: async () => ({ ok: true, configured: true, model: 'm1' }),
    sendeJson: async (url, token, body) => { gesendet.push({ url, token, body }); if (o.fehler) { const e = new Error('x'); e.status = o.fehler; throw e; } return o.antwort || ANTWORT; }
  });
  await d.starten();
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Mein Wohnmobil', marke: 'Fiat', kennzeichen: 'LB-XY 123', fin: 'ZFA1234567890', plaetze: '4' })).id;
  let ort = null, standort = null;
  if (!o.ohneHeimat) {
    ort = (await d.ortAusTreffer(treffer)).id;
    standort = (await d.standortAnlegen(ort, { bezeichnung: 'Stellplatz hinterm Haus' })).id;
    await d.fahrzeugStandortSetzen(wm, standort);
  }
  if (!o.ohneDienst) { await d.reisecheckEinrichten({ dienstUrl: URL_DIENST, passwort: 'geheim1234' }); if (!o.ohneZustimmung) await d.reisecheckZustimmen(); }
  return { d, wm, ort, standort, gesendet };
}
const status = (an, name) => (an.zeilen.find(z => z.punkt.name === name) || {}).status;

test('Neues Feld „Personen / Plätze“ am Fahrzeug, bei Land, Wasser, Luft und Motorrad, nicht beim Wohnwagen', async () => {
  const c = await neu();
  const f = await c.d.fahrzeugLaden(c.wm);
  assert.equal(f.aktuell.werte.plaetze, 4);
  const hat = id => MM.Fahrzeugarten.art(id).felder.some(x => (x.key || x) === 'plaetze');
  ['auto', 'wohnmobil', 'motorrad', 'oldtimer', 'boot', 'segelboot', 'flugzeug'].forEach(id => assert.equal(hat(id), true, id));
  assert.equal(hat('wohnwagen'), false);
  const bad = await c.d.fahrzeugAnlegen('auto', { bezeichnung: 'X', plaetze: '0' });
  assert.equal(bad.ok, false); assert.ok(bad.fehler.plaetze);
});

test('Heimatland kommt vom Heimatstandort: Ort, Gebiet Land; ohne Standort ein klarer Grund', async () => {
  const c = await neu();
  const h = await c.d.heimatland(c.wm);
  assert.equal(h.land, 'Deutschland'); assert.equal(h.herkunft, 'gebiet'); assert.equal(h.ortName, 'Sersheim'); assert.equal(h.standortName, 'Stellplatz hinterm Haus');
  const o = await neu({ ohneHeimat: true });
  const k = await o.d.heimatland(o.wm);
  assert.equal(k.land, null); assert.ok(k.grund.includes('Heimatstandort'));
});

test('Heimatland: ein von Hand angelegter Ort mit Landtext zählt, einer ohne Land nicht', async () => {
  const c = await neu({ ohneHeimat: true });
  const von = (await c.d.ortAnlegen({ bezeichnung: 'Hafen Biograd', land: 'Kroatien' })).id;
  const so = (await c.d.standortAnlegen(von, { bezeichnung: 'Steg 4' })).id;
  await c.d.fahrzeugStandortSetzen(c.wm, so);
  const h = await c.d.heimatland(c.wm);
  assert.equal(h.land, 'Kroatien'); assert.equal(h.herkunft, 'ort');
  const ohne = (await c.d.ortAnlegen({ bezeichnung: 'Irgendwo' })).id;
  const so2 = (await c.d.standortAnlegen(ohne, { bezeichnung: 'Platz' })).id;
  await c.d.fahrzeugStandortSetzen(c.wm, so2);
  const k = await c.d.heimatland(c.wm);
  assert.equal(k.land, null); assert.ok(k.grund.includes('Irgendwo'));
});

test('Anfrage: ohne Datum der Aktivität und ohne Besatzung möglich, keine Namen und keine Nummern, Fingerabdruck ohne Tagesdatum', async () => {
  const c = await neu();
  const q = await c.d.grundcheckAnfrage(c.wm);
  assert.equal(q.ok, true); assert.equal(q.anfrage.trip.areas[0].name, 'Deutschland'); assert.deepEqual(q.anfrage.persons, []);
  const text = JSON.stringify(q.anfrage);
  ['Mein Wohnmobil', 'LB-XY 123', 'ZFA1234567890', 'Stellplatz hinterm Haus'].forEach(n => assert.equal(text.includes(n), false, n));
  assert.equal(q.anfrage.vehicle.seats, 4);
  assert.ok(q.vorschau.length >= 3);
  const o = await neu({ ohneHeimat: true });
  const k = await o.d.grundcheckAnfrage(o.wm);
  assert.equal(k.ok, false); assert.ok(k.fehler.join(' ').includes('Heimatland'));
  assert.equal(await c.d.grundcheckAnfrage('gibtesnicht'), null);
});

test('Start: braucht Einrichtung und Zustimmung, schickt Grundcheck-Anfrage mit Passwort, speichert mit art „grund“, ohne Aktivität', async () => {
  const a = await neu({ ohneDienst: true }); const r1 = await a.d.grundcheckStarten(a.wm);
  assert.equal(r1.ok, false); assert.equal(r1.art, 'einrichtung'); assert.equal(a.gesendet.length, 0);
  const b = await neu({ ohneZustimmung: true }); const r2 = await b.d.grundcheckStarten(b.wm);
  assert.equal(r2.ok, false); assert.equal(r2.art, 'zustimmung'); assert.equal(b.gesendet.length, 0);
  const o = await neu({ ohneHeimat: true }); const r3 = await o.d.grundcheckStarten(o.wm);
  assert.equal(r3.ok, false); assert.equal(r3.art, 'daten'); assert.equal(o.gesendet.length, 0);
  const c = await neu();
  const r = await c.d.grundcheckStarten(c.wm);
  assert.equal(r.ok, true);
  assert.equal(c.gesendet.length, 1); assert.equal(c.gesendet[0].url, URL_DIENST + '/research'); assert.equal(c.gesendet[0].token, 'geheim1234');
  assert.equal(c.gesendet[0].body.trip.title, 'Grundcheck');
  const liste = await c.d.grundcheckListe(c.wm);
  assert.equal(liste.length, 1); assert.equal(liste[0].art, 'grund'); assert.equal(liste[0].aktivitaetId, null); assert.equal(liste[0].land, 'Deutschland');
});

test('Dienstfehler: verständlicher Satz, nichts gespeichert', async () => {
  const c = await neu({ fehler: 401 });
  const r = await c.d.grundcheckStarten(c.wm);
  assert.equal(r.ok, false); assert.ok(r.fehler.allgemein.length > 10);
  assert.equal((await c.d.grundcheckListe(c.wm)).length, 0);
});

test('Vergleich: ohne Eintragungen fehlt oder ist unklar, nichts wird gesperrt, unlesbarer Hinweis steht extra', async () => {
  const c = await neu(); await c.d.grundcheckStarten(c.wm);
  const an = await c.d.grundcheckAnsicht(c.wm);
  assert.equal(an.zeilen.length, 5);
  assert.equal(status(an, 'Warndreieck'), 'fehlt'); assert.equal(status(an, 'Warnweste'), 'fehlt'); assert.equal(status(an, 'Feuerlöscher'), 'fehlt');
  assert.equal(status(an, 'Zulassungsbescheinigung Teil 1'), 'fehlt'); assert.equal(status(an, 'Zulassungsbescheinigung Teil 2'), 'fehlt');
  assert.equal(an.zaehl.fehlt, 5); assert.equal(an.zaehl.vorhanden, 0);
  assert.deepEqual(an.nichtLesbar.map(x => x.text), ['Es gibt noch regionale Besonderheiten']);
  const ww = an.zeilen.find(z => z.punkt.name === 'Warnweste');
  assert.equal(ww.soll, 4); assert.equal(ww.link.href, '#/fahrzeug/' + encodeURIComponent(c.wm) + '/komponente/neu?name=Warnweste&anzahl=4');
  assert.equal(an.gewaehlt.land, 'Deutschland'); assert.equal(an.gewaehlt.veraltet, false);
  assert.ok(an.zeilen[0].punkt.quellen[0].url.startsWith('https://')); assert.equal(an.zeilen[0].punkt.stand, '2026-05-12');
});

test('Eintragen wirkt sofort ohne neuen Online-Check: Komponenten und Nachweise ändern den Vergleich', async () => {
  const c = await neu(); await c.d.grundcheckStarten(c.wm);
  assert.equal((await c.d.komponenteAnlegen(c.wm, null, 'sonstiges', { bezeichnung: 'Warndreieck', anzahl: '1' })).ok, true);
  await c.d.komponenteAnlegen(c.wm, null, 'sonstiges', { bezeichnung: 'Warnweste', anzahl: '2' });
  const zb1 = (await c.d.nachweisartAusVorschlag('DE_FZV_ZB_I')).id;
  const n = await c.d.nachweisAnlegen('fahrzeug', c.wm, zb1, { datei: scan });
  assert.equal(n.ok, true, JSON.stringify(n.fehler));
  const an = await c.d.grundcheckAnsicht(c.wm);
  assert.equal(c.gesendet.length, 1);
  assert.equal(status(an, 'Warndreieck'), 'vorhanden');
  assert.equal(status(an, 'Warnweste'), 'zu_wenig');
  assert.equal(an.zeilen.find(z => z.punkt.name === 'Warnweste').soll, 4);
  assert.equal(status(an, 'Zulassungsbescheinigung Teil 1'), 'vorhanden');
  assert.equal(status(an, 'Zulassungsbescheinigung Teil 2'), 'fehlt');
  assert.equal(status(an, 'Feuerlöscher'), 'fehlt');
  await c.d.komponenteAnlegen(c.wm, null, 'sonstiges', { bezeichnung: 'Warnweste hinten', anzahl: '2' });
  assert.equal(status(await c.d.grundcheckAnsicht(c.wm), 'Warnweste'), 'vorhanden');
});

test('Ohne Plätze am Fahrzeug ist „je Person“ unklar, mit Link zum Fahrzeug', async () => {
  const c = await neu();
  const ohne = (await c.d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Zweites', kennzeichen: 'X' })).id;
  const so = (await c.d.standortAnlegen(c.ort, { bezeichnung: 'Zweiter Platz' })).id;
  await c.d.fahrzeugStandortSetzen(ohne, so);
  await c.d.grundcheckStarten(ohne);
  await c.d.komponenteAnlegen(ohne, null, 'sonstiges', { bezeichnung: 'Warnweste', anzahl: '3' });
  const an = await c.d.grundcheckAnsicht(ohne);
  const z = an.zeilen.find(x => x.punkt.name === 'Warnweste');
  assert.equal(z.status, 'unklar'); assert.equal(z.link.href, '#/fahrzeug/' + encodeURIComponent(ohne) + '/aendern');
});

test('Ausgebaute Teile zählen nicht, Papier ohne Foto ist „unklar“', async () => {
  const c = await neu(); await c.d.grundcheckStarten(c.wm);
  const k = (await c.d.komponenteAnlegen(c.wm, null, 'sonstiges', { bezeichnung: 'Warndreieck', anzahl: '1', ausgebautAm: '2026-10-01' }));
  assert.equal(k.ok, true);
  const zb1 = (await c.d.nachweisartAusVorschlag('DE_FZV_ZB_I')).id;
  await c.d.nachweisAnlegen('fahrzeug', c.wm, zb1, {});
  const an = await c.d.grundcheckAnsicht(c.wm);
  assert.equal(status(an, 'Warndreieck'), 'fehlt');
  assert.equal(status(an, 'Zulassungsbescheinigung Teil 1'), 'unklar');
});

test('Wiederholbar: zweiter Check nach Umzug, frühere bleiben, Hinweis „Land gewechselt“ und „Daten geändert“', async () => {
  const c = await neu();
  const r1 = await c.d.grundcheckStarten(c.wm);
  const nach = await c.d.grundcheckAnsicht(c.wm);
  assert.equal(nach.gewaehlt.landWechsel, false); assert.equal(nach.checks.length, 1);
  const hr = (await c.d.ortAusTreffer(MM.Ortssuche.kandidaten([{ osm_type: 'node', osm_id: 4, name: 'Biograd na Moru', lat: '43.9387', lon: '15.4443', address: { town: 'Biograd na Moru', county: 'Zadarska županija', country: 'Kroatien', country_code: 'hr' } }])[0])).id;
  const so = (await c.d.standortAnlegen(hr, { bezeichnung: 'Steg' })).id;
  await c.d.fahrzeugStandortSetzen(c.wm, so);
  const alt = await c.d.grundcheckAnsicht(c.wm);
  assert.equal(alt.heimat.land, 'Kroatien'); assert.equal(alt.gewaehlt.landWechsel, true); assert.equal(alt.gewaehlt.land, 'Deutschland'); assert.equal(alt.gewaehlt.veraltet, true);
  const r2 = await c.d.grundcheckStarten(c.wm);
  assert.equal(r2.ok, true); assert.notEqual(r2.id, r1.id);
  assert.equal(c.gesendet[1].body.trip.areas[0].name, 'Kroatien');
  const neuAn = await c.d.grundcheckAnsicht(c.wm);
  assert.equal(neuAn.checks.length, 2); assert.equal(neuAn.gewaehlt.id, r2.id); assert.equal(neuAn.gewaehlt.land, 'Kroatien'); assert.equal(neuAn.gewaehlt.landWechsel, false);
  const fruehere = await c.d.grundcheckAnsicht(c.wm, r1.id);
  assert.equal(fruehere.gewaehlt.id, r1.id); assert.equal(fruehere.gewaehlt.land, 'Deutschland');
});

test('Ein Dienst, der das Format nicht einhält, bringt „nicht auswertbar“, nichts wird geraten', async () => {
  const antwort = { ok: true, model: 'm', requestId: 'q', researchedAt: '2026-11-05T11:00:00Z', result: Object.assign({}, ANTWORT.result, { requirements: [req('Man braucht ein Warndreieck und eine Warnweste', 'Ausrüstung')] }) };
  const c = await neu({ antwort }); await c.d.grundcheckStarten(c.wm);
  const an = await c.d.grundcheckAnsicht(c.wm);
  assert.equal(an.zeilen.length, 0); assert.equal(an.nichtLesbar.length, 1);
});

test('Der Reisecheck bleibt unberührt: Übersicht und Listen kennen den Grundcheck nicht, kein Zählen', async () => {
  const c = await neu(); await c.d.grundcheckStarten(c.wm);
  const u = await c.d.reisecheckUebersicht();
  assert.deepEqual(u, []);
  assert.deepEqual(await c.d.reisecheckListe('gibtesnicht'), []);
});

test('Sicherung enthält den Grundcheck, Passwort bleibt draußen', async () => {
  const c = await neu(); await c.d.grundcheckStarten(c.wm);
  const s = await c.d.sicherungErzeugen({});
  const text = typeof s === 'string' ? s : (s.text || JSON.stringify(s));
  assert.equal(text.includes('geheim1234'), false);
});
