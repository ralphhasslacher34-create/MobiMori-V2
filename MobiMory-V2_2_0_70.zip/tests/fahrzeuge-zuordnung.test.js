'use strict';
/* 2.0.45, Punkt 3 und 3a: zusammengehörige Fahrzeuge („Gehört zu“) und ihre Fristen in der Planung. */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren', 'personen', 'orte',
  'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const JETZT = '2026-11-06T12:00:00.000Z';

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anh = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Motorradanhänger' })).id;
  const moto = (await d.fahrzeugAnlegen('auto', { bezeichnung: 'Motorrad' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'] })).id;
  return { d, wm, anh, moto, anna };
}
const zu = async (c, id) => (await c.d.fahrzeugLaden(id)).aktuell.werte.hauptfahrzeugId || null;

test('Zuordnung setzen, ändern, entfernen: jedes Fahrzeug bleibt eigenständig, Verlauf mit Namen', async () => {
  const c = await neu();
  const boot = (await c.d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  assert.ok((await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'Motorradanhänger', hauptfahrzeugId: c.wm })).geaendert);
  assert.equal(await zu(c, c.anh), c.wm);
  assert.ok((await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'Motorradanhänger', hauptfahrzeugId: boot })).geaendert);
  assert.equal((await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'Motorradanhänger', hauptfahrzeugId: boot })).geaendert, false);
  assert.ok((await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'Motorradanhänger', hauptfahrzeugId: '' })).geaendert);
  assert.equal(await zu(c, c.anh), null);
  const v = (await c.d.fahrzeugLaden(c.anh)).verlauf.map(x => x.aenderungen.find(a => a.key === 'hauptfahrzeugId')).filter(Boolean);
  assert.deepEqual(v.map(a => [a.alt, a.neu]), [['Boot', null], ['Wohnmobil', 'Boot'], [null, 'Wohnmobil']]);
  assert.equal((await c.d.fahrzeugListe()).length, 4, 'alle bleiben eigene Fahrzeuge');
  /* ohne Angabe in den Werten bleibt die Zuordnung */
  await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'Motorradanhänger', hauptfahrzeugId: c.wm });
  await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'Motorradanhänger 2' });
  assert.equal(await zu(c, c.anh), c.wm);
});

test('Beim Anlegen wählbar; Selbstbezug, Kreis und unbekannte Fahrzeuge werden abgewiesen', async () => {
  const c = await neu();
  const r = await c.d.fahrzeugAnlegen('boot', { bezeichnung: 'Dinghy', hauptfahrzeugId: c.wm });
  assert.ok(r.ok);
  assert.equal(await zu(c, r.id), c.wm);
  assert.ok((await c.d.fahrzeugAnlegen('boot', { bezeichnung: 'X', hauptfahrzeugId: 'fz-gibt-es-nicht' })).fehler.hauptfahrzeugId);
  assert.ok((await c.d.fahrzeugAendern(c.wm, { bezeichnung: 'Wohnmobil', hauptfahrzeugId: c.wm })).fehler.hauptfahrzeugId);
  await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'A', hauptfahrzeugId: c.wm });
  const k = await c.d.fahrzeugAendern(c.wm, { bezeichnung: 'Wohnmobil', hauptfahrzeugId: c.anh });
  assert.equal(k.ok, false);
  assert.ok(k.fehler.hauptfahrzeugId.includes('kreis') || k.fehler.hauptfahrzeugId.includes('Kreis'));
  await c.d.fahrzeugAendern(c.moto, { bezeichnung: 'Motorrad', hauptfahrzeugId: c.anh });
  assert.ok((await c.d.fahrzeugAendern(c.wm, { bezeichnung: 'Wohnmobil', hauptfahrzeugId: c.moto })).fehler.hauptfahrzeugId, 'Kreis über drei');
  assert.equal(await zu(c, c.wm), null);
});

test('Kette über drei Fahrzeuge, Anzeige in beide Richtungen, Auswahl ohne Kreise', async () => {
  const c = await neu();
  await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'A', hauptfahrzeugId: c.wm });
  await c.d.fahrzeugAendern(c.moto, { bezeichnung: 'Motorrad', hauptfahrzeugId: c.anh });
  const oben = await c.d.fahrzeugZuordnung(c.wm);
  assert.deepEqual(oben.direkt.map(x => x.id), [c.anh]);
  assert.deepEqual(oben.alle.map(x => [x.id, x.tiefe]), [[c.anh, 1], [c.moto, 2]]);
  assert.equal(oben.alle[1].ueber, 'A');
  const unten = await c.d.fahrzeugZuordnung(c.moto);
  assert.equal(unten.hauptfahrzeug.id, c.anh);
  assert.deepEqual(unten.kette.map(x => x.id), [c.anh, c.wm]);
  const wahl = await c.d.zuordnungAuswahl(c.wm);
  assert.deepEqual(wahl, [], 'unter dem Wohnmobil hängt alles, nichts zur Auswahl');
  assert.deepEqual((await c.d.zuordnungAuswahl(c.anh)).map(x => x.wert), [c.wm]);
  assert.equal((await c.d.zuordnungAuswahl(null)).length, 3);
});

test('Hauptfahrzeug abgegeben: Anhänger bleibt bestehen und verliert nur die Zuordnung, mit Hinweis', async () => {
  const c = await neu();
  await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'A', hauptfahrzeugId: c.wm });
  const r = await c.d.fahrzeugAbgeben(c.wm, { datum: '2026-11-05', grund: 'verkauft' });
  assert.ok(r.ok);
  assert.deepEqual(r.zuordnungGeloest, ['A']);
  assert.equal(await zu(c, c.anh), null);
  assert.ok((await c.d.fahrzeugListe()).some(x => x.fahrzeug.id === c.anh));
  const v = (await c.d.fahrzeugLaden(c.anh)).verlauf[0].aenderungen.find(a => a.key === 'hauptfahrzeugId');
  assert.equal(v.alt, 'Wohnmobil');
  /* abgegebene Fahrzeuge stehen nicht zur Auswahl */
  assert.ok((await c.d.fahrzeugAendern(c.moto, { bezeichnung: 'M', hauptfahrzeugId: c.wm })).fehler.hauptfahrzeugId);
  assert.ok(!(await c.d.zuordnungAuswahl(c.moto)).some(x => x.wert === c.wm));
});

test('Übergabedatei enthält keinen Verweis auf andere Fahrzeuge', async () => {
  const c = await neu();
  await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'A', hauptfahrzeugId: c.wm });
  await c.d.fahrzeugAbgeben(c.anh, { datum: '2026-11-05', grund: 'verkauft' });
  const u = await c.d.uebergabeErzeugen(c.anh, {});
  assert.ok(u.ok);
  const g = await c.d.uebergabeLesen(u.bytes, '');
  g.kopf.tabellen.eintraege.forEach(e => assert.ok(!('hauptfahrzeugId' in e.werte)));
});

test('Sicherung und Wiederherstellung behalten „Gehört zu“', async () => {
  const c = await neu();
  await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'A', hauptfahrzeugId: c.wm });
  const s = await c.d.sicherungErzeugen({});
  const d2 = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher());
  await d2.starten();
  await d2.sicherungEinspielen(await d2.sicherungLesen(s.bytes, ''));
  assert.equal((await d2.fahrzeugLaden(c.anh)).aktuell.werte.hauptfahrzeugId, c.wm);
});

/* ---------- 3a: Planung ---------- */
async function mitFristen(c) {
  /* Wohnmobil: keine Frist. Anhänger: HU am 2026-12-01 fällig. */
  await c.d.fristAnlegen(c.anh, null, { bezeichnung: 'HU Anhänger', kategorie: 'pruefung', kalenderWert: '24', vorwarnTage: '30', zuletztAm: '2024-12-01' });
  const arten = await c.d.aktivitaetsartenListe();
  const artId = arten.find(x => x.aktuell.werte.bezeichnung === 'Urlaub').objekt.id;
  return (roh) => c.d.aktivitaetAnlegen(Object.assign({ bezeichnung: 'Urlaub', artId, fahrzeugId: c.wm, vonDatum: '2026-11-20', bisDatum: '2026-12-10', verantwortlichId: c.anna }, roh || {}));
}

test('Planung: Frist des Anhängers im Zeitraum erscheint in der Prüfung des Wohnmobils, getrennt nach Fahrzeug', async () => {
  const c = await neu();
  const plane = await mitFristen(c);
  const a = await plane();
  assert.ok(a.ok, JSON.stringify(a));
  let pr = await c.d.aktivitaetPruefung(a.id);
  assert.deepEqual(pr.fristen.gespann, [], 'ohne Zuordnung ändert sich nichts');
  assert.equal(pr.fristen.liste.length, 0);
  await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'Motorradanhänger', hauptfahrzeugId: c.wm });
  pr = await c.d.aktivitaetPruefung(a.id);
  assert.equal(pr.fristen.gespann.length, 1);
  const g = pr.fristen.gespann[0];
  assert.equal(g.name, 'Motorradanhänger');
  assert.equal(g.liste[0].status, 'faellig');
  assert.equal(g.zusammenfassung.betroffen, 1);
  assert.equal(pr.fristen.zusammenfassung.betroffen, 0, 'Das Hauptfahrzeug bleibt, wie es war');
});

test('Planung: Kette über drei Fahrzeuge, abgegebener Anhänger wird nicht geprüft, Befähigung bleibt beim Wohnmobil', async () => {
  const c = await neu();
  const plane = await mitFristen(c);
  await c.d.fristAnlegen(c.moto, null, { bezeichnung: 'HU Motorrad', kategorie: 'pruefung', kalenderWert: '12', vorwarnTage: '30', zuletztAm: '2025-12-01' });
  await c.d.fahrzeugAendern(c.anh, { bezeichnung: 'A', hauptfahrzeugId: c.wm });
  await c.d.fahrzeugAendern(c.moto, { bezeichnung: 'M', hauptfahrzeugId: c.anh });
  const a = await plane();
  const pr = await c.d.aktivitaetPruefung(a.id);
  assert.deepEqual(pr.fristen.gespann.map(x => x.name), ['A', 'M']);
  assert.equal(pr.fristen.gespann[1].ueber, 'A');
  assert.equal(pr.fristen.gespann[1].liste[0].status, 'faellig');
  assert.deepEqual(pr.befaehigung.personen.map(p => p.person.name), ['Anna']);
  await c.d.fahrzeugAbgeben(c.anh, { datum: '2026-11-05', grund: 'verkauft' });
  assert.deepEqual((await c.d.aktivitaetPruefung(a.id)).fristen.gespann.map(x => x.name), [], 'abgegeben: nicht mehr geprüft');
});
