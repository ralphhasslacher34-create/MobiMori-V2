'use strict';
/* Tag der Reise wählen (2.0.44): Regeln für den Kalender. */
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/tagwahl.js');
const T = globalThis.MM.Tagwahl;

test('Mehrtägig und Zahl der Reisetage', () => {
  assert.equal(T.mehrtaegig('2026-12-24', '2026-12-24'), false);
  assert.equal(T.mehrtaegig('2026-12-24', '2026-12-25'), true);
  assert.equal(T.mehrtaegig('', '2026-12-25'), false);
  assert.equal(T.reiseTage('2026-12-24', '2027-01-02'), 10);
  assert.equal(T.reiseTage('2026-03-28', '2026-03-30'), 3, 'Zeitumstellung ändert die Zählung nicht');
  assert.equal(T.reiseTage('2026-12-25', '2026-12-24'), 0);
});

test('Tag der Reise: Tag 1 ist der erste Reisetag, nicht das heutige Datum', () => {
  assert.equal(T.tagNummer('2026-12-24', '2027-01-02', '2026-12-24'), 1);
  assert.equal(T.tagNummer('2026-12-24', '2027-01-02', '2027-01-02'), 10);
  assert.equal(T.tagNummer('2026-12-24', '2027-01-02', '2026-12-23'), null);
  assert.equal(T.tagNummer('2026-12-24', '2027-01-02', '2027-01-03'), null);
});

test('Vorwahl: zuletzt gewählter Tag, sonst heutiger Reisetag, sonst Tag 1', () => {
  const tage = [{ id: 'b', datum: '2026-12-26' }, { id: 'a', datum: '2026-12-24' }, { id: 'c', datum: '2026-12-27' }];
  assert.equal(T.standard(tage, '2026-11-05', null), 'a', 'Reise noch nicht begonnen: Tag 1');
  assert.equal(T.standard(tage, '2026-12-26', null), 'b', 'heute ist ein Reisetag');
  assert.equal(T.standard(tage, '2026-12-26', 'c'), 'c', 'die Wahl bleibt');
  assert.equal(T.standard(tage, '2026-12-26', 'gibtsnicht'), 'b', 'gewählter Tag gibt es nicht mehr');
  assert.equal(T.standard([], '2026-12-26', null), null);
});

test('Knopftext', () => {
  assert.equal(T.knopfText(3, 8, 'Mi', '26.12.2026'), 'Tag 3 von 8 · Mi 26.12.2026');
  assert.equal(T.knopfText(null, 0, '', '26.12.2026'), 'Tag · 26.12.2026');
});

test('Kalender: beginnt im Monat des ersten Reisetags, hebt Tage mit Logbuch hervor, kennt die Wahl', () => {
  const tage = [{ id: 'a', datum: '2026-12-24' }, { id: 'b', datum: '2026-12-26' }, { id: 'x', datum: '2026-12-26' }];
  const m = T.monate('2026-12-24', '2027-01-02', tage, 'b', '2026-12-25');
  assert.deepEqual(m.map(x => x.titel), ['Dezember 2026', 'Januar 2027']);
  m.forEach(mo => mo.wochen.forEach(w => assert.equal(w.length, 7)));
  const alle = m.flatMap(mo => mo.wochen.flat()).filter(Boolean);
  assert.equal(alle.filter(z => z.art === 'ausserhalb').length > 0, true);
  const z24 = alle.find(z => z.datum === '2026-12-24'), z25 = alle.find(z => z.datum === '2026-12-25'), z26 = alle.find(z => z.datum === '2026-12-26');
  assert.deepEqual([z24.art, z24.nr, z24.id], ['aktiv', 1, 'a']);
  assert.deepEqual([z25.art, z25.nr, z25.id, z25.heute], ['frei', 2, null, true]);
  assert.deepEqual([z26.art, z26.id, z26.gewaehlt], ['aktiv', 'b', true], 'bei gleichem Datum zählt der erste');
  assert.equal(alle.filter(z => z.gewaehlt).length, 1);
  assert.equal(alle.filter(z => z.art !== 'ausserhalb').length, 10);
  /* der 1. Dezember 2026 ist ein Dienstag: eine leere Zelle davor */
  assert.equal(m[0].wochen[0][0], null); assert.equal(m[0].wochen[0][1].datum, '2026-12-01');
});

test('Kalender: lange Reise über mehrere Monate, ungültige Zeiträume geben nichts', () => {
  const m = T.monate('2026-11-20', '2027-02-10', [], null, '2026-11-05');
  assert.deepEqual(m.map(x => x.titel), ['November 2026', 'Dezember 2026', 'Januar 2027', 'Februar 2027']);
  assert.deepEqual(T.monate('2026-12-25', '2026-12-24', [], null, ''), []);
  assert.deepEqual(T.monate('', '', [], null, ''), []);
});
