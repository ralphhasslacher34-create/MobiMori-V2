'use strict';
/* Schritt 11c (2.0.41): „Habe ich unter anderem Namen“, Datenfunktionen mit nachgebautem Dienst. */
const test = require('node:test');
const assert = require('node:assert/strict');

['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'routen', 'reisecheck', 'grundcheck', 'daten']
  .forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;

const JETZT = new Date(2026, 10, 5, 12, 0, 0).toISOString();
const URL_DIENST = 'https://dienst.example.dev';
const QUELLE = { title: 'Verordnung', url: 'https://amt.example/v', publisher: 'Behörde', official: true, updated: '2026-05-12' };
const req = (requirement, proofKey) => ({ id: 'r' + requirement.length + proofKey.length, area: 'Fahrzeug', category: 'Pflicht', subjectKey: 'vehicle', subjectType: 'Fahrzeug', trafficMode: 'Wasser',
  requirement, proofKey, status: 'Prüfen', evidence: '', explanation: '', confidence: 'hoch', conflict: false, sources: [QUELLE] });
const ANTWORT = { ok: true, model: 'm1', requestId: 'q1', researchedAt: '2026-11-05T11:00:00Z', result: { summary: 'Grundausstattung Frankreich', researchStatus: 'vollständig', warnings: [],
  route: { routingStatus: 'nicht erforderlich', summary: '', countries: [], borders: [], assumptions: [], routeWarnings: [] },
  requirements: [
    req('Persönliche Schwimmhilfe | 1 | je Person | für jede Person an Bord', 'Ausrüstung'),
    req('Feuerlöscher | 1 | je Fahrzeug | Pflicht', 'Ausrüstung'),
    req('Zulassungsbescheinigung Teil 1 | 1 | je Fahrzeug | mitführen', 'Papier')
  ] } };
const scan = { name: 'scan.jpg', type: 'image/jpeg', size: 100 };
const treffer = MM.Ortssuche.kandidaten([{ osm_type: 'node', osm_id: 7, name: 'Strasbourg', lat: '48.5846', lon: '7.7507',
  address: { country: 'Frankreich', country_code: 'fr', state: 'Grand Est', city: 'Strasbourg', county: 'Bas-Rhin' } }])[0];

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), {
    jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(),
    holeJson: async () => ({ ok: true, configured: true, model: 'm1' }),
    sendeJson: async () => ANTWORT
  });
  await d.starten();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Mein Boot', plaetze: '4' })).id;
  const ort = (await d.ortAusTreffer(treffer)).id;
  const standort = (await d.standortAnlegen(ort, { bezeichnung: 'Liegeplatz 3' })).id;
  await d.fahrzeugStandortSetzen(boot, standort);
  await d.reisecheckEinrichten({ dienstUrl: URL_DIENST, passwort: 'geheim1234' }); await d.reisecheckZustimmen();
  await d.grundcheckStarten(boot);
  return { d, boot };
}
const zeile = (an, name) => an.zeilen.find(z => z.punkt.name === name);
const ziel = extra => Object.assign({ art: 'ausruestung', punkt: 'Persönliche Schwimmhilfe', land: 'Frankreich', ziel: 'Rettungsweste' }, extra || {});

test('Ohne Zuordnung: „fehlt“; die Auswahlliste nennt nur, was am Fahrzeug wirklich eingetragen ist (alle Ebenen, ohne Ausgebautes)', async () => {
  const c = await neu();
  await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Rettungsweste', anzahl: '4' });
  const haupt = (await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Sicherheit' })).id;
  await c.d.komponenteAnlegen(c.boot, haupt, 'sonstiges', { bezeichnung: 'Auftriebsweste Kind', anzahl: '1' });
  await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Alte Weste', anzahl: '1', ausgebautAm: '2026-10-01' });
  const an = await c.d.grundcheckAnsicht(c.boot);
  assert.equal(zeile(an, 'Persönliche Schwimmhilfe').status, 'fehlt'); assert.deepEqual(zeile(an, 'Persönliche Schwimmhilfe').zugeordnet, []);
  assert.deepEqual(an.kandidaten.ausruestung, ['Auftriebsweste Kind', 'Rettungsweste', 'Sicherheit']);
  assert.deepEqual(an.kandidaten.papier, []);
});

test('Zuordnen: die App rechnet danach mit der bestätigten Komponente, mehrere Namen zählen zusammen, Aufheben nimmt es zurück', async () => {
  const c = await neu();
  await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Rettungsweste', anzahl: '3' });
  await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Rettungsweste Kind', anzahl: '1' });
  const r = await c.d.grundcheckZuordnen(c.boot, ziel());
  assert.equal(r.ok, true);
  let an = await c.d.grundcheckAnsicht(c.boot);
  let z = zeile(an, 'Persönliche Schwimmhilfe');
  assert.equal(z.status, 'zu_wenig'); assert.equal(z.soll, 4); assert.equal(z.ist, 3, 'nur die bestätigte Komponente zählt, „Rettungsweste Kind“ wird nicht geraten');
  assert.deepEqual(z.zugeordnet, ['Rettungsweste']);
  assert.match(z.text, /Gleichgesetzt mit „Rettungsweste“/);
  assert.equal((await c.d.grundcheckZuordnen(c.boot, ziel({ ziel: 'Rettungsweste Kind' }))).ok, true);
  z = zeile(await c.d.grundcheckAnsicht(c.boot), 'Persönliche Schwimmhilfe');
  assert.equal(z.status, 'vorhanden'); assert.equal(z.ist, 4); assert.deepEqual(z.zugeordnet, ['Rettungsweste', 'Rettungsweste Kind']);
  assert.equal((await c.d.grundcheckZuordnungAufheben(c.boot, ziel({ ziel: 'Rettungsweste Kind' }))).ok, true);
  assert.equal(zeile(await c.d.grundcheckAnsicht(c.boot), 'Persönliche Schwimmhilfe').status, 'zu_wenig');
  assert.equal((await c.d.grundcheckZuordnungAufheben(c.boot, ziel({ ziel: '' }))).ok, true);
  an = await c.d.grundcheckAnsicht(c.boot);
  assert.equal(zeile(an, 'Persönliche Schwimmhilfe').status, 'fehlt'); assert.deepEqual(zeile(an, 'Persönliche Schwimmhilfe').zugeordnet, []);
  assert.equal((await c.d.zuordnungenListe()).length, 0);
});

test('Zuordnen prüft: das Ziel muss am Fahrzeug eingetragen sein, nichts Leeres, nichts Gleichnamiges, kein unbekanntes Land', async () => {
  const c = await neu();
  await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Rettungsweste', anzahl: '4' });
  assert.equal((await c.d.grundcheckZuordnen(c.boot, ziel({ ziel: 'Gibt es nicht' }))).ok, false);
  assert.equal((await c.d.grundcheckZuordnen(c.boot, ziel({ ziel: '' }))).ok, false);
  assert.equal((await c.d.grundcheckZuordnen(c.boot, ziel({ land: '' }))).ok, false);
  assert.equal((await c.d.grundcheckZuordnen(c.boot, ziel({ punkt: 'Rettungsweste' }))).ok, false);
  assert.equal((await c.d.grundcheckZuordnen(c.boot, ziel({ art: 'papier' }))).ok, false, 'als Papier gibt es keinen Nachweis dieses Namens');
  assert.equal((await c.d.grundcheckZuordnen('gibtesnicht', ziel())).ok, false);
  assert.equal((await c.d.zuordnungenListe()).length, 0, 'nach den Fehlern ist nichts gespeichert');
});

test('Papier: ein Nachweis des Fahrzeugs wird gleichgesetzt, „vorhanden“ braucht Foto oder Scan', async () => {
  const c = await neu();
  const art = (await c.d.nachweisartAnlegen({ bezeichnung: 'Internationaler Bootsschein', gehoertZu: 'fahrzeug', hatAblauf: 'nein' })).id;
  const art2 = (await c.d.nachweisartAnlegen({ bezeichnung: 'Registerauszug', gehoertZu: 'fahrzeug', hatAblauf: 'nein' })).id;
  await c.d.nachweisAnlegen('fahrzeug', c.boot, art, {});
  await c.d.nachweisAnlegen('fahrzeug', c.boot, art2, { datei: scan });
  let an = await c.d.grundcheckAnsicht(c.boot);
  assert.equal(zeile(an, 'Zulassungsbescheinigung Teil 1').status, 'fehlt');
  assert.deepEqual(an.kandidaten.papier, ['Internationaler Bootsschein', 'Registerauszug']);
  const p = { art: 'papier', punkt: 'Zulassungsbescheinigung Teil 1', land: 'Frankreich' };
  assert.equal((await c.d.grundcheckZuordnen(c.boot, Object.assign({ ziel: 'Internationaler Bootsschein' }, p))).ok, true);
  an = await c.d.grundcheckAnsicht(c.boot);
  assert.equal(zeile(an, 'Zulassungsbescheinigung Teil 1').status, 'unklar', 'eingetragen, aber ohne Foto oder Scan');
  assert.equal((await c.d.grundcheckZuordnen(c.boot, Object.assign({ ziel: 'Registerauszug' }, p))).ok, true);
  an = await c.d.grundcheckAnsicht(c.boot);
  const z = zeile(an, 'Zulassungsbescheinigung Teil 1');
  assert.equal(z.status, 'vorhanden'); assert.deepEqual(z.zugeordnet, ['Internationaler Bootsschein', 'Registerauszug']);
});

test('Gilt je Land und Fahrzeugart: ein anderes Fahrzeug einer anderen Art und ein anderes Land sehen die Zuordnung nicht', async () => {
  const c = await neu();
  await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Rettungsweste', anzahl: '4' });
  await c.d.grundcheckZuordnen(c.boot, ziel());
  const wm = (await c.d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil', plaetze: '4' })).id;
  const so = (await c.d.standortAnlegen((await c.d.orteListe())[0].objekt.id, { bezeichnung: 'Stellplatz' })).id;
  await c.d.fahrzeugStandortSetzen(wm, so);
  await c.d.grundcheckStarten(wm);
  await c.d.komponenteAnlegen(wm, null, 'sonstiges', { bezeichnung: 'Rettungsweste', anzahl: '4' });
  assert.equal(zeile(await c.d.grundcheckAnsicht(wm), 'Persönliche Schwimmhilfe').status, 'fehlt', 'andere Fahrzeugart');
  const zw = (await c.d.fahrzeugAnlegen('boot', { bezeichnung: 'Zweites Boot', plaetze: '2' })).id;
  await c.d.fahrzeugStandortSetzen(zw, so);
  await c.d.grundcheckStarten(zw);
  await c.d.komponenteAnlegen(zw, null, 'sonstiges', { bezeichnung: 'Rettungsweste', anzahl: '2' });
  assert.equal(zeile(await c.d.grundcheckAnsicht(zw), 'Persönliche Schwimmhilfe').status, 'vorhanden', 'gleiche Art, gleiches Land');
  const l = await c.d.zuordnungenListe();
  assert.equal(l.length, 1); assert.equal(l[0].land, 'Frankreich'); assert.equal(l[0].artId, 'boot'); assert.deepEqual(l[0].namen, ['Rettungsweste']);
});

test('Reisecheck: die Pflichtausrüstung einer Gebietsregel nimmt dieselbe Zuordnung (Land der Regel, Art der Aktivität)', async () => {
  const c = await neu();
  const d = c.d;
  await d.aktivitaetsartenAusVorschlaegen();
  const arten = await d.aktivitaetsartenListe();
  const art = arten.find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const g = (await d.gebieteListe()).find(x => x.aktuell.werte.bezeichnung === 'Frankreich' && x.aktuell.werte.ebene === 'land').objekt.id;
  await d.regelAnlegen(g, { bezeichnung: 'Schwimmhilfen', art: 'ausruestung', pflichtAusruestung: 'Persönliche Schwimmhilfe', fahrzeugArten: ['boot'], menge: '1', bezug: 'fahrzeug' });
  await d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Rettungsweste', anzahl: '2' });
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: art, fahrzeugId: c.boot, vonDatum: '2026-12-01', bisDatum: '2026-12-10', verantwortlichId: anna, gebietId: g });
  let p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.ausruestung.liste[0].status, 'nicht_eingetragen');
  assert.equal((await d.grundcheckZuordnen(c.boot, ziel())).ok, true);
  p = await d.aktivitaetPruefung(r.id);
  assert.equal(p.ausruestung.liste[0].status, 'eingetragen'); assert.equal(p.ausruestung.ergebnis, 'erlaubt');
  assert.match(p.ausruestung.liste[0].text, /Gleichgesetzt mit „Rettungsweste“/);
  await d.grundcheckZuordnungAufheben(c.boot, ziel());
  assert.equal((await d.aktivitaetPruefung(r.id)).ausruestung.liste[0].status, 'nicht_eingetragen');
});

test('Speicher: ein Dokument in „einstellungen“, Datenbank-Version bleibt 16, geht in die Sicherung', async () => {
  const c = await neu();
  await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Rettungsweste', anzahl: '4' });
  await c.d.grundcheckZuordnen(c.boot, ziel());
  assert.equal(MM.Speicher.DB_VERSION, 16);
  const alle = await c.d.speicher.alleTabellen();
  const doc = alle.einstellungen.find(x => x.id === 'zuordnungen');
  assert.ok(doc); assert.equal(doc.eintraege.length, 1);
  assert.equal(JSON.stringify(doc).includes('Mein Boot'), false, 'kein Fahrzeugname im Dokument');
});
