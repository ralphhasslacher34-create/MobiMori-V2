'use strict';
/* 2.0.45, Punkt 1 und 1a: Komponenten löschen (unbenutzt), ausblenden (benutzt), verschieben. */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren', 'personen', 'orte',
  'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 6, 12, 0, t++)).toISOString() });
  await d.starten();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const motor = (await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor Backbord' })).id;
  const pumpe = (await d.komponenteAnlegen(boot, motor, null, { bezeichnung: 'Pumpe' })).id;
  const heizung = (await d.komponenteAnlegen(boot, null, 'heizung', { bezeichnung: 'Heizung' })).id;
  return { d, boot, motor, pumpe, heizung };
}
const anzahlKomp = async (c) => (await c.d.komponentenListe(c.boot)).length;

test('Unbenutzt: löschen entfernt die Komponente, ihre Teile und alle Einträge', async () => {
  const c = await neu();
  await c.d.komponenteAendern(c.motor, { bezeichnung: 'Motor BB' });
  const v = await c.d.komponenteVerwendung(c.motor);
  assert.equal(v.benutzt, false);
  assert.equal(v.anzahlUnter, 1);
  const r = await c.d.komponenteLoeschen(c.motor);
  assert.ok(r.ok);
  assert.equal(r.anzahl, 2);
  assert.equal(await anzahlKomp(c), 1);
  assert.equal(await c.d.komponenteLaden(c.motor), null);
  const eintraege = await c.d.speicher.alle('komponenteneintraege');
  assert.ok(eintraege.every(e => e.komponenteId === c.heizung));
});

test('Benutzt: Frist, Zähler, Vorgang, Dokument, Kosten, Motorlauf verhindern das Löschen, Ausblenden geht', async () => {
  const verwendungen = {
    zaehler: (c, id) => c.d.zaehlerAnlegen(c.boot, id, 'stunden', { bezeichnung: 'Stunden' }),
    frist: (c, id) => c.d.fristAnlegen(c.boot, id, { bezeichnung: 'Prüfen', kategorie: 'pruefung', kalenderWert: '12', vorwarnTage: '30' }),
    vorgang: (c, id) => c.d.vorgangAnlegen(c.boot, id, 'arbeit', { bezeichnung: 'Ölwechsel', ausfuehrung: 'selbst' }),
    dokument: (c, id) => c.d.dokumentAnlegen(c.boot, id, { quelle: 'link', link: 'www.hersteller.de/a.pdf', bezeichnung: 'Anleitung', art: 'bedienung' }),
    kosten: (c, id) => c.d.kostenAnlegen(c.boot, { gruppe: 'instandhaltung', bezeichnung: 'Kerzen', kostenart: 'teile', betrag: '45', datum: '2026-09-01', komponenteId: id }),
    lauf: (c, id) => c.d.motorStart(id)
  };
  for (const name of Object.keys(verwendungen)) {
    const c = await neu();
    const r = await verwendungen[name](c, c.motor);
    assert.ok(r.ok, name + ' anlegen: ' + JSON.stringify(r));
    const v = await c.d.komponenteVerwendung(c.motor);
    assert.equal(v.benutzt, true, name);
    const l = await c.d.komponenteLoeschen(c.motor);
    assert.equal(l.ok, false, name);
    assert.ok(l.fehler.allgemein.includes('nur ausblenden'), name);
    assert.equal(await anzahlKomp(c), 3, name);
    assert.ok((await c.d.komponenteAusblenden(c.motor, true)).geaendert, name);
  }
});

test('Verwendung an einem Teil darunter: die Hauptkomponente lässt sich nicht löschen, das unbenutzte Teil schon', async () => {
  const c = await neu();
  assert.ok((await c.d.fristAnlegen(c.boot, c.pumpe, { bezeichnung: 'Pumpe prüfen', kategorie: 'pruefung', kalenderWert: '6', vorwarnTage: '14' })).ok);
  const v = await c.d.komponenteVerwendung(c.motor);
  assert.equal(v.benutzt, true);
  assert.equal(v.inUnterteilen, true);
  assert.equal((await c.d.komponenteLoeschen(c.motor)).ok, false);
  assert.equal((await c.d.komponenteLoeschen(c.heizung)).ok, true);
});

test('Gleichsetzung bei der Pflichtausrüstung zählt als benutzt', async () => {
  const c = await neu();
  const w = await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Schwimmweste' });
  const doc = MM.Orte.zuordnungSetzen(null, { land: 'Deutschland', artId: 'boot', art: 'ausruestung', punkt: 'Rettungsweste', ziel: 'Schwimmweste', jetzt: 'x' });
  await c.d.speicher.speichern('einstellungen', doc);
  const v = await c.d.komponenteVerwendung(w.id);
  assert.equal(v.benutzt, true);
  assert.ok(v.gruende.some(g => g.includes('Pflichtausrüstung')));
});

test('Ausblenden und Einblenden: Verlauf hat eigene Einträge, Angaben bleiben gleich', async () => {
  const c = await neu();
  assert.ok((await c.d.komponenteAusblenden(c.heizung, true)).geaendert);
  assert.equal((await c.d.komponenteAusblenden(c.heizung, true)).geaendert, false);
  let k = await c.d.komponenteLaden(c.heizung);
  assert.equal(k.komponente.ausgeblendet, true);
  assert.equal(k.verlauf[0].art, 'ausgeblendet');
  assert.equal(k.verlauf[0].aenderungen[0].neu, 'ausgeblendet');
  assert.equal(k.aktuell.werte.bezeichnung, 'Heizung');
  await c.d.komponenteAusblenden(c.heizung, false);
  k = await c.d.komponenteLaden(c.heizung);
  assert.ok(!k.komponente.ausgeblendet);
  assert.equal(k.verlauf.length, 3);
  assert.equal(k.verlauf[0].art, 'eingeblendet');
});

test('Ausgeblendet: nicht im Motorschalter (außer er läuft), Teile darunter sind verdeckt', async () => {
  const c = await neu();
  assert.equal((await c.d.motorenListe(c.boot)).length, 1);
  await c.d.komponenteAusblenden(c.motor, true);
  assert.equal((await c.d.motorenListe(c.boot)).length, 0);
  const aktiv = MM.Komponenten.aktive(await c.d.komponentenListe(c.boot));
  assert.deepEqual(aktiv.map(x => x.aktuell.werte.bezeichnung), ['Heizung']);
  await c.d.komponenteAusblenden(c.motor, false);
  assert.ok((await c.d.motorStart(c.motor)).ok);
  await c.d.komponenteAusblenden(c.motor, true);
  assert.equal((await c.d.motorenListe(c.boot)).length, 1, 'läuft noch');
  await c.d.komponenteAusblenden(c.motor, false);
  assert.equal((await c.d.motorenListe(c.boot)).length, 1);
});

test('Ausgeblendet zählt nicht für Grundcheck und Ausrüstungsprüfung', async () => {
  const c = await neu();
  const w = await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Rettungsweste', anzahl: '4' });
  let e = await c.d.grundcheckEingabe(c.boot);
  assert.ok(e.fahrzeug.komponenten.some(k => k.name === 'Rettungsweste'));
  await c.d.komponenteAusblenden(w.id, true);
  e = await c.d.grundcheckEingabe(c.boot);
  assert.ok(!e.fahrzeug.komponenten.some(k => k.name === 'Rettungsweste'));
  assert.ok(!e.vergleich.komponenten.some(k => k.name === 'Rettungsweste'));
  await c.d.komponenteAusblenden(c.motor, true);
  e = await c.d.grundcheckEingabe(c.boot);
  assert.ok(!e.fahrzeug.komponenten.some(k => k.name === 'Pumpe'), 'Teil unter ausgeblendetem Motor ist verdeckt');
});

test('Verschieben: samt Teilen, benutzte Komponente, Verweise bleiben, Verlauf zeigt von wo nach wo', async () => {
  const c = await neu();
  const z = (await c.d.zaehlerAnlegen(c.boot, c.pumpe, 'stunden', { bezeichnung: 'Pumpenstunden' })).id;
  const unter = (await c.d.komponenteAnlegen(c.boot, c.pumpe, null, { bezeichnung: 'Dichtung' })).id;
  const r = await c.d.komponenteVerschieben(c.pumpe, { parentId: c.heizung });
  assert.ok(r.ok && r.geaendert);
  const k = await c.d.komponenteLaden(c.pumpe);
  assert.deepEqual(k.weg.map(x => x.aktuell.werte.bezeichnung), ['Heizung']);
  assert.equal(k.verlauf[0].art, 'verschoben');
  assert.equal(k.verlauf[0].aenderungen[0].alt, 'unter Motor Backbord');
  assert.equal(k.verlauf[0].aenderungen[0].neu, 'unter Heizung');
  assert.equal((await c.d.komponenteLaden(unter)).tiefe, 5);
  assert.equal((await c.d.zaehlerListe(c.boot)).filter(x => x.komponenteId === c.pumpe).length, 1);
  assert.equal((await c.d.komponenteVerwendung(c.pumpe)).benutzt, true);
  assert.ok(z);
});

test('Verschieben: kein Kreis, kein Selbstbezug, anderes Fahrzeug nicht', async () => {
  const c = await neu();
  assert.ok((await c.d.komponenteVerschieben(c.motor, { parentId: c.pumpe })).fehler.parentId);
  assert.ok((await c.d.komponenteVerschieben(c.motor, { parentId: c.motor })).fehler.parentId);
  const wm = (await c.d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'WM' })).id;
  const fremd = (await c.d.komponenteAnlegen(wm, null, 'motor', { bezeichnung: 'Fremdmotor' })).id;
  assert.ok((await c.d.komponenteVerschieben(c.pumpe, { parentId: fremd })).fehler.parentId);
  assert.equal((await c.d.komponenteVerschieben(c.pumpe, { parentId: c.motor })).geaendert, false);
  const ziele = await c.d.komponenteZiele(c.motor);
  assert.deepEqual(ziele.map(x => x.name), ['Heizung']);
});

test('Verschieben als Hauptkomponente: Art ist Pflicht, Ausrüstung und Motorschalter funktionieren danach', async () => {
  const c = await neu();
  const teilMotor = (await c.d.komponenteAnlegen(c.boot, c.heizung, null, { bezeichnung: 'Hilfsmotor' })).id;
  assert.equal((await c.d.motorenListe(c.boot)).length, 1);
  assert.ok((await c.d.komponenteVerschieben(teilMotor, { parentId: null })).fehler.art);
  assert.ok((await c.d.komponenteVerschieben(teilMotor, { parentId: null, art: 'ding' })).fehler.art);
  assert.ok((await c.d.komponenteVerschieben(teilMotor, { parentId: null, art: 'motor' })).ok);
  const k = await c.d.komponenteLaden(teilMotor);
  assert.equal(k.komponente.art, 'motor');
  assert.equal(k.komponente.parentId, null);
  assert.equal((await c.d.motorenListe(c.boot)).length, 2);
  assert.ok((await c.d.komponenteVerschieben(teilMotor, { parentId: c.heizung })).ok);
  assert.equal((await c.d.komponenteLaden(teilMotor)).komponente.art, null);
  assert.equal((await c.d.motorenListe(c.boot)).length, 1);
});

test('Verschieben zur Hauptkomponente: Kurzname-Kollision bleibt geprüft', async () => {
  const c = await neu();
  await c.d.komponenteAendern(c.motor, { bezeichnung: 'Motor Backbord', kurzname: 'BB' });
  const t = (await c.d.komponenteAnlegen(c.boot, c.heizung, null, { bezeichnung: 'Zweiter', kurzname: 'BB' })).id;
  const r = await c.d.komponenteVerschieben(t, { parentId: null, art: 'motor' });
  assert.equal(r.ok, false);
  assert.ok(r.fehler.kurzname);
});

test('Sicherung und Wiederherstellung behalten ausgeblendet, verschoben und gelöscht', async () => {
  const c = await neu();
  await c.d.komponenteAusblenden(c.heizung, true);
  await c.d.komponenteVerschieben(c.pumpe, { parentId: null, art: 'sonstiges' });
  const extra = (await c.d.komponenteAnlegen(c.boot, null, 'sonstiges', { bezeichnung: 'Weg damit' })).id;
  await c.d.komponenteLoeschen(extra);
  const s = await c.d.sicherungErzeugen({});
  const gelesen = await c.d.sicherungLesen(s.bytes, '');
  const d2 = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher());
  await d2.starten();
  await d2.sicherungEinspielen(gelesen);
  const liste = await d2.komponentenListe(c.boot);
  assert.equal(liste.length, 3);
  assert.equal(liste.find(x => x.komponente.id === c.heizung).komponente.ausgeblendet, true);
  assert.equal(liste.find(x => x.komponente.id === c.pumpe).komponente.parentId, null);
  assert.equal(MM.Speicher.DB_VERSION, 16);
});
