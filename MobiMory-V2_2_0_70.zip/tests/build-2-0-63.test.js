'use strict';
/* 2.0.60: Anzahl in der Checkliste, Löschen und „neu“ in der Komponentenliste, Start und Ziel der Tage, Ablegen mit Ortsauswahl, ETA. */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM, K = MM.Komponenten, E = MM.Etappen;

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(2026, 10, 9, 12, 0, 0).getTime() + (t++) * 1000).toISOString() });
  await d.starten(); await d.aktivitaetsartenAusVorschlaegen();
  return d;
}

async function reise(extra) {
  const d = await neu();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot', reisegeschwindigkeit: '10', hoechstgeschwindigkeit: '20' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const art = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const ort = async (n, b, l) => (await d.ortAnlegen({ bezeichnung: n, positionBreite: b, positionLaenge: l })).id;
  const kiel = await ort('Kiel', '54,32', '10,14'), laboe = await ort('Laboe', '54,40', '10,22'), ohne = (await d.ortAnlegen({ bezeichnung: 'Ohne Position' })).id;
  const r = await d.aktivitaetAnlegen(Object.assign({ bezeichnung: 'Törn', artId: art, fahrzeugId: boot, vonDatum: '2026-11-09', vonZeit: '09:00', bisDatum: '2026-11-09', bisZeit: '17:00', verantwortlichId: anna, startOrtId: kiel, zielOrtId: laboe }, extra || {}));
  assert.ok(r.ok, JSON.stringify(r));
  const t = await d.heutigerTag(r.id);
  await d.abschnittAendern(t.abschnittId, { datum: '2026-11-09', beginnZeit: '09:00' });
  return { d, boot, akt: r.id, tag: t.abschnittId, kiel, laboe, ohne };
}

/* ---------- Punkt 1: Reisecheck für einen Tag nimmt die abgeleiteten Orte ---------- */
test('Reisecheck für einen Tag: Tag ohne eigene Orte bekommt Start und Ziel aus der Reise, mit Herkunft', async () => {
  const c = await reise();
  const x = await c.d.reisecheckEingabe(c.akt, c.tag);
  const w = x.eingabe.wegpunkte;
  assert.deepEqual(w.map(p => [p.art, p.name]), [['start', 'Kiel'], ['ziel', 'Laboe']]);
  assert.deepEqual(x.aktivitaet.tagHerkunft, { start: 'reise', ziel: 'reise' });
  assert.ok(x.eingabe.gebiete.length >= 0);
  const q = await c.d.reisecheckAnfrage(c.akt, c.tag);
  assert.ok(!(q.fehler || []).some(f => /Start- und einen Zielort/.test(f)), 'der Tag braucht keine von Hand eingetragenen Orte mehr');
});
test('Reisecheck für einen Tag: Tag 2 startet am Ziel von Tag 1, eigene Orte gelten zuerst', async () => {
  const c = await reise({ bisDatum: '2026-11-10' });
  await c.d.tagesabschnitteVorbereiten(c.akt);
  const lb = await c.d.logbuchLaden(c.akt);
  const tag2 = lb.abschnitte.filter(t => !t.ausgeblendet)[1];
  const art = await c.d.ereignisartAnlegen({ bezeichnung: 'Ablegen Y', fragen: MM.Baukasten.vorlage('ablegen').fragen, wirkungen: [] });
  const e = await c.d.ereignisSchnell(c.akt, 'Ablegen Y', { artId: art.id, ortName: 'Kiel' });
  await c.d.ereignisAblaufAusfuehren(e.id, { zielOrtId: c.laboe });
  const x = await c.d.reisecheckEingabe(c.akt, tag2.objekt.id);
  assert.equal(x.eingabe.wegpunkte[0].name, 'Laboe');
  assert.equal(x.aktivitaet.tagHerkunft.start, 'vortag');
  await c.d.abschnittAendern(tag2.objekt.id, { datum: tag2.aktuell.werte.datum, startOrtId: c.kiel, zielOrtId: c.kiel });
  const y = await c.d.reisecheckEingabe(c.akt, tag2.objekt.id);
  assert.equal(y.eingabe.wegpunkte[0].name, 'Kiel');
  assert.equal(y.aktivitaet.tagHerkunft.start, 'tag');
});

/* ---------- Punkt 2: Baukasten-Knopf „Verbraucher einschalten“ ---------- */
async function strom() {
  const d = await neu();
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const gen = (await d.komponenteAnlegen(wm, null, 'sonstiges', { bezeichnung: 'Generator', verbraucher: 'ja', stoff: 'Benzin', stromRolle: 'generator' })).id;
  const k = (await d.komponenteAnlegen(wm, null, 'sonstiges', { bezeichnung: 'Kühlschrank', verbraucher: 'ja', stoff: 'Strom', spannung: '12 V', weitere: [{ stoff: 'Strom', spannung: '220/230/240 V' }] })).id;
  const heiz = (await d.komponenteAnlegen(wm, null, 'sonstiges', { bezeichnung: 'Heizung', verbraucher: 'ja', stoff: 'Strom', spannung: '12 V' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Fahrer'] })).id;
  const art = (await d.aktivitaetsartenListe())[0].objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Tour', artId: art, fahrzeugId: wm, vonDatum: '2026-11-09', vonZeit: '09:00', bisDatum: '2026-11-12', bisZeit: '17:00', verantwortlichId: anna });
  assert.ok(r.ok, JSON.stringify(r));
  const ea = await d.ereignisartAnlegen({ bezeichnung: 'Verbraucher an', fragen: ['verbraucher'], wirkungen: ['verbraucherEin'] });
  return { d, wm, gen, k, heiz, akt: r.id, ea: ea.id };
}
const neuesEreignis = async (c) => (await c.d.ereignisSchnell(c.akt, 'Verbraucher an', { artId: c.ea })).id;
test('Baukasten-Knopf „Verbraucher einschalten“: mit der Wahl des Nutzers (Versorgung, Quelle) klappt es, ohne sie sagt er, was fehlt', async () => {
  const c = await strom();
  const e1 = await neuesEreignis(c);
  const o = await c.d.ereignisAblaufAusfuehren(e1, { verbraucherId: c.k });
  assert.equal(o.ok, false); assert.ok(o.fehler.versorgungId, 'die Meldung steht beim Feld „Womit läuft es?“');
  const p = await c.d.ereignisAblaufAusfuehren(e1, { verbraucherId: c.k, versorgungId: 'v2' });
  assert.equal(p.ok, false); assert.ok(p.fehler.stromQuelle);
  const q = await c.d.ereignisAblaufAusfuehren(e1, { verbraucherId: c.k, versorgungId: 'v2', stromQuelle: 'generator' });
  assert.ok(q.ok, JSON.stringify(q));
  assert.equal(q.lauf.stromQuelle, 'generator');
  assert.equal((await c.d.verbraucherSchalter(c.wm)).find(x => x.komponenteId === c.k).laeuftMit, 'Strom 220/230/240 V (Generator)');
});
test('Baukasten-Knopf: ein Verbraucher mit einer einzigen Möglichkeit braucht keine Wahl', async () => {
  const c = await strom();
  const e = await neuesEreignis(c);
  const r = await c.d.ereignisAblaufAusfuehren(e, { verbraucherId: c.heiz });
  assert.ok(r.ok, JSON.stringify(r));
});
test('Eine Stelle für Schalter und Knopf: dieselbe Auswahl (MM.Versorgung.einschalten…)', async () => {
  const c = await strom();
  const k = await c.d.verbraucherEinschaltenKontext(c.k), h = await c.d.verbraucherEinschaltenKontext(c.heiz);
  const V = MM.Versorgung;
  assert.equal(V.einschaltenWahlNoetig(k), true); assert.equal(V.einschaltenWahlNoetig(h), false);
  assert.deepEqual(V.einschaltenFelder(k, {}).map(f => f.key), ['versorgungId']);
  assert.deepEqual(V.einschaltenFelder(k, { versorgungId: 'v2' }).map(f => f.key), ['versorgungId', 'stromQuelle']);
  assert.deepEqual(V.einschaltenFelder(h, {}), [], 'Gleichstrom mit einer Quelle: keine Rückfrage');
  assert.deepEqual(V.einschaltenAntwort(k, { versorgungId: 'v2', stromQuelle: 'generator', erzeugerId: 'x' }), { versorgungId: 'v2', stromQuelle: 'generator' });
  const w = { versorgungId: 'v2', stromQuelle: 'generator', erzeugerId: 'g' }; V.einschaltenNachAenderung('versorgungId', w);
  assert.deepEqual(w, { versorgungId: 'v2', stromQuelle: '', erzeugerId: '' });
  const a = require('node:fs').readFileSync(require('node:path').join(__dirname, '..', 'js', 'ansicht.js'), 'utf8');
  assert.ok((a.match(/einschaltenFormFelder\(/g) || []).length >= 3, 'Cockpit-Seite und Baukasten-Formular benutzen dieselbe Funktion');
});

/* ---------- Punkt 3: Kennungsprüfung bei „Angaben ändern“ ---------- */
test('Angaben ändern: gleiche Kennung bei einem anderen Fahrzeug warnt, „trotzdem“ bestätigt, das eigene Fahrzeug zählt nicht', async () => {
  const d = await neu();
  const a = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'A', kennzeichen: 'HN-AB 123' })).id;
  const b = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'B', kennzeichen: 'HN-CD 456' })).id;
  const r = await d.fahrzeugAendern(b, { bezeichnung: 'B', kennzeichen: 'hn ab123' });
  assert.equal(r.ok, false); assert.equal(r.doppelt.length, 1); assert.equal(r.doppelt[0].id, a);
  assert.match(r.fehler.allgemein, /Es gibt schon ein Fahrzeug mit der Kennung/);
  assert.equal((await d.fahrzeugLaden(b)).aktuell.werte.kennzeichen, 'HN-CD 456', 'nichts wurde geändert');
  const t = await d.fahrzeugAendern(b, { bezeichnung: 'B', kennzeichen: 'HN-AB 123' }, undefined, { trotzdem: true });
  assert.ok(t.ok, JSON.stringify(t));
  /* eigene Kennung wieder eintragen oder andere Felder ändern: keine Frage, auch wenn es schon doppelt ist */
  const u = await d.fahrzeugAendern(b, { bezeichnung: 'B neu', kennzeichen: 'HN-AB 123' });
  assert.ok(u.ok, JSON.stringify(u));
  const e = await d.fahrzeugAendern(a, { bezeichnung: 'A', kennzeichen: 'HN-AB 123', fin: 'WDB123' });
  assert.ok(e.ok, 'nur neue Kennungen werden geprüft: die FIN ist frei, das gleiche Kennzeichen war schon da');
});
test('Angaben ändern: FIN eines anderen Fahrzeugs warnt auch', async () => {
  const d = await neu();
  await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'A', fin: 'WDB123456' });
  const b = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'B' })).id;
  const r = await d.fahrzeugAendern(b, { bezeichnung: 'B', fin: 'wdb 123456' });
  assert.equal(r.ok, false); assert.equal(r.doppelt.length, 1);
});

/* ---------- Punkt 4: Fixkosten ---------- */
test('Posten ohne Anteil im Jahr bleiben in ihrer Gruppe sichtbar, mit Grund', async () => {
  const d = await neu();
  const fz = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'WM' })).id;
  const mk = (n, extra) => d.kostenAnlegen(fz, Object.assign({ gruppe: 'fix', bezeichnung: n }, extra));
  const alle = [await mk('Versicherung', { betrag: '600', datum: '2026-01-01', rhythmus: 'jaehrlich' }),
    await mk('Einmalig 2025', { betrag: '100', datum: '2025-05-03', rhythmus: 'einmalig' }),
    await mk('Beginnt 2027', { betrag: '50', datum: '2027-03-01', rhythmus: 'monatlich' }),
    await mk('Endete 2025', { betrag: '50', datum: '2024-01-01', bis: '2025-06-30', rhythmus: 'monatlich' })];
  alle.forEach(r => assert.ok(r.ok, JSON.stringify(r)));
  const a = await d.kostenAuswertung(fz, 2026);
  assert.deepEqual(a.posten.fix.map(x => x.aktuell.werte.bezeichnung), ['Versicherung']);
  const grund = Object.fromEntries(a.ohneAnteil.fix.map(x => [x.aktuell.werte.bezeichnung, x.keinAnteil]));
  assert.deepEqual(Object.keys(grund).sort(), ['Beginnt 2027', 'Einmalig 2025', 'Endete 2025']);
  assert.equal(grund['Einmalig 2025'].jahr, 2026);
  assert.match(grund['Einmalig 2025'].grund, /Einmalig am 03\.05\.2025/);
  assert.match(grund['Beginnt 2027'].grund, /Beginnt erst im 03\.2027/);
  assert.match(grund['Endete 2025'].grund, /Endet schon im 06\.2025/);
  assert.equal(a.andere.length, 3, 'andere bleibt die Liste aller Posten ohne Anteil');
});
test('Grund bei fehlendem Betrag, Betrag 0 und fehlendem Datum (reine Rechnung)', () => {
  const K = MM.Kosten, h = '2026-11-10';
  assert.equal(K.keinAnteilGrund({ betrag: 100, datum: '2026-02-01' }, 2026, h), null);
  assert.equal(K.keinAnteilGrund({ datum: '2026-02-01' }, 2026, h), 'Der Betrag fehlt.');
  assert.equal(K.keinAnteilGrund({ betrag: 0, datum: '2026-02-01' }, 2026, h), 'Der Betrag ist 0.');
  assert.equal(K.keinAnteilGrund({ betrag: 10 }, 2026, h), 'Das Datum fehlt.');
});
test('Fixkosten in mehreren Schritten über das Fahrzeug anlegen: danach sind alle noch da', async () => {
  const d = await neu();
  const fz = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'WM' })).id;
  const namen = ['Stellplatz', 'Versicherung', 'Steuer', 'HU', 'Gasprüfung'];
  for (const n of namen) {
    const r = await d.kostenAnlegen(fz, { gruppe: 'fix', bezeichnung: n, betrag: '100', datum: '2026-01-01', rhythmus: 'jaehrlich' });
    assert.ok(r.ok, JSON.stringify(r));
    /* zwischendurch ändern und den Kostenstamm speichern, wie über die Fahrzeugseite */
    await d.kostenAendern(r.id, { gruppe: 'fix', bezeichnung: n, betrag: '110', datum: '2026-01-01', rhythmus: 'jaehrlich' });
  }
  const a = await d.kostenAuswertung(fz, 2026);
  assert.deepEqual(a.posten.fix.map(x => x.aktuell.werte.bezeichnung).sort(), namen.slice().sort());
  assert.equal(a.ohneAnteil.fix.length, 0);
  assert.equal((await d.kostenListe(fz)).length, 5);
});
