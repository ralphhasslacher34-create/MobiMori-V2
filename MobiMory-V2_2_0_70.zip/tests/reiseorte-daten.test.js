'use strict';
/* 2.0.28, Schritt 8a: Reiseorte – Orte mit Position, Besuche, Frage nach der Ankunft, Plan, Auswertung, Sicherung. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/daten.js');
const MM = globalThis.MM;

/* feste Uhr: 3. November 2026, 12:00 Ortszeit */
const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const motor = (await d.komponenteAnlegen(boot, null, 'motor', { bezeichnung: 'Motor Backbord' })).id;
  const wmMotor = (await d.komponenteAnlegen(wm, null, 'motor', { bezeichnung: 'Motor' })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = n => arten.find(x => x.aktuell.werte.bezeichnung === n).objekt.id;
  return { d, boot, wm, anna, motor, wmMotor, artId };
}
const toern = (c, extra) => Object.assign({ bezeichnung: 'Sommertörn', artId: c.artId('Törn'), fahrzeugId: c.boot, vonDatum: '2026-07-01', bisDatum: '2026-07-10', verantwortlichId: c.anna }, extra || {});
const liegeplatz = { gruppe: 'fix', bezeichnung: 'Liegeplatz Heimathafen', kostenart: 'stellplatz', betrag: '2.400', rhythmus: 'jaehrlich', datum: '2026-01-01' };
const diesel = { gruppe: 'variabel', bezeichnung: 'Diesel', kostenart: 'treibstoff', betrag: '180,50', datum: '2026-07-05' };
const kerzen = { gruppe: 'instandhaltung', bezeichnung: 'Zündkerzen', kostenart: 'teile', betrag: '45', datum: '2026-09-01' };


const BAD = { bezeichnung: 'Stellplatz Bad Mergentheim', ortart: 'stellplatz', positionBreite: '49,4800', positionLaenge: '9,7700', ausstattung: ['strom', 'wasser'] };

async function mitAktivitaet(c, extra) { return (await c.d.aktivitaetAnlegen(toern(c, extra))).id; }
async function ankunft(c, aktId, art, breite, laenge, zeit) {
  await c.d.ereignisartenAusVorschlaegen();
  await c.d.tagesabschnitteVorbereiten(aktId);
  const tag = (await c.d.logbuchLaden(aktId)).abschnitte[0].objekt.id;
  const r = await c.d.ereignisAnlegen(tag, { artId: (await c.d.ereignisartenListe()).find(a => a.aktuell.werte.bezeichnung === art).objekt.id, datum: '2026-07-01', zeit: zeit || '12:00', breite: breite, laenge: laenge }, { nachtragen: true });
  assert.equal(r.ok, true, JSON.stringify(r));
  return r.id;
}

test('Orte mit Position: Komma erlaubt, beide oder keine, Süd und West, Standort ebenso', async () => {
  const c = await neu();
  const r = await c.d.ortAnlegen(BAD);
  assert.equal(r.ok, true);
  const w = (await c.d.ortLaden(r.id)).aktuell.werte;
  assert.equal(w.positionBreite, 49.48); assert.equal(w.positionLaenge, 9.77); assert.deepEqual(w.ausstattung, ['strom', 'wasser']); assert.equal(w.ortart, 'stellplatz');
  assert.ok((await c.d.ortAnlegen({ bezeichnung: 'X', positionBreite: '49,48' })).fehler.positionLaenge, 'nur eine Koordinate');
  assert.ok((await c.d.ortAnlegen({ bezeichnung: 'X', positionBreite: '95', positionLaenge: '1' })).fehler.positionBreite);
  assert.ok((await c.d.ortAnlegen({ bezeichnung: 'X', ortart: 'raumschiff' })).fehler.ortart);
  const sued = await c.d.ortAnlegen({ bezeichnung: 'Südhafen', positionBreite: 'S 33,9', positionLaenge: 'W 18,4' });
  assert.equal((await c.d.ortLaden(sued.id)).aktuell.werte.positionBreite, -33.9);
  const so = await c.d.standortAnlegen(r.id, { bezeichnung: 'Platz 3', positionBreite: '49,4801', positionLaenge: '9,7701', laenge: '8' });
  assert.equal(so.ok, true);
  assert.equal((await c.d.standortLaden(so.id)).aktuell.werte.laenge, 8, 'die Platzgröße bleibt');
  assert.equal((await c.d.ortAnlegen({ bezeichnung: 'Ohne' })).ok, true, 'alles freiwillig');
});

test('Alte Orte ohne die neuen Felder bleiben gültig, ändern erzeugt keinen Scheinunterschied', async () => {
  const c = await neu();
  const id = (await c.d.ortAnlegen({ bezeichnung: 'Heimat' })).id;
  assert.equal((await c.d.ortAendern(id, { bezeichnung: 'Heimat' })).geaendert, false);
  assert.equal((await c.d.ortAendern(id, { bezeichnung: 'Heimat', ausstattung: ['strom'] })).geaendert, true);
});

test('Ort zu einer Position und Ortsname-Vorschlag aus den Orten', async () => {
  const c = await neu();
  const id = (await c.d.ortAnlegen(BAD)).id;
  const t = await c.d.ortZuPosition(49.4803, 9.7701);
  assert.equal(t.ortId, id); assert.ok(t.abstand < 100);
  assert.equal(await c.d.ortZuPosition(50, 10), null);
  assert.equal((await c.d.ortNameVorschlag(49.4803, 9.7701)).name, 'Stellplatz Bad Mergentheim');
  assert.equal(await c.d.ortNameVorschlag(50, 10), null);
});

test('Gelernte Namen werden zu Orten mit Position, doppelte werden nicht noch einmal angelegt', async () => {
  const c = await neu();
  await c.d.ortAnlegen({ bezeichnung: 'Hafen Rovinj' });
  await c.d.speicher.speichern('einstellungen', { id: 'positionsnamen', punkte: [
    { name: 'Schleuse Gamsheim', breite: 48.7, laenge: 8.0, n: 2, zuletzt: 'x' }, { name: 'hafen rovinj', breite: 45.08, laenge: 13.6, n: 1, zuletzt: 'x' }] });
  assert.equal((await c.d.gelernteNamenOffen()).length, 1);
  assert.equal((await c.d.gelernteNamenUebernehmen()).angelegt, 1);
  assert.equal((await c.d.gelernteNamenOffen()).length, 0);
  const o = (await c.d.orteListe()).find(x => x.aktuell.werte.bezeichnung === 'Schleuse Gamsheim');
  assert.equal(o.aktuell.werte.positionBreite, 48.7);
  assert.equal((await c.d.gelernteNamenUebernehmen()).angelegt, 0);
});

test('Aktivität: Start, Ziel und Zwischenziele sind Orte, mit Namen geladen, ungültige werden abgelehnt', async () => {
  const c = await neu();
  const a = (await c.d.ortAnlegen({ bezeichnung: 'Heimathafen' })).id, z = (await c.d.ortAnlegen({ bezeichnung: 'Rovinj' })).id, m = (await c.d.ortAnlegen({ bezeichnung: 'Pula' })).id;
  assert.ok((await c.d.aktivitaetAnlegen(toern(c, { startOrtId: 'gibtsnicht' }))).fehler.startOrtId);
  const id = (await c.d.aktivitaetAnlegen(toern(c, { startOrtId: a, zielOrtId: z, zwischenzielIds: [m] }))).id;
  const x = await c.d.aktivitaetLaden(id);
  assert.equal(x.startOrt.name, 'Heimathafen'); assert.equal(x.zielOrt.name, 'Rovinj'); assert.deepEqual(x.zwischenziele.map(q => q.name), ['Pula']);
  await c.d.aktivitaetAendern(id, toern(c, { startOrtId: a, zielOrtId: m, zwischenzielIds: [] }));
  const y = await c.d.aktivitaetLaden(id);
  assert.equal(y.zielOrt.name, 'Pula');
  assert.equal(y.verlauf[0].aenderungen.find(u => u.key === 'zielOrtId').alt, 'Rovinj', 'Namen statt Kennungen im Verlauf');
  const ohne = await c.d.aktivitaetLaden((await mitAktivitaet(c)));
  assert.equal(ohne.startOrt, null); assert.deepEqual(ohne.zwischenziele, []);
});

test('Frage nach der Ankunft: Ort im Umfeld, Plan gegen Ist, Nicht jetzt fragt nicht wieder', async () => {
  const c = await neu();
  const ortId = (await c.d.ortAnlegen(BAD)).id;
  const aktId = await mitAktivitaet(c, { zielOrtId: ortId });
  await ankunft(c, aktId, 'Abfahrt', 49.0, 9.0, '09:00');
  const eId = await ankunft(c, aktId, 'Ankunft', 49.4802, 9.7701, '12:00');
  const lb = await c.d.logbuchLaden(aktId);
  const liste = []; lb.abschnitte.forEach(t => t.ereignisse.forEach(e => { if (e.art === 'ereignis') liste.push(e); }));
  const f = await c.d.reiseortFrage(aktId, liste);
  assert.equal(f.ereignisId, eId); assert.equal(f.vorschlag.ortId, ortId);
  assert.equal(f.plan.art, 'ziel'); assert.ok(f.plan.text.includes('geplantes Ziel'));
  assert.equal((await c.d.besuchUeberspringen(aktId, eId)).ok, true);
  assert.equal(await c.d.reiseortFrage(aktId, liste), null);
  assert.equal((await c.d.besuchListe({ aktivitaetId: aktId })).length, 0, 'übersprungen zählt nicht');
  assert.equal((await c.d.besuchListe({ aktivitaetId: aktId, mitUebersprungenen: true })).length, 1);
  assert.equal((await c.d.besuchAnlegen(aktId, { ereignisId: eId, ortId: ortId })).ok, false, 'es gibt schon einen Besuch zu dieser Ankunft');
});

test('Besuch anlegen: neuer Ort mit Position der Ankunft, Ausstattung, Betrag als variabler Posten mit Ort, Aktivität und Besuch', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const eId = await ankunft(c, aktId, 'Ankunft', 49.48, 9.77, '12:00');
  const r = await c.d.besuchAnlegen(aktId, { ereignisId: eId, neuerOrtName: 'Camping Taubertal', neuerOrtArt: 'camping', ausstattung: ['strom', 'dusche'], ausstattungSonst: 'Brötchen',
    betrag: '28,50', kostenart: 'unterwegs', grundlage: 'eingegeben', notiz: 'schön' });
  assert.equal(r.ok, true, JSON.stringify(r)); assert.equal(r.neuerOrt, true);
  const o = (await c.d.ortLaden(r.ortId)).aktuell.werte;
  assert.equal(o.bezeichnung, 'Camping Taubertal'); assert.equal(o.positionBreite, 49.48); assert.deepEqual(o.ausstattung, ['strom', 'dusche']); assert.equal(o.ortart, 'camping');
  const b = await c.d.besuchLaden(r.id);
  assert.equal(b.aktuell.werte.status, 'besucht'); assert.equal(b.aktuell.werte.datum, '2026-07-01'); assert.equal(b.aktuell.werte.zeit, '12:00'); assert.equal(b.ort.name, 'Camping Taubertal');
  assert.equal(b.kosten.length, 1);
  const k = b.kosten[0].aktuell.werte;
  assert.equal(k.betrag, 28.5); assert.equal(k.gruppe, 'variabel'); assert.equal(k.ortId, r.ortId); assert.equal(k.aktivitaetId, aktId); assert.equal(k.besuchId, r.id);
  assert.equal((await c.d.kostenAuswertung(c.boot, 2026)).gruppen.variabel.summe, 28.5, 'der Betrag zählt in der Kosten-Liste, es gibt keine zweite Buchführung');
  assert.equal((await c.d.ortAuswertung(r.ortId)).summe, 28.5);
});

test('Besuch an bekanntem Ort: Ausstattung gilt auch am Ort, Ort ohne Position bekommt die der Ankunft, zuletzt bezahlter Preis', async () => {
  const c = await neu();
  const ortId = (await c.d.ortAnlegen({ bezeichnung: 'Hafen Biograd', ortart: 'hafen' })).id;
  const aktId = await mitAktivitaet(c);
  const eId = await ankunft(c, aktId, 'Ankunft', 43.94, 15.44, '12:00');
  const r = await c.d.besuchAnlegen(aktId, { ereignisId: eId, ortId: ortId, ausstattung: ['strom', 'treibstoff'], betrag: '60', datum: '2026-07-01' });
  assert.equal(r.ok, true);
  const o = (await c.d.ortLaden(ortId)).aktuell.werte;
  assert.deepEqual(o.ausstattung, ['strom', 'treibstoff']); assert.equal(o.positionBreite, 43.94);
  assert.equal((await c.d.ortLaden(ortId)).verlauf.length, 2, 'die Änderung am Ort steht im Verlauf');
  const k = await c.d.besuchKontext(aktId, null);
  assert.equal(k.preise[ortId].betrag, 60);
  const zweiter = await c.d.besuchAnlegen(aktId, { ortId: ortId, datum: '2026-07-02' });
  assert.equal(zweiter.ok, true);
  assert.deepEqual((await c.d.ortLaden(ortId)).aktuell.werte.ausstattung, ['strom', 'treibstoff'], 'ohne Angabe bleibt die Ausstattung des Ortes');
  const a = await c.d.ortAuswertung(ortId);
  assert.equal(a.anzahl, 2); assert.equal(a.summe, 60); assert.equal(a.letzterPreis.betrag, 60);
});

test('Besuch anlegen: Fehler speichern nichts, Zukunft verboten, Ort Pflicht, doppelter Name, Standort muss zum Ort gehören', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const ortId = (await c.d.ortAnlegen({ bezeichnung: 'A' })).id, o2 = (await c.d.ortAnlegen({ bezeichnung: 'B' })).id;
  const st = (await c.d.standortAnlegen(o2, { bezeichnung: 'Platz 1' })).id;
  const f = async roh => (await c.d.besuchAnlegen(aktId, roh)).fehler || {};
  assert.ok((await f({})).ortId);
  assert.ok((await f({ ortId: 'gibtsnicht' })).ortId);
  assert.ok((await f({ neuerOrtName: 'a' })).neuerOrtName, 'Name gibt es schon (Groß- und Kleinschreibung egal)');
  assert.ok((await f({ ortId: ortId, datum: '2099-01-01' })).datum);
  assert.ok((await f({ ortId: ortId, standortId: st })).standortId);
  assert.ok((await f({ ortId: ortId, betrag: 'viel' })).betrag);
  assert.ok((await f({ ortId: ortId, betrag: '5', kostenart: 'versicherung' })).kostenart);
  assert.ok((await f({ neuerOrtName: 'C', positionBreite: '99', positionLaenge: '1' })).positionBreite);
  assert.equal((await c.d.besuchListe({})).length, 0);
  assert.equal((await c.d.orteListe()).length, 2, 'kein halb angelegter Ort');
  assert.equal((await c.d.kostenListe(c.boot)).length, 0);
  assert.equal((await c.d.besuchAnlegen('gibtsnicht', { ortId })).ok, false);
  await c.d.aktivitaetStornieren(aktId, 'x');
  assert.ok((await c.d.besuchAnlegen(aktId, { ortId })).fehler.allgemein, 'storniert');
});

test('Besuch ändern: Ort bleibt, Verlauf, Ausblenden und Einblenden, übersprungener hat nichts zu ändern', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const ortId = (await c.d.ortAnlegen({ bezeichnung: 'A' })).id;
  const id = (await c.d.besuchAnlegen(aktId, { ortId, datum: '2026-07-02', notiz: 'alt' })).id;
  assert.equal((await c.d.besuchAendern(id, { notiz: 'alt' })).geaendert, false);
  assert.equal((await c.d.besuchAendern(id, { notiz: 'neu', ausstattung: ['wlan'] })).geaendert, true);
  const b = await c.d.besuchLaden(id);
  assert.equal(b.aktuell.werte.notiz, 'neu'); assert.equal(b.aktuell.werte.ortId, ortId); assert.equal(b.verlauf.length, 2);
  assert.deepEqual((await c.d.ortLaden(ortId)).aktuell.werte.ausstattung || [], [], 'die Ausstattung beim Besuch ändert den Ort nicht');
  assert.ok((await c.d.besuchAendern(id, { datum: '' })).fehler.datum);
  assert.ok((await c.d.besuchAendern(id, { datum: '2099-01-01' })).fehler.datum);
  await c.d.besuchAusblenden(id, true);
  assert.equal((await c.d.ortAuswertung(ortId)).anzahl, 0, 'ausgeblendet zählt nicht');
  await c.d.besuchAusblenden(id, false);
  assert.equal((await c.d.ortAuswertung(ortId)).anzahl, 1);
  assert.ok((await c.d.besuchAendern('gibtsnicht', {})).fehler.allgemein);
  const aktId2 = await mitAktivitaet(c, { bezeichnung: 'Zweite', vonDatum: '2026-08-01', bisDatum: '2026-08-05' });
  const eId = await ankunft(c, aktId2, 'Ankunft', 1, 1, '10:00');
  const skip = (await c.d.besuchUeberspringen(aktId2, eId)).id;
  assert.ok((await c.d.besuchAendern(skip, { notiz: 'x' })).fehler.allgemein);
});

test('Betrag später an einen Besuch: übernimmt Ort und Aktivität, behält sie beim Ändern, nur variable Kosten', async () => {
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const ortId = (await c.d.ortAnlegen({ bezeichnung: 'A' })).id;
  const bid = (await c.d.besuchAnlegen(aktId, { ortId })).id;
  const r = await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'Strom', betrag: '4', besuchId: bid });
  assert.equal(r.ok, true);
  const w = (await c.d.kostenLaden(r.id)).aktuell.werte;
  assert.equal(w.ortId, ortId); assert.equal(w.aktivitaetId, aktId); assert.equal(w.besuchId, bid);
  const o2 = (await c.d.ortAnlegen({ bezeichnung: 'B' })).id;
  await c.d.kostenAendern(r.id, { gruppe: 'variabel', bezeichnung: 'Strom', betrag: '5', ortId: o2, datum: w.datum });
  const w2 = (await c.d.kostenLaden(r.id)).aktuell.werte;
  assert.equal(w2.ortId, ortId, 'der Ort eines Betrags aus einem Besuch bleibt'); assert.equal(w2.betrag, 5);
  assert.ok((await c.d.kostenAnlegen(c.boot, { gruppe: 'fix', bezeichnung: 'x', betrag: '1', rhythmus: 'monatlich', besuchId: bid })).fehler.gruppe);
  assert.ok((await c.d.kostenAnlegen(c.wm, { gruppe: 'variabel', bezeichnung: 'x', betrag: '1', besuchId: bid })).fehler.besuchId, 'anderes Fahrzeug');
  const frei = await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'Maut', betrag: '3', ortId: o2 });
  assert.equal((await c.d.kostenLaden(frei.id)).ortName, 'B');
  assert.ok((await c.d.kostenAnlegen(c.boot, { gruppe: 'fix', bezeichnung: 'x', betrag: '1', rhythmus: 'monatlich', ortId: o2 })).fehler.ortId);
  assert.ok((await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'x', betrag: '1', ortId: 'gibtsnicht' })).fehler.ortId);
});

test('Auswertung pro Reise: Kosten nach Art, Plan gegen Ist, Orte', async () => {
  const c = await neu();
  const z = (await c.d.ortAnlegen({ bezeichnung: 'Ziel' })).id, m = (await c.d.ortAnlegen({ bezeichnung: 'Mitte' })).id, u = (await c.d.ortAnlegen({ bezeichnung: 'Ungeplant' })).id;
  const aktId = await mitAktivitaet(c, { zielOrtId: z, zwischenzielIds: [m] });
  await c.d.besuchAnlegen(aktId, { ortId: u, datum: '2026-07-02', betrag: '20' });
  await c.d.kostenAnlegen(c.boot, { gruppe: 'variabel', bezeichnung: 'Diesel', kostenart: 'treibstoff', betrag: '100', aktivitaetId: aktId });
  const r = await c.d.reiseAuswertung(aktId);
  assert.equal(r.summe, 120); assert.equal(r.nachArt.length, 2); assert.equal(r.nachArt[0].kostenart, 'treibstoff');
  assert.equal(r.anzahlBesuche, 1); assert.equal(r.zielErreicht, false);
  assert.deepEqual(r.plan.map(x => [x.name, x.besucht]), [['Mitte', false], ['Ziel', false]]);
  assert.deepEqual(r.ungeplant.map(x => x.name), ['Ungeplant']);
  assert.equal(r.besuche[0].aktuell.werte.geplant, 'nein');
  await c.d.besuchAnlegen(aktId, { ortId: z, datum: '2026-07-03' });
  const r2 = await c.d.reiseAuswertung(aktId);
  assert.equal(r2.zielErreicht, true);
  assert.equal(await c.d.reiseAuswertung('gibtsnicht'), null);
});

test('Sicherung: Besuche und Position kommen samt Verweisen wieder, alte Sicherung ohne die Tabelle lässt sich einspielen', async () => {
  assert.equal(MM.Speicher.DB_VERSION, 16);
  assert.ok(MM.Speicher.TABELLEN.includes('besuche'));
  const c = await neu();
  const aktId = await mitAktivitaet(c);
  const r = await c.d.besuchAnlegen(aktId, { neuerOrtName: 'Camping', positionBreite: '49,5', positionLaenge: '9,5', betrag: '12' });
  const s = await c.d.sicherungErzeugen({ mitDateien: false });
  assert.equal(s.zahlen.besuche, 1);
  const b = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => JETZT });
  await b.starten();
  const g = await b.sicherungLesen(s.bytes, '');
  await b.sicherungEinspielen(g);
  const x = await b.besuchLaden(r.id);
  assert.equal(x.ort.name, 'Camping'); assert.equal(x.kosten.length, 1);
  assert.equal((await b.ortAuswertung(r.ortId)).summe, 12);
  const alt = await c.d.sicherungLesen(s.bytes, '');
  delete alt.kopf.tabellen.besuche; delete alt.kopf.zaehlung.besuche;
  const b2 = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => JETZT });
  await b2.starten();
  await b2.sicherungEinspielen(alt);
  assert.equal((await b2.besuchListe({})).length, 0);
});
