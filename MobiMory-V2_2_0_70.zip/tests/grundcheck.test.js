'use strict';
/* Schritt 11b (2.0.40): Grundcheck, die reinen Regeln. */
const test = require('node:test');
const assert = require('node:assert/strict');

['version', 'fahrzeugarten', 'komponenten', 'orte', 'reisecheck', 'grundcheck'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const G = MM.Grundcheck;

const QUELLE = { titel: 'FZV', url: 'https://amt.example/fzv', herausgeber: 'BMDV', amtlich: true, stand: '2026-05-12' };
const anf = (requirement, proofKey, extra) => Object.assign({ id: 'r' + Math.random(), bereich: 'Fahrzeug', kategorie: 'Pflicht', subjekt: 'vehicle', subjektArt: 'Fahrzeug', verkehr: 'Strasse',
  anforderung: requirement, nachweisArt: proofKey, status: 'Prüfen', beleg: '', erklaerung: '', vertrauen: 'hoch', widerspruch: false, quellen: [QUELLE] }, extra || {});

test('Zeile lesen: „Name | Menge | je Fahrzeug oder je Person | Erklärung“, alles andere wird nicht geraten', () => {
  assert.deepEqual(G.zeileLesen('Warnweste | 1 | je Person | Pflicht im Auto'), { name: 'Warnweste', menge: 1, bezug: 'person', erklaerung: 'Pflicht im Auto' });
  assert.deepEqual(G.zeileLesen(' Feuerlöscher | 2 | JE FAHRZEUG '), { name: 'Feuerlöscher', menge: 2, bezug: 'fahrzeug', erklaerung: '' });
  assert.equal(G.zeileLesen('Warnweste ist Pflicht'), null);
  assert.equal(G.zeileLesen('Warnweste | ein | je Person | x'), null);
  assert.equal(G.zeileLesen('Warnweste | 0 | je Person | x'), null);
  assert.equal(G.zeileLesen('Warnweste | 1 | pro Kopf | x'), null);
  assert.equal(G.zeileLesen(' | 1 | je Person | x'), null);
  assert.equal(G.zeileLesen('A | 1 | je Person | Erklärung | mit Strich').erklaerung, 'Erklärung | mit Strich');
});

test('Anfrage: Heimatland als Gebiet, keine Personen, keine Tiere, Aufgabe und Format stehen drin', () => {
  const fz = { name: 'Mein Wohnmobil', artName: 'Wohnmobil', welt: 'land', werte: { marke: 'Fiat', kennzeichen: 'LB-XY 123', fin: 'ZFA1234567890', plaetze: 4 }, komponenten: [{ name: 'Warndreieck', anzahl: 1 }], nachweise: [] };
  const b = G.anfrageBauen({ heute: '2026-11-05', land: 'Deutschland', fahrzeug: fz });
  assert.equal(b.ok, true);
  const a = b.anfrage;
  assert.equal(a.trip.checkMode, 'free'); assert.equal(a.trip.areas[0].name, 'Deutschland');
  assert.equal(a.trip.start, '2026-11-05T00:00:00'); assert.deepEqual(a.persons, []); assert.deepEqual(a.animals, []);
  assert.equal(a.vehicle.seats, 4); assert.equal(a.vehicle.hasRegistrationIdentifier, true); assert.equal(a.vehicle.hasVIN, true);
  assert.deepEqual(a.vehicle.components, [{ name: 'Warndreieck', count: 1 }]);
  assert.ok(a.basicCheck.format.includes('Name | Menge | je Fahrzeug')); assert.equal(a.basicCheck.homeCountry, 'Deutschland');
  const text = JSON.stringify(a);
  ['Mein Wohnmobil', 'LB-XY 123', 'ZFA1234567890'].forEach(n => assert.equal(text.includes(n), false, n + ' darf nicht hinausgehen'));
  assert.ok(G.vorschau(a).some(z => z.includes('Heimatland: Deutschland'))); assert.ok(G.vorschau(a).some(z => z.includes('Keine Besatzung')));
});

test('Anfrage: ohne Heimatland oder Fahrzeug kein Check, mit klarem Hinweis', () => {
  const fz = { name: 'x', welt: 'land', werte: {}, komponenten: [], nachweise: [] };
  const a = G.anfrageBauen({ heute: '2026-11-05', land: '', fahrzeug: fz });
  assert.equal(a.ok, false); assert.ok(a.fehler[0].includes('Heimatland'));
  assert.equal(G.anfrageBauen({ heute: '2026-11-05', land: 'Deutschland', fahrzeug: null }).ok, false);
  assert.equal(G.anfrageBauen({ heute: '', land: 'Deutschland', fahrzeug: fz }).ok, false);
});

test('Punkte lesen: nur Fahrzeug, nur lesbare Zeilen, „Nicht relevant“ fällt weg, doppelte werden einmal gezählt, Stand aus der Quelle oder dem Dienst', () => {
  const erg = { anforderungen: [
    anf('Warnweste | 1 | je Person | im Auto', 'Ausrüstung'),
    anf('Warnweste | 1 | je Person | doppelt', 'Ausrüstung'),
    anf('Zulassungsbescheinigung Teil 1 | 1 | je Fahrzeug | mitführen', 'Papier', { quellen: [Object.assign({}, QUELLE, { stand: '' })] }),
    anf('Feuerlöscher | 1 | je Fahrzeug | nicht Pflicht', 'Ausrüstung', { status: 'Nicht relevant' }),
    anf('Führerschein | 1 | je Person | Person', 'Papier', { subjekt: 'P1', subjektArt: 'Person' }),
    anf('Es gibt noch weitere Regeln im Ausland', 'Hinweis'),
    anf('Warndreieck | 1 | je Fahrzeug | x', 'sonstiges')
  ] };
  const r = G.punkteLesen(erg, { recherchiertAm: '2026-11-05T11:00:00Z' });
  assert.deepEqual(r.punkte.map(p => p.name), ['Warnweste', 'Zulassungsbescheinigung Teil 1']);
  assert.equal(r.punkte[0].stand, '2026-05-12'); assert.equal(r.punkte[1].stand, '2026-11-05');
  assert.equal(r.punkte[0].art, 'ausruestung'); assert.equal(r.punkte[1].art, 'papier');
  assert.deepEqual(r.nichtLesbar.map(x => x.text), ['Es gibt noch weitere Regeln im Ausland', 'Warndreieck | 1 | je Fahrzeug | x']);
});

test('Papiere: „Teil 1“ passt auf „Teil I (Fahrzeugschein)“, aber nie auf „Teil II“', () => {
  assert.equal(G.papierPasst('Zulassungsbescheinigung Teil 1', 'Zulassungsbescheinigung Teil I (Fahrzeugschein)'), true);
  assert.equal(G.papierPasst('Zulassungsbescheinigung Teil 2', 'Zulassungsbescheinigung Teil II (Fahrzeugbrief)'), true);
  assert.equal(G.papierPasst('Zulassungsbescheinigung Teil 1', 'Zulassungsbescheinigung Teil II (Fahrzeugbrief)'), false);
  assert.equal(G.papierPasst('Zulassungsbescheinigung Teil I', 'Zulassungsbescheinigung Teil I (Fahrzeugschein)'), true);
  assert.equal(G.papierPasst('Versicherungsnachweis', 'Zulassungsbescheinigung Teil I'), false);
  assert.equal(G.papierPasst('', 'x'), false);
});

const pt = (name, menge, bezug, art) => ({ id: name, name, menge, bezug, art: art || 'ausruestung', erklaerung: '', kategorie: 'Pflicht', quellen: [QUELLE], stand: '2026-05-12', vertrauen: 'hoch', widerspruch: false });
const verg = (punkte, extra) => G.vergleichen(Object.assign({ punkte, komponenten: [], nachweise: [], plaetze: null, fahrzeugId: 'f1' }, extra || {}));

test('Vergleich Ausrüstung: vorhanden, zu wenig, fehlt, nach Dringlichkeit sortiert, mit Link und vorbelegter Menge', () => {
  const r = verg([pt('Warndreieck', 1, 'fahrzeug'), pt('Feuerlöscher', 1, 'fahrzeug'), pt('Warnweste', 1, 'person')],
    { komponenten: [{ name: 'Warndreieck', anzahl: 1 }, { name: 'Warnweste vorn', anzahl: 1 }], plaetze: 4 });
  assert.deepEqual(r.map(z => z.punkt.name + ':' + z.status), ['Feuerlöscher:fehlt', 'Warnweste:zu_wenig', 'Warndreieck:vorhanden']);
  const fl = r[0], ww = r[1];
  assert.equal(fl.soll, 1); assert.equal(fl.ist, 0);
  assert.equal(fl.link.href, '#/fahrzeug/f1/komponente/neu?name=Feuerl%C3%B6scher&anzahl=1');
  assert.equal(ww.soll, 4); assert.equal(ww.ist, 1); assert.ok(ww.text.includes('Soll ist 4 (1 je Person, 4 Plätze)'));
  assert.equal(ww.link.href, '#/fahrzeug/f1/komponente/neu?name=Warnweste&anzahl=4');
  assert.equal(r[2].link, null);
});

test('Vergleich Ausrüstung: je Person ohne Plätze ist „unklar“ mit Link zum Fahrzeug, nicht „fehlt“ und nicht geraten', () => {
  const r = verg([pt('Rettungsweste', 1, 'person')], { komponenten: [{ name: 'Rettungsweste', anzahl: 3 }] });
  assert.equal(r[0].status, 'unklar'); assert.equal(r[0].soll, null); assert.ok(r[0].text.includes('Plätze'));
  assert.equal(r[0].link.href, '#/fahrzeug/f1/aendern');
});

test('Vergleich Ausrüstung: Zusätze in Klammern stören die Suche nicht, größere Menge als Soll ist in Ordnung', () => {
  const r = verg([pt('Verbandskasten (DIN 13164)', 1, 'fahrzeug')], { komponenten: [{ name: 'Verbandskasten', anzahl: 2 }] });
  assert.equal(r[0].status, 'vorhanden'); assert.equal(r[0].ist, 2);
  assert.equal(G.suchbegriff('Verbandskasten (DIN 13164)'), 'Verbandskasten');
});

test('Vergleich Papiere: fehlt, unklar ohne Foto, vorhanden mit Foto', () => {
  const p1 = pt('Zulassungsbescheinigung Teil 1', 1, 'fahrzeug', 'papier'), p2 = pt('Zulassungsbescheinigung Teil 2', 1, 'fahrzeug', 'papier');
  const r = verg([p1, p2], { nachweise: [{ artName: 'Zulassungsbescheinigung Teil I (Fahrzeugschein)', gescannt: false }] });
  assert.deepEqual(r.map(z => z.punkt.name + ':' + z.status), ['Zulassungsbescheinigung Teil 2:fehlt', 'Zulassungsbescheinigung Teil 1:unklar']);
  assert.equal(r[0].link.href, '#/fahrzeug/f1/nachweis/neu'); assert.equal(r[1].link, null);
  const ok = verg([p1], { nachweise: [{ artName: 'Zulassungsbescheinigung Teil I (Fahrzeugschein)', gescannt: true }] });
  assert.equal(ok[0].status, 'vorhanden');
});

test('Zusammenfassung und Zählzeile', () => {
  const r = verg([pt('A', 1, 'fahrzeug'), pt('B', 1, 'fahrzeug'), pt('C', 2, 'fahrzeug')], { komponenten: [{ name: 'A', anzahl: 1 }, { name: 'C', anzahl: 1 }] });
  const z = G.zusammenfassung(r);
  assert.deepEqual(z, { fehlt: 1, zu_wenig: 1, unklar: 0, vorhanden: 1 });
  assert.equal(G.zaehlText(z), '1 vorhanden · 1 zu wenig · 1 fehlt');
  assert.equal(G.zaehlText({ fehlt: 2, zu_wenig: 0, unklar: 1, vorhanden: 0 }), '2 fehlen · 1 unklar');
  assert.equal(G.zaehlText(G.zusammenfassung([])), 'Keine Punkte');
});

test('Der Reisecheck baut sein Fahrzeug weiter wie vorher (herausgelöster Fahrzeug-Block)', () => {
  const fz = { name: 'B', artName: 'Boot', welt: 'wasser', werte: { marke: 'Bavaria', laenge: 9.5, registriernummer: 'X' }, komponenten: [{ name: 'Anker', anzahl: 2 }], nachweise: [] };
  const v = MM.Reisecheck.fahrzeugBlock(fz);
  assert.equal(v.type, 'Wasserfahrzeug'); assert.equal(v.lengthM, 9.5); assert.equal(v.hasRegistrationIdentifier, true); assert.deepEqual(v.components, [{ name: 'Anker', count: 2 }]);
  assert.equal(v.seats, null);
});
