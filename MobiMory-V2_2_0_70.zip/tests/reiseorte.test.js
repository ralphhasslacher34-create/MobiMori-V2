'use strict';
/* 2.0.28, Schritt 8a: Reiseorte – Beschreibung und Rechnung (ohne Speicher). */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/hilfen.js');
require('../js/fahrzeugarten.js');
require('../js/logbuch.js');
require('../js/motoren.js');
require('../js/kosten.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/reiseorte.js');
const MM = globalThis.MM;
const R = MM.Reiseorte;

const ort = (id, name, b, l, extra) => ({ objekt: { id }, aktuell: { werte: Object.assign({ bezeichnung: name, positionBreite: b, positionLaenge: l, ausgeblendet: 'nein' }, extra || {}) } });
const standort = (id, ortId, name, b, l) => ({ objekt: { id, ortId }, aktuell: { werte: { bezeichnung: name, positionBreite: b, positionLaenge: l } } });

test('Orte haben Art, Position und Ausstattung; teilbar sind nur Name, Art, Land, Position, Ausstattung', () => {
  const keys = MM.Orte.ortFelder().map(f => f.key);
  ['ortart', 'positionBreite', 'positionLaenge', 'ausstattung', 'ausstattungSonst'].forEach(k => assert.ok(keys.includes(k), k));
  assert.deepEqual(MM.Orte.teilbareOrtFelder().sort(), ['ausstattung', 'ausstattungSonst', 'land', 'ortart', 'positionBreite', 'positionLaenge']);
  const aus = R.teilbarAuszug({ bezeichnung: 'Hafen', ortart: 'hafen', notiz: 'privat', telefon: '123', adresse: 'x', ausstattung: ['strom'] });
  assert.equal(aus.bezeichnung, 'Hafen'); assert.deepEqual(aus.ausstattung, ['strom']);
  ['notiz', 'telefon', 'adresse', 'ansprechpartner'].forEach(k => assert.ok(!(k in aus), k + ' bleibt privat'));
});

test('Standort: Platzgröße behält ihre Schlüssel, die Position hat eigene', () => {
  const keys = MM.Orte.standortFelder().map(f => f.key);
  ['laenge', 'breite', 'positionBreite', 'positionLaenge'].forEach(k => assert.ok(keys.includes(k)));
});

test('Ort im Umfeld: der nächste gewinnt, außerhalb von 300 m kein Treffer, ausgeblendete zählen nicht', () => {
  const k = R.kandidaten([ort('o1', 'Camping Nord', 49.4800, 9.7700), ort('o2', 'Camping Süd', 49.4830, 9.7700), ort('o3', 'Aus', 49.4801, 9.7701, { ausgeblendet: 'ja' }), ort('o4', 'Ohne', null, null)], []);
  assert.equal(k.length, 2);
  assert.equal(R.naechster(k, 49.4801, 9.7700).ortId, 'o1');
  assert.equal(R.naechster(k, 49.4829, 9.7700).ortId, 'o2');
  assert.equal(R.naechster(k, 49.4900, 9.7700), null, 'weit weg');
  assert.equal(R.naechster(k, null, null), null);
  assert.equal(R.ORT_RADIUS_M, 300);
});

test('Standorte mit Position werden als „Ort, Standort“ erkannt', () => {
  const k = R.kandidaten([ort('o1', 'Hafen Biograd', 43.94, 15.44)], [standort('s1', 'o1', 'Liegeplatz 12', 43.9402, 15.4402)]);
  const t = R.naechster(k, 43.9402, 15.4402);
  assert.equal(t.standortId, 's1'); assert.equal(t.ortId, 'o1'); assert.equal(t.name, 'Hafen Biograd, Liegeplatz 12');
});

test('Plan gegen Ist: Ziel, Zwischenziel, Start, nicht geplant, kein Plan', () => {
  const plan = { startOrtId: 'a', zielOrtId: 'z', zwischenzielIds: ['m'] };
  assert.equal(R.planVergleich(plan, 'z'), 'ziel');
  assert.equal(R.planVergleich(plan, 'm'), 'zwischenziel');
  assert.equal(R.planVergleich(plan, 'a'), 'start');
  assert.equal(R.planVergleich(plan, 'x'), 'nein');
  assert.equal(R.planVergleich({ startOrtId: 'a', zielOrtId: 'a', zwischenzielIds: [] }, 'a'), 'ziel', 'Rundreise: Ziel vor Start');
  assert.equal(R.planVergleich({ startOrtId: null, zielOrtId: null, zwischenzielIds: [] }, 'x'), null);
  assert.ok(R.planText('ziel').includes('geplantes Ziel'));
});

const ev = (id, art, zp, extra) => Object.assign({ id, artName: art, zeitpunkt: zp, datum: zp.slice(0, 10), zeit: zp.slice(11), ausgeblendet: false }, extra || {});
const JETZT = '2026-07-05T18:00';

test('Frage nach der Ankunft: nur nach dem letzten Ziel-Ereignis, nie wenn danach weitergefahren wurde oder schon beantwortet', () => {
  const liste = [ev('e1', 'Abfahrt', '2026-07-05T09:00'), ev('e2', 'Ankunft', '2026-07-05T12:00')];
  assert.equal(R.besuchFrage(liste, [], JETZT).id, 'e2');
  assert.equal(R.besuchFrage(liste, [{ ereignisId: 'e2' }], JETZT), null, 'beantwortet oder übersprungen');
  assert.equal(R.besuchFrage(liste.concat([ev('e3', 'Abfahrt', '2026-07-05T14:00')]), [], JETZT), null, 'schon weitergefahren');
  assert.equal(R.besuchFrage([ev('a', 'Anlegen', '2026-07-05T10:00')], [], JETZT).artName, 'Anlegen');
  assert.equal(R.besuchFrage([ev('a', 'Anker werfen', '2026-07-05T10:00')], [], JETZT).artName, 'Anker werfen');
  assert.equal(R.besuchFrage([ev('n', 'Notiz', '2026-07-05T10:00')], [], JETZT), null);
  assert.equal(R.besuchFrage([ev('a', 'Ankunft', '2026-07-05T10:00', { ausgeblendet: true })], [], JETZT), null);
  assert.equal(R.besuchFrage([ev('a', 'Ankunft', '2026-07-06T10:00')], [], JETZT), null, 'noch nicht passiert');
  assert.equal(R.besuchFrage([], [], JETZT), null);
});

const bw = (ortId, datum, extra) => ({ werte: Object.assign({ status: 'besucht', ortId, datum, ausgeblendet: 'nein', geplant: null }, extra || {}) });
const kw = (ortId, betrag, extra) => ({ werte: Object.assign({ ortId, betrag, kostenart: 'unterwegs', datum: '2026-07-05', grundlage: 'eingegeben', ausgeblendet: 'nein' }, extra || {}) });

test('Auswertung pro Ort: wie oft, zuletzt dort, was bezahlt, zuletzt bezahlt, nach Art', () => {
  const a = R.ortAuswertung([bw('o', '2026-07-05'), bw('o', '2025-06-01'), bw('o', '2024-01-01', { status: 'uebersprungen' }), bw('o', '2023-01-01', { ausgeblendet: 'ja' })],
    [kw('o', 25, { datum: '2025-06-01' }), kw('o', 30, { datum: '2026-07-05', grundlage: 'geschaetzt' }), kw('o', 5, { kostenart: 'gebuehren' }), kw('o', 99, { ausgeblendet: 'ja' })]);
  assert.equal(a.anzahl, 2); assert.equal(a.letzter, '2026-07-05'); assert.equal(a.erster, '2025-06-01');
  assert.equal(a.summe, 60); assert.equal(a.anzahlPosten, 3);
  assert.equal(a.grundlage, 'gemischt');
  assert.equal(a.letzterPreis.betrag, 30);
  assert.equal(a.nachArt[0].summe, 55); assert.equal(a.nachArt[1].summe, 5);
});

test('Auswertung ohne Besuche und Kosten: alles leer, nichts stürzt ab', () => {
  const a = R.ortAuswertung([], []);
  assert.equal(a.anzahl, 0); assert.equal(a.summe, 0); assert.equal(a.letzterPreis, null); assert.equal(a.letzter, null);
});

test('Auswertung pro Reise: Summe nach Art, Orte, Plan gegen Ist, nicht geplante Besuche, Ziel erreicht', () => {
  const r = R.reiseAuswertung({
    kosten: [kw('a', 20, { kostenart: 'treibstoff' }), kw('b', 40), kw(null, 10, { kostenart: 'gebuehren' })],
    besuche: [bw('a', '2026-07-01', { zeit: '10:00', geplant: 'start' }), bw('b', '2026-07-02', { zeit: '12:00', geplant: 'nein' }), bw('b', '2026-07-03')],
    plan: { startOrtId: 'a', zielOrtId: 'z', zwischenzielIds: ['m'] }, orteNamen: { a: 'Heimat', b: 'Camping B', z: 'Ziel', m: 'Mitte' } });
  assert.equal(r.summe, 70); assert.equal(r.anzahlPosten, 3);
  assert.equal(r.nachArt[0].label.length > 0, true);
  assert.equal(r.anzahlOrte, 2); assert.equal(r.anzahlBesuche, 3);
  assert.equal(r.orte[1].name, 'Camping B'); assert.equal(r.orte[1].besuche, 2); assert.equal(r.orte[1].summe, 40);
  assert.equal(r.ohneOrt, 10);
  assert.deepEqual(r.plan.map(x => [x.art, x.besucht]), [['start', true], ['zwischenziel', false], ['ziel', false]]);
  assert.deepEqual(r.ungeplant.map(o => o.name), ['Camping B']);
  assert.equal(r.zielErreicht, false);
  assert.equal(R.reiseAuswertung({ kosten: [], besuche: [], plan: {}, orteNamen: {} }).zielErreicht, null);
});

test('Ausstattung als Text, mit Beschriftung statt Kennung', () => {
  assert.equal(R.ausstattungText(['strom', 'wasser'], 'Brötchenservice'), 'Strom, Frischwasser, Brötchenservice');
  assert.equal(R.ausstattungText([], ''), null);
  assert.equal(MM.Hilfen.wert({ typ: 'mehrfach', optionen: MM.Orte.AUSSTATTUNG }, ['wlan']), 'WLAN');
  assert.equal(MM.Hilfen.wert({ typ: 'text', koordinate: 'breite' }, 49.48), '49,48000');
});
