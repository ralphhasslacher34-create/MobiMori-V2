'use strict';
/* Schritt 11d (2.0.42): Revier als Auswahlliste, Ort als unterste Ebene (eigene Regeln am Ort). */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren',
  'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'reiseorte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const G = MM.Gebiete;

/* ---------- Regeln (ohne Speicher) ---------- */
const gebiet = (id, name, ebene, eltern, extra) => ({ objekt: { id }, aktuell: { werte: Object.assign({ bezeichnung: name, ebene: ebene || null, elternId: eltern || null }, extra || {}) } });
const GEBIETE = [
  gebiet('de', 'Deutschland', 'land'), gebiet('bw', 'Baden-Württemberg', 'region', 'de'), gebiet('bb', 'Landkreis Böblingen', 'kreis', 'bw'),
  gebiet('rh', 'Rhein', 'revier', 'de'), gebiet('og1', 'Hafen Kehl', 'ort', 'de', { ortId: 'o1' })
];
const ort = (id, name, w) => ({ id, name, werte: w });

test('Ort als unterste Ebene: hängt hinten an die Kette, aber nur bei dem Ort, der eigene Regeln hat', () => {
  const orte = [ort('o1', 'Hafen Kehl', { gebietId: 'bb', revierId: 'rh' }), ort('o2', 'Anleger', { gebietId: 'bb', revierId: 'rh' })];
  const w = G.kettenAusOrten({ gebiete: GEBIETE, welt: 'wasser', orte });
  assert.deepEqual(w.ketten.map(k => k.map(g => g.name)), [['Deutschland', 'Rhein', 'Hafen Kehl'], ['Deutschland', 'Rhein']]);
  assert.deepEqual(w.ketten[0].map(g => g.ebene), ['land', 'revier', 'ort']);
  assert.deepEqual(w.ids, ['de', 'rh', 'og1']);
  const l = G.kettenAusOrten({ gebiete: GEBIETE, welt: 'land', orte });
  assert.deepEqual(l.ketten.map(k => k.map(g => g.name)), [['Deutschland', 'Baden-Württemberg', 'Landkreis Böblingen', 'Hafen Kehl'], ['Deutschland', 'Baden-Württemberg', 'Landkreis Böblingen']]);
  assert.deepEqual(l.ids, ['de', 'bw', 'bb', 'og1']);
});

test('Ort als unterste Ebene: Luftfahrzeug zählt nur das Land, ein ausgeblendetes Ort-Gebiet und ein ungeprüfter Ort zählen nicht', () => {
  const orte = [ort('o1', 'Hafen Kehl', { gebietId: 'bb', revierId: 'rh' })];
  assert.deepEqual(G.kettenAusOrten({ gebiete: GEBIETE, welt: 'luft', orte }).ketten.map(k => k.map(g => g.name)), [['Deutschland']]);
  const aus = GEBIETE.slice(0, 4).concat([gebiet('og1', 'Hafen Kehl', 'ort', 'de', { ortId: 'o1', ausgeblendet: 'ja' })]);
  assert.deepEqual(G.kettenAusOrten({ gebiete: aus, welt: 'wasser', orte }).ketten.map(k => k.map(g => g.name)), [['Deutschland', 'Rhein']]);
  const ohne = G.kettenAusOrten({ gebiete: GEBIETE, welt: 'wasser', orte: [ort('o1', 'Hafen Kehl', {})] });
  assert.deepEqual(ohne.ketten, []); assert.deepEqual(ohne.ohneGebiet, ['Hafen Kehl']);
  /* Fehlt das Revier, bleibt der Hinweis, auch wenn der Ort eigene Regeln hat */
  const keinRevier = G.kettenAusOrten({ gebiete: GEBIETE, welt: 'wasser', orte: [ort('o1', 'Hafen Kehl', { gebietId: 'bb' })] });
  assert.deepEqual(keinRevier.ohneRevier, ['Hafen Kehl']);
});

test('Das Gebiet eines Ortes wird über die Ort-Nummer gefunden', () => {
  assert.equal(G.ortGebiet(GEBIETE, 'o1').objekt.id, 'og1');
  assert.equal(G.ortGebiet(GEBIETE, 'o2'), null);
  assert.equal(G.ortGebiet(GEBIETE, null), null);
  assert.equal(G.ortGebiet(null, 'o1'), null);
});

/* ---------- Datenschicht ---------- */
const JETZT = new Date(2026, 10, 5, 12, 0, 0).toISOString();
const item = (id, name, lat, lon, adr) => ({ osm_type: 'node', osm_id: id, name, lat: String(lat), lon: String(lon), address: Object.assign({ country: 'Deutschland', country_code: 'de', state: 'Baden-Württemberg' }, adr) });
const TREFFER = {
  sersheim: item(3, 'Sersheim', 48.9561, 9.0546, { village: 'Sersheim', county: 'Landkreis Ludwigsburg' }),
  boeblingen: item(1, 'Eutingen', 48.5651, 8.8951, { village: 'Eutingen', municipality: 'Gäufelden', county: 'Landkreis Böblingen' }),
  kroatien: { osm_type: 'node', osm_id: 4, name: 'Biograd na Moru', lat: '43.9387', lon: '15.4443', address: { town: 'Biograd na Moru', county: 'Zadarska županija', country: 'Kroatien', country_code: 'hr' } }
};
const treffer = key => MM.Ortssuche.kandidaten([TREFFER[key]])[0];

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString(), holeJson: () => Promise.resolve([]) });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = n => arten.find(x => x.aktuell.werte.bezeichnung === n).objekt.id;
  const sbf = (await d.nachweisartAnlegen({ bezeichnung: 'Sportbootführerschein', gehoertZu: 'person', hatAblauf: 'nein' })).id;
  const funk = (await d.nachweisartAnlegen({ bezeichnung: 'Funkzeugnis', gehoertZu: 'person', hatAblauf: 'nein' })).id;
  return { d, boot, wm, anna, artId, sbf, funk };
}
const akt = (c, extra) => Object.assign({ bezeichnung: 'Törn', artId: c.artId('Törn'), fahrzeugId: c.boot, vonDatum: '2026-12-01', bisDatum: '2026-12-10', verantwortlichId: c.anna }, extra || {});
const ortGebiete = async d => (await d.gebieteListe()).filter(x => x.aktuell.werte.ebene === 'ort');
const regel = c => ({ bezeichnung: 'Funk am Hafen', fahrzeugArten: ['boot'], artIds: [c.funk] });

test('Eigene Regel am Ort: erst mit der ersten Regel entsteht das Gebiet des Ortes, danach wird es wiederverwendet', async () => {
  const c = await neu(); const d = c.d;
  const o = (await d.ortAusTreffer(treffer('sersheim'))).id;
  assert.deepEqual(await ortGebiete(d), [], 'ohne Regel gibt es kein Ort-Gebiet');
  const r1 = await d.ortRegelAnlegen(o, regel(c));
  assert.equal(r1.ok, true); assert.equal(r1.gebietNeu, true);
  const og = await ortGebiete(d);
  assert.equal(og.length, 1);
  const w = og[0].aktuell.werte, land = (await d.ortLaden(o)).gebietPfad[0];
  assert.equal(w.bezeichnung, 'Sersheim'); assert.equal(w.ortId, o); assert.equal(w.elternId, land.id); assert.equal(w.herkunft, 'eigen');
  const r2 = await d.ortRegelAnlegen(o, { bezeichnung: 'Zweite', fahrzeugArten: [], artIds: [c.sbf] });
  assert.equal(r2.ok, true); assert.equal(r2.gebietNeu, false); assert.equal(r2.gebietId, r1.gebietId);
  assert.equal((await ortGebiete(d)).length, 1);
  const x = await d.ortLaden(o);
  assert.equal(x.eigeneRegeln.length, 2); assert.equal(x.ortGebiet.id, r1.gebietId);
  assert.equal((await d.regelnListe(r1.gebietId)).length, 2);
});

test('Eigene Regel am Ort: ohne geprüften Ort oder mit fehlerhafter Regel wird nichts gespeichert', async () => {
  const c = await neu(); const d = c.d;
  const frei = (await d.ortAnlegen({ bezeichnung: 'Irgendwo' })).id;
  const a = await d.ortRegelAnlegen(frei, regel(c));
  assert.equal(a.ok, false); assert.ok(a.fehler.allgemein.includes('geprüft'));
  const geprueft = (await d.ortAusTreffer(treffer('sersheim'))).id;
  const b = await d.ortRegelAnlegen(geprueft, { bezeichnung: '', artIds: [] });
  assert.equal(b.ok, false); assert.ok(b.fehler.bezeichnung);
  assert.equal((await d.ortRegelAnlegen('gibt-es-nicht', regel(c))).ok, false);
  assert.deepEqual(await ortGebiete(d), []); assert.equal((await d.regelnListe()).length, 0);
});

test('Das Gebiet des Ortes heißt wie der Ort und hängt unter seinem Land, auch nach Umbenennen und nach neuer Prüfung', async () => {
  const c = await neu(); const d = c.d;
  const o = (await d.ortAusTreffer(treffer('sersheim'))).id;
  await d.ortRegelAnlegen(o, regel(c));
  assert.equal((await d.ortAendern(o, { bezeichnung: 'Sersheim Hafen', land: 'Deutschland' })).ok, true);
  assert.equal((await ortGebiete(d))[0].aktuell.werte.bezeichnung, 'Sersheim Hafen');
  assert.equal((await d.ortLaden(o)).eigeneRegeln.length, 1, 'die Regel bleibt beim Ort');
  /* Wechselt das Land bei der Prüfung, zieht das Gebiet des Ortes mit, seine Regeln bleiben */
  assert.equal((await d.ortPruefungUebernehmen(o, treffer('kroatien'))).ok, true);
  const x = await d.ortLaden(o);
  assert.equal(x.gebietPfad[0].name, 'Kroatien');
  assert.equal((await ortGebiete(d))[0].aktuell.werte.elternId, x.gebietPfad[0].id);
  assert.equal(x.eigeneRegeln.length, 1);
  /* Eine Änderung ohne Folgen für das Gebiet legt dort keine neue Fassung an */
  const nr = (await ortGebiete(d))[0].aktuell.nr;
  await d.ortAendern(o, { bezeichnung: 'Sersheim Hafen', land: 'Kroatien', notiz: 'nur eine Notiz' });
  assert.equal((await ortGebiete(d))[0].aktuell.nr, nr);
});

test('Gebiet des Ortes: Namen der Gebiete kollidieren nicht, der Name lässt sich dort nicht ändern, der Ort ist verlinkt', async () => {
  const c = await neu(); const d = c.d;
  const o = (await d.ortAusTreffer(treffer('sersheim'))).id;
  const r = await d.ortRegelAnlegen(o, regel(c));
  assert.equal((await d.gebietAnlegen({ bezeichnung: 'Sersheim' })).ok, true, 'ein eigenes Gebiet darf so heißen wie ein Ort mit Regeln');
  const g = await d.gebietLaden(r.gebietId);
  assert.deepEqual(g.ort, { id: o, name: 'Sersheim' });
  assert.deepEqual(g.pfad.map(x => x.name), ['Deutschland', 'Sersheim']);
  const ae = await d.gebietAendern(r.gebietId, { bezeichnung: 'Anderer Name', notiz: 'Notiz' });
  assert.equal(ae.ok, true);
  const nach = await d.gebietLaden(r.gebietId);
  assert.equal(nach.aktuell.werte.bezeichnung, 'Sersheim'); assert.equal(nach.aktuell.werte.ortId, o); assert.equal(nach.aktuell.werte.ebene, 'ort');
  assert.equal(nach.aktuell.werte.notiz, 'Notiz');
  const rl = await d.regelLaden(r.id);
  assert.equal(rl.gebiet.ortId, o); assert.equal(rl.gebiet.id, r.gebietId);
  /* Ein gewöhnliches Gebiet hat keinen Ort */
  assert.equal((await d.gebietLaden((await d.ortLaden(o)).gebietPfad[0].id)).ort, null);
});

test('Aktivität: Boot mit Revier bekommt Land, Revier, Ort; Wohnmobil Land, Region, Kreis, Ort; nur der Ort mit eigenen Regeln', async () => {
  const c = await neu(); const d = c.d;
  const a = (await d.ortAusTreffer(treffer('sersheim'))).id, b = (await d.ortAusTreffer(treffer('boeblingen'))).id;
  await d.ortAendern(a, { bezeichnung: 'Sersheim', land: 'Deutschland', revierName: 'Neckar' });
  await d.ortAendern(b, { bezeichnung: 'Eutingen', land: 'Deutschland', revierName: 'Neckar' });
  const vorher = await d.aktivitaetLaden((await d.aktivitaetAnlegen(akt(c, { startOrtId: a, zielOrtId: b }))).id);
  assert.deepEqual(vorher.ortGebiete.ketten.map(k => k.map(g => g.name)), [['Deutschland', 'Neckar']], 'ohne eigene Regel gelten die Regeln des Reviers');
  await d.ortRegelAnlegen(a, regel(c));
  const s = await d.aktivitaetLaden((await d.aktivitaetAnlegen(akt(c, { bezeichnung: 'Zwei', startOrtId: a, zielOrtId: b }))).id);
  assert.deepEqual(s.ortGebiete.ketten.map(k => k.map(g => g.name)), [['Deutschland', 'Neckar', 'Sersheim'], ['Deutschland', 'Neckar']]);
  const w = await d.aktivitaetLaden((await d.aktivitaetAnlegen(akt(c, { bezeichnung: 'Drei', fahrzeugId: c.wm, startOrtId: a, zielOrtId: b }))).id);
  assert.deepEqual(w.ortGebiete.ketten.map(k => k.map(g => g.name)), [['Deutschland', 'Baden-Württemberg', 'Landkreis Ludwigsburg', 'Sersheim'], ['Deutschland', 'Baden-Württemberg', 'Landkreis Böblingen']]);
});

test('Prüfung: die eigene Regel des Ortes gilt zusätzlich zu den Regeln des Reviers, nichts wird gesperrt', async () => {
  const c = await neu(); const d = c.d;
  const a = (await d.ortAusTreffer(treffer('sersheim'))).id, b = (await d.ortAusTreffer(treffer('boeblingen'))).id;
  await d.ortAendern(a, { bezeichnung: 'Sersheim', land: 'Deutschland', revierName: 'Neckar' });
  await d.ortAendern(b, { bezeichnung: 'Eutingen', land: 'Deutschland', revierName: 'Neckar' });
  const revier = (await d.ortLaden(a)).revier.id;
  await d.regelAnlegen(revier, { bezeichnung: 'SBF Binnen', fahrzeugArten: ['boot'], artIds: [c.sbf] });
  await d.nachweisAnlegen('person', c.anna, c.sbf, { nummer: '1', datei: { name: 'scan.jpg', type: 'image/jpeg', size: 100 } });
  /* Nur der Ort Eutingen hat keine eigene Regel: es gilt die Regel des Reviers */
  const ohneOrtRegel = await d.aktivitaetAnlegen(akt(c, { startOrtId: b }));
  let p = await d.aktivitaetPruefung(ohneOrtRegel.id);
  assert.equal(p.anforderungen, 1); assert.equal(p.befaehigung.ergebnis, 'erlaubt'); assert.equal(p.befaehigung.gebiet, 'Deutschland › Neckar');
  /* Sersheim bekommt eine eigene Regel (Funkzeugnis), die Anna nicht hat */
  await d.ortRegelAnlegen(a, regel(c));
  const mit = await d.aktivitaetAnlegen(akt(c, { bezeichnung: 'Mit Ortsregel', startOrtId: a, zielOrtId: b }));
  p = await d.aktivitaetPruefung(mit.id);
  assert.equal(p.anforderungen, 2, 'Regel des Reviers und Regel des Ortes');
  assert.equal(p.befaehigung.gebiet, 'Deutschland › Neckar › Sersheim; Deutschland › Neckar');
  const gruende = p.befaehigung.personen[0].gruende.map(x => x.text).join(' | ');
  assert.ok(gruende.includes('Funk am Hafen') && gruende.includes('Deutschland › Neckar › Sersheim'), gruende);
  assert.notEqual(p.befaehigung.ergebnis, 'erlaubt', 'das Funkzeugnis fehlt');
  /* Mit dem Funkzeugnis ist wieder alles klar */
  await d.nachweisAnlegen('person', c.anna, c.funk, { nummer: '2', datei: { name: 'funk.jpg', type: 'image/jpeg', size: 100 } });
  p = await d.aktivitaetPruefung(mit.id);
  assert.equal(p.befaehigung.ergebnis, 'erlaubt');
  /* Das Wohnmobil bekommt die Bootsregel nicht */
  const wm = await d.aktivitaetAnlegen(akt(c, { bezeichnung: 'Landfahrt', fahrzeugId: c.wm, startOrtId: a }));
  p = await d.aktivitaetPruefung(wm.id);
  assert.ok(p.befaehigung.gebietHinweis.includes('trifft keine Regel'));
});

test('Reisecheck: der Ort mit eigenen Regeln steht hinten an der Kette, die der anderen Orte bleibt unverändert', async () => {
  const c = await neu(); const d = c.d;
  const a = (await d.ortAusTreffer(treffer('sersheim'))).id, b = (await d.ortAusTreffer(treffer('boeblingen'))).id;
  const r = await d.aktivitaetAnlegen(akt(c, { fahrzeugId: c.wm, startOrtId: a, zielOrtId: b }));
  assert.deepEqual((await d.reisecheckEingabe(r.id)).eingabe.gebiete.map(g => g.name),
    ['Deutschland, Baden-Württemberg, Landkreis Ludwigsburg', 'Deutschland, Baden-Württemberg, Landkreis Böblingen']);
  await d.ortRegelAnlegen(a, regel(c));
  assert.deepEqual((await d.reisecheckEingabe(r.id)).eingabe.gebiete.map(g => g.name),
    ['Deutschland, Baden-Württemberg, Landkreis Ludwigsburg, Sersheim', 'Deutschland, Baden-Württemberg, Landkreis Böblingen']);
});

test('Revier-Auswahl: die Liste unter dem Land wächst mit jedem neuen Revier, ein gewähltes Revier wird wiederverwendet', async () => {
  const c = await neu(); const d = c.d;
  const a = (await d.ortAusTreffer(treffer('sersheim'))).id, b = (await d.ortAusTreffer(treffer('boeblingen'))).id;
  const land = (await d.ortLaden(a)).gebietPfad[0].id;
  assert.deepEqual(await d.reviereZuLand(land), []);
  await d.ortAendern(a, { bezeichnung: 'Sersheim', land: 'Deutschland', revierName: 'Neckar' });
  assert.deepEqual(await d.reviereZuLand(land), ['Neckar']);
  /* Der zweite Ort wählt das Revier aus der Liste, ein drittes Revier kommt neu hinzu */
  await d.ortAendern(b, { bezeichnung: 'Eutingen', land: 'Deutschland', revierName: 'Neckar' });
  assert.equal((await d.gebieteListe()).filter(x => x.aktuell.werte.ebene === 'revier').length, 1);
  await d.ortAendern(b, { bezeichnung: 'Eutingen', land: 'Deutschland', revierName: 'Rhein' });
  assert.deepEqual((await d.reviereZuLand(land)).sort(), ['Neckar', 'Rhein']);
  /* „Kein Revier“ aus der Liste leert das Revier des Ortes, die Liste bleibt */
  await d.ortAendern(b, { bezeichnung: 'Eutingen', land: 'Deutschland', revierName: '' });
  assert.equal((await d.ortLaden(b)).revier, null);
  assert.deepEqual((await d.reviereZuLand(land)).sort(), ['Neckar', 'Rhein']);
});

test('Sicherung: das Gebiet des Ortes und seine Regeln gehen mit der Sicherung und kommen auf einem anderen Gerät wieder', async () => {
  const c = await neu(); const d = c.d;
  const o = (await d.ortAusTreffer(treffer('sersheim'))).id;
  const r = await d.ortRegelAnlegen(o, regel(c));
  const s = await d.sicherungErzeugen({ mitDateien: false });
  const b = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher()); await b.starten();
  await b.sicherungEinspielen(await b.sicherungLesen(s.bytes, ''));
  const og = (await b.gebieteListe()).filter(x => x.aktuell.werte.ebene === 'ort');
  assert.equal(og.length, 1); assert.equal(og[0].aktuell.werte.ortId, o); assert.equal(og[0].objekt.id, r.gebietId);
  const x = await b.ortLaden(o);
  assert.equal(x.eigeneRegeln.length, 1); assert.equal(x.eigeneRegeln[0].aktuell.werte.bezeichnung, 'Funk am Hafen');
});

/* ---------- Oberfläche (Quelltext, es gibt keinen Browser im Test) ---------- */
const lesen = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
const ansicht = lesen('js/ansicht.js');
function funktion(name) {
  const start = ansicht.indexOf('  function ' + name + '(');
  assert.ok(start >= 0, 'Funktion fehlt: ' + name);
  return ansicht.slice(start, ansicht.indexOf('\n  }\n', start));
}

test('Oberfläche: Route und Seite für die eigene Regel am Ort, Block auf der Ortsseite, Rückweg zum Ort', () => {
  assert.match(ansicht, /teile\[0\] === 'ort' && teile\[1\] && teile\[2\] === 'regel' && teile\[3\] === 'neu'\) p = regelFormular\('neu', decodeURIComponent\(teile\[1\]\), true\)/);
  const blk = funktion('ortRegelnBlock');
  assert.match(blk, /\/regel\/neu/); assert.match(blk, /Eigene Regeln dieses Ortes/); assert.match(blk, /Ort prüfen/);
  assert.match(funktion('seiteBenannt'), /ortRegelnBlock\(id, x\)/);
  const f = funktion('regelFormular');
  assert.match(f, /daten\.ortRegelAnlegen\(id, v\)/); assert.match(f, /k\.ort \? '#\/ort\/'/);
  assert.match(funktion('seiteBenannt'), /'Zum Ort'/);
});

test('Oberfläche: das Ortsformular bietet die Reviere als Auswahlliste an, dazu „Neues Revier eintragen“', () => {
  const f = funktion('benanntFormular');
  assert.match(f, /key: 'revierWahl'/); assert.match(f, /Neues Revier eintragen/); assert.match(f, /neuzeichnenBei: typ === 'ort' && revierInfo && revierInfo\.auswahl \? \['revierWahl'\]/);
  assert.match(f, /delete werte\.revierWahl/); assert.match(f, /werte\.revierName = w\.revierWahl \|\| ''/);
  assert.match(f, /auswahl: !!\(land && liste\.length\)/);
});

test('„Neu im Programm“ nennt 2.0.42', () => {
  require('../js/texte.js');
  const n = MM.Texte.NEUERUNGEN.filter((x) => x.version === '2.0.42')[0];
  assert.ok(n);
  assert.ok(n.punkte.join(' ').includes('Auswahlliste') && n.punkte.join(' ').includes('unterste Ebene'));
});
