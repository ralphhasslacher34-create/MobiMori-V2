'use strict';
/* 2.0.51: Tanken komplett: Füllstand, Verbrauch, Reichweite, Kostenposten (Kostenart „Treibstoff und Energie“).
   Festlegungen vom 09.11.2026: Füllstand einmal angeben, nicht voll = Stand plus Menge (nur gerechnet), Verbrauch je Verbraucher aus Füllstand oder Betriebsstunden. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/verbrauch.js');
require('../js/tanken.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/aktionen.js');
require('../js/baukasten.js');
require('../js/logbuch.js');
require('../js/status.js');
require('../js/motoren.js');
require('../js/personen.js');
require('../js/orte.js');
require('../js/gebiete.js');
require('../js/ortssuche.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/werkstatt.js');
require('../js/kosten.js');
require('../js/reisekasse.js');
require('../js/reiseorte.js');
require('../js/karte.js');
require('../js/daten.js');
const MM = globalThis.MM;
const T = MM.Tanken, B = MM.Baukasten;
const TAG = 86400000;

function neueDaten() {
  const uhr = { ms: new Date(2026, 10, 8, 12, 0, 0).getTime() };
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(uhr.ms + (t++)).toISOString() });
  d.uhr = uhr;
  return d;
}
/* Boot mit zwei Tanks (Steuerbord, Backbord) und einem Gastank */
async function boot() {
  const d = neueDaten();
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const fz = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const toern = (await d.aktivitaetsartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Törn').objekt.id;
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'Törn', artId: toern, fahrzeugId: fz, vonDatum: '2026-11-08', vonZeit: '09:00', bisDatum: '2026-11-20', bisZeit: '17:30', verantwortlichId: anna });
  assert.ok(r.ok, JSON.stringify(r));
  const mk = (n, stoff, inh) => d.komponenteAnlegen(fz, null, 'tank', { bezeichnung: n, stoff, merkmale: [{ name: 'Tankinhalt', wert: String(inh), einheit: 'l' }] });
  const stb = await mk('Steuerbordtank', 'Diesel', 400), bb = await mk('Backbordtank', 'Diesel', 400), gas = await mk('Gastank', 'Gas (Flüssiggas)', 20);
  [stb, bb, gas].forEach(x => assert.ok(x.ok, JSON.stringify(x)));
  const art = await d.ereignisartAnlegen({ bezeichnung: 'Tanken', fragen: B.vorlage('tanken').fragen, wirkungen: B.vorlage('tanken').wirkungen });
  assert.ok(art.ok, JSON.stringify(art));
  return { d, id: r.id, fz, stb: stb.id, bb: bb.id, gas: gas.id, art: art.id };
}
const tw = async (c, id) => (await c.d.komponenteLaden(id)).aktuell.werte;
async function stand(c, id, name, liter, inh) {
  const r = await c.d.komponenteAendern(id, { bezeichnung: name, stoff: 'Diesel', fuellstand: String(liter), merkmale: [{ name: 'Tankinhalt', wert: String(inh), einheit: 'l' }] });
  assert.ok(r.ok, JSON.stringify(r));
}
async function tanken(c, antw, datum, zeit) {
  const e = await c.d.ereignisSchnell(c.id, 'Tanken', { artId: c.art, ortName: 'Horrheim', datum, zeit });
  assert.ok(e.ok, JSON.stringify(e));
  const r = await c.d.ereignisAblaufAusfuehren(e.id, antw);
  assert.ok(r.ok, JSON.stringify(r));
  return { id: e.id, r };
}


/* Zusätzlich: Frischwasser, Grauwasser, eine Gasflasche und die Art „Ver- und Entsorgung“ */
async function entsorgung() {
  const c = await boot();
  const mk = async (n, stoff, inh) => { const r = await c.d.komponenteAnlegen(c.fz, null, 'tank', { bezeichnung: n, stoff, merkmale: [{ name: 'Tankinhalt', wert: String(inh), einheit: 'l' }] }); assert.ok(r.ok, JSON.stringify(r)); return r.id; };
  c.frisch = await mk('Frischwassertank', 'Frischwasser', 200);
  c.grau = await mk('Grauwassertank', 'Grauwasser', 150);
  const v = B.vorlage('versorgung');
  const art = await c.d.ereignisartAnlegen({ bezeichnung: 'Ver- und Entsorgung', fragen: v.fragen, wirkungen: v.wirkungen });
  assert.ok(art.ok, JSON.stringify(art));
  c.vart = art.id;
  return c;
}
async function vorgang(c, antw, datum, zeit) {
  const e = await c.d.ereignisSchnell(c.id, 'Ver- und Entsorgung', { artId: c.vart, ortName: 'Hafen', datum, zeit });
  assert.ok(e.ok, JSON.stringify(e));
  const r = await c.d.ereignisAblaufAusfuehren(e.id, antw);
  return { id: e.id, r };
}

test('Ver- und Entsorgung: Vorlage hat die Frage „Was?“ zuerst, Tanken ist darin enthalten', () => {
  const v = B.vorlage('versorgung');
  assert.deepEqual(v.fragen.slice(0, 2), ['vorgang', 'tank']);
  assert.deepEqual(B.fehlendeFragen({ fragen: v.fragen, wirkungen: v.wirkungen }), []);
  const ids = T.VORGANG_VORLAGE.map(x => x.id);
  assert.deepEqual(ids, ['tanken', 'gasflasche', 'frischwasser', 'grauwasser', 'schwarzwasser', 'chemietoilette']);
});

test('Angeboten wird nur, was das Fahrzeug als Tank hat: ohne Schwarzwassertank kein „Schwarzwasser entleeren“', async () => {
  const c = await entsorgung();
  const a = await c.d.vorgangAuswahl(c.fz);
  const namen = a.map(x => x.id);
  assert.ok(namen.includes('tanken') && namen.includes('gasflasche') && namen.includes('frischwasser') && namen.includes('grauwasser'));
  assert.ok(!namen.includes('schwarzwasser') && !namen.includes('chemietoilette'));
  assert.deepEqual(a.find(x => x.id === 'tanken').tanks.map(t => t.name).sort(), ['Backbordtank', 'Dieseltank'.replace('Dieseltank', 'Gastank'), 'Steuerbordtank'].sort(), 'Tanken: Diesel- und Gastanks, kein Wasser');
  assert.deepEqual(a.find(x => x.id === 'frischwasser').tanks.map(t => t.name), ['Frischwassertank']);
  assert.deepEqual(a.find(x => x.id === 'gasflasche').tanks.map(t => t.name), ['Gastank']);
  /* ausgeblendet = nicht mehr angeboten */
  assert.ok((await c.d.vorgangAusblenden('grauwasser', true)).ok);
  assert.ok(!(await c.d.vorgangAuswahl(c.fz)).some(x => x.id === 'grauwasser'));
});

test('Frischwasser auffüllen: Füllstand steigt, bei voll auf den Tankinhalt, Kosten sind freiwillig', async () => {
  const c = await entsorgung();
  await c.d.komponenteAendern(c.frisch, { bezeichnung: 'Frischwassertank', stoff: 'Frischwasser', fuellstand: '20', merkmale: [{ name: 'Tankinhalt', wert: '200', einheit: 'l' }] });
  c.d.uhr.ms += TAG;
  const a = await vorgang(c, { vorgangId: 'frischwasser', tankId: c.frisch, menge: '50', voll: 'nein' });
  assert.ok(a.r.ok, JSON.stringify(a.r));
  assert.equal(a.r.kostenNeu, false, 'ohne Betrag kein Kostenposten, aber auch kein Fehler');
  assert.equal((await tw(c, c.frisch)).fuellstand, 70);
  c.d.uhr.ms += TAG;
  const b = await vorgang(c, { vorgangId: 'frischwasser', tankId: c.frisch, menge: '130', betrag: '1,50', voll: 'ja' });
  assert.ok(b.r.ok, JSON.stringify(b.r));
  assert.equal((await tw(c, c.frisch)).fuellstand, 200);
  const k = (await c.d.kostenListe(c.fz)).find(x => x.objekt.id === b.r.kostenId);
  assert.equal(k.aktuell.werte.kostenart, 'wasser');
  assert.equal((await c.d.ereignisLaden(b.id)).aktuell.werte.entsorgungName, 'Frischwasser auffüllen');
});

test('Grauwasser entleeren: bei „ganz leer“ auf 0, sonst Füllstand minus Menge; Gebühr wird ein Kostenposten', async () => {
  const c = await entsorgung();
  await c.d.komponenteAendern(c.grau, { bezeichnung: 'Grauwassertank', stoff: 'Grauwasser', fuellstand: '100', merkmale: [{ name: 'Tankinhalt', wert: '150', einheit: 'l' }] });
  c.d.uhr.ms += TAG;
  const t = await vorgang(c, { vorgangId: 'grauwasser', tankId: c.grau, menge: '30', voll: 'nein' });
  assert.ok(t.r.ok, JSON.stringify(t.r));
  assert.equal((await tw(c, c.grau)).fuellstand, 70);
  c.d.uhr.ms += TAG;
  const g = await vorgang(c, { vorgangId: 'grauwasser', tankId: c.grau, voll: 'ja', betrag: '3' });
  assert.ok(g.r.ok, JSON.stringify(g.r));
  const w = await tw(c, c.grau);
  assert.equal(w.fuellstand, 0); assert.equal(w.fuellstandArt, 'leer');
  assert.equal(g.r.kostenNeu, true);
  /* ohne Menge und ohne „ganz leer“ geht es nicht */
  const bad = await vorgang(c, { vorgangId: 'grauwasser', tankId: c.grau, voll: 'nein' });
  assert.equal(bad.r.ok, false); assert.ok(bad.r.fehler.menge);
  /* Ändern mit 0 gilt auch hier: der Tank geht auf den Stand davor zurück */
  const a = await c.d.tankvorgangAendern(g.id, { menge: '0' });
  assert.ok(a.ok, JSON.stringify(a));
  assert.equal((await tw(c, c.grau)).fuellstand, 70);
});

test('Gasflasche tauschen: neue Flasche ist voll, keine Menge nötig; Ändern auf 0 macht es rückgängig', async () => {
  const c = await entsorgung();
  await c.d.komponenteAendern(c.gas, { bezeichnung: 'Gastank', stoff: 'Gas (Flüssiggas)', fuellstand: '2', merkmale: [{ name: 'Tankinhalt', wert: '20', einheit: 'l' }] });
  c.d.uhr.ms += TAG;
  const f = await vorgang(c, { vorgangId: 'gasflasche', tankId: c.gas, betrag: '28' });
  assert.ok(f.r.ok, JSON.stringify(f.r));
  const w = await tw(c, c.gas);
  assert.equal(w.fuellstand, 20); assert.equal(w.fuellstandArt, 'voll');
  assert.equal((await c.d.kostenListe(c.fz)).find(x => x.objekt.id === f.r.kostenId).aktuell.werte.kostenart, 'treibstoff');
  const a = await c.d.tankvorgangAendern(f.id, { menge: '0' });
  assert.ok(a.ok, JSON.stringify(a));
  assert.equal((await tw(c, c.gas)).fuellstand, 2);
});

test('Tanken in der Ver- und Entsorgung: Gas in kg (Füllstation), Kraftstoffart wird mit dem Stoff des Tanks festgehalten', async () => {
  const c = await entsorgung();
  await c.d.komponenteAendern(c.gas, { bezeichnung: 'Gastank', stoff: 'Gas (Flüssiggas)', fuellstand: '5', merkmale: [{ name: 'Tankinhalt', wert: '20', einheit: 'l' }] });
  c.d.uhr.ms += TAG;
  const t = await vorgang(c, { vorgangId: 'tanken', tankId: c.gas, menge: '5,1', mengeEinheit: 'kg', literpreis: '2', voll: 'nein', stoff: 'Gas (Flüssiggas)' });
  assert.ok(t.r.ok, JSON.stringify(t.r));
  const w = (await c.d.ereignisLaden(t.id)).aktuell.werte;
  assert.equal(w.menge, 10); assert.equal(w.kraftstoff, 'Gas (Flüssiggas)'); assert.equal(w.entsorgungArt, 'tanken'); assert.equal(w.tankArt, 'auf');
  assert.equal((await tw(c, c.gas)).fuellstand, 15);
  /* Wasser ist kein Kraftstoff: der Wassertank wird beim Tanken nicht angeboten, aber die Daten sperren die Wahl nicht still */
  const bad = await vorgang(c, { tankId: c.gas, menge: '1', voll: 'nein' });
  assert.equal(bad.r.ok, false); assert.ok(bad.r.fehler.vorgang, 'ohne „Was?“ geht es nicht');
});

test('Eigene Vorgänge: Name, Art und Stoffe; nur Tanks mit diesem Stoff werden angeboten', async () => {
  const c = await entsorgung();
  assert.equal((await c.d.versorgungsvorgangAnlegen({ name: '', art: 'auf', stoffe: ['Frischwasser'] })).ok, false);
  assert.equal((await c.d.versorgungsvorgangAnlegen({ name: 'Trinkwasser nachfüllen', art: 'auf', stoffe: [] })).ok, false);
  const r = await c.d.versorgungsvorgangAnlegen({ name: 'Trinkwasser nachfüllen', art: 'auf', stoffe: ['Frischwasser'], kostenart: 'wasser' });
  assert.ok(r.ok, JSON.stringify(r));
  assert.equal((await c.d.versorgungsvorgangAnlegen({ name: 'trinkwasser nachfüllen', art: 'auf', stoffe: ['Frischwasser'] })).ok, false, 'gleicher Name nur einmal');
  assert.ok((await c.d.vorgangAuswahl(c.fz)).some(x => x.name === 'Trinkwasser nachfüllen'));
});

test('Das Cockpit hat einen einzigen Knopf „Ver- und Entsorgung“; „Tanken“ bleibt als eigene Art wählbar', async () => {
  const d = neueDaten(); await d.starten();
  await d.ereignisartenAusVorschlaegen(); await d.ereignisartenVorauswahlUebernehmen();
  const i = await d.schnellknoepfeFuerFahrzeugart('wohnmobil');
  const namen = i.knoepfe.map(k => k.name);
  assert.ok(namen.includes('Ver- und Entsorgung')); assert.ok(!namen.includes('Tanken'));
  assert.ok(i.angebot.ereignisse.map(k => k.name).includes('Tanken'), 'Tanken lässt sich zusätzlich ins Cockpit legen');
});

test('Die Art „Ver- und Entsorgung“ kommt aus den Vorschlägen gleich mit Fragen und Wirkungen der Vorlage', async () => {
  const d = neueDaten(); await d.starten();
  await d.ereignisartenAusVorschlaegen(); await d.ereignisartenVorauswahlUebernehmen();
  const art = (await d.ereignisartenListe()).find(x => x.aktuell.werte.bezeichnung === 'Ver- und Entsorgung');
  assert.ok(art);
  assert.deepEqual(B.zusammenstellung(art.aktuell.werte), { fragen: B.vorlage('versorgung').fragen, wirkungen: B.vorlage('versorgung').wirkungen });
  assert.ok(B.hatAblauf(art.aktuell.werte));
});
