'use strict';
/* 2.0.14: Rechnung für Cockpit, Nachtrag-Erkennung und Prüfung beim Wechsel (js/logbuch.js, ohne Speicher). */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/aktivitaeten.js');
require('../js/logbuch.js');
const MM = globalThis.MM;
const L = MM.Logbuch;

test('Nachtrag erkennen: bis 5 Minuten Abstand ist „jetzt“, mehr in der Vergangenheit „nachtrag“, mehr in der Zukunft „zukunft“', () => {
  const j = '2026-11-03T12:00';
  assert.equal(L.NACHTRAG_MINUTEN, 5);
  assert.equal(L.zeitpunktArt('2026-11-03', '12:00', j), 'jetzt');
  assert.equal(L.zeitpunktArt('2026-11-03', '11:55', j), 'jetzt', 'genau 5 Minuten zählt noch als jetzt');
  assert.equal(L.zeitpunktArt('2026-11-03', '11:54', j), 'nachtrag');
  assert.equal(L.zeitpunktArt('2026-11-03', '12:05', j), 'jetzt');
  assert.equal(L.zeitpunktArt('2026-11-03', '12:06', j), 'zukunft');
  assert.equal(L.zeitpunktArt('2026-11-02', '12:00', j), 'nachtrag', 'gestern');
  assert.equal(L.zeitpunktArt('2026-11-02', '23:58', '2026-11-03T00:02'), 'jetzt', 'über Mitternacht gerechnet');
  assert.equal(L.zeitpunktArt('', '12:00', j), 'unklar');
  assert.equal(L.zeitpunktArt('2026-11-03', '', j), 'unklar');
  assert.equal(L.zeitpunktArt('2026-11-03', '12:00', 'kaputt'), 'unklar');
});

test('Cockpit: nur wenn nicht storniert und heute im Zeitraum (nach Datum)', () => {
  const w = { status: 'aktiv', vonDatum: '2026-11-03', bisDatum: '2026-11-05' };
  assert.deepEqual(L.cockpitMoeglich(w, '2026-11-03'), { moeglich: true, grund: null }, 'erster Tag');
  assert.equal(L.cockpitMoeglich(w, '2026-11-04').moeglich, true);
  assert.equal(L.cockpitMoeglich(w, '2026-11-05').moeglich, true, 'letzter Tag');
  assert.deepEqual(L.cockpitMoeglich(w, '2026-11-02'), { moeglich: false, grund: 'geplant' });
  assert.deepEqual(L.cockpitMoeglich(w, '2026-11-06'), { moeglich: false, grund: 'vorbei' });
  assert.deepEqual(L.cockpitMoeglich(Object.assign({}, w, { status: 'storniert' }), '2026-11-04'), { moeglich: false, grund: 'storniert' });
});

test('Schnellknöpfe nutzen Abfahrt, Ankunft und Notiz, und die gibt es unter den Vorschlägen', () => {
  assert.deepEqual(L.SCHNELL_ART, { abfahrt: 'Abfahrt', ankunft: 'Ankunft', notiz: 'Notiz' });
  Object.values(L.SCHNELL_ART).forEach(n => assert.ok(L.VORSCHLAEGE_EREIGNISARTEN.includes(n), n));
});

function pruefung(ergebnis, extra) {
  return Object.assign({
    geprueftAm: '2026-11-03T12:00',
    befaehigung: {
      ergebnis, gebiet: null, gebietHinweis: null,
      personen: [
        { person: { id: 'pe1', name: 'Anna' }, rolleText: 'Skipper', ergebnis: 'erlaubt', gruende: [{ ergebnis: 'erlaubt', text: 'Sportbootführerschein gültig' }] },
        { person: { id: 'pe2', name: 'Ben' }, rolleText: 'Stellvertreter', ergebnis, gruende: [{ ergebnis, text: 'Nachweis läuft ab' }] }
      ]
    }
  }, extra || {});
}

test('Wechsel: Prüfung der übernehmenden Person wird festgehalten, mit „geprüft am“, Namen und Gründen', () => {
  const p = L.wechselPruefungFestgehalten(pruefung('nicht_erlaubt'), 'pe2');
  assert.equal(p.geprueftAm, '2026-11-03T12:00');
  assert.equal(p.name, 'Ben'); assert.equal(p.rolleText, 'Stellvertreter');
  assert.equal(p.ergebnis, 'nicht_erlaubt', 'sicher bekannt: bleibt „nicht erlaubt“');
  assert.deepEqual(p.gruende, [{ ergebnis: 'nicht_erlaubt', text: 'Nachweis läuft ab' }]);
  assert.equal(L.wechselPruefungFestgehalten(pruefung('erlaubt'), 'pe1').ergebnis, 'erlaubt');
});

test('Wechsel: Gebiet nicht oder nur als Text eingetragen macht „erlaubt“ zu „unklar“, „nicht erlaubt“ bleibt', () => {
  const hinweis = { befaehigung: Object.assign(pruefung('erlaubt').befaehigung, { gebietHinweis: 'Das Gebiet „Kroatien“ ist nur als Text eingetragen.' }) };
  const p = L.wechselPruefungFestgehalten(pruefung('erlaubt', hinweis), 'pe1');
  assert.equal(p.ergebnis, 'unklar');
  assert.match(p.gebietHinweis, /nur als Text/);
  const q = pruefung('nicht_erlaubt'); q.befaehigung.gebietHinweis = 'Hinweis';
  assert.equal(L.wechselPruefungFestgehalten(q, 'pe2').ergebnis, 'nicht_erlaubt');
});

test('Wechsel: ohne Prüfung oder für eine Person, die nicht geprüft wird, kommt nichts', () => {
  assert.equal(L.wechselPruefungFestgehalten(null, 'pe1'), null);
  assert.equal(L.wechselPruefungFestgehalten(pruefung('erlaubt'), 'unbekannt'), null);
  assert.equal(L.wechselPruefungKurz(null), null);
  assert.equal(L.wechselPruefungKurz(L.wechselPruefungFestgehalten(pruefung('unklar'), 'pe2')), 'Befähigung von Ben: Unklar (geprüft am 03.11.2026, 12:00 Uhr)');
});

test('Wechselereignisse tragen Nachtrag und Prüfung weiter', () => {
  const p = { ergebnis: 'unklar' };
  const w = L.wechselEreignisse([
    { id: 'v1', personId: 'a', name: 'Anna', ab: '2026-11-03T09:00' },
    { id: 'v2', personId: 'b', name: 'Ben', ab: '2026-11-03T13:00', nachgetragenAm: '2026-11-03T14:00:00.000Z', pruefung: p },
    { id: 'v3', personId: 'a', name: 'Anna', ab: '2026-11-03T15:00' }
  ]);
  assert.equal(w.length, 2);
  assert.equal(w[0].nachgetragenAm, '2026-11-03T14:00:00.000Z'); assert.equal(w[0].pruefung, p);
  assert.equal(w[1].nachgetragenAm, null); assert.equal(w[1].pruefung, null);
});

function tag(id, datum, ausgeblendet, ereignisse) {
  return { objekt: { id }, aktuell: { werte: { datum } }, ausgeblendet: !!ausgeblendet, ereignisse: ereignisse || [] };
}
const ev = (id, zeitpunkt, ausgeblendet) => ({ id, zeitpunkt, ausgeblendet: !!ausgeblendet, artName: 'x' });

test('Heutiger Tag: der erste sichtbare mit dem Datum; ausgeblendete zählen nicht', () => {
  const t = [tag('a', '2026-11-02'), tag('b', '2026-11-03', true), tag('c', '2026-11-03'), tag('d', '2026-11-03')];
  assert.equal(L.heutigerAbschnitt(t, '2026-11-03').objekt.id, 'c');
  assert.equal(L.heutigerAbschnitt(t, '2026-11-04'), null);
  assert.equal(L.heutigerAbschnitt([tag('b', '2026-11-03', true)], '2026-11-03'), null);
});

test('Letzte Einträge: neueste zuerst, über alle Tage, ohne ausgeblendete Ereignisse und Tage', () => {
  const t = [
    tag('a', '2026-11-02', false, [ev('e1', '2026-11-02T08:00'), ev('e2', '2026-11-02T18:00')]),
    tag('b', '2026-11-03', false, [ev('e3', '2026-11-03T09:00'), ev('e4', '2026-11-03T10:00', true)]),
    tag('c', '2026-11-04', true, [ev('e5', '2026-11-04T09:00')])
  ];
  assert.deepEqual(L.letzteEreignisse(t, 10).map(e => e.id), ['e3', 'e2', 'e1']);
  assert.deepEqual(L.letzteEreignisse(t, 2).map(e => e.id), ['e3', 'e2']);
  assert.equal(L.letzteEreignisse(t, 1)[0].tagId, 'b');
  assert.equal(L.letzteEreignisse([], 5).length, 0);
});

test('Tagesabschluss: vorhanden, wenn Ziel oder Notiz eingetragen ist', () => {
  assert.equal(L.hatAbschluss({}), false);
  assert.equal(L.hatAbschluss({ zielTatsaechlich: null, abschlussNotiz: '' }), false);
  assert.equal(L.hatAbschluss({ zielTatsaechlich: 'Zadar' }), true);
  assert.equal(L.hatAbschluss({ abschlussNotiz: 'ruhig' }), true);
});
