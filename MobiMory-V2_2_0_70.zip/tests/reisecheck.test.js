'use strict';
/* Schritt 11 (2.0.38): Reisecheck, reine Regeln. Adresse, Passwort, anonymisierte Anfrage, Antwort prüfen, Auswertung. */
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/reisecheck.js');
const MM = globalThis.MM;
const R = MM.Reisecheck;

function eingabe(extra) {
  return Object.assign({
    vonDatum: '2026-11-10', vonZeit: '08:00', bisDatum: '2026-11-17', bisZeit: '',
    fahrzeug: { name: 'Seeschwalbe', artName: 'Motorboot', welt: 'wasser',
      werte: { marke: 'Bavaria', modell: 'S30', laenge: 9.5, kennzeichen: '', registriernummer: 'KN-1234', hin: 'DE-ABC12345D404', fin: '' },
      komponenten: [{ name: 'Rettungsweste', anzahl: 4 }, { name: '', anzahl: 1 }],
      nachweise: [{ art: 'Versicherung', gueltigBis: '2027-01-01', gescannt: true }] },
    gebiete: [{ name: 'Kroatien' }], gebietText: '',
    wegpunkte: [],
    personen: [{ name: 'Anna Beispiel', rolle: 'Skipper', funktionen: ['Skipper'], nachweise: [{ art: 'Sportbootführerschein See', gueltigBis: '2030-05-01', gescannt: true, klassen: 'See' }] },
      { name: 'Ben', rolle: 'Crew', funktionen: [], nachweise: [] }],
    tiere: [{ name: 'Bello', tierart: 'Hund', hatChip: true, nachweise: [{ art: 'Tollwutimpfung', gueltigBis: '2027-02-01' }] }]
  }, extra || {});
}

test('Dienstadresse: nur https, ohne Leerzeichen, /research und /health werden entfernt', () => {
  assert.equal(R.dienstAdresse('').ok, false);
  assert.equal(R.dienstAdresse('http://x.workers.dev').ok, false);
  assert.equal(R.dienstAdresse('https://x workers.dev').ok, false);
  assert.equal(R.dienstAdresse('https://localhost').ok, false);
  assert.equal(R.dienstAdresse('https://').ok, false);
  const a = R.dienstAdresse('  https://Mobimory-Research.Name.workers.dev/research/  ');
  assert.equal(a.ok, true);
  assert.equal(a.url, 'https://mobimory-research.name.workers.dev');
  assert.equal(R.dienstAdresse('https://a.b.de/health').url, 'https://a.b.de');
  assert.equal(R.dienstAdresse('https://a.b.de/dienst/').url, 'https://a.b.de/dienst');
});

test('Passwort: mindestens 8 Zeichen, keine Leerzeichen', () => {
  assert.equal(R.tokenPruefen('').ok, false);
  assert.equal(R.tokenPruefen('kurz').ok, false);
  assert.equal(R.tokenPruefen('ein passwort lang').ok, false);
  assert.deepEqual(R.tokenPruefen(' abcdefgh12 '), { ok: true, token: 'abcdefgh12' });
});

test('Anfrage: keine Namen, keine Nummern, Besatzung als P1 und Tiere als A1', () => {
  const b = R.anfrageBauen(eingabe());
  assert.equal(b.ok, true, JSON.stringify(b.fehler));
  const s = JSON.stringify(b.anfrage);
  ['Anna', 'Beispiel', 'Ben', 'Bello', 'Seeschwalbe', 'KN-1234', 'DE-ABC12345D404'].forEach(x => assert.ok(!s.includes(x), x + ' darf nicht hinausgehen'));
  assert.deepEqual(b.anfrage.persons.map(p => p.key), ['P1', 'P2']);
  assert.deepEqual(b.anfrage.animals.map(p => p.key), ['A1']);
  assert.equal(b.namen.P1, 'Anna Beispiel'); assert.equal(b.namen.A1, 'Bello'); assert.equal(b.namen.vehicle, 'Seeschwalbe');
  assert.equal(b.anfrage.vehicle.hasRegistrationIdentifier, true);
  assert.equal(b.anfrage.vehicle.hasHIN, true); assert.equal(b.anfrage.vehicle.hasVIN, false);
  assert.deepEqual(b.anfrage.vehicle.components, [{ name: 'Rettungsweste', count: 4 }], 'leere Bezeichnungen fallen weg');
  assert.equal(b.anfrage.persons[0].qualifications[0].validTo, '2030-05-01');
  assert.equal(b.anfrage.animals[0].hasChip, true);
});

test('Anfrage: Zeitraum, Verkehrsart, freier Check mit Gebiet', () => {
  const b = R.anfrageBauen(eingabe());
  assert.equal(b.anfrage.trip.start, '2026-11-10T08:00:00');
  assert.equal(b.anfrage.trip.end, '2026-11-17T23:59:00');
  assert.deepEqual(b.anfrage.trip.trafficModes, ['Wasser']);
  assert.equal(b.anfrage.trip.checkMode, 'free');
  assert.equal(b.anfrage.trip.title, 'Reisecheck', 'der Titel der Aktivität geht nicht hinaus');
  assert.deepEqual(b.anfrage.trip.areas.map(a => a.name), ['Kroatien']);
  assert.equal(b.anfrage.trip.routePlan, undefined);
  assert.deepEqual(R.verkehrsarten('land'), ['Strasse']);
  assert.deepEqual(R.verkehrsarten('luft'), ['Luft']);
});

test('Anfrage: mit Start und Ziel geplanter Check, Lage auf zwei Stellen gerundet, Land als Zusammenhang', () => {
  const b = R.anfrageBauen(eingabe({ gebiete: [], wegpunkte: [
    { art: 'start', name: 'Biograd', land: 'Kroatien', breite: 43.93812, laenge: 15.44555 },
    { art: 'ziel', name: 'Zadar', land: 'Kroatien', breite: 44.1194, laenge: 15.2314 }] }));
  assert.equal(b.ok, true);
  const t = b.anfrage.trip;
  assert.equal(t.checkMode, 'planned-usage');
  assert.deepEqual(t.routePlan.waypoints.map(w => [w.order, w.kind, w.ortName, w.lat, w.lon]), [[1, 'start', 'Biograd', 43.94, 15.45], [2, 'ziel', 'Zadar', 44.12, 15.23]]);
  assert.equal(t.routePlan.locationContext.allWaypointsResolved, true);
  assert.equal(t.routePlan.locationContext.sameKnownCountry, 'Kroatien');
  assert.equal(t.areas.length, 0);
});

test('Anfrage: Gebiet nur als Text zählt, ohne Gebiet und ohne Start und Ziel keine Anfrage', () => {
  assert.equal(R.anfrageBauen(eingabe({ gebiete: [], gebietText: 'Adria' })).anfrage.trip.areas[0].name, 'Adria');
  const ohne = R.anfrageBauen(eingabe({ gebiete: [], gebietText: '' }));
  assert.equal(ohne.ok, false);
  assert.ok(ohne.fehler.some(f => f.includes('Gebiet')));
  const eins = R.anfrageBauen(eingabe({ gebiete: [], wegpunkte: [{ art: 'start', name: 'A' }] }));
  assert.equal(eins.ok, false, 'ein einzelner Ort reicht nicht');
});

test('Anfrage: ohne Besatzung, ohne Zeitraum oder ohne Fahrzeug keine Anfrage', () => {
  assert.ok(R.anfrageBauen(eingabe({ personen: [] })).fehler.some(f => f.includes('Besatzung')));
  assert.ok(R.anfrageBauen(eingabe({ vonDatum: '' })).fehler.some(f => f.includes('Beginn')));
  assert.ok(R.anfrageBauen(eingabe({ fahrzeug: null })).fehler.some(f => f.includes('Fahrzeug')));
});

test('Fingerabdruck: gleich bei gleichen Daten, anders bei anderen; Vorschau nennt keine Namen', () => {
  const a = R.anfrageBauen(eingabe()), b = R.anfrageBauen(eingabe()), c = R.anfrageBauen(eingabe({ bisDatum: '2026-11-18' }));
  assert.equal(R.fingerabdruck(a.anfrage), R.fingerabdruck(b.anfrage));
  assert.notEqual(R.fingerabdruck(a.anfrage), R.fingerabdruck(c.anfrage));
  const v = R.vorschau(a.anfrage).join('\n');
  assert.match(v, /P1 \(Skipper\)/); assert.match(v, /bis 2030-05-01/); assert.match(v, /A1 \(Hund\)/);
  assert.ok(!v.includes('Anna') && !v.includes('Bello'));
});

const ANF = (x) => Object.assign({ id: 'r1', area: 'Papiere', category: 'Pflicht', subjectKey: 'P1', subjectType: 'Person', trafficMode: 'Wasser', requirement: 'Sportbootführerschein See', proofKey: 'SBF',
  status: 'Erfüllt', evidence: 'P1 hat SBF See bis 2030', explanation: 'passt', confidence: 'hoch', conflict: false,
  sources: [{ title: 'Behörde', url: 'https://www.example.hr/x', publisher: 'Ministerium', official: true, updated: '2026-10-01' }] }, x || {});
const ANTWORT = (liste, extra) => ({ ok: true, model: 'modell-x', requestId: 'req1', researchedAt: '2026-11-05T11:00:00Z', result: Object.assign({ summary: 'Zusammenfassung', researchStatus: 'vollständig', warnings: [], route: { routingStatus: 'plausibel', summary: '', assumptions: [], routeWarnings: [] }, requirements: liste }, extra || {}) });

test('Antwort: gültige Antwort wird in unser Format gebracht', () => {
  const p = R.antwortPruefen(ANTWORT([ANF()]));
  assert.equal(p.ok, true);
  const a = p.ergebnis.anforderungen[0];
  assert.equal(a.kategorie, 'Pflicht'); assert.equal(a.status, 'Erfüllt'); assert.equal(a.subjekt, 'P1'); assert.equal(a.vertrauen, 'hoch');
  assert.equal(a.quellen[0].amtlich, true); assert.equal(p.dienst.modell, 'modell-x');
  assert.equal(p.ergebnis.recherche, 'vollständig');
});

test('Antwort: fehlende oder falsche Teile sind Fehler, unbekannte Werte werden vorsichtig', () => {
  assert.equal(R.antwortPruefen(null).ok, false);
  assert.equal(R.antwortPruefen({ ok: true }).ok, false);
  assert.equal(R.antwortPruefen({ result: { requirements: 'x' } }).ok, false);
  assert.equal(R.antwortPruefen(ANTWORT([])).ok, false, 'keine Anforderungen heißt kein Ergebnis');
  assert.equal(R.antwortPruefen(ANTWORT([{ id: 'x' }, null, 5])).ok, false, 'Zeilen ohne Text zählen nicht');
  const p = R.antwortPruefen(ANTWORT([ANF({ status: 'Vielleicht', category: 'Egal', confidence: '??', subjectType: 'Boot' })], { researchStatus: 'komisch' }));
  const a = p.ergebnis.anforderungen[0];
  assert.equal(a.status, 'Prüfen', 'unbekannter Status heißt prüfen, nie erfüllt');
  assert.equal(a.kategorie, 'Hinweis'); assert.equal(a.vertrauen, 'niedrig'); assert.equal(a.subjektArt, 'Reise');
  assert.equal(p.ergebnis.recherche, 'teilweise');
});

test('Antwort: nur http- und https-Quellen, höchstens sechs, lange Texte werden gekürzt', () => {
  const quellen = [{ title: 'a', url: 'javascript:alert(1)' }, { title: 'b', url: 'ftp://x.de' }, { title: 'c', url: 'http://ok.de/a' }]
    .concat(Array.from({ length: 10 }, (_, i) => ({ title: 'q' + i, url: 'https://q' + i + '.de' })));
  const p = R.antwortPruefen(ANTWORT([ANF({ sources: quellen, requirement: 'x'.repeat(2000) })]));
  const a = p.ergebnis.anforderungen[0];
  assert.equal(a.quellen.length, 6);
  assert.ok(a.quellen.every(q => /^https?:\/\//.test(q.url)));
  assert.ok(a.anforderung.length <= 700);
  assert.equal(a.quellen[0].url, 'http://ok.de/a');
});

test('Auswertung: Gesamtbild kommt nur aus Pflicht und Wichtig, unvollständige Recherche ist nie ok', () => {
  function gesamt(liste, extra) { const p = R.antwortPruefen(ANTWORT(liste, extra)); return R.auswerten(p.ergebnis); }
  assert.equal(gesamt([ANF(), ANF({ id: 'b', category: 'Empfohlen', status: 'Fehlt' })]).gesamt, 'ok', 'Empfohlen färbt nicht');
  assert.equal(gesamt([ANF(), ANF({ id: 'b', status: 'Prüfen' })]).gesamt, 'pruefen');
  assert.equal(gesamt([ANF(), ANF({ id: 'b', category: 'Wichtig', status: 'Fehlt' })]).gesamt, 'fehlt');
  assert.equal(gesamt([ANF()], { researchStatus: 'teilweise' }).gesamt, 'pruefen');
  const z = gesamt([ANF(), ANF({ id: 'b', status: 'Fehlt' }), ANF({ id: 'c', status: 'Nicht relevant' })]);
  assert.deepEqual(z.zaehl, { Fehlt: 1, 'Prüfen': 0, 'Erfüllt': 1, 'Nicht relevant': 1 });
  assert.equal(z.wichtigFehlt, 1);
});

test('Sortierung: erst Pflicht, dann was fehlt; Namen nur lokal', () => {
  const p = R.antwortPruefen(ANTWORT([ANF({ id: 'a', category: 'Hinweis', status: 'Fehlt' }), ANF({ id: 'b', status: 'Erfüllt' }), ANF({ id: 'c', status: 'Fehlt' }), ANF({ id: 'd', category: 'Wichtig', status: 'Fehlt' })]));
  assert.deepEqual(R.sortiert(p.ergebnis).map(x => x.id), ['c', 'b', 'd', 'a']);
  assert.equal(R.subjektName({ P1: 'Anna' }, 'P1'), 'Anna');
  assert.equal(R.subjektName({}, 'trip'), 'Reise');
  assert.equal(R.subjektName({}, 'P9'), 'P9');
});

test('Zustimmungstext nennt, was nicht hinausgeht, und dass es keine rechtsgültige Auskunft ist', () => {
  assert.match(R.ZUSTIMMUNG_TEXT, /Namen/); assert.match(R.ZUSTIMMUNG_TEXT, /Kennzeichen/); assert.match(R.ZUSTIMMUNG_TEXT, /widerrufen/); assert.match(R.ZUSTIMMUNG_TEXT, /nicht rechtsgültig|keine rechtsgültige/);
  assert.equal(typeof R.ZUSTIMMUNG_VERSION, 'number');
});
