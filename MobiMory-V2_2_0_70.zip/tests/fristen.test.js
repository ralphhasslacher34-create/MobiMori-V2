'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/fristen.js');
const F = globalThis.MM.Fristen;

test('Monate addieren: Monatsende bleibt Monatsende', () => {
  assert.equal(F.addMonate('2026-01-31', 1), '2026-02-28');
  assert.equal(F.addMonate('2024-01-31', 1), '2024-02-29');
  assert.equal(F.addMonate('2026-11-03', 12), '2027-11-03');
  assert.equal(F.addMonate('2026-11-03', 3), '2027-02-03');
  assert.equal(F.addMonate('2026-12-15', 24), '2028-12-15');
  assert.equal(F.addMonate('kaputt', 1), null);
});

test('Tage zwischen zwei Daten, über Jahres- und Schaltjahrgrenzen', () => {
  assert.equal(F.tageZwischen('2026-11-03', '2026-11-10'), 7);
  assert.equal(F.tageZwischen('2026-11-10', '2026-11-03'), -7);
  assert.equal(F.tageZwischen('2026-12-31', '2027-01-01'), 1);
  assert.equal(F.tageZwischen('2028-02-28', '2028-03-01'), 2);
  assert.equal(F.tageZwischen('2026-03-28', '2026-03-30'), 2); /* Zeitumstellung */
});

const basis = { zaehlerId: null, zaehlerWert: null, kalenderWert: null, kalenderEinheit: null, vorwarnTage: 30, vorwarnZaehler: null };

test('Kalender: in Ordnung, bald fällig, heute fällig, überfällig', () => {
  const w = Object.assign({}, basis, { kalenderWert: 12, kalenderEinheit: 'monate' });
  const letzte = { datum: '2026-01-15', zaehlerstand: null };
  assert.equal(F.berechne({ werte: w, letzte, stand: null, heute: '2026-06-01' }).status, 'ok');
  const bald = F.berechne({ werte: w, letzte, stand: null, heute: '2026-12-20' });
  assert.equal(bald.status, 'bald'); assert.equal(bald.kalender.faelligAm, '2027-01-15'); assert.equal(bald.kalender.tage, 26);
  assert.equal(F.berechne({ werte: w, letzte, stand: null, heute: '2027-01-15' }).status, 'bald');
  const ueber = F.berechne({ werte: w, letzte, stand: null, heute: '2027-01-16' });
  assert.equal(ueber.status, 'ueberfaellig'); assert.equal(ueber.kalender.tage, -1);
});

test('Kalender in Jahren und ohne Vorwarnung', () => {
  const w = Object.assign({}, basis, { kalenderWert: 2, kalenderEinheit: 'jahre', vorwarnTage: 0 });
  const letzte = { datum: '2025-03-10', zaehlerstand: null };
  assert.equal(F.berechne({ werte: w, letzte, stand: null, heute: '2027-03-09' }).status, 'ok');
  assert.equal(F.berechne({ werte: w, letzte, stand: null, heute: '2027-03-10' }).status, 'bald'); /* am Tag selbst */
  assert.equal(F.berechne({ werte: w, letzte, stand: null, heute: '2027-03-11' }).status, 'ueberfaellig');
});

test('Zähler: Ölwechsel 10.000 km, Vorwarnung 500 km', () => {
  const w = Object.assign({}, basis, { zaehlerId: 'z1', zaehlerWert: 10000, vorwarnZaehler: 500 });
  const letzte = { datum: '2026-01-01', zaehlerstand: 84200 };
  const ok = F.berechne({ werte: w, letzte, stand: { wert: 90000 }, heute: '2026-11-03' });
  assert.equal(ok.status, 'ok'); assert.equal(ok.zaehler.faelligBei, 94200); assert.equal(ok.zaehler.rest, 4200);
  assert.equal(F.berechne({ werte: w, letzte, stand: { wert: 93700 }, heute: '2026-11-03' }).status, 'bald');
  assert.equal(F.berechne({ werte: w, letzte, stand: { wert: 94200 }, heute: '2026-11-03' }).status, 'bald');
  const ueber = F.berechne({ werte: w, letzte, stand: { wert: 94500 }, heute: '2026-11-03' });
  assert.equal(ueber.status, 'ueberfaellig'); assert.equal(ueber.zaehler.rest, -300);
});

test('Zähler ohne Vorwarnung wird erst bei Überschreitung auffällig', () => {
  const w = Object.assign({}, basis, { zaehlerId: 'z1', zaehlerWert: 100 });
  const letzte = { datum: '2026-01-01', zaehlerstand: 50 };
  assert.equal(F.berechne({ werte: w, letzte, stand: { wert: 149 }, heute: '2026-11-03' }).status, 'ok');
  assert.equal(F.berechne({ werte: w, letzte, stand: { wert: 151 }, heute: '2026-11-03' }).status, 'ueberfaellig');
});

test('Was zuerst eintritt, gewinnt: Boot 100 Stunden oder 12 Monate', () => {
  const w = Object.assign({}, basis, { zaehlerId: 'z1', zaehlerWert: 100, kalenderWert: 12, kalenderEinheit: 'monate', vorwarnZaehler: 10 });
  const letzte = { datum: '2026-03-01', zaehlerstand: 200 };
  /* Zähler noch weit weg, Kalender überfällig */
  assert.equal(F.berechne({ werte: w, letzte, stand: { wert: 210 }, heute: '2027-04-01' }).status, 'ueberfaellig');
  /* Kalender in Ordnung, Zähler überschritten */
  const z = F.berechne({ werte: w, letzte, stand: { wert: 305 }, heute: '2026-06-01' });
  assert.equal(z.status, 'ueberfaellig'); assert.equal(z.kalender.status, 'ok'); assert.equal(z.zaehler.status, 'ueberfaellig');
  /* beides in Ordnung */
  assert.equal(F.berechne({ werte: w, letzte, stand: { wert: 250 }, heute: '2026-06-01' }).status, 'ok');
});

test('Zähler ohne Stand oder ohne Ausgangsstand: unbekannt statt falscher Zahlen', () => {
  const w = Object.assign({}, basis, { zaehlerId: 'z1', zaehlerWert: 100 });
  const a = F.berechne({ werte: w, letzte: { datum: '2026-01-01', zaehlerstand: 50 }, stand: null, heute: '2026-11-03' });
  assert.equal(a.status, 'unbekannt'); assert.ok(a.zaehler.grund);
  const b = F.berechne({ werte: w, letzte: { datum: '2026-01-01', zaehlerstand: null }, stand: { wert: 10 }, heute: '2026-11-03' });
  assert.equal(b.status, 'unbekannt');
  /* Überfälliger Kalender schlägt "unbekannt" */
  const w2 = Object.assign({}, w, { kalenderWert: 6, kalenderEinheit: 'monate' });
  assert.equal(F.berechne({ werte: w2, letzte: { datum: '2025-01-01', zaehlerstand: null }, stand: null, heute: '2026-11-03' }).status, 'ueberfaellig');
});

test('Reihenfolge und Beschriftungen', () => {
  assert.ok(F.rang('ueberfaellig') > F.rang('bald'));
  assert.ok(F.rang('bald') > F.rang('unbekannt'));
  assert.ok(F.rang('unbekannt') > F.rang('ok'));
  assert.equal(F.labelVon(F.WIRKUNGEN, 'sperre'), 'Sperre');
  assert.equal(F.zaehlerArt('stunden').einheit, 'h');
  assert.equal(F.felder(false).some(f => f.key === 'zuletztAm'), false);
  assert.equal(F.felder(true).some(f => f.key === 'zuletztAm'), true);
});
