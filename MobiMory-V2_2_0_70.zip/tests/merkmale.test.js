'use strict';
/* 2.0.45, Punkt 2: Merkmale mit Liste, Einheit und Bezugsgröße. */
const test = require('node:test');
const assert = require('node:assert/strict');
['version', 'fahrzeugarten', 'komponenten', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'logbuch', 'status', 'motoren', 'personen', 'orte',
  'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte', 'daten'].forEach(n => require('../js/' + n + '.js'));
const MM = globalThis.MM;

async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(Date.UTC(2026, 10, 6, 12, 0, t++)).toISOString() });
  await d.starten();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  return { d, boot };
}
const merkmale = async (c, id) => (await c.d.komponenteLaden(id)).aktuell.werte.merkmale;

test('Listen: Vorlage ist da, die App ist nie nackt, nichts wird von selbst in eine Komponente geschrieben', async () => {
  const c = await neu();
  const m = await c.d.merkmaleListe(), e = await c.d.einheitenListe();
  assert.ok(m.some(x => x.label === 'Leistung' && x.einheit === 'kW'));
  assert.ok(m.some(x => x.label === 'Verbrauch' && x.bezug === 'Betriebsstunde'));
  ['kW', 'PS', 'l', 'kg', 'bar', 'V', 'A', 'Ah', 'W', 'mm', 'cm', 'm', 'cm³'].forEach(u => assert.ok(e.some(x => x.label === u), u));
  const k = (await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'Motor' })).id;
  assert.deepEqual(await merkmale(c, k), []);
});

test('Zeile mit Einheit und Bezugsgröße speichern, Verlauf zeigt die Änderung, Anzeige mit Einheit', async () => {
  const c = await neu();
  const k = (await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'Motor', merkmale: [{ name: 'Verbrauch', wert: '8', einheit: 'l', bezug: '100 km' }] })).id;
  assert.deepEqual(await merkmale(c, k), [{ name: 'Verbrauch', wert: '8', einheit: 'l', bezug: '100 km' }]);
  assert.equal(MM.Komponenten.merkmalText((await merkmale(c, k))[0]), 'Verbrauch: 8 l, bezogen auf 100 km');
  const r = await c.d.komponenteAendern(k, { bezeichnung: 'Motor', merkmale: [{ name: 'Verbrauch', wert: '9', einheit: 'l', bezug: 'Betriebsstunde' }] });
  assert.ok(r.geaendert);
  const v = (await c.d.komponenteLaden(k)).verlauf[0];
  const u = v.aenderungen.find(x => x.key === 'merkmale');
  assert.equal(MM.Hilfen.wert(u.feld, u.alt), 'Verbrauch: 8 l, bezogen auf 100 km');
  assert.equal(MM.Hilfen.wert(u.feld, u.neu), 'Verbrauch: 9 l, bezogen auf Betriebsstunde');
});

test('Einheit muss aus der Liste kommen; eine neue Einheit im Formular kommt in die Liste', async () => {
  const c = await neu();
  const f = await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'Motor', merkmale: [{ name: 'Fahrt', wert: '7', einheit: 'Knoten' }] });
  assert.equal(f.ok, false);
  assert.ok(f.fehler.merkmale.includes('Knoten'));
  assert.equal((await c.d.komponentenListe(c.boot)).length, 0);
  const r = await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'Motor', merkmale: [{ name: 'Fahrt', wert: '7', neueEinheit: 'kn' }, { name: 'Fahrt max', wert: '9', neueEinheit: 'KN' }] });
  assert.ok(r.ok);
  const e = (await c.d.einheitenListe()).filter(x => x.label.toLowerCase() === 'kn');
  assert.equal(e.length, 1);
  assert.equal(e[0].eigen, true);
  assert.deepEqual((await merkmale(c, r.id)).map(z => z.einheit), ['kn', 'kn']);
  assert.ok((await c.d.einheitAnlegen('kn')).fehler.bezeichnung);
  assert.ok((await c.d.einheitAnlegen('')).fehler.bezeichnung);
  assert.ok((await c.d.einheitAnlegen('x'.repeat(21))).fehler.bezeichnung);
});

test('Neues Merkmal im Formular kommt in die Liste, alte Zeilen füllen sie nicht von selbst', async () => {
  const c = await neu();
  const alt = (await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'Motor', merkmale: [{ name: 'Farbe', wert: 'blau' }] })).id;
  assert.ok((await c.d.merkmaleListe()).some(x => x.label === 'Farbe'), 'neu eingegeben');
  const c2 = await neu();
  const id = (await c2.d.komponenteAnlegen(c2.boot, null, 'motor', { bezeichnung: 'M' })).id;
  await c2.d.speicher.speichern('komponenteneintraege', { id: 'ke-alt', komponenteId: id, nr: 2, werte: { bezeichnung: 'M', merkmale: [{ name: 'Altlast', wert: '1' }] }, quelle: 'hand', korrekturZu: null, erstelltAm: 'x' });
  const r = await c2.d.komponenteAendern(id, { bezeichnung: 'M2', merkmale: [{ name: 'Altlast', wert: '1' }] });
  assert.ok(r.ok);
  assert.ok(!(await c2.d.merkmaleListe()).some(x => x.label === 'Altlast'));
  assert.ok(alt);
});

test('Alte Zeilen ohne Einheit bleiben gültig, bleiben unverändert und lassen sich ergänzen', async () => {
  const c = await neu();
  const id = (await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'Motor', merkmale: [{ name: 'Leistung', wert: '110 kW' }] })).id;
  assert.deepEqual(await merkmale(c, id), [{ name: 'Leistung', wert: '110 kW' }]);
  assert.equal((await c.d.komponenteAendern(id, { bezeichnung: 'Motor', merkmale: [{ name: 'Leistung', wert: '110 kW', einheit: '', bezug: '' }] })).geaendert, false);
  assert.ok((await c.d.komponenteAendern(id, { bezeichnung: 'Motor', merkmale: [{ name: 'Leistung', wert: '110', einheit: 'kW' }] })).geaendert);
  assert.deepEqual(await merkmale(c, id), [{ name: 'Leistung', wert: '110', einheit: 'kW' }]);
});

test('Prüfung: Name und Wert Pflicht, Längen begrenzt', async () => {
  const c = await neu();
  const f = async z => (await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'M', merkmale: [z] })).fehler || {};
  assert.ok((await f({ name: 'Leistung', wert: '' })).merkmale);
  assert.ok((await f({ name: '', wert: '5', einheit: 'kW' })).merkmale);
  assert.ok((await f({ name: 'X', wert: '5', bezug: 'y'.repeat(41) })).merkmale);
});

test('Listen verwalten: eigenes Merkmal anlegen, ausblenden, einblenden; Einheit ausblenden; doppelt nicht', async () => {
  const c = await neu();
  const e = await c.d.einheitAnlegen('m²');
  assert.ok(e.ok);
  assert.ok((await c.d.merkmalAnlegen('Segelfläche', 'm²', '')).ok);
  assert.ok((await c.d.merkmalAnlegen('segelfläche', '', '')).fehler.name);
  assert.ok((await c.d.merkmalAnlegen('Ding', 'Zoll', '')).fehler.einheit);
  const m = (await c.d.merkmaleListe()).find(x => x.label === 'Segelfläche');
  assert.equal(m.eigen, true);
  await c.d.merkmalAusblenden('Leistung', true);
  assert.equal((await c.d.merkmaleListe()).find(x => x.label === 'Leistung').ausgeblendet, true);
  await c.d.merkmalAusblenden('Leistung', false);
  assert.equal((await c.d.merkmaleListe()).find(x => x.label === 'Leistung').ausgeblendet, false);
  await c.d.einheitAusblenden('PS', true);
  assert.equal((await c.d.einheitenListe()).find(x => x.label === 'PS').ausgeblendet, true);
  /* Eine ausgeblendete Einheit bleibt an alten Zeilen gültig. */
  assert.ok((await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'M', merkmale: [{ name: 'Leistung', wert: '150', einheit: 'PS' }] })).ok);
});

test('Sicherung nimmt Listen und Zeilen mit, Datenbank-Version bleibt 16', async () => {
  const c = await neu();
  await c.d.einheitAnlegen('kn');
  const id = (await c.d.komponenteAnlegen(c.boot, null, 'motor', { bezeichnung: 'M', merkmale: [{ name: 'Fahrt', wert: '7', einheit: 'kn', bezug: 'Stunde' }] })).id;
  const s = await c.d.sicherungErzeugen({});
  const d2 = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher());
  await d2.starten();
  await d2.sicherungEinspielen(await d2.sicherungLesen(s.bytes, ''));
  assert.ok((await d2.einheitenListe()).some(x => x.label === 'kn'));
  assert.ok((await d2.merkmaleListe()).some(x => x.label === 'Fahrt'));
  assert.deepEqual((await d2.komponenteLaden(id)).aktuell.werte.merkmale, [{ name: 'Fahrt', wert: '7', einheit: 'kn', bezug: 'Stunde' }]);
  assert.equal(MM.Speicher.DB_VERSION, 16);
});
