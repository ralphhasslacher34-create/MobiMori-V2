'use strict';
/* 2.0.67 (Schritt 13c): Freigaben in der App, reine Rechnung (js/freigaben.js): Eingaben, Codes, Link, Ansicht aus den Datensätzen des Dienstes. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
['version', 'fahrzeugarten', 'fristen', 'hilfen', 'konto', 'freigaben'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const F = MM.Freigaben;
const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

const HEUTE = '2026-11-11';

test('Einladung prüfen: gültige Eingabe, Standard „von“ ist heute', () => {
  const r = F.einladung({ fahrzeugId: 'fz-1', email: ' Gast@Example.org ', bis: '2027-03-31' }, HEUTE);
  assert.equal(r.ok, true);
  assert.deepEqual(r.werte, { fahrzeugId: 'fz-1', email: 'gast@example.org', ab: HEUTE, bis: '2027-03-31' });
});

test('Einladung prüfen: höchstens 12 Monate ab „von“, Monatsende bleibt Monatsende', () => {
  assert.equal(F.einladung({ fahrzeugId: 'a', email: 'g@example.org', bis: '2027-11-11' }, HEUTE).ok, true);
  const zu = F.einladung({ fahrzeugId: 'a', email: 'g@example.org', bis: '2027-11-12' }, HEUTE);
  assert.equal(zu.ok, false); assert.match(zu.fehler.bis, /höchstens 12 Monate/); assert.match(zu.fehler.bis, /2027-11-11/);
  assert.equal(F.einladung({ fahrzeugId: 'a', email: 'g@example.org', ab: '2027-01-15', bis: '2028-01-15' }, HEUTE).ok, true);
  assert.equal(F.plusMonate('2026-02-28', 12), '2027-02-28'); assert.equal(F.plusMonate('2024-02-29', 12), '2025-02-28'); assert.equal(F.plusMonate('2026-01-31', 1), '2026-02-28');
});

test('Einladung prüfen: Fehler je Feld in einfachen Worten', () => {
  const r = F.einladung({ fahrzeugId: '', email: 'keine', ab: '2026-11-10', bis: '' }, HEUTE);
  assert.equal(r.ok, false);
  assert.deepEqual(Object.keys(r.fehler).sort(), ['ab', 'bis', 'email', 'fahrzeugId']);
  assert.match(F.einladung({ fahrzeugId: 'a', email: 'g@example.org', bis: '2026-11-10' }, HEUTE).fehler.bis, /vor dem Datum/);
  assert.match(F.einladung({ fahrzeugId: 'a', email: 'g@example.org', bis: '31.03.2027' }, HEUTE).fehler.bis, /als Tag/);
  assert.match(F.einladung({ fahrzeugId: 'a', email: 'g@example.org', bis: '2027-02-30' }, HEUTE).fehler.bis, /als Tag/);
});

test('Codes: Einladung 10 Zeichen, Kontrolle 8 Zeichen, Groß und Klein, mit Strich und Leerzeichen; falsche Zeichen werden abgelehnt', () => {
  assert.deepEqual(F.codeEinladung(' abcde-fghjk '), { ok: true, code: 'ABCDEFGHJK' });
  assert.equal(F.codeEinladung('ABCDE-FGHJ').ok, false);
  assert.equal(F.codeEinladung('ABCDEFGHJ0').ok, false, 'die Null gibt es nicht (verwechselbar)');
  assert.equal(F.codeEinladung('ABCDEFGHIJ').ok, false, 'das I gibt es nicht');
  assert.deepEqual(F.codeKontrolle('abcd efgh'), { ok: true, code: 'ABCDEFGH' });
  assert.equal(F.codeKontrolle('ABCDEFG').ok, false);
  assert.equal(F.codeKontrolle(null).ok, false);
  assert.equal(F.codeAnzeige('ABCDEFGH'), 'ABCD-EFGH'); assert.equal(F.codeAnzeige('ABCDEFGHJK'), 'ABCDE-FGHJK');
});

test('Kontroll-Gültigkeit: 1 bis 168 Stunden', () => {
  assert.equal(F.stunden(24).ok, true); assert.equal(F.stunden('168').ok, true);
  [0, 169, 1.5, 'x', null].forEach((x) => assert.equal(F.stunden(x).ok, false));
  assert.deepEqual(F.KONTROLLE_STUNDEN.map((x) => x.wert), [1, 4, 24, 72, 168]);
});

test('Kontroll-Link: App-Adresse, Code und Dienst; ohne Anhang der alten Seite; wieder lesbar', () => {
  const link = F.kontrollLink('https://app.example.org/V2/#/funktionen', 'https://konto.example.workers.dev', 'ABCDEFGH');
  assert.equal(link, 'https://app.example.org/V2/#/kontrolle/ABCDEFGH/https%3A%2F%2Fkonto.example.workers.dev');
  const teile = link.replace(/^.*#/, '').split('/').filter(Boolean);
  assert.deepEqual(F.kontrollLinkLesen(teile[1], teile[2]), { code: 'ABCDEFGH', dienstUrl: 'https://konto.example.workers.dev' });
  assert.deepEqual(F.kontrollLinkLesen('abcd-efgh', 'https%3A%2F%2Fkonto.example.workers.dev%2Fgesundheit'), { code: 'ABCDEFGH', dienstUrl: 'https://konto.example.workers.dev' });
  assert.deepEqual(F.kontrollLinkLesen('%E0%A4%A', '%'), { code: '', dienstUrl: '' }, 'kaputte Zeichen im Link werfen nicht');
  assert.deepEqual(F.kontrollLinkLesen('', ''), { code: '', dienstUrl: '' });
  assert.deepEqual(F.kontrollLinkLesen('ABCDEFGH', 'http://boese.example.net'), { code: 'ABCDEFGH', dienstUrl: '' }, 'Dienst nur mit https');
});

/* Datensätze, wie der Dienst sie liefert */
const ds = (tabelle, o) => ({ tabelle, id: o.id, nutzlast: JSON.stringify(o) });
function beispiel() {
  return [
    ds('fahrzeuge', { id: 'fz-1', datenraumId: '@', art: 'wohnmobil', erstelltAm: 1 }),
    ds('eintraege', { id: 'en-2', fahrzeugId: 'fz-1', nr: 2, werte: { bezeichnung: 'Mein Wohnmobil', kennzeichen: 'LB-AB 123' }, erstelltAm: 2 }),
    ds('fristen', { id: 'fr-1', fahrzeugId: 'fz-1', komponenteId: null, erstelltAm: 1 }),
    ds('verlaeufe', { id: 'v1', objektTyp: 'frist', objektId: 'fr-1', nr: 1, werte: { bezeichnung: 'Hauptuntersuchung', kalenderWert: 2, kalenderEinheit: 'jahre', vorwarnTage: 30, wirkung: 'sperre' } }),
    ds('verlaeufe', { id: 'v1b', objektTyp: 'frist', objektId: 'fr-1', nr: 2, werte: { bezeichnung: 'HU/AU', kalenderWert: 2, kalenderEinheit: 'jahre', vorwarnTage: 30, wirkung: 'sperre' } }),
    ds('durchfuehrungen', { id: 'du-0', fristId: 'fr-1', datum: '2023-03-01', zaehlerstand: null }),
    ds('durchfuehrungen', { id: 'du-1', fristId: 'fr-1', datum: '2025-03-01', zaehlerstand: null }),
    ds('fristen', { id: 'fr-2', fahrzeugId: 'fz-1', komponenteId: null, erstelltAm: 1 }),
    ds('verlaeufe', { id: 'v2', objektTyp: 'frist', objektId: 'fr-2', nr: 1, werte: { bezeichnung: 'Ölwechsel', zaehlerId: 'za-1', zaehlerWert: 10000, vorwarnZaehler: 1000 } }),
    ds('durchfuehrungen', { id: 'du-2', fristId: 'fr-2', datum: '2025-12-01', zaehlerstand: 42000 }),
    ds('fristen', { id: 'fr-3', fahrzeugId: 'fz-1', komponenteId: null, erstelltAm: 1 }),
    ds('verlaeufe', { id: 'v3', objektTyp: 'frist', objektId: 'fr-3', nr: 1, werte: { bezeichnung: 'Gasprüfung', kalenderWert: 2, kalenderEinheit: 'jahre', vorwarnTage: 30 } }),
    ds('durchfuehrungen', { id: 'du-3', fristId: 'fr-3', datum: '2024-10-01', zaehlerstand: null }),
    ds('zaehler', { id: 'za-1', fahrzeugId: 'fz-1', komponenteId: null, art: 'strecke', erstelltAm: 1 }),
    ds('verlaeufe', { id: 'v4', objektTyp: 'zaehler', objektId: 'za-1', nr: 1, werte: { bezeichnung: 'Kilometerstand' } }),
    ds('zaehlerstaende', { id: 'zs-1', zaehlerId: 'za-1', nr: 1, wert: 50000, datum: '2026-10-01' }),
    ds('zaehlerstaende', { id: 'zs-0', zaehlerId: 'za-1', nr: 0, wert: 41000, datum: '2025-12-01' }),
    ds('dokumente', { id: 'do-1', fahrzeugId: 'fz-1', komponenteId: null, vorgangId: null, erstelltAm: 1 }),
    ds('verlaeufe', { id: 'v5', objektTyp: 'dokument', objektId: 'do-1', nr: 1, werte: { bezeichnung: 'Fahrzeugschein', art: 'Papiere', link: null } }),
    ds('dateien', { id: 'da-1', dokumentId: 'do-1', name: 'schein.pdf', mime: 'application/pdf', groesse: 11 }),
    ds('dokumente', { id: 'do-2', fahrzeugId: 'fz-1', komponenteId: null, vorgangId: null, erstelltAm: 1 }),
    ds('verlaeufe', { id: 'v6', objektTyp: 'dokument', objektId: 'do-2', nr: 1, werte: { bezeichnung: 'Anleitung', art: 'Anleitung', link: 'https://www.beispiel.de/a.pdf' } }),
    ds('tagespruefungen', { id: 'tp-1', aktivitaetId: 'ak-1', erstelltAm: 5, stand: { geprueftAm: '2026-11-01T08:00', tagesbeginn: '2026-11-01', ergebnis: 'erlaubt', fristen: { betroffen: 1, sperre: 0, eingeschraenkt: 1 } } })
  ];
}

test('Ansicht: Fahrzeug mit neuestem Eintrag und Kennung', () => {
  const s = F.sicht(beispiel(), HEUTE);
  assert.equal(s.fahrzeug.bezeichnung, 'Mein Wohnmobil'); assert.equal(s.fahrzeug.id, 'fz-1');
  assert.equal(s.fahrzeug.kennung, 'LB-AB 123');
});

test('Ansicht: Fristen mit Stand (Kalender, Zähler, Erledigung), schlechteste zuerst', () => {
  const s = F.sicht(beispiel(), HEUTE);
  assert.deepEqual(s.fristen.map((x) => [x.name, x.status]), [['Gasprüfung', 'ueberfaellig'], ['HU/AU', 'ok'], ['Ölwechsel', 'ok']].sort((a, b) => MM.Fristen.rang(b[1]) - MM.Fristen.rang(a[1]) || (a[0] < b[0] ? -1 : 1)));
  const hu = s.fristen.filter((x) => x.name === 'HU/AU')[0];
  assert.equal(hu.text, 'fällig am 01.03.2027 (in 110 Tagen), zuletzt erledigt am 01.03.2025', 'der neueste Verlauf gibt den Namen, die neueste Erledigung gilt');
  const oel = s.fristen.filter((x) => x.name === 'Ölwechsel')[0];
  assert.match(oel.text, /fällig bei 52\.000 km/); assert.match(oel.text, /zuletzt erledigt am 01\.12\.2025/);
  const gas = s.fristen.filter((x) => x.name === 'Gasprüfung')[0];
  assert.match(gas.text, /^überfällig seit 01\.10\.2026 \(41 Tagen\)/);
});

test('Ansicht: Zähler mit letztem Stand, Dokumente mit Dateien und Link, Prüfergebnis', () => {
  const s = F.sicht(beispiel(), HEUTE);
  assert.deepEqual(s.zaehler, [{ id: 'za-1', name: 'Kilometerstand', einheit: 'km', stand: 50000, datum: '2026-10-01' }]);
  assert.deepEqual(s.dokumente.map((d) => [d.bezeichnung, d.dateien.length, d.link]), [['Anleitung', 0, 'https://www.beispiel.de/a.pdf'], ['Fahrzeugschein', 1, null]]);
  assert.deepEqual(s.dokumente[1].dateien, [{ id: 'da-1', name: 'schein.pdf', mime: 'application/pdf', groesse: 11 }]);
  assert.deepEqual(s.pruefung, { geprueftAm: '2026-11-01T08:00', tagesbeginn: '2026-11-01', ergebnis: 'erlaubt', ergebnisText: 'Erlaubt', fristen: { betroffen: 1, sperre: 0, eingeschraenkt: 1 } });
});

test('Ansicht: ohne Fahrzeug nichts; kaputte oder fremde Datensätze werden übergangen; ein Link ohne https nicht angezeigt', () => {
  assert.equal(F.sicht([], HEUTE), null);
  assert.equal(F.sicht(null, HEUTE), null);
  const s = F.sicht([ds('fahrzeuge', { id: 'fz-1', art: 'auto' }), { tabelle: 'eintraege', id: 'x', nutzlast: '{kaputt' }, { tabelle: 'eintraege', id: 'y', nutzlast: JSON.stringify({ id: 'andere', werte: { bezeichnung: 'falsch' } }) },
    ds('dokumente', { id: 'do-9', fahrzeugId: 'fz-1' }), ds('verlaeufe', { id: 'v', objektTyp: 'dokument', objektId: 'do-9', nr: 1, werte: { bezeichnung: 'Böse', link: 'javascript:alert(1)' } })], HEUTE);
  assert.equal(s.fahrzeug.bezeichnung, 'Fahrzeug'); assert.equal(s.pruefung, null);
  assert.equal(s.dokumente[0].link, null, 'nur http und https werden zum Link');
});

test('Ansicht: Frist ohne Erledigung hat „noch kein Stand“, Zähler ohne Stand „unbekannt“', () => {
  const s = F.sicht([ds('fahrzeuge', { id: 'fz-1', art: 'auto' }), ds('fristen', { id: 'fr-1', fahrzeugId: 'fz-1' }), ds('verlaeufe', { id: 'v', objektTyp: 'frist', objektId: 'fr-1', nr: 1, werte: { bezeichnung: 'Reifen', kalenderWert: 1, kalenderEinheit: 'jahre' } })], HEUTE);
  assert.deepEqual([s.fristen[0].status, s.fristen[0].text], ['unbekannt', 'noch kein Stand bekannt']);
});

test('Texte: Freigabe und Kontrolle sagen, was gesehen wird und was nie', () => {
  assert.match(F.TEXT_FREIGABE, /nur zum Lesen/); assert.match(F.TEXT_FREIGABE, /12 Monaten/); assert.match(F.TEXT_FREIGABE, /Nachweis-Scans/); assert.match(F.TEXT_FREIGABE, /widerrufen/);
  assert.match(F.TEXT_KONTROLLE, /7 Tage/); assert.match(F.TEXT_KONTROLLE, /ohne eigenes Konto/); assert.match(F.TEXT_KONTROLLE, /nur jetzt angezeigt/);
});

test('Dienst und App führen dieselben Grenzen: 12 Monate, 168 Stunden, Zeichen der Codes', () => {
  const d = lesen('server/konto-dienst.mjs');
  assert.match(d, /const FREIGABE_MONATE = 12;/); assert.match(d, /const KONTROLLE_MAX_STUNDEN = 168;/);
  assert.ok(d.includes("const CODE_ZEICHEN = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';"));
  assert.match(d, /const EINLADUNG_CODE_LAENGE = 10;/); assert.match(d, /const KONTROLLE_CODE_LAENGE = 8;/);
  const a = lesen('js/freigaben.js');
  assert.ok(a.includes("var CODE_ZEICHEN = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';")); assert.match(a, /var MAX_MONATE = 12;/); assert.match(a, /var EINLADUNG_CODE = 10;/); assert.match(a, /var KONTROLLE_CODE = 8;/);
  assert.equal(F.KONTROLLE_STUNDEN[F.KONTROLLE_STUNDEN.length - 1].wert, 168);
});

test('Einbindung: Seiten, Kachel, Skript, Offline-Liste', () => {
  const an = lesen('js/ansicht.js');
  assert.match(an, /teile\[0\] === 'freigaben'\) p = seiteFreigaben\(\)/);
  assert.match(an, /teile\[0\] === 'geteilt' && teile\[1\]\) p = seiteGeteilt\(/);
  assert.match(an, /teile\[0\] === 'kontrolle'\) p = seiteKontrolle\(/);
  assert.match(an, /kachel\('Freigaben'/);
  assert.ok(lesen('index.html').includes('js/freigaben.js')); assert.ok(lesen('sw.js').includes("'js/freigaben.js'"));
  assert.ok(lesen('server/EINRICHTUNG.md').includes('13c.sql'));
});

test('Kein Zugriff der App auf Orte, die nicht zur Freigabe gehören: Die Ansicht liest nur die freigegebenen Tabellen', () => {
  const a = lesen('js/freigaben.js');
  ['kosten', 'nachweise', 'reisechecks', 'routen', 'besuche', 'ereignisse', 'aktivitaeten', 'personen', 'orte', 'notiz', 'spur'].forEach((n) => assert.ok(!new RegExp("liste\\('" + n + "'\\)").test(a), n + ' wird nicht gelesen'));
});
