'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/fristen.js');
require('../js/hilfen.js');
require('../js/aktivitaeten.js');
const A = globalThis.MM.Aktivitaeten;

test('Zeitpunkte: ohne Uhrzeit Tagesanfang, beim Ende Tagesende', () => {
  assert.equal(A.zeitpunkt('2026-07-01', null, false), '2026-07-01T00:00');
  assert.equal(A.zeitpunkt('2026-07-01', null, true), '2026-07-01T23:59');
  assert.equal(A.zeitpunkt('2026-07-01', '14:30', true), '2026-07-01T14:30');
  assert.equal(A.zeitpunkt(null, null), null);
});

test('Status: geplant, läuft, vorbei, storniert', () => {
  const w = { vonDatum: '2026-07-01', bisDatum: '2026-07-10' };
  assert.equal(A.status(w, '2026-06-30T23:59'), 'geplant');
  assert.equal(A.status(w, '2026-07-01T00:00'), 'laeuft');
  assert.equal(A.status(w, '2026-07-10T23:59'), 'laeuft');
  assert.equal(A.status(w, '2026-07-11T00:00'), 'vorbei');
  assert.equal(A.status(Object.assign({ status: 'storniert' }, w), '2026-07-05T00:00'), 'storniert');
});

test('Überschneidung: Aneinanderstoßen zählt nicht, ganze Tage überschneiden sich', () => {
  const a = { vonDatum: '2026-07-01', vonZeit: '08:00', bisDatum: '2026-07-01', bisZeit: '12:00' };
  assert.equal(A.ueberschneiden(a, { vonDatum: '2026-07-01', vonZeit: '12:00', bisDatum: '2026-07-01', bisZeit: '18:00' }), false);
  assert.equal(A.ueberschneiden(a, { vonDatum: '2026-07-01', vonZeit: '11:59', bisDatum: '2026-07-01', bisZeit: '18:00' }), true);
  assert.equal(A.ueberschneiden({ vonDatum: '2026-07-01', bisDatum: '2026-07-10' }, { vonDatum: '2026-07-10', bisDatum: '2026-07-12' }), true, 'ganze Tage');
  assert.equal(A.ueberschneiden({ vonDatum: '2026-07-01', bisDatum: '2026-07-09' }, { vonDatum: '2026-07-10', bisDatum: '2026-07-12' }), false);
});

test('Verantwortlich: zu jedem Zeitpunkt genau einer, Wechsel mit Zeitpunkt', () => {
  const e = [{ ab: '2026-07-01T00:00', id: 'anna' }, { ab: '2026-07-05T14:00', id: 'ben' }, { ab: '2026-07-08T09:00', id: 'anna2' }];
  assert.equal(A.verantwortlicher(e, '2026-06-01T00:00').id, 'anna', 'vor dem Beginn: der erste');
  assert.equal(A.verantwortlicher(e, '2026-07-05T13:59').id, 'anna');
  assert.equal(A.verantwortlicher(e, '2026-07-05T14:00').id, 'ben');
  assert.equal(A.verantwortlicher(e, '2026-07-20T00:00').id, 'anna2');
  assert.equal(A.verantwortlicher([], '2026-07-01T00:00'), null);
});

test('Bezeichnung nach Fahrzeugwelt: Skipper, Fahrer, Verantwortlicher', () => {
  assert.equal(A.rolleLabel('verantwortlich', 'wasser'), 'Skipper');
  assert.equal(A.rolleLabel('verantwortlich', 'land'), 'Fahrer');
  assert.equal(A.rolleLabel('verantwortlich', 'luft'), 'Verantwortlicher');
  assert.equal(A.rolleLabel('stellvertreter', 'wasser'), 'Stellvertreter');
  assert.equal(A.rolleLabel('crew', 'land'), 'Crew');
});

const anf = [{ bezeichnung: 'Sportbootführerschein', artIds: ['sbf'] }];
const nw = (artId, werte, hatAblauf) => ({ artId, artName: artId.toUpperCase(), hatAblauf: !!hatAblauf, werte });

test('Befähigung: erlaubt nur mit Scan und gültig bis zum Ende des Zeitraums', () => {
  const r = A.pruefeBefaehigung({ anforderungen: anf, nachweise: [nw('sbf', { dateiName: 'sbf.jpg' }, false)], endDatum: '2026-08-01' });
  assert.equal(r.ergebnis, 'erlaubt');
  const mitAblauf = A.pruefeBefaehigung({ anforderungen: [{ bezeichnung: 'Führerschein B', artIds: ['fs'] }], nachweise: [nw('fs', { dateiName: 'x.jpg', gueltigBis: '2026-08-01' }, true)], endDatum: '2026-08-01' });
  assert.equal(mitAblauf.ergebnis, 'erlaubt', 'gültig bis zum Ende genügt');
});

test('Befähigung: läuft vor dem Ende ab = nicht erlaubt, auch wenn er heute noch gilt', () => {
  const r = A.pruefeBefaehigung({ anforderungen: [{ bezeichnung: 'Führerschein B', artIds: ['fs'] }], nachweise: [nw('fs', { dateiName: 'x.jpg', gueltigBis: '2026-07-31' }, true)], endDatum: '2026-08-01' });
  assert.equal(r.ergebnis, 'nicht_erlaubt');
  assert.ok(r.gruende[0].text.includes('2026-07-31'));
});

test('Befähigung: ohne Scan, ohne Nachweis oder ohne Ablaufdatum = unklar, nie "nicht erlaubt"', () => {
  assert.equal(A.pruefeBefaehigung({ anforderungen: anf, nachweise: [nw('sbf', {}, false)], endDatum: '2026-08-01' }).ergebnis, 'unklar');
  assert.equal(A.pruefeBefaehigung({ anforderungen: anf, nachweise: [], endDatum: '2026-08-01' }).ergebnis, 'unklar');
  assert.equal(A.pruefeBefaehigung({ anforderungen: anf, nachweise: [nw('andere', { dateiName: 'x' }, false)], endDatum: '2026-08-01' }).ergebnis, 'unklar');
  const ohneDatum = A.pruefeBefaehigung({ anforderungen: [{ bezeichnung: 'B', artIds: ['fs'] }], nachweise: [nw('fs', { dateiName: 'x' }, true)], endDatum: '2026-08-01' });
  assert.equal(ohneDatum.ergebnis, 'unklar'); assert.ok(ohneDatum.gruende[0].text.includes('Ablaufdatum'));
});

test('Befähigung: abgelaufen, aber ein anderer gültiger Nachweis der Anforderung genügt', () => {
  const r = A.pruefeBefaehigung({
    anforderungen: [{ bezeichnung: 'Funk', artIds: ['src', 'ubi'] }],
    nachweise: [nw('src', { dateiName: 'a', gueltigBis: '2020-01-01' }, true), nw('ubi', { dateiName: 'b' }, false)], endDatum: '2026-08-01' });
  assert.equal(r.ergebnis, 'erlaubt');
});

test('Befähigung: mehrere Anforderungen, eine fehlt = unklar, eine abgelaufen = nicht erlaubt', () => {
  const zwei = [{ bezeichnung: 'SBF', artIds: ['sbf'] }, { bezeichnung: 'Funk', artIds: ['src'] }];
  assert.equal(A.pruefeBefaehigung({ anforderungen: zwei, nachweise: [nw('sbf', { dateiName: 'x' }, false)], endDatum: '2026-08-01' }).ergebnis, 'unklar');
  assert.equal(A.pruefeBefaehigung({ anforderungen: zwei, nachweise: [nw('sbf', { dateiName: 'x' }, false), nw('src', { dateiName: 'y', gueltigBis: '2020-01-01' }, true)], endDatum: '2026-08-01' }).ergebnis, 'nicht_erlaubt');
  assert.equal(A.pruefeBefaehigung({ anforderungen: [], nachweise: [], endDatum: '2026-08-01' }).ergebnis, 'unklar');
});

test('Gesamtergebnis mehrerer Personen', () => {
  assert.equal(A.gesamtErgebnis(['erlaubt', 'erlaubt']), 'erlaubt');
  assert.equal(A.gesamtErgebnis(['erlaubt', 'unklar']), 'unklar');
  assert.equal(A.gesamtErgebnis(['unklar', 'nicht_erlaubt']), 'nicht_erlaubt');
  assert.equal(A.gesamtErgebnis([]), 'unklar');
});

const frist = (w, letzte, zaehler) => ({ bezeichnung: w.bezeichnung || 'F', werte: Object.assign({ wirkung: 'warnen', kalenderWert: null, zaehlerId: null, zaehlerWert: null }, w), letzte, zaehler });

test('Fristen im Zeitraum: Kalender fällig im Zeitraum, davor, danach, schon überfällig', () => {
  const p = (letzteDatum) => A.fristenImZeitraum({ fristen: [frist({ kalenderWert: 12, kalenderEinheit: 'monate' }, { datum: letzteDatum, zaehlerstand: null }, null)], heute: '2026-11-03', endDatum: '2026-12-01' })[0];
  assert.equal(p('2025-11-20').status, 'faellig', 'fällig am 20.11.2026, im Zeitraum');
  assert.equal(p('2025-12-01').status, 'faellig', 'am letzten Tag');
  assert.equal(p('2025-12-02').status, 'ok');
  assert.equal(p('2025-10-01').status, 'ueberfaellig');
});

test('Fristen im Zeitraum: Zähler rechnet die geplante Strecke mit', () => {
  const z = { stand: { wert: 90000 }, art: 'strecke', einheit: 'km' };
  const f = frist({ zaehlerId: 'z', zaehlerWert: 10000 }, { datum: '2026-01-01', zaehlerstand: 84200 }, z);
  const r1 = A.fristenImZeitraum({ fristen: [f], heute: '2026-11-03', endDatum: '2026-12-01', geplanteStrecke: 3000 })[0];
  assert.equal(r1.status, 'ok'); assert.ok(r1.text.includes('erwartet'));
  const r2 = A.fristenImZeitraum({ fristen: [f], heute: '2026-11-03', endDatum: '2026-12-01', geplanteStrecke: 5000 })[0];
  assert.equal(r2.status, 'faellig');
  const r3 = A.fristenImZeitraum({ fristen: [f], heute: '2026-11-03', endDatum: '2026-12-01' })[0];
  assert.equal(r3.status, 'ok'); assert.ok(r3.text.includes('ohne geplante Strecke'));
  const ueber = frist({ zaehlerId: 'z', zaehlerWert: 10000 }, { datum: '2026-01-01', zaehlerstand: 70000 }, z);
  assert.equal(A.fristenImZeitraum({ fristen: [ueber], heute: '2026-11-03', endDatum: '2026-12-01' })[0].status, 'ueberfaellig');
});

test('Fristen im Zeitraum: Betriebsstunden nutzen die geplanten Stunden, nicht die Strecke', () => {
  const z = { stand: { wert: 190 }, art: 'stunden', einheit: 'h' };
  const f = frist({ zaehlerId: 'z', zaehlerWert: 100 }, { datum: '2026-01-01', zaehlerstand: 100 }, z);
  assert.equal(A.fristenImZeitraum({ fristen: [f], heute: '2026-11-03', endDatum: '2026-12-01', geplanteStrecke: 5000, geplanteStunden: 5 })[0].status, 'ok');
  assert.equal(A.fristenImZeitraum({ fristen: [f], heute: '2026-11-03', endDatum: '2026-12-01', geplanteStunden: 15 })[0].status, 'faellig');
});

test('Fristen im Zeitraum: Zähler ohne Stand = unbekannt; schlechtester Teil gewinnt; Sortierung; Wirkung', () => {
  const fehlt = frist({ bezeichnung: 'A', zaehlerId: 'z', zaehlerWert: 100 }, { datum: '2026-01-01', zaehlerstand: 5 }, { stand: null, art: 'strecke', einheit: 'km' });
  const beides = frist({ bezeichnung: 'B', kalenderWert: 12, kalenderEinheit: 'monate', zaehlerId: 'z', zaehlerWert: 100, wirkung: 'sperre' },
    { datum: '2025-10-01', zaehlerstand: 0 }, { stand: { wert: 10 }, art: 'strecke', einheit: 'km' });
  const r = A.fristenImZeitraum({ fristen: [fehlt, beides], heute: '2026-11-03', endDatum: '2026-12-01' });
  assert.deepEqual(r.map(x => [x.bezeichnung, x.status]), [['B', 'ueberfaellig'], ['A', 'unbekannt']]);
  assert.equal(r[0].wirkung, 'sperre');
  const z = A.fristenZusammenfassung(r);
  assert.deepEqual(z, { betroffen: 1, sperre: true, eingeschraenkt: false });
  assert.deepEqual(A.fristenZusammenfassung([]), { betroffen: 0, sperre: false, eingeschraenkt: false });
});
