CREATE TABLE IF NOT EXISTS freigabe (id TEXT PRIMARY KEY, datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, fahrzeug_id TEXT NOT NULL, email TEXT NOT NULL, code_hash TEXT NOT NULL, gast_nutzer_id TEXT REFERENCES nutzer(id) ON DELETE CASCADE, erstellt_am INTEGER NOT NULL, ab_am INTEGER NOT NULL, laeuft_ab INTEGER NOT NULL, einladung_bis INTEGER NOT NULL, angenommen_am INTEGER, widerrufen_am INTEGER);
CREATE INDEX IF NOT EXISTS freigabe_raum ON freigabe(datenraum_id);
CREATE INDEX IF NOT EXISTS freigabe_gast ON freigabe(gast_nutzer_id);
CREATE INDEX IF NOT EXISTS freigabe_code ON freigabe(code_hash);
CREATE TABLE IF NOT EXISTS kontrolle (id TEXT PRIMARY KEY, datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, fahrzeug_id TEXT NOT NULL, code_hash TEXT NOT NULL, erstellt_am INTEGER NOT NULL, laeuft_ab INTEGER NOT NULL, widerrufen_am INTEGER);
CREATE INDEX IF NOT EXISTS kontrolle_raum ON kontrolle(datenraum_id);
CREATE INDEX IF NOT EXISTS kontrolle_code ON kontrolle(code_hash);
