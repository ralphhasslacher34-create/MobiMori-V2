# Konto-Dienst: Einrichtung und Updates (Stand 2.0.69, Schritt 13e)

## Was gerade läuft

| | Echter Dienst | Test-Dienst |
|---|---|---|
| Worker | `mobimory-konto` unter **konto.mobimory.com** | `winter-violet-1a11` |
| Datenbank (D1, EU) | `mobimory-konten` | `mobimory-konten-test` (andere ID, nicht verwechseln) |
| Dateispeicher (R2, EU) | `mobimory-daten` | `mobimory-daten-test` |
| Einstellungen | `wrangler-konto.jsonc` | `wrangler.jsonc` |
| Tarif | Workers Paid, Email Sending für mobimory.com (3 000 Mails im Monat enthalten) | – |
| Variablen | `ABSENDER` = konto@mobimory.com, `ERLAUBTE_URSPRUENGE` = https://app.mobimory.com | `ENTWICKLUNG` = 1 |
| Geheimnis | `PASSWORT_PEPPER` (nie ändern, anderer Wert als beim Test-Dienst) | eigener Wert |
| Bindungen | `DB`, `DATEN`, `EMAIL` | `DB`, `DATEN` |

- Deploy-Befehl des echten Dienstes: `npx wrangler deploy --config wrangler-konto.jsonc` (Zweig `main`, Root `/`, Build command leer).
- **Die Variable `ENTWICKLUNG` gibt es im echten Dienst nie.**
- Die App läuft unter **app.mobimory.com**. Der Workflow `veroeffentlichen.yml` macht nur noch Tests.
- Beide Dienste bauen aus derselben Datei `konto-dienst.mjs` im Hauptverzeichnis des Repositorys. Wird sie ersetzt, aktualisieren sich beide.

## Update einspielen (immer so)

1. **Neue SQL-Zeilen** (falls die Version welche hat): D1 → Datenbank → **Console**, **jede Zeile einzeln**. Die Zeilen stehen in einer eigenen Datei in `server/` (`13c.sql`, `13d.sql`, `13e.sql`).
2. **Dateien ins Hauptverzeichnis des Repositorys** (bei GitHub immer **Upload files**, „Create new file“ legt nur leere Dateien an): `konto-dienst.mjs` und, falls geändert, `wrangler-konto.jsonc`. **Zuerst die alte Datei löschen, dann die neue hochladen** und den Dateinamen prüfen (kein Leerzeichen). Sonst baut Cloudflare weiter aus der alten Datei.
3. Cloudflare baut nach ein bis zwei Minuten selbst (Worker → **Deployments**).
4. **Prüfen:** `konto.mobimory.com/gesundheit` aufrufen. Die Version muss stimmen, alles muss `true` sein, `entwicklung` muss `false` sein.

## Update auf 13e (Stufen, Kontingent, Online-Checks, seit 2.0.69)

1. **Tabellen:** Die 6 Zeilen aus `server/13e.sql` in der D1-Console von `mobimory-konten` ausführen, jede einzeln.
2. **Recherche-Dienst eintragen:** Im Worker `mobimory-konto` unter **Settings → Variables and Secrets**:
   - Typ **Text**: `RECHERCHE_URL` = Adresse des Recherche-Dienstes (`https://mobimory-research….workers.dev`, ohne `/research`).
   - Typ **Secret**: `RECHERCHE_TOKEN` = dasselbe Passwort wie `MOBIMORY_TOKEN` im Recherche-Dienst.
   - Sie bleiben bei jedem Bau erhalten (`keep_vars`).
   - Im **Recherche-Dienst** muss bei `ALLOWED_ORIGINS` `https://app.mobimory.com` stehen.
3. **Ihr Konto auf Entwickler (ohne Grenzen) setzen** (Konten von vor 13e gelten sonst als Basic). In der D1-Console, mit Ihrer Mail-Adresse statt `ihre@adresse`:
   `INSERT OR REPLACE INTO stufe_konto (nutzer_id, stufe, gueltig_bis, geaendert_am) SELECT id, 'entwickler', NULL, 0 FROM nutzer WHERE email = 'ihre@adresse';`
   Für andere Konten `'mittel'` oder `'voll'` (`'entwickler'` nur für Sie). Ein Ablauf steht in `gueltig_bis` (Millisekunden seit 1970), `NULL` heißt ohne Ablauf.
4. `konto-dienst.mjs` hochladen (Update einspielen, Schritt 2 bis 4). `/gesundheit` muss `"version":"13e-2"`, `"stufen":true` und `"recherche":true` zeigen.
5. App (ZIP) hochladen, am Tablet neu laden, unter Reisecheck › Zustimmung einmal neu zustimmen.

Der Test-Dienst baut dieselbe Datei. Seine Datenbank hat die 13e-Tabellen nur, wenn Sie die 6 Zeilen dort auch ausführen. Ohne sie funktioniert dort das Anmelden weiter, Online-Checks und Stufen nicht.

Wie es arbeitet:
- Die App spricht nur mit `konto.mobimory.com`. Der Dienst prüft Stufe und Kontingent, zählt und ruft den Recherche-Dienst auf. Dessen Passwort kennt nur der Konto-Dienst.
- Testwoche: 7 Tage, 1 Check, einmal je Mail-Adresse. Danach Basic.
- Stufen und Grenzen stehen in `server/konto-dienst.mjs` (`STUFEN`) und `js/konto.js`. Ein Test vergleicht beide.

## Hinweise

- **Geheimnis:** `PASSWORT_PEPPER` gehört nie in eine Datei, nie in GitHub und nie in einen Chat. Ohne ihn passt kein Passwort mehr.
- **Passwort-Abdruck:** Cloudflare erlaubt höchstens 100 000 Runden, OWASP empfiehlt 600 000. Gehört auf die Liste für den Datenschutz-Fachmann vor dem öffentlichen Start.
- **Wenn etwas schiefgeht:** Worker → **Logs**. Die Meldung abschreiben.
- **Neu von Null** (nur falls je nötig): `server/schema.sql` enthält alle Tabellen, die Einstellungen stehen in `wrangler-konto.jsonc`. Datenbank und Bucket nur beim Anlegen mit Jurisdiktion **EU**.
