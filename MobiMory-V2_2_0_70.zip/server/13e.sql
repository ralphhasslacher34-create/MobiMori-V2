CREATE TABLE IF NOT EXISTS stufe_konto (nutzer_id TEXT PRIMARY KEY REFERENCES nutzer(id) ON DELETE CASCADE, stufe TEXT NOT NULL, gueltig_bis INTEGER, geaendert_am INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS testwoche (email_hash TEXT PRIMARY KEY, nutzer_id TEXT NOT NULL, start_am INTEGER NOT NULL, ende_am INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS testwoche_nutzer ON testwoche(nutzer_id);
CREATE TABLE IF NOT EXISTS check_nutzung (id TEXT PRIMARY KEY, datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, art TEXT NOT NULL, stufe TEXT NOT NULL, am INTEGER NOT NULL, status TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS check_nutzung_raum ON check_nutzung(datenraum_id, am);
CREATE TABLE IF NOT EXISTS check_ergebnis (schluessel TEXT PRIMARY KEY, art TEXT NOT NULL, antwort TEXT NOT NULL, erstellt_am INTEGER NOT NULL);
