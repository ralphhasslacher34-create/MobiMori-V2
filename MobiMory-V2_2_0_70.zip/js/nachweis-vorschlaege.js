/*
 * Vorschläge für Nachweisarten: Deutschland und EU.
 *
 * Das sind VORSCHLÄGE, keine festen Vorgaben. Der Nutzer übernimmt davon, was
 * er braucht. Danach ist die Art seine eigene und frei änderbar. Eigene Arten
 * stehen in derselben Liste, mit dem Zusatz "von dir eingetragen".
 *
 * Jeder Vorschlag nennt Quelle und Prüfdatum. Der Prüfstand sagt ehrlich,
 * wie weit die Angaben nachgeprüft sind:
 *   geprueft   Felder und Angaben laut Quelle nachgeprüft
 *   teilweise  Quelle nachgeprüft für die genannten Angaben, die Felder des
 *              Musters aber noch nicht Feld für Feld
 *   offen      noch nicht nachgeprüft (Ausgangsstand aus V1)
 *
 * Die Beschriftung auf dem Papier ("papier") gibt an, welche Feldnummer oder
 * Beschriftung auf dem Dokument steht. Smart Capture braucht das später.
 * Wo auf dem Foto das Feld sitzt, wird erst mit echten Mustern festgelegt.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var GEPRUEFT_AM = '2026-11-03';

  function art(id, name, gehoertZu, p) {
    var a = {
      id: id, name: name, gehoertZu: gehoertZu, land: p.land || 'DE', hatAblauf: !!p.hatAblauf,
      gemeinsam: p.gemeinsam || {}, ohne: p.ohne || [], felder: p.felder || [],
      quelle: p.quelle || null, pruefstatus: p.pruefstatus || 'offen', geprueftAm: p.pruefstatus === 'offen' || !p.pruefstatus ? null : GEPRUEFT_AM,
      hinweis: p.hinweis || ''
    };
    return a;
  }
  function f(key, label, typ, papier) { return { key: key, label: label, typ: typ || 'text', papier: papier || '' }; }

  var Q = {
    fev: { titel: 'Fahrerlaubnis-Verordnung (FeV), Anlage 8', url: 'https://lxgesetze.de/fev/AL-8' },
    fzv6: { titel: 'Fahrzeug-Zulassungsverordnung (FZV 2023), Anlage 6', url: 'https://www.gesetze-im-internet.de/fzv_2023/anlage_6.html' },
    fzv8: { titel: 'Fahrzeug-Zulassungsverordnung (FZV 2023), Anlage 8', url: 'https://gesetze.legal/bund/fzv/inhaltsuebersicht' },
    pauswg: { titel: 'Personalausweisgesetz (PAuswG), § 6 Gültigkeitsdauer', url: 'https://lxgesetze.de/pauswg/6' },
    pass: { titel: 'Reisepass, Gültigkeitsdauer (Passgesetz), Informationen der Stadt Heidelberg', url: 'https://www.heidelberg.de/-/Lebenslagen/reisepass/leb5001126' },
    heimtier: { titel: 'Verordnung (EU) Nr. 576/2013, Artikel 21 (Inhalt des Heimtierausweises)', url: 'https://gesetze.legal/eu/vo_eu_2013_576/21' },
    tollwut: { titel: 'Tollwutimpfung im Heimtierausweis, Fragen und Antworten der Länder (LAV)', url: 'https://www.amtstierarzt.de/wp-content/uploads/2023/11/2018-12-17-FAQ-neue-EU-Heimtierausweise-PJG-der-LAV-AG-ED-zu-EU-Heimtierverbringungen.pdf' },
    spfv: { titel: 'Sportbootführerscheinverordnung (SpFV)', url: 'https://www.buzer.de/Sportbootfuehrerschein_SpFV.htm' },
    src: { titel: 'Funkzeugnisse SRC und LRC, Leistungsverzeichnis des Bundes', url: 'https://verwaltung.bund.de/leistungsverzeichnis/en/leistung/99096049050000' },
    ubi: { titel: 'UKW-Sprechfunkzeugnis UBI, Leistungsverzeichnis des Bundes', url: 'https://verwaltung.bund.de/leistungsverzeichnis/en/leistung/99096048012001' },
    ibs: { titel: 'Kennzeichnung von Sportbooten, Polizei NRW (2023)', url: 'https://lippe.polizei.nrw/sites/default/files/2023-10/kennzeichnung-2023.pdf' },
    hu: { titel: 'Zulassungsbescheinigung, Wissenschaftliche Dienste des Bundestages (WD 7 166/19)', url: 'https://www.bundestag.de/resource/blob/671690/b9f513adb0b89aa7f1fbc322941c20f8/WD-7-166-19-pdf-data.pdf' }
  };

  var VORSCHLAEGE = [
    /* ---------- Personen ---------- */
    art('DE_FEV_FUEHRERSCHEIN_EU', 'Führerschein (EU-Kartenführerschein)', 'person', {
      hatAblauf: true, pruefstatus: 'geprueft', quelle: Q.fev,
      gemeinsam: { nummer: { label: 'Führerscheinnummer', papier: '5' }, aussteller: { label: 'Ausstellungsbehörde', papier: '4c' },
        ausgestelltAm: { label: 'Ausstellungsdatum', papier: '4a' }, gueltigBis: { label: 'Ablaufdatum des Dokuments', papier: '4b' },
        klassen: { label: 'Fahrerlaubnisklassen', papier: '9' } },
      felder: [f('z1', 'Name', 'text', '1'), f('z2', 'Vorname', 'text', '2'), f('z3', 'Geburtsdatum und Geburtsort', 'text', '3'),
        f('z4', 'Erteilungsdatum je Klasse', 'text', '10'), f('z5', 'Gültig bis je Klasse', 'text', '11'),
        f('z6', 'Beschränkungen und Zusatzangaben', 'text', '12')],
      hinweis: 'Die Feldnummern 1 bis 12 entsprechen dem Muster 1 der Anlage 8 FeV. Das Ablaufdatum des Dokuments (4b) ist nicht das Ende der Fahrerlaubnis.'
    }),
    art('DE_PAUSWG_PERSONALAUSWEIS', 'Personalausweis', 'person', {
      hatAblauf: true, pruefstatus: 'teilweise', quelle: Q.pauswg,
      gemeinsam: { nummer: { label: 'Ausweisnummer' }, aussteller: { label: 'Behörde' }, ausgestelltAm: { label: 'Ausstellungsdatum' }, gueltigBis: { label: 'Gültig bis' } },
      ohne: ['klassen'],
      hinweis: 'Gültigkeit laut § 6 PAuswG: zehn Jahre, bei unter 24-Jährigen sechs Jahre, keine Verlängerung. Die Felder des Musters sind noch nicht Feld für Feld geprüft.'
    }),
    art('DE_PASSG_REISEPASS', 'Reisepass', 'person', {
      hatAblauf: true, pruefstatus: 'teilweise', quelle: Q.pass,
      gemeinsam: { nummer: { label: 'Passnummer' }, aussteller: { label: 'Behörde' }, ausgestelltAm: { label: 'Ausstellungsdatum' }, gueltigBis: { label: 'Gültig bis' } },
      ohne: ['klassen'],
      hinweis: 'Gültigkeit: zehn Jahre, bei unter 24-Jährigen sechs Jahre, keine Verlängerung. Die Felder des Musters sind noch nicht Feld für Feld geprüft.'
    }),
    art('DE_SPFV_SBF', 'Sportbootführerschein', 'person', {
      hatAblauf: false, pruefstatus: 'teilweise', quelle: Q.spfv,
      gemeinsam: { nummer: { label: 'Nummer' }, aussteller: { label: 'Ausgestellt durch' }, klassen: { label: 'Geltungsbereich (Binnen, See)' } },
      felder: [f('z1', 'Antriebsart (Motor, Segel)', 'text', '')],
      hinweis: 'Geltungsbereiche laut SpFV: Binnenschifffahrtsstraßen und Seeschifffahrtsstraßen, je nach Antriebsart. Eine Befristung kennt die SpFV laut Anbieterangaben nicht, das ist aber nicht amtlich bestätigt. Die Felder des Musters (Anlage 1) sind noch nicht geprüft.'
    }),
    art('DE_SRC', 'Funkzeugnis SRC (beschränkt gültiges Funkbetriebszeugnis)', 'person', {
      hatAblauf: false, pruefstatus: 'teilweise', quelle: Q.src, ohne: ['klassen'],
      hinweis: 'Berechtigt zur Teilnahme am UKW-Seefunk. Ausgestellt vom Deutschen Segler-Verband (DSV) bzw. Deutschen Motoryachtverband (DMYV). Die Felder des Musters sind noch nicht geprüft.'
    }),
    art('DE_LRC', 'Funkzeugnis LRC (allgemeines Funkbetriebszeugnis)', 'person', {
      hatAblauf: false, pruefstatus: 'teilweise', quelle: Q.src, ohne: ['klassen'],
      hinweis: 'Berechtigt zur Teilnahme am UKW-, Grenzwellen- und Kurzwellen-Seefunk und am Satellitenfunk. Die Felder des Musters sind noch nicht geprüft.'
    }),
    art('DE_UBI', 'Funkzeugnis UBI (UKW-Sprechfunkzeugnis Binnenschifffahrtsfunk)', 'person', {
      hatAblauf: false, pruefstatus: 'teilweise', quelle: Q.ubi, ohne: ['klassen'],
      hinweis: 'Erforderlich für den Binnenschifffahrtsfunk. Laut Merkblatt von DMYV und DSV unbefristet gültig. Die Felder des Musters sind noch nicht geprüft.'
    }),

    /* ---------- Tiere ---------- */
    art('EU_HEIMTIERAUSWEIS', 'EU-Heimtierausweis', 'tier', {
      land: 'EU', hatAblauf: false, pruefstatus: 'teilweise', quelle: Q.heimtier,
      gemeinsam: { nummer: { label: 'Nummer des Heimtierausweises' }, aussteller: { label: 'Ausstellender Tierarzt' }, ausgestelltAm: { label: 'Ausstellungsdatum' } },
      ohne: ['klassen'],
      felder: [f('z1', 'Kennzeichnungsnummer (Mikrochip)', 'text', ''), f('z2', 'Datum der Kennzeichnung', 'datum', '')],
      hinweis: 'Nach Art. 21 der Verordnung (EU) Nr. 576/2013 enthält der Ausweis unter anderem Angaben zum Halter, zum Tier, zur Kennzeichnung und zur Tollwutimpfung. Das Muster steht in Anhang III der Durchführungsverordnung (EU) Nr. 577/2013 und ist noch nicht Feld für Feld geprüft.'
    }),
    art('EU_TOLLWUTIMPFUNG', 'Tollwutimpfung', 'tier', {
      land: 'EU', hatAblauf: true, pruefstatus: 'teilweise', quelle: Q.tollwut,
      gemeinsam: { aussteller: { label: 'Tierarzt' }, ausgestelltAm: { label: 'Impfdatum' }, gueltigBis: { label: 'Gültig bis' } },
      ohne: ['nummer', 'klassen'],
      felder: [f('z1', 'Impfstoff', 'text', ''), f('z2', 'Gültig ab', 'datum', '')],
      hinweis: 'Die Gültigkeit beginnt bei einer Erstimpfung frühestens 21 Tage nach der Impfung. Ob eine Impfung für eine Reise ausreicht, hängt vom Zielland ab.'
    }),

    /* ---------- Fahrzeuge ---------- */
    art('DE_FZV_ZB_I', 'Zulassungsbescheinigung Teil I (Fahrzeugschein)', 'fahrzeug', {
      hatAblauf: false, pruefstatus: 'geprueft', quelle: Q.fzv6,
      gemeinsam: { nummer: { label: 'Druckstücknummer' }, aussteller: { label: 'Zulassungsbehörde' }, ausgestelltAm: { label: 'Datum der Zulassung', papier: 'I' } },
      ohne: ['klassen'],
      felder: [f('z1', 'Amtliches Kennzeichen', 'text', 'A'), f('z2', 'Datum der Erstzulassung', 'datum', 'B'), f('z3', 'Marke', 'text', 'D.1'),
        f('z4', 'Typ, Variante, Version', 'text', 'D.2'), f('z5', 'Handelsbezeichnung', 'text', 'D.3'), f('z6', 'Fahrzeug-Identifizierungsnummer (FIN)', 'text', 'E'),
        f('z7', 'Technisch zulässige Gesamtmasse (kg)', 'zahl', 'F.1'), f('z8', 'Im Zulassungsstaat zulässige Gesamtmasse (kg)', 'zahl', 'F.2'),
        f('z9', 'Leermasse (kg)', 'zahl', 'G'), f('z10', 'Fahrzeugklasse', 'text', 'J'), f('z11', 'Nummer der EG-Typgenehmigung', 'text', 'K'),
        f('z12', 'Anzahl der Achsen', 'zahl', 'L'), f('z13', 'Anhängelast gebremst (kg)', 'zahl', 'O.1'), f('z14', 'Anhängelast ungebremst (kg)', 'zahl', 'O.2'),
        f('z15', 'Hubraum (cm³)', 'zahl', 'P.1'), f('z16', 'Nennleistung (kW) und Nenndrehzahl', 'text', 'P.2/P.4'), f('z17', 'Kraftstoffart oder Energiequelle', 'text', 'P.3'),
        f('z18', 'Sitzplätze', 'zahl', 'S.1'), f('z19', 'Höchstgeschwindigkeit (km/h)', 'zahl', 'T'),
        f('z20', 'Länge (mm)', 'zahl', '18'), f('z21', 'Breite (mm)', 'zahl', '19'), f('z22', 'Höhe (mm)', 'zahl', '20'), f('z23', 'Bemerkungen und Ausnahmen', 'text', '22')],
      hinweis: 'In der FZV von 2023 (zuletzt geändert am 12.05.2026) ist die Zulassungsbescheinigung Teil I die Anlage 6. Die Felddefinitionen A bis 22 wurden an der amtlichen Fassung geprüft. Länge, Breite und Höhe stehen in Millimetern.'
    }),
    art('DE_FZV_ZB_II', 'Zulassungsbescheinigung Teil II (Fahrzeugbrief)', 'fahrzeug', {
      hatAblauf: false, pruefstatus: 'teilweise', quelle: Q.fzv8,
      ohne: ['klassen'],
      felder: [f('z1', 'Amtliches Kennzeichen', 'text', 'A'), f('z2', 'Marke', 'text', 'D.1'), f('z3', 'Typ, Variante, Version', 'text', 'D.2'),
        f('z4', 'Handelsbezeichnung', 'text', 'D.3'), f('z5', 'Fahrzeug-Identifizierungsnummer (FIN)', 'text', 'E')],
      hinweis: 'In der FZV von 2023 ist die Zulassungsbescheinigung Teil II die Anlage 8. Dass sie Kennzeichen und FIN enthält, ist belegt. Die übrigen Felder stammen aus V1 und sind noch nicht Feld für Feld geprüft.'
    }),
    art('DE_HAUPTUNTERSUCHUNG', 'Hauptuntersuchung (HU)', 'fahrzeug', {
      hatAblauf: true, pruefstatus: 'teilweise', quelle: Q.hu,
      gemeinsam: { aussteller: { label: 'Prüforganisation' }, ausgestelltAm: { label: 'Datum der Untersuchung' }, gueltigBis: { label: 'Nächste HU fällig' } },
      ohne: ['nummer', 'klassen'],
      hinweis: 'Die Zulassungsbescheinigung Teil I enthält Daten zur nächsten erforderlichen Hauptuntersuchung. Die Prüfplakette und der Prüfbericht sind noch nicht Feld für Feld geprüft.'
    }),
    art('DE_IBS', 'Internationaler Bootsschein', 'fahrzeug', {
      hatAblauf: false, pruefstatus: 'teilweise', quelle: Q.ibs,
      gemeinsam: { nummer: { label: 'Bootsscheinnummer (mit Kennbuchstabe M, S oder A)' }, aussteller: { label: 'Ausgebende Organisation (DMYV, DSV, ADAC)' } },
      ohne: ['klassen'],
      hinweis: 'Laut Polizei NRW in Deutschland unbefristet gültig. Im Ausland sollte er nicht älter als zwei Jahre sein, danach kann er verlängert werden. Das Kennzeichen besteht aus der Nummer und dem Kennbuchstaben der Organisation. Die Felder des Musters sind noch nicht geprüft.'
    }),
    art('EU_CE_WATERCRAFT', 'CE-Konformitätserklärung Sportboot', 'fahrzeug', {
      land: 'EU', hatAblauf: false, pruefstatus: 'offen', ohne: ['klassen'],
      hinweis: 'Ausgangsstand aus V1. Quelle und Felder sind noch nicht geprüft.'
    }),
    art('DE_WSA_KLEINFAHRZEUG', 'Kennzeichnung oder Ausweis Kleinfahrzeug (WSA)', 'fahrzeug', {
      hatAblauf: false, pruefstatus: 'offen', ohne: ['klassen'],
      hinweis: 'Ausgangsstand aus V1. Quelle und Felder sind noch nicht geprüft.'
    }),
    art('DE_SCHIFFSREGISTER', 'Schiffsregister-Unterlage', 'fahrzeug', {
      hatAblauf: false, pruefstatus: 'offen', ohne: ['klassen'],
      hinweis: 'Ausgangsstand aus V1. Quelle und Felder sind noch nicht geprüft.'
    })
  ];

  function kopieren(o) { return JSON.parse(JSON.stringify(o)); }

  MM.NachweisVorschlaege = {
    GEPRUEFT_AM: GEPRUEFT_AM,
    alle: function () { return kopieren(VORSCHLAEGE); },
    finde: function (id) {
      for (var i = 0; i < VORSCHLAEGE.length; i++) { if (VORSCHLAEGE[i].id === id) return kopieren(VORSCHLAEGE[i]); }
      return null;
    },
    PRUEFSTATUS: {
      geprueft: 'Geprüft',
      teilweise: 'Teilweise geprüft',
      offen: 'Noch nicht geprüft'
    }
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
