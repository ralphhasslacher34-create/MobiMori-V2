/*
 * Freigaben (Schritt 13c, seit 2.0.67): reine Rechnung und Texte, kein Netz, kein Speicher. Das Senden steht in daten.js.
 *
 * Festlegungen (Nutzer, 03.11.2026): Freigaben gelten je Fahrzeug und Zeitraum, die Einladung höchstens 12 Monate, die Kontroll-Freigabe geht per Code,
 * die Rechte werden auf dem Server geprüft (server/konto-dienst.mjs). Ein Gast darf nur lesen.
 * Der Gast sieht: Fahrzeug, Fristen, Zähler, Dokumente samt Datei und das letzte Prüfergebnis. Der Kontrolleur sieht nur Fahrzeug, Dokumente und Prüfergebnis.
 * Nie: Kosten, Notizen, Nachweise, Reisechecks, Routen, Besuche, Aktivitäten, Ereignisse, Personen, Orte, GPS.
 * Die Ansicht entsteht aus den Datensätzen des Dienstes (Form des Abgleichs) und wird nirgends gespeichert.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var MAX_MONATE = 12;
  var EINLADUNG_CODE = 10;
  var KONTROLLE_CODE = 8;
  var CODE_ZEICHEN = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';
  var KONTROLLE_STUNDEN = [
    { wert: 1, label: '1 Stunde' }, { wert: 4, label: '4 Stunden' }, { wert: 24, label: '1 Tag (Standard)' },
    { wert: 72, label: '3 Tage' }, { wert: 168, label: '7 Tage (Höchstwert)' }
  ];
  var STATUS_TEXT = { eingeladen: 'wartet auf Annahme', aktiv: 'gilt', wartet: 'beginnt später', abgelaufen: 'abgelaufen', widerrufen: 'widerrufen' };
  var ERGEBNIS_TEXT = { erlaubt: 'Erlaubt', nicht_erlaubt: 'Nicht erlaubt', unklar: 'Unklar' };

  function text(x) { return x === null || x === undefined ? '' : String(x).trim(); }

  /* ---------- Datum (nur Tage) ---------- */
  function teile(t) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text(t));
    if (!m) return null;
    var y = +m[1], mo = +m[2], d = +m[3], x = new Date(Date.UTC(y, mo - 1, d));
    return x.getUTCFullYear() === y && x.getUTCMonth() === mo - 1 && x.getUTCDate() === d ? { y: y, mo: mo, d: d } : null;
  }
  function plusMonate(t, n) {
    var p = teile(t);
    if (!p) return null;
    var gesamt = p.y * 12 + (p.mo - 1) + n, y = Math.floor(gesamt / 12), mo = (gesamt % 12) + 1;
    var tage = new Date(Date.UTC(y, mo, 0)).getUTCDate(), d = Math.min(p.d, tage);
    function z(k) { return (k < 10 ? '0' : '') + k; }
    return y + '-' + z(mo) + '-' + z(d);
  }

  /* Eingaben der Einladung. Der Dienst prüft alles noch einmal, hier kommt nur die Meldung früher und in einfachen Worten. */
  function einladung(roh, heute) {
    roh = roh || {};
    var fehler = {}, w = {};
    var fz = text(roh.fahrzeugId);
    if (!fz) fehler.fahrzeugId = 'Bitte ein Fahrzeug wählen.'; else w.fahrzeugId = fz;
    var e = MM.Konto.email(roh.email);
    if (!e.ok) fehler.email = e.fehler; else w.email = e.email;
    var ab = text(roh.ab) || heute;
    if (!teile(ab)) fehler.ab = 'Bitte das Datum „von“ als Tag eingeben.';
    else if (ab < heute) fehler.ab = 'Das Datum „von“ liegt in der Vergangenheit.';
    else w.ab = ab;
    var bis = text(roh.bis);
    if (!bis) fehler.bis = 'Bitte angeben, bis wann die Freigabe gilt.';
    else if (!teile(bis)) fehler.bis = 'Bitte das Datum „bis“ als Tag eingeben.';
    else if (w.ab && bis < w.ab) fehler.bis = 'Das Datum „bis“ liegt vor dem Datum „von“.';
    else if (w.ab && bis > plusMonate(w.ab, MAX_MONATE)) fehler.bis = 'Eine Freigabe gilt höchstens ' + MAX_MONATE + ' Monate. Spätestens bis ' + plusMonate(w.ab, MAX_MONATE) + '.';
    else w.bis = bis;
    return { ok: Object.keys(fehler).length === 0, werte: w, fehler: fehler };
  }

  function codeSauber(roh, laenge) {
    var t = text(roh).toUpperCase().replace(/[\s-]+/g, '');
    if (t.length !== laenge) return null;
    for (var i = 0; i < t.length; i++) { if (CODE_ZEICHEN.indexOf(t.charAt(i)) < 0) return null; }
    return t;
  }
  function codeEinladung(roh) {
    var c = codeSauber(roh, EINLADUNG_CODE);
    return c ? { ok: true, code: c } : { ok: false, fehler: 'Der Code aus der E-Mail hat ' + EINLADUNG_CODE + ' Zeichen (Buchstaben und Ziffern).' };
  }
  function codeKontrolle(roh) {
    var c = codeSauber(roh, KONTROLLE_CODE);
    return c ? { ok: true, code: c } : { ok: false, fehler: 'Der Kontroll-Code hat ' + KONTROLLE_CODE + ' Zeichen (Buchstaben und Ziffern).' };
  }
  /* Zur Anzeige in zwei Hälften: ABCD-EFGH */
  function codeAnzeige(code) { var t = text(code); return t.length > 4 ? t.slice(0, t.length / 2) + '-' + t.slice(t.length / 2) : t; }

  function stunden(roh) {
    var n = Number(roh);
    return Number.isInteger(n) && n >= 1 && n <= 168 ? { ok: true, stunden: n } : { ok: false, fehler: 'Die Gültigkeit liegt zwischen 1 Stunde und 7 Tagen.' };
  }

  /* Der Link für den Kontrolleur: Adresse der App, Code und Adresse des Dienstes. Die Adresse des Dienstes steht mit im Link, damit
     das Gerät des Kontrolleurs nichts einrichten muss. */
  function kontrollLink(appAdresse, dienstUrl, code) {
    var basis = text(appAdresse).replace(/#.*$/, '');
    return basis + '#/kontrolle/' + encodeURIComponent(text(code)) + '/' + encodeURIComponent(text(dienstUrl));
  }
  function entschluesseln(t) { try { return decodeURIComponent(t); } catch (e) { return ''; } }
  function kontrollLinkLesen(code, dienst) {
    var c = codeKontrolle(code ? entschluesseln(code) : '');
    var u = dienst ? MM.Konto.dienstAdresse(entschluesseln(dienst)) : { ok: false };
    return { code: c.ok ? c.code : '', dienstUrl: u.ok ? u.url : '' };
  }

  /* ---------- Ansicht aus den Datensätzen des Dienstes ---------- */
  function lesen(d) {
    try { var o = JSON.parse(d.nutzlast); return o && typeof o === 'object' && !Array.isArray(o) && o.id === d.id ? o : null; } catch (e) { return null; }
  }
  function neuer(a, b) { return !a || (b.nr || 0) > (a.nr || 0); }

  function sicht(datensaetze, heute) {
    var nach = {};
    (datensaetze || []).forEach(function (d) {
      if (!d || typeof d.tabelle !== 'string') return;
      var o = lesen(d);
      if (o) (nach[d.tabelle] = nach[d.tabelle] || []).push(o);
    });
    function liste(t) { return nach[t] || []; }
    var fzRec = liste('fahrzeuge')[0];
    if (!fzRec) return null;

    var verlauf = {};
    liste('verlaeufe').forEach(function (v) { var k = v.objektTyp + '/' + v.objektId; if (neuer(verlauf[k], v)) verlauf[k] = v; });
    function werte(typ, id) { var v = verlauf[typ + '/' + id]; return v && v.werte && typeof v.werte === 'object' ? v.werte : {}; }

    var eintrag = null;
    liste('eintraege').forEach(function (e) { if (neuer(eintrag, e)) eintrag = e; });
    var fw = eintrag && eintrag.werte ? eintrag.werte : {};
    var kennungFeld = null, artName = '';
    try { kennungFeld = fzRec.art ? MM.Fahrzeugarten.kennungFeld(fzRec.art) : null; var a = fzRec.art ? MM.Fahrzeugarten.art(fzRec.art) : null; artName = a ? a.name : ''; } catch (e) { kennungFeld = null; }
    var fahrzeug = { id: fzRec.id, bezeichnung: text(fw.bezeichnung) || 'Fahrzeug', kennung: kennungFeld ? text(fw[kennungFeld]) : '', art: artName };

    /* Zähler mit dem letzten Stand */
    var stand = {};
    liste('zaehlerstaende').forEach(function (s) {
      var b = stand[s.zaehlerId];
      if (!b || String(s.datum || '') > String(b.datum || '') || (s.datum === b.datum && (s.nr || 0) > (b.nr || 0))) stand[s.zaehlerId] = s;
    });
    var zaehler = liste('zaehler').map(function (z) {
      var art = MM.Fristen.zaehlerArt(z.art), s = stand[z.id] || null;
      return { id: z.id, name: text(werte('zaehler', z.id).bezeichnung) || (art ? art.standard : 'Zähler'), einheit: art ? art.einheit : '',
        stand: s && typeof s.wert === 'number' ? s.wert : null, datum: s ? s.datum || null : null };
    });

    /* Fristen */
    var letzte = {};
    liste('durchfuehrungen').forEach(function (d) {
      var b = letzte[d.fristId];
      if (!b || String(d.datum || '') > String(b.datum || '') || (d.datum === b.datum && String(d.erstelltAm || '') > String(b.erstelltAm || ''))) letzte[d.fristId] = d;
    });
    var fristen = liste('fristen').map(function (f) {
      var w = werte('frist', f.id), l = letzte[f.id] || null, s = w.zaehlerId ? stand[w.zaehlerId] : null, res;
      if (l && l.datum) {
        res = MM.Fristen.berechne({ werte: w, letzte: { datum: l.datum, zaehlerstand: l.zaehlerstand === undefined ? null : l.zaehlerstand },
          stand: s && typeof s.wert === 'number' ? { wert: s.wert } : null, heute: heute });
      } else res = { status: 'unbekannt', kalender: null, zaehler: null };
      var zeilen = [], zArt = null;
      zaehler.forEach(function (z) { if (z.id === w.zaehlerId) zArt = z; });
      if (res.kalender) {
        var tage = res.kalender.tage;
        zeilen.push((tage < 0 ? 'überfällig seit ' : 'fällig am ') + MM.Hilfen.datum(res.kalender.faelligAm) + (tage < 0 ? ' (' + (-tage) + (tage === -1 ? ' Tag' : ' Tagen') + ')' : tage === 0 ? ' (heute)' : ' (in ' + tage + (tage === 1 ? ' Tag' : ' Tagen') + ')'));
      }
      if (res.zaehler && res.zaehler.faelligBei !== undefined) {
        zeilen.push('fällig bei ' + MM.Hilfen.zahl(res.zaehler.faelligBei) + (zArt && zArt.einheit ? ' ' + zArt.einheit : ''));
      }
      if (l && l.datum) zeilen.push('zuletzt erledigt am ' + MM.Hilfen.datum(l.datum));
      return { id: f.id, name: text(w.bezeichnung) || 'Frist', kategorie: w.kategorie || null, status: res.status, text: zeilen.join(', ') || 'noch kein Stand bekannt' };
    }).sort(function (a, b) { return MM.Fristen.rang(b.status) - MM.Fristen.rang(a.status) || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0); });

    /* Dokumente mit ihren Dateien */
    var dateien = {};
    liste('dateien').forEach(function (d) { (dateien[d.dokumentId] = dateien[d.dokumentId] || []).push({ id: d.id, name: text(d.name) || 'Datei', mime: text(d.mime), groesse: typeof d.groesse === 'number' ? d.groesse : null }); });
    var dokumente = liste('dokumente').map(function (d) {
      var w = werte('dokument', d.id);
      return { id: d.id, bezeichnung: text(w.bezeichnung) || 'Dokument', art: text(w.art), link: /^https?:\/\//i.test(text(w.link)) ? text(w.link) : null,
        dateien: (dateien[d.id] || []).sort(function (a, b) { return a.name < b.name ? -1 : a.name > b.name ? 1 : 0; }) };
    }).sort(function (a, b) { return a.bezeichnung < b.bezeichnung ? -1 : a.bezeichnung > b.bezeichnung ? 1 : 0; });

    /* Letztes Prüfergebnis (zum Tagesbeginn festgehalten) */
    var p = null;
    liste('tagespruefungen').forEach(function (t) { if (!p || String(t.erstelltAm || '') > String(p.erstelltAm || '')) p = t; });
    var pruefung = null;
    if (p && p.stand && typeof p.stand === 'object') {
      var f = p.stand.fristen || {};
      pruefung = { geprueftAm: p.stand.geprueftAm || null, tagesbeginn: p.stand.tagesbeginn || null, ergebnis: p.stand.ergebnis || null,
        ergebnisText: ERGEBNIS_TEXT[p.stand.ergebnis] || 'Kein Ergebnis', fristen: { betroffen: f.betroffen || 0, sperre: f.sperre || 0, eingeschraenkt: f.eingeschraenkt || 0 } };
    }
    return { fahrzeug: fahrzeug, fristen: fristen, zaehler: zaehler, dokumente: dokumente, pruefung: pruefung };
  }

  MM.Freigaben = {
    MAX_MONATE: MAX_MONATE, EINLADUNG_CODE: EINLADUNG_CODE, KONTROLLE_CODE: KONTROLLE_CODE, KONTROLLE_STUNDEN: KONTROLLE_STUNDEN, STATUS_TEXT: STATUS_TEXT,
    einladung: einladung, codeEinladung: codeEinladung, codeKontrolle: codeKontrolle, codeAnzeige: codeAnzeige, stunden: stunden, plusMonate: plusMonate,
    kontrollLink: kontrollLink, kontrollLinkLesen: kontrollLinkLesen, sicht: sicht,
    TEXT_FREIGABE: 'Du gibst ein Fahrzeug für eine andere Person frei, nur zum Lesen, für einen Zeitraum von höchstens 12 Monaten. Die Person bekommt per E-Mail einen Code, meldet sich mit derselben E-Mail-Adresse bei MobiMory an und trägt den Code ein. Sie sieht das Fahrzeug, seine Fristen und Zähler, die Dokumente samt Dateien und das letzte Prüfergebnis. Sie sieht nie deine Kosten, Notizen, Nachweise, Reisechecks, Aktivitäten, Ereignisse oder Standorte. Nachweis-Scans kann sie nicht öffnen, weil sie mit deinem Schlüsselwort verschlüsselt sind. Du kannst die Freigabe jederzeit widerrufen, der Zugriff endet dann sofort.',
    TEXT_FREIGABE_VORAUS: 'Das Fahrzeug muss beim Dienst liegen. Tippe vorher unter Funktionen › Konto auf „Jetzt abgleichen“.',
    TEXT_KONTROLLE: 'Für eine Kontrolle (zum Beispiel Polizei oder Hafenbehörde) erzeugst du einen kurzen Code. Wer ihn kennt, sieht nur das Fahrzeug, die Dokumente samt Dateien und das letzte Prüfergebnis, ohne eigenes Konto. Der Code gilt nur kurz (höchstens 7 Tage), und du kannst ihn jederzeit widerrufen. Der Code wird nur jetzt angezeigt. Notiere ihn oder schicke den Link gleich weiter.',
    TEXT_GAST: 'Du siehst hier nur, was die Person für dich freigegeben hat. Du kannst nichts ändern. Die Daten werden nur angezeigt und nicht auf deinem Gerät gespeichert. Wenn die Freigabe endet oder widerrufen wird, ist sie beim nächsten Laden weg.',
    TEXT_KONTROLLE_SEITE: 'Du siehst nur das Fahrzeug, die Dokumente und das letzte Prüfergebnis. Nichts davon wird auf diesem Gerät gespeichert. Der Code gilt nur für kurze Zeit.'
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
