/* Tag der Reise wählen (seit 2.0.44): Regeln für den kleinen Kalender hinter dem Knopf auf der Seite einer Mehrtagesaktivität.
 * Der Kalender richtet sich nach der Reise, nicht nach dem heutigen Datum: Er beginnt am ersten Reisetag (Tag 1) und endet am letzten (Tag X).
 * Nur Regeln, keine Oberfläche. tage: [{ id, datum }] (die Tage im Logbuch, ohne ausgeblendete). */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var MONATE = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
  var WOCHENTAGE = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
  var TAG_MS = 86400000;

  function z2(n) { return (n < 10 ? '0' : '') + n; }
  function iso(y, m, d) { return y + '-' + z2(m) + '-' + z2(d); }
  function teile(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
    return m ? { j: +m[1], m: +m[2], t: +m[3] } : null;
  }
  /* Tage zählen ohne Sommerzeit-Fehler: über UTC */
  function utc(s) { var p = teile(s); return p ? Date.UTC(p.j, p.m - 1, p.t) : null; }

  /* Zählt die Reise mehr als einen Tag? Dann gibt es die Auswahl. */
  function mehrtaegig(von, bis) { var a = utc(von), b = utc(bis); return a !== null && b !== null && b > a; }

  /* Wie viele Tage hat die Reise (Tag X)? 0, wenn der Zeitraum nicht lesbar ist. */
  function reiseTage(von, bis) {
    var a = utc(von), b = utc(bis);
    return a === null || b === null || b < a ? 0 : Math.round((b - a) / TAG_MS) + 1;
  }

  /* Die Nummer eines Datums in der Reise (Tag 1 ist der erste Reisetag); null, wenn es außerhalb liegt. */
  function tagNummer(von, bis, datum) {
    var a = utc(von), d = utc(datum), n = reiseTage(von, bis);
    if (a === null || d === null || !n) return null;
    var nr = Math.round((d - a) / TAG_MS) + 1;
    return nr >= 1 && nr <= n ? nr : null;
  }

  /* Der Tag, der zuerst gezeigt wird: der Tag, den die Nutzerin oder der Nutzer zuletzt gewählt hat (wenn es ihn noch gibt),
     sonst der heutige Reisetag, sonst Tag 1 (der erste Tag der Liste). Ergebnis: die Kennung oder null (keine Tage). */
  function standard(tage, heute, gewaehltId) {
    var liste = (tage || []).slice().sort(function (x, y) { return x.datum < y.datum ? -1 : (x.datum > y.datum ? 1 : 0); });
    if (!liste.length) return null;
    if (gewaehltId && liste.some(function (t) { return t.id === gewaehltId; })) return gewaehltId;
    var h = liste.filter(function (t) { return t.datum === heute; })[0];
    return (h || liste[0]).id;
  }

  /* Die Beschriftung des Knopfes, zum Beispiel „Tag 3 von 8 · Mi 26.12.2026“. wochentag: 'Mi' oder ''. datumText: '26.12.2026'. */
  function knopfText(nr, anzahl, wochentag, datumText) {
    return (nr ? 'Tag ' + nr + (anzahl ? ' von ' + anzahl : '') : 'Tag') + ' · ' + (wochentag ? wochentag + ' ' : '') + datumText;
  }

  /*
   * Der Kalender: ein Monat nach dem anderen, vom Monat des ersten bis zum Monat des letzten Reisetags.
   * Ergebnis: [{ titel: 'Dezember 2026', wochen: [[Zelle × 7]] }]; Zelle: null (leer) oder
   *   { tag: 24, datum, nr: Tag der Reise | null, art: 'aktiv' (es gibt einen Tag im Logbuch, wählbar) | 'frei' (liegt in der Reise, aber ohne Tag)
   *     | 'ausserhalb', id: Kennung des Tages | null, gewaehlt: Boolean, heute: Boolean }.
   * Mehrere Tage mit demselben Datum: der erste zählt.
   */
  function monate(von, bis, tage, gewaehltId, heute) {
    var a = teile(von), b = teile(bis);
    if (!a || !b || utc(bis) < utc(von)) return [];
    var nachDatum = {};
    (tage || []).forEach(function (t) { if (!nachDatum[t.datum]) nachDatum[t.datum] = t; });
    var aus = [], j = a.j, m = a.m;
    while (j < b.j || (j === b.j && m <= b.m)) {
      var tageImMonat = new Date(j, m, 0).getDate();
      /* Montag = 0 */
      var ersterWt = (new Date(j, m - 1, 1).getDay() + 6) % 7;
      var zellen = [], i;
      for (i = 0; i < ersterWt; i++) zellen.push(null);
      for (i = 1; i <= tageImMonat; i++) {
        var d = iso(j, m, i), nr = tagNummer(von, bis, d), t = nachDatum[d] || null;
        zellen.push({ tag: i, datum: d, nr: nr, art: nr === null ? 'ausserhalb' : (t ? 'aktiv' : 'frei'), id: t ? t.id : null, gewaehlt: !!(t && t.id === gewaehltId), heute: d === heute });
      }
      while (zellen.length % 7) zellen.push(null);
      var wochen = [];
      for (i = 0; i < zellen.length; i += 7) wochen.push(zellen.slice(i, i + 7));
      aus.push({ titel: MONATE[m - 1] + ' ' + j, wochen: wochen });
      m++; if (m > 12) { m = 1; j++; }
    }
    return aus;
  }

  MM.Tagwahl = { MONATE: MONATE, WOCHENTAGE: WOCHENTAGE, mehrtaegig: mehrtaegig, reiseTage: reiseTage, tagNummer: tagNummer, standard: standard, knopfText: knopfText, monate: monate };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
