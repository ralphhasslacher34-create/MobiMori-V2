/*
 * Aktivität: Regeln und Rechnung (Urlaub, Törn, Ausfahrt, Wasserski, Segeln, Rallye ...).
 *
 * Das Wort "Aktivität" ersetzt "Nutzung". Aus den V2-Festlegungen:
 *  - Die Besatzung hängt immer an der Aktivität, einmal pro Person.
 *  - Für Skipper und Fahrer gibt es einen oder mehrere Stellvertreter.
 *    Zu jedem Zeitpunkt ist genau einer verantwortlich. Jeder Wechsel
 *    wird mit Zeitpunkt festgehalten.
 *  - Für eine verantwortliche Funktion zählt nur ein gescannter Nachweis.
 *  - Geprüft wird nicht "gilt heute", sondern "gilt bis zum Ende des Zeitraums".
 *    Ergebnis: erlaubt, nicht erlaubt oder unklar, jeweils mit "geprüft am".
 *  - Die App prüft nur den Stand, den sie kennt, und trifft keine rechtliche Aussage.
 *  - Bei Fristen zählt, was bis zum Ende des Zeitraums fällig wird, bei
 *    Zähler-Fristen auch aus der geplanten Strecke oder Betriebsstunden.
 *  - Jede Aktivität lässt sich stornieren. Nichts wird gelöscht.
 *
 * Hier steht nur Rechnung und Beschreibung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var VORSCHLAEGE_ARTEN = ['Urlaub', 'Törn', 'Ausfahrt', 'Wasserski', 'Segeln', 'Rallye'];

  /* Starthilfe (seit 2.0.17): für welche Fahrzeugarten die Vorschläge gelten. Knoten im Baum der Fahrzeugarten.
     Der Nutzer ändert alles. */
  var ZUORDNUNG_VORSCHLAEGE = {
    'Urlaub': ['alle'], 'Törn': ['wasser'], 'Ausfahrt': ['alle'],
    'Wasserski': ['wasserskiboot'], 'Segeln': ['segelboot'], 'Rallye': ['land']
  };
  /* Die Starthilfe zu einem Namen (Groß- und Kleinschreibung egal) oder null, wenn es keine gibt. */
  function zuordnungVorschlag(bezeichnung) {
    var n = String(bezeichnung || '').toLowerCase(), treffer = null;
    Object.keys(ZUORDNUNG_VORSCHLAEGE).forEach(function (k) { if (k.toLowerCase() === n) treffer = ZUORDNUNG_VORSCHLAEGE[k]; });
    return treffer;
  }

  var ROLLEN = [
    { wert: 'verantwortlich', label: 'Skipper oder Fahrer' },
    { wert: 'stellvertreter', label: 'Stellvertreter' },
    { wert: 'crew', label: 'Crew' }
  ];

  var ERGEBNIS = { erlaubt: 'Erlaubt', nicht_erlaubt: 'Nicht erlaubt', unklar: 'Unklar' };

  /* Skipper bei Booten, Fahrer an Land. */
  function verantwortlichenName(welt) { return welt === 'wasser' ? 'Skipper' : (welt === 'land' ? 'Fahrer' : 'Verantwortlicher'); }

  function rolleLabel(rolle, welt) {
    if (rolle === 'verantwortlich') return verantwortlichenName(welt);
    if (rolle === 'stellvertreter') return 'Stellvertreter';
    return 'Crew';
  }

  /* "JJJJ-MM-TT" und "HH:MM" -> "JJJJ-MM-TTTHH:MM". Ohne Uhrzeit: Tagesanfang, beim Ende Tagesende. */
  function zeitpunkt(datum, zeit, alsEnde) {
    if (!datum) return null;
    return datum + 'T' + (zeit || (alsEnde ? '23:59' : '00:00'));
  }
  function von(w) { return zeitpunkt(w.vonDatum, w.vonZeit, false); }
  function bis(w) { return zeitpunkt(w.bisDatum, w.bisZeit, true); }

  /* storniert, geplant, laeuft oder vorbei. jetzt = "JJJJ-MM-TTTHH:MM" (Ortszeit). */
  function status(w, jetzt) {
    if (w.status === 'storniert') return 'storniert';
    if (jetzt < von(w)) return 'geplant';
    if (jetzt <= bis(w)) return 'laeuft';
    return 'vorbei';
  }

  /* Überschneiden sich zwei Zeiträume? Aneinanderstoßen zählt nicht. */
  function ueberschneiden(a, b) {
    return von(a) < bis(b) && von(b) < bis(a);
  }

  /* Wer ist zum Zeitpunkt t verantwortlich? entries: [{ab, ...}] */
  function verantwortlicher(entries, t) {
    var liste = entries.slice().sort(function (x, y) { return x.ab < y.ab ? -1 : (x.ab > y.ab ? 1 : 0); });
    if (!liste.length) return null;
    var res = liste[0];
    liste.forEach(function (e) { if (e.ab <= t) res = e; });
    return res;
  }

  /*
   * Befähigung prüfen.
   *  p.anforderungen  [{ bezeichnung, artIds }]  (eine der Arten genügt, alle Anforderungen müssen erfüllt sein)
   *  p.nachweise      Nachweise der Person: [{ artId, artName, hatAblauf, werte }]
   *  p.endDatum       Ende des Zeitraums "JJJJ-MM-TT"
   * Ergebnis: erlaubt, nicht_erlaubt oder unklar, dazu die Gründe.
   *
   * Vorsicht ist Absicht: "nicht erlaubt" gibt es nur, wenn die App einen
   * Nachweis kennt, der vor dem Ende des Zeitraums abläuft. Fehlt ein Nachweis
   * oder ein Scan, sagt die App "unklar" und nicht "nicht erlaubt".
   */
  function pruefeBefaehigung(p) {
    var gruende = [];
    if (!p.anforderungen.length) {
      return { ergebnis: 'unklar', gruende: [{ ergebnis: 'unklar', text: 'Für dieses Fahrzeug sind noch keine Anforderungen festgelegt.' }] };
    }
    var ergebnisse = [];
    p.anforderungen.forEach(function (a) {
      var treffer = p.nachweise.filter(function (n) { return a.artIds.indexOf(n.artId) >= 0; });
      if (!treffer.length) {
        ergebnisse.push('unklar');
        gruende.push({ ergebnis: 'unklar', text: a.bezeichnung + ': Kein passender Nachweis erfasst.' });
        return;
      }
      var erfuellt = treffer.filter(function (n) {
        var scan = !!n.werte.dateiName;
        var gueltig = !n.hatAblauf || (!!n.werte.gueltigBis && n.werte.gueltigBis >= p.endDatum);
        return scan && gueltig;
      })[0];
      if (erfuellt) {
        ergebnisse.push('erlaubt');
        gruende.push({ ergebnis: 'erlaubt', text: a.bezeichnung + ': ' + erfuellt.artName + ' mit Scan' + (erfuellt.hatAblauf ? ', gültig bis ' + erfuellt.werte.gueltigBis : '') + '.' });
        return;
      }
      var allAbgelaufen = treffer.every(function (n) { return n.hatAblauf && n.werte.gueltigBis && n.werte.gueltigBis < p.endDatum; });
      if (allAbgelaufen) {
        ergebnisse.push('nicht_erlaubt');
        var spaet = treffer.map(function (n) { return n.werte.gueltigBis; }).sort().pop();
        gruende.push({ ergebnis: 'nicht_erlaubt', text: a.bezeichnung + ': Der Nachweis gilt nur bis ' + spaet + ', das Ende des Zeitraums ist ' + p.endDatum + '.' });
        return;
      }
      ergebnisse.push('unklar');
      var n0 = treffer[0];
      if (!treffer.some(function (n) { return !!n.werte.dateiName; })) gruende.push({ ergebnis: 'unklar', text: a.bezeichnung + ': ' + n0.artName + ' ist erfasst, aber es hängt kein Scan oder Foto daran.' });
      else if (treffer.some(function (n) { return n.hatAblauf && !n.werte.gueltigBis; })) gruende.push({ ergebnis: 'unklar', text: a.bezeichnung + ': Beim Nachweis fehlt das Ablaufdatum.' });
      else gruende.push({ ergebnis: 'unklar', text: a.bezeichnung + ': Der Nachweis lässt sich nicht sicher beurteilen.' });
    });
    var ergebnis = ergebnisse.indexOf('nicht_erlaubt') >= 0 ? 'nicht_erlaubt' : (ergebnisse.every(function (e) { return e === 'erlaubt'; }) ? 'erlaubt' : 'unklar');
    return { ergebnis: ergebnis, gruende: gruende };
  }

  /* Mehrere Personen: eine unzulässige reicht für "nicht erlaubt", alle müssen "erlaubt" sein. */
  function gesamtErgebnis(einzel) {
    if (!einzel.length) return 'unklar';
    if (einzel.indexOf('nicht_erlaubt') >= 0) return 'nicht_erlaubt';
    return einzel.every(function (e) { return e === 'erlaubt'; }) ? 'erlaubt' : 'unklar';
  }

  var RANG_FRIST = { ueberfaellig: 3, faellig: 2, unbekannt: 1, ok: 0 };

  /*
   * Fristen bis zum Ende des Zeitraums.
   *  p.fristen  [{ bezeichnung, werte, letzte, zaehler }]  zaehler = { stand:{wert}|null, art:'strecke'|'stunden', einheit }
   *  p.heute, p.endDatum, p.geplanteStrecke, p.geplanteStunden
   * Status je Frist: ok, faellig (wird bis zum Ende fällig), ueberfaellig (schon jetzt), unbekannt.
   */
  function fristenImZeitraum(p) {
    return p.fristen.map(function (f) {
      var w = f.werte, teile = [], status = 'ok';
      function nehmen(s, text) { teile.push(text); if (RANG_FRIST[s] > RANG_FRIST[status]) status = s; }

      if (w.kalenderWert && f.letzte) {
        var monate = w.kalenderWert * (w.kalenderEinheit === 'jahre' ? 12 : 1);
        var faellig = MM.Fristen.addMonate(f.letzte.datum, monate);
        if (faellig < p.heute) nehmen('ueberfaellig', 'Zeit: schon seit ' + faellig + ' überfällig');
        else if (faellig <= p.endDatum) nehmen('faellig', 'Zeit: fällig am ' + faellig + ', also im Zeitraum');
        else nehmen('ok', 'Zeit: fällig am ' + faellig);
      }
      if (w.zaehlerId && w.zaehlerWert) {
        var z = f.zaehler;
        if (!z || !z.stand || !f.letzte || f.letzte.zaehlerstand === null || f.letzte.zaehlerstand === undefined) {
          nehmen('unbekannt', 'Zähler: Stand oder Ausgangsstand fehlt');
        } else {
          var bei = f.letzte.zaehlerstand + w.zaehlerWert;
          var geplant = z.art === 'strecke' ? p.geplanteStrecke : p.geplanteStunden;
          var vorhaben = geplant || 0;
          var voraus = z.stand.wert + vorhaben;
          var hinweis = geplant ? '' : ' (ohne geplante ' + (z.art === 'strecke' ? 'Strecke' : 'Betriebsstunden') + ' gerechnet)';
          if (z.stand.wert > bei) nehmen('ueberfaellig', 'Zähler: schon um ' + MM.Hilfen.zahl(z.stand.wert - bei) + ' ' + z.einheit + ' überschritten');
          else if (voraus > bei) nehmen('faellig', 'Zähler: wird im Zeitraum überschritten, Grenze ' + MM.Hilfen.zahl(bei) + ' ' + z.einheit + ', erwartet ' + MM.Hilfen.zahl(voraus) + ' ' + z.einheit);
          else nehmen('ok', 'Zähler: Grenze ' + MM.Hilfen.zahl(bei) + ' ' + z.einheit + ', erwartet ' + MM.Hilfen.zahl(voraus) + ' ' + z.einheit + hinweis);
        }
      }
      return { bezeichnung: f.bezeichnung, status: status, text: teile.join('; '), wirkung: w.wirkung };
    }).sort(function (a, b) { return RANG_FRIST[b.status] - RANG_FRIST[a.status]; });
  }

  /* Zusammenfassung: Gibt es Fristen, die bis zum Ende fällig werden, und mit welcher Wirkung? */
  function fristenZusammenfassung(liste) {
    var betroffen = liste.filter(function (f) { return f.status === 'faellig' || f.status === 'ueberfaellig'; });
    return {
      betroffen: betroffen.length,
      sperre: betroffen.some(function (f) { return f.wirkung === 'sperre'; }),
      eingeschraenkt: betroffen.some(function (f) { return f.wirkung === 'eingeschraenkt'; })
    };
  }

  MM.Aktivitaeten = {
    VORSCHLAEGE_ARTEN: VORSCHLAEGE_ARTEN, ZUORDNUNG_VORSCHLAEGE: ZUORDNUNG_VORSCHLAEGE, zuordnungVorschlag: zuordnungVorschlag, ROLLEN: ROLLEN, ERGEBNIS: ERGEBNIS,
    verantwortlichenName: verantwortlichenName, rolleLabel: rolleLabel,
    zeitpunkt: zeitpunkt, von: von, bis: bis, status: status, ueberschneiden: ueberschneiden, verantwortlicher: verantwortlicher,
    pruefeBefaehigung: pruefeBefaehigung, gesamtErgebnis: gesamtErgebnis,
    fristenImZeitraum: fristenImZeitraum, fristenZusammenfassung: fristenZusammenfassung
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
