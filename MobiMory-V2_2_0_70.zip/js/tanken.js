/* Tanken: Füllstand, Verbrauch und Reichweite (seit 2.0.51). Nur Regeln, kein Speicher und kein Netz.
 *
 * Festlegungen des Nutzers (09.11.2026):
 *  - Der Füllstand beginnt, indem der Nutzer den Stand EINMAL beim Tank angibt. „Voll getankt“ setzt den Tank danach auf seinen Tankinhalt.
 *  - „Nicht voll getankt“: Füllstand plus Menge, mit Hinweis, dass der Stand dann nur gerechnet ist.
 *  - Verbrauch: aus Füllstand ODER aus Betriebsstunden, je Verbraucher wählbar. Bei mehreren Verbrauchern an einem Tank gibt der
 *    Füllstand nur eine Summe.
 *
 * Was „aus Füllstand“ und „aus Betriebsstunden“ hier heißt:
 *  - aus Füllstand:      verbrauchte Liter seit dem letzten Stand, je Tag (l/Tag)
 *  - aus Betriebsstunden: dieselben Liter, geteilt durch die Betriebsstunden des Verbrauchers in dieser Zeit (l/h)
 * Verbrauchte Liter gibt es nur, wenn der letzte Stand genau war (angegeben oder voll) und jetzt voll getankt wurde:
 *   Liter = letzter Stand − (Tankinhalt − getankte Menge).
 * Nichts wird geraten: Fehlt etwas, steht es als Hinweis im Ergebnis und es wird nichts gerechnet.
 *
 * Gespeichert wird in den Werten des Tanks (Verlauf wie bei jedem anderen Feld):
 *   fuellstand (Liter), fuellstandArt ('angegeben' | 'voll' | 'gerechnet'), fuellstandZeit ('JJJJ-MM-TTTHH:MM'),
 *   fuellstandStunden ({ Kennung des Verbrauchers: Stand des Betriebsstunden-Zählers zu dieser Zeit }),
 *   fuellstandStrecke (Kilometerstand zu dieser Zeit, seit 2.0.56),
 *   verbrauch ({ liter, tage, von, bis, lProTag, km, lProKm, lProSm, summe, einzeln: [{ id, name, aus, lProTag, lProStunde, stunden }] }),
 *   reichweite ([{ name, wert, einheit }]). */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var TAG_MS = 86400000;

  function zahl(v) {
    if (typeof v === 'number') return isFinite(v) ? v : null;
    var t = String(v === undefined || v === null ? '' : v).trim().replace(',', '.');
    if (!t || !/^-?\d+(\.\d+)?$/.test(t)) return null;
    return Number(t);
  }
  function runde(x, stellen) { var f = Math.pow(10, stellen === undefined ? 1 : stellen); return Math.round(x * f) / f; }
  function text(x, stellen) { return String(runde(x, stellen === undefined ? 1 : stellen)).replace('.', ','); }
  function ms(iso) { var t = iso ? new Date(iso).getTime() : NaN; return isFinite(t) ? t : null; }
  function gleichText(a, b) { return String(a == null ? '' : a).trim().toLowerCase() === String(b == null ? '' : b).trim().toLowerCase(); }

  /* Tankinhalt in Litern aus den Merkmalen des Tanks, oder null (fehlt, keine Zahl oder andere Einheit als Liter). */
  function kapazitaet(werte) {
    var m = ((werte && werte.merkmale) || []).filter(function (x) { return x && gleichText(x.name, 'Tankinhalt'); })[0];
    if (!m) return null;
    var n = zahl(m.wert);
    if (n === null || !(n > 0)) return null;
    var e = String(m.einheit || '').trim().toLowerCase();
    return e === '' || e === 'l' || e === 'liter' ? n : null;
  }

  /*
   * Ein Tankvorgang. o:
   *   kapazitaet   Tankinhalt in Litern oder null
   *   alt          { fuellstand, art, zeit, stunden }  der Stand vor diesem Tanken (Werte des Tanks)
   *   altVerbrauch zuletzt berechneter Verbrauch (für die Reichweite, wenn dieses Tanken keinen neuen liefert)
   *   menge        getankte Liter
   *   voll         true, wenn voll getankt
   *   zeit         Zeitpunkt des Tankens ('JJJJ-MM-TTTHH:MM')
   *   verbraucher  [{ id, name, aus: 'fuellstand' | 'stunden', stunden: aktueller Stand des Betriebsstunden-Zählers oder null }]
   * Ergebnis: { setzen, fuellstand, art, verbrauch, reichweite, stunden, hinweise }
   *   setzen = der Füllstand des Tanks soll geändert werden (sonst bleibt er, wie er ist).
   */
  function berechnen(o) {
    var hinweise = [];
    var erg = { setzen: false, fuellstand: null, art: null, verbrauch: null, reichweite: null, stunden: {}, strecke: null, hinweise: hinweise };
    var kap = o.kapazitaet === undefined ? null : o.kapazitaet;
    var alt = o.alt || {}, menge = o.menge, voll = !!o.voll;
    var verb = o.verbraucher || [];
    verb.forEach(function (v) { if (typeof v.stunden === 'number') erg.stunden[v.id] = v.stunden; });
    erg.strecke = typeof o.strecke === 'number' && isFinite(o.strecke) ? o.strecke : null;
    var altStand = typeof alt.fuellstand === 'number' ? alt.fuellstand : null;
    var zt = ms(o.zeit), za = ms(alt.zeit);

    if (altStand !== null && zt !== null && za !== null && zt < za) {
      hinweise.push('Dieses Tanken liegt vor dem letzten Füllstand. Der Füllstand bleibt, wie er ist.');
      return erg;
    }

    var nach = null;
    if (voll) {
      if (kap === null) {
        hinweise.push('Der Tankinhalt fehlt oder ist nicht in Litern angegeben. Ohne ihn setzt „voll getankt“ keinen Füllstand. Trag „Tankinhalt“ beim Tank ein.');
      } else {
        nach = kap; erg.art = 'voll';
        if (menge > kap) hinweise.push('Die Menge ist größer als der Tankinhalt (' + text(kap) + ' l). Bitte Menge und Tankinhalt prüfen. Verbrauch wurde nicht gerechnet.');
        else if (altStand === null) hinweise.push('Verbrauch noch nicht gerechnet: Es gibt noch keinen früheren Füllstand. Ab dem nächsten Volltanken wird gerechnet.');
        else if (alt.art === 'gerechnet') hinweise.push('Verbrauch nicht gerechnet: Der letzte Füllstand war nur gerechnet, nicht angegeben und nicht voll.');
        else {
          var liter = altStand - (kap - menge);
          if (liter < 0) hinweise.push('Verbrauch nicht gerechnet: Die Menge passt nicht zum letzten Füllstand (' + text(altStand) + ' l). Bitte Füllstand und Menge prüfen.');
          else if (za === null || zt === null || !((zt - za) / TAG_MS > 0.0001)) hinweise.push('Verbrauch nicht gerechnet: Zwischen dem letzten Stand und diesem Tanken ist keine Zeit vergangen oder die Zeit fehlt.');
          else erg.verbrauch = verbrauchRechnen(liter, (zt - za) / TAG_MS, alt, o, verb, hinweise, erg.strecke);
        }
      }
    } else if (altStand === null) {
      hinweise.push('Der Füllstand ist noch nicht angegeben. Gib den Stand einmal beim Tank an. Bis dahin wird nichts gerechnet.');
    } else {
      nach = altStand + menge; erg.art = 'gerechnet';
      if (kap !== null && nach > kap) { nach = kap; hinweise.push('Letzter Stand plus Menge ist mehr als der Tankinhalt. Der Füllstand ist auf ' + text(kap) + ' l begrenzt.'); }
      hinweise.push('Der Füllstand ist nur gerechnet: letzter Stand plus Menge. Der Verbrauch dazwischen ist nicht abgezogen.');
    }

    if (nach !== null) {
      erg.setzen = true; erg.fuellstand = runde(nach, 2);
      erg.reichweite = reichweiteRechnen(erg.fuellstand, erg.verbrauch || o.altVerbrauch || null);
      if (!erg.reichweite) hinweise.push('Reichweite noch nicht gerechnet: Es gibt noch keinen Verbrauch.');
    }
    return erg;
  }

  function verbrauchRechnen(liter, tage, alt, o, verb, hinweise, streckeJetzt) {
    var v = { liter: runde(liter, 2), tage: runde(tage, 3), von: alt.zeit, bis: o.zeit, lProTag: runde(liter / tage, 2), summe: verb.length !== 1, einzeln: [] };
    /* Entfernung (seit 2.0.56): nur wenn ein Motor an diesem Tank hängt und der Kilometerzähler vorher und jetzt einen Stand hat. */
    var hatMotor = verb.some(function (x) { return x.motor === true; });
    var km = hatMotor ? global.MM.Verbrauch.strecke(alt.strecke, streckeJetzt) : null;
    if (km !== null) { v.km = km; v.lProKm = runde(liter / km, 3); v.lProSm = runde(liter / global.MM.Verbrauch.kmZuSm(km), 3); }
    else if (hatMotor && (typeof alt.strecke === 'number' || streckeJetzt !== null)) hinweise.push('Verbrauch je Kilometer oder Seemeile nicht gerechnet: Der Kilometerzähler hat zu dieser Zeit keinen neuen Stand (kein Zähler, kein Stand oder nicht gewachsen).');
    verb.forEach(function (x) {
      var e = { id: x.id, name: x.name, aus: x.aus === 'stunden' ? 'stunden' : 'fuellstand' };
      var delta = alt.stunden && typeof alt.stunden[x.id] === 'number' && typeof x.stunden === 'number' ? x.stunden - alt.stunden[x.id] : null;
      if (e.aus === 'stunden') {
        if (delta !== null && delta > 0) {
          e.stunden = runde(delta, 2);
          if (!v.summe) e.lProStunde = runde(liter / delta, 2);
        } else if (!v.summe) hinweise.push('Für „' + x.name + '“ fehlen Betriebsstunden in dieser Zeit (kein Zähler oder kein neuer Stand). Es gibt nur den Verbrauch je Tag.');
      }
      if (!v.summe) e.lProTag = v.lProTag;
      v.einzeln.push(e);
    });
    if (verb.length > 1) hinweise.push('An diesem Tank hängen mehrere Verbraucher. Der Füllstand gibt nur die Summe, nicht den Verbrauch je Verbraucher.');
    return v;
  }

  function reichweiteRechnen(stand, v) {
    if (!v || !(stand > 0)) return null;
    var liste = [];
    (v.einzeln || []).forEach(function (e) {
      if (e.lProStunde > 0) liste.push({ name: e.name, wert: runde(stand / e.lProStunde, 1), einheit: 'Betriebsstunden' });
    });
    if (v.lProKm > 0) {
      liste.push({ name: 'Entfernung', wert: runde(stand / v.lProKm, 0), einheit: 'km' });
      liste.push({ name: 'Entfernung', wert: runde(stand / v.lProSm, 0), einheit: 'sm' });
    }
    if (v.lProTag > 0) liste.push({ name: v.summe ? 'alle Verbraucher zusammen' : ((v.einzeln[0] && v.einzeln[0].name) || 'Verbraucher'), wert: runde(stand / v.lProTag, 1), einheit: 'Tage' });
    return liste.length ? liste : null;
  }


  /* ---------- Menge in Liter oder kg (seit 2.0.63) ---------- */
  /*
   * Jeder Stoff kann eine Dichte haben (kg je Liter, Stoffliste). Mit Dichte kann die Menge in Liter oder kg eingegeben werden, der Tank rechnet
   * intern in Litern. Der Preis wird so eingegeben, wie bezahlt (je Liter oder je kg). Ohne Dichte geht nur Liter.
   * mengeLiter: { ok, liter, kg, einheit } oder { ok: false, fehler }.
   */
  function dichteGueltig(d) { var n = zahl(d); return n !== null && n > 0 && n <= 5 ? n : null; }
  function mengeLiter(wert, einheit, dichte) {
    var n = zahl(wert), d = dichteGueltig(dichte);
    if (n === null || n < 0) return { ok: false, fehler: 'Bitte die Menge als Zahl eingeben, zum Beispiel 45,5.' };
    if (einheit === 'kg') {
      if (d === null) return { ok: false, fehler: 'Für diesen Stoff ist keine Dichte eingetragen. Trage sie in der Stoffliste ein oder gib die Menge in Litern an.' };
      return { ok: true, liter: runde(n / d, 3), kg: n, einheit: 'kg' };
    }
    return { ok: true, liter: n, kg: d !== null ? runde(n * d, 3) : null, einheit: 'l' };
  }
  /* Preis je Liter aus dem Preis je Liter oder je kg (Euro je kg mal kg je Liter gibt Euro je Liter). */
  function preisJeLiter(preis, einheit, dichte) {
    var n = zahl(preis), d = dichteGueltig(dichte);
    if (n === null) return null;
    if (einheit === 'kg') return d === null ? null : runde(n * d, 6);
    return n;
  }
  /* „45 l (23 kg)“ oder „45 l“ */
  function mengeText(liter, dichte) {
    var d = dichteGueltig(dichte);
    return text(liter, 2) + ' l' + (d !== null ? ' (' + text(liter * d, 2) + ' kg)' : '');
  }

  /* ---------- Mehrere Vorgänge an einem Tank nacheinander rechnen (seit 2.0.63) ---------- */
  /*
   * Ändert sich ein Vorgang (zum Beispiel auf 0 Liter), oder kommt einer nachträglich dazu, wird die Kette der Vorgänge des Tanks neu gerechnet:
   * ab dem Stand, mit dem sie begonnen hat, einer nach dem anderen. Ein Vorgang mit 0 Litern ändert nichts (der Tank bleibt auf dem Stand davor).
   *  o.kapazitaet    Tankinhalt in Litern oder null
   *  o.basis         { fuellstand, art, zeit, stunden, strecke, verbrauch } der Stand am Anfang der Kette, oder null (noch kein Stand)
   *  o.vorgaenge     [{ id, zeit, art, menge, voll, stunden, strecke }] nach Zeit geordnet; art: 'auf' (tanken, auffüllen), 'leer' (entleeren), 'flasche' (neue Flasche)
   *                  menge 0 = der Vorgang zählt nicht; bei 'leer' bedeutet voll 'ja' ganz leer; bei 'flasche' gibt es keine Menge
   *  o.verbraucher   [{ id, name, aus, motor }] die Verbraucher an diesem Tank
   * Ergebnis: { stand, ergebnisse: { id: { id, zaehlt, setzen, fuellstandNach, verbrauch, hinweise } } }; stand = Stand nach dem letzten Vorgang (oder null).
   */
  function kopieStand(st) { return st ? { fuellstand: st.fuellstand, art: st.art, zeit: st.zeit, stunden: st.stunden || null, strecke: typeof st.strecke === 'number' ? st.strecke : null, verbrauch: st.verbrauch || null, reichweite: st.reichweite || null } : null; }
  function kette(o) {
    var kap = o.kapazitaet === undefined ? null : o.kapazitaet;
    var stand = kopieStand(o.basis && typeof o.basis.fuellstand === 'number' ? o.basis : null);
    var ergebnisse = {};
    (o.vorgaenge || []).forEach(function (v) {
      var e = { id: v.id, zaehlt: true, setzen: false, fuellstandNach: null, verbrauch: null, hinweise: [] };
      ergebnisse[v.id] = e;
      var art = v.art === 'leer' || v.art === 'flasche' ? v.art : 'auf';
      if (v.menge === 0) {
        e.zaehlt = false; e.fuellstandNach = stand ? stand.fuellstand : null;
        e.hinweise.push('Dieser Vorgang hat 0 Liter und zählt nicht. Der Tank bleibt auf dem Stand davor.');
        return;
      }
      var strecke = typeof v.strecke === 'number' && isFinite(v.strecke) ? v.strecke : null;
      var stundenStand = v.stunden || null;
      if (art === 'auf') {
        var verb = (o.verbraucher || []).map(function (x) { return Object.assign({}, x, { stunden: stundenStand && typeof stundenStand[x.id] === 'number' ? stundenStand[x.id] : null }); });
        var erg = berechnen({ kapazitaet: kap, alt: stand ? { fuellstand: stand.fuellstand, art: stand.art, zeit: stand.zeit, stunden: stand.stunden, strecke: stand.strecke === null ? undefined : stand.strecke } : {},
          altVerbrauch: stand ? stand.verbrauch : null, menge: v.menge, voll: !!v.voll, zeit: v.zeit, verbraucher: verb, strecke: strecke });
        e.hinweise = erg.hinweise.slice();
        if (erg.setzen) {
          e.setzen = true; e.fuellstandNach = erg.fuellstand; e.verbrauch = erg.verbrauch || null;
          stand = { fuellstand: erg.fuellstand, art: erg.art, zeit: v.zeit, stunden: erg.stunden, strecke: erg.strecke, verbrauch: erg.verbrauch || (stand ? stand.verbrauch : null), reichweite: erg.reichweite };
        } else e.fuellstandNach = stand ? stand.fuellstand : null;
      } else if (art === 'leer') {
        var neu = null, ganz = v.voll === true || v.voll === 'ja';
        if (ganz) neu = { fuellstand: 0, art: 'leer' };
        else if (stand && typeof v.menge === 'number' && v.menge > 0) neu = { fuellstand: Math.max(0, runde(stand.fuellstand - v.menge, 2)), art: 'gerechnet' };
        else if (!stand) e.hinweise.push('Der Füllstand ist noch nicht angegeben. Mit „ganz leer“ steht der Tank danach auf 0.');
        else e.hinweise.push('Weder „ganz leer“ noch eine Menge: Der Füllstand bleibt, wie er ist.');
        if (neu) {
          e.setzen = true; e.fuellstandNach = neu.fuellstand;
          stand = { fuellstand: neu.fuellstand, art: neu.art, zeit: v.zeit, stunden: stundenStand, strecke: strecke, verbrauch: stand ? stand.verbrauch : null, reichweite: reichweiteRechnen(neu.fuellstand, stand ? stand.verbrauch : null) };
        } else e.fuellstandNach = stand ? stand.fuellstand : null;
      } else {
        if (kap === null) { e.hinweise.push('Der Tankinhalt fehlt oder ist nicht in Litern angegeben. Ohne ihn kann die neue Flasche nicht als voll gesetzt werden. Trag „Tankinhalt“ beim Tank ein.'); e.fuellstandNach = stand ? stand.fuellstand : null; }
        else {
          e.setzen = true; e.fuellstandNach = kap;
          stand = { fuellstand: kap, art: 'voll', zeit: v.zeit, stunden: stundenStand, strecke: strecke, verbrauch: stand ? stand.verbrauch : null, reichweite: reichweiteRechnen(kap, stand ? stand.verbrauch : null) };
        }
      }
    });
    return { stand: stand, ergebnisse: ergebnisse };
  }


  /* ---------- Ver- und Entsorgung (seit 2.0.63) ---------- */
  /*
   * Ein Ereignis „Ver- und Entsorgung“ statt getrennter Vorgänge: Die erste Frage ist „Was?“. Die Liste ist eine Vorlage, der Nutzer erweitert sie.
   * Angeboten wird nur, was das Fahrzeug als Komponenten hat: nur Vorgänge, zu denen es einen passenden Tank gibt.
   *  art:      'auf' (Füllstand steigt, bei „voll“ auf den Tankinhalt), 'leer' (Füllstand sinkt, bei „ganz leer“ auf 0), 'flasche' (neue Flasche, voll)
   *  stoffe:   welche Stoffe am Tank dazu passen; 'brennstoff' = alle außer Strom und Wasser-Stoffen (auch Tanks ohne Stoff)
   *  kostenart: Kostenart des Kostenpostens (Vorlage der Kostenarten)
   */
  var VORGANG_VORLAGE = [
    { id: 'tanken', name: 'Treibstoff/Brennstoff tanken', art: 'auf', stoffe: 'brennstoff', kostenart: 'treibstoff' },
    { id: 'gasflasche', name: 'Gasflasche tauschen', art: 'flasche', stoffe: ['Gas (Flüssiggas)'], kostenart: 'treibstoff' },
    { id: 'frischwasser', name: 'Frischwasser auffüllen', art: 'auf', stoffe: ['Frischwasser'], kostenart: 'wasser' },
    { id: 'grauwasser', name: 'Grauwasser entleeren', art: 'leer', stoffe: ['Grauwasser'], kostenart: 'gebuehren' },
    { id: 'schwarzwasser', name: 'Schwarzwasser (Fäkalien) entleeren', art: 'leer', stoffe: ['Schwarzwasser (Fäkalien)'], kostenart: 'gebuehren' },
    { id: 'chemietoilette', name: 'Chemietoilette entleeren', art: 'leer', stoffe: ['Chemietoilette'], kostenart: 'gebuehren' }
  ];
  function vorgangStoffPasst(vorgang, stoff, istWasserOderStrom) {
    if (!vorgang) return false;
    if (vorgang.stoffe === 'brennstoff') return !stoff || !istWasserOderStrom(stoff);
    return !!stoff && (vorgang.stoffe || []).some(function (x) { return gleichText(x, stoff); });
  }
  /* Tanks, die zu dem Vorgang passen: tanks [{ id, name, stoff }] */
  function tanksFuerVorgang(vorgang, tanks, istWasserOderStrom) {
    return (tanks || []).filter(function (t) { return vorgangStoffPasst(vorgang, t.stoff, istWasserOderStrom); });
  }
  /* Die Vorgänge, die das Fahrzeug anbieten kann (mindestens ein passender Tank) */
  function vorgangAngebot(vorgaenge, tanks, istWasserOderStrom) {
    return (vorgaenge || []).filter(function (v) { return tanksFuerVorgang(v, tanks, istWasserOderStrom).length > 0; });
  }
  /* Kraftstoffart: Mit dem Stoff des gewählten Tanks vorbelegt. Wählt der Nutzer etwas anderes, gibt es nur einen Hinweis, keine Sperre.
   * Hat der Tank noch keinen Stoff: weder Vorbelegung noch Hinweis. Gibt { vorbelegung, hinweis }. */
  function stoffHinweis(tankStoff, gewaehlt, tankName) {
    var t = String(tankStoff == null ? '' : tankStoff).trim(), g = String(gewaehlt == null ? '' : gewaehlt).trim();
    if (!t) return { vorbelegung: '', hinweis: null };
    if (g && !gleichText(t, g)) return { vorbelegung: t, hinweis: 'Im Tank „' + (tankName || 'Tank') + '“ ist laut Angabe ' + t + ' (gewählt: ' + g + '). Das ist nur ein Hinweis, die App sperrt nichts.' };
    return { vorbelegung: t, hinweis: null };
  }

  /* Die Zeilen für „Das hat die App getan“. */
  function zeilen(erg, tankName) {
    var z = [];
    if (erg.setzen) {
      z.push('Füllstand ' + tankName + ': ' + text(erg.fuellstand) + ' l' + (erg.art === 'voll' ? ' (voll getankt)' : ' (nur gerechnet)') + '.');
    }
    return z;
  }
  /* Alle Zeilen des Verbrauchs. einheit (seit 2.0.56): die gewählte Einheit steht zuerst, die übrigen folgen. Ohne Angabe: Betriebsstunden,
   * Entfernung, Tag. Gezeigt wird nur, was sich rechnen ließ. */
  function verbrauchZeilen(v, einheit) {
    if (!v) return [];
    var z = ['Verbrauch seit dem letzten Stand: ' + text(v.liter) + ' l in ' + text(v.tage, 1) + ' Tagen (' + text(v.lProTag, 2) + ' l je Tag' + (v.summe ? ', Summe aller Verbraucher' : '') + ').'];
    var gruppen = { stunde: [], km: [], sm: [], tag: [] };
    (v.einzeln || []).forEach(function (e) {
      if (e.lProStunde > 0) gruppen.stunde.push(e.name + ': ' + text(e.lProStunde, 2) + ' l je Betriebsstunde (' + text(e.stunden, 1) + ' Betriebsstunden).');
      else if (e.stunden > 0) gruppen.stunde.push(e.name + ': ' + text(e.stunden, 1) + ' Betriebsstunden in dieser Zeit.');
    });
    if (v.lProKm > 0) {
      gruppen.km.push('Entfernung: ' + text(v.lProKm, 2) + ' l je km (' + text(v.km, 1) + ' km).');
      gruppen.sm.push('Entfernung: ' + text(v.lProSm, 2) + ' l je sm (' + text(global.MM.Verbrauch.kmZuSm(v.km), 1) + ' sm).');
    }
    var vorhanden = Object.keys(gruppen).filter(function (k) { return gruppen[k].length; });
    global.MM.Verbrauch.reihenfolge(einheit, vorhanden).forEach(function (k) { z = z.concat(gruppen[k]); });
    return z;
  }
  /* Eine Zeile für Listen: die gewählte Einheit, wenn sie sich rechnen ließ, sonst Betriebsstunden, Entfernung, Tag. */
  function verbrauchKurz(v, einheit) {
    if (!v) return null;
    var tagText = text(v.lProTag, 2) + ' l je Tag';
    var teile = {
      stunde: (v.einzeln || []).filter(function (e) { return e.lProStunde > 0; }).map(function (e) { return text(e.lProStunde, 2) + ' l je Betriebsstunde' + (v.einzeln.length > 1 ? ' (' + e.name + ')' : ''); }),
      km: v.lProKm > 0 ? [text(v.lProKm, 2) + ' l je km'] : [],
      sm: v.lProSm > 0 ? [text(v.lProSm, 2) + ' l je sm'] : [],
      tag: [tagText]
    };
    var vorhanden = Object.keys(teile).filter(function (k) { return teile[k].length; });
    var erste = global.MM.Verbrauch.reihenfolge(einheit, vorhanden)[0] || 'tag';
    return 'Verbrauch: ' + teile[erste].join(', ') + (v.summe && erste === 'tag' ? ' (Summe aller Verbraucher)' : '');
  }
  function reichweiteZeilen(r) {
    return (r || []).map(function (x) { return 'Reichweite ' + x.name + ': etwa ' + text(x.wert, 1) + ' ' + x.einheit + '.'; });
  }

  /* Eine Zeile für die Liste der Tanks (Fahrzeugseite). */
  function tankZeile(t) {
    if (typeof t.fuellstand !== 'number') return 'Füllstand noch nicht angegeben';
    var art = t.fuellstandArt === 'voll' ? 'voll getankt' : (t.fuellstandArt === 'gerechnet' ? 'nur gerechnet' : (t.fuellstandArt === 'leer' ? 'entleert' : 'angegeben'));
    return 'Füllstand ' + text(t.fuellstand) + ' l (' + art + (t.fuellstandZeit ? ', ' + String(t.fuellstandZeit).replace('T', ' ') + ' Uhr' : '') + ')';
  }

  MM.Tanken = {
    zahl: zahl, runde: runde, reichweite: reichweiteRechnen, kapazitaet: kapazitaet, berechnen: berechnen, zeilen: zeilen, verbrauchZeilen: verbrauchZeilen, verbrauchKurz: verbrauchKurz,
    reichweiteZeilen: reichweiteZeilen, tankZeile: tankZeile, text: text,
    VORGANG_VORLAGE: VORGANG_VORLAGE.map(function (v) { return Object.assign({}, v, { stoffe: Array.isArray(v.stoffe) ? v.stoffe.slice() : v.stoffe }); }), vorgangStoffPasst: vorgangStoffPasst, tanksFuerVorgang: tanksFuerVorgang, vorgangAngebot: vorgangAngebot, stoffHinweis: stoffHinweis,
    dichteGueltig: dichteGueltig, mengeLiter: mengeLiter, preisJeLiter: preisJeLiter, mengeText: mengeText, kette: kette,
    VERBRAUCH_AUS: [
      { wert: 'fuellstand', label: 'Aus dem Füllstand (Liter je Tag)' },
      { wert: 'stunden', label: 'Aus den Betriebsstunden (Liter je Betriebsstunde)' }
    ]
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
