/*
 * Fahrzeugarten und ihre Felder.
 *
 * Die Felder sind hier als DATEN beschrieben, nicht in der Oberfläche
 * festverdrahtet. So kann später eine vom Nutzer zusammengestellte
 * Fahrzeugart (zum Beispiel ein Monowheel) auf demselben Weg entstehen:
 * Sie ist dann nur eine weitere Liste von Feldern.
 *
 * Schale 1 = Fahrzeugliste (Bezeichnung, Art, Kennung)
 * Schale 2 = Äußere Hülle (alle Felder unten)
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var KRAFTSTOFFE = ['Benzin', 'Diesel', 'Autogas (LPG)', 'Erdgas (CNG)',
    'Elektro', 'Hybrid', 'Wasserstoff', 'Sonstiger'];

  var GRUPPEN = [
    { id: 'fahrzeug', titel: 'Fahrzeug' },
    { id: 'masse', titel: 'Maße' },
    { id: 'gewichte', titel: 'Gewichte' },
    { id: 'antrieb', titel: 'Kraftstoff und Geschwindigkeit' },
    { id: 'strasse', titel: 'Achsen und Maut' }
  ];

  var FELDER = {
    marke: { label: 'Marke', typ: 'text', gruppe: 'fahrzeug' },
    modell: { label: 'Modell', typ: 'text', gruppe: 'fahrzeug' },
    typ: { label: 'Typ', typ: 'text', gruppe: 'fahrzeug' },
    baujahr: { label: 'Baujahr', typ: 'ganzzahl', gruppe: 'fahrzeug', min: 1800 },
    erstzulassung: { label: 'Erstzulassung', typ: 'datum', gruppe: 'fahrzeug' },
    kennzeichen: { label: 'Kennzeichen', typ: 'text', gruppe: 'fahrzeug' },
    registriernummer: { label: 'Registriernummer', typ: 'text', gruppe: 'fahrzeug' },
    fin: { label: 'FIN (Fahrgestellnummer)', typ: 'text', gruppe: 'fahrzeug' },
    hin: { label: 'HIN (Rumpfnummer)', typ: 'text', gruppe: 'fahrzeug' },
    plaetze: { label: 'Personen / Plätze', typ: 'ganzzahl', gruppe: 'fahrzeug', min: 1, max: 999,
      hilfe: 'Für wie viele Personen das Fahrzeug zugelassen ist. Der Grundcheck rechnet damit Ausrüstung „je Person“, zum Beispiel Warnwesten oder Rettungswesten.' },

    laenge: { label: 'Länge', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    breite: { label: 'Breite', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    hoehe: { label: 'Höhe', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    tiefgang: { label: 'Tiefgang', typ: 'zahl', einheit: 'm', gruppe: 'masse' },
    durchfahrtshoehe: { label: 'Durchfahrtshöhe', typ: 'zahl', einheit: 'm', gruppe: 'masse',
      hilfe: 'Höhe über dem Wasser, wichtig für Brücken' },

    leergewicht: { label: 'Leergewicht', typ: 'zahl', einheit: 'kg', gruppe: 'gewichte' },
    gesamtgewicht: { label: 'Zulässiges Gesamtgewicht', typ: 'zahl', einheit: 'kg', gruppe: 'gewichte' },

    kraftstoff: { label: 'Kraftstoff', typ: 'auswahl', optionen: KRAFTSTOFFE, gruppe: 'antrieb' },
    hoechstgeschwindigkeit: { label: 'Höchstgeschwindigkeit', typ: 'zahl', einheit: 'km/h', gruppe: 'antrieb' },
    reisegeschwindigkeit: { label: 'Reisegeschwindigkeit', typ: 'zahl', einheit: 'km/h', gruppe: 'antrieb',
      hilfe: 'Deine übliche Geschwindigkeit unterwegs' },

    achsen: { label: 'Achsen', typ: 'ganzzahl', gruppe: 'strasse', min: 1, max: 10 },
    mautklasse: { label: 'Mautklasse', typ: 'text', gruppe: 'strasse' }
  };

  var LAND = ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin', 'plaetze',
    'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
    'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit', 'achsen', 'mautklasse'];

  var BOOT = ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'registriernummer', 'hin', 'plaetze',
    'laenge', 'breite', 'tiefgang', 'durchfahrtshoehe', 'leergewicht', 'gesamtgewicht',
    'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit'];

  /*
   * Der Baum der Fahrzeugarten (seit 2.0.15).
   *  - GRUPPEN_KNOTEN sind nur Ordnung (Land, Wasser, Luft), kein Fahrzeug hat so eine Art.
   *  - Jede Art hat ein „eltern“. Die Wurzel heißt 'alle'.
   *  - Gespeichert wird an einem Fahrzeug weiter nur die Art-Kennung. Alte Fahrzeuge
   *    (zum Beispiel 'boot') bleiben unverändert gültig und stehen im Baum an ihrer Stelle.
   */
  var WURZEL = 'alle';
  var GRUPPEN_KNOTEN = [
    { id: 'land', name: 'Landfahrzeug', welt: 'land', eltern: WURZEL, felder: [], gruppe: true },
    { id: 'wasser', name: 'Wasserfahrzeug', welt: 'wasser', eltern: WURZEL, felder: [], gruppe: true },
    { id: 'luft', name: 'Luftfahrzeug', welt: 'luft', eltern: WURZEL, felder: [], gruppe: true }
  ];

  var ARTEN = [
    { id: 'auto', name: 'Auto', welt: 'land', eltern: 'land', kennung: 'kennzeichen', felder: LAND },
    { id: 'motorrad', name: 'Motorrad', welt: 'land', eltern: 'land', kennung: 'kennzeichen',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin', 'plaetze',
        'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
        'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit'] },
    { id: 'wohnmobil', name: 'Wohnmobil', welt: 'land', eltern: 'land', kennung: 'kennzeichen', felder: LAND },
    { id: 'wohnwagen', name: 'Wohnwagen', welt: 'land', eltern: 'land', kennung: 'kennzeichen',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'kennzeichen', 'fin',
        'laenge', 'breite', 'hoehe', 'leergewicht', 'gesamtgewicht',
        'hoechstgeschwindigkeit', 'achsen', 'mautklasse'] },
    { id: 'oldtimer', name: 'Oldtimer', welt: 'land', eltern: 'land', kennung: 'kennzeichen', felder: LAND },
    { id: 'boot', name: 'Boot', welt: 'wasser', eltern: 'wasser', kennung: 'registriernummer', felder: BOOT },
    { id: 'sportboot', name: 'Sportboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'wasserskiboot', name: 'Wasserskiboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'wohnboot', name: 'Motorboot zum Übernachten', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'motorschiff', name: 'Motorschiff', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot', name: 'Segelboot', welt: 'wasser', eltern: 'boot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot-monohull', name: 'Segelboot Monohull', welt: 'wasser', eltern: 'segelboot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot-katamaran', name: 'Segelboot Katamaran', welt: 'wasser', eltern: 'segelboot', kennung: 'registriernummer', felder: BOOT },
    { id: 'segelboot-jolle', name: 'Segelboot Jolle oder Kleinboot', welt: 'wasser', eltern: 'segelboot', kennung: 'registriernummer', felder: BOOT },
    { id: 'flugzeug', name: 'Flugzeug', welt: 'luft', eltern: 'luft', kennung: 'registriernummer',
      felder: ['marke', 'modell', 'typ', 'baujahr', 'erstzulassung', 'registriernummer', 'plaetze',
        'laenge', { key: 'breite', label: 'Spannweite' }, 'hoehe', 'leergewicht',
        { key: 'gesamtgewicht', label: 'Höchstzulässiges Abfluggewicht' },
        'kraftstoff', 'hoechstgeschwindigkeit', 'reisegeschwindigkeit'] }
  ];

  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }

  /*
   * Eigene Arten und Änderungen des Nutzers (seit 2.0.16).
   *  eigene:        [{ id, name, eltern }]  vom Nutzer angelegte Arten oder Untergruppen
   *  ueberschreibung: { artId: { name?, ausgeblendet?, geloescht? } }  gilt für mitgelieferte und eigene Arten
   * Die Gruppen Land, Wasser und Luft sind fest. Eine eigene Art übernimmt Felder und Kennung der Obergruppe.
   * Gelöscht heißt: unsichtbar und nicht mehr wählbar. Das geht nur, wenn kein Fahrzeug die Art
   * (oder eine Untergruppe davon) hat. Ausblenden geht immer, bestehende Fahrzeuge bleiben unverändert.
   */
  var eigene = [];
  var ueber = {};
  var cache = null;

  function konfigurieren(dok) {
    eigene = dok && Array.isArray(dok.eigene) ? dok.eigene.map(function (e) { return { id: e.id, name: e.name, eltern: e.eltern }; }) : [];
    ueber = {};
    var u = dok && dok.ueberschreibung && typeof dok.ueberschreibung === 'object' ? dok.ueberschreibung : {};
    Object.keys(u).forEach(function (k) { ueber[k] = kopie(u[k]); });
    cache = null;
  }
  function dokument() {
    return { id: 'fahrzeugarten', eigene: eigene.map(function (e) { return { id: e.id, name: e.name, eltern: e.eltern }; }), ueberschreibung: JSON.parse(JSON.stringify(ueber)) };
  }

  /* Alle Knoten (ohne Gelöschte) in einer Karte. Wird bei jeder Änderung neu aufgebaut. */
  function stand() {
    if (cache) return cache;
    var karte = {}, reihenfolge = [];
    function aufnehmen(k) { karte[k.id] = k; reihenfolge.push(k.id); }
    GRUPPEN_KNOTEN.concat(ARTEN).forEach(function (a) {
      var k = kopie(a), o = ueber[a.id] || {};
      if (o.name) k.name = o.name;
      k.ausgeblendet = !!o.ausgeblendet; k.geloescht = !!o.geloescht;
      aufnehmen(k);
    });
    eigene.forEach(function (e) {
      var o = ueber[e.id] || {};
      aufnehmen({ id: e.id, name: o.name || e.name, eltern: e.eltern, eigen: true, ausgeblendet: !!o.ausgeblendet, geloescht: !!o.geloescht });
    });
    /* Felder, Kennung und Welt der eigenen Arten kommen von der Obergruppe. */
    var STANDARD = { land: 'auto', wasser: 'boot', luft: 'flugzeug' };
    function erben(k, tiefe) {
      if (k.felder || tiefe > 20) return;
      var eltern = karte[k.eltern];
      if (eltern && !eltern.felder) erben(eltern, tiefe + 1);
      k.welt = eltern ? eltern.welt : 'land';
      var quelle = eltern && eltern.felder && eltern.felder.length ? eltern : karte[STANDARD[k.welt]] || karte.auto;
      k.felder = quelle.felder; k.kennung = quelle.kennung;
    }
    reihenfolge.forEach(function (id) { erben(karte[id], 0); });
    /* Unter einer gelöschten Art ist alles gelöscht. */
    function geloeschtOben(k, tiefe) { return k.geloescht || (tiefe < 20 && karte[k.eltern] && geloeschtOben(karte[k.eltern], tiefe + 1)); }
    var lebend = {}, ids = [];
    reihenfolge.forEach(function (id) { if (!geloeschtOben(karte[id], 0)) { lebend[id] = karte[id]; ids.push(id); } });
    cache = { karte: lebend, ids: ids };
    return cache;
  }

  function art(id) { var k = stand().karte[id]; return k || null; }

  function knoten(id) { return id === WURZEL ? { id: WURZEL, name: 'Alle Fahrzeuge', eltern: null, gruppe: true } : art(id); }

  /* Die Kennung selbst und alle Obergruppen bis zur Wurzel, zuerst die Art selbst. */
  function vorfahren(id) {
    var liste = [], k = knoten(id), schutz = 0;
    while (k && schutz++ < 20) { liste.push(k.id); k = k.eltern ? knoten(k.eltern) : null; }
    return liste;
  }

  function kinder(id) {
    var st = stand();
    return st.ids.map(function (i) { return st.karte[i]; }).filter(function (a) { return a.eltern === id; });
  }

  /* Ist die Art selbst und alles darüber eingeblendet? Nur dann ist sie für neue Fahrzeuge wählbar. */
  function sichtbar(id) {
    return vorfahren(id).every(function (i) { var k = knoten(i); return !k || !k.ausgeblendet; });
  }

  /* Der Baum von oben nach unten, mit Tiefe (Wurzel = 0). Ausgeblendete Arten fehlen samt allem darunter,
     außer mitAusgeblendeten ist gesetzt. */
  function baum(mitAusgeblendeten) {
    var ergebnis = [];
    function gehe(id, tiefe) {
      var k = knoten(id);
      ergebnis.push({ id: k.id, name: k.name, welt: k.welt || null, tiefe: tiefe, gruppe: !!k.gruppe || kinder(k.id).length > 0, waehlbar: !k.gruppe });
      kinder(id).forEach(function (c) { if (mitAusgeblendeten || !c.ausgeblendet) gehe(c.id, tiefe + 1); });
    }
    gehe(WURZEL, 0);
    return ergebnis;
  }

  /* Alle Nachkommen (ohne die Art selbst). */
  function nachkommen(id) {
    var ergebnis = [];
    kinder(id).forEach(function (c) { ergebnis.push(c.id); nachkommen(c.id).forEach(function (n) { ergebnis.push(n); }); });
    return ergebnis;
  }

  /* ---------- Verwalten: anlegen, umbenennen, ausblenden, löschen, bereinigen ---------- */
  function ist(k) { return !!(k && !k.gruppe); }
  function nameFrei(name, elternId, ausser) {
    var n = name.toLowerCase();
    return !kinder(elternId).some(function (c) { return c.id !== ausser && c.name.toLowerCase() === n; });
  }
  function sauber(name) { return String(name == null ? '' : name).replace(/\s+/g, ' ').trim(); }
  function weltKnoten(k) { return !!(k && k.gruppe && k.eltern === WURZEL && !k.eigen); }

  function anlegen(id, name, elternId) {
    var n = sauber(name), fehler = {};
    if (!n) fehler.name = 'Bitte einen Namen eingeben, zum Beispiel „Trimaran“.';
    var eltern = art(elternId);
    if (!eltern) fehler.eltern = 'Bitte wählen, unter welcher Gruppe die Art stehen soll.';
    else if (n && !nameFrei(n, elternId)) fehler.name = 'Unter dieser Gruppe gibt es schon eine Art mit diesem Namen.';
    if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
    eigene.push({ id: id, name: n, eltern: elternId });
    cache = null;
    return { ok: true, id: id };
  }

  function aendern(id, name, ausgeblendet) {
    var k = art(id);
    if (!k || weltKnoten(k)) return { ok: false, fehler: { allgemein: 'Diese Art lässt sich nicht ändern.' } };
    var n = sauber(name);
    if (!n) return { ok: false, fehler: { name: 'Bitte einen Namen eingeben.' } };
    if (!nameFrei(n, k.eltern, id)) return { ok: false, fehler: { name: 'Unter dieser Gruppe gibt es schon eine Art mit diesem Namen.' } };
    var o = ueber[id] = ueber[id] || {};
    var geaendert = false;
    if (n !== k.name) { o.name = n; geaendert = true; }
    var aus = ausgeblendet === true || ausgeblendet === 'ja';
    if (aus !== !!k.ausgeblendet) { o.ausgeblendet = aus; geaendert = true; }
    cache = null;
    return { ok: true, id: id, geaendert: geaendert };
  }

  /* benutzt = Liste der Fahrzeugarten, die ein Fahrzeug hat. */
  function benutztIn(id, benutzt) {
    var gruppe = [id].concat(nachkommen(id));
    return (benutzt || []).some(function (b) { return gruppe.indexOf(b) >= 0; });
  }

  function loeschen(id, benutzt) {
    var k = art(id);
    if (!k || weltKnoten(k)) return { ok: false, fehler: { allgemein: 'Diese Art lässt sich nicht löschen.' } };
    if (benutztIn(id, benutzt)) return { ok: false, fehler: { allgemein: '„' + k.name + '“ wird von einem Fahrzeug benutzt (oder eine Untergruppe davon). Benutzte Arten lassen sich nur ausblenden.' } };
    var namen = [k.name].concat(nachkommen(id).map(function (i) { return art(i).name; }));
    [id].concat(nachkommen(id)).forEach(function (i) { (ueber[i] = ueber[i] || {}).geloescht = true; });
    cache = null;
    return { ok: true, namen: namen };
  }

  /* Was würde „Ungebrauchtes löschen“ treffen? Alles, was weder benutzt ist noch eine benutzte Untergruppe hat. Die Gruppen Land, Wasser, Luft bleiben. */
  function ungebraucht(benutzt) {
    var gebraucht = {};
    (benutzt || []).forEach(function (b) { vorfahren(b).forEach(function (i) { gebraucht[i] = true; }); });
    return baum(true).filter(function (k) { return k.tiefe > 0 && !gebraucht[k.id] && !weltKnoten(art(k.id)); }).map(function (k) { return k.id; });
  }

  function bereinigen(benutzt) {
    var ids = ungebraucht(benutzt), namen = ids.map(function (i) { return art(i).name; });
    ids.forEach(function (i) { (ueber[i] = ueber[i] || {}).geloescht = true; });
    cache = null;
    return { ok: true, anzahl: ids.length, namen: namen };
  }

  /* Gelöschte mitgelieferte Arten wieder holen. Eigene gelöschte Arten kommen nicht zurück. */
  function wiederherstellbar() {
    return ARTEN.filter(function (a) { return ueber[a.id] && ueber[a.id].geloescht; }).map(function (a) { return a.id; });
  }
  function wiederherstellen() {
    var ids = wiederherstellbar();
    ids.forEach(function (i) { delete ueber[i].geloescht; });
    cache = null;
    return { ok: true, anzahl: ids.length };
  }

  /* Die Verwaltungsansicht: alle Arten, auch ausgeblendete, mit Tiefe und Zustand. */
  function verwaltung() {
    return baum(true).filter(function (k) { return k.tiefe > 0; }).map(function (k) {
      var a = art(k.id);
      return { id: k.id, name: k.name, tiefe: k.tiefe - 1, welt: a.welt, eigen: !!a.eigen, fest: weltKnoten(a), ausgeblendet: !!a.ausgeblendet,
        verdeckt: !a.ausgeblendet && !sichtbar(k.id), waehlbar: !a.gruppe, eltern: a.eltern };
    });
  }

  function felder(artId) {
    var a = art(artId);
    if (!a) return [];
    return a.felder.map(function (eintrag) {
      var key = typeof eintrag === 'string' ? eintrag : eintrag.key;
      var f = kopie(FELDER[key]);
      if (typeof eintrag !== 'string') { for (var p in eintrag) { f[p] = eintrag[p]; } }
      f.key = key;
      return f;
    });
  }

  function gruppen(artId) {
    var alle = felder(artId);
    return GRUPPEN.map(function (g) {
      return { id: g.id, titel: g.titel, felder: alle.filter(function (f) { return f.gruppe === g.id; }) };
    }).filter(function (g) { return g.felder.length > 0; });
  }

  MM.Fahrzeugarten = {
    WURZEL: WURZEL,
    /* Alle Arten, die ein Fahrzeug haben kann, in der Reihenfolge des Baums. Ausgeblendete nur auf Wunsch. */
    alle: function (mitAusgeblendeten) { return baum(mitAusgeblendeten).filter(function (k) { return k.waehlbar; }).map(function (k) { return art(k.id); }); },
    baum: baum,
    knoten: knoten,
    vorfahren: vorfahren,
    kinder: kinder,
    nachkommen: nachkommen,
    sichtbar: sichtbar,
    /* Gilt die Art 'id' als Fall von 'gruppeId'? (Art selbst oder eine ihrer Obergruppen) */
    gehoertZu: function (id, gruppeId) { return vorfahren(id).indexOf(gruppeId) >= 0; },
    art: art,
    felder: felder,
    gruppen: gruppen,
    kennungFeld: function (artId) { var a = art(artId); return a ? a.kennung : null; },
    konfigurieren: konfigurieren, dokument: dokument,
    anlegen: anlegen, aendern: aendern, loeschen: loeschen, ungebraucht: ungebraucht, bereinigen: bereinigen,
    wiederherstellbar: wiederherstellbar, wiederherstellen: wiederherstellen, benutztIn: benutztIn, verwaltung: verwaltung
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
