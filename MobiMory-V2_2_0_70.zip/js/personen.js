/*
 * Personen und Tiere: Felder.
 *
 * Person: Name, Funktionen, E-Mail und Telefon (freiwillig). Geburtsdatum,
 * Wohnort und Ausweisdaten gehören nach den Festlegungen NICHT zur Person,
 * sondern zu den Nachweisen und bleiben lokal auf dem Gerät.
 * Tier: Name, Tierart, Chipnummer. Heimtierausweis und Impfungen sind Nachweise.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var FUNKTIONEN = ['Skipper', 'Fahrer', 'Crew', 'Beifahrer', 'Gast'];
  var TIERARTEN = ['Hund', 'Katze', 'Frettchen', 'Vogel', 'Pferd', 'Kleintier', 'Sonstiges'];

  var PERSON_FELDER = [
    { key: 'funktionen', label: 'Funktionen', typ: 'mehrfach', optionen: FUNKTIONEN,
      hilfe: 'Was die Person übernehmen kann. In einer Aktivität wird sie dann zum Beispiel als Skipper oder Crew eingesetzt.' },
    { key: 'email', label: 'E-Mail', typ: 'text', hilfe: 'Freiwillig' },
    { key: 'telefon', label: 'Telefon', typ: 'text', hilfe: 'Freiwillig' },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  var TIER_FELDER = [
    { key: 'tierart', label: 'Tierart', typ: 'auswahl', optionen: TIERARTEN },
    { key: 'chipnummer', label: 'Chipnummer', typ: 'text', hilfe: 'Die Nummer des Mikrochips, meist 15 Ziffern. Freiwillig.' },
    { key: 'notiz', label: 'Notiz', typ: 'text' }
  ];

  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }

  MM.Personen = {
    FUNKTIONEN: FUNKTIONEN, TIERARTEN: TIERARTEN,
    personFelder: function () { return PERSON_FELDER.map(kopie); },
    tierFelder: function () { return TIER_FELDER.map(kopie); }
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
