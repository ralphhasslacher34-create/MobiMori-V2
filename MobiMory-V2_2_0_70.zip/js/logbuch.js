/*
 * Logbuch-Kern: Regeln und Rechnung (Tagesabschnitte, Ereignisse, Prüfung zum Tagesbeginn).
 *
 * Aus den V2-Festlegungen und der Übergabe für 2.0.13:
 *  - Tagesabschnitte sind ein Zusatzbaustein an der Aktivität, kein eigener Bereich.
 *  - Die App bereitet die Tage aus dem Zeitraum der Aktivität vor. Jeder Abschnitt ist von Hand
 *    änderbar, ergänzbar und ausblendbar.
 *  - Die Prüfung zum Tagesbeginn ist die vorhandene Rechnung der Aktivität (aktivitaetPruefung).
 *    Sie wird hier nur je Tag festgehalten, mit „geprüft am“ und dem Verantwortlichen dieses Tages.
 *  - Ereignisarten sind eine offene Liste mit Vorschlägen.
 *  - Ein Wechsel des Verantwortlichen erscheint automatisch als Ereignis. Er bleibt die eine Quelle
 *    in der Tabelle „verantwortung“; eine Korrektur der Uhrzeit bleibt im Verlauf.
 *  - Nachtragen: ein Ereignis mit dem echten Zeitpunkt, markiert als „nachgetragen am …“.
 *  - Nichts wird gelöscht. Änderung = neuer Stand im Verlauf, Ausblenden statt Löschen.
 *  - Ab 2.0.15: Jede Ereignisart gilt für Fahrzeugarten (Baum Alle > Land/Wasser/Luft > Art > Untergruppe).
 *    Gespeichert werden nur die Stellen, an denen ein Häkchen vom darüber abweicht. Eine Untergruppe
 *    übernimmt, was darüber gilt, und der Nutzer kann auf jeder Ebene abwählen oder ergänzen.
 *    Eine Ereignisart ohne Angabe gilt wie bisher für alle.
 *  - Ab 2.0.14: Cockpit (schnelles Eintragen unterwegs) und klassisches Logbuch zeigen dieselben Einträge.
 *    Weicht eine Uhrzeit um mehr als 5 Minuten von „jetzt“ ab, ist das Ereignis ein Nachtrag.
 *    Beim Wechsel des Verantwortlichen wird die Befähigung der übernehmenden Person geprüft und
 *    festgehalten; die App weist nur hin und sperrt nichts.
 *
 * Hier steht nur Rechnung und Beschreibung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var VORSCHLAEGE_EREIGNISARTEN = ['Abfahrt', 'Ankunft', 'Wechsel des Verantwortlichen', 'Störung', 'Notiz'];
  var WECHSEL_ART = 'Wechsel des Verantwortlichen';
  /* Die Ereignisart „Geschwindigkeit“ (seit 2.0.44): schreibt die App selbst (Tagesabschluss und Rhythmus), sie liegt auf keinem Knopf. */
  var GESCHWINDIGKEIT_ART = 'Geschwindigkeit';
  function istGeschwindigkeitsArt(name) { return String(name || '').trim().toLowerCase() === GESCHWINDIGKEIT_ART.toLowerCase(); }
  /* Die Ereignisart, die im Logbuch eine Störung meldet (seit 2.0.26 legt sie den Vorgang in der Werkstatt an). Groß- und Kleinschreibung egal. */
  var STOERUNG_ART = 'Störung';
  function istStoerungArt(name) { return String(name == null ? '' : name).trim().toLowerCase() === STOERUNG_ART.toLowerCase(); }
  var MAX_TAGE = 366;
  var WOCHENTAGE = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];

  /* "2026-12-01" -> Zahl der Tage seit 1970 (ohne Zeitzonen-Probleme). */
  function tagNummer(datum) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(datum || '');
    if (!m) return NaN;
    return Math.round(Date.UTC(+m[1], +m[2] - 1, +m[3]) / 86400000);
  }
  function tagText(nr) {
    var d = new Date(nr * 86400000);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return d.getUTCFullYear() + '-' + z(d.getUTCMonth() + 1) + '-' + z(d.getUTCDate());
  }

  /* Alle Tage von bis (einschließlich). zuLang = mehr als MAX_TAGE Tage; dann kommt keine Liste. */
  function tageImZeitraum(vonDatum, bisDatum) {
    var a = tagNummer(vonDatum), b = tagNummer(bisDatum);
    if (isNaN(a) || isNaN(b) || b < a) return { tage: [], zuLang: false };
    if (b - a + 1 > MAX_TAGE) return { tage: [], zuLang: true };
    var res = [];
    for (var i = a; i <= b; i++) res.push(tagText(i));
    return { tage: res, zuLang: false };
  }

  function wochentag(datum) {
    var n = tagNummer(datum);
    return isNaN(n) ? '' : WOCHENTAGE[new Date(n * 86400000).getUTCDay()];
  }

  /*
   * Welche Tagesabschnitte fehlen noch? Gibt für jeden fehlenden Tag die Werte eines neuen
   * Abschnitts zurück. Am ersten Tag steht die Uhrzeit des Beginns, am letzten die des Endes
   * (nur wenn sie bei der Aktivität eingetragen sind). Tage, für die es schon einen Abschnitt
   * gibt (auch einen ausgeblendeten), werden nicht noch einmal vorbereitet.
   */
  function fehlendeTage(aktivitaet, vorhandeneDaten) {
    var z = tageImZeitraum(aktivitaet.vonDatum, aktivitaet.bisDatum);
    if (z.zuLang) return { zuLang: true, neu: [] };
    var da = {};
    (vorhandeneDaten || []).forEach(function (d) { da[d] = true; });
    var neu = [];
    z.tage.forEach(function (d, i) {
      if (da[d]) return;
      neu.push({
        datum: d,
        beginnZeit: i === 0 ? (aktivitaet.vonZeit || null) : null,
        endeZeit: i === z.tage.length - 1 ? (aktivitaet.bisZeit || null) : null,
        von: null, nach: null, notiz: null, ausgeblendet: 'nein'
      });
    });
    return { zuLang: false, neu: neu };
  }

  function zeitSchluessel(datum, zeit) { return (datum || '') + 'T' + (zeit || '00:00'); }

  /* Abschnitte nach Datum, dann nach Beginn. x.aktuell.werte hat datum und beginnZeit. */
  function abschnitteSortieren(liste) {
    return liste.slice().sort(function (a, b) {
      var ka = zeitSchluessel(a.aktuell.werte.datum, a.aktuell.werte.beginnZeit);
      var kb = zeitSchluessel(b.aktuell.werte.datum, b.aktuell.werte.beginnZeit);
      return ka < kb ? -1 : (ka > kb ? 1 : 0);
    });
  }

  /*
   * In welchen Abschnitt gehört ein Zeitpunkt (nur für automatische Ereignisse)?
   * Der Abschnitt mit demselben Datum, sonst der letzte davor, sonst der erste. Ohne Abschnitte: null.
   */
  function abschnittFuer(abschnitte, datum) {
    var sortiert = abschnitteSortieren(abschnitte);
    if (!sortiert.length) return null;
    var gleich = sortiert.filter(function (x) { return x.aktuell.werte.datum === datum; })[0];
    if (gleich) return gleich;
    var davor = sortiert.filter(function (x) { return x.aktuell.werte.datum < datum; });
    return davor.length ? davor[davor.length - 1] : sortiert[0];
  }

  /*
   * Aus den Einträgen der Verantwortung die Wechsel machen. Der erste Eintrag ist der Beginn
   * und kein Wechsel. Jeder weitere ist ein Wechsel mit Zeitpunkt („ab“, "JJJJ-MM-TTTHH:MM").
   * eintraege: [{ id, personId, name, ab, notiz, ausgeblendet, geaendert }] nach Zeit sortiert.
   */
  function wechselEreignisse(eintraege) {
    var liste = eintraege.slice().sort(function (a, b) { return a.ab < b.ab ? -1 : (a.ab > b.ab ? 1 : 0); });
    return liste.slice(1).map(function (v, i) {
      return {
        art: 'wechsel', verantwortungId: v.id, personId: v.personId, name: v.name,
        vorher: liste[i].name, ab: v.ab, datum: v.ab.slice(0, 10), zeit: v.ab.slice(11, 16),
        notiz: v.notiz || null, ausgeblendet: v.ausgeblendet === 'ja', geaendert: !!v.geaendert,
        nachgetragenAm: v.nachgetragenAm || null, pruefung: v.pruefung || null,
        text: v.name + ' ist ab jetzt verantwortlich' + (liste[i].name ? ' (vorher ' + liste[i].name + ')' : '') + '.'
      };
    });
  }


  /* ---------- 2.0.14: Nachtrag erkennen, Cockpit, Prüfung beim Wechsel, Tagesabschluss ---------- */

  /* Ab so vielen Minuten Abstand zu „jetzt“ gilt ein Ereignis als nachgetragen (wie in V1). */
  var NACHTRAG_MINUTEN = 5;

  /* \"JJJJ-MM-TTTHH:MM\" -> Minuten seit 1970 (ohne Zeitzonen-Probleme). NaN, wenn die Form nicht stimmt. */
  function minutenNummer(zeitpunkt) {
    var m = /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2})$/.exec(zeitpunkt || '');
    if (!m) return NaN;
    return tagNummer(m[1]) * 1440 + (+m[2]) * 60 + (+m[3]);
  }

  /*
   * Wie liegt ein eingegebener Zeitpunkt zu „jetzt“?
   *  'jetzt'     höchstens 5 Minuten Abstand (vorher oder nachher)
   *  'nachtrag'  mehr als 5 Minuten in der Vergangenheit
   *  'zukunft'   mehr als 5 Minuten in der Zukunft
   *  'unklar'    Datum oder Uhrzeit fehlt oder ist ungültig
   */
  function zeitpunktArt(datum, zeit, jetzt) {
    var a = minutenNummer((datum || '') + 'T' + (zeit || '')), b = minutenNummer(jetzt);
    if (isNaN(a) || isNaN(b)) return 'unklar';
    var d = b - a;
    if (d > NACHTRAG_MINUTEN) return 'nachtrag';
    if (d < -NACHTRAG_MINUTEN) return 'zukunft';
    return 'jetzt';
  }

  /*
   * Darf das Cockpit heute etwas eintragen? Ja, wenn die Aktivität nicht storniert ist und der
   * heutige Tag (nach Datum) im Zeitraum der Aktivität liegt. Sonst bleibt das Cockpit stumm und
   * verweist auf das Logbuch (Tag ergänzen, Nachtragen).
   * Rückgabe: { moeglich, grund }  grund: 'storniert' | 'geplant' | 'vorbei' | null
   */
  function cockpitMoeglich(aktivitaetWerte, heute) {
    if (aktivitaetWerte.status === 'storniert') return { moeglich: false, grund: 'storniert' };
    if (heute < aktivitaetWerte.vonDatum) return { moeglich: false, grund: 'geplant' };
    if (heute > aktivitaetWerte.bisDatum) return { moeglich: false, grund: 'vorbei' };
    return { moeglich: true, grund: null };
  }

  /* Welche Arten nutzen die großen Knöpfe? */
  var SCHNELL_ART = { abfahrt: 'Abfahrt', ankunft: 'Ankunft', notiz: 'Notiz' };

  /*
   * Die Prüfung der Befähigung der übernehmenden Person beim Wechsel (aus dem Ergebnis von
   * aktivitaetPruefung). Die App weist nur hin und sperrt nichts. „Nicht erlaubt“ steht nur da,
   * wo die App es sicher weiß (ein Nachweis, der vor dem Ende des Zeitraums abläuft); ein
   * Gebiet, das nicht oder nur als Text eingetragen ist, ergibt höchstens „unklar“.
   * Namen und Texte werden mitgespeichert, spätere Änderungen verändern den damaligen Stand nicht.
   */
  function wechselPruefungFestgehalten(pr, personId) {
    if (!pr) return null;
    var b = pr.befaehigung;
    var meine = b.personen.filter(function (p) { return p.person.id === personId; })[0];
    if (!meine) return null;
    var ergebnis = meine.ergebnis;
    if (b.gebietHinweis && ergebnis === 'erlaubt') ergebnis = 'unklar';
    return {
      geprueftAm: pr.geprueftAm,
      name: meine.person.name, rolleText: meine.rolleText, ergebnis: ergebnis,
      gruende: meine.gruende.map(function (g) { return { ergebnis: g.ergebnis, text: g.text }; }),
      gebietHinweis: b.gebietHinweis || null
    };
  }

  /* Ein Satz zur festgehaltenen Prüfung beim Wechsel. */
  function wechselPruefungKurz(p) {
    if (!p) return null;
    return 'Befähigung von ' + p.name + ': ' + MM.Aktivitaeten.ERGEBNIS[p.ergebnis] + ' (geprüft am ' + p.geprueftAm.slice(8, 10) + '.' + p.geprueftAm.slice(5, 7) + '.' + p.geprueftAm.slice(0, 4) + ', ' + p.geprueftAm.slice(11, 16) + ' Uhr)';
  }

  /* Tagesabschluss: tatsächliches Ziel und Notiz. Gibt es etwas davon? */
  function hatAbschluss(w) { return !!((w.zielTatsaechlich || '') || (w.abschlussNotiz || '')); }


  /* Der sichtbare Tag von heute (der erste, falls es mehrere am selben Datum gibt). abschnitte: wie in logbuchLaden. */
  function heutigerAbschnitt(abschnitte, heute) {
    return abschnitte.filter(function (x) { return !x.ausgeblendet && x.aktuell.werte.datum === heute; })[0] || null;
  }

  /* Die letzten n sichtbaren Ereignisse über alle Tage, das neueste zuerst (für das Cockpit). */
  function letzteEreignisse(abschnitte, n) {
    var alle = [];
    abschnitte.forEach(function (x) {
      if (x.ausgeblendet) return;
      x.ereignisse.forEach(function (e) { if (!e.ausgeblendet) alle.push(Object.assign({ tagId: x.objekt.id, tagDatum: x.aktuell.werte.datum }, e)); });
    });
    alle.sort(function (a, b) { return a.zeitpunkt < b.zeitpunkt ? 1 : (a.zeitpunkt > b.zeitpunkt ? -1 : 0); });
    return alle.slice(0, n);
  }

  /* Zeitpunkt eines Ereignisses zum Sortieren. */
  function ereignisZeit(werte) { return zeitSchluessel(werte.datum, werte.zeit); }

  /* Handeingetragene und automatische Ereignisse in eine Reihenfolge bringen. */
  function ereignisseSortieren(liste) {
    return liste.slice().sort(function (a, b) { return a.zeitpunkt < b.zeitpunkt ? -1 : (a.zeitpunkt > b.zeitpunkt ? 1 : 0); });
  }

  /*
   * Die Prüfung der Aktivität (Ergebnis von aktivitaetPruefung) in eine feste Form bringen,
   * die gespeichert wird. Namen und Texte werden mitgespeichert, weil spätere Änderungen an
   * Personen oder Fahrzeugen den damaligen Stand nicht verändern sollen.
   *  pr            Ergebnis von aktivitaetPruefung
   *  verantwortlich { personId, name } der Verantwortliche zum Tagesbeginn
   *  tagesbeginn   "JJJJ-MM-TTTHH:MM"
   */
  function pruefungFestgehalten(pr, verantwortlich, tagesbeginn) {
    var b = pr.befaehigung;
    var meine = verantwortlich ? b.personen.filter(function (p) { return p.person.id === verantwortlich.personId; })[0] : null;
    var fr = pr.fristen;
    return {
      geprueftAm: pr.geprueftAm,
      tagesbeginn: tagesbeginn,
      verantwortlich: verantwortlich ? { personId: verantwortlich.personId, name: verantwortlich.name, ergebnis: meine ? meine.ergebnis : null } : null,
      befaehigung: {
        ergebnis: b.ergebnis, gebiet: b.gebiet || null, gebietHinweis: b.gebietHinweis || null,
        personen: b.personen.map(function (p) {
          return { name: p.person.name, rolleText: p.rolleText, ergebnis: p.ergebnis,
            gruende: p.gruende.map(function (g) { return { ergebnis: g.ergebnis, text: g.text }; }) };
        })
      },
      ausruestung: pr.ausruestung && pr.ausruestung.liste.length ? {
        ergebnis: pr.ausruestung.ergebnis,
        liste: pr.ausruestung.liste.map(function (x) { return { bezeichnung: x.bezeichnung, status: x.status, text: x.text }; })
      } : null,
      fristen: {
        betroffen: fr.zusammenfassung.betroffen, sperre: fr.zusammenfassung.sperre, eingeschraenkt: fr.zusammenfassung.eingeschraenkt,
        liste: fr.liste.filter(function (f) { return f.status !== 'ok'; }).map(function (f) {
          return { bezeichnung: f.bezeichnung, status: f.status, wirkung: f.wirkung || null, text: f.text };
        }),
        gesamt: fr.liste.length
      }
    };
  }

  /* Ein Satz zur festgehaltenen Prüfung, zum Beispiel für die Tagesliste. */
  function pruefungKurz(p) {
    if (!p) return null;
    var e = MM.Aktivitaeten.ERGEBNIS;
    var teile = ['Befähigung: ' + e[p.befaehigung.ergebnis]];
    if (p.ausruestung) teile.push('Ausrüstung: ' + e[p.ausruestung.ergebnis]);
    teile.push(p.fristen.betroffen ? 'Fristen: ' + p.fristen.betroffen + ' betroffen' : 'Fristen: keine betroffen');
    return teile.join(', ');
  }

  /* ---------- Ereignisarten gelten für Fahrzeugarten (seit 2.0.15) ---------- */

  /* Vorschläge mit Zuordnung. gilt = Liste von Knoten im Baum der Fahrzeugarten. Der Nutzer ändert alles. */
  var ZUSATZ_VORSCHLAEGE = [
    { bezeichnung: 'Tanken', gilt: ['alle'] },
    { bezeichnung: 'Ver- und Entsorgung', gilt: ['alle'] },
    { bezeichnung: 'Wetter', gilt: ['alle'] },
    { bezeichnung: 'Karte', gilt: ['alle'] },
    { bezeichnung: 'Anlegen', gilt: ['wasser'] },
    { bezeichnung: 'Ablegen', gilt: ['wasser'] },
    { bezeichnung: 'Anker werfen', gilt: ['wasser'] },
    { bezeichnung: 'Anker lichten', gilt: ['wasser'] },
    { bezeichnung: 'Schleuse', gilt: ['wasser'] },
    { bezeichnung: 'Segel setzen', gilt: ['segelboot'] },
    { bezeichnung: 'Segel bergen', gilt: ['segelboot'] },
    { bezeichnung: 'Wasserski-Lauf', gilt: ['wasserskiboot'] }
  ];

  /* Bringt eine Zuordnung in die feste Form { knotenId: 'ja' | 'nein' } in Reihenfolge des Baums.
     Leer oder fehlend heißt „gilt für alle“ (so waren alle Ereignisarten vor 2.0.15). */
  function zuordnungNormal(z) {
    /* Auch Angaben an ausgeblendeten Arten bleiben erhalten, nur gelöschte Arten fallen weg. */
    var baum = MM.Fahrzeugarten.baum(true), ergebnis = {};
    if (z && typeof z === 'object' && !Array.isArray(z)) {
      baum.forEach(function (k) { if (z[k.id] === 'ja' || z[k.id] === 'nein') ergebnis[k.id] = z[k.id]; });
    }
    if (!Object.keys(ergebnis).length) ergebnis[MM.Fahrzeugarten.WURZEL] = 'ja';
    if (!ergebnis[MM.Fahrzeugarten.WURZEL]) {
      /* Ohne Angabe an der Wurzel gilt „nein“ für alles, was keine eigene Angabe hat. */
      var neu = {}; neu[MM.Fahrzeugarten.WURZEL] = 'nein';
      Object.keys(ergebnis).forEach(function (k) { neu[k] = ergebnis[k]; });
      ergebnis = neu;
    }
    return ergebnis;
  }

  /* Gilt die Ereignisart für diese Fahrzeugart? Die nächste Angabe von der Art nach oben entscheidet. */
  function ereignisartGilt(zuordnung, artId) {
    var z = zuordnungNormal(zuordnung);
    var weg = MM.Fahrzeugarten.vorfahren(artId);
    for (var i = 0; i < weg.length; i++) { if (z[weg[i]]) return z[weg[i]] === 'ja'; }
    return false;
  }

  /* Die angekreuzten Knoten (alle Ebenen), wie die Ansicht sie zeigt. */
  function auswahlAusZuordnung(zuordnung) {
    var z = zuordnungNormal(zuordnung), wert = {}, ids = [];
    MM.Fahrzeugarten.baum().forEach(function (k) {
      var eltern = MM.Fahrzeugarten.knoten(k.id).eltern;
      wert[k.id] = z[k.id] ? z[k.id] === 'ja' : (eltern ? !!wert[eltern] : false);
      if (wert[k.id]) ids.push(k.id);
    });
    return ids;
  }

  /* Aus den angekreuzten Knoten die kleinste Zuordnung: nur dort eine Angabe, wo das Häkchen vom darüber abweicht. */
  function zuordnungAusAuswahl(ids, bisherige) {
    var an = {}, sichtbar = {}, ergebnis = {}, alt = bisherige ? zuordnungNormal(bisherige) : {};
    (ids || []).forEach(function (i) { an[i] = true; });
    MM.Fahrzeugarten.baum().forEach(function (k) { sichtbar[k.id] = true; });
    MM.Fahrzeugarten.baum(true).forEach(function (k) {
      /* Ausgeblendete Arten zeigt die Ansicht nicht: ihre bisherige Angabe bleibt, wie sie war. */
      if (!sichtbar[k.id]) { if (alt[k.id]) ergebnis[k.id] = alt[k.id]; return; }
      var eltern = MM.Fahrzeugarten.knoten(k.id).eltern;
      if (!eltern) { ergebnis[k.id] = an[k.id] ? 'ja' : 'nein'; return; }
      if (!!an[k.id] !== !!an[eltern]) ergebnis[k.id] = an[k.id] ? 'ja' : 'nein';
    });
    return ergebnis;
  }

  /* Ein Häkchen wird gesetzt oder entfernt: Alles darunter, was bisher genauso stand wie dieser Knoten,
     zieht mit. Bewusst abweichende Arten darunter bleiben, wie sie sind. */
  function auswahlUmschalten(ids, knotenId, an) {
    var set = {};
    (ids || []).forEach(function (i) { set[i] = true; });
    var alt = !!set[knotenId];
    if (alt === !!an) return Object.keys(set);
    function setze(id, v) { if (v) set[id] = true; else delete set[id]; }
    setze(knotenId, an);
    (function runter(id) {
      MM.Fahrzeugarten.kinder(id).forEach(function (c) {
        if (c.ausgeblendet) return;
        if (!!set[c.id] === alt) { setze(c.id, an); runter(c.id); }
      });
    })(knotenId);
    return MM.Fahrzeugarten.baum().filter(function (k) { return set[k.id]; }).map(function (k) { return k.id; });
  }

  /* Ein kurzer Satz für die Liste: „Alle Fahrzeuge“, „Wasserfahrzeug“, „Segelboot außer Segelboot Katamaran“ ... */
  function zuordnungText(zuordnung) {
    var z = zuordnungNormal(zuordnung), wert = {}, teile = [], aussen = [];
    MM.Fahrzeugarten.baum().forEach(function (k) {
      var eltern = MM.Fahrzeugarten.knoten(k.id).eltern;
      var vorher = eltern ? !!wert[eltern] : false;
      wert[k.id] = z[k.id] ? z[k.id] === 'ja' : vorher;
      if (wert[k.id] && !vorher) teile.push(k.id === MM.Fahrzeugarten.WURZEL ? 'Alle Fahrzeuge' : k.name);
      if (!wert[k.id] && vorher) aussen.push(k.name);
    });
    if (!teile.length) return 'Keine Fahrzeugart';
    return teile.join(', ') + (aussen.length ? ' außer ' + aussen.join(', ') : '');
  }

  /* Zuordnung für eine Vorschlags-Art: nur die genannten Knoten (und alles darunter) gelten. */
  function zuordnungFuerKnoten(knoten) {
    var z = {}; z[MM.Fahrzeugarten.WURZEL] = 'nein';
    knoten.forEach(function (k) { z[k] = 'ja'; });
    return zuordnungNormal(z);
  }

  /* ---------- Schnellknöpfe im Cockpit (seit 2.0.18) ----------
   * Bis zu 15 frei belegbare Knöpfe je Fahrzeugart (bis 2.0.19: 8), dazu fest „Sonstige Ereignisse“.
   * Wie viele davon ein Gerät zeigt, stellt der Nutzer je Gerät ein (seit 2.0.20, Vorgabe 8): Das Gerät zeigt die
   * ersten so vielen Knöpfe, die übrigen liegen unter „Sonstige Ereignisse“ und gehen nicht verloren.
   * Gespeichert wird je Knoten im Baum der Fahrzeugarten eine Liste von Schlüsseln:
   *   'e:<Kennung einer Ereignisart>' oder 'f:notiz' | 'f:foto' | 'f:wechsel' (Funktionen).
   * Ein Knoten ohne eigene Liste übernimmt die Liste der nächsten Obergruppe, sonst gilt der Standard. */
  var MAX_SCHNELL = 15;
  var SCHNELL_GERAET_STANDARD = 8;
  var SCHNELL_FUNKTIONEN = [
    { id: 'notiz', name: 'Notiz' }, { id: 'foto', name: 'Foto' }, { id: 'wechsel', name: 'Verantwortung wechseln' }
  ];
  /* Der Standard: Abfahrt, Ankunft, Notiz, Foto, Verantwortung wechseln (Cockpit bis 2.0.17), seit 2.0.35 dazu Wetter und Karte. */
  var SCHNELL_STANDARD = ['Abfahrt', 'Ankunft', 'f:notiz', 'f:foto', 'f:wechsel', 'Wetter', 'Karte', 'Ver- und Entsorgung'];

  /* Was zu einer Fahrzeugart angeboten wird. ereignisarten: Liste wie ereignisartenListe() (objekt.id, aktuell.werte).
     Ohne ausgeblendete, ohne den Wechsel (der ist eine Funktion), ohne die Art „Notiz“ (auch eine Funktion) und ohne „Geschwindigkeit“ (schreibt die App selbst). */
  function schnellAngebot(ereignisarten, fahrzeugartId) {
    var ereignisse = (ereignisarten || []).filter(function (x) {
      var w = x.aktuell.werte, n = String(w.bezeichnung).toLowerCase();
      return w.ausgeblendet !== 'ja' && w.bezeichnung !== WECHSEL_ART && n !== 'notiz' && !istGeschwindigkeitsArt(w.bezeichnung)
        && (!fahrzeugartId || ereignisartGilt(w.zuordnung, fahrzeugartId));
    }).map(function (x) { return { key: 'e:' + x.objekt.id, typ: 'ereignis', id: x.objekt.id, name: x.aktuell.werte.bezeichnung, aktion: MM.Aktionen ? MM.Aktionen.normal(x.aktuell.werte.aktion) : '',
      /* Baukasten (seit 2.0.50): Fragen oder Wirkungen nach Wo und Wann. Ohne das Modul gilt das alte Feld „aktion“. */
      ablauf: MM.Baukasten ? MM.Baukasten.hatAblauf(x.aktuell.werte) : !!(MM.Aktionen && MM.Aktionen.normal(x.aktuell.werte.aktion)) }; });
    var funktionen = SCHNELL_FUNKTIONEN.map(function (f) { return { key: 'f:' + f.id, typ: 'funktion', id: f.id, name: f.name }; });
    return { ereignisse: ereignisse, funktionen: funktionen, alle: ereignisse.concat(funktionen) };
  }

  /* Die Liste, die für eine Fahrzeugart gilt: { keys, von, eigene }. keys = null heißt Standard.
     von = Knoten, dessen Liste gilt (null beim Standard); eigene = die Art selbst hat eine Liste. */
  function schnellBelegung(dokument, fahrzeugartId) {
    var bel = (dokument && dokument.belegung) || {};
    var weg = MM.Fahrzeugarten.vorfahren(fahrzeugartId);
    for (var i = 0; i < weg.length; i++) {
      if (Array.isArray(bel[weg[i]])) return { keys: bel[weg[i]].slice(), von: weg[i], eigene: i === 0 };
    }
    return { keys: null, von: null, eigene: false };
  }

  /* Aus den Schlüsseln die Knöpfe in der Reihenfolge der Liste. Was es nicht (mehr) gibt oder nicht zur Fahrzeugart
     passt, fällt weg. Beim Standard werden Abfahrt und Ankunft über den Namen gefunden. */
  function schnellKnoepfe(belegung, angebot) {
    var keys = belegung.keys;
    if (!keys) {
      keys = SCHNELL_STANDARD.map(function (k) {
        if (k.slice(0, 2) === 'f:') return k;
        var art = angebot.ereignisse.filter(function (e) { return e.name.toLowerCase() === k.toLowerCase(); })[0];
        return art ? art.key : null;
      }).filter(Boolean);
    }
    var gesehen = {}, liste = [];
    keys.forEach(function (k) {
      var x = angebot.alle.filter(function (a) { return a.key === k; })[0];
      if (x && !gesehen[k] && liste.length < MAX_SCHNELL) { gesehen[k] = true; liste.push(x); }
    });
    return liste;
  }

  /* Höchstzahl der Knöpfe auf einem Gerät: ganze Zahl von 0 bis MAX_SCHNELL. Null bei allem anderen. */
  function geraetKnoepfeGueltig(wert) {
    if (wert === null || wert === undefined || wert === '') return null;
    var n = Number(wert);
    if (!isFinite(n) || Math.floor(n) !== n || n < 0 || n > MAX_SCHNELL) return null;
    return n;
  }

  /* Die Seiten des Cockpits (seit 2.0.61): 1 Info, 2 Knöpfe, 3 unterer Bereich (Motoren, Zähler, Tagesabschluss …). Weitere kommen später. */
  var COCKPIT_SEITEN = 3;
  /* Eine gespeicherte Seite (0-basiert) oder null, wenn es sie nicht gibt. */
  function cockpitSeiteGueltig(wert) {
    if (wert === null || wert === undefined || wert === '') return null;
    var n = Number(wert);
    if (!isFinite(n) || Math.floor(n) !== n || n < 0 || n >= COCKPIT_SEITEN) return null;
    return n;
  }

  /* Die Knöpfe, die dieses Gerät zeigt: die ersten „max“ der Belegung (Reihenfolge bleibt). */
  function schnellAufGeraet(knoepfe, max) {
    var n = geraetKnoepfeGueltig(max);
    if (n === null) n = SCHNELL_GERAET_STANDARD;
    return (knoepfe || []).slice(0, n);
  }

  /* Alles, was nicht auf einem Knopf liegt: das steht unter „Sonstige Ereignisse“. */
  function schnellSonstige(knoepfe, angebot) {
    var auf = {}; knoepfe.forEach(function (k) { auf[k.key] = true; });
    return {
      ereignisse: angebot.ereignisse.filter(function (x) { return !auf[x.key]; }),
      funktionen: angebot.funktionen.filter(function (x) { return !auf[x.key]; })
    };
  }

  /* Neues Dokument mit der Liste für diese Fahrzeugart (keys = Schlüssel in der Reihenfolge der Knöpfe). */
  function schnellDokumentSetzen(dokument, fahrzeugartId, keys) {
    var neu = { id: 'schnellknoepfe', belegung: Object.assign({}, (dokument && dokument.belegung) || {}) };
    neu.belegung[fahrzeugartId] = keys.slice();
    return neu;
  }
  function schnellDokumentZuruecksetzen(dokument, fahrzeugartId) {
    var neu = { id: 'schnellknoepfe', belegung: Object.assign({}, (dokument && dokument.belegung) || {}) };
    delete neu.belegung[fahrzeugartId];
    return neu;
  }

  /* ---------- Position bei Ereignissen (seit 2.0.21) ----------
   * Jedes Ereignis kann eine Position tragen: Breite und Länge als Dezimalgrad, dazu die Herkunft (GPS oder von Hand)
   * und freiwillig einen Ortsnamen. GPS ist nie Voraussetzung: Ohne Position wird trotzdem sofort gespeichert.
   * Die App lernt Ortsnamen: Ein Name, den der Nutzer zu einer Position eingibt oder bestätigt, wird mit dieser Position
   * gemerkt. Liegt eine spätere Position im Umfeld (POSITION_RADIUS_M), schlägt die App den Namen vor. Es kommt nicht auf den Meter an.
   * Hier steht nur Rechnung und Beschreibung, kein Speichern. */
  var POSITION_RADIUS_M = 500;
  var POSITION_MAX_NAMEN = 500;
  var GPS_FRISCH_MS = 120000;

  function positionRunden(x) { return Math.round(x * 1e6) / 1e6; }

  /* Eine Koordinate lesen: Dezimalgrad mit Komma oder Punkt; Süd und West mit Minuszeichen oder mit S und W (Ost auch O).
     art: 'breite' oder 'laenge'. Ergebnis: { leer: true } | { wert } | { fehler } */
  function koordinateLesen(roh, art) {
    var max = art === 'breite' ? 90 : 180;
    var name = art === 'breite' ? 'Breite' : 'Länge';
    if (roh === null || roh === undefined) return { leer: true };
    var zahl;
    if (typeof roh === 'number') {
      zahl = roh;
      if (!isFinite(zahl)) return { fehler: 'Bitte die ' + name + ' als Zahl eingeben, zum Beispiel ' + (art === 'breite' ? '48,8566' : '2,3522') + '.' };
    } else {
      var t = String(roh).replace(/°/g, ' ').replace(/\s+/g, ' ').trim();
      if (!t) return { leer: true };
      var m = /^([A-Za-z])? ?(-?\d{1,3}(?:[.,]\d+)?) ?([A-Za-z])?$/.exec(t);
      var erlaubt = art === 'breite' ? 'NS' : 'OEW';
      var buchstabe = m ? (m[1] || m[3] || '') : '';
      if (m && m[1] && m[3]) m = null;
      if (!m || (buchstabe && erlaubt.indexOf(buchstabe.toUpperCase()) < 0)) {
        return { fehler: 'Bitte die ' + name + ' als Dezimalgrad eingeben, zum Beispiel ' + (art === 'breite' ? '48,8566' : '2,3522') + '. ' +
          (art === 'breite' ? 'Süd mit Minuszeichen oder S.' : 'West mit Minuszeichen oder W.') };
      }
      zahl = Number(m[2].replace(',', '.'));
      var b = buchstabe.toUpperCase();
      if (b && zahl < 0) return { fehler: 'Bitte entweder ein Minuszeichen oder den Buchstaben nehmen, nicht beides.' };
      if (b === 'S' || b === 'W') zahl = -zahl;
    }
    if (Math.abs(zahl) > max) return { fehler: 'Die ' + name + ' liegt zwischen -' + max + ' und ' + max + '.' };
    return { wert: positionRunden(zahl) };
  }

  /*
   * Position und Ortsname aus den Eingaben eines Ereignisses.
   *  roh: { breite, laenge, ortName, ortNameQuelle, gpsBreite, gpsLaenge, gpsGenauigkeit }
   *  gpsBreite, gpsLaenge: die Werte, die das GPS geliefert hat. Sind breite und laenge noch genau diese, kommt die Position
   *  vom GPS, sonst von Hand (Handeingabe hat Vorrang). ortNameQuelle 'vorschlag': Der Name kam von der App und nicht vom Nutzer.
   * Ergebnis: { werte, fehler }. Breite und Länge gehören zusammen: nur eine von beiden ist ein Fehler.
   */
  function positionPruefen(roh) {
    roh = roh || {};
    var fehler = {};
    var w = { breite: null, laenge: null, positionQuelle: null, positionGenauigkeit: null, ortName: null, ortNameQuelle: null };
    var b = koordinateLesen(roh.breite, 'breite'), l = koordinateLesen(roh.laenge, 'laenge');
    if (b.fehler) fehler.breite = b.fehler;
    if (l.fehler) fehler.laenge = l.fehler;
    if (!b.fehler && !l.fehler) {
      if (b.leer && !l.leer) fehler.breite = 'Bitte auch die Breite eingeben. Breite und Länge gehören zusammen.';
      else if (l.leer && !b.leer) fehler.laenge = 'Bitte auch die Länge eingeben. Breite und Länge gehören zusammen.';
      else if (!b.leer) {
        w.breite = b.wert; w.laenge = l.wert;
        var gb = koordinateLesen(roh.gpsBreite, 'breite'), gl = koordinateLesen(roh.gpsLaenge, 'laenge');
        var vomGps = gb.wert !== undefined && gl.wert !== undefined && gb.wert === w.breite && gl.wert === w.laenge;
        w.positionQuelle = vomGps ? 'gps' : 'hand';
        var gen = roh.gpsGenauigkeit === null || roh.gpsGenauigkeit === undefined || roh.gpsGenauigkeit === '' ? NaN : Number(roh.gpsGenauigkeit);
        w.positionGenauigkeit = vomGps && isFinite(gen) && gen >= 0 ? Math.round(gen) : null;
      }
    }
    var name = String(roh.ortName === null || roh.ortName === undefined ? '' : roh.ortName).replace(/\s+/g, ' ').trim();
    if (name.length > 80) fehler.ortName = 'Der Ortsname darf höchstens 80 Zeichen haben.';
    else if (name) { w.ortName = name; w.ortNameQuelle = roh.ortNameQuelle === 'vorschlag' ? 'vorschlag' : 'hand'; }
    return { werte: w, fehler: fehler };
  }

  /* „48,85660° N, 2,35220° O“ */
  function positionText(breite, laenge) {
    if (typeof breite !== 'number' || typeof laenge !== 'number') return '';
    function teil(x, plus, minus) { return Math.abs(x).toFixed(5).replace('.', ',') + '° ' + (x >= 0 ? plus : minus); }
    return teil(breite, 'N', 'S') + ', ' + teil(laenge, 'O', 'W');
  }

  /* Abstand zweier Positionen in Metern (Haversine) */
  function entfernungMeter(b1, l1, b2, l2) {
    var R = 6371000, rad = Math.PI / 180;
    var db = (b2 - b1) * rad, dl = (l2 - l1) * rad;
    var a = Math.sin(db / 2) * Math.sin(db / 2) + Math.cos(b1 * rad) * Math.cos(b2 * rad) * Math.sin(dl / 2) * Math.sin(dl / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
  }

  function entfernungText(m) {
    return m < 1000 ? Math.round(m) + ' m' : (m / 1000).toFixed(1).replace('.', ',') + ' km';
  }

  /* Eine GPS-Position gilt nur, wenn sie frisch ist (höchstens GPS_FRISCH_MS alt). fix: { breite, laenge, genauigkeit, zeitMs } */
  function gpsFrisch(fix, jetztMs) {
    if (!fix || typeof fix.breite !== 'number' || typeof fix.laenge !== 'number' || typeof fix.zeitMs !== 'number') return null;
    return jetztMs - fix.zeitMs <= GPS_FRISCH_MS && jetztMs - fix.zeitMs >= -5000 ? fix : null;
  }

  /* Der nächste bekannte Name im Umfeld, oder null. punkte: [{ name, breite, laenge, n, zuletzt }] */
  function ortSuchen(punkte, breite, laenge, radius) {
    var grenze = radius === undefined ? POSITION_RADIUS_M : radius, beste = null;
    (punkte || []).forEach(function (p) {
      var d = entfernungMeter(breite, laenge, p.breite, p.laenge);
      if (d > grenze) return;
      if (!beste || d < beste.genau - 1e-9 || (Math.abs(d - beste.genau) <= 1e-9 && String(p.zuletzt || '') > String(beste.punkt.zuletzt || ''))) beste = { name: p.name, abstand: Math.round(d), genau: d, punkt: p };
    });
    return beste ? { name: beste.name, abstand: beste.abstand } : null;
  }

  /* Neues Dokument „positionsnamen“: Ein Name, der im Umfeld schon so heißt, zählt hoch, sonst kommt ein neuer Punkt dazu. */
  function ortLernen(dok, name, breite, laenge, jetzt) {
    var punkte = ((dok && dok.punkte) || []).map(function (p) { return Object.assign({}, p); });
    var n = String(name).trim().toLowerCase();
    var gleich = punkte.filter(function (p) { return String(p.name).toLowerCase() === n && entfernungMeter(breite, laenge, p.breite, p.laenge) <= POSITION_RADIUS_M; })[0];
    if (gleich) { gleich.n = (gleich.n || 1) + 1; gleich.zuletzt = jetzt; }
    else punkte.push({ name: String(name).trim(), breite: breite, laenge: laenge, n: 1, zuletzt: jetzt });
    if (punkte.length > POSITION_MAX_NAMEN) {
      punkte.sort(function (a, b) { return String(b.zuletzt || '') < String(a.zuletzt || '') ? -1 : 1; });
      punkte = punkte.slice(0, POSITION_MAX_NAMEN);
    }
    return { id: 'positionsnamen', punkte: punkte };
  }

  MM.Logbuch = {
    COCKPIT_SEITEN: COCKPIT_SEITEN, cockpitSeiteGueltig: cockpitSeiteGueltig,
    MAX_SCHNELL: MAX_SCHNELL, SCHNELL_GERAET_STANDARD: SCHNELL_GERAET_STANDARD, geraetKnoepfeGueltig: geraetKnoepfeGueltig, schnellAufGeraet: schnellAufGeraet,
    SCHNELL_FUNKTIONEN: SCHNELL_FUNKTIONEN, schnellAngebot: schnellAngebot, schnellBelegung: schnellBelegung,
    schnellKnoepfe: schnellKnoepfe, schnellSonstige: schnellSonstige, schnellDokumentSetzen: schnellDokumentSetzen, schnellDokumentZuruecksetzen: schnellDokumentZuruecksetzen,
    VORSCHLAEGE_EREIGNISARTEN: VORSCHLAEGE_EREIGNISARTEN, WECHSEL_ART: WECHSEL_ART, GESCHWINDIGKEIT_ART: GESCHWINDIGKEIT_ART, istGeschwindigkeitsArt: istGeschwindigkeitsArt, STOERUNG_ART: STOERUNG_ART, istStoerungArt: istStoerungArt, MAX_TAGE: MAX_TAGE,
    tageImZeitraum: tageImZeitraum, wochentag: wochentag, fehlendeTage: fehlendeTage,
    abschnitteSortieren: abschnitteSortieren, abschnittFuer: abschnittFuer,
    wechselEreignisse: wechselEreignisse, ereignisZeit: ereignisZeit, ereignisseSortieren: ereignisseSortieren,
    pruefungFestgehalten: pruefungFestgehalten, pruefungKurz: pruefungKurz,
    NACHTRAG_MINUTEN: NACHTRAG_MINUTEN, SCHNELL_ART: SCHNELL_ART, minutenNummer: minutenNummer, zeitpunktArt: zeitpunktArt,
    cockpitMoeglich: cockpitMoeglich, wechselPruefungFestgehalten: wechselPruefungFestgehalten, wechselPruefungKurz: wechselPruefungKurz, hatAbschluss: hatAbschluss,
    heutigerAbschnitt: heutigerAbschnitt, letzteEreignisse: letzteEreignisse,
    ZUSATZ_VORSCHLAEGE: ZUSATZ_VORSCHLAEGE, zuordnungNormal: zuordnungNormal, ereignisartGilt: ereignisartGilt,
    auswahlAusZuordnung: auswahlAusZuordnung, zuordnungAusAuswahl: zuordnungAusAuswahl, auswahlUmschalten: auswahlUmschalten,
    zuordnungFuerKnoten: zuordnungFuerKnoten, zuordnungText: zuordnungText,
    POSITION_RADIUS_M: POSITION_RADIUS_M, GPS_FRISCH_MS: GPS_FRISCH_MS, koordinateLesen: koordinateLesen, positionPruefen: positionPruefen, positionText: positionText,
    entfernungMeter: entfernungMeter, entfernungText: entfernungText, gpsFrisch: gpsFrisch, ortSuchen: ortSuchen, ortLernen: ortLernen
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
