/*
 * Status des Fahrzeugs und Regeln der Ereignisse (seit 2.0.23).
 *
 * Das Fahrzeug hat immer einen Status. Jedes Ereignis kann den Status wechseln, und was erlaubt ist,
 * hängt nur vom aktuellen Status ab (Festlegung des Nutzers, 04.11.2026):
 *   Landfahrzeug:    Stillstand -> Abfahrt -> In Fahrt -> Ankunft -> Stillstand
 *   Wasserfahrzeug:  Festgemacht -> Ablegen -> In Fahrt;  In Fahrt -> Anlegen -> Festgemacht;
 *                    In Fahrt -> Anker werfen -> Vor Anker;  Vor Anker -> Anker lichten -> In Fahrt
 * Jede Ereignisart hat dazu zwei Angaben: „gilt im Status …“ und „danach Status …“. Die Regel hängt an der Art,
 * nicht am Namen. Die sechs bekannten Namen haben eine Starthilfe (STANDARD), der Nutzer kann sie je Art ändern.
 * Alles hier ist reine Rechnung ohne Speicher und ohne Oberfläche.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var STATUS = {
    land: [{ id: 'stillstand', name: 'Stillstand' }, { id: 'in-fahrt', name: 'In Fahrt' }],
    wasser: [{ id: 'festgemacht', name: 'Festgemacht' }, { id: 'in-fahrt', name: 'In Fahrt' }, { id: 'vor-anker', name: 'Vor Anker' }]
  };
  /* Beim allerersten Mal ist der Status unbekannt. Dann gilt der Anfangsstatus: Es ist der Knopf frei, der den Anfang macht. */
  var ANFANG = { land: 'stillstand', wasser: 'festgemacht' };
  /* Für Luftfahrzeuge gibt es keine Status. Es wird nichts gesperrt. */

  /* Alle Status, die es irgendwo gibt (für die Einstellseite einer Art). */
  var ALLE = [
    { id: 'stillstand', name: 'Stillstand (Landfahrzeug)' },
    { id: 'festgemacht', name: 'Festgemacht (Wasserfahrzeug)' },
    { id: 'in-fahrt', name: 'In Fahrt' },
    { id: 'vor-anker', name: 'Vor Anker (Wasserfahrzeug)' }
  ];

  /* Starthilfe nach dem Namen der Art (Groß- und Kleinschreibung egal). */
  var STANDARD = {
    'abfahrt': { gilt: ['stillstand'], danach: 'in-fahrt' },
    'ankunft': { gilt: ['in-fahrt'], danach: 'stillstand' },
    'ablegen': { gilt: ['festgemacht'], danach: 'in-fahrt' },
    'anlegen': { gilt: ['in-fahrt'], danach: 'festgemacht' },
    'anker werfen': { gilt: ['in-fahrt'], danach: 'vor-anker' },
    'anker lichten': { gilt: ['vor-anker'], danach: 'in-fahrt' }
  };

  /* „danach“ = KEINE heißt: Diese Art ändert den Status nicht und wird nie gesperrt (Notiz, Foto, Tanken …). */
  var KEINE = 'keine';

  function klein(name) { return String(name || '').trim().toLowerCase(); }
  function statusListe(welt) { return STATUS[welt] ? STATUS[welt].slice() : []; }
  function statusIds(welt) { return statusListe(welt).map(function (s) { return s.id; }); }
  function hatStatus(welt) { return !!STATUS[welt]; }
  function statusName(welt, id) {
    var s = statusListe(welt).filter(function (x) { return x.id === id; })[0] || ALLE.filter(function (x) { return x.id === id; })[0];
    return s ? s.name.replace(/ \(.*\)$/, '') : '';
  }
  function istStatus(id) { return ALLE.some(function (s) { return s.id === id; }); }

  /* „in-fahrt,vor-anker“ -> ['in-fahrt','vor-anker'] (nur bekannte, ohne Doppelte) */
  function listeLesen(wert) {
    var teile = Array.isArray(wert) ? wert : String(wert || '').split(',');
    var aus = [];
    teile.forEach(function (t) { t = String(t).trim(); if (t && istStatus(t) && aus.indexOf(t) < 0) aus.push(t); });
    return aus;
  }

  /*
   * Die Eingabe des Nutzers prüfen. roh: { giltImStatus (Liste oder Text), danachStatus (Text) }
   * Ergebnis: { ok, werte: { giltImStatus: 'a,b' | '', danachStatus: 'x' | '' }, fehler: { giltImStatus?, danachStatus? } }
   * Beides leer = Starthilfe nach dem Namen. „keine“ = ohne Wirkung. Sonst müssen beide Angaben stimmen.
   */
  function regelNormal(roh) {
    roh = roh || {};
    var danach = String(roh.danachStatus === undefined || roh.danachStatus === null ? '' : roh.danachStatus).trim();
    var gilt = listeLesen(roh.giltImStatus);
    var fehler = {};
    if (!danach) {
      if (gilt.length) fehler.danachStatus = 'Bitte wählen, in welchen Status das Ereignis das Fahrzeug bringt.';
      return Object.keys(fehler).length ? { ok: false, fehler: fehler } : { ok: true, werte: { giltImStatus: '', danachStatus: '' } };
    }
    if (danach === KEINE) return { ok: true, werte: { giltImStatus: '', danachStatus: KEINE } };
    if (!istStatus(danach)) fehler.danachStatus = 'Diesen Status gibt es nicht.';
    if (!gilt.length) fehler.giltImStatus = 'Bitte wählen, in welchem Status das Ereignis möglich ist.';
    if (Object.keys(fehler).length) return { ok: false, fehler: fehler };
    return { ok: true, werte: { giltImStatus: gilt.join(','), danachStatus: danach } };
  }

  /*
   * Die Regel einer Art für ein Fahrzeug der Welt „welt“.
   *  artWerte: die Werte der Ereignisart (bezeichnung, giltImStatus, danachStatus) oder nur { bezeichnung }
   * Ergebnis: { gilt: [ids], danach: id, quelle: 'eigene'|'standard' } oder null, wenn die Art den Status nicht betrifft.
   * Eine Regel gilt nur, wenn alle ihre Status bei dieser Welt vorkommen. Sonst ist sie für dieses Fahrzeug ohne Wirkung
   * (zum Beispiel eine „Abfahrt“ bei einem Boot).
   */
  function regelFuer(artWerte, welt) {
    if (!hatStatus(welt) || !artWerte) return null;
    var r = null;
    var danach = String(artWerte.danachStatus || '').trim();
    if (danach === KEINE) return null;
    if (danach) {
      var gilt = listeLesen(artWerte.giltImStatus);
      if (gilt.length && istStatus(danach)) r = { gilt: gilt, danach: danach, quelle: 'eigene' };
    } else if (STANDARD[klein(artWerte.bezeichnung)]) {
      var s = STANDARD[klein(artWerte.bezeichnung)];
      r = { gilt: s.gilt.slice(), danach: s.danach, quelle: 'standard' };
    }
    if (!r) return null;
    var ids = statusIds(welt);
    if (ids.indexOf(r.danach) < 0 || r.gilt.some(function (g) { return ids.indexOf(g) < 0; })) return null;
    return r;
  }

  /* „JJJJ-MM-TTTHH:MM“ (Ortszeit) -> Millisekunden, oder null */
  function ortszeitMs(text) {
    var m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(text || '');
    if (!m) return null;
    return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], 0, 0).getTime();
  }

  /*
   * Den Status aus den Ereignissen rechnen (nach Uhrzeit, nicht nach der Reihenfolge des Eintippens).
   *  ereignisse: [{ id?, artName, zeitpunkt „JJJJ-MM-TTTHH:MM“, ausgeblendet? }]
   *  artenNachName: { 'abfahrt': artWerte, ... } (Schlüssel klein) oder eine Funktion name -> artWerte
   *  welt, jetztLokal
   * Ausgeblendete Ereignisse und Ereignisse in der Zukunft zählen nicht. Das letzte Ereignis mit einer Regel gewinnt.
   * Ergebnis: { welt, status (Kennung oder null, wenn noch keins mit Regel da war), name, seit (Zeitpunkt), durch (Name der Art),
   *            unbekannt: true, wenn noch kein Ereignis mit Regel da war, dann gilt der Anfangsstatus (wirksam) }
   */
  function rechnen(ereignisse, artenNachName, welt, jetztLokal) {
    var jetztMs = ortszeitMs(jetztLokal);
    var aus = { welt: welt, status: null, name: '', seit: null, durch: null, unbekannt: true, wirksam: hatStatus(welt) ? ANFANG[welt] : null };
    if (!hatStatus(welt)) return aus;
    var suche = typeof artenNachName === 'function' ? artenNachName : function (n) { return (artenNachName || {})[klein(n)] || { bezeichnung: n }; };
    var liste = (ereignisse || []).filter(function (e) {
      if (!e || e.ausgeblendet || !e.zeitpunkt) return false;
      var ms = ortszeitMs(e.zeitpunkt);
      return ms !== null && (jetztMs === null || ms <= jetztMs);
    }).map(function (e, i) { return { e: e, i: i, ms: ortszeitMs(e.zeitpunkt) }; });
    /* Gleiche Minute: Es zählt die Reihenfolge des Eintippens (erstelltAm), sonst die Reihenfolge der Liste. */
    liste.sort(function (a, b) {
      if (a.ms !== b.ms) return a.ms - b.ms;
      var ea = a.e.erstelltAm || '', eb = b.e.erstelltAm || '';
      if (ea !== eb) return ea < eb ? -1 : 1;
      return a.i - b.i;
    });
    liste.forEach(function (x) {
      var r = regelFuer(suche(x.e.artName) || { bezeichnung: x.e.artName }, welt);
      if (!r) return;
      aus.status = r.danach; aus.seit = x.e.zeitpunkt; aus.durch = x.e.artName; aus.unbekannt = false;
    });
    if (aus.status) { aus.wirksam = aus.status; aus.name = statusName(welt, aus.status); }
    else aus.name = statusName(welt, aus.wirksam);
    return aus;
  }

  /*
   * Darf dieses Ereignis jetzt eingetragen werden?
   *  regel: regelFuer(...) oder null; stand: Ergebnis von rechnen; alleRegeln: [{ name, regel }] aller Arten, die für das Fahrzeug gelten
   * Ergebnis: { erlaubt: true } oder { erlaubt: false, grund: 'erst Ablegen', statusName: 'In Fahrt' }
   * Ohne Regel ist immer alles erlaubt.
   */
  function pruefen(regel, stand, alleRegeln) {
    if (!regel) return { erlaubt: true };
    var jetzt = stand && stand.wirksam;
    if (!jetzt || regel.gilt.indexOf(jetzt) >= 0) return { erlaubt: true };
    var kanten = (alleRegeln || []).filter(function (x) { return x.regel; });
    /* Kürzester Weg vom jetzigen Status zu einem Status, in dem das Ereignis möglich ist (Breitensuche über die Regeln). */
    var besucht = {}; besucht[jetzt] = true;
    var front = [{ status: jetzt, weg: [] }], weg = null;
    while (front.length && !weg) {
      var naechste = [];
      for (var i = 0; i < front.length && !weg; i++) {
        var f = front[i];
        for (var k = 0; k < kanten.length; k++) {
          var e = kanten[k];
          if (e.regel.gilt.indexOf(f.status) < 0) continue;
          var ziel = e.regel.danach;
          var w2 = f.weg.concat([e.name]);
          if (regel.gilt.indexOf(ziel) >= 0) {
            if (f.weg.length === 0) {
              /* Ein Schritt genügt: alle Möglichkeiten nennen. */
              weg = kanten.filter(function (y) { return y.regel.gilt.indexOf(jetzt) >= 0 && regel.gilt.indexOf(y.regel.danach) >= 0; })
                .map(function (y) { return y.name; }).filter(function (n, j, arr) { return arr.indexOf(n) === j; });
              weg = { oder: weg };
            } else weg = { dann: w2 };
            break;
          }
          if (!besucht[ziel]) { besucht[ziel] = true; naechste.push({ status: ziel, weg: w2 }); }
        }
      }
      front = naechste;
    }
    var grund = 'jetzt nicht möglich';
    if (weg && weg.oder) grund = 'erst ' + weg.oder.join(' oder ');
    else if (weg && weg.dann) grund = 'erst ' + weg.dann.join(', dann ');
    return { erlaubt: false, statusName: stand.name, grund: grund };
  }

  global.MM.Status = {
    STATUS: STATUS, ANFANG: ANFANG, ALLE: ALLE, STANDARD: STANDARD, KEINE: KEINE,
    statusListe: statusListe, statusIds: statusIds, hatStatus: hatStatus, statusName: statusName, istStatus: istStatus,
    listeLesen: listeLesen, regelNormal: regelNormal, regelFuer: regelFuer, rechnen: rechnen, pruefen: pruefen
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
