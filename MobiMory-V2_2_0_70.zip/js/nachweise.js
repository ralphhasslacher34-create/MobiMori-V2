/*
 * Nachweise: Regeln.
 *
 * Eine Nachweisart beschreibt, WAS für ein Nachweis es ist (Führerschein,
 * Heimtierausweis, Zulassungsbescheinigung, ...) und welche Angaben er hat.
 * Die Liste der Arten ist offen. Der Nutzer legt eigene an oder übernimmt
 * Vorschläge aus nachweis-vorschlaege.js.
 *
 * Ein Nachweis gehört zu einer Person, einem Tier oder einem Fahrzeug, hat
 * eine Art und die Angaben dieser Art. Er nennt seine Herkunft (von Hand,
 * später gescannt).
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var VORWARN_TAGE = 30;

  var BESITZER = [{ wert: 'person', label: 'Person' }, { wert: 'tier', label: 'Tier' }, { wert: 'fahrzeug', label: 'Fahrzeug' }];
  var JA_NEIN = [{ wert: 'ja', label: 'Ja' }, { wert: 'nein', label: 'Nein' }];
  var FELDTYPEN = [{ wert: 'text', label: 'Text' }, { wert: 'datum', label: 'Datum' }, { wert: 'zahl', label: 'Zahl' }];

  /* Die Angaben, die jeder Nachweis haben kann. Eine Art darf sie umbenennen oder weglassen. */
  var GEMEINSAM = [
    { key: 'nummer', label: 'Nummer', typ: 'text' },
    { key: 'aussteller', label: 'Aussteller', typ: 'text' },
    { key: 'ausgestelltAm', label: 'Ausgestellt am', typ: 'datum' },
    { key: 'gueltigBis', label: 'Gültig bis', typ: 'datum' },
    { key: 'klassen', label: 'Klassen oder Stufen', typ: 'text' }
  ];

  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }

  /*
   * Alle Felder eines Nachweises dieser Art, in der Reihenfolge der Anzeige.
   * art = die Angaben (werte) der Nachweisart.
   */
  function felderFuer(art) {
    var ohne = art.ohne || [];
    var gem = art.gemeinsam || {};
    var liste = [];
    GEMEINSAM.forEach(function (g) {
      if (ohne.indexOf(g.key) >= 0) return;
      if (g.key === 'gueltigBis' && art.hatAblauf !== 'ja' && art.hatAblauf !== true) return;
      var f = kopie(g);
      var o = gem[g.key];
      if (o && o.label) f.label = o.label;
      if (o && o.papier) f.papier = o.papier;
      liste.push(f);
    });
    (art.felder || []).forEach(function (z) {
      var f = { key: z.key, label: z.label, typ: z.typ || 'text', zusatz: true };
      if (z.papier) f.papier = z.papier;
      liste.push(f);
    });
    liste.push({ key: 'notiz', label: 'Notiz', typ: 'text' });
    return liste;
  }

  function hatAblauf(art) { return art.hatAblauf === 'ja' || art.hatAblauf === true; }

  /* Datum "JJJJ-MM-TT" plus Tage zwischen zwei Daten. */
  function tageZwischen(a, b) { return MM.Fristen.tageZwischen(a, b); }

  /*
   * Gültigkeit eines Nachweises zum Stichtag "heute".
   *  gueltig, bald (innerhalb der Vorwarnzeit), abgelaufen, unbefristet, unbekannt (Datum fehlt)
   */
  function status(art, werte, heute) {
    if (!hatAblauf(art)) return { status: 'unbefristet' };
    if (!werte.gueltigBis) return { status: 'unbekannt' };
    var tage = tageZwischen(heute, werte.gueltigBis);
    if (tage === null) return { status: 'unbekannt' };
    if (tage < 0) return { status: 'abgelaufen', tage: tage };
    if (tage <= VORWARN_TAGE) return { status: 'bald', tage: tage };
    return { status: 'gueltig', tage: tage };
  }

  var RANG = { abgelaufen: 3, bald: 2, unbekannt: 1, gueltig: 0, unbefristet: 0 };
  function rang(s) { return RANG[s] === undefined ? 0 : RANG[s]; }

  /* Gilt der Nachweis bis zum Ende eines Zeitraums? (Grundlage für die spätere Prüfung bei Aktivitäten.) */
  function gueltigBisZum(art, werte, endDatum) {
    if (!hatAblauf(art)) return true;
    if (!werte.gueltigBis) return null;
    return werte.gueltigBis >= endDatum;
  }

  MM.Nachweise = {
    VORWARN_TAGE: VORWARN_TAGE, BESITZER: BESITZER, JA_NEIN: JA_NEIN, FELDTYPEN: FELDTYPEN, GEMEINSAM: GEMEINSAM,
    felderFuer: felderFuer, hatAblauf: hatAblauf, status: status, rang: rang, gueltigBisZum: gueltigBisZum,
    besitzerLabel: function (wert) { for (var i = 0; i < BESITZER.length; i++) { if (BESITZER[i].wert === wert) return BESITZER[i].label; } return ''; }
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
