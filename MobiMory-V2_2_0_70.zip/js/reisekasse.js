/*
 * Reisekasse, Schritt 8c: Beschreibung und Rechnung. Hier steht kein Speichern.
 *
 * Festlegungen aus dem Gespräch vom 04.11.2026:
 *  - Auf Reisen entstehen auch Kosten, die nicht das Fahrzeug betreffen: Einkäufe, Essen gehen, Souvenirs, Eintritte.
 *    Sie gehören in die Gruppe „Reisekasse“ und hängen an der Aktivität, nicht am Fahrzeug.
 *  - „Bar“ wird zur Kasse mit Stand: Anfangsbestand, Einzahlungen (Umbuchung, keine Ausgabe), Ausgaben, Kassensturz.
 *    Stimmt der Stand nicht mit dem Geld im Portemonnaie, speichert die App die Differenz als eigenen Eintrag.
 *  - Jede Währung hat ihre eigene Kasse. Die Euro-Kasse ist die Voreinstellung.
 *  - Der Kurs kommt ohne Internet aus den Einzahlungen: „100 € = 1.150 NOK“. Die Kasse merkt sich den Durchschnittskurs.
 *    Ein Betrag, den die App so umrechnet, ist als „gerechnet“ gekennzeichnet, ein nachgetragener Euro-Betrag ist „eingegeben“.
 *  - Am Ende der Reise: Fahrzeug und Reisekasse getrennt, Gesamtsumme, der Fixkosten-Anteil als eigene Zeile zum Ein- und
 *    Ausschalten, pro Tag und pro Person, nach Zahlungsmittel.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var BAR = 'bar'; /* feste Kennung des Zahlungsmittels „Bar“, das zur Kasse gehört */

  var WAEHRUNGEN = [
    { wert: 'EUR', label: 'Euro (EUR)' },
    { wert: 'NOK', label: 'Norwegische Krone (NOK)' },
    { wert: 'SEK', label: 'Schwedische Krone (SEK)' },
    { wert: 'DKK', label: 'Dänische Krone (DKK)' },
    { wert: 'ISK', label: 'Isländische Krone (ISK)' },
    { wert: 'CHF', label: 'Schweizer Franken (CHF)' },
    { wert: 'GBP', label: 'Britisches Pfund (GBP)' },
    { wert: 'PLN', label: 'Polnischer Zloty (PLN)' },
    { wert: 'CZK', label: 'Tschechische Krone (CZK)' },
    { wert: 'HUF', label: 'Ungarischer Forint (HUF)' },
    { wert: 'RON', label: 'Rumänischer Leu (RON)' },
    { wert: 'TRY', label: 'Türkische Lira (TRY)' },
    { wert: 'USD', label: 'US-Dollar (USD)' }
  ];

  var BUCHUNGSARTEN = [
    { wert: 'anfang', label: 'Anfangsbestand' },
    { wert: 'einzahlung', label: 'Einzahlung' },
    { wert: 'differenz', label: 'Differenz' }
  ];

  function runde(n) { return Math.round(n * 100) / 100; }
  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }
  function zahl(v) { var n = Number(v); return isFinite(n) ? n : 0; }

  /* Ein Währungskürzel: drei Buchstaben, groß geschrieben. Gibt null, wenn es keines ist. */
  function waehrungNormal(text) {
    var t = String(text == null ? '' : text).trim().toUpperCase();
    return /^[A-Z]{3}$/.test(t) ? t : null;
  }
  function waehrungLabel(code) {
    var w = WAEHRUNGEN.filter(function (x) { return x.wert === code; })[0];
    return w ? w.label : (code || '');
  }
  function buchungsartLabel(wert) {
    var a = BUCHUNGSARTEN.filter(function (x) { return x.wert === wert; })[0];
    return a ? a.label : wert;
  }

  /* Eine Zahl mit Komma, zum Beispiel 11,5 oder 1.150 (Tausenderpunkt nur bei großen Zahlen). */
  function zahlText(n, stellen) {
    var s = Number(n).toFixed(stellen == null ? 2 : stellen).split('.');
    s[0] = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return s.join(',');
  }

  /* Kasseneinstellung einer Währung für die Kennung. Die Kasse einer Aktivität in einer Währung gibt es höchstens einmal. */
  function kasseId(aktivitaetId, waehrung) { return 'ka-' + aktivitaetId + '-' + waehrung; }

  /*
   * Die Rechnung einer Kasse.
   *  p.waehrung   Kürzel der Kasse
   *  p.buchungen  [{ werte }]  Anfangsbestand, Einzahlungen, Differenzen (ohne ausgeblendete rechnet die Funktion selbst weg)
   *  p.ausgaben   [{ werte }]  Posten, die bar aus dieser Kasse bezahlt wurden (Gruppe egal, ohne ausgeblendete)
   * Ergebnis: anfang, einzahlungen, differenz, ausgaben (in der Währung der Kasse), stand, euroEingezahlt, kurs, ausgabenEuro.
   * kurs = { euroProEinheit, einheitenProEuro } (null, wenn kein Euro-Wert bei Anfangsbestand oder Einzahlung steht; bei EUR 1 zu 1).
   */
  function rechnen(p) {
    var w = p.waehrung, euro = w === 'EUR';
    var anfang = 0, ein = 0, diff = 0, eurosIn = 0, einheitenIn = 0, anzahlBuchungen = 0;
    (p.buchungen || []).forEach(function (b) {
      var x = b.werte;
      if (!x || x.ausgeblendet === 'ja') return;
      var betrag = zahl(x.betrag);
      anzahlBuchungen++;
      if (x.art === 'anfang') anfang += betrag;
      else if (x.art === 'einzahlung') ein += betrag;
      else if (x.art === 'differenz') diff += betrag;
      if (x.art === 'anfang' || x.art === 'einzahlung') {
        if (euro) { eurosIn += betrag; einheitenIn += betrag; }
        else if (zahl(x.euro) > 0 && betrag > 0) { eurosIn += zahl(x.euro); einheitenIn += betrag; }
      }
    });
    var aus = 0, ausEuro = 0, anzahl = 0;
    (p.ausgaben || []).forEach(function (a) {
      var x = a.werte;
      if (!x || x.ausgeblendet === 'ja') return;
      aus += euro ? zahl(x.betrag) : zahl(x.betragWaehrung);
      ausEuro += zahl(x.betrag);
      anzahl++;
    });
    var kurs = null;
    if (euro) kurs = { euroProEinheit: 1, einheitenProEuro: 1 };
    else if (einheitenIn > 0 && eurosIn > 0) kurs = { euroProEinheit: eurosIn / einheitenIn, einheitenProEuro: einheitenIn / eurosIn };
    return {
      waehrung: w, anfang: runde(anfang), einzahlungen: runde(ein), differenz: runde(diff), ausgaben: runde(aus),
      stand: runde(anfang + ein + diff - aus), euroEingezahlt: runde(eurosIn), ausgabenEuro: runde(ausEuro), anzahlAusgaben: anzahl,
      anzahlBuchungen: anzahlBuchungen, kurs: kurs
    };
  }

  /* Euro-Betrag eines Betrags in Fremdwährung mit dem Durchschnittskurs der Kasse. Null, wenn kein Kurs da ist. */
  function euroAus(betragWaehrung, kurs) {
    if (!kurs || !(kurs.euroProEinheit > 0)) return null;
    var e = runde(zahl(betragWaehrung) * kurs.euroProEinheit);
    return e > 0 ? e : 0.01; /* ein winziger Betrag wird nie zu 0, sonst fiele er aus der Auswertung */
  }

  /* Was zeigt die Kasse beim Kassensturz an Unterschied? ist = der Betrag, der wirklich im Portemonnaie liegt. */
  function kassensturzDifferenz(rechnung, ist) { return runde(zahl(ist) - rechnung.stand); }

  /* „1 € = 11,50 NOK“ */
  function kursText(waehrung, kurs) {
    if (!kurs) return null;
    if (waehrung === 'EUR') return null;
    return '1 € = ' + zahlText(kurs.einheitenProEuro, kurs.einheitenProEuro >= 100 ? 1 : 2) + ' ' + waehrung;
  }

  /* ---------- Reisetage und Fixkosten-Anteil ---------- */
  function tagNummer(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
    return m ? Math.round(Date.UTC(+m[1], +m[2] - 1, +m[3]) / 86400000) : NaN;
  }
  function jahresTage(jahr) { return ((jahr % 4 === 0 && jahr % 100 !== 0) || jahr % 400 === 0) ? 366 : 365; }

  /* Tage der Reise, der erste und der letzte mitgezählt. Ohne Ende ein Tag, ohne Beginn null. */
  function reiseTage(von, bis) {
    if (!von || isNaN(tagNummer(von))) return null;
    var b = bis && !isNaN(tagNummer(bis)) ? bis : von;
    var t = tagNummer(b) - tagNummer(von) + 1;
    return t > 0 ? t : 1;
  }

  /*
   * Anteil der Fixkosten des Fahrzeugs an der Reise: Fixkosten des Jahres mal Reisetage durch Tage des Jahres, für jedes Jahr, das die
   * Reise berührt. fixPosten: [{ werte }] die sichtbaren Fixkosten des Fahrzeugs. Gibt { summe, tage, anzahlPosten, jahre }.
   */
  function fixAnteil(fixPosten, von, bis, heute) {
    var tage = reiseTage(von, bis);
    var leer = { summe: 0, tage: tage || 0, anzahlPosten: 0, jahre: [] };
    if (!tage) return leer;
    var b = bis && !isNaN(tagNummer(bis)) ? bis : von;
    var summe = 0, jahre = [], gezaehlt = {};
    for (var j = +von.slice(0, 4); j <= +b.slice(0, 4); j++) {
      var a = Math.max(tagNummer(von), tagNummer(j + '-01-01')), e = Math.min(tagNummer(b), tagNummer(j + '-12-31'));
      var d = e - a + 1;
      if (d <= 0) continue;
      var jahressumme = 0;
      (fixPosten || []).forEach(function (p, i) {
        var x = MM.Kosten.imJahr(p.werte, j, heute);
        if (x.summe > 0) { jahressumme += x.summe; gezaehlt[i] = true; }
      });
      jahre.push({ jahr: j, tage: d, jahressumme: runde(jahressumme) });
      summe += jahressumme * d / jahresTage(j);
    }
    return { summe: runde(summe), tage: tage, anzahlPosten: Object.keys(gezaehlt).length, jahre: jahre };
  }

  /* ---------- Auswertung der Reise ---------- */
  function nachArt(liste) {
    var m = {}, reihe = [];
    liste.forEach(function (w) {
      var k = w.kostenart || '';
      if (!m[k]) { m[k] = { art: k || null, summe: 0, anzahl: 0 }; reihe.push(k); }
      m[k].summe += zahl(w.betrag); m[k].anzahl++;
    });
    return reihe.map(function (k) { m[k].summe = runde(m[k].summe); return m[k]; }).sort(function (a, b) { return b.summe - a.summe; });
  }

  /*
   * p.kosten        [{ werte }]  alle Posten der Aktivität (ausgeblendete und Posten ohne Betrag werden hier weggelassen)
   * p.von, p.bis    Zeitraum der Aktivität
   * p.personen      Zahl der Personen in der Besatzung (0 = unbekannt)
   * p.fixPosten     [{ werte }]  die sichtbaren Fixkosten des Fahrzeugs
   * p.fixEin        true: Fixkosten-Anteil in der Gesamtsumme (Voreinstellung)
   * p.zahlungsmittel  { kennung: Bezeichnung }
   * p.heute
   * Die Posten zählen mit dem Euro-Betrag (`betrag`). Die Gruppe „Reisekasse“ steht getrennt von allem, was das Fahrzeug betrifft.
   */
  function reiseGesamt(p) {
    var k = (p.kosten || []).filter(function (x) { return x.werte.ausgeblendet !== 'ja' && zahl(x.werte.betrag) > 0; }).map(function (x) { return x.werte; });
    var kasse = k.filter(function (w) { return w.gruppe === 'reisekasse'; });
    var fz = k.filter(function (w) { return w.gruppe !== 'reisekasse'; });
    function summe(l) { var s = 0; l.forEach(function (w) { s += zahl(w.betrag); }); return runde(s); }
    function block(l) { return { summe: summe(l), anzahl: l.length, nachArt: nachArt(l), grundlage: MM.Kosten.grundlageVon(l.map(function (w) { return w.grundlage; })) }; }
    var fix = fixAnteil(p.fixPosten, p.von, p.bis, p.heute);
    var fixEin = p.fixEin !== false && fix.summe > 0;
    var vSeite = block(fz), rSeite = block(kasse);
    var ohneFix = runde(vSeite.summe + rSeite.summe);
    var gesamt = runde(ohneFix + (fixEin ? fix.summe : 0));
    var tage = reiseTage(p.von, p.bis);
    var personen = p.personen > 0 ? p.personen : 0;

    var zm = {}, zmReihe = [];
    k.forEach(function (w) {
      var id = w.bezahltMit || '';
      if (!zm[id]) { zm[id] = { id: id || null, label: id ? ((p.zahlungsmittel || {})[id] || (id === BAR ? 'Bar' : 'unbekannt')) : 'ohne Angabe', summe: 0, anzahl: 0 }; zmReihe.push(id); }
      zm[id].summe += zahl(w.betrag); zm[id].anzahl++;
    });
    var nachZahlung = zmReihe.map(function (id) { zm[id].summe = runde(zm[id].summe); return zm[id]; }).sort(function (a, b) { return b.summe - a.summe; });

    return {
      fahrzeug: vSeite, reisekasse: rSeite,
      fixAnteil: { summe: fix.summe, tage: fix.tage, anzahlPosten: fix.anzahlPosten, jahre: fix.jahre, eingerechnet: fixEin, grundlage: fix.summe > 0 ? 'gerechnet' : null },
      ohneFix: ohneFix, gesamt: gesamt, gesamtGrundlage: gesamt > 0 ? 'gerechnet' : null,
      tage: tage, personen: personen,
      proTag: tage && gesamt > 0 ? runde(gesamt / tage) : null,
      proPerson: personen && gesamt > 0 ? runde(gesamt / personen) : null,
      proTagPerson: tage && personen && gesamt > 0 ? runde(gesamt / tage / personen) : null,
      nachZahlungsmittel: nachZahlung
    };
  }

  /* Felder der Buchung in die Kasse (Anfangsbestand und Einzahlung). Bei Fremdwährung gehört der Euro-Betrag dazu. */
  function buchungsFelder(art, waehrung) {
    var f = [{ key: 'betrag', label: art === 'anfang' ? 'Anfangsbestand' : 'Eingezahlter Betrag', typ: 'zahl', einheit: waehrung }];
    if (waehrung !== 'EUR') f.push({ key: 'euro', label: 'Dafür bezahlt (Euro)', typ: 'zahl', einheit: '€',
      hilfe: 'Wie viel Euro du dafür bezahlt hast, zum Beispiel 100 € für 1.150 NOK. Daraus rechnet die App den Kurs.' });
    f.push({ key: 'datum', label: 'Datum', typ: 'datum' });
    f.push({ key: 'notiz', label: 'Notiz', typ: 'text' });
    return f.map(kopie);
  }

  MM.Reisekasse = {
    BAR: BAR, WAEHRUNGEN: WAEHRUNGEN, BUCHUNGSARTEN: BUCHUNGSARTEN,
    waehrungNormal: waehrungNormal, waehrungLabel: waehrungLabel, buchungsartLabel: buchungsartLabel, zahlText: zahlText, kasseId: kasseId,
    rechnen: rechnen, euroAus: euroAus, kassensturzDifferenz: kassensturzDifferenz, kursText: kursText,
    reiseTage: reiseTage, jahresTage: jahresTage, fixAnteil: fixAnteil, reiseGesamt: reiseGesamt, buchungsFelder: buchungsFelder, runde: runde
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
