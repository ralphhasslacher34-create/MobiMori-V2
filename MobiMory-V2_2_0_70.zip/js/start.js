/* Start: Speicher öffnen, Daten starten, erste Seite zeigen. */
(function (global) {
  'use strict';
  var MM = global.MM;
  var el = global.document.getElementById('app');

  new MM.Speicher.IdbSpeicher().oeffnen()
    .then(function (speicher) {
      var daten = new MM.Daten.Daten(speicher);
      return daten.starten().then(function () { return MM.Ansicht.starten(daten, el); });
    })
    .catch(function (err) { MM.Ansicht.fehler(el, err); });

  /* Die Daten sollen auf dem Gerät bleiben, auch wenn der Speicher knapp wird. */
  if (global.navigator.storage && global.navigator.storage.persist) {
    global.navigator.storage.persist().catch(function () {});
  }

  /* Offline-Betrieb: nur über https oder localhost möglich. */
  if ('serviceWorker' in global.navigator && /^https?:$/.test(global.location.protocol)) {
    var hatteVersion = !!global.navigator.serviceWorker.controller;
    global.addEventListener('load', function () {
      global.navigator.serviceWorker.register('sw.js', { updateViaCache: 'none' }).catch(function () {});
    });
    /* Übernimmt eine neue Version das Steuer, wird angeboten, neu zu laden.
       Beim allerersten Besuch gibt es nichts anzubieten. */
    global.navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (!hatteVersion || global.document.querySelector('.update-hinweis')) return;
      var d = global.document;
      var box = d.createElement('div');
      box.className = 'update-hinweis';
      box.setAttribute('role', 'status');
      var t = d.createElement('span');
      t.textContent = 'Eine neue Version von MobiMory ist bereit.';
      var b = d.createElement('button');
      b.type = 'button'; b.className = 'knopf'; b.textContent = 'Jetzt neu laden';
      b.addEventListener('click', function () { global.location.reload(); });
      box.appendChild(t); box.appendChild(b);
      d.body.appendChild(box);
    });
  }
})(window);
