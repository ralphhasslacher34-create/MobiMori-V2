/*
 * Ortssuche (seit 2.0.39): Der Nutzer gibt einen Ort ein, die App prüft ihn und liefert die Treffer.
 *
 *  - Gibt es den Namen mehrfach, bleibt es eine Auswahlliste (Beispiel: Eutingen bei Herrenberg oder bei Pforzheim).
 *  - Aus dem gewählten Treffer entsteht die Kette Land > Region > Kreis (oder Département).
 *  - Gesucht wird erst auf Knopfdruck, nie bei jedem Buchstaben, und nur der eingegebene Ortsname geht hinaus.
 *  - Ohne Netz oder ohne Treffer bleibt der Ort ungeprüft. Das Gebiet ist dann „unklar“, gesperrt wird nichts.
 *
 * Quelle: OpenStreetMap-Suchdienst Nominatim (https://nominatim.openstreetmap.org). Sein Dienst ist für wenige,
 * einzelne Anfragen gedacht. Für die Veröffentlichung in einem App-Store braucht es einen eigenen Suchdienst
 * oder einen Anbieter mit passenden Bedingungen (wie bei den Kartenkacheln in js/karte.js).
 *
 * Das Netz wird von außen übergeben (holeJson), damit die Tests ohne Netz laufen.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var DIENST = 'https://nominatim.openstreetmap.org/search';

  function text(v) { return String(v == null ? '' : v).replace(/\s+/g, ' ').trim(); }

  function anfrageUrl(suche) {
    return DIENST + '?format=jsonv2&addressdetails=1&limit=10&accept-language=de&q=' + encodeURIComponent(text(suche));
  }

  /* Der Name des Ortes selbst: der eigene Name des Treffers, sonst die Ortschaft aus der Adresse. */
  function ortsname(item, a) {
    return text(item.name) || text(a.city || a.town || a.village || a.hamlet || a.municipality || a.suburb || a.city_district);
  }

  function zahl(v) { var n = Number(v); return isFinite(n) ? n : null; }
  function runden(n) { return Math.round(n * 100000) / 100000; }

  /* Aus der Antwort der Suche die Treffer: { schluessel, name, label, land, landCode, region, kreis, gemeinde, breite, laenge }. */
  function kandidaten(antwort) {
    var liste = Array.isArray(antwort) ? antwort : [];
    var gesehen = {}, aus = [];
    liste.forEach(function (item) {
      if (!item || typeof item !== 'object') return;
      var a = item.address || {};
      var land = text(a.country), name = ortsname(item, a);
      var breite = zahl(item.lat), laenge = zahl(item.lon);
      if (!name || !land || breite === null || laenge === null) return;
      var region = text(a.state) || null;
      var kreis = text(a.county || a.state_district) || null;
      if (kreis && region && kreis.toLowerCase() === region.toLowerCase()) kreis = null;
      /* Die Gemeinde hilft beim Unterscheiden, wenn der Name mehrfach vorkommt (nur wenn sie anders heißt als der Ort). */
      var gemeinde = text(a.municipality || a.city || a.town || a.village) || null;
      if (gemeinde && gemeinde.toLowerCase() === name.toLowerCase()) gemeinde = null;
      var teile = [name, gemeinde, kreis, region, land].filter(Boolean);
      var label = teile.join(', ');
      var k = { schluessel: text(item.osm_type) + text(item.osm_id), name: name, label: label, land: land, landCode: text(a.country_code).toUpperCase() || null,
        region: region, kreis: kreis, gemeinde: gemeinde, breite: runden(breite), laenge: runden(laenge) };
      if (gesehen[label]) return;
      gesehen[label] = true; aus.push(k);
    });
    return aus;
  }

  /* Die Kette Land > Region > Kreis eines Treffers: [{ ebene, name, code }]. Fehlende Ebenen entfallen. */
  function kette(k) {
    var weg = [{ ebene: 'land', name: k.land, code: k.landCode || null }];
    if (k.region) weg.push({ ebene: 'region', name: k.region });
    if (k.kreis) weg.push({ ebene: 'kreis', name: k.kreis });
    return weg;
  }

  /*
   * Sucht den Ort. Ergebnis: { ok: true, kandidaten: [...] } oder { ok: false, grund, text }
   *  grund: 'zukurz' | 'leer' (kein Treffer) | 'netz' (kein Netz oder Dienst antwortet nicht)
   */
  function suchen(suche, holeJson) {
    var s = text(suche);
    if (s.length < 2) return Promise.resolve({ ok: false, grund: 'zukurz', text: 'Bitte mindestens zwei Buchstaben des Ortsnamens eingeben.' });
    return Promise.resolve().then(function () { return holeJson(anfrageUrl(s)); }).then(function (antwort) {
      var k = kandidaten(antwort);
      if (!k.length) return { ok: false, grund: 'leer', text: 'Zu „' + s + '“ hat die Suche keinen Ort gefunden. Prüfe die Schreibweise oder lege den Ort ohne Prüfung an.' };
      return { ok: true, kandidaten: k };
    }, function () {
      return { ok: false, grund: 'netz', text: 'Die Ortssuche braucht Netz und ist gerade nicht erreichbar. Du kannst den Ort ohne Prüfung anlegen. Das Gebiet bleibt dann unklar, und die Prüfung kann später nachgeholt werden.' };
    });
  }

  MM.Ortssuche = { DIENST: DIENST, anfrageUrl: anfrageUrl, kandidaten: kandidaten, kette: kette, suchen: suchen };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
