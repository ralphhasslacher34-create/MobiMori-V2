/* Aktionen für Ereignis-Knöpfe, der Baukasten (seit 2.0.47). Nur Regeln, kein Speicher und kein Netz.
 * Ein Knopf hält immer zuerst Wo und Wann fest. Danach kann seine Ereignisart eine Aktion auslösen (Feld „aktion“ an der Art).
 * Ohne Aktion bleibt der Knopf wie bisher. Welche Aktionen es gibt, steht nur in der Liste REGISTER unten:
 * Eine neue Aktion kommt als eine weitere Zeile dazu (oder mit MM.Aktionen.registrieren), der Aufbau ändert sich nicht.
 * Eintrag: { id, name, hilfe, seite, fragen, wirkungen }  seite = welche Eingabe die Aktion nach dem Antippen zeigt (siehe cockpitAktionSeite in ansicht.js).
 *
 * Seit 2.0.50 gehen die Aktionen im Baukasten-Gerüst auf (js/baukasten.js): Jede Aktion ist nur noch eine fertige Zusammenstellung aus
 * Fragen und Wirkungen (Muster Festhalten, Fragen, Wirkungen). Eine Art, die nur das alte Feld „aktion“ hat, behält ihr Verhalten:
 * MM.Baukasten.zusammenstellung liest „fragen“ und „wirkungen“ aus dieser Liste. */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var REGISTER = [
    { id: 'text', name: 'Textfeld öffnen', hilfe: 'Nach dem Antippen öffnet sich ein Textfeld. Der Text kommt zum Eintrag.', seite: 'text', fragen: ['text'], wirkungen: [] },
    { id: 'foto', name: 'Foto aufnehmen oder wählen', hilfe: 'Nach dem Antippen kannst du die Kamera öffnen oder ein vorhandenes Bild wählen. Das Foto kommt zum Eintrag.', seite: 'foto', fragen: ['foto'], wirkungen: [] },
    { id: 'navi', name: 'Navigations-App des Geräts öffnen', hilfe: 'Nach dem Antippen gibst du das Ziel ein. Die App übergibt nur das Ziel, das Gerät entscheidet, welche Navigations-App öffnet.', seite: 'navi', fragen: ['ziel'], wirkungen: ['navi'] }
  ];

  function kopie(a) { return Object.assign({}, a, { fragen: (a.fragen || []).slice(), wirkungen: (a.wirkungen || []).slice() }); }
  function liste() { return REGISTER.map(kopie); }
  function art(id) {
    var s = String(id === undefined || id === null ? '' : id);
    var a = REGISTER.filter(function (x) { return x.id === s; })[0];
    return a ? kopie(a) : null;
  }
  /* Eine bekannte Kennung bleibt, alles andere (auch „keine“) ist ''. */
  function normal(id) { var a = art(id); return a ? a.id : ''; }
  function name(id) { var a = art(id); return a ? a.name : ''; }

  /* Später kommen weitere Aktionen dazu, ohne dass sich der Aufbau ändert. Eine vorhandene Kennung wird nicht überschrieben. */
  function registrieren(a) {
    if (!a || !a.id || !a.name || art(a.id)) return false;
    REGISTER.push({ id: String(a.id), name: String(a.name), hilfe: a.hilfe || '', seite: a.seite || String(a.id),
      fragen: Array.isArray(a.fragen) ? a.fragen.map(String) : [], wirkungen: Array.isArray(a.wirkungen) ? a.wirkungen.map(String) : [] });
    return true;
  }

  /* Die Übergabe an die Navigations-App: nur das Ziel, das Gerät entscheidet.
   * Android: geo-Adresse, das Gerät zeigt die Auswahl der Navigations-Apps. Apple: Karten-Adresse. Sonst: Karten-Seite im Browser.
   * Das Verhalten darf auf Android und Apple verschieden sein (Festlegung des Nutzers vom 08.11.2026). */
  function naviLink(ziel, geraetText) {
    var z = String(ziel === undefined || ziel === null ? '' : ziel).trim();
    if (!z) return null;
    var q = encodeURIComponent(z), g = String(geraetText || '');
    if (/iPhone|iPad|iPod/i.test(g)) return 'https://maps.apple.com/?daddr=' + q;
    if (/Android/i.test(g)) return 'geo:0,0?q=' + q;
    return 'https://www.google.com/maps/dir/?api=1&destination=' + q;
  }

  MM.Aktionen = { liste: liste, art: art, normal: normal, name: name, registrieren: registrieren, naviLink: naviLink };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
