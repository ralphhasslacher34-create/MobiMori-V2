/*
 * Fristen: Regeln und Rechnung.
 *
 * Aus den V2-Festlegungen:
 *  - Jede Frist hat bis zu zwei Kriterien. Was zuerst eintritt, löst die
 *    Fälligkeit aus: ein Zähler (Strecke oder Betriebsstunden, vom Nutzer
 *    pro Frist gewählt) und/oder ein Kalender (Monate oder Jahre).
 *  - Jede Frist hat eine Wirkung bei Überfälligkeit: nur warnen,
 *    eingeschränkt oder Sperre. Dazu kommt eine Vorwarnzeit.
 *
 * Hier steht nur Rechnung und Beschreibung, kein Speichern.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var KATEGORIEN = [{ wert: 'wartung', label: 'Wartung' }, { wert: 'pruefung', label: 'Prüfung' }];
  var WIRKUNGEN = [
    { wert: 'warnen', label: 'Nur warnen' },
    { wert: 'eingeschraenkt', label: 'Eingeschränkt' },
    { wert: 'sperre', label: 'Sperre' }
  ];
  var EINHEITEN = [{ wert: 'monate', label: 'Monate' }, { wert: 'jahre', label: 'Jahre' }];
  var ZAEHLERARTEN = [
    { wert: 'strecke', label: 'Strecke (km)', einheit: 'km', standard: 'Kilometerstand' },
    { wert: 'stunden', label: 'Betriebsstunden (h)', einheit: 'h', standard: 'Betriebsstunden' }
  ];

  /* Felder einer Frist, als Daten beschrieben (wie bei Fahrzeugen und Komponenten). */
  var FELDER = [
    { key: 'kategorie', label: 'Art der Frist', typ: 'auswahl', optionen: KATEGORIEN, gruppe: 'frist' },
    { key: 'kalenderWert', label: 'Nach wie viel Zeit', typ: 'ganzzahl', min: 1, max: 600, gruppe: 'kalender',
      hilfe: 'Zum Beispiel 12 Monate oder 2 Jahre. Leer lassen, wenn es keine Zeitgrenze gibt.' },
    { key: 'kalenderEinheit', label: 'Einheit', typ: 'auswahl', optionen: EINHEITEN, gruppe: 'kalender' },
    { key: 'zaehlerId', label: 'Zähler', typ: 'text', gruppe: 'zaehler' },
    { key: 'zaehlerWert', label: 'Nach wie viel Strecke oder Stunden', typ: 'zahl', gruppe: 'zaehler',
      hilfe: 'Zum Beispiel 10.000 km oder 100 Stunden. Leer lassen, wenn es keine Zählergrenze gibt.' },
    { key: 'wirkung', label: 'Wirkung, wenn überfällig', typ: 'auswahl', optionen: WIRKUNGEN, gruppe: 'wirkung' },
    { key: 'vorwarnTage', label: 'Vorwarnung vor dem Termin', typ: 'ganzzahl', min: 0, max: 3650, einheit: 'Tage', gruppe: 'wirkung',
      hilfe: 'So viele Tage vorher zeigt die App „bald fällig“.' },
    { key: 'vorwarnZaehler', label: 'Vorwarnung beim Zähler', typ: 'zahl', gruppe: 'wirkung',
      hilfe: 'So viele km oder Stunden vor der Grenze zeigt die App „bald fällig“. Leer lassen für keine Vorwarnung.' }
  ];

  /* Zusätzliche Angaben nur beim Anlegen: Ausgangswert der Rechnung. */
  var FELDER_AUSGANG = [
    { key: 'zuletztAm', label: 'Zuletzt erledigt am', typ: 'datum', gruppe: 'ausgang',
      hilfe: 'Leer lassen, wenn die Frist ab heute zählen soll.' },
    { key: 'zuletztStand', label: 'Zählerstand damals', typ: 'zahl', gruppe: 'ausgang',
      hilfe: 'Der Zählerstand, als die Frist zuletzt erledigt wurde.' }
  ];

  var GRUPPEN = [
    { id: 'frist', titel: 'Frist' },
    { id: 'kalender', titel: 'Kalender' },
    { id: 'zaehler', titel: 'Zähler' },
    { id: 'wirkung', titel: 'Wirkung und Vorwarnung' },
    { id: 'ausgang', titel: 'Ausgangswert' }
  ];

  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }
  function felder(mitAusgang) { return FELDER.concat(mitAusgang ? FELDER_AUSGANG : []).map(kopie); }
  function finde(liste, wert) {
    for (var i = 0; i < liste.length; i++) { if (liste[i].wert === wert) return liste[i]; }
    return null;
  }
  function labelVon(liste, wert) { var x = finde(liste, wert); return x ? x.label : null; }

  /* ---------- Datum (nur Tage, ohne Uhrzeit, ohne Zeitzonen-Fallen) ---------- */
  function teile(d) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d || ''); return m ? [+m[1], +m[2], +m[3]] : null; }
  function fmt(y, m, d) { function z(n) { return (n < 10 ? '0' : '') + n; } return y + '-' + z(m) + '-' + z(d); }
  function tageImMonat(y, m) { return new Date(Date.UTC(y, m, 0)).getUTCDate(); }

  /* "2026-01-31" plus 1 Monat = "2026-02-28" (Monatsende bleibt Monatsende). */
  function addMonate(datum, n) {
    var t = teile(datum);
    if (!t) return null;
    var gesamt = t[0] * 12 + (t[1] - 1) + n;
    var y = Math.floor(gesamt / 12), m = (gesamt % 12) + 1;
    return fmt(y, m, Math.min(t[2], tageImMonat(y, m)));
  }

  /* Tage von a bis b; positiv, wenn b später liegt. */
  function tageZwischen(a, b) {
    var x = teile(a), y = teile(b);
    if (!x || !y) return null;
    return Math.round((Date.UTC(y[0], y[1] - 1, y[2]) - Date.UTC(x[0], x[1] - 1, x[2])) / 86400000);
  }

  var RANG = { ueberfaellig: 3, bald: 2, unbekannt: 1, ok: 0 };

  /*
   * Rechnet den Stand einer Frist.
   *  p.werte   die Angaben der Frist
   *  p.letzte  letzte Erledigung { datum, zaehlerstand }
   *  p.stand   aktueller Zählerstand { wert } oder null
   *  p.heute   "JJJJ-MM-TT"
   * Ergebnis: status = der schlechteste der beiden Teile (was zuerst eintritt).
   */
  function berechne(p) {
    var w = p.werte;
    var res = { status: 'ok', kalender: null, zaehler: null };
    var teilStatus = [];

    if (w.kalenderWert) {
      var monate = w.kalenderWert * (w.kalenderEinheit === 'jahre' ? 12 : 1);
      var faellig = addMonate(p.letzte.datum, monate);
      var tage = tageZwischen(p.heute, faellig);
      var s = tage < 0 ? 'ueberfaellig' : (tage <= (w.vorwarnTage || 0) ? 'bald' : 'ok');
      res.kalender = { status: s, faelligAm: faellig, tage: tage };
      teilStatus.push(s);
    }

    if (w.zaehlerId && w.zaehlerWert) {
      if (!p.stand || p.letzte.zaehlerstand === null || p.letzte.zaehlerstand === undefined) {
        res.zaehler = { status: 'unbekannt', grund: !p.stand ? 'Es gibt noch keinen Zählerstand.' : 'Der Zählerstand bei der letzten Erledigung fehlt.' };
        teilStatus.push('unbekannt');
      } else {
        var bei = p.letzte.zaehlerstand + w.zaehlerWert;
        var rest = Math.round((bei - p.stand.wert) * 100) / 100;
        var sz = rest < 0 ? 'ueberfaellig' : ((w.vorwarnZaehler !== null && w.vorwarnZaehler !== undefined && rest <= w.vorwarnZaehler) ? 'bald' : 'ok');
        res.zaehler = { status: sz, faelligBei: bei, rest: rest };
        teilStatus.push(sz);
      }
    }

    teilStatus.forEach(function (s) { if (RANG[s] > RANG[res.status]) res.status = s; });
    return res;
  }

  /* Reihenfolge in Listen: überfällig, bald, unbekannt, in Ordnung. */
  function rang(status) { return RANG[status] === undefined ? 0 : RANG[status]; }

  MM.Fristen = {
    KATEGORIEN: KATEGORIEN, WIRKUNGEN: WIRKUNGEN, EINHEITEN: EINHEITEN, ZAEHLERARTEN: ZAEHLERARTEN,
    felder: felder, gruppen: function () { return GRUPPEN.slice(); },
    zaehlerArt: function (wert) { return finde(ZAEHLERARTEN, wert); },
    labelVon: labelVon,
    addMonate: addMonate, tageZwischen: tageZwischen, berechne: berechne, rang: rang
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
