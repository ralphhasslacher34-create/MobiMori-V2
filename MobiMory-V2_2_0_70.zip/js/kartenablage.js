/*
 * Kartenablage (seit 2.0.34, Schritt 9b): die Kartenkacheln, die auf diesem Gerät liegen.
 *
 * Die Kacheln liegen im Cache des Browsers (Name „mobimory-karte“), nicht in der Datenbank der App: Sie sind große Bilder, lassen
 * sich jederzeit neu holen und gehören nicht in die Sicherungsdatei. Der Service Worker räumt diesen Cache beim Update der App nicht ab.
 * Welche Kacheln zu welcher Aktivität gehören, steht als Dokument „karte-<aktivitaetId>“ in „einstellungen“ (siehe js/daten.js).
 *
 * Geholt wird nur, wenn der Nutzer es auslöst, begrenzt (MM.Karte.QUELLE.maxKacheln), mit Pausen und höchstens zwei Abrufen gleichzeitig.
 * Für die Tests sind der Cache und der Abruf austauschbar.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var CACHE_NAME = 'mobimory-karte';
  /* So viele Fehler hintereinander: Es geht nicht (kein Netz, gesperrt). Dann bricht der Abruf ab, statt weiter zu klopfen. */
  var FEHLER_IN_FOLGE = 5;

  function standardOeffnen() {
    var c = global.caches;
    if (!c || typeof c.open !== 'function') return Promise.reject(new Error('Dieses Gerät kann keine Karten im Gerät ablegen.'));
    return c.open(CACHE_NAME);
  }
  function standardHole(url) {
    var f = global.fetch;
    if (typeof f !== 'function') return Promise.reject(new Error('Kein Netz verfügbar.'));
    return f(url, { mode: 'cors', credentials: 'omit' });
  }
  function warte(ms) { return new Promise(function (ok) { global.setTimeout(ok, ms); }); }

  function Kartenablage(optionen) {
    optionen = optionen || {};
    this.oeffnen = optionen.oeffnen || standardOeffnen;
    this.hole = optionen.hole || standardHole;
    this.pauseMs = optionen.pauseMs === undefined ? MM.Karte.QUELLE.pauseMs : optionen.pauseMs;
    this.parallel = optionen.parallel || MM.Karte.QUELLE.parallel;
  }

  /* Liegt die Kachel schon im Gerät? */
  Kartenablage.prototype.hat = function (url) {
    return this.oeffnen().then(function (c) { return c.match(url); }).then(function (r) { return !!r; }, function () { return false; });
  };

  /* Die Kachel als Blob oder null (nicht im Gerät). Fehler werden zu null, die Karte holt dann aus dem Netz. */
  Kartenablage.prototype.blob = function (url) {
    return this.oeffnen().then(function (c) { return c.match(url); }).then(function (r) { return r ? r.blob() : null; }).catch(function () { return null; });
  };

  /*
   * Die Kacheln holen und ablegen. kacheln: [{ z, x, y }]. opt: { fortschritt(fertig, gesamt), abbrechen: () => bool }.
   * Schon vorhandene Kacheln werden nicht neu geholt.
   * Ergebnis: { ok, neu, schon, fehler, bytes, abgebrochen, grund?, urls: [Schlüssel der jetzt vorhandenen Kacheln] }
   */
  Kartenablage.prototype.holen = function (kacheln, opt) {
    var self = this, o = opt || {}, gesamt = kacheln.length;
    var erg = { ok: true, neu: 0, schon: 0, fehler: 0, bytes: 0, abgebrochen: false, urls: [] };
    var naechste = 0, fertig = 0, folge = 0, stopp = false;
    if (gesamt > MM.Karte.QUELLE.maxKacheln) return Promise.resolve({ ok: false, neu: 0, schon: 0, fehler: 0, bytes: 0, abgebrochen: false, urls: [], grund: 'Das sind mehr als ' + MM.Karte.QUELLE.maxKacheln + ' Kacheln auf einmal.' });
    return this.oeffnen().then(function (cache) {
      function arbeiter() {
        if (stopp || naechste >= gesamt) return Promise.resolve();
        if (o.abbrechen && o.abbrechen()) { stopp = true; erg.abgebrochen = true; return Promise.resolve(); }
        var k = kacheln[naechste++], url = MM.Karte.kachelUrl(k.z, k.x, k.y), key = MM.Karte.kachelKey(k.z, k.x, k.y);
        return cache.match(url).then(function (da) {
          if (da) { erg.schon++; erg.urls.push(key); return null; }
          return self.hole(url).then(function (antwort) {
            if (!antwort || !antwort.ok) throw new Error('Antwort ' + (antwort ? antwort.status : 'fehlt'));
            return antwort.clone().blob().then(function (b) {
              if (!b || !b.size) throw new Error('Leere Kachel');
              return cache.put(url, antwort).then(function () { erg.neu++; erg.bytes += b.size; erg.urls.push(key); folge = 0; });
            });
          }).catch(function () {
            erg.fehler++; folge++;
            if (folge >= FEHLER_IN_FOLGE) { stopp = true; erg.ok = false; erg.grund = 'Die Kacheln konnten nicht geholt werden. Vermutlich ist kein Netz da oder der Kartenserver antwortet nicht. Bereits geholte Kacheln bleiben erhalten.'; }
          }).then(function () { return self.pauseMs ? warte(self.pauseMs) : null; });
        }).then(function () {
          fertig++;
          if (o.fortschritt) { try { o.fortschritt(fertig, gesamt); } catch (e) { /* die Anzeige darf den Abruf nicht stören */ } }
          return arbeiter();
        });
      }
      var rennen = [], i;
      for (i = 0; i < self.parallel; i++) rennen.push(arbeiter());
      return Promise.all(rennen);
    }).then(function () {
      if (erg.fehler > 0 && erg.ok && !erg.abgebrochen) erg.grund = erg.fehler + ' von ' + gesamt + ' Kacheln konnten nicht geholt werden.';
      return erg;
    }, function (e) {
      return { ok: false, neu: 0, schon: 0, fehler: 0, bytes: 0, abgebrochen: false, urls: [], grund: (e && e.message) || 'Die Kacheln konnten nicht abgelegt werden.' };
    });
  };

  /* Kacheln aus dem Gerät entfernen. keys: Schlüssel „z/x/y“. Ergebnis: Anzahl entfernter Kacheln. */
  Kartenablage.prototype.loeschen = function (keys) {
    return this.oeffnen().then(function (cache) {
      var n = 0;
      return (keys || []).reduce(function (kette, key) {
        return kette.then(function () {
          var p = key.split('/');
          return cache.delete(MM.Karte.kachelUrl(+p[0], +p[1], +p[2])).then(function (ok) { if (ok) n++; });
        });
      }, Promise.resolve()).then(function () { return n; });
    }, function () { return 0; });
  };

  MM.Kartenablage = Kartenablage;
  MM.Kartenablage.CACHE_NAME = CACHE_NAME;
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
