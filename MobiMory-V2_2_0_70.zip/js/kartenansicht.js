/*
 * Kartenansicht (seit 2.0.34, Schritt 9b): die Karte im Vollbild, gezeichnet mit Leaflet (lib/leaflet).
 *
 * Gezeigt werden: die geplante Route, Start, Ziel und Zwischenziele, die Wetterpunkte der Route (grau, wenn schon vorbei),
 * die Einträge „Wetter jetzt“ und weitere Einträge mit Position aus dem Logbuch, der tatsächlich gefahrene Weg und die aktuelle Position.
 * Die Kacheln kommen zuerst aus dem Gerät (Offline-Karte, js/kartenablage.js), sonst aus dem Netz.
 *
 * Alle Texte kommen mit textContent in die Seite, nie als HTML (außer dem festen Nachweis der Kartenquelle in der Karte selbst).
 * Die Rechnung steht in js/karte.js, das Holen der Daten in js/daten.js.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};
  var doc = global.document;

  function el(tag, attrs) {
    var e = doc.createElement(tag), k;
    if (attrs) {
      for (k in attrs) {
        if (!Object.prototype.hasOwnProperty.call(attrs, k) || attrs[k] === null || attrs[k] === undefined) continue;
        if (k === 'text') e.textContent = attrs[k];
        else if (k === 'class') e.className = attrs[k];
        else if (k.slice(0, 2) === 'on') e[k] = attrs[k];
        else e.setAttribute(k, attrs[k]);
      }
    }
    for (var i = 2; i < arguments.length; i++) { var c = arguments[i]; if (c === null || c === undefined || c === false) continue; e.appendChild(typeof c === 'string' ? doc.createTextNode(c) : c); }
    return e;
  }
  function zahl1(n) { return String(Math.round(n * 10) / 10).replace('.', ','); }
  function uhr(datum, zeit) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(datum || '');
    return (m ? m[3] + '.' + m[2] + '. ' : '') + (zeit ? zeit + ' Uhr' : '');
  }

  /* Die Kachelschicht: erst das Gerät, dann das Netz. zaehler wird hochgezählt (lokal, netz, fehlt). */
  function kachelSchicht(L, ablage, zaehler, beiAenderung) {
    var Schicht = L.GridLayer.extend({
      createTile: function (coords, fertig) {
        var img = doc.createElement('img'), url = MM.Karte.kachelUrl(coords.z, coords.x, coords.y), objekt = null, erledigt = false;
        img.alt = ''; img.setAttribute('role', 'presentation'); img.referrerPolicy = 'strict-origin-when-cross-origin';
        function schluss(ok) {
          if (erledigt) return;
          erledigt = true;
          if (objekt) { try { global.URL.revokeObjectURL(objekt); } catch (e) { /* nichts zu tun */ } objekt = null; }
          if (!ok) { zaehler.fehlt++; if (beiAenderung) beiAenderung(); }
          fertig(null, img);
        }
        img.onload = function () { schluss(true); };
        img.onerror = function () { schluss(false); };
        ablage.blob(url).then(function (b) {
          if (b) { zaehler.lokal++; try { objekt = global.URL.createObjectURL(b); img.src = objekt; return; } catch (e) { /* dann aus dem Netz */ } }
          zaehler.netz++; img.src = url;
        });
        return img;
      }
    });
    return new Schicht({ minZoom: MM.Karte.QUELLE.minZoom, maxZoom: MM.Karte.QUELLE.maxZoom, noWrap: true, tileSize: 256,
      attribution: '<a href="' + MM.Karte.QUELLE.nachweisLink + '" target="_blank" rel="noopener">' + MM.Karte.QUELLE.nachweis + '</a>' });
  }

  function pin(L, klasse, text, groesse) {
    var g = groesse || 30;
    return L.divIcon({ className: 'kv-pin-huelle', iconSize: [g, g], iconAnchor: [g / 2, g / 2], popupAnchor: [0, -g / 2], html: el('span', { class: 'kv-pin ' + klasse, text: text }) });
  }

  /*
   * opt: {
   *   ablage: Kartenablage,
   *   kd: Ergebnis von daten.kartenDaten,
   *   zurueck: Adresse „zurück zum Cockpit“, offline: Adresse der Seite Offline-Karte, routeSeite: Adresse der Seite Route und Wetter,
   *   beiZurueck: Funktion, beim Verlassen,
   *   wetterNeu(versatzMin): Zusage mit { zeilen, versatzMin } oder null (Wetterpunkte neu gerechnet für Verspätung),
   *   wetterJetzt(): Zusage mit { ok, text } oder { ok: false, fehler } (Knopf „Wetter jetzt“ in der Karte),
   *   neuLaden(): Zusage mit neuen Kartendaten (nach „Wetter jetzt“),
   *   gpsText(): Text zum Stand des GPS
   * }
   * Ergebnis: { element, start(), position(fix), neueDaten(kd), zerstoeren() } oder { fehler } ohne Leaflet.
   */
  function aufbauen(opt) {
    var L = global.L;
    if (!L || !L.map) return { fehler: 'Die Karte konnte nicht geladen werden (Leaflet fehlt).' };
    var kd = opt.kd, karte = null, folgen = true, letzteFix = null, ebenen = null, posMarker = null, genauigkeitKreis = null;
    var zaehler = { lokal: 0, netz: 0, fehlt: 0 }, verspaetungAngewandt = 0, letzteNeuRechnung = 0, fix = null, zuletztAngezeigt = null;

    var info = el('div', { class: 'kv-info', role: 'status', 'aria-live': 'polite' });
    var kartenFlaeche = el('div', { class: 'kv-karte', role: 'application', 'aria-label': 'Karte' });
    var folgenKnopf = el('button', { class: 'knopf leise klein', type: 'button', text: 'Folgen: an', 'aria-pressed': 'true' });
    var meldung = el('p', { class: 'kv-meldung', role: 'status' });
    meldung.hidden = true;
    function melden(text) { meldung.textContent = text || ''; meldung.hidden = !text; }

    var leiste = el('div', { class: 'kv-leiste' },
      el('a', { class: 'knopf leise klein', href: opt.zurueck, text: 'Zurück', onclick: function () { if (opt.beiZurueck) opt.beiZurueck(); } }),
      folgenKnopf,
      el('button', { class: 'knopf leise klein', type: 'button', text: 'Alles zeigen', onclick: function () { alles(); } }),
      el('button', { class: 'knopf leise klein', type: 'button', text: 'Wetter jetzt', onclick: function (ev) {
        var b = ev.currentTarget; if (!opt.wetterJetzt || b.disabled) return;
        b.disabled = true;
        opt.wetterJetzt().then(function (r) { b.disabled = false; melden(r.ok ? r.text : ((r.fehler && r.fehler.allgemein) || 'Das hat nicht geklappt.')); if (r.ok) neueDatenHolen(); }, function () { b.disabled = false; melden('Das hat nicht geklappt.'); });
      } }),
      el('a', { class: 'knopf leise klein', href: opt.offline, text: 'Offline-Karte' }));
    var wurzel = el('div', { class: 'karte-voll', role: 'main' }, leiste, meldung, kartenFlaeche, info);

    function planPunkte() {
      var p = [];
      if (kd.route) kd.route.punkte.forEach(function (x) { p.push([x.breite, x.laenge]); });
      kd.planOrte.forEach(function (o) { p.push([o.breite, o.laenge]); });
      return p;
    }
    function alles() {
      if (!karte) return;
      var pts = planPunkte();
      MM.Karte.wegStuecke(kd.weg).forEach(function (s) { s.forEach(function (q) { pts.push(q); }); });
      kd.ereignisse.forEach(function (e) { pts.push([e.breite, e.laenge]); });
      if (fix) pts.push([fix.breite, fix.laenge]);
      if (!pts.length) { karte.setView([50, 10], 5); return; }
      folgen = false; folgenAnzeigen();
      karte.fitBounds(L.latLngBounds(pts), { padding: [36, 36], maxZoom: 15 });
    }
    function folgenAnzeigen() { folgenKnopf.textContent = 'Folgen: ' + (folgen ? 'an' : 'aus'); folgenKnopf.setAttribute('aria-pressed', folgen ? 'true' : 'false'); }
    folgenKnopf.onclick = function () {
      folgen = !folgen; folgenAnzeigen();
      if (folgen && fix && karte) karte.setView([fix.breite, fix.laenge], Math.max(karte.getZoom(), 13));
    };

    function popupInhalt(titel, zeilen) {
      var d = el('div', { class: 'kv-popup' }, el('strong', { text: titel }));
      zeilen.forEach(function (z) { if (z) d.appendChild(el('p', { text: z })); });
      return d;
    }

    function zeichnen() {
      if (!karte) return;
      if (ebenen) ebenen.clearLayers(); else ebenen = L.layerGroup().addTo(karte);
      var pos = fix && kd.route ? MM.Karte.aufRoute(kd.route.punkte, fix.breite, fix.laenge) : null;
      /* geplante Route */
      if (kd.route && kd.route.punkte.length >= 2) {
        L.polyline(kd.route.punkte.map(function (x) { return [x.breite, x.laenge]; }), { color: '#1d5fbf', weight: 5, opacity: .75 }).addTo(ebenen);
      }
      /* gefahrener Weg */
      MM.Karte.wegStuecke(kd.weg).forEach(function (s) {
        if (s.length > 1) L.polyline(s, { color: '#e07b00', weight: 4, opacity: .95 }).addTo(ebenen);
      });
      /* Start, Ziel, Zwischenziele */
      var hatStart = false, hatZiel = false;
      kd.planOrte.forEach(function (o) {
        var s = o.rolle === 'start', z = o.rolle === 'ziel';
        if (s) hatStart = true; if (z) hatZiel = true;
        L.marker([o.breite, o.laenge], { icon: pin(L, s ? 'kv-start' : (z ? 'kv-ziel' : 'kv-zwischen'), s ? 'S' : (z ? 'Z' : '•'), 30), title: o.name, keyboard: true })
          .bindPopup(popupInhalt((s ? 'Start' : (z ? 'Ziel' : 'Zwischenziel')) + ': ' + o.name, [])).addTo(ebenen);
      });
      if (kd.route && kd.route.punkte.length >= 2) {
        var p0 = kd.route.punkte[0], p1 = kd.route.punkte[kd.route.punkte.length - 1];
        if (!hatStart) L.marker([p0.breite, p0.laenge], { icon: pin(L, 'kv-start', 'S', 30), title: 'Start der Route' }).bindPopup(popupInhalt('Start der Route', [kd.route.name])).addTo(ebenen);
        if (!hatZiel) L.marker([p1.breite, p1.laenge], { icon: pin(L, 'kv-ziel', 'Z', 30), title: 'Ziel der Route' }).bindPopup(popupInhalt('Ziel der Route', [kd.route.name])).addTo(ebenen);
      }
      /* Wetterpunkte der Route */
      if (kd.wetter) {
        kd.wetter.zeilen.forEach(function (z) {
          if (typeof z.breite !== 'number') return;
          var vorbei = pos && pos.abstandKm <= 3 && z.km < pos.km - 0.5;
          var zeilen = MM.Karte.wetterPunktText(z, kd.wetter.windEinheit);
          var kopf = 'Ankunft ca. ' + MM.Karte.etaText(z.etaMs) + ' Uhr' + (kd.wetter.versatzMin ? ' (' + MM.Karte.verspaetungText(kd.wetter.versatzMin) + ' eingerechnet)' : '') + ', km ' + zahl1(z.km);
          L.marker([z.breite, z.laenge], { icon: pin(L, vorbei ? 'kv-vorbei' : 'kv-wetterpunkt', String(z.nr), 30), title: 'Wetterpunkt ' + z.nr + (z.name ? ': ' + z.name : ''), keyboard: true })
            .bindPopup(popupInhalt('Punkt ' + z.nr + (z.name ? ' · ' + z.name : '') + (vorbei ? ' (schon vorbei)' : ''), [kopf, zeilen.length ? zeilen.join(', ') : 'Dafür gibt es kein Wetter.', 'Prognose, kein Messwert.'])).addTo(ebenen);
        });
      }
      /* Einträge aus dem Logbuch mit Position */
      kd.ereignisse.forEach(function (e) {
        var w = e.istWetter;
        L.marker([e.breite, e.laenge], { icon: w ? pin(L, 'kv-wetterjetzt', 'W', 28) : pin(L, 'kv-eintrag', '', 16), title: e.artName + ' ' + uhr(e.datum, e.zeit), keyboard: true, zIndexOffset: w ? 200 : 0 })
          .bindPopup(popupInhalt(e.artName + ' · ' + uhr(e.datum, e.zeit), [e.ortName, e.text])).addTo(ebenen);
      });
      /* aktuelle Position */
      posMarker = null; genauigkeitKreis = null;
      if (fix) {
        if (isFinite(fix.genauigkeit) && fix.genauigkeit > 0 && fix.genauigkeit < 500) genauigkeitKreis = L.circle([fix.breite, fix.laenge], { radius: fix.genauigkeit, color: '#1d5fbf', weight: 1, fillOpacity: .1, interactive: false }).addTo(ebenen);
        posMarker = L.marker([fix.breite, fix.laenge], { icon: pin(L, 'kv-position', '', 22), zIndexOffset: 1000, title: 'Du bist hier', keyboard: false, interactive: false }).addTo(ebenen);
      }
    }

    function infoZeichnen() {
      info.textContent = '';
      var pos = fix && kd.route ? MM.Karte.aufRoute(kd.route.punkte, fix.breite, fix.laenge) : null;
      var zeile1 = fix ? 'Position ' + MM.Logbuch.positionText(fix.breite, fix.laenge) + (isFinite(fix.genauigkeit) ? ' (GPS, ±' + Math.round(fix.genauigkeit) + ' m)' : ' (GPS)') : (opt.gpsText ? opt.gpsText() : 'Position wird gesucht …');
      info.appendChild(el('p', { text: zeile1 }));
      if (pos && kd.route) {
        var t = 'Auf der Route bei km ' + zahl1(pos.km) + ' von ' + zahl1(kd.route.laengeKm) + ', ' + (pos.abstandKm < 0.05 ? 'genau auf der Route' : zahl1(pos.abstandKm) + ' km neben der Route');
        var v = MM.Karte.verspaetungMin({ position: pos, kmh: kd.route.kmh, abfahrtMs: kd.route.abfahrtMs, jetztMs: Date.now() });
        if (v !== null) t += ', ' + MM.Karte.verspaetungText(v);
        else if (pos.abstandKm > 3) t += ' (zu weit weg für einen Zeitvergleich)';
        info.appendChild(el('p', { text: t }));
      } else if (!kd.route) {
        info.appendChild(el('p', { class: 'kv-leise' }, 'Es gibt noch keine Route. ', el('a', { href: opt.routeSeite, text: 'Route einlesen' })));
      }
      var wl = MM.Karte.wegLaengeKm(kd.weg);
      if (wl > 0) info.appendChild(el('p', { text: 'Gefahrener Weg: ' + zahl1(wl) + ' km (Luftlinie von Punkt zu Punkt)' }));
      if (kd.route && !kd.wetter) info.appendChild(el('p', { class: 'kv-leise' }, 'Für die Route ist noch kein Wetter geholt. ', el('a', { href: opt.routeSeite, text: 'Wetter holen' })));
      if (kd.wetter && !kd.wetter.aktuell) info.appendChild(el('p', { class: 'kv-warn', text: 'Das Wetter der Route gehört zu einer früheren Abfahrt oder Geschwindigkeit. Hole es auf der Seite Route und Wetter neu.' }));
      if (zaehler.fehlt >= 4 && zaehler.lokal === 0) info.appendChild(el('p', { class: 'kv-warn', text: 'Kartenkacheln fehlen hier (kein Netz und keine Offline-Karte für dieses Gebiet). Die Linien und Punkte stimmen trotzdem.' }));
      info.appendChild(el('p', { class: 'kv-legende' },
        el('span', { class: 'kv-pin kv-start klein', text: 'S' }), ' Start ', el('span', { class: 'kv-pin kv-ziel klein', text: 'Z' }), ' Ziel ',
        el('span', { class: 'kv-pin kv-wetterpunkt klein', text: '1' }), ' Wetterpunkt ', el('span', { class: 'kv-pin kv-wetterjetzt klein', text: 'W' }), ' Wetter jetzt ',
        el('span', { class: 'kv-linie kv-linie-plan' }), ' geplant ', el('span', { class: 'kv-linie kv-linie-weg' }), ' gefahren'));
      zuletztAngezeigt = pos;
    }

    /* Verspätung hat sich geändert: Die Wetterpunkte werden für die neue Ankunftszeit gerechnet (höchstens einmal pro Minute). */
    function verspaetungPruefen() {
      if (!opt.wetterNeu || !kd.route || !kd.wetter || !fix) return;
      if (Date.now() - letzteNeuRechnung < 60000) return;
      var pos = MM.Karte.aufRoute(kd.route.punkte, fix.breite, fix.laenge);
      var v = MM.Karte.verspaetungMin({ position: pos, kmh: kd.route.kmh, abfahrtMs: kd.route.abfahrtMs, jetztMs: Date.now() });
      if (v === null) return;
      v = Math.round(v / 5) * 5;
      if (Math.abs(v - verspaetungAngewandt) < 10) return;
      letzteNeuRechnung = Date.now();
      opt.wetterNeu(v).then(function (r) {
        if (!r || !r.zeilen) return;
        verspaetungAngewandt = v;
        kd.wetter.zeilen = r.zeilen; kd.wetter.versatzMin = r.versatzMin;
        zeichnen(); infoZeichnen();
      }, function () { /* die alten Werte bleiben */ });
    }

    function neueDatenHolen() { if (opt.neuLaden) opt.neuLaden().then(function (nd) { if (nd) neueDaten(nd); }); }
    function neueDaten(nd) { kd = nd; verspaetungAngewandt = nd.wetter ? (nd.wetter.versatzMin || 0) : 0; zeichnen(); infoZeichnen(); }

    return {
      element: wurzel,
      zaehler: zaehler,
      start: function () {
        karte = L.map(kartenFlaeche, { zoomControl: true, attributionControl: true, preferCanvas: false, worldCopyJump: false, maxBoundsViscosity: 1 });
        karte.setMaxBounds([[-85, -180], [85, 180]]);
        kachelSchicht(L, opt.ablage, zaehler, function () { infoZeichnen(); }).addTo(karte);
        karte.on('dragstart', function () { if (folgen) { folgen = false; folgenAnzeigen(); } });
        zeichnen(); infoZeichnen();
        if (fix) karte.setView([fix.breite, fix.laenge], 13); else alles();
        global.setTimeout(function () { if (karte) karte.invalidateSize(); }, 150);
      },
      position: function (f) {
        fix = f;
        if (!karte) return;
        if (f) {
          if (posMarker) { posMarker.setLatLng([f.breite, f.laenge]); if (genauigkeitKreis) { genauigkeitKreis.setLatLng([f.breite, f.laenge]); if (isFinite(f.genauigkeit)) genauigkeitKreis.setRadius(f.genauigkeit); } }
          else zeichnen();
          if (folgen) karte.panTo([f.breite, f.laenge], { animate: true });
        }
        infoZeichnen(); verspaetungPruefen();
      },
      neueDaten: neueDaten,
      aktualisieren: neueDatenHolen,
      meldung: melden,
      alles: alles,
      zerstoeren: function () { if (karte) { try { karte.remove(); } catch (e) { /* nichts zu tun */ } karte = null; } }
    };
  }

  MM.Kartenansicht = { aufbauen: aufbauen };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
