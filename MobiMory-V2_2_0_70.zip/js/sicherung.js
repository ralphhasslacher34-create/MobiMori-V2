/*
 * Sicherungsdatei: Aufbau, Verschlüsselung und Prüfung.
 *
 * Aufbau einer Datei:
 *   "MOBIMORY-SICHERUNG\n"   Kennung
 *   1 Byte                   0 = nicht verschlüsselt, 1 = verschlüsselt
 *   nicht verschlüsselt:     Nutzlast
 *   verschlüsselt:           16 Byte Salz, 12 Byte Startwert, danach die verschlüsselte Nutzlast
 * Nutzlast:
 *   4 Byte Länge des Kopfes (Kopf ist JSON), der Kopf, danach die Dateien (Scans, Dokumente) hintereinander
 *
 * Verschlüsselung: AES-GCM mit 256 Bit. Der Schlüssel entsteht aus dem Schlüsselwort
 * (PBKDF2 mit SHA-256, 200.000 Runden). AES-GCM erkennt zugleich Veränderungen.
 * Ohne Schlüsselwort ist die Datei lesbar. Wer das Schlüsselwort vergisst, kann sie nicht öffnen.
 *
 * Alles hier ist reine Rechnung auf Bytes. Das Sammeln der Daten und das Einspielen
 * steht in daten.js.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var FORMAT = 1;
  var RUNDEN = 200000;
  var KENNUNG = new TextEncoder().encode('MOBIMORY-SICHERUNG\n');

  function fehler(code, text) { var e = new Error(text); e.code = code; return e; }

  function zusammen(teile) {
    var n = 0; teile.forEach(function (t) { n += t.length; });
    var res = new Uint8Array(n), pos = 0;
    teile.forEach(function (t) { res.set(t, pos); pos += t.length; });
    return res;
  }
  function u32(n) { return new Uint8Array([(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255]); }
  function lies32(b, pos) { return ((b[pos] << 24) | (b[pos + 1] << 16) | (b[pos + 2] << 8) | b[pos + 3]) >>> 0; }
  function hex(u8) { var s = ''; for (var i = 0; i < u8.length; i++) { s += (u8[i] < 16 ? '0' : '') + u8[i].toString(16); } return s; }

  function sha256(bytes) {
    return global.crypto.subtle.digest('SHA-256', bytes).then(function (h) { return hex(new Uint8Array(h)); });
  }

  function schluesselAus(wort, salz) {
    var s = global.crypto.subtle;
    return s.importKey('raw', new TextEncoder().encode(wort), 'PBKDF2', false, ['deriveKey']).then(function (basis) {
      return s.deriveKey({ name: 'PBKDF2', salt: salz, iterations: RUNDEN, hash: 'SHA-256' }, basis, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
    });
  }

  /*
   * Baut die Datei. kopf = Angaben und Daten, dateien = Liste von Uint8Array.
   * Ohne schluessel nicht verschlüsselt.
   */
  function bauen(kopf, dateien, schluessel) {
    var blobBytes = zusammen(dateien);
    return sha256(blobBytes).then(function (summe) {
      kopf.dateien = dateien.map(function (d) { return d.length; });
      kopf.dateiPruefsumme = summe;
      var kopfBytes = new TextEncoder().encode(JSON.stringify(kopf));
      var nutzlast = zusammen([u32(kopfBytes.length), kopfBytes, blobBytes]);
      if (!schluessel) return zusammen([KENNUNG, new Uint8Array([0]), nutzlast]);
      var salz = global.crypto.getRandomValues(new Uint8Array(16));
      var iv = global.crypto.getRandomValues(new Uint8Array(12));
      return schluesselAus(schluessel, salz).then(function (key) {
        return global.crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, nutzlast);
      }).then(function (chiffre) { return zusammen([KENNUNG, new Uint8Array([1]), salz, iv, new Uint8Array(chiffre)]); });
    });
  }

  function beginntMitKennung(bytes) {
    if (bytes.length < KENNUNG.length + 1) return false;
    for (var i = 0; i < KENNUNG.length; i++) { if (bytes[i] !== KENNUNG[i]) return false; }
    return true;
  }
  function istVerschluesselt(bytes) { return beginntMitKennung(bytes) && bytes[KENNUNG.length] === 1; }

  /* Nutzlast zerlegen und prüfen. */
  function zerlegen(nutzlast) {
    if (nutzlast.length < 4) throw fehler('beschaedigt', 'Die Datei ist beschädigt.');
    var kl = lies32(nutzlast, 0);
    if (kl <= 0 || 4 + kl > nutzlast.length) throw fehler('beschaedigt', 'Die Datei ist beschädigt.');
    var kopf;
    try { kopf = JSON.parse(new TextDecoder().decode(nutzlast.subarray(4, 4 + kl))); }
    catch (e) { throw fehler('beschaedigt', 'Die Datei ist beschädigt.'); }
    var rest = nutzlast.subarray(4 + kl);
    var laengen = Array.isArray(kopf.dateien) ? kopf.dateien : [];
    var summe = laengen.reduce(function (s, n) { return s + n; }, 0);
    if (summe !== rest.length) throw fehler('beschaedigt', 'Die Datei ist beschädigt: Die Dateien darin sind unvollständig.');
    var pos = 0, dateien = laengen.map(function (n) { var d = rest.slice(pos, pos + n); pos += n; return d; });
    return sha256(rest).then(function (s) {
      if (s !== kopf.dateiPruefsumme) throw fehler('beschaedigt', 'Die Datei ist beschädigt: Die Prüfsumme der Dateien stimmt nicht.');
      return { kopf: kopf, dateien: dateien };
    });
  }

  /* Liest die Datei. Verschlüsselte brauchen das Schlüsselwort. */
  function auspacken(bytes, schluessel) {
    if (!beginntMitKennung(bytes)) return Promise.reject(fehler('format', 'Das ist keine MobiMory-Sicherung.'));
    var flag = bytes[KENNUNG.length];
    var start = KENNUNG.length + 1;
    if (flag === 0) { try { return Promise.resolve(zerlegen(bytes.subarray(start))); } catch (e) { return Promise.reject(e); } }
    if (flag !== 1) return Promise.reject(fehler('format', 'Das ist keine MobiMory-Sicherung.'));
    if (!schluessel) return Promise.reject(fehler('schluessel_noetig', 'Diese Sicherung ist verschlüsselt. Bitte das Schlüsselwort eingeben.'));
    if (bytes.length < start + 28 + 16) return Promise.reject(fehler('beschaedigt', 'Die Datei ist beschädigt.'));
    var salz = bytes.slice(start, start + 16), iv = bytes.slice(start + 16, start + 28), chiffre = bytes.slice(start + 28);
    return schluesselAus(schluessel, salz).then(function (key) {
      return global.crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv }, key, chiffre);
    }).then(function (klar) { return new Uint8Array(klar); }, function () {
      throw fehler('schluessel', 'Das Schlüsselwort stimmt nicht, oder die Datei ist beschädigt.');
    }).then(function (klar) { return zerlegen(klar); });
  }

  MM.Sicherung = { FORMAT: FORMAT, RUNDEN: RUNDEN, bauen: bauen, auspacken: auspacken, istVerschluesselt: istVerschluesselt, beginntMitKennung: beginntMitKennung, sha256: sha256 };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
