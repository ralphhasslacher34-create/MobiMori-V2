/* Verbrauch in allen Einheiten (seit 2.0.56). Nur Regeln, kein Speicher und kein Netz.
 *
 * Festlegungen des Nutzers (09.11.2026):
 *  - Die Verbrauchs-Einheit ist einstellbar: Liter je Betriebsstunde, je Kilometer, je Seemeile oder je Tag.
 *  - Ausgegeben wird in ALLEN Rechenergebnissen, was sich rechnen lässt: Betriebsstunden wenn vorhanden, Entfernung wenn
 *    vorhanden, dazu der Durchschnitt am Tag. Die Einstellung bestimmt nur, welche Einheit vorn steht.
 *  - Zeit und Entfernung kommen aus den Zählern (dort korrigierbar). Fehlt etwas, wird nichts gerechnet und nichts geraten.
 *  - Der Durchschnitt einer Aktivität ist die Summe der Verbräuche aller Tankungen dieser Aktivität, geteilt durch die
 *    zugehörige Zeit, Betriebsstunden und Strecke.
 * Die Einstellung liegt als ein Dokument „verbrauch-einheit“ in „einstellungen“ (keine Umstellung des Speichers, in der Sicherung). */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var SM_IN_KM = 1.852;
  var DOK = 'verbrauch-einheit';

  var EINHEITEN = [
    { wert: 'auto', label: 'Automatisch (Betriebsstunden, sonst Entfernung, sonst Tag)' },
    { wert: 'stunde', label: 'Liter je Betriebsstunde (l/h)' },
    { wert: 'km', label: 'Liter je Kilometer (l/km)' },
    { wert: 'sm', label: 'Liter je Seemeile (l/sm)' },
    { wert: 'tag', label: 'Liter je Tag (l/Tag)' }
  ];
  function istEinheit(w) { return EINHEITEN.some(function (e) { return e.wert === w; }); }
  function einheitAus(dok) { var w = dok && dok.werte && dok.werte.einheit; return istEinheit(w) ? w : 'auto'; }
  function dokumentSetzen(dok, wert) { return { id: DOK, werte: Object.assign({}, (dok && dok.werte) || {}, { einheit: istEinheit(wert) ? wert : 'auto' }) }; }

  function runde(x, s) { var f = Math.pow(10, s === undefined ? 2 : s); return Math.round(x * f) / f; }
  function text(x, s) { return String(runde(x, s === undefined ? 1 : s)).replace('.', ','); }
  function kmZuSm(km) { return km / SM_IN_KM; }

  /* Unterschied zweier Kilometerstände, oder null (fehlt, keine Zahl, nicht gewachsen). */
  function strecke(alt, neu) {
    if (typeof alt !== 'number' || typeof neu !== 'number' || !isFinite(alt) || !isFinite(neu)) return null;
    var d = neu - alt;
    return d > 0 ? runde(d, 2) : null;
  }

  /* Die Reihenfolge der Einheiten für die Anzeige: die gewählte zuerst, dann die übrigen. */
  var ALLE = ['stunde', 'km', 'sm', 'tag'];
  function reihenfolge(einheit, vorhanden) {
    var erste = einheit && einheit !== 'auto' ? [einheit] : [];
    var rest = ALLE.filter(function (e) { return erste.indexOf(e) < 0; });
    return erste.concat(rest).filter(function (e) { return vorhanden.indexOf(e) >= 0; });
  }

  /*
   * Der Durchschnitt über mehrere Tankungen (zum Beispiel einer Aktivität). liste: gespeicherte Verbräuche
   * { liter, tage, km, einzeln: [{ id, name, stunden }] }. Ergebnis: null (nichts da) oder
   * { liter, tage, anzahl, lProTag, km, lProKm, lProSm, einzeln: [{ id, name, stunden, lProStunde }] }.
   * Betriebsstunden und Strecke zählen nur, wenn JEDE Tankung sie hat; sonst wäre der Durchschnitt falsch.
   */
  function durchschnitt(liste) {
    liste = (liste || []).filter(function (v) { return v && typeof v.liter === 'number' && typeof v.tage === 'number' && v.tage > 0; });
    if (!liste.length) return null;
    var liter = 0, tage = 0, km = 0, alleKm = true;
    liste.forEach(function (v) { liter += v.liter; tage += v.tage; if (typeof v.km === 'number' && v.km > 0) km += v.km; else alleKm = false; });
    var erg = { liter: runde(liter, 2), tage: runde(tage, 3), anzahl: liste.length, lProTag: runde(liter / tage, 2), km: null, lProKm: null, lProSm: null, einzeln: [] };
    if (alleKm && km > 0) { erg.km = runde(km, 2); erg.lProKm = runde(liter / km, 3); erg.lProSm = runde(liter / kmZuSm(km), 3); }
    var ids = {};
    liste.forEach(function (v) {
      (v.einzeln || []).forEach(function (e) {
        var s = ids[e.id] = ids[e.id] || { id: e.id, name: e.name, stunden: 0, anzahl: 0 };
        if (typeof e.stunden === 'number' && e.stunden > 0) { s.stunden += e.stunden; s.anzahl++; }
      });
    });
    Object.keys(ids).forEach(function (k) {
      var s = ids[k];
      if (s.anzahl === liste.length && s.stunden > 0) erg.einzeln.push({ id: s.id, name: s.name, stunden: runde(s.stunden, 2), lProStunde: runde(liter / s.stunden, 2) });
    });
    /* Mit einem einzigen Verbraucher ist „Liter je Stunde“ eindeutig; bei mehreren gibt der Füllstand nur eine Summe. */
    if (liste.some(function (v) { return v.summe; })) erg.einzeln = [];
    return erg;
  }

  function durchschnittZeilen(d, einheit) {
    if (!d) return [];
    var z = ['Verbrauch in dieser Aktivität: ' + text(d.liter) + ' l in ' + text(d.tage, 1) + ' Tagen (' + text(d.lProTag, 2) + ' l je Tag, Durchschnitt aus ' + d.anzahl + (d.anzahl === 1 ? ' Tankung' : ' Tankungen') + ').'];
    var extra = { stunde: d.einzeln.map(function (e) { return e.name + ': ' + text(e.lProStunde, 2) + ' l je Betriebsstunde (' + text(e.stunden, 1) + ' Betriebsstunden).'; }),
      km: d.lProKm ? ['Entfernung: ' + text(d.lProKm, 2) + ' l je km (' + text(d.km, 1) + ' km).'] : [],
      sm: d.lProSm ? ['Entfernung: ' + text(d.lProSm, 2) + ' l je sm (' + text(kmZuSm(d.km), 1) + ' sm).'] : [], tag: [] };
    var vorhanden = ALLE.filter(function (e) { return extra[e].length || e === 'tag'; });
    reihenfolge(einheit, vorhanden).forEach(function (e) { z = z.concat(extra[e]); });
    return z;
  }

  MM.Verbrauch = {
    SM_IN_KM: SM_IN_KM, DOKUMENT: DOK, EINHEITEN: EINHEITEN, einheitAus: einheitAus, dokumentSetzen: dokumentSetzen, istEinheit: istEinheit,
    kmZuSm: kmZuSm, strecke: strecke, reihenfolge: reihenfolge, durchschnitt: durchschnitt, durchschnittZeilen: durchschnittZeilen, text: text
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
