/* Geschwindigkeit aus dem GPS (seit 2.0.44): aktuell, Durchschnitt in Bewegung (Ø fahrend) und Durchschnitt am Tag (Ø Tag).
 * Nur Regeln, kein Speicher und kein Netz. Der Tag läuft von der ersten Bewegung bis zum Tagesabschluss.
 *  - Ø fahrend = gezählte Strecke geteilt durch die Zeit, in der sich das Fahrzeug wirklich bewegt hat.
 *  - Ø Tag     = gezählte Strecke geteilt durch die ganze Zeit seit der ersten Bewegung (mit Schleusen, Pausen und Stopps).
 * Gezählt wird nach denselben Regeln wie die GPS-Strecke (Genauigkeit, Lücken, glaubhafte Geschwindigkeit, Mindestabstand).
 * Zustand f: { tagDatum, startMs, km, fahrMs, letzter, bezug, aktuell, schlussMs, abgeschlossen, luecken, verworfen } */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var LUECKE_MS = 10 * 60 * 1000;
  var BEZUG_MS = 10 * 1000;      /* Ist keine Geschwindigkeit vom Gerät da, wird sie über mindestens so lange gerechnet. */
  var FRISCH_MS = 20 * 1000;     /* So lange gilt ein „aktueller“ Wert. */
  var MIN_MS = 60 * 1000;        /* Darunter zeigt die App noch keinen Durchschnitt. */
  var MIN_FAHR_KMH = 2;          /* Langsamer gilt die Strecke seit dem letzten gezählten Punkt als Stehen. */
  var KN_IN_KMH = 1.852;
  var MODI = ['aktuell', 'fahrend', 'tag'];  /* Wechselfeld: die Geschwindigkeiten. ETA, Rest und Gefahren stehen seit 2.0.62 fest auf Seite 1 (anzeige kann sie weiter liefern). */
  var EINHEIT_STANDARD = 'km';

  function neu() {
    return { tagDatum: null, startMs: null, km: 0, fahrMs: 0, letzter: null, bezug: null, aktuell: null, schlussMs: null, abgeschlossen: false, luecken: 0, verworfen: 0 };
  }
  function kopie(f) {
    var s = {}, k;
    for (k in f) if (Object.prototype.hasOwnProperty.call(f, k)) s[k] = f[k];
    return s;
  }
  function z2(n) { return (n < 10 ? '0' : '') + n; }
  function lokalesDatum(ms) { var d = new Date(ms); return d.getFullYear() + '-' + z2(d.getMonth() + 1) + '-' + z2(d.getDate()); }

  function gueltig(b, l) { return typeof b === 'number' && typeof l === 'number' && isFinite(b) && isFinite(l) && Math.abs(b) <= 90 && Math.abs(l) <= 180; }
  function abstandKm(b1, l1, b2, l2) {
    var R = 6371, rad = Math.PI / 180, dB = (b2 - b1) * rad, dL = (l2 - l1) * rad;
    var a = Math.sin(dB / 2) * Math.sin(dB / 2) + Math.cos(b1 * rad) * Math.cos(b2 * rad) * Math.sin(dL / 2) * Math.sin(dL / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
  }

  /*
   * Ein GPS-Punkt. fix: { breite, laenge, genauigkeit, zeitMs, geschwindigkeit (m/s vom Gerät oder null) }.
   * welt: 'land' | 'wasser' | 'luft'. zaehlen: false = das Fahrzeug ist nicht „in Fahrt“, es wird nichts gezählt, nur die Position gemerkt.
   * Gibt immer einen neuen Zustand zurück, der alte bleibt unverändert.
   */
  function punkt(alt, fix, welt, zaehlen) {
    var f = kopie(alt || neu());
    if (!fix || !gueltig(fix.breite, fix.laenge) || typeof fix.zeitMs !== 'number') return f;
    var gen = typeof fix.genauigkeit === 'number' && isFinite(fix.genauigkeit) ? fix.genauigkeit : 25;
    if (gen > 50) { f.verworfen = (f.verworfen || 0) + 1; return f; }
    var jetzt = { breite: fix.breite, laenge: fix.laenge, zeitMs: fix.zeitMs, genauigkeit: gen };

    /* Aktuelle Geschwindigkeit: bevorzugt vom Gerät (Doppler), sonst aus zwei Punkten im Abstand von mindestens 10 Sekunden. */
    var v = typeof fix.geschwindigkeit === 'number' && isFinite(fix.geschwindigkeit) && fix.geschwindigkeit >= 0 ? fix.geschwindigkeit * 3.6 : null;
    if (v === null) {
      if (f.bezug && jetzt.zeitMs - f.bezug.zeitMs >= BEZUG_MS && jetzt.zeitMs - f.bezug.zeitMs <= LUECKE_MS) {
        var dm = abstandKm(f.bezug.breite, f.bezug.laenge, jetzt.breite, jetzt.laenge) * 1000;
        var rauschen = Math.max(15, Math.min(100, f.bezug.genauigkeit + gen));
        v = dm < rauschen ? 0 : (dm / 1000) / ((jetzt.zeitMs - f.bezug.zeitMs) / 3600000);
        f.bezug = jetzt;
      } else if (!f.bezug || jetzt.zeitMs - f.bezug.zeitMs > LUECKE_MS) { f.bezug = jetzt; }
    } else { f.bezug = jetzt; }
    if (v !== null) { f.aktuell = { kmh: v < 1 ? 0 : v, zeitMs: jetzt.zeitMs }; }

    /* Strecke und Fahrzeit */
    if (zaehlen === false || !f.letzter) { f.letzter = jetzt; return f; }
    if (jetzt.zeitMs - f.letzter.zeitMs > LUECKE_MS) { f.luecken = (f.luecken || 0) + 1; f.letzter = jetzt; return f; }
    var d = abstandKm(f.letzter.breite, f.letzter.laenge, jetzt.breite, jetzt.laenge) * 1000;
    var schwelle = Math.max(15, Math.min(100, f.letzter.genauigkeit + gen));
    if (d < schwelle) return f;
    var dt = jetzt.zeitMs - f.letzter.zeitMs;
    var stunden = dt / 3600000;
    var grenze = welt === 'wasser' ? 80 : 150;
    var kmh = stunden > 0 ? (d / 1000) / stunden : 0;
    if (stunden > 0 && kmh > grenze) { f.verworfen = (f.verworfen || 0) + 1; return f; }
    /* Wer vorher stand und jetzt losfährt, hat noch keine Fahrzeit: Der Weg seit dem letzten gezählten Punkt war langsamer als MIN_FAHR_KMH,
       das war Stehen mit Schwankung des GPS. Dann beginnt die Zählung hier neu, die Standzeit zählt nicht als Fahrzeit. */
    if (kmh < MIN_FAHR_KMH) { f.letzter = jetzt; return f; }
    /* Erste Bewegung: Der Tag beginnt, ein abgeschlossener Tag wird nicht fortgeführt, sondern beginnt neu. */
    if (f.abgeschlossen || f.startMs === null) {
      var frisch = neu();
      frisch.aktuell = f.aktuell; frisch.bezug = f.bezug; frisch.verworfen = 0;
      frisch.startMs = f.letzter.zeitMs; frisch.tagDatum = lokalesDatum(frisch.startMs);
      f = frisch;
    }
    f.km += d / 1000; f.fahrMs += dt; f.letzter = jetzt;
    return f;
  }

  /* Die Werte zu einem Zeitpunkt (Millisekunden). null heißt „noch nicht bekannt“. */
  function werte(f, jetztMs) {
    f = f || neu();
    var ende = f.abgeschlossen && typeof f.schlussMs === 'number' ? f.schlussMs : jetztMs;
    var gesamtMs = f.startMs === null ? 0 : Math.max(0, ende - f.startMs);
    var aktuell = f.aktuell && jetztMs - f.aktuell.zeitMs <= FRISCH_MS ? f.aktuell.kmh : null;
    return {
      aktuellKmh: aktuell,
      fahrendKmh: f.fahrMs >= MIN_MS ? f.km / (f.fahrMs / 3600000) : null,
      tagKmh: f.startMs !== null && gesamtMs >= MIN_MS ? f.km / (gesamtMs / 3600000) : null,
      km: f.km, fahrMs: f.fahrMs, gesamtMs: gesamtMs,
      gestartet: f.startMs !== null, abgeschlossen: !!f.abgeschlossen, tagDatum: f.tagDatum
    };
  }

  /* Der Tag ist abgeschlossen: Die Werte bleiben stehen, bis die nächste Bewegung einen neuen Tag beginnt. */
  function abschliessen(f, jetztMs) {
    var s = kopie(f || neu());
    if (s.startMs === null || s.abgeschlossen) return s;
    s.abgeschlossen = true; s.schlussMs = jetztMs;
    return s;
  }

  /* Wasser und Luft in Knoten, sonst in km/h */
  function einheit(welt) { return welt === 'wasser' || welt === 'luft' ? 'kn' : 'km/h'; }
  function inEinheit(kmh, welt) { return kmh === null || kmh === undefined ? null : (einheit(welt) === 'kn' ? kmh / KN_IN_KMH : kmh); }
  function zahlText(n) { return (Math.round(n * 10) / 10).toLocaleString('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 1 }); }

  function naechsterModus(modus) {
    var i = MODI.indexOf(modus);
    return MODI[(i + 1) % MODI.length];
  }

  /* Die Anzeige im Wechselfeld: { name, wert } zum Beispiel { name: 'Aktuell', wert: '12,3 km/h' }; ohne Wert steht „–“.
     opt (seit 2.0.61): { einheit: 'km' | 'sm', eta: Ergebnis von MM.Etappen.etaAusKontext oder null, jetztMs } */
  function anzeige(w, welt, modus, opt) {
    var name = { aktuell: 'Aktuell', fahrend: 'Ø fahrend', tag: 'Ø Tag', eta: 'ETA', rest: 'Rest', gefahren: 'Gefahren' }[modus] || 'Aktuell';
    opt = opt || {};
    var sys = einheitGueltig(opt.einheit);
    /* Ohne gewählte Einheit gilt wie bisher die Einheit der Welt (Wasser und Luft kn, sonst km/h). Das Cockpit gibt seit 2.0.61 immer die gewählte Einheit mit. */
    if (sys === null) sys = einheit(welt) === 'kn' ? 'sm' : 'km';
    if (modus === 'eta') {
      var e = opt.eta && opt.eta.eta && opt.eta.eta.ok ? opt.eta.eta : null;
      if (!e) return { name: name, wert: '–' };
      if (typeof e.etaMs === 'number') return { name: name, wert: uhrText(e.etaMs, opt.jetztMs) };
      return { name: name, wert: dauerText(e.fahrzeitMin * 60000) + ' Fahrzeit' };
    }
    if (modus === 'rest') {
      var rk = opt.eta && typeof opt.eta.restKm === 'number' ? opt.eta.restKm : null;
      return { name: name, wert: rk === null ? '–' : streckeEinheitText(rk, sys) };
    }
    if (modus === 'gefahren') return { name: name, wert: w.gestartet ? streckeEinheitText(w.km, sys) : '–' };
    var kmh = modus === 'fahrend' ? w.fahrendKmh : (modus === 'tag' ? w.tagKmh : w.aktuellKmh);
    return { name: name, wert: kmh === null || kmh === undefined ? '–' : geschwindigkeitText(kmh, sys) };
  }

  /* ---------- Einheit km oder sm (seit 2.0.61) ----------
   * Der Nutzer schaltet im Cockpit zwischen km (km/h) und sm (kn) um, die Wahl wird auf dem Gerät gemerkt. Sie gilt für Geschwindigkeit, ETA,
   * Rest und Gefahren, auch auf der Tag-Seite und nach dem Ablegen. Das Logbuch bleibt bei seinen eigenen Regeln (eintragText). */
  function einheitGueltig(wert) { return wert === 'km' || wert === 'sm' ? wert : null; }
  function naechsteEinheit(wert) { return einheitGueltig(wert) === 'km' ? 'sm' : 'km'; }
  function geschwEinheit(sys) { return einheitGueltig(sys) === 'sm' ? 'kn' : 'km/h'; }
  function geschwindigkeitText(kmh, sys) {
    var s = einheitGueltig(sys) || EINHEIT_STANDARD;
    return zahlText(s === 'sm' ? kmh / KN_IN_KMH : kmh) + ' ' + geschwEinheit(s);
  }
  function streckeEinheitText(km, sys) {
    var s = einheitGueltig(sys) || EINHEIT_STANDARD;
    return zahlText(s === 'sm' ? km / KN_IN_KMH : km) + ' ' + s;
  }
  /* Uhrzeit der ETA; an einem anderen Tag als jetzt steht das Datum davor. */
  function uhrText(ms, jetztMs) {
    var d = new Date(ms);
    var t = z2(d.getHours()) + ':' + z2(d.getMinutes()) + ' Uhr';
    if (typeof jetztMs === 'number' && lokalesDatum(ms) !== lokalesDatum(jetztMs)) t = z2(d.getDate()) + '.' + z2(d.getMonth() + 1) + '. ' + t;
    return t;
  }

  function dauerText(ms) {
    var min = Math.round(ms / 60000), h = Math.floor(min / 60), m = min % 60;
    return h ? h + ' h ' + z2(m) + ' min' : m + ' min';
  }
  function streckeText(km, welt) {
    if (welt === 'wasser' || welt === 'luft') return zahlText(km / 1.852) + ' sm';
    return zahlText(km) + ' km';
  }

  /*
   * Der Text für den Logbuch-Eintrag „Geschwindigkeit“.
   * art: 'tag' (beim Tagesabschluss) oder 'rhythmus' (Zwischenwert im Rhythmus der automatischen Einträge).
   */
  function eintragText(w, welt, art) {
    var e = einheit(welt), t = [];
    function v(kmh, name) { var n = inEinheit(kmh, welt); t.push(name + ' ' + (n === null ? 'noch offen' : zahlText(n) + ' ' + e)); }
    if (art === 'rhythmus') v(w.aktuellKmh, 'aktuell');
    v(w.fahrendKmh, 'Ø fahrend');
    v(w.tagKmh, 'Ø Tag');
    t.push('Strecke ' + streckeText(w.km, welt));
    t.push('Fahrzeit ' + dauerText(w.fahrMs));
    t.push('Gesamtzeit ' + dauerText(w.gesamtMs));
    return (art === 'tag' ? 'Geschwindigkeit (Tagesabschluss): ' : 'Geschwindigkeit (automatisch): ') + t.join(', ') + '. Aus den GPS-Punkten gerechnet, Luftlinie von Punkt zu Punkt.';
  }

  /* Wann war der letzte Logbuch-Eintrag „Geschwindigkeit“ (Millisekunden) oder null. Wird immer aus den Ereignissen gelesen. */
  function letzterEintragMs(ereignisse) {
    var letzte = null;
    (ereignisse || []).forEach(function (e) {
      if (!MM.Logbuch || !MM.Logbuch.istGeschwindigkeitsArt(e.artName)) return;
      var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(e.datum || '')), t = /^(\d{2}):(\d{2})/.exec(String(e.zeit || ''));
      if (!m) return;
      var ms = new Date(+m[1], +m[2] - 1, +m[3], t ? +t[1] : 0, t ? +t[2] : 0, 0, 0).getTime();
      if (letzte === null || ms > letzte) letzte = ms;
    });
    return letzte;
  }

  /* Ist ein Zwischenwert fällig? Gleiche Regel wie beim Wetter: Rhythmus in Minuten (0 = aus), letzter Eintrag, letzter Versuch. */
  function faellig(minuten, letzteMs, versuchMs, jetztMs) {
    if (!(minuten > 0)) return false;
    if (versuchMs !== null && versuchMs !== undefined && jetztMs - versuchMs < 60000) return false;
    if (letzteMs === null || letzteMs === undefined) return true;
    return jetztMs - letzteMs >= minuten * 60000;
  }

  MM.Fahrt = {
    EINHEIT_STANDARD: EINHEIT_STANDARD, einheitGueltig: einheitGueltig, naechsteEinheit: naechsteEinheit, geschwEinheit: geschwEinheit,
    geschwindigkeitText: geschwindigkeitText, streckeEinheitText: streckeEinheitText, uhrText: uhrText,
    MODI: MODI, MIN_FAHR_KMH: MIN_FAHR_KMH, LUECKE_MS: LUECKE_MS, FRISCH_MS: FRISCH_MS, MIN_MS: MIN_MS,
    neu: neu, punkt: punkt, werte: werte, abschliessen: abschliessen, einheit: einheit, inEinheit: inEinheit,
    naechsterModus: naechsterModus, anzeige: anzeige, eintragText: eintragText, dauerText: dauerText,
    letzterEintragMs: letzterEintragMs, faellig: faellig, lokalesDatum: lokalesDatum
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
