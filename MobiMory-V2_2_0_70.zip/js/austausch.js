/*
 * Import und Export, Schritt 8b: Tabellen aus Excel (.xlsx) und CSV lesen und schreiben.
 * Hier steht nur Rechnung auf Bytes und Texten. Das Speichern steht in daten.js.
 *
 * Grundsätze:
 *  - Kein Fremdprogramm. Excel-Dateien sind ZIP-Dateien mit XML darin, beides lesen und schreiben wir selbst.
 *    Zum Entpacken nutzt der Browser seine eigene Funktion (DecompressionStream), sie gibt es in den heutigen Browsern.
 *  - Lesen ist großzügig: deutsche Zahlen („1.234,5“), deutsche Daten („03.11.2026“), Einheiten im Feld („3.500 kg“),
 *    Trennzeichen Semikolon, Komma oder Tabulator, Zeichensatz UTF-8 oder Windows (so speichert das deutsche Excel CSV).
 *  - Schreiben ist so, dass deutsches Excel die Datei ohne Umwege öffnet: CSV mit Semikolon und Zeichen für UTF-8,
 *    Zahlen mit Komma, Daten als TT.MM.JJJJ. Excel-Dateien enthalten echte Zahlen und echte Daten.
 *  - Eine Zelle aus dem Programm ist ein Text, eine Zahl oder ein Datum { d: 'JJJJ-MM-TT' }.
 *  - Texte, die mit = + - @ beginnen, bekommen beim Schreiben ein Hochkomma davor, damit Excel sie nicht als Formel ausführt.
 *    Beim Lesen wird dieses Hochkomma wieder entfernt.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  var MAX_ZEILEN = 20000;
  var MAX_SPALTEN = 200;
  var MAX_TEIL = 60 * 1024 * 1024;

  function fehler(code, text) { var e = new Error(text); e.code = code; return e; }

  /* ---------- Namen vergleichen ---------- */
  /* Für den Vergleich von Überschriften: klein, ohne Umlaute, ohne Sonderzeichen, ohne Klammern am Ende („Länge (m)“ = „Länge“). */
  function norm(s) {
    s = String(s == null ? '' : s).toLowerCase();
    s = s.replace(/\([^)]*\)/g, ' ');
    s = s.replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
    return s.replace(/[^a-z0-9]/g, '');
  }
  function normMitKlammer(s) {
    s = String(s == null ? '' : s).toLowerCase().replace(/ä/g, 'ae').replace(/ö/g, 'oe').replace(/ü/g, 'ue').replace(/ß/g, 'ss');
    return s.replace(/[^a-z0-9]/g, '');
  }

  /* ---------- Text aus Bytes ---------- */
  function textDekodieren(bytes) {
    if (bytes.length >= 2 && bytes[0] === 0xFF && bytes[1] === 0xFE) return new TextDecoder('utf-16le').decode(bytes.subarray(2));
    if (bytes.length >= 2 && bytes[0] === 0xFE && bytes[1] === 0xFF) return new TextDecoder('utf-16be').decode(bytes.subarray(2));
    try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
    catch (e) { return new TextDecoder('windows-1252').decode(bytes); }
  }

  /* ---------- CSV ---------- */
  function trennzeichen(text) {
    var zaehl = { ';': 0, ',': 0, '\t': 0 }, inQ = false, i, c;
    for (i = 0; i < text.length; i++) {
      c = text.charAt(i);
      if (c === '"') inQ = !inQ;
      else if (!inQ && (c === '\n' || c === '\r')) break;
      else if (!inQ && zaehl[c] !== undefined) zaehl[c]++;
    }
    var best = ';', n = zaehl[';'];
    if (zaehl['\t'] > n) { best = '\t'; n = zaehl['\t']; }
    if (zaehl[','] > n) { best = ','; n = zaehl[',']; }
    return best;
  }

  function csvLesen(text) {
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    var tz = trennzeichen(text);
    var zeilen = [], zeile = [], feld = '', inQ = false, i, c;
    for (i = 0; i < text.length; i++) {
      c = text.charAt(i);
      if (inQ) {
        if (c === '"') { if (text.charAt(i + 1) === '"') { feld += '"'; i++; } else inQ = false; }
        else feld += c;
      } else if (c === '"' && feld === '') {
        inQ = true;
      } else if (c === tz) {
        zeile.push(feld); feld = '';
      } else if (c === '\r' || c === '\n') {
        if (c === '\r' && text.charAt(i + 1) === '\n') i++;
        zeile.push(feld); feld = ''; zeilen.push(zeile); zeile = [];
        if (zeilen.length > MAX_ZEILEN) throw fehler('zu_gross', 'Die Tabelle hat mehr als ' + MAX_ZEILEN + ' Zeilen. Bitte in kleinere Dateien teilen.');
      } else feld += c;
    }
    if (feld !== '' || zeile.length) { zeile.push(feld); zeilen.push(zeile); }
    return leereZeilenWeg(zeilen);
  }

  function leereZeilenWeg(zeilen) {
    return zeilen.filter(function (z) { return z.some(function (x) { return String(x == null ? '' : x).trim() !== ''; }); });
  }

  function iso2Datum(iso) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || ''); return m ? m[3] + '.' + m[2] + '.' + m[1] : ''; }

  function textZelle(s) {
    if (/^[=+\-@\t\r]/.test(s) && !/^[+-]?\d/.test(s)) return "'" + s;
    return s;
  }

  function csvFeld(z, tz) {
    var s;
    if (z === null || z === undefined) s = '';
    else if (typeof z === 'number') s = isFinite(z) ? String(z).replace('.', ',') : '';
    else if (typeof z === 'object' && z.d !== undefined) s = iso2Datum(z.d);
    else s = textZelle(String(z));
    if (s.indexOf('"') >= 0 || s.indexOf(tz) >= 0 || /[\r\n]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  /* Gibt Bytes zurück: Zeichen für UTF-8 (damit Excel Umlaute richtig zeigt), Semikolon, Zeilenende Windows. */
  function csvSchreiben(zeilen) {
    var text = zeilen.map(function (z) { return z.map(function (x) { return csvFeld(x, ';'); }).join(';'); }).join('\r\n') + '\r\n';
    var b = new TextEncoder().encode(text);
    var res = new Uint8Array(b.length + 3);
    res[0] = 0xEF; res[1] = 0xBB; res[2] = 0xBF; res.set(b, 3);
    return res;
  }

  /* ---------- ZIP ---------- */
  var CRC_TABELLE = null;
  function crc32(bytes) {
    if (!CRC_TABELLE) {
      CRC_TABELLE = new Uint32Array(256);
      for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1); CRC_TABELLE[n] = c >>> 0; }
    }
    var crc = 0xFFFFFFFF;
    for (var i = 0; i < bytes.length; i++) crc = CRC_TABELLE[(crc ^ bytes[i]) & 255] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  /* Dateien ohne Kompression in eine ZIP-Datei packen. dateien = [{ name, bytes }] */
  function zipSchreiben(dateien) {
    var enc = new TextEncoder(), teile = [], zentral = [], pos = 0;
    dateien.forEach(function (d) {
      var name = enc.encode(d.name), crc = crc32(d.bytes), n = d.bytes.length;
      var lokal = new Uint8Array(30 + name.length), dv = new DataView(lokal.buffer);
      dv.setUint32(0, 0x04034b50, true); dv.setUint16(4, 20, true); dv.setUint16(6, 0x0800, true); dv.setUint16(8, 0, true);
      dv.setUint16(10, 0, true); dv.setUint16(12, 0x0021, true); dv.setUint32(14, crc, true); dv.setUint32(18, n, true); dv.setUint32(22, n, true);
      dv.setUint16(26, name.length, true); dv.setUint16(28, 0, true); lokal.set(name, 30);
      var zen = new Uint8Array(46 + name.length), zv = new DataView(zen.buffer);
      zv.setUint32(0, 0x02014b50, true); zv.setUint16(4, 20, true); zv.setUint16(6, 20, true); zv.setUint16(8, 0x0800, true); zv.setUint16(10, 0, true);
      zv.setUint16(12, 0, true); zv.setUint16(14, 0x0021, true); zv.setUint32(16, crc, true); zv.setUint32(20, n, true); zv.setUint32(24, n, true);
      zv.setUint16(28, name.length, true); zv.setUint32(42, pos, true); zen.set(name, 46);
      teile.push(lokal, d.bytes); zentral.push(zen); pos += lokal.length + n;
    });
    var zentralLaenge = zentral.reduce(function (s, z) { return s + z.length; }, 0);
    var ende = new Uint8Array(22), ev = new DataView(ende.buffer);
    ev.setUint32(0, 0x06054b50, true); ev.setUint16(8, dateien.length, true); ev.setUint16(10, dateien.length, true);
    ev.setUint32(12, zentralLaenge, true); ev.setUint32(16, pos, true);
    var alle = teile.concat(zentral, [ende]), gesamt = alle.reduce(function (s, t) { return s + t.length; }, 0), res = new Uint8Array(gesamt), p = 0;
    alle.forEach(function (t) { res.set(t, p); p += t.length; });
    return res;
  }

  function inflate(bytes) {
    if (typeof global.DecompressionStream !== 'function' || typeof global.Response !== 'function') {
      return Promise.reject(fehler('browser', 'Dieser Browser kann Excel-Dateien nicht öffnen. Bitte die Tabelle in Excel als CSV speichern und die CSV-Datei nehmen.'));
    }
    var strom = new global.Blob([bytes]).stream().pipeThrough(new global.DecompressionStream('deflate-raw'));
    return new global.Response(strom).arrayBuffer().then(function (b) { return new Uint8Array(b); });
  }

  /* Liest die Teile einer ZIP-Datei: gibt eine Funktion zurück, die einen Teil nach Name holt (Promise von Bytes oder null). */
  function zipOeffnen(bytes) {
    var dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength), ende = -1, i;
    for (i = bytes.length - 22; i >= Math.max(0, bytes.length - 22 - 65535); i--) { if (dv.getUint32(i, true) === 0x06054b50) { ende = i; break; } }
    if (ende < 0) throw fehler('zip', 'Das ist keine gültige Excel-Datei.');
    var anzahl = dv.getUint16(ende + 10, true), pos = dv.getUint32(ende + 16, true), teile = {};
    if (anzahl > 5000) throw fehler('zip', 'Das ist keine gültige Excel-Datei.');
    for (i = 0; i < anzahl; i++) {
      if (pos + 46 > bytes.length || dv.getUint32(pos, true) !== 0x02014b50) throw fehler('zip', 'Das ist keine gültige Excel-Datei.');
      var methode = dv.getUint16(pos + 10, true), komp = dv.getUint32(pos + 20, true), unkomp = dv.getUint32(pos + 24, true);
      var nl = dv.getUint16(pos + 28, true), el = dv.getUint16(pos + 30, true), kl = dv.getUint16(pos + 32, true), lokal = dv.getUint32(pos + 42, true);
      var name = new TextDecoder().decode(bytes.subarray(pos + 46, pos + 46 + nl));
      teile[name] = { methode: methode, komp: komp, unkomp: unkomp, lokal: lokal };
      pos += 46 + nl + el + kl;
    }
    return function (name) {
      var t = teile[name];
      if (!t) return Promise.resolve(null);
      if (t.unkomp > MAX_TEIL) return Promise.reject(fehler('zu_gross', 'Die Excel-Datei ist zu groß zum Öffnen.'));
      var p = t.lokal;
      if (p + 30 > bytes.length || dv.getUint32(p, true) !== 0x04034b50) return Promise.reject(fehler('zip', 'Das ist keine gültige Excel-Datei.'));
      var start = p + 30 + dv.getUint16(p + 26, true) + dv.getUint16(p + 28, true);
      var roh = bytes.subarray(start, start + t.komp);
      if (t.methode === 0) return Promise.resolve(roh);
      if (t.methode === 8) return inflate(roh);
      return Promise.reject(fehler('zip', 'Das ist keine gültige Excel-Datei.'));
    };
  }

  /* ---------- XML ---------- */
  function xmlEntschaerfen(s) {
    return s.replace(/&(#x[0-9a-fA-F]+|#\d+|amp|lt|gt|quot|apos);/g, function (m, e) {
      if (e === 'amp') return '&'; if (e === 'lt') return '<'; if (e === 'gt') return '>'; if (e === 'quot') return '"'; if (e === 'apos') return "'";
      var n = e.charAt(1) === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      try { return String.fromCodePoint(n); } catch (x) { return ''; }
    });
  }
  function xmlMaskieren(s) {
    return String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function attribute(tag) {
    var a = {}, re = /([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g, m;
    while ((m = re.exec(tag))) a[m[1]] = xmlEntschaerfen(m[2] !== undefined ? m[2] : m[3]);
    return a;
  }
  function textInnen(xml) {
    xml = xml.replace(/<rPh\b[\s\S]*?<\/rPh>/g, '');
    var res = '', re = /<t\b[^>]*?(?:\/>|>([\s\S]*?)<\/t>)/g, m;
    while ((m = re.exec(xml))) res += m[1] ? xmlEntschaerfen(m[1]) : '';
    return res;
  }

  /* Ist ein Zahlenformat ein Datum? */
  function istDatumFormat(id, code) {
    if ((id >= 14 && id <= 22) || (id >= 27 && id <= 36) || (id >= 45 && id <= 47) || (id >= 50 && id <= 58)) return true;
    if (!code) return false;
    var c = code.replace(/"[^"]*"/g, '').replace(/\\./g, '').replace(/\[[^\]]*\]/g, '');
    return /[dyhs]/i.test(c);
  }

  function serialZuIso(n) {
    var tage = Math.floor(n);
    if (tage < 1 || tage > 2958465) return null;
    var d = new Date(Math.round((tage - 25569) * 86400000));
    function z(x) { return (x < 10 ? '0' : '') + x; }
    return d.getUTCFullYear() + '-' + z(d.getUTCMonth() + 1) + '-' + z(d.getUTCDate());
  }

  function spalteIndex(ref) {
    var m = /^([A-Z]+)/i.exec(ref || ''); if (!m) return -1;
    var s = m[1].toUpperCase(), n = 0;
    for (var i = 0; i < s.length; i++) n = n * 26 + (s.charCodeAt(i) - 64);
    return n - 1;
  }
  function spalteName(i) { var s = ''; i++; while (i > 0) { var r = (i - 1) % 26; s = String.fromCharCode(65 + r) + s; i = Math.floor((i - 1) / 26); } return s; }

  /* ---------- Excel lesen ---------- */
  function xlsxLesen(bytes) {
    var holen;
    try { holen = zipOeffnen(bytes); } catch (e) { return Promise.reject(e); }
    function text(name) { return holen(name).then(function (b) { return b ? new TextDecoder().decode(b) : null; }); }
    return Promise.all([text('xl/workbook.xml'), text('xl/_rels/workbook.xml.rels'), text('xl/sharedStrings.xml'), text('xl/styles.xml')]).then(function (r) {
      if (!r[0]) throw fehler('format', 'Das ist keine Excel-Datei (.xlsx). Bitte in Excel mit „Speichern unter“ als „Excel-Arbeitsmappe (.xlsx)“ oder als CSV speichern.');
      var ziele = {};
      (r[1] || '').replace(/<Relationship\b[^>]*>/g, function (t) { var a = attribute(t); if (a.Id) ziele[a.Id] = a.Target || ''; return ''; });
      var blaetter = [];
      r[0].replace(/<sheet\b[^>]*>/g, function (t) {
        var a = attribute(t), ziel = ziele[a['r:id']];
        if (!ziel) return '';
        blaetter.push({ name: a.name || ('Blatt ' + (blaetter.length + 1)), pfad: ziel.charAt(0) === '/' ? ziel.slice(1) : 'xl/' + ziel });
        return '';
      });
      var gemeinsam = [];
      if (r[2]) {
        var re = /<si\b[^>]*?(?:\/>|>([\s\S]*?)<\/si>)/g, m;
        while ((m = re.exec(r[2]))) gemeinsam.push(m[1] ? textInnen(m[1]) : '');
      }
      var datumStil = {};
      if (r[3]) {
        var codes = {};
        r[3].replace(/<numFmt\b[^>]*>/g, function (t) { var a = attribute(t); codes[a.numFmtId] = a.formatCode; return ''; });
        var xfs = /<cellXfs\b[^>]*>([\s\S]*?)<\/cellXfs>/.exec(r[3]);
        if (xfs) {
          var idx = 0;
          xfs[1].replace(/<xf\b[^>]*>/g, function (t) { var a = attribute(t), id = parseInt(a.numFmtId || '0', 10); datumStil[idx] = istDatumFormat(id, codes[id]); idx++; return ''; });
        }
      }
      var ergebnis = [];
      return blaetter.reduce(function (kette, b) {
        return kette.then(function () {
          return text(b.pfad).then(function (xml) {
            ergebnis.push({ name: b.name, zeilen: xml ? blattLesen(xml, gemeinsam, datumStil) : [] });
          });
        });
      }, Promise.resolve()).then(function () { return ergebnis; });
    });
  }

  function blattLesen(xml, gemeinsam, datumStil) {
    var zeilen = [], re = /<row\b([^>]*?)(?:\/>|>([\s\S]*?)<\/row>)/g, m, laufZeile = 0;
    while ((m = re.exec(xml))) {
      var ra = attribute(m[1]), zi = ra.r ? parseInt(ra.r, 10) - 1 : laufZeile;
      laufZeile = zi + 1;
      if (zi < 0 || zi >= MAX_ZEILEN * 2 || !m[2]) continue;
      var zeile = [], lauf = 0, cre = /<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g, c;
      while ((c = cre.exec(m[2]))) {
        var ca = attribute(c[1]), sp = ca.r ? spalteIndex(ca.r) : lauf;
        lauf = sp + 1;
        if (sp < 0 || sp >= MAX_SPALTEN) continue;
        var inner = c[2] || '', wert = '', v = /<v\b[^>]*>([\s\S]*?)<\/v>/.exec(inner), t = ca.t || 'n';
        if (t === 'inlineStr') { var is = /<is\b[^>]*>([\s\S]*?)<\/is>/.exec(inner); wert = is ? textInnen(is[1]) : ''; }
        else if (!v) wert = '';
        else if (t === 's') wert = gemeinsam[parseInt(v[1], 10)] || '';
        else if (t === 'str') wert = xmlEntschaerfen(v[1]);
        else if (t === 'b') wert = v[1] === '1' ? 'Ja' : 'Nein';
        else if (t === 'e') wert = '';
        else if (t === 'd') wert = String(v[1]).slice(0, 10);
        else {
          var zahl = Number(v[1]);
          if (isNaN(zahl)) wert = xmlEntschaerfen(v[1]);
          else if (datumStil[parseInt(ca.s || '0', 10)]) wert = serialZuIso(zahl) || zahl;
          else wert = zahl;
        }
        zeile[sp] = wert;
      }
      for (var i = 0; i < zeile.length; i++) { if (zeile[i] === undefined) zeile[i] = ''; }
      zeilen[zi] = zeile;
    }
    var dicht = [];
    for (var j = 0; j < zeilen.length; j++) { if (zeilen[j]) dicht.push(zeilen[j]); }
    return leereZeilenWeg(dicht);
  }

  /* ---------- Excel schreiben ---------- */
  var XMLK = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
  var NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';

  function blattName(name, benutzt) {
    var n = String(name || 'Blatt').replace(/[\[\]:*?\/\\]/g, ' ').trim().slice(0, 31) || 'Blatt', k = 2, basis = n;
    while (benutzt.indexOf(n.toLowerCase()) >= 0) { n = basis.slice(0, 28) + ' ' + k; k++; }
    benutzt.push(n.toLowerCase());
    return n;
  }

  function isoZuSerial(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || '');
    return m ? Date.UTC(+m[1], +m[2] - 1, +m[3]) / 86400000 + 25569 : null;
  }

  function blattXml(zeilen) {
    var breiten = [];
    var daten = zeilen.map(function (z, zi) {
      var zellen = z.map(function (x, si) {
        if (x === null || x === undefined || x === '') return '';
        var ref = spalteName(si) + (zi + 1), len;
        if (typeof x === 'number') { if (!isFinite(x)) return ''; len = String(x).length; breiten[si] = Math.max(breiten[si] || 0, len); return '<c r="' + ref + '"><v>' + x + '</v></c>'; }
        if (typeof x === 'object' && x.d !== undefined) {
          var s = isoZuSerial(x.d);
          if (s === null) return '';
          breiten[si] = Math.max(breiten[si] || 0, 10);
          return '<c r="' + ref + '" s="1"><v>' + s + '</v></c>';
        }
        var t = String(x); len = Math.min(t.split(/\r?\n/)[0].length, 60);
        breiten[si] = Math.max(breiten[si] || 0, len);
        return '<c r="' + ref + '" t="inlineStr"' + (zi === 0 ? ' s="2"' : '') + '><is><t xml:space="preserve">' + xmlMaskieren(zi === 0 ? t : textZelle(t)) + '</t></is></c>';
      }).join('');
      return '<row r="' + (zi + 1) + '">' + zellen + '</row>';
    }).join('');
    var cols = breiten.map(function (b, i) { return '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + Math.max(8, Math.min(60, (b || 8) + 2)) + '" customWidth="1"/>'; }).join('');
    return XMLK + '<worksheet xmlns="' + NS + '"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>' +
      (cols ? '<cols>' + cols + '</cols>' : '') + '<sheetData>' + daten + '</sheetData></worksheet>';
  }

  /* blaetter = [{ name, zeilen }], die erste Zeile ist die Kopfzeile. Gibt Bytes einer .xlsx-Datei zurück. */
  function xlsxSchreiben(blaetter) {
    var enc = new TextEncoder(), benutzt = [], dateien = [], namen = [];
    blaetter.forEach(function (b) { namen.push(blattName(b.name, benutzt)); });
    function datei(name, text) { dateien.push({ name: name, bytes: enc.encode(text) }); }
    datei('[Content_Types].xml', XMLK + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' +
      '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
      '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
      blaetter.map(function (b, i) { return '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'; }).join('') + '</Types>');
    datei('_rels/.rels', XMLK + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    datei('xl/workbook.xml', XMLK + '<workbook xmlns="' + NS + '" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' +
      namen.map(function (n, i) { return '<sheet name="' + xmlMaskieren(n) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>'; }).join('') + '</sheets></workbook>');
    datei('xl/_rels/workbook.xml.rels', XMLK + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      blaetter.map(function (b, i) { return '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>'; }).join('') +
      '<Relationship Id="rId' + (blaetter.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
    datei('xl/styles.xml', XMLK + '<styleSheet xmlns="' + NS + '"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>' +
      '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>' +
      '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>' +
      '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
      '<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="14" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>' +
      '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>');
    blaetter.forEach(function (b, i) { datei('xl/worksheets/sheet' + (i + 1) + '.xml', blattXml(b.zeilen)); });
    return zipSchreiben(dateien);
  }

  /* ---------- Datei erkennen und lesen ---------- */
  /* Gibt { art: 'xlsx' | 'csv', blaetter: [{ name, zeilen }] } zurück. Zeilen sind Listen von Zellen (Text oder Zahl). */
  function dateiLesen(bytes) {
    if (!bytes || !bytes.length) return Promise.reject(fehler('leer', 'Die Datei ist leer.'));
    if (bytes.length > 4 && bytes[0] === 0xD0 && bytes[1] === 0xCF && bytes[2] === 0x11 && bytes[3] === 0xE0) {
      return Promise.reject(fehler('xls', 'Das ist das alte Excel-Format (.xls). Bitte in Excel mit „Speichern unter“ als „Excel-Arbeitsmappe (.xlsx)“ oder als CSV speichern.'));
    }
    if (bytes[0] === 0x50 && bytes[1] === 0x4B) {
      return xlsxLesen(bytes).then(function (blaetter) {
        var mitDaten = blaetter.filter(function (b) { return b.zeilen.length; });
        if (!mitDaten.length) throw fehler('leer', 'In der Excel-Datei steht nichts.');
        return { art: 'xlsx', blaetter: mitDaten };
      });
    }
    try {
      var zeilen = csvLesen(textDekodieren(bytes));
      if (!zeilen.length) return Promise.reject(fehler('leer', 'In der Datei steht nichts.'));
      return Promise.resolve({ art: 'csv', blaetter: [{ name: 'CSV', zeilen: zeilen }] });
    } catch (e) { return Promise.reject(e); }
  }

  /* ---------- Spalten zuordnen ---------- */
  var SYNONYME = {
    bezeichnung: ['name', 'fahrzeug', 'bez', 'titel', 'fahrzeugname', 'objekt'],
    marke: ['hersteller', 'fabrikat', 'marke'],
    modell: ['model', 'fahrzeugmodell', 'baureihe', 'modellbezeichnung'],
    typ: ['type', 'variante', 'fahrzeugtyp'],
    baujahr: ['bj', 'jahrgang', 'baujahr'],
    erstzulassung: ['ez', 'erstzul', 'zulassung', 'erstzulassungsdatum', 'datumerstzulassung', 'zulassungsdatum'],
    kennzeichen: ['amtlkennzeichen', 'amtlichteskennzeichen', 'amtlicheskennzeichen', 'kfzkennzeichen', 'nummernschild', 'kz', 'polkennzeichen', 'kennz'],
    registriernummer: ['registrierungsnummer', 'bootsnummer', 'registrierung', 'segelnummer', 'registriernr', 'regnr'],
    fin: ['fahrgestellnummer', 'fahrzeugidentnummer', 'fahrzeugidentifizierungsnummer', 'vin', 'chassisnummer', 'fgnr'],
    hin: ['rumpfnummer', 'hullidentificationnumber', 'hullid', 'bootsidentnummer', 'hullidentnummer'],
    laenge: ['luea', 'laengeueberall', 'laengem', 'laengeinm'],
    breite: ['breitem', 'breiteinm', 'beam'],
    hoehe: ['hoeheinm', 'hoehem'],
    tiefgang: ['draft', 'tiefgangm'],
    durchfahrtshoehe: ['durchfahrtshoehem', 'durchfahrtshoeheinm', 'brueckenhoehe'],
    leergewicht: ['leermasse', 'eigengewicht', 'leergewichtinkg', 'leergewichtkg'],
    gesamtgewicht: ['zulgesamtgewicht', 'zulaessigesgesamtgewicht', 'zgg', 'gesamtmasse', 'zulaessigegesamtmasse', 'maxgewicht', 'zulgesamtmasse', 'gesamtgewichtinkg'],
    kraftstoff: ['treibstoff', 'antrieb', 'kraftstoffart', 'sprit'],
    hoechstgeschwindigkeit: ['vmax', 'topspeed', 'hoechstgeschw', 'hoechstgeschwindigkeitkmh'],
    reisegeschwindigkeit: ['reisetempo', 'marschfahrt', 'reisegeschw'],
    achsen: ['achszahl', 'anzahlachsen', 'anzahlderachsen'],
    mautklasse: ['mautkategorie']
  };
  var ART_SPALTE = ['art', 'fahrzeugart', 'kategorie', 'fahrzeugkategorie', 'gattung'];

  /*
   * Rät für jede Überschrift das passende Feld. felder = [{ key, label }]; Rückgabe: Liste mit einem key (oder '') je Spalte.
   * Ein Feld wird nur einer Spalte zugeordnet (die erste, die passt). '__art' steht für die Spalte mit der Fahrzeugart.
   */
  function spaltenRaten(kopf, felder) {
    var vergeben = {}, res = kopf.map(function () { return ''; });
    function passt(feld, n, nk) {
      if (feld.key === '__art') return ART_SPALTE.indexOf(n) >= 0;
      if (n === norm(feld.key) || n === norm(feld.label) || nk === normMitKlammer(feld.label)) return true;
      return (SYNONYME[feld.key] || []).indexOf(n) >= 0 || (SYNONYME[feld.key] || []).indexOf(nk) >= 0;
    }
    [0, 1].forEach(function (runde) {
      kopf.forEach(function (k, i) {
        if (res[i]) return;
        var n = norm(k), nk = normMitKlammer(k);
        if (!n) return;
        for (var j = 0; j < felder.length; j++) {
          var f = felder[j];
          if (vergeben[f.key]) continue;
          /* Runde 0: genaue Treffer; Runde 1: „Art“ nur, wenn sonst nichts passt (Art ist oft mehrdeutig) */
          if (runde === 0 && f.key === '__art') continue;
          if (runde === 1 && f.key !== '__art') continue;
          if (passt(f, n, nk)) { res[i] = f.key; vergeben[f.key] = true; break; }
        }
      });
    });
    return res;
  }

  /* ---------- Werte umwandeln ---------- */
  function ersterTeil(s) { return String(s).split(/\s+/)[0]; }

  function zahlText(feld, zelle) {
    if (typeof zelle === 'number') return String(zelle);
    var s = String(zelle).replace(/[\u00a0\s]/g, '');
    var m = /-?[\d.,]+/.exec(s);
    if (!m) return String(zelle).trim();
    var z = m[0], punkte = (z.match(/\./g) || []).length, kommas = (z.match(/,/g) || []).length;
    if (punkte && kommas) {
      var dez = z.lastIndexOf(',') > z.lastIndexOf('.') ? ',' : '.', tau = dez === ',' ? '.' : ',';
      z = z.split(tau).join('').replace(dez, '.');
    } else if (kommas > 1) {
      z = z.split(',').join('');
    } else if (kommas === 1) {
      z = z.replace(',', '.');
    } else if (punkte > 1) {
      z = z.split('.').join('');
    } else if (punkte === 1 && /^\d{1,3}\.\d{3}$/.test(z) && (feld.typ === 'ganzzahl' || feld.einheit === 'kg')) {
      z = z.replace('.', '');
    }
    if (feld.typ === 'ganzzahl' && /^\d+\.0+$/.test(z)) z = z.split('.')[0];
    return z;
  }

  function datumText(zelle) {
    if (typeof zelle === 'number') return serialZuIso(zelle) || String(zelle);
    var s = String(zelle).trim(), m;
    if ((m = /^(\d{4})-(\d{1,2})-(\d{1,2})(?:[T\s].*)?$/.exec(s))) return m[1] + '-' + ('0' + m[2]).slice(-2) + '-' + ('0' + m[3]).slice(-2);
    if ((m = /^(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4}|\d{2})(?:[\s,].*)?$/.exec(s))) {
      var j = m[3];
      if (j.length === 2) { var heute = new Date().getFullYear() % 100; j = (parseInt(j, 10) <= heute + 1 ? '20' : '19') + j; }
      return j + '-' + ('0' + m[2]).slice(-2) + '-' + ('0' + m[1]).slice(-2);
    }
    return s;
  }

  var KRAFTSTOFF_SYN = { super: 'Benzin', otto: 'Benzin', e10: 'Benzin', e5: 'Benzin', ottokraftstoff: 'Benzin', lpg: 'Autogas (LPG)', autogas: 'Autogas (LPG)', gas: 'Autogas (LPG)', cng: 'Erdgas (CNG)', erdgas: 'Erdgas (CNG)',
    strom: 'Elektro', elektrisch: 'Elektro', electric: 'Elektro', ev: 'Elektro', dieselkraftstoff: 'Diesel', plugin: 'Hybrid', phev: 'Hybrid', h2: 'Wasserstoff' };

  function auswahlText(feld, zelle) {
    var s = String(zelle).trim(), n = norm(s);
    if (!n) return '';
    var opts = (feld.optionen || []).map(function (o) { return typeof o === 'string' ? { wert: o, label: o } : o; }), i;
    for (i = 0; i < opts.length; i++) { if (norm(opts[i].wert) === n || norm(opts[i].label) === n) return opts[i].wert; }
    if (feld.key === 'kraftstoff' && KRAFTSTOFF_SYN[n]) return KRAFTSTOFF_SYN[n];
    if (n.length >= 3) { for (i = 0; i < opts.length; i++) { if (norm(opts[i].label).indexOf(n) === 0 || norm(ersterTeil(opts[i].label)) === n) return opts[i].wert; } }
    return s;
  }

  /* Macht aus einer Zelle den Text, den die Prüfung der Daten erwartet. Fehler meldet die Prüfung selbst. */
  function wertUmwandeln(feld, zelle) {
    if (zelle === null || zelle === undefined) return '';
    if (typeof zelle === 'string') {
      zelle = zelle.trim();
      if (/^'[=+\-@]/.test(zelle)) zelle = zelle.slice(1);
      if (zelle === '') return '';
    }
    if (feld.typ === 'zahl' || feld.typ === 'ganzzahl') return zahlText(feld, zelle);
    if (feld.typ === 'datum') return datumText(zelle);
    if (feld.typ === 'auswahl') return auswahlText(feld, zelle);
    return String(zelle).trim();
  }

  /* Vergleichsschlüssel für Kennzeichen, FIN und Ähnliches: Groß, ohne Leerzeichen, Striche und Punkte. */
  function kennungNorm(s) { return String(s == null ? '' : s).toUpperCase().replace(/[\s\-.]/g, ''); }

  MM.Austausch = {
    MAX_ZEILEN: MAX_ZEILEN, MAX_SPALTEN: MAX_SPALTEN,
    norm: norm, textDekodieren: textDekodieren, csvLesen: csvLesen, csvSchreiben: csvSchreiben,
    zipSchreiben: zipSchreiben, zipOeffnen: zipOeffnen, crc32: crc32,
    xlsxLesen: xlsxLesen, xlsxSchreiben: xlsxSchreiben, dateiLesen: dateiLesen,
    spaltenRaten: spaltenRaten, wertUmwandeln: wertUmwandeln, kennungNorm: kennungNorm,
    spalteName: spalteName, iso2Datum: iso2Datum, ART_SPALTE: ART_SPALTE
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
