/*
 * Reiseorte, Schritt 8a: Beschreibung und Rechnung. Hier steht kein Speichern.
 *
 * Aus den V2-Festlegungen (04.11.2026):
 *  - Orte auf Reisen (Stellplätze, Campingplätze, Häfen, Ankerplätze) sind Orte in der einen Orte-Liste.
 *    Sie bekommen eine Position, eine Art und die Ausstattung. Es gibt keine zweite Liste.
 *  - Bei Ankunft, Anlegen oder Anker werfen kommt eine kleine Abfrage. Sie ist immer freiwillig und sperrt nichts.
 *    Ist der Ort bekannt, kommt sie mit den gespeicherten Angaben zur Bestätigung, sonst legt die App ihn neu an.
 *  - Jeder Besuch bleibt gespeichert: Datum, Aktivität, Ausstattung, Kosten. Daraus entsteht die Historie.
 *  - Kosten eines Besuchs stehen nur in der Kosten-Liste (variable Kosten, verknüpft mit Aktivität und Ort).
 *    Es gibt keine zweite Buchführung. Der zuletzt bezahlte Preis ist der neueste Posten des Ortes.
 *  - Auswertung pro Ort (wie oft, was bezahlt) und pro Reise (was hat sie gekostet, nach Art aufgegliedert).
 *  - Plan gegen Ist: Start, Ziel und Zwischenziele der Aktivität sind Orte. Bei der Ankunft zeigt die App, ob es
 *    das geplante Ziel war. Route, Fahrzeit und ETA gehören zu Schritt 9.
 *  - Später vielleicht teilbar: Ort, Art, Position, Ausstattung. Nur für den Nutzer: Kosten, Notizen, Besuche.
 *    Veröffentlicht wird nichts, das kommt erst mit Konten und Server.
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  /* Ab wie vielen Metern Abstand erkennt die App einen Ort nicht mehr wieder. Stellplätze und Häfen liegen oft dicht beisammen. */
  var ORT_RADIUS_M = 300;

  var BESUCH_STATUS = [
    { wert: 'besucht', label: 'Besucht' },
    { wert: 'uebersprungen', label: 'Nicht festgehalten' }
  ];

  /* Wie verhält sich ein Besuch zum Plan der Aktivität? */
  var GEPLANT = [
    { wert: 'ziel', label: 'Geplantes Ziel' },
    { wert: 'zwischenziel', label: 'Geplantes Zwischenziel' },
    { wert: 'start', label: 'Geplanter Start' },
    { wert: 'nein', label: 'Nicht geplant' }
  ];

  function runde(n) { return Math.round(n * 100) / 100; }
  function kopie(o) { var k = {}; for (var p in o) { k[p] = o[p]; } return k; }
  function labelVon(liste, wert) { for (var i = 0; i < liste.length; i++) { if (liste[i].wert === wert) return liste[i].label; } return null; }

  /* ---------- Felder eines Besuchs ---------- */
  /* Alle gespeicherten Felder, für den Verlauf. Die Optionen für Ort und Standort setzt die Datenschicht ein. */
  function besuchFelder() {
    return [
      { key: 'status', label: 'Status', typ: 'auswahl', optionen: BESUCH_STATUS.map(kopie) },
      { key: 'ortId', label: 'Ort', typ: 'auswahl', optionen: [] },
      { key: 'standortId', label: 'Standort', typ: 'auswahl', optionen: [] },
      { key: 'datum', label: 'Datum', typ: 'datum' },
      { key: 'zeit', label: 'Uhrzeit', typ: 'zeit' },
      { key: 'geplant', label: 'Im Plan', typ: 'auswahl', optionen: GEPLANT.map(kopie) },
      { key: 'ausstattung', label: 'Ausstattung beim Besuch', typ: 'mehrfach', optionen: MM.Orte.AUSSTATTUNG.map(kopie) },
      { key: 'ausstattungSonst', label: 'Weitere Ausstattung beim Besuch', typ: 'text' },
      { key: 'notiz', label: 'Notiz', typ: 'text' },
      { key: 'landstrom', label: 'Landstrom angeschlossen', typ: 'auswahl', optionen: [{ wert: 'ja', label: 'Ja' }, { wert: 'nein', label: 'Nein' }] },
      { key: 'landstromAutomat', label: 'Münzautomat für Landstrom', typ: 'auswahl', optionen: LANDSTROM_AUTOMAT.map(kopie) },
      { key: 'landstromMenge', label: 'Gekaufte Menge Landstrom', typ: 'zahl' },
      { key: 'ausgeblendet', label: 'Ausgeblendet', typ: 'auswahl', optionen: [{ wert: 'ja', label: 'Ja' }, { wert: 'nein', label: 'Nein' }] }
    ];
  }

  /*
   * Landstrom im Aufenthalt (seit 2.0.59). Mit dem Haken „Landstrom angeschlossen“ läuft die Landstrom-Zeit von der Ankunft bis zur Abfahrt
   * (die Dauer des Aufenthalts, abgeleitet aus dem Logbuch). Der Münzautomat verkauft Zeit oder kWh:
   *  - Zeit: Die App rechnet „Strom aus um …“ und die genaue Restzeit (solange es keine Abfahrt gibt).
   *  - kWh: Nur Betrag und gekaufte kWh. Ein Restguthaben gibt es nicht, dazu bräuchte es einen Zähler mit Geber.
   * Der Betrag wird ein Kostenposten (Art „Stromzuschlag“), er steht nicht im Besuch selbst.
   */
  var LANDSTROM_AUTOMAT = [{ wert: 'zeit', label: 'Zeit (in Stunden)' }, { wert: 'kwh', label: 'Strom (in kWh)' }];

  function zahlText(x) { return String(Math.round(x * 100) / 100).replace('.', ','); }
  function lokalAus(ms) {
    var d = new Date(ms);
    function z(n) { return (n < 10 ? '0' : '') + n; }
    return { datum: d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()), zeit: z(d.getHours()) + ':' + z(d.getMinutes()) };
  }

  /* werte: Werte des Besuchs; aufenthalt: Ergebnis von aufenthalt() oder null; jetztLokal: 'JJJJ-MM-TTThh:mm' (für die Restzeit). Ohne Haken: null. */
  function landstromInfo(werte, aufenthalt, jetztLokal) {
    if (!werte || werte.landstrom !== 'ja') return null;
    var automat = werte.landstromAutomat === 'zeit' || werte.landstromAutomat === 'kwh' ? werte.landstromAutomat : null;
    var menge = typeof werte.landstromMenge === 'number' ? werte.landstromMenge : null;
    var info = { zeit: aufenthalt ? aufenthalt.text : null, automat: automat, menge: menge, mengeText: null, aus: null, restMinuten: null, restText: null, abgelaufen: false };
    if (automat === 'kwh' && menge !== null) info.mengeText = zahlText(menge) + ' kWh gekauft';
    if (automat === 'zeit' && menge !== null) {
      info.mengeText = dauerText(Math.round(menge * 60)) + ' gekauft';
      var von = zeitpunktMs(werte.datum, werte.zeit) !== null ? zeitpunktMs(werte.datum, werte.zeit) : (aufenthalt ? zeitpunktMs(aufenthalt.von.datum, aufenthalt.von.zeit) : null);
      if (von !== null) {
        var ausMs = von + Math.round(menge * 3600000);
        info.aus = lokalAus(ausMs);
        var jetzt = jetztLokal ? new Date(jetztLokal).getTime() : NaN;
        if (!aufenthalt && !isNaN(jetzt)) {
          var rest = Math.round((ausMs - jetzt) / 60000);
          if (rest > 0) { info.restMinuten = rest; info.restText = 'Noch ' + dauerText(rest); }
          else { info.abgelaufen = true; info.restText = 'Die gekaufte Zeit ist abgelaufen.'; }
        }
      }
    }
    return info;
  }

  /* ---------- Was an einem Ort später teilbar wäre ---------- */
  /* Nur die teilbaren Felder eines Ortes (Name, Art, Position, Ausstattung). Alles andere gehört nur dem Nutzer. */
  function teilbarAuszug(werte) {
    var aus = { bezeichnung: werte && werte.bezeichnung ? werte.bezeichnung : null };
    MM.Orte.teilbareOrtFelder().forEach(function (k) {
      var v = werte ? werte[k] : null;
      aus[k] = v === undefined ? null : (Array.isArray(v) ? v.slice() : v);
    });
    return aus;
  }

  /* ---------- Ort in der Nähe erkennen ---------- */
  /*
   * Kandidaten aus Orten und Standorten, die eine Position haben und nicht ausgeblendet sind.
   *  orte: [{ objekt: { id }, aktuell: { werte } }], standorte: [{ objekt: { id, ortId }, aktuell: { werte } }]
   * Ergebnis: [{ ortId, standortId|null, name, breite, laenge }]
   */
  function kandidaten(orte, standorte) {
    var namen = {}, res = [];
    (orte || []).forEach(function (o) { namen[o.objekt.id] = o; });
    (orte || []).forEach(function (o) {
      var w = o.aktuell.werte;
      if (w.ausgeblendet === 'ja' || typeof w.positionBreite !== 'number' || typeof w.positionLaenge !== 'number') return;
      res.push({ ortId: o.objekt.id, standortId: null, name: w.bezeichnung, breite: w.positionBreite, laenge: w.positionLaenge });
    });
    (standorte || []).forEach(function (s) {
      var w = s.aktuell.werte, o = namen[s.objekt.ortId];
      if (!o || o.aktuell.werte.ausgeblendet === 'ja' || w.ausgeblendet === 'ja') return;
      if (typeof w.positionBreite !== 'number' || typeof w.positionLaenge !== 'number') return;
      res.push({ ortId: s.objekt.ortId, standortId: s.objekt.id, name: o.aktuell.werte.bezeichnung + ', ' + w.bezeichnung, breite: w.positionBreite, laenge: w.positionLaenge });
    });
    return res;
  }

  /* Der nächste Kandidat im Umfeld (radius in Metern), oder null. Gibt { ortId, standortId, name, abstand }. */
  function naechster(liste, breite, laenge, radius) {
    if (typeof breite !== 'number' || typeof laenge !== 'number') return null;
    var grenze = radius === undefined ? ORT_RADIUS_M : radius, beste = null;
    (liste || []).forEach(function (k) {
      var d = MM.Logbuch.entfernungMeter(breite, laenge, k.breite, k.laenge);
      if (d > grenze) return;
      if (!beste || d < beste.genau) beste = { ortId: k.ortId, standortId: k.standortId, name: k.name, abstand: Math.round(d), genau: d };
    });
    return beste ? { ortId: beste.ortId, standortId: beste.standortId, name: beste.name, abstand: beste.abstand } : null;
  }

  /* ---------- Plan gegen Ist ---------- */
  function planVorhanden(plan) {
    return !!(plan && (plan.startOrtId || plan.zielOrtId || (plan.zwischenzielIds && plan.zwischenzielIds.length)));
  }

  /* Wie steht ein Ort zum Plan? 'ziel', 'zwischenziel', 'start', 'nein' (Plan da, Ort nicht darin) oder null (kein Plan). */
  function planVergleich(plan, ortId) {
    if (!planVorhanden(plan) || !ortId) return null;
    if (plan.zielOrtId === ortId) return 'ziel';
    if ((plan.zwischenzielIds || []).indexOf(ortId) >= 0) return 'zwischenziel';
    if (plan.startOrtId === ortId) return 'start';
    return 'nein';
  }

  var PLAN_TEXT = {
    ziel: 'Das ist dein geplantes Ziel.',
    zwischenziel: 'Das ist eines deiner geplanten Zwischenziele.',
    start: 'Das ist dein geplanter Start.',
    nein: 'Dieser Ort war nicht geplant.'
  };
  function planText(art) { return PLAN_TEXT[art] || null; }

  /* ---------- Die kleine Abfrage nach der Ankunft ---------- */
  var ZIEL = ['ankunft', 'anlegen', 'anker werfen'];
  function klein(n) { return String(n || '').trim().toLowerCase(); }
  function istZiel(name) { return ZIEL.indexOf(klein(name)) >= 0; }
  function istWeiter(name) { return (MM.Motoren && MM.Motoren.WEITER_EREIGNISSE || ['abfahrt', 'ablegen', 'anker lichten']).indexOf(klein(name)) >= 0; }

  /*
   * Zu welchem Ereignis fragt die App? Zum letzten Ereignis am Ziel (Ankunft, Anlegen, Anker werfen), wenn danach kein
   * Ereignis der Weiterfahrt (Abfahrt, Ablegen, Anker lichten) kommt und es noch keinen Besuch dazu gibt (auch keinen
   * übersprungenen). Die Frage wird bei jedem Zeichnen aus den Ereignissen abgeleitet, nicht gemerkt.
   *  ereignisse: [{ id, artName, zeitpunkt, datum, zeit, breite, laenge, ausgeblendet }]
   *  besuche:    [{ ereignisId }]
   *  jetztLokal: „JJJJ-MM-TTTHH:MM“
   */
  function besuchFrage(ereignisse, besuche, jetztLokal) {
    var relevant = (ereignisse || []).filter(function (e) {
      return e && !e.ausgeblendet && e.zeitpunkt && e.zeitpunkt <= jetztLokal && (istZiel(e.artName) || istWeiter(e.artName));
    });
    if (!relevant.length) return null;
    var letztes = relevant.reduce(function (a, b) { return (!a || b.zeitpunkt >= a.zeitpunkt) ? b : a; }, null);
    if (!istZiel(letztes.artName)) return null;
    if ((besuche || []).some(function (b) { return b.ereignisId === letztes.id; })) return null;
    return letztes;
  }

  /* ---------- Dauer eines Aufenthalts (seit 2.0.58) ---------- */
  function zeitpunktMs(datum, zeit) {
    if (!datum || !zeit) return null;
    var ms = new Date(datum + 'T' + zeit).getTime();
    return isNaN(ms) ? null : ms;
  }

  /*
   * Wie lange war man an einem Ort? Von der Ankunft (das Ereignis, zu dem der Besuch gehört) bis zur nächsten Abfahrt
   * (Abfahrt, Ablegen, Anker lichten). Eine Zahl gibt es nur, wenn beide Zeiten bekannt sind und dazwischen nichts anderes
   * liegt: Kommt vor der Abfahrt schon die nächste Ankunft, oder gibt es keine Abfahrt, bleibt es leer (keine falsche Zahl).
   * Zeiten werden als Datum und Uhrzeit verglichen, ein Aufenthalt über Mitternacht stimmt also.
   *  ereignisse: [{ id, artName, zeitpunkt, datum, zeit, ausgeblendet }], ereignisId: die Ankunft
   * Ergebnis: { minuten, text, von: { datum, zeit }, bis: { datum, zeit, artName } } oder null.
   */
  function aufenthalt(ereignisse, ereignisId) {
    var sicht = (ereignisse || []).filter(function (e) { return e && !e.ausgeblendet && e.zeitpunkt; });
    var an = sicht.filter(function (e) { return e.id === ereignisId; })[0];
    if (!an) return null;
    var nach = sicht.filter(function (e) { return e.id !== an.id && e.zeitpunkt >= an.zeitpunkt && (istWeiter(e.artName) || istZiel(e.artName)); })
      .sort(function (a, b) { return a.zeitpunkt < b.zeitpunkt ? -1 : (a.zeitpunkt > b.zeitpunkt ? 1 : 0); });
    var ab = nach[0];
    if (!ab || !istWeiter(ab.artName)) return null;
    var von = zeitpunktMs(an.datum, an.zeit), bis = zeitpunktMs(ab.datum, ab.zeit);
    if (von === null || bis === null || bis < von) return null;
    var minuten = Math.round((bis - von) / 60000);
    return { minuten: minuten, text: dauerText(minuten), von: { datum: an.datum, zeit: an.zeit }, bis: { datum: ab.datum, zeit: ab.zeit, artName: ab.artName } };
  }

  /* 45 min, 2 h 15 min, 1 Tag 3 h, 3 Tage */
  function dauerText(minuten) {
    var m = Math.round(Number(minuten));
    if (!isFinite(m) || m < 0) return '';
    var d = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60), r = m % 60;
    if (d > 0) return d + (d === 1 ? ' Tag' : ' Tage') + (h ? ' ' + h + ' h' : '');
    if (h > 0) return h + ' h' + (r ? ' ' + r + ' min' : '');
    return r + ' min';
  }

  /* ---------- Auswertung pro Ort ---------- */
  /* Aus den Posten einer Liste die Summen je Kostenart. werte: [{ kostenart, betrag }] */
  function summenNachArt(werte) {
    var karte = {}, reihenfolge = [];
    werte.forEach(function (w) {
      var k = w.kostenart || '';
      if (!karte[k]) { karte[k] = { kostenart: k || null, label: k ? (MM.Kosten.labelVon(MM.Kosten.KOSTENARTEN, k) || k) : 'Ohne Angabe', summe: 0, anzahl: 0 }; reihenfolge.push(k); }
      karte[k].summe += Number(w.betrag) || 0; karte[k].anzahl++;
    });
    var liste = reihenfolge.map(function (k) { var x = karte[k]; x.summe = runde(x.summe); return x; });
    liste.sort(function (a, b) { return b.summe - a.summe; });
    return liste;
  }

  /*
   * Was ein Ort dich insgesamt gekostet hat und wie oft du dort warst.
   *  besuche: [{ werte }] alle Besuche des Ortes; kosten: [{ werte }] alle Posten des Ortes
   * Gezählt werden nur Besuche mit Status „besucht“ und nicht ausgeblendete Posten.
   */
  function ortAuswertung(besuche, kosten) {
    var b = (besuche || []).filter(function (x) { return x.werte.status === 'besucht' && x.werte.ausgeblendet !== 'ja'; });
    var k = (kosten || []).filter(function (x) { return x.werte.ausgeblendet !== 'ja' && Number(x.werte.betrag) > 0; });
    var daten = b.map(function (x) { return x.werte.datum || ''; }).filter(Boolean).sort();
    var summe = 0; k.forEach(function (x) { summe += Number(x.werte.betrag); });
    var neuester = k.slice().sort(function (x, y) { return (y.werte.datum || '') < (x.werte.datum || '') ? -1 : ((y.werte.datum || '') > (x.werte.datum || '') ? 1 : 0); })[0] || null;
    return {
      anzahl: b.length, erster: daten[0] || null, letzter: daten[daten.length - 1] || null,
      summe: runde(summe), anzahlPosten: k.length,
      grundlage: MM.Kosten.grundlageVon(k.map(function (x) { return x.werte.grundlage; })),
      letzterPreis: neuester ? { betrag: Number(neuester.werte.betrag), datum: neuester.werte.datum || null, grundlage: neuester.werte.grundlage || 'eingegeben', kostenart: neuester.werte.kostenart || null } : null,
      nachArt: summenNachArt(k.map(function (x) { return x.werte; }))
    };
  }

  /* ---------- Auswertung pro Reise (Aktivität) ---------- */
  /*
   * Was hat die Reise gekostet, wie gliedern sich die Kosten auf, welche Orte waren dabei, was war geplant?
   *  p.kosten  [{ werte }]  Posten der Aktivität (variable Kosten), p.besuche [{ werte, besuchId }]
   *  p.plan    { startOrtId, zielOrtId, zwischenzielIds }   p.orteNamen { ortId: Name }
   */
  function reiseAuswertung(p) {
    var k = (p.kosten || []).filter(function (x) { return x.werte.ausgeblendet !== 'ja' && Number(x.werte.betrag) > 0; });
    var summe = 0; k.forEach(function (x) { summe += Number(x.werte.betrag); });
    var namen = p.orteNamen || {};
    var b = (p.besuche || []).filter(function (x) { return x.werte.status === 'besucht' && x.werte.ausgeblendet !== 'ja' && x.werte.ortId; });
    b.sort(function (x, y) { var a = (x.werte.datum || '') + 'T' + (x.werte.zeit || ''), c = (y.werte.datum || '') + 'T' + (y.werte.zeit || ''); return a < c ? -1 : (a > c ? 1 : 0); });

    var proOrt = {}, reihenfolge = [];
    b.forEach(function (x) {
      var id = x.werte.ortId;
      if (!proOrt[id]) { proOrt[id] = { ortId: id, name: namen[id] || 'unbekannt', besuche: 0, summe: 0, geplant: x.werte.geplant || null }; reihenfolge.push(id); }
      proOrt[id].besuche++;
    });
    k.forEach(function (x) {
      var id = x.werte.ortId;
      if (id && proOrt[id]) proOrt[id].summe += Number(x.werte.betrag);
    });
    var orte = reihenfolge.map(function (id) { var o = proOrt[id]; o.summe = runde(o.summe); return o; });
    var ohneOrt = 0; k.forEach(function (x) { if (!x.werte.ortId || !proOrt[x.werte.ortId]) ohneOrt += Number(x.werte.betrag); });

    var plan = p.plan || {}, besucht = {};
    b.forEach(function (x) { besucht[x.werte.ortId] = true; });
    var planListe = [];
    if (plan.startOrtId) planListe.push({ art: 'start', ortId: plan.startOrtId });
    (plan.zwischenzielIds || []).forEach(function (id) { planListe.push({ art: 'zwischenziel', ortId: id }); });
    if (plan.zielOrtId) planListe.push({ art: 'ziel', ortId: plan.zielOrtId });
    planListe = planListe.map(function (x) { return { art: x.art, ortId: x.ortId, name: namen[x.ortId] || 'unbekannt', besucht: !!besucht[x.ortId] }; });
    var imPlan = {}; planListe.forEach(function (x) { imPlan[x.ortId] = true; });
    var ungeplant = planVorhanden(plan) ? orte.filter(function (o) { return !imPlan[o.ortId]; }) : [];

    return {
      summe: runde(summe), anzahlPosten: k.length,
      grundlage: MM.Kosten.grundlageVon(k.map(function (x) { return x.werte.grundlage; })),
      nachArt: summenNachArt(k.map(function (x) { return x.werte; })),
      orte: orte, anzahlOrte: orte.length, anzahlBesuche: b.length, ohneOrt: runde(ohneOrt),
      plan: planListe, planVorhanden: planVorhanden(plan), ungeplant: ungeplant,
      zielErreicht: plan.zielOrtId ? !!besucht[plan.zielOrtId] : null
    };
  }

  /* Die Ausstattung als Text, zum Beispiel „Strom, Frischwasser, Brötchenservice“. */
  function ausstattungText(liste, sonst) {
    var t = (liste || []).map(function (w) { return MM.Orte.ausstattungLabel(w); });
    if (sonst && String(sonst).trim()) t.push(String(sonst).trim());
    return t.length ? t.join(', ') : null;
  }

  MM.Reiseorte = {
    ORT_RADIUS_M: ORT_RADIUS_M, BESUCH_STATUS: BESUCH_STATUS, GEPLANT: GEPLANT,
    labelVon: labelVon, besuchFelder: besuchFelder, landstromInfo: landstromInfo, LANDSTROM_AUTOMAT: LANDSTROM_AUTOMAT, teilbarAuszug: teilbarAuszug,
    kandidaten: kandidaten, naechster: naechster,
    planVorhanden: planVorhanden, planVergleich: planVergleich, planText: planText,
    istZiel: istZiel, istWeiter: istWeiter, besuchFrage: besuchFrage, aufenthalt: aufenthalt, dauerText: dauerText,
    summenNachArt: summenNachArt, ortAuswertung: ortAuswertung, reiseAuswertung: reiseAuswertung, ausstattungText: ausstattungText
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
