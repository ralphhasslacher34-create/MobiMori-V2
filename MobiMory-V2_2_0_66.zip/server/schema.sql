-- MobiMory Konto-Dienst, Schritt 13a (seit 2.0.64)
-- In der Cloudflare-Datenbank (D1) einmal ausführen. Mehrfaches Ausführen schadet nicht.
-- Gespeichert wird nur das Nötige: E-Mail-Adresse, Passwort-Abdruck (nie das Passwort selbst),
-- Sitzungen (nur ein Abdruck des Schlüssels), Codes (nur ein Abdruck) und Zähler gegen Durchprobieren.

CREATE TABLE IF NOT EXISTS nutzer (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  passwort_hash TEXT,
  passwort_wartend TEXT,
  erstellt_am INTEGER NOT NULL,
  bestaetigt_am INTEGER,
  letzte_anmeldung INTEGER
);

-- Jeder Nutzer hat genau einen eigenen Datenraum (auch kostenlos).
CREATE TABLE IF NOT EXISTS datenraum (
  id TEXT PRIMARY KEY,
  nutzer_id TEXT NOT NULL UNIQUE REFERENCES nutzer(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  erstellt_am INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sitzung (
  token_hash TEXT PRIMARY KEY,
  nutzer_id TEXT NOT NULL REFERENCES nutzer(id) ON DELETE CASCADE,
  erstellt_am INTEGER NOT NULL,
  laeuft_ab INTEGER NOT NULL,
  geraet TEXT
);
CREATE INDEX IF NOT EXISTS sitzung_nutzer ON sitzung(nutzer_id);

CREATE TABLE IF NOT EXISTS code (
  email TEXT PRIMARY KEY,
  zweck TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  laeuft_ab INTEGER NOT NULL,
  versuche INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS drossel (
  schluessel TEXT PRIMARY KEY,
  anzahl INTEGER NOT NULL,
  fenster_bis INTEGER NOT NULL
);

-- ===== Schritt 13b (seit 2.0.65): Abgleich zwischen Geräten und verschlüsselte Sicherung =====
-- Diese Tabellen kommen zu den fünf oben dazu. Vorhandene Daten bleiben. Mehrfaches Ausführen schadet nicht.

-- Zähler der Änderungen je Datenraum und eine Kennung, die sich ändert, wenn der Datenraum auf dem Server geleert wird.
CREATE TABLE IF NOT EXISTS abgleich_stand (
  datenraum_id TEXT PRIMARY KEY REFERENCES datenraum(id) ON DELETE CASCADE,
  seq INTEGER NOT NULL DEFAULT 0,
  epoche TEXT NOT NULL
);

-- Ein Datensatz je Objekt. „nutzlast“ ist der Text, den die App schickt (ohne die Angaben, die lokal bleiben). Gelöschtes bleibt als Marke.
CREATE TABLE IF NOT EXISTS abgleich (
  datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE,
  tabelle TEXT NOT NULL,
  objekt_id TEXT NOT NULL,
  seq INTEGER NOT NULL,
  geloescht INTEGER NOT NULL DEFAULT 0,
  fahrzeug_id TEXT,
  nutzlast TEXT,
  geaendert_am INTEGER NOT NULL,
  PRIMARY KEY (datenraum_id, tabelle, objekt_id)
);
CREATE INDEX IF NOT EXISTS abgleich_seq ON abgleich(datenraum_id, seq);

-- Verschlüsselte Sicherung der App. Der Dienst sieht nur Größe und Zeit, nie den Inhalt (er ist mit dem Schlüsselwort des Nutzers verschlüsselt).
CREATE TABLE IF NOT EXISTS sicherung (
  id TEXT PRIMARY KEY,
  datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE,
  erstellt_am INTEGER NOT NULL,
  app TEXT,
  groesse INTEGER NOT NULL,
  teile INTEGER NOT NULL,
  summe TEXT NOT NULL,
  fertig INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS sicherung_raum ON sicherung(datenraum_id);

CREATE TABLE IF NOT EXISTS sicherungsteil (
  sicherung_id TEXT NOT NULL REFERENCES sicherung(id) ON DELETE CASCADE,
  nr INTEGER NOT NULL,
  daten TEXT NOT NULL,
  PRIMARY KEY (sicherung_id, nr)
);

-- ===== Schritt 13d (seit 2.0.66): Dateien in R2 =====
-- Eine Zeile je Datei, die im Dateispeicher (R2) liegt. Der Inhalt selbst liegt nicht in der Datenbank.
-- Diese Anweisung steht bewusst in einer einzigen Zeile (für die D1-Console am Tablet). Mehrfaches Ausführen schadet nicht.
CREATE TABLE IF NOT EXISTS datei (datenraum_id TEXT NOT NULL REFERENCES datenraum(id) ON DELETE CASCADE, tabelle TEXT NOT NULL, objekt_id TEXT NOT NULL, groesse INTEGER NOT NULL, verschluesselt INTEGER NOT NULL DEFAULT 0, erstellt_am INTEGER NOT NULL, PRIMARY KEY (datenraum_id, tabelle, objekt_id));
