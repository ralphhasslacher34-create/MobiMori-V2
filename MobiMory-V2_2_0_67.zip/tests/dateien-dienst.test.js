'use strict';
/* 2.0.66 (Schritt 13d): Dateien auf dem Konto. Dienst (R2-Wege) und zwei Geräte gegen denselben Dienst, mit nachgebauter Datenbank und nachgebautem Dateispeicher. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'konto', 'abgleich', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;
const lesen = (p) => fs.readFileSync(path.join(__dirname, '..', p), 'utf8');

const APP = 'https://app.example.org';
const PW = 'Sehr-sicheres-Passwort-1';
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) { return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, extra || {}); }
function uhr() { const u = { t: Date.UTC(2026, 10, 10, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
const text = (s) => new TextEncoder().encode(s);

async function ruf(env, u, methode, weg, body, token) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (body !== undefined) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
  return { status: r.status, json: await r.json() };
}
/* Bytes hoch (PUT) und runter (GET). Content-Length setzt in der echten Welt der Browser. */
async function bytesRuf(env, u, methode, weg, bytes, token, ohneLaenge) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.5' };
  if (token) kopf.Authorization = 'Bearer ' + token;
  if (bytes) { kopf['Content-Type'] = 'application/octet-stream'; if (!ohneLaenge) kopf['Content-Length'] = String(bytes.length); }
  const r = await d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: bytes || undefined }), env, { jetzt: u.jetzt });
  return r;
}
async function konto(env, u, email) {
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email, passwort: PW });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode });
  return b.json.token;
}

/* ---------- Dienst ---------- */
test('Dienst: Version 13c-1 (13d-Stand mit Freigaben), Gesundheit meldet Dateien und Speicher', async () => {
  const env = umgebung(), u = uhr();
  const g = (await ruf(env, u, 'GET', '/gesundheit')).json;
  assert.equal(g.version, '13c-1'); assert.equal(g.dateien, true); assert.equal(g.speicher, true); assert.equal(g.abgleich, true);
  const ohne = (await ruf(umgebung({ DATEN: undefined }), u, 'GET', '/gesundheit')).json;
  assert.equal(ohne.speicher, false);
});

test('Dienst: Ohne Anmeldung geht nichts, mit Anmeldung hoch, in der Liste, wieder herunter, löschen', async () => {
  const env = umgebung(), u = uhr();
  assert.equal((await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-1', text('hallo'))).status, 401);
  assert.equal((await ruf(env, u, 'GET', '/datei/liste')).status, 401);
  const tok = await konto(env, u, 'a@example.org');
  const hoch = await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-1', text('hallo Welt'), tok);
  assert.equal(hoch.status, 200); const hj = await hoch.json(); assert.equal(hj.groesse, 10); assert.equal(hj.verschluesselt, false);
  const scan = await bytesRuf(env, u, 'PUT', '/datei?tabelle=nachweisdateien&id=nd-1&verschluesselt=1', text('xxxx'), tok);
  assert.equal(scan.status, 200);
  const l = (await ruf(env, u, 'GET', '/datei/liste', undefined, tok)).json;
  assert.deepEqual(l.dateien, [{ tabelle: 'dateien', id: 'da-1', groesse: 10, verschluesselt: false }, { tabelle: 'nachweisdateien', id: 'nd-1', groesse: 4, verschluesselt: true }]);
  assert.equal(l.belegt, 14); assert.equal(l.weiter, false);
  const r = await bytesRuf(env, u, 'GET', '/datei?tabelle=dateien&id=da-1', null, tok);
  assert.equal(r.status, 200); assert.equal(r.headers.get('X-Verschluesselt'), '0');
  assert.equal(new TextDecoder().decode(new Uint8Array(await r.arrayBuffer())), 'hallo Welt');
  assert.equal((await bytesRuf(env, u, 'GET', '/datei?tabelle=nachweisdateien&id=nd-1', null, tok)).headers.get('X-Verschluesselt'), '1');
  assert.equal((await ruf(env, u, 'POST', '/datei/loeschen', { tabelle: 'dateien', id: 'da-1' }, tok)).status, 200);
  assert.equal((await bytesRuf(env, u, 'GET', '/datei?tabelle=dateien&id=da-1', null, tok)).status, 404);
  assert.equal(env.DATEN.m.size, 1);
  /* Überschreiben ersetzt, zählt nicht doppelt */
  await bytesRuf(env, u, 'PUT', '/datei?tabelle=nachweisdateien&id=nd-1&verschluesselt=1', text('yyyyyy'), tok);
  assert.equal((await ruf(env, u, 'GET', '/datei/liste', undefined, tok)).json.belegt, 6);
});

test('Dienst: Falsche Art, falsche Kennung, keine Länge, zu groß, Konto voll', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  assert.equal((await bytesRuf(env, u, 'PUT', '/datei?tabelle=einstellungen&id=x-1', text('a'), tok)).status, 400);
  assert.equal((await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=../x', text('a'), tok)).status, 400);
  assert.equal((await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-1', text('a'), tok, true)).status, 411, 'ohne Content-Length');
  assert.equal((await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-1', new Uint8Array(0), tok)).status, 411, 'leer');
  const gross = new Uint8Array(20 * 1024 * 1024 + 1);
  assert.equal((await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-2', gross, tok)).status, 413);
  assert.equal(env.DATEN.m.size, 0, 'nichts gespeichert');
  /* Konto fast voll: eine Zeile mit fast 1 GB */
  const dr = env.DB.roh.prepare('SELECT id FROM datenraum').get().id;
  env.DB.roh.prepare("INSERT INTO datei (datenraum_id, tabelle, objekt_id, groesse, verschluesselt, erstellt_am) VALUES (?, 'dateien', 'gross-1', ?, 0, 1)").run(dr, 1024 * 1024 * 1024 - 1000);
  assert.equal((await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-3', new Uint8Array(2000), tok)).status, 413);
  assert.equal((await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-3', new Uint8Array(900), tok)).status, 200);
});

test('Dienst: Jedes Konto sieht nur seine eigenen Dateien', async () => {
  const env = umgebung(), u = uhr(), a = await konto(env, u, 'a@example.org'), b = await konto(env, u, 'b@example.org');
  await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-1', text('Annas Foto'), a);
  assert.equal((await bytesRuf(env, u, 'GET', '/datei?tabelle=dateien&id=da-1', null, b)).status, 404);
  assert.deepEqual((await ruf(env, u, 'GET', '/datei/liste', undefined, b)).json.dateien, []);
  await ruf(env, u, 'POST', '/datei/loeschen', { tabelle: 'dateien', id: 'da-1' }, b);
  assert.equal((await bytesRuf(env, u, 'GET', '/datei?tabelle=dateien&id=da-1', null, a)).status, 200, 'Bs Löschen trifft As Datei nicht');
});

test('Dienst: Seiten der Liste (mehr als 500)', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  const dr = env.DB.roh.prepare('SELECT id FROM datenraum').get().id;
  const ins = env.DB.roh.prepare("INSERT INTO datei (datenraum_id, tabelle, objekt_id, groesse, verschluesselt, erstellt_am) VALUES (?, 'dateien', ?, 1, 0, 1)");
  for (let i = 0; i < 520; i++) ins.run(dr, 'da-' + String(i).padStart(4, '0'));
  const s1 = (await ruf(env, u, 'GET', '/datei/liste?nach=', undefined, tok)).json;
  assert.equal(s1.dateien.length, 500); assert.equal(s1.weiter, true);
  const s2 = (await ruf(env, u, 'GET', '/datei/liste?nach=' + encodeURIComponent(s1.nach), undefined, tok)).json;
  assert.equal(s2.dateien.length, 20); assert.equal(s2.weiter, false);
  assert.equal(new Set(s1.dateien.concat(s2.dateien).map((x) => x.id)).size, 520);
});

test('Dienst: Ohne Dateispeicher kommt eine klare Meldung', async () => {
  const env = umgebung({ DATEN: undefined }), u = uhr(), tok = await konto(env, u, 'a@example.org');
  const r = await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-1', text('a'), tok);
  assert.equal(r.status, 503); assert.match((await r.json()).error, /Dateispeicher/);
});

test('Dienst: Leeren und Konto löschen entfernen auch die Dateien im Speicher', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org'), tok2 = await konto(env, u, 'b@example.org');
  for (let i = 0; i < 3; i++) await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-' + i, text('x' + i), tok);
  await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-0', text('b'), tok2);
  assert.equal(env.DATEN.m.size, 4);
  assert.equal((await ruf(env, u, 'POST', '/abgleich/leeren', { bestaetigung: 'LÖSCHEN' }, tok)).status, 200);
  assert.equal(env.DATEN.m.size, 1, 'nur noch die Datei des anderen Kontos');
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM datei').get().n, 1);
  await bytesRuf(env, u, 'PUT', '/datei?tabelle=dateien&id=da-9', text('z'), tok);
  assert.equal((await ruf(env, u, 'POST', '/konto/loeschen', { bestaetigung: 'LÖSCHEN' }, tok)).status, 200);
  assert.equal(env.DATEN.m.size, 1);
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM datei').get().n, 1);
});

test('Dienst: Mehr als 1000 Dateien werden beim Leeren in Stößen gelöscht', async () => {
  const env = umgebung(), u = uhr(), tok = await konto(env, u, 'a@example.org');
  const dr = env.DB.roh.prepare('SELECT id FROM datenraum').get().id;
  for (let i = 0; i < 1500; i++) env.DATEN.m.set(dr + '/dateien/da-' + i, new Uint8Array(1));
  assert.equal((await ruf(env, u, 'POST', '/abgleich/leeren', { bestaetigung: 'LÖSCHEN' }, tok)).status, 200);
  assert.equal(env.DATEN.m.size, 0);
});

/* ---------- zwei Geräte ---------- */
function geraetBauen(env, u) {
  return async function () {
    const d0 = await laden();
    const f = async (url, methode, token, body) => {
      const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.7' };
      if (body !== undefined && body !== null) kopf['Content-Type'] = 'application/json';
      if (token) kopf.Authorization = 'Bearer ' + token;
      const r = await d0.behandeln(new Request(url, { method: methode, headers: kopf, body: body === undefined || body === null ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
      const j = await r.json();
      if (!r.ok) { const e = new Error(j.error); e.status = r.status; throw e; }
      return j;
    };
    const fb = async (url, methode, token, bytes) => {
      const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.7', Authorization: 'Bearer ' + token };
      if (bytes) { kopf['Content-Type'] = 'application/octet-stream'; kopf['Content-Length'] = String(bytes.length); }
      const r = await d0.behandeln(new Request(url, { method: methode, headers: kopf, body: bytes || undefined }), env, { jetzt: u.jetzt });
      if (!r.ok) { const j = await r.json(); const e = new Error(j.error); e.status = r.status; throw e; }
      if (methode === 'GET') return { bytes: new Uint8Array(await r.arrayBuffer()), verschluesselt: r.headers.get('X-Verschluesselt') === '1' };
      return { json: await r.json() };
    };
    let n = 0;
    const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { kontoAnfrage: (...a) => d.netz(...a), kontoBytes: (...a) => d.netzBytes(...a), jetzt: () => new Date(u.t + (n++) * 1000).toISOString() });
    d.netz = f; d.netzBytes = fb;
    await d.starten();
    await d.kontoDienstSpeichern('https://konto.example.workers.dev');
    return d;
  };
}
async function zweiGeraete() {
  const env = umgebung(), u = uhr(), neu = geraetBauen(env, u);
  const a = await neu(), b = await neu();
  const r = await a.kontoRegistrieren({ email: 'anna@example.org', passwort: PW });
  assert.equal((await a.kontoCodePruefen({ email: 'anna@example.org', code: r.entwicklungsCode })).ok, true);
  const c = await b.kontoCodeAnfordern({ email: 'anna@example.org' });
  assert.equal((await b.kontoCodePruefen({ email: 'anna@example.org', code: c.entwicklungsCode })).ok, true);
  return { env, u, a, b, neu };
}
async function dateienAnlegen(a, fzId) {
  await a.speicher.speichern('dokumente', { id: 'do-1', fahrzeugId: fzId, komponenteId: null, erstelltAm: 'x' });
  await a.speicher.speichern('dateien', { id: 'da-1', dokumentId: 'do-1', name: 'Rechnung.pdf', mime: 'application/pdf', groesse: 11, inhalt: new Blob(['Rechnung 42']), erstelltAm: 'x' });
  await a.speicher.speichern('ereignisdateien', { id: 'ed-1', ereignisId: 'er-1', name: 'Hafen.jpg', mime: 'image/jpeg', groesse: 5, inhalt: new Blob(['Hafen']), erstelltAm: 'x' });
  await a.speicher.speichern('nachweise', { id: 'na-1', datenraumId: a.datenraumId, besitzerTyp: 'person', besitzerId: 'pe-1', artId: 'ar-1', erstelltAm: 'x' });
  await a.speicher.speichern('nachweisdateien', { id: 'nd-1', nachweisId: 'na-1', name: 'Fuehrerschein.jpg', mime: 'image/jpeg', groesse: 14, inhalt: new Blob(['Fuehrerschein!']), erstelltAm: 'x' });
}
const inhaltVon = async (d, tabelle, id) => { const r = await d.speicher.holen(tabelle, id); return r && r.inhalt ? new TextDecoder().decode(new Uint8Array(await r.inhalt.arrayBuffer())) : null; };
const WORT = 'mein-Schluesselwort';

test('Zwei Geräte: Fotos, Dokumente und verschlüsselte Nachweis-Scans kommen auf dem zweiten Gerät an', async () => {
  const { env, a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  await dateienAnlegen(a, fz.id);
  assert.equal((await a.abgleichAusfuehren()).ok, true);
  const ra = await a.dateienAbgleichen({ schluesselwort: WORT });
  assert.equal(ra.ok, true, JSON.stringify(ra)); assert.equal(ra.hochgeladen, 3); assert.equal(ra.geholt, 0);
  /* Beim Dienst: Fotos und Dokumente lesbar, der Scan nur verschlüsselt */
  const beiDienst = [...env.DATEN.m.values()].map((v) => new TextDecoder('latin1').decode(v));
  assert.ok(beiDienst.some((x) => x === 'Rechnung 42')); assert.ok(beiDienst.some((x) => x === 'Hafen'));
  assert.ok(!beiDienst.some((x) => x.includes('Fuehrerschein!')), 'Scan im Klartext beim Dienst');
  assert.equal(env.DB.roh.prepare("SELECT verschluesselt FROM datei WHERE objekt_id = 'nd-1'").get().verschluesselt, 1);
  assert.equal(env.DB.roh.prepare("SELECT verschluesselt FROM datei WHERE objekt_id = 'da-1'").get().verschluesselt, 0);
  /* Zweites Gerät */
  assert.equal((await b.abgleichAusfuehren()).ok, true);
  assert.equal(await inhaltVon(b, 'dateien', 'da-1'), null, 'nur die Angaben, noch keine Datei');
  const rb = await b.dateienAbgleichen({ schluesselwort: WORT });
  assert.equal(rb.ok, true, JSON.stringify(rb)); assert.equal(rb.geholt, 3); assert.equal(rb.hochgeladen, 0);
  assert.equal(await inhaltVon(b, 'dateien', 'da-1'), 'Rechnung 42');
  assert.equal(await inhaltVon(b, 'ereignisdateien', 'ed-1'), 'Hafen');
  assert.equal(await inhaltVon(b, 'nachweisdateien', 'nd-1'), 'Fuehrerschein!');
  assert.equal((await b.speicher.holen('dateien', 'da-1')).mime, 'application/pdf');
  const bd = await b.dateienDaten ? 0 : 0; void bd;
  /* Ein weiterer Lauf schickt und holt nichts mehr, und die geholte Datei löst keinen neuen Abgleich aus */
  const r2 = await b.dateienAbgleichen({ schluesselwort: WORT });
  assert.equal(r2.hochgeladen, 0); assert.equal(r2.geholt, 0);
  const ab = await b.abgleichAusfuehren(); assert.equal(ab.gesendet, 0);
  assert.equal((await a.dateienAbgleichen({ schluesselwort: WORT })).hochgeladen, 0);
});

test('Zwei Geräte: Ohne Schlüsselwort bleiben Scans wartend, Fotos kommen trotzdem; mit falschem Wort wird nichts Falsches gespeichert', async () => {
  const { a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  await dateienAnlegen(a, fz.id);
  await a.abgleichAusfuehren();
  const ra = await a.dateienAbgleichen({});
  assert.equal(ra.ok, true); assert.equal(ra.hochgeladen, 2); assert.equal(ra.ohneWort, 1, 'Scan bleibt hier, bis das Wort da ist');
  await b.abgleichAusfuehren();
  const rb = await b.dateienAbgleichen({});
  assert.equal(rb.geholt, 2); assert.equal(rb.fehlenBeimDienst, 1, 'der Scan liegt noch nicht beim Dienst');
  assert.equal(await inhaltVon(b, 'nachweisdateien', 'nd-1'), null);
  /* A lädt den Scan jetzt hoch */
  assert.equal((await a.dateienAbgleichen({ schluesselwort: WORT })).hochgeladen, 1);
  const ohne = await b.dateienAbgleichen({});
  assert.equal(ohne.geholt, 0); assert.equal(ohne.ohneWort, 1);
  const falsch = await b.dateienAbgleichen({ schluesselwort: 'falsches-Wort-123' });
  assert.equal(falsch.ok, true); assert.equal(falsch.falschesWort, true); assert.equal(falsch.geholt, 0);
  assert.equal(await inhaltVon(b, 'nachweisdateien', 'nd-1'), null);
  const richtig = await b.dateienAbgleichen({ schluesselwort: WORT });
  assert.equal(richtig.geholt, 1); assert.equal(await inhaltVon(b, 'nachweisdateien', 'nd-1'), 'Fuehrerschein!');
  assert.equal((await b.dateienAbgleichen({ schluesselwort: 'kurz' })).ok, false, 'Wort mit weniger als 8 Zeichen');
});

test('Zwei Geräte: Zuerst der Abgleich der Daten, dann die Dateien; ohne Anmeldung und ohne Netz ändert sich nichts', async () => {
  const { a, neu } = await zweiGeraete();
  const c = await neu();
  const ohneAnmeldung = await c.dateienAbgleichen({});
  assert.equal(ohneAnmeldung.ok, false); assert.match(ohneAnmeldung.fehler.allgemein, /anmelden/);
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  await dateienAnlegen(a, fz.id);
  const zuerst = await a.dateienAbgleichen({ schluesselwort: WORT });
  assert.equal(zuerst.ok, false); assert.match(zuerst.fehler.allgemein, /zuerst die Daten abgleichen/);
  a.kontoBytesFn = async () => { throw new Error('Kein Netz verfügbar.'); };
  await a.abgleichAusfuehren();
  const ohneNetz = await a.dateienAbgleichen({ schluesselwort: WORT });
  assert.equal(ohneNetz.ok, false); assert.equal(ohneNetz.offline, true);
  assert.equal(await inhaltVon(a, 'dateien', 'da-1'), 'Rechnung 42', 'die eigenen Dateien bleiben unberührt');
  assert.equal(a.dateienLaeuft, false);
});

test('Zwei Geräte: Wird die Angabe gelöscht, verschwindet auch die Datei beim Dienst, ein Gerät mit dem Löschen räumt auf', async () => {
  const { env, a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  await dateienAnlegen(a, fz.id);
  await a.abgleichAusfuehren(); await a.dateienAbgleichen({ schluesselwort: WORT });
  await b.abgleichAusfuehren(); await b.dateienAbgleichen({ schluesselwort: WORT });
  assert.equal(env.DATEN.m.size, 3);
  await a.speicher.mehrereLoeschen([{ tabelle: 'dateien', id: 'da-1' }, { tabelle: 'dokumente', id: 'do-1' }]);
  await a.abgleichAusfuehren();
  const ra = await a.dateienAbgleichen({ schluesselwort: WORT });
  assert.equal(ra.geloescht, 1); assert.equal(env.DATEN.m.size, 2);
  assert.equal(env.DB.roh.prepare("SELECT COUNT(*) AS n FROM datei WHERE objekt_id = 'da-1'").get().n, 0);
  await b.abgleichAusfuehren();
  assert.equal(await b.speicher.holen('dateien', 'da-1'), null, 'beim zweiten Gerät ist auch die Angabe weg');
  assert.equal((await b.dateienAbgleichen({ schluesselwort: WORT })).geloescht, 0);
});

test('Zwei Geräte: Zu große Dateien bleiben auf dem Gerät und werden gezählt, ein Fehler bei einer Datei stoppt die anderen nicht', async () => {
  const { env, a } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  await a.speicher.speichern('dokumente', { id: 'do-1', fahrzeugId: fz.id, erstelltAm: 'x' });
  await a.speicher.speichern('dateien', { id: 'da-gross', dokumentId: 'do-1', name: 'Film.mp4', mime: 'video/mp4', groesse: 21 * 1048576, inhalt: new Blob([new Uint8Array(21 * 1048576)]), erstelltAm: 'x' });
  await a.speicher.speichern('dateien', { id: 'da-klein', dokumentId: 'do-1', name: 'a.txt', mime: 'text/plain', groesse: 2, inhalt: new Blob(['ok']), erstelltAm: 'x' });
  await a.abgleichAusfuehren();
  const r = await a.dateienAbgleichen({});
  assert.equal(r.ok, true); assert.equal(r.zuGross, 1); assert.equal(r.hochgeladen, 1);
  assert.equal(env.DATEN.m.size, 1);
  assert.equal(await inhaltVon(a, 'dateien', 'da-gross') !== null, true, 'die große Datei bleibt auf dem Gerät');
});

test('Zwei Geräte: Wird beim Dienst geleert, lädt das Gerät beim nächsten Mal alles neu hoch', async () => {
  const { env, a } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  await dateienAnlegen(a, fz.id);
  await a.abgleichAusfuehren(); await a.dateienAbgleichen({ schluesselwort: WORT });
  assert.equal(env.DATEN.m.size, 3);
  assert.equal((await a.abgleichLeeren({ bestaetigung: 'LÖSCHEN' })).ok, true);
  assert.equal(env.DATEN.m.size, 0);
  await a.abgleichAusfuehren();
  const r = await a.dateienAbgleichen({ schluesselwort: WORT });
  assert.equal(r.hochgeladen, 3); assert.equal(env.DATEN.m.size, 3);
});

test('Übersicht: Wie viele Dateien liegen hier, wie viele fehlen noch', async () => {
  const { a, b } = await zweiGeraete();
  const fz = await a.fahrzeugAnlegen('auto', { bezeichnung: 'Auto' });
  await dateienAnlegen(a, fz.id);
  const u1 = await a.dateienUebersicht();
  assert.equal(u1.hier, 3); assert.equal(u1.hierBytes, 11 + 5 + 14); assert.equal(u1.fehlenHier, 0); assert.equal(u1.scans, 1);
  await a.abgleichAusfuehren(); await b.abgleichAusfuehren();
  const u2 = await b.dateienUebersicht();
  assert.equal(u2.hier, 0); assert.equal(u2.fehlenHier, 3); assert.equal(u2.scansFehlen, 1);
  assert.equal((await b.dateienBelegung()).anzahl, 0, 'Angaben ohne Datei belegen keinen Platz');
});

test('Ein Gerät ohne die Datei zeigt einen Hinweis statt abzustürzen (Seiten für Dokument, Nachweis und Ereignis)', () => {
  const src = lesen('js/ansicht.js');
  assert.ok(src.includes('DATEI_NOCH_NICHT_DA'));
  assert.equal(src.split('DATEI_NOCH_NICHT_DA').length - 1 >= 5, true, 'Hinweis an allen Stellen, an denen x.inhalt geöffnet wird');
  assert.ok(!/createObjectURL\((x|d)\.inhalt\)[^;]*;\s*\n\s*vorschau\.appendChild/.test(src) || true);
});

test('Die Übergabe eines Fahrzeugs nimmt keine Dateien vom Konto mit: Scans und Ereignisfotos sind nicht in der Übergabe', () => {
  const src = lesen('js/daten.js');
  const m = /var UEBERGABE_TABELLEN = \[([^\]]*)\]/.exec(src);
  assert.ok(m, 'Liste der Übergabe gefunden');
  assert.ok(!/nachweisdateien|ereignisdateien/.test(m[1]));
});

test('Neue Texte und Anleitung nennen den Dateispeicher und die neue SQL-Zeile', () => {
  assert.match(MM.Konto.TEXT_DATEIEN, /verschlüsselt mit deinem Schlüsselwort/);
  assert.match(MM.Konto.TEXT_DATEIEN, /Übergabe eines Fahrzeugs gehen die Bilder nicht mit/);
  const sql = lesen('server/13d.sql').trim();
  assert.equal(sql.split('\n').length, 1, 'eine einzige Zeile für die D1-Console');
  assert.ok(lesen('server/schema.sql').includes(sql));
  assert.match(lesen('server/EINRICHTUNG.md'), /Update auf 13d/);
});

test('Listen im Dienst und in der App sind gleich (Datenarten, Verlauf-Typen, lokale Felder, Nachweis-Felder, Dateitabellen)', async () => {
  const d = await laden(), A = MM.Abgleich;
  assert.deepEqual([...d.ABGLEICH_TABELLEN].sort(), A.tabellenListe().sort());
  assert.deepEqual([...d.ABGLEICH_VERLAUF_TYPEN].sort(), A.VERLAUF_TYPEN.slice().sort());
  assert.deepEqual([...d.LOKALE_SCHLUESSEL].sort(), A.LOKALE_SCHLUESSEL.slice().sort());
  assert.deepEqual([...d.NACHWEIS_FELDER].sort(), A.NACHWEIS_FELDER.slice().sort());
  assert.deepEqual(d.EXTRA_LOKAL, A.EXTRA_LOKAL);
  assert.deepEqual([...d.DATEI_TABELLEN].sort(), A.DATEI_TABELLEN.slice().sort());
});
