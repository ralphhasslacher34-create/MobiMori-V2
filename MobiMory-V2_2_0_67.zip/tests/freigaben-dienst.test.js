'use strict';
/* 2.0.67 (Schritt 13c): Freigaben je Fahrzeug und Zeitraum, Einladung per Code, Kontroll-Freigabe, Rechteprüfung auf dem Server.
   Dienst mit nachgebauter Datenbank und nachgebautem Dateispeicher. */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');

const APP = 'https://app.example.org';
const PW = 'Sehr-sicheres-Passwort-1';
const TAG = 24 * 60 * 60 * 1000;
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function umgebung(extra) { return Object.assign({ DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, extra || {}); }
function uhr() { const u = { t: Date.UTC(2026, 10, 11, 12, 0, 0) }; u.jetzt = () => u.t; return u; }
const text = (s) => new TextEncoder().encode(s);

async function roh(env, u, methode, weg, body, token, ip) {
  const d = await laden();
  const kopf = { Origin: APP, 'CF-Connecting-IP': ip || '203.0.113.5' };
  if (body !== undefined && !(body instanceof Uint8Array)) kopf['Content-Type'] = 'application/json';
  if (token) kopf.Authorization = 'Bearer ' + token;
  const bytes = body instanceof Uint8Array;
  if (bytes) kopf['Content-Length'] = String(body.length);
  return d.behandeln(new Request('https://konto.example.workers.dev' + weg, { method: methode, headers: kopf, body: body === undefined ? undefined : (bytes ? body : JSON.stringify(body)) }), env, { jetzt: u.jetzt });
}
async function ruf(env, u, methode, weg, body, token, ip) { const r = await roh(env, u, methode, weg, body, token, ip); return { status: r.status, json: await r.json() }; }
async function konto(env, u, email) {
  const a = await ruf(env, u, 'POST', '/konto/registrieren', { email, passwort: PW });
  const b = await ruf(env, u, 'POST', '/konto/code-pruefen', { email, code: a.json.entwicklungsCode });
  return b.json.token;
}
/* Ein Datensatz in der Form des Abgleichs. */
function satz(tabelle, o) { return { tabelle, id: o.id, basis: 0, nutzlast: JSON.stringify(o) }; }
async function senden(env, u, tok, liste) {
  const r = await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: liste }, tok);
  assert.equal(r.status, 200, JSON.stringify(r.json));
  return r.json;
}

/* Besitzer mit zwei Fahrzeugen: F1 mit Angaben, Frist, Zähler, Dokument samt Datei, Kosten, Nachweis, Ereignis; F2 mit einem Dokument. */
async function besitzer(env, u) {
  const tok = await konto(env, u, 'besitzer@example.org');
  await senden(env, u, tok, [
    satz('fahrzeuge', { id: 'fz-1', datenraumId: '@', art: 'wohnmobil', erstelltAm: 1 }),
    satz('eintraege', { id: 'en-1', fahrzeugId: 'fz-1', nr: 1, werte: { bezeichnung: 'Alter Name' }, erstelltAm: 1 }),
    satz('eintraege', { id: 'en-2', fahrzeugId: 'fz-1', nr: 2, werte: { bezeichnung: 'Mein Wohnmobil', kennzeichen: 'LB-AB 123' }, erstelltAm: 2 }),
    satz('fristen', { id: 'fr-1', fahrzeugId: 'fz-1', komponenteId: null, erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-fr-1', objektTyp: 'frist', objektId: 'fr-1', nr: 1, werte: { bezeichnung: 'Hauptuntersuchung', kalenderWert: 2, kalenderEinheit: 'jahre' }, erstelltAm: 1 }),
    satz('durchfuehrungen', { id: 'du-1', fristId: 'fr-1', datum: '2025-03-01', zaehlerstand: null, art: 'erledigt', erstelltAm: 1 }),
    satz('zaehler', { id: 'za-1', fahrzeugId: 'fz-1', komponenteId: null, art: 'strecke', erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-za-1', objektTyp: 'zaehler', objektId: 'za-1', nr: 1, werte: { bezeichnung: 'Kilometerstand' }, erstelltAm: 1 }),
    satz('zaehlerstaende', { id: 'zs-1', zaehlerId: 'za-1', nr: 1, wert: 51000, datum: '2026-10-01', erstelltAm: 1 }),
    satz('dokumente', { id: 'do-1', fahrzeugId: 'fz-1', komponenteId: null, vorgangId: null, erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-do-1', objektTyp: 'dokument', objektId: 'do-1', nr: 1, werte: { bezeichnung: 'Fahrzeugschein' }, erstelltAm: 1 }),
    satz('dateien', { id: 'da-1', dokumentId: 'do-1', name: 'schein.pdf', mime: 'application/pdf', groesse: 11, erstelltAm: 1 }),
    satz('dokumente', { id: 'do-2', fahrzeugId: 'fz-2', komponenteId: null, vorgangId: null, erstelltAm: 1 }),
    satz('dateien', { id: 'da-2', dokumentId: 'do-2', name: 'anderes.pdf', mime: 'application/pdf', groesse: 7, erstelltAm: 1 }),
    satz('kosten', { id: 'ko-1', datenraumId: '@', fahrzeugId: 'fz-1', erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-ko-1', objektTyp: 'kosten', objektId: 'ko-1', nr: 1, werte: { betrag: 99 }, erstelltAm: 1 }),
    satz('nachweise', { id: 'na-1', datenraumId: '@', artId: 'x', besitzerTyp: 'person', besitzerId: 'pe-1', erstelltAm: 1 }),
    satz('fahrzeuge', { id: 'fz-2', datenraumId: '@', art: 'boot', erstelltAm: 1 }),
    satz('aktivitaeten', { id: 'ak-1', datenraumId: '@', erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-ak-1', objektTyp: 'aktivitaet', objektId: 'ak-1', nr: 1, werte: { fahrzeugId: 'fz-1', vonDatum: '2026-11-01' }, erstelltAm: 1 }),
    satz('tagespruefungen', { id: 'tp-1', datenraumId: '@', aktivitaetId: 'ak-1', abschnittId: 'ab-1', stand: { geprueftAm: '2026-11-01T08:00', tagesbeginn: '2026-11-01', ergebnis: 'ok', fristen: { betroffen: 0, sperre: 0, eingeschraenkt: 0 } }, erstelltAm: 5 }),
    satz('tagespruefungen', { id: 'tp-0', datenraumId: '@', aktivitaetId: 'ak-1', abschnittId: 'ab-0', stand: { geprueftAm: '2026-10-01T08:00', tagesbeginn: '2026-10-01', ergebnis: 'sperre', fristen: { betroffen: 1, sperre: 1, eingeschraenkt: 0 } }, erstelltAm: 3 }),
    satz('ereignisse', { id: 'er-1', datenraumId: '@', aktivitaetId: 'ak-1', abschnittId: 'ab-1', erstelltAm: 1 }),
    satz('verlaeufe', { id: 've-er-1', objektTyp: 'ereignis', objektId: 'er-1', nr: 1, werte: { text: 'Standort geheim', breite: 48.1, laenge: 9.1 }, erstelltAm: 1 })
  ]);
  const me = await ruf(env, u, 'GET', '/konto/ich', undefined, tok);
  const dr = me.json.datenraum.id;
  assert.equal((await roh(env, u, 'PUT', '/datei?tabelle=dateien&id=da-1', text('Inhalt-Pdf-1'.slice(0, 11)), tok)).status, 200);
  assert.equal((await roh(env, u, 'PUT', '/datei?tabelle=dateien&id=da-2', text('anderes!'.slice(0, 7)), tok)).status, 200);
  assert.equal((await roh(env, u, 'PUT', '/datei?tabelle=nachweisdateien&id=nd-1&verschluesselt=1', text('geheim'), tok)).status, 200);
  return { tok, dr };
}
async function einladen(env, u, tok, extra) {
  return ruf(env, u, 'POST', '/freigabe/einladen', Object.assign({ fahrzeugId: 'fz-1', email: 'gast@example.org', bis: '2027-03-31' }, extra || {}), tok);
}
/* Gast eingeladen und angenommen. */
async function freigabe(env, u, b, extra) {
  const gast = await konto(env, u, 'gast@example.org');
  const e = await einladen(env, u, b.tok, extra);
  assert.equal(e.status, 200, JSON.stringify(e.json));
  const a = await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, gast);
  assert.equal(a.status, 200, JSON.stringify(a.json));
  return { gast, id: e.json.id, code: e.json.entwicklungsCode };
}
const tabellenVon = (j) => j.datensaetze.map((x) => x.tabelle);

test('Dienst: Version 13c-1, Gesundheit meldet Freigaben; ohne die Tabellen „false“, Anmelden geht trotzdem', async () => {
  const env = umgebung(), u = uhr();
  const g = (await ruf(env, u, 'GET', '/gesundheit')).json;
  assert.equal(g.version, '13c-1'); assert.equal(g.freigaben, true);
  const alt = umgebung(); alt.DB.roh.exec('DROP TABLE freigabe'); alt.DB.roh.exec('DROP TABLE kontrolle');
  assert.equal((await ruf(alt, u, 'GET', '/gesundheit')).json.freigaben, false);
  assert.ok(await konto(alt, u, 'a@example.org'), 'Anmelden und Aufräumen gehen auch ohne die neuen Tabellen');
  assert.equal((await ruf(alt, u, 'GET', '/freigabe/liste', undefined, await konto(alt, u, 'b@example.org'))).status, 503);
});

test('Einladen: nur angemeldet, nur eigene Fahrzeuge, Zeitraum höchstens 12 Monate, nicht an sich selbst', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  assert.equal((await einladen(env, u, undefined)).status, 401);
  assert.equal((await einladen(env, u, b.tok, { fahrzeugId: 'fz-gibt-es-nicht' })).status, 404);
  assert.equal((await einladen(env, u, b.tok, { email: 'besitzer@example.org' })).status, 400);
  assert.equal((await einladen(env, u, b.tok, { email: 'keine-adresse' })).status, 400);
  assert.equal((await einladen(env, u, b.tok, { bis: '2027-11-11' })).status, 200, 'genau 12 Monate sind erlaubt');
  const zuLang = await einladen(env, u, b.tok, { email: 'zwei@example.org', bis: '2027-11-12' });
  assert.equal(zuLang.status, 400); assert.equal(zuLang.json.feld, 'bis');
  assert.equal((await einladen(env, u, b.tok, { email: 'zwei@example.org', bis: '2026-11-10' })).status, 400, 'bis liegt in der Vergangenheit');
  assert.equal((await einladen(env, u, b.tok, { email: 'zwei@example.org', ab: '2026-11-10' })).status, 400, 'von liegt in der Vergangenheit');
  assert.equal((await einladen(env, u, b.tok, { email: 'zwei@example.org', ab: '2026-12-01', bis: '2026-11-30' })).status, 400, 'bis vor von');
  assert.equal((await einladen(env, u, b.tok, { email: 'zwei@example.org', bis: '2027-02-30' })).status, 400, 'ungültiges Datum');
  const spaet = await einladen(env, u, b.tok, { email: 'drei@example.org', ab: '2027-01-15', bis: '2028-01-15' });
  assert.equal(spaet.status, 200, '12 Monate gelten ab dem Beginn des Zeitraums');
  /* Ein fremdes Konto kann nicht für ein Fahrzeug einladen, das ihm nicht gehört. */
  const fremd = await konto(env, u, 'fremd@example.org');
  assert.equal((await einladen(env, u, fremd)).status, 404);
});

test('Einladung: Code gilt nur für die eingeladene Adresse und nur einmal; der Code selbst liegt nicht in der Datenbank', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  const e = await einladen(env, u, b.tok);
  assert.equal(e.status, 200); assert.match(e.json.entwicklungsCode, /^[2-9A-HJKMNP-Z]{10}$/);
  const alle = JSON.stringify(env.DB.roh.prepare('SELECT * FROM freigabe').all());
  assert.ok(!alle.includes(e.json.entwicklungsCode), 'nur ein Abdruck des Codes wird gespeichert');
  const fremd = await konto(env, u, 'fremd@example.org');
  const f = await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, fremd);
  assert.equal(f.status, 400, 'eine andere Adresse kann den Code nicht nutzen');
  assert.equal((await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode })).status, 401);
  const gast = await konto(env, u, 'gast@example.org');
  assert.equal((await ruf(env, u, 'POST', '/freigabe/annehmen', { code: 'XXXXXXXXXX' }, gast)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode.toLowerCase().replace(/^(.{5})/, '$1-') }, gast)).status, 200, 'Klein, mit Strich: geht');
  assert.equal((await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, gast)).status, 400, 'zweites Mal geht nicht');
});

test('Einladung: nach 14 Tagen ohne Annahme verfällt der Code; zu viele Versuche werden gebremst', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  const e = await einladen(env, u, b.tok);
  const gast = await konto(env, u, 'gast@example.org');
  u.t += 15 * TAG;
  assert.equal((await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, gast)).status, 400);
  const env2 = umgebung(), u2 = uhr(), g2 = await konto(env2, u2, 'g@example.org');
  let letzte;
  for (let i = 0; i < 12; i++) letzte = await ruf(env2, u2, 'POST', '/freigabe/annehmen', { code: 'AAAAAAAAAA' }, g2);
  assert.equal(letzte.status, 429);
});

test('Gast liest das Fahrzeug: Angaben, Fristen, Zähler, Dokumente, letztes Prüfergebnis, nichts sonst', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b);
  const r = await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast);
  assert.equal(r.status, 200, JSON.stringify(r.json));
  const ids = r.json.datensaetze.map((x) => x.tabelle + '/' + x.id).sort();
  assert.deepEqual(ids, ['dateien/da-1', 'dokumente/do-1', 'durchfuehrungen/du-1', 'eintraege/en-2', 'fahrzeuge/fz-1', 'fristen/fr-1', 'tagespruefungen/tp-1',
    'verlaeufe/ve-do-1', 'verlaeufe/ve-fr-1', 'verlaeufe/ve-za-1', 'zaehler/za-1', 'zaehlerstaende/zs-1'].sort());
  const alles = JSON.stringify(r.json);
  ['Standort geheim', '"betrag"', 'fz-2', 'da-2', 'na-1', 'nd-1', 'ko-1', 'er-1'].forEach((x) => assert.ok(!alles.includes(x), x + ' darf der Gast nicht sehen'));
  assert.equal(r.json.bis, '2027-03-31');
});

test('Rechte: Gast liest nur über /geteilt, nie über die Wege des Besitzers; fremdes Konto sieht nichts; ohne Anmeldung nichts', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b);
  const fremd = await konto(env, u, 'fremd@example.org');
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id)).status, 401);
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, fremd)).status, 403, 'fremdes Konto');
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=gibt-es-nicht', undefined, g.gast)).status, 403);
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug', undefined, g.gast)).status, 400);
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, b.tok)).status, 403, 'auch der Besitzer ist hier kein Gast (er hat seinen eigenen Weg)');
  /* Die Wege des Abgleichs und der Dateien gelten nur für den eigenen Datenraum des Gastes: Er hat keinen Zugriff auf den des Besitzers. */
  const ag = await ruf(env, u, 'GET', '/abgleich/aenderungen?seit=0', undefined, g.gast);
  assert.equal(ag.status, 200); assert.deepEqual(ag.json.eintraege, []);
  assert.equal((await roh(env, u, 'GET', '/datei?tabelle=dateien&id=da-1', undefined, g.gast)).status, 404);
  assert.deepEqual((await ruf(env, u, 'GET', '/datei/liste', undefined, g.gast)).json.dateien, []);
  /* Schreiben kann der Gast nirgends in den Datenraum des Besitzers: Seine Pakete landen in seinem eigenen Raum. */
  await senden(env, u, g.gast, [satz('fahrzeuge', { id: 'fz-1', datenraumId: '@', art: 'auto', erstelltAm: 9 })]);
  const nachher = await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast);
  assert.ok(nachher.json.datensaetze.some((x) => x.tabelle === 'fahrzeuge' && JSON.parse(x.nutzlast).art === 'wohnmobil'), 'die Daten des Besitzers sind unverändert');
  const beides = await ruf(env, u, 'GET', '/abgleich/aenderungen?seit=0', undefined, b.tok);
  assert.ok(beides.json.eintraege.every((x) => !(x.tabelle === 'fahrzeuge' && x.id === 'fz-1' && JSON.parse(x.nutzlast).art === 'auto')));
});

test('Rechte: andere Fahrzeuge desselben Besitzers bleiben unsichtbar, auch Dateien (falsches Fahrzeug)', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b);
  const ok = await roh(env, u, 'GET', '/geteilt/datei?freigabe=' + g.id + '&id=da-1', undefined, g.gast);
  assert.equal(ok.status, 200); assert.equal(new TextDecoder().decode(new Uint8Array(await ok.arrayBuffer())), 'Inhalt-Pdf-');
  assert.equal(ok.headers.get('Cache-Control'), 'no-store');
  assert.equal((await roh(env, u, 'GET', '/geteilt/datei?freigabe=' + g.id + '&id=da-2', undefined, g.gast)).status, 404, 'Datei eines anderen Fahrzeugs');
  assert.equal((await roh(env, u, 'GET', '/geteilt/datei?freigabe=' + g.id + '&id=nd-1', undefined, g.gast)).status, 404, 'Nachweis-Scan');
  assert.equal((await roh(env, u, 'GET', '/geteilt/datei?freigabe=' + g.id + '&id=..%2Fx', undefined, g.gast)).status, 400);
  const fremd = await konto(env, u, 'fremd@example.org');
  assert.equal((await roh(env, u, 'GET', '/geteilt/datei?freigabe=' + g.id + '&id=da-1', undefined, fremd)).status, 403);
  /* Eine Freigabe für Fahrzeug 2 öffnet Fahrzeug 1 nicht. */
  const e2 = await einladen(env, u, b.tok, { fahrzeugId: 'fz-2', email: 'zwei@example.org' });
  const g2 = await konto(env, u, 'zwei@example.org');
  assert.equal((await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e2.json.entwicklungsCode }, g2)).status, 200);
  assert.equal((await roh(env, u, 'GET', '/geteilt/datei?freigabe=' + e2.json.id + '&id=da-1', undefined, g2)).status, 404);
  assert.equal((await roh(env, u, 'GET', '/geteilt/datei?freigabe=' + e2.json.id + '&id=da-2', undefined, g2)).status, 200);
  const s2 = await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + e2.json.id, undefined, g2);
  assert.ok(!JSON.stringify(s2.json).includes('Mein Wohnmobil') && !JSON.stringify(s2.json).includes('fz-1'));
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g2)).status, 403, 'die Freigabe eines anderen Gastes');
});

test('Rechte: Zeitraum, Ablauf, Widerruf und Zurückgeben beenden den Zugriff sofort', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  const gast = await konto(env, u, 'gast@example.org');
  const e = await einladen(env, u, b.tok, { ab: '2026-11-13', bis: '2026-11-20' });
  assert.equal((await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e.json.entwicklungsCode }, gast)).status, 200);
  const lies = () => ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + e.json.id, undefined, gast);
  assert.equal((await lies()).status, 403, 'vor dem Beginn');
  const noch = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, gast)).json.erhalten[0];
  assert.equal(noch.status, 'wartet');
  u.t = Date.UTC(2026, 10, 13, 0, 0, 1); assert.equal((await lies()).status, 200, 'ab dem ersten Tag');
  u.t = Date.UTC(2026, 10, 20, 23, 59, 58); assert.equal((await lies()).status, 200, 'am letzten Tag bis Mitternacht');
  u.t = Date.UTC(2026, 10, 21, 0, 0, 1); assert.equal((await lies()).status, 403, 'abgelaufen');
  assert.equal((await ruf(env, u, 'GET', '/freigabe/liste', undefined, gast)).json.erhalten[0].status, 'abgelaufen');
  /* Widerruf durch den Besitzer */
  u.t = Date.UTC(2026, 10, 14, 12, 0, 0);
  assert.equal((await lies()).status, 200);
  const fremd = await konto(env, u, 'fremd@example.org');
  assert.equal((await ruf(env, u, 'POST', '/freigabe/widerrufen', { id: e.json.id }, fremd)).status, 404, 'ein fremdes Konto kann nicht widerrufen');
  assert.equal((await lies()).status, 200, 'das Widerrufen durch Fremde hat nichts geändert');
  assert.equal((await ruf(env, u, 'POST', '/freigabe/widerrufen', { id: e.json.id }, b.tok)).status, 200);
  assert.equal((await lies()).status, 403, 'sofort weg');
  assert.equal((await roh(env, u, 'GET', '/geteilt/datei?freigabe=' + e.json.id + '&id=da-1', undefined, gast)).status, 403);
  assert.deepEqual((await ruf(env, u, 'GET', '/freigabe/liste', undefined, gast)).json.erhalten, [], 'der Gast sieht sie nicht mehr');
  assert.equal((await ruf(env, u, 'POST', '/freigabe/widerrufen', { id: e.json.id }, b.tok)).status, 404, 'zweites Mal: gibt es nicht mehr');
  /* Zurückgeben durch den Gast */
  const e2 = await einladen(env, u, b.tok, { bis: '2026-12-31' });
  await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e2.json.entwicklungsCode }, gast);
  assert.equal((await ruf(env, u, 'POST', '/freigabe/widerrufen', { id: e2.json.id }, gast)).status, 200);
  assert.equal((await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + e2.json.id, undefined, gast)).status, 403);
});

test('Rechte: Fahrzeug beim Besitzer gelöscht oder Konto des Besitzers gelöscht: Der Gast sieht nichts mehr', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u), g = await freigabe(env, u, b);
  await ruf(env, u, 'POST', '/abgleich/senden', { eintraege: [{ tabelle: 'fahrzeuge', id: 'fz-1', basis: 1, geloescht: true }] }, b.tok);
  const r = await ruf(env, u, 'GET', '/geteilt/fahrzeug?freigabe=' + g.id, undefined, g.gast);
  assert.equal(r.status, 404);
  const env2 = umgebung(), u2 = uhr(), b2 = await besitzer(env2, u2), g2 = await freigabe(env2, u2, b2);
  assert.equal((await ruf(env2, u2, 'POST', '/konto/loeschen', { bestaetigung: 'LÖSCHEN' }, b2.tok)).status, 200);
  assert.equal((await ruf(env2, u2, 'GET', '/geteilt/fahrzeug?freigabe=' + g2.id, undefined, g2.gast)).status, 403);
  assert.equal(env2.DB.roh.prepare('SELECT COUNT(*) AS n FROM freigabe').get().n, 0, 'die Freigaben verschwinden mit dem Konto');
});

test('Einladung ersetzt eine ältere für dasselbe Fahrzeug und denselben Gast; die Liste zeigt Namen und Stand', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  const e1 = await einladen(env, u, b.tok), e2 = await einladen(env, u, b.tok);
  const gast = await konto(env, u, 'gast@example.org');
  assert.equal((await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e1.json.entwicklungsCode }, gast)).status, 400, 'der alte Code gilt nicht mehr');
  assert.equal((await ruf(env, u, 'POST', '/freigabe/annehmen', { code: e2.json.entwicklungsCode }, gast)).status, 200);
  const l = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, b.tok)).json;
  assert.equal(l.gegeben.length, 2);
  assert.deepEqual(l.gegeben.map((x) => x.status).sort(), ['aktiv', 'widerrufen']);
  assert.equal(l.gegeben[0].name, 'Mein Wohnmobil', 'der neueste Eintrag gibt den Namen');
  const gl = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, gast)).json;
  assert.deepEqual(gl.erhalten.map((x) => [x.name, x.von, x.status, x.bis]), [['Mein Wohnmobil', 'besitzer@example.org', 'aktiv', '2027-03-31']]);
  assert.deepEqual(gl.gegeben, []);
  assert.ok(!JSON.stringify(gl).includes('code'), 'die Liste verrät keinen Code');
});

test('Kontroll-Freigabe: Code ohne Konto, nur Papiere und Prüfergebnis, kurz gültig, widerrufbar, gebremst', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  assert.equal((await ruf(env, u, 'POST', '/kontrolle/erstellen', { fahrzeugId: 'fz-1' })).status, 401);
  assert.equal((await ruf(env, u, 'POST', '/kontrolle/erstellen', { fahrzeugId: 'nix' }, b.tok)).status, 404);
  assert.equal((await ruf(env, u, 'POST', '/kontrolle/erstellen', { fahrzeugId: 'fz-1', stunden: 169 }, b.tok)).status, 400);
  assert.equal((await ruf(env, u, 'POST', '/kontrolle/erstellen', { fahrzeugId: 'fz-1', stunden: 0 }, b.tok)).status, 400);
  const k = await ruf(env, u, 'POST', '/kontrolle/erstellen', { fahrzeugId: 'fz-1', stunden: 2 }, b.tok);
  assert.equal(k.status, 200); assert.match(k.json.code, /^[2-9A-HJKMNP-Z]{8}$/); assert.equal(k.json.laeuftAb, u.t + 2 * 60 * 60 * 1000);
  assert.ok(!JSON.stringify(env.DB.roh.prepare('SELECT * FROM kontrolle').all()).includes(k.json.code), 'nur ein Abdruck wird gespeichert');
  const lesen = await ruf(env, u, 'GET', '/kontrolle/lesen?code=' + k.json.code.toLowerCase(), undefined, undefined, '198.51.100.7');
  assert.equal(lesen.status, 200, 'ohne Anmeldung');
  assert.deepEqual(tabellenVon(lesen.json).sort(), ['dateien', 'dokumente', 'eintraege', 'fahrzeuge', 'tagespruefungen', 'verlaeufe']);
  const alles = JSON.stringify(lesen.json);
  ['Hauptuntersuchung', 'fr-1', 'za-1', 'Kilometerstand', 'Standort geheim', 'fz-2', 'da-2', 'na-1', 'ko-1', 'er-1'].forEach((x) => assert.ok(!alles.includes(x), x + ' gehört nicht zur Kontrolle'));
  assert.ok(alles.includes('Fahrzeugschein') && alles.includes('Mein Wohnmobil'));
  const datei = await roh(env, u, 'GET', '/kontrolle/datei?code=' + k.json.code + '&id=da-1', undefined, undefined, '198.51.100.7');
  assert.equal(datei.status, 200);
  assert.equal((await roh(env, u, 'GET', '/kontrolle/datei?code=' + k.json.code + '&id=da-2', undefined, undefined, '198.51.100.7')).status, 404, 'Datei eines anderen Fahrzeugs');
  assert.equal((await roh(env, u, 'GET', '/kontrolle/datei?code=' + k.json.code + '&id=nd-1', undefined, undefined, '198.51.100.7')).status, 404);
  assert.equal((await ruf(env, u, 'GET', '/kontrolle/lesen?code=ABCDEFGH', undefined, undefined, '198.51.100.7')).status, 404);
  assert.equal((await ruf(env, u, 'GET', '/kontrolle/lesen', undefined, undefined, '198.51.100.7')).status, 404);
  assert.equal((await ruf(env, u, 'GET', '/kontrolle/lesen?code=' + k.json.code, undefined, undefined, '198.51.100.7')).status, 200);
  /* Die Liste des Besitzers zeigt den Code nicht, aber den Stand. */
  const liste = (await ruf(env, u, 'GET', '/freigabe/liste', undefined, b.tok)).json.kontrollen;
  assert.deepEqual(liste.map((x) => [x.name, x.status]), [['Mein Wohnmobil', 'aktiv']]); assert.ok(!JSON.stringify(liste).includes(k.json.code));
  /* Ablauf */
  u.t += 2 * 60 * 60 * 1000 + 1;
  assert.equal((await ruf(env, u, 'GET', '/kontrolle/lesen?code=' + k.json.code, undefined, undefined, '198.51.100.7')).status, 404);
  /* Widerruf */
  const k2 = await ruf(env, u, 'POST', '/kontrolle/erstellen', { fahrzeugId: 'fz-1' }, b.tok);
  assert.equal(k2.json.laeuftAb, u.t + 24 * 60 * 60 * 1000, '24 Stunden sind der Standard');
  assert.equal((await ruf(env, u, 'GET', '/kontrolle/lesen?code=' + k2.json.code, undefined, undefined, '198.51.100.7')).status, 200);
  const fremd = await konto(env, u, 'fremd@example.org');
  assert.equal((await ruf(env, u, 'POST', '/kontrolle/widerrufen', { id: k2.json.id }, fremd)).status, 404);
  assert.equal((await ruf(env, u, 'POST', '/kontrolle/widerrufen', { id: k2.json.id }, b.tok)).status, 200);
  assert.equal((await ruf(env, u, 'GET', '/kontrolle/lesen?code=' + k2.json.code, undefined, undefined, '198.51.100.7')).status, 404);
  /* Bremse gegen Durchprobieren */
  let letzte;
  for (let i = 0; i < 45; i++) letzte = await ruf(env, u, 'GET', '/kontrolle/lesen?code=AAAAAAAA', undefined, undefined, '192.0.2.99');
  assert.equal(letzte.status, 429);
});

test('Kontroll-Freigabe: höchstens 10 gültige Codes, Freigaben höchstens 50; Abgelaufenes verschwindet nach 30 Tagen', async () => {
  const env = umgebung(), u = uhr(), b = await besitzer(env, u);
  for (let i = 0; i < 10; i++) assert.equal((await ruf(env, u, 'POST', '/kontrolle/erstellen', { fahrzeugId: 'fz-1', stunden: 1 }, b.tok)).status, 200);
  assert.equal((await ruf(env, u, 'POST', '/kontrolle/erstellen', { fahrzeugId: 'fz-1' }, b.tok)).status, 409);
  u.t += 31 * TAG;
  const neu = await konto(env, u, 'neu@example.org');
  await ruf(env, u, 'POST', '/konto/anmelden', { email: 'neu@example.org', passwort: PW });
  assert.equal(env.DB.roh.prepare('SELECT COUNT(*) AS n FROM kontrolle').get().n, 0, 'nach 30 Tagen aufgeräumt');
  assert.ok(neu);
});

test('Server-Dateien: 13c.sql hat je Anweisung eine Zeile und steht auch im Schema', () => {
  const sql = fs.readFileSync(path.join(__dirname, '..', 'server', '13c.sql'), 'utf8').trim().split('\n');
  assert.ok(sql.length >= 5);
  sql.forEach((z) => { assert.match(z, /^CREATE (TABLE|INDEX) IF NOT EXISTS .*;$/); });
  const schema = fs.readFileSync(path.join(__dirname, '..', 'server', 'schema.sql'), 'utf8');
  sql.forEach((z) => assert.ok(schema.includes(z), 'im Schema: ' + z.slice(0, 50)));
});
