'use strict';
/* 2.0.67 (Schritt 13c): Freigaben und Kontrolle mit echten Geräten (Daten, Speicher) gegen den Dienst mit nachgebauter Datenbank und nachgebautem Dateispeicher.
   Besitzer-Gerät, Gast-Gerät und ein Gerät ohne Konto (Kontrolle). */
const t = require('node:test');
let sqliteDa = true;
try { require('node:sqlite'); } catch (e) { sqliteDa = false; }
const test = sqliteDa ? t : (name) => t(name, { skip: 'node:sqlite fehlt (Node 22 nötig)' }, () => {});
const assert = require('node:assert/strict');
const { neueDatenbank } = require('./hilfen/d1-attrappe.js');
const { neuerR2 } = require('./hilfen/r2-attrappe.js');
['version', 'fahrzeugarten', 'komponenten', 'verbrauch', 'tanken', 'fristen', 'dokumente', 'nachweis-vorschlaege', 'nachweise', 'aktivitaeten', 'aktionen', 'baukasten',
  'logbuch', 'status', 'motoren', 'personen', 'orte', 'gebiete', 'ortssuche', 'sicherung', 'speicher', 'hilfen', 'werkstatt', 'kosten', 'reisekasse', 'reiseorte',
  'routen', 'etappen', 'reisecheck', 'karte', 'konto', 'freigaben', 'abgleich', 'daten'].forEach((n) => require('../js/' + n + '.js'));
const MM = globalThis.MM;

const APP = 'https://app.example.org';
const DIENST = 'https://konto.example.workers.dev';
const PW = 'Sehr-sicheres-Passwort-1';
let dienst;
async function laden() { if (!dienst) dienst = await import('../server/konto-dienst.mjs'); return dienst; }
function uhr() { const u = { t: Date.UTC(2026, 10, 11, 12, 0, 0) }; u.jetzt = () => u.t; return u; }

function geraetBauen(env, u) {
  return async function (ohneDienst) {
    const d0 = await laden();
    const f = async (url, methode, token, body) => {
      const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.7' };
      if (body !== undefined && body !== null) kopf['Content-Type'] = 'application/json';
      if (token) kopf.Authorization = 'Bearer ' + token;
      const r = await d0.behandeln(new Request(url, { method: methode, headers: kopf, body: body === undefined || body === null ? undefined : JSON.stringify(body) }), env, { jetzt: u.jetzt });
      const j = await r.json();
      if (!r.ok) { const e = new Error(j.error); e.status = r.status; e.feld = j.feld; throw e; }
      return j;
    };
    const fb = async (url, methode, token, bytes) => {
      const kopf = { Origin: APP, 'CF-Connecting-IP': '203.0.113.7' };
      if (token) kopf.Authorization = 'Bearer ' + token;
      if (bytes) { kopf['Content-Type'] = 'application/octet-stream'; kopf['Content-Length'] = String(bytes.length); }
      const r = await d0.behandeln(new Request(url, { method: methode, headers: kopf, body: bytes || undefined }), env, { jetzt: u.jetzt });
      if (!r.ok) { const j = await r.json(); const e = new Error(j.error); e.status = r.status; throw e; }
      if (methode === 'GET') return { bytes: new Uint8Array(await r.arrayBuffer()), verschluesselt: r.headers.get('X-Verschluesselt') === '1' };
      return { json: await r.json() };
    };
    let n = 0;
    const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { kontoAnfrage: f, kontoBytes: fb, jetzt: () => new Date(u.t + (n++) * 1000).toISOString() });
    await d.starten();
    if (!ohneDienst) await d.kontoDienstSpeichern(DIENST);
    return d;
  };
}
async function anmelden(d, email) {
  const r = await d.kontoRegistrieren({ email, passwort: PW });
  assert.equal((await d.kontoCodePruefen({ email, code: r.entwicklungsCode })).ok, true);
}
const text = async (bytes) => new TextDecoder().decode(bytes);

/* Besitzer mit einem Fahrzeug, einer Frist, einem Dokument samt Datei, einem Nachweis samt Scan und einer Notiz; alles abgeglichen. */
async function besitzerMitFahrzeug() {
  const env = { DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, u = uhr(), neu = geraetBauen(env, u);
  const a = await neu();
  await anmelden(a, 'besitzer@example.org');
  const fz = await a.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Mein Wohnmobil', kennzeichen: 'LB-AB 123' });
  assert.equal(fz.ok, true, JSON.stringify(fz));
  const fr = await a.fristAnlegen(fz.id, null, { kategorie: 'pruefung', bezeichnung: 'Hauptuntersuchung', kalenderWert: 2, kalenderEinheit: 'jahre', wirkung: 'sperre', vorwarnTage: 30, zuletztAm: '2025-03-01' });
  assert.equal(fr.ok, true, JSON.stringify(fr));
  await a.speicher.speichern('dokumente', { id: 'do-1', fahrzeugId: fz.id, komponenteId: null, vorgangId: null, erstelltAm: 'x' });
  await a.speicher.speichern('verlaeufe', { id: 've-do-1', objektTyp: 'dokument', objektId: 'do-1', nr: 1, werte: { bezeichnung: 'Fahrzeugschein', art: 'Papiere', link: null }, quelle: 'hand', korrekturZu: null, erstelltAm: 'x' });
  await a.speicher.speichern('dateien', { id: 'da-1', dokumentId: 'do-1', name: 'schein.pdf', mime: 'application/pdf', groesse: 11, inhalt: new Blob(['Rechnung 42']), erstelltAm: 'x' });
  await a.speicher.speichern('nachweise', { id: 'na-1', datenraumId: a.datenraumId, besitzerTyp: 'person', besitzerId: 'pe-1', artId: 'ar-1', erstelltAm: 'x' });
  await a.speicher.speichern('nachweisdateien', { id: 'nd-1', nachweisId: 'na-1', name: 'Fuehrerschein.jpg', mime: 'image/jpeg', groesse: 14, inhalt: new Blob(['Fuehrerschein!']), erstelltAm: 'x' });
  assert.equal((await a.abgleichAusfuehren()).ok, true);
  const dat = await a.dateienAbgleichen({ schluesselwort: 'mein-Schluesselwort' });
  assert.equal(dat.ok, true, JSON.stringify(dat));
  return { env, u, neu, a, fz: fz.id };
}

test('Freigabe von Anfang bis Ende: einladen, annehmen, ansehen, Datei öffnen, Frist, widerrufen; auf dem Gast-Gerät wird nichts gespeichert', async () => {
  const { u, neu, a, fz } = await besitzerMitFahrzeug();
  const gast = await neu();
  await anmelden(gast, 'gast@example.org');
  const fahrzeuge = await a.freigabeFahrzeuge();
  assert.deepEqual(fahrzeuge, [{ id: fz, name: 'Mein Wohnmobil' }]);
  /* Eingaben werden zuerst auf dem Gerät geprüft */
  assert.equal((await a.freigabeEinladen({ fahrzeugId: fz, email: 'kaputt', bis: '2027-03-31' })).fehler.email.length > 0, true);
  assert.match((await a.freigabeEinladen({ fahrzeugId: fz, email: 'gast@example.org', bis: '2030-01-01' })).fehler.bis, /höchstens 12 Monate/);
  const e = await a.freigabeEinladen({ fahrzeugId: fz, email: 'gast@example.org', bis: '2027-03-31' });
  assert.equal(e.ok, true, JSON.stringify(e)); assert.match(e.entwicklungsCode, /^[2-9A-HJKMNP-Z]{10}$/);
  /* Falscher Code, richtiger Code */
  assert.equal((await gast.freigabeAnnehmen({ code: 'zu kurz' })).ok, false);
  const falsch = await gast.freigabeAnnehmen({ code: 'AAAAAAAAAA' });
  assert.equal(falsch.ok, false); assert.match(falsch.fehler.code, /gilt nicht/);
  const ok = await gast.freigabeAnnehmen({ code: e.entwicklungsCode });
  assert.equal(ok.ok, true, JSON.stringify(ok));
  const liste = await gast.freigabeListe();
  assert.deepEqual(liste.erhalten.map((x) => [x.name, x.von, x.status]), [['Mein Wohnmobil', 'besitzer@example.org', 'aktiv']]);
  const g = await gast.geteiltLaden(ok.id);
  assert.equal(g.ok, true, JSON.stringify(g));
  assert.equal(g.sicht.fahrzeug.bezeichnung, 'Mein Wohnmobil'); assert.equal(g.bis, '2027-03-31');
  assert.equal(g.sicht.fristen.length, 1); assert.equal(g.sicht.fristen[0].name, 'Hauptuntersuchung');
  assert.deepEqual(g.sicht.dokumente.map((d) => [d.bezeichnung, d.dateien.map((x) => x.name)]), [['Fahrzeugschein', ['schein.pdf']]]);
  const datei = await gast.geteiltDatei(ok.id, 'da-1');
  assert.equal(datei.ok, true); assert.equal(await text(datei.bytes), 'Rechnung 42');
  assert.equal((await gast.geteiltDatei(ok.id, 'nd-1')).ok, false, 'der Scan des Nachweises ist nicht erreichbar');
  assert.equal((await gast.geteiltDatei(ok.id, 'nd-1')).status, 404);
  /* nichts davon liegt auf dem Gast-Gerät */
  assert.deepEqual(await gast.fahrzeugListe(), []);
  assert.deepEqual(await gast.speicher.alle('dokumente'), []); assert.deepEqual(await gast.speicher.alle('fristen'), []);
  /* Widerruf: Der Zugriff endet sofort */
  const gegeben = (await a.freigabeListe()).gegeben;
  assert.deepEqual(gegeben.map((x) => [x.email, x.status]), [['gast@example.org', 'aktiv']]);
  assert.equal((await a.freigabeWiderrufen(gegeben[0].id)).ok, true);
  const danach = await gast.geteiltLaden(ok.id);
  assert.equal(danach.ok, false); assert.equal(danach.beendet, true);
  assert.equal((await gast.geteiltDatei(ok.id, 'da-1')).ok, false);
  assert.deepEqual((await gast.freigabeListe()).erhalten, []);
  void u;
});

test('Kein Zugriff ohne Freigabe: fremdes Konto, anderes Fahrzeug, abgelaufen', async () => {
  const { u, neu, a, fz } = await besitzerMitFahrzeug();
  const gast = await neu(), fremd = await neu();
  await anmelden(gast, 'gast@example.org'); await anmelden(fremd, 'fremd@example.org');
  const e = await a.freigabeEinladen({ fahrzeugId: fz, email: 'gast@example.org', ab: '2026-11-11', bis: '2026-11-20' });
  const ok = await gast.freigabeAnnehmen({ code: e.entwicklungsCode });
  assert.equal((await fremd.geteiltLaden(ok.id)).ok, false, 'fremdes Konto');
  assert.equal((await fremd.freigabeAnnehmen({ code: e.entwicklungsCode })).ok, false, 'Code gilt nur einmal');
  assert.equal((await gast.geteiltLaden(ok.id)).ok, true);
  u.t = Date.UTC(2026, 10, 21, 0, 0, 1);
  const alt = await gast.geteiltLaden(ok.id);
  assert.equal(alt.ok, false); assert.equal(alt.beendet, true);
  assert.equal((await gast.freigabeListe()).erhalten[0].status, 'abgelaufen');
  /* Ein Fahrzeug, das nicht beim Dienst liegt, kann nicht freigegeben werden */
  const b = await a.freigabeEinladen({ fahrzeugId: 'fz-gibt-es-nicht', email: 'gast@example.org', bis: '2026-12-31' });
  assert.equal(b.ok, false);
});

test('Ohne Anmeldung kein Freigeben; ein Gerät ohne Dienst bekommt einen klaren Hinweis', async () => {
  const env = { DB: neueDatenbank(), DATEN: neuerR2(), PASSWORT_PEPPER: 'p'.repeat(40), ERLAUBTE_URSPRUENGE: APP, ENTWICKLUNG: '1' }, u = uhr(), neu = geraetBauen(env, u);
  const d = await neu();
  const r = await d.freigabeEinladen({ fahrzeugId: 'x', email: 'g@example.org', bis: '2027-01-01' });
  assert.equal(r.ok, false);
  const kein = await (await neu(true)).freigabeListe();
  assert.equal(kein.ok, false); assert.match(kein.fehler.allgemein, /Adresse des Dienstes/);
});

test('Kontroll-Freigabe: Code erzeugen, Kontrolle liest ohne Konto und ohne eingerichtetes Gerät, nur Papiere und Prüfergebnis, widerrufen', async () => {
  const { neu, a, fz } = await besitzerMitFahrzeug();
  const k = await a.kontrolleErstellen({ fahrzeugId: fz, stunden: 4 });
  assert.equal(k.ok, true, JSON.stringify(k)); assert.match(k.code, /^[2-9A-HJKMNP-Z]{8}$/); assert.equal(k.dienstUrl, DIENST);
  assert.equal((await a.kontrolleErstellen({ fahrzeugId: fz, stunden: 999 })).ok, false);
  /* Der Link trägt Code und Dienst, das Gerät des Kontrolleurs hat weder Konto noch Dienst eingetragen. */
  const link = MM.Freigaben.kontrollLink('https://app.example.org/', k.dienstUrl, k.code);
  const teile = link.replace(/^.*#/, '').split('/').filter(Boolean);
  const l = MM.Freigaben.kontrollLinkLesen(teile[1], teile[2]);
  const kontrolleur = await neu(true);
  const r = await kontrolleur.kontrolleLesen(l.dienstUrl, l.code);
  assert.equal(r.ok, true, JSON.stringify(r));
  assert.equal(r.sicht.fahrzeug.bezeichnung, 'Mein Wohnmobil');
  assert.deepEqual(r.sicht.fristen, [], 'keine Fristen in der Kontrolle'); assert.deepEqual(r.sicht.zaehler, []);
  assert.deepEqual(r.sicht.dokumente.map((d) => d.bezeichnung), ['Fahrzeugschein']);
  const datei = await kontrolleur.kontrolleDatei(l.dienstUrl, l.code, 'da-1');
  assert.equal(datei.ok, true); assert.equal(await text(datei.bytes), 'Rechnung 42');
  assert.equal((await kontrolleur.kontrolleDatei(l.dienstUrl, l.code, 'nd-1')).ok, false);
  assert.deepEqual(await kontrolleur.fahrzeugListe(), [], 'nichts bleibt auf dem Gerät des Kontrolleurs');
  assert.equal((await kontrolleur.rcGeraet()).kontoDienstUrl, undefined, 'das Gerät wurde nicht eingerichtet');
  const falsch = await kontrolleur.kontrolleLesen(DIENST, 'AAAAAAAA');
  assert.equal(falsch.ok, false); assert.match(falsch.fehler, /gilt nicht/);
  assert.equal((await kontrolleur.kontrolleLesen('keine adresse', l.code)).ok, false);
  assert.equal((await kontrolleur.kontrolleLesen(DIENST, 'kurz')).ok, false);
  const liste = (await a.freigabeListe()).kontrollen;
  assert.deepEqual(liste.map((x) => [x.name, x.status]), [['Mein Wohnmobil', 'aktiv']]);
  assert.equal((await a.kontrolleWiderrufen(liste[0].id)).ok, true);
  assert.equal((await kontrolleur.kontrolleLesen(l.dienstUrl, l.code)).ok, false, 'nach dem Widerruf sofort ungültig');
});
