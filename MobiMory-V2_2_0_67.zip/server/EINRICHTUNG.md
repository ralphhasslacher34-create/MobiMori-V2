# Konto-Dienst einrichten (Schritt 13a, Abgleich und Sicherung 13b, Dateien 13d, Freigaben 13c)

Das ist die Anleitung für den kleinen Dienst, bei dem sich die App anmeldet. Er läuft bei Cloudflare, wie schon der Recherchedienst.
Die Namen der Menüpunkte im Cloudflare-Dashboard können etwas anders heißen. Wenn etwas nicht passt, schreib mir, was du siehst.

Es gibt **zwei Dienste**, damit nichts durcheinanderkommt:

| | Test-Dienst | Echter Dienst |
|---|---|---|
| Name des Workers | `mobimory-konto-test` | `mobimory-konto` |
| Datenbank | `mobimory-konten-test` | `mobimory-konten` |
| `ENTWICKLUNG` | **1** (der Code erscheint in der App statt per E-Mail) | **nicht setzen, nie** |
| E-Mail-Versand | nicht nötig | nötig, eigene Domain |
| Kosten | kostenlos (siehe Hinweis unten) | bezahlter Tarif, etwa 5 $ im Monat |

Mit dem Test-Dienst kannst du alles ausprobieren, auch ohne eigene Domain. Der echte Dienst kommt erst vor dem öffentlichen Start.

## 1. Datenbank anlegen (EU, nur beim Anlegen einstellbar)

1. Cloudflare-Dashboard → **D1 SQL Database** → **Create Database**.
2. Name: `mobimory-konten-test`.
3. Bei **Data location** den Punkt **Specify jurisdiction** wählen und **European Union** auswählen. Das geht nur jetzt, später nicht mehr.
4. **Create**.
5. In der neuen Datenbank den Reiter **Console** öffnen und die SQL-Zeilen aus `server/schema.sql` ausführen, **jede Anweisung einzeln** (am Tablet klappt das Einfügen langer Texte nicht). Nacheinander entstehen alle Tabellen. Mehrfaches Ausführen schadet nicht.

## 2. Dateispeicher anlegen (R2, gebraucht ab Schritt 13d)

1. Dashboard → **R2** → **Create bucket**, Name `mobimory-daten-test`.
2. Beim Speicherort die Jurisdiktion **EU** wählen. Auch das geht nur beim Anlegen.

## 3. Worker anlegen und mit GitHub verbinden

Das Einfügen langer Texte im Cloudflare-Editor klappt am Tablet nicht. Deshalb baut Cloudflare den Dienst selbst aus dem Repository.

1. Dashboard → **Workers & Pages** → **Create** → **Worker**. Cloudflare vergibt dem Worker selbst einen Namen (zum Beispiel `winter-violet-1a11`). Den Namen nimmst du so, wie er ist. **Deploy**.
2. Im Worker unter **Settings → Builds** das Repository `MobiMori-V2` verbinden. Zweig `main`, **Root directory** `/`, **Build command** leer, **Deploy command** `npx wrangler deploy`.
3. Im **Hauptverzeichnis des Repositorys** (dort, wo auch die ZIP-Dateien und der Ordner `.github` liegen) müssen zwei einzelne Dateien liegen: `konto-dienst.mjs` und `wrangler.jsonc`. Sie stehen in diesem ZIP im Ordner `server/` und werden **einzeln** ins Hauptverzeichnis hochgeladen (nicht der ganze Ordner). In `wrangler.jsonc` stehen der Name des Workers, die Bindung `DB` (mit der Nummer deiner Datenbank), die Bindung `DATEN` für R2 und `keep_vars: true`, damit die Variablen aus dem Dashboard bei jedem Bau erhalten bleiben.
4. Der Workflow `.github/workflows/veroeffentlichen.yml` veröffentlicht nur die App. Der Dienst baut sich über Cloudflare.

## 4. Verbinden und einstellen

Im Worker unter **Settings**:

1. **Bindings**: Die Bindungen `DB` (D1, Datenbank `mobimory-konten-test`) und `DATEN` (R2, Bucket `mobimory-daten-test`) stehen in `wrangler.jsonc` und erscheinen nach dem ersten Bau von selbst. Im Dashboard muss man sie nicht anlegen. (Am Tablet muss man zum Ansehen herauszoomen.)
3. **Variables and Secrets** → **Add variable**. Im Fenster weitere Zeilen mit **+ Add** ergänzen. Ein gelber Hinweis zu Wrangler darf ignoriert werden. Einzutragen:
   - Typ **Text**: `ERLAUBTE_URSPRUENGE` = die Adresse der App ohne Pfad und ohne Schrägstrich am Ende. Vermutlich `https://ralphhasslacher34-create.github.io` (die genaue Adresse steht in GitHub unter *Settings > Pages*). Kein Punkt und kein Schrägstrich am Ende (ein Punkt am Ende lässt den Dienst die App ablehnen). Mehrere Adressen mit Komma trennen.
   - Typ **Text**: `ENTWICKLUNG` = `1` (**nur beim Test-Dienst**).
   - Typ **Secret (Geheimnis)**: `PASSWORT_PEPPER` = eine lange Zufallsfolge, mindestens 32 Zeichen, am besten 40 bis 60 Buchstaben und Ziffern aus einem Passwortgenerator. **Gut aufbewahren und nie ändern.** Ohne dieses Geheimnis passt kein Passwort mehr, und eine Wiederherstellung gibt es nicht.
4. Speichern und neu bereitstellen.

## 5. In der App eintragen und ausprobieren

1. Die Adresse des Workers steht oben im Worker (`https://mobimory-konto-test.….workers.dev`).
2. In MobiMory: **Funktionen → Konto**. Adresse eintragen, **Speichern**, **Verbindung testen**. Die App sagt, falls noch etwas fehlt (Tabellen, Geheimnis, E-Mail).
3. **Neues Konto mit Passwort** oder **Anmelden mit Code**. Beim Test-Dienst steht der Code auf dem Bildschirm.

## Hinweise

- **Kostenloser Tarif:** Das Prüfen eines Passworts rechnet länger als die 10 Millisekunden, die der kostenlose Tarif pro Anfrage erlaubt. Es kann sein, dass Anmeldungen mit Passwort beim Test-Dienst mit einem Fehler wie „Exceeded CPU“ scheitern. Das ist kein Fehler im Dienst, dann brauchst du auch für den Test den bezahlten Tarif (etwa 5 $ im Monat). Die Anmeldung mit Code ist davon weniger betroffen. Schreib mir den genauen Fehler, dann sehen wir weiter.
- **Passwort-Abdruck:** Cloudflare erlaubt höchstens 100 000 Runden. Das ist weniger als die Empfehlung von OWASP (600 000). Das gehört auf die Liste für den Datenschutz-Fachmann vor dem öffentlichen Start.
- **E-Mail im echten Dienst:** Dafür braucht es eine eigene Domain, die bei Cloudflare für den E-Mail-Versand eingerichtet ist (Dashboard → Email Service), und die Bindung `EMAIL` (Typ *Send Email*) sowie die Variable `ABSENDER` (zum Beispiel `konto@deine-domain.de`). Nach der Cloudflare-Dokumentation sind im bezahlten Tarif 3 000 Mails im Monat enthalten, danach etwa 0,35 $ je 1 000. Vor dem Start die aktuellen Preise prüfen.
- **Nicht im Repository:** Das Geheimnis `PASSWORT_PEPPER` gehört nie in eine Datei, nie in GitHub und nie in einen Chat.
- **Wenn etwas schiefgeht:** Unter *Workers → mobimory-konto-test → Logs* stehen Fehlermeldungen. Schreib sie mir einfach ab.

## Einrichten mit wrangler (nur falls du es lieber so machst)

`server/wrangler.jsonc` ist dafür vorbereitet. Datenbank mit `npx wrangler d1 create mobimory-konten --jurisdiction eu`, Tabellen mit `npx wrangler d1 execute mobimory-konten --remote --file=schema.sql`, Geheimnis mit `npx wrangler secret put PASSWORT_PEPPER`, dann `npx wrangler deploy`.

## Den Dienst aktualisieren (seit 13b-1)

Der Dienst bleibt derselbe Worker. Datenbank, Variablen und Geheimnis bleiben.

- **Programmtext:** Die neue `konto-dienst.mjs` im Hauptverzeichnis des Repositorys hochladen (ersetzt die alte). Cloudflare baut nach ein bis zwei Minuten selbst (Worker → **Deployments**).
- **Neue Bindung oder neue Einstellung:** Dann ändert sich auch `wrangler.jsonc`. Sie wird ebenso hochgeladen.
- **Neue SQL-Zeilen:** In der D1-Datenbank → **Console**, **jede Zeile einzeln**. Die fertigen Zeilen stehen in einer eigenen Datei (zu 13d: `server/13d.sql`, zu 13c: `server/13c.sql`).
- **Falle beim Hochladen (ist schon passiert):** Beim Hochladen kann eine Datei mit Leerzeichen im Namen entstehen, zum Beispiel `konto-dienst .mjs` neben der alten `konto-dienst.mjs`. Cloudflare baut dann weiter aus der alten Datei, und `/gesundheit` zeigt die alte Version. **Darum: zuerst die alte Datei im Repository löschen, dann die neue hochladen und vorher den Dateinamen prüfen.** Ist es doch passiert: die alte Datei löschen und die neue in `konto-dienst.mjs` umbenennen. Prüfen immer mit `/gesundheit` (die Version muss stimmen).

## Update auf 13d (Dateien auf dem Konto, seit 2.0.66)

1. **R2-Bucket** `mobimory-daten-test` anlegen (Abschnitt 2), falls noch nicht geschehen. **Jurisdiktion EU** wählen, das geht nur beim Anlegen.
2. **Neue Tabelle:** In der D1-Console die **eine** Zeile aus `server/13d.sql` ausführen. Vorhandene Daten bleiben.
3. **Zwei Dateien ins Hauptverzeichnis des Repositorys hochladen** (ersetzen die alten): `konto-dienst.mjs` und `wrangler.jsonc` (mit der neuen Bindung `DATEN`, Jurisdiktion `eu`). Cloudflare baut selbst.
4. **Prüfen:** Adresse des Workers mit `/gesundheit` aufrufen. Es muss `"version":"13d-1"`, `"abgleich":true`, `"dateien":true` und `"speicher":true` stehen. In der App: Konto → Verbindung testen, dann **Jetzt abgleichen**.

Grenzen im Test (Version 13d-1): Eine Datei darf höchstens 20 MB groß sein, ein Konto darf zusammen höchstens 1 GB an Dateien haben. Zum Vergleich: Der kostenlose Teil von R2 umfasst 10 GB im Monat für alle Konten zusammen. Die Grenzen je Stufe kommen mit 13e.

## Update auf 13c (Freigaben und Kontroll-Code, seit 2.0.67)

Es gibt **keine neue Bindung** und **keine neue Einstellung**. Nur der Programmtext und zwei neue Tabellen.

1. **Neue Tabellen:** In der D1-Console die **sieben Zeilen** aus `server/13c.sql` ausführen, **jede einzeln** (zwei Tabellen und fünf Verzeichnisse). Vorhandene Daten bleiben. Mehrfaches Ausführen schadet nicht.
2. **Eine Datei ins Hauptverzeichnis des Repositorys hochladen:** `konto-dienst.mjs`. **Zuerst die alte Datei löschen, dann die neue hochladen** und den Dateinamen prüfen (kein Leerzeichen). `wrangler.jsonc` bleibt unverändert. Cloudflare baut selbst (Worker → **Deployments**).
3. **Prüfen:** Adresse des Workers mit `/gesundheit` aufrufen. Es muss `"version":"13c-1"` und `"freigaben":true` stehen (dazu wie vorher `abgleich`, `dateien`, `speicher` auf `true`).
4. **In der App** (Version 2.0.67): Funktionen → **Freigaben**.

Wie es arbeitet:
- Ein Gast liest nur über eigene Wege des Dienstes (`/geteilt/…`). Die Wege des Abgleichs und der Dateien gelten weiter nur für den eigenen Datenraum.
- Bei **jeder** Anfrage prüft der Dienst: angemeldet, Freigabe gehört diesem Konto, angenommen, nicht widerrufen, Zeitraum. Widerruf und Ablauf wirken sofort.
- Die Einladung geht an eine E-Mail-Adresse. Beim **Test-Dienst** (`ENTWICKLUNG` = 1) geht keine Mail raus, der Code steht in der App. Im echten Dienst geht er per E-Mail (`EMAIL` und `ABSENDER`, wie bei der Anmeldung).
- Der Kontroll-Code funktioniert ohne Konto. Falsche Versuche werden je Adresse gebremst.
- Abgelaufene und widerrufene Freigaben verschwinden nach 30 Tagen aus der Datenbank.
