'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../js/version.js');
require('../js/fahrzeugarten.js');
require('../js/komponenten.js');
require('../js/fristen.js');
require('../js/dokumente.js');
require('../js/nachweis-vorschlaege.js');
require('../js/nachweise.js');
require('../js/aktivitaeten.js');
require('../js/personen.js');
require('../js/sicherung.js');
require('../js/speicher.js');
require('../js/hilfen.js');
require('../js/daten.js');
const MM = globalThis.MM;

/* feste Uhr: 3. November 2026, 12:00 Ortszeit */
const JETZT = new Date(2026, 10, 3, 12, 0, 0).toISOString();
async function neu() {
  let t = 0;
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher(), { jetzt: () => new Date(new Date(JETZT).getTime() + (t++) * 1000).toISOString() });
  await d.starten();
  await d.aktivitaetsartenAusVorschlaegen();
  const boot = (await d.fahrzeugAnlegen('boot', { bezeichnung: 'Boot' })).id;
  const wm = (await d.fahrzeugAnlegen('wohnmobil', { bezeichnung: 'Wohnmobil' })).id;
  const anna = (await d.personAnlegen({ bezeichnung: 'Anna', funktionen: ['Skipper'] })).id;
  const ben = (await d.personAnlegen({ bezeichnung: 'Ben', funktionen: ['Skipper'] })).id;
  const cora = (await d.personAnlegen({ bezeichnung: 'Cora', funktionen: ['Crew'] })).id;
  const arten = await d.aktivitaetsartenListe();
  const artId = n => arten.find(x => x.aktuell.werte.bezeichnung === n).objekt.id;
  return { d, boot, wm, anna, ben, cora, artId };
}
const basis = (c, extra) => Object.assign({ bezeichnung: 'Sommertörn', artId: c.artId('Törn'), fahrzeugId: c.boot, vonDatum: '2026-12-01', bisDatum: '2026-12-10', verantwortlichId: c.anna }, extra || {});

test('Aktivitätsarten: Vorschläge übernehmen, nur die fehlenden, eigene Art, doppelt nicht', async () => {
  const { d } = await neu();
  const liste = await d.aktivitaetsartenListe();
  assert.deepEqual(liste.map(x => x.aktuell.werte.bezeichnung), ['Ausfahrt', 'Rallye', 'Segeln', 'Törn', 'Urlaub', 'Wasserski']);
  assert.equal((await d.aktivitaetsartenAusVorschlaegen()).anzahl, 0);
  assert.ok((await d.aktivitaetsartAnlegen({ bezeichnung: 'Angeln' })).ok);
  assert.ok((await d.aktivitaetsartAnlegen({ bezeichnung: 'angeln' })).fehler.bezeichnung);
  assert.ok((await d.aktivitaetsartAnlegen({ bezeichnung: ' ' })).fehler.bezeichnung);
  assert.equal((await d.aktivitaetsartenListe()).length, 7);
});

test('Aktivität anlegen: Besatzung mit Verantwortlichem, Verantwortung ab Beginn, Status geplant', async () => {
  const c = await neu();
  const r = await c.d.aktivitaetAnlegen(basis(c, { vonZeit: '09:00', gebiet: '', geplanteStrecke: '120', tierIds: [] }));
  assert.ok(r.ok);
  const a = await c.d.aktivitaetLaden(r.id);
  assert.equal(a.aktuell.werte.bezeichnung, 'Sommertörn');
  assert.equal(a.aktuell.werte.status, 'geplant');
  assert.equal(a.aktuell.werte.geplanteStrecke, 120);
  assert.equal(a.aktuell.quelle, 'hand');
  assert.equal(a.art.name, 'Törn');
  assert.equal(a.fahrzeug.welt, 'wasser');
  assert.deepEqual(a.besatzung.map(b => [b.person.name, b.rolleText]), [['Anna', 'Skipper']]);
  assert.deepEqual(a.verantwortung.map(v => [v.name, v.ab]), [['Anna', '2026-12-01T09:00']]);
  assert.equal(a.status, 'geplant');
});

test('Aktivität: Pflichtangaben und Zeitraum', async () => {
  const c = await neu();
  const f = async extra => (await c.d.aktivitaetAnlegen(basis(c, extra))).fehler || {};
  assert.ok((await f({ bezeichnung: ' ' })).bezeichnung);
  assert.ok((await f({ artId: '' })).artId);
  assert.ok((await f({ fahrzeugId: 'gibt-es-nicht' })).fahrzeugId);
  assert.ok((await f({ vonDatum: '' })).vonDatum);
  assert.ok((await f({ bisDatum: '2026-11-30' })).bisDatum);
  assert.ok((await f({ vonDatum: '2026-12-01', bisDatum: '2026-12-01', vonZeit: '14:00', bisZeit: '09:00' })).bisZeit);
  assert.ok((await f({ vonZeit: '25:00' })).vonZeit);
  assert.ok((await f({ verantwortlichId: 'x' })).verantwortlichId);
  assert.ok((await f({ geplanteStrecke: 'viel' })).geplanteStrecke);
  assert.ok((await f({ tierIds: ['gibt-es-nicht'] })).ok !== false, 'unbekannte Tiere werden einfach ignoriert');
  assert.equal((await c.d.aktivitaetenListe()).filter(x => x.aktuell.werte.bezeichnung === 'Sommertörn').length, 1, 'nur die gültige Eingabe wurde gespeichert');
});

test('Aktivität ohne Person oder Fahrzeug: verständliche Hinweise', async () => {
  const d = new MM.Daten.Daten(new MM.Speicher.MemorySpeicher());
  await d.starten();
  const r = await d.aktivitaetAnlegen({ bezeichnung: 'X', vonDatum: '2026-12-01', bisDatum: '2026-12-02' });
  assert.ok(r.fehler.verantwortlichId.includes('Person'));
  assert.ok(r.fehler.fahrzeugId.includes('Fahrzeug'));
  assert.ok(r.fehler.artId.includes('Art'));
});

test('Aktivität ändern = neuer Eintrag "Korrektur zu", Namen im Verlauf lesbar', async () => {
  const c = await neu();
  const t = (await c.d.tierAnlegen({ bezeichnung: 'Bello', tierart: 'Hund' })).id;
  const { id } = await c.d.aktivitaetAnlegen(basis(c));
  const r = await c.d.aktivitaetAendern(id, basis(c, { bezeichnung: 'Sommertörn Kroatien', fahrzeugId: c.wm, tierIds: [t], bisDatum: '2026-12-12' }));
  assert.ok(r.ok && r.geaendert);
  const a = await c.d.aktivitaetLaden(id);
  assert.equal(a.verlauf.length, 2);
  assert.equal(a.aktuell.werte.bezeichnung, 'Sommertörn Kroatien');
  assert.deepEqual(a.tiere.map(x => x.name), ['Bello']);
  const u = Object.fromEntries(a.verlauf[0].aenderungen.map(x => [x.key, [x.alt, x.neu]]));
  assert.deepEqual(u.fahrzeugId, ['Boot', 'Wohnmobil']);
  assert.deepEqual(u.tierIds, [null, 'Bello']);
  assert.equal((await c.d.aktivitaetAendern(id, basis(c, { bezeichnung: 'Sommertörn Kroatien', fahrzeugId: c.wm, tierIds: [t], bisDatum: '2026-12-12' }))).geaendert, false);
});

test('Stornieren: nichts wird gelöscht, Grund bleibt, wieder herstellen möglich, storniert ist nicht änderbar', async () => {
  const c = await neu();
  const { id } = await c.d.aktivitaetAnlegen(basis(c));
  const s = await c.d.aktivitaetStornieren(id, 'Wetter');
  assert.ok(s.ok && s.geaendert);
  let a = await c.d.aktivitaetLaden(id);
  assert.equal(a.aktuell.werte.status, 'storniert'); assert.equal(a.aktuell.werte.stornoGrund, 'Wetter'); assert.ok(a.aktuell.werte.stornoAm);
  assert.equal(a.status, 'storniert');
  assert.equal(a.verlauf.length, 2);
  assert.equal((await c.d.aktivitaetStornieren(id, 'nochmal')).ok, false);
  assert.ok((await c.d.aktivitaetAendern(id, basis(c))).fehler.allgemein.includes('storniert'));
  assert.equal((await c.d.aktivitaetenListe()).length, 1, 'bleibt in der Liste');
  assert.ok((await c.d.aktivitaetWiederherstellen(id)).ok);
  a = await c.d.aktivitaetLaden(id);
  assert.equal(a.aktuell.werte.status, 'geplant'); assert.equal(a.aktuell.werte.stornoGrund, null); assert.equal(a.verlauf.length, 3);
  assert.equal((await c.d.aktivitaetWiederherstellen(id)).ok, false);
});

test('Besatzung: einmal pro Person, Stellvertreter und Crew, dabei von bis, wieder aufnehmen', async () => {
  const c = await neu();
  const { id } = await c.d.aktivitaetAnlegen(basis(c));
  assert.ok((await c.d.besatzungHinzufuegen(id, c.ben, { rolle: 'stellvertreter' })).ok);
  const cb = await c.d.besatzungHinzufuegen(id, c.cora, { rolle: 'crew', dabeiVonDatum: '2026-12-03', dabeiBisDatum: '2026-12-08', dabeiVonZeit: '10:00' });
  assert.ok(cb.ok);
  assert.ok((await c.d.besatzungHinzufuegen(id, c.cora, { rolle: 'crew' })).fehler.personId.includes('schon dabei'));
  assert.ok((await c.d.besatzungHinzufuegen(id, c.ben, { rolle: 'verantwortlich' })).ok === false);
  assert.ok((await c.d.besatzungHinzufuegen(id, c.cora, { rolle: 'unsinn' })).ok === false);
  assert.ok((await c.d.besatzungHinzufuegen(id, 'gibt-es-nicht', { rolle: 'crew' })).fehler.personId);
  assert.ok((await c.d.besatzungAendern(cb.id, { rolle: 'crew', dabeiVonDatum: '2026-12-08', dabeiBisDatum: '2026-12-03' })).fehler.dabeiBisDatum);
  let a = await c.d.aktivitaetLaden(id);
  assert.deepEqual(a.besatzung.map(b => [b.person.name, b.rolleText]), [['Anna', 'Skipper'], ['Ben', 'Stellvertreter'], ['Cora', 'Crew']]);
  /* Crew austauschbar: entfernen, später wieder aufnehmen; die frühere Zeit bleibt im Verlauf */
  assert.ok((await c.d.besatzungAendern(cb.id, { rolle: 'crew', entfernt: 'ja' })).ok);
  a = await c.d.aktivitaetLaden(id);
  assert.deepEqual(a.besatzung.map(b => b.person.name), ['Anna', 'Ben']);
  assert.deepEqual(a.entfernte.map(b => b.person.name), ['Cora']);
  assert.ok((await c.d.besatzungHinzufuegen(id, c.cora, { rolle: 'stellvertreter' })).ok);
  a = await c.d.aktivitaetLaden(id);
  assert.equal(a.besatzung.length, 3);
  assert.equal(a.besatzung.find(b => b.person.name === 'Cora').aktuell.nr, 3, 'drei Einträge: angelegt, entfernt, wieder aufgenommen');
});

test('Verantwortung wechseln: nur Skipper/Fahrer und Stellvertreter, mit Zeitpunkt, zeitlich geordnet', async () => {
  const c = await neu();
  const { id } = await c.d.aktivitaetAnlegen(basis(c));
  await c.d.besatzungHinzufuegen(id, c.ben, { rolle: 'stellvertreter' });
  await c.d.besatzungHinzufuegen(id, c.cora, { rolle: 'crew' });
  assert.ok((await c.d.verantwortungWechseln(id, c.cora, { abDatum: '2026-12-05', abZeit: '14:00' })).fehler.personId.includes('Stellvertreter'));
  assert.ok((await c.d.verantwortungWechseln(id, c.ben, { abDatum: '2026-12-05' })).fehler.abZeit);
  assert.ok((await c.d.verantwortungWechseln(id, c.ben, { abZeit: '14:00' })).fehler.abDatum);
  assert.ok((await c.d.verantwortungWechseln(id, c.ben, { abDatum: '2026-12-05', abZeit: '14:00' })).ok);
  assert.ok((await c.d.verantwortungWechseln(id, c.ben, { abDatum: '2026-12-06', abZeit: '10:00' })).fehler.personId.includes('schon verantwortlich'));
  assert.ok((await c.d.verantwortungWechseln(id, c.anna, { abDatum: '2026-12-05', abZeit: '14:00' })).fehler.abDatum, 'nicht vor dem letzten Wechsel');
  assert.ok((await c.d.verantwortungWechseln(id, c.anna, { abDatum: '2026-12-08', abZeit: '09:00' })).ok);
  const a = await c.d.aktivitaetLaden(id);
  assert.deepEqual(a.verantwortung.map(v => [v.name, v.ab]), [['Anna', '2026-12-01T00:00'], ['Ben', '2026-12-05T14:00'], ['Anna', '2026-12-08T09:00']]);
  assert.equal(MM.Aktivitaeten.verantwortlicher(a.verantwortung, '2026-12-06T00:00').name, 'Ben');
  assert.equal(MM.Aktivitaeten.verantwortlicher(a.verantwortung, '2026-12-09T00:00').name, 'Anna');
});

test('Wer zuletzt verantwortlich ist, kann nicht entfernt oder zur Crew gemacht werden', async () => {
  const c = await neu();
  const { id } = await c.d.aktivitaetAnlegen(basis(c));
  const be = await c.d.besatzungHinzufuegen(id, c.ben, { rolle: 'stellvertreter' });
  const a = await c.d.aktivitaetLaden(id);
  const annaB = a.besatzung.find(b => b.person.name === 'Anna').besatzung.id;
  assert.ok((await c.d.besatzungAendern(annaB, { rolle: 'verantwortlich', entfernt: 'ja' })).fehler.allgemein.includes('Verantwortung'));
  assert.ok((await c.d.besatzungAendern(annaB, { rolle: 'crew' })).fehler.allgemein.includes('Verantwortung'));
  await c.d.verantwortungWechseln(id, c.ben, { abDatum: '2026-12-02', abZeit: '08:00' });
  assert.ok((await c.d.besatzungAendern(annaB, { rolle: 'crew' })).ok, 'jetzt ist Anna frei');
  assert.ok((await c.d.besatzungAendern(be.id, { rolle: 'crew' })).fehler.allgemein, 'Ben ist jetzt der Verantwortliche');
});

test('Anforderungen am Fahrzeug: Nachweisarten für Personen, mindestens eine, ändern, abschalten', async () => {
  const c = await neu();
  const sbf = (await c.d.nachweisartAusVorschlag('DE_SPFV_SBF')).id;
  const tier = (await c.d.nachweisartAusVorschlag('EU_HEIMTIERAUSWEIS')).id;
  assert.ok((await c.d.anforderungAnlegen(c.boot, { bezeichnung: ' ', artIds: [sbf] })).fehler.bezeichnung);
  assert.ok((await c.d.anforderungAnlegen(c.boot, { bezeichnung: 'SBF', artIds: [] })).fehler.artIds);
  assert.ok((await c.d.anforderungAnlegen(c.boot, { bezeichnung: 'SBF', artIds: [tier] })).fehler.artIds, 'Tier-Nachweis ist keine Befähigung');
  assert.equal((await c.d.anforderungAnlegen('gibt-es-nicht', { bezeichnung: 'X', artIds: [sbf] })).ok, false);
  const r = await c.d.anforderungAnlegen(c.boot, { bezeichnung: 'Sportbootführerschein', artIds: [sbf, 'unbekannt'] });
  assert.ok(r.ok);
  const l = await c.d.anforderungenListe(c.boot);
  assert.deepEqual(l.map(x => [x.aktuell.werte.bezeichnung, x.artNamen]), [['Sportbootführerschein', ['Sportbootführerschein']]]);
  assert.deepEqual(l[0].aktuell.werte.artIds, [sbf]);
  assert.ok((await c.d.anforderungAendern(r.id, { bezeichnung: 'SBF', artIds: [sbf], gilt: 'nein' })).geaendert);
  assert.equal((await c.d.anforderungenListe(c.boot, true)).length, 0, 'abgeschaltet gilt nicht mehr');
  const x = await c.d.anforderungLaden(r.id);
  assert.equal(x.verlauf.length, 2);
  assert.equal((await c.d.anforderungenListe(c.wm)).length, 0, 'Anforderungen gehören zum Fahrzeug');
});

async function mitAnforderung(c, bis) {
  const fs = (await c.d.nachweisartAusVorschlag('DE_FEV_FUEHRERSCHEIN_EU')).id;
  const sbf = (await c.d.nachweisartAusVorschlag('DE_SPFV_SBF')).id;
  await c.d.anforderungAnlegen(c.boot, { bezeichnung: 'Sportbootführerschein', artIds: [sbf] });
  const { id } = await c.d.aktivitaetAnlegen(basis(c, { bisDatum: bis || '2026-12-10' }));
  return { id, fs, sbf };
}
const scan = { name: 'scan.jpg', type: 'image/jpeg', size: 100 };

test('Prüfung: Skipper mit gescanntem Nachweis = erlaubt, mit "geprüft am"', async () => {
  const c = await neu();
  const { id, sbf } = await mitAnforderung(c);
  await c.d.nachweisAnlegen('person', c.anna, sbf, { nummer: '1', datei: scan });
  const p = await c.d.aktivitaetPruefung(id);
  assert.equal(p.befaehigung.ergebnis, 'erlaubt');
  assert.equal(p.befaehigung.personen[0].person.name, 'Anna');
  assert.match(p.geprueftAm, /^2026-11-03T12:\d\d$/);
});

test('Prüfung: ohne Scan oder ohne Nachweis = unklar; Stellvertreter zählt mit', async () => {
  const c = await neu();
  const { id, sbf } = await mitAnforderung(c);
  assert.equal((await c.d.aktivitaetPruefung(id)).befaehigung.ergebnis, 'unklar', 'kein Nachweis');
  await c.d.nachweisAnlegen('person', c.anna, sbf, { nummer: '1' });
  assert.equal((await c.d.aktivitaetPruefung(id)).befaehigung.ergebnis, 'unklar', 'ohne Scan');
  await c.d.nachweisAnlegen('person', c.anna, sbf, { nummer: '1', datei: scan });
  assert.equal((await c.d.aktivitaetPruefung(id)).befaehigung.ergebnis, 'erlaubt');
  await c.d.besatzungHinzufuegen(id, c.ben, { rolle: 'stellvertreter' });
  const p = await c.d.aktivitaetPruefung(id);
  assert.equal(p.befaehigung.ergebnis, 'unklar', 'der Stellvertreter hat noch keinen Nachweis');
  assert.deepEqual(p.befaehigung.personen.map(x => [x.person.name, x.ergebnis]), [['Anna', 'erlaubt'], ['Ben', 'unklar']]);
  /* Crew wird nicht geprüft */
  await c.d.besatzungAendern((await c.d.aktivitaetLaden(id)).besatzung.find(b => b.person.name === 'Ben').besatzung.id, { rolle: 'crew' });
  assert.equal((await c.d.aktivitaetPruefung(id)).befaehigung.ergebnis, 'erlaubt');
});

test('Prüfung: gilt bis zum Ende des Zeitraums, nicht nur heute', async () => {
  const c = await neu();
  const fs = (await c.d.nachweisartAusVorschlag('DE_FEV_FUEHRERSCHEIN_EU')).id;
  await c.d.anforderungAnlegen(c.wm, { bezeichnung: 'Führerschein', artIds: [fs] });
  await c.d.nachweisAnlegen('person', c.anna, fs, { gueltigBis: '2026-12-05', datei: scan });
  const kurz = await c.d.aktivitaetAnlegen(basis(c, { fahrzeugId: c.wm, bisDatum: '2026-12-05' }));
  assert.equal((await c.d.aktivitaetPruefung(kurz.id)).befaehigung.ergebnis, 'erlaubt');
  const lang = await c.d.aktivitaetAnlegen(basis(c, { fahrzeugId: c.wm, vonDatum: '2026-12-01', bisDatum: '2026-12-06' }));
  const p = await c.d.aktivitaetPruefung(lang.id);
  assert.equal(p.befaehigung.ergebnis, 'nicht_erlaubt', 'heute gültig, aber nicht bis zum Ende');
  assert.ok(p.befaehigung.personen[0].gruende[0].text.includes('2026-12-05'));
});

test('Prüfung: ohne Anforderungen am Fahrzeug = unklar; Gebiet als Text macht "erlaubt" zu "unklar"', async () => {
  const c = await neu();
  const sbf = (await c.d.nachweisartAusVorschlag('DE_SPFV_SBF')).id;
  const a1 = await c.d.aktivitaetAnlegen(basis(c));
  const p1 = await c.d.aktivitaetPruefung(a1.id);
  assert.equal(p1.befaehigung.ergebnis, 'unklar'); assert.equal(p1.anforderungen, 0);
  await c.d.anforderungAnlegen(c.boot, { bezeichnung: 'SBF', artIds: [sbf] });
  await c.d.nachweisAnlegen('person', c.anna, sbf, { datei: scan });
  const a2 = await c.d.aktivitaetAnlegen(basis(c, { bezeichnung: 'Mit Gebiet', gebiet: 'Kroatien, Adria', vonDatum: '2027-03-01', bisDatum: '2027-03-05' }));
  const p2 = await c.d.aktivitaetPruefung(a2.id);
  assert.equal(p2.befaehigung.ergebnis, 'unklar');
  assert.ok(p2.befaehigung.gebietHinweis.includes('Kroatien, Adria'));
  assert.equal(p2.befaehigung.personen[0].ergebnis, 'erlaubt', 'die Person selbst ist in Ordnung');
});

test('Prüfung: Fristen bis zum Ende des Zeitraums mit geplanter Strecke, Sperre wird gemeldet', async () => {
  const c = await neu();
  const z = (await c.d.zaehlerAnlegen(c.wm, null, 'strecke', { bezeichnung: 'Kilometerstand' })).id;
  await c.d.zaehlerStandEintragen(z, { wert: '90000', datum: '2026-11-01' });
  await c.d.fristAnlegen(c.wm, null, { bezeichnung: 'Ölwechsel', kategorie: 'wartung', zaehlerId: z, zaehlerWert: '10000', wirkung: 'sperre', zuletztAm: '2026-01-01', zuletztStand: '84200' });
  await c.d.fristAnlegen(c.wm, null, { bezeichnung: 'TÜV', kategorie: 'pruefung', kalenderWert: '24', wirkung: 'warnen', zuletztAm: '2026-01-01' });
  const nah = await c.d.aktivitaetAnlegen(basis(c, { fahrzeugId: c.wm, geplanteStrecke: '2000' }));
  const weit = await c.d.aktivitaetAnlegen(basis(c, { bezeichnung: 'Weit', fahrzeugId: c.wm, geplanteStrecke: '6000', vonDatum: '2027-01-01', bisDatum: '2027-01-10' }));
  const pn = await c.d.aktivitaetPruefung(nah.id);
  assert.deepEqual(pn.fristen.zusammenfassung, { betroffen: 0, sperre: false, eingeschraenkt: false });
  const pw = await c.d.aktivitaetPruefung(weit.id);
  assert.equal(pw.fristen.liste[0].bezeichnung, 'Ölwechsel');
  assert.equal(pw.fristen.liste[0].status, 'faellig');
  assert.deepEqual(pw.fristen.zusammenfassung, { betroffen: 1, sperre: true, eingeschraenkt: false });
});

test('Sperre ausdrücklich übergehen: Zeit wird festgehalten und beim Ändern des Zeitraums gelöscht', async () => {
  const c = await neu();
  const { id } = await c.d.aktivitaetAnlegen(basis(c));
  assert.ok((await c.d.aktivitaetSperreUebergehen(id)).ok);
  let a = await c.d.aktivitaetLaden(id);
  assert.match(a.aktuell.werte.sperreUebergangenAm, /^2026-/);
  await c.d.aktivitaetAendern(id, basis(c, { bezeichnung: 'Umbenannt' }));
  a = await c.d.aktivitaetLaden(id);
  assert.ok(a.aktuell.werte.sperreUebergangenAm, 'nur Umbenennen ändert nichts daran');
  await c.d.aktivitaetAendern(id, basis(c, { bisDatum: '2026-12-20' }));
  a = await c.d.aktivitaetLaden(id);
  assert.equal(a.aktuell.werte.sperreUebergangenAm, null, 'anderer Zeitraum: neue Prüfung nötig');
});

test('Belegung: Überschneidung am selben Fahrzeug warnt, andere Fahrzeuge und stornierte nicht', async () => {
  const c = await neu();
  const a1 = await c.d.aktivitaetAnlegen(basis(c, { bezeichnung: 'A1' }));
  const a2 = await c.d.aktivitaetAnlegen(basis(c, { bezeichnung: 'A2', vonDatum: '2026-12-08', bisDatum: '2026-12-15' }));
  const a3 = await c.d.aktivitaetAnlegen(basis(c, { bezeichnung: 'A3', fahrzeugId: c.wm }));
  const a4 = await c.d.aktivitaetAnlegen(basis(c, { bezeichnung: 'A4', vonDatum: '2026-12-11', bisDatum: '2026-12-12' }));
  const liste = await c.d.aktivitaetenListe();
  const k = n => liste.find(x => x.aktuell.werte.bezeichnung === n).konflikte.length;
  assert.deepEqual([k('A1'), k('A2'), k('A3'), k('A4')], [1, 2, 0, 1]);
  assert.deepEqual((await c.d.aktivitaetPruefung(a1.id)).belegung.konflikte.map(x => x.name), ['A2']);
  await c.d.aktivitaetStornieren(a2.id, 'abgesagt');
  assert.deepEqual((await c.d.aktivitaetPruefung(a1.id)).belegung.konflikte, []);
  assert.deepEqual((await c.d.aktivitaetPruefung(a2.id)).belegung.konflikte, [], 'eine stornierte Aktivität blockiert nichts');
});

test('Liste: laufende, geplante, vergangene, stornierte in dieser Reihenfolge', async () => {
  const c = await neu();
  const mk = (n, v, b) => c.d.aktivitaetAnlegen(basis(c, { bezeichnung: n, vonDatum: v, bisDatum: b, fahrzeugId: n === 'Z' ? c.wm : c.boot }));
  await mk('Vorbei', '2026-09-01', '2026-09-05'); await mk('Laeuft', '2026-11-01', '2026-11-10'); await mk('Spaeter', '2027-02-01', '2027-02-05');
  const z = await mk('Z', '2027-06-01', '2027-06-05'); await c.d.aktivitaetStornieren(z.id, '');
  await mk('Bald', '2026-12-01', '2026-12-05');
  const l = await c.d.aktivitaetenListe();
  assert.deepEqual(l.map(x => [x.aktuell.werte.bezeichnung, x.status]), [['Laeuft', 'laeuft'], ['Bald', 'geplant'], ['Spaeter', 'geplant'], ['Vorbei', 'vorbei'], ['Z', 'storniert']]);
});

test('Löschen aller Daten leert auch Aktivitäten, Besatzung, Verantwortung und Anforderungen', async () => {
  const c = await neu();
  await mitAnforderung(c);
  await c.d.allesLoeschen();
  for (const t of ['aktivitaeten', 'aktivitaetsarten', 'besatzung', 'verantwortung', 'anforderungen']) assert.equal((await c.d.speicher.alle(t)).length, 0, t);
});
