# Änderungen

## 2.0.9
- Sicherungsdatei: Ein Tipp in den Einstellungen erzeugt eine Datei (.mmsicherung) mit allen Daten. Sie lässt sich auf dem Gerät speichern oder über „Teilen“ in die Cloud legen.
- Wahlweise mit Schlüsselwort verschlüsselt (AES-256, Schlüssel aus dem Schlüsselwort mit PBKDF2). Wer das Schlüsselwort vergisst, kann die Sicherung nicht öffnen. Ohne Schlüsselwort warnt die App.
- Dokumente und Scans lassen sich mitsichern oder weglassen. Die Größe wird vorher angezeigt.
- Wiederherstellen: Die App prüft die Datei (Aufbau, Prüfsumme, Version) und zeigt, was in der Sicherung steht und was ersetzt wird. Erst nach ausdrücklicher Bestätigung werden ALLE Daten auf dem Gerät ersetzt, in einem Schritt: Gelingt nicht alles, bleibt der bisherige Stand unverändert. Defekte, veränderte oder aus einer neueren Version stammende Dateien werden mit verständlicher Meldung abgelehnt.
- Erinnerung an die Sicherung im Hauptmenü, einstellbar (nie, 14, 30 oder 90 Tage). Die Einstellungen zeigen das Datum der letzten Sicherung.
- Der Speicher auf dem Gerät wurde auf Datenbank-Version 7 umgestellt. Vorhandene Daten bleiben erhalten.
- Noch nicht dabei: automatische Sicherung, Zusammenführen mehrerer Geräte (kommt mit Konten und Server).

## 2.0.8
- Aktivität (ersetzt „Nutzung“): Name, Art, Fahrzeug, Zeitraum (Datum von bis, Uhrzeit freiwillig), Gebiet als Text, geplante Strecke und Betriebsstunden, mitreisende Tiere, Notiz.
- Arten von Aktivitäten als offene Liste mit den Vorschlägen Urlaub, Törn, Ausfahrt, Wasserski, Segeln, Rallye.
- Besatzung aus den Personen. Skipper (Boot), Fahrer (Land), Stellvertreter und Crew. Jede Person steht einmal da, „dabei von bis“ ist möglich, die Crew ist austauschbar.
- Verantwortung: Zu jedem Zeitpunkt ist genau eine Person verantwortlich. Wechsel nur zwischen Skipper oder Fahrer und Stellvertretern, jeweils mit Datum und Uhrzeit, nur nach vorn in der Zeit.
- Anforderungen am Fahrzeug: Welche Nachweise ein Skipper oder Fahrer braucht. Es genügt je Anforderung eine der gewählten Nachweisarten, alle Anforderungen müssen erfüllt sein.
- Prüfung bei der Planung mit „geprüft am“: Befähigung („erlaubt“ nur mit Scan und gültig bis zum Ende des Zeitraums, „nicht erlaubt“ nur bei einem Nachweis, der vor dem Ende abläuft, sonst „unklar“), Fristen bis zum Ende des Zeitraums mit geplanter Strecke, Überschneidungen am Fahrzeug. Ein Gebiet als Text macht „erlaubt“ zu „unklar“.
- Eine Sperre durch eine Frist lässt sich ausdrücklich übergehen. Die Zeit wird festgehalten.
- Stornieren ohne zu löschen, mit Grund, und Wiederherstellen.
- Der Speicher auf dem Gerät wurde auf Datenbank-Version 6 umgestellt. Vorhandene Daten bleiben erhalten.
- Noch nicht dabei: Gebiete mit Anforderungen, Tagesabschnitte und Reisecheck, Prüfung bei jedem Tagesbeginn und Wechsel unterwegs, Verleih und Zusage.

## 2.0.7
- Personen (Name, Funktionen Skipper, Fahrer, Crew, Beifahrer, Gast, E-Mail und Telefon freiwillig) und Tiere (Name, Tierart, Chipnummer). Geburtsdatum und Wohnort gehören nicht zur Person, sondern zu den Nachweisen.
- Nachweise an Personen, Tieren und Fahrzeugen: Nummer, Aussteller, Ausstellungsdatum, „gültig bis“, Klassen oder Stufen, Notiz und weitere Angaben je Art. Status „Gültig“, „Läuft bald ab“ (30 Tage), „Abgelaufen“, „Ohne Ablauf“ oder „Datum fehlt“. Herkunft: von Hand.
- Optionaler Scan oder Foto je Nachweis. Er liegt in einer eigenen Ablage und bleibt nur auf dem Gerät.
- Die Liste der Nachweisarten ist offen. Eigene Arten mit eigenen Angaben (Beschriftung, Typ, Stelle auf dem Papier) sind möglich.
- Vorschläge für Deutschland und die EU (16 Arten) mit Quelle und Prüfstand: Führerschein, Personalausweis, Reisepass, Sportbootführerschein, Funkzeugnisse SRC, LRC und UBI, EU-Heimtierausweis, Tollwutimpfung, Zulassungsbescheinigung Teil I und II, Hauptuntersuchung, Internationaler Bootsschein, CE-Konformitätserklärung, Kennzeichnung Kleinfahrzeug, Schiffsregister-Unterlage. Zwei sind vollständig geprüft, elf teilweise, drei noch nicht.
- Übernommene Vorschläge sind frei änderbar. Änderungen an Arten, Personen, Tieren und Nachweisen sind neue Einträge „Korrektur zu …“, nichts geht verloren.
- Die Fahrzeugliste zeigt abgelaufene und bald ablaufende Nachweise. Die Einstellungen zeigen den Platz für Scans.
- Der Speicher auf dem Gerät wurde auf Datenbank-Version 5 umgestellt. Vorhandene Daten bleiben erhalten.
- Noch nicht dabei: automatisches Einlesen (Smart Capture), die Prüfung von Nachweisen bei Aktivitäten und im Reisecheck, Konto und Einladung für Personen, Nachweise für Komponenten.

## 2.0.6
- Dokumente an Fahrzeug und Komponente: Bedienungsanleitung, Ersatzteilliste, Wartungsanleitung, Kaufbeleg oder Rechnung, Garantie, Foto, Sonstiges.
- Ein Dokument ist eine Datei vom Gerät oder ein Link (nur http und https). Dateien liegen auf dem Gerät und sind auch ohne Internet da. Die Datei liegt in einer eigenen Ablage, getrennt vom Eintrag, damit später ein Server dazukommen kann.
- Am Fahrzeug eine Gesamtliste aller Dokumente, nach Komponente geordnet, mit Suche. Dateien lassen sich öffnen oder auf dem Gerät speichern, Fotos werden gezeigt.
- Angaben zu einem Dokument lassen sich ändern (neuer Eintrag „Korrektur zu …“). Die Datei selbst bleibt unverändert, für eine andere Datei wird ein neues Dokument angelegt.
- Ist der Speicher des Geräts voll, meldet die App das verständlich.
- Einstellungen zeigen, wie viel Speicher die Dokumente belegen und wie viel Platz der Browser erlaubt.
- Der Speicher auf dem Gerät wurde auf Datenbank-Version 4 umgestellt. Vorhandene Daten bleiben erhalten.
- Noch nicht dabei: Abgleich zwischen mehreren Geräten und „Offline verfügbar“ vom Server (kommt mit den Konten), Smart Capture.

## 2.0.5
- Fristen am Fahrzeug und an jeder Komponente. Eine Frist gilt nach Zeit (Monate oder Jahre), nach Zähler (Strecke oder Betriebsstunden) oder nach beidem. Was zuerst eintritt, löst die Fälligkeit aus.
- Zähler am Fahrzeug oder an einer einzelnen Komponente (zum Beispiel pro Motor). Der Zählerstand ist ein Verlauf von Handeinträgen, der neueste gilt. Stände steigen nur.
- Jede Frist zeigt „In Ordnung“, „Bald fällig“, „Überfällig“ oder „Angaben fehlen“. Die Fahrzeugliste zeigt überfällige und bald fällige Fristen.
- Wirkung bei Überfälligkeit (nur warnen, eingeschränkt, Sperre) und Vorwarnung (Tage, bei Zählern Strecke oder Stunden) sind einstellbar. Die Wirkung selbst greift erst bei Verleih und Aktivitäten, das folgt später.
- „Erledigt eintragen“ legt eine Erledigung an und setzt die Rechnung neu an. Ein höherer Zählerstand wird dabei auch im Zähler eingetragen. Frühere Erledigungen bleiben sichtbar.
- Änderungen an Fristen und Zählernamen sind wie bisher neue Einträge „Korrektur zu …“.
- Der Speicher auf dem Gerät wurde auf Datenbank-Version 3 umgestellt. Vorhandene Daten bleiben erhalten.
- Noch nicht dabei: Zähler per Start/Stopp-Schalter, Zählerstände aus Aktivitäten, Kosten der Erledigungen, Prüfung von Fristen bei Anfragen und im Reisecheck.

## 2.0.4
- Hauptkomponenten (Schale 3): Motor, Getriebe, Heizung, Klima, Stromversorgung, Wasserversorgung und Sonstiges.
- Beliebig tiefe Aufschlüsselung darunter. Es gibt nur eine Liste für alle Komponenten, jede „gehört zu“ einem Fahrzeug oder einer anderen Komponente.
- Zu jeder Komponente: Hersteller, Modell, Seriennummer, Baujahr, Eingebaut am, Einbauort, Ausgebaut am und technische Merkmale (Name und Wert).
- Änderungen sind wie beim Fahrzeug neue Einträge „Korrektur zu …“, nichts wird überschrieben oder gelöscht. Ausgebaute Teile stehen eingeklappt unter „Ausgebaut“.
- Der Speicher auf dem Gerät wurde auf Datenbank-Version 2 umgestellt. Vorhandene Fahrzeuge bleiben erhalten.
- Neuer Hinweis „Neue Version bereit“ mit Knopf zum Neuladen, damit eine hochgeladene neue Version nicht übersehen wird.
- Noch nicht dabei: Fristen, Kosten und Nachweise an den Komponenten, ein fester Merkmal-Katalog.

## 2.0.3
- Startseite neu gestaltet. Vor den drei Teilen des Kernsatzes stehen die Logo-Buchstaben V, T und D.
- Infotext nennt „Reisen planen“ statt „Reisen prüfen“.
- Das Logo ist eine einzige Datei (`icons/icon.svg`) und wird auf der Startseite, in der Kopfzeile und als App-Symbol verwendet. Das jetzige Zeichen ist ein Platzhalter.

## 2.0.2
- Startseite mit Logo, Kernsatz „Dein Fahrzeug. Dein Weg. Deine Daten.“, Copyright und den Knöpfen „Programm starten“ und „Neu im Programm“.
- Hauptmenü mit den Kacheln Stammdaten, Funktionen (kommt) und Einstellungen.
- Stammdaten mit Fahrzeugen. Personen und Tiere sind als „kommt“ vorgesehen.
- Seite „Neu im Programm“ mit der Liste der Änderungen (steht in `js/texte.js`).
- Einstellungen mit Datenhinweis, Versionsangabe und dem Testknopf zum Löschen.
- Die Fahrzeugliste ist jetzt unter Stammdaten erreichbar, der Rest aus 2.0.1 ist unverändert.
- Neue Prüfungen: Versionsnummer, Änderungsliste und Dateiliste für den Offline-Betrieb müssen zusammenpassen.

## 2.0.1 – Schritt 1
- Neu aufgebaut, nicht aus V1 geflickt.
- Fahrzeugliste mit Kennung (Schale 1) und äußere Hülle (Schale 2).
- Sieben feste Fahrzeugarten: Auto, Motorrad, Wohnmobil, Wohnwagen, Oldtimer, Boot, Flugzeug. Felder je nach Art, zum Beispiel Tiefgang nur beim Boot, Achsen nur an Land.
- Handeingabe mit Prüfung. Änderungen werden als neuer Eintrag „Korrektur zu …“ gespeichert, der alte Stand bleibt im Verlauf.
- Offline-fähig, Daten liegen lokal auf dem Gerät.
- Automatische Tests für die Daten-Schicht.
