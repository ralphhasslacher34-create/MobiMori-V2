/*
 * Texte, die das Programm von sich selbst zeigt: Kernsatz, Infotext,
 * Copyright und die Liste "Neu im Programm". Nur hier ändern.
 * Das Logo ist die Datei icons/icon.svg (zugleich das App-Symbol).
 */
(function (global) {
  'use strict';
  var MM = global.MM = global.MM || {};

  MM.Texte = {
    KERNSATZ: 'Dein Fahrzeug. Dein Weg. Deine Daten.',
    INFOTEXT: 'Fahrzeuge verwalten, Reisen planen und Erinnerungen festhalten. Auf Land, zu Wasser und in der Luft.',
    COPYRIGHT: '© 2026 Ralph Hasslacher',

    /* Neueste Version zuerst. Die oberste muss zu MM.VERSION passen (wird getestet). */
    NEUERUNGEN: [
      { version: '2.0.9', datum: '2026-11-03', punkte: [
        'Sicherungsdatei: ein Tipp erstellt eine Datei mit allen deinen Daten. Sie lässt sich speichern oder teilen, zum Beispiel in die Cloud.',
        'Wahlweise mit Schlüsselwort verschlüsselt. Darin stehen auch Ausweisdaten und Scans.',
        'Dokumente und Scans kannst du mitsichern oder weglassen. Vorher siehst du, wie groß es wird.',
        'Wiederherstellen: Die App zeigt zuerst, was in der Sicherung steht und was ersetzt wird. Erst nach deiner Bestätigung wird etwas verändert, und zwar ganz oder gar nicht.',
        'Die App erinnert an die Sicherung, nach 14, 30 oder 90 Tagen oder gar nicht.'
      ] },
      { version: '2.0.8', datum: '2026-11-03', punkte: [
        'Aktivitäten (Urlaub, Törn, Ausfahrt, Wasserski, Segeln, Rallye): Name, Art, Fahrzeug, Zeitraum mit freiwilliger Uhrzeit, Gebiet, geplante Strecke oder Betriebsstunden, Tiere und Notiz.',
        'Besatzung aus den Personen: Skipper oder Fahrer, Stellvertreter und Crew. Jede Person steht einmal da, bei Bedarf mit „dabei von bis“.',
        'Zu jedem Zeitpunkt ist genau eine Person verantwortlich. Jeder Wechsel wird mit Zeitpunkt festgehalten.',
        'Prüfung bei der Planung: Befähigung von Skipper oder Fahrer und Stellvertretern (erlaubt, nicht erlaubt, unklar, mit „geprüft am“), Fristen bis zum Ende des Zeitraums und Überschneidungen am Fahrzeug.',
        'Am Fahrzeug legst du fest, welche Nachweise ein Skipper oder Fahrer braucht.',
        'Aktivitäten lassen sich jederzeit stornieren und wiederherstellen. Nichts wird gelöscht.'
      ] },
      { version: '2.0.7', datum: '2026-11-03', punkte: [
        'Personen mit Funktionen (Skipper, Fahrer, Crew, Beifahrer, Gast) und Tiere mit Tierart und Chipnummer.',
        'Nachweise an Personen, Tieren und Fahrzeugen, mit „gültig bis“, Status und optionalem Scan oder Foto, das nur auf dem Gerät bleibt.',
        'Die Liste der Nachweisarten ist offen: Du legst eigene Arten an oder übernimmst Vorschläge für Deutschland und die EU. Jeder Vorschlag nennt seine Quelle und wie weit er geprüft ist.',
        'Vorschläge: Führerschein, Personalausweis, Reisepass, Sportbootführerschein, Funkzeugnisse, Heimtierausweis, Tollwutimpfung, Zulassungsbescheinigung Teil I und II, Hauptuntersuchung, Internationaler Bootsschein und mehr.',
        'Die Fahrzeugliste zeigt auch abgelaufene und bald ablaufende Nachweise.'
      ] },
      { version: '2.0.6', datum: '2026-11-03', punkte: [
        'Dokumente an Fahrzeug und Komponente: Bedienungsanleitung, Ersatzteilliste, Wartungsanleitung, Kaufbeleg, Garantie, Foto oder Sonstiges.',
        'Als Datei vom Gerät (auch ohne Internet da) oder als Link ins Internet.',
        'Am Fahrzeug gibt es eine Gesamtliste aller Dokumente, nach Komponente geordnet und mit Suche.',
        'In den Einstellungen siehst du, wie viel Speicher die Dokumente belegen und wie viel Platz der Browser erlaubt.'
      ] },
      { version: '2.0.5', datum: '2026-11-03', punkte: [
        'Fristen am Fahrzeug und an jeder Komponente: nach Zeit (Monate oder Jahre), nach Zähler (Strecke oder Betriebsstunden) oder nach beidem. Was zuerst eintritt, löst die Fälligkeit aus.',
        'Zähler am Fahrzeug oder pro Komponente, zum Beispiel pro Motor, mit Verlauf der Zählerstände.',
        'Jede Frist zeigt, ob sie in Ordnung, bald fällig oder überfällig ist. In der Fahrzeugliste siehst du es auf einen Blick.',
        'Wirkung bei Überfälligkeit (nur warnen, eingeschränkt, Sperre) und Vorwarnung sind einstellbar.',
        '„Erledigt eintragen“ setzt die Rechnung einer Frist neu an, frühere Erledigungen bleiben sichtbar.'
      ] },
      { version: '2.0.4', datum: '2026-11-03', punkte: [
        'Hauptkomponenten (Schale 3): Motor, Getriebe, Heizung, Klima, Stromversorgung, Wasserversorgung und Sonstiges.',
        'Darunter lässt sich beliebig tief aufschlüsseln, zum Beispiel Motor, Einspritzung, Pumpe.',
        'Zu jedem Teil: Hersteller, Modell, Seriennummer, Baujahr, Einbau, Ausbau und technische Merkmale.',
        'Änderungen bleiben wie beim Fahrzeug im Verlauf sichtbar.',
        'Wenn eine neue Version bereitsteht, erscheint ein Hinweis zum Neuladen.'
      ] },
      { version: '2.0.3', datum: '2026-11-03', punkte: [
        'Startseite neu gestaltet: Die Buchstaben V, T und D des Logos stehen vor den drei Teilen des Kernsatzes.',
        'Infotext: „Reisen planen“.',
        'Das Logo ist an einer einzigen Stelle abgelegt und gilt auf der Startseite, in der Kopfzeile und als App-Symbol.'
      ] },
      { version: '2.0.2', datum: '2026-11-03', punkte: [
        'Startseite mit Logo, Kernsatz und den Knöpfen „Programm starten“ und „Neu im Programm“.',
        'Hauptmenü mit Stammdaten, Funktionen und Einstellungen.',
        'Stammdaten mit den Fahrzeugen. Personen und Tiere folgen.',
        'Einstellungen mit Hinweisen zu deinen Daten.'
      ] },
      { version: '2.0.1', datum: '2026-11-03', punkte: [
        'Fahrzeugliste und äußere Hülle für sieben Fahrzeugarten.',
        'Eingaben von Hand, jede Änderung bleibt im Verlauf sichtbar.',
        'Funktioniert ohne Internet, die Daten liegen auf dem Gerät.'
      ] }
    ]
  };
})(typeof window !== 'undefined' ? window : (typeof self !== 'undefined' ? self : globalThis));
